-- After live release 13-07-2023
-- Add new column to table (wms_workflow_eventod_details)
ALTER TABLE IF EXISTS public.wms_workflow_eventlog_details
    ADD COLUMN actualactivitycount smallint;

-- adding actualactivitycount on view (wms_tasklist)
wms_tasklist


--Is8224 ( july 31 - 2023)
   alter table wms_wip_wostage_notes add column responsibilitytext character varying(1000);
   sp changes : insert_wipstage_notes

   -- IS8224 (page Target changes aug- 8-2023)
   view changes : wms_wfevent_details

   -- modify on view table (wms_task_files)

   sp changes:  enabl collation activity for cup journals
   getarticlestagetrigger

-- Is8224 - cup journals - instruction pop for view despatch screen

table : wms_workorder_stage_instructions (wostageid should be null)

sp changes : workorder_autocreation

--- next stage config table
ALTER TABLE IF EXISTS public.wms_workflow_nextstage_map DROP COLUMN IF EXISTS currentstageid;

ALTER TABLE IF EXISTS public.wms_workflow_nextstage_map
    ALTER COLUMN nextstageid DROP NOT NULL;

ALTER TABLE IF EXISTS public.wms_workflow_nextstage_map
    ALTER COLUMN submittype DROP NOT NULL;

ALTER TABLE IF EXISTS public.wms_workflow_nextstage_map
    ADD COLUMN wfstageconfigid bigint;

    ALTER TABLE IF EXISTS public.wms_workflow_nextstage_map
    ADD COLUMN flowtype character varying(200);

ALTER TABLE IF EXISTS public.wms_workflow_nextstage_map
    ADD CONSTRAINT wfstageconfigid_fk FOREIGN KEY (wfstageconfigid)
    REFERENCES public.wms_workflow_stageconfig (wfstageconfigid) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

------------- add new column to table (wms_workflow_stageconfig)
ALTER TABLE IF EXISTS public.wms_workflow_stageconfig
    ADD COLUMN enableautostagetrnsf boolean;


-- IS8224 - 29-08-2023
Table : wms_ftp_audit  (new column added : status, remarks, createdon, wfeventid)

-- IS7359 - 30-08-2023
select * from wms_mst_view_config where screenid=3 and entityid=3
need to add an additional data to a column (columnfields) value next to mspage
    {
		"id": "wordcount",
		"name": "Word Count",
		"fieldType": "number",
		"isShow": true,
		"isSort": true,
		"isAsc": false,
		"isSearch": false,
        "maxLength": 10,
		"isSearchType": "text",
		"searchValue": ""
	}

----- need to add a new column to table (wms_tasklist) - enableautostagetrnsf

-- IS8224 : delivery monitoring report changes
view changes : wms_delivery_monitoring_report

select * from public.wms_mst_view_config where viewid = 703 (changes)

select * from wms_mst_entity where entityid = 76

select * from public.wms_viewconfig_permissions
 where viewid = 703

 ----- new column added in wms_uimenu table on (07-09-2023) -----
 ALTER TABLE IF EXISTS public.wms_uimenu
    ADD COLUMN duid bigint[];

------ adding foren key to wms_email_audit ---
ALTER TABLE IF EXISTS public.wms_email_audit
    ADD COLUMN wfeventid bigint;
ALTER TABLE IF EXISTS public.wms_email_audit
    ADD CONSTRAINT wms_wfeventid_fk FOREIGN KEY (wfeventid)
    REFERENCES public.wms_workflow_eventlog (wfeventid) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;
-- new table added for springer on (12-09-2023) ---------
select * from wms_mst_referenceprofile

-- new column added in pp_mst_journal
referenceprofileid

changes in veiw : wms_detail_journal

 ---New Table Added for springer journals
-- wms_mst_referenceprofile
 CREATE TABLE IF NOT EXISTS public.wms_mst_referenceprofile

(

    referenceprofileid bigserial primary key,

    referenceprofile character varying(250) COLLATE pg_catalog."default",

    isactive boolean DEFAULT true,

    duid bigint,

    createdon timestamp without time zone DEFAULT now()

)

-- wms_mst_pdfa2bprofile
CREATE TABLE IF NOT EXISTS public.wms_mst_pdfa2bprofile

(
    pdfa2bprofileid bigserial primary key,

    pdfa2bprofile character varying(250) COLLATE pg_catalog."default",

    isactive boolean DEFAULT true,

    duid bigint,

    createdon timestamp without time zone DEFAULT now()

)

-- 
   ALTER TABLE IF EXISTS public.pp_mst_journal

    ADD COLUMN  referenceprofileid bigint;

    ALTER TABLE IF EXISTS public.pp_mst_journal

    ADD COLUMN pdfa2bprofileid bigint;


-- 06-10-2023 - sp changes fro issue workflow : 
workorder_autocreation

-- changes in view  : wf_event_details
wf_event_details


--pap workflow  for oup customer (21-02-2024_

--changes in tables : pp_mst_flowtype

pp_mst_flowtype


-- changes for wkh issue worklow partial batch  21-03-2024

changes in wms_workflow_details view

changes in new table  wms_audit_runonmerginghistory


--changes for run on for cup journal issue  23-04-2024

articleordersequence added new column in wms_workorder_incoming_filedetails

--changes for run on for cup journals 26=04-2024

changes in view : wms_tasklist

changes in view : wms_wfevent_details

changes in view : wms_wfevent_details for adding new fields index from wms_book_master table

-- 11-07-2024

changes in wms_tools_api table : added new column isactive : defualt : true

-- 12-08-2024  changes for book
changes in view : wms_wfevent_details


-- 16-10-2024 changes for elseiver books
ALTER TABLE wms_workorder_additionalinfo
ADD COLUMN pdfless int8,
ADD COLUMN fpprofileid int8,
ADD COLUMN rvsprofileid int8,
ADD COLUMN s300id int8,
ADD COLUMN o300id int8,
ADD COLUMN bookprintid int8;

-- 29-04-2025 changes for springer books
ALTER TABLE public.wms_book_master
ADD COLUMN book2 VARCHAR(5),
ADD COLUMN book2isbn VARCHAR(50);