// eslint-disable-next-line import/no-extraneous-dependencies
import { readFileSync } from 'fs';
import Pool from 'pg-pool';
import { appConfig } from '../config/app.js';
import logger from '../modules/utils/logs/index.js';

const packageConfig = JSON.parse(
  readFileSync('./package.json', { encoding: 'utf-8' }),
);

const config = () => {
  return {
    host: appConfig.postgres.host,
    port: appConfig.postgres.port,
    user: appConfig.postgres.user,
    database: appConfig.postgres.database,
    password: appConfig.postgres.password,
    application_name: packageConfig.name,
    ssl: appConfig.postgres.ssl,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 20000,
    max: 50,
  };
};

const pgPool = new Pool(config());
const pgPoolTrans = new Pool(config());

export const query = (queryString, queryParams = []) => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await pgPool.query(queryString, queryParams);
      resolve(result.rows);
    } catch (e) {
      logger.info('Query execution failed', e);
      logger.info('--------------------------');
      reject(e);
    }
  });
};

export const transaction = callback => {
  return new Promise(async (resolve, reject) => {
    try {
      logger.info('--------------------------');
      const client = await pgPoolTrans.connect();
      logger.info('Connection Established');
      try {
        logger.info('Transaction begin');
        await client.query('BEGIN');
        await callback(client);
        await client.query('COMMIT');
        logger.info('Transaction completed');
        resolve();
      } catch (e) {
        await client.query('ROLLBACK');
        logger.info('Transaction Rollbacked');
        reject(e);
      } finally {
        client.release();
        logger.info('PG Client released');
        logger.info('--------------------------');
      }
    } catch (e) {
      logger.info(e);
      reject(e);
    }
  });
};

export const transactionWithResult = callback => {
  return new Promise(async (resolve, reject) => {
    try {
      logger.info('--------------------------');
      const client = await pgPoolTrans.connect();
      logger.info('Connection Established');
      try {
        logger.info('Transaction begin');
        await client.query('BEGIN');
        const result = await callback(client);
        await client.query('COMMIT');
        logger.info('Transaction completed');
        resolve(result.rows);
      } catch (e) {
        await client.query('ROLLBACK');
        logger.info('Transaction Rollbacked');
        reject(e);
      } finally {
        client.release();
        logger.info('PG Client released');
        logger.info('--------------------------');
      }
    } catch (e) {
      logger.info(e);
      reject(e);
    }
  });
};
