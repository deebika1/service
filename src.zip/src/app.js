import http from 'http';
import express from 'express';
import session from 'express-session';
import cors from 'cors';
import bodyParser from 'body-parser';
import fileUpload from 'express-fileupload';
import corn from 'node-cron';
import compress from 'compression';
import helmet from 'helmet';
import { appConfig } from './config/app.js';
import router from './router/routes.js';
import { establishSocket } from './socket/index.js';
import { authenticate } from './auth/service/authentication.js';
import logger from './modules/utils/logs/index.js';
import {
  RepushtheJobtoMQ,
  runWipRefresh,
  logJobStatus,
} from './modules/bpmn/listener/create.js';

const app = express();

const server = http.createServer(app);
const SIX_MONTHS = 15778476000;
// It should be removed once we get the SSL certificate
process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

establishSocket(server);
app.set('showStackError', true);
app.enable('jsonp callback');
app.use(
  compress({
    filter(req, res) {
      return /json|text|javascript|css|font|svg/.test(
        res.getHeader('Content-Type'),
      );
    },
    level: 9,
  }),
);
app.use(
  fileUpload({
    limits: {
      fileSize: 2000 * 1024 * 1024,
    },
    useTempFiles: true,
    uriDecodeFileNames: true,
    tempFileDir: '/tmp/',
    uploadTimeout: 0,
  }),
);
app.use(
  cors({
    origin: (origin, callback) => {
      return callback(null, true);
    },
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    preflightContinue: false,
    optionsSuccessStatus: 204,
    credentials: true,
  }),
);
app.options('*', cors());
app.set('trust proxy', 1);
app.use(function (req, res, next) {
  res.header('x-powered-by', 'Integra Software Services Pvt. Ltd.');
  res.header('server', 'Integra Software Services Pvt. Ltd.');
  next();
});
app.disable('x-powered-by');
app.use(helmet.xFrameOptions());
app.use(helmet.noSniff());
app.use(helmet.ieNoOpen());
app.use(helmet.xssFilter());
app.use(
  helmet.hsts({
    maxAge: SIX_MONTHS,
    includeSubDomains: true,
    force: true,
  }),
);
app.use(
  session({
    secret: process.env.OAUTH_SESSION_SECRET,
    saveUninitialized: true,
    resave: false,
    cookie: {
      secure: appConfig.protocol == 'https',
      httpOnly: true,
    },
  }),
);

app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.json({ limit: '50mb' }));
app.get('/restartcheck', async (req, res) => {
  res.send('Server resatrtred');
});
app.use(`${appConfig.basePath}/`, authenticate, router);
// eslint-disable-next-line no-unused-vars
app.use(function (err, req, res, next) {
  // If err has no specified error code, set error code to 'Internal Server Error (500)'
  if (!err.statusCode) {
    err.statusCode = 500;
  }
  res.status(err.statusCode).send({
    status: false,
    error: err.message,
  });
});

server.setTimeout(1800000);
server.listen(
  appConfig.port,
  logger.info(`WMS server is listening on ${appConfig.port}`),
);

corn.schedule('0 */30 * * * *', () => {
  try {
    // mailReader();
    RepushtheJobtoMQ();
    logger.info(`Cron job called at ${new Date()}`);
  } catch (err) {
    logger.info(`Error occured in MailReader Cron : ${err.message}`);
  }
});
process.on('warning', e => {
  logger.info(e.message);
});

// Define your cron job (runs every 15 minutes)
corn.schedule('*/10 * * * *', async () => {
  const jobName = 'wip_refresh';
  try {
    console.log(`Running ${jobName}...`);

    await runWipRefresh();

    // Log successful execution
    await logJobStatus(jobName, 'success', 'Job completed successfully');
    console.log(`${jobName} completed successfully.`);
  } catch (error) {
    // Log failure
    await logJobStatus(jobName, 'failure', `Error: ${error.message}`);
    console.error(`${jobName} failed:`, error);
  }
});

process.on('unhandledRejection', error => {
  logger.info('unhandledRejection : ', error);
});

process.on('uncaughtException', error => {
  logger.info('uncaughtException : ', error);
});
