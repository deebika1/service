/* eslint-disable no-restricted-globals */
import moment from 'moment';
import axios from 'axios';
import { query, transaction } from '../../database/postgres.js';
import { emitAction } from '../../modules/activityListener/activityListener.js';
import {
  CreateOrUpdateuser,
  CreateOrUpdateDesigRole,
  CreateOrUpdateUserRole,
  getDuId,
  checkUserExistence,
  checkUserRoleExistence,
  deleteUserRole,
  isAppraiser,
} from '../datalayer/userUpdate.js';
import {
  insertPBDetails,
  updatePBDetails,
  getPbStatusId,
  getPbStatusDetById,
  insOrUpdateReviewerDetails,
  getPbStatusDetByAliasName,
  isPbEligible,
  getOpenKraList,
  getIdByField,
  getOrInsCurrentQuaterDetails,
  getQuaterDetailsByQcode,
  getQuaterDetailsByDate,
  getAppraisalType,
  getTemplateId,
  getUserDetailByUserIdScript,
  getReportHeadMappingScript,
  scoreAndRatingGetFilterOptionScript,
  scoreAndRatingGetFilterScript,
  scoreAndRatingGetFromMstUserScript,
  scoreAndRatingCreateGroupScript,
  getEmailTemplate,
  scoreAndRatingCreateRatingScript,
  assignGroupRatingScript,
  scoreAndRatingGetFromMstUserWithGroupScript,
  getDuHeadListScript,
  getFunctionalHeadistScript,
  getScoreRatingHistoryScript,
  insReOpenRequestScript,
  updatePbReOpenStatus,
  checkIsDOJAvailable,
  getDUHFUHScript,
  updDUHFUHScript,
} from '../datalayer/iaspireIntegration.js';
import {
  getQuaterListScript,
  getUserDeatilsForKraGoals,
  getKraGoals,
  getPrevQuarterListScript,
  getAppraisalId,
  insertKraLineItem,
  updateKraLineItem,
  deleteKraLineItem,
  updateKraGoalsSubmitStatus,
  getReportingManager,
  updateKraLineItemSelfScoreScript,
  insertPrevQuaterKraLineItemScript,
  getKraVersionListScript,
  getKraGoalsWithVersion,
  insAttachmentInfoScript,
  getAttachmentInfoScript,
  deleteAttachmentScript,
  getL1UsersListScript,
  getUserFoundInAppraisalMappingScript,
  updateMaxKeyScript,
  getOverAllFeedbacks,
  getAddScoreRemarks,
  getReOpenRejRemarksScript,
  getGoalRejRemarks,
  getReviewRejRemarks,
  getPBSummaryforKRA,
  getIsMLGoalExist,
} from '../datalayer/kraDetails.js';
import {
  insTemplateMst,
  updTemplateMst,
  get_iAspireSoftDel_query,
  get_iAspireHardDel_query,
  qprMasterGetTemplateDetailsScript,
  qprMasterGetCombinationScript,
  updateQprLineItemReviewScore,
  getBandLevelScript,
  getTemplateScript,
  getQprMasterDropDownDataScript,
  getQprScriptTemplateDataScript,
  getDesignationLevelScript,
} from '../datalayer/qprModule.js';
import {
  // getAppraisalYearScript,
  insOrUpdateAppraisalEntry,
  getEmpAppraisalList,
  // updateEmpAppraisalDet,
  getEmpAppraisalHistoryScript,
  getAppraisalTypeScript,
  // getOverAllEmpAppraisalList,
  getBandLevelListScript,
  getDesignationListScript,
} from '../datalayer/appraisalSetUp.js';
import {
  getMySquadListScript,
  // updateApprovalScript,
  // updateRejectScript,
  updateFeedbackScript,
  updateTotalScoreScript,
  updateAdditionalScoreScript,
  updateKraLineItemReviewScoreScript,
  getReopenReqListScript,
  getReopenReqTypeScript,
  getQuarterList,
  getiAspireUsrRoleAcry,
  getNextStatusROR,
  getNextStatusAppMap,
  updateNextStatusROR,
  updateNextStatusAppMap,
  getUserScoreRateScript,
  updateUserRatingScript,
  // getStatusUsingAliasName,
  updateQprLineItemReviewScoreScript,
  getSubordinatesList,
  getIsFirstPB,
  MLEmpList,
  getMLEmpStatus,
  changeGoalInActive,
  getIsMLInRestrictedStatusScript,
} from '../datalayer/mySquadGoals.js';
import {
  getPerformanceTypeMapped,
  getTempId,
  updatePerformanceMap,
  // insertPerformanceTypeHistory,
  getHistoryPerformanceMap,
  getAppraisalTypeforPerformanceTypeMapping,
} from '../datalayer/performanceMapping.js';
import {
  getMLDetails,
  getMlId,
  insertMLMapping,
  updateMLMapping,
  deleteMLMapping,
  getViewMLDetails,
  updateMlEntryFlag,
  checkIsMLEmp,
} from '../datalayer/mappingML.js';
import {
  getQPRLineitem,
  insertQPRLineItem,
  getQPRStatusforQuarter,
  getStatusListScript,
  getStatusTrackerCurrentScript,
  getLineItemRatingScript,
  getNewProductivityScript,
  getCCICCountScript,
  getQPRLineitemCount,
  updateQPRLineItem,
  getReportingEmail,
  modifyNotificationConfigFromEmails,
  getMonthandYearforLatestQuarter,
  getStatusTrackerRejectionScript,
  // getQPRAdditionalScoreforQuarter,
  getRatingforQuarter,
  getScoreusingAppraisalId,
  updateScoreandRating,
  getPBSummaryforQPR,
  getMonthandYearforReviewStartDateQuarter,
  getGoalEndDateForQuarter,
  getGoalEndDateForEmployee,
} from '../datalayer/qprDetails.js';
import {
  getPBEmpReportScript,
  insertClosingDateRangeScript,
  getClosingDateRangeScript,
  updateFinanceStsScript,
  getPBFinReportScript,
  getMasterDataScript,
  updateEmpStsScript,
  updatePBNoteScript,
  updateEmpPaidScript,
  getAddScoreScript,
  getRoleAcrScript,
  updateUnHoldScript,
  updateHoldScript,
  getGift,
  setGift,
  getUserGiftDetails,
  getGiftExcelDetails,
} from '../datalayer/reportData.js';
import { get_master_drop_down } from '../../iProductivity/dataLayer/masterDropDown.js';
import { remainderEmail } from '../helpers/remainderEmail.js';
import {
  checkIsEligibleScript,
  getAppEmpScript,
  getFinYearScript,
  getQuarterListforYearScript,
  getQuestionsScript,
  InsertEmpDataScript,
  UpdateEmpDataScript,
  InsertQueAnsScript,
  UpdateQueAnsScript,
  getQueAnsScript,
} from '../datalayer/appraisalForm.js';
import {
  getManagerEvaluationDataScript,
  getAppraisalStatusListScript,
  getB3AboveDesignationsScript,
  updateAppReviewDataScript,
  getEmpYearlyApprisalDetScript,
  getQueWithAnsScript,
  getAppNxtStausIdScript,
  getB3AboveBandLvlScript,
  checkAppManEvalEligibleScript,
} from '../datalayer/appManagerEvaluation.js';
import {
  getDesignationScript,
  getQuestionaliasnameScript,
  getFormAssessmentScript,
  getStatusScript,
  getfinancialYearScript,
  getAppraisalFormReport,
} from '../datalayer/formAssessment.js';

// iStrong Integration start

export const updateUserService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        empCode,
        empName,
        emailId,
        designationDesc,
        address1,
        phone,
        divisionDesc,
        isActive,
        l1Manager,
        category,
        bandLevel,
        doj,
        relievingDate,
        dob,
        gender,
        duHead,
        fuHead,
        unit,
        isServingNotice,
        functionName,
        businessDesignation,
        modifiedBy,
      } = info;
      const duId = await getDuId(divisionDesc);
      const itrackDuId = await getIdByField('duname', divisionDesc);
      const designationId = await getIdByField(
        'designationdesc',
        designationDesc,
      );
      const categoryId = await getIdByField('category', category);
      const bendLevelId = await getIdByField('bandlevel', bandLevel);
      const unitId = await getIdByField('unit', unit);
      const functionId = await getIdByField('function', functionName);
      const businessDesigId = await getIdByField(
        'bus_desig_name',
        businessDesignation,
      );
      let pbType = 'YTD';
      if (await isPbEligible(empCode)) {
        pbType = await getAppraisalType(categoryId);
      }
      const result = await CreateOrUpdateuser(
        empCode,
        empName,
        emailId,
        designationDesc,
        designationId,
        address1,
        phone,
        duId,
        isActive,
        l1Manager,
        categoryId,
        bendLevelId,
        doj,
        relievingDate,
        dob,
        gender,
        itrackDuId,
        duHead,
        fuHead,
        pbType,
        unitId,
        isServingNotice,
        functionId,
        businessDesigId,
        modifiedBy,
      );
      if (isActive === 'true') {
        if (designationDesc && designationDesc.trim() !== '') {
          const result2 = await CreateOrUpdateDesigRole(designationDesc);
          if (result2 && result2 !== '') {
            const roleIds =
              result2.length >= 1 ? result2.split(',') : [result2];

            for (const roleId of roleIds) {
              await CreateOrUpdateUserRole(empCode, roleId.trim());
            }
          }
        }
        // Insert or update Appraisal Setup entry
        // if (doj != null) {
        //   const effYearScript = getAppraisalYearScript();
        //   const effYear = await query(effYearScript, [empCode]);
        //   await insOrUpdateAppraisalEntry(
        //     empCode,
        //     3,
        //     effYear[0].effyear,
        //     modifiedBy,
        //   );
        // }
      }
      // To map the iAspire role for Appraisee and Appraiser
      await iaspireRoleMapping(empCode, l1Manager);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insOrUpdTransEntryService = async (
  empCode,
  quarterCode,
  modifiedBy,
  startDate,
  isML,
) => {
  let appraisalId = null;
  let templateId = null;
  let statusId = 1;
  let maxKraAttachKey = 0;
  const currentDate = new Date();
  const script = getUserDetailByUserIdScript(empCode);
  const userDetails = await query(script, [empCode]);
  const dateParam = startDate || userDetails[0].doj;
  const isEligible = await isUserEligible(dateParam, quarterCode);

  const quarterDetails = await getQuaterDetailsByQcode(quarterCode);

  if (isEligible) {
    if (
      userDetails[0].pbtype &&
      userDetails[0].pbtype.toUpperCase() === 'QPR'
    ) {
      templateId = await getTemplateId(
        userDetails[0].designationid,
        userDetails[0].itracks_duid,
        userDetails[0].bandlevelid,
      );
      statusId =
        currentDate > quarterDetails[0]?.review_deadline && !isML
          ? await getPbStatusDetByAliasName('REVIEW_EXPIRED')
          : await getPbStatusDetByAliasName('REVIEW_PENDING_L1');
    } else {
      statusId = isML
        ? await getPbStatusDetByAliasName('REVIEW_PENDING_L1')
        : currentDate > quarterDetails[0]?.goal_deadline
        ? await getPbStatusDetByAliasName('GOAL_EXPIRED')
        : await getPbStatusDetByAliasName('GOAL_PENDING_EMPLOYEE');
    }

    if (
      (templateId && userDetails[0]?.pbtype.toUpperCase() === 'QPR') ||
      userDetails[0]?.pbtype.toUpperCase() === 'KRA'
    ) {
      appraisalId = await getAppraisalId(empCode, quarterCode);

      if (!appraisalId) {
        // Inserting appraisal details
        appraisalId = await insertPBDetails(
          empCode,
          quarterCode,
          userDetails[0].pbtype,
          statusId,
          templateId,
          quarterDetails[0]?.goal_deadline,
          quarterDetails[0]?.review_deadline,
          modifiedBy,
          isML,
        );
      } else {
        if (isML) {
          const getcurrStatusScript = getMLEmpStatus();
          const currStatus = await query(getcurrStatusScript, [
            empCode,
            quarterCode,
          ]);
          // we are checking the status id
          const isMLInRestrictedStatus = await query(
            getIsMLInRestrictedStatusScript(),
            [currStatus[0]?.statusid],
          );
          // if ml in restricted status we should update the same status
          if (isMLInRestrictedStatus[0].is_restricted_status) {
            statusId = currStatus[0]?.statusid;
          }
        } else {
          statusId = await getPbStatusId(empCode, quarterCode);
        }
        // For ML, if goals is not approved, copy from last quarter check
        if (
          isML &&
          appraisalId &&
          userDetails[0]?.pbtype.toUpperCase() === 'KRA'
        ) {
          const isGoalExistScript = getIsMLGoalExist();
          const isGoalExist = await query(isGoalExistScript, [appraisalId]);
          if (isGoalExist.length == 0) {
            const goalInactiveScript = changeGoalInActive();
            await query(goalInactiveScript, [appraisalId]);
            await copyPrevQuarterKraGoalsService(empCode, quarterCode);
          }
        }

        // Updating appraisal details
        maxKraAttachKey = await updatePBDetails(
          empCode,
          quarterCode,
          userDetails[0].pbtype,
          statusId,
          templateId,
          // modifiedBy,
          isML,
          quarterDetails[0]?.goal_deadline,
          quarterDetails[0]?.review_deadline,
        );
      }
      if (appraisalId) {
        // Insert the Reviewer Details
        await reviewerDetailsMapping(
          empCode,
          userDetails[0].reportingto,
          userDetails[0].duhead,
          userDetails[0].functionalhead,
          modifiedBy,
        );
      }
    } else {
      // throw new Error({
      //   message: `Template is not found for this user ${empCode}`,
      //   AppType: userDetails[0]?.pbtype.toUpperCase(),
      // });
      return {
        empCode,
        AppType: userDetails[0]?.pbtype.toUpperCase(),
        AppraisalId: appraisalId,
        TemplateId: templateId,
      };
    }
  }
  const statusName = await getPbStatusDetById(statusId);
  return {
    AppraisalId: appraisalId,
    AppType: userDetails[0].pbtype,
    TemplateId: templateId,
    Status: statusName[0].status,
    Status_alias: statusName[0].alias_name,
    Status_category: statusName[0].status_category,
    MaxKraAttachKey: maxKraAttachKey || 0,
    empCode,
  };
};

const reviewerDetailsMapping = async (
  empCode,
  l1Manager,
  duHead,
  fuHead,
  modifiedBy,
) => {
  if (l1Manager && l1Manager !== '') {
    const l2Manager = await getReportingManager(l1Manager);

    const openKraList = await getOpenKraList(empCode);
    if (openKraList) {
      for (let i = 0; i < openKraList.length; i++) {
        await insOrUpdateReviewerDetails(
          openKraList[i].appraisalid,
          l1Manager,
          l2Manager,
          duHead,
          fuHead,
          modifiedBy,
        );
      }
    }
  }
};

const isUserEligible = async (dateParam, quarterCode) => {
  const date = new Date(dateParam);
  const quarterDetails = await getQuaterDetailsByQcode(quarterCode);
  const qEndDate = new Date(quarterDetails[0]?.enddate);

  const differenceInDays = Math.abs((qEndDate - date) / (1000 * 60 * 60 * 24));

  return differenceInDays >= 15;
};

const iaspireRoleMapping = async (empCode, l1Manager) => {
  const appraiseeRoleId = await getIdByField('rolename', 'Appraisee');
  // Appraisee Role mapping
  if (!(await isAppraiser(empCode))) {
    await CreateOrUpdateUserRole(empCode, appraiseeRoleId);
  }
  // Appraiser Role mapping
  if (l1Manager !== null) {
    const userExists = await checkUserExistence(l1Manager);
    if (userExists) {
      const appraiserRoleId = await getIdByField('rolename', 'Appraiser');
      await CreateOrUpdateUserRole(l1Manager, appraiserRoleId);
      if (await checkUserRoleExistence(l1Manager, appraiseeRoleId)) {
        await deleteUserRole(l1Manager, appraiseeRoleId);
      }
    }
  }
};

export const maternityLeaveIntegrationService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        empCode,
        startDate,
        endDate,
        // reqType,
        approveStatus,
        modifiedBy,
      } = info;
      const mlId = await getMlId(empCode);
      if (mlId) {
        if (
          approveStatus.toLowerCase().includes('completed') ||
          approveStatus.toLowerCase().includes('approved')
        ) {
          await updateMLMapping(empCode, mlId, startDate, endDate, modifiedBy);
          await pbMappingForML(empCode, startDate, modifiedBy);
        } else {
          await deleteMLMapping(empCode, mlId);
          await pbUnMappingForML(empCode, startDate, modifiedBy);
        }
      } else if (
        approveStatus.toLowerCase().includes('completed') ||
        approveStatus.toLowerCase().includes('approved')
      ) {
        await insertMLMapping(empCode, startDate, endDate, modifiedBy);
        await pbMappingForML(empCode, startDate, modifiedBy);
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

const pbMappingForML = async (empCode, startDate, modifiedBy) => {
  // Check if the user exists
  const userExists = await checkUserExistence(empCode);
  if (!userExists) return;

  // Get quarter details by start date
  const quarterDetails = await getQuaterDetailsByDate(startDate);
  if (quarterDetails.length === 0) return;

  // Insert or update transaction entry
  const result = await insOrUpdTransEntryService(
    empCode,
    quarterDetails[0]?.quartercode,
    modifiedBy,
    startDate,
    false,
  );

  // Update ML entry flag if AppraisalId is available
  if (result?.AppraisalId) {
    await updateMlEntryFlag(result.AppraisalId, true, modifiedBy);
  }

  // Update KRA goals submit status for KRA type
  if (result?.AppraisalId && result?.AppType === 'KRA') {
    const kraGoalsScript = await getKraGoals();
    let currentKraGoals = await query(kraGoalsScript, [
      empCode,
      quarterDetails[0]?.quartercode,
    ]);
    const statusAlias = 'REVIEW_PENDING_L1';
    const statusId = await getPbStatusDetByAliasName(statusAlias);
    // If no current KRA goals or goals are pending, copy previous quarter KRA goals
    if (
      currentKraGoals.length === 0 ||
      currentKraGoals[0]?.alias_name === 'GOAL_PENDING_EMPLOYEE' ||
      currentKraGoals[0]?.alias_name === 'GOAL_EXPIRED' ||
      currentKraGoals[0]?.alias_name === 'GOAL_REOPEN_REQUESTED'
    ) {
      const copyResult = await copyPrevQuarterKraGoalsService(
        empCode,
        quarterDetails[0]?.quartercode,
      );
      if (copyResult) {
        // Update KRA goals submit status to REVIEW_PENDING_L1
        const script = updateKraLineItemSelfScoreScript();
        currentKraGoals = await query(kraGoalsScript, [
          empCode,
          quarterDetails[0]?.quartercode,
        ]);
        for (const data of currentKraGoals) {
          await query(script, [data.kra_itemid, '-', 0, empCode]);
        }
        await updateKraGoalsSubmitStatus(result.AppraisalId, statusId, empCode);
      }
    } else {
      // Update KRA goals submit status to REVIEW_PENDING_L1
      const script = updateKraLineItemSelfScoreScript();

      for (const data of currentKraGoals) {
        await query(script, [data.kra_itemid, '-', 0, empCode]);
      }
      await updateKraGoalsSubmitStatus(result.AppraisalId, statusId, empCode);
    }
    // Check if the previous quarter is completed and update its status
    const prevQuartersQuery = getPrevQuarterListScript();
    const prevQuarter = await query(prevQuartersQuery, [
      empCode,
      quarterDetails[0]?.quartercode,
    ]);
    if (prevQuartersQuery && prevQuartersQuery[0]?.quarter) {
      const prevStatusId = await getPbStatusId(
        empCode,
        prevQuarter[0]?.quarter,
      );
      if (prevStatusId !== 13) {
        const prevAppraisalId = await getAppraisalId(
          empCode,
          prevQuarter[0]?.quarter,
        );
        const script = updateKraLineItemSelfScoreScript();
        const prevKraGoals = await query(kraGoalsScript, [
          empCode,
          prevQuarter[0]?.quarter,
        ]);
        for (const data of prevKraGoals) {
          await query(script, [data.kra_itemid, '-', 0, empCode]);
        }
        await updateKraGoalsSubmitStatus(prevAppraisalId, statusId, empCode);
      }
    }
  }
};

const pbUnMappingForML = async (empCode, startDate, modifiedBy) => {
  const quarterDetails = await getQuaterDetailsByDate(startDate);
  const statusAlias = 'GOAL_PENDING_EMPLOYEE';
  const statusId = await getPbStatusDetByAliasName(statusAlias);
  const appraisalId = await getAppraisalId(
    empCode,
    quarterDetails[0]?.quartercode,
  );
  if (appraisalId) {
    await updateMlEntryFlag(appraisalId, false, modifiedBy);
    await updateKraGoalsSubmitStatus(appraisalId, statusId, empCode);
  }
  // Check if the previous quarter is completed and update its status
  const prevQuartersQuery = getPrevQuarterListScript();
  const prevQuarter = await query(prevQuartersQuery, [
    empCode,
    quarterDetails[0]?.quartercode,
  ]);
  if (prevQuartersQuery && prevQuartersQuery[0]?.quarter) {
    const prevStatusId = await getPbStatusId(empCode, prevQuarter[0]?.quarter);
    if (prevStatusId !== 13) {
      const prevAppraisalId = await getAppraisalId(
        empCode,
        prevQuarter[0]?.quarter,
      );
      await updateMlEntryFlag(prevAppraisalId, false, modifiedBy);
      await updateKraGoalsSubmitStatus(prevAppraisalId, statusId, empCode);
    }
  }
};

// iStrong Integration end

export const createRatingGroupService = ratingGroupDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { groupname, isactive, createdby } = ratingGroupDetail;
      const script = `INSERT INTO iaspire.mst_rating_group(
         groupname, isactive, created_by)
        VALUES ( $1, $2, $3);`;
      const result = await query(script, [groupname, isactive, createdby]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createOrUpdateRatingService = ratingDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        valueid,
        groupid,
        minvalue,
        maxvalue,
        isactive,
        createdby,
        updatedby,
      } = ratingDetail;
      let script;
      let value = [];
      if (valueid) {
        script = `UPDATE iaspire.mst_rating_value
        SET  minvalue=$3, maxvalue=$4, updated_by=$5
        WHERE valueid = $1 AND groupid = $2`;
        value = [valueid, groupid, minvalue, maxvalue, updatedby];
      } else {
        script = `INSERT INTO iaspire.mst_rating_value(
           groupid, minvalue, maxvalue, isactive, created_by)
          VALUES ($1,$2,$3,$4,$5);`;
        value = [groupid, minvalue, maxvalue, isactive, createdby];
      }
      const result = await query(script, value);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteRatingValueService = ratingDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { valueid, groupid } = ratingDetail;
      const script = `UPDATE iaspire.mst_rating_value
      SET  isactive=false
      WHERE valueid = $1 AND groupid = $2`;
      const result = await query(script, [valueid, groupid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getReportHeadMappingService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duID, dhID, fhID, userId } = param;
      const result = await getReportHeadMappingScript(duID, dhID, fhID, userId);
      // const result = await query(script, [duID, dhID, fhID, userId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUserDetailsServce = userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getUserDetailByUserIdScript();
      const result = await query(script, [userId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getDuHeadFuHeadService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getDuHeadListScript();
      const script1 = getFunctionalHeadistScript();
      const result = await query(script);
      const result1 = await query(script1);
      resolve({ result, result1 });
    } catch (error) {
      reject(error);
    }
  });
};

// score and Rating

export const createScoreAndRatingGroupService = groupDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { groupname, isactive, created_by, updated_by } = groupDetails;
      const script = scoreAndRatingCreateGroupScript();
      const values = [groupname, isactive, created_by, updated_by];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createScoreAndRatingValueService = (ratingDetails, groupid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = scoreAndRatingCreateRatingScript();
      // Loop through each object in the array and execute the insertion
      for (const ratingDetail of ratingDetails) {
        const { minvalue, maxvalue, isactive, created_by, updated_by, rating } =
          ratingDetail;
        const values = [
          groupid,
          minvalue,
          maxvalue,
          isactive,
          created_by,
          updated_by,
          rating,
        ];
        await query(script, values);
        // Optionally, you can handle or collect the results for each insertion
      }
      resolve('Insertions completed');
    } catch (error) {
      reject(error);
    }
  });
};

export const getScoreAndRatingGroupOptionsService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = scoreAndRatingGetFilterOptionScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getScoreAndRatingGroupByFilterService = filterOption => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = scoreAndRatingGetFilterScript();
      const result = await query(script, [filterOption]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getScoreAndRatingUserDataService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, filterOption } = payload;
      let script;
      let result;
      if (filterOption != '') {
        script = scoreAndRatingGetFromMstUserWithGroupScript();
        const values = [searchText, filterOption];
        result = await query(script, values);
      } else {
        script = scoreAndRatingGetFromMstUserScript();
        const values = [searchText];
        result = await query(script, values);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const assignGroupRatingService = payload => {
  return new Promise(async (resolve, reject) => {
    const { groupData, group } = payload;
    const { groupid, isactive, created_by, updated_by } = groupData;
    try {
      const script = assignGroupRatingScript();
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            for (const data of group) {
              const { duid, designationid, bandlevelid } = data;
              await client.query(script, [
                groupid,
                duid,
                designationid,
                bandlevelid,
                isactive,
                created_by,
                updated_by,
              ]);
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('successfully inserted ');
    } catch (error) {
      reject(error);
    }
  });
};

// Appraisal Set Up start

export const getEmpAppraisalListService = (
  duId,
  bandId,
  desigId,
  appId,
  searchText,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getEmpAppraisalList(duId, bandId, desigId, appId);
      const result = await query(script, [searchText]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateEmpAppraisalDetService = (
  empCode,
  appTypeId,
  effYear,
  modifiedBy,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      await insOrUpdateAppraisalEntry(empCode, appTypeId, effYear, modifiedBy);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const getEmpAppraisalHistoryService = appId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getEmpAppraisalHistoryScript();
      const result = await query(script, [appId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAppraisalTypeforApprSetupService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getAppraisalTypeScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getDesigBandLevelListService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const desigScript = getDesignationListScript();
      const desigList = await query(desigScript);
      const bandLvlScript = getBandLevelListScript();
      const banLvlList = await query(bandLvlScript);
      resolve({ desigList, banLvlList });
    } catch (error) {
      reject(error);
    }
  });
};

// Appraisal Set Up end

// Email Links start

export const getEmailTemplateService = async (entityId, searchText) => {
  try {
    const data = {
      content: 'XXXX',
    };
    const script = getEmailTemplate();
    const resForConfig = await query(script, [entityId, searchText]);
    if (resForConfig.length > 0) {
      const result = resForConfig.map(item => {
        const replacedTemplate = item.notificationconfig.template
          .replace(/<%= data.reportingToName %>/g, data.content)
          .replace(/<%= data.quarter %>/g, data.content)
          .replace(/<%= data.month %>/g, data.content)
          .replace(/<%= data.year %>/g, data.content)
          .replace(/<%= data.Date %>/g, data.content);
        item.notificationconfig.template = replacedTemplate;
        return item;
      });
      return result;
    }
    return false;
  } catch (error) {
    return false;
  }
};

// Email Links end

// Performace Type Mapping start

export const getPerformanceTypeMapService = (type, duId, searchText) => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await getPerformanceTypeMapped(type, duId, searchText);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updatePerformanceMapService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      // const { appraisalId, appraisalType, updated_by } = info;
      const { userId, appraisalType, updated_by } = info;
      let tempid = null;
      if (appraisalType === 'QPR') {
        tempid = await getTempId(userId);
      }
      let result = '';
      if (tempid === 0) {
        result = 'no data for template';
      } else {
        // const statusId =
        //   appraisalType === 'QPR' ? 2 : appraisalType === 'KRA' ? 1 : null;
        // result = await updatePerformanceMap(
        //   appraisalId,
        //   appraisalType,
        //   updated_by,
        //   tempid ? Number(tempid) : null,
        //   statusId,
        // );
        result = await updatePerformanceMap(userId, appraisalType, updated_by);
      }
      // let histupdate;
      // if (result.length > 0) {
      //   histupdate = await insertPerformanceTypeHistory(result, updated_by);
      // }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getHistoryPerformanceMapService = async userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getHistoryPerformanceMap();
      const result = await query(script, [userId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAppraisalTypeService = async empCode => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getAppraisalTypeforPerformanceTypeMapping();
      const result = await query(script, [empCode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getScoreRatingHistoryService = async (
  duId,
  designationId,
  bandlevelId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getScoreRatingHistoryScript();
      const result = await query(script, [duId, designationId, bandlevelId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// Performace Type Mapping end

// ML Mapping start

export const getMLMappingDetailsService = async searchText => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getMLDetails();
      const result = await query(script, [searchText]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertMLMappingService = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { empCode, startDate, endDate, createdBy } = info;
      const result = await insertMLMapping(
        empCode,
        startDate,
        endDate,
        createdBy,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateMLMappingService = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { empCode, mlId, startDate, endDate, updatedBy } = info;
      const result = await updateMLMapping(
        empCode,
        mlId,
        startDate,
        endDate,
        updatedBy,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteMLMappingService = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { empCode, mlId } = info;
      const result = await deleteMLMapping(empCode, mlId);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getViewMLDetailsService = async empCode => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await getViewMLDetails(empCode);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// ML Mapping end

// My Goals start
export const getOrInsCurrentQuaterDetailsService = (dateParam, empCode) => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await getOrInsCurrentQuaterDetails(dateParam, empCode);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getQuaterListService = empCode => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getQuaterListScript();
      const result = await query(script, [empCode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUserDeatilsForKraGoalsService = appraisalId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getUserDeatilsForKraGoals();
      const result = await query(script, [appraisalId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getKraGoalsService = (empCode, quarterCode) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getKraGoals();
      const result = await query(script, [empCode, quarterCode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getKraGoalsWithVersionService = (
  empCode,
  quarterCode,
  versionId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      let result;
      if (versionId) {
        const script = getKraGoalsWithVersion();
        result = await query(script, [empCode, quarterCode, versionId]);
      } else {
        const script = getKraGoals();
        result = await query(script, [empCode, quarterCode]);
      }
      if (result?.length == 0) {
        const appraisalId = await getAppraisalId(empCode, quarterCode);
        const MLscript = checkIsMLEmp();
        const IsML = await query(MLscript, [appraisalId]);
        if (IsML.length > 0) {
          const copyResult = await copyPrevQuarterKraGoalsService(
            empCode,
            quarterCode,
          );
          if (copyResult) {
            const script = getKraGoals();
            result = await query(script, [empCode, quarterCode]);
          }
        }
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getKraVersionListService = appraisalId => {
  return new Promise(async (resolve, reject) => {
    try {
      if (appraisalId) {
        const script = getKraVersionListScript();
        let result = await query(script, [appraisalId]);
        if (result?.length == 0) {
          const MLscript = checkIsMLEmp();
          const IsML = await query(MLscript, [appraisalId]);
          if (IsML.length > 0) {
            const Verscript = `SELECT 'VERSION 1' AS version, 1 AS versionid;`;
            result = await query(Verscript);
          }
        }
        resolve(result);
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const copyPrevQuarterKraGoalsService = (empCode, quarterCode) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Fetch quarters
      const quartersQuery = getPrevQuarterListScript();
      const quarter = await query(quartersQuery, [empCode, quarterCode]);

      if (quarter[0]?.quarter === null || quarter[0]?.quarter === undefined) {
        resolve(false);
      }

      const kraItemsScript = getKraGoals();
      const kraItemsResult = await query(kraItemsScript, [
        empCode,
        quarter[0].quarter,
      ]);
      const appraisalId = await getAppraisalId(empCode, quarterCode);

      const insScript = insertPrevQuaterKraLineItemScript();

      const appraisalIds = [];
      const items = [];
      const measures = [];
      const weightages = [];
      const createdBys = [];
      const versionIds = [];
      const kraItemkeys = [];
      const seqNos = [];
      let i = 1;
      kraItemsResult.forEach(kraItem => {
        appraisalIds.push(appraisalId);
        items.push(kraItem.item);
        measures.push(kraItem.measure);
        weightages.push(kraItem.weightage);
        createdBys.push(kraItem.created_by);
        versionIds.push(1);
        seqNos.push(kraItem.serial);
        kraItemkeys.push(`${appraisalId}_1_${i}`);
        i += 1;
      });
      const updateScript = await updateMaxKeyScript();
      await query(updateScript, [appraisalId, i - 1, empCode]);
      const queryValues = [
        appraisalIds,
        items,
        measures,
        weightages,
        createdBys,
        versionIds,
        seqNos,
        kraItemkeys,
      ];

      await query(insScript, queryValues, empCode);

      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertOrUpdateKraLineItemsService = (
  empCode,
  quarterCode,
  lineItems,
  versionId,
  maxKey,
  goalApproved,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      // versionId = goalApproved ? versionId + 1 : versionId;
      const appraisalId = await getAppraisalId(empCode, quarterCode);
      lineItems.forEach(async lineItem => {
        if (appraisalId?.length !== 0) {
          if (lineItem.kra_itemid && !goalApproved) {
            await updateKraLineItem(appraisalId, versionId, lineItem, empCode);
          } else {
            await insertKraLineItem(appraisalId, lineItem, versionId, empCode);
          }
        }
      });
      const updateScript = updateMaxKeyScript();
      await query(updateScript, [appraisalId, maxKey, empCode]);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteKraLineItemService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // await deleteKraLineItem(lineItemId);
      const { itemId, userId, appraisalId } = payload;
      await deleteKraLineItem(itemId);
      const statusScript = updateKraGoalsSubmitStatus();
      await query(statusScript, [appraisalId, 1, userId]);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateKraGoalsSubmitStatusService = (
  appraisalId,
  statusName,
  empCode,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const statusAlias =
        statusName === 'submit' ? 'GOAL_PENDING_L1' : 'GOAL_PENDING_EMPLOYEE';
      const statusId = await getPbStatusDetByAliasName(statusAlias);
      const script = updateKraGoalsSubmitStatus();
      await query(script, [appraisalId, statusId, empCode]);
      // noneed for send mail when goal submits
      // if (statusName === 'submit') {
      //   try {
      //     await sendMail(appraisalId, 'goal_submitted');
      //   } catch (error) {
      //     console.log('Mail Error', error);
      //   }
      // }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateKraLineItemSelfScoreService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { lineItems, appraisalId, updatedby, userRequest } = payload;
      const script = updateKraLineItemSelfScoreScript();
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            for (const data of lineItems) {
              const { kra_itemid, actions, selfscore } = data;
              await client.query(script, [
                kra_itemid,
                actions,
                selfscore,
                updatedby,
              ]);
            }
            const updateReviewPendingScript = `UPDATE iaspire.trn_appraisalmapping 
            SET statusid = 
                CASE 
                    WHEN 'S' = $2 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L1')
                    WHEN 'D' = $2 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_EMPLOYEE')
                    ELSE (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_EMPLOYEE')
                END,
                updated_by = $3
            WHERE appraisalid = $1;`;
            if (userRequest) {
              await client.query(updateReviewPendingScript, [
                appraisalId,
                userRequest,
                updatedby,
              ]);
            }
            if (userRequest == 'S') {
              await sendMail(appraisalId, 'selfscore_submitted');
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const getOrInsQPRLineitemService = async (
  AppraisalId,
  TemplateId,
  Quarter,
  empCode,
  CreatedBy,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      // let ExistData = [];
      // let scoreresponce = '';

      const AppDetailsScript = getUserFoundInAppraisalMappingScript();
      const AppraisalDetails = await query(AppDetailsScript, [
        empCode,
        Quarter,
      ]);

      const Countscript = getQPRLineitemCount();
      const script = getQPRLineitem();
      const lineItemCount = await query(Countscript, [AppraisalId]);

      const QuarterDetail = await getQuaterDetailsByQcode(Quarter);
      const formattedStartDate = dateformatConvert(QuarterDetail[0].startdate);
      const formattedEndDate = dateformatConvert(QuarterDetail[0].enddate);

      let CCCount = 0;
      let ICCount = 0;
      let AppCount = 0;
      let ProductivityScore = 0;
      if (!AppraisalDetails[0]?.ismlentry) {
        const OldProductivity = await fetchOldiTracksProductivity({
          empCode,
          fromDate: `${formattedStartDate} 00:00:00`,
          toDate: `${formattedEndDate} 23:59:00`,
        });
        const NewProductivity = await getNewProductivityService(
          empCode,
          formattedStartDate,
          formattedEndDate,
        );
        const CCICCount = await getCCICCountService(
          empCode,
          formattedStartDate,
          formattedEndDate,
        );
        if (CCICCount.length > 0) {
          CCICCount.map(async data => {
            if (data.get_feedbackcount_for_iaspire.includes('CC')) {
              CCCount = parseInt(
                data.get_feedbackcount_for_iaspire.split('(')[1].split(',')[0],
              );
            } else if (data.get_feedbackcount_for_iaspire.includes('IC')) {
              ICCount = parseInt(
                data.get_feedbackcount_for_iaspire.split('(')[1].split(',')[0],
              );
            } else if (
              data.get_feedbackcount_for_iaspire.includes('IA') ||
              data.includes('EA')
            ) {
              AppCount = parseInt(
                data.get_feedbackcount_for_iaspire.split('(')[1].split(',')[0],
              );
            }
          });
        }
        ProductivityScore =
          parseFloat(OldProductivity) + parseFloat(NewProductivity[0].score);
      }

      if (lineItemCount[0].count > 0) {
        await updateQPRLineItem(
          AppraisalId,
          CreatedBy,
          ProductivityScore,
          CCCount,
          ICCount,
          AppCount,
          empCode,
          AppraisalDetails[0]?.ismlentry,
        );
        // scoreresponce = await updateScoreandRatingService(AppraisalId);
        // ExistData = await query(script, [AppraisalId]);
      } else {
        await insertQPRLineItem(
          AppraisalId,
          TemplateId,
          CreatedBy,
          ProductivityScore,
          CCCount,
          ICCount,
          AppCount,
          empCode,
          AppraisalDetails[0]?.ismlentry,
        );
        // scoreresponce = await updateScoreandRatingService(AppraisalId);
        // ExistData = await query(script, [AppraisalId]);
      }
      const scoreresponce = await updateScoreandRatingService(AppraisalId);
      const ExistData = await query(script, [AppraisalId]);
      // try {
      //   await sendMail(AppraisalId, 'goal_initiation');
      // } catch (error) {
      //   console.log('Mail Error', error);
      // }
      resolve({ ExistData, scoreresponce });
    } catch (error) {
      reject(error);
    }
  });
};

export const getQPRStatusforQuarterService = async appraisalId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getQPRStatusforQuarter();
      const result = await query(script, [appraisalId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getLineItemforReportService = async (empCode, quarterCode) => {
  return new Promise(async (resolve, reject) => {
    try {
      const AppScript = getUserFoundInAppraisalMappingScript();
      const appraisalData = await query(AppScript, [empCode, quarterCode]);
      let script = '';
      let script1 = '';
      let script2 = '';
      let result = '';
      if (appraisalData[0].appraisaltype === 'KRA') {
        script = getKraGoals();
        script1 = getQPRStatusforQuarter();
        script2 = getPBSummaryforKRA();
      } else if (appraisalData[0].appraisaltype === 'QPR') {
        script = getQPRLineitem();
        script1 = getQPRStatusforQuarter();
        script2 = getPBSummaryforQPR();
      }
      if (appraisalData[0].appraisaltype === 'QPR') {
        result = await query(script, [appraisalData[0].appraisalid]);
      } else if (appraisalData[0].appraisaltype === 'KRA') {
        result = await query(script, [empCode, quarterCode]);
      }
      const result1 = await query(script1, [appraisalData[0].appraisalid]);
      const result2 = await query(script2, [appraisalData[0].appraisalid]);
      resolve({
        appraisalType: appraisalData[0].appraisaltype,
        result,
        result1,
        result2,
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const getStatusListService = async empCode => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getStatusListScript();
      const result = await query(script, [empCode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getStatusTrackerCurrentService = async (
  quarterCode,
  statusId,
  empCode,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (quarterCode === '') {
        quarterCode = null;
      }
      const script = getStatusTrackerCurrentScript();
      const result = await query(script, [quarterCode, statusId, empCode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getStatusTrackerRejectionService = async (
  quarterCode,
  statusId,
  empCode,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (quarterCode === '') {
        quarterCode = null;
      }
      const script = getStatusTrackerRejectionScript();
      const result = await query(script, [quarterCode, statusId, empCode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getLineItemRatingService = async lineitemId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getLineItemRatingScript();
      const result = await query(script, [lineitemId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

const getNewProductivityService = async (quarterCode, startDate, endDate) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getNewProductivityScript();
      const result = await query(script, [quarterCode, startDate, endDate]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

const getCCICCountService = async (quarterCode, startDate, endDate) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getCCICCountScript();
      const result = await query(script, [quarterCode, startDate, endDate]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

const fetchOldiTracksProductivity = async option => {
  return new Promise(async (resolve, reject) => {
    try {
      const header = {
        iendpointkey: 'test',
        iendpointname: 'getOldProductivity',
      };
      const response = await axios({
        method: 'POST',
        url: process.env.OldWMSData,
        data: option,
        headers: {
          'Content-Type': 'application/json',
          ...header,
          // Add other headers if needed
        },
      });
      if (response.data.status) {
        resolve(response.data.productivity);
      } else {
        resolve(response.data);
      }
    } catch (error) {
      reject(error.response.status).json(error.response.data);
    }
  });
};

export const dateformatConvert = inputDate => {
  try {
    const year = inputDate.getFullYear();
    const month = String(inputDate.getMonth() + 1).padStart(2, '0');
    const day = String(inputDate.getDate()).padStart(2, '0');
    const formattedStartDate = `${year}-${month}-${day}`;
    return formattedStartDate;
  } catch (error) {
    console.log(error);
    return error;
  }
};

export const getRatingService = async (empCode, totalScore) => {
  return new Promise(async (resolve, reject) => {
    try {
      let result;
      const script = getRatingforQuarter();
      const RatingResult = await query(script, [empCode]);
      RatingResult.map(async data => {
        if (data.minvalue <= totalScore && data.maxvalue >= totalScore) {
          result = data;
        }
      });
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateScoreandRatingService = async AppraisalId => {
  await transaction(async client => {
    return new Promise(async (tresolve, treject) => {
      try {
        const script = getScoreusingAppraisalId();
        const result = await client.query(script, [AppraisalId]);
        const script1 = getUserScoreRateScript();
        const scoreRate = await query(script1, [result.rows[0].employeecode]);
        let resp = '';
        if (scoreRate.length > 0) {
          const ratingObject = scoreRate.find(row => {
            return (
              parseFloat(result.rows[0].score) >= row.minvalue &&
              parseFloat(result.rows[0].score) <= row.maxvalue
            );
          });
          const rating = ratingObject
            ? ratingObject.rating
            : scoreRate[scoreRate.length - 1].rating;
          const updateScript = updateScoreandRating();
          await query(updateScript, [
            AppraisalId,
            result.rows[0].score,
            rating,
          ]);
        } else {
          resp = 'not mapped';
        }
        // return resp;
        tresolve(resp);
      } catch (err) {
        treject(err);
      }
    });
  });

  // const script = getScoreusingAppraisalId();
  // const result = await query(script, [AppraisalId]);
  // const script1 = getUserScoreRateScript();
  // const scoreRate = await query(script1, [result[0].employeecode]);
  // let resp = '';
  // if (scoreRate.length > 0) {
  //   const ratingObject = scoreRate.find(row => {
  //     return (
  //       parseFloat(result[0].score) >= row.minvalue &&
  //       parseFloat(result[0].score) <= row.maxvalue
  //     );
  //   });
  //   const rating = ratingObject
  //     ? ratingObject.rating
  //     : scoreRate[scoreRate.length - 1].rating;
  //   const updateScript = updateScoreandRating();
  //   await query(updateScript, [AppraisalId, result[0].score, rating]);
  // } else {
  //   resp = 'not mapped';
  // }
  // return resp;
};

// My Goals end

// My Squad Goals start

export const insertUserForQuarterService = payload => {
  const { repToEmpCode, quarterCode, appType } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      if (appType == 'KRA') {
        await transaction(async client => {
          const L1EmployeeScript = getL1UsersListScript();
          const userList = await client.query(L1EmployeeScript, [
            repToEmpCode,
            appType,
          ]);
          for (const user of userList.rows) {
            await insOrUpdTransEntryService(
              user.userid,
              quarterCode,
              repToEmpCode,
              '',
              false,
            );
          }
        });
      }
      const userList = await getMySquadListService(payload);
      resolve(userList);
    } catch (error) {
      reject(error);
    }
  });
};

export const getMySquadListService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        repToEmpCode,
        statusCode,
        searchText,
        quarterCode,
        appType,
        roleId,
        filter,
      } = payload;
      const { duId, bandLevelId, designationId, statusId } = filter;
      const Rolescript = getiAspireUsrRoleAcry();
      const roleAcr = (await query(Rolescript, [roleId]))[0]?.roleacronym;

      // const duIdString = duId.length > 0 ? duId.join() : null;
      // const bandLevelIdString =
      //   bandLevelId.length > 0 ? bandLevelId.join() : null;
      // const designationIdString =
      //   designationId.length > 0 ? designationId.join() : null;
      // const statusIdString = statusId.length > 0 ? statusId.join() : null;

      const firstDU = duId.length > 0 ? duId[0].toString() : '';
      const fstBandLevel =
        bandLevelId.length > 0 ? bandLevelId[0].toString() : '';
      const fstDesig =
        designationId.length > 0 ? designationId[0].toString() : '';
      const firstStatus = statusId.length > 0 ? statusId[0].toString() : '';

      // ML Change on 08-01-2025
      const MLUserListScript = MLEmpList();
      const MLUserList = await query(MLUserListScript, [
        repToEmpCode,
        quarterCode,
      ]);

      const dojNullArr = [];

      if (roleAcr != 'SHR') {
        await transaction(async client => {
          const L1EmployeeScript = getL1UsersListScript();
          const userList = await client.query(L1EmployeeScript, [
            repToEmpCode,
            appType,
          ]);
          for (const user of userList.rows) {
            let isValid = true;
            let isML = false;
            if (
              MLUserList.filter(data => data.empcode == user.userid)?.length > 0
            ) {
              const MLDetails = await MLValidation(MLUserList, user.userid);
              isValid = MLDetails?.isValid;
              isML = MLDetails?.isML;
            }
            if (user.doj && isValid) {
              await insOrUpdTransEntryService(
                user.userid,
                quarterCode,
                repToEmpCode,
                '',
                isML,
              );
            } else if (!user.doj) {
              dojNullArr.push(user.userid);
            }
          }
        });
      }

      const fromScreen = 'G';
      const script = getMySquadListScript(statusCode, roleAcr, fromScreen);

      let result;
      if (roleAcr === 'SHR') {
        result = await query(script, [
          searchText,
          quarterCode,
          appType,
          repToEmpCode,
          firstDU,
          fstBandLevel,
          fstDesig,
          firstStatus,
          duId,
          bandLevelId,
          designationId,
          statusId,
        ]);
      } else {
        result = await query(script, [
          searchText,
          quarterCode,
          appType,
          repToEmpCode,
          firstDU,
          fstBandLevel,
          fstDesig,
          firstStatus,
          duId,
          bandLevelId,
          designationId,
          statusId,
        ]);
      }
      resolve({ result, dojError: dojNullArr });
    } catch (error) {
      reject(error);
    }
  });
};

export const updateApproveorRejectService = (
  appraisalId,
  approvalLvl,
  modifiedBy,
  rejectComment,
  actionType,
  overAllFeedBack,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const approvalRequired = await handleValidateApproveReject(appraisalId);
      const updateGoalApprovalRejectScript = `UPDATE iaspire.trn_appraisalmapping 
        SET statusid = 
            CASE 
              WHEN ('A' = $2 AND 'L1' = $3 AND 'DH' <> $3 AND 'FH' <> $3) AND (SELECT 1 FROM iaspire.super_approver WHERE employeecode = $5 AND isactive = true) = 1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_APPROVED')
              WHEN ('A' = $2 AND 'L1' = $3 AND 'DH' <> $3 AND 'FH' <> $3) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_L2')

              WHEN 'A' = $2 AND ('L2' = $3 OR 'DH' = $3 OR 'FH' = $3) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_APPROVED')
              WHEN 'R' = $2 AND ('L2' = $3 OR 'DH' = $3 OR 'FH' = $3) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_REJECTED_L2')
              WHEN 'R' = $2 AND (SELECT 1 FROM iaspire.super_approver WHERE employeecode = $5 and isactive = true) = 1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_REJECTED_L2')
              WHEN 'R' = $2 AND 'L1' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_REJECTED_L1')
              WHEN 'R' = $2 AND 'L2' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_REJECTED_L2')
              ELSE (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_EMPLOYEE')
              END,
                 rejection_remarks =
                  CASE 
                      WHEN 'R' = $2 THEN $4
                      ELSE  rejection_remarks 
                  END,
                  overall_feedback=$6,
                  updated_by = $5
              WHERE appraisalid = $1;`;
      if (!approvalRequired) {
        await query(updateGoalApprovalRejectScript, [
          appraisalId,
          actionType,
          approvalLvl,
          rejectComment,
          modifiedBy,
          overAllFeedBack,
        ]);
        // const status = actionType == 'A' ? 'approved' : 'rejected';
        // let level = approvalLvl.toLowerCase();
        // if (approvalLvl === 'DH' || approvalLvl === 'FH') {
        //   level = 'l2';
        // }
        // const templateName = `goal_${status}_${level}`;
        if (
          actionType == 'A' &&
          (approvalLvl == 'L2' || approvalLvl == 'DH' || approvalLvl == 'FH')
        ) {
          await sendMail(appraisalId, 'goal_approved');
        } else if (actionType == 'R') {
          await sendMail(appraisalId, 'goal_rejected');
        }
        resolve(true);
      } else {
        throw new Error('Something Went Wrong. Please try again Later.');
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const handleValidateApproveReject = appraisalId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `select appr_check from iaspire.mst_status ms where statusid  = 
              (select statusid  from iaspire.trn_appraisalmapping ta where appraisalid = $1)`;
      const result = await query(script, [appraisalId]);
      resolve(result[0].appr_check);
    } catch (error) {
      reject(error);
    }
  });
};

// export const updateRejectService = (appraisalId, remarks, modifiedBy) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const script = updateRejectScript();
//       await query(script, [appraisalId, remarks, modifiedBy]);
//       resolve(true);
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

export const updateKraQprLineItemReviewScoreService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        lineItems,
        appraisalId,
        appraisalType,
        additionalScore,
        additionalRemarks,
        rejectionRemarks,
        rating,
        modifiedBy,
        approvalLvl,
        userRequest,
        overAllFeedBack,
        userID,
        bhName,
        dhName,
      } = payload;
      let script = '';
      let totalScore = 0;
      for (const data of lineItems) {
        totalScore += parseFloat(
          appraisalType === 'QPR' ? data.score : data.reviwerscore,
        );
      }
      const approvalRequired = await handleValidateApproveReject(appraisalId);
      if (approvalRequired) {
        throw new Error('Something Went Wrong. Please try again Later.');
      }
      if (appraisalType === 'KRA') {
        script = updateKraLineItemReviewScoreScript();
      } else if (appraisalType === 'QPR') {
        script = updateQprLineItemReviewScoreScript();
      }
      const updateAppraisalApprovalRejectScript = `UPDATE iaspire.trn_appraisalmapping 
            SET statusid =
            CASE
              WHEN 'A' = $2 AND (SELECT 1 FROM iaspire.super_approver WHERE employeecode = $7 and isactive = true) = 1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')

              WHEN 'A' = $2 AND 'HR' = $3 AND (SELECT 1 FROM iaspire.trn_reviewerdetails WHERE reviewer1 = $7 AND appraisalid = $1) = 1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2')
              WHEN 'A' = $2 AND 'HR' = $3 AND (SELECT 1 FROM iaspire.trn_reviewerdetails WHERE reviewer1 != $7 AND appraisalid = $1) = 1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')

              -- 	WHEN 'A' = $2 AND 'FH' = $3 AND (select 1 from public.wms_userrole where isactive=true and roleid=(select roleid from public.wms_role where roleacronym='SHR') and userid=$7) =1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              WHEN 'A' = $2 AND 'FH' = $3 AND ($6::FLOAT > 0) AND ($8::FLOAT >= 121) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_HR')
              WHEN 'A' = $2 AND 'FH' = $3 AND ($6::FLOAT > 0) AND ($8::FLOAT BETWEEN 101 AND 120.9) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              WHEN 'A' = $2 AND 'FH' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              -- 	WHEN 'A' = $2 AND 'DH' = $3 AND (select 1 from public.wms_userrole where isactive=true and roleid=(select roleid from public.wms_role where roleacronym='SHR') and userid=$7) =1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              WHEN 'A' = $2 AND 'DH' = $3 AND ($6::FLOAT > 0) AND ($8::FLOAT >= 121) AND (select 1 from public.wms_user where userid=$10 and duhead=functionalhead limit 1) =1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_HR')
              WHEN 'A' = $2 AND 'DH' = $3 AND ($6::FLOAT > 0) AND ($8::FLOAT >= 121) AND (select 1 from public.wms_user where userid=$10 and duhead!=functionalhead limit 1)=1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_FH')
              WHEN 'A' = $2 AND 'DH' = $3 AND ($6::FLOAT > 0) AND ($8::FLOAT BETWEEN 101 AND 120.9) AND (select 1 from public.wms_user where userid=$10 and duhead=functionalhead limit 1) =1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              WHEN 'A' = $2 AND 'DH' = $3 AND ($6::FLOAT > 0) AND ($8::FLOAT BETWEEN 101 AND 120.9) AND (select 1 from public.wms_user where userid=$10 and duhead!=functionalhead limit 1)=1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_FH')
              WHEN 'A' = $2 AND 'DH' = $3 AND ($6::FLOAT > 0) AND ($8::FLOAT <= 100) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              WHEN 'A' = $2 AND 'DH' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              -- 	WHEN 'A' = $2 AND 'L2' = $3 AND (select 1 from public.wms_userrole where isactive=true and roleid=(select roleid from public.wms_role where roleacronym='SHR') and userid=$7) =1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              WHEN 'A' = $2 AND 'L2' = $3 AND ($6::FLOAT > 0) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_DUH')
              WHEN 'A' = $2 AND 'L2' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              -- 	WHEN 'A' = $2 AND 'L1' = $3 AND (select 1 from public.wms_userrole where isactive=true and roleid=(select roleid from public.wms_role where roleacronym='SHR') and userid=$7) =1 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_COMPLETED')
              WHEN 'A' = $2 AND 'L1' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2')				
              
              -- 	WHEN 'R' = $2 AND (((SELECT 1 FROM iaspire.super_approver WHERE employeecode = $7 and isactive = true) = 1) OR ((select 1 from public.wms_userrole where isactive=true and roleid=(select roleid from public.wms_role where roleacronym='SHR') and userid=$7) =1)) THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_HR')
              WHEN 'R' = $2 AND 'HR' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_HR')
              WHEN 'R' = $2 AND 'FH' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_FH')
              WHEN 'R' = $2 AND 'DH' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_DUH')
              WHEN 'R' = $2 AND 'L2' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_L2')
              WHEN 'R' = $2 AND 'L1' = $3 THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_L1')
              ELSE (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_EMPLOYEE')
            END ,
            score = $5,
            overall_feedback=$9,
            updated_by = $7,
          rejection_remarks =
            CASE
                WHEN 'R' = $2 THEN $4
                ELSE  rejection_remarks
            END
        WHERE appraisalid = $1;`;
      // RETURNING appraisalid, employeecode, quartercode, statusid,
      // (SELECT doj FROM public.wms_user WHERE userid = $10) AS doj,
      // (SELECT alias_name FROM iaspire.mst_status WHERE statusid = (SELECT statusid FROM iaspire.trn_appraisalmapping WHERE appraisalid = $1)),
      // (SELECT startdate-15 AS startdate FROM iaspire.mst_quarters WHERE quartercode = (SELECT quartercode FROM iaspire.trn_appraisalmapping WHERE appraisalid = $1)),
      // (SELECT enddate-15 AS enddate FROM iaspire.mst_quarters WHERE quartercode = (SELECT quartercode FROM iaspire.trn_appraisalmapping WHERE appraisalid = $1)),
      // score, additionalscore, additionalscore_remarks;`;
      if (userRequest == 'A') {
        await transaction(async client => {
          if (appraisalType === 'KRA') {
            for (const data of lineItems) {
              const { kra_itemid, reviwerscore, reviewercomment } = data;
              await client.query(script, [
                kra_itemid,
                reviwerscore,
                reviewercomment,
                modifiedBy,
              ]);
              // totalScore += parseFloat(reviwerscore);
            }
          } else if (appraisalType === 'QPR') {
            for (const data of lineItems) {
              const { qpr_itemid, score, reviewercomment } = data;
              await client.query(script, [
                qpr_itemid,
                appraisalId,
                score,
                reviewercomment,
                modifiedBy,
              ]);
              // totalScore += parseFloat(score);
            }
          }
          await updateUserRatingService(appraisalId, rating, modifiedBy);
          if (additionalScore) {
            await updateAdditionalScoreService(
              appraisalId,
              additionalScore,
              additionalRemarks,
              modifiedBy,
            );
            let templateName;
            if (
              approvalLvl == 'DH' &&
              parseFloat(totalScore + parseFloat(additionalScore)) > 100
            ) {
              templateName = 'additional_score_approval_bh';
            } else if (approvalLvl == 'L2') {
              templateName = 'additional_score_approval_dh';
            }
            if (additionalScore > 0) {
              sendMail(
                appraisalId,
                templateName,
                106,
                additionalRemarks,
                bhName,
                dhName,
              );
            }
          }
        });
      }
      await query(updateAppraisalApprovalRejectScript, [
        appraisalId,
        userRequest,
        approvalLvl,
        rejectionRemarks,
        totalScore,
        parseFloat(additionalScore),
        modifiedBy,
        parseFloat(totalScore + parseFloat(additionalScore)),
        overAllFeedBack,
        userID,
      ]);
      const isFirstPBScript = getIsFirstPB();
      const ISFirstPB = await query(isFirstPBScript, [appraisalId]);
      if (
        ISFirstPB[0].alias_name === 'REVIEW_COMPLETED' &&
        new Date(ISFirstPB[0].startdate) <= new Date(ISFirstPB[0].doj) &&
        new Date(ISFirstPB[0].startdate) <= new Date(ISFirstPB[0].doj)
      ) {
        const firstPB = `UPDATE iaspire.trn_appraisalmapping SET 
        additionalscore_remarks = COALESCE(additionalscore_remarks || '/ ', '') || '/ Employee First PB, User given additional score is ' || COALESCE(additionalscore, 0),
        additionalscore = 100 - score,
        rating = 4
        WHERE appraisalid = $1;`;
        await query(firstPB, [appraisalId]);
      }
      // const status = userRequest == 'A' ? 'approved' : 'rejected';
      // let templateName;
      // if (approvalLvl === 'L1') {
      //   templateName = `score_${status.toLowerCase()}_${approvalLvl.toLowerCase()}`;
      // } else if (approvalLvl === 'L2' && userRequest == 'R') {
      //   templateName = `score_${status.toLowerCase()}_${approvalLvl.toLowerCase()}`;
      // } else if (
      //   approvalLvl === 'L2' &&
      //   additionalScore == '' &&
      //   userRequest == 'A'
      // ) {
      //   templateName = `score_${status.toLowerCase()}_${approvalLvl.toLowerCase()}`;
      // } else if (approvalLvl === 'L2' && additionalScore) {
      //   templateName =
      //     totalScore > 100 ? 'additional_score_100' : 'additional_score_99';
      // } else if (approvalLvl == 'DH') {
      //   templateName = `duhead_${status.toLowerCase()}`;
      // } else if (approvalLvl == 'FH') {
      //   templateName = `functionalhead_${status.toLowerCase()}`;
      // }
      // await sendMail(appraisalId, templateName);
      resolve(
        userRequest == 'A' ? 'successfully Inserted' : 'successfully Rejected',
      );
    } catch (error) {
      reject(error);
    }
  });
};

export const updateQprLineItemReviewScoreService = async (
  appraisalId,
  lineItems,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      lineItems.forEach(async lineItem => {
        await updateQprLineItemReviewScore(appraisalId, lineItem);
      });
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateFeedbackService = async (
  appraisalId,
  remarks,
  modifiedBy,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateFeedbackScript();
      await query(script, [appraisalId, remarks, modifiedBy]);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateTotalScoreService = async (
  appraisalId,
  score,
  modifiedBy,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateTotalScoreScript();
      await query(script, [appraisalId, score, modifiedBy]);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateAdditionalScoreService = async (
  appraisalId,
  additionalScore,
  remarks,
  modifiedBy,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateAdditionalScoreScript();
      await query(script, [appraisalId, additionalScore, remarks, modifiedBy]);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
export const updateUserRatingService = async (
  appraisalId,
  rating,
  modifiedBy,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateUserRatingScript();
      await query(script, [appraisalId, rating, modifiedBy]);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const requestReOpenService = async (
  appraisalId,
  reqType,
  reqRemarks,
  modifiedBy,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const pbStatusAlias = reqType.toUpperCase().includes('GOAL')
        ? 'GOAL_REOPEN_REQUESTED'
        : 'REVIEW_REOPEN_REQUESTED';
      const pbStatusId = await getPbStatusDetByAliasName(pbStatusAlias);
      const updateScript = updatePbReOpenStatus();
      await query(updateScript, [appraisalId, pbStatusId, modifiedBy]);
      const reqTypeId = await getIdByField('type', reqType);
      const reqStatusId = await getPbStatusDetByAliasName(
        'ROR_PENDING_HR_ADMIN',
      );
      const script = await insReOpenRequestScript();
      const result = await query(script, [
        appraisalId,
        reqRemarks,
        reqTypeId,
        reqStatusId,
        modifiedBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getReopenReqListService = async (
  typeId,
  roleId,
  searchText,
  userId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getReopenReqListScript();
      const result = await query(script, [typeId, roleId, searchText, userId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getReopenReqTypeService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getReopenReqTypeScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getQuarterListService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQuarterList();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const aprRejReopenReqService = async (
  requestId,
  appraisalId,
  modalType,
  reqType,
  comment,
  userid,
  roleId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script1 = getiAspireUsrRoleAcry();
      const roleAcr = (await query(script1, [roleId]))[0]?.roleacronym;

      const script3 = getNextStatusAppMap();
      const statusAppMap = (
        await query(script3, [roleAcr, modalType, reqType, appraisalId])
      )[0]?.statusid;

      const script2 = getNextStatusROR();
      const statusROR = (await query(script2, [roleAcr, modalType]))[0]
        ?.statusid;

      const script4 = await updateNextStatusROR();
      const result1 = await query(script4, [
        statusROR || 0,
        roleAcr,
        comment,
        userid,
        requestId,
      ]);

      if (result1) {
        const script5 = await updateNextStatusAppMap();
        const result2 = await query(script5, [
          statusAppMap || 0,
          reqType,
          appraisalId,
        ]);
        resolve(result2);
        if (modalType == 'R') {
          sendMail(appraisalId, 'reopen_rejected');
        }
      } else {
        resolve(false);
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const getQRatingListService = async empCode => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getRatingforQuarter();
      const result = await query(script, [empCode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// const getStatus = async aliasName => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const script = getStatusUsingAliasName();
//       const result = await query(script, [aliasName]);
//       resolve(result[0].statusid);
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

// My Squad Goals end

// QPR Template Start

export const insUpdTemplateMstService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { templateId, templateName, userId } = info;
      const isInsert = templateId == null || templateId === 0;
      let result;

      if (isInsert) {
        result = await insTemplateMst(templateName, userId);
      } else {
        result = await updTemplateMst(templateId, templateName, userId);
      }

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insUpdTemplateConfigService = async payload => {
  const { groupData, group } = payload;
  const insDuids = [];
  const insDesignationids = [];
  const insBandlevelids = [];
  const insTemplateids = [];
  const insCreatedBys = [];
  const uptTempQpr = [];
  group.forEach(item => {
    if (item.templateid == null) {
      insDuids.push(item.duid);
      insDesignationids.push(item.designationid);
      insBandlevelids.push(item.bandlevelid);
      insTemplateids.push(groupData.newTemplateid);
      insCreatedBys.push(groupData.created_by);
    } else {
      uptTempQpr.push(item.qpr_tempid);
    }
  });
  const queryValues = [
    insDuids,
    insDesignationids,
    insBandlevelids,
    insTemplateids,
    insCreatedBys,
  ];
  try {
    await transaction(async client => {
      const insertQuery = `
        INSERT INTO iaspire.trn_qpr_template
          (duid, designationid, bandlevelid, templateid, isactive, created_by)
        VALUES (
          unnest($1::bigint[]),
          unnest($2::bigint[]),
          unnest($3::bigint[]),
          unnest($4::bigint[]),
          true,
          unnest($5::text[])
        ) RETURNING qpr_tempid;
      `;
      const updateQuery = `
        UPDATE iaspire.trn_qpr_template 
        SET templateid = $2, updated_time = CURRENT_TIMESTAMP
        WHERE qpr_tempid = ANY($1::bigint[])
        RETURNING qpr_tempid;
      `;
      if (insDuids.length > 0) {
        await client.query(insertQuery, queryValues);
      } else if (uptTempQpr.length > 0) {
        await client.query(updateQuery, [uptTempQpr, groupData.newTemplateid]);
      }
    });
    return 'Successfully';
  } catch (error) {
    console.error('Error:', error.message);
    throw error; // Re-throw for external handling
  }
};

export const iAspireSoftDelService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { uniqueId, p_type, userId } = info;
      const queryScript = await get_iAspireSoftDel_query(p_type);

      const result = await query(queryScript, [uniqueId, userId]);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const iAspireHardDelService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { uniqueId, p_type } = info;
      const queryScript = await get_iAspireHardDel_query(p_type);

      const result = await query(queryScript, [uniqueId]);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertTemplateDetails = async info => {
  try {
    // Extract relevant data from `info` object
    const { mstInfo, template } = info;

    // **Error Handling:** Handle potential null/undefined values early
    if (!mstInfo || !template) {
      throw new Error('Missing required information in `info` object.');
    }

    await transaction(async client => {
      // **1. Insert into `mst_qpr_template` (if template ID is missing):**
      let mstTempId;
      if (mstInfo?.templateId == '') {
        const queryScript = `INSERT INTO iaspire.mst_qpr_template(templatename, created_by) VALUES ($1, $2) RETURNING templateid`;
        const result = await client.query(queryScript, [
          mstInfo.templateName,
          mstInfo.userId,
        ]);
        mstTempId = result.rows[0].templateid;
      } else {
        mstTempId = mstInfo.templateId; // Use existing template ID
      }

      // **2. Process each line item:**
      const lineItemPromises = template.map(async lineItem => {
        // **Data Validation:** Ensure data types and required values before insertion
        if (
          !lineItem.measureId ||
          !lineItem.seqNo ||
          isNaN(lineItem.weightAge) || // Check for NaN
          !mstInfo.userId
        ) {
          throw new Error('Invalid data in line item object.');
        }

        // **Prepare line item data:**
        const versionId = lineItem.versionId ? lineItem.versionId + 1 : 1;
        const lineItemData = [
          mstTempId,
          versionId,
          lineItem.asmtParamId,
          lineItem.parameterDesc,
          lineItem.measureId,
          lineItem.seqNo,
          lineItem.weightAge, // Assuming valid number
          lineItem.notes,
          mstInfo.userId,
        ];

        // **3. Insert into `trn_qpr_lineitem` and handle rateValid:**
        const lineItemResult = await client.query(
          `INSERT INTO iaspire.trn_qpr_lineitem (templateid, versionid, parameterid, userdesc, measureid, seqno, weightage, notes, created_by, created_time) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, Now()) RETURNING lineitemid`,
          lineItemData,
        );
        const lineItemId = lineItemResult.rows[0].lineitemid;

        // **3.a. Process `rateValid` array (if present):**
        if (lineItem.rateValid?.length > 0) {
          const rateValidPromises = lineItem.rateValid.map(async rateValid => {
            // **Data Validation:** Ensure required values and data types
            if (
              !rateValid.rateTypeId ||
              isNaN(rateValid.value1) ||
              isNaN(rateValid.value2) ||
              isNaN(rateValid.score)
            ) {
              throw new Error('Invalid data in rateValid object.');
            }

            const rateValidData = [
              lineItemId,
              rateValid.rateTypeId,
              rateValid.value1,
              rateValid.value2,
              rateValid.score,
              mstInfo.userId,
            ];
            const script = `INSERT INTO iaspire.trn_qpr_lineitem_validation
            (lineitemid, validationid, value1, value2, score, created_by, created_time) VALUES ($1, $2, $3, $4, $5, $6, Now()) RETURNING lnvalidid`;
            await client.query(script, rateValidData); // Assuming script receives an array
          });
          await Promise.all(rateValidPromises);
        }
      });

      await Promise.all(lineItemPromises);
    });

    return 'Template Details inserted successfully.';
  } catch (error) {
    console.error('Error inserting template details:', error.message);
    throw error; // Re-throw for external handling
  }
};

export const getTemplateDetails = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const Script = qprMasterGetTemplateDetailsScript();
      const result = await query(Script, [info.templateId]);
      if (result && result.length > 0 && result[0].result !== undefined) {
        resolve(result[0].result);
      } else {
        resolve(null);
      }
    } catch (error) {
      reject('Error get template details:', error.message || error);
    }
  });
};

export const getCombinationDetails = async info => {
  return new Promise(async (resolve, reject) => {
    const { templateId, duId, bandLvlId, desigLvlId, designationDesc } = info;
    try {
      const result = await qprMasterGetCombinationScript(
        duId,
        bandLvlId,
        desigLvlId,
        templateId,
        designationDesc,
      );
      resolve(result);
    } catch (error) {
      reject('Error get Combination details:', error);
    }
  });
};
export const iAspireExcelUploadService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      // const { uniqueId, p_type } = info;
      // const queryScript = await get_iAspireHardDel_query(p_type);

      // validations goes here

      // const result = await query(queryScript, [uniqueId]);
      resolve('result');
    } catch (error) {
      reject(error);
    }
  });
};

export const fetchDataAndJoin = async () => {
  // eslint-disable-next-line no-useless-catch
  try {
    // Fetch data from wms_user table
    const users = await query(
      'SELECT * FROM public.wms_user WHERE duid IS NOT NULL AND designationid IS NOT NULL AND bandlevelid IS NOT NULL',
    );

    // Extract relevant fields
    const userRows = users.map(user => user);
    const bandLvlId = userRows.map(user => user.bandlevelid);
    const designationId = users.map(user => user.designationid);
    const duidList = users.map(user => user.duid);
    // Fetch data from mst_deliveryunit table
    const deliveryUnits = await query(
      'SELECT * FROM public.mst_deliveryunit WHERE duid = ANY($1::integer[])',
      [duidList],
    );

    // Fetch data from mst_bandlevel table
    const bandLevels = await query(
      'SELECT * FROM public.mst_bandlevel WHERE bandlevelid = ANY($1::integer[])',
      [bandLvlId],
    );

    // Fetch data from mst_designation table
    const designations = await query(
      'SELECT * FROM public.mst_designation WHERE designationid = ANY($1::integer[])',
      [designationId],
    );

    // Perform the join logic in JavaScript
    const result = await userRows
      .map((user, i) => {
        const deliveryUnit = deliveryUnits.find(du => du.duid == user.duid);
        const bandLevel = bandLevels.find(
          bl => bl.bandlevelid == user.bandlevelid,
        );
        const designation = designations.find(
          ds => ds.designationid == user.designationid,
        );

        return {
          serial: i + 1, // Assuming you have a 'serial' field in the wms_user table
          duname: deliveryUnit ? deliveryUnit.duname : '',
          bandlevel: bandLevel ? bandLevel.bandlevel : null,
          designation: designation ? designation.designationdesc : null,
          duid: user.duid,
          bandlevelid: user.bandlevelid,
          designationid: user.designationid,
          action: 'action', // Replace with your actual action logic
        };
      })
      .filter(
        data =>
          data.duname !== '' &&
          ['duuname', 'bandlevel', 'designationdesc'].some(field =>
            data[field]?.toLowerCase().includes(''.toLowerCase()),
          ) &&
          data.bandlevel !== null &&
          data.designation !== null,
      );
    // .sort((a, b) =>
    //   a.duname.localeCompare(b.duname, undefined, { sensitivity: 'base' }),
    // );

    return result;
  } catch (error) {
    throw error;
  }
};

export const getBandLvlTemplateService = async (
  DuList,
  BandLevelList,
  designationList,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await getBandLevelScript(DuList);
      const result1 = await getDesignationLevelScript(DuList, BandLevelList);
      const result2 = await getTemplateScript(
        DuList,
        BandLevelList,
        designationList,
      );
      resolve({ result, result1, result2 });
    } catch (error) {
      reject(error);
    }
  });
};

export const getQPRMasterDropDownService = async master => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQprMasterDropDownDataScript(master);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getQPRTemplateDataService = async templateId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQprScriptTemplateDataScript();
      const result = await query(script, [templateId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// Email Event
export async function sendMail(
  AppraisalId,
  EmailTemplate,
  entityId = 106,
  comments = '',
  bhName = '',
  dhName = '',
) {
  try {
    // let comments;
    // if (
    //   EmailTemplate == 'additional_score_approval_bh' ||
    //   EmailTemplate == 'additional_score_approval_dh'
    // ) {
    //   AppraisalId = AppraisalId.appraisalId;
    //   comments = AppraisalId.comments;
    // }
    // const endpointUrl = `${process.env.CLIENT_HOST}:${process.env.CLIENT_PORT}`;
    const resForConfig = await getEmailTemplateforEmail(
      entityId,
      EmailTemplate,
    );
    const { notificationconfig } = resForConfig[0];
    const mailIDinTO = extractEmails(notificationconfig.to);
    const mailIDinCC = extractEmails(notificationconfig.cc);
    const userID = await getUserDeatilsForKraGoalsService(AppraisalId);
    const reportingto = await getReportingEmail(userID[0].userid);
    const monthandYear = await getMonthandYearforLatestQuarter();
    const reviewStartDate = await getMonthandYearforReviewStartDateQuarter();
    const goalEndDate = await getGoalEndDateForQuarter();
    const goalEndDateForEmp = await getGoalEndDateForEmployee(AppraisalId);
    const currentDate = new Date().toISOString().substring(0, 10);

    if (notificationconfig.to.includes('repto'))
      mailIDinTO.push(reportingto[0].useremail);
    else if (notificationconfig.cc.includes('repto'))
      mailIDinCC.push(reportingto[0].useremail);
    if (notificationconfig.to.includes('emp'))
      mailIDinTO.push(userID[0].useremail);
    else if (notificationconfig.cc.includes('emp'))
      mailIDinCC.push(userID[0].useremail);
    if (notificationconfig.to.includes('l2'))
      mailIDinTO.push(userID[0].l2email);
    else if (notificationconfig.cc.includes('l2'))
      mailIDinCC.push(userID[0].l2email);
    if (notificationconfig.to.includes('duh'))
      mailIDinTO.push(userID[0].duheademail);
    else if (notificationconfig.cc.includes('duh'))
      mailIDinCC.push(userID[0].duheademail);
    if (notificationconfig.to.includes('fh'))
      mailIDinTO.push(userID[0].fuheademail);
    else if (notificationconfig.cc.includes('fh'))
      mailIDinCC.push(userID[0].fuheademail);

    const updatedNotificationConfig = await modifyNotificationConfigFromEmails(
      notificationconfig,
      mailIDinTO,
      mailIDinCC,
    );
    const mailData = {
      ...updatedNotificationConfig,
      reportingToName: reportingto[0].username,
      quarter: monthandYear[0].quarter,
      year: monthandYear[0].year,
      month:
        EmailTemplate == 'goal_approved'
          ? reviewStartDate[0].month
          : EmailTemplate == 'goal_rejected'
          ? goalEndDateForEmp[0].month
          : monthandYear[0].month,
      date:
        EmailTemplate == 'goal_approved'
          ? reviewStartDate[0].date
          : EmailTemplate == 'goal_rejected'
          ? goalEndDateForEmp[0].date
          : monthandYear[0].date,
      goalEndDate:
        EmailTemplate == 'goal_rejected'
          ? goalEndDateForEmp[0].date
          : goalEndDate[0].date,
      quarterCode: userID[0].quartercode,
      Date: currentDate,
      empName: `${userID[0].username} (${userID[0].userid})`,
      comments,
      bhName,
      dhName,
    };
    emitAction(mailData);
    return true;
  } catch (error) {
    return true;
  }
}

export const getEmailTemplateforEmail = async (entityid, action) => {
  try {
    const sql = `SELECT * from wms_notifications WHERE entityid = ${entityid} and action = '${action}'`;
    const resForConfig = await query(sql);
    if (resForConfig.length > 0) {
      return resForConfig;
    }
    return false;
  } catch (error) {
    return false;
  }
};

function extractEmails(emails) {
  return emails.filter(email => email.includes('@'));
}

export const insAttachmentInfoService = async (
  kra_itemkey,
  type,
  fileName,
  path,
  empCode,
) => {
  try {
    const sql = insAttachmentInfoScript();
    const result = await query(sql, [
      kra_itemkey,
      type,
      fileName,
      path,
      empCode,
    ]);
    return result;
  } catch (error) {
    return false;
  }
};

export const getAttachmentInfoService = async kra_itemkey => {
  try {
    const sql = getAttachmentInfoScript();
    const result = await query(sql, [kra_itemkey]);
    return result;
  } catch (error) {
    return error;
  }
};

export const deleteAttachmentService = async (columnName, id) => {
  try {
    const sql = deleteAttachmentScript(columnName);
    const result = await query(sql, [id]);
    return result;
  } catch (error) {
    return error;
  }
};

export const insertUserForQuarterQPRService = payload => {
  const { quarterCode, userId, appraisalType } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const Arr = [];
      const dojNullArr = [];
      // if (appraisalType == 'QPR') {
      await transaction(async client => {
        const L1EmployeeScript = getL1UsersListScript();
        const userList = await client.query(L1EmployeeScript, [
          userId,
          appraisalType,
        ]);

        // ML employee list based on reportingto userid
        const MLEmplListScript = MLEmpList();
        const MLEmplList = await client.query(MLEmplListScript, [
          userId,
          quarterCode,
        ]);

        for (const user of userList.rows) {
          // const userScript = getUserFoundInAppraisalMappingScript();
          // const isUserFound = await client.query(userScript, [
          //   user.userid,
          //   quarterCode,
          // ]);

          let isValid = true;
          let isML = false;
          if (
            MLEmplList?.rows?.filter(data => data.empcode == user.userid)
              ?.length > 0
          ) {
            const MLDetails = await MLValidation(MLEmplList?.rows, user.userid);
            isValid = MLDetails?.isValid;
            isML = MLDetails?.isML;
          }

          if (user.doj && isValid) {
            const response = await insOrUpdTransEntryService(
              user.userid,
              quarterCode,
              userId,
              '',
              isML,
            );
            if (
              response?.AppType === 'QPR' &&
              !response?.AppraisalId &&
              !response?.TemplateId
            ) {
              Arr.push(response?.empCode);
            }
          } else if (!user.doj) {
            dojNullArr.push(user.userid);
          }
        }
        const userLists = await getScoreCardReviewDataService(payload);
        resolve({
          userLists,
          Arr,
          dojError: dojNullArr,
        });
      });
      // }
    } catch (error) {
      reject(error);
    }
  });
};

export const getScoreCardReviewDataService = async payload => {
  try {
    const {
      quarterCode,
      userId,
      appraisalType,
      statusCode,
      searchText,
      roleId,
      filter,
    } = payload;
    const { duId, bandLevelId, designationId, statusId } = filter;
    // const duIdString = duId.join();
    // const bandLevelIdString = bandLevelId.join();
    // const designationIdString = designationId.join();
    // const statusIdString = statusId.join();
    const Rolescript = getiAspireUsrRoleAcry();
    const roleAcr = (await query(Rolescript, [roleId]))[0]?.roleacronym;
    // const SubordinateScript = getSubordinatesList();
    // const SubordinateList = await query(SubordinateScript, [userId]);
    // const Arr = [];
    // Arr.push(SubordinateList.map(data => data.userid));

    const firstDU = duId.length > 0 ? duId[0].toString() : '';
    const fstBandLevel =
      bandLevelId.length > 0 ? bandLevelId[0].toString() : '';
    const fstDesig =
      designationId.length > 0 ? designationId[0].toString() : '';
    const firstStatus = statusId.length > 0 ? statusId[0].toString() : '';

    // ML Change on 08-01-2025
    // const MLUserListScript = MLEmpList();
    // const MLUserList = await query(MLUserListScript, [userId, quarterCode]);

    // const dojNullArr = [];

    // if (roleAcr != 'SHR') {
    //   await transaction(async client => {
    //     const L1EmployeeScript = getL1UsersListScript();
    //     const userList = await client.query(L1EmployeeScript, [
    //       userId,
    //       appraisalType,
    //     ]);
    //     for (const user of userList.rows) {
    //       if (appraisalType == 'KRA') {
    //         let isValid = true;
    //         let isML = false;
    //         if (
    //           MLUserList.filter(data => data.empcode == user.userid)?.length > 0
    //         ) {
    //           const MLDetails = await MLValidation(MLUserList, user.userid);
    //           isValid = MLDetails?.isValid;
    //           isML = MLDetails?.isML;
    //         }
    //         if (user.doj && isValid) {
    //           await insOrUpdTransEntryService(
    //             user.userid,
    //             quarterCode,
    //             userId,
    //             '',
    //             isML,
    //           );
    //         } else if (!user.doj) {
    //           dojNullArr.push(user.userid);
    //         }
    //         // } else if (user.doj) {
    //         //   await insOrUpdTransEntryService(
    //         //     user.userid,
    //         //     quarterCode,
    //         //     userId,
    //         //     '',
    //         //     MLUserList.filter(data => data.empcode == user.userid)?.length >
    //         //       0,
    //         //   );
    //       }
    //       const script = getUserDetailByUserIdScript();
    //       const userDetails = await query(script, [user.userid]);
    //       await reviewerDetailsMapping(
    //         user.userid,
    //         userDetails[0].reportingto,
    //         userDetails[0].duhead,
    //         userDetails[0].functionalhead,
    //         userId,
    //       );
    //     }
    //   });
    // }
    const fromScreen = 'R';
    const getScript = getMySquadListScript(
      statusCode,
      roleAcr,
      fromScreen,
      userId,
    );
    let userData;
    if (roleAcr === 'SHR') {
      userData = await query(getScript, [
        searchText,
        quarterCode,
        appraisalType,
        userId,
        firstDU,
        fstBandLevel,
        fstDesig,
        firstStatus,
        duId,
        bandLevelId,
        designationId,
        statusId,
      ]);
    } else {
      userData = await query(getScript, [
        searchText,
        quarterCode,
        appraisalType,
        userId,
        firstDU,
        fstBandLevel,
        fstDesig,
        firstStatus,
        duId,
        bandLevelId,
        designationId,
        statusId,
      ]);
    }
    return userData;
  } catch (error) {
    console.error('error', error);
    throw error;
  }
};

export const getViewScorecardService = async payload => {
  try {
    const { userid, quarterCode } = payload;
    const sql = `select * from iaspire.trn_appraisalmapping apm  where apm.employeecode = $1 and apm.quartercode = $2`;
    const userDetails = await query(sql, [userid, quarterCode]);
    const result = [...userDetails];
    if (userDetails.length > 0) {
      result[0].templateData = await getQPRTemplateDataService(
        userDetails[0].templateid,
      );
    } else {
      result[0].templateData = [];
    }
    return result;
  } catch (error) {
    return false;
  }
};

export const getUserScoreRatingService = async userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getUserScoreRateScript();
      const result = await query(script, [userId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAllCommentsService = async appraisalId => {
  return new Promise(async (resolve, reject) => {
    try {
      const commentArray = [];
      let script;

      script = getOverAllFeedbacks();
      const feedbacks = await query(script, [appraisalId]);
      commentArray.push(feedbacks[0].overallfeedback);

      script = getAddScoreRemarks();
      const addScoreRemarks = await query(script, [appraisalId]);
      commentArray.push(addScoreRemarks[0].addscoreremarks);

      script = getReOpenRejRemarksScript();
      const reopenRejRemarks = await query(script, [appraisalId]);
      commentArray.push(reopenRejRemarks[0].reopenrejremarks);

      script = getGoalRejRemarks();
      const goalRejRemarks = await query(script, [appraisalId]);
      commentArray.push(goalRejRemarks[0].goalrejremarks);

      script = getReviewRejRemarks();
      const reviewRejRemarks = await query(script, [appraisalId]);
      commentArray.push(reviewRejRemarks[0].reviewrejremarks);

      resolve(commentArray);
    } catch (error) {
      reject(error);
    }
  });
};

// MySquadGoals Report

export const getSubordinateListService = async empCode => {
  return new Promise(async (resolve, reject) => {
    try {
      const SubordinateScript = getSubordinatesList();
      const SubordinateList = await query(SubordinateScript, [empCode]);
      resolve(SubordinateList);
    } catch (error) {
      reject(error);
    }
  });
};

export const cService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duID, quarterCode, statusID, pbType, empStatus, userId } = param;
      const result = await getPBEmpReportScript(
        duID,
        quarterCode,
        statusID,
        pbType,
        empStatus,
        userId,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPBEmpReportService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        duID,
        quarterCode,
        statusID,
        pbType,
        empStatus,
        searchText,
        empType,
        key,
        fromDate,
        toDate,
      } = param;
      const result = await getPBEmpReportScript(
        duID,
        quarterCode,
        statusID,
        pbType,
        empStatus,
        searchText,
        empType,
        key,
        fromDate,
        toDate,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertClosingDateRangeService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { startDate, endDate, finTransfer, userID, rangeID } = param;
      const script = await insertClosingDateRangeScript(
        startDate,
        endDate,
        finTransfer,
        userID,
        rangeID,
      );
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getClosingDateRangeService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { date } = param;
      const script = await getClosingDateRangeScript(date);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateFinanceStsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userID, appID } = param;
      const script = await updateFinanceStsScript(userID, appID);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// iAspire Reports
export const getFilterforPBReportService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = get_master_drop_down('DU');
      const result = await query(script);
      const script1 = getQuarterList();
      const result1 = await query(script1);
      const script2 = get_master_drop_down('PBREPORTSTATUS');
      const result2 = await query(script2);
      const script3 = getQprMasterDropDownDataScript('appraisaltype');
      const result3 = await query(script3);
      const script4 = get_master_drop_down('UNIT');
      const result4 = await query(script4);
      const script5 = getQprMasterDropDownDataScript('empstatus');
      const result5 = await query(script5);
      const script6 = getQprMasterDropDownDataScript('employeetype');
      const result6 = await query(script6);

      resolve({
        du: result,
        quarter: result1,
        status: result2,
        performancetype: result3,
        unit: result4,
        empstatus: result5,
        emptype: result6,
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const updatePBNoteService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { note, userID, appID } = param;
      const script = await updatePBNoteScript(note, userID, appID);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateHoldService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { reason, userID, appID } = param;
      const script = await updateHoldScript(reason, userID, appID);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateUnHoldService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { reason, userID, appID } = param;
      const script = await updateUnHoldScript(reason, userID, appID);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateEmpStsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userID, appID } = param;
      const result = await updateEmpStsScript(userID, appID);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateEmpPaidService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { paidDate, userID, appID } = param;
      const script = await updateEmpPaidScript(paidDate, userID, appID);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPBFinReportService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { year, month, statusID, unit, searchText } = param;
      const result = await getPBFinReportScript(
        year,
        month,
        statusID,
        unit,
        searchText,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getMasterDataService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getMasterDataScript('YEAR');
      const result = await query(script);
      const script1 = getMasterDataScript('MONTH');
      const result1 = await query(script1);
      const script2 = getMasterDataScript('STATUS');
      const result2 = await query(script2);
      const script3 = getMasterDataScript('UNIT');
      const result3 = await query(script3);

      resolve({
        year: result,
        month: result1,
        status: result2,
        unit: result3,
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const getAddScoreService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { appID } = param;
      const script = await getAddScoreScript(appID);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRoleAcrService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { RoleId } = param;
      const script = await getRoleAcrScript(RoleId);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const triggerRemainderMailService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await remainderEmail(query, transaction);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// Appraisal Form
export const checkIsEligibleService = EmpID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = checkIsEligibleScript();
      const result = await query(script, [EmpID]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAppEmpDetailsService = EmpID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getAppEmpScript();
      const result = await query(script, [EmpID]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getFinYearService = EmpID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getFinYearScript();
      const result = await query(script, [EmpID]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getQuaListforYearService = (EmpId, Year) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQuarterListforYearScript();
      const result = await query(script, [EmpId, Year]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getQuestionsService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQuestionsScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const InsorUpdEmpDataService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let result;
      const {
        empId,
        finYear,
        AppType,
        modifiedBy,
        isSubmit,
        queAnswers,
        finalScore,
        finalRating,
      } = payload;
      const IsDataExist = await query(
        `SELECT * FROM iaspire.trn_yearly_appraisal WHERE employee_code = $1 AND fin_year = $2`,
        [empId, finYear],
      );
      if (IsDataExist.length > 0) {
        const script = UpdateEmpDataScript();
        const statusId = isSubmit
          ? await query(
              `SELECT statusid, status, status_category, alias_name FROM iaspire.mst_status WHERE alias_name = 'APP_L1'`,
            )
          : await query(
              `SELECT ya.statusid, s.status, s.status_category, alias_name FROM iaspire.trn_yearly_appraisal ya
              LEFT JOIN iaspire.mst_status s ON s.statusid = ya.statusid
              WHERE ya.employee_code = $1 AND ya.fin_year = $2`,
              [empId, finYear],
            );
        result = await query(script, [
          statusId[0].statusid,
          modifiedBy,
          IsDataExist[0].y_appraisal_id,
          empId,
          finYear,
        ]);
        result[0].status = statusId[0].status;
        result[0].status_category = statusId[0].status_category;
        result[0].alias_name = statusId[0].alias_name;
      } else {
        const script = InsertEmpDataScript();
        const statusId = await query(
          `SELECT statusid, status, status_category, alias_name FROM iaspire.mst_status WHERE alias_name = 'APP_YTS'`,
        );
        result = await query(script, [
          empId,
          finYear,
          AppType,
          statusId[0].statusid,
          true,
          modifiedBy,
          finalScore,
          finalRating,
        ]);
        result[0].status = statusId[0].status;
        result[0].status_category = statusId[0].status_category;
        result[0].alias_name = statusId[0].alias_name;
      }
      const queAns = await InsorUpdQueAnsService(
        result[0].y_appraisal_id,
        empId,
        queAnswers,
        modifiedBy,
      );
      resolve({ result, queAns });
    } catch (error) {
      reject(error);
    }
  });
};

export const InsorUpdQueAnsService = (AppId, empId, answer, modifiedBy) => {
  return new Promise(async (resolve, reject) => {
    try {
      await Promise.all(
        answer.map(async item => {
          const IsDataExist = await query(
            `SELECT * FROM iaspire.trn_yearly_appraisal_qa WHERE y_appraisal_id = $1 AND employee_code = $2 AND questionid = $3`,
            [AppId, empId, item.id],
          );
          if (IsDataExist.length > 0) {
            const script = UpdateQueAnsScript();
            await query(script, [
              item.answer,
              modifiedBy,
              AppId,
              empId,
              item.id,
            ]);
          } else {
            const script = InsertQueAnsScript();
            await query(script, [
              AppId,
              empId,
              item.id,
              item.answer,
              true,
              modifiedBy,
            ]);
          }
        }),
      );
      const getscript = getQueAnsScript();
      const result = await query(getscript, [AppId, empId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getFinYearKRADetailsService = (EmpId, QuarterList) => {
  return new Promise(async (resolve, reject) => {
    try {
      const KRAArr = [];
      const script = getKraGoals();
      if (QuarterList.length) {
        for (const quartercode of QuarterList) {
          const result = await query(script, [EmpId, quartercode.quartercode]);
          KRAArr.push(result);
        }
      }
      resolve(KRAArr);
    } catch (error) {
      reject(error);
    }
  });
};

export const getManagerEvaluationDataService = async payload => {
  try {
    const { userId, searchText, statusId, year } = payload;
    const yearFilter = year === '' || !year ? new Date().getFullYear() : year;
    const userDataScript = getManagerEvaluationDataScript();
    const result = await query(userDataScript, [
      userId,
      searchText,
      yearFilter,
      statusId,
    ]);
    return result;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};

export const getAppraisalStatusListService = async () => {
  try {
    const statusListScript = getAppraisalStatusListScript();
    const statusList = await query(statusListScript);
    return statusList;
  } catch (error) {
    console.error('error', error);
    throw error;
  }
};

export const getB3AboveDesignationsService = async () => {
  try {
    const designationsScript = getB3AboveDesignationsScript();
    const designationsList = await query(designationsScript);
    return designationsList;
  } catch (error) {
    console.error('error', error);
    throw error;
  }
};

export const getB3AboveBandLvlService = async userId => {
  try {
    const bandLvlScript = getB3AboveBandLvlScript();
    const bandLvlList = await query(bandLvlScript, [userId]);
    return bandLvlList;
  } catch (error) {
    console.error('error', error);
    throw error;
  }
};

export const getEmpYearlyApprisalDetService = async (appId, userId) => {
  try {
    const script = getEmpYearlyApprisalDetScript();
    const appDet = await query(script, [appId]);
    const getscript = getQueWithAnsScript();
    const queAns = await query(getscript, [appId, userId]);
    return { appDet, queAns };
  } catch (error) {
    console.error('error', error);
    throw error;
  }
};

export const updAppraisalReviewDataService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        userId,
        year,
        modifiedBy,
        isSubmit,
        finalScore,
        rating,
        isPromotion,
        bandLevel,
        designation,
        justComments,
        l1Comments,
        l2Comments,
      } = payload;
      const IsDataExist = await query(
        `SELECT * FROM iaspire.trn_yearly_appraisal WHERE employee_code = $1 AND fin_year = $2`,
        [userId, year],
      );
      if (IsDataExist.length > 0) {
        let statusId = null;
        const updateScript = updateAppReviewDataScript();
        if (isSubmit) {
          const script = getAppNxtStausIdScript();
          const statusDet = await query(script, [userId, modifiedBy]);
          statusId = statusDet[0]?.statusid;
        }

        await query(updateScript, [
          userId,
          year,
          statusId,
          modifiedBy,
          finalScore,
          rating,
          isPromotion,
          bandLevel,
          designation,
          l1Comments,
          l2Comments,
          justComments,
        ]);
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const checkAppManEvalEligibleService = async userId => {
  try {
    const script = checkAppManEvalEligibleScript();
    const result = await query(script, [userId]);
    return result?.length > 0;
  } catch (error) {
    console.error('error', error);
    throw error;
  }
};

// Form Assessment Q&A
export const getFilterforFormAssessmentService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = get_master_drop_down('DU');
      const result = await query(script);
      const script1 = getDesignationScript();
      const result1 = await query(script1);
      resolve({
        du: result,
        designation: result1,
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const getQueforFormAssessmentService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQuestionaliasnameScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getFormAssessmentDataService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { Duid, Designationid, Search } = payload;
      const script = getFormAssessmentScript();
      const result = await query(script, [Duid, Designationid, Search]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
// Form Assessment Q&A END

// Appraisal Form Report
export const getFilterforAppraisalFormReportService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getStatusScript();
      const result = await query(script);
      const script1 = getfinancialYearScript();
      const result1 = await query(script1);
      resolve({
        status: result,
        year: result1,
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const getAppraisalFormReportService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { Statusid, Year, Search } = payload;
      const script = getAppraisalFormReport();
      const result = await query(script, [Statusid, Year, Search]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getgiftservice = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getGift();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const setGiftService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userid, itemid } = payload;
      const script = setGift();
      const result = await query(script, [userid, itemid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUserGiftService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userid } = payload;
      const script = getUserGiftDetails();
      const result = await query(script, [userid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getgiftexcelservice = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getGiftExcelDetails();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const checkIsDOJAvailableService = async userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = checkIsDOJAvailable();
      const result = await query(script, [userId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// get duheasd, functionalhead dropdown data
export const getDUHFUHService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getDUHFUHScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updDUHFUHService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, duHead, fuHead, modifiedBy } = payload;
      const script = updDUHFUHScript();
      const result = await query(script, [userId, duHead, fuHead, modifiedBy]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const MLValidation = async (MLData, empCode) => {
  let isValid = true;
  let isML = false;
  const userData = MLData?.filter(data => data.empcode == empCode)[0];
  const daysDiffofStartDate = moment(userData?.mlstartdate).diff(
    moment(userData?.quarterstartdate),
    'days',
  );
  const daysDiffofEndDate = moment(userData?.quarterenddate).diff(
    moment(userData?.mlenddaate),
    'days',
  );

  const quarterStart = new Date(userData?.quarterstartdate);
  const quarterEnd = new Date(userData?.quarterenddate);
  const mlStart = new Date(userData?.mlstartdate);
  const mlEnd = new Date(userData?.mlenddaate);

  // ML starts in quarter
  if (
    quarterStart < mlStart &&
    mlStart < quarterEnd &&
    quarterEnd < mlEnd &&
    daysDiffofStartDate >= 15
  ) {
    isValid = true;
    isML = true;
    // ML ends in quarter
  } else if (
    mlStart < quarterStart &&
    quarterStart < mlEnd &&
    mlEnd < quarterEnd &&
    daysDiffofEndDate >= 15
  ) {
    isValid = true;
    // ML not eligible
  } else if (
    (mlStart < quarterStart &&
      quarterStart < quarterEnd &&
      quarterEnd < mlEnd) ||
    (daysDiffofStartDate < 15 && daysDiffofEndDate < 15)
  ) {
    isValid = false;
    // Quarter which falls Before ML
  } else if (quarterEnd < mlStart) {
    isValid = true;
    // Quarter which falls After ML
  } else if (mlEnd < quarterStart) {
    isValid = true;
  } else {
    isValid = false;
  }
  return { isValid, isML };
};
