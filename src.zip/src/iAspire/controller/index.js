import {
  createOrUpdateRatingService,
  createRatingGroupService,
  deleteRatingValueService,
  getUserDetailsServce,
  getOrInsCurrentQuaterDetailsService,
  getQuaterListService,
  insOrUpdTransEntryService,
  getUserDeatilsForKraGoalsService,
  getKraGoalsService,
  getKraGoalsWithVersionService,
  copyPrevQuarterKraGoalsService,
  insertOrUpdateKraLineItemsService,
  deleteKraLineItemService,
  updateKraGoalsSubmitStatusService,
  updateKraLineItemSelfScoreService,
  updateApproveorRejectService,
  // updateRejectService,
  getEmpAppraisalListService,
  updateEmpAppraisalDetService,
  getEmpAppraisalHistoryService,
  getEmailTemplateService,
  getMySquadListService,
  updateFeedbackService,
  updateTotalScoreService,
  updateAdditionalScoreService,
  updateKraQprLineItemReviewScoreService,
  updateQprLineItemReviewScoreService,
  updateUserService,
  maternityLeaveIntegrationService,
  getReportHeadMappingService,
  createScoreAndRatingGroupService,
  createScoreAndRatingValueService,
  getScoreAndRatingGroupOptionsService,
  getScoreAndRatingGroupByFilterService,
  getScoreAndRatingUserDataService,
  insUpdTemplateMstService,
  insUpdTemplateConfigService,
  iAspireSoftDelService,
  iAspireHardDelService,
  insertTemplateDetails,
  getTemplateDetails,
  getCombinationDetails,
  iAspireExcelUploadService,
  getPerformanceTypeMapService,
  updatePerformanceMapService,
  getHistoryPerformanceMapService,
  getMLMappingDetailsService,
  insertMLMappingService,
  updateMLMappingService,
  deleteMLMappingService,
  assignGroupRatingService,
  getDuHeadFuHeadService,
  getAppraisalTypeService,
  getScoreRatingHistoryService,
  getViewMLDetailsService,
  getAppraisalTypeforApprSetupService,
  getBandLvlTemplateService,
  getQPRMasterDropDownService,
  getQPRTemplateDataService,
  getOrInsQPRLineitemService,
  getQPRStatusforQuarterService,
  getLineItemforReportService,
  getStatusListService,
  getStatusTrackerCurrentService,
  getLineItemRatingService,
  getKraVersionListService,
  getStatusTrackerRejectionService,
  getReopenReqListService,
  getReopenReqTypeService,
  aprRejReopenReqService,
  getQuarterListService,
  insAttachmentInfoService,
  getAttachmentInfoService,
  deleteAttachmentService,
  getRatingService,
  getScoreCardReviewDataService,
  getViewScorecardService,
  getUserScoreRatingService,
  requestReOpenService,
  getQRatingListService,
  getAllCommentsService,
  insertUserForQuarterService,
  insertUserForQuarterQPRService,
  // fetchDataAndJoin,
  getSubordinateListService,
  getPBEmpReportService,
  insertClosingDateRangeService,
  getClosingDateRangeService,
  updateFinanceStsService,
  getFilterforPBReportService,
  getPBFinReportService,
  getMasterDataService,
  updateEmpStsService,
  updatePBNoteService,
  updateEmpPaidService,
  getAddScoreService,
  getRoleAcrService,
  triggerRemainderMailService,
  updateHoldService,
  updateUnHoldService,
  checkIsEligibleService,
  getAppEmpDetailsService,
  getFinYearService,
  getQuaListforYearService,
  getQuestionsService,
  InsorUpdEmpDataService,
  getFinYearKRADetailsService,
  getManagerEvaluationDataService,
  getAppraisalStatusListService,
  getB3AboveDesignationsService,
  getEmpYearlyApprisalDetService,
  updAppraisalReviewDataService,
  getB3AboveBandLvlService,
  checkAppManEvalEligibleService,
  getFilterforFormAssessmentService,
  getQueforFormAssessmentService,
  getFormAssessmentDataService,
  getFilterforAppraisalFormReportService,
  getAppraisalFormReportService,
  getDesigBandLevelListService,
  getgiftservice,
  setGiftService,
  getUserGiftService,
  getgiftexcelservice,
  checkIsDOJAvailableService,
  getDUHFUHService,
  updDUHFUHService,
} from '../service/index.js';

// iStrong Integration start

export const updateUserController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateUserService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const maternityLeaveIntegrationController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await maternityLeaveIntegrationService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// iStrong Integration end

export const createRatingGroupController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createRatingGroupService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createOrUpdateRatingValueController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createOrUpdateRatingService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteRatingValueController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await deleteRatingValueService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getReportHeadMappingController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getReportHeadMappingService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUserDetailsController = async (req, res) => {
  try {
    const payload = req.body;
    const { userId } = payload;
    const result = await getUserDetailsServce(userId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getDuHeadFuHeadController = async (req, res) => {
  try {
    const result = await getDuHeadFuHeadService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// score and Rating
export const getScoreAndRatingCreateGroupController = async (req, res) => {
  try {
    const payload = req.body;
    const { groupData, ratingData } = payload;
    const groupDetails = await createScoreAndRatingGroupService(groupData);
    const { groupid } = groupDetails[0];
    const result = await createScoreAndRatingValueService(ratingData, groupid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getScoreAndRatingGroupOptionsController = async (req, res) => {
  try {
    const result = await getScoreAndRatingGroupOptionsService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getScoreAndRatingGroupFilterController = async (req, res) => {
  try {
    const filterdata = req.payload;
    const result = await getScoreAndRatingGroupByFilterService(filterdata);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getScoreAndRatingGroupUserDataController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getScoreAndRatingUserDataService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const assignGroupRatingController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await assignGroupRatingService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getScoreRatingHistoryController = async (req, res) => {
  try {
    const { duId, designationId, bandlevelId } = req.params;
    const result = await getScoreRatingHistoryService(
      duId,
      designationId,
      bandlevelId,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// score and Rating

// Appraisal Set Up start

export const getEmpAppraisalListController = async (req, res) => {
  try {
    const { duId, bandId, desigId, appId, searchText } = req.body;
    const result = await getEmpAppraisalListService(
      duId,
      bandId,
      desigId,
      appId,
      searchText,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateEmpAppraisalDetController = async (req, res) => {
  try {
    const { empCode, appTypeId, effYear, modifiedBy } = req.body;
    const result = await updateEmpAppraisalDetService(
      empCode,
      appTypeId,
      effYear,
      modifiedBy,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getEmpAppraisalHistoryController = async (req, res) => {
  try {
    const { appId } = req.params;
    const result = await getEmpAppraisalHistoryService(appId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAppraisalTypeforApprSetupController = async (req, res) => {
  try {
    const result = await getAppraisalTypeforApprSetupService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getDesigBandLevelListController = async (req, res) => {
  try {
    const result = await getDesigBandLevelListService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// Appraisal Set Up end

// Email Links start

export const getEmailTemplateController = async (req, res) => {
  try {
    const { entityId, searchText } = req.body;
    const result = await getEmailTemplateService(entityId, searchText);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Email Links end

// Performance Type mapping start

export const getPerformanceTypeMapController = async (req, res) => {
  try {
    const { type, duId, searchText } = req.body;
    const result = await getPerformanceTypeMapService(type, duId, searchText);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updatePerformanceMapController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updatePerformanceMapService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getHistoryPerformanceMapConstroller = async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await getHistoryPerformanceMapService(userId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAppraisalTypeConstroller = async (req, res) => {
  try {
    const { empCode } = req.params;
    const result = await getAppraisalTypeService(empCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Performance Type mapping end

// ML Mapping start

export const getMLMappingDetailsController = async (req, res) => {
  try {
    const { searchText } = req.body;
    const result = await getMLMappingDetailsService(searchText);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertMLMappingController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await insertMLMappingService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateMLMappingController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateMLMappingService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteMLMappingController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await deleteMLMappingService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getViewMLDetailsController = async (req, res) => {
  try {
    const { empCode } = req.params;
    const result = await getViewMLDetailsService(empCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// ML Mapping end

// My Goals start

export const getOrInsCurrentQuaterDetailsController = async (req, res) => {
  try {
    const { dateParam, empCode } = req.body;
    const result = await getOrInsCurrentQuaterDetailsService(
      dateParam,
      empCode,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQuaterListController = async (req, res) => {
  try {
    const { empCode } = req.params;
    const result = await getQuaterListService(empCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUserDeatilsForKraGoalsController = async (req, res) => {
  try {
    const { appraisalId } = req.params;
    const result = await getUserDeatilsForKraGoalsService(appraisalId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insOrUpdTransEntryController = async (req, res) => {
  try {
    const { empCode, quarterCode, modifiedBy } = req.body;
    const result = await insOrUpdTransEntryService(
      empCode,
      quarterCode,
      modifiedBy,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getKraGoalsController = async (req, res) => {
  try {
    const { empCode, quarterCode } = req.body;
    const result = await getKraGoalsService(empCode, quarterCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getKraGoalsWithVersionController = async (req, res) => {
  try {
    const { empCode, quarterCode, versionId } = req.body;
    const result = await getKraGoalsWithVersionService(
      empCode,
      quarterCode,
      versionId,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getKraVersionListController = async (req, res) => {
  try {
    const { appraisalId } = req.params;
    const result = await getKraVersionListService(appraisalId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const copyPrevQuarterKraGoalsController = async (req, res) => {
  try {
    const { empCode, quarterCode } = req.body;
    const result = await copyPrevQuarterKraGoalsService(empCode, quarterCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertOrUpdateKraLineItemsController = async (req, res) => {
  try {
    const { empCode, quarterCode, versionId, payload, maxKey, goalApproved } =
      req.body;
    const result = await insertOrUpdateKraLineItemsService(
      empCode,
      quarterCode,
      payload,
      versionId,
      maxKey,
      goalApproved,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteKraLineItemController = async (req, res) => {
  try {
    // const { itemId } = req.params;
    const result = await deleteKraLineItemService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateKraGoalsSubmitStatusController = async (req, res) => {
  try {
    const { appraisalId, statusName, empCode } = req.body;
    const result = await updateKraGoalsSubmitStatusService(
      appraisalId,
      statusName,
      empCode,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateKraLineItemSelfScoreController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateKraLineItemSelfScoreService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getOrInsQPRLineitemController = async (req, res) => {
  try {
    const { AppraisalId, TemplateId, Quarter, empCode, CreatedBy } = req.body;
    const result = await getOrInsQPRLineitemService(
      AppraisalId,
      TemplateId,
      Quarter,
      empCode,
      CreatedBy,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQPRStatusforQuarterController = async (req, res) => {
  try {
    const { appraisalId } = req.params;
    const result = await getQPRStatusforQuarterService(appraisalId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getLineItemforReportController = async (req, res) => {
  try {
    const { empCode, quarterCode } = req.body;
    const result = await getLineItemforReportService(empCode, quarterCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getStatusListController = async (req, res) => {
  try {
    const { empCode } = req.params;
    const result = await getStatusListService(empCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getStatusTrackerCurrentController = async (req, res) => {
  try {
    const { quarterCode, statusId, empCode } = req.body;
    const result = await getStatusTrackerCurrentService(
      quarterCode,
      statusId,
      empCode,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getStatusTrackerRejectController = async (req, res) => {
  try {
    const { quarterCode, statusId, empCode } = req.body;
    const result = await getStatusTrackerRejectionService(
      quarterCode,
      statusId,
      empCode,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getLineItemRatingController = async (req, res) => {
  try {
    const { lineitemId } = req.params;
    const result = await getLineItemRatingService(lineitemId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRatingController = async (req, res) => {
  try {
    const { empCode, totalScore } = req.params;
    const result = await getRatingService(empCode, totalScore);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// My Goals end

// My Squad goals start

export const insertQuarterUserListController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await insertUserForQuarterService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getMySquadListController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getMySquadListService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateApproveorRejectController = async (req, res) => {
  try {
    const {
      appraisalId,
      approvalLvl,
      modifiedBy,
      rejectComment,
      actionType,
      overAllFeedBack,
    } = req.body;
    const result = await updateApproveorRejectService(
      appraisalId,
      approvalLvl,
      modifiedBy,
      rejectComment,
      actionType,
      overAllFeedBack,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// export const updateRejectController = async (req, res) => {
//   try {
//     const { appraisalId, remarks, modifiedBy } = req.body;
//     const result = await updateRejectService(appraisalId, remarks, modifiedBy);
//     res.status(200).send(result);
//   } catch (error) {
//
//     res.status(400).send({ error, message: error?.message });
//   }
// };

export const updateKraQprLineItemReviewScoreController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateKraQprLineItemReviewScoreService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateQprLineItemReviewScoreController = async (req, res) => {
  try {
    const { appraisalId, lineItem } = req.body;
    const result = await updateQprLineItemReviewScoreService(
      appraisalId,
      lineItem,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateFeedbackController = async (req, res) => {
  try {
    const { appraisalId, remarks, modifiedBy } = req.body;
    const result = await updateFeedbackService(
      appraisalId,
      remarks,
      modifiedBy,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateTotalScoreController = async (req, res) => {
  try {
    const { appraisalId, score, modifiedBy } = req.body;
    const result = await updateTotalScoreService(
      appraisalId,
      score,
      modifiedBy,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateAdditionalScoreController = async (req, res) => {
  try {
    const { appraisalId, statusId, additionalScore, remarks, modifiedBy } =
      req.body;
    const result = await updateAdditionalScoreService(
      appraisalId,
      statusId,
      additionalScore,
      remarks,
      modifiedBy,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const requestReOpenController = async (req, res) => {
  try {
    const { appraisalId, reqType, reqRemarks, modifiedBy } = req.body;
    const result = await requestReOpenService(
      appraisalId,
      reqType,
      reqRemarks,
      modifiedBy,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getReopenReqListController = async (req, res) => {
  const { typeId, roleId, searchText, userId } = req.body;
  try {
    const result = await getReopenReqListService(
      typeId,
      roleId,
      searchText,
      userId,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQuarterListController = async (req, res) => {
  try {
    const result = await getQuarterListService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getReopenReqTypeController = async (req, res) => {
  try {
    const result = await getReopenReqTypeService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const aprRejReopenReqController = async (req, res) => {
  const {
    requestId,
    appraisalId,
    modalType,
    reqType,
    comment,
    userid,
    roleId,
  } = req.body;
  try {
    const result = await aprRejReopenReqService(
      requestId,
      appraisalId,
      modalType,
      reqType,
      comment,
      userid,
      roleId,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUserScoreRateContoller = async (req, res) => {
  try {
    const { userId } = req.body;
    const result = await getUserScoreRatingService(userId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQRatingListController = async (req, res) => {
  try {
    const { empCode } = req.body;
    const result = await getQRatingListService(empCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// My Squad goals end

export const insUpdTemplateMstController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await insUpdTemplateMstService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insUpdTemplateConfigController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await insUpdTemplateConfigService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const iAspireSoftDelController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAspireSoftDelService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const iAspireHardDelController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAspireHardDelService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertTemplateDetailsController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await insertTemplateDetails(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getTemplateDetailsController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getTemplateDetails(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCombinationDetailsController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getCombinationDetails(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const iAspireExcelUploadServiceController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAspireExcelUploadService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getBandLvlTemplateController = async (req, res) => {
  try {
    const { DuList, BandLevelList, designationList } = req.body;
    const result = await getBandLvlTemplateService(
      DuList,
      BandLevelList,
      designationList,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQPRMstDropdownController = async (req, res) => {
  try {
    const { master } = req.body;
    const result = await getQPRMasterDropDownService(master);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getQPRTemplateController = async (req, res) => {
  try {
    const { templateId } = req.body;
    const result = await getQPRTemplateDataService(templateId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insAttachmentInfoController = async (req, res) => {
  try {
    const { kra_itemkey, type, fileName, path, empCode } = req.body;
    const result = await insAttachmentInfoService(
      kra_itemkey,
      type,
      fileName,
      path,
      empCode,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAttachmentInfoController = async (req, res) => {
  try {
    const { kra_itemkey } = req.params;
    const result = await getAttachmentInfoService(kra_itemkey);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteAttachmentController = async (req, res) => {
  try {
    const { kra_itemkey, kra_attachmentid } = req.body;
    let result = false;
    if (kra_itemkey) {
      result = await deleteAttachmentService('kra_itemkey', kra_itemkey);
    } else if (kra_attachmentid) {
      result = await deleteAttachmentService(
        'kra_attachmentid',
        kra_attachmentid,
      );
    }
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getiAspireFolderPath = async (req, res) => {
  try {
    const { quarter, empCode, version, type } = req.body;
    let path;
    if (type === 'Plan') {
      path = `/okm:root/prodrepository/iAspire/${quarter}/${empCode}/Plan/${version}/`;
    } else {
      path = `/okm:root/prodrepository/iAspire/${quarter}/${empCode}/Actual/`;
    }
    res.status(200).send({
      path,
    });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertQPRQuarterUserController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await insertUserForQuarterQPRService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getScoreCardReviewDataController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getScoreCardReviewDataService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getViewScoreCardController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getViewScorecardService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAllCommentsController = async (req, res) => {
  try {
    const { appraisalId } = req.params;
    const result = await getAllCommentsService(appraisalId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// MySquadGoals Report
export const getSubordinateListController = async (req, res) => {
  try {
    const { empCode } = req.params;
    const result = await getSubordinateListService(empCode);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getPBEmpReportController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getPBEmpReportService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertClosingDateRangeController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await insertClosingDateRangeService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getClosingDateRangeController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getClosingDateRangeService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateFinanceStsController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateFinanceStsService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFilterforPBReportController = async (req, res) => {
  try {
    const result = await getFilterforPBReportService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateEmpStsController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateEmpStsService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updatePBNoteController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updatePBNoteService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateEmpPaidController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateEmpPaidService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getPBFinReportController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getPBFinReportService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getMasterDataController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getMasterDataService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAddScoreController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getAddScoreService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRoleAcrController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getRoleAcrService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const triggerRemainderMailController = async (req, res) => {
  try {
    const result = await triggerRemainderMailService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateHoldController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateHoldService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateUnHoldController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateUnHoldService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Appraisal Form
export const checkIsEligibleController = async (req, res) => {
  try {
    const { EmpId } = req.params;
    const result = await checkIsEligibleService(EmpId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAppEmpDetailsController = async (req, res) => {
  try {
    const { EmpId } = req.params;
    const result = await getAppEmpDetailsService(EmpId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFinYearController = async (req, res) => {
  try {
    const { EmpId } = req.params;
    const result = await getFinYearService(EmpId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQuaListforYearController = async (req, res) => {
  try {
    const { EmpId, Year } = req.params;
    const result = await getQuaListforYearService(EmpId, Year);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQuestionsController = async (req, res) => {
  try {
    const result = await getQuestionsService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const InsorUpdEmpDataController = async (req, res) => {
  try {
    const result = await InsorUpdEmpDataService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFinYearKRADetailsController = async (req, res) => {
  try {
    const { EmpId, QuarterList } = req.body;
    const result = await getFinYearKRADetailsService(EmpId, QuarterList);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getManagerEvaluationDataController = async (req, res) => {
  try {
    const result = await getManagerEvaluationDataService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAppraisalStatusListController = async (req, res) => {
  try {
    const result = await getAppraisalStatusListService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getB3AboveDesignationsController = async (req, res) => {
  try {
    const result = await getB3AboveDesignationsService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getB3AboveBandLvlController = async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await getB3AboveBandLvlService(userId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getEmpYearlyApprisalDetController = async (req, res) => {
  try {
    const { appId, userId } = req.body;
    const result = await getEmpYearlyApprisalDetService(appId, userId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updAppraisalReviewDataController = async (req, res) => {
  try {
    const result = await updAppraisalReviewDataService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const checkAppManEvalEligibleController = async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await checkAppManEvalEligibleService(userId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Form Assessment Q&A
export const getFilterforFormAssessmentController = async (req, res) => {
  try {
    const result = await getFilterforFormAssessmentService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQueforFormAssessmentController = async (req, res) => {
  try {
    const result = await getQueforFormAssessmentService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFormAssessmentDataController = async (req, res) => {
  try {
    const result = await getFormAssessmentDataService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFilterforAppraisalFormReportController = async (req, res) => {
  try {
    const result = await getFilterforAppraisalFormReportService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAppraisalFormReportController = async (req, res) => {
  try {
    const result = await getAppraisalFormReportService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getgiftController = async (req, res) => {
  try {
    const result = await getgiftservice();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const setGiftServiceController = async (req, res) => {
  try {
    const result = await setGiftService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUserGiftDetailsController = async (req, res) => {
  try {
    const result = await getUserGiftService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getGiftExcelController = async (req, res) => {
  try {
    const result = await getgiftexcelservice();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const checkIsDOJAvailableController = async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await checkIsDOJAvailableService(userId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// get duheasd, functionalhead dropdown data
export const getDUHFUHController = async (req, res) => {
  try {
    const result = await getDUHFUHService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updDUHFUHController = async (req, res) => {
  try {
    const result = await updDUHFUHService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
