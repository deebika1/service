import express from 'express';
import swaggerUi from 'swagger-ui-express';
import { readFileSync } from 'fs';
import {
  // validateArrRequestBody,
  validateRequestBody,
  validateRequestParams,
} from '../helpers/middleware.js';
import {
  aprRejeopenreqSchema,
  getReopenReqListSchema,
  getAttachmentInfoSchema,
  insAttachmentInfoSchema,
  getiAspireFolderPathSchema,
  deleteAttachmentSchema,
} from '../helpers/validation.js';

import {
  createOrUpdateRatingValueController,
  createRatingGroupController,
  deleteRatingValueController,
  getUserDetailsController,
  getEmpAppraisalListController,
  updateEmpAppraisalDetController,
  getEmpAppraisalHistoryController,
  getEmailTemplateController,
  getOrInsCurrentQuaterDetailsController,
  getQuaterListController,
  getUserDeatilsForKraGoalsController,
  insOrUpdTransEntryController,
  getKraGoalsController,
  getKraGoalsWithVersionController,
  copyPrevQuarterKraGoalsController,
  insertOrUpdateKraLineItemsController,
  deleteKraLineItemController,
  updateKraGoalsSubmitStatusController,
  updateKraLineItemSelfScoreController,
  getMySquadListController,
  updateApproveorRejectController,
  // updateRejectController,
  updateKraQprLineItemReviewScoreController,
  updateQprLineItemReviewScoreController,
  updateFeedbackController,
  updateTotalScoreController,
  updateAdditionalScoreController,
  updateUserController,
  maternityLeaveIntegrationController,
  getReportHeadMappingController,
  getScoreAndRatingCreateGroupController,
  getScoreAndRatingGroupOptionsController,
  getScoreAndRatingGroupFilterController,
  getScoreAndRatingGroupUserDataController,
  insUpdTemplateMstController,
  insUpdTemplateConfigController,
  iAspireSoftDelController,
  iAspireHardDelController,
  insertTemplateDetailsController,
  getTemplateDetailsController,
  getCombinationDetailsController,
  iAspireExcelUploadServiceController,
  getPerformanceTypeMapController,
  updatePerformanceMapController,
  getHistoryPerformanceMapConstroller,
  getMLMappingDetailsController,
  insertMLMappingController,
  updateMLMappingController,
  deleteMLMappingController,
  assignGroupRatingController,
  getDuHeadFuHeadController,
  getAppraisalTypeConstroller,
  getScoreRatingHistoryController,
  getViewMLDetailsController,
  getAppraisalTypeforApprSetupController,
  getBandLvlTemplateController,
  getQPRMstDropdownController,
  getQPRTemplateController,
  getOrInsQPRLineitemController,
  getQPRStatusforQuarterController,
  getLineItemforReportController,
  getStatusListController,
  getStatusTrackerCurrentController,
  getLineItemRatingController,
  getKraVersionListController,
  getStatusTrackerRejectController,
  requestReOpenController,
  getReopenReqListController,
  getReopenReqTypeController,
  aprRejReopenReqController,
  getQuarterListController,
  insAttachmentInfoController,
  getAttachmentInfoController,
  deleteAttachmentController,
  getiAspireFolderPath,
  getRatingController,
  getScoreCardReviewDataController,
  getViewScoreCardController,
  getUserScoreRateContoller,
  getAllCommentsController,
  insertQPRQuarterUserController,
  getSubordinateListController,
  getPBEmpReportController,
  insertClosingDateRangeController,
  getClosingDateRangeController,
  updateFinanceStsController,
  getFilterforPBReportController,
  getPBFinReportController,
  getMasterDataController,
  updateEmpStsController,
  updatePBNoteController,
  updateEmpPaidController,
  getAddScoreController,
  getRoleAcrController,
  triggerRemainderMailController,
  updateHoldController,
  updateUnHoldController,
  checkIsEligibleController,
  getAppEmpDetailsController,
  getFinYearController,
  getQuaListforYearController,
  getQuestionsController,
  InsorUpdEmpDataController,
  getFinYearKRADetailsController,
  getManagerEvaluationDataController,
  getAppraisalStatusListController,
  getB3AboveDesignationsController,
  getEmpYearlyApprisalDetController,
  updAppraisalReviewDataController,
  getB3AboveBandLvlController,
  checkAppManEvalEligibleController,
  getFilterforFormAssessmentController,
  getQueforFormAssessmentController,
  getFormAssessmentDataController,
  getFilterforAppraisalFormReportController,
  getAppraisalFormReportController,
  getDesigBandLevelListController,
  getgiftController,
  setGiftServiceController,
  getUserGiftDetailsController,
  getGiftExcelController,
  checkIsDOJAvailableController,
  getDUHFUHController,
  updDUHFUHController,
} from '../controller/index.js';

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}

const iAspireRouter = express.Router();
swaggerDocs(iAspireRouter);
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

// iStrong Integration start
iAspireRouter.post('/userUpdation', handler(updateUserController));
iAspireRouter.post(
  '/maternityLeaveIntegration',
  handler(maternityLeaveIntegrationController),
);
// iStrong Integration end

iAspireRouter.post('/ratinggroup', handler(createRatingGroupController));
iAspireRouter.post('/deleterating', handler(deleteRatingValueController));
iAspireRouter.post(
  '/getreportinghead',
  handler(getReportHeadMappingController),
);
iAspireRouter.post(
  '/ratingvalue',
  handler(createOrUpdateRatingValueController),
);
iAspireRouter.post('/getUserDetails', handler(getUserDetailsController));
iAspireRouter.get('/getDuFuHeadDetails', handler(getDuHeadFuHeadController));

// Appraisal Set Up start
iAspireRouter.post(
  '/getEmpAppraisalList',
  handler(getEmpAppraisalListController),
);
iAspireRouter.post(
  '/updateEmpAppraisalDet',
  handler(updateEmpAppraisalDetController),
);

iAspireRouter.get(
  '/getEmpAppraisalHistory/:appId',
  handler(getEmpAppraisalHistoryController),
);
iAspireRouter.get(
  '/getAppraisalTypeforApprSetup',
  handler(getAppraisalTypeforApprSetupController),
);
iAspireRouter.get(
  '/getdesigbandlevellist',
  handler(getDesigBandLevelListController),
);
// Appraisal Set Up end
// Email Links start
iAspireRouter.post('/getEmailTemplate', handler(getEmailTemplateController));
// Email Links end
// score and rating
iAspireRouter.post(
  '/createGroup',
  handler(getScoreAndRatingCreateGroupController),
);
iAspireRouter.get(
  '/groupOption',
  handler(getScoreAndRatingGroupOptionsController),
);
iAspireRouter.post(
  '/scoreoption',
  handler(getScoreAndRatingGroupFilterController),
);
iAspireRouter.post(
  '/scoredata',
  handler(getScoreAndRatingGroupUserDataController),
);
iAspireRouter.post('/assigngroup', handler(assignGroupRatingController));
iAspireRouter.get(
  '/getScoreRatingHistory/:duId/:designationId/:bandlevelId',
  handler(getScoreRatingHistoryController),
);
// score and rating
// QPR Template
iAspireRouter.post('/insUpdTemplateMst', handler(insUpdTemplateMstController));
iAspireRouter.post(
  '/assignqprtemplate',
  handler(insUpdTemplateConfigController),
);
iAspireRouter.post('/iAspireSoftDel', handler(iAspireSoftDelController));
iAspireRouter.post('/iAspireHardDel', handler(iAspireHardDelController));
iAspireRouter.post('/createtemplate', handler(insertTemplateDetailsController));
iAspireRouter.get('/getTemplateDetails', handler(getTemplateDetailsController));
iAspireRouter.post(
  '/getCombinationDetails',
  handler(getCombinationDetailsController),
);
iAspireRouter.post('/getqprmst', handler(getQPRMstDropdownController));
iAspireRouter.post('/getqprtemplatedata', handler(getQPRTemplateController));
// QPR Template
iAspireRouter.post(
  '/uploadExcel',
  handler(iAspireExcelUploadServiceController),
);
iAspireRouter.post(
  '/getBandLvlTemplateDetails',
  handler(getBandLvlTemplateController),
);
// Performance Type Mapping start
iAspireRouter.post(
  '/getPerformanceTypeNotMapped',
  handler(getPerformanceTypeMapController),
);
iAspireRouter.post(
  '/updatePerformanceTypeNotMap',
  handler(updatePerformanceMapController),
);
iAspireRouter.get(
  '/getHistoryPerformanceMap/:userId',
  handler(getHistoryPerformanceMapConstroller),
);
iAspireRouter.get(
  '/getapprtypeperfmap/:empCode',
  handler(getAppraisalTypeConstroller),
);
// Performance Type Mapping end
// ML Mapping start
iAspireRouter.post(
  '/getMLMappingDetails',
  handler(getMLMappingDetailsController),
);
iAspireRouter.post('/insertMLMapping', handler(insertMLMappingController));
iAspireRouter.post('/updateMLMapping', handler(updateMLMappingController));
iAspireRouter.post('/deleteMLMapping', handler(deleteMLMappingController));
iAspireRouter.get(
  '/getViewMLDetails/:empCode',
  handler(getViewMLDetailsController),
);
// ML Mapping end
// My Goals start
iAspireRouter.post(
  '/getOrInsCurrentQuaterDetails',
  handler(getOrInsCurrentQuaterDetailsController),
);
iAspireRouter.get('/getQuaterList/:empCode', handler(getQuaterListController));
iAspireRouter.post(
  '/insOrUpdTransEntry',
  handler(insOrUpdTransEntryController),
);
iAspireRouter.get(
  '/getuserdetailsforkra/:appraisalId',
  handler(getUserDeatilsForKraGoalsController),
);
iAspireRouter.post('/getkragoals', handler(getKraGoalsController));
iAspireRouter.post(
  '/getkragoalswithversion',
  handler(getKraGoalsWithVersionController),
);
iAspireRouter.get(
  '/getkraversionlist/:appraisalId',
  handler(getKraVersionListController),
);
iAspireRouter.post(
  '/copyprevquartergoals',
  handler(copyPrevQuarterKraGoalsController),
);
iAspireRouter.post(
  '/insorupdatekraitems',
  handler(insertOrUpdateKraLineItemsController),
);
iAspireRouter.post('/delkralineitem', handler(deleteKraLineItemController));
iAspireRouter.post(
  '/updatekrasubmit',
  handler(updateKraGoalsSubmitStatusController),
);
iAspireRouter.post(
  '/updatekraitemselfscore',
  handler(updateKraLineItemSelfScoreController),
);
iAspireRouter.post(
  '/getorinstransentry',
  handler(getOrInsQPRLineitemController),
);
iAspireRouter.get(
  '/getqprstatusforquarter/:appraisalId',
  handler(getQPRStatusforQuarterController),
);
iAspireRouter.post(
  '/getlineitemforreport',
  handler(getLineItemforReportController),
);
iAspireRouter.get('/getstatuslist/:empCode', handler(getStatusListController));
iAspireRouter.post(
  '/getstatustrackercurrent',
  handler(getStatusTrackerCurrentController),
);
iAspireRouter.post(
  '/getstatusrejected',
  handler(getStatusTrackerRejectController),
);
iAspireRouter.get(
  '/getlineitemrating/:lineitemId',
  handler(getLineItemRatingController),
);
iAspireRouter.post(
  '/insattachmentinfo',
  validateRequestBody(insAttachmentInfoSchema),
  handler(insAttachmentInfoController),
);
iAspireRouter.get(
  '/getattachmentinfo/:kra_itemkey',
  validateRequestParams(getAttachmentInfoSchema),
  handler(getAttachmentInfoController),
);
iAspireRouter.post(
  '/deleteattachment',
  validateRequestBody(deleteAttachmentSchema),
  handler(deleteAttachmentController),
);
iAspireRouter.get(
  '/getrating/:empCode/:totalScore',
  handler(getRatingController),
);

// My Goals end
// My Squad Goals start
iAspireRouter.post('/quarteruserlist', handler(getMySquadListController));
iAspireRouter.post('/mysquadlist', handler(getMySquadListController));
iAspireRouter.post(
  '/updateapproveorreject',
  handler(updateApproveorRejectController),
);
// iAspireRouter.post('/updateReject', handler(updateRejectController));
iAspireRouter.post(
  '/kraqprapprovereject',
  handler(updateKraQprLineItemReviewScoreController),
);
iAspireRouter.post(
  '/updateQprItemReviewScore',
  handler(updateQprLineItemReviewScoreController),
);
iAspireRouter.post('/updateFeedback', handler(updateFeedbackController));
iAspireRouter.post('/updateTotalScore', handler(updateTotalScoreController));
iAspireRouter.post(
  '/updateaAdditionalScore',
  handler(updateAdditionalScoreController),
);
iAspireRouter.post('/reqforreopen', handler(requestReOpenController));
iAspireRouter.post(
  '/getreopenreqlist',
  validateRequestBody(getReopenReqListSchema),
  handler(getReopenReqListController),
);
iAspireRouter.get('/getreopenreqtype', handler(getReopenReqTypeController));
iAspireRouter.post(
  '/aprrejreopenreq',
  validateRequestBody(aprRejeopenreqSchema),
  handler(aprRejReopenReqController),
);
iAspireRouter.get('/getQuarterList', handler(getQuarterListController));
iAspireRouter.post(
  '/folderpath',
  validateRequestBody(getiAspireFolderPathSchema),
  handler(getiAspireFolderPath),
);
iAspireRouter.post(
  '/insertqprquarterlist',
  handler(insertQPRQuarterUserController),
);
iAspireRouter.post(
  '/scorecardreview',
  handler(getScoreCardReviewDataController),
);
iAspireRouter.post('/viewscorecard', handler(getViewScoreCardController));
iAspireRouter.post('/userscorerate', handler(getUserScoreRateContoller));
iAspireRouter.get(
  '/getsubordinate/:empCode',
  handler(getSubordinateListController),
);
// My Squad Goals end
iAspireRouter.get(
  '/getcomments/:appraisalId',
  handler(getAllCommentsController),
);

iAspireRouter.post('/getpbempReport', handler(getPBEmpReportController));
iAspireRouter.post(
  '/updateclosingrange',
  handler(insertClosingDateRangeController),
);
iAspireRouter.post('/getclosingrange', handler(getClosingDateRangeController));
iAspireRouter.post('/movetofinance', handler(updateFinanceStsController));
iAspireRouter.get(
  '/getFilterforPBReport',
  handler(getFilterforPBReportController),
);
iAspireRouter.post('/getpbfinReport', handler(getPBFinReportController));
iAspireRouter.post('/getmasterdata', handler(getMasterDataController));
iAspireRouter.post('/updateempsts', handler(updateEmpStsController));
iAspireRouter.post('/updatepbnote', handler(updatePBNoteController));
iAspireRouter.post('/updatepbpaid', handler(updateEmpPaidController));
iAspireRouter.post('/getaddscore', handler(getAddScoreController));
iAspireRouter.post('/getrole', handler(getRoleAcrController));
iAspireRouter.get('/triggermail', handler(triggerRemainderMailController));

iAspireRouter.post('/updatehold', handler(updateHoldController));
iAspireRouter.post('/updateUnhold', handler(updateUnHoldController));

// Appraisal Form
iAspireRouter.get('/iseligible/:EmpId', handler(checkIsEligibleController));
iAspireRouter.get(
  '/getappempdetails/:EmpId',
  handler(getAppEmpDetailsController),
);
iAspireRouter.get('/getfinyeardropdown/:EmpId', handler(getFinYearController));
iAspireRouter.get(
  '/getqualist/:EmpId/:Year',
  handler(getQuaListforYearController),
);
iAspireRouter.get('/getquestionslist', handler(getQuestionsController));
iAspireRouter.post('/instorupdempdata', handler(InsorUpdEmpDataController));
iAspireRouter.post(
  '/getfinyearkradetails',
  handler(getFinYearKRADetailsController),
);
iAspireRouter.get(
  '/getappstatuslist',
  handler(getAppraisalStatusListController),
);
iAspireRouter.post(
  '/getmanagerevaluationdata',
  handler(getManagerEvaluationDataController),
);
iAspireRouter.get(
  '/getb3designations',
  handler(getB3AboveDesignationsController),
);
iAspireRouter.get(
  '/getb3bandlvl/:userId',
  handler(getB3AboveBandLvlController),
);
iAspireRouter.post(
  '/getempyearlyappdet',
  handler(getEmpYearlyApprisalDetController),
);
iAspireRouter.post(
  '/updappreviewdata',
  handler(updAppraisalReviewDataController),
);
iAspireRouter.get(
  '/checkappmaneligible/:userId',
  handler(checkAppManEvalEligibleController),
);

// Form Assessment Q&A
iAspireRouter.get(
  '/getfilterformassessment',
  handler(getFilterforFormAssessmentController),
);
iAspireRouter.get(
  '/getquestionformassessment',
  handler(getQueforFormAssessmentController),
);
iAspireRouter.post(
  '/getformassessmentdata',
  handler(getFormAssessmentDataController),
);

// Form Assessment Q&A
iAspireRouter.get(
  '/getfilterappformreport',
  handler(getFilterforAppraisalFormReportController),
);
iAspireRouter.post(
  '/getappraisalformreport',
  handler(getAppraisalFormReportController),
);
iAspireRouter.get('/getgift', handler(getgiftController));
iAspireRouter.post('/setgift', handler(setGiftServiceController));
iAspireRouter.post('/getusergift', handler(getUserGiftDetailsController));
iAspireRouter.get('/getexcel', handler(getGiftExcelController));

iAspireRouter.get('/getdoj/:userId', handler(checkIsDOJAvailableController));

// get duheasd, functionalhead dropdown data
iAspireRouter.get('/getduhfuhoptions', handler(getDUHFUHController));
iAspireRouter.post('/updduhfuh', handler(updDUHFUHController));

export default iAspireRouter;
