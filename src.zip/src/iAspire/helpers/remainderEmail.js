import moment from 'moment';
import { emitAction } from '../../modules/activityListener/activityListener.js';
import { getOrInsCurrentQuaterDetails } from '../datalayer/iaspireIntegration.js';

export const remainderEmail = async query => {
  try {
    const currentDate = moment(new Date()).format('YYYY-MM-DD');
    await getOrInsCurrentQuaterDetails(currentDate, 'IS9325');
    const getQuarterDetailsScript = `select * from iaspire.mst_quarters where startdate <= current_date and enddate >= current_date `;
    const quarterDetails = await query(getQuarterDetailsScript);
    const quarterCode = quarterDetails[0].quartercode;
    const goalEndDate = moment(quarterDetails[0].goal_deadline);
    // const reviewEndDate = moment(quarterDetails[0].review_deadline);
    const numberOfDays = goalEndDate.diff(moment(currentDate), 'days');
    const { month, year } = getCurrentMonthAndYear();
    const previousQuarterDetails = await query(
      `SELECT * FROM iaspire.mst_quarters WHERE quartercode != '${quarterCode}' ORDER BY 1 DESC LIMIT 1`,
    );
    const prevQuarterCode = previousQuarterDetails[0].quartercode;
    const prevQrtReviewEndDate = moment(
      previousQuarterDetails[0].review_deadline,
    );
    const getMailTemplatesToSendScript = `select * from iaspire.email_schedule_config esc 
    join public.wms_notifications wn on notificationid  = esc.email_id 
    join iaspire.mst_schedule_type mst on mst.id = esc.schedultype 
    where esc.scheduledtime <= CURRENT_TIMESTAMP and esc.is_active = true ORDER BY 1`;
    const mails = await query(getMailTemplatesToSendScript);
    if (mails.length > 0) {
      mails.forEach(async mail => {
        if (mail.action == 'goal_remainder_kra') {
          const { notificationconfig } = mail;
          const mailData = {
            ...notificationconfig,
            quarterCode,
            month: goalEndDate.format('MMMM'),
            year: goalEndDate.format('YYYY'),
            date: currentDate,
          };
          await emitAction(mailData);
          await updateScheduledTime(query, mail);
        } else if (mail.action == 'goal_approval_waiting') {
          // const condition = `and sts.alias_name in ('GOAL_REJECTED_L2',
          //               'GOAL_REJECTED_L1',
          //               'GOAL_REOPEN_REJECTED',
          //               'GOAL_REOPEN_REQUESTED',
          //               'GOAL_EXPIRED',
          //               'GOAL_APPROVED',
          //               'GOAL_PENDING_L2',
          //               'GOAL_PENDING_L1',
          //               'GOAL_PENDING_EMPLOYEE')`;
          await approvalWaitingMailTrigger(
            query,
            mail,
            // currentDate,
            goalEndDate.format('YYYY-MM-DD'),
            // condition,
            '',
            quarterCode,
          );
          await updateScheduledTime(query, mail);
        } else if (mail.action == 'goal_review') {
          const { notificationconfig } = mail;
          const mailData = {
            ...notificationconfig,
            // quarterCode,
            quarterCode: prevQuarterCode,
            // month,
            // year,
            // date: currentDate,
            // remDays: numberOfDays,
            month: prevQrtReviewEndDate.format('MMMM'),
            year: prevQrtReviewEndDate.format('YYYY'),
            date: prevQrtReviewEndDate.format('DD'),
            remDays: prevQrtReviewEndDate.diff(moment(currentDate), 'days'),
          };
          await emitAction(mailData);
          await updateScheduledTime(query, mail);
        } else if (mail.action == 'goal_review_approval_waiting') {
          const condition = `and sts.alias_name not in ('REVIEW_COMPLETED')`;
          await approvalWaitingMailTrigger(
            query,
            mail,
            // currentDate,
            prevQrtReviewEndDate.format('YYYY-MM-DD'),
            condition,
            // quarterCode,
            prevQuarterCode,
          );
          await updateScheduledTime(query, mail);
        } else if (mail.action == 'goal_setting_remainder') {
          const { notificationconfig } = mail;
          const mailData = {
            ...notificationconfig,
            quarterCode,
            month: goalEndDate.format('MMMM'),
            year: goalEndDate.format('YYYY'),
            date: currentDate,
            goalEndDate: goalEndDate.format('DD'),
            remDays: numberOfDays,
          };
          await emitAction(mailData);
          await updateScheduledTime(query, mail);
        } else if (mail.action == 'dashboard_to_dh') {
          await previousQuarterDuHeadDashboardEmail(
            query,
            currentDate,
            mail,
            // quarterCode,
            prevQuarterCode,
          );
          await updateScheduledTime(query, mail);
        } else if (mail.action == 'goal_review_initiation') {
          const { notificationconfig } = mail;
          const mailData = {
            ...notificationconfig,
            quarterCode: prevQuarterCode,
            month,
            year,
            date: currentDate,
            // lastDate: reviewEndDate.format('YYYY-MM-DD'),
            lastDate: prevQrtReviewEndDate.format('YYYY-MM-DD'),
          };
          await emitAction(mailData);
          await updateScheduledTime(query, mail);
        }
      });
    }
    return 'mail sent successfully';
  } catch (error) {
    return error;
  }
};

export function generateCustomQuarterCode() {
  const currentDate = new Date();
  const month = currentDate.getMonth() + 1; // Month is 0-indexed, so adding 1 to get 1-12
  let quarter;
  // Mapping of month ranges to quarters
  if (month >= 4 && month <= 6) {
    quarter = '1'; // Q1: April, May, June
  } else if (month >= 7 && month <= 9) {
    quarter = '2'; // Q2: July, August, September
  } else if (month >= 10 && month <= 12) {
    quarter = '3'; // Q3: October, November, December
  } else {
    quarter = '4'; // Q4: January, February, March
  }
  const year = currentDate.getFullYear();
  return `Q${quarter}Y${year}`;
}

function getCurrentMonthAndYear() {
  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  const currentDate = new Date();
  // Get the month name based on the current month index
  const month = monthNames[currentDate.getMonth()];
  // Get the year
  const year = currentDate.getFullYear();
  return { month, year };
}

const approvalWaitingMailTrigger = async (
  query,
  mailTemplate,
  currentDate,
  condition,
  quarterCode,
) => {
  try {
    const getSubbordinateScript = `SELECT
        jsonb_build_object( 
        'reportingto', reporting_to,
        'name', (select username from public.wms_user where userid = reporting_to),
        'to', COALESCE((select useremail from public.wms_user where userid = reporting_to),reporting_to || '@integra.co.in'), 
        'users', jsonb_agg(json_data))
   FROM (
       SELECT
           usr.reportingto AS reporting_to,
           jsonb_build_object(
               'userid', usr.userid,
               'name', usr.username,
               'designation', ds.designationdesc,
               'du', itrackdu.duname,
               'bandlevel', bl.bandlevel,
               'quartercode', COALESCE(app.quartercode, '${quarterCode}'),
               'status', COALESCE(sts.status, (
                   SELECT status
                   FROM iaspire.mst_status
                   WHERE alias_name = 'GOAL_PENDING_EMPLOYEE'
               ))
           ) AS json_data
       FROM
           IASPIRE.reporting_hierarchy_view usr
       left JOIN public.mst_deliveryunit itrackdu ON usr.itracks_duid = itrackdu.duid
       LEFT JOIN iaspire.trn_appraisalmapping app ON app.employeecode = usr.userid and app.quartercode = '${quarterCode}'
       left JOIN public.mst_bandlevel bl ON bl.bandlevelid = usr.bandlevelid
       left JOIN public.mst_designation ds ON ds.designationid = usr.designationid
       LEFT JOIN iaspire.mst_status sts ON sts.statusid = app.statusid
       WHERE
           usr.reportingto IN (
               SELECT DISTINCT reportingto
               FROM public.wms_user
               WHERE reportingto IS NOT NULL AND usr.reportingto NOT IN ('IS001','IS002','')
           ) ${condition} 
            AND usr.useractive = true AND usr.ispbeligible = true 
            ${
              mailTemplate.action == 'goal_approval_waiting'
                ? `AND pbtype = 'KRA'`
                : ''
            } 
   ) AS subquery
   GROUP BY
       reporting_to
   ORDER BY
       reporting_to`;
    const { notificationconfig } = mailTemplate;
    const mails = await query(getSubbordinateScript);
    mails.forEach(async data => {
      notificationconfig.to = [
        'nirmala.udayakumar@integra.co.in',
        'gauthaamman.somasundaram@integra.co.in',
      ];
      // notificationconfig.to = [data.jsonb_build_object.to];
      const { name } = data.jsonb_build_object;
      const { users } = data.jsonb_build_object;
      const mailData = {
        ...notificationconfig,
        date: currentDate,
        users,
        name,
      };
      await emitAction(mailData);
    });
    return true;
  } catch (error) {
    return error;
  }
};

const previousQuarterDuHeadDashboardEmail = async (
  query,
  currentDate,
  mailTemplate,
  quarterCode,
) => {
  try {
    const duHeadDashboardScript = `
        WITH HeadCounts AS (
            SELECT
                us.functionalhead,
                usr.useremail,
                md.duname,
                COUNT(us.userid) AS headcount
            FROM
                wms_user us
                JOIN wms_user usr ON usr.userid = us.functionalhead
                LEFT JOIN mst_deliveryunit md ON md.duid = us.itracks_duid
            WHERE
                us.functionalhead IS NOT NULL
            GROUP BY
                md.duname,
                us.functionalhead,
                usr.useremail
        ),
        AppraisalCounts AS (
            SELECT
                us.functionalhead,
                md.duname,
                ta.quartercode,
                COUNT(ta.appraisalid) AS appraisalcount
            FROM
                iaspire.trn_appraisalmapping ta
                JOIN wms_user us ON ta.employeecode = us.userid
                JOIN mst_deliveryunit md ON md.duid = us.itracks_duid
            WHERE
                us.functionalhead IS NOT NULL
                AND ta.statusid = 11 and ta.quarterCode in (
                        select quartercode from iaspire.mst_quarters  where (
                        select startdate - 1 from iaspire.mst_quarters mq
                        where quartercode in (
                        SELECT CONCAT('Q', EXTRACT(QUARTER FROM CURRENT_DATE) - 1, 'Y', EXTRACT(YEAR FROM CURRENT_DATE)))) between
                        startdate and enddate
                )
            GROUP BY
                md.duname,
                us.functionalhead,
                ta.quartercode
                
        )
        SELECT
            jsonb_build_object(
                'functionalhead', COALESCE(hc.functionalhead, ac.functionalhead),
                'name', COALESCE((select username from public.wms_user where userid = hc.functionalhead),
								                (select username from public.wms_user where userid = ac.functionalhead)),
                'to', COALESCE(hc.useremail, hc.functionalhead || '@integra-india.com'),
                'users', jsonb_agg(jsonb_build_object(
                    'duname', COALESCE(hc.duname, ac.duname),
                    'headcount', COALESCE(hc.headcount, 0),
                    'appraisalcount', COALESCE(ac.appraisalcount, 0),
                    'quarterCode', ac.quartercode ,
                    'percentage', CASE
                                     WHEN ac.appraisalcount > 0 THEN ROUND((ac.appraisalcount::numeric / hc.headcount::numeric) * 100)::text
                                     ELSE '0'
                                 END
                ))
            ) AS result
        FROM
            HeadCounts hc
        FULL JOIN
            AppraisalCounts ac ON hc.functionalhead = ac.functionalhead AND hc.duname = ac.duname 
        WHERE hc.functionalhead NOT IN ('IS001','IS002','') OR ac.functionalhead NOT IN ('IS001','IS002','')
        GROUP by
            ac.functionalhead,
            hc.functionalhead, 
            hc.useremail;`;
    const dhMailData = await query(duHeadDashboardScript);
    const { notificationconfig } = mailTemplate;
    dhMailData.forEach(async data => {
      // const { to } = data.result;
      // notificationconfig.to = to;
      notificationconfig.to = [
        'nirmala.udayakumar@integra.co.in',
        'gauthaamman.somasundaram@integra.co.in',
      ];
      const { users } = data.result;
      const { name } = data.result;
      // const mailData = {
      //   ...notificationconfig,
      //   date: currentDate,
      //   users: data.users,
      // };
      const mailData = {
        ...notificationconfig,
        date: currentDate,
        name,
        users,
        quarterCode,
      };
      await emitAction(mailData);
    });
    return true;
  } catch (error) {
    return error;
  }
};

const updateScheduledTime = async (query, mail) => {
  try {
    const { schedule_type, frequency } = mail;
    if (schedule_type == 'yearly') {
      mail.scheduledtime = moment(
        moment(mail.scheduledtime).add(parseInt(frequency), 'years'),
      ).format('YYYY-MM-DD HH:mm:ss.SSS');
    } else if (schedule_type == 'monthly') {
      mail.scheduledtime = moment(
        moment(mail.scheduledtime).add(parseInt(frequency), 'months'),
      ).format('YYYY-MM-DD HH:mm:ss.SSS');
    } else if (schedule_type == 'weekly') {
      mail.scheduledtime = moment(
        moment(mail.scheduledtime).add(parseInt(frequency), 'weeks'),
      ).format('YYYY-MM-DD HH:mm:ss.SSS');
    } else if (schedule_type == 'hourly') {
      mail.scheduledtime = moment(
        moment(mail.scheduledtime).add(parseInt(frequency), 'hours'),
      ).format('YYYY-MM-DD HH:mm:ss.SSS');
    } else if (schedule_type == 'minute') {
      mail.scheduledtime = moment(
        moment(mail.scheduledtime).add(parseInt(frequency), 'minutes'),
      ).format('YYYY-MM-DD HH:mm:ss.SSS');
    }
    const updateEmailScheduleConfigScript = `UPDATE iaspire.email_schedule_config
    SET  scheduledtime = $2, updated_by = $3 WHERE config_id = $1`;
    await query(updateEmailScheduleConfigScript, [
      mail.config_id,
      mail.scheduledtime,
      'IS9325',
    ]);
  } catch (error) {
    console.log('error updating emailscheduler script', error);
  }
};
