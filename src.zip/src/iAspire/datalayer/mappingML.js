import { query } from '../../database/postgres.js';

export const getMLDetails = () => {
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY ml.startdate DESC) AS serial,u.userid,u.username,ml.startdate,ml.enddate,
    ml.created_by,ml.ml_detailid,'action' AS action FROM iaspire.trn_emp_ml_details ml LEFT JOIN public.wms_user u ON 
    u.userid=ml.empcode WHERE ml.isactive=true AND u.useractive=true AND 
    (($1::text IS NULL OR trim(upper(u.userid)) ILIKE '%' || trim(upper($1::text)) || '%') OR
    ($1::text IS NULL OR trim(upper(u.username)) ILIKE '%' || trim(upper($1::text)) || '%'))
    order by ml.startdate DESC`;
  return script;
};

export const getMlId = async empCode => {
  const mlId = await query(
    `SELECT ml_detailid FROM iaspire.trn_emp_ml_details
    WHERE empcode=$1 and isactive = true;`,
    [empCode],
  );
  return mlId[0]?.ml_detailid;
};

export const insertMLMapping = async (
  empcode,
  startDate,
  endDate,
  createdBy,
) => {
  const result = await query(
    `INSERT INTO  iaspire.trn_emp_ml_details (empcode,startdate,enddate,created_by)
	    VALUES($1,$2,$3,$4)`,
    [empcode, startDate, endDate, createdBy],
  );
  return result;
};

export const updateMLMapping = async (
  empcode,
  mlId,
  startDate,
  endDate,
  updatedBy,
) => {
  const result = await query(
    `UPDATE iaspire.trn_emp_ml_details SET startdate=$3,enddate=$4,isactive = TRUE,
      updated_by=$5,updated_time=CURRENT_TIMESTAMP WHERE empcode=$1 and ml_detailid=$2`,
    [empcode, mlId, startDate, endDate, updatedBy],
  );
  return result;
};

export const deleteMLMapping = async (empcode, mlId) => {
  const result = await query(
    `UPDATE iaspire.trn_emp_ml_details SET isactive = FALSE WHERE empcode = $1 and ml_detailid=$2`,
    [empcode, mlId],
  );
  return result;
};

export const getViewMLDetails = async empCode => {
  const result = await query(
    `SELECT app.quartercode AS quarter, s.status AS status,
    CASE WHEN s.status ilike '%pending%' THEN 'pending'
    WHEN s.status ilike '%rejected%' THEN 'rejected'
    ELSE 'completed' 
    END AS statusClass FROM iaspire.trn_appraisalmapping app
    JOIN iaspire.mst_status s ON app.statusid = s.statusid where app.employeecode=$1 and app.ismlentry=true`,
    [empCode],
  );
  return result;
};

export const updateMlEntryFlag = async (appraisalId, isMlEntry, modifiedBy) => {
  const result = await query(
    `UPDATE iaspire.trn_appraisalmapping
      SET ismlentry = $2,
      updated_by = $3,
      updated_time = CURRENT_TIMESTAMP
      WHERE appraisalid = $1;`,
    [appraisalId, isMlEntry, modifiedBy],
  );
  return result;
};

export const checkIsMLEmp = () => {
  const script = `SELECT * FROM iaspire.trn_appraisalmapping where appraisalid = $1 and ismlentry = true;`;
  return script;
};
