export const checkIsEligibleScript = () => {
  const script = `SELECT u.userid,u.pbtype,u.doj,u.serving_notice,
  CASE WHEN UPPER(mapp.appraisalcode) = 'AJUL' AND EXTRACT(YEAR FROM CURRENT_DATE) >= app.effectivefrom THEN true
  ELSE false
  END AS iseligible
  FROM public.wms_user u
  JOIN iaspire.trn_emp_appraisal app ON u.userid = app.employeecode
  JOIN iaspire.mst_emp_appraisal mapp ON mapp.empapp_id = app.empapp_id
  WHERE userid = $1;`;
  return script;
};

export const getAppEmpScript = () => {
  const script = `SELECT u.username,u.userid,u.duid,du.duname,u.bandlevelid,bl.bandlevel,u.designationid,de.designationdesc,
    u.doj,u.pbtype FROM public.wms_user u 
    LEFT JOIN public.org_mst_deliveryunit du ON du.duid = u.duid
    LEFT JOIN public.mst_bandlevel bl ON bl.bandlevelid = u.bandlevelid
    LEFT JOIN public.mst_designation de ON de.designationid = u.designationid
    WHERE u.userid = $1;`;
  return script;
};

export const getFinYearScript = () => {
  const script = `SELECT DISTINCT CONCAT(SUBSTRING(a.quartercode, 4, 4), '-', SUBSTRING(a.quartercode, 4, 4)::integer + 1) AS label,
    SUBSTRING(a.quartercode,4,4) as value FROM iaspire.trn_appraisalmapping a
    JOIN iaspire.mst_quarters mq ON a.quartercode = mq.quartercode 
    WHERE a.employeecode = $1 ORDER BY value DESC;`;
  return script;
};

export const getQuarterListforYearScript = () => {
  const script = `SELECT quartercode, CASE WHEN score IS NULL THEN additionalscore::Float 
  ELSE COALESCE((score + additionalscore)::Float, score) END AS total 
  FROM iaspire.trn_appraisalmapping 
  WHERE employeecode = $1 AND quartercode ILIKE CONCAT('%', $2::text) ORDER BY quartercode`;
  return script;
};

export const getQuestionsScript = () => {
  const script = `SELECT questionid,question FROM iaspire.mst_ry_ques WHERE isactive = true ORDER BY questionid`;
  return script;
};

export const InsertEmpDataScript = () => {
  const script = `INSERT INTO iaspire.trn_yearly_appraisal(
    employee_code, fin_year, appraisal_type, statusid, is_active, created_by, updated_by, actual_score, actual_rating)
    VALUES ($1,$2,$3,$4,$5,$6,$6,$7,$8)
    RETURNING y_appraisal_id;`;
  return script;
};

export const UpdateEmpDataScript = () => {
  const script = `UPDATE iaspire.trn_yearly_appraisal SET statusid = $1, updated_by = $2
    WHERE y_appraisal_id = $3 AND employee_code = $4 AND fin_year = $5 AND is_active = TRUE
    RETURNING y_appraisal_id;`;
  return script;
};

export const InsertQueAnsScript = () => {
  const script = `INSERT INTO iaspire.trn_yearly_appraisal_qa(
    y_appraisal_id, employee_code, questionid, answer, is_active, created_by, updated_by)
    VALUES ($1,$2,$3,$4,$5,$6,$6);`;
  return script;
};

export const UpdateQueAnsScript = () => {
  const script = `UPDATE iaspire.trn_yearly_appraisal_qa SET 
  answer = CASE WHEN $1 = '' THEN answer ELSE $1 END, updated_by = $2 WHERE 
  y_appraisal_id = $3 AND employee_code = $4 AND questionid = $5 AND is_active = TRUE;`;
  return script;
};

export const getQueAnsScript = () => {
  const script = `SELECT * FROM iaspire.trn_yearly_appraisal_qa WHERE y_appraisal_id = $1 AND employee_code = $2 AND is_active = TRUE;`;
  return script;
};
