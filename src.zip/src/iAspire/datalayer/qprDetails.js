// eslint-disable-next-line import/no-extraneous-dependencies
import format from 'pg-format';
import { query, transaction } from '../../database/postgres.js';

const AutoDrivenValue = 'AUTO DRIVEN';

export const getQPRLineitemCount = () => {
  const script = `SELECT COUNT(*) FROM iaspire.trn_qpr_user_lineitem WHERE appraisalid = $1`;
  return script;
};

export const getQPRLineitem = () => {
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY li.lineitemid) AS serial,li.lineitemid,li.templateid,
  te.templatename,li.parameterid,li.userdesc AS parameterdesc,li.measureid,me.measuredesc,li.weightage,
  ul.planned_score AS value,ul.score AS appraiserscore,ul.remarks AS reviewerremarks,pa.calculationid,
  am.appraisalid,am.score,am.additionalscore,am.rating,am.additionalscore_remarks as additionalremarks,
  s.alias_name,'action' AS action,
  CASE WHEN (SELECT count(*) FROM iaspire.trn_qpr_lineitem_validation where lineitemid = li.lineitemid) >= 1 THEN true
  ELSE false
  END::boolean AS isEnableStar,
  -- CASE WHEN li.measureid = 1 THEN false
  -- ELSE true
  -- END::boolean AS hideHistory
  true AS hideHistory, q.enddate
  FROM iaspire.trn_qpr_user_lineitem ul
  LEFT JOIN iaspire.trn_appraisalmapping am ON ul.appraisalid = am.appraisalid
  LEFT JOIN iaspire.trn_qpr_lineitem li ON li.lineitemid = ul.lineitemid
  LEFT JOIN iaspire.mst_qpr_template te ON te.templateid = li.templateid
  LEFT JOIN iaspire.mst_qpr_parameters pa ON pa.parameterid = li.parameterid
  LEFT JOIN iaspire.mst_qpr_measures me ON me.measureid = li.measureid
  LEFT JOIN iaspire.mst_status s ON s.statusid = am.statusid
  LEFT JOIN iaspire.mst_quarters q ON q.quartercode = am.quartercode
  WHERE ul.appraisalid = $1 AND ul.isactive=true ORDER BY li.lineitemid`;
  return script;
};

export const insertQPRLineItem = async (
  AppraisalId,
  TemplateId,
  CreatedBy,
  ProductivityScore,
  CCICCount,
  ICCount,
  AppCount,
  empCode,
  isML,
) => {
  // let score = 0;
  // await transaction(client => {
  //   return new Promise(async (tresolve, treject) => {
  //     try {
  //       let result = '';
  //       const lineitemid = await client.query(
  //         `SELECT lineitemid FROM iaspire.trn_qpr_lineitem where templateid = $1 order by lineitemid;`,
  //         [TemplateId],
  //       );
  //       if (lineitemid.rows.length > 0) {
  //         // const lineItemPromises =
  //         lineitemid?.rows?.map(async data => {
  //           let returnReslt;
  //           let MLValue;
  //           if (!isML) {
  //             returnReslt = await ScoreCalculation(
  //               data.lineitemid,
  //               ProductivityScore,
  //               CCICCount,
  //               ICCount,
  //               AppCount,
  //             );
  //             if (returnReslt.currentScore > 0) {
  //               score = returnReslt.currentScore;
  //             } else {
  //               score = 0;
  //             }
  //           } else {
  //             MLValue = await getMLPreviousQuarterScores(
  //               empCode,
  //               AppraisalId,
  //               data.lineitemid,
  //             );
  //           }
  //           result = await client.query(
  //             `INSERT INTO iaspire.trn_qpr_user_lineitem(appraisalid, lineitemid, score, planned_score, isactive, created_by, created_time)
  //         VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP);`,
  //             [
  //               AppraisalId,
  //               data.lineitemid,
  //               isML ? MLValue[0]?.score : score,
  //               isML ? MLValue[0]?.planned_score : returnReslt?.currentCount,
  //               true,
  //               CreatedBy,
  //             ],
  //           );
  //         });
  //         tresolve(result);
  //         // await Promise.all(lineItemPromises);
  //       }
  //     } catch (error) {
  //       treject(error);
  //     }
  //   });
  // });

  await transaction(async client => {
    const lineitemidRes = await client.query(
      `SELECT lineitemid FROM iaspire.trn_qpr_lineitem WHERE templateid = $1 ORDER BY lineitemid;`,
      [TemplateId],
    );

    if (!lineitemidRes.rows.length) return;

    const insertValues = [];

    for (const row of lineitemidRes.rows) {
      const lineitemId = row.lineitemid;
      let score = 0;
      let plannedScore = 0;

      if (!isML) {
        const result = await ScoreCalculation(
          lineitemId,
          ProductivityScore,
          CCICCount,
          ICCount,
          AppCount,
        );
        score = result?.currentScore || 0;
        plannedScore = result?.currentCount || 0;
      } else {
        const mlValues = await getMLPreviousQuarterScores(
          empCode,
          AppraisalId,
          lineitemId,
        );
        score = mlValues[0]?.score || 0;
        plannedScore = mlValues[0]?.planned_score || 0;
      }

      insertValues.push([
        AppraisalId,
        lineitemId,
        score,
        plannedScore,
        true,
        CreatedBy,
      ]);
    }

    if (insertValues.length) {
      const insertQuery = format(
        `INSERT INTO iaspire.trn_qpr_user_lineitem 
        (appraisalid, lineitemid, score, planned_score, isactive, created_by, created_time)
        VALUES %L`,
        insertValues.map(vals => [...vals, new Date()]),
      );

      await client.query(insertQuery);
    }
  });
};

export const getQPRStatusforQuarter = () => {
  const script = `SELECT s.status AS status, s.alias_name AS aliasName,
  CASE WHEN s.status ilike '%pending%' THEN 'pending'
  WHEN s.status ilike '%rejected%' THEN 'rejected'
  WHEN s.status ilike '%expired%' THEN 'expired'
  WHEN s.status ilike '%reopen%' THEN 'reopen'
  WHEN s.status ilike '%approved%' THEN 'approved'
  ELSE 'completed' 
  END AS statusClass FROM iaspire.trn_appraisalmapping app
  JOIN iaspire.mst_status s ON app.statusid = s.statusid WHERE app.appraisalid = $1`;
  return script;
};

export const getStatusListScript = () => {
  const script = `SELECT DISTINCT app.statusid, s.status FROM iaspire.trn_appraisalmapping app
  LEFT JOIN iaspire.mst_status s ON s.statusid = app.statusid 
  WHERE employeecode = $1`;
  return script;
};

export const getStatusTrackerCurrentScript = () => {
  const script = `SELECT
    am.quartercode AS quarter,
    -- rt.username AS level1,
    -- rth.username AS level2,
    -- rth2.username AS level3,
    -- dh.username AS duhead,
    rt.username AS level1,
    rth.username AS level2,
    rth2.username AS level3,
    dh.username AS duhead,
    (COALESCE(am.score, 0) + COALESCE(am.additionalscore, 0))::float AS finalscore,
    am.statusid,
    s.status,s.status_category as statusclass
    FROM public.wms_user u
    LEFT JOIN public.org_mst_deliveryunit du ON du.duid = u.duid
    -- LEFT JOIN public.wms_user rt ON u.reportingto = rt.userid
    -- LEFT JOIN public.wms_user rth ON rt.reportingto = rth.userid
    -- LEFT JOIN public.wms_user rth2 ON rth.reportingto = rth2.userid
    -- LEFT JOIN public.wms_user dh ON u.duhead = dh.userid
    -- LEFT JOIN public.wms_user fh ON u.functionalhead = fh.userid
    LEFT JOIN iaspire.trn_appraisalmapping am ON am.employeecode = u.userid
    LEFT JOIN iaspire.mst_status s ON am.statusid = s.statusid
    LEFT JOIN iaspire.trn_reviewerdetails rd ON rd.appraisalid = am.appraisalid
    LEFT JOIN public.wms_user rt ON rt.userid = rd.reviewer1
    LEFT JOIN public.wms_user rth ON rth.userid = rd.reviewer2
    LEFT JOIN public.wms_user rth2 ON rth2.userid = rth.reportingto
    LEFT JOIN public.wms_user dh ON dh.userid = rd.duhead
    LEFT JOIN public.wms_user fh ON fh.userid = rd.functionalhead
    WHERE u.useractive = true AND am.isactive = true AND s.isactive = true AND du.isactive = true AND
      u.userid = $3 AND (am.quartercode = COALESCE($1, am.quartercode)) 
      AND ($2::int IS NULL OR am.statusid = $2::int) ORDER BY am.quartercode desc;`;
  return script;
};
export const getStatusTrackerRejectionScript = () => {
  const script = `SELECT
      am.quartercode AS quarter,
      rt.username AS level1,
      rth.username AS level2,
      rth2.username AS level3,
      dh.username AS duhead,
      (COALESCE(am.score, 0) + COALESCE(am.additionalscore, 0))::float AS finalscore,
      am.statusid,
    am.rejection_remarks,
    am.updated_by,
    am.updated_time,
    am.appraisaltype,
      s.status
    FROM public.wms_user u
    LEFT JOIN public.org_mst_deliveryunit du ON du.duid = u.duid
    LEFT JOIN public.wms_user rt ON u.reportingto = rt.userid
    LEFT JOIN public.wms_user rth ON rt.reportingto = rth.userid
    LEFT JOIN public.wms_user rth2 ON rth.reportingto = rth2.userid
    LEFT JOIN public.wms_user dh ON u.duhead = dh.userid
    LEFT JOIN public.wms_user fh ON u.functionalhead = fh.userid
    LEFT JOIN iaspire.trn_appraisalmapping am ON am.employeecode = u.userid
    LEFT JOIN iaspire.mst_status s ON am.statusid = s.statusid
    WHERE 
      u.useractive = true 
      AND am.isactive = true 
      AND s.isactive = true 
      AND du.isactive = true 
      AND (am.quartercode = COALESCE($1, am.quartercode)) 
      AND s.status_category = $2
      AND s.alias_name not in ('GOAL_REOPEN_REJECTED','REVIEW_REOPEN_REJECTED')
      AND u.userid = $3  ORDER BY am.quartercode desc`;
  return script;
};

export const getLineItemRatingScript = () => {
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY lv.value1) AS serial,lv.lineitemid,lv.validationid,
  v.validationtype,lv.value1,lv.value2,lv.score,UPPER(me.measuredesc) as measuredesc,
  false AS isSelected
  FROM iaspire.trn_qpr_lineitem_validation lv
  LEFT JOIN iaspire.mst_qpr_validationtypes v ON v.validationid = lv.validationid
  LEFT JOIN iaspire.trn_qpr_lineitem li ON li.lineitemid = lv.lineitemid
  LEFT JOIN iaspire.mst_qpr_measures me ON me.measureid = li.measureid
  where lv.lineitemid = $1 order by lv.value1,lv.score`;
  return script;
};

export const getNewProductivityScript = () => {
  const script = `SELECT COALESCE(avg(score), 0) AS score FROM iproductivity.Productivity_Trans PT
  WHERE PT.empid = $1 AND PT.created_date BETWEEN $2 AND $3`;
  return script;
};

export const getCCICCountScript = () => {
  const script = `SELECT iquality.get_feedbackcount_for_iaspire($1,$2,$3)`;
  return script;
};

const evaluateCondition = (score, validation, value) => {
  switch (validation) {
    case 'Less than':
      return score < value;
    case 'Greater than':
      return score > value;
    case 'Equal to':
      return score === value;
    case 'Greater than or Equal to':
      return score >= value;
    case 'Less than or Equal to':
      return score <= value;
    default:
      return false; // Handle invalid validation symbols
  }
};

const ScoreCalculation = async (
  lineitemid,
  ProductivityScore,
  CCICCount,
  ICCount,
  AppCount,
) => {
  let score = null;
  let currentScore = 0;
  const calculationid = await query(
    `SELECT pa.calculationid,lv.validationid,vt.validationtype,lv.value1,lv.value2,lv.score,li.measureid,me.measuredesc 
      FROM iaspire.trn_qpr_lineitem li
      LEFT JOIN iaspire.mst_qpr_parameters pa ON li.parameterid = pa.parameterid
      LEFT JOIN iaspire.trn_qpr_lineitem_validation lv ON lv.lineitemid = li.lineitemid
      LEFT JOIN iaspire.mst_qpr_validationtypes vt ON vt.validationid = lv.validationid
      LEFT JOIN iaspire.mst_qpr_measures me ON me.measureid = li.measureid
      where li.lineitemid = $1 order by lv.value1,lv.value2,lv.score desc;`,
    [lineitemid],
  );
  if (calculationid[0].measuredesc.trim().toUpperCase() === AutoDrivenValue) {
    if (calculationid[0].calculationid === 1) {
      score = ProductivityScore;
    } else if (calculationid[0].calculationid === 2) {
      score = CCICCount;
    } else if (calculationid[0].calculationid === 3) {
      score = ICCount;
    } else if (calculationid[0].calculationid === 4) {
      score = AppCount;
    }

    calculationid.map(async item => {
      if (item.value1 !== 0 && item.value2 != 0) {
        if (
          parseInt(`${item.value1}`) <= parseInt(`${score}`) &&
          parseInt(`${score}`) <= parseInt(`${item.value2}`)
        ) {
          currentScore = item.score;
        }
      } else {
        // eslint-disable-next-line no-lonely-if
        if (evaluateCondition(score, item.validationtype, item.value1)) {
          currentScore = item.score;
        }
      }
    });
  }
  return { currentScore, currentCount: score };
};

export const updateQPRLineItem = async (
  AppraisalId,
  CreatedBy,
  ProductivityScore,
  CCICCount,
  ICCount,
  AppCount,
  empCode,
  isML,
) => {
  let score;
  let returnReslt;
  const lineitemid = await query(
    `SELECT lineitemid FROM iaspire.trn_qpr_user_lineitem where appraisalid = $1 order by lineitemid;`,
    [AppraisalId],
  );
  if (lineitemid.length > 0) {
    // const lineItemPromises =
    lineitemid.map(async data => {
      const measureDesc = await checkMeasureDesc(data.lineitemid, AppraisalId);
      if (measureDesc.trim().toUpperCase() === AutoDrivenValue) {
        if (!isML) {
          returnReslt = await ScoreCalculation(
            data.lineitemid,
            ProductivityScore,
            CCICCount,
            ICCount,
            AppCount,
          );
          if (returnReslt.currentScore > 0) {
            score = returnReslt.currentScore;
          } else {
            score = 0;
          }
        } else {
          returnReslt = await getMLPreviousQuarterScores(
            empCode,
            AppraisalId,
            data.lineitemid,
          );
          score = returnReslt[0]?.score;
          returnReslt.currentCount = returnReslt[0]?.planned_score;
        }
      } else if (measureDesc.trim().toUpperCase() !== AutoDrivenValue) {
        const scoreandplans = await getManualScore(
          data.lineitemid,
          AppraisalId,
          2,
        );
        score = scoreandplans[0].score;
        returnReslt.currentCount = scoreandplans[0].planned_score;
      }
      if (returnReslt) {
        await query(
          `UPDATE iaspire.trn_qpr_user_lineitem SET score = COALESCE($1,score), planned_score = COALESCE($2,planned_score), 
            updated_by = $3,
            updated_time = CURRENT_TIMESTAMP WHERE appraisalid = $4 and lineitemid = $5;`,
          [
            // isML ? returnReslt[0]?.score : score,
            // isML ? returnReslt[0]?.planned_score : returnReslt?.currentCount,
            score,
            returnReslt?.currentCount,
            CreatedBy,
            AppraisalId,
            data.lineitemid,
          ],
        );
      }
    });
    // await Promise.all(lineItemPromises);
  }
};

const checkMeasureDesc = async (lineitemid, appraisalId) => {
  const measureDesc = await query(
    `select me.measuredesc from iaspire.trn_qpr_user_lineitem ul 
    LEFT JOIN iaspire.trn_qpr_lineitem li ON li.lineitemid = ul.lineitemid
    LEFT JOIN iaspire.mst_qpr_measures me ON me.measureid = li.measureid
    where ul.lineitemid = $1 and ul.appraisalid = $2`,
    [lineitemid, appraisalId],
  );
  return measureDesc[0].measuredesc;
};

const getManualScore = async (lineitemid, appraisalId, measureId) => {
  const scoreandplannedScore = await query(
    `select ul.score,ul.planned_score from iaspire.trn_qpr_user_lineitem ul 
    LEFT JOIN iaspire.trn_qpr_lineitem li ON li.lineitemid = ul.lineitemid
    LEFT JOIN iaspire.mst_qpr_measures me ON me.measureid = li.measureid
    where ul.lineitemid = $1 and ul.appraisalid = $2 and me.measureid = $3`,
    [lineitemid, appraisalId, measureId],
  );
  return scoreandplannedScore;
};

export const getReportingEmail = async EmployeeCode => {
  const reportingto = await query(
    `SELECT dh.username,dh.useremail FROM public.wms_user u LEFT JOIN public.wms_user dh ON dh.userid = u.reportingto
    WHERE u.userid = $1;`,
    [EmployeeCode],
  );
  return reportingto;
};

export async function modifyNotificationConfigFromEmails(
  mailConfig,
  mailIDinTO,
  mailIDinCC,
) {
  // Combine all email IDs
  // const allEmails = [...reportingtoMail, ...mailIDinTO, ...mailIDinCC];

  // Deduplicate and filter out null values
  mailConfig.to = [...new Set(mailIDinTO)].filter(
    email => email && email !== 'null',
  );
  mailConfig.cc = [...new Set([...mailIDinCC])].filter(
    email => email && email !== 'null',
  );

  // Remove email IDs that exist in both to and cc arrays
  mailConfig.cc = mailConfig.cc.filter(email => !mailConfig.to.includes(email));
  return mailConfig;
}

export const getMonthandYearforLatestQuarter = async () => {
  const monthandYear = await query(
    `SELECT quartercode AS quarter, TO_CHAR(startdate , 'DD') AS date, TO_CHAR(startdate, 'Mon') AS month,TO_CHAR(startdate, 'YYYY') AS year
    FROM iaspire.mst_quarters WHERE isactive = true ORDER BY startdate DESC LIMIT 1;`,
  );
  return monthandYear;
};

export const getMonthandYearforReviewStartDateQuarter = async () => {
  const monthandYear = await query(
    `SELECT quartercode AS quarter, TO_CHAR(enddate + INTERVAL '1 day', 'DD') AS date, TO_CHAR(enddate + INTERVAL '1 day', 'Mon') AS month,TO_CHAR(enddate, 'YYYY') AS year
FROM iaspire.mst_quarters WHERE isactive = true ORDER BY enddate DESC LIMIT 1;`,
  );
  return monthandYear;
};
export const getGoalEndDateForQuarter = async () => {
  const monthandYear = await query(
    `SELECT quartercode AS quarter, TO_CHAR(goal_deadline, 'DD') AS date, TO_CHAR(goal_deadline, 'Mon') AS month,TO_CHAR(goal_deadline, 'YYYY') AS year
FROM iaspire.mst_quarters WHERE isactive = true ORDER BY goal_deadline DESC LIMIT 1;`,
  );
  return monthandYear;
};

export const getQPRAdditionalScoreforQuarter = () => {
  const script = `SELECT am.additionalscore AS addscr,am.additionalscore_remarks AS remarks
  FROM iaspire.trn_appraisalmapping am WHERE am.appraisalid = $1`;
  return script;
};

export const getRatingforQuarter = () => {
  const script = `select rc.groupid,rv.minvalue,rv.maxvalue,rv.rating from public.wms_user u
  JOIN public.mst_deliveryunit du ON u.itracks_duid = du.duid
  JOIN iaspire.trn_rating_combination rc ON rc.duid = du.duid AND rc.designationid = u.designationid AND rc.bandlevelid = u.bandlevelid
  JOIN iaspire.mst_rating_value rv ON rv.groupid = rc.groupid
  where u.userid = $1`;
  return script;
};

export const getScoreusingAppraisalId = () => {
  const script = `SELECT app.employeecode, SUM(qu.score) AS score FROM iaspire.trn_qpr_user_lineitem qu
    LEFT JOIN iaspire.trn_appraisalmapping app ON app.appraisalid = qu.appraisalid
    WHERE qu.appraisalid = $1 GROUP BY app.employeecode`;
  return script;
};

export const updateScoreandRating = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping SET score = $2,rating = $3 WHERE appraisalid = $1`;
  return script;
};

export const getPBSummaryforQPR = () => {
  const script = `WITH L1_CTE AS (
    SELECT apphis.score AS L1
    FROM iaspire.trn_appraisalmapping_status_history apphis
    WHERE apphis.new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2')
      AND apphis.appraisalid = $1 ORDER BY apphis.updated_time DESC LIMIT 1
),
L2_CTE AS (
    SELECT CASE
        WHEN (apphis.old_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2') AND
              apphis.new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_L2')) THEN 0
        WHEN apphis.old_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2') THEN CAST(apphis.score AS double precision)
        WHEN apphis.new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_DUH') THEN CAST(apphis.score AS double precision)
        ELSE CAST(apphis.score AS double precision) END AS l2 FROM iaspire.trn_appraisalmapping_status_history apphis
    WHERE apphis.appraisalid = $1 ORDER BY apphis.updated_time DESC LIMIT 1
),
final_CTE AS (
    SELECT appmap.additionalscore AS additionalscore,
      (COALESCE(appmap.score, 0) + COALESCE(appmap.additionalscore, 0)) AS finalbpscore,
      COALESCE(u.username)||' ('|| COALESCE(appmap.updated_by)||')' AS lastchangedoneby
      --      appmap.updated_by AS lastchangedoneby
    FROM iaspire.trn_appraisalmapping appmap 
    LEFT JOIN public.wms_user u ON u.userid = appmap.updated_by WHERE appmap.appraisalid = $1
)
SELECT
    L1_CTE.L1,
    L2_CTE.l2,
    final_CTE.additionalscore,
    final_CTE.finalbpscore,
    final_CTE.lastchangedoneby
FROM L1_CTE, L2_CTE, final_CTE;`;
  return script;
};

export const getGoalEndDateForEmployee = async appraisalId => {
  const monthandYear = await query(
    `SELECT quartercode AS quarter, TO_CHAR(goal_deadline, 'DD') AS date, TO_CHAR(goal_deadline, 'Mon') AS month,TO_CHAR(goal_deadline, 'YYYY') AS year
      FROM iaspire.trn_appraisalmapping WHERE appraisalid = ${appraisalId};`,
  );
  return monthandYear;
};

export const getMLPreviousQuarterScores = async (
  empCode,
  AppraisalId,
  lineitemid,
) => {
  const MLScores = await query(
    `SELECT am.employeecode, am.templateid, qpr.parameterid, qpr.measureid, li.lineitemid, li.score, li.planned_score
      FROM iaspire.trn_appraisalmapping am
      JOIN iaspire.trn_qpr_lineitem qpr ON qpr.templateid = am.templateid AND qpr.lineitemid = $3
      JOIN iaspire.mst_qpr_measures me ON me.measureid = qpr.measureid AND measuredesc = 'Auto Driven'
      LEFT JOIN iaspire.trn_qpr_user_lineitem li ON li.appraisalid = am.appraisalid AND 
        li.lineitemid = qpr.lineitemid AND li.isactive = true-- AND li.planned_score IS NOT NULL
      WHERE am.appraisalid = (select appraisalid from iaspire.trn_appraisalmapping 
      where employeecode = $1 and appraisalid <> $2 order by 1 desc limit 1) and am.isactive = true;`,
    [empCode, AppraisalId, lineitemid],
  );
  return MLScores;
};
