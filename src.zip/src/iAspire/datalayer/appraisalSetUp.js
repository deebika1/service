import { query } from '../../database/postgres.js';

export const getAppraisalYearScript = () => {
  const script = `SELECT
                  CASE
                  WHEN EXTRACT(MONTH FROM doj) BETWEEN 1 AND 5 THEN EXTRACT(YEAR FROM doj) + 1
                  WHEN EXTRACT(MONTH FROM doj) = 6 AND EXTRACT(DAY FROM doj) <= 15 THEN EXTRACT(YEAR FROM doj) + 1
                  ELSE EXTRACT(YEAR FROM doj) + 2
                  END AS effyear
                  FROM wms_user
                  WHERE userid = $1;`;
  return script;
};

// Function to check if the Appraisal record exists
const checkAppRecordExists = async empCode => {
  const existsResult = await query(
    `SELECT 1 FROM iaspire.trn_emp_appraisal
      WHERE trim(upper(employeecode)) = trim(upper($1)) AND isactive = TRUE`,
    [empCode],
  );
  return existsResult?.length !== 0;
};

export const insOrUpdateAppraisalEntry = async (
  empCode,
  appTypeId,
  effyear,
  modifiedBy,
) => {
  const existingRecord = await checkAppRecordExists(empCode);

  if (!existingRecord) {
    const empAppId = await query(
      `INSERT INTO iaspire.trn_emp_appraisal(employeecode, empapp_id, effectivefrom, created_by)
        VALUES ($1, $2, $3, $4) RETURNING empappraisal_id;`,
      [empCode, appTypeId, effyear, modifiedBy],
    );
    const YTD_Id = await query(
      `SELECT empapp_id FROM iaspire.mst_emp_appraisal WHERE appraisalcode = 'YTD'`,
    );
    await query(
      `INSERT INTO iaspire.trn_emp_appraisal_history(empappraisal_id, employeecode, old_empapp_id, new_empapp_id, new_effectivefrom, created_by, changed_by, created_time, change_time, isactive)
        VALUES ($1, $2, $6, $3, $4, $5, $5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, TRUE);`,
      [
        empAppId[0]?.empappraisal_id,
        empCode,
        appTypeId,
        effyear,
        modifiedBy,
        YTD_Id[0]?.empapp_id,
      ],
    );
  } else {
    await query(
      `UPDATE iaspire.trn_emp_appraisal
        SET
        empapp_id = $2,
        effectivefrom = $3,
        isactive = TRUE,
        updated_by = $4,
        updated_time = CURRENT_TIMESTAMP
        WHERE trim(upper(employeecode)) = trim(upper($1));`,
      [empCode, appTypeId, effyear, modifiedBy],
    );
  }
  return true;
};

export const getEmpAppraisalList = (duId, bandId, desigId, appId) => {
  let condition1 = '';
  let condition2 = '';
  let condition3 = '';
  let condition4 = '';
  // if (searchText === '') {
  if (duId !== null && duId.length > 0) {
    condition1 = `AND (users.itracks_duid = ANY(ARRAY[${duId}]::bigint[]))`;
  }
  if (bandId !== '' && bandId.length > 0) {
    condition2 = `AND (users.bandlevelid = ANY(ARRAY[${bandId.map(
      value => `'${value}'`,
    )}]::bigint[]))`;
  }
  if (desigId !== '' && desigId.length > 0) {
    condition3 = `AND (users.designationid = ANY(ARRAY[${desigId.map(
      value => `'${value}'`,
    )}]::bigint[]))`;
  }
  if (appId !== '' && appId.length > 0) {
    condition4 = `AND (mstapp.empapp_id = ANY(ARRAY[${appId.map(
      value => `'${value}'`,
    )}]::bigint[]))`;
  }

  const script = `SELECT 
        ROW_NUMBER() OVER (ORDER BY itrackdu.duname) AS serial,
        empapp.empappraisal_id,
        itrackdu.duname,
        users.username, 
        users.userid, 
        CASE WHEN L1det.userid = users.userid THEN '' ELSE L1det.username || ' (' || users.reportingto || ')' END as l1manager,
        users.doj,
        band.bandlevel,
        desig.designationdesc,
        COALESCE(mstapp.appraisaltype, (SELECT appraisaltype FROM iaspire.mst_emp_appraisal WHERE appraisalcode = 'YTD')) AS appraisaltype,
        COALESCE(mstapp.empapp_id, (SELECT empapp_id FROM iaspire.mst_emp_appraisal WHERE appraisalcode = 'YTD')) as appraisaltypeid,
        COALESCE(empapp.effectivefrom, EXTRACT(YEAR FROM CURRENT_DATE)) AS yearid,
        COALESCE(empapp.effectivefrom, EXTRACT(YEAR FROM CURRENT_DATE)) AS year,
        'action' as action,
        false AS isedit,
        false AS hideedit,
        CASE WHEN NOT EXISTS(select 1 from iaspire.trn_emp_appraisal_history 
          where empappraisal_id=empapp.empappraisal_id) THEN TRUE
        END AS hidehistory
        FROM 
          public.wms_user users
        LEFT JOIN 
          public.mst_deliveryunit itrackdu ON users.itracks_duid = itrackdu.duid
        LEFT JOIN 
          public.wms_user L1det ON L1det.userid = users.reportingto
        LEFT JOIN
          public.mst_bandlevel band ON band.bandlevelid = users.bandlevelid
        LEFT JOIN
          public.mst_designation desig ON desig.designationid = users.designationid
        LEFT JOIN
          iaspire.trn_emp_appraisal empapp ON empapp.employeecode = users.userid
        LEFT JOIN
          iaspire.mst_emp_appraisal mstapp ON mstapp.empapp_id = empapp.empapp_id
        WHERE 
          users.useractive = TRUE and (($1::text IS NULL OR trim(upper(users.userid)) ILIKE '%' || trim(upper($1)) || '%') or
          ($1::text IS NULL OR trim(upper(users.username)) ILIKE '%' || trim(upper($1)) || '%')) ${condition1} ${condition2} ${condition3} ${condition4};`;
  return script;
};

export const getOverAllEmpAppraisalList = () => {
  const script = `SELECT 
        ROW_NUMBER() OVER (ORDER BY itrackdu.duname) AS serial,
        empapp.empappraisal_id,
        itrackdu.duname,
        users.username, 
        users.userid, 
        CASE WHEN L1det.userid = users.userid THEN '' ELSE L1det.username || ' (' || users.reportingto || ')' END as l1manager,
        users.doj,
        band.bandlevel,
        desig.designationdesc,
        mstapp.appraisaltype,
        mstapp.empapp_id as appraisaltypeid,
        empapp.effectivefrom,
        'action' as action,
        false AS isedit,
        false AS hideedit,
        CASE WHEN NOT EXISTS(select 1 from iaspire.trn_emp_appraisal_history 
          where empappraisal_id=empapp.empappraisal_id) THEN TRUE
        END AS hidehistory
        FROM 
          public.wms_user users
        LEFT JOIN 
          public.org_mst_deliveryunit wmsdu ON wmsdu.duid = users.duid
        LEFT JOIN 
          public.mst_deliveryunit itrackdu ON wmsdu.itrackduid = itrackdu.duid
        LEFT JOIN 
          public.wms_user L1det ON L1det.userid = users.reportingto
        LEFT JOIN
          public.mst_bandlevel band ON band.bandlevelid = users.bandlevelid
        LEFT JOIN
          public.mst_designation desig ON desig.designationid = users.designationid
        LEFT JOIN
          iaspire.trn_emp_appraisal empapp ON empapp.employeecode = users.userid
        LEFT JOIN
          iaspire.mst_emp_appraisal mstapp ON mstapp.empapp_id = empapp.empapp_id
        WHERE 
          users.useractive = TRUE and  (($1::text IS NULL OR trim(upper(users.userid)) ILIKE '%' || trim(upper($1)) || '%') or
          ($1::text IS NULL OR trim(upper(users.username)) ILIKE '%' || trim(upper($1)) || '%'));`;
  return script;
};

export const updateEmpAppraisalDet = () => {
  const script = `UPDATE iaspire.trn_emp_appraisal
        SET empapp_id = $2,
        effectivefrom = $3,
        updated_by = $4,
        updated_time = CURRENT_TIMESTAMP
        WHERE empappraisal_id = $1;`;

  return script;
};

export const getEmpAppraisalHistoryScript = () => {
  const script = `SELECT TO_CHAR(change_time, 'DD') AS date,
  STRING_AGG(TO_CHAR(change_time, 'Mon') || ' ' || TO_CHAR(change_time, 'YYYY'),'') AS month,
  jsonb_agg(
    jsonb_build_object(
      'by', (select username from public.wms_user where userid = trn.changed_by),
      'from', (mstold.appraisaltype || ' ' || COALESCE(trn.effectivefrom, EXTRACT(YEAR FROM CURRENT_DATE))),
	  'to', (mstnew.appraisaltype || ' ' || trn.new_effectivefrom)
    )
  ) AS history 
  FROM iaspire.trn_emp_appraisal_history trn 
  JOIN iaspire.mst_emp_appraisal mstold ON mstold.empapp_id = trn.old_empapp_id
  JOIN iaspire.mst_emp_appraisal mstnew ON mstnew.empapp_id = trn.new_empapp_id
  WHERE trn.empappraisal_id = $1
  GROUP BY change_time,changed_by;`;
  return script;
};

export const getAppraisalTypeScript = () => {
  const script = `SELECT DISTINCT empapp_id AS value, appraisaltype AS label, false AS isSelected, CASE WHEN appraisaltype = 'YTD' 
  THEN true ELSE false END AS isHide FROM iaspire.mst_emp_appraisal WHERE isactive=TRUE ORDER BY appraisaltype DESC`;
  return script;
};

export const getBandLevelListScript = () => {
  const script = `SELECT DISTINCT bandlevelid AS id,bandlevel AS name, false AS isSelected FROM public.mst_bandlevel
  WHERE isactive = TRUE`;
  return script;
};

export const getDesignationListScript = () => {
  const script = `SELECT DISTINCT designationid AS id,designationdesc AS name, false AS isSelected FROM public.mst_designation
  WHERE isactive = TRUE ORDER BY designationdesc`;
  return script;
};
