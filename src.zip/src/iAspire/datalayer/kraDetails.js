import { query } from '../../database/postgres.js';

export const getUserDeatilsForKraGoals = () => {
  const script = `SELECT 
  users.userid, 
  users.username, 
  itrackdu.duname,
  users.useremail,
  appmap.quartercode,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE L1det.username || '(' || L1det.userid || ')' END as l1manager,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE L1det.userid END as l1manageruserid,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE L1det.useremail END as l1email,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE L2det.username || '(' ||  L2det.userid || ')' END as l2manager,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE L2det.userid END as l2manageruserid,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE L2det.useremail END as l2email,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE  COALESCE(duhead.username, duheadu.username)||'('||
  COALESCE(duhead.userid, duheadu.userid)||')'  END as dhmanager,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE COALESCE(duhead.userid, duheadu.userid) END as dhmanageruserid,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE COALESCE(duhead.useremail, duheadu.useremail) END as duheademail,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE COALESCE(fuhead.username, fuheadu.username)||'('||
  COALESCE(fuhead.userid, fuheadu.userid)||')' END as fhmanager,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE COALESCE(fuhead.userid, fuheadu.userid) END as fhmanageruserid,
  CASE WHEN L1det.userid = users.userid THEN '' ELSE COALESCE(fuhead.useremail, fuheadu.useremail) END as fuheademail,
  appmap.ismlentry
  FROM
      iaspire.trn_appraisalmapping appmap
  LEFT JOIN
      public.wms_user users ON users.userid = appmap.employeecode
  LEFT JOIN 
      public.mst_deliveryunit itrackdu ON users.itracks_duid = itrackdu.duid
  LEFT JOIN
      iaspire.trn_reviewerdetails revdet ON revdet.appraisalid = appmap.appraisalid
  LEFT JOIN 
      public.wms_user L1det ON L1det.userid = revdet.reviewer1
  LEFT JOIN
      public.wms_user L2det ON L2det.userid = revdet.reviewer2
  LEFT JOIN
      public.wms_user duhead ON duhead.userid = revdet.duhead
  LEFT JOIN
      public.wms_user fuhead ON fuhead.userid = revdet.functionalhead      
  LEFT JOIN
      public.wms_user duheadu ON duheadu.userid = users.duhead
LEFT JOIN
      public.wms_user fuheadu ON fuheadu.userid = users.functionalhead
  WHERE
    appmap.appraisalid = $1
    AND appmap.isactive = TRUE;`;
  return script;
};

export const getKraGoals = () => {
  const kraGoalsScript = `SELECT ROW_NUMBER() OVER (ORDER BY item.seq_no) AS serial, app.appraisalid, app.quartercode,
  app.additionalscore, app.additionalscore_remarks as additionalremarks, app.rating, app.max_attachment_key, app.ismlentry,
  sts.status, sts.status_category as statuscategory,  item.versionid,item.kra_itemid,item.item, item.measure, item.weightage, 
  item.selfscore,item.item as goals, item.actions, item.reviwerscore,item.created_by, item.kra_itemkey, sts.alias_name, item.appraisercomment as reviewercomment,
  CASE WHEN (SELECT count(*) from iaspire.trn_kra_attachment where kra_itemkey = item.kra_itemkey) >= 1  THEN true
  ELSE false
  END AS hasattachment, mq.enddate as enddate
  FROM iaspire.trn_appraisalmapping app
  LEFT JOIN iaspire.trn_kra_lineitem item ON app.appraisalid = item.appraisalid
  JOIN iaspire.mst_status sts ON sts.statusid = app.statusid
  JOIN iaspire.mst_quarters mq ON mq.quartercode = app.quartercode
  WHERE app.employeecode = $1
    AND app.quartercode = $2
    AND app.isactive = TRUE
    AND item.isactive = TRUE
    AND item.versionid in ( select max(item.versionid)
  FROM iaspire.trn_appraisalmapping app
  LEFT JOIN iaspire.trn_kra_lineitem item ON app.appraisalid = item.appraisalid
  JOIN iaspire.mst_status sts ON sts.statusid = app.statusid
  WHERE app.employeecode = $1
    AND app.quartercode = $2
    AND app.isactive = TRUE
    AND item.isactive = TRUE)`;
  return kraGoalsScript;
};

export const getKraGoalsWithVersion = () => {
  const kraGoalsScript = `SELECT ROW_NUMBER() OVER (ORDER BY item.seq_no) AS serial, app.appraisalid,
  app.additionalscore, app.additionalscore_remarks as additionalremarks, app.rating, app.max_attachment_key,
  sts.status, sts.status_category as statuscategory,  item.versionid,item.kra_itemid,item.item, item.measure, item.weightage, 
  item.selfscore,item.item as goals, item.actions, item.reviwerscore,item.created_by, item.kra_itemkey, sts.alias_name, item.appraisercomment as reviewercomment,
  CASE WHEN (SELECT count(*) from iaspire.trn_kra_attachment where kra_itemkey = item.kra_itemkey) >= 1  THEN true
  ELSE false
  END AS hasattachment
  FROM iaspire.trn_appraisalmapping app
  LEFT JOIN iaspire.trn_kra_lineitem item ON app.appraisalid = item.appraisalid
  JOIN iaspire.mst_status sts ON sts.statusid = app.statusid
  WHERE app.employeecode = $1
    AND app.quartercode = $2
    AND app.isactive = TRUE
    AND item.isactive = TRUE
    AND item.versionid = $3;`;
  return kraGoalsScript;
};

export const getKraVersionListScript = () => {
  const kraGoalsVersionScript = `select distinct CONCAT('VERSION ', versionid) AS version, versionid
  FROM iaspire.trn_kra_lineitem
  WHERE appraisalid = $1 AND isactive = TRUE ORDER BY versionid desc;`;
  return kraGoalsVersionScript;
};

export const getPrevQuarterListScript = () => {
  const prevQuarterListScript = `SELECT distinct Q.quartercode  as quarter, Q.enddate
  FROM iaspire.trn_appraisalmapping a
  JOIN iaspire.trn_kra_lineitem l ON l.appraisalid = a.appraisalid
  LEFT JOIN iaspire.mst_quarters Q ON Q.quartercode = a.quartercode 
  WHERE a.employeecode = $1 AND a.quartercode != $2 ORDER BY Q.enddate DESC limit 1;`;

  return prevQuarterListScript;
};

export const insertPrevQuaterKraLineItemScript = () => {
  const script = `INSERT INTO iaspire.trn_kra_lineitem(appraisalid, item, measure, weightage, created_by, versionid, seq_no, kra_itemkey)
        SELECT 
        unnest($1::bigint[]),
        unnest($2::text[]),
        unnest($3::text[]),
        unnest($4::double precision[]),
        unnest($5::text[]),
        unnest($6::integer[]),
        unnest($7::integer[]),
        unnest($8::text[])`;
  return script;
};

export const getAppraisalId = async (empCode, quarterCode) => {
  const appraisalId = await query(
    `SELECT appraisalid FROM iaspire.trn_appraisalmapping
    WHERE trim(upper(employeecode)) = trim(upper($1)) AND quartercode = $2 AND isactive = TRUE;`,
    [empCode, quarterCode],
  );
  return appraisalId[0]?.appraisalid;
};

export const insertKraLineItem = async (
  appraisalId,
  lineItem,
  versionId,
  modifiedBy,
) => {
  const { goals, measure, weightage, serial, kra_itemkey } = lineItem;
  const result = await query(
    `INSERT INTO iaspire.trn_kra_lineitem(
        appraisalid, item, measure, weightage, seq_no, created_by, versionid, kra_itemkey)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8);`,
    [
      appraisalId,
      goals,
      measure,
      parseFloat(weightage) || null,
      serial,
      modifiedBy,
      versionId,
      kra_itemkey,
    ],
  );
  return result;
};

// Function to check if the KRA Line item record exists
const checkLineItemExists = async itemId => {
  const existsResult = await query(
    `SELECT 1 FROM iaspire.trn_kra_lineitem
    WHERE kra_itemid = $1;`,
    [itemId],
  );
  return existsResult?.length !== 0;
};

export const updateKraLineItem = async (
  appraisalId,
  versionId,
  lineItem,
  modifiedBy,
) => {
  const { kra_itemid, goals, measure, weightage, serial, kra_itemkey } =
    lineItem;
  let result;
  if (await checkLineItemExists(kra_itemid)) {
    result = await query(
      `UPDATE iaspire.trn_kra_lineitem
	      SET
        item=$3, 
        measure=$4,
        weightage=$5,
        seq_no=$6,
        updated_by=$7,
        isactive = TRUE,
        kra_itemkey = $8,
        updated_time = CURRENT_TIMESTAMP
	      WHERE kra_itemid = $1 AND versionid = $2;`,
      [
        kra_itemid,
        versionId,
        goals,
        measure,
        parseFloat(weightage) || null,
        serial,
        modifiedBy,
        kra_itemkey,
      ],
    );
  } else {
    result = await insertKraLineItem(appraisalId, lineItem, versionId);
  }
  return result;
};

export const deleteKraLineItem = async lineItemId => {
  if (await checkLineItemExists(lineItemId)) {
    await query(
      `DELETE FROM iaspire.trn_kra_lineitem
      WHERE kra_itemid = $1;`,
      [lineItemId],
    );
  }
  return true;
};

export const updateKraGoalsSubmitStatus = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
      SET
      statusid=$2,
      updated_by=$3,
      updated_time = CURRENT_TIMESTAMP
    WHERE appraisalid = $1;`;
  return script;
};

export const getReportingManager = async empCode => {
  const reportingManager = await query(
    `SELECT reportingto FROM public.wms_user WHERE userid = $1;`,
    [empCode],
  );
  return reportingManager[0]?.reportingto;
};

export const updateKraLineItemSelfScoreScript = () => {
  const script = `UPDATE iaspire.trn_kra_lineitem
	      SET
        actions = $2,
        selfscore = $3,
        updated_by=$4
	      WHERE kra_itemid = $1;`;
  return script;
};

export const getQuaterListScript = () => {
  const script = `select * FROM iaspire.mst_quarters
  JOIN public.wms_user us ON us.userid = $1
  WHERE isactive = TRUE
  AND  us.doj <= enddate
  AND ( enddate - us.doj::DATE) >= 15
  ORDER BY startdate DESC;`;
  return script;
};

export const insAttachmentInfoScript = () => {
  const script =
    'INSERT INTO iaspire.trn_kra_attachment(kra_itemkey, attachment_type, filename, attachment, created_by) VALUES ($1, $2, $3, $4, $5)';
  return script;
};

export const getAttachmentInfoScript = () => {
  const script = `SELECT kra_attachmentid, filename, attachment, attachment_type, TO_CHAR(created_time + '5 hours 30 minutes', 'DD Mon YYYY HH:MIam') AS uploadedOn
                    FROM iaspire.trn_kra_attachment
                    WHERE kra_itemkey = $1`;
  return script;
};

export const deleteAttachmentScript = columnName => {
  const script = `DELETE FROM iaspire.trn_kra_attachment WHERE ${columnName} = $1`;
  return script;
};

export const getL1UsersListScript = () => {
  const script = `SELECT  usr.userid,
  itrackdu.duid, 
  usr.designationid,
      usr.bandlevelid,  
      usr.reportingto, usr.doj
  FROM public.wms_user usr
  -- JOIN public.org_mst_deliveryunit wmsdu ON wmsdu.duid = usr.duid
  -- JOIN public.mst_deliveryunit itrackdu ON wmsdu.itrackduid = itrackdu.duid
  JOIN public.mst_deliveryunit itrackdu ON usr.itracks_duid = itrackdu.duid
    WHERE usr.useractive = true and  usr.reportingto = $1 and usr.pbtype = $2`;
  return script;
};

export const getUserFoundInAppraisalMappingScript = () => {
  const script = `select * from iaspire.trn_appraisalmapping app where app.employeecode = $1 and quartercode = $2`;
  return script;
};

export const updateMaxKeyScript = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
      SET
      max_attachment_key=$2,
      updated_by=$3,
      updated_time = CURRENT_TIMESTAMP
    WHERE appraisalid = $1;`;
  return script;
};

export const getOverAllFeedbacks = () => {
  const script = `SELECT
      json_agg(json_build_object(
          'author', usr.username,
          'timestamp', TO_CHAR(his.updated_time, 'Mon DD, YYYY'),
          'comment', his.overall_feedback,
          'roundColor', 'blueRound'
      )) AS overallfeedback
    FROM
      iaspire.trn_appraisalmapping_status_history his
    LEFT JOIN
      iaspire.mst_status sts ON sts.statusid = his.new_statusid
    LEFT JOIN
      public.wms_user usr ON usr.userid = his.updated_by
    WHERE
      his.appraisalid = $1
      AND sts.alias_name IN ('REVIEW_COMPLETED', 'REVIEW_PENDING_L2', 'ADS_DUH', 'ADS_FH', 'ADS_HR');`;
  return script;
};

export const getAddScoreRemarks = () => {
  const script = `SELECT
    json_agg(json_build_object(
        'author', usr.username,
        'timestamp', TO_CHAR(his.updated_time, 'Mon DD, YYYY'),
        'comment', his.additionalscore_remarks,
        'roundColor', 'greenRound'
    )) AS addscoreremarks
    FROM
    iaspire.trn_appraisalmapping_status_history his
    LEFT JOIN iaspire.mst_status sts ON sts.statusid = his.new_statusid
    LEFT JOIN public.wms_user usr ON usr.userid = his.updated_by
    WHERE
      appraisalid = $1 AND additionalscore_remarks IS NOT NULL;`;
  // appraisalid = $1 AND sts.alias_name IN ('ADS_DUH') AND additionalscore_remarks IS NOT NULL;`;
  return script;
};

export const getReviewRejRemarks = () => {
  const script = `SELECT
      json_agg(json_build_object(
          'author', usr.username,
          'timestamp', TO_CHAR(his.updated_time, 'Mon DD, YYYY'),
          'comment', rejection_remarks,
          'roundColor', 'redRound'
      )) AS reviewrejremarks
      FROM
      iaspire.trn_appraisalmapping_status_history his
      LEFT JOIN iaspire.mst_status sts ON sts.statusid = his.new_statusid
      LEFT JOIN public.wms_user usr ON usr.userid = his.updated_by
      WHERE
          appraisalid = $1 AND sts.alias_name ilike '%REVIEW%' AND sts.status_category IN ('rejected') AND rejection_remarks IS NOT NULL;`;
  return script;
};

export const getGoalRejRemarks = () => {
  const script = `SELECT
      json_agg(json_build_object(
          'author', usr.username,
          'timestamp', TO_CHAR(his.updated_time, 'Mon DD, YYYY'),
          'comment', his.rejection_remarks,
          'roundColor', 'redRound'
      )) AS goalrejremarks
      FROM
      iaspire.trn_appraisalmapping_status_history his
      LEFT JOIN iaspire.mst_status sts ON sts.statusid = his.new_statusid
      LEFT JOIN public.wms_user usr ON usr.userid = his.updated_by
      WHERE
          appraisalid = $1 AND sts.alias_name ilike '%GOAL%' AND sts.status_category IN ('rejected') AND rejection_remarks IS NOT NULL;`;
  return script;
};

export const getReOpenRejRemarksScript = () => {
  const script = `WITH rejremarks AS (
    SELECT
        appraisalid,
        usr.username AS author,
        TO_CHAR(reopen.updated_time, 'Mon DD, YYYY') AS timestamp,
		    approver1_remarks AS comment,
        CASE WHEN sts.alias_name = 'ROR_REJECTED_HR' THEN 'redRound'
	      ELSE 'greenRound' END AS roundColor
    FROM
        iaspire.trn_reopen_request reopen
    LEFT JOIN iaspire.mst_status sts ON sts.statusid = reopen.statusid
	  LEFT JOIN public.wms_user usr ON usr.userid = reopen.approver1
    WHERE
        appraisalid = $1    -- AND sts.alias_name IN ('ROR_PENDING_HR_SUPER_ADMIN','ROR_REJECTED_HR')  
        AND approver1_remarks IS NOT NULL
	
	  UNION ALL
 
    SELECT
        appraisalid,
        usr.username AS author,
        TO_CHAR(reopen.updated_time, 'Mon DD, YYYY') AS timestamp,
		    approver2_remarks AS comment,
        CASE WHEN sts.alias_name = 'ROR_REJECTED_SHR' THEN 'redRound'
	      ELSE 'greenRound' END AS roundColor
    FROM
        iaspire.trn_reopen_request reopen
    LEFT JOIN iaspire.mst_status sts ON sts.statusid = reopen.statusid
	  LEFT JOIN public.wms_user usr ON usr.userid = reopen.approver2
    WHERE
        appraisalid = $1    -- AND sts.alias_name IN ('ROR_REJECTED_SHR','ROR_APPROVED') 
        AND approver2_remarks IS NOT NULL
    )
    SELECT
        json_agg(json_build_object(
            'author', author,
            'timestamp', timestamp,
            'comment', comment,
            'roundColor', roundColor
        ) ORDER BY timestamp, author DESC) AS reopenrejremarks
    FROM
      rejremarks;`;
  return script;
};

export const getPBSummaryforKRA = () => {
  const script = `WITH sub1 AS (
    SELECT
        SUM(kra.selfscore) AS employeescore,
        MAX(appmap.additionalscore) AS additionalscore,
        (COALESCE(MAX(appmap.score), 0) + COALESCE(MAX(appmap.additionalscore), 0)) AS finalbpscore,
        COALESCE(u.username)||' ('|| COALESCE(appmap.updated_by)||')' AS lastchangedoneby
        --      appmap.updated_by AS lastchangedoneby
    FROM iaspire.trn_kra_lineitem kra
    LEFT JOIN iaspire.trn_appraisalmapping appmap ON kra.appraisalid = appmap.appraisalid
    LEFT JOIN public.wms_user u ON u.userid = appmap.updated_by 
    WHERE
        kra.appraisalid = $1
        AND kra.versionid = (
            SELECT MAX(item.versionid)
            FROM iaspire.trn_appraisalmapping app
            LEFT JOIN iaspire.trn_kra_lineitem item ON app.appraisalid = item.appraisalid
            JOIN iaspire.mst_status sts ON sts.statusid = app.statusid
            WHERE app.appraisalid = $1
              AND app.isactive = TRUE
              AND item.isactive = TRUE
        )
    GROUP BY appmap.updated_by, u.username
),
sub2 AS (
    SELECT
        (SELECT score
         FROM iaspire.trn_appraisalmapping_status_history
         WHERE new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2')
           AND appraisalid = $1
         ORDER BY updated_time DESC
         LIMIT 1) AS l1,
        (SELECT CASE
                    WHEN old_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2') 
                         AND new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_L2') THEN 0
                    WHEN old_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2') THEN score
                    WHEN new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_DUH') THEN score
                    ELSE 0
                END
         FROM iaspire.trn_appraisalmapping_status_history
         WHERE appraisalid = $1
           AND CASE
                    WHEN old_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2') 
                         AND new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_REJECTED_L2') THEN 0
                    WHEN old_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'REVIEW_PENDING_L2') THEN score
                    WHEN new_statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'ADS_DUH') THEN score
                    ELSE 0
                END > 0
         ORDER BY updated_time DESC
         LIMIT 1) AS l2
)
SELECT
    COALESCE(ROUND(sub1.employeescore::numeric, 2)::float, 0) AS employeescore,
    COALESCE(ROUND(sub1.additionalscore::numeric, 2)::float, 0) AS additionalscore,
    COALESCE(ROUND(sub1.finalbpscore::numeric, 2)::float, 0) AS finalbpscore,
    sub1.lastchangedoneby,
    COALESCE(ROUND(sub2.l1::numeric, 2)::float, 0) AS l1,
    COALESCE(ROUND(sub2.l2::numeric, 2)::float, 0) AS l2
FROM sub1, sub2;`;
  return script;
};

export const getIsMLGoalExist = () => {
  const script = `SELECT kl.appraisalid, kl.item, kl.measure, kl.weightage, MAX(kl.versionid) AS versionid, 
    app.quartercode, app.statusid, s.status, s.alias_name
    FROM iaspire.trn_kra_lineitem kl 
    JOIN iaspire.trn_appraisalmapping app ON app.appraisalid = kl.appraisalid AND app.isactive = true
    JOIN iaspire.mst_status s ON s.statusid = app.statusid AND s.isactive = true AND 
        s.alias_name IN ('GOAL_APPROVED', 'REVIEW_PENDING_EMPLOYEE', 'REVIEW_PENDING_L1', 'REVIEW_PENDING_L2', 'REVIEW_REJECTED_L1', 'REVIEW_REJECTED_L2',
        'ADS_DUH', 'ADS_FH', 'REVIEW_REOPEN_REQUESTED', 'REVIEW_EXPIRED','HOLD', 'PAID', 'RDY_PAID', 'REVIEW_COMPLETED',
        'REVIEW_REJECTED_HR','REVIEW_REJECTED_FH', 'REVIEW_REJECTED_DUH','REVIEW_REJECTED_L2')
    WHERE kl.appraisalid = $1 AND kl.isactive = true
    GROUP BY kl.appraisalid, kl.item, kl.measure, kl.weightage, app.quartercode, 
        app.statusid, s.status, s.alias_name;`;
  return script;
};
