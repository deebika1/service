export const getMySquadListScript = (
  statusCode,
  roleAcr,
  fromScreen,
  userId,
) => {
  let condition = '';
  if (statusCode !== '') {
    if (fromScreen === 'G') {
      if (statusCode === 'pendingQueue') {
        condition = ` AND ((usr.l2 = $4 AND sts.alias_name IN ('GOAL_PENDING_L2'))
              OR (usr.reportingto = $4 AND sts.alias_name IN ('GOAL_PENDING_L1')))`;
      } else if (statusCode === 'rejectQueue') {
        condition = ` AND ((usr.l2 = $4 AND sts.alias_name IN ('GOAL_REJECTED_L2'))
              OR (usr.reportingto = $4 AND sts.alias_name IN ('GOAL_REJECTED_L1')))`;
      } else if (statusCode === 'yts') {
        condition = ` AND usr.reportingto = $4 AND  (sts.alias_name IN ('GOAL_PENDING_EMPLOYEE') OR sts.alias_name IS NULL)`;
      } else if (statusCode === 'overallStatus') {
        if (roleAcr !== 'SHR') {
          condition = ` AND (usr.reportingto = $4 OR usr.duhead = $4 OR usr.functionalhead = $4 OR usr.l2 = $4 OR usr.l3 = $4 OR 
                usr.l4 = $4 OR usr.l5 = $4 OR usr.l6 = $4 OR usr.l7 = $4 OR usr.l8 = $4) 
                AND (sts.alias_name IN ('GOAL_APPROVED','GOAL_PENDING_EMPLOYEE','GOAL_PENDING_L1','GOAL_PENDING_L2','GOAL_REJECTED_L1','GOAL_REJECTED_L2','GOAL_EXPIRED')
                OR sts.alias_name IS NULL)`;
        } else {
          condition = ` AND $4 = $4 or (sts.alias_name IN ('GOAL_APPROVED','GOAL_PENDING_EMPLOYEE','GOAL_PENDING_L1','GOAL_PENDING_L2','GOAL_REJECTED_L1','GOAL_REJECTED_L2','GOAL_EXPIRED')
          OR sts.alias_name IS NULL)`;
        }
      }
    } else if (fromScreen === 'R') {
      if (statusCode === 'pendingQueue') {
        if (roleAcr !== 'SHR') {
          condition = ` AND ((usr.l2 = $4 AND sts.alias_name IN ('REVIEW_PENDING_L2','REVIEW_REJECTED_DUH','REVIEW_REJECTED_FH','REVIEW_REJECTED_HR'))
            OR (usr.reportingto = $4 AND sts.alias_name IN ('REVIEW_PENDING_L1','REVIEW_REJECTED_L2'))
            OR (sts.alias_name = 'ADS_DUH' AND usr.duhead = $4 AND (app.score + app.additionalscore) >= 100)
            OR (sts.alias_name = 'ADS_FH' AND usr.functionalhead = $4 AND (app.score + app.additionalscore) >= 100)
            OR (sts.alias_name = 'ADS_DUH' AND usr.duhead = $4 AND (app.score + app.additionalscore) <= 100))`;
        } else {
          condition = `--  $4 = $4 OR 
            AND ((usr.l2 = $4 AND sts.alias_name IN ('REVIEW_PENDING_L2','REVIEW_REJECTED_DUH','REVIEW_REJECTED_FH','REVIEW_REJECTED_HR'))
            OR (usr.reportingto = $4 AND sts.alias_name IN ('REVIEW_PENDING_L1','ADS_DUH','ADS_FH'))
            OR ('${roleAcr}' = 'SHR' AND sts.alias_name IN ('ADS_HR'))
            OR (sts.alias_name = 'ADS_DUH' AND usr.duhead = $4 AND (app.score + app.additionalscore) >= 100)
            OR (sts.alias_name = 'ADS_FH' AND usr.functionalhead = $4 AND (app.score + app.additionalscore) >= 100)
            OR (sts.alias_name = 'ADS_DUH' AND usr.duhead = $4 AND (app.score + app.additionalscore) <= 100))
            --  OR (sts.alias_name IN ('GOAL_APPROVED','GOAL_PENDING_EMPLOYEE','GOAL_PENDING_L1','GOAL_PENDING_L2','GOAL_REJECTED_L1','GOAL_REJECTED_L2','GOAL_EXPIRED','ADS_HR')))`;
        }
      } else if (statusCode === 'rejectQueue') {
        condition = ` AND ((usr.l2 = $4 AND sts.alias_name IN ('REVIEW_REJECTED_L2','REVIEW_REJECTED_DUH','REVIEW_REJECTED_FH','REVIEW_REJECTED_HR'))
            OR (usr.reportingto = $4 AND sts.alias_name IN ('REVIEW_REJECTED_L1','REVIEW_REJECTED_DUH','REVIEW_REJECTED_FH','REVIEW_REJECTED_HR')))`;
      } else if (statusCode === 'yts') {
        condition = ` AND ((usr.reportingto = $4 AND  sts.alias_name IN ('GOAL_APPROVED','REVIEW_PENDING_EMPLOYEE')))`;
      } else if (statusCode === 'overallStatus') {
        if (roleAcr !== 'SHR') {
          condition = ` AND (usr.reportingto = $4 OR usr.duhead = $4 OR usr.functionalhead = $4 OR usr.l2 = $4 OR
          usr.l3 = $4 OR usr.l4 = $4 OR usr.l5 = $4 OR usr.l6 = $4 OR usr.l7 = $4 OR usr.l8 = $4) AND 
         (sts.alias_name IN ('REVIEW_COMPLETED','REVIEW_PENDING_EMPLOYEE','REVIEW_PENDING_L1','REVIEW_PENDING_L2','REVIEW_REJECTED_L1','REVIEW_REJECTED_L2','REVIEW_EXPIRED','REVIEW_REOPEN_REQUESTED','REVIEW_REOPEN_REJECTED',
         'ADS_DUH','ADS_FH','ADS_HR','REVIEW_REJECTED_DUH','REVIEW_REJECTED_FH','REVIEW_REJECTED_HR'))
         --  OR	(usr.duhead = $4 AND app.appraisaltype = 'QPR' AND sts.alias_name IN ('REVIEW_REOPEN_REQUESTED','REVIEW_REOPEN_REJECTED')))`;
        } else {
          condition = ` AND $4 = $4 OR 
          (sts.alias_name IN ('REVIEW_COMPLETED', 'REVIEW_PENDING_EMPLOYEE', 'REVIEW_PENDING_L1', 
              'REVIEW_PENDING_L2', 'REVIEW_REJECTED_L1', 'REVIEW_REJECTED_L2', 'REVIEW_EXPIRED',
              'ADS_DUH','ADS_FH','ADS_HR','REVIEW_REJECTED_DUH','REVIEW_REJECTED_FH','REVIEW_REJECTED_HR'))`;
        }
      }
    }
  }

  const script = `SELECT ROW_NUMBER() OVER (ORDER BY q.userid) AS serial, q.*
  FROM (
      SELECT
          usr.userid,
          usr.username,
          ds.designationdesc,
          itrackdu.duname,
          bl.bandlevel,
          COALESCE(sts.status, (SELECT status FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_EMPLOYEE')) as status,
           COALESCE( sts.status_category, (SELECT  status_category FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_EMPLOYEE'))  AS statusclass,
          usr.reportingto,
          usr.duhead,
          usr.functionalhead,
          usr.useractive,
          app.appraisalid, 
          app.employeecode, 
          COALESCE(app.quartercode,$2) as quartercode, 
          usr.pbtype as appraisaltype,
          app.statusid,
          app.templateid,
          app.score, 
          app.additionalscore,
          app.pendingwith,
          app.goal_deadline, 
          app.reviewcompleteddate,
          app.overall_feedback,
          app.additionalscore_remarks,
          app.rejection_remarks,
          app.ismlentry, 
          app.review_deadline,
          app.max_attachment_key,
          app.rating,
          usr.itracks_duid ,
          bl.bandlevelid,
          ds.designationid,
          CASE 
          WHEN '${roleAcr}' NOT IN ('HR','SHR') THEN
           CASE 
           WHEN $4 NOT IN (usr.reportingto, usr.l2, usr.duhead, usr.functionalhead) THEN ''
           WHEN (usr.pbtype = 'QPR' AND (sts.alias_name ILIKE '%EXPIRED%' OR sts.alias_name ILIKE '%REJECTED%') AND usr.duhead = $4) THEN 'action'
           WHEN ((sts.alias_name IN ('GOAL_PENDING_EMPLOYEE','REVIEW_PENDING_EMPLOYEE')) OR (sts.alias_name IS NULL) OR
               (sts.alias_name ILIKE '%EXPIRED%' OR sts.alias_name ILIKE '%REOPEN%' OR sts.alias_name ILIKE '%ROR%')) THEN ''
           ELSE 'action' END
           WHEN '${roleAcr}' = 'SHR' THEN
            CASE WHEN (sts.alias_name ILIKE '%ADS_HR%') THEN 'action'
            ELSE '' END 
          ELSE '' END AS action,
          COALESCE(sts.alias_name, 'GOAL_PENDING_EMPLOYEE') AS alias_name,
          usr.L2 AS l2,
          1 AS depth
      FROM 
          IASPIRE.reporting_hierarchy_view usr
      JOIN 
          public.mst_deliveryunit itrackdu ON usr.itracks_duid = itrackdu.duid
      LEFT JOIN 
          iaspire.trn_appraisalmapping app ON app.employeecode = usr.userid
      JOIN 
          public.mst_bandlevel bl ON bl.bandlevelid = usr.bandlevelid
      JOIN  
          public.mst_designation ds ON ds.designationid = usr.designationid
      LEFT JOIN 
          iaspire.mst_status sts ON sts.statusid = app.statusid
      WHERE usr.useractive = true AND app.isactive = true
          ${condition} order by action desc
  ) AS q where q.employeecode <> '${userId}' AND
  ($1 = '' OR q.userid ILIKE '%' || $1 || '%' OR q.username ILIKE '%' || $1 || '%')
  AND q.quartercode = $2 AND q.appraisaltype = $3
  -- AND ($5 = '' OR q.itracks_duid IN ($9))
  -- AND ($6 = '' OR q.bandlevelid IN ($10))
  -- AND ($7 = '' OR q.designationid IN ($11))
  -- AND ($8 = '' OR q.statusid IN ($12))
  AND ($5 = '' OR q.itracks_duid = ANY($9))
  AND ($6 = '' OR q.bandlevelid = ANY($10))
  AND ($7 = '' OR q.designationid = ANY($11))
  AND ($8 = '' OR q.statusid = ANY($12))`;
  return script;
};

export const updateApprovalScript = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
        SET
        statusid=$2,
        updated_by = $3,
        updated_time = CURRENT_TIMESTAMP
      WHERE appraisalid = $1;`;
  return script;
};

export const updateRejectScript = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
        SET
        statusid=$2,
        rejection_remarks = $4,
        updated_by = $3,
        updated_time = CURRENT_TIMESTAMP
      WHERE appraisalid = $1;`;
  return script;
};

export const updateFeedbackScript = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
          SET
          overall_feedback = $2,
          updated_by = $3,
          updated_time = CURRENT_TIMESTAMP
        WHERE appraisalid = $1;`;
  return script;
};

export const updateKraLineItemReviewScoreScript = () => {
  const script = `UPDATE iaspire.trn_kra_lineitem
	      SET
        reviwerscore = $2,
        appraisercomment = $3,
        updated_by=$4
	      WHERE kra_itemid = $1;`;

  return script;
};

export const updateQprLineItemReviewScoreScript = () => {
  const script = `UPDATE iaspire.trn_qpr_user_lineitem SET
        score = $3,
        remarks = $4,
        updated_by = $5
	      WHERE lineitemid = $1 AND appraisalid = $2;`;
  return script;
};

export const updateTotalScoreScript = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
              SET
              score = $2,
              updated_by = $3,
              updated_time = CURRENT_TIMESTAMP
            WHERE appraisalid = $1;`;
  return script;
};

export const updateAdditionalScoreScript = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
            SET
            additionalscore = $2,
            additionalscore_remarks = $3,
            updated_by = $4,
            updated_time = CURRENT_TIMESTAMP
          WHERE appraisalid = $1;`;
  return script;
};
export const updateUserRatingScript = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
            SET
            rating = $2,
            updated_by = $3,
            updated_time = CURRENT_TIMESTAMP
          WHERE appraisalid = $1;`;
  return script;
};

export const getReopenReqTypeScript = () => {
  const script = `SELECT typeid::bigint AS column_id, type AS column_name FROM iaspire.mst_reopen_req_type WHERE isactive = true;`;
  return script;
};

export const getReopenReqListScript = () => {
  const script = `
    WITH user_roles AS (
      SELECT roleacronym
      FROM wms_role
      WHERE roleid = $2
    )

    SELECT 
      ROW_NUMBER() OVER (ORDER BY req.raised_on DESC) AS serial,
      req.requestid,
      req.appraisalid,
      usr.userid,
      usr.username,
      itrackdu.duname AS du,
      reqt.type AS type,
      reqt.type_alias AS type_alias,
      appmap.quartercode AS quarter,
      req.raised_on::text AS requestraisedon,
      'action' AS action,
      req.request_remarks AS reason,
      CASE 
        WHEN reqt.type_alias = 'GOAL' THEN qua.goal_deadline 
        ELSE qua.review_deadline 
      END AS deadline,
      (
        SELECT COUNT(*)
        FROM iaspire.trn_reopen_request
        WHERE appraisalid = req.appraisalid and typeid = req.typeid
      ) as iteration,
      usrhr.username AS hr,
      req.approver1_remarks AS hrremark
    FROM 
      iaspire.trn_reopen_request req
    JOIN 
      iaspire.mst_status st ON st.statusid = req.statusid
    JOIN 
      iaspire.trn_appraisalmapping appmap ON appmap.appraisalid = req.appraisalid
    JOIN 
      public.wms_user usr ON usr.userid = appmap.employeecode
    JOIN 
      public.mst_deliveryunit itrackdu ON usr.itracks_duid = itrackdu.duid
    JOIN 
      iaspire.mst_reopen_req_type reqt ON reqt.typeid = req.typeid
    JOIN 
      iaspire.mst_quarters qua ON qua.quartercode = appmap.quartercode
    LEFT JOIN 
      public.wms_user usrhr ON usrhr.userid = req.approver1
    WHERE 
      ($1 = '' OR req.typeid::text = $1)
      AND (
        ('HR' IN (SELECT roleacronym FROM user_roles) AND st.alias_name = 'ROR_PENDING_HR_ADMIN')
        OR
        ('SHR' IN (SELECT roleacronym FROM user_roles) AND st.alias_name = 'ROR_PENDING_HR_SUPER_ADMIN')
      )
      AND (
        $3 = '' OR
        usr.username ILIKE '%' || $3 || '%' OR
        usr.userid ILIKE '%' || $3 || '%'
      ) AND appmap.employeecode <> $4;
  `;
  return script;
};

export const getNextStatusAppMap = () => {
  // const script = `SELECT statusid
  //                 FROM iaspire.mst_status
  //                 WHERE alias_name IN (
  //                     CASE
  //                         WHEN $1 = 'SHR' AND $2 = 'approve' AND $3 = 'GOAL' THEN 'GOAL_PENDING_EMPLOYEE'
  //                         WHEN $1 = 'SHR' AND $2 = 'approve' AND $3 = 'K_Review' THEN 'REVIEW_PENDING_EMPLOYEE'
  //                         WHEN $1 = 'SHR' AND $2 = 'approve' AND $3 = 'Q_Review' THEN 'REVIEW_PENDING_L1'
  //                         WHEN $1 IN ('SHR', 'HR') AND $2 = 'reject' AND $3 = 'GOAL' THEN 'GOAL_REOPEN_REJECTED'
  //                         WHEN $1 IN ('SHR', 'HR') AND $2 = 'reject' AND $3 = 'K_Review' THEN 'REVIEW_REOPEN_REJECTED'
  //                         WHEN $1 IN ('SHR', 'HR') AND $2 = 'reject' AND $3 = 'Q_Review' THEN 'REVIEW_REOPEN_REJECTED'
  //                         ELSE '0'
  //                     END
  //                 );`;
  const condition = `SELECT COALESCE((SELECT s.alias_name FROM iaspire.trn_appraisalmapping_status_history h
    JOIN iaspire.mst_status s ON s.statusid = h.old_statusid
    WHERE appraisalid = $4 AND old_statusid NOT IN (SELECT statusid FROM iaspire.mst_status WHERE alias_name IN 
	  ('GOAL_EXPIRED', 'REVIEW_EXPIRED', 'GOAL_REOPEN_REQUESTED', 'REVIEW_REOPEN_REQUESTED', 'GOAL_REOPEN_REJECTED', 
    'REVIEW_REOPEN_REJECTED', 'ROR_PENDING_HR_ADMIN', 'ROR_PENDING_HR_SUPER_ADMIN', 'ROR_REJECTED_HR', 
    'ROR_REJECTED_SHR', 'ROR_APPROVED')) ORDER BY h.history_id DESC LIMIT 1)`;
  // const script = `SELECT statusid
  //                 FROM iaspire.mst_status
  //                 WHERE alias_name IN (
  //                     CASE
  //                         WHEN $1 = 'SHR' AND $2 = 'A' AND $3 = 'GOAL' THEN 'GOAL_PENDING_EMPLOYEE'
  //                         WHEN $1 = 'SHR' AND $2 = 'A' AND $3 = 'K_REVIEW' THEN 'REVIEW_PENDING_EMPLOYEE'
  //                         WHEN $1 = 'SHR' AND $2 = 'A' AND $3 = 'Q_REVIEW' THEN 'REVIEW_PENDING_L1'
  //                         WHEN $1 IN ('SHR', 'HR') AND $2 = 'R' AND $3 = 'GOAL' THEN 'GOAL_REOPEN_REJECTED'
  //                         WHEN $1 IN ('SHR', 'HR') AND $2 = 'R' AND $3 = 'K_REVIEW' THEN 'REVIEW_REOPEN_REJECTED'
  //                         WHEN $1 IN ('SHR', 'HR') AND $2 = 'R' AND $3 = 'Q_REVIEW' THEN 'REVIEW_REOPEN_REJECTED'
  //                         ELSE '0'
  //                     END
  //                 );`;
  const script = `SELECT statusid
                  FROM iaspire.mst_status
                  WHERE alias_name IN (
                      CASE
                          WHEN $1 = 'SHR' AND $2 = 'A' AND $3 = 'GOAL' THEN (${condition}, 'GOAL_PENDING_EMPLOYEE') FROM iaspire.mst_status LIMIT 1)
                          WHEN $1 = 'SHR' AND $2 = 'A' AND $3 = 'K_REVIEW' THEN (${condition}, 'REVIEW_PENDING_EMPLOYEE') FROM iaspire.mst_status LIMIT 1)
                          WHEN $1 = 'SHR' AND $2 = 'A' AND $3 = 'Q_REVIEW' THEN (${condition}, 'REVIEW_PENDING_L1') FROM iaspire.mst_status LIMIT 1)
                          WHEN $1 IN ('SHR', 'HR') AND $2 = 'R' AND $3 = 'GOAL' THEN 'GOAL_REOPEN_REJECTED'
                          WHEN $1 IN ('SHR', 'HR') AND $2 = 'R' AND $3 = 'K_REVIEW' THEN 'REVIEW_REOPEN_REJECTED'
                          WHEN $1 IN ('SHR', 'HR') AND $2 = 'R' AND $3 = 'Q_REVIEW' THEN 'REVIEW_REOPEN_REJECTED'
                          ELSE '0'
                      END
                  );`;
  return script;
};

export const getNextStatusROR = () => {
  // const script = `SELECT statusid
  //                 FROM iaspire.mst_status
  //                 WHERE alias_name IN (
  //                     CASE
  //                         WHEN $1 = 'HR' AND $2 = 'approve' THEN 'ROR_PENDING_HR_SUPER_ADMIN'
  //                         WHEN $1 = 'HR' AND $2 = 'reject' THEN 'ROR_REJECTED_HR'
  //                         WHEN $1 = 'SHR' AND $2 = 'approve' THEN 'ROR_APPROVED'
  //                         WHEN $1 = 'SHR' AND $2 = 'reject' THEN 'ROR_REJECTED_SHR'
  //                         ELSE '0'
  //                     END
  //                 );`;
  const script = `SELECT statusid
                  FROM iaspire.mst_status
                  WHERE alias_name IN (
                      CASE
                          WHEN $1 = 'HR' AND $2 = 'A' THEN 'ROR_PENDING_HR_SUPER_ADMIN'
                          WHEN $1 = 'HR' AND $2 = 'R' THEN 'ROR_REJECTED_HR'
                          WHEN $1 = 'SHR' AND $2 = 'A' THEN 'ROR_APPROVED'
                          WHEN $1 = 'SHR' AND $2 = 'R' THEN 'ROR_REJECTED_SHR'
                          ELSE '0'
                      END
                  );`;
  return script;
};

export const updateNextStatusAppMap = () => {
  const script = `UPDATE iaspire.trn_appraisalmapping
  SET
    statusid = CASE
                 WHEN $1 <> 0 THEN $1
                 ELSE statusid
               END,
    goal_deadline = CASE
                      WHEN $2 = 'GOAL' THEN CURRENT_DATE + INTERVAL '15 days'
                      ELSE goal_deadline
                    END,
    review_deadline = CASE
                        WHEN $2 = 'GOAL' AND review_deadline < CURRENT_DATE THEN CURRENT_DATE + INTERVAL '15 days'
                        WHEN $2 != 'GOAL' THEN CURRENT_DATE + INTERVAL '15 days'
                        ELSE review_deadline
                      END
  WHERE
    appraisalid = $3;`;
  return script;
};

export const updateNextStatusROR = () => {
  const script = `UPDATE iaspire.trn_reopen_request
                  SET statusid = CASE WHEN $1 <> 0 THEN $1 ELSE statusid END,
                    approver1_remarks = CASE WHEN $2 = 'HR' THEN $3 ELSE approver1_remarks END,
                    approver1 = CASE WHEN $2 = 'HR' THEN $4 ELSE approver1 END,
                    approver2_remarks = CASE WHEN $2 = 'SHR' THEN $3 ELSE approver2_remarks END,
                    approver2 = CASE WHEN $2 = 'SHR' THEN $4 ELSE approver2 END,
                    updated_time = CURRENT_TIMESTAMP
                  WHERE requestid = $5;`;
  return script;
};

export const getQuarterList = () => {
  const script = `SELECT quartercode FROM iaspire.mst_quarters WHERE isactive = true ORDER BY startdate DESC;`;
  return script;
};

export const getiAspireUsrRoleAcry = () => {
  const script = `SELECT DISTINCT roleacronym FROM PUBLIC.wms_role where roleid = $1`;
  return script;
};

export const getUserScoreRateScript = () => {
  const script = `SELECT rv.minvalue, rv.maxvalue, rv.rating,rg.groupid , rg.groupname  from wms_user usr 
  JOIN iaspire.trn_rating_combination rc on rc.duid = usr.itracks_duid 
  and rc.designationid = usr.designationid and rc.bandlevelid = usr.bandlevelid
  JOIN iaspire.mst_rating_value rv ON rv.groupid = rc.groupid
  JOIN iaspire.mst_rating_group rg ON rg.groupid = rc.groupid
  WHERE usr.userid = $1 `;
  return script;
};

export const getStatusUsingAliasName = () => {
  const script = `SELECT statusid FROM iaspire.mst_status WHERE alias_name = $1`;
  return script;
};

export const getSubordinatesList = () => {
  const script = `select userid, username || ' ' || '(' || userid || ')' as username from public.wms_user where reportingto = $1 and useractive = true`;
  return script;
};

export const getIsFirstPB = () => {
  const script = `SELECT appraisalid, employeecode, quartercode, statusid,
      (SELECT doj FROM public.wms_user WHERE userid = employeecode) AS doj,
      (SELECT alias_name FROM iaspire.mst_status WHERE statusid = (SELECT statusid FROM iaspire.trn_appraisalmapping WHERE appraisalid = $1)),
      (SELECT startdate-15 AS startdate FROM iaspire.mst_quarters WHERE quartercode = (SELECT quartercode FROM iaspire.trn_appraisalmapping WHERE appraisalid = $1)), 
      (SELECT enddate-15 AS enddate FROM iaspire.mst_quarters WHERE quartercode = (SELECT quartercode FROM iaspire.trn_appraisalmapping WHERE appraisalid = $1))
      FROM iaspire.trn_appraisalmapping WHERE appraisalid = $1`;
  return script;
};

export const MLEmpList = () => {
  const script = `SELECT md.empcode, u.username, u.doj, md.startdate AS mlstartdate, md.enddate AS mlenddaate, 
    q.quartercode, am.appraisalid, u.pbtype, am.appraisaltype, q.startdate AS quarterstartdate, q.enddate AS quarterenddate 
    FROM public.wms_user u 
    JOIN iaspire.trn_emp_ml_details md ON md.empcode = u.userid AND md.isactive = true
    JOIN iaspire.mst_quarters q ON q.quartercode = $2 AND q.isactive = true
    LEFT JOIN iaspire.trn_appraisalmapping am ON am.employeecode = md.empcode AND 
      am.quartercode = q.quartercode AND am.isactive = true
    WHERE u.reportingto = $1 AND u.useractive = true AND
    ((md.startdate BETWEEN q.startdate AND q.enddate) OR (md.enddate BETWEEN q.startdate AND q.enddate));`;
  return script;
};

export const getMLEmpStatus = () => {
  const script = `SELECT statusid FROM iaspire.trn_appraisalmapping 
    WHERE employeecode = $1 AND quartercode = $2 AND isactive = true`;
  return script;
};
export const getIsMLInRestrictedStatusScript = () => {
  const script = `SELECT 
    CASE 
        WHEN $1 IN (
            SELECT statusid 
            FROM iaspire.mst_status ms 
            WHERE alias_name IN ('HOLD', 'PAID', 'RDY_PAID', 'ADS_FH', 'REVIEW_PENDING_L2', 'REVIEW_COMPLETED', 'ADS_DUH',
            'REVIEW_REJECTED_HR','REVIEW_REJECTED_FH', 'REVIEW_REJECTED_DUH','REVIEW_REJECTED_L2')
        )
        THEN TRUE
        ELSE FALSE
    END AS is_restricted_status;`;
  return script;
};

export const changeGoalInActive = () => {
  const script = `UPDATE iaspire.trn_kra_lineitem
	      SET isactive = false
        WHERE appraisalid = $1;`;
  return script;
};
