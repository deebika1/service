import { query } from '../../database/postgres.js';

export const getAppraisalType = async categoryId => {
  const appType = await query(
    'SELECT appraisaltype FROM iaspire.mst_appraisaltype WHERE categoryid = $1 AND isactive = TRUE',
    [categoryId],
  );
  return appType[0]?.appraisaltype;
};

export const getOrInsCurrentQuaterDetails = async (dateParam, empCode) => {
  const quarterDetails = await query(
    'SELECT * FROM iaspire.insert_quarters($1, $2)',
    [dateParam, empCode],
  );
  return quarterDetails;
};

export const getQuaterDetailsByQcode = async quarterCode => {
  const quarterDetails = await query(
    'SELECT * FROM iaspire.mst_quarters WHERE quartercode = $1',
    [quarterCode],
  );
  return quarterDetails;
};

export const getQuaterDetailsByDate = async startDate => {
  const quarterDetails = await query(
    'SELECT * FROM iaspire.mst_quarters WHERE $1 BETWEEN startdate AND enddate',
    [startDate],
  );
  return quarterDetails;
};

export const getTemplateId = async (designationId, duId, bendLevelId) => {
  const templateDetails = await query(
    `SELECT templateid FROM iaspire.trn_qpr_template WHERE duid = $1 AND designationid = $2 AND bandlevelid = $3 AND isactive = TRUE`,
    [duId, designationId, bendLevelId],
  );
  return templateDetails[0]?.templateid;
};

// Function to get PB Status
export const getPbStatusId = async (empCode, quarterCode) => {
  const result = await query(
    `SELECT 
    CASE 
        WHEN EXISTS (
            SELECT 1
            FROM iaspire.trn_appraisalmapping a
            JOIN iaspire.mst_status s ON a.statusid = s.statusid
            WHERE a.employeecode = $1
            AND a.quartercode = $2
            AND s.alias_name IN ('GOAL_PENDING_EMPLOYEE', 'GOAL_PENDING_L1', 'GOAL_PENDING_L2', 'GOAL_REJECTED_L1', 'GOAL_REJECTED_L2')
			AND a.goal_deadline < CURRENT_TIMESTAMP AND a.ismlentry = false
        ) THEN 
            (SELECT statusid 
             FROM iaspire.mst_status 
             WHERE alias_name = 'GOAL_EXPIRED')
        WHEN EXISTS (
            SELECT 1
            FROM iaspire.trn_appraisalmapping a
            JOIN iaspire.mst_status s ON a.statusid = s.statusid
            WHERE a.employeecode = $1
            AND a.quartercode = $2
            AND s.alias_name  IN ('REVIEW_PENDING_EMPLOYEE',
			'REVIEW_PENDING_L1','REVIEW_PENDING_L2','ADS_DUH','REVIEW_REJECTED_L1','REVIEW_REJECTED_L2',
			'ADS_FH','ADS_HR','REVIEW_REJECTED_DUH','REVIEW_REJECTED_FH','REVIEW_REJECTED_HR','GOAL_APPROVED')
      AND s.alias_name NOT IN ('REVIEW_REOPEN_REQUESTED','REVIEW_REOPEN_REJECTED')
			 AND a.review_deadline < CURRENT_TIMESTAMP AND a.ismlentry = false
        ) THEN
             (SELECT statusid 
             FROM iaspire.mst_status 
             WHERE alias_name = 'REVIEW_EXPIRED')
        ELSE 
            (SELECT statusid 
             FROM iaspire.trn_appraisalmapping 
             WHERE employeecode = $1
             AND quartercode = $2)
    END AS statusid;`,
    [empCode, quarterCode],
  );
  return result[0]?.statusid;
};

export const getPbStatusDetById = async statusId => {
  const statusDet = await query(
    `SELECT * FROM iaspire.mst_status WHERE statusid = $1`,
    [statusId],
  );
  return statusDet;
};

export const getPbStatusDetByAliasName = async aliasName => {
  const statusDet = await query(
    `SELECT * FROM iaspire.mst_status WHERE trim(upper(alias_name)) = trim(upper($1))`,
    [aliasName],
  );
  return statusDet[0].statusid;
};

export const insertPBDetails = async (
  empCode,
  quarterCode,
  appType,
  statusid,
  templateId,
  goal_deadline,
  review_deadline,
  modifiedBy,
  isML,
) => {
  const result = await query(
    `INSERT INTO iaspire.trn_appraisalmapping(employeecode, quartercode, appraisaltype, statusid, templateid, goal_deadline, review_deadline, created_by, ismlentry) 
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) 
     RETURNING appraisalId`,
    [
      empCode,
      quarterCode,
      appType,
      statusid,
      templateId,
      goal_deadline,
      review_deadline,
      modifiedBy,
      isML,
    ],
  );
  const appraisalId = result[0]?.appraisalid;
  return appraisalId;
};

export const updatePBDetails = async (
  empCode,
  quarterCode,
  appType,
  statusid,
  templateId,
  // modifiedBy,
  isML,
) => {
  const maxKey = await query(
    `UPDATE iaspire.trn_appraisalmapping
      SET
        appraisaltype = COALESCE($3, appraisaltype),
        statusid = $4,
        templateid = $5,
       -- updated_by = $6,
        updated_time = CURRENT_TIMESTAMP,
        ismlentry = $6
      WHERE trim(upper(employeecode)) = trim(upper($1)) AND trim(upper(quartercode)) = trim(upper($2))
      RETURNING max_attachment_key;`,
    // [empCode, quarterCode, appType, statusid, templateId, modifiedBy, isML],
    [empCode, quarterCode, appType, statusid, templateId, isML],
  );
  return maxKey[0].max_attachment_key;
};

// Function to check if the Appraisal record exists
const checkReviewRecordExists = async appraisalId => {
  const existsResult = await query(
    `SELECT 1 FROM iaspire.trn_reviewerdetails
      WHERE appraisalid = $1 AND isactive = TRUE`,
    [appraisalId],
  );
  return existsResult?.length !== 0;
};

export const insOrUpdateReviewerDetails = async (
  appraisalId,
  l1Manager,
  l2Manager,
  duHead,
  fuHead,
  modifiedBy,
) => {
  const existingRecord = await checkReviewRecordExists(appraisalId);
  if (!existingRecord) {
    await query(
      `INSERT INTO iaspire.trn_reviewerdetails(
        appraisalid, reviewer1, reviewer2, duhead, functionalhead, created_by)
        VALUES ($1, $2, $3, $4, $5, $6);`,
      [appraisalId, l1Manager, l2Manager, duHead, fuHead, modifiedBy],
    );
  } else {
    await query(
      `UPDATE iaspire.trn_reviewerdetails
        SET
          reviewer1 = COALESCE($2, reviewer1),
          reviewer2 = COALESCE($3, reviewer2),
          duhead = COALESCE($4, duhead),
          functionalhead = COALESCE($5, functionalhead),
          updated_by = $6
        WHERE appraisalId = $1 AND isactive = TRUE`,
      [appraisalId, l1Manager, l2Manager, duHead, fuHead, modifiedBy],
    );
  }
};

const getEmpMode = async empCode => {
  // Use a regular expression to match only alphabets
  const empMode = empCode.replace(/[^a-zA-Z]/g, '');
  return empMode;
};

export const isPbEligible = async empCode => {
  const empMode = await getEmpMode(empCode);
  const result = await query(
    `SELECT iseligible FROM iaspire.mst_pb_eligibility
      WHERE trim(upper(employmentmode)) = trim(upper($1)) AND isactive = TRUE`,
    [empMode],
  );
  const isEligible = result?.length !== 0 && result[0]?.iseligible;

  return isEligible === true;
};

export const isActiveUser = async empCode => {
  const userActive = await query(
    'SELECT * FROM public.wms_user WHERE userid = $1 AND useractive = TRUE',
    [empCode],
  );
  return userActive?.length !== 0;
};

export const getOpenKraList = async empCode => {
  const userActive = await query(
    // 'SELECT * FROM iaspire.trn_appraisalmapping WHERE employeecode = $1 AND statusid <> 11',
    `SELECT am.* FROM iaspire.trn_appraisalmapping am
      JOIN iaspire.mst_status s ON s.statusid = am.statusid
      WHERE employeecode = $1 AND s.alias_name NOT in ('REVIEW_COMPLETED','RDY_PAID','PAID');`,
    [empCode],
  );
  return userActive;
};

export const updatePbEligibilty = async (empCode, isPbEligibleFlag) => {
  const result = await query(
    `UPDATE public.wms_user
      SET ispbeligible = $2
      WHERE userid = $1;`,
    [empCode, isPbEligibleFlag],
  );
  return result;
};

// Function to fetch the ID based on the field and value
export const getIdByField = async (fieldName, fieldValue) => {
  let tableName;
  let idField;
  // eslint-disable-next-line no-undef
  if (fieldValue == null) return undefined;
  switch (fieldName) {
    case 'designationdesc':
      tableName = 'public.mst_designation';
      idField = 'designationid';
      break;
    case 'category':
      tableName = 'iaspire.mst_appraisaltype';
      idField = 'categoryid';
      break;
    case 'bandlevel':
      tableName = 'public.mst_bandlevel';
      idField = 'bandlevelid';
      break;
    case 'rolename':
      tableName = 'public.wms_role';
      idField = 'roleid';
      break;
    case 'duname':
      tableName = 'public.mst_deliveryunit';
      idField = 'duid';
      break;
    case 'appraisaltype':
      tableName = 'iaspire.mst_emp_appraisal';
      idField = 'empapp_id';
      break;
    case 'type':
      tableName = 'iaspire.mst_reopen_req_type';
      idField = 'typeid';
      break;
    case 'unit':
      tableName = 'public.mst_unit';
      idField = 'unitid';
      break;
    case 'function':
      tableName = 'public.mst_function';
      idField = 'functionid';
      break;
    case 'bus_desig_name':
      tableName = 'public.mst_business_designation';
      idField = 'bus_desig_id';
      break;
    default:
      throw new Error('Invalid field name');
  }

  const queryResult = await query(
    `SELECT ${idField} FROM ${tableName} WHERE trim(upper(${fieldName})) = trim(upper($1))`,
    [fieldValue],
  );
  if (
    queryResult?.length === 0 &&
    (fieldName === 'duname' ||
      fieldName === 'designationdesc' ||
      fieldName === 'category' ||
      fieldName === 'bandlevel' ||
      fieldName === 'unit' ||
      fieldName === 'function' ||
      fieldName === 'bus_desig_name')
  ) {
    throw new Error(`field does not match with iWMS Master - ${fieldName}`);
  }
  return queryResult[0]?.[idField];
};

export const getUserDetailByUserIdScript = () => {
  const script = ` SELECT *
    FROM public.wms_user us 
    LEFT JOIN iaspire.mst_appraisaltype at ON us.categoryid = at.categoryid
    LEFT JOIN public.mst_bandlevel bl ON bl.bandlevelid = us.bandlevelid
    LEFT JOIN public.mst_designation ds ON ds.designationid = us.designationid
    WHERE us.userid = $1;`;

  return script;
};

export const getReportHeadMappingScript = async (
  duID,
  dhID,
  fhID,
  searchText,
) => {
  let condition1 = '';
  let condition2 = '';
  let condition3 = '';
  // if (searchText === '') {
  if (duID !== null && duID.length > 0) {
    condition1 = `AND (u.duid = ANY(ARRAY[${duID}]::bigint[]))`;
  }
  if (dhID !== '' && dhID.length > 0) {
    condition2 = `AND (u.duhead = ANY(ARRAY[${dhID.map(
      value => `'${value}'`,
    )}]::text[]))`;
  }
  if (fhID !== '' && fhID.length > 0) {
    condition3 = `AND (u.functionalhead = ANY(ARRAY[${fhID.map(
      value => `'${value}'`,
    )}]::text[]))`;
  }
  // }
  const result = await query(`
  SELECT
    ROW_NUMBER() OVER (ORDER BY employeename) AS serial,
    isnum,
    employeename,
    duid,
    duname,
    level1,
    level1status,
    level2,
    level2status,
    level3,
    level3status,
    duheadid,
    duhead,
    duheadstatus,
    functionalheadid,
    functionalhead,
    fhstatus,
    status,
    pbtype,
    'action' AS action
  FROM (
    SELECT
        u.userid AS isnum,
        u.username AS employeename,
        du.duid AS duid,
        du.duname AS duname,
        rt.username||' ('||rt.userid||')' AS level1,
        rt.useractive AS level1status,
        rth.username||' ('||rth.userid||')' AS level2,
        rth.useractive AS level2status,
        rth2.username||' ('||rth2.userid||')' AS level3,
        rth2.useractive AS level3status,
        dh.userid AS duheadid,
        dh.username||' ('||dh.userid||')' AS duhead,
        dh.useractive AS duheadstatus,
        fh.userid AS functionalheadid,
        fh.username||' ('||fh.userid||')' AS functionalhead,
        fh.useractive AS fhstatus,
        u.useractive AS status,
        u.pbtype AS pbtype
    FROM
        public.wms_user u
    LEFT JOIN public.mst_deliveryunit du ON du.duid = u.itracks_duid
    LEFT JOIN public.wms_user rt ON u.reportingto = rt.userid
    LEFT JOIN public.wms_user rth ON rt.reportingto = rth.userid
    LEFT JOIN public.wms_user rth2 ON rth.reportingto = rth2.userid
    LEFT JOIN public.wms_user dh ON u.duhead = dh.userid
    LEFT JOIN public.wms_user fh ON u.functionalhead = fh.userid
    WHERE
        u.useractive = true
        ${condition1} ${condition2} ${condition3}
  ) AS subquery
  WHERE
    (isnum ILIKE '%${searchText}%') OR (employeename ILIKE '%${searchText}%')
    OR (level1 ILIKE '%${searchText}%') OR (level2 ILIKE '%${searchText}%') OR (level3 ILIKE '%${searchText}%')
    ORDER BY employeename;`);
  return result;
};

// Score and rating

export const scoreAndRatingCreateGroupScript = () => {
  const script = ` INSERT INTO iaspire.mst_rating_group(
     groupname, isactive, created_by, updated_by)
VALUES
    ($1, $2, $3, $4) RETURNING groupid;
`;
  return script;
};
export const scoreAndRatingCreateRatingScript = () => {
  const script = ` INSERT INTO iaspire.mst_rating_value(
     groupid, minvalue, maxvalue, isactive, created_by, updated_by, rating)
    VALUES ($1, $2, $3, $4, $5, $6, $7);
`;
  return script;
};

export const scoreAndRatingGetFromMstUserScript = () => {
  const script = `SELECT
  ROW_NUMBER() OVER (ORDER BY du.duname) AS serial,
  du.duname AS duname,
  bl.bandlevel AS bandlevel,
  ds.designationdesc AS designation,
  du.duid AS duid,
  bl.bandlevelid AS bandlevelid,
  ds.designationid AS designationid,
  'action' AS action,
  CASE WHEN NOT EXISTS(select 1 from iaspire.trn_rating_combination_history where duid=du.duid and
    designationid=ds.designationid and bandlevelid=bl.bandlevelid) THEN true
  END AS hideHistory
  FROM
    public.wms_user us
  JOIN
    public.mst_deliveryunit du ON us.itracks_duid = du.duid
  JOIN
    public.mst_bandlevel bl ON us.bandlevelid = bl.bandlevelid
  JOIN
    public.mst_designation ds ON us.designationid = ds.designationid
  WHERE
    (du.duname ILIKE '%' ||$1 || '%'
    OR bl.bandlevel ILIKE '%' || $1 || '%'
    OR ds.designationdesc ILIKE '%' || $1 || '%')
  AND NOT EXISTS (
    SELECT 1
    FROM iaspire.trn_rating_combination rc
    WHERE rc.duid = du.duid
      AND rc.bandlevelid = bl.bandlevelid
      AND rc.designationid = ds.designationid
  ) group by ds.designationdesc,bl.bandlevel, du.duid , bl.bandlevelid, ds.designationid;`;
  return script;
};

export const scoreAndRatingGetFromMstUserWithGroupScript = () => {
  const script = `
  SELECT 
    ROW_NUMBER() OVER (ORDER BY duname) AS serial,
    du.duname AS duname,
    du.duid AS duid,
    bl.bandlevel AS bandlevel,
    ds.designationdesc AS designation,
    du.duid AS duid,
    bl.bandlevelid AS bandlevelid,
    ds.designationid AS designationid,
    'action' AS action,
    false::boolean AS isSelected,
    CASE WHEN NOT EXISTS(select 1 from iaspire.trn_rating_combination_history where duid=du.duid and
      designationid=ds.designationid and bandlevelid=bl.bandlevelid) THEN true
    END AS hideHistory
  FROM
    public.wms_user us
  JOIN
    public.mst_deliveryunit du ON us.itracks_duid = du.duid
  JOIN
    public.mst_bandlevel bl ON us.bandlevelid = bl.bandlevelid
  JOIN
    public.mst_designation ds ON us.designationid = ds.designationid
   left join iaspire.trn_rating_combination r on r.groupid = $2
   where us.itracks_duid = r.duid 
   and us.bandlevelid = r.bandlevelid  
   and  us.designationid = r.designationid  
  and (du.duname ilike '%' || $1 || '%' OR bl.bandlevel ilike '%' || $1 || '%' OR ds.designationdesc ilike '%' || $1 || '%')
  group by ds.designationdesc,bl.bandlevel, du.duid , bl.bandlevelid, ds.designationid;
  `;
  return script;
};

export const assignGroupRatingScript = () => {
  const script = `
  INSERT INTO iaspire.trn_rating_combination
  (groupid, duid, designationid, bandlevelid, isactive, created_by, updated_by, created_time, updated_time)
VALUES
  ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (duid, designationid, bandlevelid)
DO UPDATE
SET
  groupid = $1,
  isactive = EXCLUDED.isactive,
  updated_by = EXCLUDED.updated_by,
  updated_time = CURRENT_TIMESTAMP`;
  return script;
};
export const scoreAndRatingGetFilterOptionScript = () => {
  const script = ` SELECT * FROM iaspire.mst_rating_group`;
  return script;
};

export const scoreAndRatingGetFilterScript = () => {
  const script = `SELECT * FROM iaspire.trn_rating_combination rc
        LEFT JOIN
            public.mst_deliveryunit du ON rc.duid = du.duid
        LEFT JOIN
            public.mst_bandlevel bl ON rc.bandlevelid = bl.bandlevelid
        LEFT JOIN
            public.mst_designation ds ON rc.designationid = ds.designationid
        WHERE groupid = $1`;
  return script;
};

// Score and rating

export const getEmailTemplate = () => {
  // const script = `SELECT ROW_NUMBER() OVER (ORDER BY notificationid) AS serial,* from wms_notifications WHERE entityid = $1 and isactive = TRUE;`;
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY notificationid) AS serial,* FROM wms_notifications 
  WHERE entityid = $1 AND notificationconfig->>'subject' ILIKE '%' || $2 || '%' AND isactive = TRUE;`;
  return script;
};

export const getDuHeadListScript = () => {
  const script = `SELECT DISTINCT u.duhead AS id,dh.username AS name, false AS isSelected FROM public.wms_user u LEFT 
  JOIN public.wms_user dh ON trim(upper(u.duhead)) = trim(upper(dh.userid)) WHERE u.duhead IS NOT NULL AND dh.username IS NOT NULL`;
  return script;
};

export const getFunctionalHeadistScript = () => {
  const script = `SELECT DISTINCT u.functionalhead AS id,fu.username AS name, false AS isSelected FROM public.wms_user u LEFT 
  JOIN public.wms_user fu ON trim(upper(u.functionalhead)) = trim(upper(fu.userid)) WHERE u.functionalhead IS NOT NULL AND fu.username IS NOT NULL`;
  return script;
};

export const getScoreRatingHistoryScript = () => {
  const script = `select TO_CHAR(his.change_time, 'DD') AS date,
  STRING_AGG(TO_CHAR(his.change_time, 'Mon') || ' ' || TO_CHAR(his.change_time, 'YYYY'),'') AS month,
  jsonb_agg(
    jsonb_build_object(
      'by', (select username from public.wms_user where userid = his.changed_by),
      'from', (SELECT groupname FROM iaspire.mst_rating_group where groupid=old_groupid),
	    'to', (SELECT groupname FROM iaspire.mst_rating_group where groupid=new_groupid)
      )
  ) AS history
  FROM iaspire.trn_rating_combination_history his where his.duid = $1 and his.designationid = $2 and 
  his.bandlevelid = $3 GROUP BY his.change_time`;
  return script;
};

export const insertLineItemValidationScript = () => {
  const script = `
  INSERT INTO iaspire.trn_qpr_lineitem_validation
  (lineitemid, validationid, value1, value2, score, created_by, created_time)
SELECT
  unnest($1::int[]),
  unnest($2::int[]),
  unnest($3::int[]),
  unnest($4::int[]),
  unnest($5::int[]),  -- Assuming rateValid.rateTypeId is of type bigint
  unnest($6::text[]),
  CURRENT_TIMESTAMP
`;
  return script;
};

export const insReOpenRequestScript = () => {
  const script = `INSERT INTO iaspire.trn_reopen_request(
    appraisalid, raised_on, request_remarks, typeid, statusid, created_by)
    VALUES ($1, CURRENT_TIMESTAMP, $2, $3, $4, $5);`;
  return script;
};

export const updatePbReOpenStatus = () => {
  const script = `
    UPDATE iaspire.trn_appraisalmapping
      SET
      statusid=$2,
      updated_by=$3,
      updated_time = CURRENT_TIMESTAMP
      WHERE appraisalid = $1;`;
  return script;
};

export const checkIsDOJAvailable = () => {
  const script = `SELECT doj FROM public.wms_user WHERE userid = $1;`;
  return script;
};

// get duheasd, functionalhead dropdown data
export const getDUHFUHScript = () => {
  const script = `SELECT u.userid AS value, u.username||' ('||u.userid||')' AS label FROM public.wms_user u
    LEFT JOIN public.mst_bandlevel b ON b.bandlevelid = u.bandlevelid AND isactive = true
    WHERE (b.bandlevel ILIKE '%B1%' OR b.bandlevel ILIKE '%B2%' OR b.bandlevel ILIKE '%B3%') AND 
    useractive = true AND u.userid IS NOT NULL AND u.username IS NOT NULL
    ORDER BY u.username;`;
  return script;
};

export const updDUHFUHScript = () => {
  const script = `UPDATE public.wms_user SET duhead = $2, functionalhead = $3, updated_by = $4, updated_time = CURRENT_TIMESTAMP
    WHERE userid = $1 AND useractive = true;`;
  return script;
};
