import { query } from '../../database/postgres.js';

export const insTemplateMst = (templateName, userId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const checkScript = `SELECT templateid FROM iaspire.mst_qpr_template WHERE templatename = $1`;

      const checkResult = await query(checkScript, [templateName]);

      if (checkResult.length > 0) {
        reject(new Error('Template name already exists'));
        return;
      }

      const queryScript = `INSERT INTO iaspire.mst_qpr_template(templatename, created_by) VALUES ($1, $2) RETURNING templateid`;

      const result = await query(queryScript, [templateName, userId]);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updTemplateMst = (templateId, templateName, userId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const checkScript = `SELECT templateid FROM iaspire.mst_qpr_template WHERE templatename = $1 AND templateid <> $2`;

      const checkResult = await query(checkScript, [templateName, templateId]);

      if (checkResult.length > 0) {
        reject(new Error('Template name already exists'));
        return;
      }

      const queryScript = `UPDATE iaspire.mst_qpr_template SET templatename=$2, updated_by=$3, updated_time=now() WHERE templateid = $1 RETURNING templateid`;

      const result = await query(queryScript, [
        templateId,
        templateName,
        userId,
      ]);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insTemplateConfig = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { templateId, duId, bandLvlId, designationId, userId } = info;

      const checkScript =
        'SELECT qpr_tempid FROM iaspire.trn_qpr_template WHERE duid = $1 AND designationid = $2 AND bandlevelid = $3';
      const checkResult = await query(checkScript, [
        duId,
        designationId,
        bandLvlId,
      ]);

      if (checkResult.length > 0) {
        reject(new Error('Combination already exists for another template'));
        return;
      }

      const insertScript = `INSERT INTO iaspire.trn_qpr_template(duid, designationid, bandlevelid, templateid, isactive, created_by)
        VALUES ($1, $2, $3, $4, true, $5) RETURNING qpr_tempid`;
      const result = await query(insertScript, [
        duId,
        designationId,
        bandLvlId,
        templateId,
        userId,
      ]);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updTemplateConfig = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { templateId, qpr_tempid, userId } = info;

      const script = `UPDATE iaspire.trn_qpr_template SET templateid=$1, updated_by=$3, updated_time = NOW() WHERE qpr_tempid=$2 RETURNING qpr_tempid`;
      const result = await query(script, [templateId, qpr_tempid, userId]);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export function get_iAspireSoftDel_query(p_name) {
  let script = '';

  switch (p_name) {
    case 'templateMst':
      script =
        'UPDATE iaspire.mst_qpr_template SET isactive=false, updated_by=$2, updated_time=now() WHERE templateid = $1 RETURNING templateid';
      break;
    case 'templateConfig':
      script =
        'UPDATE iaspire.trn_qpr_template SET isactive=false, updated_by=$2, updated_time=now() WHERE qpr_tempid = $1 RETURNING qpr_tempid';
      break;
    default:
      throw new Error('Invalid Param');
  }

  return script;
}

export function get_iAspireHardDel_query(p_name) {
  let script = '';

  switch (p_name) {
    case 'templateMst':
      script = 'DELETE FROM iaspire.mst_qpr_template WHERE templateid = $1';
      break;
    case 'templateConfig':
      script = 'DELETE FROM iaspire.trn_qpr_template WHERE qpr_tempid = $1';
      break;
    default:
      throw new Error('Invalid Param');
  }

  return script;
}

export const qprMasterGetTemplateDetailsScript = () => {
  const script = `WITH MaxVersion AS (
                      SELECT MAX(tt.versionid) AS max_version
                      FROM iaspire.trn_qpr_lineitem tt
                      WHERE tt.templateid = $1
                  )

                  SELECT json_build_object(
                          'templateId', t.templateid,
                          'templateName', t.templatename,
                          'lineItem', json_agg(
                              json_build_object(
                                  'measureId', m.measureid,
                                  'measureDesc', m.measuredesc,
                                  'asmtParamId', p.parameterid,
                                  'parameterDesc', p.parameterdesc,
                                  'seqNo', l.seqno,
                                  'weightAge', l.weightage,
                                  'rateValid', rates.rateValid,
                                  'notes', l.notes,
                                  'versionId', l.versionid
                              )
                          )
                      ) AS result
                  FROM iaspire.trn_qpr_lineitem l
                  JOIN iaspire.mst_qpr_template t ON t.templateid = l.templateid
                  JOIN iaspire.mst_qpr_parameters p ON p.parameterid = l.parameterid
                  JOIN iaspire.mst_qpr_measures m ON m.measureid = l.measureid
                  LEFT JOIN (
                      SELECT
                          lv.lineitemid,
                          json_agg(
                              json_build_object(
                                  'rateTypeId', vt.validationid,
                                  'rateType', vt.validationtype,
                                  'value1', lv.value1,
                                  'value2', lv.value2,
                                  'score', lv.score
                              )
                          ) AS rateValid
                      FROM
                          iaspire.trn_qpr_lineitem_validation lv
                      JOIN
                          iaspire.mst_qpr_validationtypes vt ON vt.validationid = lv.validationid
                      GROUP BY
                          lv.lineitemid
                  ) AS rates ON rates.lineitemid = l.lineitemid
                  CROSS JOIN MaxVersion mv
                  WHERE t.templateid = $1
                    AND l.versionid = mv.max_version
                  GROUP BY
                      t.templateid, t.templatename, l.versionid
                  ORDER BY
                      t.templateid;`;

  return script;
};

export const qprMasterGetCombinationScript = async (
  duId,
  bandLvlId,
  desigLvlId,
  templateId,
  designationDesc,
) => {
  let condition1 = '';
  let condition2 = '';
  let condition3 = '';
  let condition4 = '';
  if (designationDesc === '') {
    if (duId !== null && duId.length > 0) {
      condition1 = `(us.itracks_duid = ANY(ARRAY[${duId}]::bigint[])) AND`;
    }
    if (bandLvlId !== null && bandLvlId.length > 0) {
      condition2 = `(bl.bandlevelid = ANY(ARRAY[${bandLvlId}]::bigint[])) AND`;
    }
    if (templateId !== null && templateId.length > 0) {
      if (templateId.some(obj => obj === 0)) {
        condition3 = `WHERE (templateid = ANY(ARRAY[${templateId}]::int[]) OR templateid IS NULL) ORDER BY templateid, duname`;
      } else {
        condition3 = `WHERE templateid = ANY(ARRAY[${templateId}]::int[])`;
      }
    }
    if (desigLvlId !== null && desigLvlId.length > 0) {
      condition4 = `(ds.designationid = ANY(ARRAY[${desigLvlId}]::int[])) AND`;
    }
  }
  const result = await query(`WITH qpr_combination_data AS (
    SELECT
    du.duid,
    du.duname AS duname,
    bl.bandlevelid,
    bl.bandlevel AS bandlevel,
    ds.designationid,
    ds.designationdesc AS designation,
    mqpr.templateid AS templateid,
    mqpr.templatename AS templatename,
tqpr.qpr_tempid
FROM
    public.wms_user us
JOIN
    public.mst_deliveryunit du ON us.itracks_duid = du.duid
JOIN
    public.mst_bandlevel bl ON us.bandlevelid = bl.bandlevelid
JOIN
    public.mst_designation ds ON us.designationid = ds.designationid
LEFT JOIN
    iaspire.trn_qpr_template tqpr ON tqpr.duid = du.duid AND tqpr.designationid = ds.designationid
    AND tqpr.bandlevelid = bl.bandlevelid
LEFT JOIN
    iaspire.mst_qpr_template mqpr ON mqpr.templateid = tqpr.templateid
WHERE us.pbtype = 'QPR' AND ${condition1} ${condition2} ${condition4}
   (ds.designationdesc ILIKE '%${designationDesc}%')
   GROUP BY
   du.duid, du.duname, bl.bandlevelid, bl.bandlevel, ds.designationid, ds.designationdesc,
   mqpr.templateid, mqpr.templatename, tqpr.qpr_tempid
ORDER BY
   du.duname, bl.bandlevel, ds.designationdesc ASC
)
SELECT
  ROW_NUMBER() OVER () AS serial,
  *
FROM
  qpr_combination_data ${condition3};`);

  return result;
};
// Function to check if the QPR Line item record exists
const checkQPRLineItemExists = async (appraisalId, lineItemId) => {
  const existsResult = await query(
    `SELECT qpruseritem_id FROM iaspire.trn_qpr_user_lineitem WHERE appraisalid = $1 AND lineitemid = $2;`,
    [appraisalId, lineItemId],
  );
  return existsResult?.length !== 0;
};

const insertQPRLineItem = async (appraisalId, lineItem) => {
  const { lineItemId, reviewScore, reviewerRemarks, modifiedBy } = lineItem;
  const result = await query(
    `INSERT INTO iaspire.trn_qpr_user_lineitem
        (appraisalid, lineitemid, score, remarks, created_by)
        VALUES ($1, $2, $3, $4, $5);`,
    [appraisalId, lineItemId, reviewScore, reviewerRemarks, modifiedBy],
  );
  return result;
};

export const updateQprLineItemReviewScore = async (appraisalId, lineItem) => {
  const { lineItemId, reviewScore, reviewerRemarks, modifiedBy } = lineItem;
  let result;
  if (await checkQPRLineItemExists(appraisalId, lineItemId)) {
    result = await query(
      `UPDATE iaspire.trn_qpr_user_lineitem
        SET score=$3,
        remarks=$4,
        updated_by=$5
      WHERE appraisalid = $1 AND lineitemid = $2;`,
      [appraisalId, lineItemId, reviewScore, reviewerRemarks, modifiedBy],
    );
  } else {
    result = await insertQPRLineItem(appraisalId, lineItem);
  }
  return result;
};

export const getBandLevelScript = async DuList => {
  let condition1 = '';
  if (DuList !== null && DuList.length > 0) {
    condition1 = `AND (du.duid = ANY(ARRAY[${DuList}]::int[]))`;
  }
  const result =
    await query(`SELECT DISTINCT bl.bandlevelid AS id,bl.bandlevel AS name, false AS isSelected 
    FROM public.wms_user us JOIN public.mst_deliveryunit du ON us.itracks_duid = du.duid
    JOIN public.mst_bandlevel bl ON us.bandlevelid = bl.bandlevelid where bl.isactive=true
    ${condition1} order by bl.bandlevel desc`);
  return result;
};

export const getDesignationLevelScript = async (DuList, BandLevelList) => {
  const conditions = [];
  if (DuList !== null && DuList.length > 0) {
    conditions.push(`du.duid = ANY(ARRAY[${DuList}]::int[])`);
  }
  if (BandLevelList !== null && BandLevelList.length > 0) {
    conditions.push(`bl.bandlevelid = ANY(ARRAY[${BandLevelList}]::int[])`);
  }
  const whereClause =
    conditions.length > 0
      ? `AND ( ${
          conditions.length == 2 ? conditions.join(' AND ') : conditions[0]
        })`
      : '';
  const script = `SELECT DISTINCT 
      md.designationid AS id, 
      md.designationdesc AS name, 
      false AS isSelected  
    FROM public.wms_user us
    JOIN public.mst_deliveryunit du 
      ON us.itracks_duid = du.duid AND du.isactive = true
    JOIN public.mst_bandlevel bl 
      ON us.bandlevelid = bl.bandlevelid AND bl.isactive = true
    JOIN public.mst_designation md 
      ON us.designationid = md.designationid 
    WHERE md.isactive = true ${whereClause}
    ORDER BY md.designationdesc ASC
  `;

  const result = await query(script);
  return result;
};

export const getTemplateScript = async (
  DuList,
  BandLevelList,
  designationList,
) => {
  let condition1 = '';
  let condition2 = '';
  let condition3 = '';
  if (DuList !== null && DuList.length > 0) {
    condition1 = `AND (du.duid = ANY(ARRAY[${DuList}]::int[]))`;
  }
  if (BandLevelList !== null && BandLevelList.length > 0) {
    condition2 = `AND (bl.bandlevelid = ANY(ARRAY[${BandLevelList}]::int[]))`;
  }
  if (designationList !== null && designationList.length > 0) {
    condition3 = `AND (md.designationid= ANY(ARRAY[${designationList}]::int[]))`;
  }
  let result = '';
  if (condition1 === '' && condition2 === '' && condition3 === '') {
    result =
      await query(`SELECT DISTINCT mqpr.templateid AS id,mqpr.templatename AS name,false AS isSelected 
      FROM iaspire.mst_qpr_template mqpr ORDER BY mqpr.templatename;`);
  } else {
    result =
      await query(`SELECT DISTINCT mqpr.templateid AS id,mqpr.templatename AS name, false AS isSelected FROM public.wms_user us
  JOIN public.mst_deliveryunit du ON us.itracks_duid = du.duid
  JOIN public.mst_bandlevel bl ON us.bandlevelid = bl.bandlevelid
  JOIN public.mst_designation md on us.designationid = md.designationid 
  JOIN iaspire.trn_qpr_template tqpr ON tqpr.duid = du.duid AND tqpr.bandlevelid = bl.bandlevelid AND tqpr.designationid = md.designationid 
  JOIN iaspire.mst_qpr_template mqpr ON mqpr.templateid = tqpr.templateid AND tqpr.bandlevelid = bl.bandlevelid AND tqpr.designationid = md.designationid
  where bl.isactive=true ${condition1} ${condition2} ${condition3}
  order by mqpr.templatename`);
  }
  return result;
};

export const getQprMasterDropDownDataScript = master => {
  let script = '';
  switch (master) {
    case 'measure':
      script =
        'SELECT measureid::bigint AS column_id, measuredesc AS column_name FROM iaspire.mst_qpr_measures WHERE isactive = true;';
      break;
    case 'parameter':
      script =
        'SELECT parameterid::bigint AS column_id, parameterdesc AS column_name FROM iaspire.mst_qpr_parameters WHERE isactive = true;';
      break;
    case 'weightage':
      script = `SELECT validationid::bigint AS column_id, validationtype AS column_name FROM iaspire.mst_qpr_validationtypes WHERE isactive = true;`;
      break;
    case 'template':
      script = `SELECT templateid::bigint AS column_id, templatename AS column_name FROM iaspire.mst_qpr_template WHERE isactive = true;`;
      break;
    case 'appraisaltype':
      script = `SELECT DISTINCT appraisaltype AS column_name FROM iaspire.mst_appraisaltype WHERE isactive = true;`;
      break;
    case 'empstatus':
      script = `select 'Active' as EMP_STATUS union all select 'InActive'  as EMP_STATUS union all select 'Serving Notice'  as EMP_STATUS union all select 'Active (ML)' as EMP_STATUS ;`;
      break;
    case 'employeetype':
      script = `SELECT DISTINCT UPPER(REGEXP_REPLACE(userid, '[0-9]+$', '')) AS emptype FROM public.wms_user 
          WHERE useractive = true AND userid is not null AND userid != ' ' AND userid != '';`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return script;
};

export const getQprScriptTemplateDataScript = () => {
  const script = `SELECT
  t.templateid,
  t.templatename,
  json_agg(
      json_build_object(
          'measureId', l.measureid,
          'measureDesc', m.measuredesc,
          'asmtParamId', l.parameterid,
          'parameterDesc', l.userdesc,
          'seqNo', l.seqno,
          'weightAge', l.weightage,
          'rateValid', rate_valid_array,
          'notes', l.notes,
          'versionId', l.versionid,
          'fieldType', 'dropdown',
          'action', 'action',
          'isSave', true,
          'hideRating', (
              SELECT CASE WHEN COUNT(*) >= 1 THEN false ELSE true END
              FROM iaspire.trn_qpr_lineitem_validation WHERE lineitemid = l.lineitemid
          )
      ) ORDER BY l.lineitemid
  ) AS template
FROM
  iaspire.mst_qpr_template t
LEFT JOIN
  iaspire.trn_qpr_lineitem l ON l.templateid = t.templateid
  LEFT JOIN iaspire.mst_qpr_measures m ON l.measureid = m.measureid
  LEFT JOIN iaspire.mst_qpr_parameters p ON l.parameterid = p.parameterid
LEFT JOIN
  (
      SELECT
          v.lineitemid,
          json_agg(
              json_build_object(
                  'rateTypeId', v.validationid,
                  'rateType', vt.validationtype,
                  'value1', v.value1,
                  'value2', v.value2,
                  'score', v.score,
                  'action', 'action'
              )
          ) AS rate_valid_array
      FROM
          iaspire.trn_qpr_lineitem_validation v
      JOIN
          iaspire.trn_qpr_lineitem l ON v.lineitemid = l.lineitemid  -- Adjusted join condition
      JOIN iaspire.mst_qpr_validationtypes vt ON v.validationid = vt.validationid
      GROUP BY
          v.lineitemid, l.notes  -- Added l.notes to GROUP BY clause
  ) v ON v.lineitemid = l.lineitemid
WHERE
  t.templateid = $1
  and l.versionid  in (select max(versionid) from iaspire.trn_qpr_lineitem  where templateid = $1)
GROUP BY
  t.templatename, t.templateid;`;
  return script;
};
