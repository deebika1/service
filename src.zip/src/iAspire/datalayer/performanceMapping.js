import { query } from '../../database/postgres.js';

export const getPerformanceTypeMapped = async (type, duId, searchText) => {
  let result = null;
  if (duId === '') {
    duId = null;
  }
  // if (searchText !== '') {
  //   duId = null;
  //   type = '';
  // }
  if (type === '') {
    result = await query(
      `select ROW_NUMBER() OVER (ORDER BY d.duname) AS serial,
      d.duname,
      d.duid,
      u.username,
      u.userid,
      CONCAT((select username from public.wms_user where userid = u.reportingto), ' (', u.reportingto, ')')::VARCHAR as reportingto,
      u.bandlevelid,
      u.designationid,
      u.pbtype AS appraisaltype,
      b.bandlevel,
      des.designationdesc,
      'action' as action,
      false AS isedit,
      CASE
        WHEN u.pbtype = 'YTD' THEN false
        else true
      END AS hideedit,
      CASE WHEN NOT EXISTS(SELECT 1 FROM public.application_type_history WHERE user_id = u.userid) THEN true
      END AS hidehistory
      from public.wms_user u
      --   LEFT JOIN 
      --   public.org_mst_deliveryunit odu ON odu.duid=u.duid and odu.isactive=true
  	  LEFT JOIN 
      public.mst_deliveryunit d ON d.duid = u.itracks_duid and d.isactive=true
      LEFT JOIN 
        iaspire.mst_appraisaltype app ON app.categoryid = u.categoryid and app.isactive=true
      LEFT JOIN
        public.mst_bandlevel b ON b.bandlevelid= u.bandlevelid and b.isactive=true
      LEFT JOIN
        public.mst_designation des ON des.designationid=u.designationid and des.isactive=true
      WHERE 
        u.useractive=true and (${duId} is null or d.duid = ${duId}) and 
        (u.userid ilike '%${searchText}%' or u.username ilike '%${searchText}%')
        order by d.duname;`,
    );
  }
  if (type === 'KRA' || type === 'QPR') {
    result = await query(
      `select ROW_NUMBER() OVER (ORDER BY d.duname) AS serial,
      d.duname,
      d.duid,
      u.username,
      u.userid,
      CONCAT((select username from public.wms_user where userid = u.reportingto), ' (', u.reportingto, ')')::VARCHAR as reportingto,
      u.bandlevelid,
      u.designationid,
      u.pbtype AS appraisaltype,
      b.bandlevel,
      des.designationdesc,
      'action' as action,
      false AS isedit,
      CASE
        WHEN u.pbtype = 'YTD' THEN false
        else true
      END AS hideedit,
      CASE WHEN NOT EXISTS(SELECT 1 FROM public.application_type_history WHERE user_id = u.userid) THEN true
      END AS hidehistory
      from public.wms_user u
      --   LEFT JOIN 
      --   public.org_mst_deliveryunit odu ON odu.duid=u.duid and odu.isactive=true
      LEFT JOIN 
      public.mst_deliveryunit d ON d.duid = u.itracks_duid and d.isactive=true
      LEFT JOIN 
        iaspire.mst_appraisaltype app ON app.categoryid = u.categoryid and app.isactive=true
      LEFT JOIN
        public.mst_bandlevel b ON b.bandlevelid= u.bandlevelid and b.isactive=true
      LEFT JOIN
        public.mst_designation des ON des.designationid=u.designationid and des.isactive=true
      WHERE u.useractive=true and u.pbtype = '${type}'
        AND (${duId} is null or d.duid = ${duId}) and 
        (u.userid ilike '%${searchText}%' or u.username ilike '%${searchText}%')
        order by d.duname;`,
    );
  }
  if (type === 'YTD') {
    result = await query(
      `select ROW_NUMBER() OVER (ORDER BY d.duname) AS serial,
      d.duname,
      d.duid,
      u.username,
      u.userid,
      CONCAT((select username from public.wms_user where userid = u.reportingto), ' (', u.reportingto, ')')::VARCHAR as reportingto,
      u.bandlevelid,
      u.designationid,
      u.pbtype AS appraisaltype,
	    b.bandlevel,
      des.designationdesc,
      'action' as action,
      false AS isedit,
      CASE
        WHEN u.pbtype = 'YTD' THEN false
        else true
      END AS hideedit,
      CASE WHEN NOT EXISTS(SELECT 1 FROM public.application_type_history WHERE user_id = u.userid) THEN true
      END AS hidehistory
      from public.wms_user u
      --   LEFT JOIN 
      --   public.org_mst_deliveryunit odu ON odu.duid=u.duid and odu.isactive=true
  	  LEFT JOIN 
      public.mst_deliveryunit d ON d.duid = u.itracks_duid and d.isactive=true
      LEFT JOIN 
      iaspire.mst_appraisaltype app ON app.categoryid = u.categoryid and app.isactive=true
      LEFT JOIN
        public.mst_bandlevel b ON b.bandlevelid= u.bandlevelid and b.isactive=true
      LEFT JOIN
        public.mst_designation des ON des.designationid=u.designationid and des.isactive=true
      WHERE u.useractive=true and u.pbtype = 'YTD'
      and (${duId} is null or d.duid = ${duId}) and 
      (u.userid ilike '%${searchText}%' or u.username ilike '%${searchText}%')
      order by d.duname;`,
    );
  }
  return result;
};

export const getTempId = async userId => {
  //   const tempId = await query(`
  //   SELECT te.templateid
  // FROM iaspire.trn_appraisalmapping ap
  // LEFT JOIN public.wms_user u ON u.userid = ap.employeecode
  // LEFT JOIN public.org_mst_deliveryunit odu ON odu.duid = u.duid AND odu.isactive = true
  // LEFT JOIN public.mst_deliveryunit d ON d.duid = odu.itrackduid AND d.isactive = true
  // LEFT JOIN iaspire.trn_qpr_template te ON te.duid = d.duid and te.isactive=true
  // AND te.designationid = u.designationid
  // AND te.bandlevelid = u.bandlevelid
  // WHERE ap.appraisalid = ${appId} AND ap.appraisaltype = 'QPR' and u.useractive=true;
  //   `);
  const tempId = await query(`
  SELECT te.templateid 
FROM public.wms_user u
LEFT JOIN public.mst_deliveryunit d ON d.duid = u.itracks_duid AND d.isactive = true
LEFT JOIN iaspire.trn_qpr_template te ON te.duid = d.duid and te.isactive=true
AND te.designationid = u.designationid AND te.bandlevelid = u.bandlevelid
WHERE u.userid = '${userId}' AND u.useractive=true;
  `);
  return tempId[0].templateid || 0;
};

// export const updatePerformanceMap = async (
//   appraisalId,
//   appraisalType,
//   updated_by,
//   temId,
//   statusId,
// ) => {
//   await query(
//     `UPDATE iaspire.trn_appraisalmapping
//     SET appraisaltype = $2, statusid = $3 ,templateid = $4,updated_by = $5,updated_time = CURRENT_TIMESTAMP
//     WHERE appraisalid = $1;
//     `,
//     [appraisalId, appraisalType, statusId, temId, updated_by],
//   );
//   const historyData = await query(
//     `SELECT * FROM iaspire.trn_appraisalmapping WHERE appraisalid = ${appraisalId}`,
//   );
//   return historyData;
// };

export const updatePerformanceMap = async (
  userId,
  appraisalType,
  updated_by,
) => {
  const result = await query(
    `UPDATE public.wms_user SET pbtype = $2, updated_by= $3 where userid = $1;`,
    [userId, appraisalType, updated_by],
  );
  // const historyData = await query(
  //   `SELECT * FROM iaspire.trn_appraisalmapping WHERE appraisalid = ${appraisalId}`,
  // );
  return result;
};

export const insertPerformanceTypeHistory = async (histData, updatedby) => {
  const {
    appraisalid,
    employeecode,
    quartercode,
    appraisaltype,
    statusid,
    templateid,
    created_by,
    created_time,
    updated_by,
    updated_time,
  } = histData[0];
  const result = await query(
    `INSERT INTO iaspire.trn_appraisalmapping_history (
  appraisalid,
  employeecode,
  quartercode,
  appraisaltype,
  statusid,
  templateid,
  created_by,
  created_time,
  updated_by,
  updated_time,
  changed_by,
  changed_time
)
VALUES (
  $1,
  $2,
  $3,
  $4,
  $5,
  $6,
  $7,
  $8,
  $9,
  $10,
  $11,
  CURRENT_TIMESTAMP
);
`,
    [
      appraisalid,
      employeecode,
      quartercode,
      appraisaltype,
      statusid,
      templateid,
      created_by,
      created_time,
      updated_by,
      updated_time,
      updatedby,
    ],
  );
  return result;
};

export const getHistoryPerformanceMap = () => {
  // const result = await query(`
  // SELECT * FROM
  // iaspire.trn_appraisalmapping_history where appraisalid=${appId}
  // `);
  const script = `SELECT TO_CHAR(ah.changed_on, 'DD') AS date,
  STRING_AGG(TO_CHAR(ah.changed_on, 'Mon') || ' ' || TO_CHAR(ah.changed_on, 'YYYY'),'') AS month,
  jsonb_agg(
    jsonb_build_object(
      'by', (select username from public.wms_user where userid = ah.changed_by),
      'from', (ah.old_app_type),
      'to', (ah.new_app_type)
    )
  ) AS history 
  FROM public.application_type_history ah WHERE ah.user_id = $1 GROUP BY ah.changed_on,ah.changed_by`;
  return script;
};

export const getAppraisalTypeforPerformanceTypeMapping = () => {
  // const result = await query(
  //   `SELECT distinct appraisaltype AS value, appraisaltype AS label FROM iaspire.mst_appraisaltype order by appraisaltype`,
  // );
  const result = `SELECT DISTINCT a.appraisaltype AS value, a.appraisaltype AS label FROM iaspire.mst_appraisaltype a
  LEFT JOIN public.wms_user u ON a.categoryid = u.categoryid WHERE u.userid = $1 ORDER BY a.appraisaltype`;
  return result;
};
