import { query } from '../../database/postgres.js';

export const getPBEmpReportScript = async (
  duID,
  quarterCode,
  statusID,
  pbType,
  empStatus,
  searchText,
  empType,
  key,
  fromDate,
  toDate,
) => {
  let condition1 = '';
  let condition2 = '';
  let condition3 = '';
  let condition4 = '';
  let condition5 = '';
  let condition6 = '';
  let condition7 = '';
  let condition8 = '';
  let check = 1;

  if (duID !== null && duID.length > 0) {
    condition1 = `AND (usr.itracks_duid = ANY(ARRAY[${duID}]::bigint[]))`;
  }
  if (quarterCode !== '' && quarterCode.length > 0) {
    condition2 = `AND (q.quartercode = ANY(ARRAY[${quarterCode.map(
      value => `'${value}'`,
    )}]::text[]))`;
  }
  if (statusID !== null && statusID.length > 0) {
    condition3 = `AND ( select  case when  goal_deadline >  current_date and alias_name is null then 
      (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_EXPIRED')
      when alias_name is null and goal_deadline <  current_date then 
      (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_EMPLOYEE')
      else 
      (SELECT statusid FROM iaspire.mst_status WHERE status = subquery.status)
      end = ANY(ARRAY[${statusID}]::bigint[]))`;
  }
  if (pbType !== '' && pbType.length > 0) {
    condition4 = `AND (usr.pbtype = ANY(ARRAY[${pbType.map(
      value => `'${value}'`,
    )}]::text[]))`;
  }
  if (empStatus !== '' && empStatus.length > 0) {
    condition5 = `AND (case when usr.serving_notice = true then   'Serving Notice'  when app.ismlentry = true then 'Active (ML)' 
    when usr.useractive   = true then 'Active' else 'InActive' END  = ANY(ARRAY[${empStatus.map(
      value => `'${value}'`,
    )}]::text[]))`;
  }
  if (searchText !== '') {
    condition6 = ` and  (('${searchText}'::text IS NULL OR trim(upper(usr.userid)) ILIKE '%' || trim(upper('${searchText}')) || '%') or
    ('${searchText}'::text IS NULL OR trim(upper(usr.username)) ILIKE '%' || trim(upper('${searchText}')) || '%'))`;
  }
  if (empType !== '' && empType.length > 0) {
    condition7 = `AND (usr.userid ILIKE ANY(ARRAY[${empType.map(
      value => `'%${value}%'`,
    )}]::text[]))`;
  }
  if (key == 'doj' && fromDate !== '' && toDate !== '') {
    condition8 = `AND usr.doj BETWEEN '${fromDate}' AND '${toDate}'`;
  }
  if (key == 'doe' && fromDate !== '' && toDate !== '') {
    condition8 = `AND usr.relievingdate BETWEEN '${fromDate}' AND '${toDate}'`;
  }

  if (
    duID.length <= 0 &&
    quarterCode.length <= 0 &&
    statusID.length <= 0 &&
    pbType.length <= 0 &&
    empStatus.length <= 0 &&
    empType.length <= 0 &&
    (fromDate == '' || toDate == '')
  ) {
    check = 0;
  }
  console.log(
    'check',
    condition1,
    condition2,
    condition3,
    condition4,
    condition5,
    condition6,
    condition7,
    condition8,
  );
  const result = await query(`
  SELECT
  ROW_NUMBER() OVER (ORDER BY quarter, employee_name) AS serial,
  employee_status,
  employee_status_clr,
  employee_code,
  employee_name,
  du,
  bandlevel, 
  designation,
  quarter, 
  total_score as pb_totalscore,         
  pb_approved_date::varchar,
  paid_date::varchar,
 case when  goal_deadline <  current_date and alias_name is null then 
 (SELECT status FROM iaspire.mst_status WHERE alias_name = 'GOAL_EXPIRED')
 when alias_name is null and goal_deadline > current_date then 
 (SELECT status FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_EMPLOYEE')
 else 
 status
 end as status,
  status_completed,
  pbstatus_completed,
  notes,holdreason,pbhold,holdedby,
  appraisalid,
  case when  goal_deadline < current_date and alias_name is null then 
 (SELECT status_category FROM iaspire.mst_status WHERE alias_name = 'GOAL_EXPIRED')
 when alias_name is null and goal_deadline >  current_date then 
 (SELECT status_category FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_EMPLOYEE')
 else 
  statusclass
end as statusclass,
  pb_eligible,
  case when appraisalid is null then true 
  when status in (select status from iaspire.mst_status where alias_name in
('RDY_PAID','PAID')) then true 
else false end as ishold  ,goal_deadline,
  action,
  pbtype,
  doj, relievingdate AS doe, employeetype
FROM (
    SELECT
    case when usr.serving_notice = true then   'Serving Notice' 
      when app.ismlentry = true then 'Active (ML)' 
     when usr.useractive   = true then 'Active' else 'InActive' END as employee_status,
     case when usr.useractive   = true then 'success' else 'pending' END as employee_status_clr,
    usr.userid as employee_code,
    usr.username as employee_name,
    itrackdu.duname as du,
    bl.bandlevel as bandlevel, 
    ds.designationdesc as designation,
    q.quartercode as quarter, 
    CASE
    WHEN app.score is null and sts.status IN ('REVIEW_EXPIRED', 'GOAL_EXPIRED') THEN '0'
    WHEN app.score is null  AND sts.status NOT IN ('REVIEW_EXPIRED', 'GOAL_EXPIRED') THEN '-'
    ELSE  round((coalesce(app.score,0)+coalesce(app.additionalscore,0)) ::numeric,1) ::varchar
    END AS total_score,        
    app.reviewcompleteddate::date as pb_approved_date,
    app.pb_paid_date::date as paid_date,
    case when app.pb_hold_status is not null then  (SELECT status FROM iaspire.mst_status WHERE alias_name = 'HOLD')  else  sts.status end as status ,
    case when sts.alias_name   = 'REVIEW_COMPLETED' then true else false END ::boolean as status_completed,
    case when sts.alias_name   = 'PAID' then true else false END ::boolean as pbstatus_completed,
    app.pb_notes as notes,
    app.pb_hold_reason as holdreason,
    case when app.pb_on_hold is null then false else app.pb_on_hold end   as pbhold,
    u.username as holdedby,
    app.appraisalid ,
    CASE  when app.appraisalid  in (SELECT a.appraisalid 
      FROM iaspire.trn_appraisalmapping a
      JOIN iaspire.trn_closing_date_range d ON a.reviewcompleteddate ::date <= d.end_date ::date
      WHERE 
      EXTRACT(MONTH FROM d.end_date) = EXTRACT(MONTH FROM CURRENT_DATE) AND 
      EXTRACT(YEAR FROM d.end_date) = EXTRACT(YEAR FROM CURRENT_DATE)
) then true else false end pb_eligible,
      case when app.pb_hold_status is not null then  (SELECT status_category FROM iaspire.mst_status WHERE alias_name = 'HOLD') else  sts.status_category  end as statusclass,
     q.goal_deadline,
     sts.alias_name,
    'action'  as action,
    usr.pbtype as pbtype,
    usr.doj,
    CASE WHEN usr.useractive = false then usr.relievingdate::text
	  ELSE '-' END as relievingdate,
    UPPER(REGEXP_REPLACE(usr.userid, '[0-9]+$', '')) AS employeetype
     FROM 
         public.wms_user  usr
     LEFT JOIN  
         iaspire.mst_quarters q ON 1 = 1   
     LEFT JOIN 
         public.mst_deliveryunit itrackdu ON usr.itracks_duid = itrackdu.duid
     LEFT JOIN 
         iaspire.trn_appraisalmapping app ON app.employeecode = usr.userid and app.quartercode = q.quartercode
     LEFT JOIN 
         public.mst_bandlevel bl ON bl.bandlevelid = usr.bandlevelid
     LEFT JOIN  
         public.mst_designation ds ON ds.designationid = usr.designationid
     LEFT JOIN 
         iaspire.mst_status sts ON sts.statusid = app.statusid
     LEFT JOIN 
         public.wms_user u ON u.userid = app.pb_updated_by
     LEFT JOIN  
         iaspire.mst_quarters mq ON mq.quartercode = CONCAT('Q', EXTRACT(QUARTER FROM CURRENT_DATE) - 1, 'Y', EXTRACT(YEAR FROM CURRENT_DATE))
   WHERE 1 = ${check}
  ${condition1} ${condition2}  ${condition4}  ${condition5} ${condition6} ${condition7} ${condition8}
      group by  usr.useractive ,
      usr.userid ,app.ismlentry,
      usr.username ,
      itrackdu.duname ,
      bl.bandlevel, q.quartercode,
      ds.designationdesc,
      app.quartercode, 
      app.score ,     app.additionalscore,    app.pb_on_hold,
      app.reviewcompleteddate ,sts.status_category,
      app.pb_paid_date ,u.username,
      sts.status,sts.alias_name ,mq.goal_deadline,
      app.pb_notes, app.pb_hold_reason,app.appraisalid
) AS subquery where  1 = 1 ${condition3} 
ORDER BY quarter, employee_name;
`);

  return result;
};

export const insertClosingDateRangeScript = (
  startDate,
  endDate,
  finTransfer,
  userID,
  rangeID,
) => {
  let script;

  if (!rangeID) {
    script = `
        INSERT INTO iaspire.trn_closing_date_range (start_date, end_date, MONTH, YEAR, fin_transfer, created_by, updated_by)
        VALUES ('${startDate}'::date, '${endDate}'::date, EXTRACT(MONTH FROM TIMESTAMP '${endDate}'), EXTRACT(YEAR FROM TIMESTAMP '${endDate}'), ${finTransfer}, '${userID}', '${userID}');
      `;
  } else {
    script = `
        UPDATE iaspire.trn_closing_date_range
        SET end_date = '${endDate}'::date,
            MONTH = EXTRACT(MONTH FROM TIMESTAMP '${endDate}'),
            YEAR = EXTRACT(YEAR FROM TIMESTAMP '${endDate}'),
            fin_transfer = ${finTransfer},
            updated_by = '${userID}'
        WHERE rangeid = ${rangeID};
      `;
  }

  return script;
};

export const getClosingDateRangeScript = date => {
  const script = `
  SELECT 
  start_date::varchar AS start_date,
  end_date::varchar AS end_date,
  u.username || '(' || t.updated_by || ')' AS changes_by,
  rangeid
FROM 
  iaspire.trn_closing_date_range t
JOIN 
  wms_user u ON u.userid = t.updated_by
WHERE 
  extract(month FROM DATE '${date}') = extract(month FROM end_date)
  AND extract(year FROM DATE '${date}') = extract(year FROM end_date)
ORDER BY 
updated_date DESC
LIMIT 1   `;

  return script;
};

export const getAddScoreScript = appID => {
  const script = `
    SELECT 
        u.username || '(' || a.updated_by || ')' AS last_approvedby,
        additionalscore_remarks AS comments,
        (a.updated_time::date)::varchar AS last_approvedon
    FROM  
        iaspire.trn_appraisalmapping a
    JOIN 
        wms_user u ON a.updated_by = u.userid 
    WHERE 
        additionalscore_remarks IS NOT NULL
        AND statusid IN (
            SELECT statusid 
            FROM iaspire.mst_status
            WHERE alias_name IN ('REVIEW_PENDING_L2', 'ADS_DUH', 'ADS_FH', 'ADS_HR', 'REVIEW_COMPLETED','RDY_PAID','PAID')
        )
        AND appraisalid = '${appID}';
  `;
  return script;
};

export const updateEmpStsScript = async (userID, appID) => {
  const script = `
    UPDATE iaspire.trn_appraisalmapping
    SET statusid = select statusid from iaspire.mst_status where alias_name = 'RDY_PAID'),
        pb_updated_by = '${userID}',
        pb_updated_time = current_time 
    WHERE appraisalid =  '${appID}';
      `;
  return script;
};

export const updatePBNoteScript = async (note, userID, appID) => {
  const script = `
    UPDATE iaspire.trn_appraisalmapping
    SET pb_notes = '${note}',
        pb_updated_by = '${userID}',
        pb_updated_time = CURRENT_TIMESTAMP  
    WHERE appraisalid =  '${appID}'::int;
      `;

  return script;
};

export const updateHoldScript = async (reason, userID, appID) => {
  const script = `
    UPDATE iaspire.trn_appraisalmapping
    SET pb_prev_status = statusid,
        pb_hold_status = (select statusid from iaspire.mst_status where alias_name = 'HOLD'),
        pb_hold_reason = '${reason}',
        pb_on_hold    = true,
        pb_updated_by = '${userID}',
        pb_updated_time = CURRENT_TIMESTAMP  
    WHERE appraisalid =  '${appID}'::int
      and statusid  not in (select statusid from iaspire.mst_status where alias_name in ('RDY_PAID','PAID'));
      `;
  return script;
};

export const updateUnHoldScript = async (reason, userID, appID) => {
  const script = `
    UPDATE iaspire.trn_appraisalmapping
    SET pb_prev_status = statusid,
        pb_hold_status = null,
        pb_hold_reason = '${reason}',
        pb_on_hold    = false,
        pb_updated_by = '${userID}',
        pb_updated_time = CURRENT_TIMESTAMP  
    WHERE appraisalid =  '${appID}'::int
    and statusid  not in (select statusid from iaspire.mst_status where alias_name in ('RDY_PAID','PAID'));
      `;
  return script;
};

export const updateFinanceStsScript = async (userID, appID) => {
  const script = `
    UPDATE iaspire.trn_appraisalmapping
    SET statusid = (select statusid from iaspire.mst_status where alias_name = 'RDY_PAID'),
        pb_updated_by = '${userID}',
        pb_updated_time = CURRENT_TIMESTAMP 
    WHERE appraisalid =   ANY(ARRAY[${appID}]::bigint[]) 
      and appraisalid IN (
        SELECT a.appraisalid 
        FROM iaspire.trn_appraisalmapping a
        JOIN iaspire.trn_closing_date_range d ON a.reviewcompleteddate <= d.end_date 
        WHERE 
            EXTRACT(MONTH FROM d.end_date) = EXTRACT(MONTH FROM CURRENT_DATE) AND 
            EXTRACT(YEAR FROM d.end_date) = EXTRACT(YEAR FROM CURRENT_DATE)
    )
      and statusid  = (select statusid from iaspire.mst_status where alias_name = 'REVIEW_COMPLETED');`;

  return script;
};

export const updateEmpPaidScript = async (paidDate, userID, appID) => {
  const script = `
  UPDATE iaspire.trn_appraisalmapping
  SET 
      statusid = (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'PAID'),
      pb_paid_date = '${paidDate}',
      pb_updated_by = '${userID}',
      pb_updated_time = CURRENT_TIMESTAMP 
  WHERE 
      appraisalid IN (
          SELECT a.appraisalid 
          FROM iaspire.trn_appraisalmapping a
          JOIN iaspire.trn_closing_date_range d ON a.reviewcompleteddate <= d.end_date
      )
      AND appraisalid = ANY(ARRAY[${appID}]::bigint[]) 
      AND statusid IN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'RDY_PAID');
      `;

  return script;
};

export const getPBFinReportScript = async (
  year,
  month,
  statusID,
  unit,
  searchText,
) => {
  let condition1 = '';
  let condition2 = '';
  let condition3 = '';
  let condition4 = '';
  let condition5 = '';
  let check = 1;
  if (
    year.length <= 0 &&
    month.length <= 0 &&
    statusID.length <= 0 &&
    unit.length <= 0
  ) {
    check = 0;
  }

  if (year !== '' && year.length > 0) {
    condition1 = `AND(EXTRACT(YEAR FROM app.reviewcompleteddate) = ANY(ARRAY[${year.map(
      value => `'${value}'::int`,
    )}]::int[]))`;
  }

  if (month !== '' && month.length > 0) {
    condition2 = `AND(EXTRACT(MONTH FROM app.reviewcompleteddate) = ANY(ARRAY[${month.map(
      value => `'${value}'::int`,
    )}]::int[]))`;
  }

  if (statusID !== null && statusID.length > 0) {
    condition3 = `AND ( app.statusid= ANY(ARRAY[${statusID}]::bigint[]))`;
  }
  if (unit !== null && unit.length > 0) {
    condition4 = `AND (usr.unitid = ANY(ARRAY[${unit}]::bigint[]))`;
  }
  if (searchText !== '') {
    condition5 = ` and  (('${searchText}'::text IS NULL OR trim(upper(usr.userid)) ILIKE '%' || trim(upper('${searchText}')) || '%') or
    ('${searchText}'::text IS NULL OR trim(upper(usr.username)) ILIKE '%' || trim(upper('${searchText}')) || '%'))`;
  }

  const result = await query(`
  SELECT
  ROW_NUMBER() OVER (ORDER BY quarter,employee_name) AS serial,
  employee_code,
  employee_name,
  du,
  bandlevel, 
  designation,
  quarter, 
  doj::varchar,
  quarter_wrked_days,
  round(total_score::numeric,1) as pb_totalscore, 
  pb_paid_date::varchar,
  status,
  status_completed,  
  statusclass,
  appraisalid ,unitid
  FROM (
    SELECT
    usr.userid as employee_code,
    usr.username as employee_name,
    itrackdu.duname as du,
    bl.bandlevel as bandlevel, 
    ds.designationdesc as designation,
    app.quartercode as quarter, 
    usr.doj::date,
    case when usr.doj between  q.startdate and  q.enddate then  q.enddate - usr.doj
      else q.enddate - q.startdate end  as quarter_wrked_days,
      coalesce(app.score,0)+coalesce(app.additionalscore,0)  as total_score,         
    app.pb_paid_date::date as pb_paid_date,
    COALESCE(sts.status, (SELECT status FROM iaspire.mst_status WHERE alias_name = 'GOAL_PENDING_EMPLOYEE')) as status,
    case when sts.alias_name   = 'PAID' then false else true END ::boolean as status_completed,    
    sts.status_category as statusclass,
    app.appraisalid ,usr.unitid
     FROM 
         public.wms_user  usr
     JOIN 
         public.mst_deliveryunit itrackdu ON usr.itracks_duid = itrackdu.duid
     LEFT JOIN 
         iaspire.trn_appraisalmapping app ON app.employeecode = usr.userid
     JOIN 
         public.mst_bandlevel bl ON bl.bandlevelid = usr.bandlevelid
     JOIN 
         iaspire.mst_quarters  q ON q.quartercode = app.quartercode    
     JOIN  
         public.mst_designation ds ON ds.designationid = usr.designationid
     LEFT JOIN 
         iaspire.mst_status sts ON sts.statusid = app.statusid
    where sts.alias_name in ('RDY_PAID','PAID') 
    and 1 = ${check}  ${condition1} ${condition2} ${condition3}  ${condition4}  ${condition5}
    group by 
    usr.userid ,app.ismlentry,
    usr.username ,
    itrackdu.duname ,
    bl.bandlevel, 
    ds.designationdesc,sts.status_category,
    app.appraisalid ,
    app.quartercode, 
    app.score ,   app.additionalscore,      
    app.pb_paid_date , usr.doj,q.startdate,q.enddate,
    sts.status,sts.alias_name ,usr.unitid
) AS subquery
  ORDER BY quarter,employee_name;`);
  return result;
};

export const getMasterDataScript = master => {
  const script = `
  SELECT id, value
  FROM (
      SELECT DISTINCT 
          SUBSTRING(quartercode, 4, 4)::text AS id,
          SUBSTRING(quartercode, 4, 4)::text AS value
      FROM iaspire.mst_quarters
      WHERE 'YEAR' = '${master}'
      UNION ALL
      SELECT 
          EXTRACT(MONTH FROM (generate_series)::DATE)::text AS id,
          TO_CHAR(DATE_TRUNC('month', (generate_series)::DATE), 'Month')::text AS value
      FROM generate_series(
               DATE_TRUNC('year', CURRENT_DATE),
               DATE_TRUNC('year', CURRENT_DATE) + INTERVAL '11 months',
               '1 month'
           ) AS gs(generate_series)
      WHERE 'MONTH' = '${master}'
      UNION ALL
      SELECT id::text,
             value::text
      FROM (
             SELECT 'Active' AS id,
                    'Active' AS value
             UNION ALL
             SELECT 'InActive' AS id,
                    'InActive' AS value
             UNION ALL
             SELECT 'Active (ML)' AS id,
                    'Active (ML)' AS value
                    UNION ALL
                    SELECT 'Serving Notice' AS id,
                           'Serving Notice' AS value
                    
           ) AS Q
      WHERE 'EMP' = '${master}'
      UNION ALL
      SELECT unitid::text AS id, 
             unit::text AS value
      FROM mst_unit wmu 
      WHERE isactive = true
       and 'UNIT' = '${master}'
       union all      
  select statusid ::text AS id,status  AS value 
  from iaspire.mst_status where alias_name in ('RDY_PAID','PAID')
     and 'STATUS' = '${master}'  
  ) AS result;
  `;
  return script;
};

export const getRoleAcrScript = async roleID => {
  const script = `SELECT CASE WHEN roleacronym = 'SHR' THEN true ELSE false END AS role FROM PUBLIC.wms_role WHERE roleid = ${roleID};`;
  return script;
};

export const getGift = () => {
  const script = `
    SELECT * 
    FROM iaspire.int30_item_master 
    WHERE isactive = 'true';
  `;
  return script;
};

export const setGift = () => {
  const script = `
    SELECT iaspire.gift_user($1, $2);
  `;
  return script;
};

export const getUserGiftDetails = () => {
  const script = `
  SELECT u.userid, u.useritem,u.itemid, m.itemname, m.itemlogoname
  FROM iaspire.int30_useritem u
  JOIN iaspire.int30_item_master m ON u.itemid = m.itemid
  WHERE u.userid= $1;
  `;
  return script;
};

export const getGiftExcelDetails = () => {
  const script = `
   select u.userid ,u.username ,iim.itemname , md.duname  from wms_user u
      left join iaspire.int30_useritem iu on u.userid = iu.userid  
      left join iaspire.int30_item_master iim on  iim.itemid = iu.itemid
      left join mst_deliveryunit md on md.duid = u.itracks_duid
      where u.useractive = true order by iim.itemname ,md.duname
  `;
  return script;
};
