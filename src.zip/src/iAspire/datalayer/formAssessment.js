export const getDesignationScript = () => {
  const script = `SELECT DISTINCT u.designationid, de.designationdesc FROM public.wms_user u 
  LEFT JOIN public.mst_designation de ON de.designationid = u.designationid
  LEFT JOIN iaspire.trn_emp_appraisal app ON app.employeecode = u.userid
  JOIN iaspire.mst_emp_appraisal mapp ON mapp.empapp_id = app.empapp_id
  WHERE UPPER(mapp.appraisalcode) = 'AJUL' AND u.useractive = true AND 
  mapp.isactive = true AND u.designationid IS NOT NULL
  ORDER BY de.designationdesc`;
  return script;
};

export const getQuestionaliasnameScript = () => {
  const script = `SELECT DISTINCT questionid, tag_name FROM iaspire.mst_ry_ques order by 1`;
  return script;
};

export const getFormAssessmentScript = () => {
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY yapp.y_appraisal_id) AS serial,
        yapp.employee_code AS employeecode, u.username AS employeename, bl.bandlevel,
        du.duname AS du, de.designationdesc AS designation,
        jsonb_object_agg('que' || qa.questionid, yqa.answer ORDER BY qa.questionid) AS questions_answers
        FROM iaspire.trn_yearly_appraisal yapp
        LEFT JOIN iaspire.trn_yearly_appraisal_qa yqa ON yqa.y_appraisal_id = yapp.y_appraisal_id
        LEFT JOIN iaspire.mst_ry_ques qa ON qa.questionid = yqa.questionid
        LEFT JOIN iaspire.mst_status s ON s.statusid = yapp.statusid
        LEFT JOIN public.wms_user u ON u.userid = yapp.employee_code
        LEFT JOIN public.mst_bandlevel bl ON bl.bandlevelid = u.bandlevelid
        LEFT JOIN public.mst_deliveryunit du ON du.duid = u.itracks_duid
        LEFT JOIN public.mst_designation de ON de.designationid = u.designationid
        WHERE s.alias_name = 'APP_COMPLETED' AND yapp.is_active = true AND yqa.is_active = true AND 
        qa.isactive = true AND s.isactive = true AND u.useractive = true AND bl.isactive = true AND
        du.isactive = true AND de.isactive = true AND yapp.fin_year = (EXTRACT(YEAR FROM CURRENT_DATE) - 1) AND
        ($1 = 0 OR u.itracks_duid = $1) AND ($2 = 0 OR u.designationid = $2) AND
        ($3 = '' OR u.userid ILIKE '%' || $3 || '%' OR u.username ILIKE '%' || $3 || '%')
        GROUP BY yapp.y_appraisal_id, yapp.employee_code, u.username, bl.bandlevel, du.duname, de.designationdesc`;
  return script;
};

// Appraisal Form Report
export const getStatusScript = () => {
  const script = `SELECT statusid AS value, status AS label from iaspire.mst_status where status_type = 'appraisal' order by 1`;
  return script;
};

export const getfinancialYearScript = () => {
  const script = `SELECT DISTINCT CONCAT(SUBSTRING(mq.quartercode, 4, 4), '-', 
        SUBSTRING(mq.quartercode, 4, 4)::integer + 1) AS label,
        SUBSTRING(mq.quartercode,4,4) as value FROM iaspire.mst_quarters mq ORDER BY value DESC;`;
  return script;
};

export const getAppraisalFormReport = () => {
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY yapp.y_appraisal_id) AS serial,
    CASE WHEN u.serving_notice = true THEN 'Serving Notice' 
    WHEN u.useractive = true THEN 'Active' ELSE 'InActive' END AS empstatus,
    CASE WHEN u.useractive = true THEN 'success' ELSE 'pending' END AS empstatusclass,
    yapp.employee_code AS employeecode, u.username AS employeename, UPPER(s.status) AS status,  
    s.status_category AS statusclass, u.doj, du.duname as costcenter, fu.function, ca.category, 
    de.designationdesc AS designation, yapp.fin_year AS year, yapp.y_appraisal_id as appid,
    CASE WHEN yapp.promotion_recommended = true THEN 
    (SELECT designationdesc FROM public.mst_designation WHERE designationid = yapp.revised_designation)
    ELSE 'NA' END AS reviseddesignation, bl.bandlevel,
    CASE WHEN yapp.promotion_recommended = true THEN 
    (SELECT bandlevel FROM public.mst_bandlevel WHERE bandlevelid = yapp.revised_band_level)
    ELSE 'NA' END AS revisedbandlevel, u.integra_exp as integraexperiance, u.total_exp as totalexperiance,
    -- (SELECT EXTRACT(YEAR FROM AGE(CURRENT_DATE, u.doj)) || ' Years ' ||
    -- EXTRACT(MONTH FROM AGE(CURRENT_DATE, u.doj)) || ' Months') AS intexp
    jsonb_object_agg(LEFT(ap.quartercode, 2), ap.score ORDER BY ap.quartercode) AS quelist,
    yapp.actual_score AS actualscore,yapp.actual_rating AS actualrating, final_score AS approverscore, final_rating AS approverrating,
    CASE WHEN yapp.promotion_recommended = true THEN yapp.justification_comments
    ELSE 'NA' END AS justificationforpromotion, yapp.approver1_comments, yapp.approver2_comments,'action' AS action
    FROM iaspire.trn_yearly_appraisal yapp
    LEFT JOIN iaspire.trn_yearly_appraisal_qa yqa ON yqa.y_appraisal_id = yapp.y_appraisal_id
    LEFT JOIN iaspire.mst_ry_ques qa ON qa.questionid = yqa.questionid
    LEFT JOIN iaspire.mst_status s ON s.statusid = yapp.statusid
    LEFT JOIN public.wms_user u ON u.userid = yapp.employee_code
    LEFT JOIN public.mst_bandlevel bl ON bl.bandlevelid = u.bandlevelid
    LEFT JOIN public.mst_deliveryunit du ON du.duid = u.itracks_duid
    LEFT JOIN public.mst_designation de ON de.designationid = u.designationid
    LEFT JOIN public.mst_function fu ON fu.functionid = u.functionid
    LEFT JOIN iaspire.mst_appraisaltype ca ON ca.categoryid = u.categoryid
    LEFT JOIN iaspire.trn_appraisalmapping ap ON ap.employeecode = u.userid
    WHERE yapp.is_active = true AND yqa.is_active = true AND qa.isactive = true AND s.isactive = true AND 
    u.useractive = true AND bl.isactive = true AND du.isactive = true AND de.isactive = true AND
    yapp.fin_year IS NOT NULL AND ap.quartercode ILIKE CONCAT('%', yapp.fin_year::text) AND
    ($1 = 0 OR yapp.statusid = $1) AND ($2 = 0 OR yapp.fin_year = $2) AND
    ($3 = '' OR u.userid ILIKE '%' || $3 || '%' OR u.username ILIKE '%' || $3 || '%')
    GROUP BY yapp.y_appraisal_id, yapp.employee_code, u.username, bl.bandlevel, du.duname, 
    de.designationdesc,u.useractive,yapp.employee_code,yapp.statusid,s.status,u.doj,yapp.fin_year,u.serving_notice,
    fu.function,ca.category,u.integra_exp,u.total_exp, u.userid, s.status_category`;
  return script;
};
