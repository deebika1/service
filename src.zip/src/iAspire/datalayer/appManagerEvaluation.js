export const getAppraisalStatusListScript = () => {
  const script = `SELECT status as label, statusid as value FROM iaspire.mst_status WHERE status_type = 'appraisal' ORDER BY statusid;`;
  return script;
};

export const getManagerEvaluationDataScript = () => {
  const script = `SELECT 
      ROW_NUMBER() OVER (ORDER BY q.action DESC) AS serial, 
      q.*,
          (SELECT 
          CONCAT(
              q.yearid, 
              '-', 
              q.yearid + 1
          )
       ) AS year
    FROM (
      SELECT
          usr.userid,
          usr.username,
          COALESCE(sts.status, default_status.status) AS status,
          COALESCE(sts.status_category, default_status.status_category) AS statusclass,
          usr.reportingto AS l1,
          usr.duhead,
          usr.functionalhead,
          usr.useractive,
          COALESCE(app.fin_year, $3) AS yearid,
          app.appraisal_type,
          app.y_appraisal_id AS appraisalid,
          COALESCE(sts.statusid, default_status.statusid) AS statusid,
          CASE 
              WHEN (usr.reportingto = $1 AND sts.alias_name IN ('APP_L1')) THEN 'action'
              WHEN (usr.l2 = $1 AND sts.alias_name IN ('APP_L2')) THEN 'action'
              WHEN (sts.alias_name IN ('APP_YTS')) OR (sts.alias_name IS NULL) THEN ''
              WHEN (sts.alias_name IN ('APP_COMPLETED')) THEN 'action'
              ELSE '' 
          END AS action,
          CASE 
              WHEN (usr.doj <= TO_DATE(EXTRACT(YEAR FROM CURRENT_DATE) - 1 || '-09-15', 'YYYY-MM-DD')) THEN true
              ELSE false
          END AS iseligible,
          COALESCE(sts.alias_name, 'APP_YTS') AS alias_name,
          usr.L2 AS l2
      FROM 
          IASPIRE.reporting_hierarchy_view usr
      LEFT JOIN 
          iaspire.trn_yearly_appraisal app ON app.employee_code = usr.userid AND app.fin_year = COALESCE($3, EXTRACT(YEAR FROM CURRENT_DATE))
      JOIN 
          iaspire.trn_emp_appraisal empapp ON usr.userid = empapp.employeecode
      LEFT JOIN 
          iaspire.mst_status sts ON sts.statusid = app.statusid
      LEFT JOIN (
          SELECT 
              status,
              status_category,
              statusid
          FROM 
              iaspire.mst_status 
          WHERE 
              alias_name = 'APP_YTS'
      ) AS default_status ON true
      WHERE
          (usr.reportingto = $1 OR usr.l2 = $1) AND
          (empapp.empapp_id = 4 AND COALESCE($3, EXTRACT(YEAR FROM CURRENT_DATE)) >= empapp.effectivefrom AND empapp.isactive = TRUE) AND
          usr.useractive = TRUE
    ) AS q where q.iseligible = TRUE AND
        ($2 = '' OR q.userid ILIKE '%' || $2 || '%' OR q.username ILIKE '%' || $2 || '%')
        AND ($4 = '' OR q.statusid::text IN ($4));`;
  return script;
};

export const getB3AboveDesignationsScript = () => {
  const script = `SELECT DISTINCT desig.designationid AS value, desig.designationdesc AS label FROM public.wms_user usr
  JOIN public.mst_bandlevel bl ON bl.bandlevelid = usr.bandlevelid
  JOIN public.mst_designation desig ON desig.designationid = usr.designationid
  WHERE bl.bandlevel LIKE 'B3%' OR bl.bandlevel LIKE 'B2%' OR bl.bandlevel LIKE 'B1%'
  ORDER BY desig.designationdesc;`;
  return script;
};

export const getB3AboveBandLvlScript = () => {
  const script = `SELECT bl.bandlevel AS label, bl.bandlevelid AS value, bl.bandlevel_seq  FROM public.wms_user usr
  JOIN public.mst_bandlevel bl ON bl.bandlevel_seq <= (SELECT bandlevel_seq FROM public.mst_bandlevel WHERE bandlevelid = usr.bandlevelid)
  WHERE usr.userid = $1 ORDER BY bandlevel_seq DESC;`;
  return script;
};

export const getEmpYearlyApprisalDetScript = () => {
  const script = `SELECT * FROM iaspire.trn_yearly_appraisal WHERE y_appraisal_id = $1;`;
  return script;
};

export const getAppNxtStausIdScript = () => {
  const script = `SELECT 
  CASE WHEN (reportingto = $2 AND (duhead <> $2 OR functionalhead <> $2))
  THEN (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'APP_L2')
  ELSE (SELECT statusid FROM iaspire.mst_status WHERE alias_name = 'APP_COMPLETED') END
  FROM IASPIRE.reporting_hierarchy_view WHERE userid = $1;`;
  return script;
};

export const updateAppReviewDataScript = () => {
  const script = `UPDATE iaspire.trn_yearly_appraisal 
                  SET statusid = COALESCE($3, statusid), 
                      updated_by = $4,
                      updated_time = CURRENT_TIMESTAMP, 
                      final_score = COALESCE($5, final_score),
                      final_rating = COALESCE($6, final_score),
                      promotion_recommended = COALESCE($7, promotion_recommended),
                      revised_band_level = COALESCE($8, revised_band_level), 
                      revised_designation = COALESCE($9, revised_designation), 
                      approver1_comments = COALESCE($10, approver1_comments), 
                      approver2_comments = COALESCE($11, approver2_comments), 
                      justification_comments = COALESCE($12, justification_comments)
                  WHERE employee_code = $1
                      AND fin_year = $2 
                      AND is_active = TRUE`;
  return script;
};

export const getQueWithAnsScript = () => {
  const script = `SELECT que.question AS label, ans.answer AS value, que.questionid AS id, true AS required  FROM
        iaspire.mst_ry_ques que
        LEFT JOIN iaspire.trn_yearly_appraisal_qa ans ON que.questionid = ans.questionid
        WHERE y_appraisal_id = $1 AND employee_code = $2 AND is_active = TRUE ORDER BY id;`;
  return script;
};

export const checkAppManEvalEligibleScript = () => {
  const script = `SELECT * FROM IASPIRE.reporting_hierarchy_view usr
  JOIN iaspire.trn_emp_appraisal app ON usr.userid = app.employeecode
  JOIN iaspire.mst_emp_appraisal mapp ON mapp.empapp_id = app.empapp_id
  WHERE (usr.reportingto = $1 OR usr.l2 = $1) AND
  UPPER(mapp.appraisalcode) = 'AJUL' AND EXTRACT(YEAR FROM CURRENT_DATE) >= app.effectivefrom AND app.isactive = TRUE AND
  usr.useractive = TRUE;`;
  return script;
};
