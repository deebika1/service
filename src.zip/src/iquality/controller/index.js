import axios from 'axios';
import CryptoJS from 'crypto-js';
import { query } from '../../database/postgres.js';
import {
  welcome,
  viewDuMappingService,
  FeedbackDUMappingService,
  searchforfeedbackService,
  getDuService,
  getCustomerByDuIdService,
  getSearchOptionsService,
  getCurrencyService,
  getD1EmployeeDetailsService,
  insertD1TeamService,
  getD1TeamService,
  searchAppreciationPosService,
  viewFeedbackService,
  modifyCCAService,
  getCCAdetailsService,
  ActiveIPSwitchURL,
  createFeedBackService,
  createOldWmsFeedBackService,
  insertFeedbackAttachment,
  getD2ProbDefService,
  createD2Service,
  getD2JobCountService,
  getD2JobdetailService,
  createD3Service,
  getD3detailsService,
  getApprdetailsService,
  ApprDUMappingService,
  getApprDUdetailsService,
  errorCatReomveService,
  getD4detailService,
  insertd4ACausesService,
  getsvnDIDService,
  D5actiondrpdwnService,
  D5rootcausedrpdwnService,
  getD5dataService,
  updateD5Service,
  deleteD5Service,
  reopenD5Service,
  insertApprDUMappingService,
  updateApprDUMappingService,
  getAwardsMasterService,
  getAppreDetailsAwardsService,
  deleteApprEmpMapService,
  updateApprAwardService,
  d5HdsUpdateService,
  getD4aColumnsService,
  getD4aDetailsService,
  createD4aDetailsService,
  createD4aWhyService,
  getD4aWhyCategoryService,
  getD4AEmpDetailService,
  createD4aRootCauseEmpService,
  getD4AWhyService,
  getD4BDetailService,
  insertD6Service,
  getRootCauseService,
  get6dDataService,
  getDUErrorStatusService,
  getD7dataService,
  getD7DropdownDetailsService,
  createD7Service,
  closeFeedbackService,
  getD5StatusService,
  getSeverityService,
  getSeverityDataService,
  InsertCompSeverityService,
  DeleteCompSeverityService,
  getChargeBackResourceTypeService,
  getChargeBackService,
  InsertEmpChargeBackService,
  getD4AWhyEmpDetailService,
  deleteD4BCauseDetailService,
  mailTriggerService,
  getRpEmpTypeDDService,
  getReportDuDDService,
  getReportEmpDDService,
  getReportService,
  getFeedbackCountService,
  getResponsibleFBService,
  getResponsibleAppreciationService,
  getFBActionassignedService,
  getFBAssignedDetailsService,
  getCCANotAttachedService,
  getCompaintsTeamMemberService,
  getCompaintsTeamMemberDetService,
  getInitialSeverityDataService,
  getChargeBackAttachmentService,
  getD3AttachmentService,
  SaveLevelforD2Service,
  getLevelforD2Service,
  getFeedbacktypeforAppReportService,
  getAppReportService,
  getToDUService,
  removeFileTableService,
  geticetService,
  getiAspireService,
  createWmsUserService,
  getDUEmployeeDetailsService,
  getD7FlowStatusService,
  getApprReportEmpDDService,
  updateAttachmentcommentService,
  updateAccountMISService,
  getApprDropdownService,
  searchAppreciationFilterService,
  getFeedbackDropdownService,
  searchFeedbackFilterService,
  getFromDUforUserService,
  getDUFeedbackDropdownService,
  getDUDropdownforD2Service,
  UpdateLineitemD2Service,
  getOrgMstDeliveryUnitService,
  getMISReportService,
  UpdateZeroRepeatErrorService,
  getCustomerCopyService,
  getOrgMstDeliveryUnitforOldWMSService,
  getOrgMstDuIdforOldWMSService,
  getMisReportFeedbackCountService,
  getqtrMISService,
  getFeedbacktypeService,
} from '../service/index.js';
import { sendMail } from '../../modules/iTracks/index.js';

export const welcomeController = async (req, res) => {
  try {
    const out = await welcome();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getiQualityFolderPath = async (req, res) => {
  try {
    res.status(200).send({ path: '/okm:root/prodrepository/iQuality/' });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const searchforfeedbackController = async (req, res) => {
  try {
    const out = await searchforfeedbackService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getDuController = async (req, res) => {
  try {
    const out = await getDuService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustomerByDuIdController = async (req, res) => {
  try {
    const { divid } = req.params;
    const out = await getCustomerByDuIdService(divid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getSearchOptionsController = async (req, res) => {
  try {
    const out = await getSearchOptionsService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getCurrencyController = async (req, res) => {
  try {
    const out = await getCurrencyService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
/**
 * The `createFeedbackController` function handles the creation of feedback, including attaching files,
 * and returns the created feedback.
 *
 * Args:
 *   req: The `req` parameter is the request object that contains information about the incoming HTTP
 * request, such as headers, query parameters, and the request body. It is typically provided by the
 * web framework or server handling the request.
 *   res: The `res` parameter is the response object that is used to send the response back to the
 * client. It contains methods and properties that allow you to control the response, such as setting
 * the status code, headers, and sending the response body.
 */
export const createFeedbackController = async (req, res) => {
  try {
    const { payload, oldWMSPayload, fileUrls } = req.body;
    const out = await createFeedBackService(payload);
    const feedbackID = out[0].svnd_insertfeedback;
    let id = out[0].svnd_insertfeedback;
    const regex = /-(\d+)-/; // Match a dash followed by one or more digits, and capture the digits
    const match = feedbackID.match(regex);
    if (match && match[1]) {
      id = parseInt(match[1], 10); // Convert the captured string to an integer
    } else {
      console.log('No match found.');
      throw new Error('Error in feedback id.');
    }
    if (payload.feedbackdata === 'old') {
      await createOldWmsFeedBackService({ ...oldWMSPayload, feedbackID: id });
    }
    let attachment;
    if (fileUrls.length > 0) {
      attachment = await insertFeedbackAttachment(
        fileUrls,
        id,
        payload.created_by,
        payload.fromScreen || 'NewFeedback',
      );
    }
    // if (payload.fromDivId || payload.feedbackdata !== 'old') {
    if (payload.fromDivId) {
      payload.fromDivId = await getOrgMstDeliveryUnitService(payload.fromDivId);
    }
    if (payload.toDivId) {
      payload.toDivId = await getOrgMstDeliveryUnitService(payload.toDivId);
    } else if (payload.divisionId) {
      payload.divisionId = await getOrgMstDeliveryUnitService(
        payload.divisionId,
      );
    }
    if (
      payload.feedbackdata === 'old' &&
      (payload.customerData[0]?.divisionid ||
        payload.customerData[0]?.DivisionId)
    ) {
      const divisionDesc =
        payload.customerData[0]?.divisiondesc ||
        payload.customerData[0]?.DivisionDesc;
      payload.customerData[0].divisionid = await getOrgMstDuIdforOldWMSService(
        divisionDesc,
      );
    }
    if (
      payload.feedbackdata === 'new' &&
      (payload.customerData[0]?.divisionid ||
        payload.customerData[0]?.DivisionId)
    ) {
      const divisionId =
        payload.customerData[0]?.divisionid ||
        payload.customerData[0]?.DivisionId;
      payload.customerData[0].divisionid = await getOrgMstDeliveryUnitService(
        divisionId,
      );
    }
    const mailData = {
      feedbackId: feedbackID,
      // eslint-disable-next-line prettier/prettier
      encryptedID: CryptoJS.AES.encrypt(
        feedbackID,
        'secret key 123',
      ).toString(),
      mailAction:
        payload.feedbacktype === 'IA' || payload.feedbacktype === 'EA'
          ? 'Appreciation'
          : payload.feedbacktype,
      entityid: 70,
      BookCode:
        payload.customerData[0]?.bookcode ||
        payload.customerData[0]?.BookCode ||
        null,
      Raisedby: payload.raisedby,
      userid: payload.raisedById,
      RaisedFrom:
        payload.fromDivId ||
        payload.customerData[0]?.divisionid ||
        payload.customerData[0]?.DivisionId ||
        payload.loggedUserDuId,
      RaisedFromDU:
        payload.fromDu ||
        payload.customerData[0]?.divisiondesc ||
        payload.customerData[0]?.DivisionDesc ||
        payload.loggedUserDu,
      RaisedTo:
        payload.toDivName ||
        payload.customerData[0]?.divisiondesc ||
        payload.customerData[0]?.DivisionDesc ||
        payload.loggedUserDu,
      RaisedToId: payload.divisionId || payload.toDivId,
      RaisedOn: payload.despatchedDate,
      BookCodekamEmail: [payload.customerData[0]?.kam] || null,
      BookCodeCMEmail: [payload.customerData[0]?.cm] || null,
      BookCodePMEmail: [payload.customerData[0]?.pme] || null,
      CustomerName:
        payload.customerData[0]?.customer ||
        payload.customerData[0]?.CustomerName ||
        null,
      CustomerId:
        payload.customerData[0]?.customerid ||
        payload.customerData[0]?.CustomerId ||
        null,
      CustomerCountry:
        payload.customerData[0]?.country ||
        payload.customerData[0]?.CountryName ||
        null,
      Description: payload.feedbackdesc,
    };
    try {
      await sendMail(mailData);
    } catch (mailError) {
      console.error('Mail Trigger Service Error:', mailError);
    }
    res.status(201).json({ msg: out, attachment });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD1EmployeeDetailsController = async (req, res) => {
  try {
    const { searchBy } = req.params;
    const out = await getD1EmployeeDetailsService(searchBy);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD1TeamController = async (req, res) => {
  try {
    const { feedBackID } = req.params;
    const out = await getD1TeamService(feedBackID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createD1TeamController = async (req, res) => {
  try {
    const D1teamDetailsArray = req.body;
    const out = await insertD1TeamService(D1teamDetailsArray);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const searchAppreciationPosController = async (req, res) => {
  try {
    const searchInfo = req.body;
    const out = await searchAppreciationPosService(searchInfo);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const viewFeedbackController = async (req, res) => {
  try {
    const out = await viewFeedbackService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const modifyCCAController = async (req, res) => {
  try {
    const info = req.body;
    await modifyCCAService(info);
    res.status(200).send('CCA Updated Successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getCCADetailsController = async (req, res) => {
  try {
    const { fId } = req.params;
    const out = await getCCAdetailsService(fId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getOlditracks = async (req, res) => {
  try {
    const { itracksServer } = process.env;
    const out = await ActiveIPSwitchURL(itracksServer);
    res.status(201).send(out);
  } catch (error) {
    //
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD2ProbDefController = async (req, res) => {
  try {
    const { feedBackID } = req.params;
    const out = await getD2ProbDefService(feedBackID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const createD2Controller = async (req, res) => {
  try {
    const { payload, fileUrls } = req.body;
    let attachment;
    if (fileUrls.length > 0) {
      attachment = await insertFeedbackAttachment(
        fileUrls,
        payload.feedbackId,
        payload.createdBy,
        payload.fromScreen || 'D2',
      );
    }
    const out = await createD2Service(payload);
    res.status(200).send({ msg: out, attachment });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD2JobCountController = async (req, res) => {
  try {
    const { feedBackID } = req.params;
    const out = await getD2JobCountService(feedBackID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD2JobdetailController = async (req, res) => {
  try {
    const { feedBackID } = req.params;
    const out = await getD2JobdetailService(feedBackID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const CreateD3Controller = async (req, res) => {
  try {
    const { payload, fileUrls } = req.body;
    let attachment;
    const out = await createD3Service(payload);
    if (fileUrls.length > 0) {
      attachment = await insertFeedbackAttachment(
        fileUrls,
        payload.feedbackId,
        payload.createdBy,
        payload.fromScreen || 'D3',
      );
    }
    res.status(200).send({ msg: out, attachment });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD3DetailsController = async (req, res) => {
  try {
    const { fId } = req.params;
    const out = await getD3detailsService(fId);
    const attachment = await getD3AttachmentService(fId);
    res.status(200).send({ msg: out, attachment });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const viewDuMappingController = async (req, res) => {
  try {
    const info = req.body;
    const out = await viewDuMappingService(info);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const FeedbackDUMappingController = async (req, res) => {
  try {
    const { payload, mailDetails } = req.body;
    const out = await FeedbackDUMappingService(payload);
    const script = `select customerid from public.org_mst_customer where trim(upper(customername))= trim(upper('${mailDetails.CustomerName}'))`;
    const result = await query(script);
    // const script2 = `select duname from public.org_mst_deliveryunit where duid = ${mailDetails.toDu}`;
    const script2 = `select duname from public.mst_deliveryunit where duid = ${mailDetails.toDu}`;
    const result2 = await query(script2);

    if (mailDetails.toDu) {
      mailDetails.toDu = await getOrgMstDeliveryUnitService(mailDetails.toDu);
    }

    const mailData = {
      feedbackId: mailDetails.feedbackId,
      encryptedID: CryptoJS.AES.encrypt(
        mailDetails.feedbackNo,
        'secret key 123',
      ).toString(),
      mailAction: 'DUMapping',
      entityid: 70,
      MisStatus: mailDetails.mis,
      RaisedFrom: mailDetails.fromDuId,
      SubDu: mailDetails.SubDu,
      JobFamily: mailDetails.JobFamily,
      CustomerName: mailDetails.CustomerName,
      CustomerId: result.length > 0 ? parseInt(result[0].customerid) : '',
      CustomerDivision: mailDetails.CustomerDivision,
      CustomerCountry: mailDetails.CustomerCountry || '',
      Description: mailDetails.Description,
      RaisedToId: mailDetails.toDu,
      RaisedTo: result2[0].duname,
      userid: mailDetails.raisedById,
    };
    try {
      await sendMail(mailData);
      // await mailTriggerService(mailData);
    } catch (mailError) {
      console.error('Mail Trigger Service Error:', mailError);
    }
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getApprDetailsController = async (req, res) => {
  try {
    const { fId } = req.params;
    const out = await getApprdetailsService(fId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const ApprDUMappingController = async (req, res) => {
  try {
    const finfo = req.body;
    const out = await ApprDUMappingService(finfo);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getApprDUDetailsController = async (req, res) => {
  try {
    const { fId } = req.params;
    const out = await getApprDUdetailsService(fId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const errorCatRemoveController = async (req, res) => {
  try {
    const { DMId } = req.params;
    const out = await errorCatReomveService(DMId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD4detailController = async (req, res) => {
  try {
    const { feedBackID } = req.params;
    const out = await getD4detailService(feedBackID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insertD6Controller = async (req, res) => {
  try {
    const { payload, fileUrls } = req.body;
    let attachment;
    const out = await insertD6Service(payload);
    if (fileUrls.length > 0) {
      for (let i = 0; i < fileUrls.length; i += 1) {
        fileUrls[i].FileID = out[0].insert6d;
      }
      attachment = await insertFeedbackAttachment(
        fileUrls,
        payload.feedbackId,
        payload.entryBy,
        payload.fromScreen,
      );
    }
    res.status(201).send({ msg: out, attachment });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRootCauseController = async (req, res) => {
  try {
    const { svndId, dimensionCode, isApplicale } = req.params;
    const result = await getRootCauseService(
      svndId,
      dimensionCode,
      isApplicale,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const get6dDataController = async (req, res) => {
  try {
    const { fId, svndId, dimensionCode, serialno } = req.params;
    const result = await get6dDataService(fId, svndId, dimensionCode, serialno);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insertd4ACausesController = async (req, res) => {
  try {
    const info = req.body;
    const result = await insertd4ACausesService(info);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getsvnDIDController = async (req, res) => {
  try {
    const { feedBackID } = req.params;
    const out = await getsvnDIDService(feedBackID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const D5actiondrpdwnController = async (req, res) => {
  try {
    const result = await D5actiondrpdwnService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const D5rootcausedrpdwnController = async (req, res) => {
  try {
    const { SvnDID, SID } = req.params;
    const result = await D5rootcausedrpdwnService(SvnDID, SID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD5dataController = async (req, res) => {
  try {
    const { SvnDID, SID } = req.params;
    const out = await getD5dataService(SvnDID, SID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateD5Controller = async (req, res) => {
  try {
    const result = await updateD5Service(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteD5Controller = async (req, res) => {
  try {
    const result = await deleteD5Service(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const reopenD5Controller = async (req, res) => {
  try {
    const result = await reopenD5Service(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertApprDUMappingController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertApprDUMappingService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateApprDUMappingController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await updateApprDUMappingService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAwardsMasterController = async (req, res) => {
  try {
    const out = await getAwardsMasterService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getAppreDetailsAwardsController = async (req, res) => {
  try {
    const { fID } = req.params;
    const out = await getAppreDetailsAwardsService(fID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const deleteApprEmpMapController = async (req, res) => {
  try {
    const { AppAwardDuSkillRelID } = req.params;
    const out = await deleteApprEmpMapService(AppAwardDuSkillRelID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateApprAwardController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await updateApprAwardService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const d5HdsUpdateController = async (req, res) => {
  try {
    const out = await d5HdsUpdateService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD4aColumnsController = async (req, res) => {
  try {
    const out = await getD4aColumnsService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD4aDetailsController = async (req, res) => {
  try {
    const { FID, SID } = req.params;
    const out = await getD4aDetailsService(FID, SID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const createD4aDetailsController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await createD4aDetailsService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const createD4aWhyController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await createD4aWhyService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD4aWhyController = async (req, res) => {
  try {
    const { fId, causeDelId } = req.params;
    const out = await getD4AWhyService(fId, causeDelId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD4aWhyCategoryController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getD4aWhyCategoryService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD4AEmpDetailController = async (req, res) => {
  try {
    const { searchBy, empType, duId } = req.params;
    const out = await getD4AEmpDetailService(searchBy, empType, duId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD4WhyEmpDetailsController = async (req, res) => {
  try {
    const { fId, causeDelId } = req.params;
    const out = await getD4AWhyEmpDetailService(fId, causeDelId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createD4aWhyEmpDetailController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await createD4aRootCauseEmpService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD4BDetailController = async (req, res) => {
  try {
    const { fId, sId } = req.params;
    const out = await getD4BDetailService(fId, sId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const deleteD4BCauseDetailsController = async (req, res) => {
  try {
    const { causeDelId, empId, feedbackId, serialno, updatedBy } = req.params;
    const out = await deleteD4BCauseDetailService(
      causeDelId,
      empId,
      feedbackId,
      serialno,
      updatedBy,
    );
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getDUErrorStatusController = async (req, res) => {
  try {
    const { fId } = req.params;
    const out = await getDUErrorStatusService(fId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD7dataController = async (req, res) => {
  try {
    const { SvnDID } = req.params;
    const out = await getD7dataService(SvnDID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getD7DropdownDetailsController = async (req, res) => {
  try {
    const { searchBy } = req.params;
    const out = await getD7DropdownDetailsService(searchBy);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const createD7Controller = async (req, res) => {
  try {
    const { payload, fileUrls } = req.body;
    let attachment;
    const out = await createD7Service(payload);
    if (fileUrls.length > 0) {
      for (let i = 0; i < fileUrls.length; i += 1) {
        fileUrls[i].FileID = out[0]?.insert_svnd_d7;
      }
      attachment = await insertFeedbackAttachment(
        fileUrls,
        payload.feedbackID,
        payload.createdBy,
        payload.fromScreen || 'D7',
      );
    }
    res.status(200).send({ msg: out, attachment });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const closeFeedbackController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await closeFeedbackService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getSeverityController = async (req, res) => {
  try {
    const result = await getSeverityService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getSeverityDataController = async (req, res) => {
  try {
    const { severityType, feedBackID } = req.params;
    const result = await getSeverityDataService(severityType, feedBackID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getInitialSeverityDataController = async (req, res) => {
  try {
    const { fID } = req.params;
    const result = await getInitialSeverityDataService(fID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const InsertCompSeverityController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await InsertCompSeverityService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const DeleteCompSeverityController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await DeleteCompSeverityService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getChargeBackResourceTypeController = async (req, res) => {
  try {
    const result = await getChargeBackResourceTypeService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getChargeBackController = async (req, res) => {
  try {
    const { fID } = req.params;
    const result = await getChargeBackService(fID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const InsertEmpChargeBackController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await InsertEmpChargeBackService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getd5StatusController = async (req, res) => {
  try {
    const { fId, svdId, serialNo } = req.params;
    const out = await getD5StatusService(fId, svdId, serialNo);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const mailTriggerController = async (req, res) => {
  try {
    const out = await mailTriggerService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Reports
export const getRpEmpTypeDDController = async (req, res) => {
  try {
    const result = await getRpEmpTypeDDService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getReportDuDDController = async (req, res) => {
  try {
    const { userID } = req.params;
    const result = await getReportDuDDService(userID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getReportEmpDDController = async (req, res) => {
  try {
    const { DuId } = req.params;
    const result = await getReportEmpDDService(DuId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getReportController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getReportService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getFeedbackCountController = async (req, res) => {
  try {
    const { empID } = req.params;
    const result = await getFeedbackCountService(empID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getResponsibleFeedbackController = async (req, res) => {
  try {
    const { empID, type } = req.params;
    const result = await getResponsibleFBService(empID, type);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getResponsibleAppreciationController = async (req, res) => {
  try {
    const { empID, type } = req.params;
    const result = await getResponsibleAppreciationService(empID, type);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getFBActionassignedController = async (req, res) => {
  try {
    const { empID } = req.params;
    const result = await getFBActionassignedService(empID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getFBAssignedDetailsController = async (req, res) => {
  try {
    const { empID, type, module } = req.params;
    const result = await getFBAssignedDetailsService(empID, type, module);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getCCANotAttachedController = async (req, res) => {
  try {
    const { empID } = req.params;
    const result = await getCCANotAttachedService(empID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getCompaintsTeamMemberController = async (req, res) => {
  try {
    const { empID } = req.params;
    const result = await getCompaintsTeamMemberService(empID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getCompaintsTeamMemberDetController = async (req, res) => {
  try {
    const { empID, module, type } = req.params;
    const result = await getCompaintsTeamMemberDetService(empID, module, type);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const ChargeBackAttController = async (req, res) => {
  try {
    const { payload, fileUrls } = req.body;
    let attachment;
    if (fileUrls.length > 0) {
      attachment = await insertFeedbackAttachment(
        fileUrls,
        payload.feedbackId,
        payload.createdBy,
        payload.fromScreen || 'D2',
      );
    }
    res.status(200).send({ attachment });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getChargeBackAttachmentController = async (req, res) => {
  try {
    const { fID } = req.params;
    const result = await getChargeBackAttachmentService(fID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const SaveLevelforD2Controller = async (req, res) => {
  try {
    const result = await SaveLevelforD2Service(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getLevelforD2Controller = async (req, res) => {
  try {
    const { feedBackID } = req.params;
    const result = await getLevelforD2Service(feedBackID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getFeedbacktypeforAppReportController = async (req, res) => {
  try {
    const result = await getFeedbacktypeforAppReportService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getAppReportController = async (req, res) => {
  try {
    const result = await getAppReportService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getToDUController = async (req, res) => {
  try {
    const { fID } = req.params;
    const result = await getToDUService(fID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const removeFileFromTableController = async (req, res) => {
  try {
    const { filename } = req.body;
    const result = await removeFileTableService(filename);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getICEController = async (req, res) => {
  try {
    const out = await geticetService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const fetchOldiTracksController = async (req, res) => {
  try {
    const { option, header } = req.body;
    const response = await axios({
      method: req.method,
      url: process.env.OldWMSData,
      data: option,
      headers: {
        'Content-Type': 'application/json',
        ...header,
        // Add other headers if needed
      },
    });
    res.send(response.data.Result);
  } catch (error) {
    res.status(error.response.status).json(error.response.data);
  }
};
export const createWmsUserController = async (req, res) => {
  try {
    const { payload } = req.body;
    const result = await createWmsUserService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getDUEmployeeDetailsController = async (req, res) => {
  try {
    const { searchBy } = req.params;
    const out = await getDUEmployeeDetailsService(searchBy);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getiAspireController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getiAspireService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getD7FlowStatusController = async (req, res) => {
  try {
    const { FID, CurrentStatus, SID, SLID } = req.params;
    const result = await getD7FlowStatusService(FID, CurrentStatus, SID, SLID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getApprReportEmpDDController = async (req, res) => {
  try {
    const { DuId } = req.params;
    const result = await getApprReportEmpDDService(DuId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateAttachmentcommentControler = async (req, res) => {
  try {
    const result = await updateAttachmentcommentService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const updateAccountMISController = async (req, res) => {
  try {
    const payload = req.body;

    const result = await updateAccountMISService(payload);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getApprDropdownController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getApprDropdownService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const searchAppreciationFilterController = async (req, res) => {
  try {
    const searchInfo = req.body;
    const out = await searchAppreciationFilterService(searchInfo);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getFeedbackDropdownController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getFeedbackDropdownService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const searchFeedbackFilterController = async (req, res) => {
  try {
    const searchInfo = req.body;
    const out = await searchFeedbackFilterService(searchInfo);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFromDUforUserController = async (req, res) => {
  try {
    const { userID } = req.params;
    const result = await getFromDUforUserService(userID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getDUFeedbackDropdownController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getDUFeedbackDropdownService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getDUDropdownforD2Controller = async (req, res) => {
  try {
    const { fID } = req.params;
    const result = await getDUDropdownforD2Service(fID);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const UpdateLineitemD2Controller = async (req, res) => {
  try {
    const result = await UpdateLineitemD2Service(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getMISReportController = async (req, res) => {
  try {
    const result = await getMISReportService(req.body);
    const count = await getMisReportFeedbackCountService(req.body);
    res.status(200).send({ result, count });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const UpdateZeroRepeatErrorController = async (req, res) => {
  try {
    const result = await UpdateZeroRepeatErrorService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const fetchPdfDownload = async (req, res) => {
  try {
    const { options, header } = req.body;
    const response = await axios({
      method: req.method,
      url: process.env.PDFDownload,
      data: options,
      headers: {
        clientid: 'WMS',
        apikey: '84B9A8C7-FDEA-47DC-B1CF-845FD79C4E05',
        ...header,
        // Add other headers if needed
      },
    });
    res.send(response.data);
  } catch (error) {
    res.status(error.response.status).json(error.response.data);
  }
};
export const getCustomerCopyController = async (req, res) => {
  try {
    const { fId } = req.params;
    const result = await getCustomerCopyService(fId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getOrgMstDeliveryUnitforOldWMSController = async (req, res) => {
  try {
    const { duName } = req.params;
    const result = await getOrgMstDeliveryUnitforOldWMSService(duName);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getqtrMISServiceController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getqtrMISService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFeedbacktypeController = async (req, res) => {
  try {
    const out = await getFeedbacktypeService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
