/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
import AWS from 'aws-sdk';
import fs from 'fs';
import path from 'path';
import https from 'https';
import axios from 'axios';
import crypto from 'crypto';
import moment from 'moment';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../../database/postgres.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import {
  ialtSignalLogService,
  ialtSignalLogHistory,
  iAltAutoJobCreationService,
  checkChapterExists,
} from './index.js';
import { emitAction } from '../../modules/activityListener/index.js';
import { getNotificationTemplate } from '../../modules/common/index.js';
import {
  _uploads3File,
  _downloadForIalt,
} from '../../modules/utils/azure/index.js';
import { getFolderStructureForIalt } from '../../modules/utils/wmsFolder/index.js';
import { logAcknowledgementActivity } from '../../signalIntegration/service/elseVier/altTextJobProcess.js';

const service = new Service();

// Configure the AWS SDK with your credentials and region
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

const s3 = new AWS.S3();
const sqs = new AWS.SQS({ apiVersion: '2012-11-05' });
const bucketName = process.env.AWS_ELSEVIER_BUCKET_NAME;
const folderPath = 'contributors/158184564625';
const queueURL = process.env.SQS_QUEUE_URL;

export const altextGenerationJobService = async data => {
  return new Promise(async (resolve, reject) => {
    let jobPayload = {};
    let generalInfo = {
      customerId: 14,
      duId: 94,
      wfId: 38,
      serviceId: 1,
      stageId: 54,
      stageIteration: 1,
      jobFlowType: 'ialt',
      jobFlowTypeId: 3,
      chapterInfo: {},
      bookInfo: {},
    };
    try {
      if (!Object.keys(data).length) {
        throw new Error('Job received without payload');
      }
      const jobInfo = await readJobData(data);
      // initial log entry
      let logPayload = {
        ...generalInfo,
        ...jobInfo,
        response: data,
        message: 'Job request received',
        status: 'Success',
        processStatusId: 1,
      };
      const { data: signalAuditId } = await ialtSignalLogService(
        logPayload,
        'Insert',
      );
      try {
        const signalAckPayload = {
          signalAuditId,
          piiNumber: jobInfo.piiNumber,
          ackMsgInfo: jobInfo.ackMsgInfo,
        };
        await ialtJobReceivedAcknowledgeService(signalAckPayload);
        // get the metadata info
        const result = await getMetaData(signalAckPayload);
        const bookInfo = await readMetadata(result);

        jobPayload = {
          ...jobPayload,
          signalAuditId,
          ...generalInfo,
          ...jobInfo,
          bookInfo,
        };
        await checkChapterExists(
          {
            isbn: bookInfo.isbn,
            chapterName: jobInfo.chapterInfo.name,
          },
          signalAckPayload,
        );

        // download source files
        const assetDownloadRes = await downloadAssetFile(
          bookInfo.assetInfo,
          signalAckPayload,
        );

        // get du , customer, stage, dms info
        generalInfo = await getGeneralInfo(generalInfo);
        // upload source file to blob
        const assetUploadRes = await assetUploadProcess({
          assetDownloadRes,
          signalAuditId,
          ...generalInfo,
          bookName: bookInfo.title,
          chapterName: jobInfo.chapterInfo.name,
        });

        const allFiles = assetUploadRes.map(item => item.allPath);
        const originalFiles = assetUploadRes
          .map(item => item.pathWithSAS)
          .filter(p => p !== '');

        jobPayload = {
          ...jobPayload,
          originalFiles,
          allFiles,
        };
        const response = await iAltAutoJobCreationService(jobPayload);
        resolve(response);
      } catch (err) {
        logPayload = {
          signalAuditId,
          response: err.message,
          updateType: 'failed',
        };
        await ialtSignalLogService(logPayload, 'Update');
        throw new Error(err.message);
      }
    } catch (err) {
      const mailPayload = {
        action: 'job_receive_common_failure',
        to: [],
        title: jobPayload?.bookInfo?.title
          ? jobPayload.bookInfo.title
          : 'Failed in initial process',
        chapterName: jobPayload.chapterInfo.name,
        stageName: jobPayload?.bookInfo?.stage ? jobPayload.bookInfo.stage : '',
        message: err.message ? err.message : err,
      };
      await sendMail(mailPayload);
      reject({ status: false, message: err.message ? err.message : err });
    }
  });
};
// Function to send a message to SQS
export const sendMessageToSQSService = async messageBody => {
  try {
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: '',

      // QueueUrl: `${queueURL}/${process.env.SQS_QUEUE_NAME}`,
    };
    const data = await sqs.sendMessage(params).promise();
  } catch (err) {
    console.error('Error sending message', err);
  }
};
export const listInBucketsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const data = await s3
        .listObjectsV2({
          Bucket: payload.bucketName,
          Prefix: payload.folderPath,
        })
        .promise();
      resolve(data.Contents);
      // to get all buckets
      // s3.listBuckets((err, data) => {
      //   if (err) {
      //
      //   } else {
      //
      //   }
      // });
    } catch (err) {
      console.error('Error listing objects in bucket:', err);
      reject(err); // Throw error for caller to handle
    }
  });
};
// Function to delete a message from the SQS queue
const deleteMessage = async receiptHandle => {
  const params = {
    QueueUrl: queueURL,
    ReceiptHandle: receiptHandle,
  };

  try {
    // await sqs.deleteMessage(params).promise();
  } catch (err) {
    console.error('Error deleting message:', err);
  }
};
export const uploadFileToS3Service = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      filePath,
      signalAuditInfo: { signalauditid: signalAuditId, signalinfo: ackMsgInfo },
    } = payload;
    let params = {};
    try {
      // Download the file from the provided folder URL
      const url = new URL(filePath);
      const fileName = path.basename(url.pathname);
      const tempFilePath = `tempFolder/${fileName}`; // Temporary download path
      try {
        await downloadFileFromUrl(filePath, tempFilePath);
        // Read content from the file
        const fileContent = fs.readFileSync(tempFilePath);
        // Setting up S3 upload parameters
        params = {
          Bucket: `${bucketName}`,
          Key: `${folderPath}/${fileName}`,
          Body: fileContent,
          ACL: 'bucket-owner-full-control',
        };
        // Uploading files to the bucket
        const data = await s3.upload(params).promise();
        const logHisPayload = {
          signalAuditId,
          request: params,
          response: data,
          message: 'Final output has been uploaded successfully',
          status: 'Success',
          processStatusId: 22,
        };
        await ialtSignalLogHistory(logHisPayload);
        resolve(data);
      } catch (err) {
        const logHisPayload = {
          signalAuditId,
          updateType: 'failed',
          request: params,
          response: err.message ? err.message : err,
          message: 'Final output upload has failed',
          status: 'Failed',
          processStatusId: 23,
        };
        await ialtSignalLogService(logHisPayload, 'Update');
        await ialtSignalLogHistory(logHisPayload);
        const ackPaylod = {
          signalAuditId,
          ackMsgInfo,
        };
        await ialtFailedAcknowledgeService(ackPaylod, 'Failed');
        reject(err); // Throw error for caller to handle
      } finally {
        fs.unlinkSync(tempFilePath); // Clean up temporary file
      }
    } catch (err) {
      reject(err);
    }
  });
};
const downloadFileFromUrl = (fileUrl, destPath) => {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);

    https
      .get(fileUrl, response => {
        response.pipe(file);
        file.on('finish', () => {
          file.close(resolve); // close() is async, resolve after close completes.
        });
      })
      .on('error', err => {
        fs.unlink(destPath, () => reject(err)); // Delete the file async. (But we don't check the result)
      });
  });
};
export const altTextUploadNotification = (data, signalAuditInfo) => {
  return new Promise(async (resolve, reject) => {
    const { Location, ETag, piiNumber, key } = data;
    const { signalauditid: signalAuditId, signalinfo: ackMsgInfo } =
      signalAuditInfo;

    let payload = {};
    try {
      const assetVersion = ETag.replace(/^"|"$/g, '');
      const fileName = path.basename(Location);
      payload = {
        '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
        '@type': 'bam:ContentObjects',
        'bam:hasContentObjects': [
          {
            '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
            '@type': 'bam:Metadata',
            '@id': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
            'dct:language': 'en',
            'ecm:identifier': `pii:${piiNumber}`,
            'dct:title': 'Como articular la cooperación en red',
            'prism:aggregationType': [
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3',
            ],
            'dct:type':
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3.1',
            'bam:hasAssetMetadata': [
              {
                '@id': `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                '@type': 'bam:AssetMetadata',
                'dct:isFormatOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'dct:format':
                  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'bam:assetType': 'ALTERNATE-TEXT',
                'bam:assetVersion': `${assetVersion}`,
                'prism:byteCount': 2619,
                'bam:mode': 'private',
                'bam:filename': `${fileName}`,
                'bam:multiPart': false,
              },
            ],
            'bam:hasGeneration': [
              {
                '@type': 'bam:Generation',
                'bam:isGenerationOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'bam:hasAsset': [
                  `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                ],
                'bam:classificationLevel': 'public',
                'bam:stage': 'uncorrected_proof',
                'bam:hasGeneration': [],
              },
            ],
          },
        ],
      };
      const url = `${config.iAlt.else_vier.base_url}/${config.iAlt.else_vier.uri.upload}`;
      const result = await service.ialtPost(url, payload);

      const logHisPayload = {
        signalAuditId,
        updateType: 'completed',
        request: payload,
        response: result.data,
        message: 'Final output upload acknowledgment has been set successfully',
        status: 'Success',
        processStatusId: 25,
      };
      await ialtSignalLogHistory(logHisPayload);
      await ialtSignalLogService(logHisPayload, 'Update');

      resolve(result);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        updateType: 'failed',
        request: payload,
        response: err.message ? err.message : err,
        message: 'Final output upload acknowledgment has failed',
        status: 'Failed',
        processStatusId: 26,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);

      const ackPaylod = {
        signalAuditId,
        ackMsgInfo,
      };
      await ialtFailedAcknowledgeService(ackPaylod, 'Failed');
      reject('Alt text upload notification sending failed');
    }
  });
};

const getMetaData = signalAckPayload => {
  return new Promise(async (resolve, reject) => {
    const { piiNumber, signalAuditId, ackMsgInfo } = signalAckPayload;
    const url = `${config.iAlt.else_vier.base_url}/metadata/pii/${piiNumber}`;
    try {
      const result = await service.ialtGet(url);
      if (Object.keys(result).length) {
        const logHisPayload = {
          signalAuditId,
          request: url,
          response: result,
          message: 'Metadata fetching request successful',
          status: 'Success',
          processStatusId: 3,
        };
        await ialtSignalLogHistory(logHisPayload);
        resolve(result);
      } else {
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: url,
        response: err.message ? err.message : err,
        message: 'Metadata fetching request failed',
        status: 'Failed',
        processStatusId: 3,
      };
      await ialtSignalLogHistory(logHisPayload);

      await ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
      reject(err.message ? err.message : err);
    }
  });
};
export const readJobData = jobData => {
  return new Promise((resolve, reject) => {
    try {
      const serviceCallType = path.basename(jobData['msg:service']['svc:type']);
      const piiNumber = path.basename(jobData['msg:service']['svc:about']);
      const chpData = jobData['msg:service']['svc:params'][0];
      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);
      const ackMsgInfo = {
        messageSMSId: path.basename(jobData['@id']),
        serviceSMSId: path.basename(jobData['msg:service']['@id']),
        serviceAboutUrl: path.basename(jobData['msg:service']['svc:about']),
      };

      const chapterInfo = {
        name: `${chpData.chapterPit} ${chpData.chapterNumber}`,
        title: chpData.chapterTitle,
        startDate: moment().format('YYYY-MM-DD hh:mm:ss'),
        endDate: moment(futureDate).format('YYYY-MM-DD hh:mm:ss'),
        userId: 'System',
      };
      resolve({ serviceCallType, piiNumber, ackMsgInfo, chapterInfo });
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};
export const readMetadata = result => {
  return new Promise((resolve, reject) => {
    try {
      const jobInfo = {};
      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);
      const allStageSourceInfo = result['bam:hasGeneration'];
      let stageSourceInfo = [];
      stageSourceInfo = result['bam:hasGeneration'].filter(
        item => item['bam:stage'] === 'accepted_manuscript',
      );
      const getMaxVerison = stageSourceInfo.reduce(
        (max, row) =>
          row['bam:generation'] > max['bam:generation'] ? row : max,
        allStageSourceInfo[0],
      );
      const assetInfo = getMaxVerison['bam:hasAsset'];
      jobInfo.receivedStage = getMaxVerison['bam:stage'];
      jobInfo.title = result['prism:publicationName'];
      jobInfo.isbn = result['prism:isbn'].replace(/-/g, '');
      jobInfo.assetInfo = assetInfo;
      jobInfo.dueDate = moment(futureDate).format('YYYY-MM-DD hh:mm:ss');
      jobInfo.userId = 'System';

      resolve(jobInfo);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};
// download asset file from client
const downloadAssetFile = (assetInfo, signalAckPayload) => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId, ackMsgInfo } = signalAckPayload;
    try {
      const assetPromises = assetInfo.map(async item => {
        const assetUrl = item;
        const {
          data: sourceContent,
          filename,
          contentType,
        } = await service.ialtGetWithBlob(assetUrl);
        return { sourceContent, filename, contentType };
      });
      const assetDownloadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: JSON.stringify(assetDownloadRes),
        message: 'Source file downloaded successfully',
        status: 'Success',
        processStatusId: 4,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(assetDownloadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: err.message ? err.message : 'Source file downloaded failed',
        message: 'Source file downloaded failed',
        status: 'Failed',
        processStatusId: 4,
      };
      await ialtSignalLogHistory(logHisPayload);

      await ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
      reject(err);
    }
  });
};
// get du, customer info
export const getGeneralInfo = payload => {
  return new Promise(async (resolve, reject) => {
    const { duId, customerId, receivedStage, stageId } = payload;
    try {
      let sql = `select duid, duname from org_mst_deliveryunit where duid=${duId} and isactive=true`;
      const duInfo = await query(sql);
      sql = `select customerid, customername from org_mst_customer where customerid=${customerId} and isactive=true`;
      const custInfo = await query(sql);
      sql = `select stageid, stagename from wms_mst_stage where stageid=${stageId}`;
      // sql = `select stageid, stagename from wms_mst_stage where stageid = (select stageid from wms_mst_service_calltype
      // join wms_mst_service_calltype_map on wms_mst_service_calltype_map.servicecallmapid=wms_mst_service_calltype.servicecaltypeid
      // where servicecalltype='${receivedStage}' and wms_mst_service_calltype.isactive=true and wms_mst_service_calltype_map.isactive=true) and isactive=true`;
      const stageInfo = await query(sql);
      sql = ` SELECT dms_master.dmsid, dms_master.dmstype FROM wms_mst_customerconfigdetails 
      JOIN dms_master ON dms_master.dmsid = wms_mst_customerconfigdetails.dmsid
      WHERE customerid=${customerId} and dms_master.isactive`;

      const dmsInfo = await query(sql);
      if (
        duInfo.length &&
        custInfo.length &&
        stageInfo.length &&
        dmsInfo.length
      ) {
        resolve({
          ...payload,
          du: { id: duInfo[0].duid, name: duInfo[0].duname },
          customer: {
            id: custInfo[0].customerid,
            name: custInfo[0].customername,
          },
          stage: { id: stageInfo[0].stageid, name: stageInfo[0].stagename },
          dms: { id: dmsInfo[0].dmsid, name: dmsInfo[0].dmstype },
        });
      } else {
        throw new Error('Du | Customer | Stage info not found');
      }
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};
// asset upload process
const assetUploadProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      assetDownloadRes,
      signalAuditId,
      du,
      customer,
      stage,
      bookName,
      chapterName,
    } = payload;
    try {
      const folderPathData = {
        type: 'ialt_book_chapter_stage',
        duName: du.name,
        customerName: customer.name,
        bookName,
        chapterName,
        stageName: stage.name,
      };
      const pathToStore = await getFolderStructureForIalt(folderPathData);
      const assetPromises = assetDownloadRes.map(async item => {
        const docPath = `${pathToStore}${item.filename}`;
        const { fullPath } = await _uploads3File(
          docPath,
          item.sourceContent,
          item.contentType,
        );
        let sasPath = {};
        if (fullPath.includes('.pdf')) {
          const { data } = await _downloadForIalt(fullPath);
          sasPath = data;
        }
        return {
          allPath: fullPath,
          pathWithSAS: sasPath.path ? sasPath.path : '',
        };
      });
      const assetUploadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(payload),
        response: JSON.stringify(assetUploadRes),
        message: 'Source file uploaded to blob successfully',
        status: 'Success',
        processStatusId: 5,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(assetUploadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(payload),
        response: err.message
          ? err.message
          : 'Source file upload to blob failed',
        message: 'Source file upload to blob failed',
        status: 'Failed',
        processStatusId: 5,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// job received acknowledgement to client
export const ialtJobReceivedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      const tokenRes = await service.post(url, data);
      const { auth_token } = tokenRes.data;
      data = {
        '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/AltTextSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
        'msg:event': {
          '@id':
            'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-1008-4e52-9b8a-c75f8c6c7742',
          '@type': 'msg:EventNotification',
          'evt:time': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
          'evt:type':
            'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      const result = await service.post(url, data, headers);
      const logHisPayload = {
        signalAuditId,
        updateType: 'acknowledged',
        request: data,
        response: result,
        message: 'Job received acknowledgment sent successfully',
        status: 'Success',
        processStatusId: 2,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Job received acknowledgement sent failed',
        message: 'Job received acknowledgement sent failed',
        status: 'Failed',
        processStatusId: 2,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// failed acknowledgement to client
export const ialtFailedAcknowledgeService = (payload, status) => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      const tokenRes = await service.post(url, data);
      const { auth_token } = tokenRes.data;
      const autoGenerateNumber = `${uuidv4()}`;

      data = {
        '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/AltTextSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
        'msg:event': {
          '@id': `http://vtw.elsevier.com/event/id/Elsevier/SMS/${autoGenerateNumber}`,
          '@type': 'msg:EventNotification',
          'evt:time': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
          'evt:type': `http://vtw.elsevier.com/data/voc/Events/${status}`,
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      const result = await service.post(url, data, headers);
      const logHisPayload = {
        signalAuditId,
        updateType: 'failed',
        request: data,
        response: result,
        message: 'Job failure acknowledgment sent successfully',
        status: 'Success',
        processStatusId: 15,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Sent failed',
        message: 'Job failure acknowledgment sent failed',
        status: 'Failed',
        processStatusId: 24,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// job completed acknowledgement to client
export const ialtJobCompletedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
      queueUrl,
    } = payload;
    const messageBody = {
      '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
      '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
      '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
      '@type': 'msg:Message',
      'msg:format': 'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
      'msg:type':
        'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
      'msg:from':
        'http://vtw.elsevier.com/data/voc/Contributors/MPS/BookSupplier',
      'msg:to':
        'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
      'msg:event': {
        '@id':
          'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-1008-4e52-9b8a-c75f8c6c7742',
        '@type': 'msg:EventNotification',
        'evt:time': '2024-05-29T11:07:25.777Z',
        'evt:type':
          'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
        'evt:about': `${serviceAboutUrl}`,
        'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
      },
    };
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: queueUrl,
    };
    try {
      const data = await sqs.sendMessage(params).promise();
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent successfully',
        status: 'Job received acknowledgment sent successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent failed',
        status: 'Job received acknowledgement sent failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { action, to, customerId, message, title, stageName } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        customerId,
      };
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        stageName,
        subMessage: message,
        toMail: toMailArray,
      };
      await emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};
// get dms info
const getDmsInfo = customerId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE customerid=$1`;
      const dmsInfo = await query(sql, [customerId]);
      const { dmsid } = dmsInfo[0];
      resolve(dmsid);
    } catch (err) {
      reject('DMS info not found for the customer');
    }
  });
};

// success acknowledgement to client
export const ialtSuccessAcknowledgeService = (payload, status) => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      isRetrigger = false,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    let currentStage = '';
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      currentStage = 'TOKEN_FETCH';

      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      let tokenRes = null;

      try {
        tokenRes = await service.post(url, data);
      } catch (error) {
        throw new Error(`iAlt API Failed to get Token: ${error.message}`);
      }

      const { auth_token } = tokenRes.data;

      const autoGenerateNumber = `${uuidv4()}`;
      currentStage = 'PREPARE_COMPLETED_ACK_PAYLOAD';

      data = {
        '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/AltTextSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
        'msg:event': {
          '@id': `http://vtw.elsevier.com/event/id/Elsevier/SMS/${autoGenerateNumber}`,
          '@type': 'msg:EventNotification',
          'evt:time': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
          'evt:type': `http://vtw.elsevier.com/data/voc/Events/${status}`,
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      currentStage = 'SEND_COMPLETED_ACK';

      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      let result = null;
      try {
        result = await service.post(url, data, headers);
      } catch (error) {
        throw new Error(
          `iAlt API Failed to sending acknowledgment: ${error.message}`,
        );
      }
      currentStage = 'COMPLETED_ACK_SUCCESS';

      const logHisPayload = {
        signalAuditId,
        updateType: 'completed',
        request: data,
        response: result,
        message: 'Job success acknowledgment sent successfully',
        status: 'Success',
        processStatusId: 22,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);

      const isAcklogsAvailableQuery = `SELECT id as ackid, pii, signalauditid, acknowledgementtype, status
      FROM ialtacknowledgementlog where status = 'Failed' and signalauditid = '${signalAuditId}' and acknowledgementtype = 'COMPLETED_ACK'`;

      const isAcklogsAvailable = await query(isAcklogsAvailableQuery);

      if (isAcklogsAvailable.length) {
        await logAcknowledgementActivity({
          signalAuditId,
          stage: currentStage,
          acknowledgementtype: 'COMPLETED_ACK',
          status: isRetrigger ? 'Retriggered' : 'Completed',
          pii: piiNumber,
          errorMessage: '',
        });
      }
      resolve(true);
    } catch (error) {
      await logAcknowledgementActivity({
        signalAuditId,
        stage: currentStage,
        acknowledgementtype: 'COMPLETED_ACK',
        status: 'Failed',
        pii: piiNumber,
        errorMessage: `Failed at ${currentStage} stage: ${
          error.message || 'Unknown error'
        }`,
      });

      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Sent failed',
        message: 'Job notification failure acknowledgment sent failed',
        status: 'Failed',
        processStatusId: 24,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
