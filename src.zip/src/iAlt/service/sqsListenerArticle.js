/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
import AWS from 'aws-sdk';
import fs from 'fs';
import path from 'path';
import https from 'https';
import axios from 'axios';
import crypto from 'crypto';
import moment from 'moment';
import { query } from '../../database/postgres.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import {
  ialtSignalLogService,
  ialtSignalLogHistory,
  iAltAutoJobCreationService,
} from './index.js';
import { emitAction } from '../../modules/activityListener/index.js';
import { getNotificationTemplate } from '../../modules/common/index.js';
import {
  _uploads3File,
  _downloadForIalt,
} from '../../modules/utils/azure/index.js';
import { getFolderStructureForIalt } from '../../modules/utils/wmsFolder/index.js';

const service = new Service();

// Configure the AWS SDK with your credentials and region
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

const s3 = new AWS.S3();
const sqs = new AWS.SQS({ apiVersion: '2012-11-05' });
const bucketName = process.env.AWS_ELSEVIER_BUCKET_NAME;
const folderPath = 'contributors/158184564625';
const queueURL = process.env.SQS_QUEUE_URL;
const elseVierQueueURL =
  'https://sqs.eu-west-1.amazonaws.com/461549540087/uatnp-contributor-event-queue-INTEGRA';

// Function to start listening to SQS queue
const startListening = async () => {
  // processMessages(queueURL);
};
// Function to process messages from SQS
export const processMessages = async () => {
  const params = {
    QueueUrl: `${queueURL}/${process.env.SQS_QUEUE_NAME}`,
    MaxNumberOfMessages: 1,
    WaitTimeSeconds: 20, // Long polling duration
  };

  try {
    const data = await sqs.receiveMessage(params).promise();
    if (data.Messages && data.Messages.length) {
      const promises = data.Messages.map(async message => {
        // const body = JSON.parse(message.Body);
        const body = {
          '@timestamp': '2024-05-22T09:15:41.890Z',
          '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
          '@id':
            'http://vtw.elsevier.com/message/id/Elsevier/SMS/93d5eb30-c501-4cce-8b4c-568a091873be',
          '@type': 'msg:Message',
          'msg:format':
            'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
          'msg:type':
            'http://vtw.elsevier.com/data/voc/MessageTypes/ServiceCall-1',
          'msg:from':
            'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/ProcessManager/JournalProduction',
          'msg:to':
            'http://vtw.elsevier.com/data/voc/Contributors/MPS/BookSupplier',
          'msg:service': {
            '@id':
              'http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/0aa3df7d-34c1-4b16-b9da-c5b85f34f143',
            '@type': 'msg:ServiceCall',
            'svc:time': '2024-05-22T09:15:41.890Z',
            'svc:type':
              'http://vtw.elsevier.com/data/voc/ServiceCalls/GenerateAltText',
            'svc:about':
              'http://uatnp.vtw-np.elsevier.com/content/pii/B9780128197288000512',
            'svc:resource': [
              'http://uatnp.vtw.elsevier.com/content/egi/10S7RV9BD6Q',
              'http://uatnp.vtw.elsevier.com/content/egi/10PHSKQMCC3',
            ],
            'svc:params': [
              {
                compositorNote: '<p>MTEL-Emfc-New</p>',
                chapterPit: 'CHP',
                chapterNumber: '',
                chapterTitle:
                  'TEST: Lithium and Sodium Layered Oxide Cathodes for Secondary Batteries: Structural and Electronic Considerations',
                chapterFormattedPii: 'B978-0-12-819728-8.00040-9',
                copyEditLevel: '',
              },
              {
                moreDetails: {
                  workflowName: 'AltTextProcess',
                  businessKey: 'B9780128197288000512',
                },
              },
            ],
          },
        };
        const metaInfo = {
          jobFlowType: 'Article',
          title: '',
          stage: '',
          isbn: '',
          duId: 93,
          wfId: 32,
          customerName: 'KLI',
          customerId: 70,
          journalAcronym: 'EUCL',
          jobType: '1',
          woType: 'Journal',
        };
        try {
          if (!Object.keys(body).length) {
            throw new Error('Job received without payload');
          }
          const jobFlowType = 'Article';
          const piiNumber = path.basename(body['msg:service']['svc:about']);

          const ackMsgInfo = {
            messageSMSId: path.basename(body['@id']),
            serviceSMSId: path.basename(body['msg:service']['@id']),
            serviceAboutUrl: path.basename(body['msg:service']['svc:about']),
          };

          let logPayload = {
            ...metaInfo,
            ackMsgInfo,
            response: body,
            status: 'In Progress',
          };
          const { data: signalAuditId } = await ialtSignalLogService(
            logPayload,
            'Insert',
          );
          try {
            // const signalAckPayload = {
            //   signalAuditId,
            //   piiNumber,
            //   ackMsgInfo,
            // };
            // await ialtJobReceivedAcknowledgeService(signalAckPayload);
            // get the metadata info
            // const result = await getMetaData(signalAckPayload);
            // metaInfo = await readMetadata(result, metaInfo);

            // update job info to log
            logPayload.title = metaInfo.title;
            logPayload.stage = metaInfo.stage;
            logPayload.signalAuditId = signalAuditId;
            await ialtSignalLogService(logPayload, 'Update');

            // // download source files
            // const assetDownloadRes = await downloadAssetFile(
            //   metaInfo.assetInfo,
            //   signalAckPayload,
            // );

            // // get du , customer, stage, dms info
            // const genaralInfo = await getGeneralInfo(metaInfo);
            // // upload source file to blob
            // const assetUploadRes = await assetUploadProcess({
            //   assetDownloadRes,
            //   signalAuditId,
            //   genaralInfo,
            // });
            // const allFiles = assetUploadRes.map(item => item.allPath);
            // const originalFiles = assetUploadRes
            //   .map(item => item.pathWithSAS)
            //   .filter(p => p !== '');

            const jobPayload = {
              ...metaInfo,
              // ...genaralInfo,
              signalAuditId,
              jobFlowType,
              piiNumber,
              ackMsgInfo,
              // metaData: result,
              // originalFiles,
              // allFiles,
            };
            const response = await iAltAutoJobCreationService(jobPayload);

            // return response;
          } catch (err) {
            logPayload = {
              signalAuditId,
              response: err.message,
              status: 'Failed',
            };
            await ialtSignalLogService(logPayload, 'Update');
            throw new Error(err.message);
          }
        } catch (err) {
          const mailPayload = {
            action: 'job_receive_common_failure',
            to: [],
            title: metaInfo.title,
            stageName: metaInfo.stage,
            message: err.message ? err.message : err,
          };
          await sendMail(mailPayload);
        } finally {
          await deleteMessage(message.ReceiptHandle);
        }
      });
      await Promise.all(promises);
    }
  } catch (err) {
    console.error('Error receiving messages:', err);
  } finally {
    // Continue listening for messages
    // processMessages(queueURL);
  }
};
// Function to send a message to SQS
export const sendMessageToSQSService = async messageBody => {
  try {
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: '',

      // QueueUrl: `${queueURL}/${process.env.SQS_QUEUE_NAME}`,
    };
    const data = await sqs.sendMessage(params).promise();
  } catch (err) {
    console.error('Error sending message', err);
  }
};
export const listInBucketsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const data = await s3
        .listObjectsV2({
          Bucket: payload.bucketName,
          Prefix: payload.folderPath,
        })
        .promise();
      resolve(data.Contents);
      // to get all buckets
      // s3.listBuckets((err, data) => {
      //   if (err) {
      //
      //   } else {
      //
      //   }
      // });
    } catch (err) {
      console.error('Error listing objects in bucket:', err);
      reject(err); // Throw error for caller to handle
    }
  });
};
// Function to delete a message from the SQS queue
const deleteMessage = async receiptHandle => {
  const params = {
    QueueUrl: queueURL,
    ReceiptHandle: receiptHandle,
  };

  try {
    // await sqs.deleteMessage(params).promise();
  } catch (err) {
    console.error('Error deleting message:', err);
  }
};
export const uploadFileToS3Service = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { filePath } = payload;
      // Download the file from the provided folder URL
      const url = new URL(filePath);
      const fileName = path.basename(url.pathname);
      const tempFilePath = `tempFolder/${fileName}`; // Temporary download path
      try {
        await downloadFileFromUrl(filePath, tempFilePath);
        // Read content from the file
        const fileContent = fs.readFileSync(tempFilePath);
        // Setting up S3 upload parameters
        const params = {
          Bucket: `${bucketName}`,
          Key: `${folderPath}/${fileName}`,
          Body: fileContent,
          ACL: 'bucket-owner-full-control',
        };
        // Uploading files to the bucket
        const data = await s3.upload(params).promise();

        resolve(data); // Return uploaded file metadata
      } catch (err) {
        console.error('Error uploading file to S3:', err);
        reject(err); // Throw error for caller to handle
      } finally {
        // fs.unlinkSync(tempFilePath); // Clean up temporary file
      }
    } catch (err) {
      reject(err);
    }
  });
};
const downloadFileFromUrl = (fileUrl, destPath) => {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);

    https
      .get(fileUrl, response => {
        response.pipe(file);
        file.on('finish', () => {
          file.close(resolve); // close() is async, resolve after close completes.
        });
      })
      .on('error', err => {
        fs.unlink(destPath, () => reject(err)); // Delete the file async. (But we don't check the result)
      });
  });
};
export const altTextUploadNotification = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { Location, ETag, piiNumber, key } = data;
      const assetVersion = ETag.replace(/^"|"$/g, '');
      const fileName = path.basename(Location);
      const payload = {
        '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
        '@type': 'bam:ContentObjects',
        'bam:hasContentObjects': [
          {
            '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
            '@type': 'bam:Metadata',
            '@id': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
            'dct:language': 'en',
            'ecm:identifier': `pii:${piiNumber}`,
            'dct:title': 'Como articular la cooperación en red',
            'prism:aggregationType': [
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3',
            ],
            'dct:type':
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3.1',
            'bam:hasAssetMetadata': [
              {
                '@id': `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                '@type': 'bam:AssetMetadata',
                'dct:isFormatOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'dct:format':
                  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'bam:assetType': 'ALTERNATE-TEXT',
                'bam:assetVersion': `${assetVersion}`,
                'prism:byteCount': 2619,
                'bam:mode': 'private',
                'bam:filename': `${fileName}`,
                'bam:multiPart': false,
              },
            ],
            'bam:hasGeneration': [
              {
                '@type': 'bam:Generation',
                'bam:isGenerationOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'bam:hasAsset': [
                  `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                ],
                'bam:classificationLevel': 'public',
                'bam:stage': 'uncorrected_proof',
                'bam:hasGeneration': [],
              },
            ],
          },
        ],
      };
      const url = `${config.iAlt.else_vier.base_url}/${config.iAlt.else_vier.uri.upload}`;
      const result = await service.ialtPost(url, payload);
      resolve(result);
    } catch (err) {
      reject('Alt text upload notification sending failed');
    }
  });
};

const getMetaData = data => {
  return new Promise(async (resolve, reject) => {
    const { piiNumber, signalAuditId } = data;
    const url = `${config.iAlt.else_vier.base_url}/metadata/pii/${piiNumber}`;
    try {
      const result = await service.ialtGet(url);
      if (Object.keys(result).length) {
        const logHisPayload = {
          signalAuditId,
          request: url,
          response: result,
          status: 'Metadata fetching request successful',
        };
        await ialtSignalLogHistory(logHisPayload);
        resolve(result);
      } else {
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: url,
        response: err.message ? err.message : err,
        status: 'Metadata info not found',
      };
      await ialtSignalLogHistory(logHisPayload);
      await ialtFailedAcknowledgeService(data);
      reject(err.message ? err.message : err);
    }
  });
};
export const readMetadata = (result, payload) => {
  return new Promise((resolve, reject) => {
    try {
      const jobInfo = {
        ...payload,
      };
      const allStageSourceInfo = result['bam:hasGeneration'];
      let stageSourceInfo = [];
      stageSourceInfo = result['bam:hasGeneration'].filter(
        item => item['bam:stage'] === 'accepted_manuscript',
      );
      const getMaxVerison = stageSourceInfo.reduce(
        (max, row) =>
          row['bam:generation'] > max['bam:generation'] ? row : max,
        allStageSourceInfo[0],
      );
      const assetInfo = getMaxVerison['bam:hasAsset'];
      if (getMaxVerison['bam:stage'] === 'accepted_manuscript') {
        jobInfo.stage = 'Accepted Manuscript';
      } else {
        jobInfo.stage = getMaxVerison['bam:stage'];
      }
      jobInfo.title = result['dct:title'];
      jobInfo.isbn = result['prism:isbn'].replace(/-/g, '');
      jobInfo.assetInfo = assetInfo;
      resolve(jobInfo);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};
// download asset file from client
const downloadAssetFile = (assetInfo, data) => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = data;
    try {
      const assetPromises = assetInfo.map(async item => {
        const assetUrl = item;
        const {
          data: sourceContent,
          filename,
          contentType,
        } = await service.ialtGetWithBlob(assetUrl);
        return { sourceContent, filename, contentType };
      });
      const assetDownloadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: JSON.stringify(assetDownloadRes),
        status: 'Source file downloaded successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(assetDownloadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: err.message ? err.message : 'Source file downloaded failed',
        status: 'Source file downloaded failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      await ialtFailedAcknowledgeService(data);
      reject(err);
    }
  });
};
// get du, customer info
const getGeneralInfo = payload => {
  return new Promise(async (resolve, reject) => {
    const { duId, customerId, stage } = payload;
    try {
      let sql = `select duid, duname from org_mst_deliveryunit where duid=${duId} and isactive=true`;
      const duInfo = await query(sql);
      sql = `select customerid, customername from org_mst_customer where customerid=${customerId} and isactive=true`;
      const custInfo = await query(sql);
      sql = `select stageid, stagename from wms_mst_stage where stagename='${stage}' and isactive=true`;
      const stageInfo = await query(sql);
      sql = ` SELECT dms_master.dmsid, dms_master.dmstype FROM wms_mst_customerconfigdetails 
      JOIN dms_master ON dms_master.dmsid = wms_mst_customerconfigdetails.dmsid
      WHERE customerid=${customerId} and dms_master.isactive`;

      const dmsInfo = await query(sql);
      if (
        duInfo.length &&
        custInfo.length &&
        stageInfo.length &&
        dmsInfo.length
      ) {
        resolve({
          ...payload,
          du: { id: duInfo[0].duid, name: duInfo[0].duname },
          customer: {
            id: custInfo[0].customerid,
            name: custInfo[0].customername,
          },
          stage: { id: stageInfo[0].stageid, name: stageInfo[0].stagename },
          dms: { id: dmsInfo[0].dmsid, name: dmsInfo[0].dmstype },
        });
      } else {
        throw new Error('Du | Customer | Stage info not found');
      }
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};
// asset upload process
const assetUploadProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      assetDownloadRes,
      signalAuditId,
      genaralInfo: { du, customer, stage, title },
    } = payload;
    try {
      const folderPathData = {
        type: 'ialt_book_chapter_stage',
        duName: du.name,
        customerName: customer.name,
        bookName: title,
        chapterName: title,
        stageName: stage.name,
      };
      const pathToStore = await getFolderStructureForIalt(folderPathData);
      const assetPromises = assetDownloadRes.map(async item => {
        const docPath = `${pathToStore}/${item.filename}`;
        const { fullPath } = await _uploads3File(
          docPath,
          item.sourceContent,
          item.contentType,
        );
        let sasPath = {};
        if (fullPath.includes('.pdf')) {
          const { data } = await _downloadForIalt(fullPath);
          sasPath = data;
        }
        return {
          allPath: fullPath,
          pathWithSAS: sasPath.path ? sasPath.path : '',
        };
      });
      const assetUploadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(payload),
        response: JSON.stringify(assetUploadRes),
        status: 'Source file uploaded to blob successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(assetUploadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(payload),
        response: err.message
          ? err.message
          : 'Source file upload to blob failed',
        status: 'Source file upload to blob failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// job received acknowledgement to client
export const ialtJobReceivedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      const tokenRes = await service.post(url, data);
      const { auth_token } = tokenRes.data;
      data = {
        '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/AltTextSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
        'msg:event': {
          '@id':
            'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-1008-4e52-9b8a-c75f8c6c7742',
          '@type': 'msg:EventNotification',
          'evt:time': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
          'evt:type':
            'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      const result = await service.post(url, data, headers);
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: result,
        status: 'Job received acknowledgment sent successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Sent failed',
        status: 'Job received acknowledgement sent failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      // resolve(true);
      reject(error);
    }
  });
};
// failed acknowledgement to client
export const ialtFailedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      const tokenRes = await service.post(url, data);
      const { auth_token } = tokenRes.data;
      data = {
        '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/AltTextSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
        'msg:event': {
          '@id':
            'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-5007-4e52-9b8a-c75f8c6c7742',
          '@type': 'msg:EventNotification',
          'evt:time': '2024-07-11T11:17:54.777Z',
          'evt:type':
            'http://vtw.elsevier.com/data/voc/Events/FinishedSuccessfully',
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      const result = await service.post(url, data, headers);
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: result,
        status: 'Job failure acknowledgment sent successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Sent failed',
        status: 'Job failure acknowledgment sent failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      // resolve(true);
      reject(error);
    }
  });
};
// job completed acknowledgement to client
export const ialtJobCompletedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
      queueUrl,
    } = payload;
    const messageBody = {
      '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
      '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
      '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
      '@type': 'msg:Message',
      'msg:format': 'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
      'msg:type':
        'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
      'msg:from':
        'http://vtw.elsevier.com/data/voc/Contributors/MPS/BookSupplier',
      'msg:to':
        'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
      'msg:event': {
        '@id':
          'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-1008-4e52-9b8a-c75f8c6c7742',
        '@type': 'msg:EventNotification',
        'evt:time': '2024-05-29T11:07:25.777Z',
        'evt:type':
          'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
        'evt:about': `${serviceAboutUrl}`,
        'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
      },
    };
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: queueUrl,
    };
    try {
      const data = await sqs.sendMessage(params).promise();
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent successfully',
        status: 'Job received acknowledgment sent successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent failed',
        status: 'Job received acknowledgement sent failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { action, to, customerId, message, title, stageName } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        customerId,
      };
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        stageName,
        subMessage: message,
        toMail: toMailArray,
      };
      await emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};
// get dms info
const getDmsInfo = customerId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE customerid=$1`;
      const dmsInfo = await query(sql, [customerId]);
      const { dmsid } = dmsInfo[0];
      resolve(dmsid);
    } catch (err) {
      reject('DMS info not found for the customer');
    }
  });
};
export { startListening };
