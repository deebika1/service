/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
// import {
//   createEventLog,
//   updateEventLog,
//   updateEventLogDetails,
// } from '../../modules/bpmn/listener/updatedb.js';
import {
  // getFirstActivityId,
  // getIaltWorkflowInfo,
  createEventLog,
  updateEventLog,
  updateEventLogDetails,
  // getiAltTaskListScript,
  getChapterListScript,
  getPayloadInfo,
  workorderCreation,
  woServiceCreation,
  woStageCreation,
  addIncoming,
  addIncomingFiles,
  updateTriggerStatusScript,
  getNextActivityScript,
  updateTriggerStatusOnServiceScript,
  // fileTransactionScript,
  updateComplexity,
  captureApiEventLog,
  getChapterListByTypeScript,
} from '../datalayer/index.js';
import { query, transaction } from '../../database/postgres.js';
import { getdmsType } from '../../modules/bpmn/listener/create.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import {
  getXlReportData,
  sendExcelFileIalt,
  _triggerIaltWorkflowController,
} from '../controller/index.js';
import {
  uploadFileToS3Service,
  altTextUploadNotification,
  ialtFailedAcknowledgeService,
  downloadAssetFile,
  assetUploadProcess,
  altextGenerationJobService,
  ialtJobReceivedAcknowledgeService,
  readJobData,
} from '../../signalIntegration/service/elseVier/altTextJobProcess.js';
import moment from 'moment';
import {
  fileCopyForElsevierJournalFromSignal,
  wmsWorkflowTrigger,
  _saveChapter,
} from '../../modules/woi/incoming.js';
import { _downloadForIalt } from '../../modules/utils/azure/index.js';
import {
  // altextGenerationJobService,
  getGeneralInfo,
  ialtSuccessAcknowledgeService,
} from './altTextJobProcess.js';
import { sendMail } from '../../modules/iTracks/index.js';
import archiver from 'archiver';
import { basename, join, parse } from 'path';
import axios from 'axios';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { getFolderStructureForIalt } from '../../modules/utils/wmsFolder/index.js';
import { fetchJsonFromAzureBlob } from '../blobService/utils/blob.js';

const __filename = fileURLToPath(import.meta.url);
const pattern = ';{{placeholder}};';

// import { makeDir, removeFile } from '../../modules/utils/custom/io.js';

const service = new Service();

const jobTypeObj = {
  1: 'Article',
  2: 'Issue',
  3: 'Non Article',
};

const ialt_tasklist = `
SELECT *
FROM (
    SELECT DISTINCT ON (wms_workflow_eventlog.wfeventid) wms_workflow_eventlog.wfeventid,
           wms_workorder_incomingfiledetails.woincomingfileid,
           wms_workorder_incomingfiledetails.filename,
           wms_workorder_incomingfiledetails.filetypeid,
           wms_workorder_incomingfiledetails.filepath,
           wms_workorder_incomingfiledetails.fileuuid,
           wms_workflowdefinition.activitytype,
           wms_workflowdefinition.activityalias,
           wms_workflowdefinition.activityalias AS activitywithcount,
           wms_mst_stage.stagename AS stagewithcount,
           wms_workflowdefinition.stageid,
           wms_workflowdefinition.activityid,
           wms_workflowdefinition.instancetype,
           wms_workflowdefinition.nextactivityid,
           wms_mst_stage.stagename,
           wms_mst_activity.activityname,
           ialt_books.bookid,
           ialt_books.bookname,
           concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') AS booknamewithedition,
           ialt_books.chaptercount,
           ialt_books.editorname AS editon,
           ialt_books.isbn,
           ialt_books.createdby,
           concat(userinfo.username, ' (', userinfo.userid, ')') AS pm,
           wms_workflow_eventlog.userid,
           wms_workflow_eventlog.skillid,
           wms_workflow_eventlog.wfdefid,
           wms_workflow_eventlog.activitystatus,
           wms_workflow_eventlog.stageiterationcount,
           wms_workflow_eventlog.activityiterationcount,
           wms_workflow_eventlog.activitycount,
           wms_workflow_eventlog.actualactivitycount,
           wms_workorder.workorderid,
           ialt_mst_complexity.complexityid,
           ialt_mst_complexity.complexity,
           org_mst_deliveryunit.duid,
           wms_workorder.jobcardid,
           wms_workorder.wotype,
           wms_workorder_service.serviceid,
           wms_mst_service.servicename,
           org_mst_deliveryunit.duname,
           wms_workorder.customerid,
           org_mst_customer.customername,
           wms_workorder.itemcode,
           wms_workorder.title,
           wms_workorder.assignedby,
           wms_workorder.totalchaptercount AS imagecount,
           CASE
               WHEN wms_user.username::text <> 'System'::text 
               THEN concat(wms_user.username, ' (', wms_user.userid, ')')::character varying
               ELSE wms_user.username
           END AS assignedto,
           pp_mst_filetype.filetype,
           wms_userrole.roleid,
           false AS isselected,
           wms_workorder_incomingfiledetails.assettype,
           wms_workorder.status AS chapterstatus,
           wms_workorder.isactive AS ischapteractive,
           ialt_books.isactive AS isbookactive,
           ialt_books.status AS bookstatus,
           to_char(ialt_books.startdate::timestamp, 'DD-MM-YYYY') AS startdate,
           to_char(ialt_books.receiveddate::timestamp, 'DD-MM-YYYY') AS receiveddate,
           to_char(ialt_books.enddate::timestamp, 'DD-MM-YYYY') AS enddate,
           to_char(ialt_books.actualenddate::timestamp, 'DD-MM-YYYY') AS actualenddate,
           to_char(wms_workorder_stage.plannedstartdate::timestamp, 'DD-MM-YYYY') AS chapterstartdate,
           to_char(wms_workorder_stage.plannedenddate::timestamp, 'DD-MM-YYYY') AS chapterenddate,
           to_char(wms_workorder_stage.enddatetime::timestamp, 'DD-MM-YYYY') AS chapteractualenddate,
           ialt_books.instruction,
           ialt_books.assignedby AS bookassignedby,
           wms_workorder.otherfield ->> 'pii' AS piinumber,
           wms_workflowdefinition.config,
           wms_workflowdefinition.rejectactivity,
           org_mst_customer.short_description_length,
                   CASE
            WHEN (EXTRACT(epoch FROM age(now()::timestamp without time zone, wms_workflow_eventlog.updated_date)) / 60::numeric) <= 10::numeric THEN false
            ELSE true
        END AS isretrigger
    FROM wms_workflow_eventlog
    JOIN wms_workorder_service 
        ON wms_workorder_service.workorderid = wms_workflow_eventlog.workorderid
    JOIN wms_workorder 
        ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid 
        AND wms_workorder.isactive <> false
       AND wms_workorder.wotype::text = 'ialt'::text
    JOIN ialt_books 
        ON ialt_books.bookid = wms_workorder.bookid 
        AND wms_workorder.isactive <> false
    LEFT JOIN wms_user 
        ON wms_user.userid::text = wms_workflow_eventlog.userid::text
    JOIN wms_workflowdefinition 
        ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
    JOIN wms_workorder_stage 
        ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid
        AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid
        AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid
        AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
    JOIN wms_workorder_incomingfiledetails 
        ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
    JOIN org_mst_deliveryunit 
        ON org_mst_deliveryunit.duid = wms_workorder.duid
    JOIN wms_mst_service 
        ON wms_mst_service.serviceid = wms_workorder_service.serviceid
    JOIN wms_workflow 
        ON wms_workflow.wfid = wms_workorder_service.wfid
    JOIN org_mst_customer 
        ON org_mst_customer.customerid = wms_workorder.customerid
    LEFT JOIN wms_mst_stage 
        ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
    LEFT JOIN wms_mst_activity 
        ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
    LEFT JOIN pp_mst_filetype 
        ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
    LEFT JOIN wms_userrole 
        ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
    LEFT JOIN ialt_mst_complexity 
        ON ialt_mst_complexity.complexityid = wms_workorder_incomingfiledetails.complexityid
    LEFT JOIN wms_user userinfo 
        ON userinfo.userid::text = ialt_books.createdby::text
) AS ialt_tasklist
`;
const ialt_tasklist_query = `
    SELECT DISTINCT ON (wms_workflow_eventlog.wfeventid) wms_workflow_eventlog.wfeventid,
           wms_workorder_incomingfiledetails.woincomingfileid,
           wms_workorder_incomingfiledetails.filename,
           wms_workorder_incomingfiledetails.filetypeid,
           wms_workorder_incomingfiledetails.filepath,
           wms_workorder_incomingfiledetails.fileuuid,
           wms_workflowdefinition.activitytype,
           wms_workflowdefinition.activityalias,
           wms_workflowdefinition.activityalias AS activitywithcount,
           wms_mst_stage.stagename AS stagewithcount,
           wms_workflowdefinition.stageid,
           wms_workflowdefinition.activityid,
           wms_workflowdefinition.instancetype,
           wms_workflowdefinition.nextactivityid,
           wms_mst_stage.stagename,
           wms_mst_activity.activityname,
           ialt_books.bookid,
           ialt_books.bookname,
           concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') AS booknamewithedition,
           ialt_books.chaptercount,
           ialt_books.editorname AS editon,
           ialt_books.isbn,
           ialt_books.createdby,
           concat(userinfo.username, ' (', userinfo.userid, ')') AS pm,
           wms_workflow_eventlog.userid,
           wms_workflow_eventlog.skillid,
           wms_workflow_eventlog.wfdefid,
           wms_workflow_eventlog.activitystatus,
           wms_workflow_eventlog.stageiterationcount,
           wms_workflow_eventlog.activityiterationcount,
           wms_workflow_eventlog.activitycount,
           wms_workflow_eventlog.actualactivitycount,
           wms_workorder.workorderid,
           ialt_mst_complexity.complexityid,
           ialt_mst_complexity.complexity,
           org_mst_deliveryunit.duid,
           wms_workorder.jobcardid,
           wms_workorder.wotype,
           wms_workorder_service.serviceid,
           wms_mst_service.servicename,
           org_mst_deliveryunit.duname,
           wms_workorder.customerid,
           org_mst_customer.customername,
           wms_workorder.itemcode,
           wms_workorder.title,
           wms_workorder.assignedby,
           wms_workorder.totalchaptercount AS imagecount,
           CASE
               WHEN wms_user.username::text <> 'System'::text 
               THEN concat(wms_user.username, ' (', wms_user.userid, ')')::character varying
               ELSE wms_user.username
           END AS assignedto,
           pp_mst_filetype.filetype,
           wms_userrole.roleid,
           false AS isselected,
           wms_workorder_incomingfiledetails.assettype,
           wms_workorder.status AS chapterstatus,
           wms_workorder.isactive AS ischapteractive,
           ialt_books.isactive AS isbookactive,
           ialt_books.status AS bookstatus,
           to_char(ialt_books.startdate::timestamp, 'DD-MM-YYYY') AS startdate,
           to_char(ialt_books.receiveddate::timestamp, 'DD-MM-YYYY') AS receiveddate,
           to_char(ialt_books.enddate::timestamp, 'DD-MM-YYYY') AS enddate,
           to_char(ialt_books.actualenddate::timestamp, 'DD-MM-YYYY') AS actualenddate,
           to_char(wms_workorder_stage.plannedstartdate::timestamp, 'DD-MM-YYYY') AS chapterstartdate,
           to_char(wms_workorder_stage.plannedenddate::timestamp, 'DD-MM-YYYY') AS chapterenddate,
           to_char(wms_workorder_stage.enddatetime::timestamp, 'DD-MM-YYYY') AS chapteractualenddate,
           ialt_books.instruction,
           ialt_books.assignedby AS bookassignedby,
           wms_workorder.otherfield ->> 'pii' AS piinumber,
           wms_workflowdefinition.config,
           wms_workflowdefinition.rejectactivity,
           org_mst_customer.short_description_length,
                   CASE
            WHEN (EXTRACT(epoch FROM age(now()::timestamp without time zone, wms_workflow_eventlog.updated_date)) / 60::numeric) <= 10::numeric THEN false
            ELSE true
        END AS isretrigger
    FROM wms_workflow_eventlog
    JOIN wms_workorder_service 
        ON wms_workorder_service.workorderid = wms_workflow_eventlog.workorderid
    JOIN wms_workorder 
        ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid 
        AND wms_workorder.isactive <> false
        AND wms_workorder.wotype::text = 'ialt'::text
    JOIN ialt_books 
        ON ialt_books.bookid = wms_workorder.bookid 
        AND wms_workorder.isactive <> false
    LEFT JOIN wms_user 
        ON wms_user.userid::text = wms_workflow_eventlog.userid::text
    JOIN wms_workflowdefinition 
        ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
    JOIN wms_workorder_stage 
        ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid
        AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid
        AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid
        AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
    JOIN wms_workorder_incomingfiledetails 
        ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
    JOIN org_mst_deliveryunit 
        ON org_mst_deliveryunit.duid = wms_workorder.duid
    JOIN wms_mst_service 
        ON wms_mst_service.serviceid = wms_workorder_service.serviceid
    JOIN wms_workflow 
        ON wms_workflow.wfid = wms_workorder_service.wfid
    JOIN org_mst_customer 
        ON org_mst_customer.customerid = wms_workorder.customerid
    LEFT JOIN wms_mst_stage 
        ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
    LEFT JOIN wms_mst_activity 
        ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
    LEFT JOIN pp_mst_filetype 
        ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
    LEFT JOIN wms_userrole 
        ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
    LEFT JOIN ialt_mst_complexity 
        ON ialt_mst_complexity.complexityid = wms_workorder_incomingfiledetails.complexityid
    LEFT JOIN wms_user userinfo 
        ON userinfo.userid::text = ialt_books.createdby::text
`;

const ialt_tasklist_query_fun = (
  activitystatus,
  activityid,
  bookassignedby,
  eventlogUserid,
) => {
  const sql_query = `
   SELECT DISTINCT ON (wms_workflow_eventlog.wfeventid) 
           wms_workflow_eventlog.wfeventid,
           wms_workorder_incomingfiledetails.woincomingfileid,
           wms_workorder_incomingfiledetails.filename,
           wms_workorder_incomingfiledetails.filetypeid,
           wms_workorder_incomingfiledetails.filepath,
           wms_workorder_incomingfiledetails.fileuuid,
           wms_workflowdefinition.activitytype,
           wms_workflowdefinition.activityalias,
           wms_workflowdefinition.activityalias AS activitywithcount,
           wms_mst_stage.stagename AS stagewithcount,
           wms_workflowdefinition.stageid,
           wms_workflowdefinition.activityid,
           wms_workflowdefinition.instancetype,
           wms_workflowdefinition.nextactivityid,
           wms_mst_stage.stagename,
           wms_mst_activity.activityname,
           ialt_books.bookid,
           ialt_books.bookname,
           concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') AS booknamewithedition,
           ialt_books.chaptercount,
           ialt_books.editorname AS editon,
           ialt_books.isbn,
           ialt_books.createdby,
           concat(userinfo.username, ' (', userinfo.userid, ')') AS pm,
           wms_workflow_eventlog.userid,
           wms_workflow_eventlog.skillid,
           wms_workflow_eventlog.wfdefid,
           wms_workflow_eventlog.activitystatus,
           wms_workflow_eventlog.stageiterationcount,
           wms_workflow_eventlog.activityiterationcount,
           wms_workflow_eventlog.activitycount,
           wms_workflow_eventlog.actualactivitycount,
           wms_workorder.workorderid,
           ialt_mst_complexity.complexityid,
           ialt_mst_complexity.complexity,
           org_mst_deliveryunit.duid,
           wms_workorder.jobcardid,
           wms_workorder.wotype,
           wms_workorder_service.serviceid,
           wms_mst_service.servicename,
           org_mst_deliveryunit.duname,
           wms_workorder.customerid,
           org_mst_customer.customername,
           wms_workorder.itemcode,
           wms_workorder.title,
           wms_workorder.assignedby,
           wms_workorder.totalchaptercount AS imagecount,
           CASE
               WHEN wms_user.username::text <> 'System'::text 
               THEN concat(wms_user.username, ' (', wms_user.userid, ')')::character varying
               ELSE wms_user.username
           END AS assignedto,
           pp_mst_filetype.filetype,
           wms_userrole.roleid,
           false AS isselected,
           wms_workorder_incomingfiledetails.assettype,
           wms_workorder.status AS chapterstatus,
           wms_workorder.isactive AS ischapteractive,
           ialt_books.isactive AS isbookactive,
           ialt_books.status AS bookstatus,
           to_char(ialt_books.startdate::timestamp, 'DD-MM-YYYY') AS startdate,
           to_char(ialt_books.receiveddate::timestamp, 'DD-MM-YYYY') AS receiveddate,
           to_char(ialt_books.enddate::timestamp, 'DD-MM-YYYY') AS enddate,
           to_char(ialt_books.actualenddate::timestamp, 'DD-MM-YYYY') AS actualenddate,
           to_char(wms_workorder_stage.plannedstartdate::timestamp, 'DD-MM-YYYY') AS chapterstartdate,
           to_char(wms_workorder_stage.plannedenddate::timestamp, 'DD-MM-YYYY') AS chapterenddate,
           to_char(wms_workorder_stage.enddatetime::timestamp, 'DD-MM-YYYY') AS chapteractualenddate,
           ialt_books.instruction,
           ialt_books.assignedby AS bookassignedby,
           wms_workorder.otherfield ->> 'pii' AS piinumber,
           wms_workflowdefinition.config,
           wms_workflowdefinition.rejectactivity,
           org_mst_customer.short_description_length,
                   CASE
            WHEN (EXTRACT(epoch FROM age(now()::timestamp without time zone, wms_workflow_eventlog.updated_date)) / 60::numeric) <= 10::numeric THEN false
            ELSE true
        END AS isretrigger
    FROM wms_workflow_eventlog
    JOIN wms_workorder_service 
        ON wms_workorder_service.workorderid = wms_workflow_eventlog.workorderid
    JOIN wms_workorder 
        ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid 
        AND wms_workorder.isactive = true
        AND wms_workorder.status <> 'Completed'
        AND wms_workorder.wotype::text = 'ialt'::text
    JOIN ialt_books 
        ON ialt_books.bookid = wms_workorder.bookid 
        AND ialt_books.isactive = true
        ${bookassignedby}
    LEFT JOIN wms_user 
        ON wms_user.userid::text = wms_workflow_eventlog.userid::text
    JOIN wms_workflowdefinition 
        ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
        And ${activityid}

    JOIN wms_workorder_stage 
        ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid
        AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid
        AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid
        AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
    JOIN wms_workorder_incomingfiledetails 
        ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
    JOIN org_mst_deliveryunit 
        ON org_mst_deliveryunit.duid = wms_workorder.duid
    JOIN wms_mst_service 
        ON wms_mst_service.serviceid = wms_workorder_service.serviceid
    JOIN wms_workflow 
        ON wms_workflow.wfid = wms_workorder_service.wfid
    JOIN org_mst_customer 
        ON org_mst_customer.customerid = wms_workorder.customerid
    LEFT JOIN wms_mst_stage 
        ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
    LEFT JOIN wms_mst_activity 
        ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
    LEFT JOIN pp_mst_filetype 
        ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
    LEFT JOIN wms_userrole 
        ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
    LEFT JOIN ialt_mst_complexity 
        ON ialt_mst_complexity.complexityid = wms_workorder_incomingfiledetails.complexityid
    LEFT JOIN wms_user userinfo 
        ON userinfo.userid::text = ialt_books.createdby::text
        WHERE ${activitystatus}  ${eventlogUserid}
        ORDER BY wfeventid,workorderid DESC
`;
  return sql_query;
};
const ialt_tasklist_fun = (
  activitystatus,
  activityid,
  bookassignedby,
  eventlogUserid,
) => {
  const sql_query = `
    SELECT distinct on (workorderid)
           wms_workflow_eventlog.wfeventid,
           wms_workorder_incomingfiledetails.woincomingfileid,
           wms_workorder_incomingfiledetails.filename,
           wms_workorder_incomingfiledetails.filetypeid,
           wms_workorder_incomingfiledetails.filepath,
           wms_workorder_incomingfiledetails.fileuuid,
           wms_workflowdefinition.activitytype,
           wms_workflowdefinition.activityalias,
           wms_workflowdefinition.activityalias AS activitywithcount,
           wms_mst_stage.stagename AS stagewithcount,
           wms_workflowdefinition.stageid,
           wms_workflowdefinition.activityid,
           wms_workflowdefinition.instancetype,
           wms_workflowdefinition.nextactivityid,
           wms_mst_stage.stagename,
           wms_mst_activity.activityname,
           ialt_books.bookid,
           ialt_books.bookname,
           concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') AS booknamewithedition,
           ialt_books.chaptercount,
           ialt_books.editorname AS editon,
           ialt_books.isbn,
           ialt_books.createdby,
           concat(userinfo.username, ' (', userinfo.userid, ')') AS pm,
           wms_workflow_eventlog.userid,
           wms_workflow_eventlog.skillid,
           wms_workflow_eventlog.wfdefid,
           wms_workflow_eventlog.activitystatus,
           wms_workflow_eventlog.stageiterationcount,
           wms_workflow_eventlog.activityiterationcount,
           wms_workflow_eventlog.activitycount,
           wms_workflow_eventlog.actualactivitycount,
           wms_workorder.workorderid,
           ialt_mst_complexity.complexityid,
           ialt_mst_complexity.complexity,
           org_mst_deliveryunit.duid,
           wms_workorder.jobcardid,
           wms_workorder.wotype,
           wms_workorder_service.serviceid,
           wms_mst_service.servicename,
           org_mst_deliveryunit.duname,
           wms_workorder.customerid,
           org_mst_customer.customername,
           wms_workorder.itemcode,
           wms_workorder.title,
           wms_workorder.assignedby,
           wms_workorder.totalchaptercount AS imagecount,
           CASE
               WHEN wms_user.username::text <> 'System'::text 
               THEN concat(wms_user.username, ' (', wms_user.userid, ')')::character varying
               ELSE wms_user.username
           END AS assignedto,
           pp_mst_filetype.filetype,
           wms_userrole.roleid,
           false AS isselected,
           wms_workorder_incomingfiledetails.assettype,
           wms_workorder.status AS chapterstatus,
           wms_workorder.isactive AS ischapteractive,
           ialt_books.isactive AS isbookactive,
           ialt_books.status AS bookstatus,
           to_char(ialt_books.startdate::timestamp, 'DD-MM-YYYY') AS startdate,
           to_char(ialt_books.receiveddate::timestamp, 'DD-MM-YYYY') AS receiveddate,
           to_char(ialt_books.enddate::timestamp, 'DD-MM-YYYY') AS enddate,
           to_char(ialt_books.actualenddate::timestamp, 'DD-MM-YYYY') AS actualenddate,
           to_char(wms_workorder_stage.plannedstartdate::timestamp, 'DD-MM-YYYY') AS chapterstartdate,
           to_char(wms_workorder_stage.plannedenddate::timestamp, 'DD-MM-YYYY') AS chapterenddate,
           to_char(wms_workorder_stage.enddatetime::timestamp, 'DD-MM-YYYY') AS chapteractualenddate,
           ialt_books.instruction,
           ialt_books.assignedby AS bookassignedby,
           wms_workorder.otherfield ->> 'pii' AS piinumber,
           wms_workflowdefinition.config,
           wms_workflowdefinition.rejectactivity,
           org_mst_customer.short_description_length,
                   CASE
            WHEN (EXTRACT(epoch FROM age(now()::timestamp without time zone, wms_workflow_eventlog.updated_date)) / 60::numeric) <= 10::numeric THEN false
            ELSE true
        END AS isretrigger
    FROM wms_workflow_eventlog
    JOIN wms_workorder_service 
        ON wms_workorder_service.workorderid = wms_workflow_eventlog.workorderid
    JOIN wms_workorder 
        ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid 
        AND wms_workorder.isactive = true
        AND wms_workorder.status <> 'Completed'
        AND wms_workorder.wotype::text = 'ialt'::text
    JOIN ialt_books 
        ON ialt_books.bookid = wms_workorder.bookid 
        AND ialt_books.isactive = true
        ${bookassignedby}
    LEFT JOIN wms_user 
        ON wms_user.userid::text = wms_workflow_eventlog.userid::text
    JOIN wms_workflowdefinition 
        ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
        And ${activityid}

    JOIN wms_workorder_stage 
        ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid
        AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid
        AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid
        AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
    JOIN wms_workorder_incomingfiledetails 
        ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
    JOIN org_mst_deliveryunit 
        ON org_mst_deliveryunit.duid = wms_workorder.duid
    JOIN wms_mst_service 
        ON wms_mst_service.serviceid = wms_workorder_service.serviceid
    JOIN wms_workflow 
        ON wms_workflow.wfid = wms_workorder_service.wfid
    JOIN org_mst_customer 
        ON org_mst_customer.customerid = wms_workorder.customerid
    LEFT JOIN wms_mst_stage 
        ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
    LEFT JOIN wms_mst_activity 
        ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
    LEFT JOIN pp_mst_filetype 
        ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
    LEFT JOIN wms_userrole 
        ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
    LEFT JOIN ialt_mst_complexity 
        ON ialt_mst_complexity.complexityid = wms_workorder_incomingfiledetails.complexityid
    LEFT JOIN wms_user userinfo 
        ON userinfo.userid::text = ialt_books.createdby::text
        WHERE ${activitystatus}  ${eventlogUserid}
        ORDER BY workorderid DESC
`;
  return sql_query;
};

const getIAltReport_query_fun = (chapterstatus, activityid) => {
  const sql_query = `
    SELECT distinct on (workorderid)
           wms_workflow_eventlog.wfeventid,
           wms_workorder_incomingfiledetails.woincomingfileid,
           wms_workorder_incomingfiledetails.filename,
           wms_workorder_incomingfiledetails.filetypeid,
           wms_workorder_incomingfiledetails.filepath,
           wms_workorder_incomingfiledetails.fileuuid,
           wms_workflowdefinition.activitytype,
           wms_workflowdefinition.activityalias,
           wms_workflowdefinition.activityalias AS activitywithcount,
           wms_mst_stage.stagename AS stagewithcount,
           wms_workflowdefinition.stageid,
           wms_workflowdefinition.activityid,
           wms_workflowdefinition.instancetype,
           wms_workflowdefinition.nextactivityid,
           wms_mst_stage.stagename,
           wms_mst_activity.activityname,
           ialt_books.bookid,
           ialt_books.bookname,
           concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') AS booknamewithedition,
           ialt_books.chaptercount,
           ialt_books.editorname AS editon,
           ialt_books.isbn,
           ialt_books.createdby,
           concat(userinfo.username, ' (', userinfo.userid, ')') AS pm,
           wms_workflow_eventlog.userid,
           wms_workflow_eventlog.skillid,
           wms_workflow_eventlog.wfdefid,
           wms_workflow_eventlog.activitystatus,
           wms_workflow_eventlog.stageiterationcount,
           wms_workflow_eventlog.activityiterationcount,
           wms_workflow_eventlog.activitycount,
           wms_workflow_eventlog.actualactivitycount,
           wms_workorder.workorderid,
           ialt_mst_complexity.complexityid,
           ialt_mst_complexity.complexity,
           org_mst_deliveryunit.duid,
           wms_workorder.jobcardid,
           wms_workorder.wotype,
           wms_workorder_service.serviceid,
           wms_mst_service.servicename,
           org_mst_deliveryunit.duname,
           wms_workorder.customerid,
           org_mst_customer.customername,
           wms_workorder.itemcode,
           wms_workorder.title,
           wms_workorder.assignedby,
           wms_workorder.totalchaptercount AS imagecount,
           CASE
               WHEN wms_user.username::text <> 'System'::text 
               THEN concat(wms_user.username, ' (', wms_user.userid, ')')::character varying
               ELSE wms_user.username
           END AS assignedto,
           pp_mst_filetype.filetype,
           wms_userrole.roleid,
           false AS isselected,
           wms_workorder_incomingfiledetails.assettype,
           wms_workorder.status AS chapterstatus,
           wms_workorder.isactive AS ischapteractive,
           ialt_books.isactive AS isbookactive,
           ialt_books.status AS bookstatus,
           to_char(ialt_books.startdate::timestamp, 'DD-MM-YYYY') AS startdate,
           to_char(ialt_books.receiveddate::timestamp, 'DD-MM-YYYY') AS receiveddate,
           to_char(ialt_books.enddate::timestamp, 'DD-MM-YYYY') AS enddate,
           to_char(ialt_books.actualenddate::timestamp, 'DD-MM-YYYY') AS actualenddate,
           to_char(wms_workorder_stage.plannedstartdate::timestamp, 'DD-MM-YYYY') AS chapterstartdate,
           to_char(wms_workorder_stage.plannedenddate::timestamp, 'DD-MM-YYYY') AS chapterenddate,
           to_char(wms_workorder_stage.enddatetime::timestamp, 'DD-MM-YYYY') AS chapteractualenddate,
           ialt_books.instruction,
           ialt_books.assignedby AS bookassignedby,
           wms_workorder.otherfield ->> 'pii' AS piinumber,
           wms_workflowdefinition.config,
           wms_workflowdefinition.rejectactivity,
           org_mst_customer.short_description_length,
                   CASE
            WHEN (EXTRACT(epoch FROM age(now()::timestamp without time zone, wms_workflow_eventlog.updated_date)) / 60::numeric) <= 10::numeric THEN false
            ELSE true
        END AS isretrigger
    FROM wms_workflow_eventlog
    JOIN wms_workorder_service 
        ON wms_workorder_service.workorderid = wms_workflow_eventlog.workorderid
    JOIN wms_workorder 
        ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid 
        AND wms_workorder.isactive = true
        AND wms_workorder.status = '${chapterstatus}'
        AND wms_workorder.wotype::text = 'ialt'::text
    JOIN ialt_books 
        ON ialt_books.bookid = wms_workorder.bookid 
        AND ialt_books.isactive = true
    LEFT JOIN wms_user 
        ON wms_user.userid::text = wms_workflow_eventlog.userid::text
    JOIN wms_workflowdefinition 
        ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
        And wms_workflowdefinition.activityid = ${activityid}
    JOIN wms_workorder_stage 
        ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid
        AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid
        AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid
        AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
    JOIN wms_workorder_incomingfiledetails 
        ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
    JOIN org_mst_deliveryunit 
        ON org_mst_deliveryunit.duid = wms_workorder.duid
    JOIN wms_mst_service 
        ON wms_mst_service.serviceid = wms_workorder_service.serviceid
    JOIN wms_workflow 
        ON wms_workflow.wfid = wms_workorder_service.wfid
    JOIN org_mst_customer 
        ON org_mst_customer.customerid = wms_workorder.customerid
    LEFT JOIN wms_mst_stage 
        ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
    LEFT JOIN wms_mst_activity 
        ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
    LEFT JOIN pp_mst_filetype 
        ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
    LEFT JOIN wms_userrole 
        ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
    LEFT JOIN ialt_mst_complexity 
        ON ialt_mst_complexity.complexityid = wms_workorder_incomingfiledetails.complexityid
    LEFT JOIN wms_user userinfo 
        ON userinfo.userid::text = ialt_books.createdby::text
        ORDER BY workorderid DESC
`;
  return sql_query;
};

// get incoming chapter list
export const getIncomingChapters = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId } = payload;
      const script = await getChapterListScript(payload);
      const response = await query(script, [workorderId]);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
// get incoming chapter list by type
export const getIncomingChaptersByType = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId } = payload;
      const script = await getChapterListByTypeScript(payload);
      const response = await query(script, [workorderId]);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteIncomingChapters = payload => {
  return new Promise(async (resolve, reject) => {
    const { woincomingfileid } = payload;
    const script = `delete from wms_workorder_incomingfiledetails where woincomingfileid=${woincomingfileid}`;
    await query(script);
    resolve(true);
  });
};

export const incomingOperations = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        plannedenddatetime,
        type,
        woincomingfileid,
        isbn,
        totalchaptercount,
        filesequence,
        filesresponse,
        workorderId,
        imagecount,
        serviceId,
        stageId,
        bookid,
      } = payload.item;
      let sql = '';

      let woincomingid = payload.item.woincomingid;

      // Check if an existing woincomingid is present
      let checkSql = `SELECT woincomingid FROM public.wms_workorder_incoming 
                  WHERE woid = ${workorderId} 
                  ORDER BY updatedon DESC LIMIT 1`;

      let existing = await query(checkSql);

      if (existing.length > 0) {
        woincomingid = existing[0].woincomingid;
      } else {
        // Insert if not found
        let insertSql = `INSERT INTO public.wms_workorder_incoming (woid, serviceid, stageid, receiptdate, batchno, updatedon, receiptdatetime)
                     VALUES (${workorderId}, ${serviceId}, ${stageId}, current_timestamp, 1, current_timestamp, current_timestamp)
                     RETURNING woincomingid`;

        let incoming = await query(insertSql);
        woincomingid = incoming[0].woincomingid;
      }
      // let woincomingid = payload.item.woincomingid;

      // if (!woincomingid) {
      //   let sql3 = `INSERT INTO public.wms_workorder_incoming(woid, serviceid, stageid, receiptdate,batchno, updatedon, receiptdatetime)
      //   VALUES (${workorderId}, ${serviceId}, ${stageId}, current_timestamp,
      //      1,current_timestamp, current_timestamp) RETURNING woincomingid`;
      //   let incoming = await query(sql3);
      //   woincomingid = incoming[0].woincomingid;
      // }

      if (payload.type == 'insert') {
        //insert incoming query
        const val = [];
        filesresponse.forEach(list => {
          const filename = `${list.imagename.slice(
            0,
            list.imagename.lastIndexOf('.'),
          )}`;

          const sanitizedValue = filename.replaceAll(/[^a-zA-Z0-9.-]/g, '_');
          const sanitizedImageNumber =
            list.image_number &&
            list.image_number.replaceAll(/[^a-zA-Z0-9.-]/g, '_');

          val.push(
            `(${woincomingid},85,'${list.imageurl.replace(/'/g, "''")}','${
              list._id
            }','${sanitizedValue.replace(/'/g, "''")}',${
              list.filesequence ?? 'NULL'
            },'${list.thumbnailurl.replace(/'/g, "''")}',1,'${list.size.replace(
              /'/g,
              "''",
            )}','${list.assettype.replace(/'/g, "''")}','${(
              sanitizedImageNumber || ''
            ).replace(/'/g, "''")}','${(list.page_no || '').replace(
              /'/g,
              "''",
            )}')`,
          );
        });

        sql = `INSERT INTO public.wms_workorder_incomingfiledetails(
                  woincomingid,filetypeid,filepath,fileuuid,filename,filesequence,
                  thumbnailurl,complexityid,filesize,assettype,fignumber,pagenumber)
                VALUES ${val}`;

        let sql1 = `Update wms_workorder set totalchaptercount =${imagecount} where workorderid=${workorderId}`;
        await query(sql1);
      } else if (payload.type == 'update') {
        //update update query
        const filename = `${filesresponse[0].imagename.split('.')[0]}`;
        const sanitizedValue = filename.replaceAll(/[^a-zA-Z0-9.-]/g, '_');

        sql = `update public.wms_workorder_incomingfiledetails set filepath='${filesresponse[0].imageurl}',thumbnailurl='${filesresponse[0].thumbnailurl}',
        fileuuid='${filesresponse[0]._id}',filename ='${sanitizedValue}',filesize='${filesresponse[0].size}' where woincomingfileid=${woincomingfileid} `;
      } else {
        let getEventIdsSQL = `SELECT wfeventid FROM wms_workflow_eventlog WHERE woincomingfileid = ${woincomingfileid}`;
        if (getEventIdsSQL.length) {
          let eventIdsResult = await query(getEventIdsSQL);

          if (eventIdsResult.length > 0) {
            let wfeventIds = eventIdsResult.map(row => row.wfeventid);
            let deleteDetailsSQL = `DELETE FROM wms_workflow_eventlog_details WHERE wfeventid IN (${wfeventIds.join(
              ',',
            )})`;
            await query(deleteDetailsSQL);
            let deleteEventLogSQL = `DELETE FROM wms_workflow_eventlog WHERE woincomingfileid = ${woincomingfileid}`;
            await query(deleteEventLogSQL);
          }
        }
        sql = `delete from wms_workorder_incomingfiledetails where woincomingfileid=${woincomingfileid}`;
        let sql1 = `Update wms_workorder set totalchaptercount =${imagecount} where workorderid=${workorderId}`;
        await query(sql1);

        //delete delete query
      }
      await query(sql);

      let selectQuery = `select * from  public.wms_workorder_incomingfiledetails
      where woincomingid=${woincomingid}   order by 1 desc`;

      const incomingList = await query(selectQuery);

      // let getCountSql = `SELECT totalchaptercount FROM wms_workorder WHERE workorderid = ${workorderId}`;
      // let result = await query(getCountSql);

      // let currentCount = result.length > 0 ? result[0].totalchaptercount : 0;
      let updateSql = `UPDATE wms_workorder 
                 SET totalchaptercount = ${incomingList.length} 
                 WHERE workorderid = ${workorderId} RETURNING totalchaptercount`;

      let updatedResult = await query(updateSql);
      let updatedCount = updatedResult[0].totalchaptercount;

      if (payload.type != 'update') {
        let estimatePayload = {
          workorderId: workorderId,
          imageCount: updatedCount,
          bookId: bookid || payload?.item?.bookId,
        };
        let updateSql = `UPDATE wms_workorder 
                 SET completeddate =  current_timestamp
                 WHERE workorderid = ${workorderId} and isactive = true`;

        await query(updateSql);
        await getTimeEstimate(estimatePayload);
      }

      resolve(incomingList);
    } catch (error) {
      reject(error);
    }
  });
};

export const startProcessService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let payloadCollection = await getPayloadInfo(payload);
      payloadCollection.workOrderId = payloadCollection.workorderId;
      payloadCollection.dmsType = await getdmsType(
        payloadCollection.workorderId,
      );
      await transaction(async client => {
        payloadCollection.wfeventId = await createEventLog(
          payloadCollection,
          client,
        );
        // unassigned status
        let eventData = {
          actionType: 'Auto',
          wfeventId: payloadCollection.wfeventId,
          userId:
            payloadCollection.activity.activityalias == 'Proof Reader'
              ? payload.userId
              : 'System',
          status: 'Unassigned',
        };
        await updateEventLog(eventData, client);

        if (
          payloadCollection.assignedby &&
          payloadCollection.activity.activityalias != 'Final Verification' &&
          payloadCollection.activity.activityalias != 'Dispatch' &&
          payloadCollection.activity.activityalias != 'Proof Reader'
        ) {
          // assigned status in eventlog
          eventData.userId =
            payloadCollection.activity.activityalias == 'Proof Reader'
              ? payload.userId
              : payloadCollection.assignedby || eventData.userId;
          eventData.status = 'YTS';
          await updateEventLog(eventData, client);
        }

        // created status
        eventData.status = 'Created';
        await updateEventLogDetails(eventData, client);

        if (
          payloadCollection.assignedby &&
          payloadCollection.activity.activityalias != 'Final Verification' &&
          payloadCollection.activity.activityalias != 'Dispatch' &&
          payloadCollection.activity.activityalias != 'Proof Reader'
        ) {
          // assigned status in details
          eventData.userId =
            payloadCollection.activity.activityalias == 'Proof Reader'
              ? payload.userId
              : payloadCollection.assignedby || eventData.userId;
          eventData.status = 'YTS';
          await updateEventLogDetails(eventData, client);
        }
      });
      // checkEngineTask
      const result = await triggerEngineProcess(payloadCollection);

      resolve(result);
    } catch (e) {
      reject(e);
    }
  });
};
// check and trigger engine
export const triggerEngineProcess = payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      const { type, activity, workorderId } = payloadCollection;

      if (type === 'External Task') {
        // update task status to work in progres
        payloadCollection.status = 'Work in progress';
        payloadCollection.actionType = 'Auto';
        await updateActivityLog(payloadCollection);

        let result = '';
        if (activity.name === 'Image Classification') {
          payloadCollection.files = [{ id: payloadCollection.fileuuid }];
          result = await imageClassificationByIdService(payloadCollection);
        } else if (activity.name === 'Alt Text Generation') {
          payloadCollection.files = [{ id: payloadCollection.fileuuid }];
          result = await altTextGenerationService(payloadCollection);
        }
        resolve(result);
      } else {
        resolve(true);
      }
    } catch (e) {
      // update task status to Failed
      payloadCollection.status = 'Failed';
      payloadCollection.actionType = 'Auto';
      await updateActivityLog(payloadCollection);
      reject(e);
    }
  });
};
// classification module
export const imageClassificationByIdService = payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      const { files } = payloadCollection;
      const iAltPayload = files.map(item => {
        return {
          ...item,
          fileuuid: item.id,
          duId: payloadCollection.duId,
          customerId: payloadCollection.customerId,
          wfId: payloadCollection.wfId,
          userId: 'System',
          bookid: payloadCollection.bookid,
          workorderId: payloadCollection.workorderId,
          serviceId: payloadCollection.serviceId,
          stageId: payloadCollection.stageId,
          stageIteration: payloadCollection.stageIteration,
          stage: payloadCollection.stage,
          activity: payloadCollection.activity,
          actionType: payloadCollection.actionType,
          wfeventId: payloadCollection.wfeventId,
          nextActivityId: payloadCollection.nextActivityId,
          type: payloadCollection.type,
          wf: payloadCollection.wf,
          fileId: payloadCollection.fileId, // wo incoming file id
        };
      });
      payloadCollection.apiStatus = 'triggered';
      payloadCollection.apiMessage = {};
      payloadCollection.payloadArray = iAltPayload;
      await captureApiEventLog(payloadCollection);
      const url =
        config.iAlt.base_url + config.iAlt.uri.imageClassificationByIdQueue;
      const result = await service.post(url, iAltPayload);

      payloadCollection.apiStatus = 'acknowledged';
      payloadCollection.apiMessage = {};
      payloadCollection.payloadArray = iAltPayload;
      await captureApiEventLog(payloadCollection);
      resolve({ status: true, data: result.data });
    } catch (e) {
      reject(e);
    }
  });
};
export const getImageClassificationService = files => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iAlt.base_url + config.iAlt.uri.getImageClassification;
      const result = await service.post(url, files);

      resolve({ status: true, data: result.data });
    } catch (e) {
      reject(e);
    }
  });
};
export const getAllClassificationService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iAlt.base_url + config.iAlt.uri.getAllClassification;
      const result = await service.get(url);
      resolve({ status: true, data: result.data });
    } catch (e) {
      reject(e);
    }
  });
};
export const updateImageClassificationService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { payloadArray } = payload;
      payload.apiStatus = 'triggered';
      payload.apiMessage = {};
      await captureApiEventLog(payload);

      const url =
        config.iAlt.base_url + config.iAlt.uri.updateImageClassification;
      const result = await service.post(url, payloadArray);

      payload.apiStatus = 'completed';
      payload.apiMessage = {};
      await captureApiEventLog(payload);

      resolve({ status: true, data: result.data });
    } catch (e) {
      payload.apiStatus = 'failed';
      payload.apiMessage = e;
      await captureApiEventLog(payload);
      reject(e);
    }
  });
};

// alt text generation module
export const getAllPromptService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iAlt.base_url + config.iAlt.uri.getAllPrompt;
      const result = await service.get(url);
      resolve({ status: true, data: result.data });
    } catch (e) {
      reject(e);
    }
  });
};
export const getAltTextGenerationService = payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      const { files } = payloadCollection;
      const payload = files.map(item => {
        return {
          id: item._id || item.id,
        };
      });
      const url = config.iAlt.base_url + config.iAlt.uri.getAltTextGeneration;
      const result = await service.post(url, payload);

      resolve({ status: true, data: result.data });
    } catch (e) {
      reject(e);
    }
  });
};
export const getTaskComplexityService = async payload => {
  return new Promise(async (resolve, reject) => {
    const { files } = payload;
    const uuid = files.map(item => item.id);
    try {
      const sql = `select woincomingfileid, fileuuid from wms_workorder_incomingfiledetails where fileuuid =ANY ($1)`;
      const complexityRes = await query(sql, [uuid]);
      resolve(complexityRes);
    } catch (error) {
      reject(error);
    }
  });
};
export const altTextGenerationService = payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      const { files } = payloadCollection;
      const iAltPayload = files.map(item => {
        return {
          id: item._id || item.id,
          fileuuid: item._id || item.id,
          duId: payloadCollection.duId,
          customerId: payloadCollection.customerId,
          wfId: payloadCollection.wfId,
          userId: 'System',
          bookid: payloadCollection.bookid,
          workorderId: payloadCollection.workorderId,
          serviceId: payloadCollection.serviceId,
          stageId: payloadCollection.stageId,
          stageIteration: payloadCollection.stageIteration,
          stage: payloadCollection.stage,
          activity: payloadCollection.activity,
          actionType: payloadCollection.actionType,
          wfeventId: payloadCollection.wfeventId,
          nextActivityId: payloadCollection.nextActivityId,
          type: payloadCollection.type,
          wf: payloadCollection.wf,
          fileId: payloadCollection.fileId, // wo incoming file id
        };
      });
      payloadCollection.apiStatus = 'triggered';
      payloadCollection.apiMessage = {};
      // const payload = files.map(item => {
      //   return {
      //     id: item._id || item.id,
      //   };
      // });
      payloadCollection.payloadArray = iAltPayload;
      await captureApiEventLog(payloadCollection);
      const url = config.iAlt.base_url + config.iAlt.uri.altTextGenerationQueue;
      const result = await service.post(url, iAltPayload);

      payloadCollection.apiStatus = 'completed';
      payloadCollection.apiMessage = {};
      payloadCollection.payloadArray = iAltPayload;
      await captureApiEventLog(payloadCollection);
      resolve({ status: true, data: result.data });
    } catch (e) {
      payloadCollection.apiStatus = 'failed';
      payloadCollection.apiMessage = e;
      await captureApiEventLog(payloadCollection);

      reject(e);
    }
  });
};

export const reAltTextGenerationService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { payloadArray } = payload;
      payload.apiStatus = 'triggered';
      payload.apiMessage = {};
      await captureApiEventLog(payload);

      const url = config.iAlt.base_url + config.iAlt.uri.altTextGeneration;
      const result = await service.post(url, payloadArray);

      payload.apiStatus = 'completed';
      payload.apiMessage = {};
      await captureApiEventLog(payload);
      resolve({ status: true, data: result.data });
    } catch (e) {
      payload.apiStatus = 'failed';
      payload.apiMessage = e.message.data ? e.message.data : '';
      await captureApiEventLog(payload);
      reject(e);
    }
  });
};

export const updateAltTextGenerationService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { payloadArray } = payload;
      // this function will update the complexity
      payload.apiStatus = 'triggered';
      payload.apiMessage = {};
      await captureApiEventLog(payload);

      const url =
        config.iAlt.base_url + config.iAlt.uri.updateAltTextGeneration;
      const result = await service.post(url, payloadArray);
      if (result?.data && result?.data?.length > 0) {
        payload.complexityid = result?.data?.[0]?.complexityid;
        await updateComplexity(payload);
      }

      payload.apiStatus = 'completed';
      payload.apiMessage = {};
      await captureApiEventLog(payload);
      resolve(result.data);
    } catch (e) {
      payload.apiStatus = 'failed';
      payload.apiMessage = e.message.data ? e.message.data : '';
      await captureApiEventLog(payload);
      reject(e);
    }
  });
};
// update trigger status against the file
export const updateTriggerStatus = woIncomingFileIds => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await updateTriggerStatusScript();
      await query(script, [woIncomingFileIds]);
      resolve(
        `Trigger status updated successfully for ${woIncomingFileIds.toString()}`,
      );
    } catch (e) {
      reject(e);
    }
  });
};
// get the next activity info and trigger
export const checkNextActivityAndTrigger = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { nextActivityId, wf, stage } = payload;
      const script = await getNextActivityScript();

      const response = await query(script, [wf.wfId, stage.id, nextActivityId]);
      if (response.length) {
        if (response[0].activityid) {
          payload.activityId = response[0].activityid;
          payload.actionType = 'nextTrigger';
          startProcessService(payload);
          resolve();
        } else {
          reject(`Next activity id not mapped for the WF`);
        }
      } else {
        resolve();
      }
    } catch (e) {
      reject(e);
    }
  });
};
// start
// // check and trigger engine
// export const triggerEngineProcess = payloadCollection => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const { fileId } = payloadCollection;
//       if (payloadCollection.type === 'External Task') {
//
//         await imageClassification(fileId);
//
//         // update task status
//         await transaction(async client => {
//           let eventData = {
//             wfeventId: payloadCollection.wfeventId,
//             userId: 'System',
//             status: 'Completed',
//           };
//           await updateEventLog(eventData, client);
//           eventData.status = 'Completed';
//           eventData.actionType = 'Auto';
//           await updateEventLogDetails(eventData, client);
//         });
//         resolve(true);
//       } else {
//         resolve(true);
//       }
//     } catch (e) {
//       reject(e);
//     }
//   });
// };
// end
// This function will cal iALt Image classification API
// const imageClassification = fileId => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const files = await getSelectedFileInfoService(fileId);
//       if (files.length) {
//         const promises = [];
//         files.forEach(async item => {
//           const ialtPayload = {
//             id: item.uuid,
//           };
//           await ialtAuditEntry(item.woincomingfilemapid, 'started');
//           const url =
//             config.iAlt.base_url + config.iAlt.uri.getImageClassification;
//           const result = await service.post(url, ialtPayload);
//           await ialtAuditEntry(item.woincomingfilemapid, 'completed');
//           promises.push(result);
//         });
//         // Use Promise.all() to wait for all promises to resolve
//         Promise.all(promises)
//           .then(results => {
//
//             resolve(results);
//           })
//           .catch(error => {
//             reject(error);
//           });
//       } else {
//         resolve();
//       }
//     } catch (e) {
//       reject(e);
//     }
//   });
// };
// end
// this function will put file transaction entry
// const ialtAuditEntry = (id, status) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const script = await fileTransactionScript();
//       const response = await query(script, [id, status]);
//       resolve(response);
//     } catch (e) {
//       reject(e);
//     }
//   });
// };

// get task list client side
export const old_getiAltTaskListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, filterObj, searchText, roleId } = payload;
      let status = [];
      let condition = `isbookactive=true AND ischapteractive=true AND `;
      let activitystatus = '';
      let activityid = '';

      if (payload.type === 'My Task') {
        if (parseInt(roleId) == 1) {
          // status = ['Work in progress', 'Unassigned', 'YTS'];
          condition += `activitystatus in ('Work in progress', 'Unassigned', 'YTS') AND activityid=370`;
          activitystatus = `wms_workflow_eventlog.activitystatus in ('Work in progress', 'Unassigned', 'YTS')`;
          activityid = `wms_workflowdefinition.activityid = 370`;
        } else if (parseInt(roleId) == 2) {
          // status = ['Unassigned', 'YTS'];
          condition += `activitystatus in ('Unassigned', 'YTS', 'Work in progress') AND activityid = 369 AND bookassignedby='${userId}'`;
          activitystatus = `wms_workflow_eventlog.activitystatus in ('Work in progress', 'Unassigned', 'YTS')`;
          activityid = `wms_workflowdefinition.activityid = 369`;
        } else if (parseInt(roleId) == 55) {
          condition += `activitystatus in ('Unassigned', 'YTS', 'Work in progress') AND activityid = 560 AND userid='${userId}'`;
          activityid = `wms_workflowdefinition.activityid = 560`;
        } else {
          // status = ['YTS', 'Work in progress'];
          condition += `activitystatus in ('YTS', 'Work in progress', 'Unassigned') AND activityid != 560 AND userid='${userId}'`;
          activitystatus = `wms_workflow_eventlog.activitystatus in ('YTS', 'Work in progress', 'Unassigned')`;
          activityid = `wms_workflowdefinition.activityid != 560`;
          // userid = userId
          // activityid = ` != 560`;
          eventlogUserid = ` AND wms_workflow_eventlog.userid='${userId}'`;
        }
      } else if (payload.type === 'Assigned') {
        // status = ['YTS'];
        condition += `activitystatus in ('YTS')`;
        activitystatus = `wms_workflow_eventlog.activitystatus = 'YTS'`;
      } else {
        // status = [payload.type];
        condition += `activitystatus in ('${payload.type}')`;
        activitystatus = `wms_workflow_eventlog.activitystatus in ('${payload.type}')`;
      }
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);
      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }
      if (searchText) {
        if (roleId == 1) {
          condition += ` AND LOWER(itemcode) LIKE '%${searchText.toLowerCase()}%'`;
        } else {
          condition += ` AND LOWER(filename) LIKE '%${searchText.toLowerCase()}%'`;
        }
      }
      payload.status = status;
      payload.condition = condition;
      payload.filterObj = filterObj;

      const queryStart = performance.now();
      // const response = await old_getRecords(payload);
      const response = await getRecords(payload, activitystatus, activityid);
      const queryEnd = performance.now();
      const queryTime = (queryEnd - queryStart).toFixed(2);
      console.log('queryTime:', queryTime, 'ms');

      let finalResponse = [];
      let iAltAPITime = '0.00';

      if (roleId != 1) {
        if (response.data.length) {
          const files = response.data.map(item => {
            return {
              id: item.fileuuid,
            };
          });

          const iAltStart = performance.now();
          const getImgServices = await getImageClassificationService(files);
          const iAltEnd = performance.now();
          iAltAPITime = (iAltEnd - iAltStart).toFixed(2);
          console.log('iAltAPITime:', iAltAPITime, 'ms');

          if (getImgServices.data) {
            response.data.forEach((item, index) => {
              const sItem = getImgServices.data[index];
              if (item.fileuuid === sItem._id) {
                finalResponse.push({ ...item, ...sItem });
              }
            });
          }
        }
      } else {
        finalResponse = response.data;
      }
      resolve({
        ...response,
        data: finalResponse,
        responseTime: {
          query: `${queryTime} ms`,
          iAltAPI: `${iAltAPITime} ms`,
        },
      });
    } catch (error) {
      reject(error);
    }
  });
};
// get task list server side
export const old_getRecords = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        isServerSide,
        status,
        roleId,
        userId,
        pageNo,
        recordPerPage,
        duId,
        filterObj,
      } = payload;
      let { condition } = payload;
      const { bookid, workorderid } = filterObj;
      if (!isServerSide) {
        // const script = `SELECT * FROM ialt_tasklist WHERE ${condition} `;
        const script = `${ialt_tasklist} WHERE chapterstatus  <> 'Completed' AND ${condition} `;
        // const script = await getiAltTaskListScript(payload);
        const response = await query(script, [status]);
        resolve(response);
      } else {
        // let offset = (pageNo - 1) * recordPerPage;
        let sql = '';
        // if (roleId == 1) {
        // sql = `SELECT distinct on (workorderid) * FROM public.ialt_tasklist ${
        //   condition ? `WHERE ${condition}` : condition
        // }`;
        //   sql = `SELECT distinct on (workorderid) * FROM ( ${ialt_tasklist_query} )AS ialt_tasklist ${
        //     condition ? `WHERE ${condition}` : condition
        //   }`;
        // } else if (roleId == 2) {
        // sql = `SELECT * FROM public.ialt_tasklist ${
        //   condition ? `WHERE ${condition}` : condition
        // }`;
        // sql = `${ialt_tasklist} ${
        //   condition
        //     ? `WHERE chapterstatus  <> 'Completed' AND ${condition}`
        //     : condition
        // }`;
        // ${ (!bookid && !workorderid) ? `UNION
        //   SELECT * FROM public.ialt_tasklist
        //   WHERE duid = ${duId} AND userid='${userId}' AND activitystatus in ('Work in progress') AND activityid = 369`
        //   : ``
        // }`;
        // } else {
        // sql = `SELECT * FROM public.ialt_tasklist ${
        //   condition ? `WHERE ${condition}` : condition
        // }`;
        //   sql = `${ialt_tasklist} ${
        //     condition
        //       ? `WHERE chapterstatus  <> 'Completed' AND ${condition}`
        //       : condition
        //   }`;
        // }

        // const getResCount = await query(sql);
        // if (getResCount.length > 0) {
        //   const numOfPages = Math.ceil(getResCount.length / recordPerPage);
        if (roleId == 1) {
          // sql = `SELECT distinct on (workorderid) * FROM public.ialt_tasklist ${
          //   condition ? `WHERE ${condition}` : condition
          // } ORDER BY workorderid DESC`;
          sql = `SELECT distinct on (workorderid) * FROM ( ${ialt_tasklist_query} )AS ialt_tasklist ${
            condition
              ? ` Where chapterstatus  <> 'Completed' AND ${condition}`
              : condition
          } ORDER BY workorderid DESC`;
        } else if (roleId == 2) {
          // sql = `SELECT * FROM public.ialt_tasklist ${
          //   condition ? `WHERE ${condition}` : condition
          // } ORDER BY workorderid DESC`;
          sql = `${ialt_tasklist} ${
            condition
              ? `WHERE chapterstatus  <> 'Completed' AND ${condition}`
              : condition
          } ORDER BY workorderid DESC`;
        } else {
          // sql = `SELECT * FROM public.ialt_tasklist ${
          //   condition ? `WHERE ${condition}` : condition
          // } ORDER BY workorderid DESC`;
          sql = `${ialt_tasklist} ${
            condition
              ? `WHERE chapterstatus  <> 'Completed' AND ${condition}`
              : condition
          } ORDER BY workorderid DESC`;
        }
        const response = await query(sql);
        if (response && response.length > 0) {
          const sql2 = `select isother_user from wms_user where userid='${userId}'`;
          const res = await query(sql2);
          response.map(list => {
            list.isother_user = res[0]?.isother_user;
          });
        }
        // if (response && response.length > 0) {
        //   await Promise.all(
        //     response.map(async list => {
        //       const sql = `
        //                 SELECT wms_workflow_eventlog_details.usercomments AS reject_comment
        //                 FROM wms_workflow_eventlog_details
        //                 WHERE wfeventid = $1
        //                   AND wms_workflow_eventlog_details.usercomments IS NOT NULL
        //                   AND wms_workflow_eventlog_details.usercomments::text <> ''::text
        //                 ORDER BY wms_workflow_eventlog_details."timestamp" DESC
        //                 ;
        //             `;
        //       const data = await query(sql, [list.wfeventid]);
        //       list.reject_comment =
        //         data && data.length > 0 ? data[0].reject_comment : null;
        //     }),
        //   );
        // }

        resolve({
          status: true,
          data: response,
          total: response.length,
          // numOfPages,
        });
        // } else {
        //   resolve({
        //     status: true,
        //     data: [],
        //     total: 0,
        //     numOfPages: 0,
        //     message: 'No data found',
        //   });
        // }
      }
    } catch (e) {
      reject(e);
    }
  });
};

// get chapter list
export const getiAltChapterListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { filterObj, searchText, userId } = payload;
      let condition = `isbookactive=true AND ischapteractive=true AND  bookassignedby='${userId}' AND `;
      if (payload.type === 'Unassigned') {
        condition += `bookstatus !='Completed' AND assignedby is null and chapterstatus !='Completed'`;
      } else if (payload.type === 'Assigned') {
        condition += `bookstatus !='Completed' AND assignedby is not null and chapterstatus !='Completed'`;
      }
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);
      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }

      if (searchText) {
        condition += ` AND LOWER(itemcode) LIKE '%${searchText.toLowerCase()}%'`;
      }
      payload.condition = condition;
      const response = await getChapterRecords(payload);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

// get task list server side
export const getChapterRecords = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
        const script = `select * from ialt_chapterlist WHERE ${condition} `;
        const response = await query(script);
        resolve(response);
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        let sql = '';
        if (type === 'filter') {
        } else {
          sql = `SELECT COUNT(*) FROM public.ialt_chapterlist ${
            condition ? `WHERE ${condition}` : condition
          }`;
        }

        const getResCount = await query(sql);
        if (getResCount[0].count > 0) {
          const numOfPages = Math.ceil(getResCount[0].count / recordPerPage);
          const sqlQuery = `SELECT DISTINCT * FROM public.ialt_chapterlist ${
            condition ? `WHERE ${condition}` : condition
          } ORDER BY workorderid DESC`;
          const response = await query(sqlQuery);
          resolve({
            status: true,
            data: response,
            total: getResCount[0].count,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};

// get book master array input fields

export const getBookMasterFieldsList = async payload => {
  return new Promise(async (resolve, reject) => {
    const { duId, customerid } = payload;
    try {
      const sql = ` select * from ialt_mst_book_fields as bookfields 
      join ialt_mst_book_fields_map as fieldsmap on bookfields.fieldid = fieldsmap.fieldid
      where fieldsmap.duid = ${duId} and  bookfields.isactive = true and fieldsmap.isactive = true
    order by fieldsmap.fieldsequence`;
      const fieldsArray = await query(sql);
      resolve(fieldsArray);
    } catch (error) {
      reject(error);
    }
  });
};

//ialt wip report start

export const getiAltWIPReportTwoService = async payload => {
  return new Promise((resolve, reject) => {
    try {
      // const jdata = JSON.stringify(payload);
      const sql = `select workorderid , bookname as "Book Name" , itemcode,filename, stagename , stagestatus , 
      activityname as "Activity Name", activitystatus as "Activity Status", assigned , 
      jobcreatedon ,
      to_char(receiveddate::timestamp(0), 'yyyy-mm-dd') as receiveddate,
      to_char(plannedstartdate::timestamp(0), 'yyyy-mm-dd') as plannedstartdate,
      to_char(plannedenddate::timestamp(0), 'yyyy-mm-dd') as plannedenddate,
      to_char(startdatetime::timestamp(0), 'yyyy-mm-dd') as startdatetime,
      to_char(enddatetime::timestamp(0), 'yyyy-mm-dd') as enddatetime,
      to_char(revisedduedate::timestamp(0), 'yyyy-mm-dd') as revisedduedate,
      to_char(receiveddate::timestamp(0), 'dd-mm-yyyy') as startdate,
      to_char(receiveddate::timestamp(0), 'dd-mm-yyyy') as enddate,
      customername as "Customer",
      dates as "Date", months , daysleft from getwip_ialt('{"duID":${payload.duID}}')`;

      console.log(sql, 'wiproportqry');

      query(sql)
        .then(data => {
          resolve(data);
        })
        .catch(error => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

export const getiAltWIPChapterReportService = async payload => {
  return new Promise((resolve, reject) => {
    try {
      const jdata = JSON.stringify(payload);
      const sql = `select row_number()over(order by chapter) as "S.No", 
      chapter as "Chapter", service as "Service", stage as "Stage",mspages as "MS_Page", actstatus as "Status", 
      currentactivity as "Current_Activity", assignedto as "Assigned_To", 
      priority as "Priority"
    from public.getwip_workorderchapterdata('${jdata}')`;
      console.log(sql, 'wiproportqry');

      query(sql)
        .then(data => {
          resolve(data);
        })
        .catch(error => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

//ialt wip report end

//get chapter master datas list
export const getChapterMasterList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, filterObj, duId } = payload;
      let condition = ``;
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);

      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }
      if (searchText) {
        condition += ` AND LOWER(itemcode) LIKE '%${searchText.toLowerCase()}%'`;
      }
      // payload.status = status;
      payload.condition = condition;
      const response = await getIAltChapterReportService(payload);
      let finalResponse = [];
      resolve({ data: response });
    } catch (error) {
      reject(error);
    }
  });
};

export const getIAltChapterReportService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        let completedStatus = '';
        if (payload?.isCompleted) {
          completedStatus = ` `;
        } else {
          completedStatus = ` and chapterstatus !='Completed' `;
        }
        let sql = '';
        //         let sql = `with cte as ( select ialt_books.bookid, ialt_books.bookname,ialt_books.duid, wms_workorder.workorderid, wms_workorder.itemcode, wms_workorder.totalchaptercount, wms_workorder.status, woservice.isbookcompleted,
        // to_char(ialt_books.startdate, 'DD-MM-YYYY') as plannedstartdate,to_char(ialt_books.enddate, 'DD-MM-YYYY') as plannedenddate,to_char(wostage.ordermaildatetime, 'DD-MM-YYYY') as receiveddate,plannedstartdate as startdatetime,plannedenddate as enddatetime ,wostage.wfstageid, customer.customerid, customer.customername,
        //              ialt_books.isactive as bookisactive , wms_workorder.isactive as chapterisactive,wms_workorder.status as chapterstatus,wms_workorder.wfid from wms_workorder
        // join ialt_books on ialt_books.bookid = wms_workorder.bookid
        // left join wms_workorder_service as woservice on woservice.workorderid = wms_workorder.workorderid
        // left join wms_workorder_stage as wostage on wostage.workorderid = wms_workorder.workorderid
        // left join org_mst_customer as customer on wms_workorder.customerid = customer.customerid )
        // select * from cte
        // where bookisactive = true and chapterisactive = true and chapterstatus !='Completed'  ${condition}`;

        //         const getResCount = await query(sql);
        //         if (getResCount.length > 0) {
        //           const numOfPages = Math.ceil(getResCount.length / recordPerPage);
        sql = `with cte as ( select ialt_books.bookid, ialt_books.bookname,ialt_books.duid,ialt_books.isbn,ialt_books.category, wms_workorder.workorderid, wms_workorder.itemcode, wms_workorder.totalchaptercount,wms_workorder.otherfield->>'pii' as piinumber,wms_workorder.otherfield->>'egiCount' as egicount,wms_workorder.otherfield->>'needExtraction' as needExtraction, wms_workorder.status, woservice.isbookcompleted, 
to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as plannedstartdate,to_char(wostage.plannedenddate, 'DD-MM-YYYY') as plannedenddate,to_char(wostage.ordermaildatetime, 'DD-MM-YYYY') as receiveddate,plannedstartdate as startdatetime,plannedenddate as enddatetime, wostage.wfstageid, customer.customerid, customer.customername,
             ialt_books.isactive as bookisactive , wms_workorder.isactive as chapterisactive,wms_workorder.status as chapterstatus,wms_workorder.wfid,
       CASE 
       WHEN ialt_books.piinumber IS NOT NULL THEN false 
       ELSE true 
     END AS ismanual,
     wms_workorder.ceddetails as query
       from wms_workorder
join ialt_books on ialt_books.bookid = wms_workorder.bookid
left join wms_workorder_service as woservice on woservice.workorderid = wms_workorder.workorderid
left join wms_workorder_stage as wostage on wostage.workorderid = wms_workorder.workorderid
left join org_mst_customer as customer on wms_workorder.customerid = customer.customerid )
select * from cte
where bookisactive = true and chapterisactive = true ${completedStatus}  ${condition} order by workorderid desc`;
        const response = await query(sql);
        resolve({
          status: true,
          data: response,
          total: response.length,
          // numOfPages,
        });
        // } else {
        //   resolve({
        //     status: true,
        //     data: [],
        //     total: 0,
        //     numOfPages: 0,
        //     message: 'No data found',
        //   });
        // }
      }
    } catch (e) {
      reject(e);
    }
  });
};

//get ialt report list

export const getiAltReportDataList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, filterObj } = payload;
      let condition = `isbookactive =true  AND activityid = 370 AND chapterstatus = 'Completed'`;
      //  let condition=`bookstatus='In Process'` -- this part for testing
      let chapterstatus = 'Completed';
      let activityid = 370;

      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);

      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }
      if (searchText) {
        condition += ` AND LOWER(filename) LIKE '%${searchText.toLowerCase()}%'`;
      }
      // payload.status = status;
      payload.condition = condition;
      const response = await getIAltReportService(
        payload,
        chapterstatus,
        activityid,
      );
      let finalResponse = [];

      if (response.data.length) {
        const files = response.data.map(item => {
          return {
            id: item.fileuuid,
          };
        });
        const getImgServices = await getImageClassificationService(files);
        if (getImgServices.data) {
          response.data.forEach((item, index) => {
            const sItem = getImgServices.data[index];
            if (item.fileuuid === sItem._id) {
              finalResponse.push({ ...item, ...sItem });
            }
          });
        }
      }

      resolve({ ...response, data: finalResponse });
    } catch (error) {
      reject(error);
    }
  });
};

export const getiAltJobsOverallInflowReport = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `workorder.bookid IS NOT NULL`,
        `workorder.status = 'In Process'`,
      ];

      const chapterDetailsQuery = `
        SELECT 
          customer.customername as customer_name,
          ialt_books.bookname as book_name,
          ialt_books.isbn,
          workorder.otherfield->>'pii' as pii_number,
          ialt_books.remarks as remarks,
          workorder.itemcode as chapter_name,
          workorder.totalchaptercount as image_count,
          workorder.otherfield->>'egiCount' as received_image_count,
          workorder.status as chapter_status,
          to_char(wostage.updatedon, 'DD-MM-YYYY HH:MI AM') as received_date,
          to_char(wostage.plannedstartdate, 'DD-MM-YYYY HH:MI AM') as start_date,
          to_char(wostage.plannedenddate, 'DD-MM-YYYY HH:MI AM') as end_date,
          to_char(ialt_books.enddate, 'DD-MM-YYYY HH:MI AM') as book_end_date,
          to_char(ialt_books.plannedcompleteddate, 'DD-MM-YYYY HH:MI AM') as planned_end_date,
          workorder.workorderid,
          workorder.bookid,
          customer.customerid
        FROM wms_workorder workorder
        INNER JOIN wms_workorder_stage wostage 
          ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer 
          ON customer.customerid = workorder.customerid
        LEFT JOIN ialt_books 
          ON ialt_books.bookid = workorder.bookid
        WHERE ${baseConditions.join(' AND ')}
        ORDER BY 
          customer.customername,
          ialt_books.bookname,
          wostage.updatedon DESC
        LIMIT ${recordPerPage} OFFSET ${(pageNo - 1) * recordPerPage}
      `;

      const statusCountQuery = `
        SELECT 
          customer.customerid,
          customer.customername,
          COUNT(*) as in_progress,
          0 as completed,
          COUNT(*) as total
        FROM wms_workorder workorder
        INNER JOIN wms_workorder_stage wostage 
          ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer 
          ON customer.customerid = workorder.customerid
        LEFT JOIN ialt_books 
          ON ialt_books.bookid = workorder.bookid
        WHERE ${baseConditions.join(' AND ')}
        GROUP BY customer.customerid, customer.customername
      `;

      const totalCountQuery = `
        SELECT COUNT(*) as count 
        FROM wms_workorder workorder 
        INNER JOIN wms_workorder_stage wostage 
          ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer 
          ON customer.customerid = workorder.customerid
        LEFT JOIN ialt_books 
          ON ialt_books.bookid = workorder.bookid
        WHERE ${baseConditions.join(' AND ')}
      `;

      let statusCounts, dailySummary, chapterDetails, totalCount;

      try {
        statusCounts = await query(statusCountQuery);
      } catch (error) {
        console.error('Status count query failed:', error);
        throw new Error('Status count query failed');
      }

      try {
        chapterDetails = await query(chapterDetailsQuery);
      } catch (error) {
        console.error('Chapter details query failed:', error);
        throw new Error('Chapter details query failed');
      }

      try {
        totalCount = await query(totalCountQuery);
      } catch (error) {
        console.error('Total count query failed:', error);
        throw new Error('Total count query failed');
      }

      const count = parseInt(totalCount[0]?.count || 0);

      resolve({
        status: true,
        data: {
          status_counts: statusCounts,
          // summary: dailySummary,
          chapter_details: chapterDetails,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltJobsOverallReport:', error);
      reject({
        status: false,
        message:
          error.message || 'An error occurred while generating the report',
        error: error,
      });
    }
  });
};

export const getiAltJobsOverallDispatchReport = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `workorder.status = 'Completed'`,
      ];

      // Overall Summary Query
      const overallSummaryQuery = `
        SELECT 
          COUNT(DISTINCT workorder.workorderid) as total_chapters,
          COUNT(DISTINCT workorder.bookid) as total_books,
          SUM(workorder.totalchaptercount) as total_images,
          COUNT(DISTINCT customer.customerid) as total_customers
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE ${baseConditions.join(' AND ')}`;

      const customerSummaryQuery = `
        SELECT 
          customer.customerid,
          customer.customername,
          COUNT(DISTINCT workorder.workorderid) as total_chapters,
          COUNT(DISTINCT workorder.bookid) as total_books,
          SUM(workorder.totalchaptercount) as total_images
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE ${baseConditions.join(' AND ')} AND book.isactive = true
        GROUP BY 
          customer.customerid, 
          customer.customername
        ORDER BY customer.customername`;

      // Detailed Records Query
      const detailQuery = `
        SELECT 
          customer.customerid,
          customer.customername,
          book.bookname,
          book.isbn,
          book.chaptercount as book_total_chapters,
          workorder.otherfield->>'pii' as pii_number,
          workorder.totalchaptercount as total_images,
          workorder.otherfield->>'egiCount' as received_image_count,
          workorder.itemcode as chapter_name,
          book.enddate as end_date,
          workorder.ceddetails as remarks,
          to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as received_date,
          to_char(workorder.updated_date, 'DD-MM-YYYY HH12:MI AM') as dispatch_date,
          to_char(wostage.plannedenddate, 'DD-MM-YYYY HH12:MI AM') as plannedcompleteddate,
          to_char(book.plannedcompleteddate, 'DD-MM-YYYY HH12:MI AM') AS bookplannedcompleteddate,
          workorder.workorderid,
          workorder.status
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE ${baseConditions.join(' AND ')}
        ORDER BY workorder.updated_date DESC NULLS LAST, 
          customer.customername
        LIMIT ${recordPerPage} 
        OFFSET ${(pageNo - 1) * recordPerPage}`;

      const totalCountQuery = `
        SELECT COUNT(*) as total 
        FROM wms_workorder workorder 
        WHERE ${baseConditions.join(' AND ')}`;

      const [overallSummary, customerSummary, details, totalCount] =
        await Promise.all([
          query(overallSummaryQuery),
          query(customerSummaryQuery),
          query(detailQuery),
          query(totalCountQuery),
        ]);

      const count = parseInt(totalCount[0]?.total || 0);

      resolve({
        status: true,
        data: {
          overall_summary: overallSummary[0],
          customer_summary: customerSummary,
          details: details,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltJobsOverallDispatchReport:', error);
      reject(error);
    }
  });
};

export const getiAltJobsOverallWIPReport = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `ialt_books.isactive = true`,
        `workorder.bookid IS NOT NULL`,
        `workorder.status != 'Completed'`,
        `wostage.status != 'Completed'`,
        `wostage.plannedenddate IS NOT NULL`,
        `woservice.isbookcompleted IS NOT NULL`, //- remove yts list
      ];

      const chapterDetailsQuery = `
    SELECT 
    customer.customername AS customer_name,
    ialt_books.bookname AS book_name,
    ialt_books.isbn,
    workorder.otherfield->>'pii' AS pii_number,
    workorder.ceddetails AS remarks,
    workorder.itemcode AS chapter_name,
    workorder.totalchaptercount AS image_count,
    workorder.otherfield->>'egiCount' AS received_image_count,
    workorder.status AS chapter_status,
    to_char(wostage.updatedon, 'DD-MM-YYYY HH:MI AM') AS received_date,
    to_char(wostage.plannedstartdate, 'DD-MM-YYYY HH:MI AM') AS start_date,
    to_char(wostage.plannedenddate, 'DD-MM-YYYY HH:MI AM') AS end_date,
    to_char(ialt_books.enddate, 'DD-MM-YYYY HH:MI AM') AS book_end_date,
    to_char(ialt_books.plannedcompleteddate, 'DD-MM-YYYY HH:MI AM') AS planned_end_date,
    workorder.workorderid,
    workorder.bookid,
    customer.customerid,
    CASE 
    WHEN workorder.ceddetails != '' AND workorder.isadvertavailable = true THEN 'Queries'
    WHEN ialt_books.plannedcompleteddate < CURRENT_DATE OR ialt_books.enddate < CURRENT_DATE THEN 'Overdue'
    ELSE '' 
END AS status

FROM wms_workorder workorder
INNER JOIN wms_workorder_stage wostage 
    ON wostage.workorderid = workorder.workorderid
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
LEFT JOIN org_mst_customer customer 
    ON customer.customerid = workorder.customerid
LEFT JOIN ialt_books 
    ON ialt_books.bookid = workorder.bookid
WHERE ${baseConditions.join(' AND ')}
ORDER BY 
    customer.customername, 
    ialt_books.bookname, 
    wostage.updatedon DESC
LIMIT ${recordPerPage} OFFSET ${(pageNo - 1) * recordPerPage};

    `;

      const statusCountQuery = `
     SELECT 
    customer.customerid,
    customer.customername,
    COUNT(*) AS in_progress,
    0 AS completed,
    COUNT(*) AS total
FROM wms_workorder workorder
INNER JOIN wms_workorder_stage wostage 
    ON wostage.workorderid = workorder.workorderid
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
LEFT JOIN org_mst_customer customer 
    ON customer.customerid = workorder.customerid
LEFT JOIN ialt_books 
    ON ialt_books.bookid = workorder.bookid
WHERE ${baseConditions.join(' AND ')}
GROUP BY 
    customer.customerid, 
    customer.customername
ORDER BY customer.customername;

    `;

      const totalCountQuery = `
     SELECT 
    COUNT(*) AS count
FROM wms_workorder workorder 
INNER JOIN wms_workorder_stage wostage 
    ON wostage.workorderid = workorder.workorderid
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
LEFT JOIN org_mst_customer customer 
    ON customer.customerid = workorder.customerid
INNER JOIN ialt_books 
    ON ialt_books.bookid = workorder.bookid
WHERE ${baseConditions.join(' AND ')}

`;
      // -- AND (
      // --    CAST(wostage.plannedenddate AS DATE) <= CURRENT_DATE
      // --    OR wostage.plannedenddate IS NOT NULL
      // -- );

      let statusCounts, dailySummary, chapterDetails, totalCount;

      try {
        statusCounts = await query(statusCountQuery);
      } catch (error) {
        console.error('Status count query failed:', error);
        throw new Error('Status count query failed');
      }

      try {
        chapterDetails = await query(chapterDetailsQuery);
      } catch (error) {
        console.error('Chapter details query failed:', error);
        throw new Error('Chapter details query failed');
      }

      try {
        totalCount = await query(totalCountQuery);
      } catch (error) {
        console.error('Total count query failed:', error);
        throw new Error('Total count query failed');
      }

      const count = parseInt(totalCount[0]?.count || 0);

      resolve({
        status: true,
        data: {
          status_counts: statusCounts,
          // summary: dailySummary,
          chapter_details: chapterDetails,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltJobsOverallReport:', error);
      reject({
        status: false,
        message:
          error.message || 'An error occurred while generating the report',
        error: error,
      });
    }
  });
};

export const getiAltJobsOverallYTSReport = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `workorder.bookid IS NOT NULL`,
        `workorder.status != 'Completed'`,
        `wostage.status != 'Completed'`,
        `woservice.isbookcompleted IS NULL`,
      ];

      // Overall Summary Query
      const overallSummaryQuery = `
   SELECT 
     COUNT(DISTINCT workorder.workorderid) as total_chapters,
     COUNT(DISTINCT workorder.bookid) as total_books,
     SUM(workorder.totalchaptercount) as total_images,
     COUNT(DISTINCT customer.customerid) as total_customers
   FROM wms_workorder workorder 
   INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
   WHERE ${baseConditions.join(' AND ')} AND book.isactive = true`;

      const customerSummaryQuery = `
   SELECT 
     customer.customerid,
     customer.customername,
     COUNT(DISTINCT workorder.workorderid) as total_chapters,
     COUNT(DISTINCT workorder.bookid) as total_books,
     SUM(workorder.totalchaptercount) as total_images
   FROM wms_workorder workorder 
   INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
   WHERE ${baseConditions.join(' AND ')} AND book.isactive = true
   GROUP BY 
     customer.customerid, 
     customer.customername
   ORDER BY customer.customername`;

      // Detailed Records Query
      const detailQuery = `
   SELECT 
     customer.customerid,
     customer.customername,
     book.bookname,
     book.isbn,
     book.chaptercount as book_total_chapters,
     workorder.otherfield->>'pii' as pii_number,
     workorder.totalchaptercount as total_images,
     workorder.otherfield->>'egiCount' as received_image_count,
     workorder.itemcode as chapter_name,
     book.enddate as end_date,
     to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as received_date,
     to_char(workorder.updated_date, 'DD-MM-YYYY HH12:MI AM') as dispatch_date,
     to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as plannedstartdate,
     to_char(book.plannedcompleteddate, 'DD-MM-YYYY HH12:MI AM') as bookplannedcompleteddate,
      to_char(wostage.plannedenddate, 'DD-MM-YYYY HH12:MI AM') as plannedcompleteddate,
     workorder.workorderid,
     workorder.ceddetails AS remarks,
     workorder.status
   FROM wms_workorder workorder 
   INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
   INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
   LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
   WHERE ${baseConditions.join(' AND ')} AND book.isactive = true
   ORDER BY workorder.updated_date DESC NULLS LAST, 
     customer.customername
   LIMIT ${recordPerPage} 
   OFFSET ${(pageNo - 1) * recordPerPage}`;

      const totalCountQuery = `
   SELECT COUNT(*) as total 
   FROM wms_workorder workorder 
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   WHERE ${baseConditions.join(' AND ')}`;

      const [overallSummary, customerSummary, details, totalCount] =
        await Promise.all([
          query(overallSummaryQuery),
          query(customerSummaryQuery),
          query(detailQuery),
          query(totalCountQuery),
        ]);

      const count = parseInt(totalCount[0]?.total || 0);

      resolve({
        status: true,
        data: {
          overall_summary: overallSummary[0],
          customer_summary: customerSummary,
          details: details,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltJobsOverallYTSReport:', error);
      reject({
        status: false,
        message:
          error.message || 'An error occurred while generating the report',
        error: error,
      });
    }
  });
};

export const getiAltJobsDataList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
      ];

      if (filterObj.fromDate && filterObj.toDate) {
        baseConditions.push(
          `workorder.createdon::timestamp BETWEEN '${filterObj.fromDate} 00:00:00'::timestamp AND '${filterObj.toDate} 23:59:59'::timestamp`,
        );
      }

      const statusCountQuery = `
        SELECT 
          customer.customerid,
          customer.customername,
          COUNT(CASE WHEN status = 'In Process' THEN 1 END) as in_progress_count,
          COUNT(CASE WHEN status = 'Completed' THEN 1 END) as completed_count,
          COUNT(*) as total_count
        FROM wms_workorder workorder
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE ${baseConditions.join(' AND ')}
        GROUP BY 
          customer.customerid,
          customer.customername
        ORDER BY customer.customername
      `;

      const dailySummaryQuery = `
        SELECT 
          DATE(wostage.updatedon) as date,
          customer.customerid,
          customer.customername,
          COUNT(DISTINCT workorder.workorderid) as chapters_received,
          SUM(workorder.totalchaptercount) as total_images,
          COUNT(DISTINCT workorder.bookid) as total_books
        FROM wms_workorder workorder
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE workorder.bookid IS NOT NULL
        AND workorder.status = 'In Process'
        AND ${baseConditions.join(' AND ')}
        GROUP BY 
          DATE(wostage.updatedon),
          customer.customerid,
          customer.customername
        ORDER BY DATE(wostage.updatedon) DESC, customer.customername
      `;

      const chapterDetailsQuery = `
        SELECT 
          customer.customername as customer_name,
          ialt_books.bookname as book_name,
          ialt_books.isbn,
          workorder.otherfield->>'pii' as pii_number,
          ialt_books.remarks as remarks,
          workorder.itemcode as chapter_name,
          workorder.totalchaptercount as image_count,
          workorder.otherfield->>'egiCount' as received_image_count,
          workorder.status as chapter_status,
          to_char(wostage.updatedon, 'DD-MM-YYYY HH:MI AM') as received_date,
          to_char(wostage.plannedstartdate, 'DD-MM-YYYY HH:MI AM') as start_date,
          to_char(wostage.plannedenddate, 'DD-MM-YYYY HH:MI AM') as end_date,
          to_char(ialt_books.enddate, 'DD-MM-YYYY HH:MI AM') as book_end_date,
          to_char(ialt_books.plannedcompleteddate, 'DD-MM-YYYY HH12:MI AM') as planned_end_date,
          workorder.workorderid,
          workorder.bookid,
          customer.customerid
        FROM wms_workorder workorder
        INNER JOIN wms_workorder_stage wostage 
          ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer 
          ON customer.customerid = workorder.customerid
        LEFT JOIN ialt_books 
          ON ialt_books.bookid = workorder.bookid
        WHERE workorder.bookid IS NOT NULL
        AND workorder.status = 'In Process'
        AND ${baseConditions.join(' AND ')}
        ORDER BY 
          customer.customername,
          ialt_books.bookname,
          wostage.updatedon DESC
      `;

      const totalCountQuery = `
        SELECT COUNT(*) as total 
        FROM wms_workorder workorder 
        WHERE status = 'In Process'
        AND ${baseConditions.join(' AND ')}
      `;

      const [statusCounts, dailySummary, chapterDetails, totalCount] =
        await Promise.all([
          query(statusCountQuery),
          query(dailySummaryQuery),
          query(chapterDetailsQuery),
          query(totalCountQuery),
        ]);

      // Transform status counts to grouped format
      const customerStatusCounts = statusCounts.reduce((acc, customer) => {
        acc[customer.customername] = {
          customerid: customer.customerid,
          in_progress: parseInt(customer.in_progress_count) || 0,
          completed: parseInt(customer.completed_count) || 0,
          total: parseInt(customer.total_count) || 0,
        };
        return acc;
      }, {});

      // Calculate overall totals
      const overallTotals = statusCounts.reduce(
        (acc, customer) => {
          acc.in_progress += parseInt(customer.in_progress_count) || 0;
          acc.completed += parseInt(customer.completed_count) || 0;
          acc.total += parseInt(customer.total_count) || 0;
          return acc;
        },
        { in_progress: 0, completed: 0, total: 0 },
      );

      const count = parseInt(totalCount[0].total);
      const startIndex = (pageNo - 1) * recordPerPage;
      const endIndex = startIndex + recordPerPage;
      const paginatedDetails = chapterDetails.slice(startIndex, endIndex);

      resolve({
        status: true,
        data: {
          status_counts: {
            overall: overallTotals,
            by_customer: customerStatusCounts,
          },
          summary: dailySummary,
          details: paginatedDetails,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltJobsDataList:', error);
      reject(error);
    }
  });
};

export const getiAltDispatchDataList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `workorder.status = 'Completed'`,
        `workorder.updated_date IS NOT NULL`,
      ];

      if (filterObj.fromDate && filterObj.toDate) {
        baseConditions.push(
          `workorder.updated_date BETWEEN '${filterObj.fromDate} 00:00:00'::timestamp AND '${filterObj.toDate} 23:59:59'::timestamp`,
        );
      }

      const customerCountQuery = `
        SELECT 
          to_char(workorder.updated_date, 'DD-MM-YYYY') as date, -- Date without time
          customer.customerid,
          customer.customername,
          COUNT(DISTINCT workorder.workorderid) as total_books,
          COUNT(DISTINCT workorder.workorderid) as total_chapters,
          SUM(workorder.totalchaptercount) as total_images
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE workorder.bookid IS NOT NULL
        AND ${baseConditions.join(' AND ')}
        GROUP BY 
          to_char(workorder.updated_date, 'DD-MM-YYYY'), -- Match SELECT expression
          customer.customerid, 
          customer.customername
        ORDER BY 
          to_char(workorder.updated_date, 'DD-MM-YYYY') DESC, -- Align with GROUP BY
          customer.customername;`;

      const detailQuery = `
        SELECT 
          to_char(workorder.updated_date, 'DD-MM-YYYY HH12:MI AM') as date,
          customer.customerid,
          customer.customername,
          book.bookname,
          book.isbn,
          workorder.ceddetails as remarks,
          book.chaptercount as book_total_chapters,
          workorder.otherfield->>'pii' as pii_number,
          workorder.totalchaptercount as total_images,
          workorder.otherfield->>'egiCount' as received_image_count,
          workorder.itemcode as chapter_name,
          book.enddate as end_date,
          to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as received_date,
          to_char(workorder.updated_date, 'DD-MM-YYYY HH12:MI AM') as dispatch_date,
          to_char(wostage.plannedenddate, 'DD-MM-YYYY HH12:MI AM') as plannedcompleteddate,
          workorder.workorderid,
          workorder.status
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE workorder.bookid IS NOT NULL
        AND ${baseConditions.join(' AND ')}
        ORDER BY workorder.updated_date DESC NULLS LAST, 
          customer.customername`;

      const totalCountQuery = `
        SELECT COUNT(*) as total 
        FROM wms_workorder workorder 
        WHERE ${baseConditions.join(' AND ')}`;

      const [customerCounts, details, totalCount] = await Promise.all([
        query(customerCountQuery, []),
        query(detailQuery, []),
        query(totalCountQuery, []),
      ]);

      const count = parseInt(totalCount[0]?.total || 0);

      resolve({
        status: true,
        data: {
          summary: customerCounts,
          details: details,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltDispatchDataList:', error);
      reject(error);
    }
  });
};

export const getiAltWIPDataList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `ialt_books.isactive = true`,
        `workorder.status != 'Completed'`,
        `wostage.status != 'Completed'`,
        `wostage.plannedenddate IS NOT NULL`,
        `woservice.isbookcompleted IS NOT NULL`, //- remove yts list
      ];
      // `wostage.plannedenddate > CURRENT_DATE`,
      const dailySummaryConditions = [...baseConditions];

      if (filterObj.fromDate && filterObj.toDate) {
        if (filterObj.isCurrentDate == true) {
          baseConditions.push(
            `DATE(wostage.plannedenddate) <= CURRENT_DATE - INTERVAL '1 day'`,
          );
          dailySummaryConditions.push(
            `DATE(wostage.plannedenddate) <= CURRENT_DATE - INTERVAL '1 day'`,
          );
        } else {
          if (filterObj.type === 'FTDW_Records') {
            baseConditions.push(
              `wostage.plannedenddate::timestamp <= '${filterObj.toDate} 23:59:59'::timestamp`,
            );
          } else {
            baseConditions.push(
              `wostage.plannedenddate::timestamp BETWEEN '${filterObj.fromDate} 00:00:00'::timestamp AND '${filterObj.toDate} 23:59:59'::timestamp`,
            );
          }
        }
      }

      const statusCountQuery = `
  SELECT 
    customer.customerid, 
    customer.customername,
    COUNT(CASE WHEN wostage.plannedenddate::date <= CURRENT_DATE AND wostage.status != 'Completed' THEN 1 END) as current_count,
    COUNT(CASE WHEN wostage.plannedenddate::date > CURRENT_DATE THEN 1 END) as future_count,
    COUNT(*) as total_count
  FROM wms_workorder workorder
  INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
     left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
  LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
  INNER JOIN ialt_books ON ialt_books.bookid = workorder.bookid
  WHERE ${baseConditions.join(' AND ')}
  GROUP BY customer.customerid, customer.customername
  ORDER BY customer.customername`;

      const dailySummaryQuery = `
SELECT 
    CASE 
        WHEN CAST(wostage.plannedenddate AS DATE) <= CURRENT_DATE - INTERVAL '1 day' 
        THEN TO_CHAR(CURRENT_DATE - INTERVAL '1 day', 'YYYY-MM-DD') -- Show actual current date instead of "current"
        ELSE TO_CHAR(wostage.plannedenddate, 'YYYY-MM-DD') 
    END AS date,
    customer.customerid,
    customer.customername,
    COUNT(DISTINCT workorder.workorderid) AS chapters_received,
    SUM(workorder.totalchaptercount) AS total_images,
    COUNT(DISTINCT workorder.bookid) AS total_books
FROM wms_workorder workorder
INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
     left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
INNER JOIN ialt_books ON ialt_books.bookid = workorder.bookid
WHERE 
    workorder.bookid IS NOT NULL   
    AND ${dailySummaryConditions.join(' AND ')}
GROUP BY 
    CASE 
        WHEN CAST(wostage.plannedenddate AS DATE) <= CURRENT_DATE - INTERVAL '1 day' 
        THEN TO_CHAR(CURRENT_DATE - INTERVAL '1 day', 'YYYY-MM-DD') 
        ELSE TO_CHAR(wostage.plannedenddate, 'YYYY-MM-DD')
    END,
    customer.customerid,
    customer.customername
ORDER BY date DESC, customer.customername;
`;

      const chapterDetailsQuery = `
  SELECT 
    customer.customername as customer_name,
    ialt_books.bookname as book_name,
    ialt_books.isbn,
    workorder.otherfield->>'pii' as pii_number,
    ialt_books.remarks as remarks,
    workorder.itemcode as chapter_name,
    workorder.totalchaptercount as image_count,
    workorder.otherfield->>'egiCount' as received_image_count,
    workorder.status as chapter_status,
    to_char(wostage.updatedon, 'DD-MM-YYYY HH:MI AM') as received_date,
    to_char(wostage.plannedstartdate, 'DD-MM-YYYY HH:MI AM') as start_date,
    to_char(wostage.plannedenddate, 'DD-MM-YYYY HH:MI AM') as end_date,
    to_char(ialt_books.enddate, 'DD-MM-YYYY HH:MI AM') as book_end_date,
    to_char(wostage.plannedenddate, 'DD-MM-YYYY HH12:MI AM') as planned_end_date,
    workorder.workorderid,
    workorder.bookid,
    customer.customerid,
    CASE 
      WHEN wostage.plannedenddate::date <= CURRENT_DATE - INTERVAL '1 day' THEN 'current'
      ELSE 'future'
    END as date_category,
    CASE 
    WHEN ialt_books.plannedcompleteddate < CURRENT_DATE - INTERVAL '1 day' OR ialt_books.enddate < CURRENT_DATE - INTERVAL '1 day' THEN 'Overdue'
    WHEN workorder.ceddetails != '' AND workorder.isadvertavailable = true THEN 'Queries'
    ELSE '' 
END AS status

  FROM wms_workorder workorder
  INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
     left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
  LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
  INNER JOIN ialt_books ON ialt_books.bookid = workorder.bookid
  WHERE workorder.bookid IS NOT NULL 
  AND ${baseConditions.join(' AND ')}
  ORDER BY customer.customername, ialt_books.bookname, wostage.plannedenddate DESC`;

      const totalCountQuery = `
        SELECT COUNT(*) as total 
        FROM wms_workorder workorder 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
     left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
INNER JOIN ialt_books ON ialt_books.bookid = workorder.bookid
        AND ${baseConditions.join(' AND ')}
      `;

      const [statusCounts, dailySummary, chapterDetails, totalCount] =
        await Promise.all([
          query(statusCountQuery),
          query(dailySummaryQuery),
          query(chapterDetailsQuery),
          query(totalCountQuery),
        ]);

      // Transform status counts to grouped format
      const customerStatusCounts = statusCounts.reduce((acc, customer) => {
        acc[customer.customername] = {
          customerid: customer.customerid,
          in_progress: parseInt(customer.in_progress_count) || 0,
          completed: parseInt(customer.completed_count) || 0,
          total: parseInt(customer.total_count) || 0,
        };
        return acc;
      }, {});

      // Calculate overall totals
      const overallTotals = statusCounts.reduce(
        (acc, customer) => {
          acc.in_progress += parseInt(customer.in_progress_count) || 0;
          acc.completed += parseInt(customer.completed_count) || 0;
          acc.total += parseInt(customer.total_count) || 0;
          return acc;
        },
        { in_progress: 0, completed: 0, total: 0 },
      );

      const count = parseInt(totalCount[0].total);
      const startIndex = (pageNo - 1) * recordPerPage;
      const endIndex = startIndex + recordPerPage;
      const paginatedDetails = chapterDetails.slice(startIndex, endIndex);

      resolve({
        status: true,
        data: {
          status_counts: {
            overall: overallTotals,
            by_customer: customerStatusCounts,
          },
          summary: dailySummary,
          details: paginatedDetails,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltJobsDataList:', error);
      reject(error);
    }
  });
};

export const getiAltYTSDataList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `workorder.bookid IS NOT NULL`,
        `workorder.status != 'Completed'`,
        `woservice.isbookcompleted IS NULL`,
      ];

      if (filterObj.fromDate && filterObj.toDate) {
        baseConditions.push(
          `wostage.updatedon BETWEEN '${filterObj.fromDate} 00:00:00'::timestamp AND '${filterObj.toDate} 23:59:59'::timestamp`,
        );
      }

      const customerCountQuery = `
        SELECT 
          to_char(wostage.updatedon, 'DD-MM-YYYY') as date, -- Date without time
          customer.customerid,
          customer.customername,
          COUNT(DISTINCT workorder.workorderid) as total_books,
          COUNT(DISTINCT workorder.workorderid) as total_chapters,
          SUM(workorder.totalchaptercount) as total_images
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE workorder.bookid IS NOT NULL
        AND book.isactive = true AND ${baseConditions.join(' AND ')}
        GROUP BY 
          to_char(wostage.updatedon, 'DD-MM-YYYY'), -- Match SELECT expression
          customer.customerid, 
          customer.customername
        ORDER BY 
          to_char(wostage.updatedon, 'DD-MM-YYYY') DESC, -- Align with GROUP BY
          customer.customername;`;

      const detailQuery = `
        SELECT 
          to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as date,
          customer.customerid,
          customer.customername,
          book.bookname,
          book.isbn,
          book.chaptercount as book_total_chapters,
          workorder.otherfield->>'pii' as pii_number,
          workorder.totalchaptercount as total_images,
          workorder.otherfield->>'egiCount' as received_image_count,
          workorder.itemcode as chapter_name,
          book.enddate as end_date,
          to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as received_date,
          to_char(workorder.updated_date, 'DD-MM-YYYY HH12:MI AM') as dispatch_date,
          to_char(book.plannedcompleteddate, 'DD-MM-YYYY HH12:MI AM') as bookplannedcompleteddate,
          to_char(wostage.plannedenddate, 'DD-MM-YYYY HH12:MI AM') as plannedcompleteddate,
          to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as plannedstartdate,
          to_char(wostage.plannedenddate, 'DD-MM-YYYY') as duedate,
          workorder.workorderid,
          workorder.ceddetails AS remarks,
          workorder.status
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE workorder.bookid IS NOT NULL
        AND book.isactive = true AND ${baseConditions.join(' AND ')}
        ORDER BY wostage.updatedon DESC NULLS LAST, 
          customer.customername`;

      const totalCountQuery = `
        SELECT COUNT(*) as total 
        FROM wms_workorder workorder 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        WHERE ${baseConditions.join(' AND ')}`;

      const [customerCounts, details, totalCount] = await Promise.all([
        query(customerCountQuery, []),
        query(detailQuery, []),
        query(totalCountQuery, []),
      ]);

      const count = parseInt(totalCount[0]?.total || 0);

      resolve({
        status: true,
        data: {
          summary: customerCounts,
          details: details,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltDispatchDataList:', error);
      reject(error);
    }
  });
};

export const getiAltBookDetailList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const dataSql = `
      SELECT DISTINCT ialt_books.*, org_mst_customer.*, 
    (SELECT SUM(wms_workorder.totalchaptercount)
     FROM wms_workorder
     WHERE wms_workorder.bookid = ialt_books.bookid
       AND isactive = true) AS imagecount
FROM ialt_books
JOIN org_mst_customer ON org_mst_customer.customerid = ialt_books.customerid
LEFT JOIN wms_workorder ON wms_workorder.bookid = ialt_books.bookid
WHERE ialt_books.isactive = true
ORDER BY receiveddate DESC;

  `;
      const dataResult = await query(dataSql);

      resolve({
        status: true,
        data: dataResult,
      });
    } catch (error) {
      console.error('Error in getiAltBookDetailList:', error);
      reject(error);
    }
  });
};

export const getiAltBookwiseList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
      ];

      if (filterObj.fromDate && filterObj.toDate) {
        baseConditions.push(
          `workorder.createdon::timestamp BETWEEN '${filterObj.fromDate} 00:00:00'::timestamp AND '${filterObj.toDate} 23:59:59'::timestamp`,
        );
      }

      if (filterObj.customerId) {
        baseConditions.push(`customer.customerid = ${filterObj.customerId}`);
      }

      // Query to get both monthly summary and chapter details
      const detailedQuery = `
        WITH monthly_data AS (
          SELECT 
            DATE_TRUNC('month', workorder.createdon) as month_date,
            to_char(DATE_TRUNC('month', workorder.createdon), 'Month YYYY') as month_year,
            customer.customerid,
            customer.customername,
            book.bookid,
            book.bookname,
            COUNT(DISTINCT workorder.workorderid) as total_chapters,
            ARRAY_AGG(
              json_build_object(
                'chapter_name', workorder.itemcode,
                'image_count', workorder.totalchaptercount,
                'status', workorder.status,
                'received_date', to_char(wostage.updatedon, 'DD-MM-YYYY HH:MI AM')
              )
            ) as chapter_details
          FROM wms_workorder workorder 
          INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
          LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
          LEFT JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
          WHERE ${baseConditions.join(' AND ')}
          GROUP BY 
            DATE_TRUNC('month', workorder.createdon),
            customer.customerid,
            customer.customername,
            book.bookid,
            book.bookname
          ORDER BY DATE_TRUNC('month', workorder.createdon) DESC, customer.customername, book.bookname
        )
        SELECT * FROM monthly_data
      `;

      const totalCountQuery = `
        SELECT COUNT(DISTINCT book.bookid) as total 
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid
        WHERE ${baseConditions.join(' AND ')}
      `;

      const [monthlyData, totalCount] = await Promise.all([
        query(detailedQuery),
        query(totalCountQuery),
      ]);

      // Group the data
      const groupedBooks = monthlyData.reduce((acc, book) => {
        const key = `${book.month_year}_${book.customerid}`;
        if (!acc[key]) {
          acc[key] = {
            month_year: book.month_year,
            customerid: book.customerid,
            customername: book.customername,
            books: [],
          };
        }
        acc[key].books.push({
          bookid: book.bookid,
          bookname: book.bookname,
          total_chapters: book.total_chapters,
          chapter_details: book.chapter_details,
        });
        return acc;
      }, {});

      const summaryData = Object.values(groupedBooks);
      const count = parseInt(totalCount[0].total);
      const startIndex = (pageNo - 1) * recordPerPage;
      const endIndex = startIndex + recordPerPage;
      const paginatedSummary = summaryData.slice(startIndex, endIndex);

      resolve({
        status: true,
        data: {
          summary: paginatedSummary,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltBookwiseList:', error);
      reject(error);
    }
  });
};

export const getiAltAssetTranceferDataList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, filterObj } = payload;
      let condition = ``;
      //  let condition=`bookstatus='In Process'` -- this part for testing

      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);

      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }
      if (searchText) {
        condition += ` AND LOWER(itemcode) LIKE '%${searchText.toLowerCase()}%'`;
      }
      // payload.status = status;
      payload.condition = condition;
      const response = await getIAltAssetReportService(payload);
      let finalResponse = [];

      // if (response.data.length) {
      //   const files = response.data.map(item => {
      //     return {
      //       id: item.fileuuid,
      //     };
      //   });
      //   const getImgServices = await getImageClassificationService(files);
      //
      //   if (getImgServices.data) {
      //     response.data.forEach((item, index) => {
      //       const sItem = getImgServices.data[index];
      //       if (item.fileuuid === sItem._id) {
      //         finalResponse.push({ ...item, ...sItem });
      //       }
      //     });
      //   }
      // }

      resolve({ data: response });
    } catch (error) {
      reject(error);
    }
  });
};

export const getIAltAssetReportService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        let sql = `select * from wms_workorder as workorder 
        left join ialt_books as book on workorder.bookid = book.bookid
        left join wms_workorder_stage as wostage on workorder.workorderid = wostage.workorderid
        where workorder.isactive =true and book.isactive=true and workorder.duid = ${
          payload.duId
        } and workorder.workorderid not in (
        SELECT  distinct workorderid FROM WMS_WORKFLOW_EVENTLOG ) ${
          condition ? `${condition}` : condition
        }`;

        const getResCount = await query(sql);
        if (getResCount.length > 0) {
          const numOfPages = Math.ceil(getResCount.length / recordPerPage);
          sql = `select book.bookname,customer.customername,workorder.itemcode,workorder.totalchaptercount,
          to_char(wostage.plannedenddate, 'DD-MM-YYYY') as enddate,to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as enddate
          from wms_workorder as workorder 
          left join ialt_books as book on workorder.bookid = book.bookid
          left join wms_workorder_stage as wostage on workorder.workorderid = wostage.workorderid
          left  join org_mst_customer as customer on customer.customerid = workorder.customerid
          where workorder.isactive =true and book.isactive=true and workorder.duid = ${
            payload.duId
          } and workorder.workorderid not in (
          SELECT  distinct workorderid FROM WMS_WORKFLOW_EVENTLOG ) ${
            condition ? `${condition}` : condition
          } order by workorder.workorderid desc`;
          const response = await query(sql);
          resolve({
            status: true,
            data: response,
            total: getResCount.length,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getIAltReportService = async (
  payload,
  chapterstatus,
  activityid,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;

      if (!isServerSide) {
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        // let sql = `SELECT * FROM public.ialt_tasklist ${
        //   condition ? `WHERE ${condition}` : condition
        // }`;
        // let sql = `${ialt_tasklist} ${
        //   condition ? `WHERE ${condition}` : condition
        // }`;
        let sql = getIAltReport_query_fun(chapterstatus, activityid);

        // "isbookactive =true  AND activityid = 370 AND chapterstatus = 'Completed'"

        const getResCount = await query(sql);
        if (getResCount.length > 0) {
          const numOfPages = Math.ceil(getResCount.length / recordPerPage);
          // sql = `SELECT * FROM public.ialt_tasklist ${
          //   condition ? `WHERE ${condition}` : condition
          // } ORDER BY workorderid DESC`;
          // sql = `${ialt_tasklist} ${
          //   condition ? `WHERE ${condition}` : condition
          // } ORDER BY workorderid DESC`;
          // sql = getIAltReport_query_fun(chapterstatus, activityid);

          // const response = await query(sql);
          resolve({
            status: true,
            data: getResCount,
            total: getResCount.length,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getExportExcelData = async (payload, files) => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iAlt.base_url + config.iAlt.uri.getdataexportExcel;
      const payloadObject = {
        clientName: payload.customerName || payload.customername,
        data: files,
        isInternalReport: payload?.isInternalReport
          ? payload?.isInternalReport
          : false,
        ...(payload.bookCategory === 'vtex' && { isVtex: true }),
      };
      const result = await service.post(url, payloadObject);

      resolve(result.data);
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

// get book master datas list

export const getBookMasterDataList = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, filterObj } = payload;
      let condition = ``;
      //  let condition=`bookstatus='In Process'` -- this part for testing

      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);

      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }
      if (searchText) {
        condition += ` AND LOWER(bookname) LIKE '%${searchText.toLowerCase()}%'`;
      }
      // payload.status = status;
      payload.condition = condition;
      const response = await getBookMasterDataListService(payload);
      let finalResponse = [];
      resolve({ data: response });
    } catch (error) {
      reject(error);
    }
  });
};

export const getBookMasterDataListService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;

        let sql = '';
        // sql = `WITH maintable AS (
        //   SELECT
        //     bookid,
        //     assetuploaded,
        //     bookname,
        //     authorname,
        //     publishername,
        //     editorname,
        //     chaptercount,
        //     countryname as countryid,
        //     duid,
        //     customerid,
        //     isactive,
        //     isbn,
        //     filetype,
        //     status,
        //     startdate,
        //     receiveddate,
        //     to_char(startdate, 'dd-MM-YYYY') as assetstartdate,
        //     enddate,
        //     to_char(receiveddate, 'dd-MM-YYYY') as startdatetableshow,
        //     to_char(enddate, 'dd-MM-YYYY') as enddatetableshow,
        //     complexityid,
        //     assignedby,
        //     CASE
        //     WHEN piinumber IS NOT NULL THEN false
        //     ELSE true
        //   END AS ismanual
        //   FROM
        //     public.ialt_books
        //   WHERE
        //     isactive = true
        //     AND status != 'Completed'
        //     ${condition ? `${condition}` : ''}
        // )
        // SELECT
        //   maintable.bookid,
        //   maintable.assetuploaded,
        //   maintable.bookname,
        //   maintable.authorname,
        //   maintable.publishername,
        //   maintable.editorname,
        //   maintable.chaptercount,
        //   maintable.countryid,
        //   maintable.duid,
        //   maintable.customerid,
        //   maintable.isactive,
        //   maintable.isbn,
        //   maintable.filetype,
        //   maintable.status,
        //   maintable.startdate,
        //   maintable.receiveddate,
        //   maintable.assetstartdate,
        //   maintable.enddate,
        //   maintable.startdatetableshow,
        //   maintable.enddatetableshow,
        //   maintable.complexityid,
        //   maintable.ismanual,
        //   country.countryname,
        //   customer.customername,
        //   complexity.complexity,
        //   (SELECT concat(username, ' (', userid ,')')  FROM wms_user WHERE userid = maintable.assignedby) as assignedto
        // FROM
        //   maintable
        // LEFT JOIN
        //   geo_mst_country AS country ON maintable.countryid = country.countryid
        // LEFT JOIN
        //   org_mst_customer AS customer ON customer.customerid = maintable.customerid
        // LEFT JOIN
        //   ialt_mst_complexity AS complexity ON complexity.complexityid = maintable.complexityid
        // ORDER BY
        //   maintable.bookid DESC;
        // `;

        // const getResCount = await query(sql);
        // if (getResCount.length > 0) {
        //   const numOfPages = Math.ceil(getResCount.length / recordPerPage);
        sql = `WITH maintable AS (
            SELECT 
              bookid, 
              category,
              assetuploaded,
              bookname, 
              authorname,
              instruction, 
              publishername, 
              editorname, 
              chaptercount, 
              countryname as countryid, 
              duid, 
              customerid, 
              isactive,
              isbn,
              filetype, 
              status,
              startdate,
              receiveddate,
              to_char(startdate, 'dd-MM-YYYY') as assetstartdate,
              enddate,
              to_char(receiveddate, 'dd-MM-YYYY') as startdatetableshow,
              to_char(enddate, 'dd-MM-YYYY') as enddatetableshow, 
              complexityid,
              plannedcompleteddate,
              assignedby,
              CASE
              WHEN piinumber IS NOT NULL THEN false
              ELSE true
            END AS ismanual
            FROM 
              public.ialt_books
            WHERE 
              isactive = true 
              --AND status != 'Completed'
              ${condition ? `${condition}` : ''}
          )
          SELECT 
            maintable.bookid, 
            maintable.category,
            maintable.assetuploaded,
            maintable.bookname, 
            maintable.authorname,
            maintable.instruction, 
            maintable.publishername, 
            maintable.editorname, 
            maintable.chaptercount, 
            maintable.countryid, 
            maintable.duid, 
            maintable.customerid, 
            maintable.isactive,
            maintable.isbn,
            maintable.filetype, 
            maintable.status,
            maintable.startdate,
            maintable.receiveddate,
            maintable.assetstartdate,
            maintable.enddate,
            maintable.plannedcompleteddate,
            maintable.startdatetableshow,
            maintable.enddatetableshow, 
            maintable.complexityid,
            country.countryname,
            customer.customername, 
            complexity.complexity,
            maintable.ismanual,
            maintable.instruction, 
            (SELECT concat(username, ' (', userid ,')')  FROM wms_user WHERE userid = maintable.assignedby) as assignedto,
            maintable.assignedby,
            COALESCE(workorder.totalchaptercount, 0) AS totalchaptercount
          FROM 
            maintable
          LEFT JOIN 
            geo_mst_country AS country ON maintable.countryid = country.countryid
          LEFT JOIN 
            org_mst_customer AS customer ON customer.customerid = maintable.customerid 
          LEFT JOIN 
            ialt_mst_complexity AS complexity ON complexity.complexityid = maintable.complexityid
          LEFT JOIN (
            SELECT 
              bookid, 
              SUM(totalchaptercount) AS totalchaptercount
            FROM 
              wms_workorder
            WHERE 
              isactive = true
            GROUP BY 
              bookid
          ) AS workorder ON maintable.bookid = workorder.bookid
          ORDER BY 
            maintable.bookid DESC;`;
        const response = await query(sql);
        resolve({
          status: true,
          data: response,
          total: response.length,
          // numOfPages,
        });
        // } else {
        //   resolve({
        //     status: true,
        //     data: [],
        //     total: 0,
        //     numOfPages: 0,
        //     message: 'No data found',
        //   });
        // }
      }
    } catch (e) {
      reject(e);
    }
  });
};

// delete book master row

export const _deleteBookMasterDatas = async payload => {
  return new Promise(async (resolve, reject) => {
    const { bookid } = payload;
    try {
      // const sql1 = `Select count(*) from wms_workorder where bookid = ${bookid}`;
      // let checkCount = await query(sql1);
      // if (checkCount && checkCount[0].count == 0) {
      //   const sql = ` DELETE FROM ialt_books WHERE bookid = ${bookid}`;
      //   await query(sql);
      //   resolve(true);
      // } else {
      //   resolve(false);
      // }
      const woFalseQuery = `UPDATE wms_workorder SET isactive = false WHERE bookid = ${bookid}`;
      const bookFalseQuery = `UPDATE ialt_books SET isactive = false WHERE bookid = ${bookid}`;

      await query(woFalseQuery);
      await query(bookFalseQuery);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

// create book code master
// create book code master
export const createBookCode = async payload => {
  return new Promise(async (resolve, reject) => {
    const {
      bookname,
      country,
      authorname,
      editorname,
      duId,
      type,
      chaptercount,
      customerid,
      enddate,
      isbn,
      filetype,
      assetuploaded,
      assetstartdate,
      userId,
      instruction,
      updateChapterCount,
      startdate,
      remarks,
      category,
    } = payload;
    try {
      let sql = '';
      if (bookname && editorname) {
        sql = `select bookid from ialt_books where bookname ='${bookname}' AND editorname = '${editorname}' and isactive =true`;
      } else {
        sql = `select bookid from ialt_books where bookname ='${bookname}' and isactive =true`;
      }
      let checkCount = await query(sql);
      // if(checkCount && checkCount[0].count == 0){
      if (type == 'create') {
        if (checkCount.length == 0) {
          sql = ` INSERT INTO ialt_books ( bookname, countryname, authorname, editorname, duid, chaptercount, customerid, receiveddate, complexityid, isactive, isbn, filetype, assetuploaded, createdby, instruction, category
      )
      VALUES ( $1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP, $8, $9, $10, $11, $12, $13, $14, $15 ) RETURNING bookid`;

          const values = [
            bookname,
            country,
            authorname,
            editorname,
            duId,
            chaptercount,
            customerid,
            1,
            true,
            isbn,
            filetype,
            assetuploaded,
            userId,
            instruction,
            category,
          ];
          let response = await query(sql, values);
          let bookId = response && response[0].bookid;
          if (assetstartdate) {
            sql = `UPDATE ialt_books SET startdate =CURRENT_TIMESTAMP WHERE bookid = ${bookId}
    RETURNING bookid;`;
            await query(sql);
          }

          const startDueDate = await query(`SELECT * FROM 
          add_hours_exclude_weekends_and_holidays
        (CURRENT_TIMESTAMP::timestamp(0),48 ::integer)`);

          let formattedStartDate = await convertDateFormat(
            startDueDate?.[0]?.add_hours_exclude_weekends_and_holidays,
          );
          sql = `UPDATE ialt_books SET startdate = '${formattedStartDate}'  WHERE bookid = ${bookId}
          RETURNING bookid;`;
          await query(sql);

          resolve({ bookId: bookId, signalAuditId: 1 }); // default id sent 1
        } else {
          reject({
            message: 'This book is already registered. Try another book name.',
            status: 403,
          });
        }
      } else {
        // sql = `UPDATE ialt_books SET filetype ='${filetype}', authorname='${authorname}',editorname='${editorname}',countryname=${country} ,assetuploaded =${assetuploaded}  WHERE bookid = ${payload.bookid}
        // RETURNING bookid;`;

        sql = `UPDATE ialt_books SET filetype = $1, authorname = $2, editorname = $3, countryname = $4, assetuploaded = $5 WHERE bookid = $6 RETURNING bookid; `;
        const values = [
          filetype,
          authorname,
          editorname,
          country,
          assetuploaded,
          payload.bookid,
        ];

        let response = await query(sql, values);
        let bookId = response && response[0].bookid;
        //asset start date update
        //       if (assetstartdate) {
        //         let sql1 = `UPDATE ialt_books SET startdate =CURRENT_TIMESTAMP WHERE bookid = ${bookId}
        // RETURNING bookid;`;
        //         await query(sql1);
        //       }
        if (updateChapterCount) {
          let query1 = `select chaptercount from ialt_books where bookid = ${bookId}`;
          let chapterCount = await query(query1);
          let chapterCount1 =
            Number(chapterCount && chapterCount[0].chaptercount) +
            updateChapterCount;

          let query2 = `UPDATE ialt_books SET chaptercount =${chapterCount1} WHERE bookid = ${bookId}
          RETURNING bookid;`;
          await query(query2);
        }

        if (remarks || enddate) {
          const sql5 = `
          UPDATE ialt_books
          SET plannedcompleteddate = $1, remarks = $2
          WHERE bookid = $3
          RETURNING bookid;
        `;

          const values = [enddate || null, remarks || null, bookId];
          await query(sql5, values);
        }

        resolve({
          bookId: bookId,
          signalAuditId: 1,
        });
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const decodeSymbol = async EncodeURL => {
  return new Promise(resolve => {
    resolve(EncodeURL.replace(/%20/g, ' ').replace(/%25/g, ' '));
  });
};

// retreive blob storage files

export const _listAllFiles = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.retreiveBlobFiles;
      let encodedURL = encodeURI(pth);
      encodedURL = await decodeSymbol(encodedURL);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

// retreive local storage files

export const _locallistAllFiles = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.retreiveLocalFiles;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};
// upload zipfile format folder
export const zipFileUploadService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { formData, destPath } = payload;
      console.log(formData, destPath, 'test');
      const url = config.blob_rest.uri.localfolderzipupload;
      const result = await service.post(
        `${config.blob_rest.base_url}${url}`,
        payload,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// retreiveBookFiles for chapter creations
export const retreiveBookFilesService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { path, duId, customerId } = payload;
      const sql = `SELECT dmstype  FROM wms_mst_customerconfigdetails as cust
      join dms_master as dms on cust.dmsid = dms.dmsid 
       WHERE cust.duid=$1 and cust.customerid=$2`;
      const rows = await query(sql, [duId, customerId]);
      let retreivedFiles = [];
      switch (rows[0].dmstype) {
        case 'azure':
          retreivedFiles = await _listAllFiles(path);
          break;
        case 'local':
          retreivedFiles = await _locallistAllFiles(path);
          break;
        default:
          retreivedFiles = await _locallistAllFiles(path);
          break;
      }

      await constuctPayloadWO(retreivedFiles, path);
      resolve(retreivedFiles);
    } catch (error) {
      reject(error);
    }
  });
};

// Construct payload for chapters and image upload
export const constuctPayloadWO = (data, basePath) => {
  return new Promise((resolve, reject) => {
    try {
      const chapterArrays = {};

      data.forEach(item => {
        const relativePath = item.path.replace(basePath, '');
        const pathParts = relativePath.split('/');
        const chapterName = pathParts[0];
        // if (!chapterArrays.hasOwnProperty(chapterName)) {

        if (!(chapterName in chapterArrays)) {
          chapterArrays[chapterName] = [];
        }
        chapterArrays[chapterName].push({
          chapterPath: `${basePath + chapterName}/`,
          chapterName,
          imagePath: item.path,
          imageName: pathParts[pathParts.length - 1],
        });
      });
      console.log(chapterArrays, 'chapterArrays');
      resolve(chapterArrays);
    } catch (error) {
      console.log('Error in constructing Pay', error);
      reject(error);
    }
  });
};

// Claim action pre process service
export const claimActionPreService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      resolve({
        status: true,
        message: 'Validated',
      });
    } catch (e) {
      reject(e);
    }
  });
};
// Claim action process service
export const claimActionService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        userId,
        wfeventId,
        actualActivityCount,
        systemInfo,
        roleId,
        activityId,
        stageIteration,
        bookId,
        workorderId,
      } = data;
      await transaction(async client => {
        let wfeventIdArray = wfeventId;
        if (roleId == 1) {
          const sql = `select wfeventid from wms_workflow_eventlog 
          join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
          where workorderid =$1
          and activityid=$2 and stageiterationcount=$3 `;
          const getAllEvents = await query(sql, [
            workorderId,
            activityId,
            stageIteration,
          ]);
          wfeventIdArray = getAllEvents.map(item => item.wfeventid);
        }
        let eventData = {
          wfeventId: wfeventIdArray,
          userId,
          status: 'YTS',
          systemInfo,
          actualActivityCount,
        };
        // claim by the user directly moves to view task page so updating the status yts to claimed immediately
        eventData.status = 'Claimed';
        eventData.actionType = 'Manual';
        await updateEventLogDetails(eventData, client);
        // claim by the user directly moves to view task page so updating the status claimed to work in progress immediately
        eventData.status = 'Work in progress';
        await updateEventLog(eventData, client);
        await updateEventLogDetails(eventData, client);
        resolve({
          status: true,
          message: 'Task has been claimed successfully',
        });
      });
    } catch (e) {
      reject(e);
    }
  });
};
// View action pre process service
export const viewActionPreService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      resolve({
        status: true,
        message: 'Validated',
      });
    } catch (e) {
      reject(e);
    }
  });
};
// View action process service
export const viewActionService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, wfeventId, actualActivityCount, systemInfo } = data;
      await transaction(async client => {
        let eventData = {
          wfeventId,
          userId,
          status: 'Work in progress',
          systemInfo,
          actualActivityCount,
        };
        await updateEventLog(eventData, client);
        eventData.actionType = 'Manual';
        await updateEventLogDetails(eventData, client);
        resolve({
          status: true,
          message: 'Task has been claimed successfully',
        });
      });
    } catch (e) {
      reject(e);
    }
  });
};

// Direct Save action pre process service
export const directSaveActionPreService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      data.status = 'Work in progress';
      data.actionType = 'Manual';
      await updateActivityLog(data);
      resolve({
        status: true,
        message: 'Validated',
      });
    } catch (e) {
      reject(e);
    }
  });
};
// Direct Save action process service
export const directSaveActionService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        activityTriggerType,
        files,
        workorderId,
        serviceId,
        stageId,
        stageIteration,
        nextActivityId,
        userId,
      } = data;
      let isCorrectionArray = [];
      let payloadArray = [];
      let payload = {};
      switch (activityTriggerType) {
        case 'Image Classification Verification':
          isCorrectionArray = files.filter(item => item.isCorrection);
          payloadArray = isCorrectionArray.map(item => {
            return {
              id: item._id || item.id,
              serviceId: item.serviceId,
            };
          });
          const fileuuid = isCorrectionArray.map(item => item._id || item.id);
          if (payloadArray.length) {
            payload = {
              ...data,
              payloadArray,
              fileuuid,
            };
            await updateImageClassificationService(payload);
          }
          break;
        default:
          reject('Activity type not mapped');
          return;
      }
      const promisesCom = [];
      files.forEach(async item => {
        promisesCom.push(updateComplexity(item));
      });
      // Use Promise.all() to wait for all promises to resolve
      await Promise.all(promisesCom).then(results => {});
      data.status = 'Completed';
      data.actionType = 'Manual';
      await updateActivityLog(data);
      resolve({
        status: true,
        message: 'Image classification has been verified successfully!',
      });
      if (nextActivityId) {
        const nextActivityPayload = {
          activityId: nextActivityId,
          serviceId,
          stageId,
          stageIteration,
          workorderId,
          files,
          userId,
          actionType: 'saveTrigger',
        };
        // trigger next activity process
        const imageId = files.map(item => item.ImageId || item._id);
        const woIncomingFiles = await getWoIncomingFileInfo(imageId);
        const promises = [];
        woIncomingFiles.forEach(item => {
          nextActivityPayload.fileId = item.woincomingfileid;
          nextActivityPayload.fileuuid = item.fileuuid;
          promises.push(startProcessService(nextActivityPayload));
        });
      } else {
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Save action pre process service
export const saveActionPreService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      resolve({
        status: true,
        message: 'Validated',
      });
    } catch (e) {
      reject(e);
    }
  });
};
// Save action process service
export const saveActionService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        activityTriggerType,
        files,
        workorderId,
        serviceId,
        stageId,
        stageIteration,
        nextActivityId,
        userId,
        bookId,
        nextUserId,
      } = data;
      let isCorrectionArray = [];
      let payloadArray = [];
      let payload = {};
      let fileuuid = [];
      let resMessage = 'Task saved successfully';
      switch (activityTriggerType) {
        case 'Image Classification Verification':
          isCorrectionArray = files.filter(item => item.isCorrection);
          payloadArray = isCorrectionArray.map(item => {
            return {
              id: item._id || item.id,
              serviceId: item.long_descriptionedit,
            };
          });
          fileuuid = isCorrectionArray.map(item => item._id || item.id);
          if (payloadArray.length) {
            payload = {
              ...data,
              payloadArray,
              fileuuid,
            };
            await updateImageClassificationService(payload);
          }
          resMessage = 'Image classification has been verified successfully!';
          break;
        case 'Alt Text Generation Verification':
          // isCorrectionArray = files.filter(item => item.isCorrection);
          // payloadArray = isCorrectionArray.map(item => {
          //   return {
          //     promptName: item.promptName.value,
          //     prompt: item.prompt,
          //     id: item._id,
          //     long_descriptionedit: item.long_descriptionedit,
          //     short_descriptionedit: item.short_descriptionedit,
          //   };
          // });
          // fileuuid = isCorrectionArray.map(item => item._id || item.id);
          // if (payloadArray.length) {
          //   payload = {
          //     ...data,
          //     payloadArray,
          //     fileuuid,
          //   };
          //   await updateAltTextGenerationService(payload);
          // }
          resMessage = 'Alt text generation has been verified successfully!';
          break;
        case 'Final Verification':
          // isCorrectionArray = files.filter(item => item.isCorrection);
          // payloadArray = isCorrectionArray.map(item => {
          //   return {
          //     promptName: item.promptName.value,
          //     prompt: item.prompt,
          //     id: item._id,
          //     long_descriptionedit: item.long_descriptionedit,
          //     short_descriptionedit: item.short_descriptionedit,
          //   };
          // });
          // if (payloadArray.length)
          //   payload = {
          //     ...data,
          //     payloadArray,
          //     fileuuid,
          //   };
          // await updateAltTextGenerationService(payload);
          resMessage = 'Final viewer has been verified successfully!';
          break;
        case 'Proof Reader':
          resMessage = 'Proofing has been verified successfully!';
          break;
        case 'Dispatch':
          const { filePath, piiNumber } = data;
          const signalAuditInfo = await getSignalAuidtInfo(piiNumber);
          if (signalAuditInfo) {
            const resOfUpload = await uploadFileToS3Service({
              filePath,
              signalAuditInfo,
            });
            const notifPayload = {
              ...resOfUpload,
              piiNumber: data.piiNumber,
              title: data.title,
            };
            const resOfUploadNotif = await altTextUploadNotification(
              notifPayload,
              signalAuditInfo,
            );
          } else {
          }
          resMessage = 'The book has been dispatched successfully!';
          break;
        default:
          reject('Activity type not mapped');
          return;
      }

      data.status = 'Completed';
      data.actionType = 'Manual';
      await updateActivityLog(data);

      let isChapterCompletion = false;
      if (
        (activityTriggerType === 'Final Verification' &&
          nextActivityId != '560') ||
        activityTriggerType == 'Proof Reader'
      ) {
        isChapterCompletion = await checkAllFileCompletedForChapter(data);
      } else if (activityTriggerType === 'Dispatch') {
        // await BookCompletionProcessService(data);
        await chapterCompletionProcessService(data);
        if (bookId) {
          let sql;
          sql = `select * from wms_workorder where bookid = ${bookId} and isactive = true`;
          let result = await query(sql);
          let completedCount = 0;
          result.length &&
            result.forEach(item => {
              if (item.status === 'Completed') {
                completedCount++;
              }
            });
          if (result.length === completedCount) {
            let updateQuery;
            updateQuery = `UPDATE ialt_books SET status = 'Completed' WHERE bookid = ${bookId} and isactive = true`;
            await query(updateQuery);

            let updateActualEnddate;
            updateActualEnddate = `UPDATE ialt_books SET actualenddate =CURRENT_TIMESTAMP  WHERE bookid = ${bookId}`;
            await query(updateActualEnddate);
          }
          const sql1 = `update wms_workorder set updated_date = CURRENT_TIMESTAMP where workorderid = ${workorderId} and isactive = true`;
          await query(sql1);
        }
      }

      // next activity enable check

      if (nextActivityId) {
        if (
          (activityTriggerType === 'Final Verification' &&
            nextActivityId != '560') ||
          activityTriggerType == 'Proof Reader'
        ) {
          //Need to check here for

          if (isChapterCompletion) {
            const nextActivityPayload = {
              activityId: nextActivityId,
              serviceId,
              stageId,
              stageIteration,
              workorderId,
              files,
              userId: nextUserId ? nextUserId : userId,
              actionType: 'saveTrigger',
              activityTriggerType,
            };
            // trigger next activity process
            const woIncomingFiles = await getWoIncomingFileInfoByChapterId(
              workorderId,
            );
            const promises = [];
            woIncomingFiles.forEach(item => {
              nextActivityPayload.fileId = item.woincomingfileid;
              nextActivityPayload.fileuuid = item.fileuuid;
              nextActivityPayload.workorderId = item.woid;
              promises.push(startProcessService(nextActivityPayload));
            });

            // use this code snippet, if enable task after all chapters completed
            // const sql = `select workorderid,bookid from wms_workorder where wotype ='ialt' and bookid=$1 and status='Completed'`;
            // const bookCount = await query(sql, [data.bookId]);
            //
            //
            // if (data.chapterCount == bookCount.length) {
            //

            // } else {
            //
            // }
          }
        } else {
          const nextActivityPayload = {
            activityId: nextActivityId,
            serviceId,
            stageId,
            stageIteration,
            workorderId,
            files,
            userId: nextUserId ? nextUserId : userId,
            actionType: 'saveTrigger',
            activityTriggerType,
          };
          // trigger next activity process
          const imageId = files.map(item => item.ImageId || item._id);
          const woIncomingFiles = await getWoIncomingFileInfo(imageId);
          const promises = [];
          woIncomingFiles.forEach(item => {
            nextActivityPayload.fileId = item.woincomingfileid;
            nextActivityPayload.fileuuid = item.fileuuid;
            promises.push(startProcessService(nextActivityPayload));
          });
        }
      } else {
      }
      resolve({ status: true, message: resMessage });
    } catch (e) {
      reject(e);
    }
  });
};
// update activity log process
export const updateActivityLog = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        userId,
        wfeventId,
        actualActivityCount,
        systemInfo,
        status,
        actionType,
        nextUserId,
      } = data;
      await transaction(async client => {
        let eventData = {
          wfeventId,
          userId,
          status,
          systemInfo,
          actualActivityCount,
          actionType,
          nextUserId,
        };
        await updateEventLog(eventData, client);
        await updateEventLogDetails(eventData, client);
        resolve(`Log updated successfully`);
      });
    } catch (e) {
      reject(e);
    }
  });
};
// Cancel action pre process service
export const cancelActionPreService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      resolve({
        status: true,
        message: 'Validated',
      });
    } catch (e) {
      reject(e);
    }
  });
};
// Save action process service
export const cancelActionService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, wfeventId, actualActivityCount, systemInfo, roleId } =
        data;
      await transaction(async client => {
        let eventData = {
          wfeventId,
          status: 'YTS',
          systemInfo,
          actualActivityCount,
        };
        if (roleId == 3 || parseInt(roleId) == 55) {
          eventData.userId = userId;
        }
        await updateEventLog(eventData, client);
        eventData.actionType = 'Manual';
        eventData.status = 'Cancelled';
        await updateEventLogDetails(eventData, client);
        resolve({
          status: true,
          message: 'Task cancelled successfully',
        });
      });
    } catch (e) {
      reject(e);
    }
  });
};

export const iAltChapterCreationService = async payload => {
  var woResponse;
  try {
    woResponse = await workorderCreation(payload);
    await transaction(async client => {
      payload.workorderId = woResponse.data.workorderid;
      await woServiceCreation(payload, client);
      await woStageCreation(payload, client);
      if (!payload.isChapterScreen) {
        await addIncoming(payload);
      }
    });
    return {
      status: true,
      message: `Work order created successfully (${payload.workorderId})`,
    };
  } catch (error) {
    // Handle specific errors or rethrow for generic handling in controller
    throw error;
  }
};

export const iAltOnSaveChapterService = async payload => {
  try {
    // await addIncoming(payload);
    await _triggerIaltWorkflowController(payload);
    return {
      status: true,
      message: `Work order created successfully (${payload.workorderId})`,
    };
  } catch (error) {
    // Handle specific errors or rethrow for generic handling in controller
    throw error;
  }
};

export const updateChapterCreationService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `update wms_workorder_stage set plannedenddate = '${payload.enddate}' where workorderid = ${payload.workorderId}`;
      await query(sql);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteChapterCreationService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, bookid } = payload;

      let sql = `delete from wms_workorder_service where workorderid = ${workorderId}`;

      let sql1 = `delete from wms_workorder_stage where workorderid = ${workorderId}`;

      let sql3 = `delete from wms_workorder_incomingfiledetails where woincomingid in (select woincomingid from public.wms_workorder_incoming where woid = ${workorderId})`;

      let sql4 = `delete from wms_workorder_incoming where woid =${workorderId}`;

      let sql5 = `delete from wms_workorder where workorderid = ${workorderId}`;

      await query(sql);
      await query(sql1);
      await query(sql3);
      await query(sql4);
      await query(sql5);

      // once delete completed update the chaptercount in ialt_books table
      let sql6 = `select count(*) from wms_workorder where bookid = ${bookid} and isactive = true`;
      const responseSQL6 = await query(sql6);

      let sql7 = `UPDATE ialt_books SET chaptercount = ${responseSQL6[0].count} WHERE bookid = ${bookid}`;
      await query(sql7);

      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

//chapter creation service end

export const workorderCreationService = async payload => {
  var woResponse;
  var originalFiles;
  const extensions = [
    '.pdf',
    '.docx',
    '.doc',
    '.ppt',
    '.pptx',
    '.tiff',
    '.tif',
    '.eps',
    '.jpg',
    '.jpeg',
    '.webp',
    '.bmp',
    '.gif',
    '.ico',
    '.svg',
    '.svg+xml',
    '.png',
    '.psd',
    '.ai',
    '.xml',
  ];

  if (payload.needExtraction) {
    originalFiles = await Promise.all(
      payload.files.map(async list => {
        let sasPath = null;
        if (list.originalImageName) {
          let path = list.path;
          if (path.startsWith('/okm:root/'))
            path = path.replace('/okm:root/', '');
          if (path.startsWith('/okm_root/'))
            path = path.replace('/okm_root/', '');
          const { data } = await _downloadForIalt(path);
          sasPath = data;
          return {
            imageSASPath: sasPath?.path,
            isegiFile: list.isegiFile,
            originalImageName: list.originalImageName,
          };
        }

        const excelExtensions = ['.xls', '.xlsx', '.xlsm'];

        if (
          excelExtensions.some(ext => list.path.toLowerCase().includes(ext))
        ) {
          let path = list.path;

          if (path.startsWith('/okm:root/'))
            path = path.replace('/okm:root/', '');
          if (path.startsWith('/okm_root/'))
            path = path.replace('/okm_root/', '');
          const isExcel = excelExtensions.some(ext =>
            path.toLowerCase().endsWith(ext),
          );
          const { data } = await _downloadForIalt(path);
          sasPath = data;
          return {
            excelPath: sasPath?.path,
            isExcelFile: isExcel,
            isegiFile: list.isegiFile,
          };
        }

        if (extensions.some(ext => list.path.toLowerCase().includes(ext))) {
          let path = list.path;
          if (path.startsWith('/okm:root/'))
            path = path.replace('/okm:root/', '');
          if (path.startsWith('/okm_root/'))
            path = path.replace('/okm_root/', '');
          const { data } = await _downloadForIalt(path);
          sasPath = data;
        }

        return {
          pathWithSAS: sasPath,
          isegiFile: list.isegiFile,
        };
      }),
    );
  }

  try {
    if (
      (originalFiles && originalFiles.length > 0) ||
      !payload.needExtraction
    ) {
      woResponse = await workorderCreation(payload);
      await transaction(async client => {
        payload.workorderId = woResponse.data.workorderid;
        await woServiceCreation(payload, client);
        await woStageCreation(payload, client);

        //  await addIncoming(payload);
        // Need to integra ialt api queue incoming process
        // let originalFiles = [];

        // const extensions = [
        //   '.pdf',
        //   '.docx',
        //   '.doc',
        //   '.ppt',
        //   '.pptx',
        //   '.tiff',
        //   '.tif',
        //   '.eps',
        //   '.jpg',
        //   '.jpeg',
        //   '.webp',
        //   '.bmp',
        //   '.gif',
        //   '.ico',
        //   '.svg',
        //   '.svg+xml',
        //   '.png',
        //   '.psd',
        //   '.ai',
        //   '.xml',
        // ];

        // const originalFiles = await Promise.all(
        //   payload.files.map(async list => {
        //     let sasPath = null;

        //     if (extensions.some(ext => list.path.includes(ext))) {
        //       const { data } = await _download(list.path);
        //       sasPath = data;
        //     }

        //     return {
        //       pathWithSAS: sasPath,
        //       isegiFile: list.isegiFile,
        //     };
        //   }),
        // );
        if (payload.needExtraction) {
          payload.originalFiles = originalFiles;

          await getSourceFilesUpdateQueue(payload);
        }
      });
      // if (payload.isImage) {
      //   payload.assetType = 'image';
      //   await _triggerIaltWorkflowController(payload);
      // }

      return {
        status: true,
        message: `Work order created successfully (${payload.workorderId})`,
      };
    } else {
      throw new Error('Please upload correct format files');
    }
  } catch (error) {
    // Handle specific errors or rethrow for generic handling in controller
    throw error;
  }
};

// add incoming service
export const addIncomingService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const normalizedPayload = Array.isArray(payload) ? payload : [payload];
      const promises = normalizedPayload.map(item => addIncoming(item));
      const responses = await Promise.all(promises);
      resolve(responses);
    } catch (e) {
      reject(e);
    }
  });
};

// add incoming files service
export const addIncomingFilesService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await addIncomingFiles(payload);
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
// get selected file info service
export const getSelectedChapterInfoService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { fileId } = payload;
      const sql = `SELECT wms_workorder_incomingfiledetails.woincomingfileid,
            json_agg(json_build_object(
                'name', wms_workorder_incoming_files.name,
                'path', wms_workorder_incoming_files.path,
                'uuid', wms_workorder_incoming_files.uuid,
                'size', wms_workorder_incoming_files.size,
                'createdby', wms_workorder_incoming_files.createdby
            )) AS files
            FROM wms_workorder_incomingfiledetails
            JOIN wms_workorder_incoming_files ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workorder_incoming_files.woincomingfileid
            WHERE wms_workorder_incomingfiledetails.woincomingfileid =ANY ($1) GROUP BY wms_workorder_incomingfiledetails.woincomingfileid`;
      const response = await query(sql, [fileId]);
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
export const getWoIncomingFileInfo = imageId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT fileuuid,filepath,woincomingfileid FROM wms_workorder_incomingfiledetails 
      WHERE fileuuid =ANY ($1)`;
      const response = await query(sql, [imageId]);
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
export const getWoIncomingFileInfoByChapterId = workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT fileuuid,filepath,woincomingfileid, woid FROM wms_workorder_incomingfiledetails
      JOIN wms_workorder_incoming ON wms_workorder_incoming.woincomingid = wms_workorder_incomingfiledetails.woincomingid
      WHERE woid=$1`;
      const response = await query(sql, [workorderId]);
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
export const getWoIncomingFileInfoByBookId = bookId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT fileuuid,filepath,woincomingfileid, woid FROM wms_workorder_incomingfiledetails
      JOIN wms_workorder_incoming ON wms_workorder_incoming.woincomingid = wms_workorder_incomingfiledetails.woincomingid
      WHERE woid in (SELECT workorderid FROM wms_workorder WHERE bookid=$1)`;
      const response = await query(sql, [bookId]);
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
export const getSelectedFileInfoService = fileId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM wms_workorder_incoming_files 
      WHERE wms_workorder_incoming_files.woincomingfileid =$1`;
      const response = await query(sql, [fileId]);
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
//
export const checkAssignedTaskService = workorderIds => {
  return new Promise(async (resolve, reject) => {
    try {
      // const sql = `SELECT itemcode FROM ialt_tasklist WHERE workorderid =ANY($1) and activitystatus='Work in progress' `;

      const sql = `SELECT itemcode FROM ( ${ialt_tasklist_query} )AS ialt_tasklist WHERE workorderid =ANY($1) and activitystatus='Work in progress' `;

      const response = await query(sql, [workorderIds]);
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
//  this function will update user on task
export const taskAssignService = data => {
  return new Promise(async (resolve, reject) => {
    const { userId, workorderId, type, wfeventId } = data;
    try {
      await transaction(async client => {
        if (type === 'assign') {
          let sql = `UPDATE public.wms_workorder SET assignedby=$1 WHERE workorderid=ANY($2)`;
          await client.query(sql, [userId, workorderId]);
          sql = `UPDATE public.wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE wfeventid in (select wfeventid from wms_workflow_eventlog where workorderid=ANY($3) and activitystatus in ('Unassigned', 'YTS') ) `;
          await client.query(sql, [userId, 'YTS', workorderId]);
          sql = `UPDATE public.wms_workflow_eventlog SET userid =$1 WHERE wfeventid in (select wfeventid from wms_workflow_eventlog where workorderid=ANY($2) and activitystatus in ('Work in progress', 'Failed', 'Completed') ) `;
          await client.query(sql, [userId, workorderId]);
        } else if (type === 'reaasign') {
          let sql = `UPDATE public.wms_workorder SET assignedby=$1 WHERE workorderid=ANY($2)`;
          await client.query(sql, [userId, workorderId]);
          sql = `UPDATE public.wms_workflow_eventlog SET userid =$1 WHERE wfeventid in (select wfeventid from wms_workflow_eventlog where workorderid=ANY($2) and activitystatus not in ('Completed', 'Failed') ) `;
          await client.query(sql, [userId, workorderId]);
        } else if (type === 'tlTaskAssign') {
          let sql = `UPDATE public.wms_workflow_eventlog SET userid =$1 WHERE wfeventid =ANY($2)`;
          await client.query(sql, [userId, wfeventId]);
        }
      });
      const message =
        type === 'assign' || type === 'tlTaskAssign'
          ? 'Task assigned successfully'
          : 'The task has been successfully reassigned';
      resolve(message);
    } catch (e) {
      const message =
        type === 'assign' || type === 'tlTaskAssign'
          ? 'Task assigned failed'
          : 'Task reassigned failed';
      reject(message);
    }
  });
};
//  this function will update user on task
export const taskAssignForTLService = data => {
  return new Promise(async (resolve, reject) => {
    const { userId, bookId, type } = data;
    try {
      await transaction(async client => {
        if (type === 'assign') {
          let sql = `UPDATE public.ialt_books SET assignedby=$1 WHERE bookid=ANY($2)`;
          await client.query(sql, [userId, bookId]);
        } else if (type === 'reaasign') {
          let sql = `UPDATE public.ialt_books SET assignedby=$1 WHERE bookid=ANY($2)`;
          await client.query(sql, [userId, bookId]);
        }
      });
      const message =
        type === 'assign' || type === 'tlTaskAssign'
          ? 'Task assigned successfully'
          : 'The task has been successfully reassigned';
      resolve(message);
    } catch (e) {
      const message =
        type === 'assign' || type === 'tlTaskAssign'
          ? 'Task assigned failed'
          : 'Task reassigned failed';
      reject(message);
    }
  });
};

//check isbn status start
export const checkiAltAvailabilityService = payload => {
  return new Promise((resolve, reject) => {
    try {
      const { value, type } = payload;
      const name = value ? value.trim() : '';
      let sql = '';

      if (type === 'isbn') {
        sql = `select isbn from ialt_books where isbn='${name}' and isactive = true`;
      }
      query(sql)
        .then(data => {
          if (data.length) {
            resolve({ status: false, message: 'Not available' });
          } else {
            resolve({ status: true, message: 'Available' });
          }
        })
        .catch(error => {
          reject({ message: error });
        });
    } catch (error) {
      reject(error);
    }
  });
};

// check isbn status end
export const getOptionListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { type, duId, userId, roleId, listType, role, customer } = payload;
      let sql = ``;
      if (type === 'du') {
        sql = `select duid as value, duname as label from public.org_mst_deliveryunit WHERE duid = ${duId} AND isactive = true order by duid asc`;
      } else if (type === 'category') {
        sql = `select categoryid as value, category as label from wms_ialt_mst_category where isactive = true`;
      } else if (type === 'customer') {
        // sql = `select duid as value, duname as label from public.mst_deliveryunit WHERE duid = ${duId} AND org_mst_customer.isactive = true `;
        sql = `SELECT * FROM (
                SELECT DISTINCT ON (org_mst_customer.customerid) 
                    org_mst_customer.customerid AS value, 
                    org_mst_customer.customername AS label, 
                    org_mst_customer.customerid AS id
                FROM org_mst_customerorg_du_map 
                JOIN org_mst_customer_orgmap 
                    ON org_mst_customer_orgmap.custorgmapid = org_mst_customerorg_du_map.custorgmapid
                JOIN org_mst_customer 
                    ON org_mst_customer.customerid = org_mst_customer_orgmap.customerid
                WHERE duid = 94 
                  AND org_mst_customer.isactive = true
                ORDER BY org_mst_customer.customerid, org_mst_customer.customername  -- Ensures a deterministic row selection
            ) subquery
            ORDER BY label;`;
      } else if (type === 'complexity') {
        if (customer) {
          sql = `SELECT complexityid as value, complexityid as id, complexity as label FROM wms_ialt_mst_complexity where customerid = ${customer} 
          ORDER BY complexityid ASC`;
        } else {
          sql = `SELECT complexityid as value, complexityid as id, complexity as label FROM public.ialt_mst_complexity
          ORDER BY complexityid ASC`;
        }
      } else if (type === 'users') {
        if (role === 'TL') {
          // sql = `SELECT DISTINCT ON (wms_user.userid) wms_user.userid as value, CONCAT(wms_user.username, ' (', wms_user.userid, ')') as label FROM public.wms_user
          // JOIN wms_userrole ON wms_userrole.userid = wms_user.userid
          // WHERE duid=${duId} AND wms_userrole.roleid = 2`;

          sql = `SELECT DISTINCT ON (wms_user.userid) wms_user.userid as value, CONCAT(wms_user.username, ' (', wms_user.userid, ')') as label FROM public.wms_user 
          JOIN wms_userrole ON wms_userrole.userid = wms_user.userid
          WHERE wms_user.mappedduid @> ARRAY[${duId}]::integer[]  AND wms_userrole.roleid = 2`;
        } else if (role === 'PR') {
          sql = `SELECT DISTINCT ON (wms_user.userid) wms_user.userid as value, CONCAT(wms_user.username, ' (', wms_user.userid, ')') as label FROM public.wms_user 
          JOIN wms_userrole ON wms_userrole.userid = wms_user.userid
          WHERE wms_user.mappedduid @> ARRAY[${duId}]::integer[] AND wms_userrole.roleid = 55`;
        } else {
          sql = `SELECT DISTINCT ON (wms_user.userid) wms_user.userid as value, CONCAT(wms_user.username, ' (', wms_user.userid, ')') as label FROM public.wms_user 
          JOIN wms_userrole ON wms_userrole.userid = wms_user.userid
          WHERE wms_user.mappedduid @> ARRAY[${duId}]::integer[] AND wms_userrole.roleid = 3`;
        }
      } else if (type === 'ialtbooks') {
        sql = `select concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') as label, bookid as value, isbn as isbn, bookid as id,chaptercount,startdate,enddate from ialt_books where duid = ${duId} and isactive = true order by bookid asc`;
      } else if (type === 'books') {
        const { customerId } = payload;
        let condition = ``;
        if (customerId) {
          condition += ` AND customerid = ${customerId} `;
        }

        if (roleId != 1) {
          if (listType === 'My Task') {
            if (roleId == 1) {
              // status = ['Work in progress', 'Unassigned', 'YTS'];
              condition += ` AND activitystatus in ('Work in progress', 'Unassigned', 'YTS') AND activityid=370`;
            } else if (roleId == 2) {
              // status = ['Unassigned', 'YTS'];
              condition += ` AND activitystatus in ('Unassigned', 'YTS', 'Work in progress') AND activityid = 369 AND bookassignedby='${userId}'`;
            } else {
              // status = ['YTS', 'Work in progress'];
              condition += ` AND activitystatus in ('YTS', 'Work in progress', 'Unassigned') AND userid='${userId}'`;
            }
          }
        }

        if (roleId == 3) {
          // sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and assignedby='${userId}' ${condition} order by bookid desc`;
          sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ( ${ialt_tasklist_query} )AS ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and assignedby='${userId}' ${condition} order by bookid desc`;
        } else if (roleId == 2) {
          if (listType === 'Unassigned') {
            // sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and assignedby is null ${condition}  order by bookid desc`;
            sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ( ${ialt_tasklist_query} )AS ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and assignedby is null ${condition}  order by bookid desc`;
          } else if (listType === 'Assigned') {
            // sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and assignedby is not null ${condition}  order by bookid desc`;
            sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ( ${ialt_tasklist_query} )AS ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and assignedby is not null ${condition}  order by bookid desc`;
          } else {
            // sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and activityid = 369 ${condition}  order by bookid desc`;
            sql = `select distinct on (bookid) booknamewithedition as label, bookid as value from ( ${ialt_tasklist_query} )AS ialt_tasklist where isbookactive = true and bookstatus !='Completed' and duid = ${duId} and activityid = 369 ${condition}  order by bookid desc`;
          }
        } else {
          sql = `select concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') as label, bookid as value from ialt_books where duid = ${duId} and isactive = true and status !='Completed' ${condition} order by bookid desc`;
        }
      } else if (type === 'chapters') {
        const { bookid, customerId } = payload;
        let condition = ``;
        if (bookid) {
          if (roleId == 3) {
            condition += ` AND bookid = ${bookid} AND assignedby='${userId}'`;
          } else if (roleId == 2) {
            if (listType === 'Unassigned' || listType === 'Assigned') {
              condition += ` AND bookid = ${bookid}`;
            } else {
              condition += ` AND bookid = ${bookid} AND activityid = 369`;
            }
          } else {
            condition += ` AND bookid = ${bookid}`;
          }
        } else {
          if (roleId == 3) {
            condition += ` AND assignedby='${userId}'`;
          } else if (roleId == 2) {
            if (listType === 'Unassigned') {
              condition += ` and assignedby is null`;
            } else if (listType === 'Assigned') {
              condition += ` and assignedby is not null`;
            } else {
              condition += ` AND activityid='369'`;
            }
          }
        }

        if (customerId) {
          condition += ` AND customerid = ${customerId} `;
        }

        if (listType === 'My Task') {
          if (roleId == 1) {
            // status = ['Work in progress', 'Unassigned', 'YTS'];
            condition += ` AND activitystatus in ('Work in progress', 'Unassigned', 'YTS') AND activityid=370`;
          } else if (roleId == 2) {
            // status = ['Unassigned', 'YTS'];
            condition += ` AND activitystatus in ('Unassigned', 'YTS', 'Work in progress') AND activityid = 369 AND bookassignedby='${userId}'`;
          } else {
            // status = ['YTS', 'Work in progress'];
            condition += ` AND activitystatus in ('YTS', 'Work in progress', 'Unassigned') AND userid='${userId}'`;
          }
        }

        if (roleId == 1) {
          // sql = `select distinct on (workorderid) itemcode as label, workorderid as value  from ialt_tasklist where duid = ${duId} and isbookactive = true and ischapteractive = true and chapterstatus !='Completed' ${condition} order by workorderid asc`;
          sql = `select distinct on (workorderid) itemcode as label, workorderid as value  from ( ${ialt_tasklist_query} )AS ialt_tasklist where duid = ${duId} and isbookactive = true and ischapteractive = true and chapterstatus !='Completed' ${condition} order by workorderid asc`;
        } else {
          // sql = `select distinct on (workorderid) itemcode as label, workorderid as value  from ialt_tasklist where duid = ${duId} and isbookactive = true and ischapteractive = true and chapterstatus !='Completed'  ${condition} order by workorderid asc`;
          sql = `select distinct on (workorderid) itemcode as label, workorderid as value  from ( ${ialt_tasklist_query} )AS ialt_tasklist where duid = ${duId} and isbookactive = true and ischapteractive = true and chapterstatus !='Completed'  ${condition} order by workorderid asc`;
        }
        // sql = `select itemcode as label, workorderid as value  from wms_workorder where duid = ${duId} and isactive = true and status !='Completed'  ${condition} order by workorderid asc`;
      } else if (type === 'activity') {
        const { bookid, workorderid, roleId } = payload;
        let condition = ``;
        if (bookid) {
          condition += ` AND bookid = ${bookid}`;
        }
        if (workorderid) {
          condition += ` AND workorderid = ${workorderid}`;
        }
        // sql = `select  distinct on (activityid) activityalias as label, activityid as value from ialt_tasklist where duid = ${duId} ${condition}`;
        sql = `select activityalias as label, activityid as value from wms_workflowdefinition where wfid = ${
          parseInt(roleId) === 55 ? 162 : 38
        }  order by wfdefid asc`;
      } else if (type === 'country') {
        sql = `SELECT * FROM (
                  SELECT DISTINCT ON (geo_mst_country.countryid) 
                      geo_mst_country.countryid AS value, 
                      geo_mst_country.countryname AS label
                  FROM geo_mst_country
                  ORDER BY geo_mst_country.countryid, geo_mst_country.countryname
              ) subquery
              ORDER BY label`;
      } else if (type == 'chaptermaster') {
        const { bookid, customerId } = payload;
        let condition = ``;
        if (bookid) {
          condition += ` AND bookid = ${bookid}`;
        }
        if (customerId) {
          condition += ` AND customerid = ${customerId} `;
        }
        sql = `select itemcode as label, workorderid as value from wms_workorder where duid = ${duId} and isactive =true  and status !='Completed'  ${condition} order by workorderid desc`;
      }
      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
export const getReportOptionListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { type, filterStatus, duId, customerid } = payload;
      let sql = ``;
      if (type === 'customer') {
        // sql = `select duid as value, duname as label from public.mst_deliveryunit WHERE duid = ${duId} AND org_mst_customer.isactive = true `;
        sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label, org_mst_customer.customerid as id FROM org_mst_customerorg_du_map 
        JOIN org_mst_customer_orgmap ON org_mst_customer_orgmap.custorgmapid = org_mst_customerorg_du_map.custorgmapid
        JOIN org_mst_customer ON org_mst_customer.customerid = org_mst_customer_orgmap.customerid
        WHERE duid = ${duId} AND org_mst_customer.isactive = true `;
      } else if (type === 'books') {
        if (filterStatus == 'completed') {
          let condition = ``;
          if (customerid) {
            condition += ` AND customerid=${customerid}`;
          }
          sql = `select concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') as label, bookid as value from
         ialt_books where duid = ${duId} and isactive = true and status ='Completed' ${condition} order by bookid asc`;
        } else {
          sql = `select bookname as label, bookid as value from ialt_books where duid = ${duId} and isactive = true and status !='Completed' order by bookid desc`;
        }
      } else if (type === 'assettrnbooks') {
        const { customerId } = payload;
        let condition = ``;
        if (customerId) {
          condition += ` AND customerid=${customerId}`;
        }
        sql = `select concat(ialt_books.bookname, ' (', ialt_books.editorname, ')') as label, bookid as value from
         ialt_books where duid = ${duId} and isactive = true and status !='Completed'  and assetuploaded = true  ${condition} order by bookid desc`;
      } else if (type === 'chapters') {
        const { bookid, customerId } = payload;
        let condition = ``;

        if (payload.reporttype && payload.reporttype == 'assettrancefer') {
          if (bookid) {
            condition += ` AND bookid = ${bookid}`;
          }
          if (customerId) {
            condition += ` AND customerid = ${customerId}`;
          }
          sql = `select distinct on (workorderid) itemcode as label, workorderid as value from wms_workorder
          where isactive =true  and duid = ${payload.duId}  ${condition} and workorderid not in (
          SELECT  distinct workorderid FROM WMS_WORKFLOW_EVENTLOG ) order by workorderid desc`;
        } else {
          if (bookid) {
            condition += ` AND bookid = ${bookid}`;
          }
          // sql = `select distinct on (workorderid) itemcode as label, workorderid as value  from ialt_tasklist where duid = ${duId} and ischapteractive = true and chapterstatus ='Completed' and isbookactive = true  ${condition} order by workorderid desc`;
          sql = `select distinct on (workorderid) itemcode as label, workorderid as value  from ( ${ialt_tasklist_query} )AS ialt_tasklist where duid = ${duId} and ischapteractive = true and chapterstatus ='Completed' and isbookactive = true  ${condition} order by workorderid desc`;
        }
      }
      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
// update trigger status on service
export const updateTriggerStatusOnService = workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await updateTriggerStatusOnServiceScript();
      const response = await query(script, [workorderId]);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
// this api will do completion prcocess
export const checkAllFileCompletedForChapter = async data => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, serviceId, stageId, stageIteration } = data;
    try {
      let sql = `select wfid,totalchaptercount from wms_workorder where workorderid=${workorderId}`;
      const getImageCount = await query(sql);
      // sql = `select distinct on (wfeventid) activityalias,activitystatus,activityname,activityid,activityiterationcount,stageid,stageiterationcount from ialt_tasklist where workorderid=${workorderId}
      //   and activitystatus='Completed' and activityalias = 'Final Verification'`;
      sql = `select distinct on (wfeventid) activityalias,activitystatus,activityname,activityid,activityiterationcount,stageid,stageiterationcount from ( ${ialt_tasklist_query} )AS ialt_tasklist where workorderid=${workorderId}
        and activitystatus='Completed' AND activityalias = CASE WHEN ${getImageCount[0].wfid} = '162' THEN 'Proof Reader' ELSE 'Final Verification' END`;
      const getFinalActivityStatus = await query(sql);
      if (getImageCount.length && getFinalActivityStatus.length) {
        if (
          getImageCount[0].totalchaptercount == getFinalActivityStatus.length
        ) {
          resolve(true);
        } else {
          resolve(false);
        }
      } else {
        reject('Completion process failed due to required data not found');
      }
    } catch (e) {
      reject(e);
    }
  });
};
// this api will do completion prcocess
export const chapterCompletionProcessService = async data => {
  return new Promise(async (resolve, reject) => {
    const {
      workorderId,
      serviceId,
      stageId,
      stageIteration,
      wfdefId,
      userId,
      systemInfo,
      actualActivityCount,
    } = data;
    try {
      let sql = `SELECT wfeventid from wms_workflow_eventlog WHERE workorderid=${workorderId} AND wfdefid=${wfdefId}  `;
      const getEventId = await query(sql);
      const wfeventIds = getEventId.map(item => item.wfeventid);

      const eventLogPayload = {
        userId,
        status: 'Completed',
        wfeventId: wfeventIds,
        actionType: 'Manual',
        systemInfo,
        actualActivityCount,
      };
      await updateEventLog(eventLogPayload);
      await updateEventLogDetails(eventLogPayload);
      sql = `UPDATE public.wms_workorder_stage SET  status='Completed', enddatetime=current_timestamp WHERE wfstageid=${stageId} AND stageiterationcount=${stageIteration} AND workorderid=${workorderId}`;
      await query(sql);
      sql = `UPDATE public.wms_workorder_service SET status='Completed' WHERE serviceid=${serviceId} AND workorderid=${workorderId}`;
      await query(sql);
      sql = `UPDATE public.wms_workorder SET  status='Completed' WHERE workorderid=${workorderId}`;
      await query(sql);

      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
// this api will do completion prcocess
export const BookCompletionProcessService = async data => {
  return new Promise(async (resolve, reject) => {
    const { bookId } = data;
    try {
      const sql = `UPDATE public.ialt_books SET  status='Completed', actualenddate=current_timestamp WHERE bookid=${bookId}`;
      await query(sql);

      resolve(`Book status updated successfully - ${bookId}`);
    } catch (e) {
      reject(e);
    }
  });
};

// get PM task list report
export const getBookListByIdForPmService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { filterObj, searchText, bookId } = payload;
      let condition = `activityid = 370`;
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);
      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }

      if (searchText) {
        condition += ` AND LOWER(filename) LIKE '%${searchText.toLowerCase()}%'`;
      }

      payload.condition = condition;
      const response = await getPMTaskReportRecords(payload);
      const finalResponse = [];
      if (response.data.length) {
        const files = response.data.map(item => {
          return {
            id: item.fileuuid,
          };
        });
        const getImgServices = await getImageClassificationService(files);
        if (getImgServices.data.length) {
          response.data.forEach((item, index) => {
            const sItem = getImgServices.data[index];
            if (item.fileuuid === sItem._id) {
              finalResponse.push({
                ...item,
                ...sItem,
                complexityid: sItem.complexityid,
                ialtComplexity: sItem.ialtComplexity,
                complexity: sItem.ialtComplexity,
              });
            }
          });
        }
      }
      resolve({ ...response, data: finalResponse });
    } catch (error) {
      reject(error);
    }
  });
};
// get task list server side
export const getPMTaskReportRecords = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide, status, roleId } = payload;
      let { condition } = payload;
      if (!isServerSide) {
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        // let sql = `SELECT * FROM public.ialt_tasklist ${
        //   condition ? `WHERE ${condition}` : condition
        // }`;
        let sql = `${ialt_tasklist} ${
          condition ? `WHERE ${condition}` : condition
        }`;

        const getResCount = await query(sql);
        if (getResCount.length > 0) {
          const numOfPages = Math.ceil(getResCount.length / recordPerPage);
          // sql = `SELECT * FROM public.ialt_tasklist ${
          //   condition ? `WHERE ${condition}` : condition
          // } LIMIT ${recordPerPage} OFFSET ${offset}`;
          sql = `${ialt_tasklist} ${
            condition ? `WHERE ${condition}` : condition
          } LIMIT ${recordPerPage} OFFSET ${offset}`;
          const response = await query(sql);
          resolve({
            status: true,
            data: response,
            total: getResCount.length,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};
//  this function will update the task status and trigger next
export const updateAndNextService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      if (payload.length || payload) {
        const payloadCollection = payload.length ? payload[0] : payload;
        const {
          id,
          workorderId,
          serviceId,
          stageId,
          stageIteration,
          actionType,
          wfeventId,
          nextActivityId,
          stage,
          activity,
          fileuuid,
          type,
          wf,
          fileId,
        } = payloadCollection;
        if (
          id &&
          workorderId &&
          serviceId &&
          stageId &&
          stageIteration &&
          actionType &&
          wfeventId &&
          nextActivityId &&
          stage &&
          activity &&
          fileuuid &&
          type &&
          wf &&
          fileId
        ) {
          payloadCollection.apiStatus = 'completed';
          payloadCollection.apiMessage = {};
          await captureApiEventLog(payloadCollection);
          // update task status to completed
          payloadCollection.status = 'Completed';
          payloadCollection.userId = 'System';
          payloadCollection.actionType = 'Auto';
          await updateActivityLog(payloadCollection);
          if (payloadCollection.type != 'User Task') {
            // check whether next activity is engine or user
            await checkNextActivityAndTrigger(payloadCollection);
          }
          resolve('Task updated and triggered successfully');
        } else {
          reject('Required data is missing on the payload');
        }
      } else {
        reject('Invalid payload');
      }
    } catch (e) {
      reject(e);
    }
  });
};

// get the book wise report for dashboard
export const getiAltBookWiseReportService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        filterObj,
        searchText,
        status,
        dateRange: { startDate, endDate },
        customerId,
      } = payload;
      let condition = ` ialt_books.isactive = true`;
      if (customerId) {
        condition += ` AND ialt_books.customerid =${customerId}`;
      }
      if (startDate && endDate) {
        condition += ` AND receiveddate >= '${startDate}' AND receiveddate <=  '${endDate}'`;
      }
      if (status === 'WIP') {
        condition += ` AND ialt_books.status = 'In Process' `;
      } else if (status === 'Completed') {
        condition += ` AND ialt_books.status = 'Completed' AND NOT EXISTS (
        SELECT 1
        FROM wms_workorder
        WHERE wms_workorder.bookid = ialt_books.bookid
          AND wms_workorder.status != 'Completed'
          AND wms_workorder.isactive = true
    )`;
      } else if (status === 'Overdue') {
        condition += ` AND ialt_books.status = 'In Process' 
                       AND ( 
                            (ialt_books.plannedcompleteddate IS NOT NULL AND ialt_books.plannedcompleteddate < CURRENT_DATE) 
                            OR 
                            (ialt_books.plannedcompleteddate IS NULL AND ialt_books.enddate < CURRENT_DATE) 
                       )`;
      } else if (status === 'Queries') {
        condition += ` AND wms_workorder.ceddetails != '' and wms_workorder.isadvertavailable = true and ialt_books.status != 'Completed'`;
      }
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);
      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = '${
              filterObj[key]
            }'  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }

      if (searchText) {
        condition += ` AND LOWER(isbn) LIKE '%${searchText.toLowerCase()}%'`;
      }
      payload.condition = condition;
      const response = await getBookWiseRecords(payload);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
export const getBookWiseRecords = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
        const script = `select distinct ialt_books.*, case when wms_user.username != '' 
                   then concat(wms_user.username, '(', wms_user.userid, ')') 
                   else null 
              end as pm,
              to_char(ialt_books.startdate, 'dd-MM-YYYY') AS startdate,
              to_char(ialt_books.receiveddate, 'dd-MM-YYYY') AS receiveddate,
              to_char(ialt_books.enddate, 'dd-MM-YYYY') AS enddate,
              to_char(ialt_books.actualenddate, 'dd-MM-YYYY') AS actualenddate,
              to_char(ialt_books.plannedcompleteddate, 'dd-MM-YYYY') AS plannedcompleteddate,
              org_mst_customer.customername,
              ialt_books.book_metadata->>'PMName' as clientpmname,
              ialt_books.book_metadata->>'ChapterCount' as wochaptercount,
              ialt_books.book_metadata->>'TypeSetterName' as typesettername,
              ialt_books.book_metadata->>'PMG' as pmg,
              (select sum(wms_workorder.totalchaptercount) 
               from wms_workorder 
               where wms_workorder.bookid = ialt_books.bookid and isactive=true) as imagecount
            from ialt_books
            left join wms_user on wms_user.userid = ialt_books.createdby
            left join wms_workorder on wms_workorder.bookid = ialt_books.bookid
            left join org_mst_customer on org_mst_customer.customerid = ialt_books.customerid
          ${condition ? `WHERE ${condition}` : ''} 
          order by bookid desc`;
        const response = await query(script);
        resolve({
          status: true,
          data: response,
        });
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        let sql = '';
        // if (type === 'filter') {
        // } else {
        //   sql = `SELECT COUNT(*) FROM ialt_books ${
        //     condition ? `WHERE ${condition}` : condition
        //   }`;
        // }

        // const getResCount = await query(sql);
        // if (getResCount[0].count > 0) {
        //   const numOfPages = Math.ceil(getResCount[0].count / recordPerPage);
        const sqlQuery = `select distinct ialt_books.*, 
              case when wms_user.username != '' 
                   then concat(wms_user.username, '(', wms_user.userid, ')') 
                   else null 
              end as pm,
              to_char(ialt_books.startdate, 'dd-MM-YYYY') AS startdate,
              to_char(ialt_books.receiveddate, 'dd-MM-YYYY') AS receiveddate,
              to_char(ialt_books.enddate, 'dd-MM-YYYY') AS enddate,
              to_char(ialt_books.actualenddate, 'dd-MM-YYYY') AS actualenddate,
              org_mst_customer.customername,
              ialt_books.book_metadata->>'PMName' as clientpmname,
              ialt_books.book_metadata->>'ChapterCount' as wochaptercount,
              ialt_books.book_metadata->>'TypeSetterName' as typesettername,
              ialt_books.book_metadata->>'PMG' as pmg,
              (select sum(wms_workorder.totalchaptercount) 
               from wms_workorder 
               where wms_workorder.bookid = ialt_books.bookid and isactive=true) as imagecount
            from ialt_books
            left join wms_user on wms_user.userid=ialt_books.createdby
            left join wms_workorder on wms_workorder.bookid = ialt_books.bookid
            left join org_mst_customer on org_mst_customer.customerid=ialt_books.customerid
          ${
            condition ? `WHERE ${condition}` : condition
          } order by bookid desc `;
        const response = await query(sqlQuery);
        resolve({
          status: true,
          data: response,
          total: response.length,
          // numOfPages,
        });
        // } else {
        //   resolve({
        //     status: true,
        //     data: [],
        //     total: 0,
        //     numOfPages: 0,
        //     message: 'No data found',
        //   });
        // }
      }
    } catch (e) {
      reject(e);
    }
  });
};
// get the chapter wise report for dashboard
export const getiAltChapterWiseReportService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { filterObj, searchText, status, wfId } = payload;
      let condition = ` wms_workorder.isactive = true and wms_workorder.wfid = ${wfId}`;
      if (status === 'WIP') {
        // condition += ` AND wms_workorder.status = 'In Process' `;
      } else if (status === 'Completed') {
        // condition += ` AND wms_workorder.status = 'Completed' `;
      } else if (status === 'Overdue') {
        // condition += ` AND wms_workorder.status = 'In Process'`;
      }
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);
      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = '${
              filterObj[key]
            }'  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }

      if (searchText) {
        condition += ` AND (LOWER(itemcode) LIKE '%${searchText.toLowerCase()}%' OR LOWER(wms_workorder.otherfield ->> 'pii') LIKE '%${searchText.toLowerCase()}%')`;
      }
      payload.condition = condition;
      const response = await getChapterWiseRecords(payload);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
export const getChapterWiseRecords = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
        const script = `select distinct wms_workorder.workorderid,itemcode,wms_workorder.customerid,wms_workorder.status,totalchaptercount,wms_workorder.duid,wms_workorder.bookid,wms_workorder.assignedby, 
          to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as plannedstartdate, to_char(wostage.plannedenddate, 'DD-MM-YYYY') as plannedenddate,
          to_char(wostage.updatedon, 'DD-MM-YYYY') as receiveddate, to_char(wostage.enddate, 'DD-MM-YYYY') as enddate,
          to_char(ialt_books.plannedcompleteddate, 'dd-MM-YYYY') AS plannedcompleteddate,
          (SELECT concat(username, ' (', userid ,')')  FROM wms_user WHERE userid = wms_workorder.assignedby) as writer,
          (SELECT concat(username, ' (', userid ,')')  FROM wms_user WHERE userid = (
            select eventlog.userid
            from wms_workflow_eventlog as eventlog
            where eventlog.workorderid = wms_workorder.workorderid 
              and eventlog.wfdefid = 1259 
            limit 1
          ))
		       as reviewer,
          wms_workorder.ceddetails as remarks, wms_workorder.isadvertavailable as isadvertavailable, woservice.isbookcompleted,
          wms_workorder.otherfield ->> 'pii' as pii, to_char(wms_workorder.updated_date, 'DD-MM-YYYY') as updated_date from wms_workorder  join wms_workorder_stage as wostage on wostage.workorderid = wms_workorder.workorderid
          join wms_workorder_service as woservice on woservice.workorderid = wms_workorder.workorderid
          left join wms_workflow_eventlog as eventlog on eventlog.workorderid = wms_workorder.workorderid 
          join ialt_books as ialt_books on ialt_books.bookid = wms_workorder.bookid
          ${
            condition ? `WHERE ${condition}` : condition
          } order by wms_workorder.workorderid asc `;
        const response = await query(script);
        resolve({
          status: true,
          data: response,
        });
      } else {
        const { pageNo, recordPerPage, type, searchText } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        let sql = '';
        if (type === 'filter') {
        } else {
          sql = `SELECT COUNT(*) FROM wms_workorder ${
            condition ? `WHERE ${condition}` : condition
          }`;
        }

        const getResCount = await query(sql);
        if (getResCount[0].count > 0) {
          const numOfPages = Math.ceil(getResCount.length / recordPerPage);
          const paginationQuery = `LIMIT ${recordPerPage} OFFSET ${offset}`;

          const sqlCount = ` SELECT COUNT(*) AS total_records
          FROM wms_workorder 
          JOIN wms_workorder_stage AS wostage 
            ON wostage.workorderid = wms_workorder.workorderid
          ${condition ? ` WHERE ${condition}` : condition};`;

          const sqlCountRes = await query(sqlCount);

          let sqlQuery = `select distinct wms_workorder.workorderid,wms_workorder.itemcode,wms_workorder.customerid,wms_workorder.status,totalchaptercount,wms_workorder.duid,wms_workorder.bookid,wms_workorder.assignedby, 
          to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as plannedstartdate, to_char(wostage.plannedenddate, 'DD-MM-YYYY') as plannedenddate,to_char(wostage.updatedon, 'DD-MM-YYYY') as receiveddate, 
          to_char(ialt_books.plannedcompleteddate, 'dd-MM-YYYY') AS plannedcompleteddate,
          wms_workorder.ceddetails as remarks, wms_workorder.isadvertavailable as isadvertavailable,
          (SELECT concat(username, ' (', userid ,')')  FROM wms_user WHERE userid = wms_workorder.assignedby) as writer,
          (SELECT concat(username, ' (', userid ,')')  FROM wms_user WHERE userid = (
            select eventlog.userid
            from wms_workflow_eventlog as eventlog
            where eventlog.workorderid = wms_workorder.workorderid 
              and eventlog.wfdefid = 1259 
            limit 1
          ))
		       as reviewer,
          to_char(wostage.enddate, 'DD-MM-YYYY') as enddate,wms_workorder.otherfield ->> 'pii' as pii , to_char(wms_workorder.updated_date, 'DD-MM-YYYY') as updated_date, woservice.isbookcompleted
          from wms_workorder 
          join wms_workorder_stage as wostage on wostage.workorderid = wms_workorder.workorderid
           join ialt_books as ialt_books on ialt_books.bookid = wms_workorder.bookid
          left join wms_workflow_eventlog as eventlog on eventlog.workorderid = wms_workorder.workorderid 
          join wms_workorder_service as woservice on woservice.workorderid = wms_workorder.workorderid 
          ${
            condition ? ` WHERE ${condition}` : condition
          } order by wms_workorder.workorderid asc `;

          if (sqlCountRes[0].total_records > offset) {
            sqlQuery += paginationQuery;
          }

          const response = await query(sqlQuery);
          resolve({
            status: true,
            data: response,
            total: getResCount[0].count,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};
// get the image wise report for dashboard
export const getiAltImageWiseReportService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText } = payload;
      let condition = ``;
      if (searchText) {
        condition += ` AND LOWER(filename) LIKE '%${searchText.toLowerCase()}%'`;
      }
      payload.condition = condition;
      const response = await getImageWiseRecords(payload);
      let finalResponse = [];
      if (response.data.length) {
        const files = response.data.map(item => {
          return {
            id: item.fileuuid,
          };
        });
        const getImgServices = await getImageClassificationService(files);
        if (getImgServices.data) {
          response.data.forEach((item, index) => {
            const sItem = getImgServices.data[index];
            if (item.fileuuid === sItem._id) {
              finalResponse.push({ ...item, ...sItem });
            }
          });
        }
      }
      resolve({ ...response, data: finalResponse });
    } catch (error) {
      reject(error);
    }
  });
};
export const getImageWiseRecords = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition, workorderId } = payload;
      if (!isServerSide) {
        const script = `select woincomingfileid, filename, filepath, fileuuid, filetypeid, istriggered, thumbnailurl from wms_workorder_incomingfiledetails
          where woincomingid in (select woincomingid from wms_workorder_incoming where woid=${workorderId})`;
        const response = await query(script);
        resolve(response);
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;
        let sql = '';
        if (type === 'filter') {
        } else {
          sql = `select COUNT(*) from wms_workorder_incomingfiledetails
          where woincomingid in (select woincomingid from wms_workorder_incoming where woid=${workorderId}) ${condition}`;
        }

        const getResCount = await query(sql);
        if (getResCount[0].count > 0) {
          const numOfPages = Math.ceil(getResCount[0].count / recordPerPage);
          const sqlQuery = `SELECT
              wwif.woincomingfileid,
              wwif.filename,
              wwif.filepath,
              wwif.fileuuid,
              wwif.filetypeid,
              wwif.istriggered,
              wwif.thumbnailurl,
              wwif.complexityid,
              wf_eventlog.wfeventid,
            wf_eventlog.wfdefid,
            wms_workflowdefinition.activityalias,
            ialt_mst_complexity.complexity,
            ialt_mst_complexity.complexityid,
            woid
          FROM wms_workorder_incoming AS wwi
          JOIN wms_workorder_incomingfiledetails AS wwif ON wwif.woincomingid = wwi.woincomingid
          JOIN (
              SELECT woincomingfileid, MAX(wfeventid) AS max_wfeventid
              FROM wms_workflow_eventlog
              GROUP BY woincomingfileid
          ) AS wf_eventlog_max ON wf_eventlog_max.woincomingfileid = wwif.woincomingfileid
          JOIN wms_workflow_eventlog AS wf_eventlog ON wf_eventlog.woincomingfileid = wwif.woincomingfileid AND wf_eventlog.wfeventid = wf_eventlog_max.max_wfeventid
          join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wf_eventlog.wfdefid
          left join ialt_mst_complexity on ialt_mst_complexity.complexityid = wwif.complexityid
          WHERE wwi.woid = ${workorderId}  ${condition}
            LIMIT ${recordPerPage} OFFSET ${offset}`;
          const response = await query(sqlQuery);
          resolve({
            status: true,
            data: response,
            total: getResCount[0].count,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getDashboardReportOptionListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { type, duId, customerId, status, pmId, bookId } = payload;
      let sql = ``;
      if (type === 'customer') {
        sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label, org_mst_customer.customerid as id FROM org_mst_customerorg_du_map 
        JOIN org_mst_customer_orgmap ON org_mst_customer_orgmap.custorgmapid = org_mst_customerorg_du_map.custorgmapid
        JOIN org_mst_customer ON org_mst_customer.customerid = org_mst_customer_orgmap.customerid
        WHERE duid = ${duId} AND org_mst_customer.isactive = true `;
      } else if (type === 'books') {
        let condition = ``;
        if (status === 'WIP') {
          condition = ` AND status = 'In Process' `;
        } else if (status === 'Completed') {
          condition = ` AND status = 'Completed' `;
        } else if (status === 'Overdue') {
          condition = ` AND status = 'In Process' AND enddate < CURRENT_TIMESTAMP `;
        }
        if (customerId) {
          condition += ` AND customerid=${customerId}`;
        }
        if (pmId) {
          condition += ` AND createdby='${pmId}'`;
        }
        sql = `select concat(bookname, ' (', editorname, ')') as label, bookid as value from ialt_books where duid = ${duId} and isactive = true ${condition}  order by bookid desc`;
      } else if (type === 'pm') {
        let condition = ``;
        const { roleId } = payload;

        if (roleId && payload?.isPM) {
          condition += `AND wms_userrole.roleid = 1`;
        }
        sql = `select distinct on (wms_user.userid) wms_user.username as label, wms_user.userid as value  from wms_user 
        join wms_userrole on  wms_userrole.userid = wms_user.userid
        where duid = ${duId} and wms_user.useractive=true ${condition}`;
      } else if (type === 'chapters') {
        let condition = ``;
        if (status === 'WIP') {
          condition = ` AND status = 'In Process' `;
        } else if (status === 'Completed') {
          condition = ` AND status = 'Completed' `;
        } else if (status === 'Overdue') {
          condition = ` AND status = 'In Process' `;
        }
        sql = `select itemcode as label, workorderid as value from wms_workorder where bookid = ${bookId} and isactive = true ${condition}  order by workorderid desc`;
      } else if (type === 'activity') {
      } else if (type === 'chapterisbn') {
        let condition = ``;
        const { customerId } = payload;
        if (customerId) {
          condition += ` AND customerid=${customerId}`;
        }
        sql = `select itemcode as label, otherfield ->>'pii' as value from wms_workorder 
        where duid = ${duId} and isactive = true ${condition} order by workorderid desc`;
      }
      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
export const getDashboardDataService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        dateRange: { startDate, endDate },
        customerId,
      } = payload;
      let condition = ``;
      if (customerId) {
        condition += ` AND customerid=${customerId} `;
      }
      if (startDate && endDate) {
        condition += ` AND receiveddate >= '${startDate}' AND receiveddate <=  '${endDate}'`;
      }
      let sql = `select * from ialt_books where isactive=true ${condition} `;
      const response = await query(sql);
      sql = `SELECT COUNT(*) FROM ialt_books WHERE isactive = true AND status = 'In Process' 
      AND (
        (plannedcompleteddate IS NOT NULL AND plannedcompleteddate < CURRENT_DATE) 
        OR 
        (plannedcompleteddate IS NULL AND enddate < CURRENT_DATE)
      ) ${condition} `;
      const resOverDue = await query(sql);
      // let sqlQuery = await query(
      //   `select count(*) from ialt_books where isactive=true ${condition} and remarks != ''`,
      // );
      let sqlQuery = await query(
        `SELECT COUNT(DISTINCT ib.bookid) AS book_count
          FROM ialt_books ib
          JOIN wms_workorder wo ON ib.bookid = wo.bookid
          WHERE wo.ceddetails != ''
          AND wo.isadvertavailable = true AND ib.isactive = true AND wo.isactive=true and wo.customerid = ${customerId} and wo.wfid = 38 
          and ib.status != 'Completed'`,
      );
      let queryCount;
      queryCount = sqlQuery[0].book_count;
      // Initialize counters
      let overdueCount = resOverDue.length ? resOverDue[0].count : 0;
      let completedCount = 0;
      let inProcessCount = 0;
      // Iterate through the array and count items
      response.length &&
        response.forEach(item => {
          const endDate = new Date(item.enddate);
          if (item.status === 'Completed') {
            completedCount++;
          } else if (item.status === 'In Process') {
            inProcessCount++;
          }
        });
      resolve({ overdueCount, completedCount, inProcessCount, queryCount });
    } catch (error) {
      reject(error);
    }
  });
};

function countComplexityLevels(data) {
  const counts = data.reduce((acc, item) => {
    const level = item.ialtComplexity.toLowerCase();
    acc[level] = (acc[level] || 0) + 1;
    return acc;
  }, {});

  const levels = [
    { complexityid: '1', complexity: 'Simple', count: counts.simple || '0' },
    { complexityid: '2', complexity: 'Medium', count: counts.medium || '0' },
    { complexityid: '3', complexity: 'Complex', count: counts.complex || '0' },
  ];

  return levels;
}

export const getImageCountInfoService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText } = payload;
      let condition = ``;
      if (searchText) {
        condition += ` AND LOWER(filename) LIKE '%${searchText.toLowerCase()}%'`;
      }
      payload.condition = condition;
      const response = await getImageWiseRecords(payload);
      let finalResponse = [];
      if (response.length) {
        const files = response.map(item => {
          return {
            id: item.fileuuid,
          };
        });
        const getImgServices = await getImageClassificationService(files);
        console.log(getImgServices);
        if (getImgServices.data) {
          response.forEach((item, index) => {
            const sItem = getImgServices.data[index];
            if (item.fileuuid === sItem._id) {
              finalResponse.push({ ...item, ...sItem });
            }
          });
        }
        const complexityCounts = countComplexityLevels(finalResponse);
        resolve(complexityCounts);
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const getAllImageIdByBook = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { bookId } = payload;
      let condition = ``;
      if (bookId) {
        condition += `bookid=${bookId}`;
      }
      // let sql = `select distinct on (fileuuid) fileuuid as id, itemcode as chapter, complexityid as complexityId from ialt_tasklist where ${condition}`;
      let sql = `select distinct on (fileuuid) fileuuid as id, itemcode as chapter, bookname as book, complexityid as complexityId, piinumber as pii from ( ${ialt_tasklist_query} )AS ialt_tasklist where ${condition}`;
      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
export const getAllImageIdByChapter = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, status } = payload;
      let condition = '';

      if (workorderId) {
        condition += ` WHERE workorderid=${workorderId}`;
      }

      if (status) {
        condition += workorderId ? ` AND` : ` WHERE`;
        condition += ` activitystatus='${status}'`;
      }

      // const sql = `SELECT DISTINCT ON (fileuuid) fileuuid AS id, itemcode AS chapter FROM ialt_tasklist ${condition}`;
      const sql = `SELECT DISTINCT ON (fileuuid) fileuuid AS id, itemcode AS chapter FROM ( ${ialt_tasklist_query} )AS ialt_tasklist ${condition}`;

      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

export const iAltAutoJobCreationService = payload => {
  return new Promise(async (resole, reject) => {
    const { jobFlowType, signalAuditId } = payload;
    try {
      let logHisPayload = {
        signalAuditId,
        request: payload,
      };
      if (!jobFlowType && !signalAuditId) {
        const msg =
          'Required filed "Job Type | signalAuditId " is missing from the payload';
        logHisPayload.response = msg;
        logHisPayload.status = 'Failed';
        logHisPayload.message = msg;
        logHisPayload.processStatusId = 16;
        await ialtSignalLogHistory(logHisPayload);
        throw new Error(msg);
      }
      if (jobFlowType === 'ialt') {
        await altTextJobCreation(payload);
      } else {
        await altArticleJobCreation(payload);
      }

      resole({ status: true, message: 'Job creation successfull!' });
    } catch (err) {
      reject(err);
    }
  });
};
const altTextJobCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    let jobCreationPayload = { ...payload };
    try {
      let logHisPayload = {
        signalAuditId,
        request: payload,
        response: 'Job creation process has started',
        message: 'Job creation process has started',
        status: 'Success',
        processStatusId: 6,
      };
      await ialtSignalLogHistory(logHisPayload);

      await validatePayload(payload);

      jobCreationPayload = await readMetadata(jobCreationPayload);
      jobCreationPayload = await constructPayloadForBookCreation(
        jobCreationPayload,
      );
      jobCreationPayload = await constructPayloadForIaltWOCreation(
        jobCreationPayload,
      );
      const filesRes = await getSourceFileResponse(jobCreationPayload);
      jobCreationPayload = { ...jobCreationPayload, ...filesRes };
      await bookCreationProcess(jobCreationPayload);
      if (jobCreationPayload.chapterInfo.files.length) {
        await incomingCreationProcess(jobCreationPayload);
        //  await workflowTriggerProcess(jobCreationPayload);
      } else {
        const msg = `Auto extraction failed due to vector images. Manual processing required.`;
        logHisPayload = {
          signalAuditId,
          request: jobCreationPayload,
          response: msg,
          message: msg,
          status: 'Success',
          processStatusId: 29,
        };
        await ialtSignalLogHistory(logHisPayload);
      }
      const msg = `Job creation process completed`;
      logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 12,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ status: true, message: msg });
    } catch (err) {
      const msg = `Job creation process failed`;
      const logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Failed',
        processStatusId: 21,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
const validatePayload = payload => {
  return new Promise((resolve, reject) => {
    try {
      const {
        jobFlowType,
        signalAuditId,
        title,
        stageName,
        piiNumber,
        dms,
        metaData,
      } = payload;
      if (
        !jobFlowType &&
        !signalAuditId &&
        Object.keys(dms).length &&
        metaData &&
        title &&
        stageName
      ) {
        throw new Error('Required filed is missing from the payload');
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
export const readMetadata = item => {
  return new Promise((resolve, reject) => {
    try {
      const payload = {
        ...item,
      };
      //delete payload.metaData; //no need metaData above metaData info present
      resolve(payload);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};

// construct iAlt book payload
export const constructPayloadForBookCreation = data => {
  return new Promise((resolve, reject) => {
    try {
      const payload = {
        ...data,
        bookInfo: {
          ...data.bookInfo,
          duId: data.duId,
          customerId: data.customerId,
          country: '1',
          authorName: '',
          // edition: Math.floor(1000 + Math.random() * 9000),
          edition: 1,
          chapterCount: '1',
          startDate: moment().format('YYYY-MM-DD hh:mm:ss'),
          endDate: data.bookInfo.dueDate,
          instruction: '',
          customerType: 'Higher Education',
          piiNumber: data.piiNumber,
        },
      };
      resolve(payload);
    } catch (error) {
      reject(error);
    }
  });
};
// construct iAlt chaptercreation payload

export const constructPayloadForIaltWOCreation = data => {
  return new Promise((resolve, reject) => {
    try {
      const payload = {
        ...data,
        chapterInfo: {
          ...data.chapterInfo,
          wfId: data.wfId,
          customerId: data.customerId,
          woType: data.jobFlowType,
          duId: data.duId,
          serviceId: data.serviceId,
          stageId: data.stageId,
          stageIteration: data.stageIteration,
          bookId: data.bookId,
          imageCount: 0,
          complexityId: 1,
          piiNumber: data.piiNumber,
        },
      };
      resolve(payload);
    } catch (error) {
      reject(error);
    }
  });
};

// ialt signal log
export const ialtSignalLogService = (data, action) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobFlowTypeId,
        serviceCallType,
        piiNumber,
        response,
        ackMsgInfo,
        signalAuditId,
        duId,
        customerId,
        updateType,
        status,
        message,
        processStatusId,
      } = data;
      let sql = ``;
      if (action == 'Insert') {
        sql = `INSERT INTO wms_mst_signal_audit(
          jobflowtypeid, servicecalltype, duid, customerid, pii, signalinfo, status, receiveddate)
          VALUES (${jobFlowTypeId}, '${serviceCallType}', ${duId}, ${customerId}, '${piiNumber}', '${JSON.stringify(
          ackMsgInfo,
        )}', 'In Progress', CURRENT_TIMESTAMP) RETURNING signalauditid`;
      } else {
        if (updateType === 'acknowledged') {
          sql = `UPDATE wms_mst_signal_audit SET acknowledgeddate=CURRENT_TIMESTAMP WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
        } else if (updateType === 'completed') {
          sql = `UPDATE wms_mst_signal_audit SET status='Completed', completeddate=CURRENT_TIMESTAMP WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
        } else if (updateType === 'failed') {
          sql = `UPDATE wms_mst_signal_audit SET status='Failed', faileddate=CURRENT_TIMESTAMP WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
        } else if (updateType === 'inprogress') {
          sql = `UPDATE wms_mst_signal_audit SET status='In Progress' WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
        }
      }
      const result = await query(sql);
      const auditId = result[0].signalauditid;
      if (action == 'Insert') {
        const payload = {
          signalAuditId: auditId,
          request: {},
          response,
          processStatusId,
          status,
          message,
        };
        await ialtSignalLogHistory(payload);
      }
      resolve({
        status: true,
        data: auditId,
        message:
          action == 'Insert'
            ? 'Log inserted successfully'
            : 'Log updated successfully',
      });
    } catch (error) {
      reject({ status: false, message: error.message ? error.message : error });
    }
  });
};
export const ialtSignalLogHistory = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        status,
        message,
        processStatusId,
        signalAuditId,
        request,
        response,
      } = data;
      const sql = `INSERT INTO wms_mst_signal_audit_trns(signalauditid, processstatusid, request, response, createdon, message, status)
      VALUES (${signalAuditId}, ${processStatusId},'${
        JSON.stringify(request) || null
      }','${
        JSON.stringify(response) || null
      }', CURRENT_TIMESTAMP, '${message}', '${status}' ) RETURNING signalaudittrnsid`;
      await query(sql);
      resolve({ status: true, message: 'Log trns inserted successfully' });
    } catch (error) {
      reject({ status: false, message: error.message ? error.message : error });
    }
  });
};

//get incoming files extracted pdf and images response from ialt team
export const getSourceFileResponse = payload => {
  return new Promise(async (resolve, reject) => {
    let logHisPayload = {};
    const { signalAuditId, originalFiles } = payload;
    try {
      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: 'Source file upload to iAlt has started',
        message: 'Source file upload to iAlt has started',
        status: 'Success',
        processStatusId: 7,
      };
      await ialtSignalLogHistory(logHisPayload);

      let egiFiles = [];
      let referenceFiles = [];

      if (originalFiles && originalFiles.length > 0) {
        // Filter for isegiFile: true and get pathWithSAS
        egiFiles = originalFiles
          .filter(item => item.isegiFile)
          .map(item => item.pathWithSAS);

        // Filter for isegiFile: false and get pathWithSAS
        referenceFiles = originalFiles
          .filter(item => !item.isegiFile)
          .map(item => item.pathWithSAS);
      }

      const payloadArray = {
        files: egiFiles && egiFiles.length > 0 ? egiFiles : referenceFiles,
        ReferenceFile: referenceFiles,
      };

      const url = config.iAlt.base_url + config.iAlt.uri.ialtFileUploadFromBlob;
      const result = await service.post(url, payloadArray);
      const filteredData = Array.isArray(result?.data)
        ? result.data.filter(file => file?.imageurl)
        : [];
      // let result = {};
      // result.data = [
      //   {
      //     short_description: '',
      //     long_description: '',
      //     short_descriptionedit: '',
      //     long_descriptionedit: '',
      //     caption: '',
      //     assettype: 'image',
      //     page_no: '',
      //     image_number: '',
      //     image_chapter: '',
      //     short_description_accuracy: '100%',
      //     long_description_accuracy: '100%',
      //     notes: '',
      //     isActive: true,
      //     revision: 0,
      //     _id: '669617bb54f1ab04d7107529',
      //     imagename: 'ee952b7c-798b-4e80-9022-7f89a89e7799/page_1_image_0.png',
      //     imageurl:
      //       'https://integraproductsasa.blob.core.windows.net/alt/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_0.png',
      //     thumbnailurl:
      //       'https://integraproductsasa.blob.core.windows.net/alt/dev/upload/thumbnail/ee952b7c-798b-4e80-9022-7f89a89e7799_2024-07-16_06-47-43/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_0.png',
      //     originalType: 'image/png',
      //     fileType: 'image/png',
      //     size: '65.88 KB',
      //     service: '',
      //     project_id: '',
      //     client_id: '',
      //     apiStatus: '0',
      //     updatedBy: '',
      //     updatedOn: '2024-07-16T06:48:27.000Z',
      //     __v: 0,
      //   },
      //   // {
      //   //   short_description: '',
      //   //   long_description: '',
      //   //   short_descriptionedit: '',
      //   //   long_descriptionedit: '',
      //   //   caption: '',
      //   //   assettype: 'pdf',
      //   //   page_no: '',
      //   //   image_number: '',
      //   //   image_chapter: '',
      //   //   short_description_accuracy: '100%',
      //   //   long_description_accuracy: '100%',
      //   //   notes: '',
      //   //   isActive: true,
      //   //   revision: 0,
      //   //   _id: '669617bb54f1ab04d710752a',
      //   //   imagename: 'ee952b7c-798b-4e80-9022-7f89a89e7799/page_1_image_1.png',
      //   //   imageurl:
      //   //     'https://integraproductsasa.blob.core.windows.net/alt/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_1.png',
      //   //   thumbnailurl:
      //   //     'https://integraproductsasa.blob.core.windows.net/alt/dev/upload/thumbnail/ee952b7c-798b-4e80-9022-7f89a89e7799_2024-07-16_06-47-43/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_1.png',
      //   //   originalType: 'image/png',
      //   //   fileType: 'image/png',
      //   //   size: '238.33 KB',
      //   //   service: '',
      //   //   project_id: '',
      //   //   client_id: '',
      //   //   apiStatus: '0',
      //   //   updatedBy: '',
      //   //   updatedOn: '2024-07-16T06:48:27.000Z',
      //   //   __v: 0,
      //   // },
      // ];
      if (filteredData.length) {
        filteredData.forEach((list, i) => {
          list.filesequence = i + 1;
          list.filetypeid = 85;
          list.complexityid = 1;
          list.caption = list.caption.replace(/(')/g, '$1$1');
        });
      }

      payload.chapterInfo.files = filteredData;
      payload.chapterInfo.imageCount = filteredData.length;
      payload.chapterInfo.complexityId = 1;

      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: payload.chapterInfo.files,
        message: 'Source file upload to iAlt has been completed',
        status: 'Success',
        processStatusId: 8,
      };
      await ialtSignalLogHistory(logHisPayload);

      resolve(payload);
    } catch (error) {
      let resError;
      if (typeof error === 'object' && error !== null) {
        resError =
          error.message?.data?.message ??
          error.message ??
          'Source file upload to iAlt has failed';
      } else {
        resError = 'Source file upload to iAlt has failed';
      }
      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: resError,
        message: 'Source file upload to iAlt has failed',
        status: 'Failed',
        processStatusId: 17,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject({ status: false, message: resError });
    }
  });
};
// book , chapter, service and stage creation process
export const bookCreationProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      // book creation process
      const { bookId } = await ialtAutoBookCreate(payload.bookInfo);
      payload.chapterInfo.bookId = bookId;
      payload.bookId = bookId;
      // chapter creation process
      let { data } = await workorderCreation(payload.chapterInfo);
      payload.chapterInfo.workorderId = data.workorderid;
      payload.workorderId = data.workorderid;
      // service creation process
      await woServiceCreation(payload.chapterInfo);
      // stage creation process
      await woStageCreation(payload.chapterInfo);
      const msg =
        'Book chapter, service, or stage has been created successfully';
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 9,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ status: true, message: msg });
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message
          ? err.message
          : 'Book, chapter, service, or stage creation failed',
        message: 'Book, chapter, service, or stage creation failed',
        status: 'Success',
        processStatusId: 18,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
export const incomingCreationProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      // incoming creation process
      await addIncoming(payload.chapterInfo);
      const msg = 'Incoming creation process has been completed';
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 10,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ status: true, message: msg });
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message
          ? err.message
          : 'Incoming creation process failed',
        message: 'Incoming creation process failed',
        status: 'Failed',
        processStatusId: 19,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
export const workflowTriggerProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      payload.chapterInfo.assetType = 'image';
      payload.chapterInfo.isSignalTrigger = true;
      payload.chapterInfo.actionType = 'trigger';
      const { status } = await _triggerIaltWorkflowController(
        payload.chapterInfo,
      );
      let msg = 'Workflow not triggered, waiting for pdf extraction review';
      if (status) {
        msg = 'Workflow triggered successfully';
        const logHisPayload = {
          signalAuditId,
          request: payload,
          response: msg,
          message: msg,
          status: 'Success',
          processStatusId: 11,
        };
        await ialtSignalLogHistory(logHisPayload);
      } else {
        const logHisPayload = {
          signalAuditId,
          request: payload,
          response: msg,
          message: msg,
          status: 'Success',
          processStatusId: 30,
        };
        await ialtSignalLogHistory(logHisPayload);
      }
      resolve({ status: true, message: msg });
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message ? err.message : 'Workflow trigger failed',
        message: 'Workflow trigger failed',
        status: 'Failed',
        processStatusId: 20,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};

//create book ialt auto workorder creation
export const ialtAutoBookCreate = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        title,
        isbn,
        country,
        authorName,
        edition,
        duId,
        userId,
        customerId,
        chapterCount,
        endDate,
        customerType,
        instruction,
        piiNumber,
      } = payload;
      let bookId = '';
      let sql = `select bookid from ialt_books where isbn ='${isbn}' and isactive =true`;
      let checkExits = await query(sql);
      if (!checkExits.length) {
        sql = `Insert into ialt_books(bookname,countryname,authorname,editorname,duid,chaptercount,customerid,receiveddate,enddate,isactive,isbn,filetype,assetuploaded,createdby, instruction, startdate,piinumber) values
      ('${title}',${country},'${authorName}','${edition}',${duId},${chapterCount},${customerId},CURRENT_TIMESTAMP,'${endDate}',true,'${isbn}','${customerType}',true,'${userId}','${instruction}', CURRENT_TIMESTAMP,'${piiNumber}') RETURNING bookid`;
        let response = await query(sql);
        bookId = response.length ? response[0].bookid : null;
      } else {
        bookId = checkExits.length ? checkExits[0].bookid : null;
        const sql1 = `select count(*) from wms_workorder where bookid =${bookId}`;
        const countRes = await query(sql1);
        const count = parseInt(countRes?.[0]?.count, 10) || 0; // Default to 0 if count is not available
        const sql2 = `UPDATE ialt_books SET chaptercount = ${
          count + 1
        } WHERE bookid = ${bookId}`;
        await query(sql2);
      }
      resolve({ bookId: bookId });
    } catch (error) {
      reject({ status: false, message: error.message ? error.message : error });
    }
  });
};

//get ialt job summary report

export const getiAltSignalAuditService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, filterObj, duId } = payload;
      let condition = `Where audit.isactive = true and audit.duid =${duId}`;
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);

      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${
              index == 0 ? ' AND' : ''
            } ${key} = ${`'${filterObj[key]}'`}  ${
              arrayFilter.length - 1 != index ? 'AND' : ''
            } `;
          }
        });
      }
      if (searchText) {
        condition += ` AND LOWER(audit.pii) LIKE '%${searchText.toLowerCase()}%'`;
      }
      // payload.status = status;
      payload.condition = condition;
      const response = await _getiAltSignalAuditService(
        payload,
        searchText.toLowerCase(),
      );
      resolve({ response });
    } catch (error) {
      reject(error);
    }
  });
};
export const _getiAltSignalAuditService = async (payload, searchText) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;

        let sql = `select * from wms_mst_signal_audit as audit 
       -- join wms_mst_jobflowtype as flowtype on audit.jobflowtypeid = flowtype.jobflowtypeid
         ${
           condition ? `${condition}` : condition
         } AND audit.servicecalltype = 'GenerateAltText'`;

        const getResCount = await query(sql);
        if (getResCount.length > 0) {
          const numOfPages = Math.ceil(getResCount.length / recordPerPage);
          const paginationQuery = `LIMIT ${recordPerPage} OFFSET ${offset}`;
          condition = condition.replace(
            /\bcustomerid\b/,
            'workorder.customerid',
          );
          condition = condition.replace(
            /\bchaptername\b/,
            'workorder.itemcode',
          );

          let sql = `
          SELECT DISTINCT ON (audit.signalauditid) 
            audit.signalauditid,
            audit.pii,
            audit.status,
            TO_CHAR(audit.receiveddate, 'DD-MM-YYYY HH:MI AM') AS receiveddate,
            TO_CHAR(audit.acknowledgeddate, 'DD-MM-YYYY HH:MI AM') AS acknowledgeddate,
            TO_CHAR(audit.completeddate, 'DD-MM-YYYY HH:MI AM') AS completeddate,
            TO_CHAR(audit.faileddate, 'DD-MM-YYYY HH:MI AM') AS faileddate,
            audit.servicecalltype,
            book.bookname,
            book.isbn,
            workorder.itemcode as chaptername
          FROM wms_mst_signal_audit AS audit
         -- JOIN wms_mst_jobflowtype AS flowtype 
         -- ON audit.jobflowtypeid = flowtype.jobflowtypeid  
          LEFT JOIN wms_workorder AS workorder 
            ON workorder.otherfield->>'pii' = audit.pii
          LEFT JOIN ialt_books AS book 
            ON book.bookid = workorder.bookid 
            ${condition}
            AND audit.servicecalltype = 'GenerateAltText'
            ORDER BY audit.signalauditid DESC 
          ${paginationQuery};
            `;

          // if (sqlCountRes[0].total_records > offset) {
          //   sql += paginationQuery;
          // }

          const response = await query(sql);

          resolve({
            status: true,
            data: response,
            total: getResCount.length,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const deleteBookRelatedEntry = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT delete_book_and_related_data('${payload.piiNumber}')`;
      await query(sql);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const iAltJobSummaryRetriggerService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // await deleteBookRelatedEntry(payload);
      const response = await iAltAutoJobCreationService(payload);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

// ialt article job creation
const altArticleJobCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    let jobCreationPayload = { ...payload };
    try {
      let logHisPayload = {
        signalAuditId,
        request: payload,
        response: 'Job creation process has started',
        message: 'Job creation process has started',
        status: 'Success',
        processStatusId: 6,
      };
      await ialtSignalLogHistory(logHisPayload);

      await validatePayload(payload);
      // await checkWOExists(payload);

      jobCreationPayload = await readMetadata(jobCreationPayload);
      jobCreationPayload = await constructPayloadForArticleWOCreation(
        jobCreationPayload,
      );
      const woResponse = await artilceWoCreationProcess(jobCreationPayload);
      const { workorderId } = woResponse;
      jobCreationPayload.workorderId = workorderId;
      await autoIncomingCreationProcess(jobCreationPayload);
      await workflowTriggerProcess(jobCreationPayload);

      const msg = `Job creation process completed`;
      logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 12,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ status: true, message: msg });
    } catch (err) {
      const msg = `Job creation process failed`;
      const logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Failed',
        processStatusId: 21,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// construct payload for article workorder creation
const constructPayloadForArticleWOCreation = async item => {
  return new Promise(async (resolve, reject) => {
    const { jobFlowType, customerName, jobType } = item;
    try {
      // get journal information from customer and journal acronym
      const journalDetail = await getCustomerJournalDetail(item);
      if (journalDetail) {
        // change string to integer from journalDetails array
        journalDetail.customer = parseInt(journalDetail.customer);
        journalDetail.division = parseInt(journalDetail.division);
        journalDetail.subDivision = parseInt(journalDetail.subDivision);
        journalDetail.country = parseInt(journalDetail.country);
        journalDetail.duId = parseInt(journalDetail.duId);
        journalDetail.colours = parseInt(journalDetail.colours);
        journalDetail.softwares = parseInt(journalDetail.softwares);
        journalDetail.languages = parseInt(journalDetail.languages);
        journalDetail.CELevel = parseInt(journalDetail.CELevel);
        journalDetail.journalId = parseInt(journalDetail.journalId);
        journalDetail.custOrgMapId = parseInt(journalDetail.custOrgMapId);
        journalDetail.services = journalDetail.serviceId;
        journalDetail.custPrimaryContact = journalDetail.primaryContact;
        journalDetail.custSecondaryContact = journalDetail.secondaryContact;
        journalDetail.kamName = journalDetail.KAMContact;
        journalDetail.clientManager = journalDetail.CMContact;
        // create payload for workorder creation
        const jobTypeId = Object.keys(jobTypeObj).find(
          key => jobTypeObj[key] === jobType,
        );
        let sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE duid=$1 and customerid=$2`;
        const dmsInfo = await query(sql, [
          journalDetail.duId,
          journalDetail.customer,
        ]);
        const { dmsid } = dmsInfo.length ? dmsInfo[0] : '';
        if (dmsid) {
          const payload = {
            ...item,
            ...journalDetail,
            woType: jobFlowType,
            customerId: journalDetail.customer,
            userId: item.createdBy,
            doiNumber: item.title,
            jobId: item.name,
            jobTitle: item.title,
            jobTypeId: jobTypeId,
            jobTypeName: jobTypeObj[jobType],
            externalUsers: journalDetail.editorDetails,
            noOfChapters: 1,
            pageWidth: journalDetail.trimesizewidth,
            pageWidthUnit: journalDetail.trimesizewidthuom,
            pageHeight: journalDetail.trimesizeheight,
            pageHeightUnit: journalDetail.trimesizeheightuom,
            dmsId: dmsid,
          };
          resolve(payload);
        } else {
          throw new Error(
            `DMS type not mapping for the customer ${customerName}`,
          );
        }
      } else {
        throw new Error(
          `Journal details not found for the customer ${customerName}`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};
// ialt article workorder creation process
const artilceWoCreationProcess = async payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      let result = {};
      await transaction(async client => {
        result = await creation(payload, client);
      });
      const { data, message } = result;
      const msg =
        'Book chapter, service, or stage has been created successfully';
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 9,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ workorderId: data.workorderid, status: true, message: msg });
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message
          ? err.message
          : 'Book, chapter, service, or stage creation failed',
        message: 'Book, chapter, service, or stage creation failed',
        status: 'Success',
        processStatusId: 18,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// Auto incoming creation from API trigger based customer
export const autoIncomingCreationProcess = async payload => {
  return new Promise(async (resolve, reject) => {
    const { workorderId } = payload;
    try {
      const incomingPayload = await constructIncomingPayload(payload);
      const { workorderId, files, containerType, jobType, fileType } =
        incomingPayload;

      let sql = `select wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid, wo.isonlineissue
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid 
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId} order by wostageid limit 1`;
      // and updatedon is not null
      const woDetails = await query(sql);
      if (woDetails.length) {
        // files.forEach(async fi => {
        //   sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        //   const fileTypeRes = await query(sql);
        //   fi.filetypeid = fileTypeRes[0].filetypeid;
        //   fi.filetype = fileTypeRes[0].filetype;
        // });
        sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        const fileTypeRes = await query(sql);
        files[0].filetypeid = fileTypeRes[0].filetypeid;
        files[0].filetype = fileTypeRes[0].filetype;

        const workflow = {
          name: woDetails[0].wfname,
          id: woDetails[0].wfname_bpmnid,
          category: woDetails[0].wfcategory,
          enableListener: woDetails[0].wfconfig
            ? !!woDetails[0].wfconfig.enableListener
            : false,
          incoming: {
            fileTypes:
              woDetails[0].wfconfig &&
              woDetails[0].wfconfig.incoming &&
              woDetails[0].wfconfig.incoming.fileTypes
                ? woDetails[0].wfconfig.incoming.fileTypes
                : [],
          },
        };
        const service = {
          id: woDetails[0].serviceid,
          name: woDetails[0].servicename,
        };
        woDetails[0].workflow = workflow;
        woDetails[0].service = service;
        const payload = {
          woid: workorderId,
          service: {
            id: woDetails[0].serviceid,
            name: woDetails[0].servicename,
          },
          stageid: woDetails[0].wfstageid,
          receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
          duedate: new Date(woDetails[0].plannedenddate).toISOString(),
          updatedby: woDetails[0].updatedby,
          batchno: 0,
          valuesOfArray: files,
          totalArticleCount: 1,
          totalNonArticleCount: 0,
          totalCount: 0,
          totalChapterCount: null,
          fileNameISBN: '',
        };
        const response = await _saveChapter({ body: payload }, { res: {} });

        const fileCopyPayload = {
          resData: response.data,
          woDetails: woDetails[0],
          files,
          containerType,
          jobTypeName: jobTypeObj[jobType],
        };
        await fileCopyForElsevierJournalFromSignal(fileCopyPayload);

        for (let k = 0; k < files.length; k++) {
          const filteredObj = response.data.find(
            sublist => sublist.filename == files[k].filename,
          );
          files[k].woincomingfileid = files[k].woincomingfileid
            ? files[k].woincomingfileid
            : filteredObj.woincomingfileid;
        }
        await wmsWorkflowTrigger({ woDetails: woDetails[0], files });
        resolve({
          message: `Auto incoming success for ${workorderId}`,
          data: {
            stageId: woDetails[0].wfstageid,
            stageName: woDetails[0].stagename,
            iteration: 1,
          },
          status: true,
        });
      } else {
        reject({
          message: `Auto incoming failed due to wokflow details not found for ${workorderId}`,
        });
      }
    } catch (e) {
      reject({
        message: e.message
          ? e.message
          : `Auto incoming failed for ${workorderId}`,
        status: false,
      });
    }
  });
};
// create incoming payload for auto incoming creation
export const constructIncomingPayload = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const file = [
        {
          filetypeid: '',
          filetype: '',
          jobType: payload.jobType,
          filename: payload.fileName,
          extention: payload.extention,
          filepath: payload.sourcePath ? payload.sourcePath : null,
          fileuuid: '',
          duedate: payload.dueDate,
          mspages: payload.msPages,
          imagecount: 1,
          estimatedpages: 0,
          tablecount: 0,
          equationcount: 0,
          boxcount: 0,
          wordcount: 0,
          referencecount: 0,
          filesequence: 1,
        },
      ];
      const incomingPayload = {
        workorderId: payload.workorderId,
        containerType: payload.containerType,
        files: file,
        jobType: payload.jobType,
        fileType: payload.fileType,
      };
      resolve(incomingPayload);
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};

// get journal details from customer and journal acronym
const getCustomerJournalDetail = data => {
  const { customerName, journalAcronym } = data;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `select a.colorid::bigint as colours ,a.softwareid::bigint  as softwares ,a.languageid::bigint as languages ,a.celevelid::bigint as  "CELevel",a.printissn as "printISSN" ,
        b.divisionid::bigint as division ,b.subdivisionid::bigint as "subDivision",b.countryid::bigint as country ,b.customerid::bigint as  customer,d.duid as "duId",
        a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
        a.journalid as "journalId"
        from pp_mst_journal a
              JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
              JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
              JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid
              JOIN org_mst_customer e on e.customerid=b.customerid
              where a.isactive = 1 AND b.isactive = 1
              AND (LOWER(e.customername) = LOWER('${customerName}')
              or  LOWER(e.customershortname) = LOWER('${customerName}')
              )
              AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;
      const journalRes = await query(sql);
      if (journalRes.length) {
        sql = `select * from org_mst_customerorg_contact where custorgmapid=${journalRes[0].custOrgMapId}`;
        const journalContactRes = await query(sql);
        sql = ` select * from pp_mst_journal as journal join pp_mst_journal_contacts as journalcontact on
          journalcontact.journalid=journal.journalid where journal.journalacronym = '${journalAcronym}'`;
        const journalOtherContactRes = await query(sql);

        const journalInfo = journalRes[0];
        journalContactRes.forEach(list => {
          if (list.isprimary && list.contacttype === 'Customer') {
            journalInfo.primaryContact = list.custorgconmapid;
          } else if (!list.isprimary && list.contacttype === 'Customer') {
            journalInfo.secondaryContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'KAM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.KAMContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'CM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.CMContact = list.custorgconmapid;
          }
        });
        if (journalOtherContactRes.length) {
          let ecInfo = journalOtherContactRes.filter(
            list => list.designation == 10,
          );
          journalInfo.editorDetails = ecInfo.map(item => {
            return {
              name: item.name,
              role: '10',
              email: item.email,
              roleAcronym: 'EC',
            };
          });
        }

        resolve(journalInfo);
      } else {
        reject({
          message: `Journal details not found for the customer ${customerName} `,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const getSignalAuidtInfo = piiNumber => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM wms_mst_signal_audit WHERE pii ='${piiNumber}' and isactive = true order by signalauditid asc `;
      const response = await query(sql);
      if (response.length) {
        resolve(response[0]);
      } else {
        resolve(false);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getiAltSignalAuditHistoryService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { signalauditid } = payload;
      const sql = `select * from wms_mst_signal_audit_trns where signalauditid=${signalauditid}
      order by signalaudittrnsid desc`;
      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
export const checkChapterExists = (data, signalAckPayload) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { chapterName, isbn } = data;
      const { signalAuditId } = signalAckPayload;
      const sql = `SELECT ialt_books.bookname, wms_workorder.itemcode FROM wms_workorder
      JOIN ialt_books ON ialt_books.bookid = wms_workorder.bookid
      WHERE ialt_books.isbn='${isbn}' AND wms_workorder.itemcode='${chapterName}'`;

      const result = await query(sql);
      if (result.length) {
        let logHisPayload = {
          signalAuditId,
          request: data,
          response: `Chapter (${chapterName}) already exists for the title - ${isbn}`,
          message: 'Chapter already exists for the title',
          status: 'Failed',
          processStatusId: 28,
        };
        await ialtSignalLogHistory(logHisPayload);
        await ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
        resolve({
          status: false,
          message: `Chapter (${chapterName}) already exists for the title - ${isbn}`,
        });
      } else {
        resolve({ status: true, message: 'Chapter info not exists' });
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const rejectActionPreService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      resolve({
        status: true,
        message: 'Validated',
      });
    } catch (e) {
      reject(e);
    }
  });
};
export const rejectActionService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log(data, 'data');
      if (
        data &&
        data.files.length === 0 &&
        data.activityTriggerType === 'Dispatch'
      ) {
        let sql = `SELECT wfeventid,woincomingfileid FROM wms_workflow_eventlog WHERE workorderid=${data.workorderId} AND wfdefid=${data.wfdefId}`;
        const getEventId = await query(sql);

        if (getEventId.length) {
          data.files = getEventId.map(list => ({
            wfeventid: list.wfeventid,
            reject_comment: data.batchRejectComment,
            woincomingfileid: list.woincomingfileid,
          }));
        }
      }

      // Process all files using Promise.all
      await Promise.all(
        data.files.map(async file => {
          const eventDetailsData = {
            wfeventId: [file.wfeventid],
            status: 'Rejected',
            actionType: 'Manual',
            userId: data.userId,
            systemInfo: data.systemInfo,
            actualActivityCount: data.actualActivityCount + 1,
            usercomments: file.reject_comment,
          };

          // Start transaction for each file
          await transaction(async client => {
            // Update event log
            const eventData = {
              actionType: 'Manual',
              wfeventId: [file.wfeventid],
              userId: data.userId,
              status: 'Rejected',
            };
            await updateEventLog(eventData, client);

            // Update event log details
            await updateEventLogDetails(eventDetailsData, client);

            // Retrieve destination activity and unassign
            const sql = `
              SELECT wfeventid,userid FROM wms_workflow_eventlog
              WHERE wfdefid = (
                SELECT wfdefid FROM wms_workflowdefinition
                WHERE activityid = (
                  SELECT rejectactivity FROM wms_workflowdefinition
                  WHERE wfid = ${data.wfId} AND wfdefid = ${data.wfdefId}
                )
                AND stageid = ${data.stageId} AND wfid = ${data.wfId}
              ) AND woincomingfileid = ${file.woincomingfileid} order by wfeventid limit 1`;
            const destInfo = await query(sql);

            // Update destination event log status
            const unassignedEventData = {
              actionType: 'Manual',
              wfeventId: [destInfo?.[0]?.wfeventid],
              userId: destInfo?.[0]?.userid,
              status: 'YTS',
            };
            await updateEventLog(unassignedEventData, client);

            const unassignedEventDetailsData = {
              wfeventId: [destInfo?.[0]?.wfeventid],
              status: 'YTS',
              actionType: 'Manual',
              userId: destInfo?.[0]?.userid,
              systemInfo: data.systemInfo,
              actualActivityCount: data.actualActivityCount + 1,
              usercomments: file.reject_comment,
            };
            await updateEventLogDetails(unassignedEventDetailsData, client);
          });
        }),
      );

      // If all tasks complete successfully
      resolve({
        status: true,
        message: 'Task rejected successfully!',
      });
    } catch (error) {
      // If an error occurs, reject the promise
      reject({
        status: false,
        message: 'Task rejection failed!',
        error: error.message,
      });
    }
  });
};

export const iAltDirectDespatchService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let files = [];
      let data = await getXlReportData(payload, files);
      // data.arrayOfObjects = [
      //   {
      //     caption: 'No images found',
      //   },
      // ];
      const pth = await sendExcelFileIalt(data, payload);
      const result = await _downloadForIalt(pth);
      const filePath = result.data.path;

      const { piiNumber } = payload;
      let signalAuditInfo = await getSignalAuidtInfo(piiNumber);

      if (signalAuditInfo) {
        // const sql3 = `select * from public.wms_mst_signal_audit_trns where processstatusid =31  and signalauditid =${signalAuditInfo.signalauditid}`;

        // let checkStatus = await query(sql3);
        // if (checkStatus && checkStatus.length == 0) {
        const resOfUpload = await uploadFileToS3Service({
          filePath,
          signalAuditInfo,
        });
        const notifPayload = {
          ...resOfUpload,
          piiNumber: piiNumber,
          title: payload.chapterName,
        };
        const resOfUploadNotif = await altTextUploadNotification(
          notifPayload,
          signalAuditInfo,
        );

        const logHisPayload = {
          signalAuditInfo,
          signalAuditId: signalAuditInfo?.signalauditid,
          updateType: '',
          request: {},
          response: `Zero image xl sheet has been uploaded successfully  ${
            payload.userid || ''
          }`,
          message: 'Zero image xl sheet has been uploaded successfully',
          status: 'Success',
          processStatusId: 31,
        };
        await ialtSignalLogHistory(logHisPayload);

        const sql3 = `select chaptercount from ialt_books where bookid = ${payload.bookId} and isactive = true`;
        let countCheck = await query(sql3);

        const sql4 = `select * from wms_workorder where bookid = ${payload.bookId} and isactive = true and status ='Completed'`;
        let woCount = await query(sql4);

        if (countCheck?.[0].chapterCount - 1 == woCount.length) {
          const sql1 = `update ialt_books set status = 'Completed' where bookid = ${payload.bookId} and isactive = true`;
          await query(sql1);

          let updateActualEnddate = `UPDATE ialt_books SET actualenddate = CURRENT_TIMESTAMP  WHERE bookid = ${payload.bookId}`;
          await query(updateActualEnddate);
        }

        const sql = `update wms_workorder set status ='Completed' where workorderid = ${payload.workorderId} and isactive = true`;
        await query(sql);

        const sql1 = `update wms_workorder set updated_date = CURRENT_TIMESTAMP where workorderid = ${payload.workorderId} and isactive = true`;
        await query(sql1);

        resolve({
          isExist: true,
          message: 'Excel sheet uploaded successfully',
        });
        // } else {
        //   resolve({
        //     status: false,
        //     message: 'An Excel file has already been uploaded',
        //   });
        // }
      } else {
        reject({
          status: true,
          message: 'PII number is missing. Please provide the PII number',
        });
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const getMetaData = piiNumber => {
  return new Promise(async (resolve, reject) => {
    console.log(`Fetching metadata for PII number: ${piiNumber}`);
    const url = `${process.env.ELSEVIER_BASEURL}/metadata/pii/${piiNumber}?mode=full`;
    // const url = `https://uatnp.vtw-np.elsevier.com/search/?query=partof:http://vtw.elsevier.com/content/pii/B9780444519542000073&count=100`;
    try {
      const result = await service.ialtGet(url);
      console.log('Result from service.ialtGet:', result);

      if (Object.keys(result).length) {
        resolve(result);
      } else {
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      console.error('Error fetching metadata:', err);
      reject(err.message ? err.message : err);
    }
  });
};

export const readMetadataResult = result => {
  return new Promise((resolve, reject) => {
    try {
      const jobInfo = {};
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);

      const allStageSourceInfo = result['bam:hasGeneration'] || [];
      const stageSourceInfo = allStageSourceInfo.filter(
        item => item['bam:stage'] === 'accepted_manuscript',
      );

      if (!stageSourceInfo.length) {
        throw new Error('No accepted manuscript found in metadata');
      }

      const getMaxVersion = stageSourceInfo.reduce(
        (max, row) =>
          row['bam:generation'] > max['bam:generation'] ? row : max,
        stageSourceInfo[0],
      );

      const assetInfo = getMaxVersion['bam:hasAsset'];
      jobInfo.receivedStage = getMaxVersion['bam:stage'];
      jobInfo.title = result['prism:publicationName']
        .replaceAll(' ', '_')
        .replaceAll('–', '_');
      jobInfo.isbn = result['prism:isbn']
        ? result['prism:isbn'].replace(/-/g, '')
        : null;
      jobInfo.assetInfo = assetInfo;
      jobInfo.dueDate = moment(futureDate).format('YYYY-MM-DD hh:mm:ss');
      jobInfo.userId = 'System';

      resolve(jobInfo);
    } catch (error) {
      console.error('Error parsing metadata result:', error);
      reject(error);
    }
  });
};

export const getEgiMetaData = piiNumber => {
  return new Promise(async (resolve, reject) => {
    console.log(`Fetching metadata for PII number: ${piiNumber}`);
    const url = `${process.env.ELSEVIER_BASEURL}/search/?query=partof:http://vtw.elsevier.com/content/pii/${piiNumber}&count=100`;
    try {
      const result = await service.ialtGet(url, { Accept: 'application/json' });
      console.log('Result from service.ialtGet:', result);

      if (Object.keys(result).length) {
        resolve(result);
      } else {
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      console.error('Error fetching metadata:', err);
      reject(err.message ? err.message : err);
    }
  });
};

export const iAltJobCreationClientPIIService = data => {
  return new Promise(async (resolve, reject) => {
    let jobPayload = {};
    let generalInfo = {
      customerId: 14,
      duId: 94,
      wfId: 38,
      serviceId: 1,
      stageId: 54,
      stageIteration: 1,
      jobFlowType: 'ialt',
      jobFlowTypeId: 3,
      chapterInfo: {},
      bookInfo: {},
    };
    const piiNumber = data.piinumber.replace(/-/g, '').replace('.', '');

    try {
      if (!piiNumber) {
        throw new Error('PII Number Missing!');
      }

      //Job info need read here chapters

      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);

      const jobInfo = {
        serviceCallType: 'GenerateAltText',
        piiNumber: `${piiNumber}`,
        ackMsgInfo: {},
        chapterInfo: {
          name: data.chaptername,
          title: '',
          startDate: moment().format('YYYY-MM-DD hh:mm:ss'),
          endDate: moment(futureDate).format('YYYY-MM-DD hh:mm:ss'),
          userId: 'System',
        },
      };

      let logPayload = {
        ...generalInfo,
        ...jobInfo,
        response: data,
        message: 'Job request received',
        status: 'Success',
        processStatusId: 1,
      };
      const { data: signalAuditId } = await ialtSignalLogService(
        logPayload,
        'Insert',
      );

      const signalAckPayload = {
        signalAuditId,
        piiNumber: jobInfo.piiNumber,
        ackMsgInfo: jobInfo.ackMsgInfo,
        egiFilesInfo: jobInfo?.egiFilesInfo ? jobInfo?.egiFilesInfo : {},
      };

      try {
        //Need to confirm here if acknowledge present or not

        const result = await getMetaData(piiNumber);
        console.log(result, 'result');

        // jobInfo.chapterInfo.name = result?.['bam:hasAssetMetadata']?.[0]?.[
        //   'bam:filename'
        // ]
        //   ?.split('.')
        //   ?.slice(0, -1)
        //   .join('.');
        jobInfo.chapterInfo.title = result?.['dct:title'];

        if (!jobInfo.chapterInfo.name) {
          throw new Error('Chaptername mising!');
        }
        const egiFiles = await getEgiMetaData(piiNumber);
        console.log(egiFiles, 'egiFiles');
        const bookInfo = await readMetadataResult(result);

        let mainFiles = [];
        if (egiFiles.entries.entry && egiFiles.entries.entry.length > 0) {
          egiFiles.entries.entry.forEach(entry => {
            if (entry.links['link'] && entry.links['link'].length > 0) {
              const egiLinks = entry.links['link'].filter(link =>
                link.href.includes('/asset/egi/'),
              );
              egiLinks.forEach(item => {
                mainFiles.push({ path: item.href, isegiFile: true });
              });
            }
          });
        }

        bookInfo.assetInfo.flat().map(list => {
          mainFiles.push({
            path: list,
            isegiFile: false,
          });
        });
        bookInfo.assetInfo = mainFiles;
        jobPayload = {
          ...jobPayload,
          signalAuditId,
          ...generalInfo,
          ...jobInfo,
          bookInfo,
        };

        const statusCheck = await checkChapterExists(
          {
            isbn: bookInfo.isbn,
            chapterName: jobInfo.chapterInfo.name,
          },
          signalAckPayload,
        );

        if (
          statusCheck &&
          !statusCheck.status &&
          generalInfo.jobFlowType === 'ialt'
        ) {
          const regex = /^(?:[a-z]+\s?)*(?=:?)/gi;
          let subTitle = jobInfo.chapterInfo.title.match(regex)?.[0];
          if (subTitle) {
            jobInfo.chapterInfo.name = jobInfo.chapterInfo.name + subTitle;
          }
        }

        if (bookInfo.assetInfo.length > 0) {
          const response = await processAssetInfo(bookInfo.assetInfo);
          console.log(response, 'response');
        }

        // download source files
        const assetDownloadRes = await downloadAssetFile(
          bookInfo.assetInfo,
          signalAckPayload,
        );

        // get du , customer, stage, dms info
        generalInfo = await getGeneralInfo(generalInfo);
        // upload source file to blob
        let assetUploadRes = await assetUploadProcess({
          assetDownloadRes,
          signalAuditId,
          ...generalInfo,
          bookName: bookInfo.title,
          chapterName: jobInfo.chapterInfo.name,
        });

        const allFiles = assetUploadRes
          .filter(item => item !== undefined)
          .map(item => item.allPath);

        const originalFiles = assetUploadRes.filter(
          item => item && item.pathWithSAS !== '',
        );

        jobPayload = {
          ...jobPayload,
          originalFiles,
          allFiles,
        };
        const response = await iAltAutoJobCreationService(jobPayload);

        resolve(response);
      } catch (err) {
        logPayload = {
          signalAuditId,
          response: err.message,
          updateType: 'failed',
        };
        await ialtSignalLogService(logPayload, 'Update');
        throw new Error(err.message);
      }
    } catch (err) {
      // const mailPayload = {
      //   action: 'job_receive_common_failure',
      //   to: [],
      //   title: jobPayload?.bookInfo?.title
      //     ? jobPayload.bookInfo.title
      //     : 'Failed in initial process',
      //   chapterName: jobPayload.chapterInfo.name,
      //   stageName: jobPayload?.bookInfo?.stage ? jobPayload.bookInfo.stage : '',
      //   message: err.message ? err.message : err,
      // };
      // await sendMail(mailPayload);
      resolve(true);
      //   reject({ status: false, message: err.message ? err.message : err });
    }
  });
};

export const iAltManulWoFilesDownloadService = async (req, res) => {
  try {
    // const result = [
    //   "https://integraproductsasa.blob.core.windows.net/alt/dev/upload/Lighthouse03/lightHouseRef03/Files/Pdf/dda369d4-395b-4a66-99b9-770df7b74448.docx",
    //   "https://integraproductsasa.blob.core.windows.net/alt/dev/upload/Lighthouse03/lightHouseRef03/Files/Reference/2cba034e-cced-42fe-ab19-18c6aa234e93.docx",
    // ];

    const params = {
      chapterwms: req.body.chaptername,
      bookwms: req.body.bookname.replaceAll(' ', '_').replaceAll('–', '_'),
    };
    const queryString = new URLSearchParams(params).toString();
    const url = `${config.iAlt.base_url}${config.iAlt.uri.ialtManualWorkorderDownload}?${queryString}`;
    const result = await service.get(url);

    const zipFileName = `files_${Date.now()}.zip`;
    let tempFilePath = join(__filename, '../../../../');

    const zipFilePath = `${tempFilePath}upload/${zipFileName}`;

    // Create the ZIP file
    const output = fs.createWriteStream(zipFilePath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    archive.pipe(output);

    for (const file of result?.data) {
      const fileName = basename(file);
      try {
        const response = await axios({
          method: 'GET',
          url: file,
          responseType: 'stream',
        });
        archive.append(response.data, { name: fileName });
      } catch (error) {
        console.error(`Error fetching file: ${file}`, error.message);
        archive.append(`Error: File ${fileName} could not be downloaded.`, {
          name: `${fileName}.error.txt`,
        });
      }
    }

    await archive.finalize();

    // Wait for the archive to be fully written
    output.on('close', () => {
      res.download(zipFilePath, err => {
        if (err) {
          res.status(500).send('Error sending file');
        } else {
          // Delete the file after sending
          fs.unlink(zipFilePath, unlinkErr => {
            if (unlinkErr) {
            }
          });
        }
      });
    });

    output.on('error', err => {
      console.error('Error writing ZIP file:', err);
      res.status(500).send('Error creating ZIP file');
    });
  } catch (error) {
    console.error('Error in file download service:', error);
    res.status(500).send('Error fetching files');
  }
};

export const getEgiFileName = egiNumber => {
  return new Promise(async (resolve, reject) => {
    console.log(`Fetching metadata for PII number: ${egiNumber}`);
    const url = `${process.env.ELSEVIER_BASEURL}/metadata/egi/${egiNumber}?mode=full`;
    // const url = `https://uatnp.vtw-np.elsevier.com/search/?query=partof:http://vtw.elsevier.com/content/pii/B9780444519542000073&count=100`;
    try {
      const result = await service.ialtGet(url);
      console.log('Result from service.ialtGet:', result);

      if (Object.keys(result).length) {
        resolve(result);
      } else {
        throw new Error('Egi Metadata info not found');
      }
    } catch (err) {
      console.error('Error fetching egi metadata:', err);
      reject(err.message ? err.message : err);
    }
  });
};

export const processAssetInfo = (assetInfo, sourceType) => {
  return new Promise(async (resolve, reject) => {
    for (let i = 0; i < assetInfo.length; i++) {
      if (assetInfo[i].isegiFile) {
        const url = assetInfo[i].path;
        const parts = url.split('/');
        const name = parts[parts.length - 1].split('?')[0];

        try {
          const response = await getEgiFileName(name);
          assetInfo[i].filename = '';

          if (response?.['bam:hasAssetMetadata']) {
            const assetMetadata = response?.['bam:hasAssetMetadata']?.[0];
            //  const ucsLocation = assetMetadata?.['bam:ucsLocation']?.[0];
            let newFileName = assetMetadata?.['bam:filename'];
            //let newFileName = assetMetadata?.['bam:ucsLocation']?.[0];

            // const extension = newFileName.substring(
            //   newFileName.lastIndexOf('.') + 1,
            // );
            // if (ucsLocation) {
            //   const filenameWithExtension = ucsLocation.split('/').pop();

            //   sourceTypeName = filenameWithExtension.includes('.')
            //     ? filenameWithExtension.split('.').slice(0, -1).join('.')
            //     : filenameWithExtension + '.' + extension
            //     ? filenameWithExtension.includes('.')
            //       ? filenameWithExtension.split('.').slice(0, -1).join('.')
            //       : filenameWithExtension + '.' + extension
            //     : newFileName;
            //   // }
            // }
            assetInfo[i].filename = newFileName
              .normalize('NFD')
              .replace(/[\u0300-\u036f]/g, '')
              .replace(/['’]/gi, '')
              .replace(/[^a-z0-9\.]/gi, ' ')
              .replace(/\s+/gi, '_');
          } else {
            assetInfo[i].filename = response['bam:label'].replaceAll(' ', '.');
          }
          console.log(assetInfo[i].filename, 'filename');
        } catch (error) {
          console.error('Error fetching EGI file name:', error);
        }
      } else {
        // const verValue = assetInfo[i].path.split('ver=').pop();
        // const url = assetInfo[i].path;
        // const pattern = /pii\/(.*?)\?/;
        // const match = url.match(pattern);

        // if (match) {
        //   console.log(match[1]); // Output: B9780443273421000221
        // }
        assetInfo[i].filename = assetInfo[i].newFileName;
      }
    }
    resolve(assetInfo);
  });
};

export const iAltBookWiseReportGenerateService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log(payload, 'payload');

      const folderPathData = {
        type: 'ialt_book',
        duName: payload.duName,
        customerName: payload?.selectedData[0]?.customername,
        bookName: payload?.selectedData[0]?.bookname
          .replaceAll(' ', '_')
          .replaceAll('–', '_'),
        chapterName: '',
        stageName: 'AltTextGen',
      };
      let info;
      let bookBasePath = await getFolderStructureForIalt(folderPathData);

      for (let i = 0; i < payload.selectedData.length; i++) {
        info = payload?.selectedData[i];

        let payloadInfo = {
          duId: payload.duId,
          duName: payload.duName,
          workorderId: info?.workorderid,
          reportName: info?.isbn + '_' + info?.itemcode,
          isInternalReport: payload.isInternalReport,
          customerName: info?.customername
            .replaceAll(' ', '_')
            .replaceAll('–', '_'),
          bookName: info?.bookname,
          workorderId: info?.workorderid,
          chapterName: info?.itemcode,
          stageName: info?.stagename,
          bookBasePath: `${bookBasePath}OverallReport/${info?.itemcode
            .replaceAll(' ', '_')
            .replaceAll('–', '_')}/`,
          customerId: info.customerid,
          reportType: payload?.reportType,
          wfId: payload.wfId,
        };

        const files = await getAllImageIdByChapter(payloadInfo);
        let data = await getXlReportData(payloadInfo, files);
        const result = await sendExcelFileIalt(data, payloadInfo);
      }
      resolve({
        path: `${bookBasePath}OverallReport/`,
        fileName: payload?.selectedData[0]?.bookname
          .replaceAll(' ', '_')
          .replaceAll('–', '_'),
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const iAltDeleteJobAuditHistoryService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { pii } = payload;
      const sql = `UPDATE wms_mst_signal_audit_trns
      SET isactive = false
      WHERE signalauditid IN (
        SELECT signalauditid FROM wms_mst_signal_audit WHERE pii = $1 AND status = 'Failed'
      )`;
      await query(sql, [pii]);

      const sql1 = `UPDATE wms_mst_signal_audit
      SET isactive = false
      WHERE signalauditid IN (
        SELECT signalauditid FROM wms_mst_signal_audit WHERE pii = $1 AND status = 'Failed'
      )`;
      await query(sql1, [pii]);

      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const _getiAltPlaceholder = payload => {
  return new Promise(async (resolve, reject) => {
    const { workorderId } = payload;

    try {
      const sql = `select isbn,itemcode, title,wfid,books.customerid,books.bookname,workorder.otherfield->>'pii' as pii from wms_workorder as workorder join 
      ialt_books as books on workorder.bookid = books.bookid where workorderid = ${workorderId}`;

      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

export const getiAltFormattedName = (unFormattedName, placeHolders) => {
  const placeHolderkeys = Object.keys(placeHolders);
  let formattedName = unFormattedName;
  for (let i = 0; i < placeHolderkeys.length; i++) {
    const placeHolder = placeHolders[placeHolderkeys[i]]
      ? placeHolders[placeHolderkeys[i]]
      : `{{${placeHolderkeys[i]}}}`;
    formattedName = formattedName.replace(
      new RegExp(pattern.replace(/{{placeholder}}/, placeHolderkeys[i]), 'g'),
      placeHolder,
    );
  }
  return formattedName;
};

export const getSourceFilesUpdateQueue = payload => {
  return new Promise(async (resolve, reject) => {
    const { originalFiles } = payload;
    try {
      payload.files = [];
      let egiFiles = [];
      let referenceFiles = [];
      let imageFiles = [];
      let excelFiles = [];

      if (originalFiles && originalFiles.length > 0) {
        // Filter for isegiFile: true and get pathWithSAS
        egiFiles = originalFiles
          .filter(item => item.isegiFile)
          .map(item => item?.pathWithSAS?.path)
          .filter(path => path !== undefined);
        imageFiles = originalFiles
          .filter(item => item?.originalImageName)
          .map(item => ({
            originalImageName: item?.originalImageName,
            imageSASPath: item?.imageSASPath,
          }));
        excelFiles = originalFiles
          .filter(item => item?.isExcelFile)
          .map(item => ({
            path: item?.excelPath,
          }))
          .filter(path => path !== undefined);
        // Filter for isegiFile: false and get pathWithSAS

        referenceFiles = originalFiles
          .filter(item => !item.isegiFile)
          .map(item => item?.pathWithSAS?.path)
          .filter(path => path !== undefined);
      }
      payload.files = [];
      payload.originalFiles = [];
      let payloadArray = {};
      let url = '';
      if (payload.category === 'vtex') {
        url =
          config.iAlt.base_url +
          config.iAlt.uri.ialtUploadVtexFilesQueueSchedular;
        payloadArray = {
          ...payload,
          originalFiles:
            egiFiles && egiFiles.length > 0 ? egiFiles : referenceFiles,
          images: imageFiles,
          ReferenceFile: referenceFiles,
          reportdata: excelFiles[0].path,
        };
      } else {
        url =
          config.iAlt.base_url + config.iAlt.uri.ialtUploadFilesQueueSchedular;
        payloadArray = {
          ...payload,
          files: egiFiles && egiFiles.length > 0 ? egiFiles : referenceFiles,
          ReferenceFile: referenceFiles,
        };
      }
      // const url = `http://BCPINT-L043:3000/v1/ialtimage/uploadFilesforExtractionQueueSchedular`;
      const result = await service.post(url, [payloadArray]);
      resolve(result);
    } catch (error) {
      let resError;
      if (typeof error === 'object' && error !== null) {
        resError =
          error.message?.data?.message ??
          error.message ??
          'Source file upload to iAlt has failed';
      } else {
        resError = 'Source file upload to iAlt has failed';
      }

      reject({ status: false, message: resError });
    }
  });
};

export const getTimeEstimate = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // let imageCount = 34;
      // let workorderId = 6281;
      // let bookId =554;

      const { workorderId, bookId } = payload;
      let imageCount = payload.imageCount;
      // if (typeof imageCount !== 'number' || imageCount < 0 || imageCount == 0) {
      //   resolve(24);
      //   return;
      // }
      let customerName = await query(
        `select customerid from ialt_books where bookid = ${bookId} and isactive = true`,
      );
      let wfId = '';
      if (parseInt(customerName[0]?.customerid) == 142) {
        wfId = 162;
      } else {
        wfId = 38;
      }
      let condition = '';
      const needExtractionQuery = await query(
        `select otherfield ->>'needExtraction' as needextarction from wms_workorder where workorderid = ${workorderId} and isactive = true`,
      );
      if (
        needExtractionQuery[0].needextarction == 'false' ||
        needExtractionQuery[0].needextarction == false
      ) {
        condition = ` and DATE(completeddate) = CURRENT_DATE `;
      } else {
        condition = ` and DATE(createdon) = CURRENT_DATE `;
      }
      const imageCountQuery = `SELECT bookid, SUM(totalchaptercount) AS total_chapters
            FROM wms_workorder
            WHERE bookid = '${bookId}' and isactive = true 
            ${condition} 
            and wfid = '${wfId}'
            and status ='In Process'
            GROUP BY bookid;`;
      const imageCountResponse = await query(imageCountQuery);
      imageCount =
        imageCountResponse.length > 0
          ? imageCountResponse[0].total_chapters
          : 0;
      const timeEstimates = [
        { range: '0-30', days: 1, hours: 24 },
        { range: '31-100', days: 4, hours: 96 },
        { range: '101-300', days: 8, hours: 192 },
        { range: '301-500', days: 12, hours: 288 },
        { range: '501-1000', days: 20, hours: 480 },
        { range: '>1000', days: 30, hours: 720 },
      ];

      let result;

      if (imageCount >= 0 && imageCount <= 30) {
        result = timeEstimates[0]?.hours;
      } else if (imageCount >= 31 && imageCount <= 100) {
        result = timeEstimates[1]?.hours;
      } else if (imageCount >= 101 && imageCount <= 300) {
        result = timeEstimates[2]?.hours;
      } else if (imageCount >= 301 && imageCount <= 500) {
        result = timeEstimates[3]?.hours;
      } else if (imageCount >= 501 && imageCount <= 1000) {
        result = timeEstimates[4]?.hours;
      } else if (imageCount > 1000) {
        result = timeEstimates[5]?.hours;
      } else {
        result = null; // Handle unexpected cases
      }

      console.log(result, 'result');

      const startDate = await query(
        `select plannedstartdate from public.wms_workorder_stage where workorderid =${workorderId}`,
      );
      let formattedDate = await convertDateFormat(
        startDate?.[0]?.plannedstartdate,
      );

      let dueDate = await query(`SELECT * FROM 
      add_hours_exclude_weekends_and_holidays('${formattedDate}'::timestamp(0), ${result} ::integer)`);
      console.log(dueDate, 'duddate');

      let formattedDueDate = await convertDateFormat(
        dueDate?.[0]?.add_hours_exclude_weekends_and_holidays,
      );
      const sql = `UPDATE wms_workorder_stage 
            SET plannedenddate = '${formattedDueDate}' 
            WHERE workorderid IN (SELECT workorderid FROM wms_workorder WHERE bookid = '${bookId}' and isactive = true and wfid = '${wfId}'
            ${condition} 
            and status ='In Process')`;
      // const sql = `UPDATE wms_workorder_stage SET plannedenddate = '${formattedDueDate}' WHERE workorderid = ${workorderId}`;
      await query(sql);

      const sql2 = `SELECT MAX(wms_workorder_stage.plannedenddate) AS highestplannedenddate
        FROM ialt_books 
        JOIN wms_workorder ON ialt_books.bookid = wms_workorder.bookid
        JOIN wms_workorder_stage ON wms_workorder.workorderid = wms_workorder_stage.workorderid
        WHERE ialt_books.bookid = ${bookId} AND wms_workorder.wfid = '${wfId}'`;

      const maxEndDate = await query(sql2);

      let highestPlannedEnddate = await convertDateFormat(
        maxEndDate?.[0]?.highestplannedenddate,
      );

      const sql3 = `UPDATE ialt_books
        SET enddate = '${highestPlannedEnddate}'
        WHERE bookid = ${bookId};`;

      await query(sql3);

      const sql4 = `UPDATE ialt_books
            SET plannedcompleteddate = enddate
            WHERE enddate IS NOT NULL 
            AND plannedcompleteddate IS NOT NULL 
            AND DATE(enddate) > DATE(plannedcompleteddate) 
            AND isactive = true and bookid = ${bookId}`;
      await query(sql4);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const convertDateFormat = unFormattedDate => {
  return new Promise((resolve, reject) => {
    let dueDateWithOutHoliday = new Date(unFormattedDate);
    let formattedDueDate =
      dueDateWithOutHoliday.toISOString().replace('T', ' ').split('.')[0] +
      '.' +
      dueDateWithOutHoliday.getMilliseconds();
    resolve(formattedDueDate);
  });
};

export const iAltDirectDespatchWithExcelService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let files = [];
      // let data = await getXlReportData(payload, files);
      // data.arrayOfObjects = [
      //   {
      //     caption: 'No images found',
      //   },
      // ];
      // const pth = await sendExcelFileIalt(data, payload);
      // const result = await _download(payload.filePath);
      const filePath = payload.filePath;
      const userid = payload.userid;

      const { piiNumber } = payload;
      let signalAuditInfo = await getSignalAuidtInfo(piiNumber);

      if (signalAuditInfo) {
        // const sql3 = `select * from public.wms_mst_signal_audit_trns where processstatusid =22  and signalauditid =${signalAuditInfo.signalauditid}`;

        // let checkStatus = await query(sql3);
        // if (checkStatus && checkStatus.length == 0) {
        const resOfUpload = await uploadFileToS3Service({
          filePath,
          signalAuditInfo,
          userid,
        });
        const notifPayload = {
          ...resOfUpload,
          piiNumber: payload.piiNumber,
          title: payload.chapterName,
        };
        const resOfUploadNotif = await altTextUploadNotification(
          notifPayload,
          signalAuditInfo,
        );

        // const logHisPayload = {
        //   signalAuditInfo,
        //   signalAuditId: signalAuditInfo?.signalauditid,
        //   updateType: '',
        //   request: {},
        //   response: 'Final output has been uploaded successfully',
        //   message: 'Final output has been uploaded successfully',
        //   status: 'Success',
        //   processStatusId: 22,
        // };
        // await ialtSignalLogHistory(logHisPayload);

        const sql3 = `select chaptercount from ialt_books where bookid = ${payload.bookId} and isactive = true`;
        let countCheck = await query(sql3);

        const sql4 = `select * from wms_workorder where bookid = ${payload.bookId} and isactive = true and status ='Completed'`;
        let woCount = await query(sql4);

        if (countCheck?.[0].chapterCount - 1 == woCount.length) {
          const sql1 = `update ialt_books set status = 'Completed' where bookid = ${payload.bookId} and isactive = true`;
          await query(sql1);

          let updateActualEnddate = `UPDATE ialt_books SET actualenddate = CURRENT_TIMESTAMP  WHERE bookid = ${payload.bookId}`;
          await query(updateActualEnddate);
        }

        const sql = `update wms_workorder set status ='Completed' where workorderid = ${payload.workorderId} and isactive = true`;
        await query(sql);

        const sql1 = `update wms_workorder set updated_date = CURRENT_TIMESTAMP where workorderid = ${payload.workorderId} and isactive = true`;
        await query(sql1);

        resolve({
          isExist: true,
          message: 'Excel sheet uploaded successfully',
        });
        // } else {
        //   resolve({
        //     status: false,
        //     message: 'An Excel file has already been uploaded',
        //   });
        // }
      } else {
        reject({
          status: true,
          message: 'PII number is missing. Please provide the PII number',
        });
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const createComplexityService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      var sql;
      sql = `INSERT INTO 
    wms_ialt_mst_complexity (complexityid, complexity, isactive, customerid, wfid)
VALUES 
    (
      ${payload.complexityid},
      '${payload.complexity}',
      ${payload.status},
      ${payload.customername},
      ${payload.wfid}
    )
`;
      const complexityRes = await query(sql);
      resolve(complexityRes);
    } catch (error) {
      reject(error);
    }
  });
};

export const createPlaceholderService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      var sql;
      sql = `INSERT INTO 
    wms_ialt_mst_reportname
  (reportname_placeholder, type, isactive, customerid, wfid)
VALUES 
    (
      '${payload.placeholder}',
      '${payload.type}',
      ${payload.status},
      ${payload.customername},
      ${payload.wfid}
    )
      RETURNING reportnameid
`;
      const placeholRes = await query(sql);
      resolve(placeholRes);
    } catch (error) {
      reject(error);
    }
  });
};

export const getComplexityService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT complexity.complexityid, complexity.complexity, complexity.isactive, complexity.customerid, complexity.compid, customer.customername FROM 
    wms_ialt_mst_complexity AS complexity JOIN org_mst_customer AS customer ON complexity.customerid = customer.customerid WHERE 
    complexity.isactive = TRUE ORDER BY complexity.complexityid ASC;`;
      const complexityRes = await query(sql);
      resolve(complexityRes);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPlaceholderService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT placeholder.reportname_placeholder, placeholder.isactive, placeholder.customerid, placeholder.reportnameid, placeholder.type, customer.customername FROM 
    wms_ialt_mst_reportname AS placeholder JOIN org_mst_customer AS customer ON placeholder.customerid = customer.customerid WHERE 
    placeholder.isactive = TRUE ORDER BY placeholder.reportnameid ASC;`;
      const complexityRes = await query(sql);
      resolve(complexityRes);
    } catch (error) {
      reject(error);
    }
  });
};
export const updatePlaceholderService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      var sql;
      sql = `UPDATE 
    wms_ialt_mst_reportname
SET 
    complexity = '${payload.complexity}', 
    isactive = ${payload.status}, 
    complexityid = ${payload.complexityid},
    customerid = ${payload.customername}
WHERE 
    compid = ${payload.compid}
`;
      const complexityRes = await query(sql);
      resolve(complexityRes);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateComplexityService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      var sql;
      sql = `UPDATE 
    wms_ialt_mst_complexity
SET 
    complexity = '${payload.complexity}', 
    isactive = ${payload.status}, 
    complexityid = ${payload.complexityid},
    customerid = ${payload.customername}
WHERE 
    compid = ${payload.compid}
`;
      const complexityRes = await query(sql);
      resolve(complexityRes);
    } catch (error) {
      reject(error);
    }
  });
};

export const tandeIntegrationService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const updatedImages = await Promise.all(
        payload.images.map(async image => {
          let sasPath = null;
          let path = image.path;

          if (path.startsWith('/okm:root/'))
            path = path.replace('/okm:root/', '');
          if (path.startsWith('/okm_root/'))
            path = path.replace('/okm_root/', '');

          const { data } = await _downloadForIalt(path);
          sasPath = data;

          return {
            originalImageName: image.name,
            imageSASPath: sasPath.path,
          };
        }),
      );

      let metaDataSASPath = null;
      let metaDataPath = payload.metaDataFile;

      if (metaDataPath.startsWith('/okm:root/'))
        metaDataPath = metaDataPath.replace('/okm:root/', '');
      if (metaDataPath.startsWith('/okm_root/'))
        metaDataPath = metaDataPath.replace('/okm_root/', '');

      const { data: metaDataSAS } = await _downloadForIalt(metaDataPath);
      metaDataSASPath = metaDataSAS.path;

      const modifiedPayload = {
        ...payload,
        images: updatedImages,
        metadata: metaDataSASPath,
      };

      let updateSql = `UPDATE wms_workorder 
                 SET completeddate =  current_timestamp
                 WHERE workorderid = ${payload.workorderId} and isactive = true`;

      await query(updateSql);

      const url =
        config.iAlt.base_url + config.iAlt.uri.ialtTandEIntegrationService;
      const result = await service.post(url, [modifiedPayload]);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createiAltQueryService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      var sql;
      let active = payload.queryType == 'savequery' ? true : false;

      sql = `UPDATE 
    wms_workorder
SET 
ceddetails = '${payload.queryComment}', 
   isadvertavailable = ${active}
WHERE 
    workorderid = ${payload.workorderid}
`;
      const remarksRes = await query(sql);
      resolve(payload.queryComment);
    } catch (error) {
      reject(error);
    }
  });
};

export const queueTriggerLogService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { filterObj, pageNo, recordPerPage } = payload;

      // Calculate offset for pagination
      const offset = (pageNo - 1) * recordPerPage;

      let whereClause = '';
      const params = [];
      let paramIndex = 1;

      // Add PII filter if provided
      if (filterObj.pii && filterObj.pii.trim() !== '') {
        whereClause += whereClause ? ' AND ' : ' AND ';
        whereClause += `queuetriggerlog.pii ILIKE $${paramIndex}`;
        params.push(`%${filterObj.pii}%`);
        paramIndex++;
      }

      // Add status filter if provided
      if (filterObj.status && filterObj.status.trim() !== '') {
        whereClause += whereClause ? ' AND ' : ' AND ';
        whereClause += `queuetriggerlog.status = $${paramIndex}`;
        params.push(filterObj.status);
        paramIndex++;
      }

      // Count total records query
      const countSql = `
          SELECT COUNT(*) as total
          FROM queuetriggerlog
          WHERE queuetriggerlog.status = 'Failed'
          AND NOT EXISTS (
              SELECT 1 
              FROM wms_workorder w
              WHERE w.otherfield ->> 'pii' = queuetriggerlog.pii
              AND w.isactive = TRUE
          )
               ${whereClause}
      `;
      if (whereClause.trim().startsWith('WHERE')) {
        whereClause = whereClause.replace('WHERE', 'AND');
      }

      // Data query with pagination
      const dataSql = `
          SELECT
              queuetriggerlog.pii,
              queuetriggerlog.customer_id,
              org_mst_customer.customername AS customer_name,
              queuetriggerlog.log_type,
              queuetriggerlog.queue_name, 
              queuetriggerlog.message,
              queuetriggerlog.status,
              TO_CHAR(queuetriggerlog.timestamp, 'YYYY-MM-DD HH24:MI:SS') AS created_at
          FROM queuetriggerlog
          LEFT JOIN org_mst_customer 
              ON queuetriggerlog.customer_id = org_mst_customer.customerid
          WHERE queuetriggerlog.status = 'Failed'
          AND NOT EXISTS (
              SELECT 1 
              FROM wms_workorder w
              WHERE w.otherfield ->> 'pii' = queuetriggerlog.pii
              AND w.isactive = TRUE
          )
          ${whereClause}
          ORDER BY queuetriggerlog.timestamp DESC
      `;

      // Execute queries
      const totalResult = await query(countSql, params);
      const dataResult = await query(dataSql, params);

      resolve({
        status: 200,
        data: dataResult,
        total: parseInt(totalResult[0].total),
        message: 'Queue trigger logs fetched successfully',
      });
    } catch (error) {
      console.error('Error fetching queue trigger logs:', error?.message);
      reject({
        status: 500,
        message: 'Failed to fetch queue trigger logs',
        error: error.message,
      });
    }
  });
};

export const QueueTriggerLogger = async ({
  customer_id,
  pii,
  log_type,
  queue_name,
  message,
  status,
}) => {
  if (!customer_id || !pii || !log_type || !status || !queue_name) {
    throw new Error('Missing required fields');
  }

  const params = [status, message, log_type, queue_name, customer_id, pii];

  try {
    const [existingRecord] = await query(
      'SELECT 1 FROM queuetriggerlog WHERE pii = $1 LIMIT 1',
      [pii],
    );

    const sql = existingRecord
      ? `UPDATE queuetriggerlog SET status = $1, message = $2, log_type = $3, queue_name = $4, customer_id = $5 WHERE pii = $6`
      : `INSERT INTO queuetriggerlog (status, message, log_type, queue_name, customer_id, pii) VALUES ($1, $2, $3, $4, $5, $6)`;

    await query(sql, params);
    return { success: true };
  } catch (err) {
    throw new Error(`Queue logging failed: ${err.message}`);
  }
};

export const autoJobFailedRetriggerService = async ({ pii, customerId }) => {
  return new Promise(async (resolve, reject) => {
    const logStatus = async (status, message) => {
      await QueueTriggerLogger({
        customer_id: customerId,
        pii,
        log_type: 'AutoJob Failed Retrigger',
        queue_name: 'Service layer',
        message,
        status,
      });
    };

    try {
      // Check if PII exists in workorder
      const workorderCheck = await query(
        `SELECT workorderid FROM wms_workorder WHERE otherfield ->> 'pii' = $1 AND isactive = true`,
        [pii],
      );

      if (workorderCheck.length > 0) {
        reject({
          status: 400,
          success: false,
          message: 'PII already exists in system',
        });
      } else {
        const jsonData = await fetchJsonFromAzureBlob(pii);
        if (!jsonData) {
          await logStatus('Failed', 'No JSON file found in Azure Blob');
          resolve({
            status: 200,
            success: false,
            message: 'No JSON data found',
          });
        }

        // await logStatus('In process', 'Before service layer call');
        try {
          await altextGenerationJobService(jsonData);
          await logStatus('Completed', 'Service layer Completed');
        } catch (serviceError) {
          await logStatus(
            'Failed',
            `Service layer failed: ${serviceError.message}`,
          );
          throw serviceError;
        }
        await logStatus('Completed', 'Service layer Completed');

        resolve({
          status: 200,
          success: true,
          message: 'Re-trigger successful',
        });
      }
    } catch (error) {
      await logStatus('Failed', 'Error job creation failed : ' + error.message);
      reject({
        status: 500,
        message: 'Failed to Re-Trigger',
        error: error.message,
      });
    }
  });
};

export const acknowledgmentLogService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { filterObj, filterObj: { status } = {} } = payload;

      let whereClause = '';
      const params = [];
      let paramIndex = 1;

      whereClause += whereClause ? ' AND ' : ' WHERE ';
      whereClause += `status = 'Failed'`;

      // Add status filter if provided
      if (filterObj.status && status.trim() !== '') {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `acknowledgementtype = $${paramIndex}`;
        params.push(filterObj.status);
        paramIndex++;
      }

      // Count total records query
      const countSql = `
          SELECT COUNT(*) as total
          FROM ialtacknowledgementlog ${whereClause}
      `;

      // Data query with pagination
      const dataSql = `
          SELECT
              id as ackid,
              pii,
              signalauditid,
              stage,
              acknowledgementtype,
              error_message,
              status,
              created_at,
              updated_at,
              TO_CHAR(updated_at, 'YYYY-MM-DD HH24:MI:SS') AS updated_at
          FROM ialtacknowledgementlog
          ${whereClause}
          ORDER BY status
      `;

      // Execute queries
      const totalResult = await query(countSql, params);
      const dataResult = await query(dataSql, params);

      resolve({
        status: 200,
        data: dataResult,
        total: parseInt(totalResult[0].total),
        message: 'Acknowledgement logs fetched successfully',
      });
    } catch (error) {
      console.error('Error fetching Acknowledgement logs:', error?.message);
      reject({
        status: 500,
        message: 'Failed to fetch Acknowledgement logs :' + error?.message,
        error: error.message,
      });
    }
  });
};

export const ackFailedRetriggerService = async ({
  pii,
  signalauditid,
  acknowledgementtype,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (acknowledgementtype === 'RECEIVED_ACK') {
        const sql = ` select * from public.wms_mst_signal_audit_trns
                       where signalauditid ='${signalauditid}' and message = 'Job request received'`;

        const payloadInfo = await query(sql);

        if (
          payloadInfo &&
          payloadInfo.length > 0 &&
          'msg:to' in payloadInfo[0].response
        ) {
          const jobInfo = await readJobData(payloadInfo[0].response);

          const signalAckPayload = {
            piiNumber: pii,
            signalAuditId: signalauditid,
            ackMsgInfo: jobInfo.ackMsgInfo,
            isRetrigger: true,
          };

          await ialtJobReceivedAcknowledgeService(signalAckPayload);
        } else {
          console.log('no data found');
          return reject({
            status: 400,
            message: 'Invalid Signal Audit or Record Not Found.',
          });
        }
      } else if (acknowledgementtype === 'COMPLETED_ACK') {
        const sql = `SELECT * FROM wms_mst_signal_audit WHERE pii ='${pii}' and signalauditid='${signalauditid}' and isactive = true  order by signalauditid asc `;
        const auditResponse = await query(sql);

        if (auditResponse.length) {
          const { signalinfo, signalauditid, pii } = auditResponse[0];

          const ackPaylod = {
            signalAuditId: signalauditid,
            ackMsgInfo: signalinfo,
            piiNumber: pii,
            isRetrigger: true,
          };
          await ialtSuccessAcknowledgeService(
            ackPaylod,
            'FinishedSuccessfully',
          );
        } else {
          console.log('no data found');
          return reject({
            status: 400,
            message: 'Signal Audit Record Not Found.',
          });
        }
      } else {
        return reject({
          status: 400,
          message: 'Invalid acknowledgement type',
        });
      }

      resolve({
        status: 200,
        success: true,
        message: 'Acknowledgement Re-trigger successful',
      });
    } catch (error) {
      reject({
        status: 500,
        message: 'Failed to Re-Trigger Acknowledgement',
        error: error.message,
      });
    }
  });
};

export const getExportExcelDataForBook = async (payload, files) => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iAlt.base_url + config.iAlt.uri.getdataexportExcel;
      const payloadObject = {
        clientName: payload.clientName,
        data: files,
        isTitleReport: payload.isTitleReport,
      };
      const result = await service.post(url, payloadObject);

      resolve(result.data);
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

export const checkPIIExistsService = async piiList => {
  return new Promise(async (resolve, reject) => {
    try {
      if (!Array.isArray(piiList) || piiList.length === 0) {
        return reject({
          status: 400,
          message: 'Invalid piiList',
        });
      }

      const piiValues = piiList.map(item => item.pii);
      const placeholders = piiValues.map(i => `'${i}'`).join(',');
      const sqlQuery = `
        SELECT otherfield->>'pii' as pii
        FROM wms_workorder
        WHERE otherfield->>'pii' IN (${placeholders})
      `;

      const result = await query(sqlQuery);
      let existingPii = [];
      if (result && result.length) {
        existingPii = result.map(row => row.pii);
      }

      const notExists = piiList.filter(pii => !existingPii.includes(pii.pii));

      resolve({ exists: existingPii, notExists });
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

export const getiAltQueryDataService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `workorder.bookid IS NOT NULL`,
        `workorder.status != 'Completed'`,
        `workorder.ceddetails is not NULL`,
        `workorder.isadvertavailable = true`,
        `book.status != 'Completed'`,
      ];

      if (filterObj.fromDate && filterObj.toDate) {
        baseConditions.push(
          `wostage.updatedon BETWEEN '${filterObj.fromDate} 00:00:00'::timestamp AND '${filterObj.toDate} 23:59:59'::timestamp`,
        );
      }

      const customerCountQuery = `
        SELECT 
          to_char(wostage.updatedon, 'DD-MM-YYYY') as date, -- Date without time
          customer.customerid,
          customer.customername,
          COUNT(DISTINCT workorder.workorderid) as total_books,
          COUNT(DISTINCT workorder.workorderid) as total_chapters,
          SUM(workorder.totalchaptercount) as total_images
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE workorder.bookid IS NOT NULL
        AND book.isactive = true AND ${baseConditions.join(' AND ')}
        GROUP BY 
          to_char(wostage.updatedon, 'DD-MM-YYYY'), -- Match SELECT expression
          customer.customerid, 
          customer.customername
        ORDER BY 
          to_char(wostage.updatedon, 'DD-MM-YYYY') DESC, -- Align with GROUP BY
          customer.customername;`;

      const detailQuery = `
        SELECT 
          to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as date,
          customer.customerid,
          customer.customername,
          book.bookname,
          book.isbn,
          book.chaptercount as book_total_chapters,
          workorder.otherfield->>'pii' as pii_number,
          workorder.totalchaptercount as total_images,
          workorder.otherfield->>'egiCount' as received_image_count,
          workorder.itemcode as chapter_name,
          book.enddate as end_date,
          to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as received_date,
          to_char(workorder.updated_date, 'DD-MM-YYYY HH12:MI AM') as dispatch_date,
          to_char(book.plannedcompleteddate, 'DD-MM-YYYY HH12:MI AM') as plannedcompleteddate,
     to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as plannedstartdate,
     to_char(wostage.plannedenddate, 'DD-MM-YYYY') as duedate,
          workorder.workorderid,
          workorder.status,
               workorder.ceddetails as remarks
        FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
        WHERE workorder.bookid IS NOT NULL
        AND book.isactive = true AND ${baseConditions.join(' AND ')}
        ORDER BY wostage.updatedon DESC NULLS LAST, 
          customer.customername`;

      const totalCountQuery = `
        SELECT COUNT(*) as total 
        FROM wms_workorder workorder
        INNER JOIN ialt_books book ON book.bookid = workorder.bookid 
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
        left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        WHERE ${baseConditions.join(' AND ')}`;

      const [customerCounts, details, totalCount] = await Promise.all([
        query(customerCountQuery, []),
        query(detailQuery, []),
        query(totalCountQuery, []),
      ]);

      const count = parseInt(totalCount[0]?.total || 0);

      resolve({
        status: true,
        data: {
          summary: customerCounts,
          details: details,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltDispatchDataList:', error);
      reject(error);
    }
  });
};

export const getiAltJobsOverallQueryReport = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, wfid, filterObj, pageNo = 1, recordPerPage = 10 } = payload;

      let baseConditions = [
        `workorder.duid = ${duId}`,
        // `workorder.wfid = ${wfid}`,
        `workorder.isactive = true`,
        `workorder.bookid IS NOT NULL`,
        `workorder.status != 'Completed'`,
        `workorder.ceddetails is not NULL`,
        `workorder.isadvertavailable = true`,
        `book.status != 'Completed'`,
      ];

      // Overall Summary Query
      const overallSummaryQuery = `
   SELECT 
     COUNT(DISTINCT workorder.workorderid) as total_chapters,
     COUNT(DISTINCT workorder.bookid) as total_books,
     SUM(workorder.totalchaptercount) as total_images,
     COUNT(DISTINCT customer.customerid) as total_customers
   FROM wms_workorder workorder 
   INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
   WHERE ${baseConditions.join(' AND ')} AND book.isactive = true`;

      const customerSummaryQuery = `
   SELECT 
     customer.customerid,
     customer.customername,
     COUNT(DISTINCT workorder.workorderid) as total_chapters,
     COUNT(DISTINCT workorder.bookid) as total_books,
     SUM(workorder.totalchaptercount) as total_images
   FROM wms_workorder workorder 
   INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
   WHERE ${baseConditions.join(' AND ')} AND book.isactive = true
   GROUP BY 
     customer.customerid, 
     customer.customername
   ORDER BY customer.customername`;

      // Detailed Records Query
      const detailQuery = `
   SELECT 
     customer.customerid,
     customer.customername,
     book.bookname,
     book.isbn,
     book.chaptercount as book_total_chapters,
     workorder.otherfield->>'pii' as pii_number,
     workorder.totalchaptercount as total_images,
     workorder.otherfield->>'egiCount' as received_image_count,
     workorder.itemcode as chapter_name,
     book.enddate as end_date,
     to_char(wostage.updatedon, 'DD-MM-YYYY HH12:MI AM') as received_date,
     to_char(workorder.updated_date, 'DD-MM-YYYY HH12:MI AM') as dispatch_date,
     to_char(wostage.plannedstartdate, 'DD-MM-YYYY') as plannedstartdate,
     to_char(book.plannedcompleteddate, 'DD-MM-YYYY HH12:MI AM') as plannedcompleteddate,
      to_char(wostage.plannedenddate, 'DD-MM-YYYY') as duedate,
     workorder.workorderid,
     workorder.status,
     workorder.ceddetails as remarks
   FROM wms_workorder workorder 
   INNER JOIN ialt_books book ON workorder.bookid = book.bookid 
   INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
   LEFT JOIN org_mst_customer customer ON customer.customerid = workorder.customerid
   WHERE ${baseConditions.join(' AND ')} AND book.isactive = true
   ORDER BY workorder.updated_date DESC NULLS LAST, 
     customer.customername
   LIMIT ${recordPerPage} 
   OFFSET ${(pageNo - 1) * recordPerPage}`;

      const totalCountQuery = `
   SELECT COUNT(*) as total 
   FROM wms_workorder workorder 
        INNER JOIN ialt_books book ON book.bookid = workorder.bookid
        left join wms_workorder_service as woservice on woservice.workorderid = workorder.workorderid
        INNER JOIN wms_workorder_stage wostage ON wostage.workorderid = workorder.workorderid
   WHERE ${baseConditions.join(' AND ')}`;

      const [overallSummary, customerSummary, details, totalCount] =
        await Promise.all([
          query(overallSummaryQuery),
          query(customerSummaryQuery),
          query(detailQuery),
          query(totalCountQuery),
        ]);

      const count = parseInt(totalCount[0]?.total || 0);

      resolve({
        status: true,
        data: {
          overall_summary: overallSummary[0],
          customer_summary: customerSummary,
          details: details,
        },
        total: count,
        pageNo,
        recordPerPage,
        numOfPages: Math.ceil(count / recordPerPage),
      });
    } catch (error) {
      console.error('Error in getiAltJobsOverallYTSReport:', error);
      reject({
        status: false,
        message:
          error.message || 'An error occurred while generating the report',
        error: error,
      });
    }
  });
};

// new query to update the status of workorder and book

// get task list client side
export const getiAltTaskListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, filterObj, searchText, roleId } = payload;
      let status = [];
      let condition = `isbookactive=true AND ischapteractive=true AND `;
      let activitystatus = '';
      let activityid = '';
      let bookassignedby = '';
      let eventlogUserid = '';

      if (payload.type === 'My Task') {
        if (parseInt(roleId) == 1) {
          condition += `activitystatus in ('Work in progress', 'Unassigned', 'YTS') AND activityid=370`;
          activitystatus = `wms_workflow_eventlog.activitystatus in ('Work in progress', 'Unassigned', 'YTS')`;
          activityid = `wms_workflowdefinition.activityid = 370`;
        } else if (parseInt(roleId) == 2) {
          condition += `activitystatus in ('Unassigned', 'YTS', 'Work in progress') AND activityid = 369 AND bookassignedby='${userId}'`;
          activitystatus = `wms_workflow_eventlog.activitystatus in ('Work in progress', 'Unassigned', 'YTS')`;
          activityid = `wms_workflowdefinition.activityid = 369`;
          bookassignedby = ` AND ialt_books.assignedby='${userId}'`;
        } else if (parseInt(roleId) == 55) {
          condition += `activitystatus in ('Unassigned', 'YTS', 'Work in progress') AND activityid = 560 AND userid='${userId}'`;
          activitystatus = `wms_workflow_eventlog.activitystatus in ('Unassigned', 'YTS', 'Work in progress')`;
          activityid = `wms_workflowdefinition.activityid = 560`;
          eventlogUserid = ` AND wms_workflow_eventlog.userid='${userId}'`;
        } else {
          condition += `activitystatus in ('YTS', 'Work in progress', 'Unassigned') AND activityid != 560 AND userid='${userId}'`;
          activitystatus = `wms_workflow_eventlog.activitystatus in ('YTS', 'Work in progress', 'Unassigned')`;
          activityid = `wms_workflowdefinition.activityid != 560`;
          eventlogUserid = ` AND wms_workflow_eventlog.userid='${userId}'`;
        }
      } else if (payload.type === 'Assigned') {
        condition += `activitystatus in ('YTS')`;
        activitystatus = `wms_workflow_eventlog.activitystatus = 'YTS'`;
      } else {
        condition += `activitystatus in ('${payload.type}')`;
        activitystatus = `wms_workflow_eventlog.activitystatus in ('${payload.type}')`;
      }
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);
      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${index == 0 ? ' AND' : ''} ${key} = ${
              filterObj[key]
            }  ${arrayFilter.length - 1 != index ? 'AND' : ''} `;
          }
        });
      }
      if (searchText) {
        if (roleId == 1) {
          condition += ` AND LOWER(itemcode) LIKE '%${searchText.toLowerCase()}%'`;
        } else {
          condition += ` AND LOWER(filename) LIKE '%${searchText.toLowerCase()}%'`;
        }
      }
      payload.status = status;
      payload.condition = condition;
      payload.filterObj = filterObj;

      const queryStart = performance.now();

      const response = await getRecords(
        payload,
        activitystatus,
        activityid,
        bookassignedby,
        eventlogUserid,
      );
      const queryEnd = performance.now();
      const queryTime = (queryEnd - queryStart).toFixed(2);
      console.log('queryTime:', queryTime, 'ms');

      let finalResponse = [];
      let iAltAPITime = '0.00';

      if (roleId != 1) {
        if (response.data.length) {
          const files = response.data.map(item => {
            return {
              id: item.fileuuid,
            };
          });

          const iAltStart = performance.now();
          const getImgServices = await getImageClassificationService(files);
          const iAltEnd = performance.now();
          iAltAPITime = (iAltEnd - iAltStart).toFixed(2);
          console.log('iAltAPITime:', iAltAPITime, 'ms');

          if (getImgServices.data) {
            response.data.forEach((item, index) => {
              const sItem = getImgServices.data[index];
              if (item.fileuuid === sItem._id) {
                finalResponse.push({ ...item, ...sItem });
              }
            });
          }
        }
      } else {
        finalResponse = response.data;
      }
      resolve({
        ...response,
        data: finalResponse,
        responseTime: {
          query: `${queryTime} ms`,
          iAltAPI: `${iAltAPITime} ms`,
        },
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const getRecords = (
  payload,
  activitystatus,
  activityid,
  bookassignedby,
  eventlogUserid,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide, status, roleId, userId } = payload;
      let { condition } = payload;

      if (!isServerSide) {
        const script = `${ialt_tasklist} WHERE chapterstatus  <> 'Completed' AND ${condition} `;
        const response = await query(script, [status]);
        resolve(response);
      } else {
        let sql = '';
        if (roleId == 1) {
          sql = ialt_tasklist_fun(
            activitystatus,
            activityid,
            bookassignedby,
            eventlogUserid,
          );
        } else if (roleId == 2) {
          sql = ialt_tasklist_query_fun(
            activitystatus,
            activityid,
            bookassignedby,
            eventlogUserid,
          );
        } else {
          sql = ialt_tasklist_query_fun(
            activitystatus,
            activityid,
            bookassignedby,
            eventlogUserid,
          );
        }
        const response = await query(sql);

        if (response && response.length > 0) {
          const sql2 = `select isother_user from wms_user where userid='${userId}'`;

          const res = await query(sql2);

          response.map(list => {
            list.isother_user = res[0]?.isother_user;
          });
        }

        resolve({
          status: true,
          data: response,
          total: response.length,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};
