import Joi from 'joi';

export const aprRejeopenreqSchema = Joi.object({
  requestId: Joi.number().required(),
  modalType: Joi.string().required(),
  reqType: Joi.string().required(),
  appraisalId: Joi.number().required(),
  userid: Joi.string().required(),
  comment: Joi.string().required(),
  roleId: Joi.string().required(),
});

export const getReopenReqListSchema = Joi.object({
  typeId: Joi.string().allow('').required(),
  roleId: Joi.string().required(),
  userId: Joi.string().allow('').required(),
  searchText: Joi.string().allow('').required(),
});

export const getAttachmentInfoSchema = Joi.object({
  kra_itemkey: Joi.string().required(),
});

export const insAttachmentInfoSchema = Joi.object({
  kra_itemkey: Joi.string().required(),
  type: Joi.string().required(),
  fileName: Joi.string().required(),
  path: Joi.string().required(),
  empCode: Joi.string().required(),
});

export const getiAspireFolderPathSchema = Joi.object({
  quarter: Joi.string().required(),
  empCode: Joi.string().required(),
  version: Joi.number().allow(null),
  type: Joi.string().required(),
});

export const deleteAttachmentSchema = Joi.object({
  kra_itemkey: Joi.string().allow(''),
  kra_attachmentid: Joi.number().allow(null),
});
