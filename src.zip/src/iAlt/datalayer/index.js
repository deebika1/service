/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies

import { query, transaction } from '../../database/postgres.js';
import { ReStructureFileConfig } from '../../modules/utils/fileValidation/validate.js';
import { convertDateFormat, getTimeEstimate } from '../service/index.js';

// export const createEventLog = payload => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const {
//         ialtWorkorderId,
//         ialtWfActivitymapId,
//         stageId,
//         activityId,
//         userId,
//         skillId,
//         activityinterationcount,
//       } = payload;
//       const sql = `INSERT INTO public.wms_userrole(ialtworkorderid,ialtwfactivitymapid,stageid,activityid,userid,skillid,activityinterationcount,status)
//       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING ialtwfeventid`;
//       const response = await query(sql, [
//         ialtWorkorderId,
//         ialtWfActivitymapId,
//         stageId,
//         activityId,
//         userId,
//         skillId,
//         activityinterationcount,
//         'Unassigned',
//       ]);
//       resolve(response.length ? response[0].ialtwfeventid : '');
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

// export const getFirstActivityId = payload => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const { ialtWorkorderId, stageId } = payload;
//       const sql = `SELECT activityid, ialt_workflow_activitymap.sequence FROM ialt_workorder
//       JOIN ialt_workflow_activitymap ON ialt_workflow_activitymap.ialtwfid = ialt_workorder.ialtwfid
//       JOIN ialt_workflow_stagemap ON ialt_workflow_stagemap.ialtwfstagemapid = ialt_workflow_activitymap.ialtwfstagemapid
//       WHERE ialtworkorderid=$1 and stageid=$2 and activityid not in (SELECT activityid FROM ialt_workflow_eventlog WHERE ialtworkorderid=$3 )
//       order by sequence limit 1 `;
//       const response = await query(sql, [
//         ialtWorkorderId,
//         stageId,
//         ialtWorkorderId,
//       ]);
//       if (response.length) {
//         resolve(response[0].activityid);
//       } else {
//         resolve('');
//         // reject('Workflow activity information not found');
//       }
//     } catch (e) {
//       reject(e);
//     }
//   });
// };

export const getFirstActivityId = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfId, stageId } = payload;
      const sql = `SELECT activityid FROM wms_workflowdefinition 
      WHERE wfid=$1 and stageid=$2 order by sequence limit 1 `;
      const response = await query(sql, [wfId, stageId]);
      if (response.length) {
        resolve(response[0].activityid);
      } else {
        reject('Workflow activity information not found');
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getIaltWorkflowInfo = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { ialtWorkorderId, stageId, activityId } = payload;
      const sql = `SELECT ialtworkorderid,ialtwfactivitymapid,ialt_workflow_stagemap.ialtwfstagemapid,stageid,activityid,ialt_workflow_activitymap.sequence, activitytype, activityflow FROM ialt_workorder 
      JOIN ialt_workflow_activitymap ON ialt_workflow_activitymap.wfid = ialt_workorder.wfid
      JOIN ialt_workflow_stagemap ON ialt_workflow_stagemap.ialtwfstagemapid = ialt_workflow_activitymap.ialtwfstagemapid
      WHERE ialtworkorderid=$1 and stageid=$2 and activityid=$3`;
      const response = await query(sql, [ialtWorkorderId, stageId, activityId]);
      if (response.length) {
        resolve(response[0]);
      } else {
        reject('Workorder information not found');
      }
    } catch (e) {
      reject(e);
    }
  });
};

// get task list
export const getiAltTaskListScript = () => {
  return new Promise(resolve => {
    const script = `SELECT * FROM ialt_tasklist WHERE activitystatus= ANY($1)`;
    resolve(script);
  });
};
// get chapter list
export const getChapterListScript = () => {
  return new Promise(resolve => {
    const script = `select woincomingfileid, filename, filepath, fileuuid,filesize,wms_workorder_incomingfiledetails.woincomingid,pagenumber,fignumber, istriggered from wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    where woid=$1 order by woincomingfileid asc`;
    resolve(script);
  });
};
// get chapter list by type
export const getChapterListByTypeScript = payload => {
  return new Promise(resolve => {
    const { assetType } = payload;
    let condition = '';
    if (assetType) {
      condition = ` and assettype='${assetType}'`;
    }
    const script = `select woincomingfileid, filename, filepath, fileuuid,filesize,wms_workorder_incomingfiledetails.woincomingid,pagenumber,fignumber, istriggered from wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    where woid=$1 and ( istriggered IS FALSE OR istriggered IS NULL) ${condition} order by woincomingfileid asc`;
    resolve(script);
  });
};

// file transaction entry insert
export const fileTransactionScript = () => {
  return new Promise(resolve => {
    const script = `INSERT INTO public.wms_workflow_eventlog_file_details(
      woincomingfilemapid, status, timestamp)
      VALUES ($1, $2, current_timestamp)`;
    resolve(script);
  });
};

/// ////////////////////////////
export const getPayloadInfo = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // define key strucre
      payload = {
        ...payload,
        type: null,
        service: {
          name: null,
          id: null,
        },
        customer: {
          name: null,
          id: null,
        },
        du: {
          name: null,
          id: null,
        },
        job: {
          name: null,
          id: null,
        },
        stage: {
          name: null,
          id: null,
          iteration: null,
        },
        activity: {
          name: null,
          id: null,
          iteration: null,
          activityalias: null,
          actualIteration: null,
        },
        date: {
          plannedStart: null,
          plannedEnd: null,
          orderMail: null,
        },
        skillId: null,
        wf: {
          defId: null,
          incomingFlows: [],
          defConfig: null,
          config: null,
          fileConfig: null,
          instanceType: null,
          category: null,
          eventId: null,
          wfId: null,
          activityModelTypeFlow: null,
        },
        isCTActivity: false,
        isDespatchActivity: false,
        topicName: null,
        woType: null,
        isDirectFirstProof: false,
        logoid: null,
        nextActivityId: null,
      };
      const { workorderId, stageId, stageIteration, serviceId, actionType } =
        payload;
      const activityId =
        actionType === 'trigger'
          ? await getFirstActivityId(payload)
          : payload.activityId;
      payload.activityId = activityId;
      if (workorderId && stageId && stageIteration && activityId) {
        const wfDetailsData = await getWfDetails(payload);

        if (wfDetailsData.length) {
          const {
            skillid,
            stagename,
            activityname,
            duname,
            duid,
            jobname,
            jobid,
            servicename,
            wfdefid,
            customerid,
            customername,
            wfcategory,
            instancetype,
            isdespatchactivity,
            iscompletiontriggeractivity,
            plannedstartdate,
            plannedenddate,
            ordermaildate,
            isbookcompleted,
            wfdefconfig,
            wfconfig,
            incomingflows,
            fileconfig,
            wfid,
            activityalias,
            wotype,
            isfirstproof,
            logostatus,
            activitymodeltypeflow,
            pubflowconfig,
            issuemstid,
            ismscompleted,
            activitytype,
            nextactivityid,
            assignedby,
          } = wfDetailsData[0];
          payload.type = activitytype;
          payload.skillId = skillid;
          payload.stage.name = stagename;
          payload.stage.id = stageId;
          payload.stage.iteration = stageIteration;
          payload.activity.name = activityname;
          payload.activity.id = activityId;
          payload.isCTActivity = !!iscompletiontriggeractivity;
          payload.isDespatchActivity = !!isdespatchactivity;
          payload.du.id = duid;
          payload.du.name = duname;
          payload.customer.id = customerid;
          payload.customer.name = customername;
          payload.service.name = servicename;
          payload.service.id = serviceId;
          payload.wfdefId = wfdefid;
          payload.wf.wfId = wfid;
          payload.wf.instanceType = instancetype;
          payload.wf.defConfig = wfdefconfig;
          payload.wf.fileConfig = fileconfig;
          payload.wf.incomingFlows = incomingflows || [];
          payload.wf.config = wfconfig;
          payload.wf.defId = wfdefid;
          payload.wf.category = wfcategory;
          payload.wf.activityModelTypeFlow = activitymodeltypeflow;
          payload.date.plannedStart = plannedstartdate;
          payload.date.plannedEnd = plannedenddate;
          payload.date.orderMail = ordermaildate;
          payload.isBookCompleted = isbookcompleted;
          payload.job.id = jobid;
          payload.job.name = jobname;
          payload.activity.activityalias = activityalias;
          payload.woType = wotype;
          payload.nextActivityId = nextactivityid;
          payload.isDirectFirstProof = isfirstproof;
          payload.logoid = logostatus;
          payload.pubconfig = pubflowconfig || [];
          payload.IssuemstId = issuemstid || [];
          payload.ismscompleted = ismscompleted || [];
          payload.assignedby = assignedby;
          // get workflow eventlog details
          const eventLogsData = await fetchWfDetails(payload);
          if (eventLogsData.length) {
            const filteredActivityData = eventLogsData.filter(
              data => data.activityid == payload.activity.id,
            );
            if (filteredActivityData.length) {
              payload.activity.iteration = parseInt(
                filteredActivityData[0].activityiterationcount,
              );
              payload.activity.actualIteration =
                parseInt(filteredActivityData[0].actualactivitycount) + 1;
            } else {
              payload.activity.iteration = 1;
              payload.activity.actualIteration = 1;
            }
          } else {
            payload.activity.iteration = 1;
            payload.activity.actualIteration = 1;
          }
          payload.filesInfo = [];
          resolve(payload);
        } else {
          reject('workflow definition was not updated');
        }
      } else {
        reject(
          `Mandatory fields (workorderId / stageId / stageIteration / activityId  ) are missing`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getWfDetails = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, serviceId, stageId, activityId, stageIteration } =
        payload;
      const sql = `SELECT * FROM public.wms_workflow_details
    where workorderid = $1 and serviceid = $2 and stageid = $3 and activityid = $4 and stageiterationcount = $5`;

      const wfDetails = await query(sql, [
        workorderId,
        serviceId,
        stageId,
        activityId,
        stageIteration,
      ]);
      wfDetails.forEach(item => {
        item.fileconfig = ReStructureFileConfig(item.fileconfig);
      });
      resolve(wfDetails);
    } catch (e) {
      reject(e);
    }
  });
};
export const fetchWfDetails = async payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, serviceId, stage } = payloadCollection;
      const sql = `SELECT wms_workflow_eventlog.*, wms_workflowdefinition.stageid, wms_workflowdefinition.activityid FROM public.wms_workflow_eventlog
      join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
      where activitystatus <> 'Unassigned' and workorderid = $1 and stageid = $2 and stageiterationcount = $3 and serviceid= $4 and activitystatus not in ('Inprocess','Error') order by wfeventid desc`;
      try {
        const eventLogsData = await query(sql, [
          workorderId,
          stage.id,
          stage.iteration,
          serviceId,
        ]);
        resolve(eventLogsData);
      } catch (e) {
        reject(e);
      }
    } catch (e) {
      reject(e);
    }
  });
};

// create event log
export const createEventLog = (data, client) => {
  const {
    workOrderId,
    wfdefId,
    skillId,
    parentActivityInstance,
    activityInstanceId,
    taskInstanceId,
    stage,
    activity,
    fileId,
    service,
    payload,
  } = data;
  return new Promise(async (resolve, reject) => {
    try {
      if (workOrderId == null || wfdefId == null) {
        reject({
          message: `Input error workOrderId : ${workOrderId} , wfdefId : ${wfdefId}`,
        });
      } else {
        const sql = `select * from public.create_event_log($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;
        const { rows } = await client.query(sql, [
          workOrderId,
          wfdefId,
          parentActivityInstance,
          activityInstanceId,
          taskInstanceId,
          stage.iteration,
          activity.iteration,
          fileId,
          service.id,
          JSON.stringify(payload),
          skillId,
          activity.actualIteration,
        ]);
        resolve(rows.length ? rows[0].wfevent_id : null);
      }
    } catch (e) {
      reject(e);
    }
  });
};
// update event log
export const updateEventLog = (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, status, wfeventId, actionType } = data;
      if (actionType == 'Auto') {
        const sql = `UPDATE public.wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE wfeventid =$3 `;
        if (client) {
          await client.query(sql, [userId || 'System', status, wfeventId]);
        } else {
          await query(sql, [userId || 'System', status, wfeventId]);
        }
      } else {
        const sql = `UPDATE public.wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE wfeventid =ANY($3) `;
        if (client) {
          await client.query(sql, [userId || 'System', status, wfeventId]);
        } else {
          await query(sql, [userId || 'System', status, wfeventId]);
        }
      }
      resolve(wfeventId);
    } catch (e) {
      reject(e);
    }
  });
};
// update event log details
export const updateEventLogDetails = (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        wfeventId,
        status,
        actionType,
        userId,
        systemInfo,
        actualActivityCount,
      } = data;
      let sql = ``;
      if (actionType == 'Auto') {
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, actualactivitycount) VALUES ($1, $2, current_timestamp, $3, $4)`;
        if (client) {
          await client.query(sql, [
            wfeventId,
            status,
            userId,
            actualActivityCount,
          ]);
        } else {
          await query(sql, [wfeventId, status, userId, actualActivityCount]);
        }
      } else {
        const val = [];
        wfeventId.forEach(id => {
          val.push(
            `(${id},'${status}',current_timestamp,'${
              userId || 'System'
            }','${systemInfo}', ${actualActivityCount}, '${
              data.usercomments || ''
            }')`,
          );
        });
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount,usercomments) VALUES ${val}`;
        if (client) {
          await client.query(sql);
        } else {
          await query(sql);
        }
      }
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
export const updateComplexity = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { complexityid, woincomingfileid } = data;
      const sql = `UPDATE public.wms_workorder_incomingfiledetails SET complexityid =$1 WHERE woincomingfileid =$2 `;
      await query(sql, [complexityid, woincomingfileid]);
      resolve(woincomingfileid);
    } catch (e) {
      reject(e);
    }
  });
};
// Work order creation
export const workorderCreation = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        wfId,
        customerId,
        woType,
        userId,
        duId,
        name,
        title,
        imageCount,
        complexityId,
        bookId,
        piiNumber,
        complexityid,
        needExtraction,
      } = payload;
      const otherField = JSON.stringify({
        pii: piiNumber,
        needExtraction: needExtraction,
      });
      let sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE duid=$1 and customerid=$2`;
      const dmsInfo = await query(sql, [duId, customerId]);
      const { dmsid } = dmsInfo[0];
      if (dmsid) {
        sql = `INSERT INTO public.wms_workorder(itemcode, title, wfid, customerid, status, wotype, dmsid, createdby,duid,totalchaptercount,complexityid,bookid, otherfield)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING workorderid;`;
        const rows = await query(sql, [
          name,
          title,
          wfId,
          customerId,
          'In Process',
          woType,
          dmsid,
          userId,
          duId,
          imageCount || 0,
          complexityId || complexityid,
          bookId,
          otherField,
        ]);

        resolve({
          data: rows[0],
          status: true,
          message: 'Wordorder created successfully',
        });
      } else {
        reject('DMS type not mapping for the customer');
      }
    } catch (e) {
      reject(e);
    }
  });
};
// Work order service creation
export const woServiceCreation = (payload, client) => {
  return new Promise(async (resolve, reject) => {
    const { serviceId, duId, wfId, workorderId } = payload;
    try {
      const sql = `INSERT INTO public.wms_workorder_service(
        serviceid, baseduid, assignedduid, iscustomerbillable, wfid, workorderid, internalbilling, status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`;
      if (client) {
        await client.query(sql, [
          serviceId,
          duId,
          duId,
          true,
          wfId,
          workorderId,
          duId,
          'In Process',
        ]);
      } else {
        await query(sql, [
          serviceId,
          duId,
          duId,
          true,
          wfId,
          workorderId,
          duId,
          'In Process',
        ]);
      }
      resolve({
        status: true,
        message: `WO service created successfully (${workorderId})`,
      });
    } catch (e) {
      reject({
        status: false,
        message: `WO service created failed (${workorderId})`,
      });
    }
  });
};
// workorder stage creation service
export const woStageCreation = (payload, client) => {
  return new Promise(async (resove, reject) => {
    const {
      workorderId,
      wfId,
      serviceId,
      userId,
      startDate,
      endDate,
      imageCount,
    } = payload;

    try {
      const startDueDate = await query(`SELECT * FROM 
      add_hours_exclude_weekends_and_holidays
    (CURRENT_TIMESTAMP::timestamp(0),48 ::integer)`);

      let formattedStartDate = await convertDateFormat(
        startDueDate?.[0]?.add_hours_exclude_weekends_and_holidays,
      );

      const sqlQuery = `with cte as (SELECT DISTINCT ON(stageid) stageid, sequence
      FROM wms_workflowdefinition
      WHERE wfid IN (${wfId}) AND lock = false ) select * from cte order by sequence`;

      let rows = [];
      if (client) {
        const response = await client.query(sqlQuery);
        rows = response.rows;
      } else {
        const response = await query(sqlQuery);
        rows = response;
      }
      if (rows.length) {
        const values = [];
        rows.forEach((stage, i) => {
          if (i === 0) {
            values.push(
              `(${serviceId},${
                stage.stageid
              },'${userId}',${workorderId}, 'In Process', 1, ${
                i + 1
              }, current_timestamp,'${formattedStartDate}','${formattedStartDate}','${formattedStartDate}')`,
            );
          } else {
            values.push(
              `(${serviceId},${stage.stageid},'${userId}',${workorderId}, 'YTS', 1, ${stage.sequence}, current_timestamp, null, null, null, null)`,
            );
          }
        });
        const sql = `INSERT INTO public.wms_workorder_stage(serviceid, wfstageid, updatedby, workorderid, status, stageiterationcount, sequence, updatedon, plannedstartdate,startdatetime,ordermaildatetime)
        VALUES ${values} RETURNING workorderid`;

        if (client) {
          await client.query(sql);
        } else {
          await query(sql);
        }
        resove({
          status: true,
          message: `WO stage created successfully (${workorderId})`,
        });
      } else {
        reject({
          status: false,
          message: `No stages found the workorder (${workorderId})`,
        });
      }
    } catch (e) {
      reject({
        status: false,
        message: `WO stage created failed (${workorderId})`,
      });
    }
  });
};
// Add incoming
export const addIncoming = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      workorderId,
      serviceId,
      stageId,
      userId,
      imageCount,
      files,
      endDate,
    } = payload;
    try {
      let woincomingid = '';
      let sql = '';
      await transaction(async client => {
        let checkSql = `SELECT woincomingid FROM public.wms_workorder_incoming 
        WHERE woid = ${workorderId} 
        ORDER BY updatedon DESC LIMIT 1`;

        let existing = await query(checkSql);

        if (existing.length > 0) {
          woincomingid = existing[0].woincomingid;
        } else {
          let sql = `INSERT INTO public.wms_workorder_incoming(woid, serviceid, stageid, receiptdate, duedate, updatedby, batchno, updatedon, receiptdatetime)
           VALUES (${workorderId}, ${serviceId}, ${stageId}, current_timestamp, '${endDate}', 
             '${userId}', 1,current_timestamp, current_timestamp) RETURNING woincomingid`;
          let incoming = await client.query(sql);
          woincomingid = incoming?.rows?.[0]?.woincomingid;
        }

        if (files && files.length > 0) {
          const val = [];
          files.forEach(list => {
            const filename = list?.imagename
              ? list.imagename.split('.')[0]
              : '';
            const sanitizedValue = filename.replaceAll(/[^a-zA-Z0-9.-]/g, '_');
            const sanitizedImageNumber =
              list.image_number &&
              list.image_number.replaceAll(/[^a-zA-Z0-9.-]/g, '_');

            val.push(
              `(${woincomingid},${list.filetypeid || 4},'${list.imageurl}','${
                list._id
              }','${sanitizedValue}','${endDate}',${
                list.filesequence ? list.filesequence : null
              }, ${imageCount || 0},'${list.thumbnailurl}',${
                list.complexityid || 1
              }
            ,'${list.size}','${list.page_no ? list.page_no : ''}', '${
                sanitizedImageNumber || ''
              }', '${list.assettype}')`,
            );
          });

          sql = `INSERT INTO public.wms_workorder_incomingfiledetails(
                          woincomingid,filetypeid,filepath,fileuuid,filename, duedate,filesequence, imagecount,thumbnailurl,complexityid,filesize,pagenumber,fignumber, assettype)
                          VALUES ${val}`;
          console.log(sql, 'dfs');
          await client.query(sql);
          console.log(sql, 'dfs');
        }
      });

      let selectQuery = `select * from  public.wms_workorder_incomingfiledetails
      where woincomingid=${woincomingid}   order by 1 desc`;

      const incomingList = await query(selectQuery);

      // let getCountSql = `SELECT totalchaptercount FROM wms_workorder WHERE workorderid = ${workorderId}`;
      // let result = await query(getCountSql);

      // let currentCount = result.length > 0 ? result[0].totalchaptercount : 0;
      let updateSql = `UPDATE wms_workorder 
                 SET totalchaptercount = ${incomingList.length} 
                 WHERE workorderid = ${workorderId}  RETURNING totalchaptercount`;

      let updatedResult = await query(updateSql);
      let updatedCount = updatedResult[0].totalchaptercount;

      payload.imageCount = updatedCount;

      // await query(
      //   `Update wms_workorder set totalchaptercount =${payload.imageCount} where workorderid=${workorderId}`,
      // );
      await getTimeEstimate(payload);

      resolve({
        status: true,
        message: `Chapter file has been added successfully for (${workorderId})`,
      });
    } catch (e) {
      reject({
        status: false,
        message: `Chapter file add failed for (${workorderId})`,
        error: `Chapter file add failed for (${workorderId})`,
      });
    }
  });
};
// Add incoming files
export const addIncomingFiles = payload => {
  return new Promise(async (resolve, reject) => {
    const { files, woIncomingFileId, userId } = payload;
    try {
      await transaction(async client => {
        const val = [];
        files.forEach(list => {
          val.push(
            `(${woIncomingFileId},'${list.name}','${list.path}','${list.uuid}','${list.size}', '${userId}'
            )`,
          );
        });
        const sql = `INSERT INTO public.wms_workorder_incoming_files(woincomingfileid, name, path, uuid, size, createdby)
        VALUES ${val}`;
        await client.query(sql);
      });
      resolve({
        status: true,
        message: `File has been added successfully`,
      });
    } catch (e) {
      reject({
        status: false,
        message: `File adding failed`,
        error: e,
      });
    }
  });
};
// update trigger status in wo incoming files
export const updateTriggerStatusScript = () => {
  return new Promise(resolve => {
    const script = `UPDATE public.wms_workorder_incomingfiledetails SET istriggered=true WHERE woincomingfileid=ANY($1)`;
    resolve(script);
  });
};
// update trigger status on service
export const updateTriggerStatusOnServiceScript = () => {
  return new Promise(resolve => {
    const script = `UPDATE public.wms_workorder_service SET isbookcompleted=true WHERE workorderid=$1`;
    resolve(script);
  });
};
// get next activity info
export const getNextActivityScript = () => {
  return new Promise(resolve => {
    const script = `SELECT activityalias,activityid,activitytype FROM public.wms_workflowdefinition where wfid=$1 and stageid=$2 and activityid=$3`;
    resolve(script);
  });
};

// capture api event log
export const captureApiEventLog = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        wfeventId,
        stage,
        activity,
        apiStatus,
        apiMessage,
        fileuuid,
        // payloadArray,
      } = data;
      let uuid = '';
      if (typeof fileuuid === 'string') {
        uuid = [fileuuid];
      } else {
        uuid = fileuuid;
      }
      const ids = uuid.length ? uuid.join(',') : '';
      const val = [];
      const eventIdArray = Array.isArray(wfeventId) ? wfeventId : [wfeventId];
      // const reqPayload = payloadArray || {};
      eventIdArray.forEach(id => {
        val.push(
          `(${id}, ${stage.id}, ${stage.iteration}, ${activity.id}, ${
            activity.actualIteration
          }, current_timestamp, '${apiStatus}' , '${JSON.stringify(
            apiMessage,
          )}', '{${ids}}')`,
        );
      });
      const sql = `INSERT INTO public.ialt_api_event_log(
        wfeventid, stageid, stageiterationcount, activityid, activityiterationcount, timestamp, status, response, fileuuid)
       VALUES ${val};`;
      await query(sql);
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
