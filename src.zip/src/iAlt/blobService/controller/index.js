/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies

import * as blob from '../utils/blob.js';

export const checkin = async (req, res) => {
  try {
    const sourceURL = encodeURI(req.body.docPath);
    const tempFilePath = req?.files?.content?.tempFilePath;

    let prop = await blob.BlobUploadFile(sourceURL, tempFilePath);
    res.status(200).send({ path: prop, uuid: 'azure' });
  } catch (error) {
    res.status(400).send(error);
  }
};

export const _checkinBuffer = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const sourceURL = encodeURI(payload.docPath);
      const tempBuffer = payload?.buffer;
      let prop = await blob.BlobUploadBuffer(sourceURL, tempBuffer);
      resolve({ path: prop, uuid: 'azure' });
    } catch (error) {
      reject(error);
    }
  });
};

export const ZIPDownloadBlobFolder = async (req, res) => {
  let zipPath = undefined;
  try {
    const sourceURL = encodeURI(req.body.docPath);

    zipPath = await blob.ZIPDownloadBlobFolder(sourceURL);
    res.status(200).download(zipPath);
  } catch (error) {
    res.status(400).send(error);
  }
};

export const downloadFile = async (req, res) => {
  try {
    const sourceURL = encodeURI(req.query.docPath);

    let prop = await blob.getDownloadURL(sourceURL);
    res.status(200).send({ path: prop, uuid: 'azure' });
  } catch (error) {
    res.status(400).send(error);
  }
};

export const iAltZIPDownloadBlobFolder = async (req, res) => {
  let zipPath = undefined;
  try {
    const sourceURL = encodeURI(req.body.docPath);
    zipPath = await blob.iAltZIPDownloadBlobFolder(sourceURL, res);
  } catch (error) {
    res.status(400).send(error.message);
  }
};
