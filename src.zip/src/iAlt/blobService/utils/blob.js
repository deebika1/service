/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies

import {
  BlobServiceClient,
  StorageSharedKeyCredential,
  BlobSASPermissions,
  generateBlobSASQueryParameters,
} from '@azure/storage-blob';

import { getSecret } from '../keyvault.js';

import fs from 'fs';
import { dirname, join, basename, extname, parse } from 'path';
import * as path from 'path';
import { createHash } from 'crypto';
import pLimit from 'p-limit';
const _plimit = pLimit(10);

import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);

import AdmZip from 'adm-zip';
import xml2js from 'xml2js';

import { removeFolder, makeDir } from '../../../modules/utils/custom/io.js';
var blobStorageKey;
var storageAccount;
var containerName;
var accessKey;
var blobServiceClient;

async function initializeBlobStorage() {
  blobStorageKey = await getSecret(`iWMS${`azure`}BlobAccessKey`);
}
initializeBlobStorage().catch(error => {
  // console.error("Error initializing blob storage:", error);
  blobStorageKey = JSON.parse(blobStorageKey.value);
  storageAccount = blobStorageKey.storageAccount;
  containerName = blobStorageKey.containerName;
  accessKey = blobStorageKey.accessKey;

  let sharedKeyCredential = new StorageSharedKeyCredential(
    storageAccount,
    accessKey,
  );
  blobServiceClient = new BlobServiceClient(
    `https://${storageAccount}.blob.core.windows.net`,
    sharedKeyCredential,
  );
});
// let blobStorageKey = await getSecret(`iWMS${`azure`}BlobAccessKey`);

export const BlobUploadFile = (Path, localpath) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (Path.startsWith('/okm:root/')) Path = Path.replace('/okm:root/', '');
      if (Path.startsWith('/okm_root/')) Path = Path.replace('/okm_root/', '');

      const blobInfo = await getBlobInfo();

      const containerClient = blobInfo.blobServiceClient.getContainerClient(
        blobInfo.containerName,
      );

      const blockBlobClient = containerClient.getBlockBlobClient(Path);
      blockBlobClient
        .uploadFile(localpath, {
          maxSingleShotSize: 10,
          concurrency: 20,
          metadata: {
            contentMD5: await getChecksum(localpath),
          },
        })
        .then(Result => {
          fs.unlink(localpath, error => {
            if (error) console.log(error);
          });
          resolve(`/okm:root/${Path}`);
        })
        .catch(error => {
          fs.unlink(localpath, error => {
            if (error) console.log(error);
          });
          reject(error);
        });
    } catch (e) {
      fs.unlink(localpath, error => {
        if (error) console.log(error);
      });
      reject(e);
    }
  });
};

export const BlobUploadBuffer = (Path, bufferContent) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (Path.startsWith('/okm:root/')) {
        Path = Path.replace('/okm:root/', '');
      }
      const blobInfo = await getBlobInfo();

      const containerClient = blobInfo.blobServiceClient.getContainerClient(
        blobInfo.containerName,
      );
      const blockBlobClient = containerClient.getBlockBlobClient(Path);

      // Calculate checksum (optional) if required
      const metadata = {
        contentMD5: await getChecksumBuffer(bufferContent), // Assuming getChecksum can handle Buffer
      };

      // Upload buffer content directly
      await blockBlobClient.uploadData(bufferContent, {
        maxConcurrency: 20,
        metadata,
      });

      resolve(`/okm:root/${Path}`);
    } catch (error) {
      reject(error);
    }
  });
};

const getChecksum = path => {
  const readStream = fs.createReadStream(path);
  const hash = createHash('md5');
  hash.setEncoding('hex');
  return new Promise(async (resolve, reject) => {
    try {
      readStream.on('close', () => {
        hash.end();
        resolve(hash.read());
      });
      readStream.on('error', e => {
        global.log(e, 'hash error');
        reject(e);
      });
      readStream.pipe(hash);
    } catch (e) {
      global.log(e, 'hash error');
      reject(e);
    }
  });
};

const getChecksumBuffer = buffer => {
  return new Promise((resolve, reject) => {
    try {
      const hash = createHash('md5'); // Use the MD5 hash algorithm
      hash.update(buffer); // Update the hash with the buffer content
      const checksum = hash.digest('hex'); // Get the checksum in hexadecimal format
      resolve(checksum);
    } catch (e) {
      global.log(e, 'hash error');
      reject(e);
    }
  });
};

export const ZIPDownloadBlobFolder = async function (Path) {
  return await new Promise(async (resolve, reject) => {
    let _guid = guid();
    let tmpFolderPath = join(await createTempFolderWithDate(), _guid); // Create path for temporary folder
    let ZipPath = `${join(tmpFolderPath, basename(Path))}.zip`;
    try {
      if (Path == undefined || Path == '') {
        throw new Error('Please Check the Path : ' + Path);
      } else {
        if (Path.startsWith('/okm:root/')) {
          Path = Path.replace('/okm:root/', '');
        }

        if (Path.startsWith('/okm_root/'))
          Path = Path.replace('/okm_root/', '');

        let zip = new AdmZip();
        let _ListAllFilesPath = await ListAllFilesPath(Path);
        let awts = [];
        for (let index = 0; index < _ListAllFilesPath.length; index++) {
          const element = _ListAllFilesPath[index].path.replace(
            '/okm:root/',
            '',
          );
          let BlobPath = element.includes(Path)
            ? element.replace(Path, '')
            : element;
          let LocalPath = join(tmpFolderPath, BlobPath);
          awts.push(_plimit(() => BlobDownloadToLocal(element, LocalPath)));
        }
        await Promise.all(awts);
        await zip.addLocalFolderPromise(tmpFolderPath);
        await zip.writeZipPromise(ZipPath);
        resolve(ZipPath);
      }
    } catch (error) {
      reject(error);
    }
  });
};

const guid = function () {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4();
};

export const createTempFolderWithDate = async () => {
  let tempFilePath = join(__filename, '../../../../../');

  const baseTemp = `${tempFilePath}upload\\temps`;

  //const baseTemp = 'c:\\CUPTemp';
  const now = new Date();
  const formattedDate = now.toISOString().split('T')[0]; // Remove colons, periods, and timezone info
  const tempFolderPath = path.join(baseTemp, formattedDate);
  // if (!fs.existsSync(tempFolderPath)) {
  // Delete the baseTemp directory and all its contents
  await removeFolder(baseTemp);
  await makeDir(tempFolderPath);
  // await fs.rmSync(baseTemp, { recursive: true, force: true });
  // Create the tempFolderPath recursively
  //await fs.mkdirSync(tempFolderPath, { recursive: true });
  // }
  return tempFolderPath;
};

export const ListAllFilesPath = async prefixPath => {
  return new Promise(async (resolve, reject) => {
    const blobInfo = await getBlobInfo();
    console.log(blobInfo, 'blobInfo');

    try {
      if (prefixPath.startsWith('/okm:root/'))
        prefixPath = prefixPath.replace('/okm:root/', '');
      const containerClient = blobInfo.blobServiceClient.getContainerClient(
        blobInfo.containerName,
      );
      prefixPath = prefixPath.slice(-1) == '/' ? prefixPath : prefixPath + '/';
      let iter = await containerClient.listBlobsByHierarchy('/', {
        prefix: prefixPath,
      });
      let PathArray = [];
      let entity = await iter.next();
      while (!entity.done) {
        let item = entity.value;
        if (item.kind === 'prefix') {
          let blbs = await ListAllFilesPath(item.name).catch(error => {
            throw error;
          });
          PathArray.push(...blbs);
          // blbs.forEach(ele => {
          //     PathArray.push({ path: ele.path, uuid: "azure", createdOn: ele?.createdOn, lastModified: ele?.lastModified });
          // })
        } else if (item.kind === 'blob') {
          PathArray.push({
            path: `/okm:root/${item.name}`,
            uuid: 'azure',
            createdOn: item?.properties?.createdOn,
            lastModified: item?.properties?.lastModified,
          });
        }
        entity = await iter.next();
      }
      resolve(PathArray);
    } catch (error) {
      reject(error);
    }
  });
};

const BlobDownloadToLocal = async function (BlobPath, LocalPath) {
  return new Promise(async (resolve, reject) => {
    try {
      const blobInfo = await getBlobInfo();

      const containerClient = blobInfo.blobServiceClient.getContainerClient(
        blobInfo.containerName,
      );
      const blockBlobClient = containerClient.getBlockBlobClient(BlobPath);
      if (await blockBlobClient.exists()) {
        checkDirectorySync(dirname(LocalPath));
        await blockBlobClient.downloadToFile(LocalPath);
        resolve(true);
      } else {
        resolve(true);
      }
    } catch (error) {
      reject(error);
    }
  });
};

const checkDirectorySync = directory => {
  try {
    fs.statSync(directory);
  } catch (e) {
    fs.mkdirSync(directory, { recursive: true });
  }
};

export const getDownloadURL = async function (Path) {
  return new Promise(async (resolve, reject) => {
    try {
      if (Path.startsWith('/okm:root/')) Path = Path.replace('/okm:root/', '');
      const blobInfo = await getBlobInfo();
      const containerClient = blobInfo.blobServiceClient.getContainerClient(
        blobInfo.containerName,
      );
      const blockBlobClient = containerClient.getBlockBlobClient(Path);
      let isexists = true,
        url = '';
      if (!(await blockBlobClient.exists())) {
        isexists = false;
      } else {
        Date.prototype.addHours = function (h) {
          this.setTime(this.getTime() + h * 60 * 60 * 1000);
          return this;
        };
        url = await blockBlobClient.generateSasUrl({
          permissions: BlobSASPermissions.parse('read'),
          startsOn: new Date().addHours(-0.5),
          expiresOn: new Date().addHours(24),
        });
      }
      resolve(url);
    } catch (error) {
      reject(error);
    }
  });
};

export const iAltZIPDownloadBlobFolder = async function (Path, res) {
  try {
    const sourceURL = encodeURI(Path);
    const zipBuffer = await createZipFromBlob(sourceURL);

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${basename(sourceURL)}.zip"`,
    );
    res.send(zipBuffer); // Send the zip as a binary buffer
  } catch (error) {
    // logger.error("ZIPDownloadBlobFolder Error: ", error);
    throw error;
  }
};

export const createZipFromBlob = async function (Path) {
  try {
    if (!Path) throw new Error('Path cannot be empty.');

    if (Path.startsWith('/okm:root/')) {
      Path = Path.replace('/okm:root/', '');
    }
    if (Path.startsWith('/okm_root/')) Path = Path.replace('/okm_root/', '');

    const fileList = await ListAllFilesPath(Path);
    if (!fileList.length) {
      throw new Error('No files found at the specified path.');
    }

    const zip = new AdmZip();

    for (let i = 0; i < fileList.length; i++) {
      const filePath = fileList[i].path.replace('/okm:root/', '');
      const blobStream = await BlobDownloadToStream(filePath);

      // Convert stream to buffer
      const fileBuffer = await streamToBuffer(blobStream);

      // Get relative path for zip
      const relativePath = filePath.replace(Path, '');

      // Add buffer to zip
      zip.addFile(relativePath, fileBuffer);
    }

    return zip.toBuffer(); // Return zip as buffer
  } catch (error) {
    // logger.error("createZipFromBlob Error: ", error);
    throw error;
  }
};

// Stream to buffer utility
const streamToBuffer = async readableStream => {
  const chunks = [];
  for await (const chunk of readableStream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks); // Concatenate all chunks into one Buffer
};

export const BlobDownloadToStream = async filePath => {
  try {
    // const sourceContainerClient =blobServiceClient.getContainerClient(containerName);
    // const containerClient =sourceContainerClient.getBlockBlobClient(filePath);

    //     const blobClient = containerClient.getBlobClient(filePath);

    // const downloadResponse = await blobClient.download();
    const blobInfo = await getBlobInfo();

    const containerClient = blobInfo.blobServiceClient.getContainerClient(
      blobInfo.containerName,
    );
    const blockBlobClient = containerClient.getBlockBlobClient(filePath);
    const downloadResponse = await blockBlobClient.download();

    // Check if downloadResponse.readableStreamBody exists
    if (!downloadResponse.readableStreamBody) {
      throw new Error(`Download failed for path: ${filePath}`);
    }

    return downloadResponse.readableStreamBody; // Return readable stream
  } catch (error) {
    throw new Error(`Error downloading file: ${filePath}, ${error.message}`);
  }
};

export const getBlobInfo = async () => {
  return new Promise(async (resolve, reject) => {
    let mode =
      process.env.MODE.toLocaleLowerCase() == 'live'
        ? 'azure'
        : process.env.MODE.toLocaleLowerCase();
    let blobStorageKey = await getSecret(`iWMS${`${mode}`}BlobAccessKey`);

    blobStorageKey = JSON.parse(blobStorageKey.value);
    const storageAccount = blobStorageKey.storageAccount;
    const containerName = blobStorageKey.containerName;
    const accessKey = blobStorageKey.accessKey;

    let sharedKeyCredential = new StorageSharedKeyCredential(
      storageAccount,
      accessKey,
    );
    const blobServiceClient = new BlobServiceClient(
      `https://${storageAccount}.blob.core.windows.net`,
      sharedKeyCredential,
    );

    resolve({
      blobServiceClient: blobServiceClient,
      containerName: containerName,
    });
  });
};

const streamToString = async readableStream => {
  return new Promise((resolve, reject) => {
    const chunks = [];
    readableStream.on('data', chunk => chunks.push(chunk));
    readableStream.on('end', () =>
      resolve(Buffer.concat(chunks).toString('utf-8')),
    );
    readableStream.on('error', reject);
  });
};

export const fetchJsonFromAzureBlob = async pii => {
  return new Promise(async (resolve, reject) => {
    try {
      const blobInfo = await getBlobInfo();
      const containerClient = blobInfo.blobServiceClient.getContainerClient(
        blobInfo.containerName,
      );

      // Build the path with the PII
      const basePath = `prodrepository/iAlt/Elsevier/AutoJobCreation/${pii}/`;

      // List blobs in parent folder
      let blobs = containerClient.listBlobsByHierarchy('/', {
        prefix: basePath,
      });
      let subfolderName = null;

      for await (const blob of blobs) {
        if (blob.kind === 'prefix') {
          subfolderName = blob.name;
          break;
        }
      }

      if (!subfolderName) {
        resolve(null);
        return;
      }

      // Find JSON file in subfolder
      blobs = containerClient.listBlobsByHierarchy('/', {
        prefix: subfolderName,
      });
      let jsonFilePath = null;

      for await (const blob of blobs) {
        if (blob.name.endsWith('.json')) {
          jsonFilePath = blob.name;
          break;
        }
      }

      if (!jsonFilePath) {
        resolve(null);
        return;
      }

      // Download and parse JSON
      const blockBlobClient = containerClient.getBlockBlobClient(jsonFilePath);
      const downloadResponse = await blockBlobClient.download();
      const jsonData = await streamToString(
        downloadResponse.readableStreamBody,
      );

      resolve(JSON.parse(jsonData));
    } catch (error) {
      reject(new Error(`Error fetching JSON: ${error.message}`));
    }
  });
};

function camelToDash(str) {
  return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
}

export const xmlContentsUpdate = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { blobPath, updates } = payload;

      const blobInfo = await getBlobInfo();
      const containerClient = blobInfo.blobServiceClient.getContainerClient(
        blobInfo.containerName,
      );
      const blobClient = containerClient.getBlobClient(blobPath);

      const downloadBlockBlobResponse = await blobClient.download();
      const downloaded = await streamToString(
        downloadBlockBlobResponse.readableStreamBody,
      );

      const parser = new xml2js.Parser({
        explicitArray: false, // Important: So that values are not unnecessarily wrapped inside arrays
        explicitRoot: false, // Skip the root wrapper
      });
      const builder = new xml2js.Builder({
        headless: false,
        renderOpts: { pretty: true },
      });

      let xmlObject = await parser.parseStringPromise(downloaded);

      for (const key in updates) {
        if (updates.hasOwnProperty(key)) {
          const xmlTag = camelToDash(key);

          // Check if the tag already exists, then update or create it
          if (xmlObject.hasOwnProperty(xmlTag)) {
            xmlObject[xmlTag] = updates[key];
          } else {
            xmlObject[xmlTag] = updates[key];
          }
        }
      }

      const updatedXML = builder.buildObject(xmlObject);

      //   await blobClient.uploadData(Buffer.from(updatedXML), {
      //     overwrite: true
      // });
      console.log('XML updated successfully!');
      resolve(updatedXML);
    } catch (error) {
      reject(error);
    }
  });
};
