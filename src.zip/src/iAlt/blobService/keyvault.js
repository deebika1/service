import { ClientSecretCredential } from '@azure/identity';
import { SecretClient } from '@azure/keyvault-secrets';

const vaultConfig = {
  tenantID: '70e2bc38-6b4b-43a1-9821-a49c0a744f3d',
  clientID: 'a580e961-0945-41ec-b2d6-11f0b610dc41',
  clientSecret: '~rq8Q~kSHUeDmoX2YlhPyX6.QNPZ4o50U7OWYaSW',
  vaultName: 'ProdEnggVault',
};
const vaultURL = `https://${vaultConfig.vaultName}.vault.azure.net/`;
const vaultCredential = new ClientSecretCredential(
  vaultConfig.tenantID,
  vaultConfig.clientID,
  vaultConfig.clientSecret,
);
const secretClient = new SecretClient(vaultURL, vaultCredential);

export const getSecret = secretName => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await secretClient.getSecret(secretName);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
