import express from 'express';
// import swaggerUi from 'swagger-ui-express';
// import { readFileSync } from 'fs';

import {
  checkin,
  ZIPDownloadBlobFolder,
  downloadFile,
  iAltZIPDownloadBlobFolder,
} from '../blobService/controller/index.js';

import {
  triggerIaltWorkflowController,
  getiAltTaskListController,
  generalActionProcessController,
  workflowActionProcessController,
  workorderCreationController,
  addIncomingController,
  addIncomingFilesController,
  getSelectedChapterInfoController,
  getImageClassificationController,
  getAllClassificationController,
  getBookMasterFields,
  getAltTextGenerationController,
  getAllPromptController,
  taskAssignController,
  getOptionListController,
  checkiAltAvailabilityController,
  createiAltBookCode,
  retreiveBookFiles,
  getBookMasterDatas,
  getChapterMasterDatas,
  getiAltXlReport,
  deleteBookMasterDatas,
  getiAltChapterListController,
  checkAssignedTaskController,
  updateAltTextGenerationController,
  getBookListByIdForPmController,
  getiAltReportData,
  getiAltJobsData,
  getiAltDispatchData,
  getiAltWIPData,
  getiAltBookwise,
  getiAltJobsOverallData,
  reAltTextGenerationController,
  getReportOptionListController,
  getiAltWIPReportTwo,
  getiAltWIPChapterReport,
  iAltChapterCreationController,
  updateChapterCreationController,
  deleteChapterController,
  iAltTriggerChapterController,
  getiAltIncomingChaptersController,
  iAltIncomingFilesOperationsController,
  getiAltAssetReportDataController,
  updateAndNextController,
  getiAltBookWiseReportController,
  getiAltChapteriseReportController,
  getiAltImageWiseReportController,
  getDashboardReportOptionListController,
  getDashboardDataController,
  getImageCountInfoController,
  taskAssignForTLController,
  sendMessageToSQSController,
  uploadFileToS3Controller,
  listInBucketsController,
  iAltAutoJobCreationController,
  getiAltSignalAuditController,
  iAltJobSummaryRetriggerController,
  // altextGenerationJobController,
  getiAltSignalAuditHistoryController,
  _getFolderStructureForIalt,
  iAltDirectDespatch,
  iAltJobCreationClientPIIControler,
  iAltBookWiseReportGenerateControler,
  updtaeComplexityController,
  createComplexityController,
  getComplexityController,
  iAltDeleteJobAuditHistoryControler,
  iAltDirectDespatchWithExcel,
  updtaePlaceholderController,
  createPlaceholderController,
  getPlaceholderController,
  tandeIntegrationController,
  createiAltQueryController,
  queueTriggerLogController,
  autoJobFailedRetriggerController,
  acknowledgmentLogController,
  ackFailedRetriggerController,
  getiAltBookDetails,
  getiAltComplexityXlReport,
  getiAltYTSData,
  checkPIIExistsController,
  getiAltQueryDataController,
  // journalJobProcessController,
} from '../controller/index.js';
import { iAltManulWoFilesDownloadService } from '../service/index.js';

// const loadJSON = path =>
//   JSON.parse(readFileSync(new URL(path, import.meta.url)));
// const swagger = loadJSON('../helpers/swagger.json');

// function swaggerDocs(app) {
//   // Swagger Page
//   app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
// }

const iAltRouter = express.Router();
// swaggerDocs(iAspireRouter);
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

iAltRouter.post('/workorderCreation', handler(workorderCreationController));
iAltRouter.post('/addIncoming', handler(addIncomingController));
iAltRouter.post('/addIncomingFiles', handler(addIncomingFilesController));
iAltRouter.post('/triggerIaltWorkflow', handler(triggerIaltWorkflowController));
iAltRouter.post('/getiAltTaskList', handler(getiAltTaskListController));
iAltRouter.post('/getiAltChapterList', handler(getiAltChapterListController));
iAltRouter.post(
  '/getSelectedChapterInfo',
  handler(getSelectedChapterInfoController),
);
iAltRouter.post(
  '/generalActionProcess',
  handler(generalActionProcessController),
);
iAltRouter.post(
  '/workflowActionProcess',
  handler(workflowActionProcessController),
);
iAltRouter.post(
  '/getImageClassification',
  handler(getImageClassificationController),
);
iAltRouter.get(
  '/getAllClassification',
  handler(getAllClassificationController),
);
iAltRouter.post('/getBookMasterFields', handler(getBookMasterFields));
iAltRouter.post(
  '/getAltTextGeneration',
  handler(getAltTextGenerationController),
);
iAltRouter.post(
  '/updateAltTextGeneration',
  handler(updateAltTextGenerationController),
);
iAltRouter.post('/updateAndNext', handler(updateAndNextController));
iAltRouter.post('/reAltTextGeneration', handler(reAltTextGenerationController));
iAltRouter.get('/getAllPrompt', handler(getAllPromptController));
iAltRouter.post('/checkAssignedTask', handler(checkAssignedTaskController));
iAltRouter.post('/taskAssign', handler(taskAssignController));
iAltRouter.post('/getOptionList', handler(getOptionListController));
iAltRouter.post(
  '/checkiAltAvailability',
  handler(checkiAltAvailabilityController),
);
iAltRouter.post('/createiAltBookCode', handler(createiAltBookCode));
iAltRouter.post('/getBookMasterDatas', handler(getBookMasterDatas));
iAltRouter.post('/deleteBookMasterDatas', handler(deleteBookMasterDatas));
iAltRouter.post('/retreiveBookFiles', handler(retreiveBookFiles));
iAltRouter.post('/getChapterMasterDatas', handler(getChapterMasterDatas));
iAltRouter.post(
  '/getBookListByIdForPm',
  handler(getBookListByIdForPmController),
);
iAltRouter.post('/getiAltXlReport', handler(getiAltXlReport));
iAltRouter.post('/getiAltReportData', handler(getiAltReportData));
iAltRouter.post('/getiAltJobsData', handler(getiAltJobsData));
iAltRouter.post('/getiAltDispatchData', handler(getiAltDispatchData));
iAltRouter.post('/getiAltWIPData', handler(getiAltWIPData));
iAltRouter.post('/getiAltYTSData', handler(getiAltYTSData));
iAltRouter.post('/getiAltBookDetails', handler(getiAltBookDetails));
iAltRouter.post('/getiAltBookwise', handler(getiAltBookwise));
iAltRouter.post('/getiAltJobsOverallData', handler(getiAltJobsOverallData));
iAltRouter.post('/getReportOptionList', handler(getReportOptionListController));
iAltRouter.post('/iAltChapterCreation', handler(iAltChapterCreationController));
iAltRouter.post(
  '/updateChapterCreation',
  handler(updateChapterCreationController),
);
iAltRouter.post('/deleteChapter', handler(deleteChapterController));
iAltRouter.post('/iAltTriggerChapter', handler(iAltTriggerChapterController));
iAltRouter.post(
  '/getiAltIncomingChapters',
  handler(getiAltIncomingChaptersController),
);
iAltRouter.post(
  '/iAltIncomingFilesOperations',
  handler(iAltIncomingFilesOperationsController),
);
// ialt wip report routers start
iAltRouter.post('/getiAltWIPReportTwo', handler(getiAltWIPReportTwo));
iAltRouter.post('/getiAltWIPChapterReport', handler(getiAltWIPChapterReport));
// ialt wip report routers end

// asset trancefer report start
iAltRouter.post(
  '/getiAltAssetReportData',
  handler(getiAltAssetReportDataController),
);
// asset trancefer report end
// Dashboard module
iAltRouter.post(
  '/getiAltBookWiseReport',
  handler(getiAltBookWiseReportController),
);
iAltRouter.post(
  '/getiAltChapterWiseReport',
  handler(getiAltChapteriseReportController),
);
iAltRouter.post(
  '/getiAltImageWiseReport',
  handler(getiAltImageWiseReportController),
);
iAltRouter.post(
  '/getDashboardReportOptionList',
  handler(getDashboardReportOptionListController),
);
iAltRouter.post('/getDashboardData', handler(getDashboardDataController));
iAltRouter.post('/getImageCountInfo', handler(getImageCountInfoController));
iAltRouter.post('/taskAssignForTL', handler(taskAssignForTLController));

iAltRouter.post('/sendMessageToSQS', handler(sendMessageToSQSController));
iAltRouter.post('/uploadFileToS3', handler(uploadFileToS3Controller));
iAltRouter.post('/listInBuckets', handler(listInBucketsController));

// iAlt Auto Workorder Creation
iAltRouter.post('/iAltAutoJobCreation', handler(iAltAutoJobCreationController));

// Job summary report
iAltRouter.post('/getiAltSignalAudit', handler(getiAltSignalAuditController));
iAltRouter.post(
  '/iAltJobSummaryRetrigger',
  handler(iAltJobSummaryRetriggerController),
);
// iAltRouter.post(
//   '/altextGenerationJobProcess',
//   handler(altextGenerationJobController),
// );

iAltRouter.post(
  '/getiAltSignaleAuditHistory',
  handler(getiAltSignalAuditHistoryController),
);

// iAltRouter.post('/journalJobProcess', handler(journalJobProcessController));

iAltRouter.post(
  '/getFolderStructureForIalt',
  handler(_getFolderStructureForIalt),
);

iAltRouter.post('/iAltDirectDespatch', handler(iAltDirectDespatch));
iAltRouter.post(
  '/iAltDirectDespatchWithExcel',
  handler(iAltDirectDespatchWithExcel),
);
iAltRouter.post(
  '/iAltJobCreationClientPII',
  handler(iAltJobCreationClientPIIControler),
);

iAltRouter.post(
  '/iAltManulWoFilesDownload',
  handler(iAltManulWoFilesDownloadService),
);

iAltRouter.post(
  '/iAltBookWiseReportGenerate',
  handler(iAltBookWiseReportGenerateControler),
);
iAltRouter.post('/getComplexity', handler(getComplexityController));
iAltRouter.post('/createComplexity', handler(createComplexityController));
iAltRouter.post('/updateComplexity', handler(updtaeComplexityController));

iAltRouter.post(
  '/iAltDeleteJobAuditHistory',
  handler(iAltDeleteJobAuditHistoryControler),
);

iAltRouter.post('/getPlaceholder', handler(getPlaceholderController));
iAltRouter.post('/createPlaceholder', handler(createPlaceholderController));
iAltRouter.post('/updatePlaceholder', handler(updtaePlaceholderController));
// Blob service changes
iAltRouter.post('/document/checkin', handler(checkin));
iAltRouter.post(
  '/document/ZIPDownloadBlobFolder',
  handler(ZIPDownloadBlobFolder),
);
iAltRouter.get('/document/download', handler(downloadFile));
iAltRouter.post(
  '/iAltZIPDownloadBlobFolder',
  handler(iAltZIPDownloadBlobFolder),
);
iAltRouter.post('/tandeIntegration', handler(tandeIntegrationController));

// Query modal
iAltRouter.post('/createiAltQuery', handler(createiAltQueryController));

// Auto Job Failure Report
iAltRouter.post('/queueTriggerLog', handler(queueTriggerLogController));
iAltRouter.post(
  '/autoJobFailedRetrigger',
  handler(autoJobFailedRetriggerController),
);

// Auto Job Failure Report
iAltRouter.post('/acknowledgmentLog', handler(acknowledgmentLogController));
iAltRouter.post('/ackFailedRetrigger', handler(ackFailedRetriggerController));
iAltRouter.post(
  '/getiAltComplexityXlReport',
  handler(getiAltComplexityXlReport),
);
iAltRouter.post('/checkPIIExists', handler(checkPIIExistsController));
iAltRouter.post('/getiAltQueryData', handler(getiAltQueryDataController));

export default iAltRouter;
