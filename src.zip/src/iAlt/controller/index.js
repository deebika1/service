/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import Excel from 'excel4node';
import imageToBase64 from 'image-to-base64';
import Jimp from 'jimp';
import { fileURLToPath } from 'url';
import { join } from 'path';
import moment from 'moment';
import { ElseVierReports } from '../reportColumn.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);

import sharp from 'sharp';

import {
  startProcessService,
  getIncomingChapters,
  deleteIncomingChapters,
  incomingOperations,
  getiAltTaskListService,
  claimActionPreService,
  claimActionService,
  viewActionPreService,
  viewActionService,
  saveActionPreService,
  saveActionService,
  cancelActionPreService,
  cancelActionService,
  workorderCreationService,
  iAltChapterCreationService,
  iAltOnSaveChapterService,
  updateChapterCreationService,
  deleteChapterCreationService,
  addIncomingService,
  addIncomingFilesService,
  getSelectedChapterInfoService,
  updateTriggerStatus,
  getImageClassificationService,
  getAllClassificationService,
  getBookMasterFieldsList,
  getAltTextGenerationService,
  getAllPromptService,
  taskAssignService,
  getOptionListService,
  checkiAltAvailabilityService,
  createBookCode,
  retreiveBookFilesService,
  getBookMasterDataList,
  _deleteBookMasterDatas,
  getiAltChapterListService,
  updateTriggerStatusOnService,
  directSaveActionPreService,
  directSaveActionService,
  checkAssignedTaskService,
  getChapterMasterList,
  updateAltTextGenerationService,
  getBookListByIdForPmService,
  getiAltReportDataList,
  getiAltJobsDataList,
  getiAltDispatchDataList,
  getiAltBookwiseList,
  getiAltJobsOverallInflowReport,
  getiAltJobsOverallDispatchReport,
  getExportExcelData,
  reAltTextGenerationService,
  getReportOptionListService,
  getiAltWIPReportTwoService,
  getiAltWIPChapterReportService,
  getTaskComplexityService,
  getiAltAssetTranceferDataList,
  updateAndNextService,
  getiAltBookWiseReportService,
  getiAltChapterWiseReportService,
  getiAltImageWiseReportService,
  getDashboardReportOptionListService,
  getDashboardDataService,
  getImageCountInfoService,
  getAllImageIdByBook,
  getAllImageIdByChapter,
  taskAssignForTLService,
  iAltAutoJobCreationService,
  getIncomingChaptersByType,
  getiAltSignalAuditService,
  iAltJobSummaryRetriggerService,
  altTextGenerationService,
  getiAltSignalAuditHistoryService,
  getSignalAuidtInfo,
  ialtSignalLogHistory,
  ialtSignalLogService,
  rejectActionPreService,
  rejectActionService,
  iAltDirectDespatchService,
  iAltJobCreationClientPIIService,
  iAltManulWoFilesDownloadService,
  iAltBookWiseReportGenerateService,
  getComplexityService,
  updateComplexityService,
  createComplexityService,
  iAltDeleteJobAuditHistoryService,
  iAltDirectDespatchWithExcelService,
  _getiAltPlaceholder,
  getiAltFormattedName,
  getPlaceholderService,
  updatePlaceholderService,
  createPlaceholderService,
  tandeIntegrationService,
  getiAltWIPDataList,
  getiAltJobsOverallWIPReport,
  createiAltQueryService,
  queueTriggerLogService,
  autoJobFailedRetriggerService,
  acknowledgmentLogService,
  ackFailedRetriggerService,
  getiAltBookDetailList,
  getExportExcelDataForBook,
  getiAltJobsOverallYTSReport,
  getiAltYTSDataList,
  checkPIIExistsService,
  getiAltQueryDataService,
  getiAltJobsOverallQueryReport,
} from '../service/index.js';
import {
  _DeleteFilesInBlobFolder,
  _download,
  _upload,
} from '../../modules/utils/azure/index.js';
import { removeFile } from '../../modules/utils/custom/io.js';
import {
  sendMessageToSQSService,
  uploadFileToS3Service,
  listInBucketsService,
} from '../service/sqsListener.js';
import { getFolderStructureForIalt } from '../../modules/utils/wmsFolder/index.js';
import { query } from '../../database/postgres.js';
// import { altextGenerationJobService } from '../service/elseVier/altTextJobProcess.js';

export const triggerIaltWorkflowController = async (req, res) => {
  try {
    const payload = req.body;
    const chapterLists = await getIncomingChaptersByType(payload);
    if (chapterLists.length) {
      payload.chapterLists = chapterLists.filter(item => !item.istriggered);
      // start activity process
      const promises = [];
      payload.chapterLists.forEach(item => {
        payload.fileId = item.woincomingfileid;
        payload.fileuuid = item.fileuuid;
        promises.push(startProcessService(payload));
      });

      // to be deleted
      // const responseOfCalls = makeApiCalls(payload);
      // end activity process
      // update trigger status for each file
      const fileIds = payload.chapterLists.map(item => item.woincomingfileid);
      await updateTriggerStatus(fileIds);
      await updateTriggerStatusOnService(payload.workorderId);
      res
        .status(200)
        .json({ status: true, message: 'Wf triggered successfully' });
    } else {
      res
        .status(400)
        .send({ message: 'File details not found for the workorder' });
    }
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

const makeApiCalls = async (payload, batchSize = 2) => {
  const responses = [];
  let data = payload.chapterLists;
  for (let i = 0; i < data.length; i += batchSize) {
    payload.fileId = data[i].woincomingfileid;
    payload.fileuuid = data[i].fileuuid;
    const batch = data.slice(i, i + batchSize);
    const batchResponses = await Promise.all(
      batch.map(async () => {
        try {
          const res = startProcessService(payload);
          if (res.status) {
            return res.status;
          } else {
            return false;
          }
        } catch (error) {
          return false;
        }
      }),
    );
    responses.push(...batchResponses);
    await new Promise(resolve => setTimeout(resolve, 200)); // Adding delay to avoid overwhelming the server
  }

  // update trigger status for each file
  const fileIds = payload.chapterLists.map(item => item.woincomingfileid);
  await updateTriggerStatus(fileIds);
  return responses;
};

export const _triggerIaltWorkflowController = async payload => {
  return new Promise(async (resolve, reject) => {
    const { isSignalTrigger } = payload;
    try {
      let chapterLists = await getIncomingChaptersByType(payload);
      if (chapterLists.length) {
        payload.chapterLists = chapterLists.filter(item => !item.istriggered);
        // start activity process
        const promises = [];
        payload.chapterLists.forEach(item => {
          payload.fileId = item.woincomingfileid;
          payload.fileuuid = item.fileuuid;
          promises.push(startProcessService(payload));
        });

        // to be deleted
        // const responseOfCalls = makeApiCalls(payload);
        // end activity process
        // update trigger status for each file
        const fileIds = payload.chapterLists.map(item => item.woincomingfileid);
        await updateTriggerStatus(fileIds);
        await updateTriggerStatusOnService(payload.workorderId);
        resolve({ status: true, message: 'Wf triggered successfully' });
      } else {
        if (isSignalTrigger) {
          resolve({
            status: false,
            message: 'File details not found for the workorder',
          });
        } else {
          reject({
            status: false,
            message: 'File details not found for the workorder',
          });
        }
      }
    } catch (error) {
      reject({ error, message: error?.message });
    }
  });
};
// start the activity trigger process
// const startActivityProcess = payload => {
// payload.chapterLists.forEach(async item => {
//   payload.fileId = item.woincomingfileid;
//   payload.fileuuid = item.fileuuid;
//   await startProcessService(payload);
// });
// };
// get task list
export const getiAltTaskListController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltTaskListService(payload);
    res.status(200).json(result);
    // res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get chapter list
export const getiAltChapterListController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltChapterListService(payload);
    res.status(200).json(result);
    // res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// get book master datas
export const getBookMasterDatas = async (req, res) => {
  try {
    const payload = req.body;
    let chapterLists = '';
    chapterLists = await getBookMasterDataList(payload);
    res.status(200).json(chapterLists);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};
//get ialt xl sheet report start

export const getiAltXlReport = async (req, res) => {
  try {
    // const { reportName, bookId } = req.body;
    if (req.body.customerName === 'T_&_F_Publisher') {
      req.body.customerName = 'T AND F';
    }
    if (req.body.customerName === 'De_Gruyter') {
      req.body.customerName = 'Elsevier';
    }
    const payload = req.body;
    const categoryResponse = await query(
      `select category from ialt_books where bookid = ${payload.bookId}`,
    );
    payload.bookCategory = categoryResponse[0].category;
    const files = await getAllImageIdByChapter(req.body);
    let data = await getXlReportData(req.body, files);
    const result = await sendExcelFileIalt(data, payload);
    res.setHeader('Content-Disposition', 'attachment; filename="output.xlsx"');
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    res.send(result);
  } catch (err) {
    res.status(400).send({ err });
  }
};

export const getXlReportData = async (payload, files) => {
  const images = await getExportExcelData(payload, files);
  let arrayOfObjects = images.data.map(obj => {
    let data = obj;
    let updatedOn =
      data.updatedOn !== undefined ? new Date(data.updatedOn) : null;
    let formattedDate =
      updatedOn !== null
        ? `${String(updatedOn.getDate()).padStart(2, '0')}-${String(
            updatedOn.getMonth() + 1,
          ).padStart(2, '0')}-${updatedOn.getFullYear()}`
        : '';

    return {
      ...data,
      // id: data._id.toString(),
      updatedOn: data.updatedOn != undefined ? formattedDate : '',
      // long_description:
      //   data.long_descriptionedit != undefined ? data.long_descriptionedit : '',
      // short_description:
      //   data.short_descriptionedit != undefined
      //     ? data.short_descriptionedit
      //     : '',
    };
  });
  arrayOfObjects = arrayOfObjects.map(
    ({ _id, __v, project_id, id, updatedBy, ...rest }) => rest,
  );

  // Use map() to capitalize keys of objects in the array
  // arrayOfObjects = arrayOfObjects.map(obj => capitalizeKeys(obj));

  if (arrayOfObjects.length == 0 && files.length > 0) {
    throw new 'Images not found'();
  }
  return { arrayOfObjects, images };
};

function capitalizeKeys(obj) {
  const newObj = {};
  for (let key in obj) {
    newObj[key.charAt(0).toUpperCase() + key.slice(1)] = obj[key];
  }
  return newObj;
}

export const sendExcelFileIalt = async (data, payload) => {
  try {
    // Create a new Excel instance
    const {
      // reportName,
      customerName,
      bookName,
      chapterName,
      duName,
      stageName,
      type,
      reportType,
      customerId,
      wfId,
      workorderId,
      bookCategory,
    } = payload;

    const wb = new Excel.Workbook();
    const ws = wb.addWorksheet('Sheet 1');

    let reportColumns = data.images.setting.columns;
    // if (type == 'despatch') {
    //   reportColumns = ElseVierReports.filter(
    //     item =>
    //       item.id !== 'short_description_accuracy' &&
    //       item.id !== 'long_description_accuracy' &&
    //       item.id !== 'average',
    //   );
    // }

    reportColumns.map(list => {
      ws.cell(1, list.column)
        .string(list.name)
        .style({ font: { bold: true } });
      if (list.width) {
        ws.column(list.column).width = list.width;
      }
    });

    // Populate data
    const imagePromises = data.arrayOfObjects.map(async (item, index) => {
      reportColumns.map(list => {
        let value = item[list.id];
        let alignmentsdata = {};
        if (list.horizontal) {
          alignmentsdata.horizontal = list?.horizontal;
        }
        if (list.vertical) {
          alignmentsdata.vertical = list?.vertical;
        }
        if (list.wrapText) {
          alignmentsdata.wrapText = list?.wrapText;
        }
        ws.cell(index + 2, list.column)
          .string(value)
          .style({ alignment: alignmentsdata });
      });

      ws.row(index + 2).setHeight(200);
      ws.column(1).setWidth(40);
      ws.column(2).setWidth(25);
      // Download and convert image to base64
      let imageData;
      if (item.thumbnailurl || item.imageurl) {
        const imageUrl = item.thumbnailurl ? item.thumbnailurl : item.imageurl;
        imageData = await downloadAndConvertImage(imageUrl);
      } else {
      }
      if (imageData) {
        // Add base64 image to the Excel sheet
        const resizedImageData = await resizeImage(imageData);

        ws.addImage({
          image: Buffer.from(resizedImageData, 'base64'),
          type: 'picture',
          width: 60,
          height: 60,
          position: {
            type: 'oneCellAnchor',
            from: {
              col: reportColumns.findIndex(list => list.id == 'Image') + 1,
              colOff: 0,
              row: index + 2,
              rowOff: 0,
            },
          },
        });
      }
    });

    await Promise.all(imagePromises);

    let tempFilePath = join(__filename, '../../../../');
    const temp1 = `${tempFilePath}tempFolder`;

    if (!fs.existsSync(temp1)) {
      fs.mkdirSync(temp1, { recursive: true });
      console.log('Folder created successfully!');
    }
    const excelFilePath = 'tempFolder/output.xlsx';

    const filePathPromise = new Promise(async (resolve, reject) => {
      await wb.write(excelFilePath, async (err, data) => {
        if (err) {
          console.error('Error writing Excel file:', err);
          reject('Error generating Excel file');
        } else {
          console.log(`Excel file saved at: ${excelFilePath}`);

          let outputFilePath = join(__filename, '../../../../').replace(
            /\\/g,
            '/',
          );

          // Get report name
          let name = '';

          const sql = `select reportname_placeholder from wms_ialt_mst_reportname where customerid = ${customerId} 
          and wfid= ${wfId} and type = '${reportType}' and isactive = true`;
          const result = await query(sql);
          console.log(result, 'result');

          let newDate = moment(new Date()).format('MMDDYYYYhhmmss');

          if (result.length > 0) {
            const placeHolder = await _getiAltPlaceholder(payload);
            let updatedPlaceholder = { ...placeHolder[0], newDate }; // Corrected line
            name = getiAltFormattedName(
              result[0]?.reportname_placeholder,
              updatedPlaceholder,
            );

            console.log('report name', name);
            name = name.includes('}') ? 'iAlt_alttext.xlsx' : name;
            name = name.replaceAll(/[^a-zA-Z0-9./-]/g, '_');
            if (customerId == 14) {
              name = name.replace(/_(CHP|Chapter|chapt)[_\s]?/i, '_Ch');
              name = name.replace(/([^_])(?=alttext)/, '$1_');
              name = name.replace(/(\_ch)(\d)(\_)/i, '$10$2$3');
            }
            if (bookCategory === 'vtex') {
              name = name.replace(/(chp|CH)(\d+)/i, '$2');
            }
          } else {
            throw new Error('Report name missing');
          }
          const fileDetails = {
            tempFilePath: `${outputFilePath}${excelFilePath}`,
            name: name,
          };
          let basePath = ``;
          if (!payload.bookBasePath) {
            const folderPathData = {
              type:
                chapterName && bookName && stageName
                  ? 'ialt_book_chapter_stage_output'
                  : 'du_common',
              duName: duName
                ?.replace(/['’]/gi, '')
                .replace(/[^a-zA-Z0-9]/gi, ' ')
                .replace(/\s+/gi, '_'),
              customerName:
                customerName == 'T_&_F_Publisher' ? 'T AND F' : customerName,
              bookName: bookName
                ?.replace(/['’]/gi, '')
                .replace(/[^a-zA-Z0-9]/gi, ' ')
                .replace(/\s+/gi, '_'),
              chapterName: chapterName
                ?.replace(/['’]/gi, '')
                .replace(/[^a-zA-Z0-9]/gi, ' ')
                .replace(/\s+/gi, '_'),
              stageName: stageName
                ?.replace(/['’]/gi, '')
                .replace(/[^a-zA-Z0-9]/gi, ' ')
                .replace(/\s+/gi, '_'),
            };

            basePath = await getFolderStructureForIalt(folderPathData);
          } else {
            basePath = payload.bookBasePath;
          }
          if (payload?.reportFileType) {
            basePath = `${basePath}${payload.reportFileType}/`;
          }
          basePath = basePath.replaceAll(/[^a-zA-Z0-9./-]/g, '_');
          if (basePath.startsWith('/okm:root/'))
            basePath = basePath.replace('/okm:root/', '');
          if (basePath.startsWith('/okm_root/'))
            basePath = basePath.replace('/okm_root/', '');
          const uploadRes = await _upload(fileDetails, basePath);
          removeFile(fileDetails.tempFilePath);
          resolve(uploadRes.fullPath);
          console.log(uploadRes, 'upload');

          // Read the saved file content
          // fs.readFile(excelFilePath, (readErr, data) => {
          //   if (readErr) {
          //     reject(readErr);
          //   } else {
          //     resolve(data);
          //   }
          // });
        }
      });
    });
    const savedFilePath = await filePathPromise;
    // Optionally, send the file path as a response or return it
    return savedFilePath;
  } catch (error) {
    console.log(error, 'generate report ialt');
    reject(error);
  }
};

export const resizeImage = async imageData => {
  try {
    const buffer = Buffer.from(imageData, 'base64');

    return await sharp(buffer)
      .resize(300, 300, {
        fit: 'inside',
        withoutEnlargement: true,
      })
      .jpeg()
      .toBuffer();
  } catch (error) {
    console.error('Image processing error:', error);
    const resizedImage = await sharp(Buffer.from(imageData, 'base64'))
      .resize({
        width: 100,
        height: 100,
        fit: 'cover',
      })
      .toBuffer();
    return resizedImage;
  }
};

export const downloadAndConvertImage = url => {
  return new Promise(async (resolve, reject) => {
    try {
      const imageData = await imageToBase64(url);
      resolve(imageData);
    } catch (error) {
      console.error(`Error downloading image from ${url}:`, error.message);
      resolve(null);
    }
  });
};

//xl sheet report end

// get chapter master datas
export const getChapterMasterDatas = async (req, res) => {
  try {
    const payload = req.body;
    let chapterLists = '';
    chapterLists = await getChapterMasterList(payload);
    res.status(200).json(chapterLists);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};
//get report list
export const getiAltReportData = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltReportDataList(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};
//get inflow summary
export const getiAltJobsData = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltJobsDataList(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};
//get dispatch data
export const getiAltDispatchData = async (req, res) => {
  try {
    console.log('DispatchData');
    const payload = req.body;
    const result = await getiAltDispatchDataList(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};
//get WIP data
export const getiAltWIPData = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltWIPDataList(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};

export const getiAltYTSData = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltYTSDataList(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};

export const getiAltBookDetails = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltBookDetailList(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};

//get bookwise financial data
export const getiAltBookwise = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltBookwiseList(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};

// get iAlt overall data
export const getiAltJobsOverallData = async (req, res) => {
  try {
    const payload = req.body;
    let result;
    if (payload.reportType === 'inflow') {
      result = await getiAltJobsOverallInflowReport(payload);
    } else if (payload.reportType === 'dispatch') {
      result = await getiAltJobsOverallDispatchReport(payload);
    } else if (payload.reportType === 'wipReport') {
      result = await getiAltJobsOverallWIPReport(payload);
    } else if (payload.reportType === 'ytsReport') {
      result = await getiAltJobsOverallYTSReport(payload);
    } else if (payload.reportType === 'queryReport') {
      result = await getiAltJobsOverallQueryReport(payload);
    }
    res.status(200).json({ status: true, result });
  } catch (err) {
    console.error('Error in getiAltJobsOverallData:', err);
    res.status(400).json({
      status: false,
      error: err.message || 'An error occurred while generating the report',
    });
  }
};

// delete book masterJ

export const deleteBookMasterDatas = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _deleteBookMasterDatas(payload);
    res.status(200).json({ status: true, data: result });
  } catch (err) {
    res.status(400).send({ err });
  }
};

// Get book master fields
export const getBookMasterFields = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getBookMasterFieldsList(payload);
    res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error });
  }
};

//ialt wip reports start
export const getiAltWIPReportTwo = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltWIPReportTwoService(payload);
    res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getiAltWIPChapterReport = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltWIPChapterReportService(payload);
    res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error });
  }
};

//ialt wip reports end

// create book code master

export const createiAltBookCode = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createBookCode(payload);
    res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error });
  }
};

// retreive book files for chapter creation
export const retreiveBookFiles = async (req, res) => {
  try {
    const payload = req.body;
    const result = await retreiveBookFilesService(payload);

    res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error });
  }
};

// General actions Claim / View
export const generalActionProcessController = async (req, res) => {
  try {
    const payload = req.body;
    const { type } = req.query;
    const systemInfo = {
      systemIP: requestIp.getClientIp(req),
      publicIP: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
      ...JSON.parse(req.headers.systemdetail ? req.headers.systemdetail : {}),
    };
    payload.systemInfo = systemInfo;
    let responseObj = { status: true, message: '' };
    switch (type) {
      case 'Claim':
        responseObj = await claimActionPreService(payload);
        responseObj = await claimActionService(payload);
        break;
      case 'TaskView':
        responseObj = await viewActionPreService(payload);
        responseObj = await viewActionService(payload);
        break;
      default:
        break;
    }
    res.status(200).json(responseObj);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// Workflow actions Claim / View
export const workflowActionProcessController = async (req, res) => {
  try {
    const { type } = req.query;
    const payload = req.body;
    const systemInfo = {
      systemIP: requestIp.getClientIp(req),
      publicIP: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
      ...JSON.parse(req.headers.systemdetail),
    };
    payload.systemInfo = systemInfo;
    let responseObj = { status: true, message: '' };
    switch (type) {
      case 'Save':
        responseObj = await saveActionPreService(payload);
        responseObj = await saveActionService(payload);
        break;
      case 'Cancel':
        responseObj = await cancelActionPreService(payload);
        responseObj = await cancelActionService(payload);
        break;
      case 'DirectSave':
        responseObj = await directSaveActionPreService(payload);
        responseObj = await directSaveActionService(payload);
        break;
      case 'Reject':
        responseObj = await rejectActionPreService(payload);
        responseObj = await rejectActionService(payload);
        break;
      default:
        throw new Error('Action not found');
    }
    res.status(200).json(responseObj);
  } catch (error) {
    res
      .status(400)
      .send({ status: false, message: error.message ? error.message : error });
  }
};

// workorder creation
// export const workorderCreationController = async (req, res) => {
//   try {
//     const payload = req.body;
//     const response = await workorderCreationService(payload);
//     res.status(200).json(response);
//   } catch (error) {
//     res.status(400).send({ error, message: error?.message });
//   }
// };

export const workorderCreationController = async (req, res) => {
  try {
    const payload = req.body;
    const responses = await Promise.all(payload.map(workorderCreationService));
    console.log(responses, 'responses');

    res.status(200).json(responses);
  } catch (error) {
    const errorMessage = error?.message || error || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

//chapter creation

export const iAltChapterCreationController = async (req, res) => {
  try {
    const payload = req.body;
    const responses = await Promise.all(
      payload.map(iAltChapterCreationService),
    );
    // const response = await iAltChapterCreationService(payload);
    res.status(200).json(responses);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const updateChapterCreationController = async (req, res) => {
  try {
    const payload = req.body;
    let response = await updateChapterCreationService(payload);
    res.status(200).json(response);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const deleteChapterController = async (req, res) => {
  try {
    const payload = req.body;
    let response = await deleteChapterCreationService(payload);
    res.status(200).json(response);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const iAltTriggerChapterController = async (req, res) => {
  try {
    const payload = req.body;
    const responses = await Promise.all(payload.map(iAltOnSaveChapterService));
    const pii = payload && payload[0] ? payload[0].pii : undefined;
    const totalChapterCount = payload && payload[0] ? payload[0].imagecount : 0;

    if (totalChapterCount) {
      const sql = `update wms_workorder set totalchaptercount =${totalChapterCount} where workorderid = ${payload[0].workorderid}`;
      await query(sql);
    }
    if (pii) {
      const signalAuditInfo = await getSignalAuidtInfo(pii);
      const { signalauditid: signalAuditId, signalinfo: ackMsgInfo } =
        signalAuditInfo;
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: 'PDF extraction verified and workflow triggered successfully',
        message: 'PDF extraction verified and workflow triggered successfully',
        status: 'Success',
        processStatusId: 27,
      };
      await ialtSignalLogHistory(logHisPayload);
    }
    // const response = await iAltChapterCreationService(payload);
    res.status(200).json(responses);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const iAltIncomingFilesOperationsController = async (req, res) => {
  try {
    const payload = req.body;
    let chapterLists = '';
    chapterLists = await incomingOperations(payload);
    res.status(200).json(chapterLists);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};
export const getiAltAssetReportDataController = async (req, res) => {
  try {
    const payload = req.body;
    let chapterLists = '';
    chapterLists = await getiAltAssetTranceferDataList(payload);
    res.status(200).json(chapterLists);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const getiAltIncomingChaptersController = async (req, res) => {
  try {
    const payload = req.body;
    const chapterLists = await getIncomingChapters(payload);
    let files = [];
    let filesList = [];
    chapterLists.map(list => {
      files.push({ id: list.fileuuid });
    });

    const getImgServices = await getImageClassificationService(files);
    if (getImgServices.data && getImgServices.data.length > 0) {
      chapterLists.forEach((item, index) => {
        const sItem = getImgServices.data[index];
        if (item.fileuuid === sItem._id) {
          filesList.push({ ...item, ...sItem });
        }
      });
    }
    res.status(200).json(filesList);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

// add incoming files
export const addIncomingController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await addIncomingService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// add incoming files
export const addIncomingFilesController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await addIncomingFilesService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get task list
export const getSelectedChapterInfoController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getSelectedChapterInfoService(payload);
    res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get image classification
export const getImageClassificationController = async (req, res) => {
  try {
    const { files } = req.body;
    const response = await getImageClassificationService(files);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get all classifications
export const getAllClassificationController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getAllClassificationService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get alt text generation
export const getAltTextGenerationController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getAltTextGenerationService(payload);
    const getComplexInfo = await getTaskComplexityService(payload);
    let finalResponse = [];
    if (response.data.length) {
      response.data.forEach((item, index) => {
        getComplexInfo.forEach(sItem => {
          if (item._id === sItem.fileuuid) {
            finalResponse.push({
              ...item,
              ...sItem,
            });
          }
        });
      });
    }
    res.status(200).json({ status: true, data: finalResponse });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// update alt text generation
export const updateAltTextGenerationController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await updateAltTextGenerationService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// re alt text generation
export const reAltTextGenerationController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await reAltTextGenerationService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get all prompt
export const getAllPromptController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getAllPromptService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get assigned task list
export const checkAssignedTaskController = async (req, res) => {
  try {
    const { workorderId } = req.body;
    const response = await checkAssignedTaskService(workorderId);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
//  this function will assign the task to selected user
export const taskAssignController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await taskAssignService(payload);
    res.status(200).json({ status: true, message: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
//  this function will assign the task to selected user
export const taskAssignForTLController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await taskAssignForTLService(payload);
    res.status(200).json({ status: true, message: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// check availability isbn validation
export const checkiAltAvailabilityController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await checkiAltAvailabilityService(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

//  this function will get the option list
export const getOptionListController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getOptionListService(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
//  this function will get the option list
export const getReportOptionListController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getReportOptionListService(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get task list
export const getBookListByIdForPmController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getBookListByIdForPmService(payload);
    res.status(200).json(result);
    // res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// export const triggerIaltWorkflowController = async (req, res) => {
//   try {
//     const payload = req.body;
//     const result = await triggerIaltWorkflowService(payload);
//     res.status(200).json({ status: true, message: result });
//   } catch (error) {
//     res.status(400).send({ error, message: error?.message });
//   }
// };

//  this function will update the task status
export const updateAndNextController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await updateAndNextService(payload);
    res.status(200).json({ status: true, message: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get the bookwise wise report
export const getiAltBookWiseReportController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltBookWiseReportService(payload);
    res.status(200).json(result);
    // res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get the chapter wise report
export const getiAltChapteriseReportController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltChapterWiseReportService(payload);
    res.status(200).json(result);
    // res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// get the image wise report
export const getiAltImageWiseReportController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltImageWiseReportService(payload);
    res.status(200).json(result);
    // res.status(200).json({ status: true, data: result });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
//  this function will get the dashboard report option list
export const getDashboardReportOptionListController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getDashboardReportOptionListService(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
//  this function will get the dashboard data
export const getDashboardDataController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getDashboardDataService(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
//  this function will get the image count info
export const getImageCountInfoController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await getImageCountInfoService(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// this function used to send message to SQS
export const sendMessageToSQSController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await sendMessageToSQSService(payload);
    res.status(200).json({ status: true, message: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// this function will upload file to S3
export const uploadFileToS3Controller = async (req, res) => {
  try {
    const payload = req.body;
    const response = await uploadFileToS3Service(payload);
    res.status(200).json({ status: true, message: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const listInBucketsController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await listInBucketsService(payload);
    res.status(200).json({ status: true, message: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
//Auto workorder creation controller
export const iAltAutoJobCreationController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await iAltAutoJobCreationService(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// get job summary report datas
export const getiAltSignalAuditController = async (req, res) => {
  try {
    const payload = req.body;
    let reportLists = '';
    reportLists = await getiAltSignalAuditService(payload);
    res.status(200).json(reportLists.response);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

//ialt jobsummary re-trigger
export const iAltJobSummaryRetriggerController = async (req, res) => {
  try {
    const payload = req.body;
    const reportLists = await iAltJobSummaryRetriggerService(payload);
    const { signalAuditId } = payload;
    let logPayload = {
      signalAuditId,
      response: 'Job retriggered successfully',
      updateType: 'inprogress',
    };
    await ialtSignalLogService(logPayload, 'Update');
    res.status(200).json(reportLists.response);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

// export const altextGenerationJobController = async (req, res) => {
//   try {
//     const payload = req.body;
//     // const response = await altTextGenerationService(payload); need to check mani anna
//     const response = await altextGenerationJobService(payload);
//     res.status(200).json(response);
//   } catch (error) {
//     res.status(400).send({ error, message: error?.message });
//   }
// };
// // export const journalJobProcessController = async (req, res) => {
// //   try {
// //     const payload = req.body;
// //     const response = await journalJobService(payload);
// //     res.status(200).json(response);
// //   } catch (error) {
// //     res.status(400).send({ error, message: error?.message });
// //   }
// // };
export const getiAltSignalAuditHistoryController = async (req, res) => {
  try {
    const payload = req.body;
    const reportLists = await getiAltSignalAuditHistoryService(payload);
    res.status(200).json(reportLists);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const _getFolderStructureForIalt = async (req, res) => {
  try {
    const payload = req.body;
    const path = await getFolderStructureForIalt(payload);
    res.status(200).json(path);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const iAltDirectDespatch = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAltDirectDespatchService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const iAltJobCreationClientPIIControler = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAltJobCreationClientPIIService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const iAltManulWoFilesDownloadControler = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAltManulWoFilesDownloadService(req, res);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const iAltBookWiseReportGenerateControler = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAltBookWiseReportGenerateService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const getComplexityController = async (req, res) => {
  try {
    const result = await getComplexityService();
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const createComplexityController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createComplexityService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const updtaeComplexityController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateComplexityService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const iAltDeleteJobAuditHistoryControler = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAltDeleteJobAuditHistoryService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const iAltDirectDespatchWithExcel = async (req, res) => {
  try {
    const payload = req.body;
    const result = await iAltDirectDespatchWithExcelService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const getPlaceholderController = async (req, res) => {
  try {
    const result = await getPlaceholderService();
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const createPlaceholderController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createPlaceholderService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const updtaePlaceholderController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updatePlaceholderService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const tandeIntegrationController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await tandeIntegrationService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const createiAltQueryController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createiAltQueryService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error });
  }
};

export const queueTriggerLogController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await queueTriggerLogService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ errorMessage });
  }
};

export const autoJobFailedRetriggerController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await autoJobFailedRetriggerService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ errorMessage });
  }
};

export const acknowledgmentLogController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await acknowledgmentLogService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ errorMessage });
  }
};

export const ackFailedRetriggerController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await ackFailedRetriggerService(payload);
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ errorMessage });
  }
};

export const getiAltComplexityXlReport = async (req, res) => {
  try {
    // const { reportName, bookId } = req.body;
    if (req.body.clientName === 'T_&_F_Publisher') {
      req.body.clientName = 'T AND F';
    }
    const payload = req.body;
    payload.customerName = payload.clientName;
    const files = await getAllImageIdByBook(req.body);
    let data = await getXlReportDataforTitle(req.body, files);
    const result = await sendExcelFileIaltforBook(data, payload);
    res.setHeader('Content-Disposition', 'attachment; filename="output.xlsx"');
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    res.send(result);
  } catch (err) {
    res.status(400).send({ err });
  }
};

export const getXlReportDataforTitle = async (payload, files) => {
  const images = await getExportExcelDataForBook(payload, files);
  let arrayOfObjects = images.data.map(obj => {
    let data = obj;
    let updatedOn =
      data.updatedOn !== undefined ? new Date(data.updatedOn) : null;
    let formattedDate =
      updatedOn !== null
        ? `${String(updatedOn.getDate()).padStart(2, '0')}-${String(
            updatedOn.getMonth() + 1,
          ).padStart(2, '0')}-${updatedOn.getFullYear()}`
        : '';

    return {
      ...data,
      updatedOn: data.updatedOn != undefined ? formattedDate : '',
    };
  });
  arrayOfObjects = arrayOfObjects.map(
    ({ _id, __v, project_id, id, updatedBy, ...rest }) => rest,
  );

  if (arrayOfObjects.length == 0 && files.length > 0) {
    throw new 'Images not found'();
  }
  return { arrayOfObjects, images };
};

export const sendExcelFileIaltforBook = async (data, payload) => {
  try {
    // Create a new Excel instance
    const { clientName, bookName, chapterName, duName, stageName } = payload;

    const wb = new Excel.Workbook();
    const ws = wb.addWorksheet('Sheet 1');

    let reportColumns = data.images.setting.columns;
    reportColumns.map(list => {
      ws.cell(1, list.column)
        .string(list.name)
        .style({ font: { bold: true } });
      if (list.width) {
        ws.column(list.column).width = list.width;
      }
    });
    const imagePromises = data.arrayOfObjects.map(async (item, index) => {
      reportColumns.map(list => {
        let value = item[list.id];
        let alignmentsdata = {};
        if (list.horizontal) {
          alignmentsdata.horizontal = list?.horizontal;
        }
        if (list.vertical) {
          alignmentsdata.vertical = list?.vertical;
        }
        if (list.wrapText) {
          alignmentsdata.wrapText = list?.wrapText;
        }
        ws.cell(index + 2, list.column)
          .string(value)
          .style({ alignment: alignmentsdata });
      });

      ws.row(index + 2).setHeight(200);
      ws.column(1).setWidth(40);
      ws.column(2).setWidth(25);
      let imageData;
      if (item.thumbnailurl || item.imageurl) {
        const imageUrl = item.thumbnailurl ? item.thumbnailurl : item.imageurl;
        imageData = await downloadAndConvertImage(imageUrl);
      } else {
      }
      if (imageData) {
        const resizedImageData = await resizeImage(imageData);

        ws.addImage({
          image: Buffer.from(resizedImageData, 'base64'),
          type: 'picture',
          width: 60,
          height: 60,
          position: {
            type: 'oneCellAnchor',
            from: {
              col: reportColumns.findIndex(list => list.id == 'Image') + 1,
              colOff: 0,
              row: index + 2,
              rowOff: 0,
            },
          },
        });
      }
    });

    await Promise.all(imagePromises);

    let tempFilePath = join(__filename, '../../../../');
    const temp1 = `${tempFilePath}tempFolder`;

    if (!fs.existsSync(temp1)) {
      fs.mkdirSync(temp1, { recursive: true });
      console.log('Folder created successfully!');
    }
    const excelFilePath = 'tempFolder/output.xlsx';

    const filePathPromise = new Promise(async (resolve, reject) => {
      await wb.write(excelFilePath, async (err, data) => {
        if (err) {
          console.error('Error writing Excel file:', err);
          reject('Error generating Excel file');
        } else {
          console.log(`Excel file saved at: ${excelFilePath}`);

          let outputFilePath = join(__filename, '../../../../').replace(
            /\\/g,
            '/',
          );

          // Get report name
          let name = '';
          name = `${bookName}_category.xlsx`;

          const fileDetails = {
            tempFilePath: `${outputFilePath}${excelFilePath}`,
            name: name,
          };
          let basePath = ``;
          if (!payload.bookBasePath) {
            const folderPathData = {
              type: 'du_common',
              duName: 'iAlt',
              customerName:
                clientName == 'T_&_F_Publisher' ? 'T AND F' : clientName,
              bookName: bookName
                ?.replace(/['’]/gi, '')
                .replace(/[^a-zA-Z0-9]/gi, ' ')
                .replace(/\s+/gi, '_'),
              chapterName: '',
              stageName: '',
            };

            basePath = await getFolderStructureForIalt(folderPathData);
          } else {
            basePath = payload.bookBasePath;
          }
          if (payload?.reportFileType) {
            basePath = `${basePath}${payload.reportFileType}/`;
          }
          basePath = basePath.replaceAll(/[^a-zA-Z0-9./-]/g, '_');
          if (basePath.startsWith('/okm:root/'))
            basePath = basePath.replace('/okm:root/', '');
          if (basePath.startsWith('/okm_root/'))
            basePath = basePath.replace('/okm_root/', '');
          const uploadRes = await _upload(fileDetails, basePath);
          removeFile(fileDetails.tempFilePath);
          resolve(uploadRes.fullPath);
          console.log(uploadRes, 'upload');

          // Read the saved file content
          // fs.readFile(excelFilePath, (readErr, data) => {
          //   if (readErr) {
          //     reject(readErr);
          //   } else {
          //     resolve(data);
          //   }
          // });
        }
      });
    });
    const savedFilePath = await filePathPromise;
    // Optionally, send the file path as a response or return it
    return savedFilePath;
  } catch (error) {
    console.log(error, 'generate report ialt');
    reject(error);
  }
};

export const checkPIIExistsController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await checkPIIExistsService(payload);

    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ errorMessage });
  }
};

export const getiAltQueryDataController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await getiAltQueryDataService(payload);
    res.status(200).json({ status: true, result });
  } catch (err) {
    res.status(400).send({ err });
  }
};
