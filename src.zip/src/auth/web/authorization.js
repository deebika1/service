import { query } from '../../database/postgres.js';
import logger from '../../modules/utils/logs/index.js';

export const getInfo = userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = ` SELECT
      userdetails.*,
      deliveryunit.duname,
      deliveryunit.itrackduid,
      CASE WHEN check_roles.cqh THEN TRUE ELSE FALSE END AS cqh,
      CASE WHEN check_roles.duql THEN TRUE ELSE FALSE END AS duql,
      CASE WHEN check_roles.pm THEN TRUE ELSE FALSE END AS pm
  FROM
      wms_user_details userdetails
  LEFT JOIN
      org_mst_deliveryunit deliveryunit ON userdetails.duid = deliveryunit.duid
  LEFT JOIN
      (
          SELECT * FROM iquality.check_user_roles($1)
      ) AS check_roles ON TRUE
  WHERE
      userdetails.userid =$1 AND deliveryunit.isactive = true`;
      const userDetail = await query(sql, [userId]);
      if (userDetail.length) {
        const {
          username,
          duid,
          duname,
          actroleid,
          actisdefaultrole,
          skillid,
          skillname,
          roledetails,
          cqh,
          duql,
          pm,
          itrackduid,
        } = userDetail[0];
        const rolename = roledetails.map(r => r.rolename);
        const roleid = roledetails.map(r => r.roleid.toString());
        const roleIndex = actisdefaultrole.indexOf(true);
        const defaultRoleIndex =
          roleIndex !== -1 ? roleid.indexOf(actroleid[roleIndex]) : 0;
        const DUDetails = await getuserDU(userId.toUpperCase());
        const profile = {
          id: userId,
          username,
          duId: duid,
          itrackDuid: itrackduid,
          duName: duname,
          roles: {
            name: rolename,
            id: roleid,
          },
          defaultRole: {
            name: rolename[defaultRoleIndex],
            id: roleid[defaultRoleIndex],
          },
          skills: {
            name: skillid ? skillname : [],
            id: skillid || [],
          },
          iTrackRoles: {
            cqh,
            duql,
            pm,
          },
          roleDetails: roledetails,
          mappedDuList: DUDetails,
        };
        resolve(profile);
      } else {
        reject({ type: 'UserNotExist', message: `User (${userId}) not exist` });
      }
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getScreensInfo = async (req, res) => {
  const { roleId, skillId, duId, duName } = req.body;
  try {
    const screensInfo = {};
    let sql = '';
    let screens = [];
    if (duName && duName.toLowerCase() == 'ialt') {
      logger.info(duName, 'duName');
      sql = `
      select entpd.roleid,skillid,screenid,screenname,screenmappingpath,entityid,entityname,entpd.menuid,entpd.menuname,permissions::text
      from wms_entity_perm_details as entpd
      join wms_uimenu on  wms_uimenu.menuid = entpd.menuid and wms_uimenu.isactive = true
      where roleid = any($1) and (skillid IS NULL or (skillid = any($2))) AND ($3=ANY(wms_uimenu.duid) or screenmappingpath ilike '%ialt%')  and entpd.menuid is not null        
      union
      select roleid,skillid,screenid,screenname,screenmappingpath,entityid,entityname,menuid,menuname,permissions::text
      from wms_entity_perm_details 
      where roleid = any($1::bigint[]) and (skillid IS NULL or (skillid = any($2))) AND ($3=ANY(duid) or screenmappingpath ilike '%ialt%') and wms_entity_perm_details.menuid is null`;
      screens = await query(sql, [roleId, skillId, duId]);
    } else {
      sql = `
        select entpd.roleid,skillid,screenid,screenname,screenmappingpath,entityid,entityname,entpd.menuid,entpd.menuname,permissions::text
        from wms_entity_perm_details as entpd
        join wms_uimenu on  wms_uimenu.menuid = entpd.menuid and wms_uimenu.isactive = true
        where roleid = any($1) and (skillid IS NULL or (skillid = any($2))) and entpd.menuid is not null        
        union
        select roleid,skillid,screenid,screenname,screenmappingpath,entityid,entityname,menuid,menuname,permissions::text
        from wms_entity_perm_details 
        where roleid = any($1::bigint[]) and (skillid IS NULL or (skillid = any($2))) and wms_entity_perm_details.menuid is null`;
      screens = await query(sql, [roleId, skillId]);
    }

    // let sql = `SELECT * from wms_entity_perm_details where roleid = any($1) and (skillid IS NULL or (skillid = any($2)))`;

    screens.forEach(
      ({ screenname, screenid, roleid, screenmappingpath, menuid }) => {
        if (screensInfo[screenmappingpath]) {
          const { roles } = screensInfo[screenmappingpath];
          if (roles.indexOf(roleid) === -1) roles.push(roleid);
        } else {
          screensInfo[screenmappingpath] = {
            name: screenname,
            roles: [roleid],
            id: screenid,
            path: screenmappingpath,
            menuId: menuid,
          };
        }
      },
    );
    sql = `SELECT jsonb_object_agg(wms_uimenu.menuid, to_jsonb(wms_uimenu.*)) AS menu FROM wms_uimenu where isactive=true `;
    const menuList = await query(sql);
    res.send({ screensInfo, menu: menuList.length ? menuList[0].menu : {} });
  } catch (e) {
    res.status(500).send(e.message ? e.message : e);
  }
};
export const validateSuperUsr = userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select issuperuser from public.wms_user where userid=$1`;
      const superUserResp = await query(sql, [userId]);
      resolve({
        validStatus: superUserResp.length
          ? superUserResp[0].issuperuser
          : false,
      });
    } catch (e) {
      reject({ e });
    }
  });
};

export const getuserDU = userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select * from public.getuserdu($1)`;
      const superUserResp = await query(sql, [userId]);
      resolve(superUserResp);
    } catch (e) {
      reject({ e });
    }
  });
};

export const setuserDU = (userId, duID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select * from public.updateuserdu($1,$2)`;
      await query(sql, [userId, duID]);
      resolve(true);
    } catch (e) {
      reject({ e });
    }
  });
};

export const getAdminUser = (req, res) => {
  query(
    'SELECT * from wms_mst_configurationdetails where confname = $1 and isactive=true',
    ['admin'],
  )
    .then(result => {
      if (result.length) {
        const data = JSON.parse(result[0].confvalue);
        res.send(
          Buffer.from(
            JSON.stringify({ userName: data.User, Password: data.Password }),
          ).toString('base64'),
        );
      } else {
        throw new Error('No itoolsusers configured');
      }
    })
    .catch(e => {
      logger.info(e);
      res.status(400).send(e.message ? e.message : e);
    });
};

export const getElectronVersionDetails = (req, res) => {
  query(
    'SELECT * from wms_mst_configurationdetails where confname = $1 and isactive=true',
    ['ElectronVersion'],
  )
    .then(result => {
      if (result.length) {
        res.send(JSON.parse(result[0].confvalue));
      } else {
        throw new Error('No itoolsusers configured');
      }
    })
    .catch(e => {
      logger.info(e);
      res.status(400).send(e.message ? e.message : e);
    });
};

export const getScreenInfo = (req, res) => {
  const { roleId, skillId, screenId } = req.body;
  query(
    'SELECT * from wms_entity_perm_details where roleid = $1 and (skillid IS NULL or (skillid = any($2))) and screenid = $3',
    [roleId, skillId, screenId],
  )
    .then(result => {
      const entityInfo = {};
      if (result.length) {
        result.forEach(entity => {
          if (entityInfo[entity.entityid]) {
            if (entity.permissions) {
              entityInfo[entity.entityid] = mergePriviliges(
                entityInfo[entity.entityid],
                entity.permissions,
              );
            }
          } else {
            entityInfo[entity.entityid] = entity.permissions
              ? entity.permissions
              : {};
          }
        });
      }
      res.send(entityInfo);
    })
    .catch(e => {
      logger.info(e);
      res.status(400).send(e.message ? e.message : e);
    });
};

const mergePriviliges = (obj1, obj2) => {
  const obj = {};
  Object.keys(obj1).forEach(objKey => {
    if (obj[objKey] === undefined || obj[objKey] !== true)
      obj[objKey] = obj1[objKey];
  });
  Object.keys(obj2).forEach(objKey => {
    if (obj[objKey] === undefined || obj[objKey] !== true)
      obj[objKey] = obj2[objKey];
  });
  return obj;
};
