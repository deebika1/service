// import path from 'path';

export const wmsConfig = {
  okm: {
    path: '/okm:root',
    common: {
      get path() {
        return `${wmsConfig.okm.path}/Common`;
      },
    },
    base: {
      get path() {
        return `${wmsConfig.okm.path}/${process.env.OKM_BASE_DIR}`;
      },
      common: {
        get path() {
          return `${wmsConfig.okm.base.path}/Common`;
        },
      },
      du: {
        get path() {
          return `${wmsConfig.okm.base.path}/{DU_NAME}`;
        },
        common: {
          get path() {
            return `${wmsConfig.okm.base.du.path}/Common`;
          },
        },
        customer: {
          get path() {
            return `${wmsConfig.okm.base.du.path}/{CUSTOMER_NAME}`;
          },
          common: {
            get path() {
              return `${wmsConfig.okm.base.du.customer.path}/Common`;
            },
          },
          journals: {
            get path() {
              return `${wmsConfig.okm.base.du.customer.path}/journals`;
            },
            journal: {
              get path() {
                return `${wmsConfig.okm.base.du.customer.journals.path}/{JOURNAL_NAME}`;
              },
              instructions: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.journals.journal.path}/instructions`;
                },
              },
            },
          },
          wo: {
            get path() {
              return `${wmsConfig.okm.base.du.customer.path}/{WORK_ORDER_ID}`;
            },
            common: {
              get path() {
                return `${wmsConfig.okm.base.du.customer.wo.path}/Common`;
              },
              mail: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.wo.common.path}/mail`;
                },
              },
            },
            service: {
              get path() {
                return `${wmsConfig.okm.base.du.customer.wo.path}/{SERVICE_NAME}`;
              },
              common: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.wo.service.path}/Common`;
                },
                mail: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.wo.service.common.path}/mail`;
                  },
                },
              },
              stage: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.wo.service.path}/{STAGE_NAME}`;
                },
                common: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.wo.service.stage.path}/Common`;
                  },
                  graphic: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.wo.service.stage.common.path}/graphic`;
                    },
                  },
                  instructions: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.wo.service.stage.common.path}/instructions`;
                    },
                  },
                  query: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.wo.service.stage.common.path}/query/{QUERY_ID}`;
                    },
                  },
                },
                iteration: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.wo.service.stage.path}/{STAGE_ITERATION}`;
                  },
                  common: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.path}/Common`;
                    },
                    mail: {
                      get path() {
                        return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.common.path}/mail`;
                      },
                    },
                    proofCentral: {
                      get path() {
                        return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.activity.iteration.fileType.sub.path}/pc_out_package`;
                      },
                    },
                    ioppPath: {
                      get path() {
                        return (
                          `${wmsConfig.okm.base.du.customer.wo.service.stage.path}/Common` +
                          `/iopp`
                        );
                      },
                    },
                  },
                  activity: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.path}/{ACTIVITY_NAME}`;
                    },
                    common: {
                      get path() {
                        return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.activity.path}/Common`;
                      },
                    },
                    iteration: {
                      get path() {
                        return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.activity.path}/{ACTIVITY_ITERATION}`;
                      },
                      common: {
                        get path() {
                          return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.activity.iteration.path}/Common`;
                        },
                      },
                      fileType: {
                        get path() {
                          return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.activity.iteration.path}/{FILE_TYPE}`;
                        },
                        sub: {
                          get path() {
                            return `${wmsConfig.okm.base.du.customer.wo.service.stage.iteration.activity.iteration.fileType.path}/{FILE_ID}`;
                          },
                        },
                      },
                    },
                  },
                },
              },
              incoming: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.wo.service.path}/Incoming`;
                },
                fileType: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.wo.service.incoming.path}/{FILE_TYPE}`;
                  },
                  sub: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.wo.service.incoming.fileType.path}/{FILE_ID}`;
                    },
                  },
                },
              },
            },
          },
          // for ialt specific
          ialt: {
            get path() {
              return `${wmsConfig.okm.base.du.customer.path}/altText`;
            },
            common: {
              get path() {
                return `${wmsConfig.okm.base.du.customer.ialt.path}/Common`;
              },
            },
            book: {
              get path() {
                return `${wmsConfig.okm.base.du.customer.ialt.path}/{BOOK_NAME}`;
              },
              common: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.ialt.book.path}/Common`;
                },
              },
              chapter: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.ialt.book.path}/{CHAPTER_NAME}`;
                },
                common: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.path}/Common`;
                  },
                },
                stage: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.path}/{STAGE_NAME}`;
                  },
                  output: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.stage.path}/Output`;
                    },
                  },
                  common: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.stage.path}/Common`;
                    },
                  },
                },
              },
            },
          },
        },
      },
      composingswtemplates: {
        get path() {
          return `${wmsConfig.okm.base.path}/composingswtemplates/{DU_ID}_{CUSTOMER_ID}/{SW_ID}/`;
        },
      },
    },
  },
};

export const localwmsConfig = localpath => {
  return {
    okm: {
      path: localpath,
      common: {
        get path() {
          return `${localpath}/Common`;
        },
      },
      base: {
        get path() {
          return `${localpath}/${process.env.OKM_BASE_DIR}`;
        },
        common: {
          get path() {
            return `${localwmsConfig(localpath).okm.base.path}/Common`;
          },
        },
        du: {
          get path() {
            return `${localwmsConfig(localpath).okm.base.path}/{DU_NAME}`;
          },
          common: {
            get path() {
              return `${localwmsConfig(localpath).okm.base.du.path}/Common`;
            },
          },
          customer: {
            get path() {
              return `${
                localwmsConfig(localpath).okm.base.du.path
              }/{CUSTOMER_NAME}`;
            },
            common: {
              get path() {
                return `${
                  localwmsConfig(localpath).okm.base.du.customer.path
                }/Common`;
              },
            },
            journals: {
              get path() {
                return `${
                  localwmsConfig(localpath).okm.base.du.customer.path
                }/journals`;
              },
              journal: {
                get path() {
                  return `${
                    localwmsConfig(localpath).okm.base.du.customer.journals.path
                  }/{JOURNAL_NAME}`;
                },
                instructions: {
                  get path() {
                    return `${
                      localwmsConfig(localpath).okm.base.du.customer.journals
                        .journal.path
                    }/instructions`;
                  },
                },
              },
            },
            wo: {
              get path() {
                return `${
                  localwmsConfig(localpath).okm.base.du.customer.path
                }/{WORK_ORDER_ID}`;
              },
              common: {
                get path() {
                  return `${
                    localwmsConfig(localpath).okm.base.du.customer.wo.path
                  }/Common`;
                },
                mail: {
                  get path() {
                    return `${
                      localwmsConfig(localpath).okm.base.du.customer.wo.common
                        .path
                    }/mail`;
                  },
                },
              },
              service: {
                get path() {
                  return `${
                    localwmsConfig(localpath).okm.base.du.customer.wo.path
                  }/{SERVICE_NAME}`;
                },
                common: {
                  get path() {
                    return `${
                      localwmsConfig(localpath).okm.base.du.customer.wo.service
                        .path
                    }/Common`;
                  },
                  mail: {
                    get path() {
                      return `${
                        localwmsConfig(localpath).okm.base.du.customer.wo
                          .service.common.path
                      }/mail`;
                    },
                  },
                },
                stage: {
                  get path() {
                    return `${
                      localwmsConfig(localpath).okm.base.du.customer.wo.service
                        .path
                    }/{STAGE_NAME}`;
                  },
                  common: {
                    get path() {
                      return `${
                        localwmsConfig(localpath).okm.base.du.customer.wo
                          .service.stage.path
                      }/Common`;
                    },
                    graphic: {
                      get path() {
                        return `${
                          localwmsConfig(localpath).okm.base.du.customer.wo
                            .service.stage.common.path
                        }/graphic`;
                      },
                    },
                    instructions: {
                      get path() {
                        return `${
                          localwmsConfig(localpath).okm.base.du.customer.wo
                            .service.stage.common.path
                        }/instructions`;
                      },
                    },
                    query: {
                      get path() {
                        return `${
                          localwmsConfig(localpath).okm.base.du.customer.wo
                            .service.stage.common.path
                        }/query/{QUERY_ID}`;
                      },
                    },
                  },
                  iteration: {
                    get path() {
                      return `${
                        localwmsConfig(localpath).okm.base.du.customer.wo
                          .service.stage.path
                      }/{STAGE_ITERATION}`;
                    },
                    common: {
                      get path() {
                        return `${
                          localwmsConfig(localpath).okm.base.du.customer.wo
                            .service.stage.iteration.path
                        }/Common`;
                      },
                      mail: {
                        get path() {
                          return `${
                            localwmsConfig(localpath).okm.base.du.customer.wo
                              .service.stage.iteration.common.path
                          }/mail`;
                        },
                      },
                      proofCentral: {
                        get path() {
                          return `${
                            localwmsConfig(localpath).okm.base.du.customer.wo
                              .service.stage.iteration.activity.iteration
                              .fileType.sub.path
                          }/pc_out_package`;
                        },
                      },
                      ioppPath: {
                        get path() {
                          return `${
                            localwmsConfig(localpath).okm.base.du.customer.wo
                              .service.stage.path
                          }/Common/iopp`;
                        },
                      },
                    },
                    activity: {
                      get path() {
                        return `${
                          localwmsConfig(localpath).okm.base.du.customer.wo
                            .service.stage.iteration.path
                        }/{ACTIVITY_NAME}`;
                      },
                      common: {
                        get path() {
                          return `${
                            localwmsConfig(localpath).okm.base.du.customer.wo
                              .service.stage.iteration.activity.path
                          }/Common`;
                        },
                      },
                      iteration: {
                        get path() {
                          return `${
                            localwmsConfig(localpath).okm.base.du.customer.wo
                              .service.stage.iteration.activity.path
                          }/{ACTIVITY_ITERATION}`;
                        },
                        common: {
                          get path() {
                            return `${
                              localwmsConfig(localpath).okm.base.du.customer.wo
                                .service.stage.iteration.activity.iteration.path
                            }/Common`;
                          },
                        },
                        fileType: {
                          get path() {
                            return `${
                              localwmsConfig(localpath).okm.base.du.customer.wo
                                .service.stage.iteration.activity.iteration.path
                            }/{FILE_TYPE}`;
                          },
                          sub: {
                            get path() {
                              return `${
                                localwmsConfig(localpath).okm.base.du.customer
                                  .wo.service.stage.iteration.activity.iteration
                                  .fileType.path
                              }/{FILE_ID}`;
                            },
                          },
                        },
                      },
                    },
                  },
                },
                incoming: {
                  get path() {
                    return `${
                      localwmsConfig(localpath).okm.base.du.customer.wo.service
                        .path
                    }/Incoming`;
                  },
                  fileType: {
                    get path() {
                      return `${
                        localwmsConfig(localpath).okm.base.du.customer.wo
                          .service.incoming.path
                      }/{FILE_TYPE}`;
                    },
                    sub: {
                      get path() {
                        return `${
                          localwmsConfig(localpath).okm.base.du.customer.wo
                            .service.incoming.fileType.path
                        }/{FILE_ID}`;
                      },
                    },
                  },
                },
              },
            },
            // for ialt specific
            ialt: {
              get path() {
                return `${wmsConfig.okm.base.du.customer.path}/Ialt`;
              },
              common: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.ialt.path}/Common`;
                },
              },
              book: {
                get path() {
                  return `${wmsConfig.okm.base.du.customer.ialt.path}/{BOOK_NAME}`;
                },
                common: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.ialt.book.path}/Common`;
                  },
                },
                chapter: {
                  get path() {
                    return `${wmsConfig.okm.base.du.customer.ialt.book.path}/{CHAPTER_NAME}`;
                  },
                  common: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.path}/Common`;
                    },
                  },
                  stage: {
                    get path() {
                      return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.path}/{STAGE_NAME}`;
                    },
                    output: {
                      get path() {
                        return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.stage.path}/Output`;
                      },
                    },
                    common: {
                      get path() {
                        return `${wmsConfig.okm.base.du.customer.ialt.book.chapter.stage.path}/Common`;
                      },
                    },
                  },
                },
              },
            },
          },
        },
        composingswtemplates: {
          get path() {
            return `${
              localwmsConfig(localpath).okm.base.path
            }/composingswtemplates/{DU_ID}_{CUSTOMER_ID}/{SW_ID}/`;
          },
        },
      },
    },
  };
};
