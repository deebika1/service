export const config = {
  iAuthor: {
    base_url: () => {
      switch (process.env.MODE.toLocaleLowerCase()) {
        case 'azure':
          return 'https://ipubsuite.integra.co.in/integra/ips/';
        case 'live':
          return 'https://ipubsuite.integra.co.in/integra/ips/';
        case 'dev':
          return 'https://test-ipubsuite.integra.co.in/integra/ips/';
        case 'prod':
          return 'https://test-ipubsuite.integra.co.in/integra/ips/';
        case 'test':
          return 'https://test-ipubsuite.integra.co.in/integra/ips/';
        case 'uat':
          return 'https://demo-ipubsuite.integra.co.in/integra/ips/';
        default:
          return 'https://ipubsuite.integra.co.in/integra/ips/';
      }
    },
    journal: 'ijps/',
    createjob: 'v2/wms-jrnl-createjob-new',
    elsevierStatusUpdate: 'update-elsevier-response-wms',
    nlp: 'nlp-score',
    getiAuthorLink: 'wms-sendlinkactivity-iaurl',
    getiAuthorToken: 'client/login',
    getiAuthorLinkRest: 'reset-lock-article',
    getCurrentiAuthorLink: 'getCurrentiAuthorLink',
    iauthorhtml: 'https://iauthor.integra.co.in/api/',
    generateiAuthorhtml: 'generate-iauthor-html',
    updateiAuthorMoved: 'ijps/update-journal-job-moved-to-wms',
    checkiAuthorStatus: 'wms-checkactivity-status',
    getiAuthorActivityFiles: 'v2/get-iactivity-files',
    clientid: 'WMS',
    apikey: '84B9A8C7-FDEA-47DC-B1CF-845FD79C4E05',
    pdfDownload: 'htmlToPDF',
    nlpScore: 'ijps/nlp-score-articleguid',
    nlpScoreQueue: 'ijps/nlp-score-sb',
    vmfilecopy: 'ijps/filecopy_to_VM',
  },
  camnunda: {
    base_url: process.env.CAMUNDA_BASEURL,
    uri: {
      claimTask: 'claimtask',
      unClaim: 'unclaimtask',
      completeTask: 'commonCompleteTask',
      fileUpload: 'upload',
      startInstance: 'startinstance',
      reset: 'postModification',
    },
  },
  camnundaNative: {
    base_url: process.env.CAMUNDA_NATIVE_URL,
    uri: {
      externalTask: {
        query: 'external-task/',
        lock: 'external-task/{{id}}/lock/',
        complete: 'external-task/{{id}}/complete/',
        resetModification: 'process-instance/{{id}}/modification',
      },
      parallelReset: 'modification/execute',
      activieInstance: 'process-instance/{{id}}/activity-instances',
      getStageInfo:
        'process-instance/{{id}}/variables/__stageInfo__?deserializeValue=false',
      putStageInfo: 'process-instance/{{id}}/variables/__stageInfo__',
      putActivityStageInfo:
        'task/{{id}}/variables/__stageInfo__?deserializeValue=false',
      updateVariableValue: 'process-instance/{{id}}/variables',
      getTaskId: 'task?processInstanceId={{id}}',
    },
  },
  openKM: {
    base_url: process.env.OKM_BASEURL,
    base_out_url: process.env.OKM_BASEURL_OUT,
    uri: {
      delete: 'delete',
      ischeckout: 'ischeckout',
      viewFile: 'viewdocument/',
      download: 'downloaddocument/',
      getFileDetails: 'getFileDetails/',
      checkin: 'checkin',
      downloadwithCheckout: '/downloadwithCheckout',
      upload: 'upload',
      acscontentwrite: 'acscontentwrite/',
    },
  },
  okmNative: {
    base_url: process.env.OKM_NATIVEURL,
    uri: {
      getUuid: 'repository/getNodeUuid/',
      retreiveFiles: 'search/find/',
      getDocumentProps: 'document/getProperties/',
      checkout: 'document/checkout/',
      checkin: 'document/checkin/',
      createFolder: 'folder/createSimple/',
      createFile: 'document/createSimple/',
      documentCopy: 'document/extendedCopy/',
      documentDelete: 'document/delete/',
      restoreVersion: 'document/restoreVersion',
      extendedCopy: 'folder/extendedCopy',
      documentChildren: 'document/getChildren',
      folderCopy: 'folder/copy/',
      folderDelete: 'folder/delete/',
      folderRename: 'folder/rename',
      lock: 'document/lock',
      folderCreate: 'folder/createMissingFolders',
      folderChildren: 'folder/getChildren',
    },
  },
  trackletApi: {
    base_url: process.env.TRACKIT_URL,
    uri: {
      trackIt: 'typesetter/article/stage/v2',
    },
  },
  pkgDepositApi: {
    base_url: process.env.EMDEPOSIT_ENDPOINT,
    uri: {
      deposit_auth: 'authentication/versions/1/tickets',
      pre_pub:
        'alfresco/versions/1/nodes/23e75e57-4f46-49eb-bf10-4c8349ce53fa/children',
      post_pub:
        'alfresco/versions/1/nodes/7796a65f-7a44-4e4e-bf23-71b1d4c735df/children',
    },
  },
  iTracks: {
    switch_url: process.env.SWITCH_URL,
    base_url: process.env.ITRACKS_URL,
    service_url: process.env.ITRACKS_SERVICE,
    uri: {
      book: {
        iendpointKey: 'test',
        createJob: 'createbookjob',
        addSubJob: 'addsubjob',
        logisticEntryInsert: 'logisticentryinsert',
        logisticEntryUpdate: 'logisticentryupdate',
        logisticEntryDelete: 'logisticentrydelete',
        canWorkActivity: 'canworkactivity',
        openEntry: 'openentry',
        productionDispatch: 'productiondispatch',
        customerDispatch: 'customerdispatch',
        productionDispatchReset: 'resetProdDespatch',
        iResetDes: 'resetBothDespatch',
      },
      journal: {
        iendpointKey: 'test',
        iendpointKey_createJob: 'KhpyP6s0ArPT5fizZ97pAg==',
        createJob: 'CreateArticle',
        iendpointKey_addStage: 'QxxnlYvH10MlmsNfO6lG0w==',
        addStage: 'Addstage',
        iendpointKey_canWorkActivity: '3SYCo7PPJ2aWgVVreGGMjA==',
        canWorkActivity: 'IssueCanworkActivity',
        iendpointKey_logisticEntryInsert: '3SYCo7PPJ2aWgVVreGGMjA==',
        logisticEntryInsert: 'IssueLogisticEntryInsert',
        iendpointKey_logisticEntryUpdate: '3SYCo7PPJ2aWgVVreGGMjA==',
        logisticEntryUpdate: 'IssueLogisticEntryUpdate',
        productionDispatch: 'IssueProductionDispatch',
        customerDispatch: 'IssueCustomerDispatch',
        productionDispatchReset: 'issueResetProdDespatch',
        mergeIssue: 'Mergeissue',
        createIssueJob: 'Createissue',
        customerDispatchReset: 'issueResetCustDespatch',
      },
    },
  },
  pubflow: {
    switch_url: process.env.PUB_URL,
    uri: {
      pubupdate: 'schedule/UpdateStatusByAPI',
    },
  },
  okm_rest: {
    baseUrl: process.env.OKM_BASEURL,
    document: {
      upload: 'upload',
    },
  },
  blob_rest: {
    base_url: process.env.BLOB_BASEURL,
    uri: {
      upload: 'document/checkin',
      delete: 'document/delete',
      checkin: 'document/checkin',
      checkout: 'document/checkout',
      copy: 'document/extendedCopy',
      rename: 'document/rename',
      deleteFilesInBlobFolder: 'document/deleteFilesInBlobFolder',
      download: 'document/download',
      retreiveBlobFiles: 'document/retreiveBlobFiles',
      retreiveBlobFilesURL: 'document/retreiveBlobFilesURL',
      getProperties: 'document/getProperties',
      retreiveBlobRootList: 'document/retreiveBlobRootList',
      copyExternalBlobToBlob: 'document/copyExternalBlobToBlob',
      blobExist: '/document/isExists',
      localfolderzipupload: 'document/localfolderzipupload',
      copyBlobToBlob: 'document/copyBlobToBlob',
      copyBlobToLocal: 'document/copyBlobToLocal',
      writeRawcontentToBlob: 'document/writeRawcontentToBlob',
      ZIPDownloadLocalFolder: 'document/ZIPDownloadLocalFolder?docPath=',

      // localupload: 'document/localcheckin',
      // localdelete: 'document/localfiledelete',
      // localcheckin: 'document/localcheckin',
      // localcheckout: 'document/localcheckout',
      // localcopy: 'document/localextendedCopy',
      // localrename: 'document/localfilerename',
      // localdownload: 'document/localdownload',
      // retreiveLocalFiles: 'document/retreivelocalFiles',
      // getlocalProperties: 'document/getlocalProperties',
      // retreiveLocalRootList: 'document/retreivelocalRootList',
    },
  },
  local_rest: {
    base_url: process.env.LOCAL_BASEURL,
    uri: {
      localupload: 'document/localcheckin',
      localdelete: 'document/localfiledelete',
      localcheckin: 'document/localcheckin',
      localcheckout: 'document/localcheckout',
      localcopy: 'document/localextendedCopy',
      localmultiplefileCopy: 'document/localmultiplefileCopy',
      localrename: 'document/localfilerename',
      localdownload: 'document/localdownload',
      retreiveLocalFiles: 'document/retreivelocalFiles',
      getlocalProperties: 'document/getlocalProperties',
      retreiveLocalRootList: 'document/retreivelocalRootList',
      copyExternalBlobToLocal: 'document/copyExternalBlobToLocal',
      copyLocalStorageToLocal: 'document/copyLocalStorageToLocal',
      localisExists: 'document/localisExists',
      copyLocalToLocal: 'document/copyLocalToLocal',
      copyLocalToLocalFolder: 'document/copyLocalToLocalFolder',
      retreivelocalFilesURL: 'document/retreivelocalFilesURL',
      downloadMandatoryCheck: 'document/downloadmandatorycheck',
      localZIPCopyWithExtract: 'document/localZIPCopyWithExtract',
      localFolderDelete: 'document/localDeleteFolder',
    },
  },
  e2e: {
    base_url: process.env.E2E_BASEURL,
    uri: {
      getIssueSequence: 'Api/getArticleSequence',
    },
  },
  iAlt: {
    base_url: process.env.IALT_BASEURL,
    uri: {
      imageClassificationById: 'ialtimage/uploadImageforclassifyById',
      imageClassificationByIdQueue:
        'ialtimage/uploadImageforclassifyByIdQueueSchedular',
      getImageClassification: 'ialtservice/getImageClassificationgroup',
      getAllClassification: 'ialtservice/getallclassification',
      updateImageClassification: 'ialtservice/updateclassificationgroup',
      altTextGeneration: 'ialtservice/generateAltTextNewVersionwms',
      altTextGenerationQueue:
        'ialtservice/generateAltTextNewVersionwmsSchedular',
      getAltTextGeneration: 'ialtimage/getAlttextgroup',
      updateAltTextGeneration: 'ialtimage/updateAltTextgroup',
      getdataexportExcel: 'ialtimage/getdataexportExcel',
      getAllPrompt:
        'prompt/getAllPromptByServiceId?isActive=true&isDeleted=false',
      ialtPdfUpload: 'ialtimage/ImagePDFExtractionwms',
      ialtImageUpload: 'ialtimage/uploadImage',
      ialtFileUploadFromBlob: 'ialtimage/ImagePathExtractionwms',
      ialtManualWorkorderDownload: 'ialtimage/getdatachapterwms',
      ialtUploadFilesQueueSchedular:
        'ialtimage/uploadFilesforExtractionQueueSchedular',
      ialtUploadVtexFilesQueueSchedular:
        'ialtimage/uploadFilesVtexExtractionQueueSchedular',
      ialtTandEIntegrationService:
        'ialtimage/uploadFilesTandEExtractionQueueSchedular',
    },
    else_vier: {
      base_url: process.env.ELSEVIER_APIURL,
      uri: {
        upload: 'upload?promote=false',
      },
      sms: {
        base_url: process.env.SMS_BASEURL,
        uri: {
          getSmsApiToken: 'login',
          receiveAcknowledgement: 'message',
        },
      },
    },
  },
  iftp: {
    base_url: process.env.IFTP_BASEURL,
    iftp_token: process.env.IFTP_TOKEN,
    uri: {
      getiFTPDispatch: 'api/iftp/iFTPDispatch',
    },
  },
  toolWrapperService: {
    base_url: () => {
      switch (process.env.MODE.toLocaleLowerCase()) {
        case 'azure':
          return '/wrapper-service-live/';
        case 'live':
          return '/wrapper-service-live/';
        case 'dev':
          return '/wrapper-service-dev/';
        case 'prod':
          return '/wrapper-service-dev/';
        case 'test':
          return '/wrapper-service-dev/';
        case 'uat':
          return '/wrapper-service-uat/';
        default:
          return '/wrapper-service/';
      }
    },
  },
};
