import { parse, basename, dirname, join, extname, posix } from 'path';
import { query } from '../../../database/postgres.js';
import {
  _localcopyFileWithoutFormData,
  _localFolderCopy,
  _retreiveLocalFiles,
  _localdownload,
} from '../../../modules/utils/local/index.js';
import { emitAction } from '../../../modules/activityListener/index.js';
import {
  isInvalid,
  validateRequiredFields,
} from '../../../modules/utils/fileValidation/utils.js';
import { getFolderStructure } from '../../../modules/utils/wmsFolder/index.js';

const folderFileTypeID = {
  1: 'book_1',
  2: 'chapter_2',
  4: 'article_4',
  18: 'frontmatter_18',
  19: 'backmatter_19',
  87: 'part_backmatter_87',
  88: 'part_frontmatter_88',
  15: 'cover_15',
  17: 'toc_17',
  89: 'mycopy_89',
};

export const getIntroMailChaserforS50 = async (req, res) => {
  try {
    const sql = `SELECT bm.*,mp.jobcode,mp.peusername,mp.peuseremail_id,jb.incomingstageid,
      jb.jobsheetcontent,jb.notificationproofruncurrentstatus,jb.createddate
      FROM wms_book_master bm
      JOIN wms_workorder wo ON bm.bookid = wo.itemcode AND wo.isactive = true
      JOIN springer.ice_mstpackage mp ON mp.bookid = bm.bookid
      JOIN springer.ice_jobdetails jb ON jb.jobcodeid = mp.jobcodeid AND jb.isactive = 'Y' AND jb.incomingstageid = '50'
      WHERE mp.jobtype = 'B' AND bm.isactive = true AND jb.notificationproofruncurrentstatus IS NULL 
      AND jb.createddate <= (CURRENT_DATE - INTERVAL '2 days')`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const getWorkOrderInfoDetails = async (req, res) => {
  try {
    const sql = `select wo.*,wos.processinstanceid,wos.isbookcompleted from wms_workorder wo
                join wms_workorder_incoming  as woi on wo.workorderid=woi.woid
                join wms_workorder_incomingfiledetails as inco on inco.woincomingid = woi.woincomingid
                join wms_workorder_service wos on wo.workorderid =wos.workorderid
                where wo.itemcode= '${req.body.itemcode}' and wo.isactive=true`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const stage600FileEntry = async (req, res) => {
  try {
    const { itemCode, isDirect600, fileCount } = req.body;
    let returnValue = [];
    if (itemCode) {
      let sql = '';
      if (isDirect600) {
        if (fileCount) {
          for (let i = 0; i < 3; i++) {
            sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map where wfeventid 
            in(select wfeventid from wms_workflow_eventlog where workorderid 
            in(select workorderid from public.wms_book_workorder_details where bookworkorderid 
            in(select workorderid from wms_workorder where itemcode='${itemCode}') 
            and activitystatus='Unassigned')and wfdefid in(1367))and repofilepath like'%.3d%'`;
            const selectCount = await query(sql);
            if (fileCount == selectCount.length) {
              break;
            }
            await delay(60000); // 60 sec
          }
        }
      } else {
        sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map where wfeventid 
        in(select wfeventid from wms_workflow_eventlog where workorderid 
        in(select workorderid from public.wms_book_workorder_details where bookworkorderid 
        in(select workorderid from wms_workorder where itemcode='${itemCode}') 
        and activitystatus='Unassigned')and wfdefid in(1327,1447,1433,1461,1475))and repofilepath like'%.3d%'`;
      }
      const out = await query(sql);
      sql = `select inco.woincomingid,inco.filename,wo.woid,inco.filepath  from wms_workorder_incoming  as wo
            join  wms_workorder_incomingfiledetails as inco on inco.woincomingid = wo.woincomingid
            join wms_workorder as woid on wo.woid=woid.workorderid
            where woid.itemcode= '${itemCode}' and inco.filename='${itemCode}' and woid.isactive=true limit 1`;

      const resForEntry = await query(sql);
      const bookwoid = resForEntry[0].woid;
      const bookMstersql = `select * from wms_book_master where bookid='${itemCode}' and isactive=true`;
      const bookMsterDetails = await query(bookMstersql);
      let filename = '';
      if (out.length > 0) {
        let fileTypeID = 2;
        const val = [];
        out.forEach(list => {
          fileTypeID = 2;
          filename = parse(basename(list.repofilepath)).name;
          if (filename.includes('PFM1_Part')) {
            filename = filename.replace('PFM1', 'PartFrontmatter');
            fileTypeID = 88;
          }
          if (filename.includes('PBM2_Part')) {
            filename = filename.replace('PBM2', 'PartBackmatter');
            fileTypeID = 87;
          }
          if (filename.includes('FM1')) {
            filename = filename.replace('FM1_Chapter', 'BookFrontmatter');
            fileTypeID = 18;
          }
          if (filename.includes('BM2')) {
            filename = filename.replace('BM2_Chapter', 'BookBackmatter');
            fileTypeID = 19;
          }

          val.push(
            `(${resForEntry[0].woincomingid},${fileTypeID},'${list.repofilepath}','${list.repofileuuid}','${filename}',0)`,
          );
        });
        if (
          bookMsterDetails[0].mycopy == 'Yes' ||
          bookMsterDetails[0].mycopy == 'yes'
        ) {
          filename = `${itemCode}_MyCopy`;
          val.push(
            `(${resForEntry[0].woincomingid},89,'${out[0].repofilepath}','${out[0].repofileuuid}','${filename}',0)`,
          );
        }
        filename = `${itemCode}_BookTOC`;
        val.push(
          `(${resForEntry[0].woincomingid},17,'${out[0].repofilepath}','${out[0].repofileuuid}','${filename}',0)`,
        );
        filename = `${itemCode}_Cover`;
        val.push(
          `(${resForEntry[0].woincomingid},15,'${out[0].repofilepath}','${out[0].repofileuuid}','${filename}',0)`,
        );

        const filterValue = [];
        for (const value of val) {
          const sqlCheck = `SELECT inco.woincomingfileid,inco.woincomingid,inco.filename,inco.filetypeid,inco.filepath
                     FROM wms_workorder_incoming AS wo
                     JOIN wms_workorder_incomingfiledetails AS inco
                     ON inco.woincomingid = wo.woincomingid
                     WHERE wo.woid = ${bookwoid} AND inco.filename = ${
            value.split(',')[4]
          }`;
          const outResult = await query(sqlCheck);
          if (outResult.length === 0) {
            filterValue.push(value);
          } else if (outResult.length > 0) {
            returnValue = [...returnValue, ...outResult];
          }
        }

        if (filterValue.length > 0) {
          sql = `INSERT INTO public.wms_workorder_incomingfiledetails(woincomingid,filetypeid,filepath,fileuuid,filename,imagecount)VALUES ${filterValue} returning woincomingfileid,woincomingid,filename,filetypeid,filepath`;
          const outPut = await query(sql);
          returnValue = [...returnValue, ...outPut];
        }
      } else {
        res
          ?.status(200)
          .send({ isSuccess: false, message: 'Job not available.' });
      }
      if (isDirect600 && resForEntry.length > 0) {
        let targetFileName = '';
        let renameText = '';
        const { woid } = resForEntry[0];
        let { filepath } = resForEntry[0];
        const fileDetails = returnValue;
        let bookFilePath = filepath;
        let copyResult = false;
        if (returnValue.length > 0) {
          const s600BasePath = await getStage600BasePath(itemCode);
          if (bookFilePath.includes(woid)) {
            bookFilePath = bookFilePath.split('/').splice(0, 12).join('/');
          }
          for (const value of fileDetails) {
            let isDirectory = false;
            const { woincomingfileid, filetypeid } = value;
            filepath = value.filepath;
            let srcPath = '';
            let desPath = join(
              join(bookFilePath, folderFileTypeID[filetypeid]),
              woincomingfileid,
            );
            if (!desPath.endsWith('/')) {
              desPath = join(desPath, '/');
            }
            if (extname(basename(filepath))) {
              srcPath = dirname(filepath);
            } else {
              srcPath = filepath;
            }
            if (filetypeid != 15 && filetypeid != 17 && filetypeid != 89) {
              switch (Number(filetypeid)) {
                case 18:
                  targetFileName = 'FM1_Chapter';
                  renameText = 'BookFrontmatter';
                  break;
                case 19:
                  targetFileName = 'BM2_Chapter';
                  renameText = 'BookBackmatter';
                  break;
                case 87:
                  targetFileName = 'PBM2_Part';
                  renameText = 'PartBackmatter';
                  break;
                case 88:
                  targetFileName = 'PFM1_Part';
                  renameText = 'PartFrontmatter';
                  break;
                default:
                  targetFileName = '';
                  renameText = '';
                  isDirectory = true;
                  break;
              }

              // if (process.platform === 'win32') {
              srcPath = srcPath.replace(/\\/g, '/');
              const desPathUpdated = desPath
                .replace(/\\/g, '/')
                .startsWith('//')
                ? desPath.replace(/\\/g, '/')
                : `/${desPath.replace(/\\/g, '/')}`;
              // } else {
              // srcPath = srcPath.replace(/\//g, '\\');
              // desPath = desPath.replace(/\//g, '\\');
              // }

              copyResult = await copyFolderandFileRename(
                srcPath,
                desPathUpdated,
                s600BasePath,
                targetFileName,
                renameText,
                isDirectory,
              );
            }
          }
          if (copyResult) {
            res?.status(200).send({
              isSuccess: true,
              message: 'Job inserted successfully.',
              data: returnValue,
              bookDetails: resForEntry[0],
            });
          } else {
            res?.status(400).send({
              isSuccess: false,
              message: copyResult,
            });
          }
        } else {
          res?.status(400).send({
            isSuccess: false,
            message: 'No Record found.',
          });
        }
      }
      if (!isDirect600) {
        res?.status(200).send({
          isSuccess: true,
          message: 'Job inserted successfully.',
          data: returnValue,
          bookDetails: resForEntry[0],
        });
      }
    } else {
      res
        ?.status(200)
        .send({ isSuccess: false, message: 'itemCode is Missing' });
    }
  } catch (error) {
    res?.status(400).send({
      isSuccess: false,
      message: error.message ? error.message : error,
    });
  }
};

function delay(ms) {
  return new Promise(resolve => {
    setTimeout(resolve, ms);
  });
}

export async function copyFolderandFileRename(
  srcPath,
  destBasePath,
  s600BasePath,
  targetFileName = '',
  renameText = '',
  isDirectory = false,
) {
  let result = '';
  try {
    if (isDirectory) {
      result = await _localFolderCopy({ srcPath, destBasePath });
      const files = await _retreiveLocalFiles(srcPath);
      const pageTargetPath = files
        .flat()
        .filter(list => list.path.includes('page_target/'))[0].path;

      srcPath = posix.join(srcPath, 'page_target/', basename(pageTargetPath));
      const name = basename(pageTargetPath.replace(targetFileName, renameText));
      result = await copyPageTargetFolder(srcPath, name, s600BasePath);
    } else {
      // Get a list of all files and subdirectories in the source folder
      const files = await _retreiveLocalFiles(srcPath);
      const sourcePath = srcPath;
      // Iterate through the files and subdirectories
      for (const file of files) {
        if (file.path.includes('page_target/')) {
          srcPath = posix.join(sourcePath, 'page_target/', basename(file.path));
          const name = basename(file.path.replace(targetFileName, renameText));
          result = await copyPageTargetFolder(srcPath, name, s600BasePath);
        } else {
          srcPath = posix.join(sourcePath, basename(file.path));
          const name = basename(file.path.replace(targetFileName, renameText));
          srcPath = srcPath.replace(/\\/g, '/').startsWith('//')
            ? srcPath.replace(/\\/g, '/')
            : `/${srcPath.replace(/\\/g, '/')}`;
          result = await _localcopyFileWithoutFormData({
            srcPath,
            name,
            destBasePath,
          });
        }
      }
    }
    return result;
  } catch (ex) {
    result = ex.message ? ex.message : ex;
    return result;
  }
}

export async function copyPageTargetFolder(srcPath, name, s600BasePath) {
  let result;
  try {
    if (s600BasePath) {
      s600BasePath = posix.join(s600BasePath, 'page_target/');

      srcPath = srcPath.replace(/\\/g, '/').startsWith('//')
        ? srcPath.replace(/\\/g, '/')
        : `/${srcPath.replace(/\\/g, '/')}`;

      const destBasePath = s600BasePath.replace(/\\/g, '/').startsWith('//')
        ? s600BasePath.replace(/\\/g, '/')
        : `/${s600BasePath.replace(/\\/g, '/')}`;

      result = await _localcopyFileWithoutFormData({
        srcPath,
        name,
        destBasePath,
      });
    }
    return result;
  } catch (ex) {
    result = ex.message ? ex.message : ex;
    return result;
  }
}

export async function getStage600BasePath(itemCode) {
  let s600BasePath;
  try {
    const sql = `select g1.stageid,
                    g1.stagename,h1.serviceid, h1.servicename ,v.customerid ,i1.customername,v.workorderid,
                    e1.assignedduid as duid,l1.duname
                    from wms_workorder as v
                    join wms_workorder_service as e1 on e1.workorderid = v.workorderid
                    join wms_mst_stage as g1 on g1.stagename = 'Stage 600'
                    join wms_mst_service as h1 on h1.serviceid = e1.serviceid
                    join org_mst_customer as i1 on i1.customerid = v.customerid
                    join org_mst_deliveryunit as l1 on l1.duid=e1.assignedduid
                    where v.isactive=true and v.itemcode = '${itemCode}' limit 1`;
    const woDetails = await query(sql, []);
    if (woDetails?.length > 0) {
      const {
        customerid,
        customername,
        workorderid,
        duid,
        duname,
        serviceid,
        servicename,
        stagename,
        stageid,
      } = woDetails[0];
      s600BasePath = await getFolderStructure({
        type: 'wo_stage_iteration',
        du: { name: duname, id: duid },
        customer: { name: customername, id: customerid },
        workOrderId: workorderid,
        service: { name: servicename, id: serviceid },
        stage: {
          name: stagename,
          id: stageid,
          iteration: 1,
        },
      });
    }
    return s600BasePath;
  } catch (ex) {
    return s600BasePath;
  }
}

export const plannedDateforSpringerBooks = async (req, res) => {
  const { inputjson } = req.body;
  const jsonObject = JSON.parse(inputjson);
  let status = false;
  let l_message = '';

  try {
    const sql = `select count(*) as count from springer.ice_bookplanneddate where lower(bookseriesid) = lower('${jsonObject.bookseriesid}')`;
    const result1 = await query(sql);

    if (result1 && result1[0].count == 0) {
      const insertQuery = `INSERT INTO springer.ice_bookplanneddate (
        bookseriesid, s5typesetterdeadline, s50typesetterdeadline,s200typesetterdeadline,s300typesetterdeadline,
        s600typesetterdeadline, s650typesetterdeadline,s700printerdeadline, s800printdistributiondeadline, s900electronicdistributiondeadline,
        createdby
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,'ICE'
      ) returning planneddateid`;

      const values = [
        jsonObject.bookseriesid ?? null,
        jsonObject.s5typesetterdeadline ?? null,
        jsonObject.s50typesetterdeadline ?? null,
        jsonObject.s200typesetterdeadline ?? null,
        jsonObject.s300typesetterdeadline ?? null,
        jsonObject.s600typesetterdeadline ?? null,
        jsonObject.s650typesetterdeadline ?? null,
        jsonObject.s700printerdeadline ?? null,
        jsonObject.s800printdistributiondeadline ?? null,
        jsonObject.s900electronicdistributiondeadline ?? null,
      ];

      const result = await query(insertQuery, values);
      if (result?.length == 1) {
        l_message = 'Saved';
        status = true;
      } else {
        l_message = 'Failed';
      }
    } else {
      l_message = 'Entry already exist';
      status = true;
    }
    res.status(200).json({
      message: l_message,
      status,
    });
  } catch (error) {
    res
      .status(400)
      .json({ message: error.message ? error.message : error, status });
  }
};

export const updateBookMaster = async (req, res) => {
  try {
    const { updateData, bookid } = req.body;
    if (bookid && updateData) {
      const sql = `Select bookid from  wms_book_master WHERE bookid='${bookid}' and isactive=true`;
      const out = await query(sql);
      if (out?.length > 0) {
        // Extract keys and values from the updateData object
        const columns = Object.keys(updateData);
        const values = Object.values(updateData);

        // Create the SET part of the query dynamically
        const setQuery = columns
          .map((col, idx) => `${col} = $${idx + 1}`)
          .join(', ');
        const sqlquery = `UPDATE wms_book_master SET ${setQuery} WHERE bookid='${bookid}' and isactive=true`;
        await query(sqlquery, values);
        res
          .status(200)
          .send({ isSuccess: true, message: 'Record Updated Successfully.' });
      } else {
        res
          .status(200)
          .send({ isSuccess: false, message: 'BookDetails Not Found.' });
      }
    } else {
      res
        .status(200)
        .send({ isSuccess: false, message: 'Bookid or updateData Missing.' });
    }
  } catch (ex) {
    res
      .status(400)
      .send({ isSuccess: false, message: ex.message ? ex.message : ex });
  }
};

export const updateiFTPStatusforTools = async (req, res) => {
  try {
    const { status, wfeventid, toolid, remarks } = req.body;
    const sql = `UPDATE wms_tools_api SET 
    status = '${status}',
    remarks = '${remarks}'
    WHERE apiid = (
    SELECT apiid
    FROM wms_tools_api
    WHERE wfeventid = '${wfeventid}' AND toolid = '${toolid}'
    ORDER BY apiid DESC
    LIMIT 1)`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const sendS50IntroMail = async payload => {
  try {
    const { itemCode, stageID, surPath } = payload;
    const sql = `SELECT bm.id, bm.bookid, bm.booktitle, bm.onlinefirst, bm.language, 
      bm.workflow,bm.coverpages, bm.mspages, bm.fmpages, bm.bookpages, bm.billingpages, bm.proofingdate, bm.layout, 
	    bm.vertical, bm.complexity, bm.projectmanagement, bm.indextype, bm.seriesnumber,
      bm.referencestyle, bm.location, bm.inputtype, bm.paginationapplication,
      bm.accesability, bm.schedule, bm.bookhistory, bm.fasttrack, bm.bookproofing,
      bm.revisedproof, bm.fixedpublicationdate, bm.numberoffigures,
      bm.cover, bm.celevelid, bm.mycopy, bm.specialinstructions, bm.bookisbn, bm.compcopy,
	    bm.ordered, bm.ordereddate, bm.reorderdate, bm.status ,bm.onlineprofileid as onlineprofile, bm.printprofileid as printprofile,bm.publisherimprintname
      ,(select contactname from book_master_contacts where bookmasterid = bm.id and roleid = 1) as projectmanager
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 1)  as pmemailid
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 6) as pename
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 6) as peemailid
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 7) as correspondingauthorname
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 7) as correspondingauthoremail
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 12) as correspondingeditorname
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 12) as correspondingeditoremail
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 53) as responsibleeditorname
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 53) as responsibleeditoremail
	    ,(select familyname from book_master_contacts where bookmasterid = bm.id  and roleid = 53) as responsibleeditorfamilyname
	    ,(select familyname from book_master_contacts where bookmasterid = bm.id  and roleid = 7) as correspondingauthorfamilyname
	    ,(select familyname from book_master_contacts where bookmasterid = bm.id  and roleid = 12) as correspondingeditorfamilyname
      ,bm.trimsize
      FROM wms_book_master as bm where LOWER(bm.bookid) = LOWER('${itemCode}') and bm.isactive=true`;
    const out = await query(sql);
    if (out?.length > 0) {
      let selectTemplate = {};
      if (out[0].compcopy == true || out[0].compcopy == 'Yes') {
        selectTemplate = `select subject,bodytext,bcc,fromaddress,cc from springer.ice_jobmailtemplate where stageid=${stageID} and isactive=true and compcopy=true`;
      } else {
        selectTemplate = `select subject,bodytext,bcc,fromaddress,cc from springer.ice_jobmailtemplate where stageid=${stageID} and isactive=true and compcopy=false`;
      }
      const mailData = await query(selectTemplate);
      if (mailData.length > 0) {
        let familyName = '';
        if (
          out[0].correspondingauthorname &&
          out[0].correspondingauthoremail &&
          out[0].correspondingauthorfamilyname
        ) {
          out[0].AuthorNamefromJS = out[0].correspondingauthorname;
          familyName = out[0].correspondingauthorfamilyname;
        } else if (
          out[0].correspondingeditorname &&
          out[0].correspondingeditoremail &&
          out[0].correspondingeditorfamilyname
        ) {
          out[0].AuthorNamefromJS = out[0].correspondingeditorname;
          familyName = out[0].correspondingeditorfamilyname;
        } else {
          throw new Error('Author or Editor details are missing.');
        }

        if (isInvalid(out[0]?.pmemailid)) {
          throw new Error('PM Mail Id missing.');
        }

        let mailSubject = mailData[0].subject;
        const firstThreeWords = out[0].booktitle
          .split(' ')
          .slice(0, 3)
          .join(' ');

        mailSubject = mailSubject.replace(';PrintISBN;', out[0].bookisbn);
        mailSubject = mailSubject.replace(';FamilyName;', familyName);
        mailSubject = mailSubject.replace(';3wordsoftitle;', firstThreeWords);
        // Extract the first three words
        const result = await IntroMailreplaceValue(
          mailData[0].bodytext,
          out[0],
        );
        if (!result.isSuccess) {
          throw new Error(
            result.message || 'Replace intro mail process failed.',
          );
        }

        const emailConfig = {
          type: 'mail',
          to: [out[0].pmemailid],
          from: [mailData[0].fromaddress],
          template: result.finalTemplate,
          message: '',
          cc: [mailData[0].cc],
          subject: mailSubject,
          attachmentFileName: basename(surPath),
          attachmentFilePath: surPath,
        };

        await sendMail(emailConfig);

        return { data: { isSuccess: true, message: 'Intro Mail Sent.' } };
      }
      throw new Error('Intro Mail template not found.');
    } else {
      throw new Error('Book Record not found.');
    }
  } catch (error) {
    throw new Error(error.message ? error.message : error);
  }
};

// eslint-disable-next-line consistent-return
export const sendS200IntroMail = async (req, res) => {
  try {
    const { itemCode, stageID, surPath } = req.body;

    const sql = `SELECT chapteritemcode from springer.ice_mstchapter where LOWER(chapteritemcode) = LOWER('${itemCode}') and isactive=true and isintromailsent = true`;
    const out = await query(sql);
    if (out.length > 0) {
      return res.status(200).send({
        isSuccess: false,
        message: 'Chapter Intro Mail already sent.',
      });
    }

    const chapterQuery = `
      SELECT 
        bm.id, bm.bookid, bm.booktitle, bm.proofingdate, bm.referencestyle,
        bm.schedule, bm.bookisbn, bm.fixedpublicationdate, bm.publisherimprintname,
        cm.chapterdoi, cm.chaptertitle, cm.authoremail AS correspondingauthoremail,
        cm.authorname AS correspondingauthorname,bm.compcopy,
        (SELECT contactname FROM book_master_contacts WHERE bookmasterid = bm.id AND roleid = 1) AS projectmanager,
        (SELECT contactemail FROM book_master_contacts WHERE bookmasterid = bm.id AND roleid = 1) AS pmemailid
      FROM wms_book_master bm
      JOIN springer.ice_mstchapter cm ON cm.bookid = bm.id
      WHERE LOWER(cm.chapteritemcode) = LOWER('${itemCode}')
        AND bm.isactive = true
        AND cm.isactive = true`;

    const [chapter] = await query(chapterQuery);

    if (!chapter) {
      return res
        .status(200)
        .send({ isSuccess: false, message: 'Chapter record not found.' });
    }

    if (!chapter.correspondingauthorname || !chapter.correspondingauthoremail) {
      return res
        .status(200)
        .send({ isSuccess: false, message: 'Author details are missing.' });
    }

    if (isInvalid(chapter.pmemailid)) {
      return res
        .status(200)
        .send({ isSuccess: false, message: 'PM Mail ID missing.' });
    }

    chapter.AuthorNamefromJS = chapter.correspondingauthorname;

    const compCopy = chapter.compcopy === true || chapter.compcopy === 'Yes';
    const templateQuery = `
      SELECT subject, bodytext, bcc, fromaddress, cc
      FROM springer.ice_jobmailtemplate
      WHERE stageid = ${stageID} AND isactive = true AND compcopy = ${compCopy}`;
    const [template] = await query(templateQuery);

    if (!template) {
      return res
        .status(200)
        .send({ isSuccess: false, message: 'Intro Mail template not found.' });
    }

    // Replace subject placeholders
    const subject = template.subject
      .replace(';PrintISBN;', chapter.bookisbn)
      .replace(
        ';3wordsoftitle;',
        chapter.chaptertitle.split(' ').slice(0, 3).join(' '),
      )
      .replace(';BookID;', chapter.bookid)
      .replace(';ChapterDOI;', chapter.chapterdoi)
      .replace(';fullBookTitleFromJS;', chapter.booktitle);

    // Replace body placeholders
    const result = await IntroMailreplaceValueforS200(
      template.bodytext,
      chapter,
    );
    if (!result.isSuccess) {
      return res.status(200).send({
        isSuccess: false,
        message: result.message
          ? result.message
          : 'Replace intro mail process failed.',
      });
    }

    // Build and send email
    const emailConfig = {
      type: 'mail',
      to: [chapter.pmemailid],
      from: [template.fromaddress],
      cc: [template.cc],
      subject,
      template: result.finalTemplate,
      message: '',
      attachmentFileName: surPath ? basename(surPath) : '',
      attachmentFilePath: surPath || '',
    };

    await sendMail(emailConfig);
    // Update the chapter record to mark the intro mail as sent
    const updateQuery = `
      UPDATE springer.ice_mstchapter
      SET isintromailsent = true
      WHERE LOWER(chapteritemcode) = LOWER('${itemCode}')`;
    await query(updateQuery);
    // Send success response
    res.status(200).send({ isSuccess: true, message: 'Intro Mail Sent.' });
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message || error });
  }
};

export const IntroMailreplaceValue = async (template, value) => {
  let activeMailContentInHTML = template;
  let NoLegend = true;
  let remarks = '';

  try {
    const requiredFields = [
      'AuthorNamefromJS',
      'projectmanager',
      'booktitle',
      'proofingdate',
      'fixedpublicationdate',
    ];

    // Validate required fields
    validateRequiredFields(value, requiredFields);

    // Replace placeholders with actual values
    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';AuthorNamefromJS;',
      `<b>${value.AuthorNamefromJS.trim()}</b>`,
    );
    activeMailContentInHTML = activeMailContentInHTML.replace(
      /;PMName;/g,
      `<b>${value.projectmanager.trim()}</b>`,
    );
    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';fullBookTitleFromJS;',
      `<b>${value.booktitle}</b>`,
    );

    // Handle Imprint Name replacements
    if (value.publisherimprintname) {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        /;PublisherImprintName;/g,
        `<b>${value.publisherimprintname.trim()}</b>`,
      );
    }

    // Insert Month/Date to Date
    const dateTo = new Date(value.proofingdate);
    dateTo.setDate(dateTo.getDate() + 6); // Add 6 days

    // Format both dates correctly (Ensure formatDate is defined)
    if (typeof formatDate === 'function') {
      value.proofingdate = `${formatDate(value.proofingdate)} to ${formatDate(
        dateTo,
      )}`;
    } else {
      throw new Error('formatDate function is missing or not defined.');
    }

    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';bookPageproofstoauthor;',
      `<b>${value.proofingdate}</b>`,
    );

    // Planned Publication Date
    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';PlannedPublicationDate;',
      `<b>${formatDate(value.fixedpublicationdate)}</b>`,
    );

    // Insert Springer Nature Reference Style
    if (!isInvalid(value.referencestyle)) {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        ';referenceStyle;',
        `<b>${value.referencestyle}</b>`,
      );
    } else {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        ';referenceStyle;',
        '<b>[Insert Springer Nature Reference Style]</b>',
      );
    }

    // Handle Complimentary Copy Required
    if (!value.cbisComplementarycopy) {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        /<comprequired>[\s\S]*?<\/comprequired>/gi,
        '',
      );
    } else {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        /<\/?comprequired>/gi,
        '',
      );
    }

    // Check for remaining placeholders
    const placeholders = [
      ';PMName;',
      ';AuthorNamefromJS;',
      ';companyName;',
      ';PublisherImprintName;',
      ';bookPageproofstoauthor;',
      ';numberOfDays;',
      ';PlannedPublicationDate;',
      ';referenceStyle;',
    ];

    const missingPlaceholders = placeholders.filter(placeholder =>
      activeMailContentInHTML.includes(placeholder),
    );

    if (missingPlaceholders.length > 0) {
      NoLegend = false;
      remarks = `Unreplaced placeholders found: ${missingPlaceholders.join(
        ', ',
      )}`;
    }
  } catch (ex) {
    remarks = ex.message ? ex.message : ex;
    activeMailContentInHTML = '';
    NoLegend = false;
  }

  return {
    isSuccess: NoLegend,
    finalTemplate: activeMailContentInHTML,
    message: remarks,
  };
};
export const IntroMailreplaceValueforS200 = async (template, value) => {
  let activeMailContentInHTML = template;
  let NoLegend = true;
  let remarks = '';

  try {
    const requiredFields = [
      'AuthorNamefromJS',
      'projectmanager',
      'chaptertitle',
      'proofingdate',
      'fixedpublicationdate',
    ];

    // Validate required fields
    validateRequiredFields(value, requiredFields);

    // Replace placeholders with actual values
    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';AuthorNamefromJS;',
      `<b>${value.AuthorNamefromJS.trim()}</b>`,
    );
    activeMailContentInHTML = activeMailContentInHTML.replace(
      /;PMName;/g,
      `<b>${value.projectmanager.trim()}</b>`,
    );
    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';fullChapterTitleFromJS;',
      `<b>${value.chaptertitle}</b>`,
    );

    // Handle Imprint Name replacements
    if (value.publisherimprintname) {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        /;PublisherImprintName;/g,
        `<b>${value.publisherimprintname.trim()}</b>`,
      );
    }

    // Insert Month/Date to Date
    const dateTo = new Date(value.proofingdate);
    dateTo.setDate(dateTo.getDate() + 6); // Add 6 days

    // Format both dates correctly (Ensure formatDate is defined)
    if (typeof formatDate === 'function') {
      value.proofingdate = `${formatDate(value.proofingdate)} to ${formatDate(
        dateTo,
      )}`;
    } else {
      throw new Error('formatDate function is missing or not defined.');
    }

    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';chapterPageproofstoauthor;',
      `<b>${value.proofingdate}</b>`,
    );

    // Planned Publication Date
    activeMailContentInHTML = activeMailContentInHTML.replace(
      ';PlannedPublicationDate;',
      `<b>${formatDate(value.fixedpublicationdate)}</b>`,
    );

    // Insert Springer Nature Reference Style
    if (!isInvalid(value.referencestyle)) {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        ';referenceStyle;',
        `<b>${value.referencestyle}</b>`,
      );
    } else {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        ';referenceStyle;',
        '<b>[Insert Springer Nature Reference Style]</b>',
      );
    }

    // Handle Complimentary Copy Required
    if (!value.cbisComplementarycopy) {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        /<comprequired>[\s\S]*?<\/comprequired>/gi,
        '',
      );
    } else {
      activeMailContentInHTML = activeMailContentInHTML.replace(
        /<\/?comprequired>/gi,
        '',
      );
    }

    // Check for remaining placeholders
    const placeholders = [
      ';PMName;',
      ';AuthorNamefromJS;',
      ';companyName;',
      ';PublisherImprintName;',
      ';chapterPageproofstoauthor;',
      ';numberOfDays;',
      ';PlannedPublicationDate;',
      ';referenceStyle;',
    ];

    const missingPlaceholders = placeholders.filter(placeholder =>
      activeMailContentInHTML.includes(placeholder),
    );

    if (missingPlaceholders.length > 0) {
      NoLegend = false;
      remarks = `Unreplaced placeholders found: ${missingPlaceholders.join(
        ', ',
      )}`;
    }
  } catch (ex) {
    remarks = ex.message ? ex.message : ex;
    activeMailContentInHTML = '';
    NoLegend = false;
  }

  return {
    isSuccess: NoLegend,
    finalTemplate: activeMailContentInHTML,
    message: remarks,
  };
};

function formatDate(date) {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = d.toLocaleString('en-GB', { month: 'short' });
  const year = d.getFullYear();
  return `${day}-${month}-${year}`;
}

export const sendMail = async req => {
  try {
    const { attachmentFilePath, attachmentFileName, type } = req;
    // const sql = `SELECT * from wms_notifications WHERE customerid= 10 and action='ice_springer' and isactive = true`;
    const filePath = [];
    const fileNames = [];
    const outFiles = [];
    // const resnotification = await query(sql);
    // const { type, notificationconfig } = resnotification[0];
    if (attachmentFilePath.length > 0) {
      filePath.push(attachmentFilePath, { data: { path: attachmentFilePath } });
    }
    if (attachmentFileName.length > 0) {
      fileNames.push(attachmentFileName);
    }
    if (type == 'mail') {
      if (filePath.length > 0) {
        const out = await _localdownload(filePath[0]);
        if (out.path != '') {
          outFiles.push(out);
        }
      }
    }
    const mailData = {
      actionType: type,
      ...req,
      outFiles: outFiles.length > 0 ? outFiles : '',
      fileNames: fileNames.length > 0 ? fileNames : '',
    };
    emitAction(mailData);
    return { data: 'Mail send success.', isSuccess: true };
  } catch (error) {
    return { message: error.message, isSuccess: false };
  }
};

export const introMailPreSendCheck = async payload => {
  try {
    const { iwms } = payload.data;

    const sql = `select * from wms_tools_api where toolid=553 and wfeventid = ${iwms.wfEventId} and status = 'Success'`;
    const out = await query(sql);

    if (out?.length > 0) {
      throw new Error('Intro Mail already Sent.');
    }
  } catch (error) {
    throw new Error(error.message ? error.message : error);
  }
};
