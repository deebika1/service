import express from 'express';
import {
  stage600FileEntry,
  plannedDateforSpringerBooks,
  getIntroMailChaserforS50,
  updateBookMaster,
  getWorkOrderInfoDetails,
  updateiFTPStatusforTools,
  sendS50IntroMail,
  sendS200IntroMail,
} from '../controller/index.js';
import { validateExcelFile } from '../helpers/validation.js';

const sprBooksRouter = express.Router();
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

sprBooksRouter.post(
  '/plannedDateforSpringerBooks',
  handler(plannedDateforSpringerBooks),
);
sprBooksRouter.post(
  '/getIntroMailChaserforS50',
  handler(getIntroMailChaserforS50),
);
sprBooksRouter.post('/stage600FileEntry', handler(stage600FileEntry));
sprBooksRouter.post('/updateBookMaster', handler(updateBookMaster));
sprBooksRouter.post(
  '/updateiFTPStatusforTools',
  handler(updateiFTPStatusforTools),
);
sprBooksRouter.post(
  '/getWorkOrderInfoDetails',
  handler(getWorkOrderInfoDetails),
);
sprBooksRouter.post('/validateExcelFile', handler(validateExcelFile));
sprBooksRouter.post('/sendS50IntroMail', handler(sendS50IntroMail));
sprBooksRouter.post('/sendS200IntroMail', handler(sendS200IntroMail));

export default sprBooksRouter;
