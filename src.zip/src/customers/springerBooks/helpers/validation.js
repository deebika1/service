/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies

import Joi from 'joi';
import ExcelJS from 'exceljs';
import { promises as fs } from 'fs';
import path from 'path';

export const aprRejeopenreqSchema = Joi.object({
  requestId: Joi.number().required(),
  modalType: Joi.string().required(),
  reqType: Joi.string().required(),
  appraisalId: Joi.number().required(),
  userid: Joi.string().required(),
  comment: Joi.string().required(),
  roleId: Joi.string().required(),
});

export const getReopenReqListSchema = Joi.object({
  typeId: Joi.string().allow('').required(),
  roleId: Joi.string().required(),
  userId: Joi.string().allow('').required(),
  searchText: Joi.string().allow('').required(),
});

export const getAttachmentInfoSchema = Joi.object({
  kra_itemkey: Joi.string().required(),
});

export const insAttachmentInfoSchema = Joi.object({
  kra_itemkey: Joi.string().required(),
  type: Joi.string().required(),
  fileName: Joi.string().required(),
  path: Joi.string().required(),
  empCode: Joi.string().required(),
});

export const getiAspireFolderPathSchema = Joi.object({
  quarter: Joi.string().required(),
  empCode: Joi.string().required(),
  version: Joi.number().allow(null),
  type: Joi.string().required(),
});

export const deleteAttachmentSchema = Joi.object({
  kra_itemkey: Joi.string().allow(''),
  kra_attachmentid: Joi.number().allow(null),
});
class ExcelValidator {
  constructor(options = {}) {
    this.options = {
      requireSheets: 1,
      allowedExtensions: ['.xlsx', '.xls', '.csv'],
    };
  }

  async validateFile(filePath) {
    try {
      await this.checkFileExists(filePath);
      await this.validateFileProperties(filePath);

      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.readFile(filePath);

      const sheetInfo = await this.validateWorkbook(workbook);

      return {
        isValid: true,
        message: 'Valid Excel file',
        details: {
          fileName: path.basename(filePath),
          fileSize: await this.getFileSize(filePath),
          sheetCount: workbook.worksheets.length,
          sheetInfo,
        },
      };
    } catch (error) {
      return {
        isValid: false,
        message: `Excel Validation Proccess Failed.`,
      };
    }
  }

  async validateContent(filePath, rules) {
    try {
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.readFile(filePath);
      const worksheet = workbook.worksheets[0];

      const headers = new Map();
      const errors = [];

      // Map headers to column letters
      worksheet.getRow(1).eachCell((cell, colNumber) => {
        headers.set(worksheet.getColumn(colNumber).letter, cell.value);
      });

      // Validate each row
      for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
        const row = worksheet.getRow(rowNumber);
        await this.validateRow(row, rules, headers, errors, rowNumber);
      }

      return {
        isValid: errors.length === 0,
        errors,
        details: {
          rowCount: worksheet.rowCount,
          columnCount: worksheet.columnCount,
        },
      };
    } catch (error) {
      return {
        isValid: false,
        message: `Content validation failed: ${error.message}`,
      };
    }
  }

  async checkFileExists(filePath) {
    try {
      await fs.access(filePath);
    } catch {
      throw new Error('File does not exist');
    }
  }

  async validateFileProperties(filePath) {
    const extension = path.extname(filePath).toLowerCase();
    if (!this.options.allowedExtensions.includes(extension)) {
      throw new Error(
        `Invalid file extension. Allowed: ${this.options.allowedExtensions.join(
          ', ',
        )}`,
      );
    }
  }

  async getFileSize(filePath) {
    const stats = await fs.stat(filePath);
    return `${(stats.size / 1024).toFixed(2)} KB`;
  }

  async validateWorkbook(workbook) {
    if (workbook.worksheets.length < this.options.requireSheets) {
      throw new Error(
        `Excel file must contain at least ${this.options.requireSheets} sheet(s)`,
      );
    }

    const sheetInfo = workbook.worksheets.map(worksheet => ({
      name: worksheet.name,
      rowCount: worksheet.rowCount,
      columnCount: worksheet.columnCount,
      isEmpty: worksheet.rowCount <= 1,
    }));

    if (sheetInfo.every(sheet => sheet.isEmpty)) {
      throw new Error('Excel file contains no data');
    }

    return sheetInfo;
  }

  async validateRow(row, rules, headers, errors, rowNumber) {
    for (const [col, rule] of Object.entries(rules)) {
      const cell = row.getCell(col);
      const value = cell.value;
      const columnName = headers.get(col);

      if (rule.required && !value) {
        errors.push(
          `Row ${rowNumber}, Column ${columnName}: Required field is empty`,
        );
        continue;
      }

      if (value && rule.type) {
        this.validateDataType(value, rule.type, rowNumber, columnName, errors);
      }

      if (rule.regex && value) {
        this.validateRegex(value, rule.regex, rowNumber, columnName, errors);
      }
    }
  }

  validateDataType(value, type, rowNumber, columnName, errors) {
    const validators = {
      number: val => !isNaN(val),
      email: val => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val),
      date: val => val instanceof Date || !isNaN(new Date(val)),
      phone: val => /^\+?[\d\s-]{10,}$/.test(val),
      url: val => {
        try {
          new URL(val);
          return true;
        } catch {
          return false;
        }
      },
    };

    if (!validators[type]?.(value)) {
      errors.push(`Row ${rowNumber}, Column ${columnName}: Invalid ${type}`);
    }
  }

  validateRegex(value, regex, rowNumber, columnName, errors) {
    if (!value.toString().match(regex)) {
      errors.push(`Row ${rowNumber}, Column ${columnName}: Format mismatch`);
    }
  }
}

export const validateExcel = async filePath => {
  const validator = new ExcelValidator({
    requireSheets: 1,
  });
  try {
    const fileValidation = await validator.validateFile(filePath);
    return fileValidation;
  } catch (error) {
    return {
      isValid: false,
      message: `Excel Validation Proccess Failed.`,
    };
  }
};

export const validateExcelFile = async (req, res) => {
  try {
    const fileDetails = req.body;
    let result = await validateExcel(fileDetails.filePath);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({
      isValid: false,
      message: `Validation error: ${error.message ? error.message : error}`,
    });
  }
};
