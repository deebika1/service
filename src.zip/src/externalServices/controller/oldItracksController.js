import {
  workorderCreationService,
  incomingCreationService,
  stageCreationService,
  productionCustomerDispatchService,
  getACSOrderinflowService,
} from '../service/oldItracksService.js';

export const workorderCreationController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await workorderCreationService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ status: false, message: error?.message });
  }
};

export const incomingCreationController = async (req, res) => {
  try {
    const payload = req.body;
    const out1 = await incomingCreationService(payload);
    if (out1.status) {
      const out2 = await stageCreationService(payload);
      res.status(200).send(out2);
    } else {
      res.status(200).send(out1);
    }
  } catch (error) {
    res.status(400).send({ status: false, message: error?.message });
  }
};

export const stageCreationController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await stageCreationService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ status: false, message: error?.message });
  }
};

export const productionCustomerDispatchController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await productionCustomerDispatchService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ status: false, message: error?.message });
  }
};

export const acsOifOldItracksSyncController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getACSOrderinflowService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ status: false, message: error?.message });
  }
};
