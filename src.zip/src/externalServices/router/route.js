import express from 'express';
import swaggerUi from 'swagger-ui-express';
import { readFileSync } from 'fs';
import olditracksRoutes from './oldItrackRoutes.js';

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}
const externalServiceRouter = express.Router();
swaggerDocs(externalServiceRouter);

// oldItracksServiceRouter
externalServiceRouter.use('/olditracks', olditracksRoutes);

export default externalServiceRouter;
