import express from 'express';
import {
  workorderCreationController,
  incomingCreationController,
  stageCreationController,
  productionCustomerDispatchController,
  acsOifOldItracksSyncController,
} from '../controller/oldItracksController.js';
// import {
//   validateRequestBody,
//   validateRequestParams,
// } from '../helpers/middleware.js';

const olditracksRoutes = express.Router();
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };
// order in flow
olditracksRoutes.post(
  '/workordercreation',
  handler(workorderCreationController),
);
olditracksRoutes.post('/incomingCreation', handler(incomingCreationController));
olditracksRoutes.post('/stagecreation', handler(stageCreationController));

olditracksRoutes.post(
  '/dispatch',
  handler(productionCustomerDispatchController),
);
olditracksRoutes.post('/acsoifsync', handler(acsOifOldItracksSyncController));

export default olditracksRoutes;
