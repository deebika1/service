import { query } from '../../database/postgres.js';
import {
  insertWorkorderScript,
  insertsubjobdetailsScript,
  insertstageScript,
  insertIncomingScript,
  insertIncomingDetailScript,
  productionDispatch,
  customerDispatch,
  updateSubjobdetail,
  acsOifOldItracksSyncScript,
} from '../datalayer/oldItrackScript.js';

export const workorderCreationService = async inputdata => {
  try {
    let message = '';
    let mstatus = false;
    let workorderid = 0;
    const masterdetails = await getmasterdataid(inputdata);

    if (masterdetails.status) {
      const woresult = await createworkorder(inputdata, masterdetails.data);
      workorderid = woresult.workorderid;
    } else {
      message = masterdetails.remarks;
      mstatus = false;
    }
    if (workorderid > 0) {
      mstatus = true;
    }

    return { message, status: mstatus };
  } catch (error) {
    return { message: error.message, status: false };
  }
};

// const createworkordercontact = async(inputdata,workorderid )=> {

// }

export const incomingCreationService = async inputdata => {
  let message = '';
  let mstatus = false;
  let loopinterup = false;
  try {
    const { workorderid, receiptdate, subjobs } = inputdata;

    const masterdetails = await getIncomingMasterdata(inputdata);

    if (masterdetails.status) {
      const script_income = insertIncomingScript();
      const execute_inc = await query(script_income, [
        workorderid,
        masterdetails.data.serviceid,
        masterdetails.data.stageid,
        receiptdate,
      ]);

      if (execute_inc[0] && execute_inc[0].woincomingid > 0) {
        for (const subjob of subjobs) {
          const { filename } = subjob;
          const filepath = subjob.filepath || null;
          const mspages = subjob.mspages || 0;
          const estimatedpages = subjob.estimatedpages || null;
          const wordcount = subjob.wordcount || null;
          const imagecount = subjob.imagecount || null;
          const duedate = subjob.duedate || null;
          const startpage = subjob.startpage || null;
          const endpage = subjob.endpage || null;

          try {
            const script_incomedet = insertIncomingDetailScript();
            const execute_incdet = await query(script_incomedet, [
              execute_inc[0].woincomingid,
              filename,
              filepath,
              duedate,
              mspages,
              estimatedpages,
              wordcount,
              imagecount,
              true,
              masterdetails.filetypeid,
            ]);

            if (!execute_incdet) {
              loopinterup = true;
              message = 'error in incoming creation';
              break;
            }

            const subjobscript = insertsubjobdetailsScript();

            const execute_subjob = await query(subjobscript, [
              workorderid,
              masterdetails.data.filetypeid,
              filename,
              startpage,
              endpage,
              mspages,
              estimatedpages,
              imagecount,
              wordcount,
            ]);

            if (!execute_subjob) {
              loopinterup = true;
              message = 'error in subjob creation';
              break;
            }
          } catch (error) {
            loopinterup = true;
            console.error('Error while processing subjob:', error);
            break; // Exit the loop if an error occurs
          }
        }
        mstatus = true;
      } else {
        message = 'error created on processing incoming';
        mstatus = false;
      }
    } else {
      message = masterdetails.remarks;
    }

    if (loopinterup) {
      message = 'error created on processing incoming detail';
      mstatus = false;
    }

    return { message, status: mstatus };
  } catch (e) {
    return { message: e.message, status: false };
  }
};

export const stageCreationService = async inputdata => {
  try {
    let wostageid = 0;
    let mstatus = false;
    let message = '';
    const {
      status,
      workorderid,
      plannedenddate,
      stageiterationcount,
      startdatetime,
      enddatetime,
      ordermaildatetime,
      productiondespatchdate,
      customerdespatchdate,
    } = inputdata;

    const masterdetails = await getstagemasterdata(inputdata);

    if (masterdetails.status) {
      const stagescript = insertstageScript();
      const executeresult = await query(stagescript, [
        masterdetails.data.serviceid,
        masterdetails.data.stageid,
        status,
        workorderid,
        plannedenddate,
        stageiterationcount,
        startdatetime,
        enddatetime,
        ordermaildatetime,
        productiondespatchdate,
        customerdespatchdate,
      ]);
      wostageid = executeresult[0].wostageid;
      mstatus = true;
      message = 'success';
    } else {
      message = masterdetails.remarks;
    }
    return { wostageid, message, status: mstatus };
  } catch (e) {
    return { message: e.message, status: false };
  }
};

const createworkorder = async (inputdata, masterdetails) => {
  try {
    let status = false;
    const script = insertWorkorderScript();

    const executeresult = await query(script, [
      inputdata.Bookcode,
      inputdata.JobTitle,
      masterdetails.wfid || null,
      masterdetails.customerid,
      masterdetails.divisionid,
      masterdetails.verticalid,
      masterdetails.countryid,
      masterdetails.softwareid,
      inputdata.doinumber,
      masterdetails.wotype || 'Article',
      masterdetails.inputfiletypeid || 2,
      masterdetails.languageid,
      masterdetails.celevelid,
      masterdetails.complexityid,
      'In Process',
      masterdetails.journalid,
      inputdata.issuenumber,
      inputdata.volumenumber,
      inputdata.currencyid,
      inputdata.jobtype,
    ]);

    let workorderid = 0;
    if (executeresult) {
      workorderid = executeresult[0].workorderid;
      status = true;
    }
    return { workorderid, status };
  } catch (e) {
    // console.log(e)
    return { workorderid: 0, status: false };
  }
};

const getmasterdataid = async inputdata => {
  try {
    let message = '';
    let status = false;
    const {
      customer,
      division,
      customerdivision,
      vertical,
      country,
      software,
      language,
      celevel,
      complexity,
      journalcode,
      currency,
    } = inputdata;

    const cusscript = ` select omc.customerid, omc.itrack_customerid  as icustid 
        from mst_customer mc 
        join org_mst_customer omc on omc.itrack_customerid = mc.customerid 
        where mc.customername = $1 and mc.isactive = true and omc.isactive  =true `;
    const custresult = await query(cusscript, [customer]);
    const customerid = custresult[0] ? custresult[0].customerid : -1;
    message = customerid == -1 ? 'customerid,' : '';

    const divscript = `select md.duid ,omd.itrackduid as iduid 
        from mst_deliveryunit md 
        join org_mst_deliveryunit omd on omd.itrackduid  = md.duid 
        where md.duname = $1 and omd.isactive = true and md.isactive  =true `;
    const divresult = await query(divscript, [division]);
    const duid = divresult[0] ? divresult[0].duid : -1;
    message += duid == -1 ? ' duid,' : '';

    const vertscript = `select oms.subdivisionid , oms.itrack_vertical_id 
                     from wms_mst_vertical wmv
                     join org_mst_subdivision oms on oms.itrack_vertical_id = wmv.verticalid 
                     where wmv.verticalname = $1 and oms.isactive = true and wmv.isactive = true`;
    const verticalresult = await query(vertscript, [vertical]);
    const verticalid = verticalresult[0] ? verticalresult[0].subdivisionid : -1;
    message += verticalid == -1 ? ' verticalid,' : '';

    const countryscript = `select countryid  
                          from geo_mst_country gmc 
                          where countryname = $1 and isactive  = true`;
    const countryresult = await query(countryscript, [country]);
    const countryid = countryresult[0] ? countryresult[0].countryid : -1;
    message += countryid == -1 ? ' countryid,' : '';

    const softwarescript = `select softwareid  from 
                      pp_mst_composingsoftware pmc 
                      where isactive = true and softwarename ilike $1`;
    const softresult = await query(softwarescript, [software]);
    const softwareid = softresult[0] ? softresult[0].softwareid : -1;
    message += softwareid == -1 ? ' softwareid,' : '';

    const langscript = `select languageid from 
                        wms_mst_language wml    
                        where isactive = 1 and languagename  = $1`;
    const langresult = await query(langscript, [language]);
    const languageid = langresult[0] ? langresult[0].languageid : -1;
    message += languageid == -1 ? ' languageid,' : '';

    const journalscript = `select journalid  
                            from pp_mst_journal pmj  
                            where journalacronym  = $1 
                            and isactive  = 1`;
    const journalresult = await query(journalscript, [journalcode]);
    const journalid = journalresult[0] ? journalresult[0].journalid : -1;
    message += journalid == -1 ? ' journalid,' : '';

    const celevelscript = `SELECT x.celevelid  FROM public.pp_mst_copyeditinglevel x
                     WHERE celevel  = $1`;
    const celeveresult = await query(celevelscript, [celevel]);
    const celevelid = celeveresult[0] ? celeveresult[0].celevelid : -1;
    message += celevelid == -1 ? ' celevelid,' : '';

    const complscript = `SELECT complexityid  FROM public.wms_mst_complexity where complexity = $1 and  isactive  = 1 `;
    const complresult = await query(complscript, [complexity]);
    const complexityid = complresult[0] ? complresult[0].complexityid : -1;
    // message += complexityid == -1 ? ' complexityid,' : '';

    const custdivision = `select divisionid from org_mst_division omd where division = $1 and isactive  = true`;
    const divisionresult = await query(custdivision, [customerdivision]);
    const divisionid = divisionresult[0] ? divisionresult[0].divisionid : -1;
    message += divisionid == -1 ? ' divisionid,' : '';

    const currencyscript = `SELECT currencyid FROM public.Mst_CurrencyMst WHERE currencycode  = $1 and isactive  = true `;
    const currencyresult = await query(currencyscript, [currency]);
    const currencyid = currencyresult[0] ? currencyresult[0].currencyid : -1;
    message += currencyid == -1 ? ' currencyid,' : '';

    if (message.length > 0) {
      message += ' not found';
    } else {
      status = true;
    }

    const datacollection = {
      customerid,
      duid,
      divisionid,
      verticalid,
      countryid,
      softwareid,
      languageid,
      journalid,
      celevelid,
      complexityid,
      customerdivision,
      currencyid,
    };

    return { data: datacollection, status, remarks: message };
  } catch (e) {
    return { data: {}, status: false };
  }
};

const getstagemasterdata = async inputdata => {
  try {
    const { service, stagename } = inputdata;
    let status = false;
    let message = '';
    const servicescript = `select serviceid  from wms_mst_service wms where isactive = true and servicename = $1`;
    const serviceresult = await query(servicescript, [service]);
    const serviceid = serviceresult[0] ? serviceresult[0].serviceid : -1;
    message += serviceid == -1 ? ' serviceid,' : '';

    const stagecript = `select stageid from wms_mst_stage wms where isactive = true and stagename = $1`;
    const stageresult = await query(stagecript, [stagename]);
    const stageid = stageresult[0] ? stageresult[0].stageid : -1;
    message += stageid == -1 ? ' stageid,' : '';

    if (message.length > 0) {
      message += ' not found';
    } else {
      status = true;
    }

    const datacollection = {
      serviceid,
      stageid,
    };

    return { data: datacollection, status, remarks: message };
  } catch (e) {
    return { data: {}, status: false };
  }
};

const getIncomingMasterdata = async inputdata => {
  try {
    const { service, stagename, filetype } = inputdata;
    let status = false;
    let message = '';

    const servicescript = `select serviceid  from wms_mst_service wms where isactive = true and servicename ilike $1`;
    const serviceresult = await query(servicescript, [service]);
    const serviceid = serviceresult[0] ? serviceresult[0].serviceid : -1;
    message += serviceid == -1 ? ' serviceid,' : '';

    const stagecript = `select stageid from wms_mst_stage wms where isactive = true and stagename ilike $1`;
    const stageresult = await query(stagecript, [stagename]);
    const stageid = stageresult[0] ? stageresult[0].stageid : -1;
    message += stageid == -1 ? ' stageid,' : '';

    const filetypscript = `select filetypeid from pp_mst_inputfiletype pmi where filetypename ilike $1`;
    const fileresult = await query(filetypscript, [filetype]);
    const filetypeid = fileresult[0] ? fileresult[0].filetypeid : 0;
    message += filetypeid == -1 ? ' filetypeid,' : '';

    if (message.length > 0) {
      message += ' not found';
    } else {
      status = true;
    }

    const datacollection = {
      serviceid,
      stageid,
      filetypeid,
    };

    return { data: datacollection, status, remarks: message };
  } catch (e) {
    return { data: {}, status: false };
  }
};

// Production dispatch and customer dispatch
export const productionCustomerDispatchService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      let status = false;
      const result = [];
      const message = '';
      const sql = updateSubjobdetail();

      for (const record of info) {
        try {
          const {
            mode,
            workorderId,
            stageId,
            stageIteration,
            typesetPages,
            userId,
          } = record;

          if (mode === 'production dispatch') {
            const qty = productionDispatch();
            const productionDis = await query(qty, [
              workorderId,
              stageId,
              stageIteration,
              typesetPages,
            ]);

            if (productionDis && productionDis.length > 0) {
              const updatesubjob = await query(sql, [
                userId,
                workorderId,
                stageId,
                stageIteration,
              ]);

              if (updatesubjob && updatesubjob.length > 0) {
                status = true;
                result.push({
                  workorderId,
                  stageId,
                  stageIteration,
                  status,
                  message: 'Production dispatch completed successfully!',
                });
              }
            } else {
              result.push({
                workorderId,
                stageId,
                stageIteration,
                status: false,
                message: 'No data found for production dispatch',
              });
            }
          } else {
            const qty = customerDispatch();
            const custDis = await query(qty, [
              workorderId,
              stageId,
              stageIteration,
            ]);

            if (custDis && custDis.length > 0) {
              const updatesubjob = await query(sql, [
                userId,
                workorderId,
                stageId,
                stageIteration,
              ]);

              if (updatesubjob && updatesubjob.length > 0) {
                status = true;
                result.push({
                  workorderId,
                  stageId,
                  stageIteration,
                  status,
                  message: 'Customer dispatch completed successfully!',
                });
              }
            } else {
              result.push({
                workorderId,
                stageId,
                stageIteration,
                status: false,
                message: 'No data found for customer dispatch',
              });
            }
          }
        } catch (error) {
          result.push({
            workorderId: record.workorderId,
            stageId: record.stageId,
            stageIteration: record.stageIteration,
            status: false,
            message: `Error: ${error.message}`,
          });
        }
      }

      resolve({ status, data: result, remarks: message });
    } catch (error) {
      reject({ status: false, error: error.message });
    }
  });
};

export const getACSOrderinflowService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { du, customer, startDate, endDate } = payload;
      const script = acsOifOldItracksSyncScript();
      const result = await query(script, [du, customer, startDate, endDate]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
