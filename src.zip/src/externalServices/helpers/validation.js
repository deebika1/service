import Joi from 'joi';

export const exampleSchema = Joi.object({
  bookcode: Joi.string().allow('').required(),
  jobcardcode: Joi.number().allow(null).required(),
  jobtitle: Joi.string().allow('').required(),
  fromdate: Joi.date().allow(null).required(),
  todate: Joi.date().allow(null).required(),
  divisions: Joi.number().allow(null).required(),
  customers: Joi.number().allow(null).required(),
  companyid: Joi.number().allow(null).required(),
  searchby: Joi.string().allow('').required(),
  isbn: Joi.string().allow('').required(),
  jobcardid: Joi.number().allow(null).required(),
});
