export const insertWorkorderScript = () => {
  const script = `insert into wms_workorder 
                  (itemcode, title, wfid, customerid ,divisionid
                  ,subdivisionid, countryid, composingsoftwareid, doinumber, wotype
                  ,inputfiletypeid,languageid,celevelid,complexityid,status
                  ,journalid,issuenumber,volumenumber,currencyid,jobtype)
                  values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20) returning workorderid`;
  return script;
};

export const insertsubjobdetailsScript = () => {
  const script = `INSERT INTO public.subjobdetails (
      workorderid, filetypeid, subjobname, startpage, endpage,
      mspage,  estimatedpages, imagecount, wordcount
    )
    values ($1, $2, $3, $4, $5, $6, $7, $8, $9) returning subjobid`;

  return script;
};

export const insertstageScript = () => {
  const script = `insert into wms_workorder_stage(
            serviceid,wfstageid , status , workorderid,
            plannedenddate,stageiterationcount,
            startdatetime,enddatetime, ordermaildatetime,
            productiondespatchdate,customerdespatchdate)
            values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) returning wostageid`;

  return script;
};

export const insertIncomingScript = () => {
  const script = `insert into wms_workorder_incoming(
                woid ,serviceid ,stageid ,receiptdate)
                values ($1, $2, $3, $4 ) returning woincomingid`;
  // duedate
  return script;
};

export const insertIncomingDetailScript = () => {
  const script = `insert into wms_workorder_incomingfiledetails(woincomingid,filename
              ,filepath,duedate,mspages,estimatedpages,wordcount,imagecount,isactive,filetypeid)
              values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) returning woincomingfileid`;

  return script;
};
export const productionDispatch = () => {
  const script = `update public.wms_workorder_stage set 
  productiondespatchdate = current_timestamp ,typesetpages = $4
  where workorderid = $1 and wfstageid = $2 and stageiterationcount = $3 
  returning wostageid`;

  return script;
};

export const customerDispatch = () => {
  const script = `update public.wms_workorder_stage set 
  enddatetime = current_timestamp, status = 'Completed',customerdespatchdate = current_timestamp
  where workorderid = $1 and wfstageid = $2 and stageiterationcount = $3 
  returning wostageid`;
  return script;
};

export const updateSubjobdetail = () => {
  const script = `update public.subjob_eventlog_details set 
  status = 'Completed',  
  updated_by = $1,
  updated_time = current_timestamp,
  assigneduserid = $1
  where 
  workorderid = $2 and 
  stageid = $3 and 
  stageiterationcount = $4
  returning subjobid`;

  return script;
};

export const acsOifOldItracksSyncScript = () => {
  const script = ` 
  	;with cte AS
	   (
	    select 
	    osr.ord_inflowid, oir.workorderid , oir.bookcode as jobid 
	   ,coalesce(osr.actualinflowvalue ,0) as ordervalue
	   ,osr.ordermonth ::date as orderdate, to_char(osr.ordermonth,'MON') as ordermonth, osr.serviceid
	   ,osr.servicename as service, osr.stageid, osr.stagename
	   ,oir.divisionid ,oir.baseduname as du, oir.customerid, oir.customername as customer
	   ,oir.divisionname as division, oir.countryid, oir.countryname as country
	   ,oir.verticalid, oir.verticalname as vertical
	   ,oir.currencyid  ,oir.currencyname as currencycode 
	   ,osr.billableduid , osr.billableduname, kam.kamempcode  
	   ,wu.username as kam ,pmjc.name as projectmanager 
	   ,wo.createdon as jobcreateddate
	   ,wo.title
	   ,osr.rate ,osr.uomqty, osr.actualinflowvalue
	   ,(select max(created_time) from salespmo.trn_journal_rate tjr where journalid = wo.journalid  ) as rateentereddate
	   ,osr.transferremarks 
	   ,osr.adjqty
	  FROM salespmo.trn_ord_inflow_report as oir
	  JOIN salespmo.trn_ord_inflow_stagewise_report as osr on oir.ord_inflowid = osr.ord_inflowid 
	  JOIN wms_workorder wo on wo.workorderid = oir.workorderid and coalesce(wo.islock,false) = false
	  LEFT JOIN pp_mst_journal_contacts pmjc  on pmjc.journalid = wo.journalid AND pmjc.designation = '1'
	  LEFT JOIN salespmo.trn_kamcustomerrel as kam on kam.customerid = oir.customerid  
													 AND kam.divisionid = oir.divisionid  
													 AND kam.verticalid = oir.verticalid  
													 AND kam.serviceid  = osr.serviceid
	  LEFT JOIN wms_user wu on wu.userid = kam.kamempcode  
	  
	  WHERE oir.isactive = true 
	    AND oir.flowtype  = 'NEW'   
      and oir.baseduname ILIKE '%' || COALESCE($1, '') || '%'
	    and oir.customername ILIKE '%' || COALESCE($2, '') || '%'
--    AND (oir.baseduid = COALESCE($1, oir.baseduid))
--	  AND (
--	        oir.customername ILIKE '%' || COALESCE($4, '') || '%'
--	        OR oir.verticalname ILIKE '%' || COALESCE($4, '') || '%'
--	        OR oir.bookcode ILIKE '%' || COALESCE($4, '') || '%'
--	       )
	    AND ((osr.ordermonth  + interval '5 hours 30 minutes')::date BETWEEN COALESCE($3, osr.ordermonth )::date AND COALESCE($4, osr.ordermonth )::date)
	  ORDER BY oir.workorderid , osr.ord_inflowid
	    )
	  SELECT du, customer
	   , sum(ordervalue) as ordervalue     
	   from cte
	  GROUP BY du, customer ;
  `;
  return script;
};
