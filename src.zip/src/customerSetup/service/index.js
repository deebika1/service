import { query, transaction } from '../../database/postgres.js';
import {
  getActiveSectionTabs,
  checkIsCombinationExist,
  // UpdateDUCustType,
  getInfoListforInsert,
  InsertCustomerSetup,
  getActiveInfo,
  UpdateWOConfig,
  getActiveMstFields,
  getActiveInfoFields,
  IsFieldExist,
  InsertFieldsforTabandInfo,
  UpdateFieldsforTabandInfo,
  getActiveCustomerSetup,
  deleteCustomerSetup,
  getDUFlowType,
  UpdateCustomerSetup,
  getExistInfoList,
  UpdateCustMapping,
  getMandatoryFields,
  checkorgMapIsExist,
  insertCustomerOrgMap,
  checkIsCombExist,
  InsDuCusFlowType,
  deleteDuCusFlowType,
  updateDuCusFlowType,
} from '../dayaLayer/index.js';

import {
  checkWFDuplicate,
  insertWorkflow,
  addWorkflowid,
  getWorkflow,
  getScreenid,
  getCustWorkfolwid,
  getAllWorkflow,
} from '../dayaLayer/workflow.js';

import {
  getWoUseristScript,
  getCustorgmapId,
  getUserDetails,
  insContactMst,
  updateContactMst,
} from '../dayaLayer/userSetup.js';

import {
  getMailListScript,
  getMailForCC,
  updEmailtoCusMap,
} from '../dayaLayer/prodDespMailConfig.js';

export const getActiveSectionTabsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        // duid,
        // customerid,
        // divisionid,
        // verticalid,
        // countryid,
        custmappingId,
      } = payload;
      const script = getActiveSectionTabs();
      const result = await query(script, [
        // duid,
        // customerid,
        // divisionid,
        // verticalid,
        // countryid,
        custmappingId,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const checkIsCombinationExistService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, customerId, divisionId, verticalId, countryId } = payload;
      const script = checkIsCombinationExist();
      const result = await query(script, [
        duId,
        customerId,
        divisionId,
        verticalId,
        countryId,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const InsertCustomerSetupService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        duId,
        customerId,
        divisionId,
        verticalId,
        countryId,
        customerType,
        sections,
        ModifiedBy,
        custMapping,
        lockJobType,
        rateEntryType,
      } = payload;
      let result;

      if (custMapping > 0) {
        const updateScript = UpdateCustMapping();
        await query(updateScript, [
          custMapping,
          duId,
          customerId,
          divisionId,
          verticalId,
          countryId,
        ]);
      }
      await insorUpdateDUCustType(duId, customerId, customerType, ModifiedBy); // for Flow type

      const isCombExistScript = checkorgMapIsExist();
      const insertcustCombScript = insertCustomerOrgMap();

      divisionId.forEach(data => {
        countryId.forEach(async item => {
          const isCombExist = await query(isCombExistScript, [
            duId,
            customerId,
            data,
            verticalId,
            item,
          ]);
          if (isCombExist[0].count == 0) {
            await query(insertcustCombScript, [
              customerId,
              data,
              verticalId,
              item,
              duId,
            ]);
          }
        });
      });

      const InfoInsertScript = getInfoListforInsert();
      const InfoList = await query(InfoInsertScript);

      const isExistScript = checkIsCombinationExist();
      const isExist = await query(isExistScript, [
        duId,
        customerId,
        divisionId,
        verticalId,
        countryId,
      ]);

      const getMandatoryFieldsScript = getMandatoryFields();
      const mandatoryFields = await query(getMandatoryFieldsScript);
      const InsertFieldScript = InsertFieldsforTabandInfo();

      if (isExist[0].count > 0) {
        const getInfoScript = getExistInfoList();
        const existInfoList = await query(getInfoScript, [
          duId,
          customerId,
          divisionId,
          verticalId,
          countryId,
        ]);

        const script = UpdateCustomerSetup();
        result = await query(script, [
          duId,
          customerId,
          divisionId,
          verticalId,
          countryId,
          sections,
          existInfoList[0].infoid,
          ModifiedBy,
          lockJobType,
          rateEntryType,
        ]);
      } else {
        const script = InsertCustomerSetup();
        result = await query(script, [
          duId,
          customerId,
          divisionId,
          verticalId,
          countryId,
          sections,
          InfoList[0].infolist,
          true,
          ModifiedBy,
          lockJobType,
          rateEntryType,
        ]);
        mandatoryFields.map(async item => {
          await query(InsertFieldScript, [
            result[0].custmapping,
            item.infoid,
            item.fieldtype,
            item.labelname,
            item.placeholder,
            item.minlength,
            item.maxlength,
            item.regexpattern,
            item.bindname,
            item.ismandatory,
            false,
            true,
            item.sequence,
            item.endpoint,
            ModifiedBy,
            item.datatype,
          ]);
        });
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getActiveInfoService = async custMappingId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getActiveInfo();
      const result = await query(script, [custMappingId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const UpdateWOConfigService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { custMapId, InfoList, ModifiedBy } = payload;
      const script = UpdateWOConfig();
      const result = await query(script, [custMapId, InfoList, ModifiedBy]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getActiveMstFieldsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { custMapId, infoId } = payload;
      const script = getActiveMstFields();
      const result = await query(script, [custMapId, infoId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getActiveInfoFieldsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { custMapId, infoId } = payload;
      const script = getActiveInfoFields();
      const result = await query(script, [custMapId, infoId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const InsertFieldsforTabandInfoService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { custMapId, infoId, fieldsList, ModifiedBy } = payload;
      const existScript = IsFieldExist();
      const insertScript = InsertFieldsforTabandInfo();
      const updateScript = UpdateFieldsforTabandInfo();

      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            let result = '';
            for (const item of fieldsList) {
              const isExist = await client.query(existScript, [
                custMapId,
                infoId,
                item.fieldtype,
                item.labelname,
              ]);
              if (isExist.rows[0].count == 0 && !item.isdelete) {
                result = await client.query(insertScript, [
                  custMapId,
                  infoId,
                  item.fieldtype,
                  item.labelname,
                  item.placeholder,
                  item.minlength,
                  item.maxlength,
                  item.regexpattern,
                  item.bindname,
                  item.mandatory,
                  false,
                  !item.isdelete,
                  item.sequence,
                  item.endpoint,
                  ModifiedBy,
                  item.datatype,
                ]);
              } else if (isExist.rows[0].count == 1) {
                result = await client.query(updateScript, [
                  item.custcontrollid,
                  item.mandatory,
                  !item.isdelete,
                  ModifiedBy,
                ]);
              }
            }
            tresolve(result);
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('success');
    } catch (error) {
      reject(error);
    }
  });
};

export const getActiveCustomerSetupService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerId, searchText } = payload;
      const script = getActiveCustomerSetup();
      const result = await query(script, [customerId, searchText]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteCustomerSetupService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { custMapId } = payload;
      const script = deleteCustomerSetup();
      let result = await query(script, [custMapId]);
      const delFlowTypeScript = deleteDuCusFlowType();
      result = await query(delFlowTypeScript, [
        result[0].duid,
        result[0].customerid,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getFlowTypeDUService = async (duId, customerId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getDUFlowType();
      const result = await query(script, [duId, customerId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const addWorkflowService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfname, custmapId } = payload;
      const Err = [];
      const script = checkWFDuplicate();
      const Insertscript = insertWorkflow(); // workflow create

      await transaction(async client => {
        try {
          const workflowPromises = wfname.map(async workflow => {
            const ischeck = await client.query(script, [workflow.label]);
            if (!ischeck.rows[0].duplicate) {
              const custid = await client.query(getCustWorkfolwid(), [
                custmapId,
              ]);
              const result = await client.query(Insertscript, [
                workflow.label,
                parseInt(custid.rows[0].customerid),
              ]);
              if (result) {
                Err.push(`${workflow.label} is created`);
              }
            } else {
              Err.push({
                message: `${workflow.label} is already available`,
                status: false,
              });
            }
          });
          await Promise.all(workflowPromises);
        } catch (error) {
          reject(error);
        }
      });

      const wfId = await getSelectedWorkflow(wfname);
      const InsertWFscript = addWorkflowid();
      await query(InsertWFscript, [custmapId, wfId]);
      resolve([{ status: true, message: Err }]);

      // if (!ischeck[0].duplicate) {
      //   const custid = await query(getCustWorkfolwid(), [custmapId]);
      //   // workflow create
      //   script = insertWorkflow();
      //   const wf = await query(script, [wfname, custid[0]?.customerid]);
      //   if (wf[0].wfid) {
      //     script = addWorkflowid();
      //     await query(script, [custmapId, wf[0].wfid]);
      //     resolve([{ status: true }]);
      //   }
      // } else {
      //   resolve([
      //     { message: 'WorkFlow name is already available', status: false },
      //   ]);
      // }
    } catch (error) {
      reject(error);
    }
  });
};

export const geWorkflowService = async cId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getWorkflow();
      const result = await query(script, [cId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const geScreenIdService = async path => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getScreenid();
      const result = await query(script, [path]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

const insorUpdateDUCustType = async (duId, customerId, flowtype, userId) => {
  try {
    const isExistScript = checkIsCombExist();
    // const count = await query(isExistScript, [duId, customerId, flowtype]);
    const count = await query(isExistScript, [duId, customerId]);
    if (count[0].count == 0) {
      const insScript = InsDuCusFlowType();
      await query(insScript, [duId, customerId, flowtype, userId]);
    } else {
      const updScript = updateDuCusFlowType();
      await query(updScript, [duId, customerId, flowtype]);
    }
  } catch (error) {
    console.log(error);
  }
};

export const getAllWorkflowService = async custMapId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getAllWorkflow();
      const result = await query(script, [custMapId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSelectedWorkflow = async wfname => {
  const result = await query(
    `SELECT wfid FROM public.wms_workflow WHERE wfname = ANY(ARRAY[${wfname.map(
      workflow => `'${workflow.label}'`,
    )}]);`,
  );
  return result.map(data => parseInt(data.wfid));
};

// Workorder User Setup
export const getWOUserListService = async () => {
  const script = getWoUseristScript();
  const result = await query(script);
  return result;
};

export const insContactMstService = async payload => {
  const { duId, customerId, divisionId, subDivisionId, country, role, woUser } =
    payload;
  const getCustorgmapIdScript = getCustorgmapId();
  const custOrgMapId = await query(getCustorgmapIdScript, [
    duId,
    customerId,
    divisionId,
    subDivisionId,
    country,
  ]);
  const getUserDetailScript = getUserDetails();
  const userDet = await query(getUserDetailScript, [woUser]);
  const insertScript = insContactMst();
  const result = await query(insertScript, [
    custOrgMapId[0].custorgmapid,
    userDet[0].username,
    userDet[0].useremail,
    userDet[0].useraddress,
    userDet[0].userphone,
    true,
    'Integra',
    woUser,
    role,
  ]);
  return result;
};

export const updateContactMstService = async payload => {
  const { editData, custorgmapid, woUser } = payload;
  const getUserDetailScript = getUserDetails();
  const userDet = await query(getUserDetailScript, [woUser]);
  const updateScript = updateContactMst();
  const result = await query(updateScript, [
    custorgmapid,
    editData.user.split(' (')[0],
    editData.user.split(' (')[1].split(')')[0],
    editData.roleacronym,
    userDet[0].username,
    userDet[0].useremail,
    userDet[0].useraddress,
    userDet[0].userphone,
    woUser,
  ]);
  return result;
};

// Production Despatch Mail Setup
export const getMailListScriptService = async payload => {
  const { searchText } = payload;
  const script = getMailListScript();
  const result = await query(script, [searchText]);
  return result;
};

export const getMailforCCService = async duId => {
  const script = getMailForCC();
  const result = await query(script, [duId]);
  return result;
};

export const updEmailtoCusMapService = async payload => {
  const { custMappingId, email, ModifiedBy } = payload;
  const script = updEmailtoCusMap();
  const result = await query(script, [custMappingId, email, ModifiedBy]);
  return result;
};
