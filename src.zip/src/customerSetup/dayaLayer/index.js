export const getActiveSectionTabs = () => {
  const script = `SELECT json_agg(json_build_object(
        'id', tab.tabid,
        'label', tab.tabname,
	      'isChecked', CASE WHEN (SELECT COUNT(*) FROM public.wms_config_customertabinfomapping WHERE 
                     --  duid = $1 AND customerid = $2 AND $3 = ANY(divisionid) AND verticalid = $4 AND $5 = ANY(countryid)
				             --  AND tab.tabid = ANY(tabid)) >= 1 THEN true
                     custmapping = $1 AND tab.tabid = ANY(tabid)) >= 1 THEN true
				             ELSE false END
        ) ORDER BY tab.sequence
      ) AS tabs
    FROM public.wms_config_tabs tab WHERE tab.isactive = true;`;
  return script;
};

export const checkIsCombinationExist = () => {
  const script = `SELECT COUNT(*) FROM public.wms_config_customertabinfomapping WHERE duid = $1 AND customerid = $2 AND
        divisionid = $3::bigint[] AND verticalid = $4 AND countryid = $5::bigint[];`;
  return script;
};

export const UpdateDUCustType = () => {
  const script = `UPDATE public.org_mst_deliveryunit SET flowtype = $2 WHERE duid = $1 AND isactive = true;`;
  return script;
};

export const getInfoListforInsert = () => {
  const script = `SELECT array_agg(infoid ORDER BY sequence) AS infoList
    FROM public.wms_config_workorderinfo WHERE isactive = true;`;
  return script;
};

export const InsertCustomerSetup = () => {
  const script = `INSERT INTO public.wms_config_customertabinfomapping (duid, customerid, divisionid, verticalid, 
  countryid, tabid, infoid, isactive, created_by, created_time, job_lock_type, rate_entry_type) 
  VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,CURRENT_TIMESTAMP,$10,$11)
  RETURNING custmapping;`;
  return script;
};

export const getActiveInfo = () => {
  const script = `SELECT json_agg(json_build_object(
          'id', inf.infoid,
          'title', inf.infoname,
	        'value', CASE WHEN (SELECT 1 FROM public.wms_config_customertabinfomapping WHERE 
				              custmapping = $1 AND inf.infoid IS NULL AND inf.isactive = true) = 1 THEN true
					         WHEN (SELECT COUNT(*) FROM public.wms_config_customertabinfomapping WHERE 
				              custmapping = $1 AND inf.infoid = ANY(infoid) AND inf.isactive = true) >= 1 THEN true
				           ELSE false END,
		      'disabled', inf.ismandatory
        ) ORDER BY inf.sequence
      ) AS infoList
    FROM public.wms_config_workorderinfo inf WHERE inf.isactive = true;`;
  return script;
};

export const UpdateWOConfig = () => {
  const script = `UPDATE public.wms_config_customertabinfomapping SET infoid = $2, updated_by = $3,
    updated_time = CURRENT_TIMESTAMP WHERE custmapping = $1 AND isactive = true;`;
  return script;
};

export const getActiveMstFields = () => {
  const script = `SELECT fie.* FROM public.wms_config_fields_map fie
      LEFT JOIN public.wms_config_customerfieldmapping cc ON cc.mappingid = $1 AND cc.infoid = $2
          AND cc.fieldtype = fie.fieldtype AND cc.labelname = fie.labelname AND cc.isactive = true
      WHERE fie.isactive = true AND fie.infoid = $2 AND fie.parentid IS NULL AND fie.screenname = 'Workorder'
      AND cc.infoid IS NULL  -- This filters out the rows that have a match in cc
      ORDER BY fie.sequence;`;
  return script;
};

export const getActiveInfoFields = () => {
  const script = `SELECT cc.*, false AS isDelete, fie.ismandatory FROM public.wms_config_customerfieldmapping cc
      JOIN public.wms_config_fields_map fie ON fie.fieldtype = cc.fieldtype AND fie.labelname = cc.labelname 
        AND fie.isactive = true AND fie.screenname = 'Workorder'
      WHERE cc.mappingid = $1 AND cc.infoid = $2 AND cc.isactive = true ORDER BY cc.sequence;`;
  return script;
};

export const IsFieldExist = () => {
  const script = `SELECT COUNT(*) FROM public.wms_config_customerfieldmapping cc
      WHERE cc.mappingid = $1 AND cc.infoid = $2 AND cc.fieldtype = $3 AND cc.labelname = $4 AND cc.isactive = true;`;
  return script;
};

export const InsertFieldsforTabandInfo = () => {
  const script = `INSERT INTO public.wms_config_customerfieldmapping (mappingid, infoid, fieldtype, labelname, 
  placeholder, minlength, maxlength, pattern, keyname, mandatory, disabled, isactive, sequence, endpoint, created_by, created_time,datatype) 
  VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,CURRENT_TIMESTAMP,$16);`;
  return script;
};

export const UpdateFieldsforTabandInfo = () => {
  const script = `UPDATE public.wms_config_customerfieldmapping SET mandatory = $2, isactive = $3, updated_by = $4, 
  updated_time = CURRENT_TIMESTAMP WHERE custcontrollid = $1;`;
  return script;
};

export const getActiveCustomerSetup = () => {
  const script = `SELECT fm.custmapping, fm.duid, du.duname, fm.customerid, cu.customername, fm.divisionid,
        string_agg(DISTINCT di.division, ', ') AS divisionname, fm.verticalid, sdi.subdivision AS subdivisionname, 
        fm.countryid, string_agg(DISTINCT co.countryname, ',') AS countryname,
        fm.job_lock_type, fm.rate_entry_type, 'action' AS action
      FROM public.wms_config_customertabinfomapping fm
      --  JOIN public.wms_config_customerfieldmapping fmap ON fmap.mappingid = fm.custmapping
      JOIN public.org_mst_deliveryunit du ON du.duid = fm.duid AND du.isactive = true
      JOIN public.org_mst_customer cu ON cu.customerid = fm.customerid AND cu.isactive = true
      JOIN public.org_mst_division di ON di.divisionid = ANY(fm.divisionid) AND di.isactive = true
      JOIN public.org_mst_subdivision sdi ON sdi.subdivisionid = fm.verticalid AND sdi.isactive = true
      JOIN public.geo_mst_country co ON co.countryid = ANY(fm.countryid) AND co.isactive = true
      WHERE fm.isactive = true AND ($1 = '' OR fm.customerid::text IN ($1)) AND
        (du.duname ILIKE '%' || $2 || '%' OR cu.customername ILIKE '%' || $2 || '%')
      GROUP BY fm.custmapping, fm.duid, du.duname, fm.customerid, cu.customername, fm.divisionid,
      	fm.verticalid, sdi.subdivision, fm.countryid
      ORDER BY fm.custmapping DESC;`;
  return script;
};

export const deleteCustomerSetup = () => {
  const script = `UPDATE public.wms_config_customertabinfomapping SET isactive = false WHERE custmapping = $1
  RETURNING duid, customerid;`;
  return script;
};

export const getDUFlowType = () => {
  // const script = `SELECT flowtype FROM public.org_mst_deliveryunit WHERE duid = $1 AND isactive = true;`;
  const script = `SELECT DISTINCT flowtype FROM public.trn_customerflowtype_config WHERE duid = $1 AND customerid = $2 AND isactive = true;`;
  return script;
};

export const UpdateCustomerSetup = () => {
  const script = `UPDATE public.wms_config_customertabinfomapping SET tabid = $6, infoid = $7, updated_by = $8,
    updated_time = CURRENT_TIMESTAMP, job_lock_type = $9, rate_entry_type = $10 WHERE duid = $1 AND customerid = $2 AND divisionid = $3::bigint[] AND 
    verticalid = $4 AND countryid = $5::bigint[] AND isactive = true
    RETURNING custmapping;`;
  return script;
};

export const getExistInfoList = () => {
  const script = `SELECT infoid FROM public.wms_config_customertabinfomapping
      WHERE duid = $1 AND customerid = $2 AND divisionid = $3::bigint[] AND verticalid = $4 AND 
      countryid = $5::bigint[] AND isactive = true;`;
  return script;
};

export const UpdateCustMapping = () => {
  const script = `UPDATE public.wms_config_customertabinfomapping SET duid = $2, customerid = $3, divisionid = $4::bigint[],
  verticalid = $5, countryid = $6::bigint[] WHERE custmapping = $1 AND isactive = true;`;
  return script;
};

export const getMandatoryFields = () => {
  const script = `SELECT * FROM public.wms_config_fields_map WHERE ismandatory = true AND screenname = 'Workorder';`;
  return script;
};

export const checkorgMapIsExist = () => {
  const script = `SELECT COUNT(*) FROM public.org_mst_customer_orgmap cor
    JOIN public.org_mst_customerorg_du_map duor ON duor.custorgmapid = cor.custorgmapid AND duor.duid = $1
    WHERE cor.customerid = $2 AND cor.divisionid = $3 AND cor.subdivisionid = $4 AND cor.countryid = $5;`;
  return script;
};

export const insertCustomerOrgMap = () => {
  const script = `WITH inserted AS (
      INSERT INTO public.org_mst_customer_orgmap (customerid, divisionid, subdivisionid, countryid, isactive)
      VALUES ($1, $2, $3, $4, 1)
      RETURNING custorgmapid)
        INSERT INTO public.org_mst_customerorg_du_map (custorgmapid, duid) SELECT custorgmapid, $5 FROM inserted;`;
  return script;
};

export const checkIsCombExist = () => {
  // const script = `SELECT COUNT(*) FROM public.trn_customerflowtype_config WHERE duid = $1 AND customerid = $2 AND flowtype = $3 AND isactive = true;`;
  const script = `SELECT COUNT(*) FROM public.trn_customerflowtype_config WHERE duid = $1 AND customerid = $2 AND isactive = true;`;
  return script;
};

export const InsDuCusFlowType = () => {
  const script = `INSERT INTO public.trn_customerflowtype_config (duid,customerid,flowtype,createdby,isactive) VALUES ($1,$2,$3,$4,true);`;
  return script;
};

export const deleteDuCusFlowType = () => {
  const script = `UPDATE public.trn_customerflowtype_config SET isactive = false WHERE duid = $1 AND customerid = $2;`;
  return script;
};

export const updateDuCusFlowType = () => {
  const script = `UPDATE public.trn_customerflowtype_config SET flowtype = $3 WHERE duid = $1 AND customerid = $2;`;
  return script;
};
