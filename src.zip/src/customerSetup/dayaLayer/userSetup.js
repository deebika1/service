export const getWoUseristScript = () => {
  const script = `SELECT DISTINCT con.contactname || ' (' || u.userid || ')' AS user, r.rolename || ' (' || con.contactroleid || ')' AS contactrole, 
  co.custorgmapid, r.roleid, r.roleacronym, duo.duid, du.duname, co.customerid, cu.customername, co.divisionid, di.division, 
  co.subdivisionid, sdi.subdivision, co.countryid, cnty.countryname, con.contactname, 'action' AS action
  FROM public.org_mst_customerorg_contact con
  JOIN public.wms_user u on u.username = con.contactname AND u.useractive = true
  JOIN public.org_mst_customer_orgmap co on co.custorgmapid = con.custorgmapid AND co.isactive = 1
  JOIN public.org_mst_customerorg_du_map duo on duo.custorgmapid = co.custorgmapid
  JOIN public.org_mst_deliveryunit du on du.duid = duo.duid AND du.isactive = true
  JOIN public.org_mst_customer cu on cu.customerid = co.customerid
  JOIN public.org_mst_division di on di.divisionid = co.divisionid AND di.isactive = true
  JOIN public.org_mst_subdivision sdi on sdi.subdivisionid = co.subdivisionid AND sdi.isactive = true
  JOIN public.geo_mst_country cnty on cnty.countryid = co.countryid AND cnty.isactive = true
  JOIN public.wms_role r on r.roleacronym = con.contactroleid
  JOIN public.wms_userrole ur on ur.roleid = r.roleid AND ur.userid = u.userid
  WHERE con.contactroleid in ('PM','PMTL') --du.duid = $1 AND (u.duid = $1 or $1 = any(u.mappedduid))
  ORDER BY du.duname, cu.customername, di.division, sdi.subdivision, cnty.countryname;`;
  return script;
};

export const getCustorgmapId = () => {
  const script = `SELECT DISTINCT org.custorgmapid FROM public.org_mst_customer_orgmap org 
      JOIN public.org_mst_customerorg_du_map duorg ON duorg.duid = $1 AND duorg.custorgmapid = org.custorgmapid
      WHERE org.customerid = $2 AND org.divisionid = $3 AND org.subdivisionid = $4 AND org.countryid = $5
      AND org.isactive = 1`;
  return script;
};

export const getUserDetails = () => {
  const script = `SELECT username, useremail, useraddress, userphone FROM public.wms_user WHERE userid = $1 AND useractive = true;`;
  return script;
};

export const insContactMst = () => {
  const script = `INSERT INTO public.org_mst_customerorg_contact (custorgconmapid, custorgmapid, contactname, contactemail,
      contactaddress, contactphone1, contactphone2, isprimary, contacttype, userid, contactroleid) VALUES
      ((SELECT MAX(custorgconmapid)+1 FROM org_mst_customerorg_contact),$1,$2,$3,$4,$5,$5,$6,$7,$8,
      (SELECT roleacronym FROM public.wms_role WHERE roleid = $9))
      RETURNING custorgconmapid;`;
  return script;
};

export const updateContactMst = () => {
  const script = `UPDATE public.org_mst_customerorg_contact SET contactname = $5, contactemail = $6, contactaddress = $7, 
      contactphone1 = $8, contactphone2 = $8, userid = $9 WHERE custorgmapid = $1 AND contactname = $2 AND 
      userid = $3 AND contactroleid = $4
      RETURNING custorgconmapid;`;
  return script;
};

export const insAuditLog = () => {
  const script = `INSERT INTO salespmo.audit_log (module_id, table_name, field_name, modified_by, modified_on,
      modified_data, original_added_by, original_added_on, original_data, primary_key_value) VALUES
      ($1,$2,$3,$4,CURRENT_TIMESTAMP,$5,$6,$7,$8,$9);`;
  return script;
};
