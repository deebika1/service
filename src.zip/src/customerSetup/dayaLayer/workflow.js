export const insertWorkflow = () => {
  const script = `Insert into public.wms_workflow (wfname,wfname_bpmnid,screenid,isactive,iscamundaflow,customerid)
    values ($1,$1,3,true,false,$2) RETURNING wfid`;
  return script;
};

export const getWorkflow = () => {
  const script = `SELECT w.wfid, w.wfname ,'action' as action
    FROM public.wms_config_customertabinfomapping cust
    LEFT JOIN public.wms_workflow w ON w.wfid = ANY (cust.workflowid)
    WHERE cust.custmapping = $1 and cust.workflowid is not null;`;
  return script;
};

export const addWorkflowid = () => {
  const script = `UPDATE public.wms_config_customertabinfomapping SET workflowid = $2 WHERE custmapping = $1;`;
  return script;
};

export const checkWFDuplicate = () => {
  const script = `SELECT CASE 
    WHEN COUNT(*) > 0 THEN true 
    ELSE false 
    END AS duplicate
    FROM wms_workflow
    WHERE lower(wfname) = lower($1);`;
  return script;
};

export const getCustWorkfolwid = () => {
  const script = `select workflowid,customerid from public.wms_config_customertabinfomapping WHERE custmapping = $1`;
  return script;
};

export const getScreenid = () => {
  const script = ` select screenid from  wms_mst_screens where screenname=$1`;
  return script;
};

export const getAllWorkflow = () => {
  const script = `SELECT wfid AS value,wfname AS label FROM public.wms_workflow WHERE isactive = true AND
  wfid NOT IN (SELECT UNNEST(workflowid) FROM public.wms_config_customertabinfomapping 
  WHERE custmapping = $1 AND workflowid IS NOT NULL)
  ORDER BY label;`;
  return script;
};
