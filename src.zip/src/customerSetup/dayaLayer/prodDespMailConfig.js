export const getMailListScript = () => {
  const script = `SELECT info.custmapping, info.duid, du.duname, info.customerid, cu.customername, info.divisionid,
    string_agg(DISTINCT di.division, ', ') AS division, info.verticalid, sdi.subdivision, info.countryid, 
     string_agg(DISTINCT cnty.countryname, ',') AS countryname, info.email, 'action' AS action
    FROM public.wms_config_customertabinfomapping info
    -- JOIN public.org_mst_customer_orgmap co on co.custorgmapid = info.custmapping AND co.isactive = 1
    -- JOIN public.org_mst_customerorg_du_map duo on duo.custorgmapid = co.custorgmapid
    JOIN public.org_mst_deliveryunit du on du.duid = info.duid AND du.isactive = true
    JOIN public.org_mst_customer cu on cu.customerid = info.customerid
    JOIN public.org_mst_division di on di.divisionid = ANY(info.divisionid) AND di.isactive = true
    JOIN public.org_mst_subdivision sdi on sdi.subdivisionid = info.verticalid AND sdi.isactive = true
    JOIN public.geo_mst_country cnty on cnty.countryid = ANY(info.countryid) AND cnty.isactive = true
    WHERE info.isactive = true AND (du.duname ILIKE '%' || $1 || '%' OR cu.customername ILIKE '%' || $1 || '%')
    GROUP BY info.custmapping, info.duid, du.duname, info.customerid, cu.customername, info.divisionid,
      	info.verticalid, sdi.subdivision, info.countryid
	ORDER BY info.custmapping DESC;`;
  return script;
};

export const getMailForCC = () => {
  // const script = `SELECT userid, useremail FROM public.wms_user WHERE (duid = $1 OR $1 = ANY(mappedduid)) AND useractive = true;`;
  const script = `SELECT username || ' (' || userid || ') - ' || useremail AS label, useremail AS value 
      FROM public.wms_user WHERE (duid = $1 OR $1 = ANY(mappedduid)) AND useractive = true
      ORDER BY username;`;
  return script;
};

export const updEmailtoCusMap = () => {
  const script = `UPDATE public.wms_config_customertabinfomapping SET email = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP
    WHERE custmapping = $1 AND isactive = true;`;
  return script;
};
