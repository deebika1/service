import express from 'express';
import {
  getActiveSectionTabsController,
  getActiveInfoController,
  checkIsCombinationExistController,
  InsertCustomerSetupController,
  UpdateWOConfigController,
  getActiveFieldsController,
  InsertFieldsforTabandInfoController,
  getActiveCustomerSetupController,
  deleteCustomerSetupController,
  getFlowTypeDUController,
  createWorkflowController,
  getWorkflowController,
  getScreenIdController,
  getAllWorkflowController,
  getWOUserListController,
  insContactMstController,
  updateContactMstController,
  getMailListScriptController,
  getMailforCCController,
  updEmailtoCusMapController,
} from '../controller/index.js';

const CustSetupRouter = express.Router();

const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

// Customer Setup start
CustSetupRouter.post(
  '/getactivesections',
  handler(getActiveSectionTabsController),
);
CustSetupRouter.post(
  '/checkisexist',
  handler(checkIsCombinationExistController),
);
CustSetupRouter.post(
  '/insertcustmapping',
  handler(InsertCustomerSetupController),
);
CustSetupRouter.get(
  '/getactiveinfos/:custMapId',
  handler(getActiveInfoController),
);
CustSetupRouter.post('/updatewoconfig', handler(UpdateWOConfigController));
CustSetupRouter.post('/getactivefields', handler(getActiveFieldsController));
CustSetupRouter.post(
  '/insertfields',
  handler(InsertFieldsforTabandInfoController),
);
CustSetupRouter.post(
  '/getactivecustomersetup',
  handler(getActiveCustomerSetupController),
);
CustSetupRouter.post(
  '/deletecustomersetup',
  handler(deleteCustomerSetupController),
);
CustSetupRouter.get(
  '/getduflowtype/:duId/:customerId',
  handler(getFlowTypeDUController),
);

CustSetupRouter.post('/createworkflow', handler(createWorkflowController));

CustSetupRouter.get('/getworkflow/:custmapId', handler(getWorkflowController));

CustSetupRouter.get('/getscreenid/:path', handler(getScreenIdController));

CustSetupRouter.get(
  '/getallworkflow/:custmapId',
  handler(getAllWorkflowController),
);

// Workorder User Setup
CustSetupRouter.get('/getwouserlist', handler(getWOUserListController));
CustSetupRouter.post('/inswouser', handler(insContactMstController));
CustSetupRouter.post('/updwouser', handler(updateContactMstController));

// Production Despatch Mail Setup
CustSetupRouter.post('/getmaillist', handler(getMailListScriptController));
CustSetupRouter.get('/getccmail/:duId', handler(getMailforCCController));
CustSetupRouter.post('/insccmail', handler(updEmailtoCusMapController));

export default CustSetupRouter;
