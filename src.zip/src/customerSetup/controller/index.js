import {
  getActiveSectionTabsService,
  checkIsCombinationExistService,
  InsertCustomerSetupService,
  getActiveInfoService,
  UpdateWOConfigService,
  getActiveMstFieldsService,
  getActiveInfoFieldsService,
  InsertFieldsforTabandInfoService,
  getActiveCustomerSetupService,
  deleteCustomerSetupService,
  getFlowTypeDUService,
  addWorkflowService,
  geWorkflowService,
  geScreenIdService,
  getAllWorkflowService,
  getWOUserListService,
  insContactMstService,
  updateContactMstService,
  getMailListScriptService,
  getMailforCCService,
  updEmailtoCusMapService,
} from '../service/index.js';

export const getActiveSectionTabsController = async (req, res) => {
  try {
    const result = await getActiveSectionTabsService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const checkIsCombinationExistController = async (req, res) => {
  try {
    const result = await checkIsCombinationExistService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const InsertCustomerSetupController = async (req, res) => {
  try {
    const result = await InsertCustomerSetupService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getActiveInfoController = async (req, res) => {
  try {
    const { custMapId } = req.params;
    const result = await getActiveInfoService(custMapId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const UpdateWOConfigController = async (req, res) => {
  try {
    const result = await UpdateWOConfigService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getActiveFieldsController = async (req, res) => {
  try {
    const MstFieList = await getActiveMstFieldsService(req.body);
    const InfoFieList = await getActiveInfoFieldsService(req.body);
    res.status(200).send({ MstList: MstFieList, InfoFieldList: InfoFieList });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const InsertFieldsforTabandInfoController = async (req, res) => {
  try {
    const result = await InsertFieldsforTabandInfoService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getActiveCustomerSetupController = async (req, res) => {
  try {
    const result = await getActiveCustomerSetupService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteCustomerSetupController = async (req, res) => {
  try {
    const result = await deleteCustomerSetupService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFlowTypeDUController = async (req, res) => {
  try {
    const { duId, customerId } = req.params;
    const result = await getFlowTypeDUService(duId, customerId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createWorkflowController = async (req, res) => {
  try {
    const result = await addWorkflowService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getWorkflowController = async (req, res) => {
  try {
    const { custmapId } = req.params;
    const result = await geWorkflowService(custmapId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getScreenIdController = async (req, res) => {
  try {
    const { path } = req.params;
    const result = await geScreenIdService(path);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getAllWorkflowController = async (req, res) => {
  try {
    const { custmapId } = req.params;
    const result = await getAllWorkflowService(custmapId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Workorder User Setup
export const getWOUserListController = async (req, res) => {
  try {
    const result = await getWOUserListService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insContactMstController = async (req, res) => {
  try {
    const result = await insContactMstService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateContactMstController = async (req, res) => {
  try {
    const result = await updateContactMstService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Production Despatch Mail Setup
export const getMailListScriptController = async (req, res) => {
  try {
    const result = await getMailListScriptService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getMailforCCController = async (req, res) => {
  try {
    const { duId } = req.params;
    const result = await getMailforCCService(duId);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updEmailtoCusMapController = async (req, res) => {
  try {
    const result = await updEmailtoCusMapService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
