export const tools = {
  eProofStopSignal: {
    id: 550,
  },
  introMail: {
    id: 553,
  },
};

export const stage = {
  incomingInspection: {
    id: 22,
  },
  preEditing: {
    id: 23,
  },
  copyEditing: {
    id: 24,
  },
  onshoreCE: {
    id: 41,
  },
  xmlConversion: {
    id: 27,
  },
  firstProof: {
    id: 1,
  },
  collation: {
    id: 21,
  },
  revises: {
    id: 2,
  },
  firstView: {
    id: 12,
  },
  revisedFirstView: {
    id: 32,
  },
};
