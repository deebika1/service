export function get_dropdown_norms(type) {
  let query = '';

  switch (type) {
    case 'stage':
      query = `select distinct s.stageid as column_id,s.stagename as column_name from  public.wms_workflowdefinition wdef
                  join wms_mst_stage s on s.stageid = wdef.stageid
                  where wfid=$1 and wdef.itracksconfig->>'isNewiTrackTrigger' = 'true';`;
      break;
    case 'activity':
      query = `select distinct a.activityid as column_id,a.activityname as column_name from  public.wms_workflowdefinition wdef
                  join wms_mst_activity a on a.activityid = wdef.activityid
                  where wfid=$1 and stageid = $2 and wdef.itracksconfig->>'isNewiTrackTrigger' = 'true';`;
      break;
    case 'complexity':
      query = `select Distinct com.complexityid as column_id,com.complexity as column_name from iproductivity.mst_cust_info c
            LEFT JOIN iproductivity.mst_norms_config mnc ON mnc.custinfoid = c.custinfoid
            left join public.wms_mst_complexity com ON com.complexityid = mnc.complexityid
            where c.duid = $1 and c.customerid=$2 and c.wfid = $3 and c.stageid = $4 and mnc.activityid = $5 and 
            c.isactive = true and mnc.isactive = true`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
}

export function InsertJobNorms() {
  const sql = `Insert into iproductivity.job_norms_map_details (workorderid,customerid,duid,stageid,activityid,softwareid,complexityid,created_by,updated_by,isactive)
Values ($1,$2,$3,$4,$5,$6,$7,$8,$8,true) returning id`;
  return sql;
}

export function getjobnorms() {
  const sql = `select c.customername,d.duname,s.stagename,a.activityname,com.complexity,sw.softwarename
,jnm.customerid,jnm.duid,jnm.stageid,jnm.activityid,jnm.complexityid,jnm.softwareid,jnm.id
, COALESCE(TO_CHAR(jnm.updated_at + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS updatedon
,u.username as updatedby, 'action' as action
from iproductivity.job_norms_map_details jnm
left join org_mst_customer c on c.customerid = jnm.customerid
left join org_mst_deliveryunit d on d.duid = jnm.duid
left join wms_mst_stage s on s.stageid = jnm.stageid
left join wms_mst_activity a on a.activityid = jnm.activityid
left join wms_mst_complexity com on com.complexityid = jnm.complexityid
left join  public.pp_mst_composingsoftware sw on sw.softwareid = jnm.softwareid
left join public.wms_user u on u.userid = jnm.updated_by
where jnm.workorderid = $1 and jnm.isactive=true order by jnm.updated_at desc`;
  return sql;
}

export function updatejobnorms() {
  const sql = `Update iproductivity.job_norms_map_details set complexityid = $2 , stageid = $3, activityid = $4, isactive = $5 , updated_by = $6 , updated_at = CURRENT_TIMESTAMP
where id = $1`;
  return sql;
}

export function getWorkorderDetailsnorms() {
  const sql = `
    select ws.wfid,wo.customerid,ws.baseduid,wo.composingsoftwareid from public.wms_workorder wo
left join public.wms_workorder_service ws on ws.workorderid = wo.workorderid
where wo.workorderid = $1 limit 1
    `;
  return sql;
}

export function jobNormsValidation(type) {
  let query = ``;
  switch (type) {
    case 'add':
      query = `  SELECT COUNT(*) > 0 AS exists
FROM iproductivity.job_norms_map_details
WHERE workorderid = $1
  AND customerid = $2
  AND duid = $3
  AND stageid = $4
  AND activityid = $5
  AND isactive = true;`;
      break;
    case 'update':
      query = `SELECT COUNT(*) > 0 AS exists
FROM iproductivity.job_norms_map_details
WHERE workorderid = $1
  AND customerid = $2
  AND duid = $3
  AND stageid = $4
  AND activityid = $5
  AND complexityid = $6
  AND isactive = true;`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
}
