// export const copyActivityNorms = (
//   query,
//   p_custinfoid,
//   p_fromactivityid,
//   p_fromskilllevelid,
//   p_toactivityid,
//   p_toskilllevelid,
//   p_copydata,
//   p_created_by,
// ) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       for (const vCopyElement of p_copydata) {
//         const existsQuery = `
//           SELECT *
//           FROM iproductivity.mst_norms_config n
//           WHERE n.custinfoid = $1
//           AND n.activityid = $2
//           AND n.skilllevelid = $3
//           AND n.normsid = $4
//         `;
//         const existsValues = [
//           p_custinfoid,
//           p_fromactivityid,
//           p_fromskilllevelid,
//           vCopyElement.tonormsid,
//         ];

//         const existsResult = await query(existsQuery, existsValues);

//         if (existsResult && existsResult?.length > 0) {
//           const Query = `
//             SELECT *
//             FROM iproductivity.mst_norms_config n
//             WHERE n.custinfoid = $1
//             AND n.activityid = $2
//             AND n.skilllevelid = $3
//           `;
//           const Values = [p_custinfoid, p_toactivityid, p_toskilllevelid];

//           const Result = await query(Query, Values);

//           if (Result && Result?.length > 0) {
//             // Exit the for loop and resolve immediately
//             return resolve({ issuccess: false, message: `Norms Already Mapped` });
//           }

//           const insertQuery = `
//             INSERT INTO iproductivity.mst_norms_config (
//               custinfoid,
//               complexityid,
//               activityid,
//               noofiteration,
//               skilllevelid,
//               uomid,
//               targetsla,
//               version,
//               created_by,
//               efffrom,
//               appid
//             ) SELECT
//               $1,
//               n.complexityid,
//               $2,
//               n.noofiteration,
//               $3,
//               n.uomid,
//               $4,
//               0,
//               $5,
//               CURRENT_DATE,
//               n.appid
//             FROM iproductivity.mst_norms_config n
//             WHERE n.custinfoid = $6
//             AND n.activityid = $7
//             AND n.skilllevelid = $8
//             AND n.normsid = $9
//           `;

//           const insertValue = [
//             p_custinfoid,
//             p_toactivityid,
//             p_toskilllevelid,
//             vCopyElement.totargetsla,
//             p_created_by,
//             p_custinfoid,
//             p_fromactivityid,
//             p_fromskilllevelid,
//             vCopyElement.tonormsid,
//           ];

//           await query(insertQuery, insertValue);
//         }
//       }

//       resolve({ issuccess: true, message: 'Successfully mapped the norms' });

//     } catch (error) {
//       console.error('Error:', error);
//       reject(error);
//     }
//   });
// };

export const copyActivityNorms = (
  query,
  p_custinfoid,
  p_fromactivityid,
  p_fromskilllevelid,
  p_toactivityid,
  p_toskilllevelid,
  p_copydata,
  p_created_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (const vCopyElement of p_copydata) {
        const existsQuery = `
      SELECT *
      FROM iproductivity.mst_norms_config n
      WHERE n.custinfoid = $1
      AND n.activityid = $2
      AND n.skilllevelid = $3
      AND n.normsid = $4
    `;

        const existsValues = [
          p_custinfoid,
          p_fromactivityid,
          p_fromskilllevelid,
          vCopyElement.tonormsid,
        ];

        const existsResult = await query(existsQuery, existsValues);

        if (existsResult && existsResult?.length > 0) {
          const Query = `
            SELECT *
            FROM iproductivity.mst_norms_config n
            WHERE n.custinfoid = $1
            AND n.activityid = $2
            AND n.skilllevelid = $3
            AND n.complexityid = $4
            AND n.noofiteration = $5
            AND n.uomid = $6
            AND n.version = $7
            AND n.appid = $8
          `;
          const Values = [
            p_custinfoid,
            p_toactivityid,
            p_toskilllevelid,
            existsResult[0]?.complexityid,
            existsResult[0]?.noofiteration,
            existsResult[0]?.uomid,
            existsResult[0]?.version,
            existsResult[0]?.appid,
          ];

          const Result = await query(Query, Values);

          if (Result && Result?.length > 0) {
            // Exit the for loop and resolve immediately
            resolve({
              issuccess: false,
              message: `Norms are already mapped for the selected row(s)`,
            });
            return;
          }
        } else {
          resolve({
            issuccess: false,
            message: `No previous data found to copy`,
          });
          return;
        }
      }

      for (const vCopyElement of p_copydata) {
        const insertQuery = `
            INSERT INTO iproductivity.mst_norms_config (
              custinfoid,
              complexityid,
              activityid,
              noofiteration,
              skilllevelid,
              uomid,
              targetsla,
              version,
              created_by,
              efffrom,
              appid
            ) SELECT
              $1,
              n.complexityid,
              $2,
              n.noofiteration,
              $3,
              n.uomid,
              $4,
              0,
              $5,
              CURRENT_DATE,
              n.appid
            FROM iproductivity.mst_norms_config n
            WHERE n.custinfoid = $6
            AND n.activityid = $7
            AND n.skilllevelid = $8
            AND n.normsid = $9
          `;

        const insertValue = [
          p_custinfoid,
          p_toactivityid,
          p_toskilllevelid,
          vCopyElement.totargetsla,
          p_created_by,
          p_custinfoid,
          p_fromactivityid,
          p_fromskilllevelid,
          vCopyElement.tonormsid,
        ];

        await query(insertQuery, insertValue);
      }

      resolve({ issuccess: true, message: 'Successfully mapped the norms' });
    } catch (error) {
      console.error('Error:', error);
      reject(error);
    }
  });
};
