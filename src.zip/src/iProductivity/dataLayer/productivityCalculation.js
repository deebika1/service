import { query } from '../../database/postgres.js';

export const calculateProductivity = async (
  duid,
  p_customerid,
  p_divisionid,
  p_verticalid,
  p_serviceid,
  p_stageid,
  p_activityid,
  p_complexityid,
  p_noofiteration,
  p_skilllevelid,
  p_uomid,
  p_appid,
  p_isqueryraised,
  p_actualsla,
  p_starttime,
  p_endtime,
  p_empid,
  p_bookCode,
  p_subjob,
  p_createdDate,
  p_wfid,
) => {
  let v_targetsla;
  let v_version;
  let v_custinfoid;
  let v_timetaken = 0;
  let v_productivity = 0;
  let v_iteration_targetsla;
  let v_pretimetaken;
  const v_defaulttime = 0.25;
  const v_totaltime = 450;
  const getItracksDuId = await query(
    'SELECT itrackduid FROM public.org_mst_deliveryunit WHERE duid = $1',
    [duid],
  );
  const p_duid = getItracksDuId[0]?.itrackduid;
  // const p_duid = duid;
  // Database query to get v_targetsla, v_version, v_custinfoid
  const queryResult = await query(
    `
    SELECT COALESCE(mnc.targetsla, 0)::int, mnc.version, c.custinfoid
    FROM iproductivity.mst_cust_info c
    LEFT JOIN iproductivity.mst_norms_config mnc ON mnc.custinfoid = c.custinfoid
    WHERE c.duid = $1
      AND c.customerid = $2
      AND c.divisionid = $3
      AND c.verticalid = $4
      AND c.stageid = $5
      AND mnc.activityid = $6
      AND mnc.complexityid = $7
      AND mnc.noofiteration = $8
      AND mnc.skilllevelid = $9
      AND mnc.uomid = $10
      AND mnc.appid = $11
      AND (mnc.effto - CURRENT_DATE >= 1 OR mnc.effto IS NULL OR mnc.effto = CURRENT_DATE)
      AND mnc.efffrom <= CURRENT_DATE
      AND mnc.isactive = true
      AND c.isactive = true
      AND c.wfid = $12;
    `,
    [
      p_duid,
      p_customerid,
      p_divisionid,
      p_verticalid,
      p_stageid,
      p_activityid,
      p_complexityid,
      p_noofiteration,
      p_skilllevelid,
      p_uomid,
      p_appid,
      p_wfid,
    ],
  );

  const queryResultiteration = await query(
    `
    SELECT COALESCE(mnc.targetsla, 0)::int, mnc.version, c.custinfoid
    FROM iproductivity.mst_cust_info c
    LEFT JOIN iproductivity.mst_norms_config mnc ON mnc.custinfoid = c.custinfoid
    WHERE c.duid = $1
      AND c.customerid = $2
      AND c.divisionid = $3
      AND c.verticalid = $4
      AND c.stageid = $5
      AND mnc.activityid = $6
      AND mnc.complexityid = $7
      AND mnc.noofiteration >= 2
      AND mnc.skilllevelid = $8
      AND mnc.uomid = $9
      AND mnc.appid = $10
      AND (mnc.effto - CURRENT_DATE >= 1 OR mnc.effto IS NULL OR mnc.effto = CURRENT_DATE)
      AND mnc.efffrom <= CURRENT_DATE
      AND mnc.isactive = true
      AND mnc.targetsla = 0
      AND c.isactive = true
      AND c.wfid = $11
      order by  mnc.noofiteration desc limit 1;
    `,
    [
      p_duid,
      p_customerid,
      p_divisionid,
      p_verticalid,
      p_stageid,
      p_activityid,
      p_complexityid,
      p_skilllevelid,
      p_uomid,
      p_appid,
      p_wfid,
    ],
  );

  if (queryResult.length > 0) {
    v_targetsla = queryResult[0].coalesce; // Use "COALESCE" instead of "coalesce"
    v_version = queryResult[0].version;
    v_custinfoid = queryResult[0].custinfoid;
  } else if (queryResultiteration.length > 0) {
    v_targetsla = queryResultiteration[0].coalesce;
    v_version = queryResultiteration[0].version;
    v_custinfoid = queryResultiteration[0].custinfoid;
  } else {
    throw new Error('Error: Target SLA Not Found');
  }

  if (v_targetsla === null) {
    throw new Error('Error: Target SLA Not Found');
  }

  if (!v_targetsla) {
    v_targetsla = 0;
  }

  if (p_actualsla > 0) {
    v_timetaken = p_actualsla * (v_targetsla / v_totaltime);
    // previours value p_noofiteration === 0
    if (p_noofiteration === 1) {
      v_productivity = (p_actualsla / v_targetsla) * 100;
      // v_timetaken = 0;
    } else if (v_targetsla === 0) {
      const script = `
        SELECT Timetaken::int ,targetsla
        FROM iproductivity.Productivity_Trans
        WHERE duid = $1
          AND customerid = $2
          AND divisionid = $3
          AND verticalid = $4
          AND serviceid = $5
          AND stageid = $6
          AND activityid = $7
          AND skilllevelid = $8
          AND complexityid = $9
          AND noofiteration = $10
          AND appid = $11
          AND uomid = $12
          AND wfid = $13;
      `;

      const prevTimeResult = await query(script, [
        p_duid,
        p_customerid,
        p_divisionid,
        p_verticalid,
        p_serviceid,
        p_stageid,
        p_activityid,
        p_skilllevelid,
        p_complexityid,
        p_noofiteration - 1,
        p_appid,
        p_uomid,
        p_wfid,
      ]);

      if (prevTimeResult.length > 0) {
        if (prevTimeResult[0].timetaken > 0) {
          v_pretimetaken = prevTimeResult[0].timetaken;
        } else {
          v_pretimetaken =
            (prevTimeResult[0].targetsla / v_totaltime) * p_actualsla;
        }
      }

      v_timetaken =
        v_pretimetaken === 0 ? v_defaulttime : v_defaulttime * v_pretimetaken;
      v_iteration_targetsla = (p_actualsla / v_timetaken) * v_totaltime;
      v_productivity = (p_actualsla / v_iteration_targetsla) * 100;
    } else {
      // v_timetaken *= v_defaulttime;
      v_productivity = (p_actualsla / v_targetsla) * 100;
    }
  }
  // previous value p_noofiteration > 0
  if (p_noofiteration > 1) {
    // v_timetaken *= v_defaulttime;
    // Insert previous iteration record - debit trans
    await query(
      `
        INSERT INTO iproductivity.Productivity_Trans (
          custinfoid,
          empid,
          duid,
          customerid,
          bookCode,
          subjob,
          divisionid,
          verticalid,
          serviceid,
          stageid,
          activityid,
          skilllevelid,
          complexityid,
          noofiteration,
          appid,
          version,
          starttime,
          endtime,
          isqueryraised,
          uomid,
          targetsla,
          actualsla,
          sec_correction,
          totaltime,
          timetaken,
          productivity,
          Creditdebit_from,
          transtype,
          Score,
          created_date,
          wfid
        )
        SELECT
          custinfoid,
          empid,
          duid,
          customerid,
          bookCode,
          subjob,
          divisionid,
          verticalid,
          serviceid,
          stageid,
          activityid,
          skilllevelid,
          complexityid,
          noofiteration,
          appid,
          version,
          starttime,
          endtime,
          isqueryraised,
          uomid,
          targetsla,
          actualsla,
          sec_correction,
          totaltime,
          timetaken,
          productivity,
          $1,
          'debit',
          ($2/ targetsla) *(-25),
          $17,
          wfid
        FROM iproductivity.Productivity_Trans
        WHERE duid = $3
          AND customerid = $4
          AND divisionid = $5
          AND verticalid = $6
          AND serviceid = $7
          AND stageid = $8
          AND activityid = $9
          AND skilllevelid = $10
          AND complexityid = $11
          AND bookCode = $12
          AND subjob = $13
          AND noofiteration = $14
          AND appid = $15
          AND uomid = $16
          AND wfid = $18
      `,
      [
        p_empid,
        Number(p_actualsla),
        p_duid,
        p_customerid,
        p_divisionid,
        p_verticalid,
        p_serviceid,
        p_stageid,
        p_activityid,
        p_skilllevelid,
        p_complexityid,
        p_bookCode,
        p_subjob,
        p_noofiteration - 1,
        p_appid,
        p_uomid,
        p_createdDate,
        p_wfid,
      ],
    );
  }

  // insert into Productivity_Trans table - credit trans
  await query(
    `
    INSERT INTO iproductivity.Productivity_Trans (
      custinfoid,
      empid,
      duid,
      customerid,
      bookCode,
      subjob,
      divisionid,
      verticalid,
      serviceid,
      stageid,
      activityid,
      skilllevelid,
      complexityid,
      noofiteration,
      appid,
      version,
      starttime,
      endtime,
      isqueryraised,
      uomid,
      targetsla,
      actualsla,
      sec_correction,
      totaltime,
      timetaken,
      productivity,
      Creditdebit_from,
      transtype,
      Score,
      created_date,
      wfid
    ) VALUES (
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, CURRENT_TIMESTAMP, $18, $19, $20,$21, $22, $23, $24, $25, $26, $27, $28, $29,$30
    );
  `,
    [
      v_custinfoid,
      p_empid,
      p_duid,
      p_customerid,
      p_bookCode,
      p_subjob,
      p_divisionid,
      p_verticalid,
      p_serviceid,
      p_stageid,
      p_activityid,
      p_skilllevelid,
      p_complexityid,
      p_noofiteration,
      p_appid,
      v_version,
      p_starttime,
      // p_endtime,
      p_isqueryraised,
      p_uomid,
      v_iteration_targetsla > 0
        ? Math.round(v_iteration_targetsla)
        : v_targetsla,
      Number(p_actualsla),
      0 /* p_seccorrection */,
      v_totaltime,
      v_timetaken.toFixed(2),
      v_productivity,
      p_empid,
      'credit',
      v_productivity,
      p_createdDate,
      p_wfid,
    ],
  );
  // update the daywise productivity
  await daywiseProductivity(p_empid, p_createdDate);
  return { status: true };
};

const daywiseProductivity = async (userid, pDate) => {
  try {
    // Fetch daily productivity score from the source table
    // total hours and minutes eg: 02:09
    let script = `
    SELECT
    empid,
    CONCAT(
        FLOOR(SUM(EXTRACT(EPOCH FROM ((endtime + INTERVAL '330 minutes') - (starttime + INTERVAL '330 minutes')))) / 3600), ':',
        LPAD(FLOOR((SUM(EXTRACT(EPOCH FROM ((endtime + INTERVAL '330 minutes') - (starttime + INTERVAL '330 minutes')))) % 3600) / 60)::TEXT, 2, '0')
    ) AS total_time_hours_minutes,
    SUM(score) AS dailyscore
    FROM
        iproductivity.Productivity_Trans
    WHERE empid = $1 AND created_date = $2
    GROUP BY
    empid;
    `;
    const scoreResult = await query(script, [userid, pDate]);

    const dailyScore = scoreResult.length ? scoreResult[0]?.dailyscore : null;
    const totalHours = scoreResult.length
      ? scoreResult[0]?.total_time_hours_minutes
      : null;

    if (dailyScore !== null) {
      // Upsert into the daywise productivity table
      script = `select score from public.trn_daywise_productivity where userid=$1 and productivitydate = $2`;
      const data = await query(script, [userid, pDate]);
      if (data.length && data[0]?.score != null) {
        script = `update public.trn_daywise_productivity set score = $3,updated_by = $1,updated_time = CURRENT_TIMESTAMP,total_hours=$4
        where userid=$1 and productivitydate = $2 returning dpid`;
        await query(script, [userid, pDate, Number(dailyScore), totalHours]);
      } else {
        script = `insert into public.trn_daywise_productivity (userid,productivitydate,score,isactive, created_by,total_hours)
        values ($1,$2,$3,true,$1,$4)`;
        await query(script, [userid, pDate, Number(dailyScore), totalHours]);
      }
      return true;
    }

    return false;
  } catch (error) {
    console.error('Error in daywiseProductivity:', error);
    return false;
  }
};

export const getWoByCustIdDuIdScript = () => {
  // lockjob
  return `select wo.itemcode as column_id, wo.itemcode as column_name \
  from public.wms_workorder wo 
  left join public.org_mst_customer_orgmap co on co.customerid = wo.customerid and co.divisionid = wo.divisionid and co.subdivisionid = wo.subdivisionid and co.countryid = wo.countryid 
  left join public.org_mst_customerorg_du_map oc on oc.custorgmapid = co.custorgmapid 
  where oc.duid =  $1 and wo.customerid = $2 and  coalesce(wo.islock,false) = false`;
};

export const getSubJobByCustIdDuIdScript = () => {
  // lockjob
  return `select filename as column_id ,filename as column_name 
   from public.wms_workorder wo 
   join public.org_mst_customer_orgmap co on co.customerid = wo.customerid and co.divisionid = wo.divisionid
   and co.subdivisionid = wo.subdivisionid and co.countryid = wo.countryid 
   join public.org_mst_customerorg_du_map oc on oc.custorgmapid = co.custorgmapid 
   join public.wms_workorder_incoming wi on wi.woid = wo.workorderid 
   join public.wms_workorder_incomingfiledetails wid on wid.woincomingid = wi.woincomingid 
   where oc.duid = $1 and wo.customerid = $2
   and coalesce(wo.islock,false) = false`;
};

export const getiTrackProductivityInfo = () => {
  return 'select * from public.wms_itrack_productivity_map where duid = $1';
};
export const productivitySummaryReportScript = (userid, fromDate, toDate) => {
  return `SELECT
    PT.empid,
    wu.username,
    wu.userid,
    PT.duid,
    omdu.duname,
    PT.customerid,
    omc.customername,
    PT.bookcode,
    PT.subjob,
    PT.divisionid,
    omd.division,
    PT.verticalid,
    omv.verticalname,
    PT.serviceid,
    oms.servicename,
    PT.stageid,
    omst.stagename,
    PT.activityid,
    wma.activityname,
    PT.skilllevelid,
    wms.skilllevel,
    PT.complexityid,
    wmc.complexity,
    PT.noofiteration,
    PT.appid,
    sw.softwarename,
    PT.version,
    COALESCE(TO_CHAR(PT.starttime + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS starttime,
    COALESCE(TO_CHAR(PT.endtime + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS endtime,
    PT.isqueryraised,
    PT.uomid,
    wmu.uom,
    PT.targetsla,
    PT.actualsla,
    PT.sec_correction,
    PT.totaltime,
    PT.timetaken,
    PT.productivity,
    PT.total_productivity,
    PT.creditdebit_from,
    PT.transtype,
    PT.score,
    PT.created_date,
    PT.wfid,
    wf.wfname
FROM
    iproductivity.Productivity_Trans PT
LEFT JOIN
    public.wms_user wu ON wu.userid = PT.empid
LEFT JOIN
    public.org_mst_customer omc ON omc.customerid = PT.customerid
LEFT JOIN
    public.org_mst_division omd ON omd.divisionid = PT.divisionid
LEFT JOIN
    public.wms_mst_vertical omv ON omv.verticalid = PT.verticalid
LEFT JOIN
    public.wms_mst_service oms ON oms.serviceid = PT.serviceid
LEFT JOIN
    public.wms_mst_stage omst ON omst.stageid = PT.stageid
LEFT JOIN
    mst_deliveryunit omdu ON omdu.duid = PT.duid
LEFT JOIN
    public.wms_mst_complexity wmc ON wmc.complexityid = PT.complexityid
LEFT JOIN
    public.wms_mst_activity wma ON wma.activityid = PT.activityid
LEFT JOIN
public.pp_mst_composingsoftware sw ON sw.softwareid = PT.appid
LEFT JOIN
    public.wms_mst_skilllevel wms ON wms.skilllevelid = PT.skilllevelid
LEFT JOIN
    public.wms_mst_uom wmu ON wmu.uomid = PT.uomid
LEFT JOIN
    public.wms_workflow wf ON wf.wfid = PT.wfid
    
WHERE
    PT.empid in ('${userid}')
    AND PT.created_date BETWEEN '${fromDate}' AND '${toDate}'`;
};

// export const getWorkFlowIDByCustomerScript = () => {
//   return 'select wfid AS column_id ,wfname AS column_name from public.wms_workflow where customerid = $1 group by wfid, wfname order by wfname';
// };

// export const getStageByWorkFlowIDScript = () => {
//   return 'select d.stageid AS column_id ,s.stagename AS column_name from public.wms_workflowdefinition d left join public.wms_mst_stage s on s.stageid = d.stageid where wfid = $1 group by d.stageid,s.stagename ORDER BY s.stagename';
// };
// export const getActivityByWFIdStageIdScript = () => {
//   return 'select d.activityid AS column_id ,a.activityname AS column_name from public.wms_workflowdefinition d left join public.wms_mst_activity a on a.activityid = d.activityid where wfid = $1 and d.stageid = $2 group by d.activityid,a.activityname ORDER BY a.activityname';
// };

export const userDetails = () => {
  return `SELECT  userid
  FROM wms_user 
  WHERE reportingto = $1 AND pbtype = 'KRA' and useractive = true
  UNION ALL
  SELECT $1
  `;
};

export const userList = () => {
  return `SELECT  userid
  FROM wms_user 
  WHERE reportingto = $1 and useractive = true
  UNION ALL
  SELECT $1
  `;
};

export const getLeaveHoliDays = () => {
  return `WITH date_range AS (
    SELECT generate_series(
        $2::date, 
        $3::date, 
        '1 day'::interval
    )::date AS date
),
sundays AS (
    SELECT date
    FROM date_range
    WHERE EXTRACT(dow FROM date) = 0
)
SELECT u.userid, 
       COALESCE(SUM(ld.noofdays), 0) + 
       COALESCE(COUNT(h.holidaydate), 0) + 
       COALESCE((SELECT COUNT(*) FROM sundays), 0) AS res
FROM public.wms_user u
LEFT JOIN public.trn_leavedetails ld 
  ON ld.userid = u.userid 
  AND (ld.leave_start_date BETWEEN $1 AND $3 
       OR ld.leave_end_date BETWEEN $1 AND $3)
LEFT JOIN public.wms_mst_holidaylist h 
  ON h.unitid = u.unitid 
  AND h.holidaydate BETWEEN $1 AND $3
WHERE u.userid IN ($1)
AND u.useractive = true
GROUP BY u.userid`;
};

export const getproductivityscore = user => {
  return `WITH date_range AS (
    SELECT generate_series(
        $1::date, 
        $2::date, 
        '1 day'::interval
    )::date AS date
  ),
  sundays AS (
    SELECT date
    FROM date_range
    WHERE EXTRACT(dow FROM date) = 0
  ), holiday as(
	  select count(*)  as holidaycount , unitid,holidaylocation from wms_mst_holidaylist where    holidaydate BETWEEN $1 AND $2
	group by unitid,holidaylocation
),
  leave_details AS (
    SELECT 
		u.userid, u.username,
    COALESCE((SELECT COUNT(*) FROM sundays), 0) as sundays,
		COALESCE(SUM(ld.noofdays), 0)  as leave_days ,
    COALESCE(h.holidaycount,0) as holidays,
		COALESCE(SUM(ld.noofdays), 0) + 
		COALESCE(h.holidaycount,0) + 
    COALESCE((SELECT COUNT(*) FROM sundays), 0) AS nonworkingdays
	FROM public.wms_user u
	LEFT JOIN public.trn_leavedetails ld 
	ON ld.userid = u.userid 
	AND (ld.leave_start_date  >= $1::timestamp  and ld.leave_end_date  <=  $2::timestamp)
	LEFT JOIN  holiday h ON	h.holidaylocation = 'pdy'
	WHERE u.userid IN (${user})
	AND u.useractive = true
	GROUP BY u.userid,u.username,h.holidaycount
  ),
  productivity AS (
    SELECT pd.userid, SUM(pd.score) AS total_score,sum(total_hours) as total_hours
    FROM public.trn_daywise_productivity pd
    WHERE pd.userid IN (${user})
      AND pd.productivitydate BETWEEN $1 AND $2
    GROUP BY pd.userid
  ),
  date_diff AS (
    SELECT abs($1::date - $2::date) AS difference
  )
  SELECT ld.userid,
  UPPER(CONCAT(ld.username, ' (', ld.userid, ')')) as username,
  CONCAT($1 ,' to ', $2) as ProductivityDate,
    ld.leave_days,
    ld.holidays,
    ld.sundays,
      ld.nonworkingdays,
      COALESCE(pd.total_score, 0) AS total_score,
      COALESCE(TO_CHAR(pd.total_hours, 'HH24:MI'),'00:00') AS total_hours,
      dd.difference+1 as day_diffrent,
    (dd.difference+1) - ld.nonworkingdays as itracks_workingdays,
  COALESCE((total_score / ((dd.difference+1) - ld.nonworkingdays)),0) as overallproductivity
  FROM leave_details ld
  LEFT JOIN productivity pd
  ON ld.userid = pd.userid
  CROSS JOIN date_diff dd;`;
};

export const daywiseReport = () => {
  return `select dp.userid,to_char(dp.productivitydate,'YYYY-MM-DD') as date,dp.score,
  COALESCE(to_char(dp.total_hours,'HH24:MI'),'00:00') as total_hours,
  UPPER(CONCAT(u.username, ' (', u.userid, ')')) as username
  FROM public.trn_daywise_productivity dp 
  left join public.wms_user u on u.userid = dp.userid
  where 
  dp.userid=$1 AND (dp.productivitydate BETWEEN $2 AND $3)`;
};

export const getDOJ = () => {
  return `select doj from wms_user where userid= $1 and useractive=true`;
};

export const getSubordinatesList = () => {
  const script = `select userid as value, username || ' ' || '(' || userid || ')' as label from public.wms_user 
  where reportingto = $1 and useractive = true
  UNION ALL
  (select userid as value,username || ' ' || '(' || userid || ')' as label from public.wms_user where useractive=true and userid=$1)`;
  return script;
};

export const getProductivitySum = () => {
  return `SELECT SUM(score*targetsla)
  FROM iproductivity.Productivity_Trans 
  WHERE bookcode = $1
  AND stageid = $2
  AND activityid = $3
  AND subjob = $4;`;
};

export const getUOMArticleTitle = () => {
  return `SELECT itracksconfig FROM public.wms_workflowdefinition WHERE wfid = $1 AND stageid = $2 AND activityid = $3`;
};

export const getWorkFlowIDByCustomerScript = () => {
  return `select wfid AS column_id ,wfname AS column_name from public.wms_workflow 
  where customerid = $1
  union 
  SELECT wf.wfid AS column_id, wf.wfname AS column_name
  FROM public.wms_config_customertabinfomapping cmap
  JOIN LATERAL unnest(cmap.workflowid) AS wf_id ON true
  JOIN public.wms_workflow wf ON wf.wfid = wf_id
  WHERE cmap.customerid = $1`;
};

export const getStageByWorkFlowIDScript = () => {
  return 'select d.stageid AS column_id ,s.stagename AS column_name from public.wms_workflowdefinition d left join public.wms_mst_stage s on s.stageid = d.stageid where wfid = $1 group by d.stageid,s.stagename ORDER BY s.stagename';
};
export const getActivityByWFIdStageIdScript = () => {
  return 'select d.activityid AS column_id ,a.activityname AS column_name from public.wms_workflowdefinition d left join public.wms_mst_activity a on a.activityid = d.activityid where wfid = $1 and d.stageid = $2 group by d.activityid,a.activityname ORDER BY a.activityname';
};

// geting the UOM Quanity
export const getProductivityQuantityWMS = () => {
  return `select remaininguomcount,actualuom from public.wms_workflow_eventlog 
where wfeventid = $1`;
};
