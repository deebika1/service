export function get_master_drop_down(p_name) {
  let query = '';

  switch (p_name) {
    case 'IDU':
      query =
        'select duid AS column_id, duname AS column_name FROM public.mst_deliveryunit WHERE isactive = true ORDER BY duname';
      break;
    case 'DU':
      query =
        'SELECT duid AS column_id, duname AS column_name FROM public.mst_deliveryunit WHERE isactive = true ORDER BY duname;';
      break;
    case 'ODU':
      query =
        'SELECT duid AS column_id, duname AS column_name FROM public.org_mst_deliveryunit WHERE isactive = true ORDER BY duname;';
      break;
    case 'CUSTOMER':
      query =
        'SELECT customerid AS column_id, customername AS column_name FROM public.org_mst_customer WHERE isactive = true ORDER BY customername;';
      break;
    case 'SERVICE':
      query =
        'SELECT serviceid AS column_id, servicename AS column_name FROM public.wms_mst_service WHERE isactive = true ORDER BY servicename;';
      break;
    case 'STAGE':
      query =
        'SELECT stageid AS column_id, stagename AS column_name FROM public.wms_mst_stage WHERE isactive = true ORDER BY stagename;';
      break;
    case 'SHIFT':
      query =
        'SELECT shiftid::bigint AS column_id, shifthrs::VARCHAR AS column_name FROM public.wms_mst_shift WHERE isactive = true ORDER BY shifthrs;';
      break;
    case 'ACTIVITY':
      query =
        'SELECT activityid AS column_id, activityname AS column_name FROM public.wms_mst_activity WHERE isactive = true ORDER BY activityname;';
      break;
    case 'SOFTWARE':
      query =
        'SELECT softwarename as column_name, softwareid as column_id FROM public.pp_mst_composingsoftware WHERE isactive=true ORDER BY softwareid ASC';
      break;
    case 'COMPLEXITY':
      query =
        'SELECT complexityid AS column_id, complexity AS column_name FROM public.wms_mst_complexity WHERE isactive = 1 ORDER BY complexity;';
      break;
    case 'SKILLLEVEL':
      query =
        'SELECT skilllevelid AS column_id, skilllevel AS column_name FROM public.wms_mst_skilllevel WHERE skilllevelid NOT IN (3, 4) ORDER BY skilllevel;';
      break;
    case 'MODE':
      query =
        'SELECT modeid::bigint AS column_id, modedesc AS column_name FROM iquality.mst_qualitymode ORDER BY modedesc;';
      break;
    case 'SKILL':
      query =
        'SELECT skillid AS column_id, skillname AS column_name FROM public.wms_mst_skill ORDER BY skillname;';
      break;
    case 'DIVISION':
      query =
        'SELECT divisionid AS column_id, division AS column_name FROM public.org_mst_division WHERE isactive = true ORDER BY division;';
      break;
    case 'SUBDIVISION':
      query =
        'SELECT subdivisionid AS column_id, subdivision AS column_name FROM public.org_mst_subdivision WHERE isactive = true ORDER BY subdivision;';
      break;
    case 'UOM':
      query =
        'SELECT uomid::bigint AS column_id, uom AS column_name FROM public.wms_mst_uom WHERE isactive = 1 ORDER BY uom;';
      break;
    case 'VERTICAL':
      query =
        'SELECT verticalid AS column_id, verticalname AS column_name FROM public.wms_mst_vertical WHERE isactive = true AND verticalid <> 1 ORDER BY verticalname;';
      break;
    case 'NOC':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 1 ORDER BY ErrorDesc;';
      break;
    case 'PROCESS':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 2 ORDER BY ErrorDesc;';
      break;
    case 'BOOKPART':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 3 ORDER BY ErrorDesc;';
      break;
    case 'ELEMENT':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 4 ORDER BY ErrorDesc;';
      break;
    case 'TYPEOFEDITING':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 5 ORDER BY ErrorDesc;';
      break;
    case 'PARAMETERS':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 6 ORDER BY ErrorDesc;';
      break;
    case 'ERRORTYPE':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 7 ORDER BY ErrorDesc;';
      break;
    case 'SEVERITY':
      query =
        'SELECT SeverityId::bigint AS column_id, Severity AS column_name FROM iquality.Mst_Severity WHERE isactive = true ORDER BY Severity;';
      break;
    case 'CURRENCY':
      query =
        'SELECT Currencyid::bigint AS column_id, CurrencyText AS column_name FROM iquality.Mst_CurrencyMst WHERE isactive = true ORDER BY CurrencyText;';
      break;
    case 'APPRAISALCATEGORY':
      query =
        'SELECT categoryid::bigint AS column_id, category AS column_name FROM iaspire.mst_appraisaltype WHERE isactive = true;';
      break;
    case 'DESIGNATION':
      query =
        'SELECT designationid::bigint AS column_id, designationdesc AS column_name FROM public.mst_designation WHERE isactive = true;';
      break;
    case 'BANDLEVEL':
      query =
        'SELECT bandlevelid::bigint AS column_id, bandlevel AS column_name FROM public.mst_bandlevel WHERE isactive = true;';
      break;
    case 'STATUS':
      query =
        'SELECT statusid::bigint AS column_id, status AS column_name FROM iaspire.mst_status WHERE isactive = true ORDER BY status_seq;';
      break;
    case 'GOALSTATUS':
      query = `SELECT statusid::bigint AS column_id, status AS column_name FROM iaspire.mst_status WHERE alias_name ilike '%goal%' AND isactive = true;`;
      break;
    case 'SCORESTATUS':
      query = `SELECT statusid::bigint AS column_id, status AS column_name FROM iaspire.mst_status WHERE isactive = true AND alias_name IN ('GOAL_APPROVED','REVIEW_COMPLETED','REVIEW_PENDING_EMPLOYEE','REVIEW_PENDING_L1','REVIEW_PENDING_L2','REVIEW_REJECTED_L1','REVIEW_REJECTED_L2','REVIEW_EXPIRED');`;
      break;
    case 'UNIT':
      query = `SELECT unitid::bigint AS column_id, unit AS column_name FROM public.mst_unit WHERE isactive = true;`;
      break;
    case 'COUNTRY':
      query = `SELECT countryid::bigint AS column_id, countrycode AS column_name FROM public.geo_mst_country WHERE isactive = true order by countrycode;`;
      break;
    case 'ENTITY':
      query = `SELECT entityid::bigint AS column_id, entityname AS column_name FROM public.mst_entity wme  WHERE isactive = true order by entityname;`;
      break;
    case 'MSTCUSTOMER':
      query =
        'SELECT customerid AS column_id, customername AS column_name FROM public.mst_customer WHERE isactive = true ORDER BY customername;';
      break;
    case 'SEGMENT':
      query =
        'SELECT segment_id AS column_id, segment_name AS column_name FROM salespmo.mst_segment WHERE is_active = true ORDER BY segment_name;';
      break;
    case 'KAM':
      query = `SELECT DISTINCT ON (wu2.username)
               wu2.username || ' (' || wu2.userid || ')' AS column_name,  wu2.userid as column_id
                FROM public.wms_userrole wu
                join public.wms_role wr on wr.roleid =  wu.roleid
                JOIN public.wms_user wu2 ON wu2.userid = wu.userid
                WHERE wr.rolename = 'Key Account Manager' and wu2.useractive = true
                ORDER BY wu2.username;`;
      break;
    case 'CM':
      query = `SELECT DISTINCT ON (wu2.username)
      wu2.username || ' (' || wu2.userid || ')' AS column_name,  wu2.userid as column_id
                FROM public.wms_userrole wu
                join public.wms_role wr on wr.roleid =  wu.roleid
                JOIN public.wms_user wu2 ON wu2.userid = wu.userid
                WHERE wr.rolename = 'PMTL' and wu2.useractive = true
                ORDER BY wu2.username;`;
      break;
    case 'SPMOSTATUS':
      query =
        'select distinct status_alias as column_name ,status_alias as column_id  from salespmo.mst_status ms where isactive = true ORDER BY status_alias';
      break;
    case 'REQTYPE':
      query =
        'select reqcode as column_id, reqname as column_name from salespmo.mst_request_type where isactive = true ORDER BY reqname';
      break;
    case 'SPMOSTATUSDD':
      query = `select status_alias as column_name , statuscode as column_id from salespmo.mst_status where isactive = true and status_alias not in ('ACTIVE') ORDER BY status_alias`;
      break;
    case 'CURRENCYCODE':
      query =
        'SELECT Currencyid::bigint AS column_id, CurrencyCode AS column_name FROM iquality.Mst_CurrencyMst WHERE isactive = true ORDER BY CurrencyCode;';
      break;
    case 'EXCHANGERATE':
      query =
        'select exchangerateid AS column_id, exchangerate AS column_name  from public.currency_exchange_rates where isactive = true order by exchangerateid';
      break;
    case 'KAMEMPCODE':
      query = `SELECT DISTINCT ON (wu2.username)
                CONCAT(wu2.username, ' (', wu2.userid, ')') AS column_name,  wu2.userid as column_id
                FROM public.wms_userrole wu
                join public.wms_role wr on wr.roleid =  wu.roleid
                JOIN public.wms_user wu2 ON wu2.userid = wu.userid
                WHERE wr.rolename = 'Key Account Manager' and wu2.useractive = true
                ORDER BY wu2.username;`;
      break;
    case 'CMEMPCODE':
      query = `SELECT DISTINCT ON (wu2.username)
                CONCAT(wu2.username, ' (', wu2.userid, ')') AS column_name,  wu2.userid as column_id
                FROM public.wms_userrole wu
                join public.wms_role wr on wr.roleid =  wu.roleid
                JOIN public.wms_user wu2 ON wu2.userid = wu.userid
                WHERE wr.rolename = 'Client Manager' and wu2.useractive = true
                ORDER BY wu2.username;`;
      break;
    case 'PBREPORTSTATUS':
      query = `SELECT statusid::bigint AS column_id, status AS column_name FROM iaspire.mst_status WHERE 
              alias_name NOT IN ('APP_YTS','APP_L1','APP_L2','APP_COMPLETED') AND isactive = true
              ORDER BY status_seq;`;
      break;
    case 'COUNTRYNAME':
      query = `SELECT countryid::bigint AS column_id, countryname AS column_name, countrycode FROM public.geo_mst_country
               WHERE isactive = true order by countryname;`;
      break;
    case 'FINANCETYPE':
      query = `select id as column_id,type as column_name from public.wms_mst_financialcalculationtype where isactive=true`;
      break;
    case 'EMPLOYEE':
      query = `SELECT 
      userid AS value,  
      UPPER(CONCAT(username, ' (', userid, ')')) AS label
      FROM 
          wms_user
      WHERE 
      useractive = true 
      AND (reportingto = $1 OR userid = $1)`;
      break;
    default:
      throw new Error('Invalid Param');
  }

  return query;
}
