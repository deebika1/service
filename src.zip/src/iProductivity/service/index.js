import { query } from '../../database/postgres.js';
import { copyActivityNorms } from '../dataLayer/activityCopy.js';
import {
  calculateProductivity,
  getActivityByWFIdStageIdScript,
  getStageByWorkFlowIDScript,
  getSubJobByCustIdDuIdScript,
  getWoByCustIdDuIdScript,
  getWorkFlowIDByCustomerScript,
  productivitySummaryReportScript,
  userList,
  getproductivityscore,
  getSubordinatesList,
  getUOMArticleTitle,
  getProductivitySum,
  daywiseReport,
  getProductivityQuantityWMS,
} from '../dataLayer/productivityCalculation.js';
import { get_master_drop_down } from '../dataLayer/masterDropDown.js';
import {
  get_dropdown_norms,
  InsertJobNorms,
  getjobnorms,
  updatejobnorms,
  getWorkorderDetailsnorms,
  jobNormsValidation,
} from '../dataLayer/jobnormsComplexity.js';

// get all master services
export const getMasterService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      // const values = [param];
      // const script = 'SELECT * FROM iproductivity.get_master_drop_down($1)';
      // const result = await query(script, values);
      const result = await query(get_master_drop_down(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// get iteration count services
export const getIterationService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iproductivity.get_iteration()';
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// dynamic columns
export const getDynamicColumnsService = filterValues => {
  return new Promise(async (resolve, reject) => {
    try {
      const { entityId, roleid, skillid, screenId, userid } = filterValues;
      let entityIdArray = '';
      if (entityId instanceof Array) {
        entityIdArray = entityId;
      } else {
        entityIdArray = [entityId];
      }
      const condition = `entityid = any($1) AND ( userid = $2 OR (roleid = $3 AND (skillid = any($4) OR skillid IS NULL))) AND screenid = $5`;
      const script = `SELECT *,filterValues as defaultFilterValues FROM public.wms_viewconfig_details WHERE ${condition} ORDER BY viewid ASC `;
      const values = [entityIdArray, userid, roleid, skillid, screenId];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSubDivbyDivIdService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM iproductivity.get_subdivwithdiv($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createCustomerMasterService = customerDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerName, customerid, divisionid, duid } = customerDetails;
      const values = [customerName, customerid, divisionid, duid];
      const script =
        'SELECT * FROM iproductivity.insert_org_mst_customer($1, $2, $3, $4)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const editCustomerMasterService = customerDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerName, customerid } = customerDetails;
      const values = [customerName, customerid];
      const validateScript =
        'SELECT 1 FROM public.org_mst_customer WHERE trim(upper(customername)) = trim(upper($1)) ';
      const result = await query(validateScript, [customerName]);
      let out;
      if (result.length == 0) {
        const script =
          'UPDATE org_mst_customer SET customername = $1 WHERE customerid = $2';
        out = await query(script, values);
        resolve(out);
      } else {
        reject('customer Name is already taken.');
      }
    } catch (error) {
      reject(error);
    }
  });
};
export const createStageMasterService = customerDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerName, divisionid, duid } = customerDetails;
      const values = [customerName, divisionid, duid];
      const script =
        'SELECT * FROM iproductivity.insert_org_mst_customer($1, $2, $3)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createActivityMasterService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [payload.activityName];
      const script = 'SELECT * FROM iproductivity.insert_wms_mst_activity($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateCustomerMasterService = customerData => {
  return new Promise(async (resolve, reject) => {
    try {
      // const values = [param];
      // const script = 'SELECT * FROM iproductivity.get_master_drop_down($1)';
      // const customerDataresult = await query(script, values);
      resolve(customerData);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteCustomerMasterService = customerid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [customerid];
      const script = 'SELECT * FROM iproductivity.delete_org_mst_customer($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getCustomerInfoService = duid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [duid];
      const script = 'SELECT * FROM iproductivity.GET_CUSTINFO($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getiTrackProductivityInfo = duid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [duid];
      const script =
        'select * from public.wms_itrack_productivity_map where duid = $1';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getCustomerDetailsService = (duid, customerID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [customerID, duid];
      const script = 'SELECT * FROM iproductivity.get_cust_info_details($1,$2)';
      const result = await query(script, values);
      // const result = await getSimpleTableDataWithPagination(
      //   query,
      //   script,
      //   values,
      //   searchInfo,
      // );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script =
        'SELECT * FROM iproductivity.get_service_with_customer($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getWorkflowService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script =
        'SELECT * FROM iproductivity.get_workflow_with_customer($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getStageService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM iproductivity.get_stage_with_wfid($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createCustomerInfoService = customerInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        custinfoid,
        customerid,
        divisionid,
        verticalid,
        serviceid,
        stageid,
        noofiteration,
        duid,
        created_by,
      } = customerInfo;
      const script =
        'SELECT * FROM iproductivity.insert_cust_info($1,$2,$3,$4,$5,$6,$7,$8,$9);';
      const result = await query(script, [
        custinfoid,
        customerid,
        divisionid,
        verticalid,
        serviceid,
        stageid,
        noofiteration,
        duid,
        created_by,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteCustomerInfoService = (custinfoid, updatedby) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iproductivity.delete_cust_info($1, $2)';
      const values = [custinfoid, updatedby];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getCustActivityService = custinfoid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iproductivity.get_activityinfo_bycust($1)';
      const values = [custinfoid];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getNormActidSkidService = normsDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { custinfoid, activityid, skilllevelid } = normsDetail;
      const script =
        'SELECT * FROM iproductivity.get_norms_config_details($1,$2,$3)';
      const values = [custinfoid, activityid, skilllevelid];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const copyNormsToCustService = normsDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { fromcustid, fromduid, toduid, tocustid, createdby } = normsDetail;
      const script = 'SELECT * FROM iproductivity.copy_norms($1,$2,$3,$4,$5)';
      const values = [fromcustid, fromduid, tocustid, toduid, createdby];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const copyActivityService = activityDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        custinfoid,
        fromactivityid,
        fromSkilllevelid,
        toactivityid,
        toskilllevelid,
        createdby,
        selectedItems,
      } = activityDetails;
      const result = await copyActivityNorms(
        query,
        custinfoid,
        fromactivityid,
        fromSkilllevelid,
        toactivityid,
        toskilllevelid,
        selectedItems,
        createdby,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getNormsService = custinfoid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [custinfoid];
      const script =
        'SELECT * FROM  iproductivity.get_norms_config_details($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createNormsService = normsinfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        normsid,
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
        targetsla,
        efffrom,
        createdby,
        versionid,
        remarks,
      } = normsinfo;
      const script =
        'select * from iproductivity.insert_norms_config($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)';
      const result = await query(script, [
        normsid,
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
        targetsla,
        efffrom,
        createdby,
        versionid,
        remarks,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getNormVersionHistoryService = normsinfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
      } = normsinfo;
      const script =
        'select * from iproductivity.get_norms_version_history($1,$2,$3,$4,$5,$6,$7)';
      const result = await query(script, [
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteNormsService = deleteDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { normsid, updatedby } = deleteDetails;
      const values = [normsid, updatedby];
      const script = `SELECT * FROM iproductivity.delete_norms_config($1, $2)`;
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createManualLogisticService = manualLogistics => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        duid,
        customerid,
        divisionid,
        verticalid,
        serviceid,
        stageid,
        activityid,
        complexityid,
        iteration,
        skilllevelid,
        uomid,
        appid,
        queryraised,
        actual,
        starttime,
        endtime,
        empcode,
        bookcode,
        subjob,
        createddate,
        wfid,
      } = manualLogistics;
      // const iTrackProductity = await getiTrackProductivityInfo(duid)
      const result = await calculateProductivity(
        duid /* p_duid */,
        customerid /* p_customerid */,
        divisionid /* p_divisionid */,
        verticalid /* p_verticalid */,
        serviceid /* p_serviceid */,
        stageid /* p_stageid */,
        activityid /* p_activityid */,
        complexityid /* p_complexityid */,
        iteration /* p_noofiteration */,
        skilllevelid /* p_skilllevelid */,
        uomid /* p_uomid */,
        appid /* p_appid */,
        queryraised /* p_isqueryraised */,
        // seccorrection /* p_seccorrection */,
        actual /* p_actualsla */,
        starttime /* p_starttime */,
        endtime /* p_endtime */,
        empcode /* p_empid */,
        bookcode /* p_bookCode */,
        subjob /* p_subjob */,
        createddate /* createddate */,
        wfid /* workflow id */,
      );
      resolve({ status: result, params: manualLogistics });
    } catch (error) {
      reject(error);
    }
  });
};

export const createServiceMasterService = servicename => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [servicename];
      const script = 'SELECT * FROM iproductivity.insert_wms_service($1);';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteServiceMasterService = serviceid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [serviceid];
      const script = 'SELECT * FROM iproductivity.delete_wms_service($1);';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createMasterStageService = stagename => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [stagename];
      const script = 'select * from iproductivity.insert_wms_stage($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getWODropDownService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { column, duid, custid } = payload;
      const values = [duid, custid];
      let script;
      if (column == 'wo') {
        script = getWoByCustIdDuIdScript();
      } else {
        script = getSubJobByCustIdDuIdScript();
      }
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getProductivtySchemaService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { user, fromDate, toDate } = payload;
      // const res = await query(userDetails(), [user]);
      // console.log(res);
      // const userid = res.length
      //   ? res.map(item => `'${item.userid}'`).join(',')
      //   : user;
      const script = productivitySummaryReportScript(user, fromDate, toDate);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getWorkFlowIDByCustomerService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerid } = payload;
      const values = [customerid];
      const script = getWorkFlowIDByCustomerScript();
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getStageDDByWorkFlowIDService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workFlowid } = payload;
      const values = [workFlowid];
      const script = getStageByWorkFlowIDScript();
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getActivityByWFIdStageIdService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfid, stageid } = payload;
      const values = [wfid, stageid];
      const script = getActivityByWFIdStageIdScript();
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getMonthwiseProductivityservice = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, type, dateRange, filterObj, selectedUser } = payload;
      let result = [];
      if (type === 'overallscore') {
        const res = await query(userList(), [userId]);
        const user = res.length
          ? res.map(item => `'${item.userid}'`).join(',')
          : `'${userId}'`;
        const values = [dateRange.startDate, dateRange.endDate];
        const script = getproductivityscore(user);
        result = await query(script, values);
      } else if (type === 'employee' || type === 'date') {
        // should write if the empdrop down is empty handle in UI
        let userdetails = [];
        if (type === 'date' && Object.keys(filterObj).length === 0) {
          userdetails = await query(userList(), [userId]);
        }
        const user = Object.keys(filterObj).length
          ? filterObj?.userid.map(item => `'${item}'`).join(',')
          : userdetails.length
          ? userdetails.map(item => `'${item.userid}'`).join(',')
          : `'${userId}'`;
        const values = [dateRange.startDate, dateRange.endDate];
        const script = getproductivityscore(user);
        result = await query(script, values);
      } else if (type === 'daywisereport') {
        const values = [selectedUser, dateRange.startDate, dateRange.endDate];
        result = await query(daywiseReport(), values);
      } else if (type === 'summaryreport') {
        const script = productivitySummaryReportScript(
          selectedUser,
          dateRange?.startDate,
          dateRange?.endDate,
        );
        result = await query(script);
      }
      resolve(result || []);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSubordinateListService = async empCode => {
  return new Promise(async (resolve, reject) => {
    try {
      const SubordinateScript = getSubordinatesList();
      const SubordinateList = await query(SubordinateScript, [empCode]);
      resolve(SubordinateList);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUOMArticleTitleService = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfId, stageId, activityId } = info;
      const script = getUOMArticleTitle();
      let uomres = false;
      const result = await query(script, [wfId, stageId, activityId]);
      if (result.length && result[0].itracksconfig?.isNewiTrackTrigger) {
        if (
          result[0].itracksconfig.uom_unit.toLowerCase() === 'article' ||
          result[0].itracksconfig.uom_unit.toLowerCase() === 'titles'
        ) {
          uomres = true;
        } else {
          uomres = false;
        }
      } else {
        uomres = false;
      }
      resolve(uomres);
    } catch (error) {
      reject(error);
    }
  });
};

export const getProductivityTotalService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { bookCode, stageId, activityId } = payload;
      let { subjob } = payload;
      const script = getProductivitySum();
      if (subjob === undefined) {
        subjob = null;
      }
      const result = await query(script, [
        bookCode,
        stageId,
        activityId,
        subjob,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getMasterReportService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { type, userId } = info;
      const script = get_master_drop_down(type.toUpperCase());
      const result = await query(script, [userId]);
      resolve(result || []);
    } catch (error) {
      reject(error);
    }
  });
};

export const getnormsDropdownService = info => {
  return new Promise(async (resolve, reject) => {
    const returnmsg = {
      message: '',
      issucccess: false,
      data: [],
    };
    const { type, stageid, wfid, activityid, customerid, duid } = info;
    try {
      let sql = '';
      if (type == 'odu' || type == 'customer') {
        sql = get_master_drop_down(type.toUpperCase());
      } else {
        sql = await get_dropdown_norms(type);
      }
      let itrackdu = '';
      if (duid) {
        const script = `select new_itrack_intg,itrackduid from public.org_mst_deliveryunit where duid=$1`;
        const [itrack] = (await query(script, [duid])) || [];
        itrackdu = itrack?.itrackduid || null;
      }
      const result =
        type == 'stage'
          ? await query(sql, [wfid])
          : type == 'activity'
          ? await query(sql, [wfid, stageid])
          : type == 'complexity'
          ? await query(sql, [itrackdu, customerid, wfid, stageid, activityid])
          : await query(sql);
      returnmsg.issucccess = true;
      returnmsg.data = result;
      resolve(returnmsg);
    } catch (error) {
      returnmsg.issucccess = false;
      returnmsg.message = error.message;
      reject(returnmsg);
    }
  });
};

export const getJobNormsService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { woId } = info;
      const script = getjobnorms();
      const result = await query(script, [woId]);
      resolve(result || []);
    } catch (error) {
      reject(error);
    }
  });
};

export const JobNormsInsertService = info => {
  return new Promise(async (resolve, reject) => {
    const returnmsg = {
      message: '',
      issucccess: false,
      data: [],
    };
    try {
      const {
        workorderid,
        customerid,
        duid,
        stageid,
        activityid,
        softwareid,
        complexityid,
        created_by,
      } = info;
      const script = InsertJobNorms();
      const result = await query(script, [
        workorderid,
        customerid,
        duid,
        stageid,
        activityid,
        softwareid,
        complexityid,
        created_by,
      ]);
      returnmsg.issucccess = true;
      returnmsg.data = result;
      resolve(returnmsg);
    } catch (error) {
      returnmsg.issucccess = false;
      returnmsg.message = error.message;
      reject(returnmsg);
    }
  });
};

export const JobNormsUpdateService = info => {
  return new Promise(async (resolve, reject) => {
    const returnmsg = {
      message: '',
      issucccess: false,
      data: [],
    };
    try {
      const { id, complexityid, isactive, updated_by, stageid, activityid } =
        info;
      const script = updatejobnorms();
      const result = await query(script, [
        id,
        complexityid,
        stageid,
        activityid,
        isactive,
        updated_by,
      ]);
      returnmsg.issucccess = true;
      returnmsg.data = result;
      resolve(returnmsg);
    } catch (error) {
      returnmsg.issucccess = false;
      returnmsg.message = error.message;
      reject(returnmsg);
    }
  });
};

export const getWorkorderDetailsnormsService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { woId } = info;
      const script = getWorkorderDetailsnorms();
      const result = await query(script, [woId]);
      resolve(result || []);
    } catch (error) {
      reject(error);
    }
  });
};

export const validateJobNormsService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        workorderId,
        customerId,
        duId,
        stageId,
        activityId,
        complexityid,
        type,
      } = info;
      const script = jobNormsValidation(type);
      let result = [];
      if (type == 'add') {
        result = await query(script, [
          workorderId,
          customerId,
          duId,
          stageId,
          activityId,
        ]);
      } else {
        result = await query(script, [
          workorderId,
          customerId,
          duId,
          stageId,
          activityId,
          complexityid,
        ]);
      }

      resolve(result || []);
    } catch (error) {
      reject(error);
    }
  });
};

// export const getUOMProductivityQtyService = async info => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const { woId, uomUnit } = info;
//       let column = '';
//       if (uomUnit === 'std. pages' || uomUnit === 'word count') {
//         column = 'wordcount';
//       } else if (uomUnit === 'ms pages') {
//         column = 'mspages';
//       } else if (uomUnit === 'images' || uomUnit === 'cover') {
//         column = 'imagecount';
//       } else if (
//         uomUnit === 'pdf pages' ||
//         uomUnit === 'no. of pages' ||
//         uomUnit === 'ts pages'
//       ) {
//         column = 'estimatedpages';
//       }
//       let result = [];
//       if (column != '') {
//         const script = getProductivityQuantityWMS(column);
//         result = await query(script, [woId]);
//       }
//       const valueuom =
//         result.length && result[0][column] != null
//           ? Number(result[0][column])
//           : 0;
//       resolve({ valueuom });
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

export const getUOMProductivityQtyService = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfEventId } = info;
      const script = getProductivityQuantityWMS();
      const result = await query(script, [wfEventId]);
      const valueuom =
        result.length && result[0]?.remaininguomcount != null
          ? Number(result[0]?.remaininguomcount)
          : 0;
      const total =
        result.length && result[0]?.actualuom != null
          ? Number(result[0]?.actualuom)
          : 0;
      resolve({ valueuom, total });
    } catch (error) {
      reject(error);
    }
  });
};

export const updateRemainingQty = async (
  wfeventId,
  valueuom,
  actualuom = null,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Round actualuom only if it's a valid number, else keep null
      const roundedActualUom = actualuom != null ? Math.round(actualuom) : null;
      const sql = `
        UPDATE public.wms_workflow_eventlog 
        SET 
          remaininguomcount = $2,
          actualuom = COALESCE($3, actualuom)
        WHERE wfeventid = $1;
      `;
      const result = await query(sql, [
        wfeventId,
        Math.round(valueuom),
        roundedActualUom,
      ]);
      resolve({ result });
    } catch (error) {
      reject(error);
    }
  });
};
