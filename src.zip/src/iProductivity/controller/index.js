import {
  createCustomerInfoService,
  createCustomerMasterService,
  deleteCustomerMasterService,
  getCustomerInfoService,
  getMasterService,
  getService,
  getWorkflowService,
  getStageService,
  updateCustomerMasterService,
  deleteCustomerInfoService,
  getCustActivityService,
  getIterationService,
  getNormsService,
  createNormsService,
  deleteNormsService,
  createServiceMasterService,
  deleteServiceMasterService,
  createStageMasterService,
  getSubDivbyDivIdService,
  getDynamicColumnsService,
  getCustomerDetailsService,
  createActivityMasterService,
  getNormActidSkidService,
  copyNormsToCustService,
  getNormVersionHistoryService,
  createManualLogisticService,
  getWODropDownService,
  getProductivtySchemaService,
  createMasterStageService,
  copyActivityService,
  editCustomerMasterService,
  getWorkFlowIDByCustomerService,
  getStageDDByWorkFlowIDService,
  getActivityByWFIdStageIdService,
  getUOMArticleTitleService,
  getProductivityTotalService,
  getMonthwiseProductivityservice,
  getMasterReportService,
  getnormsDropdownService,
  getJobNormsService,
  JobNormsInsertService,
  JobNormsUpdateService,
  getWorkorderDetailsnormsService,
  validateJobNormsService,
  getUOMProductivityQtyService,
  updateRemainingQty,
} from '../service/index.js';

export const getiProductivityFolderPath = async (req, res) => {
  try {
    res.status(200).send({ path: '/okm:root/prodrepository/iProductivity/' });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getDynamicColumnController = async (req, res) => {
  try {
    const filterValue = req.body;
    const out = await getDynamicColumnsService(filterValue);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getMasterController = async (req, res) => {
  try {
    const tblname = req.params.tblname.toUpperCase();
    const out = await getMasterService(tblname);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getSubDivByDivIdController = async (req, res) => {
  try {
    const { divID } = req.params;
    const out = await getSubDivbyDivIdService(divID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getIterationController = async (req, res) => {
  try {
    const out = await getIterationService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustomerInfoController = async (req, res) => {
  try {
    const { duid } = req.body;
    const out = await getCustomerInfoService(duid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustomerDetailsController = async (req, res) => {
  try {
    const { duid, customerID } = req.params;
    const out = await getCustomerDetailsService(duid, customerID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createCustomerInfoController = async (req, res) => {
  try {
    await createCustomerInfoService(req.body);
    res.status(201).send('Customer Info created successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteCustomerInfoController = async (req, res) => {
  try {
    const { custinfoid, updatedby } = req.body;
    const result = await deleteCustomerInfoService(custinfoid, updatedby);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createCustomerMasterController = async (req, res) => {
  try {
    const payload = req.body;
    let stageMaster;
    if (payload.stageid == null) {
      stageMaster = await createMasterStageService(payload.stageName);
      payload.stageid = stageMaster[0]?.insert_wms_stage;
    }
    await createCustomerInfoService(payload);
    res.status(201).send('Customer Info created successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createMstCustomerController = async (req, res) => {
  try {
    const payload = req.body;
    await createCustomerMasterService(payload);
    res.status(201).send('Customer created successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const editMasterCustomerController = async (req, res) => {
  try {
    const payload = req.body;
    await editCustomerMasterService(payload);
    res.status(201).send('Customer Updated successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateCustomerMasterController = async (req, res) => {
  try {
    await updateCustomerMasterService(req.body);
    res.status(201).send('Customer Info updated successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteCustomerMasterController = async (req, res) => {
  try {
    const { customerid } = req.params;
    await deleteCustomerMasterService(customerid);
    res.status(201).send('Customer Info updated successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getServiceController = async (req, res) => {
  try {
    const { custid } = req.params;
    const out = await getService(custid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getStageController = async (req, res) => {
  try {
    const { wfid } = req.params;
    const out = await getStageService(wfid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getWorkflowController = async (req, res) => {
  try {
    const { custid } = req.params;
    const out = await getWorkflowService(custid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustActivityController = async (req, res) => {
  try {
    const { custinfoid } = req.params;
    const result = await getCustActivityService(custinfoid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getNormsActidSkidController = async (req, res) => {
  try {
    const normsDetail = req.body;
    const result = await getNormActidSkidService(normsDetail);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const copyNormsToCustController = async (req, res) => {
  try {
    const normsDetail = req.body;
    const result = await copyNormsToCustService(normsDetail);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const copyActivityController = async (req, res) => {
  try {
    const activityDetails = req.body;
    const result = await copyActivityService(activityDetails);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getNormsController = async (req, res) => {
  try {
    const { custinfoid } = req.params;
    const out = await getNormsService(custinfoid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createNormsController = async (req, res) => {
  try {
    const payload = req.body;
    let activityMaster;
    if (payload.activityid == null) {
      activityMaster = await createActivityMasterService(payload);
      payload.activityid = activityMaster[0]?.insert_wms_mst_activity;
    }
    await createNormsService(payload);
    // try {
    //   await mailTriggerService(mailData);
    // } catch (mailError) {
    //   console.error('Mail Trigger Service Error:', mailError);
    // }
    res.status(201).send('New Norms Created Successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getNormVersionHistoryController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getNormVersionHistoryService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteNormsController = async (req, res) => {
  try {
    const payload = req.body;
    await deleteNormsService(payload);
    res.status(200).send('Norms Deleted Successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createManaualLogisticsController = async (req, res) => {
  try {
    const payload = req.body;
    await createManualLogisticService(payload);
    res.status(200).send('Norms Successfully Calculated!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createServiceMasterController = async (req, res) => {
  try {
    const { servicename } = req.body;
    await createServiceMasterService(servicename);
    res.status(201).send('Service Info created successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteServiceMasterController = async (req, res) => {
  try {
    const { serviceid } = req.params;
    await deleteServiceMasterService(serviceid);
    res.status(201).send('Service Info updated successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createStageMasterController = async (req, res) => {
  try {
    const { stagename } = req.body;
    await createStageMasterService(stagename);
    res.status(201).send('stage created successfully!');
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getDropDownForManualEntryController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getWODropDownService(payload);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getProductivityReportController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getProductivtySchemaService(payload);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getWorkFlowidByCustomerController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getWorkFlowIDByCustomerService(payload);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getStageDDByWorkFlowIDController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getStageDDByWorkFlowIDService(payload);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getActivityByWFIdStageIdController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getActivityByWFIdStageIdService(payload);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUOMArticleTitleController = async (req, res) => {
  try {
    const out = await getUOMArticleTitleService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getProductityTotalController = async (req, res) => {
  try {
    const out = await getProductivityTotalService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getProductityIndividualReportController = async (req, res) => {
  try {
    const out = await getMonthwiseProductivityservice(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getReportMasterControllers = async (req, res) => {
  try {
    const out = await getMasterReportService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getNormsDropdownControllers = async (req, res) => {
  try {
    const out = await getnormsDropdownService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getJobNormsControllers = async (req, res) => {
  try {
    const out = await getJobNormsService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const jobNormsInsertControllers = async (req, res) => {
  try {
    const out = await JobNormsInsertService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const jobNormsUpdateControllers = async (req, res) => {
  try {
    const out = await JobNormsUpdateService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getWorkorderDetailsnormsControllers = async (req, res) => {
  try {
    const out = await getWorkorderDetailsnormsService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const validateJobNormsControllers = async (req, res) => {
  try {
    const out = await validateJobNormsService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUOMProductivityQtyControllers = async (req, res) => {
  try {
    const out = await getUOMProductivityQtyService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateRemainQtyControllers = async (req, res) => {
  try {
    const { wfEventId, remQty } = req.body;
    const out = await updateRemainingQty(wfEventId, remQty);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
