import ejs from 'ejs';
import moment from 'moment';
import { query } from '../../database/postgres.js';
import {
  get_master_drop_down,
  getRoleAcronym,
} from '../dataLayer/masterDropDown.js';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import {
  createNewJob,
  fileUploadPath,
  // UpdateJobFilePath,
  getCheckSeriesExistScript,
  getJobDetails,
  getNotesScript,
  insNotesScript,
  createProductionTeam,
  createMSTeam,
  createContentTeam,
  createPMTeam,
  getExportListScript,
  updateMSedit,
  getMSEdit,
  updatePTedit,
  getPTEdit,
  updateCTedit,
  getCTEdit,
  updatePMedit,
  getSeriesInfoScript,
  getfilepath,
  updateFileInDB,
  updateCTinPMTable,
  updatePTinPMTable,
  updateMSinPMTable,
  unclaimjob,
  updatepmstatus,
  updateCTStatus,
  updatePTStatus,
  updateMSStatus,
  updatemscleanup,
  getEmailTemplateScript,
  getMailIntroInfoScript,
  getCompleteStatus,
  getPMDetails,
  getPMEdit,
  updatePMStatusWithMScleanup,
  reSubmitJob,
  pmUpdate,
  ptUpdate,
  msUpdate,
  ctUpdate,
  getCupConfig,
  getTatExcludeHolidayScript,
  getPMStatusMail,
  pmwithoutDueonUpdate,
  getJobStatus,
  updateJobElementStatus,
} from '../dataLayer/jobDetails.js';
import {
  getQueriesListScript,
  createQuery,
  createAssignQuery,
  queryfileUploadDetails,
  getQuerybasedJobId,
  getRaisedQueries,
  getOpenedQueries,
  createReject,
  getQueryDetails,
  getQueryConvo,
  getLatestRes,
  updQueryResponse,
  updQueryClose,
  updateStatusJob,
} from '../dataLayer/queries.js';
import {
  getunclaimedjob,
  getclaimedjob,
  getstatus,
  getRoleJobStatus,
  updateRoleJobStatus,
  updatePRStatus,
  getPRstatus,
  createHistory,
  getFoldername,
  addAttachementFileDetails,
  CreateSeriesMaster,
  UpdateSeriesMaster,
  checkSeries,
  checkSeriesCode,
  getSeriesMasterDetails,
  getSeriesData,
  getPMOpenJob,
  ReassignPM,
  removeSeries,
  getJobHistoryScript,
  getteamjobdetails,
  getRejectedjob,
  getRejectedjobDetails,
  updatePMJobStatus,
  updatePTJobStatus,
  updateMSJobStatus,
  updateCTJobStatus,
  updateRejectJobStatus,
  getopenquerydetails,
} from '../dataLayer/jobStatus.js';
import { emitAction } from '../../modules/activityListener/activityListener.js';
import { getRoleBasedMail, getUserMail } from '../../modules/common/index.js';
import { getCurrentTimestamp } from '../helpers/common.js';

const service = new Service();

export const getMasterService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(get_master_drop_down(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createNewJobService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const ytsStatus = await query(
        `select statusid from cupelements.mst_status where statuscode = 'YTS'`,
      );
      const {
        seriesid,
        seriescode,
        pe,
        elmnttitle,
        title,
        acptdon,
        orcid,
        s1id,
        openaccess,
        wordcount,
        figurecount,
        imagecount,
        authordet,
        suplmntryfile,
        questionnaire,
        permission,
        figurefile,
        cntenhancement,
        source,
        note,
        created_by,
        mainfile,
        projectmanager,
        enhancement,
        dueon,
        uploadedtype,
        seriesjson,
        sourcefilevalue,
      } = Info;
      let itracksJobRes = null;
      let itracksStageRes = null;
      let integrateType = null;
      let iStagePayload = null;
      let stages = null;
      let jobType = null;
      let isubjobid = null;
      const currentTime = moment().format('YYYY-MM-DD HH:mm:ss.SSS');

      const CupConfigScript = getCupConfig();
      const jciConfigInfo = await query(CupConfigScript, ['JCI']);

      if (jciConfigInfo.length && jciConfigInfo[0]?.isactive) {
        const configJson = jciConfigInfo[0]?.config_json;
        integrateType = configJson?.integrate;
        const iJobPayload = configJson[integrateType].payload.createbookjob;
        jobType = iJobPayload.VerticalCode;
        iStagePayload = configJson[integrateType].payload.addsubjob;
        stages = configJson[integrateType].stages;

        if (integrateType === 'old_iTracks') {
          const correspondingAuthor = authordet.find(
            author => author.correspondingauthor === 'Yes',
          );
          Object.assign(iJobPayload, {
            JobTitle: title,
            BookCode: `${seriescode}-${correspondingAuthor.firstname.replace(
              ' ',
              '_',
            )}-E2E-ELE-${jciConfigInfo[0]?.maxid}`,
            ProductionEditor: pe,
            Author: `${correspondingAuthor?.firstname} ${
              correspondingAuthor?.middlename
                ? `${correspondingAuthor.middlename} `
                : ''
            }${correspondingAuthor?.lastname}`,
            AuthorMailId: correspondingAuthor?.email,
            CSEEmpCode: projectmanager,
          });
          itracksJobRes = await createiTracksJob({
            type: jobType,
            iPayload: iJobPayload,
          });
          console.log(itracksJobRes, 'itracksJobRes');
        }
      }

      if (!jciConfigInfo[0]?.isactive || itracksJobRes?.status) {
        let script = createNewJob();
        let values = [
          seriesid,
          elmnttitle,
          title,
          acptdon,
          orcid,
          s1id,
          openaccess,
          wordcount,
          figurecount,
          imagecount,
          authordet != '' ? JSON.stringify(authordet) : null,
          suplmntryfile != '' ? JSON.stringify(suplmntryfile) : null,
          questionnaire != '' ? JSON.stringify(questionnaire) : null,
          permission != '' ? JSON.stringify(permission) : null,
          figurefile != '' ? JSON.stringify(figurefile) : null,
          cntenhancement,
          source != '' ? JSON.stringify(source) : null,
          note,
          created_by,
          mainfile != '' ? JSON.stringify(mainfile) : null,
          projectmanager,
          enhancement != '' ? enhancement : null,
          dueon,
          uploadedtype,
          seriesjson != '' ? JSON.stringify(seriesjson) : null,
          ytsStatus[0]?.statusid,
          itracksJobRes?.jobCardId,
          sourcefilevalue,
        ];
        const result = await query(script, values);
        const currentDateObj = new Date();
        let dateCounter = 0;
        // Loop to find the date after skipping Saturdays and Sundays
        while (dateCounter < 2) {
          // Skip Saturday (day 6) and Sunday (day 0)
          if (currentDateObj.getDay() !== 5 && currentDateObj.getDay() !== 6) {
            dateCounter++;
          }
          currentDateObj.setDate(currentDateObj.getDate() + 1); // Increment the date
        }

        if (integrateType === 'old_iTracks' && itracksJobRes?.status) {
          const buildiPayloads = Object.keys(stages).map(async key => {
            const stage = stages[key];
            const iTempPayload = { ...iStagePayload };

            Object.assign(iTempPayload, {
              dueDate: moment(
                (
                  await query(getTatExcludeHolidayScript(), [
                    currentTime,
                    stage?.tat,
                  ])
                )[0].duedate,
              ).format('YYYY-MM-DD HH:mm:ss.SSS'),
              empcode: created_by,
              jobCardId: itracksJobRes?.jobCardId,
              stageName: stage?.stagename,
              ReceiptDate: currentTime,
            });

            return iTempPayload;
          });

          const iPayload = await Promise.all(buildiPayloads);
          itracksStageRes = await createiTracksStage({
            type: jobType,
            iPayload,
          });
          isubjobid = itracksStageRes?.subJobID;
        }

        if (result[0]?.jobid) {
          const values1 = [
            result[0]?.jobid,
            seriesid,
            title,
            acptdon,
            ytsStatus[0]?.statusid,
            created_by,
            currentDateObj.toLocaleDateString('en-US'),
            isubjobid,
            elmnttitle,
            orcid,
            s1id,
            openaccess,
            authordet != '' ? JSON.stringify(authordet) : null,
          ];

          script = createPMTeam();

          await query(script, values1);
          const values2 = [
            result[0]?.jobid,
            seriesid,
            title,
            acptdon,
            ytsStatus[0]?.statusid,
            created_by,
            dueon,
            isubjobid,
          ];
          values = [
            result[0]?.jobid,
            seriesid,
            title,
            acptdon,
            ytsStatus[0]?.statusid,
            created_by,
            dueon,
            isubjobid,
          ];

          script = createProductionTeam();
          await query(script, values2);

          script = createMSTeam();
          await query(script, values);

          script = createContentTeam();
          await query(script, values);

          const seriesInfo = await getSeriesInfo(seriesid);
          const pmtlsMailId = await getRoleBasedMail('C_PMTL');
          const pmMailId = await getUserMail(projectmanager);
          const prMailId = await getUserMail(created_by);
          const mailPayload = {
            series: seriesInfo[0].series,
            title,
            ishypercare: seriesInfo[0].ishypercare ? 'Yes' : 'No',
            pmMailId,
            pmtlsMailId,
            prMailId,
          };
          console.log(mailPayload);
          await sendMail_By_PR(mailPayload, 'cup_pr_job_created');
        }
        resolve(result);
      } else {
        reject({ error: 'Failed', message: itracksJobRes.message });
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const getQueriesListService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQueriesListScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const unclaimedjobService = (role, userid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const roleDetails = await query(
        `select roleacronym from public.wms_role where roleid = ${role}`,
      );
      let result = [];
      if (roleDetails[0].roleacronym === 'C_PM') {
        result = await query(getunclaimedjob(roleDetails[0].roleacronym), [
          userid,
        ]);
      } else {
        result = await query(getunclaimedjob(roleDetails[0].roleacronym));
      }

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const claimedjobService = (role, userid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const roleDetails = await query(
        `select roleacronym from public.wms_role where roleid = ${role}`,
      );
      let result = [];
      if (
        roleDetails[0].roleacronym === 'C_PM' ||
        roleDetails[0].roleacronym === 'C_PT' ||
        roleDetails[0].roleacronym === 'C_CT' ||
        roleDetails[0].roleacronym === 'C_MS'
      ) {
        result = await query(getclaimedjob(roleDetails[0].roleacronym), [
          userid,
        ]);
      } else {
        result = await query(getclaimedjob(roleDetails[0].roleacronym));
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getstatusService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getstatus());
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getFileUploadPathService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(fileUploadPath());
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const addJobFilePathService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobid,
        MSTeam,
        PTTeam,
        CTTeam,
        PMTeamimprint,
        PMTeamupload,
        mainfile,
        suplmntryfile,
        questionnaire,
        permission,
        figurefile,
        source,
        userid,
      } = Info;
      const script = addAttachementFileDetails();
      let values = [];
      if (mainfile.length > 0) {
        mainfile.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      if (suplmntryfile.length > 0) {
        suplmntryfile.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      if (questionnaire.length > 0) {
        questionnaire.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      if (permission.length > 0) {
        permission.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      if (figurefile.length > 0) {
        figurefile.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      if (source.length > 0) {
        source.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      if (MSTeam.length > 0 || MSTeam.length == undefined) {
        if (MSTeam?.length > 0) {
          MSTeam?.map(async row => {
            values = [
              row.attachtypeid,
              jobid,
              row.fileName,
              row.fileUrl,
              row.uploadtype,
              userid,
            ];
            await query(script, values);
          });
        }
      }
      if (PTTeam?.length > 0 || PTTeam?.length == undefined) {
        if (PTTeam?.length > 0) {
          PTTeam?.map(async row => {
            values = [
              row.attachtypeid,
              jobid,
              row.fileName,
              row.fileUrl,
              row.uploadtype,
              userid,
            ];
            await query(script, values);
          });
        }
      }
      if (CTTeam?.length > 0 || CTTeam?.length == undefined) {
        if (CTTeam?.length > 0) {
          CTTeam?.map(async row => {
            values = [
              row.attachtypeid,
              jobid,
              row.fileName,
              row.fileUrl,
              row.uploadtype,
              userid,
            ];
            await query(script, values);
          });
        }
      }
      if (PMTeamimprint?.length > 0 || PMTeamimprint?.length == undefined) {
        PMTeamimprint.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      if (PMTeamupload?.length > 0 || PMTeamupload?.length == undefined) {
        PMTeamupload.map(async row => {
          values = [
            row.attachtypeid,
            jobid,
            row.fileName,
            row.fileUrl,
            row.uploadtype,
            userid,
          ];
          await query(script, values);
        });
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
export const getCheckSeriesExistService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getCheckSeriesExistScript());
      resolve(result[0]?.exists > 0);
    } catch (error) {
      reject(error);
    }
  });
};

export const getJobDetailsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getJobDetails(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getNotesService = jobid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getNotesScript();
      const result = await query(script, [jobid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insNotesService = (jobid, notes, userid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await insNotesScript();
      const result = await query(script, [
        jobid,
        notes,
        userid,
        getCurrentTimestamp(),
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRoleAcronymService = roleid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getRoleAcronym();
      const result = await query(script, [roleid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getExportListService = jobid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getExportListScript();
      const result = await query(script, [jobid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRoleJobStatusService = (jobid, role) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getRoleJobStatus(role);
      const result = await query(script, [jobid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateRoleJobStatusService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobId, status, updated_by, role, roleId, statusType } = Info;
      const statusid = await query(
        `select statusid from cupelements.mst_status where statuscode = '${status}'`,
      );
      let script = updateRoleJobStatus(role);
      let value = [jobId, statusid[0].statusid, updated_by];
      await query(script, value);
      script = getPRstatus();
      const jobstatus = await query(script, [jobId]);
      if (jobstatus[0].statuscode === 'YTS' || statusType === 'onhold') {
        script = updatePRStatus();
        await query(script, value);
      }
      if (statusType != 'onhold') {
        value = [
          jobId,
          roleId,
          statusType,
          updated_by,
          null,
          getCurrentTimestamp(),
        ];
        script = createHistory();
        await query(script, value);
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const savemseditService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobid,
        level,
        copyeditor,
        subjectCode,
        placequalifier,
        languagequalifier,
        timequalifier,
        eduactionqualifier,
        interestgroupqualifier,
        stylequalifier,
        printing,
        file,
        statusid,
        updated_by,
        completed_date,
        fromSubmitted,
        ijobcardid,
        isubjobid,
        pm,
        ismscleanup,
      } = Info;
      const status = await query(
        `select statusid from cupelements.mst_status where statuscode = '${statusid}'`,
      );
      const script = updateMSedit();
      const script2 = updateMSinPMTable();
      const values = [
        jobid,
        level,
        copyeditor,
        subjectCode,
        placequalifier,
        languagequalifier,
        timequalifier,
        eduactionqualifier,
        interestgroupqualifier,
        stylequalifier,
        printing,
        file,
        status[0].statusid,
        updated_by,
        completed_date,
      ];
      const value2 = [
        jobid,
        level,
        copyeditor,
        placequalifier,
        languagequalifier,
        timequalifier,
        eduactionqualifier,
        interestgroupqualifier,
        stylequalifier,
        printing,
        subjectCode,
      ];
      const result = await query(script, values);
      if (ismscleanup == true) {
        const dataquery = await query(script2, value2);
        console.log(dataquery);
      }
      if (fromSubmitted == '1' && ismscleanup == false) {
        const CupConfigScript = getCupConfig();
        const sciConfigInfo = await query(CupConfigScript, ['SCI']);
        let iProdDesRes;
        let iCustDesRes;
        const currentTime = moment().format('YYYY-MM-DD HH:mm:ss.SSS');

        if (sciConfigInfo.length && sciConfigInfo[0]?.isactive) {
          const configJson = sciConfigInfo[0]?.config_json;
          const integrateType = configJson?.integrate;
          const iProdDisPayload =
            configJson[integrateType].payload.productiondispatch;
          const iCustDisPayload =
            configJson[integrateType].payload.customerdispatch;
          const stageInfo = configJson[integrateType].stages?.C_MS;

          if (integrateType === 'old_iTracks') {
            Object.assign(iProdDisPayload, {
              SubJob: [
                {
                  Quantity: 1,
                  SubJobId: isubjobid,
                },
              ],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });
            Object.assign(iCustDisPayload, {
              SubJob: [isubjobid],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });

            iProdDesRes = await iTracksProdClose(iProdDisPayload);
            console.log(iProdDesRes, 'iProdDesRes');

            iCustDesRes = await iTracksCustClose(iCustDisPayload);
            console.log(iCustDesRes, 'iCustDesRes');
          }
        }
        if (
          !sciConfigInfo[0]?.isactive ||
          (iProdDesRes?.status && iCustDesRes?.status)
        ) {
          const dataquery = await query(script2, value2);
          resolve(dataquery);
        } else {
          reject({ error: 'iTracks Stage closing failed' });
        }
      } else if (fromSubmitted == '0') {
        resolve(result);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getMSEditService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getMSEdit(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const savepteditService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobid,
        wordcount,
        number_of_images,
        toc,
        line_art,
        maps,
        halftones,
        tables,
        music_examples,
        all_to_be_text,
        file,
        statusid,
        updated_by,
        completed_date,
        fromSubmitted,
        ijobcardid,
        isubjobid,
        pm,
      } = Info;
      const status = await query(
        `select statusid from cupelements.mst_status where statuscode = '${statusid}'`,
      );
      const script = updatePTedit();
      const script2 = updatePTinPMTable();
      const values = [
        jobid,
        wordcount,
        number_of_images,
        toc,
        line_art,
        maps,
        halftones,
        tables,
        music_examples,
        all_to_be_text,
        file,
        status[0].statusid,
        updated_by,
        completed_date,
      ];
      const value2 = [
        jobid,
        wordcount,
        number_of_images,
        toc,
        line_art,
        maps,
        halftones,
        tables,
        music_examples,
      ];
      const result = await query(script, values);
      if (fromSubmitted == '1') {
        const CupConfigScript = getCupConfig();
        const sciConfigInfo = await query(CupConfigScript, ['SCI']);
        let iProdDesRes;
        let iCustDesRes;
        const currentTime = moment().format('YYYY-MM-DD HH:mm:ss.SSS');

        if (sciConfigInfo.length && sciConfigInfo[0]?.isactive) {
          const configJson = sciConfigInfo[0]?.config_json;
          const integrateType = configJson?.integrate;
          const iProdDisPayload =
            configJson[integrateType].payload.productiondispatch;
          const iCustDisPayload =
            configJson[integrateType].payload.customerdispatch;
          const stageInfo = configJson[integrateType].stages?.C_PT;

          if (integrateType === 'old_iTracks') {
            Object.assign(iProdDisPayload, {
              SubJob: [
                {
                  Quantity: 1,
                  SubJobId: isubjobid,
                },
              ],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });
            Object.assign(iCustDisPayload, {
              SubJob: [isubjobid],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });

            iProdDesRes = await iTracksProdClose(iProdDisPayload);
            console.log(iProdDesRes, 'iProdDesRes');

            iCustDesRes = await iTracksCustClose(iCustDisPayload);
            console.log(iCustDesRes, 'iCustDesRes');
          }
        }
        if (
          !sciConfigInfo[0]?.isactive ||
          (iProdDesRes?.status && iCustDesRes?.status)
        ) {
          const dataquery = await query(script2, value2);
          resolve(dataquery);
        } else {
          reject({ error: 'iTracks Stage closing failed' });
        }
      } else if (fromSubmitted == '0') {
        resolve(result);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPTEditService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getPTEdit(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const savecteditService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobid,
        websiteandbrouchercopy,
        bookseller,
        tensecondsell,
        file,
        statusid,
        updated_by,
        completed_date,
        fromSubmitted,
        ijobcardid,
        isubjobid,
        pm,
      } = Info;
      const status = await query(
        `select statusid from cupelements.mst_status where statuscode = '${statusid}'`,
      );
      const script1 = updateCTedit();
      const script2 = updateCTinPMTable();
      const values = [
        jobid,
        websiteandbrouchercopy,
        bookseller,
        tensecondsell,
        file,
        status[0].statusid,
        updated_by,
        completed_date,
      ];
      const value2 = [jobid, websiteandbrouchercopy, bookseller, tensecondsell];
      const result = await query(script1, values);
      if (fromSubmitted == '1') {
        const CupConfigScript = getCupConfig();
        const sciConfigInfo = await query(CupConfigScript, ['SCI']);
        let iProdDesRes;
        let iCustDesRes;
        const currentTime = moment().format('YYYY-MM-DD HH:mm:ss.SSS');

        if (sciConfigInfo.length && sciConfigInfo[0]?.isactive) {
          const configJson = sciConfigInfo[0]?.config_json;
          const integrateType = configJson?.integrate;
          const iProdDisPayload =
            configJson[integrateType].payload.productiondispatch;
          const iCustDisPayload =
            configJson[integrateType].payload.customerdispatch;
          const stageInfo = configJson[integrateType].stages?.C_CT;

          if (integrateType === 'old_iTracks') {
            Object.assign(iProdDisPayload, {
              SubJob: [
                {
                  Quantity: 1,
                  SubJobId: isubjobid,
                },
              ],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });
            Object.assign(iCustDisPayload, {
              SubJob: [isubjobid],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });

            iProdDesRes = await iTracksProdClose(iProdDisPayload);
            console.log(iProdDesRes, 'iProdDesRes');

            iCustDesRes = await iTracksCustClose(iCustDisPayload);
            console.log(iCustDesRes, 'iCustDesRes');
          }
        }
        if (
          !sciConfigInfo[0]?.isactive ||
          (iProdDesRes?.status && iCustDesRes?.status)
        ) {
          const dataquery = await query(script2, value2);
          resolve(dataquery);
        } else {
          reject({ error: 'iTracks Stage closing failed' });
        }
      } else if (fromSubmitted == '0') {
        resolve(result);
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const getCTEditService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getCTEdit(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getFolderNameService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getFoldername();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createSeriesMasterService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        seriescode,
        series,
        issn,
        trim,
        design,
        clrprntstrgy,
        copyediting,
        copyeditinglvl,
        proofread,
        index_fld,
        style,
        runningheads,
        deliverables,
        contentmanager,
        projectmanager,
        comeditor,
        ioscontopscntrlr,
        covertemp,
        subjectarea,
        proofinstruct,
        patterntitle,
        notes,
        reference,
        addnlnotes,
        ishypercare,
        created_by,
        series_editor,
      } = Info;
      const script = CreateSeriesMaster();
      const values = [
        seriescode,
        series,
        issn,
        trim,
        design,
        clrprntstrgy,
        copyediting,
        copyeditinglvl,
        proofread,
        index_fld,
        style,
        runningheads,
        deliverables,
        contentmanager,
        projectmanager?.value ? projectmanager?.value : null,
        comeditor,
        ioscontopscntrlr,
        covertemp,
        subjectarea,
        proofinstruct,
        patterntitle,
        notes,
        reference,
        addnlnotes,
        ishypercare,
        created_by,
        series_editor != '' ? JSON.stringify(series_editor) : null,
      ];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateSeriesMasterService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        seriesid,
        seriescode,
        series,
        issn,
        trim,
        design,
        clrprntstrgy,
        copyediting,
        copyeditinglvl,
        proofread,
        index_fld,
        style,
        runningheads,
        deliverables,
        contentmanager,
        projectmanager,
        comeditor,
        ioscontopscntrlr,
        covertemp,
        subjectarea,
        proofinstruct,
        patterntitle,
        notes,
        reference,
        addnlnotes,
        ishypercare,
        updated_by,
        series_editor,
      } = Info;
      const script = UpdateSeriesMaster();
      const values = [
        seriesid,
        seriescode,
        series,
        issn,
        trim,
        design,
        clrprntstrgy,
        copyediting,
        copyeditinglvl,
        proofread,
        index_fld,
        style,
        runningheads,
        deliverables,
        contentmanager,
        projectmanager?.value ? projectmanager?.value : null,
        comeditor,
        ioscontopscntrlr,
        covertemp,
        subjectarea,
        proofinstruct,
        patterntitle,
        notes,
        reference,
        addnlnotes,
        ishypercare,
        updated_by,
        series_editor != '' ? JSON.stringify(series_editor) : null,
      ];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const checkseriesexistsService = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(checkSeries(info));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const checkseriescodeexistsService = async info => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(checkSeriesCode(info));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const savepmeditService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobid,
        seriesid,
        series_editor,
        affiliation,
        element_title,
        title,
        job_subtitle,
        acptdon,
        job_pubmonth,
        mvdtoprod,
        orcid,
        s1id,
        hypercare,
        editor_contactdetail,
        author_contact_details,
        level_english,
        copy_editor,
        wordcount,
        number_of_images,
        trimsize,
        hb_isbn,
        pb_isbn,
        oc_isbn,
        centaurid,
        shorturl,
        t_subject_code,
        t_education_qualifier,
        t_interest_group_qualifier,
        t_language_qualifier,
        t_place_qualifier,
        t_style_qualifier,
        t_time_qualifier,
        line_art,
        maps,
        halftones,
        tables,
        music_examples,
        websiteandbrouchercopy,
        bookseller,
        tensecondsell,
        toc,
        created_by,
        statusid,
        completed_date,
        updated_by,
        printing,
      } = Info;
      const status = await query(
        `select statusid from cupelements.mst_status where statuscode = '${statusid}'`,
      );
      const script = updatePMedit();
      const values = [
        jobid,
        seriesid,
        series_editor,
        affiliation,
        element_title,
        title,
        job_subtitle,
        acptdon,
        job_pubmonth,
        mvdtoprod,
        orcid,
        s1id,
        hypercare,
        editor_contactdetail != ''
          ? JSON.stringify(editor_contactdetail)
          : null,
        author_contact_details != ''
          ? JSON.stringify(author_contact_details)
          : null,
        level_english,
        copy_editor,
        wordcount,
        number_of_images,
        trimsize,
        hb_isbn,
        pb_isbn,
        oc_isbn,
        centaurid,
        shorturl,
        // t_subject_code != '' ? JSON.stringify(t_subject_code) : null,
        t_subject_code,
        t_education_qualifier,
        t_interest_group_qualifier,
        t_language_qualifier,
        t_place_qualifier,
        t_style_qualifier,
        t_time_qualifier,
        line_art,
        maps,
        halftones,
        tables,
        music_examples,
        websiteandbrouchercopy,
        bookseller,
        tensecondsell,
        toc,
        created_by,
        status[0].statusid,
        updated_by,
        completed_date,
        printing,
      ];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSeriesMasterDetailsService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      let result = [];
      const { role, userId } = Info;
      const script = getSeriesMasterDetails(role);
      if (role === 'C_PM') {
        result = await query(script, [userId]);
      } else {
        result = await query(script);
      }

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSeriesDataService = seriesid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getSeriesData();
      const result = await query(script, [seriesid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPMOpenJobService = seriesid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getPMOpenJob();
      const result = await query(script, [seriesid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const ReassignSeriesService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobId, pmId, updatedBy } = Info;
      const script = ReassignPM();
      let result = [];
      if (jobId.length > 0) {
        jobId.map(async item => {
          result = await query(script, [item.jobid, pmId, updatedBy]);
        });
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const removeSeriesService = (seriesid, userid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = removeSeries();
      const result = await query(script, [seriesid, userid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getJobHistoryService = async (jobid, roleacronym) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [jobid, roleacronym];
      const result = await query(await getJobHistoryScript(), values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// Mail Service
export async function sendMail_By_PR(Data, Type) {
  try {
    const resForConfig = await getEmailTemplateforEmail(113, Type);
    const { notificationconfig } = resForConfig[0];
    const mailIDinTO = extractEmails(notificationconfig.to);
    const mailIDinCC = extractEmails(notificationconfig.cc);

    if (notificationconfig.to.includes('C_PM'))
      mailIDinTO.push(...Data.pmMailId);
    else if (notificationconfig.cc.includes('C_PM'))
      mailIDinCC.push(...Data.pmMailId);

    if (notificationconfig.to.includes('C_PMTL'))
      mailIDinTO.push(...Data.pmtlsMailId);
    else if (notificationconfig.cc.includes('C_PMTL'))
      mailIDinCC.push(...Data.pmtlsMailId);

    if (notificationconfig.to.includes('C_PR'))
      mailIDinTO.push(...Data.prMailId);
    else if (notificationconfig.cc.includes('C_PR'))
      mailIDinCC.push(...Data.prMailId);

    const updatedNotificationConfig = await modifyNotificationConfigFromEmails(
      notificationconfig,
      mailIDinTO,
      mailIDinCC,
    );

    const mailData = {
      ...updatedNotificationConfig,
      series: Data.series,
      title: Data.title,
      isHypercare: Data.ishypercare,
    };
    emitAction(mailData);
    return true;
  } catch (error) {
    return true;
  }
}

export const getEmailTemplateforEmail = async (entityid, action) => {
  try {
    const sql = `SELECT * from wms_notifications WHERE entityid = ${entityid} and action = '${action}'`;
    const resForConfig = await query(sql);
    if (resForConfig.length > 0) {
      return resForConfig;
    }
    return false;
  } catch (error) {
    return false;
  }
};

function extractEmails(emails) {
  return emails.filter(email => email.includes('@'));
}

export async function modifyNotificationConfigFromEmails(
  mailConfig,
  mailIDinTO,
  mailIDinCC,
) {
  // Deduplicate and filter out null values
  mailConfig.to = [...new Set(mailIDinTO)].filter(
    email => email && email !== 'null',
  );
  mailConfig.cc = [...new Set([...mailIDinCC])].filter(
    email => email && email !== 'null',
  );

  // Remove email IDs that exist in both to and cc arrays
  mailConfig.cc = mailConfig.cc.filter(email => !mailConfig.to.includes(email));
  return mailConfig;
}

const getSeriesInfo = seriedid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = await getSeriesInfoScript();
      const result = await query(script, [seriedid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getFilePathService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobid, attachtypeid } = Info;
      const script = getfilepath();
      const values = [jobid, attachtypeid];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateFileInDBService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobid, attachtypeid, attachname } = Info;
      const script = updateFileInDB();
      const values = [jobid, attachtypeid, attachname];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const unclaimjobService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { team, jobid } = Info;
      const script = unclaimjob(team);
      const values = [jobid];
      const result = await query(script, values);
      if (result) {
        const statusScript = getJobStatus();
        const result2 = await query(statusScript, values);
        if (result2) {
          const PRStatusScript = updateJobElementStatus();
          const result3 = await query(PRStatusScript, values);
          resolve(result3);
        } else {
          resolve(result);
        }
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const createQueryService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobid,
        raiseQuery,
        attachment,
        is_closed,
        created_by,
        assigned_to,
        response,
        assigned_from,
      } = Info;
      let script = createQuery();
      let values = [
        jobid,
        raiseQuery,
        attachment != '' ? JSON.stringify(attachment) : null,
        is_closed,
        created_by,
        getCurrentTimestamp(),
      ];
      let result = await query(script, values);
      const queryid = result[0]?.queryid;
      if (result[0]?.queryid) {
        script = createAssignQuery();
        values = [
          result[0]?.queryid,
          assigned_to,
          response != '' ? response : null,
          attachment != '' ? JSON.stringify(attachment) : null,
          assigned_from,
          created_by,
          getCurrentTimestamp(),
        ];
        result = await query(script, values);
      }
      script = createHistory();
      values = [
        jobid,
        assigned_from,
        'query',
        created_by,
        queryid,
        getCurrentTimestamp(),
      ];
      await query(script, values);
      resolve([{ queryid, assignid: result[0]?.assignid }]);
    } catch (error) {
      reject(error);
    }
  });
};

export const queryFileUploadDetailsService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { queryid, created_by, attachment } = Info;
      const script = queryfileUploadDetails();
      const values = [
        attachment != '' ? JSON.stringify(attachment) : null,
        created_by,
        queryid,
        getCurrentTimestamp(),
      ];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getQueryJobBasedService = jobid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getQuerybasedJobId();
      const result = await query(script, [jobid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const updatepmstatusService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      let status = '';
      const { jobid, statuscode, button_status, ijobcardid, isubjobid, pm } =
        Info;
      if (statuscode != '') {
        status = await query(
          `select statusid from cupelements.mst_status where statuscode = '${statuscode}'`,
        );
      }
      const script = updatepmstatus(statuscode);
      const values = [jobid, status[0]?.statusid, button_status];
      const result = await query(script, values);
      if (statuscode == 'CL') {
        const script2 = updateCTStatus();
        const values2 = [jobid, status[0]?.statusid];
        await query(script2, values2);
        const script3 = updatePTStatus();
        const values3 = [jobid, status[0]?.statusid];
        await query(script3, values3);
        const script4 = updateMSStatus();
        const values4 = [jobid, status[0]?.statusid];
        await query(script4, values4);
      }
      if (button_status == 4) {
        const CupConfigScript = getCupConfig();
        const sciConfigInfo = await query(CupConfigScript, ['SCI']);
        let iProdDesRes;
        let iCustDesRes;
        const currentTime = moment().format('YYYY-MM-DD HH:mm:ss.SSS');

        if (sciConfigInfo.length && sciConfigInfo[0]?.isactive) {
          const configJson = sciConfigInfo[0]?.config_json;
          const integrateType = configJson?.integrate;
          const iProdDisPayload =
            configJson[integrateType].payload.productiondispatch;
          const iCustDisPayload =
            configJson[integrateType].payload.customerdispatch;
          const stageInfo = configJson[integrateType].stages?.C_PM;

          if (integrateType === 'old_iTracks') {
            Object.assign(iProdDisPayload, {
              SubJob: [
                {
                  Quantity: 1,
                  SubJobId: isubjobid,
                },
              ],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });
            Object.assign(iCustDisPayload, {
              SubJob: [isubjobid],
              EmpCode: pm,
              StageId: stageInfo?.stageid,
              JobCardId: ijobcardid,
              Finishdate: currentTime,
            });

            iProdDesRes = await iTracksProdClose(iProdDisPayload);
            console.log(iProdDesRes, 'iProdDesRes');

            iCustDesRes = await iTracksCustClose(iCustDisPayload);
            console.log(iCustDesRes, 'iCustDesRes');
          }
        }
        if (
          !sciConfigInfo[0]?.isactive ||
          (iProdDesRes?.status && iCustDesRes?.status)
        ) {
          resolve('iTracks Stage closed');
        } else {
          reject({ error: 'iTracks Stage closing failed' });
        }
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updatemscleanupService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobid, button_status, ismscleanup } = Info;
      const status = await query(
        `select statusid from cupelements.mst_status where statuscode = 'MSC'`,
      );
      const currentDateObj = new Date();
      let dateCounter = 0;
      // Loop to find the date after skipping Saturdays and Sundays
      while (dateCounter < 2) {
        // Skip Saturday (day 6) and Sunday (day 0)
        if (currentDateObj.getDay() !== 5 && currentDateObj.getDay() !== 6) {
          dateCounter++;
        }
        currentDateObj.setDate(currentDateObj.getDate() + 1); // Increment the date
      }
      const script = updatemscleanup();
      const values = [
        jobid,
        status[0].statusid,
        ismscleanup,
        currentDateObj.toLocaleDateString('en-US'),
      ];
      const result = await query(script, values);
      console.log(result);
      const script2 = updatePMStatusWithMScleanup();
      const values2 = [jobid, button_status];
      const result2 = await query(script2, values2);
      resolve(result2);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateHistoryforUnclaimService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobId, updated_by, roleId, statusType, notes } = Info;
      const value = [
        jobId,
        roleId,
        statusType,
        updated_by,
        notes,
        getCurrentTimestamp(),
      ];
      const script = createHistory();
      await query(script, value);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const getteamjobdetailsService = async (jobid, team) => {
  return new Promise(async (resolve, reject) => {
    try {
      // const values = [jobid, team];
      const result = await query(await getteamjobdetails(jobid, team));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getEmailIntroPreviewService = async (jobid, pmid) => {
  try {
    const getMailIntroInfo = await getMailIntroInfoScript();
    const resMailIntroInfo = await query(getMailIntroInfo, [jobid]);
    const data = resMailIntroInfo[0]?.result;

    const script = await getEmailTemplateScript();
    const resForConfig = await query(script, [114, 'cup_pm_intro']);
    const content = await ejs.render(
      resForConfig[0].notificationconfig.template,
      { data },
    );
    const subject = ejs.render(resForConfig[0].notificationconfig.subject, {
      data,
    });
    const pmMailId = await getUserMail(pmid);
    return { content, subject, to: data?.to, from: pmMailId };
  } catch (error) {
    return false;
  }
};

export const sendEmailIntroService = async (notificationconfig, jobid) => {
  return new Promise(async (resolve, reject) => {
    try {
      await emitAction(notificationconfig);
      resolve(
        await updatepmstatusService({
          jobid,
          statuscode: 'IP',
          button_status: 2,
        }),
      );
    } catch (error) {
      reject(error);
    }
  });
};
export const getJobCompleteStatusService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getCompleteStatus(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getOpenQueriesService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { roleid, role, userid } = Info;
      const script = getOpenedQueries(roleid, role, userid);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRaisedQueriesService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const { roleid, role, userid } = Info;
      const script = getRaisedQueries(roleid, role, userid);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRejectedjobService = (role, userid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const roleDetails = await query(
        `select roleacronym from public.wms_role where roleid = ${role}`,
      );
      let result = [];
      if (roleDetails[0].roleacronym === 'C_PM') {
        result = await query(getRejectedjob(roleDetails[0].roleacronym), [
          userid,
        ]);
      } else {
        result = await query(getRejectedjob(roleDetails[0].roleacronym));
      }

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createRejectService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const status = await query(
        `select statusid from cupelements.mst_status where statuscode = 'R'`,
      );
      const { jobid, queryid, reason, created_by, roleid, attachment } = Info;
      let script = createReject();
      let values = [
        jobid,
        queryid,
        reason,
        created_by,
        attachment !== '' ? JSON.stringify(attachment) : null,
      ];
      const result = await query(script, values);
      const rejectid = result[0]?.rid;
      script = updateStatusJob();
      values = [jobid, created_by, status[0]?.statusid];
      await query(script, values);
      script = createHistory();
      values = [
        jobid,
        roleid,
        'rejected',
        created_by,
        rejectid,
        getCurrentTimestamp(),
      ];
      await query(script, values);
      script = updatePMJobStatus();
      values = [jobid, status[0]?.statusid];
      await query(script, values);
      script = updatePTJobStatus();
      values = [jobid, status[0]?.statusid];
      await query(script, values);
      script = updateMSJobStatus();
      values = [jobid, status[0]?.statusid];
      await query(script, values);
      script = updateCTJobStatus();
      values = [jobid, status[0]?.statusid];
      await query(script, values);
      resolve([{ rejectid }]);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPMDetailsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getPMDetails(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getQueryDetailsService = (queryid, roleid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script1 = getQueryDetails();
      const queryInfo = (await query(script1, [queryid, roleid]))[0];
      const script2 = getLatestRes();
      const latestRes = (await query(script2, [queryid]))[0] || null;
      const script3 = getQueryConvo();
      const queryConvo = (await query(script3, [queryid])) || null;
      resolve({ queryInfo, latestRes, queryConvo });
    } catch (error) {
      reject(error);
    }
  });
};
export const getPMEditService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(getPMEdit(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const responseQueryService = async Info => {
  try {
    await query('BEGIN');

    const {
      isClose,
      queryid,
      assignid,
      response,
      profile_id,
      assigned_to,
      assigned_from,
      attachment,
    } = Info;

    const script = updQueryResponse();
    const values = {
      response,
      attachment: attachment !== '' ? JSON.stringify(attachment) : null,
      profile_id,
      assignid,
      currentDatetime: getCurrentTimestamp(),
    };

    const res = await query(script, Object.values(values));

    let script1;
    let values1;
    if (isClose) {
      script1 = updQueryClose();
      values1 = [assignid, profile_id, queryid, getCurrentTimestamp()];
    } else {
      script1 = createAssignQuery();
      values1 = [
        queryid,
        assigned_to,
        null,
        null,
        assigned_from,
        profile_id,
        getCurrentTimestamp(),
      ];
    }
    const res1 = await query(script1, values1);

    return res && res1 && (await query('COMMIT'));
  } catch (error) {
    await query('ROLLBACK');
    throw error;
  }
};

export const getRejectedJobDetailsService = (jobid, queryid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getRejectedjobDetails();
      const result = await query(script, [jobid, queryid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const reSubmitJobService = Info => {
  return new Promise(async (resolve, reject) => {
    try {
      const status = await query(
        `select statusid from cupelements.mst_status where statuscode = 'YTS'`,
      );
      const {
        jobid,
        elmnttitle,
        title,
        acptdon,
        orcid,
        s1id,
        openaccess,
        wordcount,
        figurecount,
        imagecount,
        authordet,
        suplmntryfile,
        questionnaire,
        permission,
        figurefile,
        cntenhancement,
        source,
        note,
        mainfile,
        enhancement,
        dueon,
        uploadedtype,
        updated_by,
        roleid,
        seriesid,
        projectmanager,
        ijobcardid,
        isubjobid,
      } = Info;
      const CupConfigScript = getCupConfig();
      const sciConfigInfo = await query(CupConfigScript, ['SCI']);
      let iResetDesRes;

      if (sciConfigInfo.length && sciConfigInfo[0]?.isactive) {
        const configJson = sciConfigInfo[0]?.config_json;
        const integrateType = configJson?.integrate;
        const stageids = configJson[integrateType].stages?.stageids;

        if (integrateType === 'old_iTracks') {
          const iResetPayload = {
            jobcardid1: ijobcardid,
            SubJobId: isubjobid,
            stageId: stageids,
          };
          iResetDesRes = await iResetDes(iResetPayload);
          console.log(iResetDesRes, 'iResetDesRes');
        }
      }

      let script = reSubmitJob();
      let values = [
        jobid,
        elmnttitle,
        title,
        acptdon,
        orcid,
        s1id,
        openaccess,
        wordcount,
        figurecount,
        imagecount,
        authordet != '' ? JSON.stringify(authordet) : null,
        suplmntryfile != '' ? JSON.stringify(suplmntryfile) : null,
        questionnaire != '' ? JSON.stringify(questionnaire) : null,
        permission != '' ? JSON.stringify(permission) : null,
        figurefile != '' ? JSON.stringify(figurefile) : null,
        cntenhancement,
        source != '' ? JSON.stringify(source) : null,
        note,
        mainfile != '' ? JSON.stringify(mainfile) : null,
        enhancement != '' ? enhancement : null,
        dueon,
        uploadedtype,
        status[0].statusid,
        updated_by,
      ];
      await query(script, values);
      const currentDateObj = new Date();
      let dateCounter = 0;
      // Loop to find the date after skipping Saturdays and Sundays
      while (dateCounter < 2) {
        // Skip Saturday (day 6) and Sunday (day 0)
        if (currentDateObj.getDay() !== 5 && currentDateObj.getDay() !== 6) {
          dateCounter++;
        }
        currentDateObj.setDate(currentDateObj.getDate() + 1); // Increment the date
      }

      if (jobid) {
        values = [
          jobid,
          title,
          acptdon,
          status[0].statusid,
          updated_by,
          currentDateObj.toLocaleDateString('en-US'),
        ];
        script = getPMStatusMail();
        const checkMail = await query(script, [jobid]);
        const values1 = [
          jobid,
          title,
          acptdon,
          status[0].statusid,
          updated_by,
          currentDateObj.toLocaleDateString('en-US'),
          elmnttitle,
          orcid,
          s1id,
          openaccess,
          authordet != '' ? JSON.stringify(authordet) : null,
        ];
        if (checkMail[0]?.issentmail) {
          const code = await query(
            `select statusid from cupelements.mst_status where statuscode = 'IP'`,
          );
          const param = [
            jobid,
            title,
            acptdon,
            code[0].statusid,
            updated_by,
            elmnttitle,
            orcid,
            s1id,
            openaccess,
            authordet != '' ? JSON.stringify(authordet) : null,
          ];
          script = pmwithoutDueonUpdate();
          await query(script, param);
        } else {
          script = pmUpdate();
          await query(script, values1);
        }

        values = [jobid, title, acptdon, status[0].statusid, updated_by, dueon];
        const values2 = [
          jobid,
          title,
          acptdon,
          status[0].statusid,
          updated_by,
          dueon,
        ];
        script = ptUpdate();
        await query(script, values2);
        script = msUpdate();
        await query(script, values);
        script = ctUpdate();
        await query(script, values);
        script = createHistory();
        values = [
          jobid,
          roleid,
          're-submitted',
          updated_by,
          null,
          getCurrentTimestamp(),
        ];
        await query(script, values);
        script = updateRejectJobStatus();
        await query(script, [jobid]);

        const seriesInfo = await getSeriesInfo(seriesid);
        const pmtlsMailId = await getRoleBasedMail('C_PMTL');
        const pmMailId = await getUserMail(projectmanager);
        const prMailId = await getUserMail(updated_by);
        const mailPayload = {
          series: seriesInfo[0].series,
          title,
          ishypercare: seriesInfo[0].ishypercare ? 'Yes' : 'No',
          pmMailId,
          pmtlsMailId,
          prMailId,
        };
        await sendMail_By_PR(mailPayload, 'cup_pr_job_resubmitted');
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

const createiTracksJob = jobinfo => {
  return new Promise(async (resolve, reject) => {
    if (jobinfo?.type === 'B') {
      try {
        const { iPayload } = jobinfo;
        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.book.iendpointKey,
          iendpointname: config.iTracks.uri.book.createJob,
        };
        const result = await service.iPost(url, iPayload, headers);
        const { status, Result } = result.data;
        if (status) {
          resolve({ status, jobCardId: Result });
        } else {
          reject({ status, message: Result });
        }
      } catch (e) {
        reject({ status: false, message: e.message ? e.message : e });
      }
    } else {
      reject({ status: false, message: 'Job Type Missing.' });
    }
  });
};

const createiTracksStage = stageinfo => {
  return new Promise(async (resolve, reject) => {
    if (stageinfo?.type === 'B') {
      try {
        const { iPayload } = stageinfo;
        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.book.iendpointKey,
          iendpointname: config.iTracks.uri.book.addSubJob,
        };
        const result = await service.iPost(url, iPayload, headers);
        const { status, Result } = result.data;
        if (status) {
          resolve({ status, subJobID: Result[0]?.subJobID });
        } else {
          reject({ status, message: Result[0]?.Error });
        }
      } catch (e) {
        reject({ status: false, message: e.message ? e.message : e });
      }
    } else {
      reject({ status: false, message: 'Job Type Missing.' });
    }
  });
};

const iTracksProdClose = iPayload => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.book.iendpointKey,
        iendpointname: config.iTracks.uri.book.productionDispatch,
      };
      const result = await service.iPost(url, iPayload, headers);
      const { status, Result } = result.data;
      if (status) {
        resolve({ status, Result });
      } else {
        reject({ status, message: Result });
      }
    } catch (e) {
      reject({ status: false, message: e.message ? e.message : e });
    }
  });
};

const iTracksCustClose = iPayload => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.book.iendpointKey,
        iendpointname: config.iTracks.uri.book.customerDispatch,
      };
      const result = await service.iPost(url, iPayload, headers);
      const { status, Result } = result.data;
      if (status) {
        resolve({ status, Result });
      } else {
        reject({ status, message: Result[0]?.Error });
      }
    } catch (e) {
      reject({ status: false, message: e.message ? e.message : e });
    }
  });
};

const iResetDes = iPayload => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.book.iendpointKey,
        iendpointname: config.iTracks.uri.book.iResetDes,
      };
      const result = await service.iPost(url, iPayload, headers);
      const { status, Result } = result.data;
      if (status) {
        resolve({ status, Result });
      } else {
        reject({ status, message: Result });
      }
    } catch (e) {
      reject({ status: false, message: e.message ? e.message : e });
    }
  });
};
export const getopenqueryService = async (jobid, user) => {
  return new Promise(async (resolve, reject) => {
    try {
      // const values = [jobid, team];
      const result = await query(await getopenquerydetails(jobid, user));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
