import { readFileSync } from 'fs';
import express from 'express';
import swaggerUi from 'swagger-ui-express';
import {
  getMasterController,
  createNewJobController,
  getQueriesListController,
  unclaimedjobController,
  claimedjobController,
  getstatusController,
  getfileUploadPathController,
  addJobFilePathController,
  getCheckSeriesExistController,
  getJobDetailsController,
  getNotesController,
  insNotesController,
  getRoleAcronymController,
  getExportListController,
  getRoleJobStatusController,
  updateRoleJobStatusController,
  savemseditController,
  getMSEditController,
  savepteditController,
  getPTEditController,
  savecteditController,
  getCTEditController,
  getFolderNameController,
  createSeriesMasterController,
  updateSeriesMasterController,
  checkseriesexistsController,
  checkseriescodeexistsController,
  savepmeditController,
  getSeriesMasterDetailsController,
  getSeriesDataController,
  getPMOpenJobsController,
  reassignPMSeriesController,
  removeSeriesController,
  getJobHistoryController,
  getFilePathController,
  updateFileInDBController,
  unclaimjobController,
  createQueryController,
  queryFileUploadDetailsController,
  getQueryJobBasedController,
  updatepmstatusController,
  updatemscleanupController,
  updatehistoryforunclaimController,
  getteamjobdetailsController,
  getEmailIntroPreviewController,
  sendEmailIntroController,
  getOpenedQueriesController,
  getRaisedQueriesController,
  getRejectedjobController,
  getJobCompleteStatusController,
  handlePdfDownload,
  getPMDetailsController,
  getPMEditController,
  getQueryDetailsController,
  responseQueryController,
  createRejectController,
  getRejectedJobDetailsController,
  reSubmitJobController,
  getopenqueryController,
} from '../controller/index.js';
import { validateRequestParams } from '../helpers/middleware.js';
import { getMasterSchema } from '../helpers/validation.js';

const cupElementRouter = express.Router();

const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}

// CRUD MASTERS
swaggerDocs(cupElementRouter);

cupElementRouter.get(
  '/getMaster/:tblname',
  validateRequestParams(getMasterSchema),
  handler(getMasterController),
);

cupElementRouter.post('/createnewjob', handler(createNewJobController));
cupElementRouter.post('/getquerieslist', handler(getQueriesListController));
cupElementRouter.get(
  '/getunclaimedjob/:role/:userid',
  handler(unclaimedjobController),
);
cupElementRouter.get(
  '/getclaimedjob/:role/:userid',
  handler(claimedjobController),
);
cupElementRouter.get('/getstatus', handler(getstatusController));
cupElementRouter.get(
  '/getfileuploadpath',
  handler(getfileUploadPathController),
);
cupElementRouter.post('/addjobfilepath', handler(addJobFilePathController));
cupElementRouter.get('/getcheckseries', handler(getCheckSeriesExistController));
cupElementRouter.get('/getJobDetails/:jobid', handler(getJobDetailsController));
cupElementRouter.post('/getNotes', handler(getNotesController));
cupElementRouter.post('/insNotes', handler(insNotesController));
cupElementRouter.get(
  '/getroleacronym/:roleid',
  handler(getRoleAcronymController),
);
cupElementRouter.post('/getexportlist', handler(getExportListController));
cupElementRouter.get(
  '/getrolejobstatus/:role/:jobid',
  handler(getRoleJobStatusController),
);
cupElementRouter.post(
  '/updatejobstatus',
  handler(updateRoleJobStatusController),
);
cupElementRouter.post('/updatemsedit', handler(savemseditController));
cupElementRouter.get('/getmsedit/:jobid', handler(getMSEditController));
cupElementRouter.post('/updateptedit', handler(savepteditController));
cupElementRouter.get('/getptedit/:jobid', handler(getPTEditController));
cupElementRouter.post('/updatectedit', handler(savecteditController));
cupElementRouter.get('/getctedit/:jobid', handler(getCTEditController));
cupElementRouter.get('/getfoldername', handler(getFolderNameController));
cupElementRouter.post(
  '/createSeriesMaster',
  handler(createSeriesMasterController),
);
cupElementRouter.post(
  '/updateSeriesMaster',
  handler(updateSeriesMasterController),
);
cupElementRouter.get(
  '/checkseriesexist/:series',
  handler(checkseriesexistsController),
);
cupElementRouter.get(
  '/checkseriescodeexist/:seriescode',
  handler(checkseriescodeexistsController),
);
cupElementRouter.post('/updatepmedit', handler(savepmeditController));
cupElementRouter.get(
  '/getJobHistory/:roleacronym/:jobid',
  handler(getJobHistoryController),
);
cupElementRouter.post('/getFilePath', handler(getFilePathController));
cupElementRouter.post('/updateFileInDB', handler(updateFileInDBController));
cupElementRouter.post('/unclaimjob', handler(unclaimjobController));

cupElementRouter.post(
  '/getseriesmasterdetails',
  handler(getSeriesMasterDetailsController),
);
cupElementRouter.get(
  '/getseriesdatadetails/:seriesid',
  handler(getSeriesDataController),
);
cupElementRouter.get(
  '/getPMOpenJobs/:seriesid',
  handler(getPMOpenJobsController),
);
cupElementRouter.post('/reassignPMSeries', handler(reassignPMSeriesController));
cupElementRouter.post(
  '/removeSeries/:seriesid/:userid',
  handler(removeSeriesController),
);
cupElementRouter.post('/raiseQuery', handler(createQueryController));
cupElementRouter.post(
  '/queryfileuploaddetails',
  handler(queryFileUploadDetailsController),
);
cupElementRouter.get(
  '/getquerybasedjob/:jobid',
  handler(getQueryJobBasedController),
);
cupElementRouter.post('/updatepmstatus', handler(updatepmstatusController));
cupElementRouter.post('/updatemscleanup', handler(updatemscleanupController));
cupElementRouter.post(
  '/updatehistoryforunclaim',
  handler(updatehistoryforunclaimController),
);
cupElementRouter.get(
  '/getteamjobdetails/:jobid/:team',
  handler(getteamjobdetailsController),
);
cupElementRouter.get(
  '/getEmailIntroPreview/:jobid/:pmid',
  handler(getEmailIntroPreviewController),
);
cupElementRouter.post('/sendEmailIntro', handler(sendEmailIntroController));
cupElementRouter.post('/getopenedqueries', handler(getOpenedQueriesController));
cupElementRouter.post('/getraisedquery', handler(getRaisedQueriesController));
cupElementRouter.get(
  '/getrejectedjob/:role/:userid',
  handler(getRejectedjobController),
);
cupElementRouter.get(
  '/getjobcompletestatus/:jobid',
  handler(getJobCompleteStatusController),
);
cupElementRouter.post('/handlePdfDownload', handler(handlePdfDownload));
cupElementRouter.get('/getPMDetails/:jobid', handler(getPMDetailsController));
cupElementRouter.get('/getpmedit/:jobid', handler(getPMEditController));
cupElementRouter.get(
  '/getQueryDetails/:queryid/:roleid',
  handler(getQueryDetailsController),
);
cupElementRouter.post('/responseQuery', handler(responseQueryController));
cupElementRouter.post('/createReject', handler(createRejectController));
cupElementRouter.get(
  '/getrejectjobdetails/:jobid/:queryid',
  handler(getRejectedJobDetailsController),
);
cupElementRouter.post('/reSubmitJob', handler(reSubmitJobController));
cupElementRouter.get(
  '/getopenquery/:jobid/:user',
  handler(getopenqueryController),
);

export default cupElementRouter;
