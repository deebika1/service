export const getQueriesListScript = () => {
  const script = ``;
  return script;
};

export const createQuery = () => {
  return `INSERT INTO cupelements.trn_queries (jobid,query,attachement,is_closed,created_by,created_time)
  VALUES ($1,$2,$3,$4,$5,$6) RETURNING queryid`;
};

export const createAssignQuery = () => {
  return `INSERT INTO cupelements.trn_queries_assign (queryid,assigned_to,response,attachment,assigned_from,created_by,created_time)
  VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING assignid`;
};

export const queryfileUploadDetails = () => {
  return `UPDATE cupelements.trn_queries SET attachement=$1,updated_by=$2,updated_time=$4
    where queryid = $3`;
};

export const getQuerybasedJobId = () => {
  return `select
  ROW_NUMBER() OVER (
  ORDER BY CASE
  WHEN q.updated_time IS NULL THEN q.created_time
  ELSE q.updated_time
  END DESC
  ) AS serial,
  q.queryid,
  UPPER(CONCAT('ID',q.queryid)) AS querycode,
  j.seriesid,
  s.seriescode,
  s.series,
  j.title,
  qa.created_by,
  qa.assigned_to,
  qa.assignid,
  TO_CHAR(q.created_time,'DD-Mon-YYYY') AS raised_on,
  UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS raisedby,
  CASE WHEN q.is_closed = false THEN 'OPEN' ELSE 'CLOSE' END AS status,
  CASE WHEN q.is_closed = false THEN 'cup_queryopen' ELSE 'cup_queryclose' END AS statusclass,
  'action' AS action
  from cupelements.trn_queries q
  left join cupelements.trn_job_element j ON j.jobid = q.jobid
  left join cupelements.mst_series s ON s.seriesid = j.seriesid
  left join public.wms_user u ON u.userid = q.created_by
  left join cupelements.trn_queries_assign qa ON qa.assignid = ( select max(assignid) from cupelements.trn_queries_assign where queryid = q.queryid)
  where q.jobid = $1 and j.isactive=true
  group by  q.queryid,querycode,j.seriesid,
  s.seriescode,
  s.series,
  j.title,
  raised_on,raisedby,status,action,
  qa.created_by,
  qa.assigned_to,qa.assignid
`;
};

export const getRaisedQueries = (roleid, role, userid) => {
  let query = '';
  if (role == 'C_PM') {
    query = `SELECT 
    ROW_NUMBER() OVER (
      ORDER BY CASE
      WHEN q.updated_time IS NULL THEN q.created_time
      ELSE q.updated_time
      END DESC
    ) AS serial,
    j.jobid,
    j.seriesid,
    max(qa.assignid) as assignid,
    ser.seriescode,
    ser.series,
    j.title,
    q.queryid,
    UPPER(CONCAT('ID', q.queryid)) AS querycode,
    q.query,
    UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS raisedby,
    CASE WHEN q.is_closed = false THEN 'OPEN' ELSE 'CLOSE' END AS status,
    CASE WHEN q.is_closed = false THEN 'cup_queryopen' ELSE 'cup_queryclose' END AS statusclass,
    TO_CHAR(q.created_time,'DD-Mon-YYYY') AS raised_on,
    'action' AS action
FROM 
    cupelements.trn_queries q
LEFT JOIN 
    cupelements.trn_job_element j ON j.jobid = q.jobid
LEFT JOIN 
    cupelements.mst_series ser ON ser.seriesid = j.seriesid
LEFT JOIN 
    cupelements.mst_status s ON s.statusid = j.statusid
LEFT JOIN 
    cupelements.trn_queries_assign qa ON qa.queryid = q.queryid
LEFT JOIN
    public.wms_user u ON u.userid = q.created_by
WHERE 
    j.isactive = true 
    AND s.statuscode != 'CL'
    AND qa.assigned_from = ${roleid}
    AND ser.projectmanager = '${userid}'
	AND q.created_by= '${userid}'
    AND NOT EXISTS (
        SELECT 1 
        FROM cupelements.trn_rejected_job rj 
        WHERE rj.jobid = j.jobid AND rj.isactive = true
    )
GROUP BY 
    j.jobid,
    j.seriesid,
    j.title,
    ser.seriescode,
    q.queryid,
    ser.series,
    q.query,
    raisedby,
    status,
    raised_on,
    querycode;`;
  } else if (role == 'C_PR') {
    query = `
    SELECT 
    ROW_NUMBER() OVER (
      ORDER BY CASE
      WHEN q.updated_time IS NULL THEN q.created_time
      ELSE q.updated_time
      END DESC
      ) AS serial,
      j.jobid,
      j.seriesid,
      max(qa.assignid) as assignid,
      ser.seriescode,
      ser.series,
      j.title,
      q.queryid,
      UPPER(CONCAT('ID',q.queryid)) AS querycode,
      q.query,
      UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS raisedby,
      CASE WHEN q.is_closed = false THEN 'OPEN' ELSE 'CLOSE' END AS status,
      CASE WHEN q.is_closed = false THEN 'cup_queryopen' ELSE 'cup_queryclose' END AS statusclass,
      TO_CHAR(q.created_time,'DD-Mon-YYYY') AS raised_on,
      'action' AS action
  FROM 
      cupelements.trn_queries q
  LEFT JOIN 
      cupelements.trn_job_element j ON j.jobid = q.jobid
  LEFT JOIN 
      cupelements.mst_series ser ON ser.seriesid = j.seriesid
  LEFT JOIN 
      cupelements.mst_status s ON s.statusid = j.statusid
  LEFT JOIN 
      cupelements.trn_queries_assign qa ON qa.queryid = q.queryid
  LEFT JOIN
      public.wms_user u ON u.userid = q.created_by
  WHERE 
      j.isactive = true AND 
      s.statuscode != 'CL'
      AND 
      qa.assigned_from = ${roleid}
      AND j.created_by = '${userid}'
      AND NOT EXISTS (
        SELECT 1 
        FROM cupelements.trn_rejected_job rj 
        WHERE rj.jobid = j.jobid AND rj.isactive = true
    )
      group by 
      j.jobid,
      j.seriesid,
      j.title,
      ser.seriescode,
      q.queryid,
      ser.series,
      q.query,raisedby,status,raised_on,querycode;`;
  } else {
    query = `SELECT 
    ROW_NUMBER() OVER (
      ORDER BY CASE
      WHEN q.updated_time IS NULL THEN q.created_time
      ELSE q.updated_time
      END DESC
      ) AS serial,
      j.jobid,
      j.seriesid,
      max(qa.assignid) as assignid,
      ser.seriescode,
      ser.series,
      j.title,
      q.queryid,
      UPPER(CONCAT('ID',q.queryid)) AS querycode,
      q.query,
      UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS raisedby,
      CASE WHEN q.is_closed = false THEN 'OPEN' ELSE 'CLOSE' END AS status,
      CASE WHEN q.is_closed = false THEN 'cup_queryopen' ELSE 'cup_queryclose' END AS statusclass,
      TO_CHAR(q.created_time,'DD-Mon-YYYY') AS raised_on,
      'action' AS action
  FROM 
      cupelements.trn_queries q
  LEFT JOIN 
      cupelements.trn_job_element j ON j.jobid = q.jobid
  LEFT JOIN 
      cupelements.mst_series ser ON ser.seriesid = j.seriesid
  LEFT JOIN 
      cupelements.mst_status s ON s.statusid = j.statusid
  LEFT JOIN 
      cupelements.trn_queries_assign qa ON qa.queryid = q.queryid
  LEFT JOIN
      public.wms_user u ON u.userid = q.created_by
  WHERE 
      j.isactive = true AND 
      s.statuscode != 'CL'
      AND 
      qa.assigned_from = ${roleid}
      AND q.created_by = '${userid}'
      AND NOT EXISTS (
        SELECT 1 
        FROM cupelements.trn_rejected_job rj 
        WHERE rj.jobid = j.jobid AND rj.isactive = true
    )
      group by 
      j.jobid,
      j.seriesid,
      j.title,
      ser.seriescode,
      q.queryid,
      ser.series,
      q.query,raisedby,status,raised_on,querycode;`;
  }
  return query;
};

export const getOpenedQueries = (roleid, role, userid) => {
  let query = '';
  if (role == 'C_PM') {
    query = `SELECT 
    ROW_NUMBER() OVER (
    ORDER BY CASE
    WHEN q.updated_time IS NULL THEN q.created_time
    ELSE q.updated_time
    END DESC
    ) AS serial,
    j.jobid,
    j.seriesid,
    ser.series,
    max(qa.assignid) as assignid,
    ser.seriescode,
    j.title,
    q.queryid,
    UPPER(CONCAT('ID',q.queryid)) AS querycode,
    q.query,
    UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS raisedby,
    CASE WHEN q.is_closed = false THEN 'OPEN' ELSE 'CLOSE' END AS status,
    CASE WHEN q.is_closed = false THEN 'cup_queryopen' ELSE 'cup_queryclose' END AS statusclass,
    TO_CHAR(q.created_time,'DD-Mon-YYYY') AS raised_on,
    'action' AS action
FROM 
    cupelements.trn_queries q
LEFT JOIN 
    cupelements.trn_job_element j ON j.jobid = q.jobid
LEFT JOIN 
    cupelements.mst_series ser ON ser.seriesid = j.seriesid
LEFT JOIN 
    cupelements.mst_status s ON s.statusid = j.statusid
LEFT JOIN 
    cupelements.trn_queries_assign qa ON qa.queryid = q.queryid
LEFT JOIN
    public.wms_user u ON u.userid = q.created_by
WHERE 
    j.isactive = true AND 
    s.statuscode != 'CL'
    AND 
    qa.assigned_to = ${roleid}
    AND ser.projectmanager = '${userid}'
    AND NOT EXISTS (
    SELECT 1 
    FROM cupelements.trn_rejected_job rj 
    WHERE rj.jobid = j.jobid AND rj.isactive = true
)
    group by 
    j.jobid,
    j.seriesid,
    j.title,
    ser.seriescode,
    q.queryid,
    ser.series,
    q.query,raisedby,status,raised_on,querycode;`;
  } else if (role == 'C_PR') {
    query = `SELECT 
        ROW_NUMBER() OVER (
        ORDER BY CASE
        WHEN q.updated_time IS NULL THEN q.created_time
        ELSE q.updated_time
        END DESC
        ) AS serial,
        j.jobid,
        j.seriesid,
        ser.series,
        max(qa.assignid) as assignid,
        ser.seriescode,
        j.title,
        q.queryid,
        UPPER(CONCAT('ID',q.queryid)) AS querycode,
        q.query,
        UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS raisedby,
        CASE WHEN q.is_closed = false THEN 'OPEN' ELSE 'CLOSE' END AS status,
        CASE WHEN q.is_closed = false THEN 'cup_queryopen' ELSE 'cup_queryclose' END AS statusclass,
        TO_CHAR(q.created_time,'DD-Mon-YYYY') AS raised_on,
        'action' AS action
    FROM 
        cupelements.trn_queries q
    LEFT JOIN 
        cupelements.trn_job_element j ON j.jobid = q.jobid
    LEFT JOIN 
        cupelements.mst_series ser ON ser.seriesid = j.seriesid
    LEFT JOIN 
        cupelements.mst_status s ON s.statusid = j.statusid
    LEFT JOIN 
        cupelements.trn_queries_assign qa ON qa.queryid = q.queryid
    LEFT JOIN
        public.wms_user u ON u.userid = q.created_by
    WHERE 
        j.isactive = true AND 
        s.statuscode != 'CL'
        AND 
        qa.assigned_to = ${roleid}
        --AND j.created_by = '${userid}'
        AND NOT EXISTS (
            SELECT 1 
            FROM cupelements.trn_rejected_job rj 
            WHERE rj.jobid = j.jobid AND rj.isactive = true
        )
        group by 
        j.jobid,
        j.seriesid,
        j.title,
        ser.seriescode,
        q.queryid,
        ser.series,
        q.query,raisedby,status,raised_on,querycode;`;
  } else {
    query = `SELECT 
        ROW_NUMBER() OVER (
        ORDER BY CASE
        WHEN q.updated_time IS NULL THEN q.created_time
        ELSE q.updated_time
        END DESC
        ) AS serial,
        j.jobid,
        j.seriesid,
        ser.series,
        max(qa.assignid) as assignid,
        ser.seriescode,
        j.title,
        q.queryid,
        UPPER(CONCAT('ID',q.queryid)) AS querycode,
        q.query,
        UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS raisedby,
        CASE WHEN q.is_closed = false THEN 'OPEN' ELSE 'CLOSE' END AS status,
        CASE WHEN q.is_closed = false THEN 'cup_queryopen' ELSE 'cup_queryclose' END AS statusclass,
        TO_CHAR(q.created_time,'DD-Mon-YYYY') AS raised_on,
        'action' AS action
    FROM 
        cupelements.trn_queries q
    LEFT JOIN 
        cupelements.trn_job_element j ON j.jobid = q.jobid
    LEFT JOIN 
        cupelements.mst_series ser ON ser.seriesid = j.seriesid
    LEFT JOIN 
        cupelements.mst_status s ON s.statusid = j.statusid
    LEFT JOIN 
        cupelements.trn_queries_assign qa ON qa.queryid = q.queryid
    LEFT JOIN
        public.wms_user u ON u.userid = q.created_by
    WHERE 
        j.isactive = true AND 
        s.statuscode != 'CL'
        AND 
        qa.assigned_to = ${roleid}
        AND NOT EXISTS (
            SELECT 1 
            FROM cupelements.trn_rejected_job rj 
            WHERE rj.jobid = j.jobid AND rj.isactive = true
        )
        group by 
        j.jobid,
        j.seriesid,
        j.title,
        ser.seriescode,
        q.queryid,
        ser.series,
        q.query,raisedby,status,raised_on,querycode;`;
  }
  return query;
};

export const createReject = () => {
  return `INSERT INTO cupelements.trn_rejected_job (jobid,queryid,reason,created_by,attachement,isactive)
    VALUES ($1,$2,$3,$4,$5,true) RETURNING rid`;
};

export const getQueryDetails = () => {
  return `SELECT
            q.queryid,
            tqa.assignid,
            CONCAT(s.series, ' (', s.seriescode, ')') AS series,
            j.title,
            q.query,
            q.attachement,
            q.created_time AS raisedon,
            UPPER(CONCAT(u.username, ' (', SUBSTRING(wr.roleacronym, 3), ') - ', u.userid)) AS raisedby,
            wr.roleid AS "raisedrole",
            CASE
                WHEN tqa.assigned_to = $2 THEN TRUE
                ELSE FALSE
            END AS ismyreponsibility,
            CASE
                WHEN q.is_closed = FALSE THEN 'open'
                ELSE 'close'
            END AS status,
            CASE
                WHEN wr.roleacronym IN ('C_PMTL', 'C_PM') THEN TRUE
                ELSE FALSE
            END AS ispmraised,
            (select assignid from cupelements.trn_queries_assign where queryid = q.queryid order by assignid desc limit 1) AS assignid
        FROM
        cupelements.trn_queries q
        LEFT JOIN cupelements.trn_queries_assign tqa ON
        tqa.queryid = q.queryid and tqa.response is null
        JOIN cupelements.trn_job_element j ON
        j.jobid = q.jobid
        JOIN cupelements.mst_series s ON
        s.seriesid = j.seriesid
        JOIN public.wms_user u ON
        u.userid = q.created_by
        JOIN public.wms_userrole wu ON
        wu.userid = q.created_by
        JOIN public.wms_role wr ON
        wr.roleid = wu.roleid
        WHERE
        wr.roleacronym IN ('C_PMTL', 'C_CT', 'C_MS', 'C_PT', 'C_PM', 'C_PR')
        AND q.queryid = $1
        AND j.isactive = TRUE;`;
};

export const getQueryConvo = () => {
  return `SELECT
            tqa.assignid,
            tqa.response,
            tqa.attachment,
            tqa.updated_time AS responsedon,
            UPPER(CONCAT(u.username, ' (', SUBSTRING(wr.roleacronym, 3), ') - ', u.userid)) AS responsedby
        FROM
            cupelements.trn_queries_assign tqa
        JOIN
            public.wms_user u ON u.userid = tqa.updated_by
        JOIN
            public.wms_userrole wu ON wu.userid = tqa.updated_by
        JOIN
            public.wms_role wr ON wr.roleid = wu.roleid
        WHERE
            wr.roleacronym IN ('C_PMTL', 'C_CT', 'C_MS', 'C_PT', 'C_PM', 'C_PR')
            AND tqa.queryid = $1
            AND tqa.response is not null
            AND assignid NOT IN (
                SELECT
                    assignid
                FROM
                    cupelements.trn_queries_assign
                WHERE
                    queryid = $1
                    AND response is not null
                ORDER BY
                    assignid DESC
                LIMIT 1
            )
        ORDER BY
            tqa.assignid ASC;`;
};

export const getLatestRes = () => {
  return `SELECT
            tqa.assignid,
            tqa.response,
            tqa.attachment,
            tqa.updated_time AS responsedon,
            UPPER(CONCAT(u.username, ' (', SUBSTRING(wr.roleacronym, 3), ') - ', u.userid)) AS responsedby
        FROM
        cupelements.trn_queries_assign tqa
        JOIN
        public.wms_user u ON
        u.userid = tqa.updated_by
        JOIN
        public.wms_userrole wu ON
        wu.userid = tqa.updated_by
        JOIN
        public.wms_role wr ON
        wr.roleid = wu.roleid
        WHERE
        wr.roleacronym IN ('C_PMTL', 'C_CT', 'C_MS', 'C_PT', 'C_PM', 'C_PR')
        AND tqa.queryid = $1
        AND response IS NOT NULL
        ORDER BY
        tqa.assignid DESC
        LIMIT 1;`;
};

export const updQueryResponse = () => {
  return `UPDATE cupelements.trn_queries_assign SET response=$1, attachment=$2, updated_by=$3, updated_time=$5 WHERE assignid=$4;`;
};

export const updQueryClose = () => {
  return `UPDATE cupelements.trn_queries SET closed_assignid=$1, is_closed=true, updated_by=$2, updated_time=$4 WHERE queryid=$3;`;
};

export const updateStatusJob = () => {
  return `UPDATE cupelements.trn_job_element SET updated_by=$2, updated_time=CURRENT_TIMESTAMP,statusid=$3 WHERE jobid=$1;`;
};
