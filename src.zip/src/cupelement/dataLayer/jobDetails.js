export const createNewJob = () => {
  return `
        INSERT INTO cupelements.trn_job_element(seriesid,elmnttitle,title,acptdon,mvdtoprod,orcid,s1id,openaccess,wordcount,figurecount,imagecount,
        authordet,suplmntryfile,questionnaire,permission,figurefile,cntenhancement,source,note,isactive,created_by,created_time,mainfile,projectmanager,
        enhancement, dueon,uploadedtype,seriesjson,statusid, ijobcardid, source_filevalue)
        VALUES ($1,$2,$3,$4,CURRENT_TIMESTAMP,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,true,$19,CURRENT_TIMESTAMP,$20,$21,$22,
        $23,$24,$25,$26,$27, $28) RETURNING jobid;
    `;
};

export const fileUploadPath = () => {
  return `
  select * from cupelements.cup_file_config where id=1 and isactive= true;
  `;
};

export const UpdateJobFilePath = () => {
  return `
  UPDATE cupelements.trn_job_element
  SET mainfile =$2 , suplmntryfile = $3,questionnaire = $4,permission = $5,figurefile = $6,source = $7
  WHERE jobid=$1;
  `;
};

export const addJobFilePath = () => {
  return `
 
  `;
};

export const getCheckSeriesExistScript = () => {
  return `SELECT EXISTS (SELECT seriesid FROM cupelements.mst_series WHERE isactive = true);
  `;
};

export const getJobDetails = jobid => {
  return `
    select je.*,
    pm.statusid AS pmstatusid,
    je.wordcount AS jewordcount,
  	je.imagecount AS jeimagecount,
    TO_CHAR(je.acptdon, 'YYYY-MM-DD') AS acceptedon,
    TO_CHAR(je.mvdtoprod, 'YYYY-MM-DD') AS movedtoprod,
    je.orcid AS joborcid,
    je.s1id AS jobs1id,
    pm.*, pt.*, ms.*, ct.*, ser.series from cupelements.trn_job_element je 
    left join cupelements.trn_pm_team pm ON pm.jobid = je.jobid
    left join cupelements.trn_production_team pt ON pt.jobid = je.jobid
    left join cupelements.trn_ms_team ms ON ms.jobid = je.jobid
    left join cupelements.trn_contentteam ct ON ct.jobid = je.jobid
    inner join cupelements.mst_series ser ON ser.seriesid = je.seriesid
    where je.jobid =${jobid};
  `;
};

export const getNotesScript = () => {
  return `SELECT notesid, notes, wu.username  as addedby, substring(wr.roleacronym, 3) as roleacronym, n.created_time as addedon FROM cupelements.trn_notes n
          join public.wms_user wu on wu.userid = n.created_by
          join public.wms_userrole wrr on wrr.userid = wu.userid
          join public.wms_role wr on wr.roleid = wrr.roleid
          WHERE wr.roleacronym in ('C_PMTL','C_CT','C_MS','C_PT','C_PM','C_PR')  and n.isactive = true and jobid = $1
          order by n.created_time asc`;
};

export const insNotesScript = () => {
  return `INSERT INTO cupelements.trn_notes
          (jobid, notes, created_by, created_time)
          VALUES($1, $2, $3, $4);`;
};

export const createProductionTeam = () => {
  return `
  INSERT INTO cupelements.trn_production_team(jobid,seriesid,title,acptdon,mvdtoprod,statusid,isactive,created_by,created_time,dueon,isubjobid)
  VALUES ($1,$2,$3,$4,CURRENT_TIMESTAMP,$5,true,$6,CURRENT_TIMESTAMP,$7,$8)
    `;
};

export const createMSTeam = () => {
  return `
  INSERT INTO cupelements.trn_ms_team(jobid,seriesid,title,acptdon,mvdtoprod,statusid,isactive,created_by,created_time,dueon,isubjobid)
  VALUES ($1,$2,$3,$4,CURRENT_TIMESTAMP,$5,true,$6,CURRENT_TIMESTAMP,$7,$8)
    `;
};

export const createContentTeam = () => {
  return `
  INSERT INTO cupelements.trn_contentteam(jobid,seriesid,title,acptdon,mvdtoprod,statusid,isactive,created_by,created_time,dueon,isubjobid)
  VALUES ($1,$2,$3,$4,CURRENT_TIMESTAMP,$5,true,$6,CURRENT_TIMESTAMP,$7,$8)
    `;
};

export const createPMTeam = () => {
  return `
  INSERT INTO cupelements.trn_pm_team(jobid,seriesid,title,acptdon,mvdtoprod,statusid,isactive,created_by,created_time,dueon,isubjobid,element_title, orcid, s1id, hypercare,author_contact_details)
  VALUES ($1,$2,$3,$4,CURRENT_TIMESTAMP,$5,true,$6,CURRENT_TIMESTAMP,$7,$8,$9,$10,$11,$12,$13)
    `;
};

export const getExportListScript = () => {
  return `select
            q.column_name,
            q.column_id,
            q.attachenv,
            q.file_path
          from
            (
            select
              ma.attachtypedesc as column_name,
              ma.foldername as column_id,
              ta.attachenv,
              case
                when ta.attachenv = 'local' then con.localpath
                else con.cloudpath
              end as file_path
            from
              cupelements.trn_job_attachment ta
            join cupelements.mst_attachmenttype ma on
              ma.attachtypeid = ta.attachtypeid
            join cupelements.cup_file_config con on
              con.upload_type = con.upload_type
            where
              ta.jobid = $1
          union all
            select
              'All ZIP' as column_name,
              'all' as column_id,
              upload_type as attachenv,
              case
                when upload_type = 'local' then localpath
                else cloudpath
              end as file_path
            from
              cupelements.cup_file_config
              ) as q
          group by
            q.column_name,
            q.column_id,
            q.attachenv,
            q.file_path;
          `;
};

export const updateMSedit = () => {
  return `
  UPDATE cupelements.trn_ms_team SET level_english = $2, copy_editor = $3,t_subject_code = $4,t_place_qualifier = $5,t_language_qualifier = $6,t_time_qualifier = $7,t_education_qualifier = $8,t_interest_group_qualifier = $9,t_style_qualifier = $10,printing = $11,file = $12, statusid = $13, updated_by = $14, updated_time = CURRENT_TIMESTAMP, completed_date = $15 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const getMSEdit = jobid => {
  return `
  select * from cupelements.trn_ms_team ms left join cupelements.trn_job_attachment ja on ja.jobid = ms.jobid 
and ja.attachtypeid = 8 and ja.isactive = true where ms.jobid =${jobid} and ms.isactive = true;
  `;
};

export const updatePTedit = () => {
  return `
  UPDATE cupelements.trn_production_team SET wordcount = $2, number_of_images = $3, toc = $4, line_art = $5, maps = $6,halftones = $7, tables = $8, music_examples = $9, all_to_be_text =$10, file = $11, statusid = $12, updated_by = $13, updated_time = CURRENT_TIMESTAMP, completed_date = $14 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const getPTEdit = jobid => {
  return `
  select * from cupelements.trn_production_team pt left join cupelements.trn_job_attachment ja on ja.jobid = pt.jobid and ja.attachtypeid = 7 and ja.isactive = true where pt.jobid =${jobid}  and pt.isactive = true;
  `;
};

export const updateCTedit = () => {
  return `
  UPDATE cupelements.trn_contentteam SET websiteandbrouchercopy = $2, bookseller = $3,tensecondsell = $4, fileupload = $5, statusid = $6, updated_by = $7, updated_time = CURRENT_TIMESTAMP, completed_date = $8 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const getCTEdit = jobid => {
  return `
  select * from cupelements.trn_contentteam ct left join cupelements.trn_job_attachment ja on ja.jobid = ct.jobid and ja.attachtypeid = 9 and ja.isactive = true 
where ct.jobid =${jobid}   and ct.isactive = true;
  `;
};

export const updatePMedit = () => {
  return `
  UPDATE cupelements.trn_pm_team SET 
  seriesid = $2,
  series_editor = $3,
  affiliation = $4,
  element_title = $5,
  title = $6,
  job_subtitle = $7,
  acptdon = $8,
  job_pubmonth = $9,
  mvdtoprod = $10,
  orcid = $11,
  s1id = $12,
  hypercare = $13,
  editor_contactdetail = $14,
  author_contact_details = $15,
  level_english = $16,
  copy_editor = $17,
  wordcount = $18,
  number_of_images = $19,
  trimsize = $20,
  hb_isbn = $21,
  pb_isbn = $22,
  oc_isbn = $23,
  centaurid =$24,
  shorturl = $25,
  t_subject_code = $26,
  t_education_qualifier =$27,
  t_interest_group_qualifier = $28,
  t_language_qualifier = $29,
  t_place_qualifier = $30,
  t_style_qualifier = $31,
  t_time_qualifier = $32,
  line_art = $33,
  maps = $34,
  halftones = $35,
  tables = $36,
  music_examples =$37,
  websiteandbrouchercopy = $38,
  bookseller = $39,
  tensecondsell = $40,
  toc =$41,
  created_by = $42,
  statusid = $43,
  updated_by = $44,
  printing = $46,
  updated_time = CURRENT_TIMESTAMP, completed_date = $45 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const getSeriesInfoScript = () => {
  return `SELECT series, ishypercare FROM cupelements.mst_series WHERE seriesid = $1 and isactive = true;`;
};

export const getfilepath = () => {
  return `
  select * from cupelements.trn_job_attachment where jobid = $1 and attachtypeid = $2 and isactive = true;
    `;
};

export const updateFileInDB = () => {
  return `
  update cupelements.trn_job_attachment SET isactive = false where jobid = $1 and attachtypeid = $2 and attachname = $3;
    `;
};

export const updateCTinPMTable = () => {
  return `
  UPDATE cupelements.trn_pm_team SET websiteandbrouchercopy = $2, bookseller = $3,tensecondsell = $4 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const updatePTinPMTable = () => {
  return `
  UPDATE cupelements.trn_pm_team SET wordcount = $2, number_of_images = $3, toc = $4, line_art = $5, maps = $6,halftones = $7, tables = $8, music_examples = $9 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const updateMSinPMTable = () => {
  return `
  UPDATE cupelements.trn_pm_team SET level_english = $2, copy_editor = $3,t_place_qualifier = $4,t_language_qualifier = $5,t_time_qualifier = $6,t_education_qualifier = $7,t_interest_group_qualifier = $8,t_style_qualifier = $9,printing = $10, t_subject_code = $11 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const unclaimjob = team => {
  let query = '';
  switch (team) {
    case 'C_PT':
      query = `UPDATE cupelements.trn_production_team SET statusid = 1 WHERE jobid = $1 RETURNING jobid;`;
      break;
    case 'C_MS':
      query = `UPDATE cupelements.trn_ms_team SET statusid = 1 WHERE jobid = $1 RETURNING jobid;`;
      break;
    case 'C_CT':
      query = `UPDATE cupelements.trn_contentteam SET statusid = 1 WHERE jobid = $1 RETURNING jobid;`;
      break;
    default:
      throw new Error('Invalid');
  }
  return query;
};
export const getJobStatus = () => {
  return `SELECT
  CASE
      WHEN EXISTS (SELECT 1 FROM cupelements.trn_ms_team WHERE statusid = 1 AND jobid = $1) 
        AND EXISTS (SELECT 1 FROM cupelements.trn_production_team WHERE statusid = 1 AND jobid = $1) 
        AND EXISTS (SELECT 1 FROM cupelements.trn_contentteam WHERE statusid = 1 AND jobid = $1) 
      THEN 'true'
      ELSE 'false'
  END AS status`;
};
export const updateJobElementStatus = () => {
  return `UPDATE cupelements.trn_job_element SET statusid = 1 WHERE jobid = $1 RETURNING jobid;`;
};

export const updatepmstatus = () => {
  return `
UPDATE cupelements.trn_pm_team
SET statusid = CASE WHEN $2 = '' THEN statusid  WHEN  $2 = NULL THEN statusid ELSE CAST($2 AS INTEGER)  end,
button_status = CASE WHEN $3 = '' THEN statusid  WHEN  $3 = NULL THEN button_status ELSE CAST($3 AS INTEGER)  end,
issentmail = true
WHERE jobid = $1 RETURNING jobid;`;
};

export const updateCTStatus = () => {
  return `
  UPDATE cupelements.trn_contentteam SET statusid = $2 WHERE jobid = $1 RETURNING jobid;
    `;
};
export const updatePTStatus = () => {
  return `
  UPDATE cupelements.trn_production_team SET statusid = $2 WHERE jobid = $1 RETURNING jobid;
    `;
};
export const updateMSStatus = () => {
  return `
  UPDATE cupelements.trn_ms_team SET statusid = $2 WHERE jobid = $1 RETURNING jobid;
    `;
};
export const updatemscleanup = () => {
  return `
  UPDATE cupelements.trn_ms_team SET statusid = $2, ismscleanup = $3, dueon = $4 WHERE jobid = $1 RETURNING jobid;
    `;
};
export const updatePMStatusWithMScleanup = () => {
  return `
  UPDATE cupelements.trn_pm_team SET button_status = $2 WHERE jobid = $1 RETURNING jobid;
    `;
};

export const getEmailTemplateScript = () => {
  const script = `SELECT * FROM wms_notifications 
                  WHERE entityid = $1 AND action = $2 AND isactive = TRUE;`;
  return script;
};

export const getMailIntroInfoScript = () => {
  const script = `select
	                  jsonb_build_object(
                      'title',
                      tje.title,
                      'elmnttitle',
                      tje.elmnttitle,
                      'pm',
                      pm.username,
                      'to',
                      json_agg(author.to)
                    ) as result
                  from
                    cupelements.trn_job_element tje
                  left join 
                    cupelements.trn_pm_team pmteam ON pmteam.jobid = tje.jobid
                  join 
                    wms_user pm on
                    pm.userid = tje.projectmanager
                  cross join lateral (
                    select
                      author->>'email' as to,
                      author->>'firstname' as author
                    from
                      jsonb_array_elements(pmteam.author_contact_details) as author
                    where
                      author->>'correspondingauthor' ilike 'YES'
                                    ) as author
                  where
                    tje.jobid = $1
                  group by
                    tje.title,
                    tje.elmnttitle,
                    pm.username;`;
  return script;
};

export const reSubmitJob = () => {
  return `update cupelements.trn_job_element set
  elmnttitle = $2,title=$3,acptdon=$4,mvdtoprod=CURRENT_TIMESTAMP,orcid=$5,s1id=$6,openaccess=$7,wordcount=$8,figurecount=$9,imagecount=$10,
  authordet = $11,suplmntryfile = $12,questionnaire=$13,permission=$14,figurefile=$15,cntenhancement=$16,source=$17,
  note=$18,mainfile=$19,
  enhancement=$20, dueon=$21,uploadedtype=$22,statusid=$23,updated_by=$24,updated_time = CURRENT_TIMESTAMP
  where jobid = $1`;
};

export const pmUpdate = () => {
  return `Update cupelements.trn_pm_team set title=$2,acptdon=$3,mvdtoprod=CURRENT_TIMESTAMP,statusid=$4,updated_by=$5,
  updated_time=CURRENT_TIMESTAMP, dueon = $6, element_title =$7, orcid= $8, s1id = $9, hypercare = $10, author_contact_details = $11
  where jobid=$1`;
};
export const pmwithoutDueonUpdate = () => {
  return `Update cupelements.trn_pm_team set title=$2,acptdon=$3,mvdtoprod=CURRENT_TIMESTAMP,statusid=$4,updated_by=$5,
  updated_time=CURRENT_TIMESTAMP,element_title =$6, orcid= $7, s1id = $8, hypercare = $9,author_contact_details = $10
  where jobid=$1`;
};

export const getPMStatusMail = () => {
  return `select issentmail from cupelements.trn_pm_team where jobid=$1`;
};

export const ptUpdate = () => {
  return `Update cupelements.trn_production_team set title=$2,acptdon=$3,mvdtoprod=CURRENT_TIMESTAMP,statusid=$4,updated_by=$5,updated_time=CURRENT_TIMESTAMP,dueon=$6
  where jobid=$1`;
};

export const msUpdate = () => {
  return `Update cupelements.trn_ms_team set title=$2,acptdon=$3,mvdtoprod=CURRENT_TIMESTAMP,statusid=$4,updated_by=$5,updated_time=CURRENT_TIMESTAMP,dueon=$6
  where jobid=$1`;
};

export const ctUpdate = () => {
  return `Update cupelements.trn_contentteam set title=$2,acptdon=$3,mvdtoprod=CURRENT_TIMESTAMP,statusid=$4,updated_by=$5,updated_time=CURRENT_TIMESTAMP,dueon=$6
  where jobid=$1`;
};
export const getCompleteStatus = jobid => {
  return `
  SELECT 
  CASE
      WHEN (SELECT statusid FROM cupelements.trn_ms_team where jobid = ${jobid} ) = 4
          AND (SELECT statusid FROM cupelements.trn_contentteam where jobid = ${jobid}) = 4
		  AND (SELECT statusid FROM cupelements.trn_production_team where jobid = ${jobid}) = 4
      THEN true
      ELSE false
  END AS result;
    `;
};

export const getPMDetails = jobid => {
  return `
  SELECT 
    pm.*, 
    pro.all_to_be_text,
    ser.series, 
    ser.series_editor::text,
    je.openaccess, 
    je.cntenhancement, 
    je.enhancement, 
    je.wordcount AS ActualWordCount,
    je.imagecount AS ActualImage,
    je.note, 
    je.source_filevalue,
    array_agg(attachm.attachname) FILTER (WHERE attachm.attachtypeid = 2) AS Supplementry,
    array_agg(attachm.attachname) FILTER (WHERE attachm.attachtypeid = 3) AS Questionarrie,
    array_agg(attachm.attachname) FILTER (WHERE attachm.attachtypeid = 4) AS permission,
    array_agg(attachm.attachname) FILTER (WHERE attachm.attachtypeid = 6) AS Source,
    array_agg(attachm.attachname) FILTER (WHERE attachm.attachtypeid = 10) AS imprints  
FROM 
    cupelements.trn_pm_team pm
    LEFT JOIN cupelements.mst_series ser ON pm.seriesid = ser.seriesid
    LEFT JOIN cupelements.trn_job_element je ON pm.jobid = je.jobid
    LEFT JOIN cupelements.trn_production_team pro ON pm.jobid = pro.jobid
    LEFT JOIN cupelements.trn_job_attachment attachm ON pm.jobid = attachm.jobid
WHERE 
    pm.jobid = ${jobid}
GROUP BY 
    pm.pmteamid,
    pro.all_to_be_text,
    ser.series, 
    ser.series_editor::text,
    je.openaccess, 
    je.cntenhancement, 
    je.enhancement, 
    je.wordcount,
    je.imagecount,
    je.note,
    je.source_filevalue;
  `;
};

export const getPMEdit = jobid => {
  return `
  SELECT
  pm.element_title,
  pm.title,
  COALESCE(NULLIF(pm.acptdon, NULL)::timestamp, je.acptdon::timestamp) AS acceptedon,
  COALESCE(NULLIF(pm.mvdtoprod, NULL)::timestamp, je.mvdtoprod::timestamp) AS movedtoprod,
  COALESCE(NULLIF(pm.author_contact_details, NULL), je.authordet) AS authordetails,
  COALESCE(NULLIF(pm.seriesid, NULL), je.seriesid) AS seriesid,
  pm.orcid,
  pm.s1id,
  pm.hypercare,
  pm.wordcount,
  pm.number_of_images,  
  pm.job_subtitle,
  pm.affiliation,
  pm.job_pubmonth,
  pm.editor_contactdetail,
  pm.trimsize,
  pm.hb_isbn,
  pm.pb_isbn,
  pm.oc_isbn,
  pm.centaurid,
  pm.shorturl,
  pm.level_english,
  pm.copy_editor,
  pm.t_place_qualifier,
  pm.t_language_qualifier,
  pm.t_time_qualifier,
  pm.t_education_qualifier,
  pm.t_interest_group_qualifier,
  pm.t_style_qualifier,
  pm.printing,
  pm.websiteandbrouchercopy,
  pm.bookseller,
  pm.tensecondsell,
  pm.toc,
  pm.line_art,
  pm.maps,
  pm.halftones,
  pm.tables,
  pm.music_examples,
  pm.t_subject_code,
  pm.button_status,
  pm.statusid,
  je.ijobcardid, 
  je.projectmanager as pm,
  pm.isubjobid,
  (SELECT ishypercare FROM cupelements.mst_series WHERE seriesid = COALESCE(NULLIF(pm.seriesid, NULL), je.seriesid) LIMIT 1) AS Series_hypercare,
  (SELECT seriesjson FROM cupelements.trn_job_element WHERE seriesid = je.seriesid LIMIT 1) AS series,
  JSON_AGG(
    JSON_BUILD_OBJECT(
      'attachname', ja.attachname,
      'attachpath', ja.attachpath,
      'attachenv', ja.attachenv,
      'attachtypeid', ja.attachtypeid 
    )
  ) FILTER (WHERE ja.jobid IS NOT NULL) AS attachments
FROM cupelements.trn_pm_team pm
LEFT JOIN cupelements.trn_job_element je ON pm.jobid = je.jobid
LEFT JOIN cupelements.trn_job_attachment ja ON ja.jobid = pm.jobid AND ja.attachtypeid IN( 10,11) AND ja.isactive = true
WHERE pm.jobid = ${jobid}
GROUP BY
  pm.element_title,
  pm.title,
  pm.acptdon, je.acptdon,
  pm.mvdtoprod, je.mvdtoprod,
  pm.orcid,
  pm.s1id,
  pm.hypercare,
  pm.wordcount,
  pm.number_of_images,
  pm.author_contact_details, je.authordet,
  pm.seriesid, je.seriesid,
  pm.job_subtitle, pm.affiliation, pm.job_pubmonth, pm.editor_contactdetail,
  pm.trimsize, pm.hb_isbn, pm.pb_isbn, pm.oc_isbn, pm.centaurid, pm.shorturl,
  pm.level_english, pm.copy_editor, pm.t_place_qualifier, pm.t_language_qualifier,
  pm.t_time_qualifier, pm.t_education_qualifier, pm.t_interest_group_qualifier,
  pm.t_style_qualifier, pm.printing, pm.websiteandbrouchercopy, pm.bookseller,
  pm.tensecondsell, pm.toc, pm.line_art, pm.maps, pm.halftones, pm.tables,
  pm.music_examples, pm.t_subject_code, pm.button_status,pm.statusid, je.ijobcardid, je.projectmanager, pm.isubjobid, je.seriesid;
  `;
};

export const getCupConfig = () => {
  return 'select config_json, isactive, (SELECT max(jobid) + 1 as maxid from cupelements.trn_job_element) from cupelements.mst_config mc where type_acronym = $1';
};

export const getTatExcludeHolidayScript = () => {
  return `select add_hours_exclude_weekends_and_holidays($1,$2) as duedate`;
};
