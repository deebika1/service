export function get_master_drop_down(p_name) {
  let query = '';

  switch (p_name) {
    case 'SERIES':
      query = `select s.seriesid as value,s.series as label,s.projectmanager as pm,u.username as name, s.seriescode, s.contentmanager as pe
         from cupelements.mst_series s
         left join public.wms_user u on u.userid = s.projectmanager
         WHERE s.isactive=true`;
      break;
    case 'STATUS':
      query = `
      select statusname as value,statusname as label,statuscode as code
      from cupelements.mst_status
      WHERE isactive=true;`;
      break;
    case 'PM':
      query = `
      select UPPER(u.username) as label,u.userid as value from public.wms_role r
      left join public.wms_userrole ur on ur.roleid = r.roleid
      left join public.wms_user u on u.userid = ur.userid
      where r.roleacronym in ('C_PM','C_PMTL') and u.useractive = true
      `;
      break;
    case 'QUERY':
      query = `
      select roleid as value, REPLACE(rolename, 'CUP-', '') AS label from public.wms_role
      where roleacronym in ('C_PR','C_PT','C_MS','C_CT', 'C_PM') and isactive=true`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
}

export const getRoleAcronym = () => {
  return `
  select roleacronym from public.wms_role where roleid = $1
    `;
};
