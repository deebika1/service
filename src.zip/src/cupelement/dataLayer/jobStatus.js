export const getunclaimedjob = role => {
  let query = '';
  switch (role) {
    case 'C_PR':
      query = `SELECT 
      ROW_NUMBER() OVER (ORDER BY je.created_time desc) AS serial,
      je.*,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
      ser.series,
      je_sts.statusname as status 
      FROM 
        cupelements.trn_job_element je 
      LEFT JOIN 
      cupelements.mst_series ser ON je.seriesid = ser.seriesid 
        LEFT JOIN 
            cupelements.mst_status je_sts ON je_sts.statusid = je.statusid
		 LEFT JOIN cupelements.trn_pm_team pm ON je.jobid = pm.jobid
		 LEFT JOIN 
            cupelements.mst_status pm_sts ON pm_sts.statusid = pm.statusid
        WHERE 
        je_sts.statuscode = 'YTS' AND je_sts.statuscode !='R' AND pm_sts.statuscode = 'YTS'
       AND je.isactive=true;`;
      break;
    case 'C_PMTL':
      query = `SELECT * FROM (SELECT 
        ROW_NUMBER() OVER ( ORDER BY
        CASE
        WHEN pm.updated_time IS NULL THEN pm.created_time
        ELSE pm.updated_time
        END DESC) AS serial,
        je.jobid,
        TO_CHAR(pm.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
        TO_CHAR(pm.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
        ser.series,
        pm.title,
        pm_sts.statusname as status,  
        'action' as action
      FROM 
        cupelements.trn_job_element je 
      LEFT JOIN 
        cupelements.mst_series ser ON je.seriesid = ser.seriesid 
      LEFT JOIN 
        cupelements.trn_pm_team pm ON pm.jobid = je.jobid
      LEFT JOIN 
        cupelements.mst_status pm_sts ON pm_sts.statusid = pm.statusid
      WHERE
        pm_sts.statuscode = 'CL' AND pm_sts.statuscode !='R'
        AND je.isactive=true) AS q order by serial;`;
      break;
    case 'C_PM':
      query = ` SELECT * FROM (SELECT 
        ROW_NUMBER() OVER (ORDER BY
        CASE
        WHEN pm.updated_time IS NULL THEN pm.created_time
        ELSE pm.updated_time
        END DESC) AS serial,
        je.jobid,
        TO_CHAR(pm.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
        TO_CHAR(pm.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
        ser.series,
        pm.title, 
        pm_sts.statusname as status,
        'action' as action   
      FROM 
        cupelements.trn_job_element je 
      LEFT JOIN 
        cupelements.mst_series ser ON je.seriesid = ser.seriesid 
      LEFT JOIN 
        cupelements.trn_pm_team pm ON pm.jobid = je.jobid
      LEFT JOIN 
        cupelements.mst_status pm_sts ON pm_sts.statusid = pm.statusid
      WHERE
        pm_sts.statuscode = 'CL' AND ser.projectmanager = $1
        AND je.isactive=true AND pm_sts.statuscode !='R'
        ) AS q order by serial;`;
      break;
    case 'C_PT':
      query = ` select
                  row_number() over (
                order by
                  pt.created_time desc) as serial,
                  je.jobid,
                  TO_CHAR(pt.acptdon,
                  'DD-Mon-YYYY') as acceptedOn,
                  TO_CHAR(pt.mvdtoprod,
                  'DD-Mon-YYYY') as movedToProd,
                  ser.series,
                  pt.title,
                  pt_sts.statusname as status,
                  case
                    when tjh.jobid is not null then true
                    else false
                  end as historyshow
                from
                  cupelements.trn_job_element je
                left join 
                      cupelements.mst_series ser on
                  je.seriesid = ser.seriesid
                left join 
                      cupelements.trn_production_team pt on
                  pt.jobid = je.jobid
                left join 
                      cupelements.mst_status pt_sts on
                  pt_sts.statusid = pt.statusid
                left join public.wms_role wr on
                  wr.roleacronym = 'C_PT'
                left join (
                  select 
                    jobid,
                    roleid
                  from
                    cupelements.trn_job_history
                  group by
                    jobid,
                    roleid
                  having
                    COUNT(jobid) > 0
                                ) tjh on
                  tjh.jobid = je.jobid
                  and tjh.roleid = wr.roleid
                where
                  pt_sts.statuscode = 'YTS' AND pt_sts.statuscode !='R'
                  and je.isactive = true;`;
      break;
    case 'C_MS':
      query = ` select
                  row_number() over (
                order by
                  ms.created_time desc) as serial,
                  je.jobid,
                  TO_CHAR(ms.acptdon,
                  'DD-Mon-YYYY') as acceptedOn,
                  TO_CHAR(ms.mvdtoprod,
                  'DD-Mon-YYYY') as movedToProd,
                  ser.series,
                  ms.title,
                  ms_sts.statusname as status,
                  case
                    when tjh.jobid is not null then true
                    else false
                  end as historyshow
                from
                  cupelements.trn_job_element je
                left join 
                        cupelements.mst_series ser on
                  je.seriesid = ser.seriesid
                left join 
                          cupelements.trn_ms_team ms on
                  ms.jobid = je.jobid
                left join 
                        cupelements.mst_status ms_sts on
                  ms_sts.statusid = ms.statusid
                left join public.wms_role wr on
                  wr.roleacronym = 'C_MS'
                left join (
                  select 
                    jobid,
                    roleid
                  from
                    cupelements.trn_job_history
                  group by
                    jobid,
                    roleid
                  having
                    COUNT(jobid) > 0
                                ) tjh on
                  tjh.jobid = je.jobid
                  and tjh.roleid = wr.roleid
                where
                  ms_sts.statuscode = 'YTS'AND ms_sts.statuscode != 'R'
                  and je.isactive = true;`;
      break;
    case 'C_CT':
      query = ` select
                  row_number() over (
                order by
                  ct.created_time desc) as serial,
                  je.jobid,
                  TO_CHAR(ct.acptdon,
                  'DD-Mon-YYYY') as acceptedOn,
                  TO_CHAR(ct.mvdtoprod,
                  'DD-Mon-YYYY') as movedToProd,
                  ser.series,
                  ct.title,
                  ct_sts.statusname as status,
                  case
                    when tjh.jobid is not null then true
                    else false
                  end as historyshow
                from
                  cupelements.trn_job_element je
                left join 
                      cupelements.mst_series ser on
                  je.seriesid = ser.seriesid
                left join 
                        cupelements.trn_contentteam ct on
                  ct.jobid = je.jobid
                left join 
                      cupelements.mst_status ct_sts on
                  ct_sts.statusid = ct.statusid
                left join public.wms_role wr on
                  wr.roleacronym = 'C_CT'
                left join (
                  select 
                    jobid,
                    roleid
                  from
                    cupelements.trn_job_history
                  group by
                    jobid,
                    roleid
                  having
                    COUNT(jobid) > 0
                                ) tjh on
                  tjh.jobid = je.jobid
                  and tjh.roleid = wr.roleid
                where
                  ct_sts.statuscode = 'YTS' AND ct_sts.statuscode != 'R'
                  and je.isactive = true;`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
};
export const getclaimedjob = role => {
  let query = '';
  switch (role) {
    case 'C_PR':
      query = `
      SELECT 
      ROW_NUMBER() OVER (ORDER BY CASE
      WHEN je.updated_time IS NULL THEN je.created_time
      ELSE je.updated_time
      END DESC) AS serial, 
      je.*,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedon,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedtoprod,
      ser.series, 
  	  pm_sts.statuscode AS pm_status,
      pt_sts.statuscode AS productionteam_status, 
      ms_sts.statuscode AS msteam_status, 
      ct_sts.statuscode AS ct_status,
	    pm_sts.statusname AS pm_statusname,
      pt_sts.statusname AS productionTeam_statusname, 
      ms_sts.statusname AS msTeam_statusname, 
      ct_sts.statusname AS ct_statusname,
	    TO_CHAR(pm.dueon, 'DD-Mon-YYYY') AS pm_dueon,
      TO_CHAR(pt.dueon, 'DD-Mon-YYYY') AS pt_dueon,
      TO_CHAR(ms.dueon, 'DD-Mon-YYYY') AS ms_dueon,
      TO_CHAR(ct.dueon, 'DD-Mon-YYYY') AS ct_dueon,
	   CASE
         WHEN CAST(pm.dueon AS DATE) >= CURRENT_DATE AND pm_sts.statuscode != 'C' AND pm_sts.statuscode != 'CL' THEN 'false'
		 WHEN CAST(pm.dueon AS DATE) >= pm.completed_date AND (pm_sts.statuscode = 'C' OR pm_sts.statuscode = 'CL') THEN 'false'
         ELSE 'true'
       END AS pm_overdue,
	   CASE
         WHEN CAST(pt.dueon AS DATE) >= CURRENT_DATE AND pt_sts.statuscode != 'C' AND pt_sts.statuscode != 'CL' THEN 'false'
		 WHEN CAST(pt.dueon AS DATE) >= pt.completed_date AND (pt_sts.statuscode = 'C' OR pt_sts.statuscode = 'CL') THEN 'false'
         ELSE 'true'
       END AS pt_overdue,
	   CASE
          WHEN CAST(ms.dueon AS DATE) >= CURRENT_DATE AND ms_sts.statuscode != 'C' AND ms_sts.statuscode != 'CL' THEN 'false'
		  WHEN CAST(ms.dueon AS DATE) >= ms.completed_date AND (ms_sts.statuscode = 'C' OR ms_sts.statuscode = 'CL') THEN 'false'
         ELSE 'true'
       END AS ms_overdue,
	   CASE
          WHEN CAST(ct.dueon AS DATE) >= CURRENT_DATE AND ct_sts.statuscode != 'C' AND ct_sts.statuscode != 'CL' THEN 'false'
		  WHEN CAST(ct.dueon AS DATE) >= ct.completed_date AND (ct_sts.statuscode = 'C' OR ct_sts.statuscode = 'CL') THEN 'false'
         ELSE 'true'
       END AS ct_overdue,
     CASE 
		 WHEN  pm_sts.statuscode = 'CL' AND pt_sts.statuscode = 'CL'
		 AND   ms_sts.statuscode = 'CL' AND ct_sts.statuscode = 'CL'
		 THEN  'Closed'
		 WHEN  pm_sts.statuscode = 'C' AND pt_sts.statuscode = 'C'
		 AND   ms_sts.statuscode = 'C' AND ct_sts.statuscode = 'C'
		 THEN  'Completed'
		 WHEN  pm_sts.statuscode = 'YTS' AND pt_sts.statuscode = 'YTS'
		 AND   ms_sts.statuscode = 'YTS' AND ct_sts.statuscode = 'YTS'
		 THEN  'Yet to Start'
     	 WHEN  pm_sts.statuscode = 'H'
		 THEN  'On Hold'
		 ELSE 'In-Progress'
	 END AS Status,
	  CASE 
		 WHEN  pm_sts.statuscode = 'CL' AND pt_sts.statuscode = 'CL'
		 AND   ms_sts.statuscode = 'CL' AND ct_sts.statuscode = 'CL'
		 THEN  'cup_completed'
		 WHEN  pm_sts.statuscode = 'C' AND pt_sts.statuscode = 'C'
		 AND   ms_sts.statuscode = 'C' AND ct_sts.statuscode = 'C'
		 THEN  'cup_completed'
		 WHEN  pm_sts.statuscode = 'YTS' AND pt_sts.statuscode = 'YTS'
		 AND   ms_sts.statuscode = 'YTS' AND ct_sts.statuscode = 'YTS'
		 THEN  'cup_yts'
     	 WHEN  pm_sts.statuscode = 'H'
		 THEN  'cup_onhold'
		 ELSE 'cup_inprogress'
	 END AS statusclass
-- 	 need to show Status in peerreview statusid (select statusname from cupelements.mst_status where statusid = je.statusid)
  FROM 
      cupelements.trn_job_element je 
  LEFT JOIN 
      cupelements.mst_series ser ON je.seriesid = ser.seriesid
  LEFT JOIN 
      cupelements.trn_production_team pt ON pt.jobid = je.jobid
  LEFT JOIN 
      cupelements.trn_ms_team ms ON ms.jobid = je.jobid 
  LEFT JOIN 
      cupelements.trn_pm_team pm ON pm.jobid = je.jobid
  LEFT JOIN 
      cupelements.trn_contentteam ct ON ct.jobid = je.jobid
  LEFT JOIN 
      cupelements.mst_status pt_sts ON pt_sts.statusid = pt.statusid
  LEFT JOIN 
      cupelements.mst_status ms_sts ON ms_sts.statusid = ms.statusid
  LEFT JOIN 
      cupelements.mst_status pm_sts ON pm_sts.statusid = pm.statusid
  LEFT JOIN 
      cupelements.mst_status ct_sts ON ct_sts.statusid = ct.statusid
  WHERE 
	  (pm_sts.statuscode != 'YTS' OR pt_sts.statuscode != 'YTS' OR ms_sts.statuscode != 'YTS' OR ct_sts.statuscode != 'YTS') AND 
	  je.isactive=true AND pm_sts.statuscode != 'R';
        `;
      break;
    case 'C_PMTL':
      query = `SELECT 
      ROW_NUMBER() OVER (ORDER BY
  CASE
  WHEN pm.updated_time IS NULL THEN pm.created_time
  ELSE pm.updated_time
  END DESC) AS serial, 
      je.jobid,
      TO_CHAR(pm.acptdon, 'DD-Mon-YYYY') AS acceptedon,
      TO_CHAR(pm.mvdtoprod, 'DD-Mon-YYYY') AS movedtoprod,
      ser.series, 
  ser.ishypercare,
  (select username from public.wms_user where userid= ser.projectmanager) as projectmanager,
      pm_sts.statuscode AS pm_status,
      pt_sts.statuscode AS productionteam_status, 
      ms_sts.statuscode AS msteam_status, 
      ct_sts.statuscode AS ct_status,
      pm_sts.statusname AS pm_statusname,
      pt_sts.statusname AS productionTeam_statusname, 
      ms_sts.statusname AS msTeam_statusname, 
      ct_sts.statusname AS ct_statusname,
      TO_CHAR(pm.dueon, 'DD-Mon-YYYY') AS pm_dueon,
      TO_CHAR(pt.dueon, 'DD-Mon-YYYY') AS pt_dueon,
      TO_CHAR(ms.dueon, 'DD-Mon-YYYY') AS ms_dueon,
      TO_CHAR(ct.dueon, 'DD-Mon-YYYY') AS ct_dueon,
      CASE
      WHEN CAST(pm.dueon AS DATE) >= CURRENT_DATE AND pm_sts.statuscode != 'C' AND pm_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(pm.dueon AS DATE) >= pm.completed_date AND (pm_sts.statuscode = 'C' OR pm_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS pm_overdue,
      CASE
          WHEN CAST(pt.dueon AS DATE) >= CURRENT_DATE AND pt_sts.statuscode != 'C' AND pt_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(pt.dueon AS DATE) >= pt.completed_date AND (pt_sts.statuscode = 'C' OR pt_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS pt_overdue,
      CASE
          WHEN CAST(ms.dueon AS DATE) >= CURRENT_DATE AND ms_sts.statuscode != 'C' AND ms_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(ms.dueon AS DATE) >= ms.completed_date AND (ms_sts.statuscode = 'C' OR ms_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS ms_overdue,
      CASE
          WHEN CAST(ct.dueon AS DATE) >= CURRENT_DATE AND ct_sts.statuscode != 'C' AND ct_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(ct.dueon AS DATE) >= ct.completed_date AND (ct_sts.statuscode = 'C' OR ct_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS ct_overdue,
      pm.title,
  pm.closeddate,
      TO_CHAR(pm.dueon, 'DD-Mon-YYYY') AS dueon,
      CASE 
   WHEN  pm_sts.statuscode = 'CL' AND pt_sts.statuscode = 'CL'
   AND   ms_sts.statuscode = 'CL' AND ct_sts.statuscode = 'CL'
   THEN  'Completed'
   WHEN  pm_sts.statuscode = 'C' AND pt_sts.statuscode = 'C'
   AND   ms_sts.statuscode = 'C' AND ct_sts.statuscode = 'C'
   THEN  'Completed'
   WHEN  pm_sts.statuscode = 'YTS' AND pt_sts.statuscode = 'YTS'
   AND   ms_sts.statuscode = 'YTS' AND ct_sts.statuscode = 'YTS'
   THEN  'Yet to Start'
   WHEN  ms_sts.statuscode = 'MSC' 
   THEN  'MS Cleanup'
   WHEN  pm_sts.statuscode = 'H' 
   THEN  'On Hold'
   ELSE 'In-Progress'
 END AS Status,
      CASE 
   WHEN  pm_sts.statuscode = 'CL' AND pt_sts.statuscode = 'CL'
   AND   ms_sts.statuscode = 'CL' AND ct_sts.statuscode = 'CL'
   THEN  'cup_completed'
   WHEN  pm_sts.statuscode = 'C' AND pt_sts.statuscode = 'C'
   AND   ms_sts.statuscode = 'C' AND ct_sts.statuscode = 'C'
   THEN  'cup_completed'
   WHEN  pm_sts.statuscode = 'YTS' AND pt_sts.statuscode = 'YTS'
   AND   ms_sts.statuscode = 'YTS' AND ct_sts.statuscode = 'YTS'
   THEN  'cup_yts'
    WHEN  ms_sts.statuscode = 'MSC' 
   THEN  'cup_onhold'
   WHEN  pm_sts.statuscode = 'H' 
   THEN  'cup_onhold'
   ELSE 'cup_inprogress'
 END AS statusclass
-- 	 need to show Status in peerreview statusid (select statusname from cupelements.mst_status where statusid = je.statusid)
  FROM 
      cupelements.trn_job_element je 
  LEFT JOIN 
      cupelements.mst_series ser ON je.seriesid = ser.seriesid
  LEFT JOIN 
      cupelements.trn_production_team pt ON pt.jobid = je.jobid
  LEFT JOIN 
      cupelements.trn_ms_team ms ON ms.jobid = je.jobid 
  LEFT JOIN 
      cupelements.trn_pm_team pm ON pm.jobid = je.jobid
  LEFT JOIN 
      cupelements.trn_contentteam ct ON ct.jobid = je.jobid
  LEFT JOIN 
      cupelements.mst_status pt_sts ON pt_sts.statusid = pt.statusid
  LEFT JOIN 
      cupelements.mst_status ms_sts ON ms_sts.statusid = ms.statusid
  LEFT JOIN 
      cupelements.mst_status pm_sts ON pm_sts.statusid = pm.statusid
  LEFT JOIN 
      cupelements.mst_status ct_sts ON ct_sts.statusid = ct.statusid
  WHERE 
     (pm_sts.statuscode != 'CL' AND pt_sts.statuscode != 'CL' AND ms_sts.statuscode != 'CL' AND ct_sts.statuscode != 'CL') AND 
  je.isactive=true AND pm_sts.statuscode != 'R';`;
      break;
    case 'C_PM':
      query = `SELECT 
      ROW_NUMBER() OVER (ORDER BY
        CASE
        WHEN pm.updated_time IS NULL THEN pm.created_time
        ELSE pm.updated_time
        END DESC) AS serial, 
      je.jobid,
      TO_CHAR(pm.acptdon, 'DD-Mon-YYYY') AS acceptedon,
      TO_CHAR(pm.mvdtoprod, 'DD-Mon-YYYY') AS movedtoprod,
      ser.series, 
      ser.ishypercare,
      (select username from public.wms_user where userid= ser.projectmanager) as projectmanager,
      pm_sts.statuscode AS pm_status,
      pt_sts.statuscode AS productionteam_status, 
      ms_sts.statuscode AS msteam_status, 
      ct_sts.statuscode AS ct_status,
      pm_sts.statusname AS pm_statusname,
      pt_sts.statusname AS productionTeam_statusname, 
      ms_sts.statusname AS msTeam_statusname, 
      ct_sts.statusname AS ct_statusname,
      TO_CHAR(pm.dueon, 'DD-Mon-YYYY') AS pm_dueon,
      TO_CHAR(pt.dueon, 'DD-Mon-YYYY') AS pt_dueon,
      TO_CHAR(ms.dueon, 'DD-Mon-YYYY') AS ms_dueon,
      TO_CHAR(ct.dueon, 'DD-Mon-YYYY') AS ct_dueon,
      CASE
      WHEN CAST(pm.dueon AS DATE) >= CURRENT_DATE AND pm_sts.statuscode != 'C' AND pm_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(pm.dueon AS DATE) >= pm.completed_date AND (pm_sts.statuscode = 'C' OR pm_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS pm_overdue,
      CASE
          WHEN CAST(pt.dueon AS DATE) >= CURRENT_DATE AND pt_sts.statuscode != 'C' AND pt_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(pt.dueon AS DATE) >= pt.completed_date AND (pt_sts.statuscode = 'C' OR pt_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS pt_overdue,
      CASE
          WHEN CAST(ms.dueon AS DATE) >= CURRENT_DATE AND ms_sts.statuscode != 'C' AND ms_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(ms.dueon AS DATE) >= ms.completed_date AND (ms_sts.statuscode = 'C' OR ms_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS ms_overdue,
      CASE
          WHEN CAST(ct.dueon AS DATE) >= CURRENT_DATE AND ct_sts.statuscode != 'C' AND ct_sts.statuscode != 'CL' THEN 'false'
      WHEN CAST(ct.dueon AS DATE) >= ct.completed_date AND (ct_sts.statuscode = 'C' OR ct_sts.statuscode = 'CL') THEN 'false'
          ELSE 'true'
        END AS ct_overdue,
      pm.title,
      pm.closeddate,
      TO_CHAR(pm.dueon, 'DD-Mon-YYYY') AS dueon,
      CASE 
      WHEN  pm_sts.statuscode = 'CL' AND pt_sts.statuscode = 'CL'
      AND   ms_sts.statuscode = 'CL' AND ct_sts.statuscode = 'CL'
      THEN  'Completed'
      WHEN  pm_sts.statuscode = 'C' AND pt_sts.statuscode = 'C'
      AND   ms_sts.statuscode = 'C' AND ct_sts.statuscode = 'C'
      THEN  'Completed'
      WHEN  pm_sts.statuscode = 'YTS' AND pt_sts.statuscode = 'YTS'
      AND   ms_sts.statuscode = 'YTS' AND ct_sts.statuscode = 'YTS'
      THEN  'Yet to Start'
	  WHEN  ms_sts.statuscode = 'MSC' 
      THEN  'MS Cleanup'
      WHEN  pm_sts.statuscode = 'H' 
      THEN  'On Hold'
      ELSE 'In-Progress'
  END AS Status,
        CASE 
      WHEN  pm_sts.statuscode = 'CL' AND pt_sts.statuscode = 'CL'
      AND   ms_sts.statuscode = 'CL' AND ct_sts.statuscode = 'CL'
      THEN  'cup_completed'
      WHEN  pm_sts.statuscode = 'C' AND pt_sts.statuscode = 'C'
      AND   ms_sts.statuscode = 'C' AND ct_sts.statuscode = 'C'
      THEN  'cup_completed'
      WHEN  pm_sts.statuscode = 'YTS' AND pt_sts.statuscode = 'YTS'
      AND   ms_sts.statuscode = 'YTS' AND ct_sts.statuscode = 'YTS'
      THEN  'cup_yts'
	  WHEN  ms_sts.statuscode = 'MSC' 
   THEN  'cup_onhold'
      WHEN  pm_sts.statuscode = 'H' 
      THEN  'cup_onhold'
      ELSE 'cup_inprogress'
  END AS statusclass
-- 	 need to show Status in peerreview statusid (select statusname from cupelements.mst_status where statusid = je.statusid)
  FROM 
      cupelements.trn_job_element je 
  LEFT JOIN 
      cupelements.mst_series ser ON je.seriesid = ser.seriesid
  LEFT JOIN 
      cupelements.trn_production_team pt ON pt.jobid = je.jobid
  LEFT JOIN 
      cupelements.trn_ms_team ms ON ms.jobid = je.jobid 
  LEFT JOIN 
      cupelements.trn_pm_team pm ON pm.jobid = je.jobid
  LEFT JOIN 
      cupelements.trn_contentteam ct ON ct.jobid = je.jobid
  LEFT JOIN 
      cupelements.mst_status pt_sts ON pt_sts.statusid = pt.statusid
  LEFT JOIN 
      cupelements.mst_status ms_sts ON ms_sts.statusid = ms.statusid
  LEFT JOIN 
      cupelements.mst_status pm_sts ON pm_sts.statusid = pm.statusid
  LEFT JOIN 
      cupelements.mst_status ct_sts ON ct_sts.statusid = ct.statusid
  WHERE 
  (pm_sts.statuscode != 'CL' AND pt_sts.statuscode != 'CL' AND ms_sts.statuscode != 'CL' AND ct_sts.statuscode != 'CL') AND 
      je.isactive=true AND ser.projectmanager = $1 AND pm_sts.statuscode != 'R'
      ORDER BY
      CASE
      WHEN pm.updated_time IS NULL THEN pm.created_time
      ELSE pm.updated_time
      END DESC;`;
      break;
    case 'C_PT':
      query = `SELECT * FROM (SELECT
        ROW_NUMBER() OVER ( order BY CASE
        WHEN pt.updated_time IS NULL THEN pt.created_time
        ELSE pt.updated_time
        END DESC) AS serial,
        je.jobid,
        TO_CHAR(pt.acptdon, 'DD-Mon-YYYY') AS acceptedon,
        TO_CHAR(pt.mvdtoprod, 'DD-Mon-YYYY') AS movedtoprod,
        ser.series,
        pt.title,
        pt_sts.statuscode,
        TO_CHAR(pt.dueon, 'DD-Mon-YYYY') AS dueon,
       (select statusname from cupelements.mst_status where statusid =pt.statusid ) AS status,
	   CASE
		WHEN (select statuscode from cupelements.mst_status where statusid =pt.statusid ) = 'IP'
		THEN 'cup_inprogress'
		WHEN (select statuscode from cupelements.mst_status where statusid =pt.statusid ) = 'C'
		THEN 'cup_completed'
		WHEN (select statuscode from cupelements.mst_status where statusid =pt.statusid ) = 'CL'
		THEN 'cup_completed'
	    WHEN (select statuscode from cupelements.mst_status where statusid =pt.statusid ) = 'YTS'
		THEN 'cup_yts'
	    WHEN (select statuscode from cupelements.mst_status where statusid =pt.statusid ) = 'H'
		THEN 'cup_onhold'
		END AS statusclass,
       CASE
           WHEN CAST(pt.dueon AS DATE) >= CURRENT_DATE AND pt_sts.statuscode != 'C' AND pt_sts.statuscode != 'CL' THEN 'On Time'
           WHEN CAST(pt.dueon AS DATE) >= pt.completed_date AND (pt_sts.statuscode = 'C' OR pt_sts.statuscode = 'CL') THEN 'On Time'
           ELSE 'Delay'
         END AS overduestatus
      FROM
          cupelements.trn_job_element je
      LEFT JOIN
          cupelements.mst_series ser ON je.seriesid = ser.seriesid
      LEFT JOIN
          cupelements.trn_production_team pt ON pt.jobid = je.jobid
      LEFT JOIN
          cupelements.mst_status pt_sts ON pt_sts.statusid = pt.statusid
      WHERE
        pt_sts.statuscode != 'YTS' AND pt_sts.statuscode != 'R' AND pt.updated_by = $1 AND
        je.isactive=true) as Q order by serial;`;
      break;
    case 'C_MS':
      query = `
      SELECT * FROM (SELECT
        ROW_NUMBER() OVER (ORDER BY  CASE
        WHEN ms.updated_time IS NULL THEN ms.created_time
        ELSE ms.updated_time
        END DESC) AS serial,
        je.jobid,
        TO_CHAR(ms.acptdon, 'DD-Mon-YYYY') AS acceptedon,
        TO_CHAR(ms.mvdtoprod, 'DD-Mon-YYYY') AS movedtoprod,
        ser.series, 
        ms.title,
      ms_sts.statuscode,
        TO_CHAR(ms.dueon, 'DD-Mon-YYYY') AS dueon,
       (select statusname from cupelements.mst_status where statusid =ms.statusid ) AS status,
	  CASE
		WHEN (select statuscode from cupelements.mst_status where statusid =ms.statusid ) = 'IP'
		THEN 'cup_inprogress'
		WHEN (select statuscode from cupelements.mst_status where statusid =ms.statusid ) = 'C'
		THEN 'cup_completed'
		WHEN (select statuscode from cupelements.mst_status where statusid =ms.statusid ) = 'CL'
		THEN 'cup_completed'
	    WHEN (select statuscode from cupelements.mst_status where statusid =ms.statusid ) = 'YTS'
		THEN 'cup_yts'
	    WHEN (select statuscode from cupelements.mst_status where statusid =ms.statusid ) = 'H'
		THEN 'cup_onhold'
	    WHEN (select statuscode from cupelements.mst_status where statusid =ms.statusid ) = 'MSC'
		THEN 'cup_onhold'
		END AS statusclass,
       CASE
           WHEN CAST(ms.dueon AS DATE) >= CURRENT_DATE AND ms_sts.statuscode != 'C' AND ms_sts.statuscode != 'CL' THEN 'On Time'
           WHEN CAST(ms.dueon AS DATE) >= ms.completed_date AND (ms_sts.statuscode = 'C' OR ms_sts.statuscode = 'CL') THEN 'On Time'
           ELSE 'Delay'
         END AS overduestatus
          FROM 
              cupelements.trn_job_element je 
          LEFT JOIN 
              cupelements.mst_series ser ON je.seriesid = ser.seriesid
          LEFT JOIN 
              cupelements.trn_ms_team ms ON ms.jobid = je.jobid 
          LEFT JOIN 
              cupelements.mst_status ms_sts ON ms_sts.statusid = ms.statusid
          WHERE 
               ms_sts.statuscode != 'YTS' AND ms.updated_by = $1 AND
              je.isactive=true AND ms_sts.statuscode != 'R'
       ) as Q order by serial;`;
      break;
    case 'C_CT':
      query = `
      SELECT * FROM (SELECT
        ROW_NUMBER() OVER (ORDER BY CASE
        WHEN ct.updated_time IS NULL THEN ct.created_time
        ELSE ct.updated_time
        END DESC) AS serial,
        je.jobid,
        TO_CHAR(ct.acptdon, 'DD-Mon-YYYY') AS acceptedon,
        TO_CHAR(ct.mvdtoprod, 'DD-Mon-YYYY') AS movedtoprod,
        ser.series, 
        ct.title,
        ct_sts.statuscode,
          TO_CHAR(ct.dueon, 'DD-Mon-YYYY') AS dueon,
        (select statusname from cupelements.mst_status where statusid =ct.statusid ) AS status,
	     CASE
		WHEN (select statuscode from cupelements.mst_status where statusid =ct.statusid ) = 'IP'
		THEN 'cup_inprogress'
		WHEN (select statuscode from cupelements.mst_status where statusid =ct.statusid ) = 'C'
		THEN 'cup_completed'
		WHEN (select statuscode from cupelements.mst_status where statusid =ct.statusid ) = 'CL'
		THEN 'cup_completed'
	    WHEN (select statuscode from cupelements.mst_status where statusid =ct.statusid ) = 'YTS'
		THEN 'cup_yts'
	    WHEN (select statuscode from cupelements.mst_status where statusid =ct.statusid ) = 'H'
		THEN 'cup_onhold'
		END AS statusclass,
        CASE
           WHEN CAST(ct.dueon AS DATE) >= CURRENT_DATE AND ct_sts.statuscode != 'C' AND ct_sts.statuscode != 'CL' THEN 'On Time'
           WHEN CAST(ct.dueon AS DATE) >= ct.completed_date AND (ct_sts.statuscode = 'C' OR ct_sts.statuscode = 'CL') THEN 'On Time'
           ELSE 'Delay'
         END AS overduestatus
          FROM 
              cupelements.trn_job_element je 
          LEFT JOIN 
              cupelements.mst_series ser ON je.seriesid = ser.seriesid
          LEFT JOIN 
              cupelements.trn_contentteam ct ON ct.jobid = je.jobid
          LEFT JOIN 
              cupelements.mst_status ct_sts ON ct_sts.statusid = ct.statusid
          WHERE 
          ct_sts.statuscode != 'YTS' AND ct.updated_by = $1 AND
          je.isactive=true AND ct_sts.statuscode != 'R'
       ) as Q order by serial;
        `;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
};
export const getstatus = () => {
  return `
  select statusname AS label, statusname AS value, statuscode FROM cupelements.mst_status
  WHERE isactive = true ORDER BY statusname
  `;
};

export function getRoleJobStatus(role) {
  let query = '';
  switch (role) {
    case 'C_PT':
      query = `select st.statuscode,st.statusname,pt.updated_by,pt.statusid from cupelements.trn_production_team pt
      left join cupelements.mst_status st ON st.statusid = pt.statusid
      where pt.jobid = $1`;
      break;
    case 'C_MS':
      query = `
      select st.statuscode,st.statusname,ms.updated_by,ms.statusid from cupelements.trn_ms_team ms 
      left join cupelements.mst_status st ON st.statusid = ms.statusid
      where ms.jobid = $1`;
      break;
    case 'C_CT':
      query = `select st.statuscode,st.statusname,ct.updated_by,ct.statusid from cupelements.trn_contentteam ct 
      left join cupelements.mst_status st ON st.statusid = ct.statusid
      where ct.jobid = $1`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
}

export function updateRoleJobStatus(role) {
  let query = '';
  switch (role) {
    case 'C_PT':
      query = `UPDATE cupelements.trn_production_team
      SET statusid = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP 
      WHERE jobid=$1;`;
      break;
    case 'C_MS':
      query = `
      UPDATE cupelements.trn_ms_team
      SET statusid = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP 
      WHERE jobid=$1;`;
      break;
    case 'C_CT':
      query = `UPDATE cupelements.trn_contentteam
      SET statusid = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP 
      WHERE jobid=$1;`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
}

export const updatePRStatus = () => {
  return `
  UPDATE cupelements.trn_job_element
  SET statusid = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP 
  WHERE jobid=$1;
  `;
};

export const getPRstatus = () => {
  return `
  select st.statuscode,st.statusname,je.updated_by,je.statusid from cupelements.trn_job_element je
  left join cupelements.mst_status st ON st.statusid = je.statusid
  where je.jobid = $1
  `;
};

export const createHistory = () => {
  return `
  INSERT INTO cupelements.trn_job_history (jobid, roleid, type, created_by,notes, created_time)
  VALUES ($1,$2,$3,$4,$5,$6)
  `;
};

export const getFoldername = () => {
  return `
  select attachtypeid,attachtypedesc,foldername,attach_acryn from cupelements.mst_attachmenttype
  where isactive = true
  `;
};

export const addAttachementFileDetails = () => {
  return `
  INSERT INTO cupelements.trn_job_attachment (attachtypeid, jobid, attachname, attachpath,attachenv,created_by)
  VALUES ($1,$2,$3,$4,$5,$6)`;
};

export const CreateSeriesMaster = () => {
  return `
  INSERT INTO cupelements.mst_series 
(seriescode, series,issn,trim,design,clrprntstrgy,copyediting,copyeditinglvl,proofread,index_fld,style
,runningheads,deliverables,contentmanager,projectmanager,comeditor,ioscontopscntrlr,covertemp,subjectarea
,proofinstruct,patterntitle,notes,reference,addnlnotes,ishypercare,created_by,series_editor) 
VALUES ($1, $2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15
,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27)`;
};

export const UpdateSeriesMaster = () => {
  return `
  UPDATE cupelements.mst_series SET seriescode = $2, series = $3,issn=$4,trim=$5,design=$6,
  clrprntstrgy= $7,copyediting= $8,copyeditinglvl= $9,proofread= $10,index_fld= $11,style= $12
  ,runningheads= $13,deliverables= $14,contentmanager= $15,projectmanager= $16,comeditor= $17,ioscontopscntrlr= $18,covertemp= $19,subjectarea= $20
  ,proofinstruct= $21,patterntitle= $22,notes= $23,reference= $24,addnlnotes= $25,ishypercare= $26,updated_by= $27,updated_time=CURRENT_DATE ,series_editor= $28
  WHERE seriesid = $1
  `;
};

export const checkSeries = name => {
  return `
  SELECT COUNT(series) > 0 AS result
  FROM cupelements.mst_series 
  WHERE
    isactive = true
    AND LOWER(series) = LOWER('${name}')
  `;
};

export const checkSeriesCode = name => {
  return `
  SELECT COUNT(seriescode) > 0 AS result
  FROM cupelements.mst_series 
  WHERE
    isactive = true
    AND LOWER(seriescode) = LOWER('${name}')
  `;
};

export const getJobHistoryScript = () => {
  return `select
            wu.username || ' [' || tjh.created_by || ']' AS username,
            substring(wr.rolename from 5) as team,
            "type",
            tjh.created_time
          from
            cupelements.trn_job_history tjh
          join public.wms_role wr on
            wr.roleid = tjh.roleid
          join public.wms_user wu on wu.userid = tjh.created_by 
          where tjh.jobid = $1 and wr.roleacronym in ($2, 'C_PM', 'C_PMTL', 'C_PR')`;
};
export const getSeriesMasterDetails = role => {
  let query = '';
  switch (role) {
    case 'C_PMTL':
      query = `SELECT 
      ROW_NUMBER() OVER (
          ORDER BY CASE
              WHEN s.updated_time IS NULL THEN s.created_time
              ELSE s.updated_time
          END DESC
      ) AS serial,
      s.seriesid,
      s.series,
      s.seriescode,
      UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS projectmanager_username,
      'action' AS action
      FROM 
          cupelements.mst_series s
      LEFT JOIN 
          public.wms_user u ON u.userid = s.projectmanager
      WHERE 
          u.useractive = true 
          AND s.isactive = true;`;
      break;
    case 'C_PM':
      query = `
      SELECT 
      ROW_NUMBER() OVER (
          ORDER BY CASE
              WHEN s.updated_time IS NULL THEN s.created_time
              ELSE s.updated_time
          END DESC
      ) AS serial,
      s.seriesid,
      s.series,
      s.seriescode,
      UPPER(CONCAT(u.username, ' (', u.userid, ')')) AS projectmanager_username,
      'action' AS action
      FROM 
          cupelements.mst_series s
      LEFT JOIN 
          public.wms_user u ON u.userid = s.projectmanager
      WHERE 
          u.useractive = true 
          AND s.isactive = true
      AND s.projectmanager = $1;`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
};

export const getSeriesData = () => {
  // return `
  // select * from cupelements.mst_series where seriesid=$1 and isactive = true;
  // `;

  return `
  SELECT *, CONCAT('{ label:"', u.username, '",value: "', u.userid, '"}') as projectmanager
  FROM cupelements.mst_series s
  LEFT JOIN public.wms_user u ON u.userid = s.projectmanager
  WHERE s.seriesid = $1 AND s.isactive = true;`;
};

export const getPMOpenJob = () => {
  return `select jobid from cupelements.trn_job_element j
  left join cupelements.mst_status s on s.statusid = j.statusid
  where j.seriesid = $1 and j.isactive = true and s.statuscode != 'CL';`;
};

export const ReassignPM = () => {
  return `
  UPDATE cupelements.trn_job_element
  SET projectmanager = $2,updated_by=$3,updated_time=CURRENT_DATE
  WHERE jobid = $1 and isactive = true;
  `;
};

export const removeSeries = () => {
  return `UPDATE cupelements.mst_series
  SET updated_by=$2,updated_time=CURRENT_DATE,isactive = false
  WHERE seriesid = $1 and isactive = true;`;
};

export const getteamjobdetails = (jobid, team) => {
  let query = '';
  switch (team) {
    case 'MS':
      query = `select je.seriesjson, je.elmnttitle,TO_CHAR(je.acptdon, 'YYYY-MM-DD') AS acceptedon,TO_CHAR(je.mvdtoprod, 'YYYY-MM-DD') AS movedtoprod, je.authordet, je.title,je.orcid, je.openaccess, je.wordcount AS actualWordCount, je.imagecount AS actualimagecount, je.ijobcardid, je.projectmanager as pm,ms.* from cupelements.trn_ms_team ms join cupelements.trn_job_element je ON ms.jobid = je.jobid where je.jobid = ${jobid};`;
      break;
    case 'CT':
      query = `select je.seriesjson, je.elmnttitle,TO_CHAR(je.acptdon, 'YYYY-MM-DD') AS acceptedon,
      TO_CHAR(je.mvdtoprod, 'YYYY-MM-DD') AS movedtoprod,je.authordet, je.title,je.orcid, je.openaccess, je.wordcount AS actualWordCount, je.imagecount AS actualimagecount, je.ijobcardid, je.projectmanager as pm,ct.* 
      from cupelements.trn_contentteam ct join cupelements.trn_job_element je ON ct.jobid = je.jobid where je.jobid = ${jobid};`;
      break;
    case 'PT':
      query = `select je.seriesjson, je.elmnttitle,TO_CHAR(je.acptdon, 'YYYY-MM-DD') AS acceptedon,
      TO_CHAR(je.mvdtoprod, 'YYYY-MM-DD') AS movedtoprod,je.authordet, je.title,je.orcid, je.openaccess, je.wordcount AS actualWordCount, je.imagecount AS actualimagecount, je.ijobcardid, je.projectmanager as pm,pt.* 
      from cupelements.trn_production_team pt join cupelements.trn_job_element je ON pt.jobid = je.jobid where je.jobid = ${jobid};`;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
};

export const getRejectedjob = role => {
  let query = '';
  switch (role) {
    case 'C_PR':
      query = `
      SELECT 
      ROW_NUMBER() OVER (ORDER BY r.created_time desc) AS serial,
      je.jobid,
	    je.title,
      r.queryid,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
      ser.series,
      TO_CHAR(r.created_time, 'DD-Mon-YYYY') AS rejectedon,
	    'action' AS action
      FROM 
	   cupelements.trn_rejected_job r
       LEFT JOIN
	   cupelements.trn_job_element je ON je.jobid = r.jobid
      LEFT JOIN 
      cupelements.mst_series ser ON je.seriesid = ser.seriesid 
      WHERE 
        je.isactive=true and r.isactive=true
        `;
      break;
    case 'C_PMTL':
      query = `SELECT 
      ROW_NUMBER() OVER (ORDER BY r.created_time desc) AS serial,
      je.jobid,
	    je.title,
      r.queryid,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
      ser.series,
      TO_CHAR(r.created_time, 'DD-Mon-YYYY') AS rejectedon,
	  'action' AS action
      FROM 
	  cupelements.trn_rejected_job r
       LEFT JOIN
	   cupelements.trn_job_element je ON je.jobid = r.jobid
      LEFT JOIN 
      cupelements.mst_series ser ON je.seriesid = ser.seriesid 
      WHERE 
        je.isactive=true and r.isactive=true;`;
      break;
    case 'C_PM':
      query = `SELECT 
      ROW_NUMBER() OVER (ORDER BY r.created_time desc) AS serial,
      je.jobid,
	    je.title,
      r.queryid,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
      ser.series,
      TO_CHAR(r.created_time, 'DD-Mon-YYYY') AS rejectedon,
	  'action' AS action
      FROM 
	  cupelements.trn_rejected_job r
       LEFT JOIN
	   cupelements.trn_job_element je ON je.jobid = r.jobid
      LEFT JOIN 
      cupelements.mst_series ser ON je.seriesid = ser.seriesid 
      WHERE 
        je.isactive=true and r.isactive=true
		and ser.projectmanager = $1;`;
      break;
    case 'C_PT':
      query = `SELECT 
      ROW_NUMBER() OVER (ORDER BY r.created_time desc) AS serial,
      je.jobid,
	    je.title,
      r.queryid,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
      ser.series,
      TO_CHAR(r.created_time, 'DD-Mon-YYYY') AS rejectedon,
	  'action' AS action
      FROM 
	  cupelements.trn_rejected_job r
       LEFT JOIN
	   cupelements.trn_job_element je ON je.jobid = r.jobid
      LEFT JOIN 
       cupelements.mst_series ser ON je.seriesid = ser.seriesid 
	    LEFT JOIN
          cupelements.trn_production_team pt ON pt.jobid = je.jobid
      WHERE 
        je.isactive=true and r.isactive=true
		    --AND pt.updated_by = ''
        ;`;
      break;
    case 'C_MS':
      query = `
      SELECT 
      ROW_NUMBER() OVER (ORDER BY r.created_time desc) AS serial,
      je.jobid,
	    je.title,
      r.queryid,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
      ser.series,
      TO_CHAR(r.created_time, 'DD-Mon-YYYY') AS rejectedon,
	  'action' AS action
      FROM 
	  cupelements.trn_rejected_job r
       LEFT JOIN
	   cupelements.trn_job_element je ON je.jobid = r.jobid
      LEFT JOIN 
       cupelements.mst_series ser ON je.seriesid = ser.seriesid 
	  LEFT JOIN 
       cupelements.trn_ms_team ms ON ms.jobid = je.jobid
      WHERE 
        je.isactive=true and r.isactive=true
		--AND ms.updated_by = '';
    `;
      break;
    case 'C_CT':
      query = `
      SELECT 
      ROW_NUMBER() OVER (ORDER BY r.created_time desc) AS serial,
      je.jobid,
      je.title,
      r.queryid,
      TO_CHAR(je.acptdon, 'DD-Mon-YYYY') AS acceptedOn,
      TO_CHAR(je.mvdtoprod, 'DD-Mon-YYYY') AS movedToProd,
      ser.series,
      TO_CHAR(r.created_time, 'DD-Mon-YYYY') AS rejectedon,
	  'action' AS action
      FROM 
	  cupelements.trn_rejected_job r
       LEFT JOIN
	   cupelements.trn_job_element je ON je.jobid = r.jobid
      LEFT JOIN 
       cupelements.mst_series ser ON je.seriesid = ser.seriesid 
	  LEFT JOIN 
       cupelements.trn_contentteam ct ON ct.jobid = je.jobid
      WHERE 
        je.isactive=true and r.isactive=true
		--AND ct.updated_by = '';
        `;
      break;
    default:
      throw new Error('Invalid Param');
  }
  return query;
};

export const getRejectedjobDetails = () => {
  return `WITH attachment_data AS (
    SELECT
        att.jobid,
        json_agg(json_build_object(
          'attachment_id', att.attachid,
          'acronym', atype.attach_acryn,
          'name', att.attachname,
          'path', att.attachpath
      )) AS attachments
    FROM
        cupelements.trn_job_attachment att
    LEFT JOIN
        cupelements.mst_attachmenttype atype ON atype.attachtypeid = att.attachtypeid
    WHERE att.isactive = true
    GROUP BY
        att.jobid
  )
  SELECT
    je.*,
    pm.isubjobid,
    mst_s.series,
    st.statuscode,
    att_data.attachments,
      UPPER(CONCAT(u.username, ' (', SUBSTRING(wr.roleacronym, 3), ')')) AS rejectedby,
      UPPER(CONCAT(uq.username, ' (', SUBSTRING(wrq.roleacronym, 3), ')')) AS queryraisedby,
      mst_s.series,
      r.reason,
      q.queryid
  FROM
    cupelements.trn_job_element je
  JOIN
    cupelements.trn_pm_team pm ON pm.jobid = je.jobid
  LEFT JOIN
    cupelements.mst_series mst_s ON je.seriesid = mst_s.seriesid
  LEFT JOIN
    cupelements.mst_status st ON st.statusid = je.statusid
  LEFT JOIN
    attachment_data att_data ON att_data.jobid = je.jobid
     LEFT JOIN
      cupelements.trn_rejected_job r ON r.jobid = je.jobid
     LEFT JOIN 
      public.wms_userrole wu ON wu.userid = r.created_by
      LEFT JOIN
      public.wms_user u ON u.userid = r.created_by
      LEFT JOIN
      public.wms_role wr ON wr.roleid = wu.roleid
      LEFT JOIN
      cupelements.trn_queries q ON q.jobid = je.jobid
      LEFT JOIN
       public.wms_userrole wuq ON wuq.userid = q.created_by
       LEFT JOIN
      public.wms_user uq ON uq.userid = q.created_by
      LEFT JOIN
      public.wms_role wrq ON wrq.roleid = wuq.roleid
  WHERE
  je.isactive = true AND st.statuscode = 'R'
    AND je.jobid = $1 
    AND q.queryid = $2
    AND r.isactive = true 
  AND wr.roleacronym IN ('C_PMTL', 'C_CT', 'C_MS', 'C_PT', 'C_PM', 'C_PR') 
  AND wrq.roleacronym IN ('C_PMTL', 'C_CT', 'C_MS', 'C_PT', 'C_PM', 'C_PR')
`;
};

export const updatePMJobStatus = () => {
  return `UPDATE  cupelements.trn_pm_team SET statusid = $2 WHERE jobid=$1`;
};
export const updatePTJobStatus = () => {
  return `UPDATE  cupelements.trn_production_team SET statusid = $2 WHERE jobid=$1`;
};
export const updateMSJobStatus = () => {
  return `UPDATE  cupelements.trn_ms_team SET statusid = $2 WHERE jobid=$1`;
};
export const updateCTJobStatus = () => {
  return `UPDATE  cupelements.trn_contentteam SET statusid = $2 WHERE jobid=$1`;
};

export const updateRejectJobStatus = () => {
  return `UPDATE  cupelements.trn_rejected_job SET isactive=false WHERE jobid=$1`;
};
export const getopenquerydetails = (jobid, user) => {
  return `
  SELECT CASE WHEN EXISTS (
        SELECT 1
        FROM cupelements.trn_queries
        WHERE jobid = ${jobid}
          AND created_by = '${user}'
          AND is_closed = false
    )
    THEN TRUE
    ELSE FALSE
END AS result`;
};
