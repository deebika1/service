import axios from 'axios';
import { config } from '../../config/restApi.js';
import {
  getMasterService,
  createNewJobService,
  getQueriesListService,
  unclaimedjobService,
  claimedjobService,
  getstatusService,
  getFileUploadPathService,
  addJobFilePathService,
  getCheckSeriesExistService,
  getJobDetailsService,
  getNotesService,
  insNotesService,
  getRoleAcronymService,
  getExportListService,
  getRoleJobStatusService,
  updateRoleJobStatusService,
  savemseditService,
  getMSEditService,
  savepteditService,
  getPTEditService,
  savecteditService,
  getCTEditService,
  getFolderNameService,
  createSeriesMasterService,
  updateSeriesMasterService,
  checkseriesexistsService,
  checkseriescodeexistsService,
  savepmeditService,
  getSeriesMasterDetailsService,
  getSeriesDataService,
  getPMOpenJobService,
  ReassignSeriesService,
  removeSeriesService,
  getJobHistoryService,
  getFilePathService,
  updateFileInDBService,
  unclaimjobService,
  createQueryService,
  queryFileUploadDetailsService,
  getQueryJobBasedService,
  updatepmstatusService,
  updatemscleanupService,
  updateHistoryforUnclaimService,
  getteamjobdetailsService,
  getEmailIntroPreviewService,
  sendEmailIntroService,
  getOpenQueriesService,
  getRaisedQueriesService,
  getRejectedjobService,
  getJobCompleteStatusService,
  getPMDetailsService,
  getPMEditService,
  getQueryDetailsService,
  responseQueryService,
  createRejectService,
  getRejectedJobDetailsService,
  reSubmitJobService,
  getopenqueryService,
} from '../service/index.js';

export const getMasterController = async (req, res) => {
  try {
    const tblname = req.params.tblname.toUpperCase();
    const out = await getMasterService(tblname);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createNewJobController = async (req, res) => {
  try {
    const out = await createNewJobService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQueriesListController = async (req, res) => {
  try {
    const result = await getQueriesListService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const unclaimedjobController = async (req, res) => {
  try {
    const { role, userid } = req.params;
    const result = await unclaimedjobService(role, userid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const claimedjobController = async (req, res) => {
  try {
    const { role, userid } = req.params;
    const result = await claimedjobService(role, userid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getstatusController = async (req, res) => {
  try {
    const result = await getstatusService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getfileUploadPathController = async (req, res) => {
  try {
    const result = await getFileUploadPathService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const addJobFilePathController = async (req, res) => {
  try {
    const out = await addJobFilePathService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCheckSeriesExistController = async (req, res) => {
  try {
    const result = await getCheckSeriesExistService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getJobDetailsController = async (req, res) => {
  try {
    const jobId = parseInt(req.params.jobid);
    const out = await getJobDetailsService(jobId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getNotesController = async (req, res) => {
  try {
    const { jobid } = req.body;
    const result = await getNotesService(jobid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insNotesController = async (req, res) => {
  try {
    const { jobid, notes, userid } = req.body;
    const result = await insNotesService(jobid, notes, userid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRoleAcronymController = async (req, res) => {
  try {
    const { roleid } = req.params;
    const result = await getRoleAcronymService(roleid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getExportListController = async (req, res) => {
  try {
    const { jobid } = req.body;
    const result = await getExportListService(jobid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRoleJobStatusController = async (req, res) => {
  try {
    const { jobid, role } = req.params;
    const out = await getRoleJobStatusService(jobid, role);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateRoleJobStatusController = async (req, res) => {
  try {
    const result = await updateRoleJobStatusService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const savemseditController = async (req, res) => {
  try {
    const out = await savemseditService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getMSEditController = async (req, res) => {
  try {
    const jobId = parseInt(req.params.jobid);
    const out = await getMSEditService(jobId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const savepteditController = async (req, res) => {
  try {
    const out = await savepteditService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getPTEditController = async (req, res) => {
  try {
    const jobId = parseInt(req.params.jobid);
    const out = await getPTEditService(jobId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const savecteditController = async (req, res) => {
  try {
    const out = await savecteditService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCTEditController = async (req, res) => {
  try {
    const jobId = parseInt(req.params.jobid);
    const out = await getCTEditService(jobId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFolderNameController = async (req, res) => {
  try {
    const result = await getFolderNameService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createSeriesMasterController = async (req, res) => {
  try {
    const result = await createSeriesMasterService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateSeriesMasterController = async (req, res) => {
  try {
    const result = await updateSeriesMasterService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const checkseriesexistsController = async (req, res) => {
  try {
    const { series } = req.params;
    const out = await checkseriesexistsService(series);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const checkseriescodeexistsController = async (req, res) => {
  try {
    const { seriescode } = req.params;
    const out = await checkseriescodeexistsService(seriescode);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const savepmeditController = async (req, res) => {
  try {
    const out = await savepmeditService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getSeriesMasterDetailsController = async (req, res) => {
  try {
    const result = await getSeriesMasterDetailsService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getSeriesDataController = async (req, res) => {
  try {
    const seriesid = parseInt(req.params.seriesid);
    const out = await getSeriesDataService(seriesid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getPMOpenJobsController = async (req, res) => {
  try {
    const seriesid = parseInt(req.params.seriesid);
    const out = await getPMOpenJobService(seriesid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const reassignPMSeriesController = async (req, res) => {
  try {
    const out = await ReassignSeriesService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const removeSeriesController = async (req, res) => {
  try {
    const seriesid = parseInt(req.params.seriesid);
    const { userid } = req.params;
    const out = await removeSeriesService(seriesid, userid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getJobHistoryController = async (req, res) => {
  try {
    const { roleacronym, jobid } = req.params;
    const out = await getJobHistoryService(jobid, roleacronym);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFilePathController = async (req, res) => {
  try {
    const out = await getFilePathService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateFileInDBController = async (req, res) => {
  try {
    const out = await updateFileInDBService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const unclaimjobController = async (req, res) => {
  try {
    const out = await unclaimjobService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updatepmstatusController = async (req, res) => {
  try {
    const out = await updatepmstatusService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updatemscleanupController = async (req, res) => {
  try {
    const out = await updatemscleanupService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updatehistoryforunclaimController = async (req, res) => {
  try {
    const result = await updateHistoryforUnclaimService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getteamjobdetailsController = async (req, res) => {
  try {
    const { jobid, team } = req.params;
    const out = await getteamjobdetailsService(jobid, team);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getEmailIntroPreviewController = async (req, res) => {
  try {
    const { jobid, pmid } = req.params;
    const result = await getEmailIntroPreviewService(jobid, pmid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const sendEmailIntroController = async (req, res) => {
  try {
    const { notificationconfig, jobid } = req.body;
    const result = await sendEmailIntroService(notificationconfig, jobid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createQueryController = async (req, res) => {
  try {
    const out = await createQueryService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getJobCompleteStatusController = async (req, res) => {
  try {
    const jobId = parseInt(req.params.jobid);
    const out = await getJobCompleteStatusService(jobId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const queryFileUploadDetailsController = async (req, res) => {
  try {
    const out = await queryFileUploadDetailsService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getQueryJobBasedController = async (req, res) => {
  try {
    const { jobid } = req.params;
    const out = await getQueryJobBasedService(jobid);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getOpenedQueriesController = async (req, res) => {
  try {
    const result = await getOpenQueriesService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRaisedQueriesController = async (req, res) => {
  try {
    const result = await getRaisedQueriesService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRejectedjobController = async (req, res) => {
  try {
    const { role, userid } = req.params;
    const result = await getRejectedjobService(role, userid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const handlePdfDownload = async (req, res) => {
  try {
    const options = req.body;
    const response = await axios({
      method: req.method,
      // url: process.env.PDFDownload,
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.pdfDownload
      }`,
      data: options,
      headers: {
        clientid: 'WMS',
        apikey: '84B9A8C7-FDEA-47DC-B1CF-845FD79C4E05',
        // Add other headers if needed
      },
    });
    res.send(response.data);
  } catch (error) {
    res.status(error.response.status).json(error.response.data);
  }
};
export const getPMDetailsController = async (req, res) => {
  try {
    const jobId = parseInt(req.params.jobid);
    const out = await getPMDetailsService(jobId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getQueryDetailsController = async (req, res) => {
  try {
    const { queryid, roleid } = req.params;
    const out = await getQueryDetailsService(queryid, roleid);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getPMEditController = async (req, res) => {
  try {
    const jobId = parseInt(req.params.jobid);
    const out = await getPMEditService(jobId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const responseQueryController = async (req, res) => {
  try {
    const out = await responseQueryService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createRejectController = async (req, res) => {
  try {
    const out = await createRejectService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRejectedJobDetailsController = async (req, res) => {
  try {
    const { jobid, queryid } = req.params;
    const out = await getRejectedJobDetailsService(jobid, queryid);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const reSubmitJobController = async (req, res) => {
  try {
    const out = await reSubmitJobService(req.body);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getopenqueryController = async (req, res) => {
  try {
    const { jobid, user } = req.params;
    const out = await getopenqueryService(jobid, user);
    res.status(201).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
