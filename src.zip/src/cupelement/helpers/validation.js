import Joi from 'joi';

const masterData = ['series', 'status', 'pm', 'query'];

export const getMasterSchema = Joi.object({
  tblname: Joi.string()
    .valid(...masterData)
    .required(),
});
