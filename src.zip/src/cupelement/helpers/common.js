export function getCurrentTimestamp() {
  return new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
}
