export const validateData = (schema, data) => {
  const { error } = schema.validate(data);
  if (error) {
    return error.details[0].message;
  }
  return null;
};

const validateArrData = (schemaArray, dataArray) => {
  const validationErrors = [];
  dataArray.forEach((data, index) => {
    const { error } = schemaArray.validate(dataArray);
    if (error) {
      validationErrors.push(
        `Error in item ${index + 1}: ${error.details[0].message}`,
      );
    }
  });
  return validationErrors.length ? validationErrors : null;
};

export const validateRequestBody = schema => (req, res, next) => {
  const validationError = validateData(schema, req.body);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }
  return next();
};

export const validateArrRequestBody = schema => (req, res, next) => {
  const validationError = validateArrData(schema, req.body);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }
  return next();
};

export const validateRequestParams = schema => (req, res, next) => {
  const validationError = validateData(schema, req.params);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }
  return next();
};

export const validateRequestQuery = schema => (req, res, next) => {
  const validationError = validateData(schema, req.query);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }
  return next();
};
