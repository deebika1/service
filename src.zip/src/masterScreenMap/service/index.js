import { query } from '../../database/postgres.js';
import { get_master_drop_down } from '../dataLayer/masterDropDown.js';
import { get_user_list, get_user_list_du } from '../dataLayer/userList.js';
import { get_menu_list } from '../dataLayer/menuList.js';
import {
  insDelMenuAccess,
  getMenuData,
} from '../dataLayer/mappingFunctionalities.js';

export const getMasterDropDownService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log('payload test', payload);
      const script = get_master_drop_down(payload);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getUserListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await get_user_list(payload);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getDUbasedlistService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await get_user_list_du(payload);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getMenuListService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await get_menu_list(payload);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const insDelMenuAccessService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await insDelMenuAccess(payload.payload);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getMenuDataService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await getMenuData(payload);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
