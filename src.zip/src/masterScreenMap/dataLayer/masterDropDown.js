export function get_master_drop_down(p_name) {
  let query = '';

  switch (p_name) {
    case 'DU':
      query =
        'SELECT duid AS column_id, duname AS column_name FROM public.org_mst_deliveryunit WHERE isactive = true ORDER BY duname;';
      break;
    case 'ROLE':
      query =
        'SELECT roleid AS column_id, rolename AS column_name FROM public.wms_role WHERE isactive = true ORDER BY rolename;';
      break;
    default:
      throw new Error('Invalid Param');
  }

  return query;
}
