import { query } from '../../database/postgres.js';

export const insDelMenuAccess = async p_data => {
  return new Promise(async (resolve, reject) => {
    try {
      const vUpdatedBy = p_data.updatedBy;
      const menuIds = p_data.menuList.map(menu => menu.toString());
      const userList = p_data.userList.map(user => user.toString());

      for (const userId of userList) {
        const query1 = ` WITH deleted AS (
          DELETE FROM public.wms_entity_user_permission
          WHERE userid = $1
          AND entityid NOT IN (
            SELECT e.entityid
            FROM public.wms_mst_screens s 
            LEFT JOIN public.wms_screen_entity_map e ON e.screenid = s.screenid
            WHERE s.menuid = ANY($2::INT[])
          )
          RETURNING entityid, userid
        )
        SELECT userid, entityid
        FROM deleted;`;

        const deletedRecords = await query(query1, [userId, menuIds]);

        // Insert new permissions
        for (const menuId of menuIds) {
          const query2 = `SELECT e.entityid FROM public.wms_mst_screens s LEFT JOIN public.wms_screen_entity_map e ON e.screenid = s.screenid WHERE s.menuid = $1`;
          const entityIdResult = await query(query2, [parseInt(menuId)]);

          const uniqueEntities = new Set();

          for (const entityResult of entityIdResult) {
            const entityId = entityResult?.entityid;

            if (entityId && !uniqueEntities.has(entityId)) {
              uniqueEntities.add(entityId);
              const query3 = `SELECT entityid FROM wms_entity_user_permission WHERE userid = $1 AND entityid = $2`;
              const existingPermission = await query(query3, [
                userId,
                entityId,
              ]);
              if (existingPermission.length === 0) {
                const query4 = `INSERT INTO public.wms_entity_user_permission(userid, entityid, created_by, updated_by) VALUES ($1, $2, $3, $3)`;
                await query(query4, [userId, entityId, vUpdatedBy]);
              }
            }
          }
        }

        // Insert deleted records into the audit table
        if (deletedRecords.length > 0) {
          for (const record of deletedRecords) {
            const query5 = `INSERT INTO public.wms_entity_user_permission_audit(userid, entityid, deleted_by) VALUES ($1, $2, $3)`;
            await query(query5, [record.userid, record.entityid, vUpdatedBy]);
          }
        }
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const getMenuData = async ({ userIds }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const query1 = `SELECT wms_uimenu.menuid::int
                      FROM wms_entity_user_permission perm
                      JOIN wms_mst_entity ON wms_mst_entity.entityid = perm.entityid
                      JOIN wms_screen_entity_map ON wms_screen_entity_map.entityid = wms_mst_entity.entityid
                      JOIN wms_mst_screens ON wms_mst_screens.screenid = wms_screen_entity_map.screenid
                      JOIN wms_uimenu ON wms_uimenu.menuid = wms_mst_screens.menuid
                      WHERE perm.userid = any($1)
                      GROUP BY wms_uimenu.menuid, wms_uimenu.menuname
                      HAVING COUNT(DISTINCT perm.userid) = ${userIds.length};`;

      const menuIds = await query(query1, [userIds]);

      resolve(menuIds);
    } catch (error) {
      reject(error);
    }
  });
};
