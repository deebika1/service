import { query } from '../../database/postgres.js';

export async function get_user_list(payload) {
  let result = '';
  const { roleId, userId } = payload;
  if (roleId.includes('21')) {
    result = await query(
      `SELECT  userdet.userid,userdet.username,userdet.designation,userdet.duid,userdet.mappedduid,
      array_agg(mstrole.roleid) AS roleid, array_agg(DISTINCT rolename) As rolename
      FROM public.wms_user as userdet
      LEFT JOIN public.wms_userrole as usrrole on usrrole.userid = userdet.userid
      LEFT JOIN public.wms_role as mstrole on mstrole.roleid = usrrole.roleid
      WHERE useractive = true 
      GROUP BY userdet.userid,userdet.username,userdet.designation,userdet.duid,userdet.mappedduid 
      ORDER BY userdet.username`,
    );
  } else {
    result = await query(
      `WITH RECURSIVE ReportingHierarchy AS (
        SELECT
            userdet.userid,
            userdet.username,
            userdet.designation,
            userdet.duid,
            userdet.mappedduid,
            usrrole.roleid,
            mstrole.rolename
        FROM
            public.wms_user AS userdet
            LEFT JOIN public.wms_userrole AS usrrole ON usrrole.userid = userdet.userid
            LEFT JOIN public.wms_role AS mstrole ON mstrole.roleid = usrrole.roleid
        WHERE
            useractive = true AND reportingto = $1
        
        UNION ALL
        
        SELECT
            userdet.userid,
            userdet.username,
            userdet.designation,
            userdet.duid,
            userdet.mappedduid,
            usrrole.roleid,
            mstrole.rolename
        FROM
            public.wms_user AS userdet
            LEFT JOIN public.wms_userrole AS usrrole ON usrrole.userid = userdet.userid
            LEFT JOIN public.wms_role AS mstrole ON mstrole.roleid = usrrole.roleid
            INNER JOIN ReportingHierarchy r ON userdet.reportingto = r.userid
        WHERE
            useractive = true
    )
    SELECT DISTINCT ON (userid, username) userid, username, designation, duid, mappedduid, array_agg(DISTINCT roleid) AS roleid, array_agg(DISTINCT rolename) As rolename
    FROM (
        SELECT * FROM ReportingHierarchy
    ) AS subquery
    GROUP BY userid, username, designation, duid, mappedduid
    ORDER BY username;`,
      [userId],
    );
  }
  return result;
}
// create function for search employee based on du

export async function get_user_list_du(payload) {
  const { duId, roleId, searchtype } = payload;
  let result = null;
  if (searchtype === 'du' && duId) {
    result = await query(
      `
    SELECT DISTINCT ON (u.userid,u.username) u.userid,u.username,u.designation,u.duid
    FROM public.mst_deliveryunit du
    LEFT JOIN public.org_mst_deliveryunit odu ON du.duid = odu.itrackduid
    LEFT JOIN public.wms_user u ON odu.duid = u.duid
    WHERE (u.duid = any($1) OR u.mappedduid::bigint[] && ARRAY[$1]::bigint[]) and u.useractive=true
    order by u.username`,
      [duId],
    );
  } else if (searchtype === 'role' && roleId) {
    result = await query(
      `
    SELECT DISTINCT ON (u.userid,u.username) u.userid,u.username,u.designation, r.roleid,r.rolename
    FROM public.wms_userrole ur 
    left join public.wms_role r on r.roleid = ur.roleid
    LEFT JOIN public.wms_user u ON ur.userid=u.userid
    WHERE ur.roleid = any($1) and u.useractive=true
    order by u.username`,
      [roleId],
    );
  } else if (searchtype === 'duandrole' && duId && roleId) {
    result = await query(
      `
    SELECT DISTINCT ON (u.userid,u.username) u.userid,u.username,u.designation,u.duid,u.mappedduid, r.roleid,r.rolename
    FROM public.mst_deliveryunit du
    LEFT JOIN public.org_mst_deliveryunit odu ON du.duid = odu.itrackduid
    LEFT JOIN public.wms_user u ON odu.duid = u.duid
    left join public.wms_userrole ur on ur.userid = u.userid
    left join public.wms_role r on r.roleid = ur.roleid
    WHERE (u.duid = any($1) OR u.mappedduid::bigint[] && ARRAY[$1]::bigint[]) and ur.roleid = any($2) and u.useractive=true
    order by u.username`,
      [duId, roleId],
    );
  }
  return result;
}
