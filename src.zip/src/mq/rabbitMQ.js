import amqp from 'amqplib';
import { appConfig } from '../config/app.js';
import logger from '../modules/utils/logs/index.js';

const config = {
  protocol: appConfig.rabbitMQ.protocol,
  hostname: appConfig.rabbitMQ.host,
  port: appConfig.rabbitMQ.port,
  username: appConfig.rabbitMQ.username,
  password: appConfig.rabbitMQ.password,
  vhost: appConfig.rabbitMQ.virtualHost,
};

// eslint-disable-next-line import/no-mutable-exports
export let connection;

export const establishConnection = reconnect => {
  return new Promise(resolve => {
    amqp
      .connect(config)
      .then(conn => {
        connection = conn;
        conn.on('error', function (e) {
          logger.info('Error occurred in AMPQ', e.message ? e.message : e);
        });

        conn.on('close', function (e) {
          logger.info('connection closed', e.message ? e.message : e);
          logger.info('Reconnecting AMPQ in 5 seconds ...');
          setTimeout(reconnect, 5000);
        });
        logger.info('MQ Connection Established');
        resolve();
      })
      .catch(e => {
        logger.info('connection failed', e.message ? e.message : e);
        logger.info('Reconnecting AMPQ in 5 seconds ...');
        setTimeout(reconnect, 5000);
      });
  });
};

export const listenToQueue = (queue, callback) => {
  return new Promise(async (resolve, reject) => {
    try {
      const channel = await connection.createChannel();
      channel.consume(queue, function (payload) {
        logger.info('Message received');
        try {
          const data = JSON.parse(payload.content.toString());
          callback(data)
            .then(() => {
              channel.ack(payload);
              logger.info('Acknowledged message');
            })
            .catch(e => {
              logger.info('Acknowledged message with error');
              channel.ack(payload);
              logger.info(e.message ? e.message : e);
            });
        } catch (e) {
          logger.info('JSON parsing issue', e.message ? e.message : e);
          logger.info('Acknowledged message with error');
          channel.ack(payload);
        }
      });
      logger.info(`Listenning to ${queue}`);
      resolve(`Listenning to ${queue}`);
    } catch (e) {
      logger.info('listenToQueue failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

export const sendToQueue = (queue, data) => {
  return new Promise(async (resolve, reject) => {
    try {
      const channel = await connection.createChannel();
      channel.sendToQueue(queue, Buffer.from(JSON.stringify(data)));
      logger.info('Message sent');
      resolve();
    } catch (e) {
      logger.info('sendToQueue failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

export const closeConnection = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      await connection.close();
      resolve();
    } catch (e) {
      logger.info('closeConnection failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};
