import { ServiceBusClient } from '@azure/service-bus';
import { appConfig } from '../config/app.js';
import logger from '../modules/utils/logs/index.js';

// eslint-disable-next-line import/no-mutable-exports
export let connection;

export const establishConnection = () => {
  return new Promise((resolve, reject) => {
    try {
      connection = new ServiceBusClient(appConfig.azureSB.conString, {
        retryOptions: {
          maxRetries: 1,
        },
      });
      logger.info('MQ Connection Established');
      resolve();
    } catch (e) {
      logger.info('connection failed', e.message ? e.message : e);
      reject(e);
    }
  });
};

export const listenToQueue = (queue, callback) => {
  return new Promise((resolve, reject) => {
    try {
      const receiver = connection.createReceiver(queue, {
        receiveMode: 'receiveAndDelete',
      });
      receiver.subscribe({
        processMessage: payload => {
          logger.info('Message received');
          try {
            const data =
              Object.prototype.toString.call(payload.body) == '[object String]'
                ? JSON.parse(payload.body)
                : payload.body;
            callback(data)
              .then(() => {
                logger.info('Acknowledged message');
              })
              .catch(e => {
                logger.info('Acknowledged message with error');
                logger.info(e.message ? e.message : e);
              });
          } catch (e) {
            logger.info('Acknowledged message with error');
            logger.info('JSON parsing issue', e.message ? e.message : e);
          }
        },
        processError: args => {
          logger.info(args.error, 'Azure SB');
        },
      });
      logger.info(`Listenning to ${queue}`);
      resolve(`Listenning to ${queue}`);
    } catch (e) {
      logger.info('listenToQueue failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

export const sendToQueue = (queue, data) => {
  return new Promise(async (resolve, reject) => {
    try {
      await establishConnection();
      const sender = connection.createSender(queue);
      await sender.sendMessages({ body: JSON.stringify(data) });
      logger.info('Message sent');
      resolve();
    } catch (e) {
      logger.info('sendToQueue failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

export const GetallMessages = queue => {
  return new Promise(async (resolve, reject) => {
    try {
      const queueReceiver = connection.createReceiver(queue);
      const Messages = await queueReceiver.peekMessages(10000);
      const msgs = [];
      Messages.forEach(element => {
        msgs.push(element.body);
      });
      resolve(msgs);
    } catch (e) {
      logger.info('sendToQueue failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

export const closeConnection = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      await connection.close();
      resolve();
    } catch (e) {
      logger.info('closeConnection failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};
