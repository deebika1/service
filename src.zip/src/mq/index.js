import axios from 'axios';
import * as rmq from './rabbitMQ.js';
import * as asb from './azureSB.js';
import { appConfig } from '../config/app.js';
import logger from '../modules/utils/logs/index.js';

export const establishConnection = () => {
  return new Promise(async (resolve, reject) => {
    try {
      switch (appConfig.MQ) {
        case 'rmq':
          // eslint-disable-next-line no-lone-blocks
          {
            if (rmq.connection) {
              resolve();
            } else {
              rmq
                .establishConnection(establishConnection)
                .then(() => {
                  resolve();
                })
                .catch(e => {
                  logger.info(
                    'rmq connection failed',
                    e.message ? e.message : e,
                  );
                  reject(e.message ? e.message : e);
                });
            }
          }
          break;
        case 'asb':
          // eslint-disable-next-line no-lone-blocks
          {
            if (asb.connection) {
              resolve();
            } else {
              asb
                .establishConnection()
                .then(async () => {
                  resolve();
                })
                .catch(e => {
                  logger.info(
                    'asb connection failed',
                    e.message ? e.message : e,
                  );
                  reject(e.message ? e.message : e);
                });
            }
          }
          break;
        default:
          reject(
            `Messaging queue was not found in the supported list${appConfig.MQ}`,
          );
      }
    } catch (e) {
      logger.info('establishConnection failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

export const closeConnection = async () => {
  switch (appConfig.MQ) {
    case 'rmq':
      if (rmq.connection) {
        return rmq.closeConnection();
      }
      return Promise.resolve();

    case 'asb':
      if (asb.connection) {
        return asb.closeConnection();
      }
      return Promise.resolve();

    default:
      return Promise.reject(
        'Messaging queue was not found in the supported list',
        appConfig.MQ,
      );
  }
};

export const sendToQueue = async (queueName, data) => {
  await establishConnection();
  switch (appConfig.MQ) {
    case 'rmq':
      return rmq.sendToQueue(queueName, data);
    case 'asb':
      return asb.sendToQueue(queueName, data);
    default:
      return Promise.reject(
        'Messaging queue was not found in the supported list',
        appConfig.MQ,
      );
  }
};

export const sendToNotificationQueue = async data => {
  await establishConnection();
  switch (appConfig.MQ) {
    case 'rmq':
      return rmq.sendToQueue(appConfig.rabbitMQ.queues.action, data);
    case 'asb':
      return asb.sendToQueue(appConfig.azureSB.queues.action, data);
    default:
      return Promise.reject(
        'Messaging queue was not found in the supported list',
        appConfig.MQ,
      );
  }
};

export const sendToTaskQueue = data => {
  return new Promise(async resolve => {
    switch (appConfig.MQ.toLowerCase()) {
      case 'rmq':
        await sendToQueue(process.env.RMQ_CAMUNDA_TASK_EXCHANGE, data);
        break;
      case 'asb':
        await sendToQueue(process.env.ASB_TASK_QUEUE, data);
        break;
      default:
    }
    resolve(true);
  });
};

export const GetAllMsgInTaskQueue = () => {
  return new Promise(async resolve => {
    try {
      switch (appConfig.MQ.toLowerCase()) {
        case 'asb':
          await establishConnection();
          const messages = await asb.GetallMessages(process.env.ASB_TASK_QUEUE);
          resolve({ status: true, message: messages });
          break;
        case 'rmq':
          const url = appConfig.rabbitMQ.getQueueMsgs;
          const data = JSON.stringify({
            vhost: process.env.RMQ_VH,
            name: process.env.RMQ_CAMUNDA_TASK_EXCHANGE,
            truncate: '50000',
            ackmode: 'ack_requeue_true',
            encoding: 'auto',
            count: '9999999',
          });
          const config = {
            method: 'post',
            maxBodyLength: Infinity,
            url,
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Basic ${btoa(
                `${appConfig.rabbitMQ.username}:${appConfig.rabbitMQ.password}`,
              )}`,
            },
            data,
          };
          axios
            .request(config)
            .then(result => {
              const msgs = [];
              result.data.forEach(element => {
                msgs.push(element.payload);
              });
              resolve({ status: true, message: msgs });
            })
            .catch(error => {
              logger.info(error);
              resolve({
                status: false,
                message: error.message ? error.message : error,
              });
            });
          break;
        default:
      }
    } catch (e) {
      resolve({ status: false, message: e.message ? e.message : e });
    }
  });
};

export const sendToFTPOUTQueue = data => {
  return new Promise(async (resolve, reject) => {
    try {
      await establishOnlyRMQConnection();
      await rmq.sendToQueue(process.env.RMQ_FTP_ADAPTER, data);
      resolve(true);
    } catch (err) {
      reject(err);
    }
  });
};

export const establishRMQConnection = () => {
  return new Promise(async (resolve, reject) => {
    try {
      if (rmq.connection) {
        resolve();
      } else {
        rmq
          .establishConnection(establishConnection)
          .then(() => {
            resolve();
          })
          .catch(e => {
            logger.info('rmq connection failed', e.message ? e.message : e);
            reject(e.message ? e.message : e);
          });
      }
    } catch (e) {
      logger.info('establishConnection failed', e.message ? e.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

export const establishOnlyRMQConnection = () => {
  return new Promise(async (resolve, reject) => {
    try {
      if (rmq.connection) {
        resolve();
      } else {
        rmq
          .establishConnection(establishOnlyRMQConnection)
          .then(() => {
            resolve();
          })
          .catch(e => {
            logger.info('rmq connection failed', e.message ? e.message : e);
            reject(e.message ? e.message : e);
          });
      }
    } catch (e) {
      logger.info(
        'establishOnlyRMQConnection failed',
        e.message ? e.message : e,
      );
      reject(e.message ? e.message : e);
    }
  });
};

export const sendToExternalTaskQueue = async data => {
  switch (appConfig.MQ) {
    case 'rmq':
      await establishConnection();
      return rmq.sendToQueue(process.env.RMQ_EXTERNAL_TASK_QUEUE, data);
    case 'asb':
      return asb.sendToQueue(process.env.ASB_EXTERNAL_TASK_QUEUE, data);
    default:
      return Promise.reject(
        'Messaging queue was not found in the supported list',
        appConfig.MQ,
      );
  }
};
