import * as socketIO from 'socket.io';
import logger from '../modules/utils/logs/index.js';

const sockets = {};
let io;
// const messageQueue = {}; // Queue to store messages for disconnected sessions

/**
 * Establish the socket connection and configure namespaces, events, and message handling.
 */
export const establishSocket = server => {
  io = new socketIO.Server(server, {
    cors: {
      origin: '*', // Adjust origin for production environments
      methods: ['GET', 'POST'],
    },
    pingTimeout: 60000, // 60 seconds to avoid frequent timeouts
    pingInterval: 25000, // 25 seconds to check the connection health
  });
  const namespace = io.of('/iwmsTool'); // Create namespace for the tool
  namespace.on('connection', socket => {
    const sessionId = socket.handshake.query.sesId;
    const { profileId } = socket.handshake.query;

    console.log(
      `Socket connected: ${socket.id}, Session: ${sessionId}, profileId: ${profileId}`,
    );

    // Validate session ID
    if (!sessionId) {
      logger.info('Socket connection rejected: Missing session ID.');
      socket.disconnect(true);
      return;
    }

    // Register the socket for the session
    sockets[sessionId] = socket;
    sockets[profileId] = socket;
    logger.info(`Socket connected: ${socket.id}, Session: ${sessionId}`);

    // Process queued messages for the session
    // if (messageQueue[sessionId]?.length > 0) {
    //   logger.info(`Processing queued messages for session: ${sessionId}`);
    //   processQueuedMessages(sessionId, socket);
    // }

    // Handle disconnection
    socket.on('disconnect', reason => {
      if (sockets[sessionId] === socket) {
        delete sockets[sessionId]; // Cleanup the session map
      }
      if (sockets[profileId] === socket) {
        delete sockets[sessionId];
      }
      logger.info(`Socket disconnected: ${socket.id}, Reason: ${reason}`);
    });
  });
};

/**
 * Emit an event to a specific session. Queue messages if the socket is not connected.
 */
export const emitEvent = (sid, name, data) => {
  logger.info(`Emit function called for session: ${sid}`);
  const trimmedSid = sid?.trim();
  const socket = sockets[trimmedSid];

  if (socket?.connected) {
    try {
      logger.info(`Emitting event: ${name} to session: ${trimmedSid}`);
      socket.emit(name, data);
    } catch (error) {
      logger.info(
        `Error emitting event: ${name} to session: ${trimmedSid}. Error: ${error.message}`,
      );
    }
  } else {
    logger.info(
      `Socket not connected for session: ${trimmedSid}, queuing message.`,
    );

    // // Add the message to the queue
    // if (!messageQueue[trimmedSid]) {
    //   messageQueue[trimmedSid] = [];
    // }
    // messageQueue[trimmedSid].push({ name, data });

    // // Optional: Log the queue length for debugging
    // logger.info(
    //   `Queued messages for session ${trimmedSid}: ${messageQueue[trimmedSid].length}`,
    // );
    // // resend
    // // if (messageQueue[trimmedSid]?.length > 0) {
    // //   logger.info(`Processing queued messages for session: ${trimmedSid}`);
    // //   processQueuedMessages(trimmedSid, sockets);
    // // }
  }
};

export const emitEventByProfileId = (profileId, name, data) => {
  logger.info(`Emit function called for session: ${profileId}`);
  const socket = sockets[profileId];

  if (socket?.connected) {
    try {
      logger.info(`Emitting event: ${name} to Profile ID: ${profileId}`);
      socket.emit(name, data);
    } catch (error) {
      logger.info(
        `Error emitting event: ${name} to Profile ID: ${profileId}. Error: ${error.message}`,
      );
    }
  } else {
    logger.info(
      `Socket not connected for Profile ID: ${profileId}, queuing message.`,
    );
  }
};

/**
 * Process and emit queued messages for a session.
 */
// const processQueuedMessages = (sessionId, resockets) => {
//   const queue = messageQueue[sessionId];

//   while (queue?.length > 0) {
//     const { name, data } = queue.shift();
//     try {
//       const socket = resockets[sessionId];
//       if (socket?.connected) {
//         socket.emit(name, data);
//         logger.info(
//           `Successfully emitted queued event: ${name} to session: ${sessionId}`,
//         );
//       } else {
//         logger.info(
//           `Retry failed emitted queued event: ${name} to session: ${sessionId}`,
//         );
//       }
//     } catch (error) {
//       logger.info(
//         `Error emitting queued event: ${name} to session: ${sessionId}. Error: ${error.message}`,
//       );
//     }
//   }

//   // Clear the queue after processing
//   delete messageQueue[sessionId];
// };
