import msal from '@azure/msal-node';
import {
  ConflictResolutionMode,
  SearchFilter,
  ExchangeService,
  LogicalOperator,
  PropertySet,
  ItemSchema,
  OAuthCredentials,
  WellKnownFolderName,
  ImpersonatedUserId,
  ItemView,
  EmailMessageSchema,
  Uri,
  ConnectingIdType,
} from 'ews-javascript-api';
import { join, basename, dirname } from 'path';
import { readdir, readFile } from 'fs/promises';
import { createReadStream, statSync, rmdirSync } from 'fs';
import { fileURLToPath } from 'url';
import axios from 'axios';
import FormData from 'form-data';
import {
  getFilefromSFTPToDestPath,
  extractZip,
  checkDirectorySync,
} from '../filetransferkit/index.js';
import { query } from '../../database/postgres.js';
import { appConfig } from '../../config/app.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const tenantId = '70e2bc38-6b4b-43a1-9821-a49c0a744f3d';
const config = {
  auth: {
    clientId: '0e5590e2-c56b-4a25-bdd0-b5a2ad0369db',
    authority: `https://login.microsoftonline.com/${tenantId}`,
    clientSecret: '6JA8Q~cmBcNg-xr4OwTLKhc-YVsc1g0qNRAeea_~',
  },
  system: {
    loggerOptions: {
      loggerCallback(loglevel, message, containsPii) {
        console.log(loglevel, message, containsPii);
      },
      piiLoggingEnabled: false,
      logLevel: msal.LogLevel.Verbose,
    },
  },
};

const Guid = () => {
  let d = new Date().getTime(); // Timestamp
  let d2 =
    (typeof performance !== 'undefined' &&
      performance.now &&
      performance.now() * 1000) ||
    0; // Time in microseconds since page-load or 0 if unsupported
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = Math.random() * 16; // random number between 0 and 16
    if (d > 0) {
      // Use timestamp until depleted
      // eslint-disable-next-line no-bitwise
      r = (d + r) % 16 | 0;
      d = Math.floor(d / 16);
    } else {
      // Use microseconds since page-load if supported
      // eslint-disable-next-line no-bitwise
      r = (d2 + r) % 16 | 0;
      d2 = Math.floor(d2 / 16);
    }
    // eslint-disable-next-line no-bitwise
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
};

const DeleteTempPathifExits = temppath => {
  try {
    statSync(temppath);
    rmdirSync(temppath, { recursive: true });
    return true;
  } catch {
    return true;
  }
};

export const UnreadMailBySubject = async (toSearch, from, subject) => {
  return new Promise(async function (resolve, reject) {
    try {
      const cca = new msal.ConfidentialClientApplication(config);
      const token = await cca.acquireTokenByClientCredential({
        scopes: ['https://outlook.office365.com/.default'],
      });
      const svc = new ExchangeService();
      svc.Url = new Uri('https://outlook.office365.com/ews/exchange.asmx');
      svc.Credentials = new OAuthCredentials(token.accessToken);
      svc.ImpersonatedUserId = new ImpersonatedUserId(
        ConnectingIdType.SmtpAddress,
        toSearch,
      );
      svc.HttpHeaders.Add('X-AnchorMailbox', toSearch);
      const sf = new SearchFilter.SearchFilterCollection(
        LogicalOperator.And,
        new SearchFilter.IsEqualTo(EmailMessageSchema.From, from),
        new SearchFilter.ContainsSubstring(EmailMessageSchema.Subject, subject),
      );
      const result = await svc.FindItems(
        WellKnownFolderName.Inbox,
        sf,
        new ItemView(1000),
      );
      if (result.length > 0) {
        const email = result[0];
        email.IsRead = false;
        email.Update(ConflictResolutionMode.AutoResolve);
      }
      resolve(true);
    } catch (err) {
      reject(err);
    }
  });
};

export const mailReader = async () => {
  const cca = new msal.ConfidentialClientApplication(config);
  const token = await cca.acquireTokenByClientCredential({
    scopes: ['https://outlook.office365.com/.default'],
  });
  const sql = `select * from wms_mst_emailreader where isactive=true`;
  const EmailReaderMaster = await query(sql);
  for (let index = 0; index < EmailReaderMaster.length; index++) {
    const EmailReader = EmailReaderMaster[index];
    const svc = new ExchangeService();
    svc.Url = new Uri('https://outlook.office365.com/ews/exchange.asmx');
    svc.Credentials = new OAuthCredentials(token.accessToken);
    svc.ImpersonatedUserId = new ImpersonatedUserId(
      ConnectingIdType.SmtpAddress,
      EmailReader.searchmail,
    );
    svc.HttpHeaders.Add('X-AnchorMailbox', EmailReader.searchmail);
    const sf = new SearchFilter.SearchFilterCollection(
      LogicalOperator.And,
      new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, false),
      new SearchFilter.IsEqualTo(
        EmailMessageSchema.From,
        EmailReader.emailfrom,
      ),
      new SearchFilter.ContainsSubstring(
        EmailMessageSchema.Subject,
        EmailReader.emailsearch.subjectfilter,
      ),
    );
    const result = await svc.FindItems(
      WellKnownFolderName.Inbox,
      sf,
      new ItemView(1000),
    );
    if (result.totalCount > 0) {
      for (let ind = 0; ind < result.Items.length; ind++) {
        EmailReader.guid = Guid();
        const msg = result.Items[ind];
        let logDataId = 0;
        let issuccess = false;
        let remark = '';
        try {
          EmailReader.Subject = msg.Subject;
          await msg.Load(new PropertySet(ItemSchema.TextBody));
          logDataId = await logWriter({
            body: msg.TextBody.Text,
            subject: EmailReader.Subject,
            emailreaderid: EmailReader.id,
            id: logDataId,
            issuccess,
          });
          EmailReader.TextBody = msg.TextBody.Text;
          await msg.Load();
          let output = {};
          switch (EmailReader.emailsearch.type) {
            case 'CAMS':
              output = await CAMSPackageDownload(EmailReader);
              issuccess = output.issuccess;
              remark = output.message;
              msg.IsRead = true;
              msg.Update(ConflictResolutionMode.AutoResolve);
              break;
            case 'WOCreation':
              output = await WOCreation(msg, EmailReader);
              issuccess = output.issuccess;
              remark = output.message;
              msg.IsRead = true;
              msg.Update(ConflictResolutionMode.AutoResolve);
              break;
            default:
              throw new Error('No such search type implemented');
          }
        } catch (error) {
          issuccess = false;
          remark = error.message;
        } finally {
          logDataId = await logWriter({
            body: EmailReader.TextBody,
            subject: EmailReader.subject,
            emailreaderid: EmailReader.id,
            id: logDataId,
            issuccess,
            remark,
          });
          DeleteTempPathifExits(join(__dirname, EmailReader.guid));
        }
        // eslint-disable-next-line no-inner-declarations
        async function logWriter(reqData) {
          const sqlQuery = `select * from  insert_emailreadertran('${JSON.stringify(
            reqData,
          ).replace(/'/g, "''")}')`;
          const logData = await query(sqlQuery);
          return logData[0].insert_emailreadertran;
        }
      }
    }
  }
};

const findByPattern = async (dir, pattern) => {
  const files = await readdir(dir);
  return files.filter(x => {
    const regex = pattern;
    return regex.test(x);
  });
};

async function CAMSPackageDownload(EmailReader) {
  let { ftppath } = EmailReader.emailsearch;
  const { guid } = EmailReader;
  let Package = '';
  let PII = '';
  const regex = /Package:(.*.zip)/gs;
  let m = regex.exec(EmailReader.TextBody);
  if (m)
    m.forEach((match, groupIndex) => {
      Package = groupIndex == 1 ? match.trim() : Package;
    });
  const regex1 = /PII: ([a-zA-Z0-9]*)/gs;
  m = regex1.exec(EmailReader.TextBody);
  if (m)
    m.forEach((match, groupIndex) => {
      PII = groupIndex == 1 ? match.trim() : PII;
    });
  ftppath = ftppath.replace(';package;', Package);
  const source = ftppath;
  let destination = join(guid, basename(ftppath));
  const ftpCredentails = EmailReader.ftpdetails;
  destination = join(__dirname, destination);
  await checkDirectorySync(join(__dirname, guid));
  await getFilefromSFTPToDestPath(
    {
      host: ftpCredentails.host,
      port: ftpCredentails.port,
      username: ftpCredentails.username,
      password: ftpCredentails.password,
      retries: '2',
      retry_factor: '2',
      retry_minTimeout: '2000',
    },
    source,
    destination,
  );
  const data = new FormData();
  data.append('zip', createReadStream(destination));
  data.append('piid', PII);
  const output = await uploadCamsPackage(data);
  return output;
}

const uploadCamsPackage = Input => {
  return new Promise(resolve => {
    axios({
      method: 'POST',
      maxBodyLength: Infinity,
      url: `${appConfig.getUrl()}/api/master/uploadCamsPackage`,
      data: Input,
      headers: {
        ...Input.getHeaders(),
        Authorization:
          'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoid21zYXBwIiwiaWF0IjoxNjMzMzUxMTQzfQ.MgBfqlTAkK90Ks0Y6dnPBmGbju79zY-T2jQfb46jAUU',
      },
    })
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        resolve(err.response.data);
      });
  });
};

async function WOCreation(msg, EmailReader) {
  const subject = msg.Subject.split(' ');
  let { ftppath } = EmailReader.emailsearch;
  const { guid } = EmailReader;
  const regex = /correction \(([0-9].*)\)/gs;
  const m = regex.exec(EmailReader.TextBody);
  let correctioncount = 0;
  if (m)
    m.forEach((match, groupIndex) => {
      correctioncount = groupIndex == 2 ? match : correctioncount;
    });
  ftppath = ftppath.replace(';journal;', subject[0].toLowerCase());
  ftppath = ftppath.replace(';filename;', subject[1]);
  if (correctioncount > 0) {
    ftppath = ftppath.replace('.zip', `_${correctioncount}.zip`);
  }
  const source = ftppath;
  let destination = join(guid, basename(ftppath));
  const ftpCredentails = EmailReader.ftpdetails;
  destination = join(__dirname, destination);
  await checkDirectorySync(join(__dirname, guid));
  await getFilefromSFTPToDestPath(
    {
      host: ftpCredentails.host,
      port: ftpCredentails.port,
      username: ftpCredentails.username,
      password: ftpCredentails.password,
      retries: '2',
      retry_factor: '2',
      retry_minTimeout: '2000',
    },
    source,
    destination,
  );
  await extractZip(destination);
  const fileList = await findByPattern(
    destination.replace('.zip', ''),
    /xml_.*\.xml/gs,
  );
  let content = '';
  if (fileList.length > 0) {
    content = await readFile(
      join(destination.replace('.zip', ''), fileList[0]),
      'utf8',
    );
  }
  const data = new FormData();
  data.append('zip', createReadStream(destination));
  data.append('woType', EmailReader.wotype);
  data.append('jobType', EmailReader.jobtype);
  data.append('customer', EmailReader.customer);
  data.append('InPath', '');
  data.append('fileType', 'xml');
  data.append('journal', subject[0]);
  data.append('stageiterationcount', correctioncount + 1);
  data.append('articlename', subject[0] + subject[1]);
  data.append('content', content);
  data.append('stagename', EmailReader.stagename);
  const output = await readerWorkOrder(data);
  return output;
}

export const getBaseURL = (req, res) => {
  const baseurl = appConfig.getUrl();
  res.send({
    baseurl,
    dir: __dirname,
  });
};

const readerWorkOrder = woInput => {
  return new Promise(resolve => {
    axios({
      method: 'POST',
      maxBodyLength: Infinity,
      url: `${appConfig.getUrl()}/api/woi/readWorkorderInfo`,
      data: woInput,
      headers: {
        ...woInput.getHeaders(),
        Authorization:
          'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoid21zYXBwIiwiaWF0IjoxNjMzMzUxMTQzfQ.MgBfqlTAkK90Ks0Y6dnPBmGbju79zY-T2jQfb46jAUU',
      },
    })
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        resolve(err.response.data);
      });
  });
};
