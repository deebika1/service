import { createReadStream } from 'fs';
import { unlink } from 'fs/promises';
import FormData from 'form-data';
import { dirname, basename } from 'path';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../../database/postgres.js';
import {
  bookDetails,
  getBookDetailsTemplateForCupJournals,
  getIncomingFileDetailsForRunOnFile,
  getdmsType,
  getBookMasterDetailsTemplate,
} from '../bpmn/listener/create.js';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import { writeSmallFile } from '../utils/custom/io.js';
import { checkoutOpenKMFile } from '../utils/okm/index.js';
import * as azureHelper from '../utils/azure/index.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';
import * as localHelper from '../utils/local/index.js';

const service = new Service();

export const getAdditionalOptionList = (req, res) => {
  const getData = req.body;
  console.log(getData, 'dataaa');
  let sql = ``;
  if (getData.type === 'pitStop') {
    // sql = `SELECT pitstopprofileid as value, pitstopprofile as label FROM public.wms_mst_pitstopprofile
    //     ORDER BY pitstopprofileid ASC `;
    sql = `select ttrn.id as value, ttrn.profilevalue as label,ttrn.duid from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn 
      on tmst.profileid=ttrn.profileid where tmst.profilename='pitStop' `;
  } else if (getData.type === 'isVerso') {
    sql = `SELECT versoid as value, versoname as label FROM public.wms_mst_verso ORDER BY versoid ASC `;
  } else if (getData.type === 'isRecto') {
    sql = `SELECT rectoid as value, rectoname as label FROM public.wms_mst_recto ORDER BY rectoid ASC `;
  } else if (getData.type === 'xmlTemplate') {
    sql = `SELECT xmltemplateid as value, xmltemplate as label FROM public.wms_mst_xml_template ORDER BY xmltemplateid ASC `;
  } else if (getData.type === 'dispatchType') {
    sql = `SELECT dispatchtypeid as value, dispatchtype as label FROM public.wms_mst_dispatchtype
        ORDER BY dispatchtypeid ASC `;
  } else if (getData.type === 'colorProfile') {
    sql = `SELECT colorprofileid as value, colorprofile as label FROM public.wms_mst_colorprofile
        ORDER BY colorprofileid ASC`;
  } else if (getData.type === 'bookCategory') {
    sql = `SELECT bookcategoryid as value, bookcategory as label FROM public.wms_mst_bookcategory ORDER BY bookcategoryid ASC `;
  } else if (getData.type === 'cssValue') {
    sql = `SELECT cssvalueid as value, cssvalue as label FROM public.wms_mst_cssvalue ORDER BY cssvalueid ASC `;
  } else if (getData.type === 'waterMark') {
    sql = `SELECT watermarkid as value, watermark as label FROM public.wms_mst_watermark ORDER BY watermarkid ASC `;
  } else if (getData.type === 'smartMetadata') {
    sql = `SELECT smartmetadataid as value, smartmetadata as label FROM public.wms_mst_smartmetadata ORDER BY smartmetadataid ASC `;
  } else if (getData.type === 'dtd') {
    sql = `SELECT dtdid as value, dtdname as label FROM public.pp_mst_dtd ORDER BY dtdid ASC  `;
  } else if (getData.type === 'additionalinfo') {
    sql = `SELECT service.workorderid,service.wfid,workflow.config FROM public.wms_workorder_service as service 
        left join wms_workflow as workflow on workflow.wfid = service.wfid
        where service.workorderid = ${getData.workorderId}`;
  } else if (
    getData.type === 'addpdf' ||
    getData.type === 'print' ||
    getData.type === 'onlinepdf'
  ) {
    sql = `select trndrop.id as value, trndrop.value as label from wms_mst_dropdown as drops
        join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
        where drops.fieldname like '%${getData.fieldName}%'`;
  } else if (
    getData.type === 'fpprofileid' ||
    getData.type === 'rvsprofileid' ||
    getData.type === 's300id' ||
    getData.type === 'o300id' ||
    getData.type === 'printprofile' ||
    getData.type === 'onlineprofile'
  ) {
    sql = `select trnpitstop.id as value, trnpitstop.profilevalue  as label from mst_pitstopprofile as pitstop
  join trn_pitstopprofiledetail as trnpitstop on trnpitstop.profileid = pitstop.profileid
  where pitstop.profilename like '%${getData.fieldName}%' and trnpitstop.duid = ${getData.duId}`;
  } else if (getData.type === 'BookMasterMap') {
    sql = `SELECT trndrop.id as value, trndrop.value as label 
           FROM wms_mst_dropdown as drops
           JOIN wms_Trn_dropdown as trndrop ON trndrop.dropid = drops.dropid
           WHERE drops.fieldname = 'BookMasterMap'
           ORDER BY trndrop.id ASC`;
  }
  console.log(sql, 'sql for adiitional');
  query(sql)
    .then(data => {
      console.log(data, 'data forrrr');
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const createAdditionalInfoList = (req, res) => {
  const { additionalList, taskDetails } = req.body;
  console.log(additionalList, taskDetails, 'taskDetailstaskDetails');
  const sql = `INSERT INTO public.wms_workorder_additionalinfo(
        workorderid, pitstopprofileid, versoid, rectoid, xmltemplateid, lastpageno, splittingid, indexcorrectionid, mscropneededid, dispatchtypeid, colorprofileid, ocisbn, bookcategoryid, cssvalueid, style1, style2, style3, style4, style5, style6, hardbackisbn, paperbackisbn,medicalbook,watermarkid,smartmetadataid,dtdid,onlinepdfid,printid,additionalpdfid,pdfless,fpprofileid,rvsprofileid,s300id,o300id,bookprintid)
       VALUES (${taskDetails.workorderid ? taskDetails.workorderid : null}, ${
    additionalList.pitStop ? additionalList.pitStop : null
  }, ${additionalList.isVerso ? additionalList.isVerso : null}, ${
    additionalList.isRecto ? additionalList.isRecto : null
  }, ${additionalList.xmlTemplate ? additionalList.xmlTemplate : null}, ${
    additionalList.pageNumber ? additionalList.pageNumber : null
  }, ${additionalList.isSplitting ? additionalList.isSplitting : null}, ${
    additionalList.isIndex ? additionalList.isIndex : null
  }, 
        ${additionalList.msCrop ? additionalList.msCrop : null}, ${
    additionalList.dispatchType ? additionalList.dispatchType : null
  }, ${additionalList.colorProfile ? additionalList.colorProfile : null}, ${
    additionalList.ocIsbn ? additionalList.ocIsbn : null
  }, ${additionalList.bookCategory ? additionalList.bookCategory : null}, ${
    additionalList.cssValue ? additionalList.cssValue : null
  }, '${additionalList.style1 ? additionalList.style1 : ''}', 
        '${additionalList.style2 ? additionalList.style2 : ''}', '${
    additionalList.style3 ? additionalList.style3 : ''
  }', '${additionalList.style4 ? additionalList.style4 : ''}', '${
    additionalList.style5 ? additionalList.style5 : ''
  }', '${additionalList.style6 ? additionalList.style6 : ''}',${
    additionalList.hardbackIssn ? additionalList.hardbackIssn : null
  }, ${additionalList.paperbackISBN ? additionalList.paperbackISBN : null},${
    additionalList.isMedical ? additionalList.isMedical : null
  },${additionalList.waterMark ? additionalList.waterMark : null},${
    additionalList.smartMetadata ? additionalList.smartMetadata : null
  },${additionalList.dtd ? additionalList.dtd : null},${
    additionalList.onlinepdf ? additionalList.onlinepdf : null
  },${additionalList.print ? additionalList.print : null},${
    additionalList.addpdf ? additionalList.addpdf : null
  },${additionalList.pdfless ? additionalList.pdfless : null},${
    additionalList.fpprofileid ? additionalList.fpprofileid : null
  },${additionalList.rvsprofileid ? additionalList.rvsprofileid : null},
  ${additionalList.s300id ? additionalList.s300id : null},${
    additionalList.o300id ? additionalList.o300id : null
  },${additionalList.printprofile ? additionalList.printprofile : null});`;
  console.log(sql, 'create additional info');
  query(sql)
    .then(() => {
      res.status(200).json({
        data: [],
        message: 'Additional Info created successfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const updateAdditionalInfoList = (req, res) => {
  const { additionalList, taskDetails } = req.body;
  console.log(additionalList, taskDetails, 'update');
  const sql = `UPDATE public.wms_workorder_additionalinfo
	SET  workorderid=${
    taskDetails.workorderid ? taskDetails.workorderid : null
  }, pitstopprofileid=${
    additionalList.pitStop ? additionalList.pitStop : null
  }, versoid=${
    additionalList.isVerso ? additionalList.isVerso : null
  }, rectoid=${
    additionalList.isRecto ? additionalList.isRecto : null
  }, xmltemplateid=${
    additionalList.xmlTemplate ? additionalList.xmlTemplate : null
  }, 
    lastpageno=${
      additionalList.pageNumber ? additionalList.pageNumber : null
    }, splittingid= ${
    additionalList.isSplitting ? additionalList.isSplitting : null
  }, indexcorrectionid=${
    additionalList.isIndex ? additionalList.isIndex : null
  }, mscropneededid= ${additionalList.msCrop ? additionalList.msCrop : null},
     dispatchtypeid=${
       additionalList.dispatchType ? additionalList.dispatchType : null
     }, colorprofileid=${
    additionalList.colorProfile ? additionalList.colorProfile : null
  }, ocisbn=${
    additionalList.ocIsbn ? additionalList.ocIsbn : null
  }, bookcategoryid=${
    additionalList.bookCategory ? additionalList.bookCategory : null
  }, cssvalueid=${additionalList.cssValue ? additionalList.cssValue : null}, 
     style1='${additionalList.style1 ? additionalList.style1 : ''}', style2='${
    additionalList.style2 ? additionalList.style2 : ''
  }', style3='${additionalList.style3 ? additionalList.style3 : ''}', style4='${
    additionalList.style4 ? additionalList.style4 : ''
  }', style5='${additionalList.style5 ? additionalList.style5 : ''}', style6='${
    additionalList.style6 ? additionalList.style6 : ''
  }',
       hardbackisbn=${
         additionalList.hardbackIssn ? additionalList.hardbackIssn : null
       }, paperbackisbn=${
    additionalList.paperbackISBN ? additionalList.paperbackISBN : null
  },medicalbook=${
    additionalList.isMedical ? additionalList.isMedical : null
  }, watermarkid=${
    additionalList.waterMark ? additionalList.waterMark : null
  },smartmetadataid=${
    additionalList.smartMetadata ? additionalList.smartMetadata : null
  },dtdid =${additionalList.dtd ? additionalList.dtd : null},
  onlinepdfid =${
    additionalList.onlinepdf || additionalList.onlineprofile || null
  },printid =${
    additionalList.print || additionalList.printprofile || null
  },additionalpdfid =${additionalList.addpdf ? additionalList.addpdf : null},
  pdfless =${additionalList.pdfless ? additionalList.pdfless : null},

  fpprofileid = ${
    additionalList.fpprofileid ? additionalList.fpprofileid : null
  },
  rvsprofileid =${
    additionalList.rvsprofileid ? additionalList.rvsprofileid : null
  },
  s300id = ${additionalList.s300id ? additionalList.s300id : null},
  o300id = ${additionalList.o300id ? additionalList.o300id : null},
  bookprintid = ${
    additionalList.printprofile ? additionalList.printprofile : null
  }
	WHERE additionalinfoid=${taskDetails.additionalinfoid};`;
  console.log(sql, 'update aditional ino');
  query(sql)
    .then(() => {
      res.status(200).json({
        data: [],
        message: 'Additional Info updated successfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const BookDetailsTextForActivites = async (req, res) => {
  try {
    const { workOrderId, ext } = req.body;
    const result = await bookDetails(workOrderId);
    let resultCupJounrals = [];
    let runonResult = [];
    let runon = false;
    let bookMasterDetails = [];
    if (result && result.length > 0 && result[0].wotype == 'Journal') {
      resultCupJounrals = await getBookDetailsTemplateForCupJournals(
        workOrderId,
      );
    }
    if (
      req.body &&
      Object.keys(req.body).includes('woIncomingFileId') &&
      req.body.woIncomingFileId &&
      req.body.woIncomingFileId != null
    ) {
      runonResult = await getIncomingFileDetailsForRunOnFile(
        workOrderId,
        req.body.woIncomingFileId,
      );
    }
    if (
      result &&
      result.length > 0 &&
      result[0].wotype == 'Book' &&
      result[0].wfid == 29
    ) {
      bookMasterDetails = await getBookMasterDetailsTemplate(
        workOrderId,
        req.body.stagename,
        req.body.activityname,
      );
    }
    runon = !!(runonResult && runonResult.length > 0);
    result[0].runon = runon;
    const formatBookDetails = await getBookDetailsTemplate(
      result[0],
      req.body,
      resultCupJounrals,
      ext,
      bookMasterDetails,
    );

    console.log('formatBookDetails', formatBookDetails);
    res
      .status(200)
      .send({ message: 'Success', status: true, data: formatBookDetails });
  } catch (error) {
    res.status(400).send({ message: error, status: false, data: [] });
  }
};

export const updateBookDetailsForActivites = async (req, res) => {
  const { workOrderId } = req.body;
  const dmsType = await getdmsType(workOrderId);
  const generateBookDetailsArray = [];
  let incomingBookDetailsForActivities = [];
  let formatBookDetails = {};
  const bookDetailsName = [];
  const sql = `select * from wms_workflow_eventlog as eventlog
            left join wms_workflowdefinition as workflowdef on workflowdef.wfdefid = eventlog.wfdefid
            left join wms_mst_stage as stage on stage.stageid =workflowdef.stageid
            left join wms_mst_activity as activity on activity.activityid = workflowdef.activityid
            where eventlog.workorderid =${workOrderId} and (eventlog.activitystatus != 'Completed' and activitystatus != 'Rejected' and activitystatus != 'Reset') `;
  console.log(sql, 'sllleee');
  await query(sql)
    .then(async response => {
      response.forEach(list => {
        // updated for fileconfig restructure
        list.fileconfig = ReStructureFileConfig(list.fileconfig);
        const fileConfigKeys =
          list.fileconfig && list.fileconfig.fileTypes
            ? Object.keys(list.fileconfig.fileTypes)
            : [];

        for (let i = 0; i < fileConfigKeys.length; i++) {
          const fileDetails =
            list.fileconfig.fileTypes[fileConfigKeys[i]].files;

          for (let j = 0; j < fileDetails.length; j++) {
            if (
              fileDetails[j].custom &&
              fileDetails[j].custom.generate_bookdetails
            ) {
              bookDetailsName.push(fileDetails[j].name);
              generateBookDetailsArray.push(list);
            }
          }
        }
      });

      const result = await bookDetails(workOrderId);
      console.log(bookDetailsName, 'bookDetailsName');
      const uniqueBookDetails = [...new Set(bookDetailsName)];
      console.log(uniqueBookDetails, 'uniqueBookDetails');
      if (
        uniqueBookDetails[0] != 'Bookdetails.txt' &&
        uniqueBookDetails[0] != 'bookdetails.txt' &&
        uniqueBookDetails[0] != 'BookDetails.txt'
      ) {
        /* log removed */
      } else {
        const bookDetailsUuid = [
          ...new Set(generateBookDetailsArray.map(list => list.wfeventid)),
        ];
        const incomingbookDetails = await getIncomingDetailsForActivity(
          bookDetailsUuid,
          workOrderId,
          uniqueBookDetails[0],
        );
        console.log(incomingbookDetails, 'incomingbookDetails');

        const uniqueRepoFileUuid = [
          ...new Set(incomingbookDetails.map(list => list.repofileuuid)),
        ];
        console.log(uniqueRepoFileUuid, 'uniqueRepoFileUuid');
        incomingBookDetailsForActivities = [];
        let unique = false;
        uniqueRepoFileUuid.forEach(uuid => {
          let count = 0;
          let Uuid = uuid;
          incomingbookDetails.forEach(list => {
            if (list.repofileuuid === Uuid) {
              count += 1;
              unique = true;
            }
            if (count == 1 && unique == true) {
              incomingBookDetailsForActivities.push(list);
            }
            unique = false;
          });
          Uuid = '';
        });
        console.log(
          incomingBookDetailsForActivities,
          'incomingBookDetailsForActivities',
        );
        if (result.length > 0 && generateBookDetailsArray.length > 0) {
          formatBookDetails = await getBookDetailsTemplate(
            result[0],
            generateBookDetailsArray[0],
          );
        }
        // for (var i = 0; i < incomingBookDetailsForActivities.length; i++) {
        //     console.log(incomingBookDetailsForActivities[i], "incomingBookDetailsForActivities333")
        //     if (incomingBookDetailsForActivities[i].repofileuuid) {
        //         console.log("check out files")
        //         await checkOutFiles(incomingBookDetailsForActivities[i], formatBookDetails)
        //     }
        // }
        for (let i = 0; i < incomingBookDetailsForActivities.length; i++) {
          if (incomingBookDetailsForActivities[i].repofileuuid) {
            console.log('write filee');
            await writeSmallFile(
              `upload/${incomingBookDetailsForActivities[i].wfeventid}/Bookdetails.txt`,
              formatBookDetails,
              `upload/${incomingBookDetailsForActivities[i].wfeventid}`,
            );
          }
        }
        for (let i = 0; i < incomingBookDetailsForActivities.length; i++) {
          console.log(incomingBookDetailsForActivities[i], '55555');
          if (incomingBookDetailsForActivities[i].repofileuuid) {
            console.log('checkin filee');
            switch (dmsType) {
              case 'azure':
                await azureHelper._upload(
                  {
                    name: 'Bookdetails.txt',
                    tempFilePath: `upload/${incomingBookDetailsForActivities[i].wfeventid}/Bookdetails.txt`,
                  },
                  incomingBookDetailsForActivities[i].repofilepath,
                );
                break;
              case 'local':
                await localHelper._uploadlocal(
                  {
                    name: 'Bookdetails.txt',
                    tempFilePath: `upload/${incomingBookDetailsForActivities[i].wfeventid}/Bookdetails.txt`,
                  },
                  incomingBookDetailsForActivities[i].repofilepath,
                );
                break;
              default:
                await checkoutOpenKMFile(
                  incomingBookDetailsForActivities[i].repofileuuid,
                );
                await checkInFiles(
                  `upload/${incomingBookDetailsForActivities[i].wfeventid}/Bookdetails.txt`,
                  incomingBookDetailsForActivities[i].repofileuuid,
                );
                break;
            }
          }
        }
      }
      res.status(200).json({
        data: {
          customconfig: generateBookDetailsArray || [],
          bookDetails: result || [],
          template: formatBookDetails || [],
          incomingfileDetails: incomingBookDetailsForActivities || [],
          status: true,
        },
      });
    })
    .catch(error => {
      console.log(error, 'errroro');
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getIncomingDetailsForActivity = async (
  uuid,
  workOrderId,
  bookName,
) => {
  return new Promise(async (resolve, reject) => {
    let condition = '';
    uuid.forEach((item, i) => {
      condition +=
        uuid.length - 1 !== i
          ? `eventlog.wfeventid = '${item}' OR `
          : `eventlog.wfeventid = '${item}'`;
    });
    console.log(condition, 'conddiii');
    const sql = `select eventlog.wfeventid,eventlog.workorderid,eventlog.activitystatus,eventlog.woincomingfileid,eventlog.parentinstanceid,eventlog.taskinstanceid,
    eventlog.eventdata,trnfile.repofileuuid,trnfile.repofilepath,trnfile.woincomingfileid,filetype.filetypeid
    from wms_workflow_eventlog as eventlog
    left join wms_workflowactivitytrn_file_map as trnfile on trnfile.wfeventid = eventlog.wfeventid
    left join wms_workorder_incomingfiledetails as incomingdetails on incomingdetails.woincomingfileid = trnfile.woincomingfileid
    left join pp_mst_filetype as filetype on filetype.filetypeid = incomingdetails.filetypeid
    where eventlog.workorderid =${workOrderId} and (eventlog.activitystatus != 'Completed' and eventlog.activitystatus != 'Rejected' and eventlog.activitystatus != 'Reset') ${
      condition ? `${' AND ('}${condition})` : ''
    } and (repofilepath like '%${bookName}%' or repofilepath like '%bookdetails%')`;
    console.log(sql, 'update aditional ino');
    query(sql)
      .then(response => {
        resolve(response);
      })
      .catch(error => {
        reject(error);
      });
  });
};

export const checkOutFiles = async file => {
  console.log(file, 'filee for checkout and check in');
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };

  const url = `${
    config.openKM.base_url + config.openKM.uri.downloadwithCheckout
  }/${file.repofileuuid}`;

  try {
    const response = await service.get(`${url}`, headers);
    // if(response){
    // await writeSmallFile(`upload/${file.wfeventid}/Bookdetails.txt`, content, `upload/${file.wfeventid}`)
    // await checkInFiles(`upload/${file.wfeventid}/Bookdetails.txt`, file.repofileuuid)
    // }
    console.log(response, 'response for check out');
  } catch (e) {
    console.log(e, 'error for check in files');
  }
};

export const checkInFiles = async (src, uuid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('content', createReadStream(src));
      formData.append('docId', uuid);
      const header = {
        'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
      };
      const result = await service.upload(
        `${config.openKM.base_url}${config.openKM.uri.checkin}`,
        formData,
        header,
      );
      console.log(result, 'result for check in');
      // fs.unlink(src, function (err) {
      //     if (err) reject(err);
      //
      // });
      resolve();
    } catch (e) {
      if (e?.message?.data) {
        // for dms error message
        e.message = e.message.data.includes('FileNotFoundException')
          ? 'Uploading was interrupted. Please retry the current action'
          : e.message.data;
      }
      reject(e);
    }
  });
};

export const getBookDetailsTemplate = async (
  details,
  taskDetails,
  resultCupJounrals,
  ext,
  bookMasterDetails,
) => {
  return new Promise(async resolve => {
    let template = '';
    let bookDetailsTemplateXml = {};
    if (details) {
      if (details.wotype == 'Book') {
        const bookDetailsOut = [];
        if (details.wfid == 48) {
          if (ext == '.xml') {
            const xmlTemplate = {
              ul: `<BookDetails>{{li}}</BookDetails>`,
              li: `
                <AuthorName>Sakthivel</AuthorName>
                <ISBN>{{isbn}}</ISBN>
                <OnlinePitstopProfile>{{onlineprofile}}</OnlinePitstopProfile>
                <PrintPitstopProfile>{{printprofile}}</PrintPitstopProfile>
                <EISBN>{{eisbn}}</EISBN>
                <colorProfile>4C (CMYK)</colorProfile>
                <CustomerCode>Elsevier</CustomerCode>
                <Edition>{{edition}}</Edition>
                <Title>{{title}}</Title>
                <PublisherName>Elsevier</PublisherName>
                <PublisherLocation>{{country}}</PublisherLocation>
                <ActivityName>{{activityAlias}}</ActivityName>
                <StageName>{{stagename}}</StageName>`,
            };
            const {
              bookcode,
              title,
              printisbn,
              eisbn,
              printprofile,
              onlineprofile,
              edition,
            } = details;
            const { stagename, activityAlias } = taskDetails;
            bookDetailsOut.push(
              xmlTemplate.li
                .replace(/{{bookcode}}/, bookcode)
                .replace(/{{isbn}}/, printisbn)
                .replace(/{{title}}/, title)
                .replace(/{{eisbn}}/, eisbn)
                .replace(/{{edition}}/, edition)
                .replace(/{{printprofile}}/, printprofile)
                .replace(/{{onlineprofile}}/, onlineprofile)
                .replace(/{{stagename}}/, stagename)
                .replace(/{{activityAlias}}/, activityAlias),
            );

            template = xmlTemplate.ul.replace(
              /{{li}}/,
              bookDetailsOut.join('\n'),
            );
            console.log(template, 'template');
          }
        } else if (details.wfid == 29 && ext == '.xml') {
          template = bookMasterDetails[0].generate_bookmaster_xml;
        } else {
          // to be hanlded
          const style1 = details.style1 ? details.style1 : '';
          const style2 = details.style2 ? details.style2 : '';
          const style3 = details.style3 ? details.style3 : '';
          const style4 = details.style4 ? details.style4 : '';
          const style5 = details.style5 ? details.style5 : '';
          const style6 = details.style6 ? details.style6 : '';
          const css = details.css ? details.css : '';
          template =
            `Customer Name : ${details.customername}\r\n` +
            `Book Name : ${details.bookcode}\r\n` +
            `Activity Name : ${
              taskDetails.config && taskDetails.config.displayName
                ? taskDetails.config.displayName
                : taskDetails.activityname
            }\r\n` +
            `Stage Name : ${taskDetails.stagename}\r\n` +
            `Paper Back Number : ${details.paperbackno}\r\n` +
            `Hardback Number : ${details.hardbackno}\r\n` +
            `OC Number : ${details.ocno}\r\n` +
            `iAuthor : No` +
            `\r\n` +
            `Book Category : ${details.bookcategory}\r\n` +
            `Style1 : ${style1}\r\n` +
            `Style2 : ${style2}\r\n` +
            `Style3 : ${style3}\r\n` +
            `Style4 : ${style4}\r\n` +
            `Style5 : ${style5}\r\n` +
            `Style6 : ${style6}\r\n` +
            `CSS : ${css}\r\n` +
            `Numbered Box : none`;
        }
      } else if (details.wotype == 'Journal') {
        if (
          details.wfid == 41 ||
          details.wfid == 43 ||
          details.wfid == 45 ||
          details.wfid == 46 ||
          details.wfid == 47 ||
          details.wfid == 48
        ) {
          if (ext == '.xml') {
            const journalDetails = resultCupJounrals[0];
            console.log('journalDetails', journalDetails);
            const amoValue = journalDetails.amoid == 1 ? 'Yes' : 'No';
            const templatefilePath = journalDetails.templatefilepath
              ? journalDetails.templatefilepath.split('/')
              : '';
            const templatePathFileName = templatefilePath
              ? templatefilePath[templatefilePath.length - 1]
              : '';
            // const TemplateFilebaseName = templatePathFileName
            //   ? templatePathFileName.replace(extname(templatePathFileName), '')
            //   : '';
            const templateFileNamme = journalDetails.filename
              ? journalDetails.filename
              : templatePathFileName || '';
            const ceValue = journalDetails.celevelid == 1 ? 'No' : 'Yes';
            bookDetailsTemplateXml = {};
            bookDetailsTemplateXml.JournalAcronym =
              journalDetails.journalacronym;
            bookDetailsTemplateXml.bookcode = details.bookcode;
            bookDetailsTemplateXml.activityid = taskDetails.activityid
              ? taskDetails.activityid
              : taskDetails.activityId;
            bookDetailsTemplateXml.division = details.division;
            bookDetailsTemplateXml.stage = taskDetails.stagename;
            bookDetailsTemplateXml.activity =
              taskDetails.config && taskDetails.config.displayName
                ? taskDetails.config.displayName
                : taskDetails.activityname;
            bookDetailsTemplateXml.bookname = details.bookname;
            bookDetailsTemplateXml.ceValue = ceValue;
            bookDetailsTemplateXml.amoValue = amoValue;
            bookDetailsTemplateXml.templatefilenamme = templateFileNamme;
            bookDetailsTemplateXml.templateformat =
              journalDetails.templateformat;
            bookDetailsTemplateXml.textcolumn = journalDetails.textcolumn;
            bookDetailsTemplateXml.onlineprofile = journalDetails.onlineprofile;
            bookDetailsTemplateXml.printprofile = journalDetails.printprofile;
            bookDetailsTemplateXml.wocategory = journalDetails.wocategory;
            bookDetailsTemplateXml.runon = details.runon;
            template = await createBookDetailsXML(bookDetailsTemplateXml);
          }
        } else {
          // to be optimized
          // eslint-disable-next-line no-lonely-if
          if (
            details.wotype == 'Journal' &&
            resultCupJounrals.length > 0 &&
            ext == '.txt' &&
            (details.wfid == 25 ||
              details.wfid == 27 ||
              details.wfid == 32 ||
              details.wfid == 30)
          ) {
            const journalDetails = resultCupJounrals[0];
            const amoValue = journalDetails.amoid == 1 ? 'Yes' : 'No';
            const templatefilePath = journalDetails.templatefilepath
              ? journalDetails.templatefilepath.split('/')
              : '';
            const templatePathFileName = templatefilePath
              ? templatefilePath[templatefilePath.length - 1]
              : '';
            // const TemplateFilebaseName = templatePathFileName
            //   ? templatePathFileName.replace(extname(templatePathFileName), '')
            //   : '';
            const templateFileNamme = journalDetails.filename
              ? journalDetails.filename
              : templatePathFileName || '';
            const ceValue = journalDetails.celevelid == 1 ? 'No' : 'Yes';
            template =
              `JournalCode : ${details.bookcode}\r\n` +
              `Division : ${details.division}\r\n` +
              `JournalTitle : ${details.bookname}\r\n` +
              `CE : ${ceValue}\r\n` +
              `AMO : ${amoValue}\r\n` +
              `TemplateName : ${templateFileNamme}\r\n` +
              `TemplateFormat : ${journalDetails.templateformat}\r\n` +
              `TextColumn : ${journalDetails.textcolumn}\r\n` +
              `OnlineProfile : ${journalDetails.onlineprofile}\r\n` +
              `PrintProfile : ${journalDetails.printprofile}\r\n` +
              `Stage : ${taskDetails.stagename}\r\n` +
              `Activity : ${
                taskDetails.config && taskDetails.config.displayName
                  ? taskDetails.config.displayName
                  : taskDetails.activityname
              }\r\n` +
              `ActivityId : ${
                taskDetails.activityid
                  ? taskDetails.activityid
                  : taskDetails.activityId
              }\r\n`;
          } else if (
            details.wotype == 'Journal' &&
            resultCupJounrals.length > 0 &&
            ext == '.xml' &&
            (details.wfid == 25 ||
              details.wfid == 27 ||
              details.wfid == 31 ||
              details.wfid == 37 ||
              details.wfid == 32 ||
              details.wfid == 30)
          ) {
            const journalDetails = resultCupJounrals[0];
            const amoValue = journalDetails.amoid == 1 ? 'Yes' : 'No';
            const templatefilePath = journalDetails.templatefilepath
              ? journalDetails.templatefilepath.split('/')
              : '';
            const templatePathFileName = templatefilePath
              ? templatefilePath[templatefilePath.length - 1]
              : '';
            // const TemplateFilebaseName = templatePathFileName
            //   ? templatePathFileName.replace(extname(templatePathFileName), '')
            //   : '';
            const templateFileNamme = journalDetails.filename
              ? journalDetails.filename
              : templatePathFileName || '';
            const ceValue = journalDetails.celevelid == 1 ? 'No' : 'Yes';
            bookDetailsTemplateXml = {};
            bookDetailsTemplateXml.JournalAcronym =
              journalDetails.journalacronym;
            bookDetailsTemplateXml.bookcode = details.bookcode;
            bookDetailsTemplateXml.activityid = taskDetails.activityid
              ? taskDetails.activityid
              : taskDetails.activityId;
            bookDetailsTemplateXml.division = details.division;
            bookDetailsTemplateXml.stage = taskDetails.stagename;
            bookDetailsTemplateXml.activity =
              taskDetails.config && taskDetails.config.displayName
                ? taskDetails.config.displayName
                : taskDetails.activityname;
            bookDetailsTemplateXml.bookname = details.bookname;
            bookDetailsTemplateXml.ceValue = ceValue;
            bookDetailsTemplateXml.amoValue = amoValue;
            bookDetailsTemplateXml.templatefilenamme = templateFileNamme;
            bookDetailsTemplateXml.templateformat =
              journalDetails.templateformat;
            bookDetailsTemplateXml.textcolumn = journalDetails.textcolumn;
            bookDetailsTemplateXml.onlineprofile = journalDetails.onlineprofile;
            bookDetailsTemplateXml.printprofile = journalDetails.printprofile;
            bookDetailsTemplateXml.wocategory = journalDetails.wocategory;
            bookDetailsTemplateXml.runon = details.runon;
            bookDetailsTemplateXml.requesttype = journalDetails.reqtype;

            template = await createBookDetailsXML(bookDetailsTemplateXml);
          } else if (
            details.wotype == 'Journal' &&
            details.wfid == 26 &&
            ext == '.txt'
          ) {
            template =
              `Book Name : ${details.bookcode}\r\n` +
              `Stage : ${taskDetails.stagename}\r\n` +
              `Last Page Number : ${0}\r\n` +
              `JATS1.2  : ` +
              `Yes` +
              `\r\n`;
          } else if (
            details.wotype == 'Journal' &&
            details.wfid == 31 &&
            ext == '.txt' &&
            resultCupJounrals[0].isiauthor == true &&
            taskDetails.stageId == '2' &&
            taskDetails.iterationcount == 1
          ) {
            const journalDetails = resultCupJounrals[0];
            template =
              `JournalAcronym : ${journalDetails.journalacronym}\r\n` +
              `Book Name : ${details.bookcode}\r\n` +
              `Stage : ${taskDetails.stagename}\r\n` +
              `Stage Name : ${taskDetails.stagename}\r\n` +
              `Last Page Number : ${0}\r\n` +
              `JATS1.2  : Yes\r\n` +
              `iAuthor :  Yes\r\n` +
              `iteration :  ${taskDetails.iterationcount}` +
              `\r\n`;
          } else if (
            details.wotype == 'Journal' &&
            details.wfid == 31 &&
            ext == '.txt'
          ) {
            const journalDetails = resultCupJounrals[0];
            template =
              `JournalAcronym : ${journalDetails.journalacronym}\r\n` +
              `Book Name : ${details.bookcode}\r\n` +
              `Stage : ${taskDetails.stagename}\r\n` +
              `Stage Name : ${taskDetails.stagename}\r\n` +
              `Last Page Number : ${0}\r\n` +
              `JATS1.2  : ` +
              `Yes` +
              `\r\n`;
          } else if (
            details.wotype == 'Journal' &&
            (details.wfid == 28 || details.wfid == 53 || details.wfid == 55) &&
            ext == '.xml'
          ) {
            const journalDetails = resultCupJounrals[0];
            const runontypeString = resultCupJounrals[0].runontype;
            const runontypeArray = runontypeString.includes('label')
              ? JSON.parse(runontypeString)
              : runontypeString;
            const valueArray = runontypeString.includes('label')
              ? runontypeArray.map(item => item.value)
              : runontypeArray;
            const runonjoinedString = runontypeString.includes('label')
              ? valueArray.join(', ')
              : runontypeString;
            const runonValue = !!(
              runontypeString.length > 0 &&
              valueArray.length > 0 &&
              runonjoinedString &&
              runonjoinedString != ''
            );
            console.log('a1', runontypeArray);
            console.log('valueArray', valueArray);
            console.log('runonjoinedString', runonjoinedString);

            const amoValue = journalDetails.amoid == 1 ? 'Yes' : 'No';
            const templatefilePath = journalDetails.templatefilepath
              ? journalDetails.templatefilepath.split('/')
              : '';
            const templatePathFileName = templatefilePath
              ? templatefilePath[templatefilePath.length - 1]
              : '';
            const templateFileNamme = journalDetails.filename
              ? journalDetails.filename
              : templatePathFileName || '';
            const ceValue = journalDetails.celevelid == 1 ? 'No' : 'Yes';
            bookDetailsTemplateXml = {};
            bookDetailsTemplateXml.bookcode = details.bookcode;
            bookDetailsTemplateXml.activityid = taskDetails.activityid
              ? taskDetails.activityid
              : taskDetails.activityId;
            bookDetailsTemplateXml.division = details.division;
            bookDetailsTemplateXml.stage = taskDetails.stagename;
            bookDetailsTemplateXml.activity =
              taskDetails.config && taskDetails.config.displayName
                ? taskDetails.config.displayName
                : taskDetails.activityname;
            bookDetailsTemplateXml.bookname = details.bookname;
            bookDetailsTemplateXml.journalname = journalDetails.journalname;
            bookDetailsTemplateXml.ceValue = ceValue;
            bookDetailsTemplateXml.amoValue = amoValue;
            bookDetailsTemplateXml.templatefilenamme = templateFileNamme;
            bookDetailsTemplateXml.templateformat =
              journalDetails.templateformat;
            bookDetailsTemplateXml.textcolumn = journalDetails.textcolumn;
            bookDetailsTemplateXml.onlineprofile = journalDetails.onlineprofile;
            bookDetailsTemplateXml.printprofile = journalDetails.printprofile;
            // bookDetailsTemplateXml.runon =
            //   journalDetails.runon == true ? 'Yes' : 'No';
            bookDetailsTemplateXml.runon = runonValue == true ? 'Yes' : 'No';
            bookDetailsTemplateXml.runontype = runonjoinedString;
            bookDetailsTemplateXml.journaltype =
              journalDetails.journaltype == 'online' ? 'Yes' : 'No';

            template = await createBookDetailsXMLForIssue(
              bookDetailsTemplateXml,
            );
          } else if (
            details.wotype == 'Journal' &&
            ext == '.txt' &&
            (details.wfid == 41 ||
              details.wfid == 43 ||
              details.wfid == 45 ||
              details.wfid == 46 ||
              details.wfid == 47 ||
              details.wfid == 48)
          ) {
            template = `${taskDetails.graphicspath}`;
          } else if (
            details.wotype == 'Journal' &&
            resultCupJounrals.length > 0 &&
            ext == '.xml' &&
            details.wfid == 25
          ) {
            const journalDetails = resultCupJounrals[0];
            const amoValue = journalDetails.amoid == 1 ? 'Yes' : 'No';
            const templatefilePath = journalDetails.templatefilepath
              ? journalDetails.templatefilepath.split('/')
              : '';
            const templatePathFileName = templatefilePath
              ? templatefilePath[templatefilePath.length - 1]
              : '';
            // const TemplateFilebaseName = templatePathFileName
            //   ? templatePathFileName.replace(extname(templatePathFileName), '')
            //   : '';
            const templateFileNamme = journalDetails.filename
              ? journalDetails.filename
              : templatePathFileName || '';
            const ceValue = journalDetails.celevelid == 1 ? 'No' : 'Yes';
            bookDetailsTemplateXml = {};
            bookDetailsTemplateXml.bookcode = details.bookcode;
            bookDetailsTemplateXml.activityid = taskDetails.activityid
              ? taskDetails.activityid
              : taskDetails.activityId;
            bookDetailsTemplateXml.division = details.division;
            bookDetailsTemplateXml.stage = taskDetails.stagename;
            bookDetailsTemplateXml.activity =
              taskDetails.config && taskDetails.config.displayName
                ? taskDetails.config.displayName
                : taskDetails.activityname;
            bookDetailsTemplateXml.bookname = details.bookname;
            bookDetailsTemplateXml.ceValue = ceValue;
            bookDetailsTemplateXml.amoValue = amoValue;
            bookDetailsTemplateXml.templatefilenamme = templateFileNamme;
            bookDetailsTemplateXml.templateformat =
              journalDetails.templateformat;
            bookDetailsTemplateXml.textcolumn = journalDetails.textcolumn;
            bookDetailsTemplateXml.onlineprofile = journalDetails.onlineprofile;
            bookDetailsTemplateXml.printprofile = journalDetails.printprofile;
            bookDetailsTemplateXml.wocategory = journalDetails.wocategory;

            template = await createBookDetailsXML(bookDetailsTemplateXml);
          } else {
            template = 'No Bookdetails found';
          }
        }
      }
    }
    const templateResult = template;
    resolve(templateResult);
  });
};

const createBookDetailsXML = async bookDetailsTemplateXml => {
  return new Promise(async (resolve, reject) => {
    try {
      const bookDetailsOut = [];
      const {
        activity,
        amoValue,
        bookcode,
        bookname,
        ceValue,
        onlineprofile,
        printprofile,
        stage,
        templatefilenamme,
        templateformat,
        textcolumn,
        division,
        activityid,
        JournalAcronym,
        wocategory,
        runon,
        requesttype,
      } = bookDetailsTemplateXml;
      const stageName = stage;
      bookDetailsOut.push(
        cupJournalBookDetailsTemplate.li
          .replace(/{{bookcode}}/, bookcode)
          .replace(/{{bookname}}/, bookname)
          .replace(/{{division}}/, division)
          .replace(/{{ceValue}}/, ceValue)
          .replace(/{{amoValue}}/, amoValue)
          .replace(/{{templatefilenamme}}/, templatefilenamme)
          .replace(/{{templateformat}}/, templateformat)
          .replace(/{{textcolumn}}/, textcolumn)
          .replace(/{{onlineprofile}}/, onlineprofile)
          .replace(/{{printprofile}}/, printprofile)
          .replace(/{{stage}}/, stage)
          .replace(/{{activity}}/, activity)
          .replace(/{{activityid}}/, activityid)
          .replace(/{{JournalAcronym}}/, JournalAcronym)
          .replace(/{{stageName}}/, stageName)
          .replace(/{{Category}}/, wocategory)
          .replace(/{{runon}}/, runon)
          .replace(/{{requesttype}}/, requesttype),
      );

      const productionXmlTemplate = cupJournalBookDetailsTemplate.ul.replace(
        /{{li}}/,
        bookDetailsOut.join('\n'),
      );
      resolve(productionXmlTemplate);
    } catch (e) {
      reject(e);
      console.log(e, 'error in job info xml');
    }
  });
};

const createBookDetailsXMLForIssue = async bookDetailsTemplateXml => {
  return new Promise(async (resolve, reject) => {
    try {
      const bookDetailsOut = [];
      const {
        activity,
        amoValue,
        bookcode,
        // eslint-disable-next-line no-unused-vars
        bookname,
        journalname,
        ceValue,
        onlineprofile,
        printprofile,
        stage,
        templatefilenamme,
        templateformat,
        textcolumn,
        division,
        activityid,
        runon,
        runontype,
        journaltype,
      } = bookDetailsTemplateXml;
      const stageName = stage;
      bookDetailsOut.push(
        IssueJournalBookDetailsTemplate.li
          .replace(/{{bookcode}}/, bookcode)
          .replace(/{{journalname}}/, journalname)
          .replace(/{{division}}/, division)
          .replace(/{{ceValue}}/, ceValue)
          .replace(/{{amoValue}}/, amoValue)
          .replace(/{{templatefilenamme}}/, templatefilenamme)
          .replace(/{{templateformat}}/, templateformat)
          .replace(/{{textcolumn}}/, textcolumn)
          .replace(/{{onlineprofile}}/, onlineprofile)
          .replace(/{{printprofile}}/, printprofile)
          .replace(/{{stage}}/, stage)
          .replace(/{{activity}}/, activity)
          .replace(/{{runon}}/, runon)
          .replace(/{{runontype}}/, runontype)
          .replace(/{{activityid}}/, activityid)
          .replace(/{{journaltype}}/, journaltype)
          .replace(/{{stageName}}/, stageName),
      );

      const productionXmlTemplate = IssueJournalBookDetailsTemplate.ul.replace(
        /{{li}}/,
        bookDetailsOut.join('\n'),
      );
      resolve(productionXmlTemplate);
    } catch (e) {
      reject(e);
      console.log(e, 'error in job info xml');
    }
  });
};

export const cupJournalBookDetailsTemplate = {
  ul: `<BookDetails>{{li}}</BookDetails>`,
  li: `
<JournalAcronym>{{JournalAcronym}}</JournalAcronym>
<JournalCode>{{bookcode}}</JournalCode>
<JournalTitle>{{bookname}}</JournalTitle>
<Division>{{division}}</Division>
<CE>{{ceValue}}</CE>
<AMO>{{amoValue}}</AMO>
<TemplateName>{{templatefilenamme}}</TemplateName>
<TemplateFormat>{{templateformat}}</TemplateFormat>
<TextColumn>{{textcolumn}}</TextColumn>
<OnlineProfile>{{onlineprofile}}</OnlineProfile>
<PrintProfile>{{printprofile}}</PrintProfile>
<Stage>{{stage}}</Stage>
<Activity>{{activity}}</Activity>
<ActivityId>{{activityid}}</ActivityId>
<StageName>{{stageName}}</StageName> 
<Run-On >{{runon}}</Run-On> 
<RequestType>{{requesttype}}</RequestType> 
`,
};

export const IssueJournalBookDetailsTemplate = {
  ul: `<BookDetails>{{li}}</BookDetails>`,
  li: `
<JournalCode>{{bookcode}}</JournalCode>
<JournalTitle>{{journalname}}</JournalTitle>
<Division>{{division}}</Division>
<CE>{{ceValue}}</CE>
<AMO>{{amoValue}}</AMO>
<TemplateName>{{templatefilenamme}}</TemplateName>
<TemplateFormat>{{templateformat}}</TemplateFormat>
<TextColumn>{{textcolumn}}</TextColumn>
<OnlineProfile>{{onlineprofile}}</OnlineProfile>
<PrintProfile>{{printprofile}}</PrintProfile>
<Stage>{{stage}}</Stage>
<Activity>{{activity}}</Activity>
<OnlineOnlyJournal>{{journaltype}}</OnlineOnlyJournal>
<RunOn>{{runon}}</RunOn>
<RunOnType>{{runontype}}</RunOnType>
<ActivityId>{{activityid}}</ActivityId>
<StageName>{{stage}}</StageName>
`,
};

// export const getIncomingDetailsIdList = (req, res) => {
//     let {workorderId,stageId,stageIterationCount} = req.body;
//     var stageIteration = stageIterationCount >1 ? stageIterationCount -1 : stageIterationCount;
//     // let sql = `select  distinct  incomingdetails.filetypeid from wms_workflow_eventlog as eventlog
//     // left join wms_workorder_incoming as incoming on incoming.woid = eventlog.workorderid
//     //   left join  wms_workorder_incomingfiledetails  as incomingdetails on incomingdetails.woincomingid = incoming.woincomingid
//     // where eventlog.workorderid =${workorderId}`
//     let sql = `SELECT distinct incomingfiledetails.filetypeid FROM public.wms_workflow_stagetrn_file as stagetrnfile
//     left join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingfileid = stagetrnfile.woincomingfileid
//     WHERE stagetrnfile.workorderid = ${workorderId} and stagetrnfile.stageid = ${stageId} and stagetrnfile.stageiterationcount = ${stageIteration}`
//     query(sql).then((data) => {
//         console.log(data, "data forrrr")
//         res.status(200).json({ data: data, status: true });
//     }).catch((error) => {
//         res.status(400).send({ message: error, status: false });
//     })
// }

export const getIncomingDetailsIdList = (req, res) => {
  const { workorderId, stageIterationCount } = req.body;
  const stageIteration =
    stageIterationCount > 1 ? stageIterationCount - 1 : stageIterationCount;
  // let sql = `select  distinct  incomingdetails.filetypeid from wms_workflow_eventlog as eventlog
  // left join wms_workorder_incoming as incoming on incoming.woid = eventlog.workorderid
  //   left join  wms_workorder_incomingfiledetails  as incomingdetails on incomingdetails.woincomingid = incoming.woincomingid
  // where eventlog.workorderid =${workorderId}`
  let sql = `SELECT * FROM public.wms_workflow_stagetrn_file where workorderid =${workorderId}  order by stagetrnfileid desc limit 1`;
  query(sql)
    .then(data => {
      console.log(data, 'data forrrr');
      if (data && data.length >= 1) {
        sql = `SELECT distinct incomingfiledetails.filetypeid,incomingfiledetails.newfiletype FROM public.wms_workflow_stagetrn_file as stagetrnfile
         left join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingfileid = stagetrnfile.woincomingfileid
         WHERE stagetrnfile.workorderid = ${workorderId}  and stageid = ${data[0].stageid} and stagetrnfile.stageiterationcount = ${stageIteration} `;
        query(sql)
          .then(() => {
            console.log(data, 'data forrrr');
            res.status(200).json({ data, status: true });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      } else {
        res.status(200).json({ data, status: true });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const updateIncomingCountValue = async (req, res) => {
  const { workorderId, imageValue, woincomingFileId } = req.body;

  try {
    if (woincomingFileId != null) {
      const sql = `update wms_workorder_incomingfiledetails set imagecount = $1 where woincomingfileid = $2`;
      await query(sql, [imageValue, woincomingFileId]);
    } else {
      let sql = `select inco.woincomingfileid from wms_workorder_incoming  as wo
        join  wms_workorder_incomingfiledetails as inco on inco.woincomingid = wo.woincomingid
        where wo.woid= $1`;
      const woincomingList = await query(sql, [workorderId]);
      const woincomingList1 = woincomingList
        .map(list => list.woincomingfileid)
        .join(', ');
      sql = `update wms_workorder_incomingfiledetails set imagecount = $1 where woincomingfileid in ($2)`;
      await query(sql, [imageValue, woincomingList1]);
    }
    res
      .status(200)
      .json({ message: 'Image Count Updated Successfully', status: true });
  } catch (e) {
    res.status(400).send({ message: e, status: false });
  }
};

export const getWorkflowName = (req, res) => {
  const { wfId } = req.body;
  const sql = `SELECT wfname FROM public.wms_workflow where wfid = ${wfId}
        ORDER BY wfid ASC  `;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};
// for engine activity
export const getBookDetailsTemplateElse = async data => {
  return new Promise(async resolve => {
    let template = false;
    let bookDetailsTemplateXml = {};
    if (data) {
      if (data.woType == 'Book') {
        // need to be handled
        // const bookDetailsOut = [];
        // if (details.wfid == 48) {
        //   if (ext == '.xml') {
        //     const xmlTemplate = {
        //       ul: `<BookDetails>{{li}}</BookDetails>`,
        //       li: `
        //         <AuthorName>Sakthivel</AuthorName>
        //         <ISBN>{{isbn}}</ISBN>
        //         <OnlinePitstopProfile>{{onlineprofile}}</OnlinePitstopProfile>
        //         <PrintPitstopProfile>{{printprofile}}</PrintPitstopProfile>
        //         <EISBN>{{eisbn}}</EISBN>
        //         <colorProfile>4C (CMYK)</colorProfile>
        //         <CustomerCode>Elsevier</CustomerCode>
        //         <Edition>{{edition}}</Edition>
        //         <Title>{{title}}</Title>
        //         <PublisherName>Elsevier</PublisherName>
        //         <PublisherLocation>{{country}}</PublisherLocation>
        //         <ActivityName>{{activityAlias}}</ActivityName>
        //         <StageName>{{stagename}}</StageName>`,
        //     };
        //     const {
        //       bookcode,
        //       title,
        //       printisbn,
        //       eisbn,
        //       printprofile,
        //       onlineprofile,
        //       edition,
        //     } = details;
        //     const { stagename, activityAlias } = taskDetails;
        //     bookDetailsOut.push(
        //       xmlTemplate.li
        //         .replace(/{{bookcode}}/, bookcode)
        //         .replace(/{{isbn}}/, printisbn)
        //         .replace(/{{title}}/, title)
        //         .replace(/{{eisbn}}/, eisbn)
        //         .replace(/{{edition}}/, edition)
        //         .replace(/{{printprofile}}/, printprofile)
        //         .replace(/{{onlineprofile}}/, onlineprofile)
        //         .replace(/{{stagename}}/, stagename)
        //         .replace(/{{activityAlias}}/, activityAlias),
        //     );
        //     template = xmlTemplate.ul.replace(
        //       /{{li}}/,
        //       bookDetailsOut.join('\n'),
        //     );
        //     console.log(template, 'template');
        //   }
        // } else if (details.wfid == 29 && ext == '.xml') {
        //   template = bookMasterDetails[0].generate_bookmaster_xml;
        // } else {
        //   // to be hanlded
        //   const style1 = details.style1 ? details.style1 : '';
        //   const style2 = details.style2 ? details.style2 : '';
        //   const style3 = details.style3 ? details.style3 : '';
        //   const style4 = details.style4 ? details.style4 : '';
        //   const style5 = details.style5 ? details.style5 : '';
        //   const style6 = details.style6 ? details.style6 : '';
        //   const css = details.css ? details.css : '';
        //   template =
        //     `Customer Name : ${details.customername}\r\n` +
        //     `Book Name : ${details.bookcode}\r\n` +
        //     `Activity Name : ${
        //       taskDetails.config && taskDetails.config.displayName
        //         ? taskDetails.config.displayName
        //         : taskDetails.activityname
        //     }\r\n` +
        //     `Stage Name : ${taskDetails.stagename}\r\n` +
        //     `Paper Back Number : ${details.paperbackno}\r\n` +
        //     `Hardback Number : ${details.hardbackno}\r\n` +
        //     `OC Number : ${details.ocno}\r\n` +
        //     `iAuthor : No` +
        //     `\r\n` +
        //     `Book Category : ${details.bookcategory}\r\n` +
        //     `Style1 : ${style1}\r\n` +
        //     `Style2 : ${style2}\r\n` +
        //     `Style3 : ${style3}\r\n` +
        //     `Style4 : ${style4}\r\n` +
        //     `Style5 : ${style5}\r\n` +
        //     `Style6 : ${style6}\r\n` +
        //     `CSS : ${css}\r\n` +
        //     `Numbered Box : none`;
        // }
      } else if (data.woType == 'Journal') {
        if (data.wfId == 43) {
          if (data.ext == '.xml') {
            const result = await bookDetails(data.workorderId);
            const resultCupJounrals =
              await getBookDetailsTemplateForCupJournals(data.workorderId);
            const journalDetails = data;
            const amoValue = journalDetails?.amoid == 1 ? 'Yes' : 'No';
            // const templatefilePath = journalDetails.templatefilepath
            //   ? journalDetails.templatefilepath.split('/')
            //   : '';
            // const templatePathFileName = templatefilePath
            //   ? templatefilePath[templatefilePath.length - 1]
            //   : '';
            // const TemplateFilebaseName = templatePathFileName
            //   ? templatePathFileName.replace(extname(templatePathFileName), '')
            //   : '';
            // const templateFileNamme = journalDetails.filename
            //   ? journalDetails.filename
            //   : templatePathFileName || '';
            const ceValue = data?.celevelid == 1 ? 'No' : 'Yes';
            bookDetailsTemplateXml = {};
            bookDetailsTemplateXml.JournalAcronym =
              journalDetails.journalAcronym;
            bookDetailsTemplateXml.bookcode = result[0].bookcode;
            bookDetailsTemplateXml.activityid = data.activityId;
            bookDetailsTemplateXml.division = result[0].division;
            bookDetailsTemplateXml.stage = data.stage?.name;
            bookDetailsTemplateXml.activity = data.activity.name;
            bookDetailsTemplateXml.bookname = result[0].bookname;
            bookDetailsTemplateXml.ceValue = ceValue;
            bookDetailsTemplateXml.amoValue = amoValue;
            // bookDetailsTemplateXml.templatefilenamme = templateFileNamme;
            bookDetailsTemplateXml.templateformat = data?.templateformat
              ? data.templateformat
              : '';
            bookDetailsTemplateXml.textcolumn = data?.textcolumn;
            bookDetailsTemplateXml.onlineprofile =
              resultCupJounrals[0].onlineprofile;
            bookDetailsTemplateXml.printprofile =
              resultCupJounrals[0].printprofile;
            bookDetailsTemplateXml.wocategory = data.wf?.category;
            bookDetailsTemplateXml.runon = data?.runon;
            bookDetailsTemplateXml.requesttype = data?.reqtype;
            template = await createBookDetailsXML(bookDetailsTemplateXml);
          }
        }
      }
    }
    if (template) {
      const tempFilePath = `uploads/bookdetails_${uuidv4()}.xml`;
      await writeSmallFile(tempFilePath, template, `uploads/`);
      switch (data.dmsType) {
        case 'azure':
          await azureHelper._upload(
            {
              name: basename(data.fileDetails.path),
              tempFilePath,
            },
            dirname(data.fileDetails.path),
          );
          break;
        case 'local':
          await localHelper._uploadlocal(
            {
              name: '',
              tempFilePath,
            },
            data.fileDetails.path,
          );
          break;
        default:
          throw new Error('Invalid DMS type.');
      }
      unlink(tempFilePath);
      resolve(template);
    }
  });
};
