import { query } from '../../database/postgres.js';

export const insert_acs_mst_notificationdetails = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select xmlnotificationid
                        from public.ACS_Mst_NotificationDetails where packageack ='${jsonobj.packageack}' `;
    const out = await query(sql);
    if (out.length == 0) {
      const sqlInsert = `INSERT INTO public.ACS_Mst_NotificationDetails(
                packageack, zipname, statusid,islock,requestid,transcode,mscno,remarks,status)
               VALUES ( '${jsonobj.packageack}', '${jsonobj.zipname}', '${jsonobj.statusid}','${jsonobj.islock}','${jsonobj.requestid}','${jsonobj.transcode}','${jsonobj.mscno}','${jsonobj.remarks}','${jsonobj.status}')`;

      await query(sqlInsert).then(() => {
        res
          .status(200)
          .json({ data: 'Query Inserted Successfully', status: 'Success' });
      });
    } else {
      res
        .status(200)
        .json({ data: 'file already available', status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getDownloadList_ACS = async (req, res) => {
  try {
    const jsonobj = req.body;

    const acsPathMap = {
      acs_convert_downloader: 1,
      acs_graphics_downloader: 11,
      acs_techedit_downloader: 21,
      convert_notification: 2,
      graphics_notification: 12,
      techedit_notification: 22,
      Conversion: 3,
      Graphics: 13,
      'Copy Editing': 23,
      errorhandling: 55,
    };

    const acsStatusId = acsPathMap[jsonobj.acsPath];
    let sql;
    console.log('getDownloadList_ACS');
    if (acsStatusId == 3) {
      sql = `SELECT  xmlnotificationid,packageack,zipname,statusid,requestid,mscno,transcode FROM public.acs_mst_notificationdetails WHERE statusid =3 AND mscNo IN (SELECT mscNo FROM public.acs_mst_notificationdetails WHERE StatusId = 13);`;
    } else if (acsStatusId == 55) {
      sql = ` select b.itemcode,a.stageid,a.islock, a.Workorderid from public.acs_errorhandling_audit a left join 
      wms_workorder b on a.Workorderid = b.workorderid  where a.islock = 'Y' ;`;
    } else {
      sql = `select xmlnotificationid,packageack,zipname,statusid,requestid,mscno,transcode from public.acs_mst_notificationdetails
    where statusid ='${acsStatusId}' order by xmlnotificationid asc;`;
    }
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const checknewjournal = async (req, res) => {
  try {
    const jsonobj = req.body;
    // jsonobj.filename
    // const inputString = "an4c00951_20240522_122231_REQ3975164_done.txt";

    const underscoreIndex = jsonobj.filename.indexOf('_');
    let sql;
    if (underscoreIndex !== -1) {
      const valueBeforeUnderscore = jsonobj.filename.substring(
        0,
        underscoreIndex,
      );
      sql = `SELECT * FROM  public.acs_mst_notificationdetails where mscno='${valueBeforeUnderscore}'`;
    } else {
      console.log('No underscore found in the input string.');
    }
    console.log('www');
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const updateACSmetainfo = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `update public.acs_mst_notificationdetails set statusid ='${jsonobj.statusid}',transcode='${jsonobj.transcode}', remarks = '${jsonobj.remarks}'where packageack='${jsonobj.packageack}' and islock = 'N'`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const updateACSFailuremetainfo = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `update public.acs_mst_notificationdetails set remarks = '${jsonobj.remarks}'where packageack='${jsonobj.packageack}' and islock = 'N'`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const insert_ack_notificationdetails = async (req, res) => {
  try {
    const jsonobj = req.body;

    const sqlInsert = `INSERT INTO public.trn_acknotificationdetails(
            transcode, transdesc, timestamp,requestid,ackcode,manuscriptnumber,statusid,islock,
              createddate,uploadedtime,notesfromvendor,packagename,journalname,tocgraphic,prioritycode,turnaroundminutes,levelofeffort)
            VALUES ( '${jsonobj.Transcode}', '${jsonobj.Transdesc}', '${jsonobj.TimeStamp}','${jsonobj.RequestId}',
                '${jsonobj.ACKcode}','${jsonobj.ManuscriptNumber}','${jsonobj.StatusId}','${jsonobj.isLock}',
                '${jsonobj.CreatedDate}','${jsonobj.UploadedTime}','${jsonobj.NotesFromVendor}',
                '${jsonobj.PackageName}','${jsonobj.JournalName}',
                '${jsonobj.tocGraphic}','${jsonobj.priorityCode}','${jsonobj.turnaroundMinutes}','${jsonobj.levelofeffort}')`;

    await query(sqlInsert).then(() => {
      res
        .status(200)
        .json({ data: 'Query Inserted Successfully', status: 'Success' });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getGraphicsList_ACS = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select xmlnotificationid,packageack,zipname,statusid,requestid,mscno,transcode from public.acs_mst_notificationdetails
    where mscno ='${jsonobj.mscno}' and transcode = 140`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const checkPendingStatus = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `SELECT * FROM wms_workflow_eventlog_details where wfeventid= ${jsonobj.wfEventId} and operationtype = 'Pending' `;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// export const fileWriteLocal = async (req) => {

//   try {
//     const jsonobj = req.body;
//     const paragraphContent = `This is a sample paragraph content.
//     It spans multiple lines.
//     Each line should be written to the text file.
//     This is line 4.
//     This is the last line.`;
//     const lines = paragraphContent.split('\n');
//   //  const filePath = `C:\\itools\\iwms\\KLI\\81b96a8acd8d253a74fe753c4815cf00\\test.tsx`

//     const filePath  = jsonobj.workingPath;
//     try {
//       const directoryPath = filePath.substring(0, filePath.lastIndexOf("\\"));
//       await fs.mkdir(directoryPath, { recursive: true });
//       await fs.writeFile(filePath, lines.join('\n'));

//       console.log('Paragraph content has been written to', filePath);
//     } catch (err) {
//       console.error('Error writing file:', err);

//     }

//   } catch (error) {
//     reject(error)
//   }

// }

export const getdataACSnotes = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select note from notestoacslog where workorderid = ${jsonobj.workorderId} and stageid = ${jsonobj.stageId} order by createddate desc limit 1`;
    const out = await query(sql);
    if (out.length > 0) {
      res.status(200).send(out);
    } else {
      res.status(200).send({ message: 'no data' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const acserrorfile = async (req, res) => {
  try {
    const jsonobj = req.body;
    const { errorstatus } = req.body;

    if (errorstatus == 'get') {
      const sql = `select * from public.acs_mst_notificationdetails where mscno='${jsonobj.itemcode}' and transcode = 
    case when ${jsonobj.stageid} = 72 then 100 when ${jsonobj.stageid} = 10 then 140 when ${jsonobj.stageid} = 24 then 840 else transcode end`;
      const out = await query(sql);
      if (out.length > 1) {
        res.status(200).send(out);
      } else {
        res.status(200).send({ message: 'no updated data' });
      }
    } else {
      const sql = `update public.acs_errorhandling_audit set islock ='N' where workorderid =${jsonobj.Workorderid} and stageid = ${jsonobj.stageid}`;
      console.log('update query', sql);
      await query(sql);
      res.status(200).send({ message: 'Updated' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const acsIsFailureAckReceived = async (req, res) => {
  try {
    const jsonobj = req.body;
    let sql = `SELECT 
                (SELECT COUNT(*)
                FROM public.acs_mst_notificationdetails
                WHERE mscno = '${jsonobj.itemcode}'
                  AND transcode = CASE
                      WHEN ${jsonobj.stageid} = 72 THEN 111
                      WHEN ${jsonobj.stageid} = 10 THEN 151
                      WHEN ${jsonobj.stageid} = 24 THEN 851
                      ELSE transcode
                  END) = 
                (SELECT COUNT(*)
                FROM wms_tools_api_list
                WHERE workorderid = ${jsonobj.woId}
                  AND stageid = ${jsonobj.stageid}
                  AND toolid = 413
                  AND status = 'Success' 
                  AND remarks <> 'skipped') AS counts_equal`;

    const checkIsResponded = await query(sql);
    let out = [];

    if (checkIsResponded[0].counts_equal) {
      sql = `select
                *
              from
                public.acs_mst_notificationdetails
              where
                xmlnotificationid in (
                select
                  max(xmlnotificationid) as xmlnotificationid
                from
                  public.acs_mst_notificationdetails
                where
                  mscno = '${jsonobj.itemcode}'
                  and transcode = 
                    case
                    when ${jsonobj.stageid} = 72 then 111
                    when ${jsonobj.stageid} = 10 then 151
                    when ${jsonobj.stageid} = 24 then 851
                    else transcode
                  end)
                and remarks = 'Failure ack received';`;
      out = await query(sql);
    }

    if (out.length > 0) {
      res.status(200).send({ isFailure: true });
    } else {
      res.status(200).send({ isFailure: false });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const checkUpdatedPackage = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select * from public.ACS_Mst_NotificationDetails where mscno = '${jsonobj.itemCode}' and transcode = '${jsonobj.transcode}'`;
    const out = await query(sql);

    if (out.length > 1) {
      const sql2 = `select inc.woincomingfileid,wo.itemcode,wo.workorderid from  public.wms_workorder_incomingfiledetails inc join public.wms_workorder as wo on wo.itemcode = filename  where itemcode='${jsonobj.itemCode}' order by 1 desc limit 1`;
      const out2 = await query(sql2);
      //  res.status(200).send(out2);
      res.status(200).send({ out2, success: true });
    } else {
      res.status(200).send({ message: 'no updated data', success: false });
    }
  } catch (error) {
    res.status(400).send({ message: error, success: false });
  }
};

export const checkNotificationPackage = async (req, res) => {
  try {
    const jsonobj = req.body;
    console.log('notification', jsonobj);
    const sql = `select packagename from public.trn_acknotificationdetails where packagename ='${jsonobj.PackageName}'`;
    const out = await query(sql);
    if (out.length == 0) {
      res.status(200).send({ out, success: true });
    } else {
      res.status(200).send({ message: 'Already Sent', success: false });
    }
  } catch (error) {
    res.status(400).send({ message: error, success: false });
  }
};
