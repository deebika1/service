import { query } from '../../database/postgres.js';
import {
  checkiTrackNorms,
  checkitrackIntegration,
  getEmailTemplate,
  extractEmails,
} from '../iTracks/index.js';
import { setOrdInflowService } from '../../salesPMO/service/index.js';
import {
  invoiceIntegrationService,
  ubrIntegrationService,
} from '../../odoo/service/index.js';
import { getUOMArticleTitle } from '../../iProductivity/dataLayer/productivityCalculation.js';
import { emitAction } from '../activityListener/activityListener.js';
// salesPMO/service/index.js';

export const getSWnormsService = async (req, res) => {
  try {
    const { workorderId } = req.body;
    const sql = `select s.softwareid,s.softwarename from wms_workorder wo
      left join public.pp_mst_composingsoftware s on s.softwareid=wo.composingsoftwareid
      where wo.workorderid=$1 and wo.composingsoftwareid is not null`;
    const software = await query(sql, [workorderId]);
    // const norms = await checkiTrackNorms(req.body);
    const targetNorms = 0;
    // if (norms.status && norms.message === 'Norms mapped') {
    //   targetNorms = norms.data[0].targetsla;
    // }
    res.status(200).send({ software, targetNorms });
  } catch (e) {
    res.status(400).send(e);
  }
};

export const getworkorderDetails = async (req, res) => {
  try {
    const { workorderId, stageId, activityId, jobType } = req.body;
    let sql = `select * from public.mst_jobtype where jobtypeconfigid = $1 and isactive=true`;
    const job = await query(sql, [jobType]);
    const workorder = [];
    if (job[0]?.jobtype === 'Non Article') {
      sql = `select wbwd.workorderid as woid from public.wms_book_workorder_details wbwd
      left join wms_workorder wo ON wo.workorderid = wbwd.workorderid
      where wbwd.bookworkorderid = $1`;
      await query(sql, [workorderId]);
    } else if (job[0]?.jobtype === 'Issue') {
      sql = `select iss.articleworkorderid as woid from public.wms_issue_workorder iss
      left join wms_workorder wo ON wo.issuenumber::int = iss.articleworkorderid
      where iss.issueworkorderid = $1`;
      await query(sql, [workorderId]);
    }
    const input = workorder.length
      ? workorder.map(item => item.woid).concat(Number(workorderId))
      : [Number(workorderId)];
    sql = `select * from (SELECT 
    icd.estimatedpages, 
    df.itracksconfig::TEXT, 
    wo.workorderid, 
    wo.itemcode, 
    CASE
    when lower(elg.activitystatus) = lower('Work in progress') then 'WIP'
    else elg.activitystatus
    end as activitystatus, 
    df.wfdefid, 
    elg.wfeventid,
    ed.operationtype,
    ed.wfeventdetailid,
    ed.timestamp,
    COALESCE(ed.uomvalue,0) AS uomvalue,  -- UOM value for the current status
    TO_CHAR(MAX(ed_s.timestamp),'YYYY-MM-DD HH24:mi') AS claim_startdatetime, -- Start datetime for the last "Claim" status
    TO_CHAR(MAX(ed_c.timestamp),'YYYY-MM-DD HH24:mi') AS completed_enddatetime -- End datetime for the last "Completed" status
FROM 
    public.wms_workorder wo
LEFT JOIN public.pp_mst_filetype ft ON ft.filetypeid = wo.inputfiletypeid
LEFT JOIN public.mst_jobtype jt ON jt.jobtypeconfigid = wo.jobtype::int
LEFT JOIN public.wms_workorder_incoming ic ON ic.woid = wo.workorderid
LEFT JOIN public.wms_workorder_incomingfiledetails icd ON icd.woincomingid = ic.woincomingid
LEFT JOIN public.wms_workflowdefinition df ON df.wfid = wo.wfid AND df.stageid = $1 AND df.activityid=$2
LEFT JOIN public.wms_workflow_eventlog elg ON elg.wfdefid = df.wfdefid AND elg.workorderid = wo.workorderid
LEFT JOIN public.wms_workflow_eventlog_details ed ON ed.wfeventid = elg.wfeventid 
    AND lower(ed.operationtype) = lower(elg.activitystatus) -- Join for current status UOM value
-- Join for last "Claim" status
LEFT JOIN public.wms_workflow_eventlog_details ed_s ON ed_s.wfeventid = elg.wfeventid 
    AND lower(ed_s.operationtype) = 'work in progress'
LEFT JOIN public.wms_workflow_eventlog_details ed_c ON ed_c.wfeventid = elg.wfeventid 
    AND lower(ed_c.operationtype) = 'completed'
WHERE 
    wo.workorderid in (${input})
GROUP BY 
    wo.workorderid, 
    icd.estimatedpages, 
    df.itracksconfig::TEXT, 
    wo.itemcode, 
    elg.activitystatus, 
    df.wfdefid,
    elg.wfeventid,
    ed.operationtype,
    ed.uomvalue,
    ed.timestamp,
    ed.wfeventdetailid) sub
    order by sub.timestamp;
`;
    // sql = `
    // WITH RankedData AS (
    //   SELECT
    //       icd.estimatedpages,
    //       df.itracksconfig::TEXT,
    //       wo.workorderid,
    //       wo.itemcode,
    //       CASE
    //           WHEN lower(elg.activitystatus) = lower('Work in progress') THEN 'WIP'
    //           ELSE elg.activitystatus
    //       END AS activitystatus,
    //       df.wfdefid,
    //       elg.wfeventid,
    //       ed.operationtype,
    //       ed.timestamp,
    //      ed.uomvalue,  -- UOM value for the current status
    //       TO_CHAR(MAX(ed_s.timestamp),'YYYY-MM-DD HH24:mi') AS claim_startdatetime,
    //       TO_CHAR(MAX(ed_c.timestamp),'YYYY-MM-DD HH24:mi') AS completed_enddatetime,
    //       ROW_NUMBER() OVER (PARTITION BY wo.workorderid ORDER BY ed.timestamp desc) AS rn-- Rank rows by timestamp, partitioned by workorderid
    //   FROM
    //       public.wms_workorder wo
    //   LEFT JOIN public.pp_mst_filetype ft ON ft.filetypeid = wo.inputfiletypeid
    //   LEFT JOIN public.mst_jobtype jt ON jt.jobtypeconfigid = wo.jobtype::int
    //   LEFT JOIN public.wms_workorder_incoming ic ON ic.woid = wo.workorderid
    //   LEFT JOIN public.wms_workorder_incomingfiledetails icd ON icd.woincomingid = ic.woincomingid
    //   LEFT JOIN public.wms_workflowdefinition df ON df.wfid = wo.wfid AND df.stageid = $1 AND df.activityid = $2
    //   LEFT JOIN public.wms_workflow_eventlog elg ON elg.wfdefid = df.wfdefid AND elg.workorderid = wo.workorderid
    //   LEFT JOIN public.wms_workflow_eventlog_details ed ON ed.wfeventid = elg.wfeventid AND ed.timestamp is not null
    // --         AND lower(ed.operationtype) = lower(elg.activitystatus)
    //   LEFT JOIN public.wms_workflow_eventlog_details ed_s ON ed_s.wfeventid = elg.wfeventid
    //       AND lower(ed_s.operationtype) = 'work in progress'
    //   LEFT JOIN public.wms_workflow_eventlog_details ed_c ON ed_c.wfeventid = elg.wfeventid
    //       AND lower(ed_c.operationtype) = 'completed'
    //   WHERE
    //       wo.workorderid IN ('3459','3460')
    //   GROUP BY
    //       wo.workorderid,
    //       icd.estimatedpages,
    //       df.itracksconfig::TEXT,
    //       wo.itemcode,
    //       elg.activitystatus,
    //       df.wfdefid,
    //       elg.wfeventid,
    //       ed.operationtype,
    //       ed.timestamp,
    // ed.uomvalue
    // )
    // SELECT *
    // FROM RankedData
    // WHERE rn = 1 -- Only take the latest row per workorderid
    // ORDER BY workorderid;
    // `
    const result = await query(sql, [stageId, activityId]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const eventlogUpdateService = async (req, res) => {
  try {
    const {
      wfeventId,
      status,
      userId,
      type,
      uomId,
      uomValue,
      comment,
      systemInfo,
    } = req.body;
    let sql = `update public.wms_workflow_eventlog set activitystatus=$2,userid=$3
    where wfeventid=$1 RETURNING wfeventid`;
    const eventupdate = await query(sql, [wfeventId, status, userId]);
    sql = `Insert into public.wms_workflow_eventlog_details(wfeventid,operationtype,userid,uomid,uomvalue,usercomments,timestamp,systemInfo)
      values($1,$2,$3,$4,$5,$6,CURRENT_TIMESTAMP,$7)`;
    await query(sql, [
      wfeventId,
      type,
      userId,
      uomId,
      uomValue,
      comment,
      systemInfo,
    ]);
    res.status(200).send(eventupdate);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const checkratevalidation_activity = async (wfDefId, workorderId) => {
  let retstatus = true;

  try {
    const confres = await getiTrackConfigData(wfDefId);

    if (confres != undefined && confres.issuccess == true) {
      const configData = confres.data;
      const checkratevalidation = configData[0].ratevalidation;

      if (checkratevalidation) {
        const chkratevalidation = await checkRateValidation(workorderId);

        if (
          chkratevalidation == undefined ||
          chkratevalidation.issuccess == false
        ) {
          retstatus = false;
        } else {
          retstatus = chkratevalidation.issuccess;
        }
      } else {
        retstatus = true;
      }
    } else {
      retstatus = true;
    }
    return retstatus;
  } catch (e) {
    return false;
  }
};

/** ******************START CLAIM************************* */

export const claim_SubjobEventdetail = async (req, res) => {
  const {
    workorderId,
    stageId,
    activityId,
    status,
    userid,
    wfDefId,
    serviceid,
    iteration,
    skillid,
    wfId,
    type,
    stageIterationCount,
  } = req.body;

  const returnobject = {
    id: 0,
    message: '',
    issuccess: false,
    chapterlist: [],
    targetNorms: 0,
  };

  try {
    let isProductionDispathcCompleted = {};
    if (type != 'assign') {
      isProductionDispathcCompleted = await checkProDisCompleted(
        workorderId,
        stageId,
        activityId,
        wfId,
        stageIterationCount,
      );
      if (!isProductionDispathcCompleted?.issuccess) {
        res.status(400).send({
          message: isProductionDispathcCompleted?.message,
        });
        return;
      }
      const checkNorms = await checkiTrackNorms(req.body, 'nonwms');
      if (!checkNorms.status) {
        res.status(400).send({ message: checkNorms?.remarks });
        return;
      }
      if (checkNorms.status && checkNorms.message === 'Norms mapped') {
        returnobject.targetNorms = checkNorms.data[0].targetsla;
      }
    }

    const confres = await checkratevalidation_activity(wfDefId, workorderId);
    if (!confres) {
      res.status(400).send({ message: 'Rate entry missing for this activity' });
      return;
    }

    // Check if event log exists
    const eventLogExists = await checkEventLog(
      workorderId,
      wfDefId,
      stageIterationCount,
    );

    // Insert event log if it doesn't exist
    if (!eventLogExists) {
      await insertEventLog(
        workorderId,
        wfDefId,
        status,
        serviceid,
        iteration || stageIterationCount,
        skillid,
        userid,
      );
    }

    // Get chapter list
    // returnobject.chapterlist = await getchapterlist_dropdown(
    //   workorderId,
    //   stageId,
    //   wfDefId,
    // );

    // Get instance type (SINGLE or MULTIPLE)
    const instanceType = await getInstanceType(wfDefId);

    // Handle SINGLE or MULTIPLE instances
    if (
      instanceType?.toUpperCase() === 'SINGLE' ||
      isProductionDispathcCompleted?.isCustomer
    ) {
      await handleSingleInstance(
        workorderId,
        stageId,
        activityId,
        userid,
        wfId,
        stageIterationCount,
      );
      returnobject.remark = 'Claimed successfully';
      returnobject.issuccess = true;
    } else if (instanceType?.toUpperCase() === 'MULTIPLE') {
      const result = await handleMultipleInstance(
        workorderId,
        stageId,
        activityId,
        userid,
        wfId,
        iteration || stageIterationCount,
      );
      if (result) {
        returnobject.id = result[0]?.subeventdetailid;
        returnobject.remark = 'Claimed successfully';
        returnobject.issuccess = true;
      }
    } else {
      returnobject.remark =
        'workflow instancetype should be single or multiple';
    }
    customerDispatchUpdate(
      workorderId,
      stageId,
      activityId,
      wfId,
      stageIterationCount,
    );
  } catch (error) {
    returnobject.message = error.message;
    res.status(400).send(returnobject);
    return;
  }

  res.status(returnobject.issuccess ? 200 : 400).send(returnobject);
};

const checkEventLog = async (workorderId, wfdefid, stageIterationCount) => {
  try {
    const sqlquery = `SELECT * FROM public.wms_workflow_eventlog WHERE workorderid = $1 AND wfdefid = $2 AND stageiterationcount = $3`;
    const result = await query(sqlquery, [
      workorderId,
      wfdefid,
      stageIterationCount,
    ]);
    return result.length > 0;
  } catch (error) {
    console.error('Error checking event log existence:', error);
    throw new Error('Failed to check event log existence.');
  }
};

const insertEventLog = async (
  workorderId,
  wfdefid,
  status,
  serviceid,
  iteration,
  skillid,
  userid,
) => {
  try {
    const insertLogQuery = `INSERT INTO public.wms_workflow_eventlog (workorderid, wfdefid, activitystatus, serviceid, stageiterationcount, skillid,activityiterationcount)
      VALUES ($1, $2, $3, $4, $5, $6,$7) RETURNING wfeventid`;

    const result = await query(insertLogQuery, [
      workorderId,
      wfdefid,
      status,
      serviceid,
      iteration,
      skillid,
      1,
    ]);

    if (result && result.length > 0) {
      const insertDetailsQuery = `INSERT INTO wms_workflow_eventlog_details (wfeventid, operationtype, timestamp, userid)
        VALUES ($1, $2, CURRENT_TIMESTAMP, $3)`;
      await query(insertDetailsQuery, [result[0].wfeventid, status, userid]);
    }
  } catch (error) {
    console.error('Error inserting event log:', error);
    throw new Error('Failed to insert event log.');
  }
};

const getInstanceType = async wfdefid => {
  try {
    const sqlquery = `SELECT instancetype FROM wms_workflowdefinition WHERE wfdefid = $1`;
    const result = await query(sqlquery, [wfdefid]);
    return result.length > 0 ? result[0].instancetype : null;
  } catch (error) {
    console.error('Error getting instance type:', error);
    throw new Error('Failed to get instance type.');
  }
};

const handleSingleInstance = async (
  workorderId,
  stageId,
  activityId,
  userid,
  wfId,
  iteration,
) => {
  try {
    const uomDetails = await getUOMArticleTitleDet(wfId, stageId, activityId);
    const { result, uomres } = uomDetails;
    let uom = uomres;
    if (!uomres)
      uom = result[0]?.itracksconfig?.uom_unit?.toLowerCase() || false;

    const sqlquery = `WITH cte AS (
      SELECT 
          wo.workorderid, 
          inc.stageId, 
          sj.subjobname, 
          sj.subjobid, 
          CASE 
              WHEN ed.subjobid IS NULL THEN 0 
              ELSE 1 
          END AS entrycount,
          CASE 
              WHEN $6::text = 'true' THEN 100
              WHEN $6 = 'ms pages' THEN wfi.mspages
              WHEN $6 = 'std. pages' AND msm.wordcount_per_page IS NOT NULL THEN wfi.wordcount / msm.wordcount_per_page
              WHEN $6 = 'std. pages' THEN 0
              WHEN $6 = 'word count' THEN wfi.wordcount
              WHEN $6 = 'images' THEN wfi.imagecount
              WHEN $6 = 'pdf pages' THEN wfi.estimatedpages
              WHEN $6 = 'no. of pages' THEN wfi.estimatedpages
              ELSE 0
          END AS remainingqty
      FROM 
          wms_workorder AS wo
      JOIN 
          public.org_mst_customer omc ON omc.customerid = wo.customerid
      LEFT JOIN 
          public.org_mst_deliveryunit odu ON odu.duid = wo.duid
      LEFT JOIN 
          public.mst_standardpage_measure AS msm 
          ON msm.customerid = omc.itrack_customerid 
          AND msm.duid = odu.itrackduid
      JOIN 
          wms_workorder_incoming AS inc ON inc.woid = wo.workorderid and inc.stageiterationcount = $7
      JOIN 
          wms_workorder_incomingfiledetails AS wfi ON wfi.woincomingid = inc.woincomingid
      JOIN 
          subjobdetails AS sj ON sj.subjobname = wfi.filename AND sj.workorderid = wo.workorderid
      LEFT JOIN 
          subjob_eventlog_details AS ed 
          ON ed.workorderid = sj.workorderid
          AND sj.subjobname = ed.subjobname 
          AND inc.stageId = ed.stageId 
          AND ed.activityId = $1 
          AND ed.stageiterationcount = $7
      WHERE 
          wo.workorderid = $2 
          AND inc.stageId = $3
  )
  INSERT INTO public.subjob_eventlog_details (
      workorderid, 
      stageId, 
      activityId, 
      subjobname, 
      subjobid, 
      status, 
      created_by, 
      created_time, 
      remainingqty,
      stageiterationcount
  )
  SELECT 
      workorderid, 
      stageId, 
      $4, 
      subjobname, 
      subjobid, 
      'YTS', 
      $5, 
      CURRENT_TIMESTAMP,
      remainingqty,
      $7
  FROM 
      cte 
  WHERE 
      entrycount = 0 
  RETURNING *;
`;

    await query(sqlquery, [
      activityId,
      workorderId,
      stageId,
      activityId,
      userid,
      uom, // Pass uomres as an additional parameter
      iteration,
    ]);

    // if (chapinsresult && chapinsresult.length) {
    const lstatus = await insertSubJobclaimedUser(
      workorderId,
      stageId,
      activityId,
      userid,
      iteration,
    );
    if (lstatus.status == false) {
      throw new Error(lstatus.msg);
    }
    // }
  } catch (error) {
    console.error('Error handling SINGLE instance:', error);
    throw new Error(error.message);
  }
};

const handleMultipleInstance = async (
  workorderId,
  stageId,
  activityId,
  userid,
  wfId,
  iteration,
) => {
  try {
    const { result, uomres } = await getUOMArticleTitleDet(
      wfId,
      stageId,
      activityId,
    );
    let uom = uomres;
    if (!uomres)
      uom = result[0]?.itracksconfig?.uom_unit?.toLowerCase() || false;
    let getsumpage = 0;
    if (uomres) {
      getsumpage = 100;
    } else {
      getsumpage = await gettotalestimatedpage(
        workorderId,
        stageId,
        activityId,
        uom,
        iteration,
      );
    }

    const sqlchk = ` SELECT *
    FROM public.subjob_eventlog_details
    WHERE workorderid = $1
      AND stageId = $2
      AND activityId = $3
      AND subjobname = 'All Chapters'
      AND stageiterationcount = $4
      `;

    const chkresult = await query(sqlchk, [
      workorderId,
      stageId,
      activityId,
      iteration,
    ]);
    let resultdata = [];
    if (
      chkresult &&
      chkresult.length &&
      chkresult[0].status &&
      chkresult[0].status?.toUpperCase() != 'PENDING'
    ) {
      //* ***********UPDATE************//
      const updateqry = `update public.subjob_eventlog_details set assigneduserid = $4, 
      remainingqty = $5 ,updated_by = $4, updated_time = CURRENT_TIMESTAMP 
      WHERE workorderid = $1
      AND stageId = $2
      AND activityId = $3
      and subjobname = 'All Chapters'
      AND stageiterationcount = $6
      RETURNING subeventdetailid
      
      `;
      resultdata = await query(updateqry, [
        workorderId,
        stageId,
        activityId,
        userid,
        getsumpage,
        iteration,
      ]);
    } else {
      //* ***********INSERT************//
      const sqlquery = `INSERT INTO public.subjob_eventlog_details (workorderid, stageId, activityId, subjobname, subjobid, status, created_by, created_time, assigneduserid, remainingqty, stageiterationcount)
    SELECT $1, $2, $3, 'All Chapters', 0, 'YTS', $4, CURRENT_TIMESTAMP, $4, $5, $6
    WHERE NOT EXISTS (
        SELECT 1
        FROM public.subjob_eventlog_details
        WHERE workorderid = $1
          AND stageId = $2
          AND activityId = $3
          AND subjobid = 0   
          AND stageiterationcount = $6
    )
    RETURNING subeventdetailid`;

      // const sqlqueryold = `INSERT INTO public.subjob_eventlog_details (workorderid, stageId, activityId, subjobname, subjobid, status, created_by, created_time, assigneduserid, remainingqty)
      //   SELECT $1, $2, $3, 'All Chapters', 0, 'YTS', $4, CURRENT_TIMESTAMP, $4 , $5 RETURNING subeventdetailid`;

      resultdata = await query(sqlquery, [
        workorderId,
        stageId,
        activityId,
        userid,
        getsumpage,
        iteration,
      ]);
    }
    await insertSubJobclaimedUser(
      workorderId,
      stageId,
      activityId,
      userid,
      iteration,
    );

    return resultdata;
  } catch (error) {
    console.error('Error handling MULTIPLE instance:', error);
    throw new Error(`Failed to handle MULTIPLE instance.${error.message}`);
  }
};

const insertSubJobclaimedUser = async (
  workorderId,
  stageId,
  activityId,
  userid,
  iteration,
) => {
  try {
    const qryclaim = `INSERT INTO public.subjob_claimed_user (workorderid, stageid, activityid, userid, stageiterationcount)
    VALUES ($1, $2, $3, $4, $5)
    ON CONFLICT (workorderid, stageid, activityid, userid) DO NOTHING;`;
    await query(qryclaim, [
      workorderId,
      stageId,
      activityId,
      userid,
      iteration,
    ]);

    return { status: true, msg: 'success' };
  } catch (error) {
    return { status: false, msg: error.message };
  }
};

const gettotalestimatedpage = async (
  workorderId,
  stageId,
  activityId,
  uom,
  iteration,
) => {
  let estimatedqty = 0;
  try {
    const qrysumpage = `SELECT 
    CASE 
        WHEN $4 = 'ms pages' THEN SUM(COALESCE(wfi.mspages, 0))
        WHEN $4 = 'std. pages' AND MAX(msm.wordcount_per_page) IS NOT NULL THEN 
            SUM(COALESCE(wfi.wordcount, 0)) / MAX(msm.wordcount_per_page)
        WHEN $4 = 'std. pages' THEN 0
        WHEN $4 = 'word count' THEN SUM(COALESCE(wfi.wordcount, 0))
        WHEN $4 = 'images' THEN SUM(COALESCE(wfi.imagecount, 0))
        WHEN $4 = 'pdf pages' THEN SUM(COALESCE(wfi.estimatedpages, 0))
        WHEN $4 = 'no. of pages' THEN SUM(COALESCE(wfi.estimatedpages, 0))

        ELSE 0
    END AS estimatedqty
            FROM wms_workorder AS wo
    JOIN public.org_mst_customer AS omc 
        ON omc.customerid = wo.customerid
    LEFT JOIN public.org_mst_deliveryunit AS odu 
        ON odu.duid = wo.duid
    LEFT JOIN public.mst_standardpage_measure AS msm 
        ON msm.customerid = omc.itrack_customerid AND msm.duid = odu.itrackduid
    JOIN wms_workorder_incoming AS inc 
        ON inc.woid = wo.workorderid and inc.stageiterationcount = $5
    JOIN wms_workorder_incomingfiledetails AS wfi 
        ON wfi.woincomingid = inc.woincomingid
    JOIN subjobdetails AS sj 
        ON sj.subjobname = wfi.filename AND sj.workorderid = wo.workorderid
    LEFT JOIN subjob_eventlog_details AS ed 
        ON ed.workorderid = sj.workorderid
        AND sj.subjobname = ed.subjobname
        AND inc.stageId = ed.stageId
        AND ed.activityId = $1
        AND ed.stageiterationcount = $5
    WHERE wo.workorderid = $2 
      AND inc.stageId = $3;

`;

    const result = await query(qrysumpage, [
      activityId,
      workorderId,
      stageId,
      uom,
      iteration,
    ]);

    if (result != undefined && result.length)
      estimatedqty = result[0].estimatedqty;

    return Math.round(Number(estimatedqty));
  } catch (error) {
    console.error('Error getting estimated pages:', error);
    throw new Error('Failed getting estimated pages.');
  }
};

// const queryDatabase = async (query, params) => {
//   try {
//     return await query(query, params);  // Assuming `query` is the function you use to interact with the DB
//   } catch (error) {
//     console.error('Database query error:', error);
//     throw new Error('Database query failed.');
//   }
// };

export const getchapterlist_dropdown = async (req, res) => {
  try {
    const { workorderid, stageid, activityid, userid, stageIterationCount } =
      req.body;
    const sql = `select subjobid as value,subjobname as label from subjob_eventlog_details where
      workorderid=$1 and stageid =$2 and activityid = $3 and (assigneduserid = $4 OR assigneduserid IS NULL) and
      status != 'Completed' and stageiterationcount=$5`;
    const result = await query(sql, [
      workorderid,
      stageid,
      activityid,
      userid,
      stageIterationCount,
    ]);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send(error);
  }
};

/** ******************END CLAIM************************* */

export const getchapterdetail_claimpage = async (req, res) => {
  const {
    workorderId,
    stageId,
    activityId,
    wfDefId,
    userId,
    wfId,
    stageIterationCount,
  } = req.body;
  try {
    const uomDetails = await getUOMArticleTitleDet(wfId, stageId, activityId);
    const { result, uomres } = uomDetails;
    let uom = uomres;
    if (!uomres)
      uom = result[0]?.itracksconfig?.uom_unit?.toLowerCase() || false;
    // const { uomres } = await getUOMArticleTitleDet(wfId, stageId, activityId);
    const qry = `SELECT 
    ROW_NUMBER() OVER (ORDER BY sev.starttime DESC) AS serial,
    --wfi.estimatedpages,
    msm.wordcount_per_page,
    wfi.mspages,
    wfi.imagecount,
    wfi.wordcount,
    wo.workorderid, inc.stageid, sev.activityid, sev.subjobname, sev.subjobid, sjd.subjobname AS subjob,
    sev.status, sev.qty, sev.remainingqty,wfi.typesetpage,
    COALESCE(TO_CHAR(ws.productiondespatchdate + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS productiondespatchdate,
    COALESCE(TO_CHAR(sev.starttime + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS starttime,
    COALESCE(TO_CHAR(sev.endtime + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS endtime,
    sev.created_by, sev.created_time + INTERVAL '330 minutes' AS created_time, sev.updated_by, sev.updated_time, 
    sev.assigneduserid, wfi.woincomingid, wfi.woincomingfileid,
    (SELECT COALESCE(itracksconfig->>'uom_unit', '') 
     FROM wms_workflowdefinition ww 
     WHERE wfdefid = $4) AS uomunit,
    (SELECT COALESCE(itracksconfig->>'isProduction', 'false') 
     FROM wms_workflowdefinition ww 
     WHERE wfdefid = $4) AS isProduction,
    (SELECT COALESCE(itracksconfig->>'isCustomer', 'false') 
     FROM wms_workflowdefinition ww 
     WHERE wfdefid = $4) AS isCustomer,
     (SELECT COALESCE(itracksconfig->>'ischecklist', 'false') 
     FROM wms_workflowdefinition ww 
     WHERE wfdefid = $4) AS ischecklist,
    sev.filepath,
    CASE
        WHEN $5::text = 'true' THEN 100
        WHEN LOWER(sev.subjobname) = LOWER('all chapters') THEN 
            (
                SELECT SUM(
                    CASE
                        WHEN $5 = 'ms pages' THEN wfi_inner.mspages
                        WHEN $5 = 'std. pages' THEN 
                            CASE
                                WHEN msm.wordcount_per_page IS NOT NULL THEN wfi_inner.wordcount / msm.wordcount_per_page
                                ELSE 0
                            END
                        WHEN $5 = 'word count' THEN wfi_inner.wordcount
                        WHEN $5 = 'images' THEN wfi_inner.imagecount
                        WHEN $5 = 'pdf pages' THEN wfi_inner.estimatedpages
                        WHEN $5 = 'no. of pages' THEN wfi_inner.estimatedpages
                        ELSE 0
                    END
                ) AS total
                FROM wms_workorder_incomingfiledetails wfi_inner
                WHERE wfi_inner.woincomingid = inc.woincomingid
            )
        ELSE (
            SELECT CASE
                WHEN $5 = 'ms pages' THEN wfi_inner.mspages
                WHEN $5 = 'std. pages' THEN 
                    CASE
                        WHEN msm.wordcount_per_page IS NOT NULL THEN wfi_inner.wordcount / msm.wordcount_per_page
                        ELSE 0
                    END
                WHEN $5 = 'word count' THEN wfi_inner.wordcount
                WHEN $5 = 'images' THEN wfi_inner.imagecount
                WHEN $5 = 'pdf pages' THEN wfi_inner.estimatedpages
                WHEN $5 = 'no. of pages' THEN wfi_inner.estimatedpages
                ELSE 0
            END
            FROM wms_workorder_incomingfiledetails wfi_inner
            WHERE wfi_inner.woincomingfileid = wfi.woincomingfileid
            LIMIT 1
        )
            END AS estimatedpages,
            CASE 
                WHEN sev.status = 'YTS' THEN 'yts'
                ELSE Lower(sev.status)
            END AS statusclass
        FROM wms_workorder AS wo
        LEFT JOIN subjobdetails sjd ON sjd.workorderid = wo.workorderid
        LEFT JOIN public.org_mst_deliveryunit odu ON odu.duid = wo.duid
        JOIN public.org_mst_customer omc ON omc.customerid = wo.customerid
        LEFT JOIN public.mst_standardpage_measure AS msm 
            ON msm.customerid = omc.itrack_customerid 
            AND msm.duid = odu.itrackduid
        LEFT JOIN subjob_eventlog_details AS sev 
            ON sev.workorderid = wo.workorderid 
            AND (sev.subjobid = sjd.subjobid OR sev.subjobid = 0) 
            AND sev.activityid = $3
            AND sev.stageid = $2
            AND sev.stageiterationcount = $6
        JOIN wms_workorder_incoming AS inc ON inc.woid = wo.workorderid and inc.stageiterationcount = $6
        JOIN wms_workorder_incomingfiledetails AS wfi 
            ON wfi.woincomingid = inc.woincomingid 
            AND wfi.filename = sjd.subjobname
            AND sev.stageid = inc.stageid
            AND sev.activityid = $3
        JOIN public.wms_workorder_stage ws 
            ON ws.workorderid = wo.workorderid 
            AND ws.wfstageid = $2
            AND ws.stageiterationcount = $6
        WHERE wo.workorderid = $1
          AND inc.stageid = $2
                `;

    const response = await query(qry, [
      workorderId,
      stageId,
      activityId,
      wfDefId,
      uom,
      stageIterationCount,
    ]);
    let chapterDetails = response.filter(row => {
      return (
        (row.assigneduserid === userId || row.assigneduserid === null) &&
        row.status != 'Completed'
      );
    });
    const allSubjobidAreZero = chapterDetails.every(
      item => Number(item.subjobid) === 0,
    );
    chapterDetails = allSubjobidAreZero ? [chapterDetails[0]] : chapterDetails;
    res.status(200).send({ chapterDetails, chapterList: response });
  } catch (error) {
    res.status(400).send(error);
  }
};
/** **************start subjob event log************************** */

// Utility function to update event log details
const updateEventLog = async (
  status,
  productivityqty,
  userid,
  workorderid,
  stageid,
  activityid,
  subjobname,
  condition,
  actiontype,
  filepath,
  iteration,
) => {
  let remainingqty = 0;
  let m_userid = status?.toUpperCase() === 'YTS' ? null : userid;

  if (
    actiontype?.toUpperCase() === 'CANCEL' ||
    actiontype?.toUpperCase() === 'PENDING'
  ) {
    m_userid = null;
  }

  try {
    const qrygetremaining = `select * from subjob_eventlog_details where workorderid = $1 and 
    stageid = $2 and 
    activityid = $3 and 
    subjobname = $4 and 
    stageiterationcount = $5
    `;

    const getremainingqty = await query(qrygetremaining, [
      workorderid,
      stageid,
      activityid,
      subjobname,
      iteration,
    ]);

    if (getremainingqty.length) {
      if (actiontype?.toUpperCase() != 'CANCEL') {
        const remainqty = getremainingqty[0].remainingqty;
        remainingqty = +remainqty - +productivityqty;
        if (remainingqty < 0) {
          throw new Error('Quantity cannot exceed the estimated page count');
        }
      } else {
        remainingqty = getremainingqty[0].remainingqty;
      }
      if (
        actiontype?.toUpperCase() == 'CANCEL' &&
        getremainingqty[0].assigneduserid != null &&
        getremainingqty[0].assigneduserid != userid
      ) {
        throw new Error('Allready another user taken this subjob');
      }
    }

    const qry_update = `update public.subjob_eventlog_details set 
      status = $1, 
      qty = $2,
      remainingqty = $3,     
      updated_by = $4,
      updated_time = current_timestamp,
      assigneduserid = $4,
      filepath = $9
      ${condition}
      where 
      workorderid = $5 and 
      stageid = $6 and 
      activityid = $7 and 
      subjobname = $8 and 
      stageiterationcount = $10
      returning subjobid`;

    const updresult = await query(qry_update, [
      status,
      productivityqty,
      remainingqty,
      m_userid,
      workorderid,
      stageid,
      activityid,
      subjobname,
      filepath,
      iteration,
    ]);

    if (
      actiontype?.toUpperCase() === 'CANCEL' ||
      actiontype?.toUpperCase() === 'PENDING'
    ) {
      const claimsubjobqty = `delete from  subjob_claimed_user where workorderid=$1 AND
      stageid=$2 and activityid=$3 and userid=$4 and stageiterationcount = $5`;

      await query(claimsubjobqty, [
        workorderid,
        stageid,
        activityid,
        userid,
        iteration,
      ]);
    }

    return { status: true, subjobid: updresult[0]?.subjobid };
  } catch (error) {
    console.error('Error in updateEventLog:', error);
    throw new Error(error);
  }
};

// Utility function
const checkOthersubjobStatus = async (
  workorderid,
  stageid,
  activityid,
  subjobname,
  status,
  iteration,
) => {
  try {
    const qry_checkstatus = `;WITH cte AS (
      SELECT sjob.subjobid, sjob.subjobname, sed.status, 
      CASE WHEN coalesce(sed.status, 'YTS') = $5 THEN 1 ELSE 0 END as calc
    FROM subjobdetails AS sjob
    LEFT JOIN subjob_eventlog_details AS sed ON 
        sjob.workorderid = sed.workorderid  
      AND sed.subjobname = sjob.subjobname  
      AND sed.stageid = $2 
      AND sed.activityid =$3
      AND sed.stageiterationcount = $6
      WHERE sjob.workorderid = $1
      AND sjob.subjobname != $4
    ) 
    select CASE WHEN SUM(calc) = count(cte.subjobid) THEN TRUE
    WHEN count(calc) = 0 Then TRUE
  ELSE false END as val
  FROM cte`;

    const result = await query(qry_checkstatus, [
      workorderid,
      stageid,
      activityid,
      subjobname,
      status,
      iteration,
    ]);
    return result ? result[0].val : false;
  } catch (error) {
    console.error('Error in checkInProcessStatus:', error);
    throw new Error('Failed to check in-process status.');
  }
};

// Utility function to check in-process status of subjobs
const checkInProcessStatus = async (
  workorderid,
  stageid,
  activityid,
  iteration,
) => {
  try {
    const qry_checkstatus = `;with cte as (
        select sjob.subjobid, sjob.subjobname, sed.status, 
        case when coalesce(sed.status, 'In Process') = 'Completed' then 0 else 1 end as calc
        from subjobdetails as sjob
        join subjob_eventlog_details as sed on 
          sjob.workorderid = sed.workorderid and 
          sed.subjobname = sjob.subjobname and 
          sed.stageid = $2 and
          sed.activityid = $3 and 
          sed.stageiterationcount = $4
        where sjob.workorderid = $1
      )
      select sum(calc) as val from cte`;

    const result = await query(qry_checkstatus, [
      workorderid,
      stageid,
      activityid,
      iteration,
    ]);
    return result ? +result[0].val : 0;
  } catch (error) {
    console.error('Error in checkInProcessStatus:', error);
    throw new Error('Failed to check in-process status.');
  }
};

// Utility function to update workflow event log
const updateWorkflowEventLog = async (
  status,
  workorderid,
  wfdefid,
  iteration,
  activityId,
  stageId,
  userid,
) => {
  try {
    const qry_insertevent = `update public.wms_workflow_eventlog set 
      activitystatus = $1
      where workorderid = $2 and wfdefid = $3 and stageiterationcount = $4 
      returning wfeventid`;

    const result = await query(qry_insertevent, [
      status,
      workorderid,
      wfdefid,
      iteration,
    ]);
    const claimsubjobqty = `delete from  subjob_claimed_user where workorderid=$1 AND
    stageid=$2 and activityid=$3 and userid=$4 and stageiterationcount = $5`;

    await query(claimsubjobqty, [
      workorderid,
      stageId,
      activityId,
      userid,
      iteration,
    ]);
    return result;
  } catch (error) {
    console.error('Error in updateWorkflowEventLog:', error);
    throw new Error('Failed to update workflow event log.');
  }
};

// Utility function to insert event log details
const insertEventDetail = async (wfeventid, status, userid) => {
  try {
    const qry_eventdetail = `INSERT INTO wms_workflow_eventlog_details
      (wfeventid, operationtype, timestamp, userid) 
      VALUES ($1, $2, current_timestamp, $3)`;

    await query(qry_eventdetail, [wfeventid, status, userid]);
    return true;
  } catch (error) {
    console.error('Error in insertEventDetail:', error);
    throw new Error('Failed to insert event log details.');
  }
};

// Utility function to handle configuration updates
const handleConfigUpdates = async (
  configdata,
  data,
  inProcessCount,
  chapterList,
  userid,
  filepath,
) => {
  try {
    let allprocessdone = true;
    let processmsg = '';
    let mailResp = '';
    if (configdata.length > 0) {
      const {
        isproduction,
        iscustomer,
        orderinflow,
        unbilledrevenue,
        ubrcalctype,
        invoice,
        oifcalctype,
      } = configdata[0];

      // Handle production despatch
      if (isproduction && inProcessCount == 0) {
        const ipresult = await updateProductivityDispatch(
          data.workorderId,
          data.stageId,
          data.stageIterationCount,
          chapterList,
          userid,
          data.wfDefId,
          filepath,
        );

        if (ipresult?.isSuccess != 'success') {
          processmsg = 'failed at productivity despatch';
          allprocessdone = false;
        }
        mailResp = ipresult?.mailReponse;
      }

      // Handle customer despatch
      if (iscustomer) {
        const icresult = await updateCustomerDispatch(
          data.workorderId,
          data.stageId,
          data.stageIterationCount,
          data.activityId,
          data.userid,
        );
        if (icresult != 'success') {
          processmsg = 'failed at customer dispatch';
          allprocessdone = false;
        }
      }
      // Handle Productivity
      const productivityparam = data;
      productivityparam.subJobId = productivityparam.subjobname;
      const itiresult = await checkitrackIntegration(
        productivityparam,
        'nonwms',
      );
      if (itiresult == undefined || itiresult.status == false) {
        processmsg = 'failed at productivity';
        allprocessdone = false;
      }

      // Handle order inflow
      if (orderinflow) {
        data.fc_oifcalctype = oifcalctype;
        data.type = 'new';

        const oifresult = await setOrdInflowService(data);

        if (oifresult?.toUpperCase() != 'SUCCESS') {
          processmsg = 'failed at orderinflow service';
          allprocessdone = false;
        }
      }

      let ubrresult = [];
      // Handle unbilled revenue integration
      if (unbilledrevenue && ubrcalctype) {
        if (
          ubrcalctype?.toLowerCase() == 'initial' ||
          ubrcalctype?.toLowerCase() == 'both'
        ) {
          data.servicetype = 'initialstagearticle';
          ubrresult = await ubrIntegrationService(data);
        }
        if (
          ubrcalctype?.toLowerCase() == 'dispatch' ||
          ubrcalctype?.toLowerCase() == 'both'
        ) {
          data.servicetype = 'dispatchstagearticle';
          ubrresult = await ubrIntegrationService(data);
        }

        // const ubrresult = await ubrIntegrationService(data);

        if (ubrresult == undefined || ubrresult.status == false) {
          processmsg = 'failed at ubr integration';
        }
      }

      if (invoice) {
        const invresult = await invoiceIntegrationService(data);
        if (invresult == undefined || invresult.status == false) {
          processmsg = 'failed at invoice integration';
          allprocessdone = false;
        }
      }
    }
    return {
      issuccess: allprocessdone,
      msg: processmsg,
      mailReponse: mailResp,
    };
  } catch (error) {
    console.error('Error in handleConfigUpdates:', error);
    return { issuccess: false, msg: error.message };
  }
};

const updateProductivityDispatch = async (
  workorderid,
  stageid,
  iteration,
  chapterList,
  userid,
  wfDefId,
  filepath,
) => {
  try {
    let totalQuantity = 0;
    if (chapterList.length > 0) {
      const script = ` update wms_workorder_incomingfiledetails set typesetpage=$2 where woincomingfileid = $1 returning woincomingfileid`;
      for (const row of chapterList) {
        totalQuantity += Number(row?.totalqty); // Update the total quantity
        await query(script, [row?.woincomingfileid, Number(row?.totalqty)]); // Await the query
      }
    }
    // typeset subjob total value
    const qry_proddesp = `update wms_workorder_stage set 
    productiondespatchdate = current_timestamp ,typesetpages = $4
    where workorderid = $1 and wfstageid = $2 and stageiterationcount = $3 
    returning wostageid`;
    await query(qry_proddesp, [workorderid, stageid, iteration, totalQuantity]);

    const mailReponse = await prodDespatchsendMail(
      70,
      'production_despatch',
      workorderid,
      stageid,
      chapterList,
      totalQuantity,
      userid,
      wfDefId,
      filepath,
    );
    return { isSuccess: 'success', mailReponse };
  } catch (error) {
    // console.log(error.message);
    return error.message;
  }
};

const updateCustomerDispatch = async (
  workorderid,
  stageid,
  iteration,
  activityid,
  userid,
) => {
  try {
    const qry_customerdesp = `update wms_workorder_stage set 
          enddatetime = current_timestamp, status = 'Completed',customerdespatchdate = current_timestamp
          where workorderid = $1 and wfstageid = $2 and stageiterationcount = $3 
          returning wostageid`;
    await query(qry_customerdesp, [workorderid, stageid, iteration]);

    const qry_update = `update public.subjob_eventlog_details set 
    status = 'Completed',  
    updated_by = $1,
    updated_time = current_timestamp,
    assigneduserid = $1
    where 
    workorderid = $2 and 
    stageid = $3 and 
    activityid = $4 and 
    stageiterationcount = $5 
    returning subjobid`;

    await query(qry_update, [
      userid,
      workorderid,
      stageid,
      activityid,
      iteration,
    ]);
    return 'success';
  } catch (error) {
    return error.message;
  }
};

// Get config data
const getiTrackConfigData = async wfDefId => {
  try {
    const qry_config = `select 
    (itracksconfig->>'isProduction')::boolean  as isproduction,
    (itracksconfig->>'isCustomer')::boolean as iscustomer,
    (itracksconfig->>'orderinflow')::boolean as orderinflow,
    (itracksconfig->>'unbilledrevenue')::boolean as unbilledrevenue,
    itracksconfig->>'ubrcalctype' as ubrcalctype,
    itracksconfig->>'oifcalctype' as oifcalctype,
    (itracksconfig->>'invoice')::boolean as invoice , 
    (itracksconfig->>'ratevalidation')::boolean as ratevalidation     
    from wms_workflowdefinition
    where wfdefid = $1`;

    const configData = await query(qry_config, [wfDefId]);
    return { issuccess: true, data: configData };
  } catch (error) {
    return { issuccess: false, msg: error.message };
  }
};

// check query status
const checkQueryStatus = async (worderorderId, stageId) => {
  try {
    const qry = `select count(*) from wms_workorder_query_list where  workorderid=$1 and querystatus = 'Open' and stageid = $2`;

    const result = await query(qry, [worderorderId, stageId]);
    return { issuccess: true, isOpen: result[0].count > 0 };
  } catch (error) {
    return { issuccess: false, msg: error.message };
  }
};

// Get config data
const checkRateValidation = async workorderId => {
  try {
    let hasrate = false;
    const qry = `SELECT w.wotype, w.journalid,  
       CASE WHEN w.wotype = 'Journal' THEN
	      EXISTS (SELECT 1 FROM salespmo.trn_journal_rate WHERE isactive = true AND journalid = w.journalid)          
       ELSE
           EXISTS (SELECT 1 FROM salespmo.trn_job_rate WHERE isactive = true AND  workorderid = w.workorderid)
       END AS hasentry
      FROM wms_workorder w
      WHERE w.workorderid = $1`;
    const getresult = await query(qry, [workorderId]);
    if (getresult && getresult.length) {
      hasrate = getresult[0].hasentry;
    }
    return { issuccess: hasrate, msg: 'success' };
  } catch (error) {
    return { issuccess: false, msg: error.message };
  }
};

// Main controller function
export const update_SubjobEventdetail = async (req, res) => {
  const {
    productivityqty,
    // typesetqty,
    userid,
    workorderId,
    stageId,
    activityId,
    subjobname,
    actiontype,
    wfDefId,
    stageIterationCount,
    filepath,
    chapterList,
  } = req.body;

  try {
    let condition = '';
    let status = '';
    let m_processcompleted = false;
    let m_configupdate = true;
    let m_remarks = '';
    let checkratevalidation = false;
    let m_subjobid = 0;
    let mailResp = '';
    // Handle different action types
    switch (actiontype?.toUpperCase()) {
      case 'CANCEL':
        condition = `,starttime=null`;
        status = 'YTS';
        break;
      case 'SAVE':
        condition = `, endtime = current_timestamp`;
        status = 'Completed';
        break;
      case 'START':
        condition = `, starttime = current_timestamp`;
        status = 'Work in progress';
        break;
      case 'PENDING':
        condition = '';
        status = 'Pending';
        break;
      default:
        throw new Error('Invalid action type');
    }

    m_remarks = 'Event log Updated process pending';

    // Get iTrack Config Data
    const confres = await getiTrackConfigData(wfDefId);

    if (confres == undefined && confres.issuccess == false) {
      throw new Error('itrack Config Data not fount');
    }

    const configData = confres.data;
    checkratevalidation = configData[0].ratevalidation;

    if (checkratevalidation && actiontype?.toUpperCase() != 'CANCEL') {
      const chkratevalidation = await checkRateValidation(workorderId);

      if (
        chkratevalidation == undefined ||
        chkratevalidation.issuccess == false
      ) {
        throw new Error('Rate entry not found');
      }
    }
    if (
      actiontype.toUpperCase() === 'SAVE' ||
      actiontype.toUpperCase() === 'PENDING'
    ) {
      if (actiontype.toUpperCase() === 'SAVE' && confres.data[0]?.iscustomer) {
        // check query status
        const queryisOpen = await checkQueryStatus(workorderId, stageId);
        if (queryisOpen == undefined && queryisOpen.issuccess == false) {
          throw new Error('Query status check failed');
        } else if (queryisOpen.isOpen) {
          throw new Error(
            'The query is not complete yet. Please finish it before saving the dispatch activity.',
          );
        }
      }
      const norms = await checkiTrackNorms(req.body, 'nonwms');
      if (!norms.status) {
        throw new Error(`For Productivity Calcuation${norms?.remarks}`);
      }
    }

    // Update the event log details
    const eventUpdate = await updateEventLog(
      status,
      productivityqty,
      userid,
      workorderId,
      stageId,
      activityId,
      subjobname,
      condition,
      actiontype,
      filepath,
      stageIterationCount,
    );

    if (eventUpdate.status == true) {
      m_subjobid = eventUpdate.subjobid;
      req.body.subJobId = m_subjobid;
      m_remarks = 'Event log Updated';

      if (actiontype?.toUpperCase() != 'SAVE') {
        const retupdatestatus = await updateeventlogstatus({
          workorderId,
          stageId,
          activityId,
          wfDefId,
          subjobname,
          actiontype,
          userid,
          stageIterationCount,
        });
        if (!retupdatestatus) {
          m_remarks = 'Event log Updated - Workflow not assigned';
        }
      }
    } else {
      m_remarks = 'Eventlog Update Failed';
    }
    if (actiontype?.toUpperCase() === 'SAVE') {
      let inProcessCount = -1;
      if (Number(req.body.subJobId) === 0) {
        inProcessCount = 0;
      } else {
        inProcessCount = await checkInProcessStatus(
          workorderId,
          stageId,
          activityId,
          stageIterationCount,
        );
      }

      if (inProcessCount === 0) {
        const updateresult = await updateWorkflowEventLog(
          status,
          workorderId,
          wfDefId,
          stageIterationCount,
          activityId,
          stageId,
          userid,
        );
        if (updateresult.length > 0) {
          const chkresult = await insertEventDetail(
            updateresult[0].wfeventid,
            status,
            userid,
          );
          if (!chkresult) {
            throw new Error('Failed on Insert Event Details');
          }
        }
      }

      // Fetch configuration data and perform related updates
      const checkupdate = await handleConfigUpdates(
        configData,
        req.body,
        inProcessCount,
        chapterList,
        userid,
        filepath,
      );

      if (checkupdate) {
        m_configupdate = checkupdate.issuccess;
        m_remarks = checkupdate.msg;
        mailResp = checkupdate?.mailReponse;
      }
    } else if (actiontype?.toUpperCase() === 'PENDING') {
      // Handle Productivity
      const productivityparam = req.body;
      productivityparam.subJobId = productivityparam.subjobname;
      const itrackresult = await checkitrackIntegration(
        productivityparam,
        'nonwms',
      );
      if (itrackresult == undefined || itrackresult.status == false) {
        m_remarks = itrackresult?.error;
        m_processcompleted = false;
      }
    } else {
      m_remarks += '-- success';
      m_processcompleted = true;
    }

    if (!m_configupdate) {
      m_remarks += ' -- iTracks Config Update Failed';
      m_processcompleted = m_configupdate;
    } else {
      m_remarks += '-- success';
      m_processcompleted = true;
    }

    res.status(m_processcompleted ? 200 : 400).send({
      issuccess: m_processcompleted,
      remark: m_remarks,
      mailReponse: mailResp,
    });
  } catch (error) {
    res.status(400).send({ issuccess: false, remark: error.message });
  }
};
// Helper function
export const updateworkfloweventlog = async (
  workorderId,
  wfDefId,
  statusname,
  userid,
  iteration,
) => {
  let status = false;
  try {
    const evsql = `update wms_workflow_eventlog set activitystatus = $3 WHERE workorderid = $1 
    and wfdefid = $2 and stageiterationcount = $4 returning wfeventid`;

    const evresult = await query(evsql, [
      workorderId,
      wfDefId,
      statusname,
      iteration,
    ]);

    if (evresult.length > 0) {
      const evdsql = `insert into public.wms_workflow_eventlog_details 
        (wfeventid,operationtype , timestamp, userid)
        values ($1,$2,current_timestamp,$3)`;

      await query(evdsql, [evresult[0].wfeventid, statusname, userid]);

      status = true;
    }
  } catch (error) {
    console.log(error);
    status = false;
  }
  return status;
};

// Helper function
export const updateeventlogstatus = async inputparam => {
  const {
    workorderId,
    stageId,
    activityId,
    wfDefId,
    subjobname,
    actiontype,
    userid,
    stageIterationCount,
  } = inputparam;
  let status = false;
  try {
    if (actiontype?.toUpperCase() == 'START') {
      status = await updateworkfloweventlog(
        workorderId,
        wfDefId,
        'Work in progress',
        userid,
        stageIterationCount,
      );
    } else if (actiontype?.toUpperCase() == 'PENDING') {
      const chkpendcount = await checkOthersubjobStatus(
        workorderId,
        stageId,
        activityId,
        subjobname,
        'Pending',
        stageIterationCount,
      );
      if (chkpendcount) {
        status = await updateworkfloweventlog(
          workorderId,
          wfDefId,
          'Pending',
          userid,
          stageIterationCount,
        );
      } else {
        status = true;
      }
    } else if (actiontype?.toUpperCase() == 'CANCEL') {
      const chkpendcount = await checkOthersubjobStatus(
        workorderId,
        stageId,
        activityId,
        subjobname,
        'Work in progress',
      );
      if (chkpendcount) {
        status = await updateworkfloweventlog(
          workorderId,
          wfDefId,
          'Unassigned',
          userid,
          stageIterationCount,
        );
      } else {
        status = true;
      }
    } else {
      status = true;
    }
  } catch (error) {
    status = true;
  }

  return status;
};

//* ********end subjob event log************* *//

// get uom details

export const getUOMArticleTitleDet = async (wfId, stageId, activityId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getUOMArticleTitle();
      let uomres = false;
      const result = await query(script, [wfId, stageId, activityId]);
      // if (result.length && result[0].itracksconfig?.isNewiTrackTrigger) {
      if (
        result[0].itracksconfig.uom_unit.toLowerCase() === 'article' ||
        result[0].itracksconfig.uom_unit.toLowerCase() === 'titles'
      ) {
        uomres = true;
      } else {
        uomres = false;
      }
      // } else {
      //   uomres = false;
      // }
      resolve({ result, uomres });
    } catch (error) {
      reject(error);
    }
  });
};

// this is for production dispatch the total quntity popup
export const checkisAllSubjobCompleted = async (req, res) => {
  try {
    const { workorderId, stageId, activityId, subjobId, stageIterationCount } =
      req.body;
    const qry_checkstatus = `SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN true 
        ELSE false 
    END AS all_completed
    FROM 
        subjob_eventlog_details
    WHERE 
    workorderid = $1
    AND stageid = $2
    AND activityid = $3     
    AND (status != 'Completed')
    AND subjobid != $4
    AND stageiterationcount = $5;`;

    const result = await query(qry_checkstatus, [
      workorderId,
      stageId,
      activityId,
      subjobId,
      stageIterationCount,
    ]);
    res.status(200).send({ result: result[0]?.all_completed });
  } catch (error) {
    res.status(400).send({ issuccess: false, remark: error.message });
  }
};
// this is for checkList update to workfloweventlog
export const updateChecklistService = async (req, res) => {
  try {
    const { wfeventid, checklist } = req.body;
    const updateCheckList = `UPDATE public.wms_workflow_eventlog
              SET checklist=$2::json
              WHERE wfeventid=$1;`;
    const result = await query(updateCheckList, [
      wfeventid,
      JSON.stringify(checklist),
    ]);
    res.status(200).send({ result });
  } catch (error) {
    res.status(400).send({ issuccess: false, remark: error.message });
  }
};
const executeQuery = async (qry, params, errorMessage) => {
  try {
    return await query(qry, params);
  } catch (error) {
    console.error(errorMessage, error);
    throw new Error(errorMessage);
  }
};

export const getWorkflowDefinitions = async (wfId, stageid) => {
  const qry = `
    SELECT * 
    FROM wms_workflowdefinition 
    WHERE wfid = $1 AND stageid = $2
  `;
  return executeQuery(
    qry,
    [wfId, stageid],
    'Error fetching workflow definitions',
  );
};

const isCustomerDispatch = (workflowDefinitions, activityid) =>
  workflowDefinitions.some(
    item =>
      Number(item.activityid) === Number(activityid) &&
      item.itracksconfig?.isCustomer,
  );

const isProductionDispatch = (workflowDefinitions, activityid) =>
  workflowDefinitions.some(
    item =>
      Number(item.activityid) === Number(activityid) &&
      item.itracksconfig?.isProduction,
  );

export const getProductionDispatchActivities = workflowDefinitions =>
  workflowDefinitions.filter(item => item.itracksconfig?.isProduction);

export const checkProductionDispatchCompleted = async (
  workorderid,
  stageid,
  wfdefid,
  iteration,
) => {
  const sql = `
    SELECT CASE
      WHEN wfe.activitystatus = 'Completed' THEN TRUE
      ELSE FALSE
    END AS isprodiscomp
    FROM public.wms_workflow_eventlog wfe
    LEFT JOIN public.wms_workorder_stage wfs 
      ON wfs.workorderid = wfe.workorderid AND wfs.wfstageid = $3
    WHERE wfe.workorderid = $1 
      AND wfe.wfdefid = $2
      AND wfe.stageiterationcount = $4 
      AND wfs.productiondespatchdate IS NOT NULL
      AND wfs.stageiterationcount = $4
  `;
  const result = await executeQuery(
    sql,
    [workorderid, wfdefid, stageid, iteration],
    'Error checking production dispatch completion',
  );
  return result[0]?.isprodiscomp || false;
};

const customerDispatchUpdate = async (
  workorderid,
  stageid,
  activityid,
  wfId,
  iteration,
) => {
  try {
    const workflowDefinitions = await getWorkflowDefinitions(wfId, stageid);

    if (isCustomerDispatch(workflowDefinitions, activityid)) {
      const proDispatches =
        getProductionDispatchActivities(workflowDefinitions);

      if (proDispatches.length) {
        const sql = `
        WITH cte AS (
          SELECT * 
          FROM public.subjob_eventlog_details 
          WHERE workorderid = $1 AND stageid = $2 AND activityid = $3 and stageiterationcount = $5
      )
      UPDATE subjob_eventlog_details
      SET filepath = cte.filepath, endtime = cte.endtime
      FROM cte
      WHERE subjob_eventlog_details.workorderid = $1 
        AND subjob_eventlog_details.stageid = $2 
        AND subjob_eventlog_details.activityid = $4
        AND subjob_eventlog_details.stageiterationcount = $5
        AND ( cte.subjobname = 'All Chapters' OR subjob_eventlog_details.subjobname = cte.subjobname)
        --AND ($6 = 'All Chapters' OR subjob_eventlog_details.subjobname = cte.subjobname)
        `;
        await executeQuery(
          sql,
          [
            workorderid,
            stageid,
            proDispatches[0]?.activityid,
            activityid,
            iteration,
          ],
          'Error updating customer dispatch',
        );
      }
    }
  } catch (error) {
    console.error('Error in customer dispatch update:', error);
    throw new Error('Failed to update customer dispatch.');
  }
};
export const rejectCustomerDispatch = async (req, res) => {
  try {
    const {
      workorderId,
      stageId,
      activityId,
      wfId,
      userId,
      stageIterationCount,
    } = req.body;
    const workflowDefinitions = await getWorkflowDefinitions(wfId, stageId);
    let rejectedResult = [];
    if (isCustomerDispatch(workflowDefinitions, activityId)) {
      const proDispatches =
        getProductionDispatchActivities(workflowDefinitions);

      if (!proDispatches.length) {
        res.status(200).send({
          rejectedResult,
          isproduction: false,
          message:
            'Production dispatch is not available for this stage. This activity cannot be rejected.',
        });
      }
      rejectedResult = await handleSingleInstanceGet(
        workorderId,
        stageId,
        proDispatches[0].activityid,
        userId,
        wfId,
        stageIterationCount,
      );

      //   const rejectDispatchQuery = `
      //   UPDATE subjob_eventlog_details
      //   SET status = 'Rejected',
      //       starttime = NULL,
      //       endtime = NULL,
      //       updated_by = $4,
      //       updated_time = CURRENT_TIMESTAMP
      //   WHERE workorderid = $1
      //     AND stageid = $2
      //     AND activityid = $3
      //   RETURNING workorderid;
      // `;

      const updateWorkflowEventQuery = `
      UPDATE public.wms_workflow_eventlog 
      SET activitystatus = 'Work in progress' 
      WHERE workorderid = $1 
      AND wfdefid = $2
      AND stageiterationcount = $3 ;
    `;
      const removeclaim = `delete from  subjob_claimed_user where workorderid=$1 AND
      stageid=$2 and activityid=$3 and stageiterationcount = $4`;

      // rejectedResult = await executeQuery(
      //   rejectDispatchQuery,
      //   [workorderId, stageId, proDispatches[0].activityid, userId],
      //   'Error rejecting customer dispatch',
      // );

      await executeQuery(
        updateWorkflowEventQuery,
        [workorderId, proDispatches[0]?.wfdefid, stageIterationCount],
        'Error updating workflow event log',
      );
      await executeQuery(
        removeclaim,
        [
          workorderId,
          stageId,
          proDispatches[0].activityid,
          stageIterationCount,
        ],
        'Error remove claimed for customer dispath',
      );
    }
    res.status(200).send({
      rejectedResult,
      isproduction: true,
      message: 'Rejected Successfully',
    });
  } catch (error) {
    res.status(400).send(error);
  }
};

const checkProDisCompleted = async (
  workorderid,
  stageid,
  activityid,
  wfId,
  iteration,
) => {
  try {
    const workflowDefinitions = await getWorkflowDefinitions(wfId, stageid);
    const isCustomer = isCustomerDispatch(workflowDefinitions, activityid);
    const isProduction = isProductionDispatch(workflowDefinitions, activityid);
    let message = '';
    if (!isCustomer && !isProduction) {
      return { message: '', issuccess: true, isCustomer };
    }
    if (isCustomer) {
      const proDispatches =
        getProductionDispatchActivities(workflowDefinitions);

      if (!proDispatches.length) {
        return { issuccess: true, message: '', isCustomer };
      }

      const isproductionCompleted = await checkProductionDispatchCompleted(
        workorderid,
        stageid,
        proDispatches[0]?.wfdefid,
        iteration,
      );
      message = isproductionCompleted
        ? 'Production dispatch completed'
        : 'Please complete the production dispatch before proceeding with the customer dispatch.';
      return { message, issuccess: isproductionCompleted, isCustomer };
    }
    if (isProduction) {
      const isActivitiesCompleted = await isPrevActivitiesCoompleted(
        workorderid,
        stageid,
        wfId,
        iteration,
      );
      message = isActivitiesCompleted
        ? 'Production dispatch previous activities are completed'
        : 'Please complete the previous activities before proceeding with the production dispatch.';
      return { message, issuccess: isActivitiesCompleted, isCustomer };
    }
    return { message: '', issuccess: true, isCustomer };
  } catch (error) {
    console.error('Error checking production dispatch completion:', error);
    throw new Error('Failed to check if production dispatch is completed.');
  }
};

export const isPrevActivitiesCoompleted = async (
  workorderid,
  stageid,
  wfid,
  iteration,
) => {
  const sql = `
  SELECT 
  CASE 
      WHEN COUNT(*) = 0 THEN true 
      ELSE false 
  END AS isall_act_completed
  FROM public.wms_workflowdefinition wd
  LEFT JOIN public.wms_workflow_eventlog we ON we.wfdefid = wd.wfdefid
  WHERE wd.stageid = $3
  AND wd.wfid = $2
  AND we.workorderid = $1
  AND activitystatus != 'Completed'
  AND we.stageiterationcount = $4
  AND wd.itracksconfig->>'isProduction' = 'false' 
  AND wd.itracksconfig->>'isCustomer' = 'false'
  `;
  const result = await executeQuery(
    sql,
    [workorderid, wfid, stageid, iteration],
    'Error checking production dispatch previous activities completion',
  );
  return result[0]?.isall_act_completed || false;
};

export const checkFlowType = async (req, res) => {
  try {
    const { duId } = req.params;
    let isnonwms = false;
    const qryflow = `select flowtype from public.trn_customerflowtype_config where duid = $1 limit 1`;
    const getflowtype = await query(qryflow, [duId]);

    if (
      getflowtype &&
      getflowtype.length > 0 &&
      getflowtype[0].flowtype == 'nonwms'
    ) {
      isnonwms = true;
    } else {
      isnonwms = false;
    }
    res.status(200).send(isnonwms);
  } catch (error) {
    res.status(400).send(error);
  }
};

export const getRoleAcronym = async (req, res) => {
  try {
    const { roleId } = req.params;
    const qry = `select roleacronym from public.wms_role where roleid = $1`;
    const roleAcronym = await query(qry, [roleId]);
    res.status(200).send(roleAcronym[0]?.roleacronym);
  } catch (error) {
    res.status(400).send(error);
  }
};

export async function prodDespatchsendMail(
  entityId,
  mailAction,
  workorderId,
  stageId,
  chapterList,
  totalQuantity,
  userid,
  wfDefId,
  filepath,
) {
  try {
    const resForConfig = await getEmailTemplate(entityId, mailAction);
    if (resForConfig) {
      const { notificationconfig } = resForConfig[0];

      const mailIDinTO = extractEmails(notificationconfig.to);
      const mailIDinCC = extractEmails(notificationconfig.cc);

      const TOGroup = notificationconfig.to;

      const mailDetails =
        workorderId != null && workorderId != ''
          ? await getMailForTo(TOGroup, workorderId, stageId)
          : [];
      let mailCC = await getMailForCC(
        mailDetails[0]?.duid,
        mailDetails[0]?.customerid,
        mailDetails[0]?.divisionid,
        mailDetails[0]?.subdivisionid,
        mailDetails[0]?.countryid,
      );
      mailCC = mailCC[0]?.email || [];

      const mailTo = [mailDetails[0]?.contactemail];

      const updatedNotificationConfig =
        await modifyNotificationConfigFromEmails(
          notificationconfig,
          mailIDinTO,
          mailIDinCC,
          mailTo,
          mailCC,
        );

      const userDetail = await getUserDetail(userid, wfDefId);

      const subJobDetails = await getEndDateforSubJob(
        workorderId,
        stageId,
        chapterList[0]?.activityid,
      );

      const updchapterList = chapterList.map(data => {
        data.endtime = subJobDetails.filter(
          item =>
            item.subjobid == data.subjobid &&
            item.subjobname == data.subjobname,
        )[0]?.taskendtime;
        // data.filePath = filepath;
        data.filePath = subJobDetails.filter(
          item =>
            item.subjobid == data.subjobid &&
            item.subjobname == data.subjobname,
        )[0]?.filepath;
        return data;
      });

      const mailData = {
        ...updatedNotificationConfig,
        itemCode: mailDetails[0]?.itemcode,
        jobTitle: mailDetails[0]?.title,
        stage: mailDetails[0]?.stagename,
        jobList: updchapterList,
        totalOutputQuantity: totalQuantity,
        filePath: filepath,
        userName: userDetail[0]?.userdet,
      };
      emitAction(mailData);
      return 'success';
    }
    return 'mail template missing';
  } catch (err) {
    return err;
  }
}

async function getMailForTo(role, workorderId, stageId) {
  const toSQL = `SELECT w.itemcode, w.title, w.duid, du.duname, ws.wfstageid, s.stagename, wc.contactname,
  wc.contactemail, w.customerid, w.divisionid, w.subdivisionid, w.countryid
  FROM public.wms_workorder w 
  LEFT JOIN public.wms_workorder_stage ws ON ws.workorderid = w.workorderid
  LEFT JOIN public.wms_mst_stage s ON s.stageid = ws.wfstageid
  LEFT JOIN public.wms_workorder_contacts wc ON wc.workorderid = ws.workorderid AND wc.contactrole = ANY($2)
  LEFT JOIN public.org_mst_deliveryunit du ON du.duid = w.duid
  WHERE w.workorderid = $1 AND ws.wfstageid = $3;`;
  const mailForTo = await query(toSQL, [workorderId, role, stageId]);
  return mailForTo;
}

async function getMailForCC(
  duId,
  customerId,
  divisionId,
  subdivisionId,
  countryId,
) {
  // const toSQL = `SELECT userid, useremail FROM public.wms_user WHERE (duid = $1 OR $1 = ANY(mappedduid)) AND useractive = true;`;
  const toSQL = `SELECT email FROM public.wms_config_customertabinfomapping WHERE duid = $1 AND customerid = $2 AND 
    $3 = ANY(divisionid) AND verticalid = $4 AND $5 = ANY(countryid) AND isactive = true;`;
  const mailForCC = await query(toSQL, [
    duId,
    customerId,
    divisionId,
    subdivisionId,
    countryId,
  ]);
  return mailForCC;
}

export function modifyNotificationConfigFromEmails(
  mailConfig,
  mailTo,
  mailCC,
  mailIDinTO,
  mailIDinCC,
) {
  // Combine all email IDs
  const allToEmails = [...mailTo, ...mailIDinTO];

  // Deduplicate and filter out null values
  mailConfig.to = [...new Set(allToEmails)].filter(
    email => email && email !== 'null',
  );

  mailConfig.cc = [...new Set([...mailCC, ...mailIDinCC])].filter(
    email => email && email !== 'null',
  );

  // Remove email IDs that exist in both to and cc arrays
  mailConfig.cc = mailConfig.cc.filter(email => !mailConfig.to.includes(email));
  return mailConfig;
}

const handleSingleInstanceGet = async (
  workorderId,
  stageId,
  activityId,
  userId,
  wfId,
  stageIterationCount,
) => {
  try {
    const uomDetails = await getUOMArticleTitleDet(wfId, stageId, activityId);
    const { result, uomres } = uomDetails;
    let uom = uomres;
    if (!uomres)
      uom = result[0]?.itracksconfig?.uom_unit?.toLowerCase() || false;

    const sqlquery = `
    WITH cte AS (
      SELECT 
          wo.workorderid, 
          inc.stageId, 
          sj.subjobname, 
          sj.subjobid, 
          CASE 
              WHEN ed.subjobid IS NULL THEN 0 
              ELSE 1 
          END AS entrycount,
          CASE 
              WHEN $5::text = 'true' THEN 100
              WHEN $5 = 'ms pages' THEN wfi.mspages
              WHEN $5 = 'std. pages' AND msm.wordcount_per_page IS NOT NULL THEN wfi.wordcount / msm.wordcount_per_page
              WHEN $5 = 'std. pages' THEN 0
              WHEN $5 = 'word count' THEN wfi.wordcount
              WHEN $5 = 'images' THEN wfi.imagecount
              WHEN $5 = 'pdf pages' THEN wfi.estimatedpages
              WHEN $5 = 'no. of pages' THEN wfi.estimatedpages
              ELSE 0
          END AS remainingqty
      FROM 
          wms_workorder AS wo
      JOIN 
          public.org_mst_customer omc ON omc.customerid = wo.customerid
      LEFT JOIN 
          public.org_mst_deliveryunit odu ON odu.duid = wo.duid
      LEFT JOIN 
          public.mst_standardpage_measure AS msm 
          ON msm.customerid = omc.itrack_customerid 
          AND msm.duid = odu.itrackduid
      JOIN 
          wms_workorder_incoming AS inc ON inc.woid = wo.workorderid and inc.stageiterationcount = $6
      JOIN 
          wms_workorder_incomingfiledetails AS wfi ON wfi.woincomingid = inc.woincomingid
      JOIN 
          subjobdetails AS sj ON sj.subjobname = wfi.filename AND sj.workorderid = wo.workorderid
      LEFT JOIN 
          subjob_eventlog_details AS ed 
          ON ed.workorderid = sj.workorderid
          AND sj.subjobname = ed.subjobname 
          AND inc.stageId = ed.stageId 
          AND ed.activityId = $1
          AND ed.stageiterationcount = $6
      WHERE 
          wo.workorderid = $2 
          AND inc.stageId = $3
  )
  UPDATE public.subjob_eventlog_details
  SET 
      status = 'Rejected',
      starttime = NULL,
      endtime = NULL,
      updated_by = $4,
      updated_time = CURRENT_TIMESTAMP,
      qty = 0,
      remainingqty = cte.remainingqty

  FROM cte
  WHERE 
      subjob_eventlog_details.workorderid = cte.workorderid
      AND subjob_eventlog_details.stageid = cte.stageId
      AND subjob_eventlog_details.activityid = $1
      AND (cte.entrycount = 0 OR subjob_eventlog_details.subjobid = cte.subjobid)
  RETURNING subjob_eventlog_details.workorderid  
`;

    await query(sqlquery, [
      activityId,
      workorderId,
      stageId,
      userId,
      uom, // Pass uomres as an additional parameter
      stageIterationCount,
    ]);
    // }
  } catch (error) {
    console.error('Error handling SINGLE instance:', error);
    throw new Error(error.message);
  }
};

async function getUserDetail(userId, wfDefId) {
  const script = `SELECT wd.wfdefid,wd.wfid,wd.skillid,s.skillname,u.userid,u.username,u.username || ', ' || s.skillname AS userdet
    FROM public.wms_workflowdefinition wd
    LEFT JOIN public.wms_mst_skill s ON s.skillid = wd.skillid AND isactive = true
    LEFT JOIN public.wms_user u ON u.userid = $1 AND useractive = true
    WHERE wd.wfdefid = $2 AND u.userid = $1;`;
  const userDet = await query(script, [userId, wfDefId]);
  return userDet;
}

async function getEndDateforSubJob(workordreId, stageId, activityId) {
  const script = `SELECT *, COALESCE(TO_CHAR(endtime + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS taskendtime
   FROM public.subjob_eventlog_details WHERE workorderid = $1 AND stageid = $2 AND activityid = $3;`;
  const userDet = await query(script, [workordreId, stageId, activityId]);
  return userDet;
}
