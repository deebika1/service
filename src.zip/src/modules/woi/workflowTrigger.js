import { query, transaction } from '../../database/postgres.js';
// import { appConfig } from '../../config/app.js';
import { getdmsType } from '../bpmn/listener/create.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';
import { sendToExternalTaskQueue } from '../../mq/index.js';
import { _engineFileCopy } from '../custom-uri/utils.js';

// ......................... #################### .............. //
// without camunda workflow trigger
// Article creation Module
export const triggerWithoutCamundaWorkflow = async (req, res) => {
  try {
    const payload = req.body;
    const response = await _triggerWithoutCamundaWorkflow(payload);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};
export const _triggerWithoutCamundaWorkflow = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let isTrigger = true;
      if (
        payload.wfId == 48 &&
        payload.pdfless &&
        payload.pdfless != 'undefined' &&
        payload.pdfless != 'null'
      ) {
        if (payload.stageId == 24) {
          const sql = `select activityalias from wms_workflowdefinition where wfid = ${payload.wfId} and activityid = ${payload.activityId} and stageid = ${payload.stageId}`;
          const data = await query(sql);
          if (
            data?.length > 0 &&
            data?.[0]?.activityalias == 'Proof Center' &&
            parseInt(payload?.pdfless) == 0
          ) {
            isTrigger = false;
          }
        }
      }

      if (
        payload.wfId == 48 &&
        payload.indexcorrectionid &&
        payload.indexcorrectionid != 'undefined' &&
        payload.indexcorrectionid != 'null'
      ) {
        if (
          payload.stageId == 24 &&
          parseInt(payload?.indexcorrectionid) == 0
        ) {
          isTrigger = false;
        }
      }

      if (isTrigger) {
        // const activityInfo = await getParallelActivityConfig(payload);
        //

        // if (activityInfo && activityInfo.length > 0) {
        try {
          // console.log(activityInfo, 'activityInfo');
          // for (const list of activityInfo) {
          let payloadCopy = { ...payload }; // Copying payload for each iteration to avoid conflicts
          // payloadCopy.activityId = list.activityId;
          // payloadCopy.activityType = list.activityType;

          payloadCopy = await getPayloadInfo(payloadCopy);

          const chapterLists = await getChapterListScript(payloadCopy);

          if (chapterLists.length) {
            const isGraphic = chapterLists.some(item => item.imagecount > 0);

            const allFiles =
              payloadCopy.stageId == 10
                ? chapterLists.filter(item => item.imagecount > 0)
                : chapterLists;

            const promises = allFiles.map((item, index) => {
              const newPayload = {
                ...payloadCopy,
                fileId: item.woincomingfileid,
                fileuuid: item.fileuuid,
                fileTypeId: item.filetypeid,
                isGraphic,
                loopIndex: index,
                arrLength: allFiles.length,
              };
              return startProcessService(newPayload);
            });
            await Promise.all(promises); // Concurrent execution of chapterLists

            if (payloadCopy.actionFlow !== 'next') {
              if (!payloadCopy?.skipAlreadyStageEntry) {
                const fileIds = chapterLists.map(item => item.woincomingfileid);
                await updateTriggerStatus(fileIds);
                await updateTriggerStatusOnService(payloadCopy.workorderId);
                await updateTriggerStatusOnStage(payloadCopy);
              }
            }
            resolve({
              status: true,
              message: 'Workflow triggered successfully',
            });
          } else {
            // throw new Error('File details not found for the workorder');
            resolve({
              status: true,
              message:
                'Workflow triggered skipped successfully without files info',
            });
          }
          // }
        } catch (error) {
          reject({
            message: error?.message || error || 'Error processing workflow',
          });
        }
        // } else {
        //   reject({ message: 'No activity found for the workorder' });
        // }
      } else {
        resolve({
          status: true,
          message: 'Workflow triggered skipped successfully',
        });
      }
    } catch (error) {
      reject({ error, message: error?.message });
    }
  });
};
// get chapter list
export const getChapterListScript = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        workorderId,
        woIncomingFileId,
        filetypeSkip,
        isnocorrectionskip,
      } = payload;
      let condition = ``;
      if (filetypeSkip && filetypeSkip.length) {
        condition += ` filetypeid not in (${filetypeSkip.join(',')}) and `;
      }
      if (isnocorrectionskip == 'Yes') {
        condition += ` is_correction = true and `;
      } else if (isnocorrectionskip == 'No') {
        condition += ` is_correction = false and `;
      }
      if (woIncomingFileId) {
        condition += `woid=${workorderId} and woincomingfileid=${woIncomingFileId} order by woincomingfileid asc `;
      } else {
        // condition += `woid=${workorderId} and ( istriggered IS FALSE OR istriggered IS NULL) order by woincomingfileid asc`;
        condition += `woid=${workorderId} order by woincomingfileid asc`;
      }
      const script = `select wms_workorder_incomingfiledetails.* from wms_workorder_incoming
      join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
      where ${condition}`;
      const response = await query(script);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

// update trigger status against the file
export const updateTriggerStatus = woIncomingFileIds => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `UPDATE public.wms_workorder_incomingfiledetails SET istriggered=true WHERE woincomingfileid=ANY($1)`;
      await query(script, [woIncomingFileIds]);
      resolve(
        `Trigger status updated successfully for ${woIncomingFileIds.toString()}`,
      );
    } catch (e) {
      reject(e);
    }
  });
};
// update trigger status on service
export const updateTriggerStatusOnService = workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `UPDATE public.wms_workorder_service SET isbookcompleted=true WHERE workorderid=$1`;
      const response = await query(script, [workorderId]);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
// stage triggered status
export const updateTriggerStatusOnStage = payloadCopy => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, stageId, plannedEndDate, stageIteration } =
      payloadCopy;

    try {
      if (plannedEndDate) {
        const script = `UPDATE public.wms_workorder_stage SET status='In Process',startdatetime = current_timestamp, plannedstartdate = current_timestamp, plannedenddate = $1, revisedenddatetime = $1, ordermaildatetime = current_timestamp  WHERE workorderid=$2 AND wfstageid=$3 AND stageiterationcount=$4`;
        const response = await query(script, [
          plannedEndDate,
          workorderId,
          stageId,
          stageIteration,
        ]);
        resolve(response);
      } else {
        const script = `UPDATE public.wms_workorder_stage SET status='In Process', startdatetime = current_timestamp  WHERE workorderid=$1 AND wfstageid=$2 AND stageiterationcount=$3`;
        const response = await query(script, [
          workorderId,
          stageId,
          stageIteration,
        ]);
        resolve(response);
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const startProcessService = payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      payloadCollection.dmsType = await getdmsType(
        payloadCollection.workorderId,
      );
      await transaction(async client => {
        payloadCollection.wfeventId = await createEventLog(
          payloadCollection,
          client,
        );
        // unassigned status
        const eventData = {
          actionType: 'Auto',
          wfeventId: payloadCollection.wfeventId,
          userId: payloadCollection.type === 'External Task' ? 'System' : null,
          status: 'Unassigned',
          taskType:
            payloadCollection.type === 'External Task'
              ? 'Engine Task'
              : 'User Task',
        };
        await updateEventLog(eventData, client);
        eventData.status = 'Created';
        eventData.actualActivityCount =
          payloadCollection.activity.actualIteration;
        eventData.userId = 'System';
        await updateEventLogDetails(eventData, client);
      });
      // check engine task and trigger
      await triggerEngineProcess(payloadCollection);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
export const getPayloadInfo = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // define key strucre
      payload = {
        ...payload,
        type: null,
        service: {
          name: null,
          id: null,
        },
        customer: {
          name: null,
          id: null,
        },
        du: {
          name: null,
          id: null,
        },
        job: {
          name: null,
          id: null,
        },
        stage: {
          name: null,
          id: null,
          iteration: null,
        },
        activity: {
          name: null,
          id: null,
          iteration: null,
          activityAlias: null,
          actualIteration: null,
        },
        date: {
          plannedStart: null,
          plannedEnd: null,
          orderMail: null,
        },
        skillId: null,
        wf: {
          defId: null,
          incomingFlows: [],
          defConfig: null,
          config: null,
          fileConfig: null,
          instanceType: null,
          category: null,
          eventId: null,
          wfId: null,
          activityModelTypeFlow: null,
        },
        nextActivityId: null,
        journalAcronym: null,
        topicName: null,

        isCTActivity: false,
        isDespatchActivity: false,
        woType: null,
        isDirectFirstProof: false,
        logoid: null,
        enableautostagetrnsf: null,
      };
      const activityInfo = await getFirstActivityId(payload);
      payload.activityId = activityInfo.activityId;
      payload.activityType = activityInfo.activityType;
      const { workorderId, stageId, stageIteration, serviceId, activityId } =
        payload;
      if (workorderId && stageId && stageIteration && activityId) {
        const wfDetailsData = await getWfDetails(payload);

        if (wfDetailsData.length) {
          const {
            skillid,
            stagename,
            activityname,
            duname,
            duid,
            jobname,
            jobid,
            servicename,
            wfdefid,
            customerid,
            customername,
            wfcategory,
            instancetype,
            isdespatchactivity,
            iscompletiontriggeractivity,
            plannedstartdate,
            plannedenddate,
            ordermaildate,
            isbookcompleted,
            wfdefconfig,
            wfconfig,
            incomingflows,
            fileconfig,
            wfid,
            activityalias,
            wotype,
            isfirstproof,
            logostatus,
            activitymodeltypeflow,
            pubflowconfig,
            issuemstid,
            ismscompleted,
            activitytype,
            nextactivityid,
            assignedby,
            journalacronym,
            isnocorrectionskip,
            enableautostagetrnsf,
          } = wfDetailsData[0];
          payload.type = activitytype;
          payload.skillId = skillid;
          payload.stage.name = stagename;
          payload.stage.id = stageId;
          payload.stage.iteration = stageIteration;
          payload.activity.name = activityname;
          payload.activity.id = payload.activityId;
          payload.activity.activityAlias = activityalias;
          payload.isCTActivity = !!iscompletiontriggeractivity;
          payload.isDespatchActivity = !!isdespatchactivity;
          payload.du.id = duid;
          payload.du.name = duname;
          payload.customer.id = customerid;
          payload.customer.name = customername;
          payload.service.name = servicename;
          payload.service.id = serviceId;
          payload.wfdefId = wfdefid;
          payload.wf.wfId = wfid;
          payload.wf.instanceType = instancetype;
          payload.wf.defConfig = wfdefconfig;
          payload.wf.fileConfig = fileconfig;
          payload.wf.incomingFlows = incomingflows || [];
          payload.wf.config = wfconfig;
          payload.wf.defId = wfdefid;
          payload.wf.category = wfcategory;
          payload.wf.activityModelTypeFlow = activitymodeltypeflow;
          payload.date.plannedStart = plannedstartdate;
          payload.date.plannedEnd = plannedenddate;
          payload.date.orderMail = ordermaildate;
          payload.isBookCompleted = isbookcompleted;
          payload.job.id = jobid;
          payload.job.name = jobname;
          payload.woType = wotype;
          payload.nextActivityId = nextactivityid;
          payload.assignedby = assignedby;
          payload.journalAcronym = journalacronym;

          payload.isDirectFirstProof = isfirstproof;
          payload.logoid = logostatus;
          payload.pubconfig = pubflowconfig || [];
          payload.IssuemstId = issuemstid || [];
          payload.ismscompleted = ismscompleted || [];
          payload.isnocorrectionskip = isnocorrectionskip;
          payload.enableautostagetrnsf = enableautostagetrnsf;
          // get workflow eventlog details
          const eventLogsData = await fetchWfDetails(payload);
          if (eventLogsData.length) {
            const filteredActivityData = eventLogsData.filter(
              data => data.activityid == payload.activity.id,
            );
            if (filteredActivityData.length) {
              payload.activity.iteration = parseInt(
                filteredActivityData[0].activityiterationcount,
              );
              payload.activity.actualIteration =
                parseInt(filteredActivityData[0].actualactivitycount) + 1;
            } else {
              payload.activity.iteration = 1;
              payload.activity.actualIteration = 1;
            }
          } else {
            payload.activity.iteration = 1;
            payload.activity.actualIteration = 1;
          }
          payload.filesInfo = [];
          resolve(payload);
        } else {
          reject('workflow definition was not updated');
        }
      } else {
        reject(
          `Mandatory fields (workorderId / stageId / stageIteration / activityId  ) are missing`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};
// create event log
export const createEventLog = (data, client) => {
  const {
    workorderId,
    wfdefId,
    skillId,
    parentActivityInstance,
    activityInstanceId,
    taskInstanceId,
    stage,
    activity,
    fileId,
    service,
    payload,
  } = data;
  return new Promise(async (resolve, reject) => {
    try {
      if (workorderId == null || wfdefId == null) {
        reject({
          message: `Input error workorderId : ${workorderId} , wfdefId : ${wfdefId}`,
        });
      } else {
        const sql = `select * from public.create_event_log($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;
        const { rows } = await client.query(sql, [
          workorderId,
          wfdefId,
          parentActivityInstance,
          activityInstanceId,
          taskInstanceId,
          stage.iteration,
          activity.iteration,
          fileId,
          service.id,
          JSON.stringify(payload),
          skillId,
          activity.actualIteration,
        ]);
        resolve(rows.length ? rows[0].wfevent_id : null);
      }
    } catch (e) {
      reject(e);
    }
  });
};
// update event log
export const updateEventLog = (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { userId, status, wfeventId, actionType, taskType } = data;
      if (actionType == 'Auto') {
        const sql = `UPDATE public.wms_workflow_eventlog SET userid =$1, activitystatus =$2, tasktype=$3 WHERE wfeventid =$4 `;
        if (client) {
          await client.query(sql, [userId, status, taskType, wfeventId]);
        } else {
          await query(sql, [userId, status, taskType, wfeventId]);
        }
      } else {
        const sql = `UPDATE public.wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE wfeventid =ANY($3) `;
        if (client) {
          await client.query(sql, [userId, status, wfeventId]);
        } else {
          await query(sql, [userId, status, wfeventId]);
        }
      }
      resolve(wfeventId);
    } catch (e) {
      reject(e);
    }
  });
};
// update event log details
export const updateEventLogDetails = (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        wfeventId,
        status,
        actionType,
        userId,
        systemInfo,
        actualActivityCount,
      } = data;
      let sql = ``;
      if (actionType == 'Auto') {
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, actualactivitycount) VALUES ($1, $2, current_timestamp, $3, $4)`;
        if (client) {
          await client.query(sql, [
            wfeventId,
            status,
            userId,
            actualActivityCount,
          ]);
        } else {
          await query(sql, [wfeventId, status, userId, actualActivityCount]);
        }
      } else {
        const val = [];
        wfeventId.forEach(id => {
          val.push(
            `(${id},'${status}',current_timestamp,'${
              userId || 'System'
            }','${systemInfo}', ${actualActivityCount})`,
          );
        });
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount) VALUES ${val}`;
        if (client) {
          await client.query(sql);
        } else {
          await query(sql);
        }
      }
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const getFirstActivityId = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfId, stageId, activityId } = payload;
      let sql = ``;
      let response = [];
      if (activityId) {
        sql = `SELECT activityid, activitytype, instancetype FROM wms_workflowdefinition 
        WHERE wfid=$1 and stageid=$2 and activityid=$3 and lock=false order by sequence limit 1 `;
        response = await query(sql, [wfId, stageId, activityId]);
      } else {
        sql = `SELECT activityid, activitytype, instancetype FROM wms_workflowdefinition 
        WHERE wfid=$1 and stageid=$2 and lock=false order by sequence limit 1 `;
        response = await query(sql, [wfId, stageId]);
      }

      if (response.length) {
        resolve({
          activityId: response[0].activityid,
          activityType: response[0].instancetype,
        });
      } else {
        reject('Workflow activity information not found');
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const getWfDetails = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, serviceId, stageId, activityId, stageIteration } =
        payload;
      const sql = `SELECT * FROM public.wms_workflow_details
    where workorderId = $1 and serviceid = $2 and stageid = $3 and activityid = $4 and stageiterationcount = $5`;

      const wfDetails = await query(sql, [
        workorderId,
        serviceId,
        stageId,
        activityId,
        stageIteration,
      ]);
      wfDetails.forEach(item => {
        item.fileconfig = ReStructureFileConfig(item.fileconfig);
      });
      resolve(wfDetails);
    } catch (e) {
      reject(e);
    }
  });
};
export const fetchWfDetails = async payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, serviceId, stage } = payloadCollection;
      const sql = `SELECT wms_workflow_eventlog.*, wms_workflowdefinition.stageid, wms_workflowdefinition.activityid FROM public.wms_workflow_eventlog
      join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
      where activitystatus <> 'Unassigned' and workorderId = $1 and stageid = $2 and stageiterationcount = $3 and serviceid= $4 and activitystatus not in ('Inprocess','Error') order by wfeventid desc`;
      try {
        const eventLogsData = await query(sql, [
          workorderId,
          stage.id,
          stage.iteration,
          serviceId,
        ]);
        resolve(eventLogsData);
      } catch (e) {
        reject(e);
      }
    } catch (e) {
      console.log(e);
    }
  });
};
// check and trigger engine
export const triggerEngineProcess = payloadCollection => {
  return new Promise(async (resolve, reject) => {
    try {
      const { type } = payloadCollection;
      if (type === 'External Task') {
        await _engineFileCopy(payloadCollection);
        if (payloadCollection.wf?.activityModelTypeFlow === 'Batch') {
          if (
            payloadCollection?.loopIndex ==
            // eslint-disable-next-line no-unsafe-optional-chaining
            payloadCollection?.arrLength - 1
          ) {
            await notifyExternalTask(payloadCollection);
          }
        } else if (payloadCollection.wf?.activityModelTypeFlow != 'Batch') {
          await notifyExternalTask(payloadCollection);
        }
        resolve(true);
      } else {
        resolve(true);
      }
    } catch (e) {
      // update task status to Failed
      payloadCollection.status = 'Failed';
      payloadCollection.actionType = 'Auto';
      await updateEventLog(payloadCollection);
      await updateEventLogDetails(payloadCollection);
      reject(e);
    }
  });
};

const notifyExternalTask = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const externalTaskPayload = {
        wfId: payload.wfId,
        isCamundaFlow: false,
        topicName: payload.activity.activityAlias,
        wfeventid: payload.wfeventId,
        workOrderId: payload.workorderId,
        wfdefId: payload.wfdefId,
        skillId: payload.skillId,
        du: payload.du,
        customer: payload.customer,
        service: payload.service,
        stage: payload.stage,
        job: payload.job,
        activity: payload.activity,
        JournalAcronym: payload.journalAcronym,
        fileId: payload.fileId,
        isGraphic: payload.isGraphic,
        activitymodeltypeflow: payload.wf.activityModelTypeFlow,
        filetypeid: payload.fileTypeId,
        placeHolders: payload.placeHolders,
        filetypeskipfornextactivity: payload.filetypeSkip,
        enableautostagetrnsf: payload.enableautostagetrnsf,
        // previousWf: this.wfDetails.previousWf,
        // fileId: this.getFileId(),
        // variables: payload.variables,
        // tooloutputid: '',
        // iAuthor: {},
        // activitymodeltypeflow: this.activityDetails.wf.activityModelTypeFlow,
      };
      await sendToExternalTaskQueue(externalTaskPayload);
      await externalTaskUpdate(externalTaskPayload);

      resolve(true);
    } catch (err) {
      reject(err);
    }
  });
};
const externalTaskUpdate = async payload => {
  const { wfeventid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const requestStr = JSON.stringify(payload);
      const escapedValueReq = requestStr.replace(/'/g, "''");
      const sql = `UPDATE public.wms_workflow_eventlog SET  externaltaskdata='${escapedValueReq}' WHERE wfeventid=${wfeventid}`;
      await query(sql);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const getParallelActivityConfig = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfId, stageId, currentActivityId } = payload;
      let sql = ``;
      let response = [];
      if (currentActivityId) {
        sql = `SELECT activityid, activitytype, instancetype, parallelactivityconfig FROM wms_workflowdefinition 
        WHERE wfid=$1 and stageid=$2 and activityid=$3 order by sequence limit 1 `;
        response = await query(sql, [wfId, stageId, currentActivityId]);
      } else {
        sql = `SELECT activityid, activitytype, instancetype,parallelactivityconfig FROM wms_workflowdefinition 
        WHERE wfid=$1 and stageid=$2 order by sequence limit 1 `;
        response = await query(sql, [wfId, stageId]);
      }
      let data = [];
      if (response && response.length) {
        const firstResponse = response[0];
        const { parallelactivityconfig, instancetype, activityid } =
          firstResponse;

        if (
          Array.isArray(parallelactivityconfig) &&
          parallelactivityconfig?.length > 0
        ) {
          data = parallelactivityconfig.map(list => ({
            activityId: list,
            activityType: instancetype,
          }));

          // To avoid duplicate entry for activityid, check before pushing
          // if (
          //   Array.isArray(parallelactivityconfig) &&
          //   !parallelactivityconfig.includes(activityid)
          // ) {
          //   data.unshift({
          //     activityId: activityid,
          //     activityType: instancetype,
          //   });
          // }
        } else {
          data = [
            {
              activityId: activityid,
              activityType: instancetype,
            },
          ];
        }

        resolve(data);
      } else {
        reject('Workflow activity information not found');
      }
    } catch (e) {
      reject(e);
    }
  });
};
// stage triggered status update for complete
export const _stageCompleteUpdate = payloadCopy => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, stageId, wfId, activityId } = payloadCopy;
    try {
      let isUpdate = false;
      const script = `select activityid from wms_workflowdefinition ww where ww.wfid = $1 and ww.stageid = $2 order by ww.sequence desc limit 1`;
      const response = await query(script, [wfId, stageId]);
      if (
        response &&
        response.length > 0 &&
        response[0].activityid == activityId
      ) {
        isUpdate = true;
      } else {
        // skip for specified activity
        // eslint-disable-next-line no-lonely-if
        if (stageId == 102 && activityId == 556) {
          isUpdate = true;
        }
      }
      if (isUpdate) {
        const script1 = `UPDATE public.wms_workorder_stage SET status='Completed', enddatetime = current_timestamp  WHERE workorderid=$1 AND wfstageid=$2`;
        await query(script1, [workorderId, stageId]);
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
