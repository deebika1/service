/* eslint-disable no-unused-vars */
/* eslint-disable */
import { transaction, query } from '../../database/postgres.js';
import { _upload } from '../utils/azure/index.js';
import { emitAction } from '../activityListener/index.js';
import { getNotificationConfig } from '../common/index.js';
import { getNotificationTemplate } from '../common/index.js';
import { oupIssueSchema, elsevierIssueSchema } from './schema.js';
import { validator } from '../../helper/validator.js';
import { createJob, checkItracksExits } from '../iTracks/index.js';
import {
  _autoIncomingCreationFromAPI,
  _autoIncomingForIssue,
} from './incoming.js';
import { workorderlog } from './woAutocreation.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import { _nextIssueStageTransferCheckTrigger } from '../task/action/workflow/save.js';
import { woxmlConfig, woKeyConfig } from '../bpmn/parser/core/config.js';
import {
  readXMLDatafromContent,
  readXMLData,
  getIdFromName,
  readKeyvalue,
} from './helper.js';
import xml2jsonConvertor from 'xml2js';

const service = new Service();

const jobTypeObj = {
  1: 'Article',
  2: 'Issue',
  3: 'Non Article',
};
let mailContainer = {
  action: '',
  from: '',
  to: '',
  customerName: '',
  customerId: '',
  stageName: '',
  iteration: '',
  subject: '',
  template: '',
  text: '',
};
let logId = 0;

// Issue Creation Module
export const autoIssueWorkorderCreation = async (req, res) => {
  try {
    const payload = req.body;
    const response = await _issueCreationContainer(payload);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};
// create auto issue workorder creation
export const _issueCreationContainer = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // issue flow type id
      payload.woTypeId = 4;
      // fields validation
      if (!payload) {
        throw new Error('Payload is required');
      }
      let schema = '';
      if (payload.customer === 'OUP') {
        schema = oupIssueSchema;
      } else if (payload.customer === 'Elsevier') {
        schema = elsevierIssueSchema;
      } else if (payload.customer === 'CUP Journals') {
        schema = '';
        payload.extractFiles = JSON.parse(payload.extractFiles);
        payload.mergeArticleInfo = JSON.parse(payload.mergeArticleInfo);
      } else if (payload.customer === 'Wolters Kluwer Health') {
        schema = '';
        payload.extractFiles = JSON.parse(payload.extractFiles);
        payload.mergeArticleInfo = JSON.parse(payload.mergeArticleInfo);
      }
      const validate = validator(payload, schema);
      if (!validate.status) {
        throw new Error(validate.message);
      }
      // --------- start the process ------ //
      const logRes = await woCreateLog(payload, 'Insert');
      logId = logRes.autologid;
      // await checkWOExists(payload);
      // await checkMergingTitleComplete(payload);
      payload = await constructPayloadForWorkorderCreation(payload);
      const { workorderId, message } = await woCreationProcess(payload);

      if (true) {
        // auto incoming creation
        const incomingPayload = await constructIncomingPayload(payload);
        const resOfIncoming = await _autoIncomingForIssue(incomingPayload);
      }

      // payload for mail
      mailContainer.action = 'auto_create_success';
      mailContainer.woTypeId = payload.woTypeId;
      mailContainer.subject = `Issue work order creation successfull for the title ${payload.title}`;
      mailContainer.message = message;
      mailContainer.customerId = payload.customerId;
      mailContainer.title = payload.title;
      mailContainer.stageName = payload.stage;
      // payload for workorder log
      payload.logMessage = message;
      payload.isSuccess = true;
      payload.workorderId = workorderId;
      payload.isStagetrigger = true;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      resolve({
        message: message,
        status: true,
        data: {
          workorderId: workorderId,
          pathToUpload: '',
        },
      });
    } catch (e) {
      if (payload.customerId) {
        mailContainer.customerId = payload.customerId;
        mailContainer.action = 'auto_create_failure';
      } else {
        mailContainer.action = 'common_failure';
        // get customer details from customer name
        const sql = `SELECT customerid FROM org_mst_customer WHERE LOWER(customername) = LOWER('${payload.customer}')`;
        const response = await query(sql);
        const customerId = response.length ? response[0].customerid : 0;
        mailContainer.customerId = customerId;
      }
      mailContainer.woTypeId = payload.woTypeId;
      mailContainer.subject = `Issue work order creation failed for the title ${payload.title}`;
      mailContainer.message = e.message ? e.message : e;
      mailContainer.title = payload.title;
      mailContainer.stageName = payload.stage;
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      payload.isStagetrigger = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject({
        message: e.message ? e.message : e,
        status: false,
      });
    }
  });
};
// need to be deleted
// // Article creation Module
// export const autoArticleWorkorderCreation = async (req, res) => {
//   try {
//     const payload = req.body;
//     const response = await _articleCreationContainer(payload);
//     res.status(200).send(response);
//   } catch (e) {
//     res.status(400).send({ status: false, message: e.message ? e.message : e });
//   }
// };
// // create auto issue workorder creation
// export const _articleCreationContainer = async payload => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       // fields validation
//       if (!payload) {
//         throw new Error('Payload is required');
//       }
//       const validate = validator(payload, oupIssueSchema);
//       if (!validate.status) {
//         throw new Error(validate.message);
//       }
//       // --------- start the process ------ //
//       const logRes = await woCreateLog(payload, 'Insert');
//       logId = logRes.autologid;
//       await checkWOExists(payload);
//       payload = await constructPayloadForWorkorderCreation(payload);
//       const { workorderId, message } = await woCreationProcess(payload);

//       // if (true) {
//       //   // auto incoming creation
//       //   const incomingPayload = await constructIncomingPayload(payload, data);
//       //
//       //   const resOfIncoming = await _autoIncomingCreationFromAPI(
//       //     incomingPayload,
//       //   );
//       // }

//       // payload for mail
//       mailContainer.action = 'auto_create_success';
//       mailContainer.subject = `Issue work order creation successfull for the title ${payload.title}`;
//       mailContainer.message = message;
//       mailContainer.customerId = payload.customerId;
//       mailContainer.title = payload.title;
//       // payload for workorder log
//       payload.logMessage = message;
//       payload.isSuccess = true;
//       payload.workorderId = workorderId;
//       payload.isStagetrigger = true;
//       await woCreateLog(payload, 'Update');
//       await sendMail(mailContainer);
//       resolve({
//         message: message,
//         status: true,
//         data: {
//           workorderId: workorderId,
//           pathToUpload: '',
//         },
//       });
//     } catch (e) {
//       if (payload.customerId) {
//         mailContainer.customerId = payload.customerId;
//         mailContainer.action = 'auto_create_failure';
//       } else {
//         mailContainer.action = 'common_failure';
//         // get customer details from customer name
//         const sql = `SELECT customerid FROM org_mst_customer WHERE LOWER(customername) = LOWER('${payload.customer}')`;
//         const response = await query(sql);
//         const customerId = response.length ? response[0].customerid : 0;
//         mailContainer.customerId = customerId;
//       }
//       mailContainer.subject = `Issue work order creation failed for the title ${payload.title}`;
//       mailContainer.message = e.message ? e.message : e;
//       mailContainer.title = payload.title;
//       // payload for workorder log
//       payload.logMessage = e.message ? e.message : e;
//       payload.isSuccess = false;
//       payload.isStagetrigger = false;
//       await woCreateLog(payload, 'Update');
//       await sendMail(mailContainer);
//       reject({
//         message: e.message ? e.message : e,
//         status: false,
//       });
//     }
//   });
// };

// workorder create log
const woCreateLog = (data, action) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        customer,
        jobType,
        woType,
        workorderId,
        logMessage,
        isSuccess,
        isStagetrigger,
        title,
        stage,
        ftpAuditId,
        extention,
      } = data;
      let sql = ``;
      if (action == 'Insert') {
        sql = `INSERT INTO log_autowocreate(apiinput,customer,filetype,wotype,jobtype,trigerarticle,trigerstage,ftpauditid) VALUES ('${JSON.stringify(
          data,
        )}', '${customer}','${extention}','${woType}','${jobType}','${title}','${stage}',${ftpAuditId}  ) RETURNING autologid`;
      } else {
        sql = `UPDATE public.log_autowocreate
        SET customer='${customer}', filetype='${extention}', wotype='${woType}', jobtype='${jobType}', payload='${JSON.stringify(
          data,
        )}', workorderid=${
          workorderId || null
        }, logmessage='${logMessage}', issuccess=${isSuccess}, isstagetrigger=${
          isStagetrigger || false
        }, trigerarticle='${title}', trigerstage='${
          stage || null
        }', ftpauditid=${ftpAuditId}

        WHERE autologid=${logId} RETURNING autologid`;
      }
      const response = await query(sql);
      resolve(response[0]);
    } catch (e) {
      reject(e);
    }
  });
};

// construct payload for workorder creation
const constructPayloadForWorkorderCreation = async item => {
  return new Promise(async (resolve, reject) => {
    const { customer, jobType } = item;
    try {
      // get journal information from customer and journal acronym
      const journalDetail = await getCustomerJournalDetail(item);
      if (journalDetail) {
        // change string to integer from journalDetails array
        journalDetail.customer = parseInt(journalDetail.customer);
        journalDetail.division = parseInt(journalDetail.division);
        journalDetail.subDivision = parseInt(journalDetail.subDivision);
        journalDetail.country = parseInt(journalDetail.country);
        journalDetail.duId = parseInt(journalDetail.duId);
        journalDetail.colours = parseInt(journalDetail.colours);
        journalDetail.softwares = parseInt(journalDetail.softwares);
        journalDetail.languages = parseInt(journalDetail.languages);
        journalDetail.CELevel = parseInt(journalDetail.CELevel);
        journalDetail.journalId = parseInt(journalDetail.journalId);
        journalDetail.custOrgMapId = parseInt(journalDetail.custOrgMapId);
        journalDetail.services = journalDetail.serviceId;
        journalDetail.custPrimaryContact = journalDetail.primaryContact;
        journalDetail.custSecondaryContact = journalDetail.secondaryContact;
        journalDetail.kamName = journalDetail.KAMContact;
        journalDetail.clientManager = journalDetail.CMContact;
        // create payload for workorder creation
        const jobTypeId = Object.keys(jobTypeObj).find(
          key => jobTypeObj[key] === jobType,
        );
        let sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE duid=$1 and customerid=$2`;
        const dmsInfo = await query(sql, [
          journalDetail.duId,
          journalDetail.customer,
        ]);
        const { dmsid } = dmsInfo.length ? dmsInfo[0] : '';
        if (dmsid) {
          const externalUsers =
            item.externalUsers && item.externalUsers.length
              ? item.externalUsers
              : [];
          const payload = {
            ...item,
            ...journalDetail,
            customerId: journalDetail.customer,
            userId: item.createdBy,
            doiNumber: item.title,
            jobId: item.title,
            jobTitle: item.title,
            jobTypeId: jobTypeId,
            externalUsers: [].concat(
              journalDetail.editorDetails,
              externalUsers,
            ),
            noOfChapters: item.mergeArticleInfo.length,
            pageWidth: journalDetail.trimesizewidth,
            pageWidthUnit: journalDetail.trimesizewidthuom,
            pageHeight: journalDetail.trimesizeheight,
            pageHeightUnit: journalDetail.trimesizeheightuom,
            dmsId: dmsid,
          };
          resolve(payload);
        } else {
          mailContainer.action = 'common_failure';
          mailContainer.subject = `DMS type not mapping for the customer ${customer}`;
          mailContainer.message = `DMS type not mapping for the customer ${customer}`;
          throw new Error(`DMS type not mapping for the customer ${customer}`);
        }
      } else {
        mailContainer.action = 'common_failure';
        mailContainer.subject = `Work order creation failed for due to journal details not found for the customer ${customer}`;
        mailContainer.message = `Journal details not found for the customer ${customer}`;
        throw new Error(
          `Journal details not found for the customer ${customer}`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

// workorder creation
const woCreationProcess = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // check iTracks exists for customer
      const iPayload = {
        customerId: payload.customer,
        duId: payload.duId,
        userId: payload.createdBy,
      };
      const { status } = await checkItracksExits({ body: iPayload }, {});
      let jobStatus = true;
      // to be changed once itracks enabled
      if (status) {
        //  create job card in iTracks
        jobStatus = await createJob(payload);
      }
      if (jobStatus) {
        let result = {};
        await transaction(async client => {
          result = await creation(payload, client);
        });
        const { data, message } = result;
        payload.workorderId = data.workorderid;
        resolve({ workorderId: data.workorderid, status: true, message });
      } else {
        throw new Error('Job creation failed in iTracks');
      }
    } catch (e) {
      // Mail trigger for error
      mailContainer = {
        action: 'auto_create_failure',
        woTypeId: payload.woTypeId,
        articlename: payload.title,
        to: [],
        customerId: payload.customer,
        duId: payload.duId,
        subject: `Work order creation failed for the title - ${payload.title}`,
        message: e.message ? e.message : e,
      };
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject(e);
    }
  });
};
export const checkMergingTitleComplete = data => {
  return new Promise(async (resolve, reject) => {
    const { mergeArticleInfo, title } = data;
    try {
      const sql = `SELECT itemcode FROM wms_workorder WHERE itemcode=$1 AND status=$2`;
      console.log(sql, 'sql for wo exists');
      const result = await query(sql, [mergeArticleInfo, 'Completed']);
      if (result.length == mergeArticleInfo.length) {
        resolve(true);
      } else {
        const data = mergeArticleInfo.map(item => `'${item}'`).join(', ');
        const sql = `UPDATE wms_workorder SET status='Completed' WHERE itemcode in (${data}) `;
        console.log(sql, 'sql for wo exists');
        const result = await query(sql);
        resolve(true);
        // reject({
        //   status: false,
        //   message: `One of the articles was not completed for the title - ${title}`,
        // });
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const checkWOExists = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { title, doiNumber } = data;
      const job = title ? title.trim() : '';
      const doi = doiNumber ? doiNumber.trim() : '';
      let condition = `WHERE itemcode='${job}'`;
      if (doi) {
        condition = `WHERE itemcode='${job}'  OR doinumber='${doi}'`;
      }

      const sql = `SELECT itemcode FROM public.wms_workorder ${condition} `;
      console.log(sql, 'sql for wo exists');
      const result = await query(sql);
      if (result.length) {
        reject({
          status: false,
          message: `Workorder already exists for the title - ${title}`,
        });
      } else {
        resolve({
          status: true,
          message: `Workorder not exists for the title - ${title}`,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        action,
        woTypeId,
        title,
        to,
        customerId,
        workorderId,
        serviceId,
        duId,
        message,
        stageName,
      } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        woTypeId,
        duId,
        customerId,
        workorderId,
        serviceId,
        stageName,
      };
      // const resForConfig = await getNotificationConfig(payload, action);
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        stageName,
        subMessage: message,
        toMail: toMailArray,
      };
      emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      console.log(e, 'ee');
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};

// get journal details from customer and journal acronym
const getCustomerJournalDetail = data => {
  const { customer, journalAcronym, duId } = data;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `select a.colorid::bigint as colours ,a.softwareid::bigint  as softwares ,a.languageid::bigint as languages ,a.celevelid::bigint as  "CELevel",a.printissn as "printISSN" ,
        b.divisionid::bigint as division ,b.subdivisionid::bigint as "subDivision",b.countryid::bigint as country ,b.customerid::bigint as  customer,d.duid as "duId",
        a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
        a.journalid as "journalId", a.trimesizewidth, a.trimesizewidthuom, a.trimesizeheight, a.trimesizeheightuom
        from pp_mst_journal a
              JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
              JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
              JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid AND d.duid=${duId}
              JOIN org_mst_customer e on e.customerid=b.customerid
              where a.isactive = 1 AND b.isactive = 1
              AND (LOWER(e.customername) = LOWER('${customer}')
              or  LOWER(e.customershortname) = LOWER('${customer}')
              )
              AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;
      const journalRes = await query(sql);
      if (journalRes.length) {
        sql = `select * from org_mst_customerorg_contact where custorgmapid=${journalRes[0].custOrgMapId}`;
        const journalContactRes = await query(sql);
        sql = ` select * from pp_mst_journal as journal join pp_mst_journal_contacts as journalcontact on
          journalcontact.journalid=journal.journalid where LOWER(journal.journalacronym) = LOWER('${journalAcronym}') and journal.custorgmapid=${journalRes[0].custOrgMapId}`;
        const journalOtherContactRes = await query(sql);

        const journalInfo = journalRes[0];
        journalContactRes.forEach(list => {
          if (list.isprimary && list.contacttype === 'Customer') {
            journalInfo.primaryContact = list.custorgconmapid;
          } else if (!list.isprimary && list.contacttype === 'Customer') {
            journalInfo.secondaryContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'KAM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.KAMContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'CM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.CMContact = list.custorgconmapid;
          }
        });
        if (journalOtherContactRes.length) {
          let ecInfo = journalOtherContactRes.filter(
            list => list.designation == 10,
          );
          journalInfo.editorDetails = ecInfo.map(item => {
            return {
              name: item.name,
              role: '10',
              email: item.email,
              roleAcronym: 'EC',
            };
          });
        }

        resolve(journalInfo);
      } else {
        reject({
          message: `Journal details not found for the customer ${customer} `,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};
// auto workorder, service, stage creation with transaction
const woCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // transaction for workorder, service, stage creation
      let responseOfWoCreation = { status: false, message: '' };
      await transaction(async client => {
        responseOfWoCreation = await creation(payload, client);
      });
      resolve(responseOfWoCreation);
    } catch (e) {
      reject(e);
    }
  });
};
// Workorder creation with transaction
export const creation = async (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { emailOrderDate } = data;
      const orderDate = emailOrderDate
        ? `'${emailOrderDate}'`
        : 'current_timestamp';

      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          if (data[key] === undefined) {
            data[key] = null;
          }
        }
      }

      // insert query for workorder creation in wms_workorder table
      let sql = `INSERT INTO public.wms_workorder(
        itemcode, title, projectbrief, printisbn, eisbn, issn, edition, customerid, 
        divisionid, subdivisionid, countryid, colorid, composingsoftwareid, inputfiletypeid, 
        languageid, celevelid, indextypeid, category, status, trimsizewidth, trimsizewidthuom,
        trimsizeheight, trimsizeheightuom, orderemailpath, orderemailpathuuid, totalchaptercount, 
        ordermaildate, journalid, jobtype, doinumber, wotype, totalarticlecount, totalnonarticlecount, 
        issuenumber, volumenumber, jobcardid, dmsid, createdby, duid, wfid
        )
        VALUES (
          '${data.jobId}', 
          '${data.jobTitle}',
          ${data.projectBrief ? `'${data.projectBrief}'` : null},
          ${data.printISBN ? `'${data.printISBN}'` : null},
          ${data.eISBN ? `'${data.eISBN}'` : null},
          ${data.ISSN ? `'${data.ISSN}'` : null},
          ${data.edition ? `'${data.edition}'` : null},
          ${data.customer ? data.customer : null}, 
          ${data.division ? data.division : null}, 
          ${data.subDivision ? data.subDivision : null}, 
          ${data.country ? data.country : null},
          ${data.colours ? data.colours : null}, 
          ${data.softwares ? data.softwares : null}, 
          ${data.inputFileTypes ? data.inputFileTypes : 4},
          ${data.languages ? data.languages : null}, 
          ${data.CELevel ? data.CELevel : null}, 
          ${data.indexType ? data.indexType : null},
          ${data.category ? `'${data.category}'` : null}, 
          'In Process',
          ${data.pageWidth ? data.pageWidth : null},
          ${data.pageWidthUnit ? `'${data.pageWidthUnit}'` : null},
          ${data.pageHeight ? data.pageHeight : null},
          ${data.pageHeightUnit ? `'${data.pageHeightUnit}'` : null},
          ${data.orderEmailPath ? `'${data.orderEmailPath}'` : null},
          ${data.orderEmailPathUuid ? `'${data.orderEmailPathUuid}'` : null},
          ${data.noOfChapters ? data.noOfChapters : null}, 
          ${orderDate ? orderDate : null}, 
          ${data.journalId ? data.journalId : null}, 
          ${data.jobTypeId ? `'${data.jobTypeId}'` : null}, 
          ${data.doiNumber ? `'${data.doiNumber}'` : null},
          ${data.woType ? `'${data.woType}'` : null}, 
          ${!isNaN(parseInt(data.noOfArticles)) ? data.noOfArticles : null},
          ${
            !isNaN(parseInt(data.noOfNonArticles)) ? data.noOfNonArticles : null
          },
          ${data.issueNumber ? `'${data.issueNumber}'` : null}, 
          ${data.volumeNumber ? `'${data.volumeNumber}'` : null}, 
          ${data.jobCardId ? data.jobCardId : null}, 
          ${data.dmsId ? data.dmsId : null}, 
          '${data.userId ? `${data.userId}` : `System`}', 
          ${data.duId ? data.duId : null}, 
          ${data.wfId ? data.wfId : null}
        ) RETURNING workorderid, customerid`;
      const response = await query(sql);
      const { workorderid, issuemstid } = response[0];
      // insert query for workorder contact details in wms_workorder_contact table
      // get contact detsils from org_mst_customerorg_contact_map table
      const getContactValues = `SELECT ${workorderid},custorgconmapid, contactname,contactemail,contactphone1,contactphone2,contactroleid,contacttype,isprimary 
          FROM org_mst_customerorg_contact WHERE custorgconmapid IN (${
            data.custPrimaryContact
          },${data.custSecondaryContact},
              ${data.kamName},${data.clientManager} ${
        data.subDivision !== 9 ? `,'${data.projectManager}'` : ''
      }) `;

      sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary)
          ${getContactValues} 
          RETURNING workorderid`;

      await client.query(sql);
      // insert query for pm entry to wms_workorder_contact table
      if (data.subDivision == 9) {
        const journalMappedPm = await workorderJournalMappedPmEntry(
          {
            projectManager: data.projectManager,
            supplierProjectManager: data.supplierProjectManager,
            workorderid,
          },
          client,
        );
      }
      let externalUserRes = [];
      if (
        data.externalUsers &&
        Object.keys(data.externalUsers).length &&
        data.externalUsers !== '{}'
      ) {
        externalUserRes = await workorderExternalUserEntry(
          { externalUsers: data.externalUsers, workorderid },
          client,
        );
      }
      const serviceResponse = await workorderServiceEntry(
        {
          duId: data.duId,
          services: data.services,
          custOrgMapId: data.custOrgMapId,
          workorderid,
          wfId: data.wfId,
        },
        client,
      );
      const { serviceid } = serviceResponse.data;
      await workorderStageEntry(
        {
          workorderid,
          wfId: data.wfId,
          serviceId: serviceid,
          userId: data.userId,
          plannedStartDate: data.plannedStartDate,
          plannedEndDate: data.plannedEndDate,
          receivedDate: data.plannedStartDate,
        },
        client,
      );
      // TAT calculation for stages
      await tatCalculationForStages(
        {
          workorderid,
          customerId: data.customer,
          journalId: data.journalId,
        },
        client,
      );
      resolve({
        data: { workorderid },
        message: `workorder created successfully (${workorderid})`,
      });
    } catch (e) {
      reject(e);
    }
  });
};

// journal mapped pm entry insert into wms_workorder_contact table
const workorderJournalMappedPmEntry = (payload, client) => {
  const { projectManager, supplierProjectManager, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${projectManager}' AND wms_userrole.roleid = 1
      UNION ALL
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${supplierProjectManager}' AND wms_userrole.roleid = 9
      `;

      const { rows } = await client.query(sql);
      let userArray = rows;
      if (projectManager == supplierProjectManager) {
        userArray = [].concat(rows, rows);
      }

      const val = [];
      userArray.forEach((list, i) => {
        val.push(`(${workorderid},'${list.contactname}','${
          list.contactemail
        }','${list.contactphone1}',
    '${list.roleacronym}', 'Integra' , ${i == 0}, '${list.userid}',${
          list.roleid
        })`);
      });
      sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, 
    contactphone1, contactrole, contacttype, isprimary, userid, roleid)
    VALUES ${val} RETURNING workorderid`;

      await client.query(sql);
      resolve({
        message: `Journal mapped pm added successfully (${workorderid})`,
      });
    } catch (e) {
      reject({ message: `Journal mapped pm added failed (${workorderid})` });
    }
  });
};
// external user entry insert into wms_workorder_contact table
const workorderExternalUserEntry = (payload, client) => {
  const { externalUsers, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const val = [];
      externalUsers.forEach(list => {
        val.push(`(${workorderid},'${list.name}','${list.email}',${
          list.phone1 ? `'${list.phone1}'` : null
        },
              '${list.roleAcronym}', 'Customer' , false, ${list.role})`);
      });

      const sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, contactphone1, contactrole, contacttype, isprimary, roleid)
              VALUES ${val} RETURNING contactrole,contactname,contactemail `;

      await client.query(sql);
      resolve({ message: `External user added successfully (${workorderid})` });
    } catch (e) {
      reject({ message: `External user added failed (${workorderid})` });
    }
  });
};
// workorder service entry insert into wms_workorder_service table
const workorderServiceEntry = (payload, client) => {
  const { duId, services, custOrgMapId, workorderid, wfId } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const getDataQuery = `SELECT org_mst_customerorg_service_map.serviceid,org_mst_deliveryunit.duid, org_mst_deliveryunit.duid as assignedduid, org_mst_deliveryunit.duid as internalbilling,true, ${workorderid}, ${wfId}, 'YTS' as status
      FROM org_mst_customerorg_service_map
      JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customerorg_service_map.custorgmapid
      JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = org_mst_customerorg_du_map.duid
      WHERE  org_mst_customerorg_service_map.serviceid IN (${services}) AND org_mst_customerorg_service_map.custorgmapid = ${custOrgMapId}
      AND org_mst_deliveryunit.duid = ${duId}`;
      const sql = `INSERT INTO public.wms_workorder_service(serviceid, baseduid, assignedduid,internalbilling,iscustomerbillable ,workorderid, wfid, status)
      ${getDataQuery} RETURNING woserviceid, workorderid, serviceid`;

      const { rows } = await client.query(sql);
      resove({
        message: `Service added successfully (${workorderid})`,
        data: { ...rows[0] },
      });
    } catch (e) {
      reject({ message: `Service added failed (${workorderid})` });
    }
  });
};
// workorder stage entry insert into wms_workorder_stage table
const workorderStageEntry = (payload, client) => {
  const {
    workorderid,
    wfId,
    serviceId,
    userId,
    plannedStartDate,
    plannedEndDate,
    receivedDate,
  } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const sqlQuery = `with cte as (SELECT DISTINCT ON(stageid) stageid, sequence
      FROM wms_workflowdefinition
      WHERE wfid IN (${wfId}) AND lock = false ) select * from cte order by sequence`;

      const { rows } = await client.query(sqlQuery);
      if (rows.length) {
        const values = [];
        rows.forEach((stage, i) => {
          if (i === 0) {
            values.push(
              `(${serviceId},${
                stage.stageid
              },'${userId}',${workorderid}, 'YTS', 1, ${
                stage.sequence
              }, current_timestamp, current_timestamp, ${
                plannedEndDate ? `'${plannedEndDate}'` : `current_timestamp`
              }, ${receivedDate ? `'${receivedDate}'` : `current_timestamp`} )`,
            );
          } else {
            values.push(
              `(${serviceId},${stage.stageid},'${userId}',${workorderid}, 'YTS', 1, ${stage.sequence}, current_timestamp, null, null, null)`,
            );
          }
        });
        const sql = `INSERT INTO public.wms_workorder_stage(serviceid, wfstageid, updatedby, workorderid, status, stageiterationcount, sequence, updatedon, plannedstartdate, plannedenddate, ordermaildatetime)
        VALUES ${values} RETURNING workorderid`;

        await client.query(sql);
        resove({ message: `Stage added successfully (${workorderid})` });
      } else {
        reject({ message: `No stages found the workorder (${workorderid})` });
      }
    } catch (e) {
      reject({ message: `Stage added failed (${workorderid})` });
    }
  });
};
// TAT calculation update for stages in wms_workorder_stage table
const tatCalculationForStages = (payload, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderid, customerId, journalId } = payload;
      const sql = `UPDATE wms_workorder_stage AS st SET plannedstartdate = cte.p_startdate ,plannedenddate = cte.p_duedate 
			FROM get_wo_autocreation_tat(${workorderid}::bigint,${customerId}:: bigint,${journalId}::bigint,1::integer) AS cte
			WHERE cte.p_wostageid = st.wostageid;`;

      await client.query(sql);
      resolve({ message: 'Stage TAT updated successfully' });
    } catch (e) {
      reject({ message: 'Stage TAT updated failed' });
    }
  });
};

// create incoming payload for auto incoming creation
export const constructIncomingPayload = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const file = [];
      // [
      //   {
      //     filetypeid: '',
      //     filetype: '',
      //     jobType: payload.jobType,
      //     filename: payload.title,
      //     extention: payload.extention,
      //     filepath: payload.sourcePath ? payload.sourcePath : null,
      //     fileuuid: '',
      //     duedate: payload.dueDate,
      //     mspages: payload.msPages,
      //     imagecount: payload.images,
      //     estimatedpages: 0,
      //     tablecount: 0,
      //     equationcount: 0,
      //     boxcount: 0,
      //     wordcount: 0,
      //     referencecount: 0,
      //     filesequence: 1,
      //   },
      // ];
      const sql = `
        SELECT wif.filetypeid, filetype, 'Article' as jobtype, filename, filepath, fileuuid, wif.duedate, mspages, imagecount, estimatedpages, tablecount, equationcount, boxcount, wordcount, referencecount, filesequence, ishalfpage, woid as workorderid, wo.createdon as article_date, pmj.journaltype as issue_type FROM wms_workorder_incomingfiledetails as wif
        JOIN pp_mst_filetype as pf ON pf.filetypeid = wif.filetypeid
        JOIN wms_workorder_incoming as wwi ON wwi.woincomingid = wif.woincomingid
        JOIN wms_workorder as wo ON wo.workorderid = wwi.woid
        JOIN pp_mst_journal pmj on pmj.journalid = wo.journalid
        WHERE wo.itemcode = ANY($1)`;
      const filesArray = await query(sql, [payload.mergeArticleInfo]);

      if (payload.wfId != 53 && payload.wfId != 55) {
        filesArray.forEach((list, i) => {
          file.push({
            filetypeid: list.filetypeid,
            filetype: list.filetype,
            jobType: list.jobtype,
            filename: list.filename,
            filepath: list.filepath,
            fileuuid: list.fileuuid,
            duedate: payload.dueDate,
            mspages: list.mspages,
            imagecount: list.imagecount,
            estimatedpages: list.estimatedpages,
            tablecount: list.tablecount,
            equationcount: list.equationcount,
            boxcount: list.boxcount,
            wordcount: list.wordcount,
            referencecount: list.referencecount,
            filesequence: i + 1,
            workorderid: list.workorderid,
          });
        });
      } else {
        payload.extractFiles.map(extractFile => {
          const matchedFile =
            filesArray.find(file => file.filename === extractFile.filename) ||
            null;
          file.push({
            ...extractFile,
            filepath: matchedFile?.filepath || null,
            fileuuid: matchedFile?.fileuuid || null,
            duedate: payload.dueDate,
            mspages: matchedFile?.mspages || null,
            imagecount: matchedFile?.imagecount || null,
            estimatedpages: matchedFile?.estimatedpages || null,
            tablecount: matchedFile?.tablecount || null,
            equationcount: matchedFile?.equationcount || null,
            boxcount: matchedFile?.boxcount || null,
            wordcount: matchedFile?.wordcount || null,
            referencecount: matchedFile?.referencecount || null,
            ishalfpage: matchedFile?.ishalfpage || null,
            workorderid: matchedFile?.workorderid || null,
            article_date: matchedFile?.article_date || null,
            issue_type: matchedFile?.issue_type || null,
          });
        });
      }

      let coverInfo = [],
        advertInfo = [];
      //CUP Issue Workflow
      const createFileInfo = (
        filetypeid,
        subfiletypeid,
        filename,
        filesequence,
        dueDate,
        typesetpage = null,
      ) => {
        return {
          filetypeid: filetypeid,
          subfiletypeid: subfiletypeid || null,
          filetype: filename === 'Advert' ? 'Advert' : 'Cover', // Assuming filename implies type
          filename: filename,
          filepath: null,
          fileuuid: null,
          duedate: dueDate,
          mspages: null,
          imagecount: null,
          estimatedpages: null,
          tablecount: null,
          equationcount: null,
          boxcount: null,
          wordcount: null,
          referencecount: null,
          filesequence: filesequence,
          is_correction: false,
          folio_type: 'num',
          article_status: 'Not processed in iWMS',
          assign_status: 'Get PM Confirmation',
          typesetpage: typesetpage,
        };
      };
      if (payload.wfId == 53 || payload.wfId == 55) {
        if (payload.isFrontCover === 'true') {
          coverInfo.push(
            createFileInfo(5, 28, 'Front Cover', 1, payload.dueDate, 1),
          );
        }

        // Back Cover
        if (payload.isBackCover === 'true') {
          const fileseq = payload.isAdvert
            ? payload.mergeArticleInfo.length + 3
            : payload.mergeArticleInfo.length + 2;
          coverInfo.push(
            createFileInfo(5, 29, 'Back Cover', fileseq, payload.dueDate, 1),
          );
        }

        // Advert
        if (payload.isAdvert === 'true') {
          advertInfo = [
            createFileInfo(
              6,
              24,
              'Advert',
              payload.mergeArticleInfo.length + 2,
              payload.dueDate,
              1,
            ),
          ];
        }
      }
      let finalFiles = [].concat(file, coverInfo, advertInfo);
      const incomingPayload = {
        workorderId: payload.workorderId,
        files: finalFiles,
        jobType: payload.jobType,
        fileType: payload.fileType,
        commonSourcePath: payload.sourcePath,
      };
      resolve(incomingPayload);
    } catch (e) {
      reject(e);
    }
  });
};

// get common path agdinst the wo and stage
const getCommonPathForStage = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { title, stage } = payload;
      const pathType = 'wo_stage_iteration_mail';
      const sql = `select a.workorderid,  a.customerid,i.customername, d.assignedduid, h.duname, d.wfid ,
         f.stageid,f.stagename, e.stageiterationcount,g.serviceid,g.servicename,
         concat('{"type": "'|| '${pathType}' :: text||'",
         "du":{"name":"', h.duname,'","id":"',d.assignedduid,'"},
         "customer":{"name":"',i.customername,'","id":"',a.customerid,'"},
         "workOrderId":"',a.workorderid,'",
         "service":{"name":"',g.servicename,'","id":"',g.serviceid,'"},
         "stage":{"name":"',f.stagename,'","id":"',f.stageid,'","iteration":"',e.stageiterationcount,'"}}') as stagepathpayload
        from wms_workorder a
        join wms_workorder_service d on d.workorderid = a.workorderid 
        join wms_workorder_stage e on e.workorderid = a.workorderid and d.serviceid = e.serviceid  
        join wms_mst_stage f on f.stageid = e.wfstageid and f.isactive = true
        join wms_mst_service g on g.serviceid = e.serviceid and g.isactive = true
        join org_mst_deliveryunit h on h.duid = d.assignedduid and h.isactive = true
        join org_mst_customer i on i.customerid = a.customerid
        where a.itemcode = '${title}' and f.stagename = '${stage}'`;

      const pathRes = await query(sql);
    } catch (e) {}
  });
};

// export const getWorkorderxmlData = async data => {
//   const {
//     customer,
//     woType,
//     jobType,
//     stagename,
//     stageiterationcount,
//     articlename,
//     journal,
//     fileType,
//     content,
//   } = data;
//   let currentkey = '';
//   return new Promise(async (resolve, reject) => {
//     try {
//       if (customer == 'OUP') {
//         currentkey = woKeyConfig.OUP_ISSUE_journalxmlkeys;
//       }
//       const xmlobjdata = await readXMLDatafromContent(content, woxmlConfig);
//       const setPayloads = {};
//       let errormsg = '';
//       if (xmlobjdata) {
//         const keyobj = JSON.parse(currentkey);
//         for (const [key, value] of Object.entries(keyobj[0])) {
//           if (key.includes('XML')) {
//             if (value.includes(',')) {
//               let xval = readKeyvalue(value, Object.values(xmlobjdata)[0]);
//               if (xval === undefined) {
//                 xval = '';
//                 errormsg =
//                   errormsg.length > 0
//                     ? `${errormsg}, ${key.replace(/^xml(?:DBID)?/i, '')}`
//                     : `${key.replace(/^xml(?:DBID)/i, '')}`;
//               }
//               xval =
//                 typeof xval === 'string' || typeof xval === 'number'
//                   ? xval
//                   : '';
//               if (key.includes('XMLDBID'))
//                 setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
//                   value: xval,
//                   keyconfig: key,
//                 });
//               else setPayloads[key.replace('XML', '')] = xval;
//             } else {
//               let dval = Object.values(xmlobjdata)[0][value];
//               const fval = typeof dval === 'object' ? dval[0] : dval;
//               if (key.includes('XMLDBID'))
//                 setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
//                   value: fval,
//                   keyconfig: key,
//                 });
//               else setPayloads[key.replace('XML', '')] = fval;
//             }
//           } else {
//             setPayloads[key] = value;
//           }
//         }
//       }
//
//       if (errormsg.length > 0) {
//         resolve({
//           message: `The following element is "${errormsg}" missing in metadata`,
//           status: false,
//           uploadpath: '',
//         });
//         return;
//       }
//       setPayloads.isauto = true;
//       setPayloads.jobId = articlename;
//       setPayloads.journalAcronym = journal;
//       setPayloads.woType = woType;
//       setPayloads.jobType = jobType;
//       setPayloads.customer = customer;
//       setPayloads.title = articlename;
//       setPayloads.stagename = stagename;
//       setPayloads.stageiterationcount = stageiterationcount;
//       setPayloads.extention = fileType;

//       resolve(setPayloads);
//     } catch (e) {
//       reject({
//         message: 'XML read operation failed',
//         status: false,
//       });
//     }
//   });
// };
