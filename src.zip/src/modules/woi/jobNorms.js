import { query } from '../../database/postgres.js';

export const woJobNormsMapping = (req, res) => {
  const reqData = req.body;
  console.log(reqData, 'req for jobnorms');
  const sql = `UPDATE wms_workorder_service
        SET jobnormsid='${reqData.jobnormsId}', complexityid='${reqData.complexityId}' WHERE serviceid = '${reqData.serviceId}' AND workorderid = ${reqData.workorderId}`;

  // if(reqData.jobnormsMapId){
  //     sql = `UPDATE wms_workorder_jobnorms_map
  //     SET duid='${reqData.duId}', workorderid='${reqData.workorderId}', serviceid='${reqData.serviceId}', wfid='${reqData.wfId}',
  //     jobnormsid='${reqData.jobnormsId}',complexityid='${reqData.complexityId}' WHERE jobnormsmapid = '${reqData.jobnormsMapId}'`;
  // } else {
  //     sql = `INSERT INTO public.wms_workorder_jobnorms_map(
  //     duid, workorderid, serviceid, wfid, jobnormsid, complexityid)
  //     VALUES (${reqData.duId}, ${reqData.workorderId}, ${reqData.serviceId}, ${reqData.wfId}, ${reqData.jobnormsId}, ${reqData.complexityId})`;
  // }
  console.log(sql, 'sql for jobnorms mapping');
  query(sql)
    .then(() => {
      console.log(sql, 'sql for jobnorms mapping');
      res.status(200).json({ message: 'Job Norms mapped successfully' });
    })
    .catch(() => {
      res.status(400).send({ message: 'Job Norms mapping failed' });
    });
};
export const getWOJobNormsMappedList = (req, res) => {
  const reqData = req.body;
  const sql = `SELECT wws.workorderid, wms.serviceid, wms.servicename, wf.wfid, wf.wfname as workflow, wmc.complexityid, wmc.complexity,
    wmj.jobnormsid, wmj.jobnormsname as jobnorms FROM wms_workorder_service as wws
    JOIN wms_mst_service as wms ON wms.serviceid = wws.serviceid 
    JOIN wms_workflow as wf ON wf.wfid = wws.wfid
    JOIN wms_mst_complexity as wmc ON wmc.complexityid = wws.complexityid
    JOIN wms_mst_jobnorms as wmj ON wmj.jobnormsid = wws.jobnormsid
    WHERE workorderid = ${reqData.workorderId}`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const deleteWOJobnormsMap = (req, res) => {
  const reqData = req.body;
  // const sql = `DELETE FROM wms_workorder_jobnorms_map WHERE jobnormsmapid = ${reqData.jobnormsMapId}`;
  const sql = `UPDATE wms_workorder_service
    SET jobnormsid=null, complexityid=null WHERE serviceid = '${reqData.serviceId}' AND workorderid = ${reqData.workorderId}`;

  query(sql)
    .then(data => {
      res.status(200).json({ data, message: 'Deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJobNormOptionList = (req, res) => {
  const getData = req.body;
  let sql = ``;
  if (getData.type === 'du') {
    sql = `SELECT DISTINCT ON (org_mst_deliveryunit.duid) org_mst_deliveryunit.duid as value, 
		org_mst_deliveryunit.duname as label FROM org_mst_customer_orgmap 
			JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
			 JOIN org_mst_deliveryunit ON org_mst_customerorg_du_map.duid = org_mst_deliveryunit.duid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} and
            org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId}  
            and  org_mst_deliveryunit.isactive=true order by org_mst_deliveryunit.duid`;
  } else if (getData.type === 'unit') {
    sql = `SELECT uomid as value, uom as label from wms_mst_uom where isactive=1 order by uomid `;
  } else if (getData.type === 'skilllevel') {
    sql = `SELECT skilllevelid as value, skilllevel as label FROM public.wms_mst_skilllevel
               ORDER BY skilllevelid ASC `;
  } else if (getData.type === 'complexity') {
    sql = `SELECT complexityid as value, complexity as label FROM public.wms_mst_complexity
             ORDER BY complexityid ASC`;
  } else if (getData.type === 'jobNormsBasedComplexity') {
    sql = `
        SELECT DISTINCT wmc.complexityid as value, wmc.complexity as label, wmj.effectivedate FROM public.wms_mst_jobnorms_details_map as jdm
        JOIN wms_mst_jobnorms as wmj ON wmj.jobnormsid = jdm.jobnormsid
		JOIN wms_mst_complexity as wmc ON wmc.complexityid = jdm.complexityid
        WHERE jdm.jobnormsid = ${getData.jobnormsId} AND wmj.effectivedate <= CURRENT_DATE
        ORDER BY wmc.complexityid ASC`;
  } else if (getData.type === 'jobNormsList') {
    sql = `SELECT jobnormsid as value, jobnormsname as label, effectivedate FROM public.wms_mst_jobnorms
        WHERE duid = ${getData.duId} AND divisionid = ${getData.divisionId} AND subdivisionid = ${getData.subDivisionId} AND customerid = ${getData.customerId}
        AND serviceid = ${getData.serviceId}  AND softwareid = ${getData.softwareId} AND filetypeid = ${getData.inputFiletypeId}
        AND wfid = ${getData.workflowId} AND effectivedate <= CURRENT_DATE
        ORDER BY jobnormsid ASC`;
    // AND categoryid = ${getData.categoryId}
  } else if (getData.type === 'division') {
    sql = `
        SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value,org_mst_division.division as label
        from org_mst_division
        WHERE org_mst_division.isactive=true order by org_mst_division.divisionid`;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap  
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId}  and org_mst_subdivision.isactive=true`;
  } else if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label FROM org_mst_customer_orgmap  
            JOIN org_mst_customer ON org_mst_customer_orgmap.customerid = org_mst_customer.customerid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId}  AND 
            org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId} and org_mst_customerorg_du_map.duid=${getData.duId}  and org_mst_customer.isactive=true`;
  } else if (getData.type === 'service') {
    sql = `SELECT  DISTINCT ON (service.serviceid)  service.serviceid as value, service.servicename as label FROM public.org_mst_customer_orgmap as custmap
                JOIN public.org_mst_customerorg_service_map as custservice ON custservice.custorgmapid = custmap.custorgmapid
                JOIN public.wms_mst_service as service ON service.serviceid = custservice.serviceid
                JOIN org_mst_customerorg_du_map as dumap ON dumap.custorgmapid = custmap.custorgmapid 
                WHERE  custmap.customerid=${getData.customerId} AND custmap.divisionid=${getData.divisionId} 
                AND custmap.subdivisionid=${getData.subDivisionId} AND dumap.duid = ${getData.duId}  and service.isactive=true`;
  } else if (getData.type === 'inputfiletype') {
    sql = `SELECT filetypeid as value, filetypename as label FROM public.pp_mst_inputfiletype ORDER BY filetypeid ASC `;
  } else if (getData.type === 'category') {
    sql = `SELECT categoryid as value, category as label FROM public.pp_mst_wocategory where isactive = 1
        ORDER BY categoryid ASC `;
  } else if (getData.type === 'workflow') {
    sql = `SELECT workflow.wfid as value, workflow.wfname as label
        FROM public.wms_workflow as workflow
        WHERE workflow.isactive = true AND  workflow.customerid =${getData.customerId}
        ORDER BY workflow.wfid ASC`;
  } else if (getData.type === 'softwares') {
    sql = `SELECT softwareid as value, softwarename as label FROM public.pp_mst_composingsoftware WHERE isactive = true`;
  }
  if (getData.type == 'stageactivity') {
    let stageArray = [];
    let activityarray = [];
    sql = `select * from(SELECT distinct on(def.stageid,def.activityid) stage.stageid,activity.activityid,def.sequence,workflow.wfid as value, workflow.wfname as label, def.wfid,stage.stagename,activity.activityname
        FROM public.wms_workflow as workflow
        left join wms_workflowdefinition as def on def.wfid = workflow.wfid
        left join wms_mst_stage as stage on stage.stageid = def.stageid
        left join wms_mst_activity as activity on activity.activityid = def.activityid
        WHERE workflow.isactive = true AND  workflow.customerid = ${getData.customerId} and def.wfid=${getData.workflowId}
        and (activity.iscompletiontriggeractivity!=true or activity.iscompletiontriggeractivity is null) and def.activitytype='User Task'
        ORDER BY def.stageid,def.activityid ASC) as table1 order by stageid,sequence`;
    query(sql)
      .then(data => {
        stageArray = [...new Set(data.map(stage => stage.stagename))];
        activityarray = unique(data, ['stagename', 'activityname']).map(
          ({ stagename, activityname, stageid, activityid }) => ({
            stagename,
            activityname,
            stageid,
            activityid,
          }),
        );
        let activityTemp = [];
        const finalArrayTemp = [];
        stageArray.forEach(stage => {
          const obj = {};
          let id = '';
          activityTemp = [];
          activityarray.forEach(activity => {
            if (stage === activity.stagename) {
              id = activity.stageid;
              activityTemp.push({
                name: activity.activityname,
                id: activity.activityid,
                checked: false,
              });
            }
          });
          obj.name = stage;
          obj.id = id;
          obj.activity = activityTemp;
          obj.opened = false;
          finalArrayTemp.push(obj);
        });
        res.status(200).json({ data: finalArrayTemp });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    console.log(sql, 'sql for optionsj');
    query(sql)
      .then(data => {
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};
const unique = (arr, keyProps) => {
  const kvArray = arr.map(entry => {
    const key = keyProps.map(k => entry[k]).join('|');
    return [key, entry];
  });
  const map = new Map(kvArray);
  return Array.from(map.values());
};
