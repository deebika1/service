import { query } from '../../database/postgres.js';

export const getStage = async (req, res) => {
  try {
    const { woId } = req.params;
    const sql = ` select s.stageid as value,s.stagename as label from public.wms_workorder wo
        left join public.wms_workflowdefinition wf on wf.wfid=wo.wfid
        left join public.wms_mst_stage s on s.stageid=wf.stageid and s.isactive=true
        where wo.workorderid= $1
        group by value,label`;
    const result = await query(sql, [woId]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const getService = async (req, res) => {
  try {
    const { woId } = req.params;
    const sql = `select s.serviceid as value , s.servicename as label from public.wms_workorder_service ws
      left join public.wms_mst_service s on s.serviceid = ws.serviceid and s.isactive=true
      where ws.workorderid= $1`;
    const result = await query(sql, [woId]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const insertStageService = async (req, res) => {
  try {
    const {
      // service,
      stage,
      receivedDate,
      orderMailDate,
      createdDate,
      // shortTat,
      plannedEndDate,
      woId,
    } = req.body;
    const sql = `Insert into public.wms_workorder_stage (serviceid,wfstageid,status,workorderid,plannedstartdate,plannedenddate,ordermaildatetime,short_tat_hour, receiveddate)
      values (1,$1,'YTS',$2,$3,$4,$5,$6,$7)`;
    const result = await query(sql, [
      // service,
      stage,
      woId,
      createdDate,
      plannedEndDate,
      orderMailDate,
      null,
      receivedDate,
    ]);
    res.status(200).send([{ result, message: 'Stage created successfully' }]);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const getStageDetailsService = async (req, res) => {
  try {
    const { woId } = req.params;
    const sql = `SELECT 
    ws.wfstageid,
    ws.wostageid,
    ws.status,
    ws.workorderid,
    TO_CHAR(ws.plannedstartdate, 'YYYY-MM-DD HH:mi') AS plannedstartdate,
    TO_CHAR(ws.plannedenddate, 'YYYY-MM-DD HH:mi') AS plannedenddate,
    TO_CHAR(ws.ordermaildatetime, 'YYYY-MM-DD HH:mi') AS ordermaildate,
    ws.short_tat_hour,
    TO_CHAR(ws.receiveddate, 'YYYY-MM-DD') AS receiveddate,
    s.stagename,
    'action' as action
FROM 
    public.wms_workorder_stage ws
LEFT JOIN 
    public.wms_mst_stage s ON s.stageid = ws.wfstageid
WHERE 
    ws.workorderid = $1;`;
    const result = await query(sql, [woId]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const updateStageService = async (req, res) => {
  try {
    const { receivedDate, shortTat, plannedEndDate, userId, wostageid } =
      req.body;
    const sql = `update public.wms_workorder_stage set plannedenddate=$2,short_tat_hour=$3,receiveddate=$4
   ,updatedby=$5,updatedon=CURRENT_TIMESTAMP
   where wostageid=$1`;
    const result = await query(sql, [
      wostageid,
      plannedEndDate,
      shortTat,
      receivedDate,
      userId,
    ]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};
export const checkStageStatus = async (req, res) => {
  try {
    const { wostageid } = req.params;
    const sql = `SELECT 
    CASE
      WHEN startdatetime IS NULL AND enddatetime IS NULL THEN TRUE
      ELSE FALSE
    END AS result
    FROM public.wms_workorder_stage 
    WHERE wostageid = $1`;
    const result = await query(sql, [wostageid]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const removeStage = async (req, res) => {
  try {
    const { wostageid } = req.body;
    const sql = `Delete FROM public.wms_workorder_stage  where wostageid=$1`;
    const result = await query(sql, [wostageid]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const dispatchStageService = async (req, res) => {
  try {
    const { stageId, woId, plannedEndDate, enddateTime, typesetPage, userId } =
      req.body;
    const sql = `update public.wms_workorder_stage set plannedenddate=$3,enddatetime=$4,typesetpages=$5,
    updatedby=$6,updatedon=CURRENT_TIMESTAMP
    where wfstageid=$1 and workorderid=$2`;
    await query(sql, [
      stageId,
      woId,
      plannedEndDate,
      enddateTime,
      typesetPage,
      userId,
    ]);
    res.status(200).send([{ message: 'Stage updated successfully' }]);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const createIncomingService = async (req, res) => {
  try {
    const {
      woId,
      serviceId,
      stageId,
      receiptDate,
      dueDate,
      batchNo,
      receiptDateTime,
      fileName,
      filePath,
      msPages,
      estimatedPages,
      imageCount,
      tableCount,
      equationCount,
      fileSequence,
      filetypeId,
      wordCount,
      pageNumber,
    } = req.body;
    const sql = `WITH first_insert AS (
      INSERT INTO public.wms_workorder_incoming 
      (woid, serviceid, stageid, receiptdate, duedate, batchno, receiptdatetime, isassigned) 
      VALUES ($1, $2, $3, $4,$5, $6, $7, false)
      RETURNING woincomingid
    ),
    second_insert AS (
      INSERT INTO public.wms_workorder_incomingfiledetails 
      (woincomingid, filename, filepath, duedate, mspages, estimatedpages, imagecount, tablecount, equationcount, filesequence, 
        isactive, filetypeid,istriggered, wordcount, pagenumber)
      VALUES ((SELECT woincomingid FROM first_insert), $8, $9, 
      $5, $10, $11, $12, $13, $14, $15, true, $16, true, $17, $18) RETURNING woincomingfileid
    )
    SELECT * FROM first_insert, second_insert`;
    const result = await query(sql, [
      woId,
      serviceId,
      stageId,
      receiptDate,
      dueDate,
      batchNo,
      receiptDateTime,
      fileName,
      filePath,
      msPages,
      estimatedPages,
      imageCount,
      tableCount,
      equationCount,
      fileSequence,
      filetypeId,
      wordCount,
      pageNumber,
    ]);
    res
      .status(200)
      .send([{ result, message: 'Incomming inserted successfully' }]);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const createEventlog = async (
  woId,
  wfId,
  stageId,
  iteration,
  skill,
  systemInfo,
) => {
  // try{
  let script =
    ' select * from public.wms_workflowdefinition where wfid=$1 and stageid=$2  order by sequence';
  const defid = await query(script, [wfId, stageId]);
  if (defid.length > 0) {
    script = `INSERT INTO public.wms_workflow_eventlog (workorderid , wfdefid, activitystatus,serviceid,stageiterationcount,skillid,systeminfo,activityiterationcount)
    VALUES ($1, $2,$3,1,$4,$5,$6,$7)`;
    await Promise.all(
      defid.map(async id => {
        const status = 'Unassigned';
        return query(script, [
          woId,
          id?.wfdefid,
          status,
          iteration,
          skill,
          systemInfo,
          1,
        ]);
      }),
    );
  }
  // }
  // catch(e){
  //  throw(e)
  // }
};

export const getitrackCustMapId = async (req, res) => {
  try {
    const { duId, customerId, divisionId, subDivisionId, countryId } = req.body;
    const sql = `SELECT custmapping FROM wms_config_customertabinfomapping map
    WHERE map.duid = $1 AND map.customerid = $2 
    AND $3 = ANY(map.divisionid) AND map.verticalid = $4
    AND $5 = ANY(map.countryid) AND map.isactive = true`;
    const result = await query(sql, [
      duId,
      customerId,
      divisionId,
      subDivisionId,
      countryId,
    ]);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send(e);
  }
};

export const getStageDropdown = async (req, res) => {
  const returnmsg = {
    message: '',
    issucccess: false,
    data: [],
  };
  try {
    const { type, woId, stageId, iteration } = req.body;
    let sql = '';
    switch (type) {
      case 'chapter':
        sql = `WITH initial_query AS (
                SELECT
                    subjobid AS value,
                    subjobname AS label
                FROM
                    public.subjobdetails
                WHERE
                    lower(subjobname) NOT IN (
                        SELECT 
                            CASE 
                                WHEN wid.filename IS NULL THEN ''
                                ELSE lower(wid.filename) 
                            END AS filename
                        FROM public.wms_workorder_incoming wi
                        LEFT JOIN public.wms_workorder_incomingfiledetails wid
                            ON wid.woincomingid = wi.woincomingid
                            AND wid.isactive = true
                           -- AND wid.duedate IS NOT NULL
                        WHERE wi.woid = $1
                        AND wi.stageiterationcount = ${iteration}
                        AND wi.stageid = ${stageId}
                    )
                AND workorderid = $1
                AND isactive = true
            )
            SELECT value,label FROM initial_query
            UNION ALL
            SELECT 0 AS value, 'All Chapters' AS label
            WHERE EXISTS (SELECT 1 FROM initial_query);`;
        break;
      case 'stage':
        sql = `
        select s.stageid as value,s.stagename as label from public.wms_workorder wo
        left join public.wms_workflowdefinition wf on wf.wfid=wo.wfid
        left join public.wms_mst_stage s on s.stageid=wf.stageid and s.isactive=true
        where wo.workorderid= $1
        group by value,label`;
        break;
      default:
        throw new Error('Invalid Param');
    }
    const result = await query(sql, [woId]);
    returnmsg.issucccess = true;
    returnmsg.data = result;
  } catch (error) {
    returnmsg.issucccess = false;
    returnmsg.message = error.message;
  } finally {
    if (returnmsg.issucccess == true) {
      res.status(200).json(returnmsg.data);
    } else {
      res.status(400).send({ issucccess: false, message: returnmsg.message });
    }
  }
};
