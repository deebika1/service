/* eslint-disable */
import { basename, dirname } from 'path';
import moment from 'moment';
import axios from 'axios';
import { query, transaction } from '../../database/postgres.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import {
  triggerStageWorkflow,
  triggerBatchCompletion,
} from '../utils/wfTrigger/index.js';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import {
  getNotificationConfig,
  getAuthAccessWorflow,
} from '../common/index.js';
import {
  addSubJob,
  checkItracksExits,
  addSatge,
  relatedStageInfo,
  mergeIssueForBatchFloq,
  getiTracksDuId,
  getiTracksCustomerId,
  getiTracksStageId,
  getFileDetails,
  getTATforStage,
  insert_itrackservicecall,
  oupaddstage,
} from '../iTracks/index.js';
import { multipleInstance } from '../master/index.js';
import { renameBlob } from '../utils/azure/index.js';
import { _nextIssueStageTransferCheckTrigger } from '../task/action/workflow/save.js';
import { _triggerWithoutCamundaWorkflow } from './workflowTrigger.js';
import { getdmsType } from '../bpmn/listener/create.js';
import { getBasePath } from '../utils/wmsFolder/index.js';
import * as azureHelper from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';
import { getFirstActivityInfo } from '../woi/incoming.js';
import { replacePlaceholders } from '../custom-uri/utils.js';
import { getSignalAuidtInfo } from '../../signalIntegration/service/index.js';
import {
  downloadAssetFile,
  getMetaData,
} from '../../signalIntegration/service/elseVier/altTextJobProcess.js';
import { ialtSignalLogHistory } from '../../iAlt/service/index.js';
import { isValidiTracksUrl } from '../../helper/validator.js';
import { srcFileDownloadFromPii } from '../../signalIntegration/service/elseVier/journalJobProcess.js';
import { ElsUpdateRevisedData } from '../woi/elsevierhelper.js';
import { _sendCampusSignal } from '../woi/woAutocreation.js';
// const iDuId = await getiTracksDuId(duId);
// const iCustomerId = await getiTracksCustomerId(customerId);
// const iStageId = await getiTracksStageId(data);
// const fileDetails = await getFileDetails(data);
// if (isrelatedstage) {
//   const relatedStagedet = await getTATforStage(woId, stageId);

const service = new Service();
const categories = {
  chapter: 'Chapterwise',
  book: 'Bookwise',
  article: 'Articlewise',
  issue: 'Issuewise',
};

export const queryWOStageChapters = async (
  category,
  incomingFileTypes,
  stageId,
  serviceId,
  stageIteration,
  woId,
) => {
  incomingFileTypes =
    category === 'Issuewise'
      ? incomingFileTypes.includes(10)
        ? (incomingFileTypes.splice(incomingFileTypes.indexOf(10), 1),
          incomingFileTypes)
        : incomingFileTypes
      : incomingFileTypes;
  let sql = `SELECT wms_workorder_incoming.woid, wms_workorder_incomingfiledetails.woincomingfileid as fileid, wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.filetypeid, pp_mst_filetype.filetype, pp_mst_filetype.allowsubfiletype,
    wms_workorder_incomingfiledetails.mspages, wms_workorder_incomingfiledetails.estimatedpages
    FROM public.wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid where wms_workorder_incoming.woid = $1 and wms_workorder_incomingfiledetails.filetypeid = any($2) ORDER BY fileid`;
  const incomingsData = await query(sql, [woId, incomingFileTypes]);
  sql = `SELECT * FROM public.wms_stage_chapter_details
    where workorderid = $1 and serviceid = $2 and stageid = $3 and stageiterationcount= $4 order by wfeventid asc`;
  const filesData = await query(sql, [
    woId,
    serviceId,
    stageId,
    stageIteration,
  ]);
  return getStageDetails(category, incomingsData, filesData);
};

//
export const queryWOStageFiles = async (
  category,
  incomingFileTypes,
  serviceId,
  woId,
) => {
  let sql = `SELECT wms_workorder_incoming.woid, wms_workorder_incomingfiledetails.woincomingfileid as fileid, wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.filetypeid, pp_mst_filetype.filetype, pp_mst_filetype.allowsubfiletype
    FROM public.wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid where wms_workorder_incoming.woid = $1 and wms_workorder_incomingfiledetails.filetypeid = any($2) ORDER BY fileid`;
  const incomingsData = await query(sql, [woId, incomingFileTypes]);
  sql = `SELECT * FROM public.wms_stage_chapter_details
    where workorderid = $1 and serviceid = $2 order by wfeventid asc`;
  const filesData = await query(sql, [woId, serviceId]);
  return getStageDetails(category, incomingsData, filesData);
};

const getStageDetails = (category, incomingsData, filesData) => {
  let stageDetails = [];
  switch (category) {
    case categories.chapter:
    case categories.article:
      stageDetails = getChapterData(incomingsData, filesData);
      break;
    case categories.book:
    case categories.issue:
      stageDetails = getBookData(incomingsData, filesData);
      break;
    default:
  }
  return stageDetails;
};

const getChapterData = (incomingsData, filesData) => {
  const files = [];
  for (let i = 0; i < incomingsData.length; i++) {
    const incomingData = incomingsData[i];
    const events = filesData.filter(
      fd => fd.woincomingfileid == incomingData.fileid,
    );
    const event = events[events.length - 1];
    console.log(event, 'eventevent');
    if (event) {
      const isCompletedChapter = !!event.iscompletiontriggeractivity;
      const isCTCreated = !!(
        event.iscompletiontriggeractivity &&
        event.activitystatus === 'Unassigned'
      );
      files.push({
        fileId: event.woincomingfileid,
        name: event.filename,
        type: event.filetype,
        wfeventId: event.wfeventid,
        isCompletedChapter,
        isCTCreated,
        stagename: `${event.stagename} (${event.stageiterationcount})`,
      });
    }
  }
  return { files };
};

const getBookData = (incomingsData, filesData) => {
  console.log(incomingsData, 'incomingsData');
  console.log(filesData, 'filesData');
  let isCTCreated = false;
  let isCompletedStage = false;
  let CTData = {};
  const files = [];
  for (let i = 0; i < incomingsData.length; i++) {
    const incomingData = incomingsData[i];
    files.push({
      id: incomingData.fileid,
      name: incomingData.filename,
      type: incomingData.filetype,
      filetypeid: incomingData.filetypeid,
      mspages: incomingData.mspages,
      estimatedpages: incomingData.estimatedpages,
    });
  }
  for (let j = 0; j < filesData.length; j++) {
    const event = filesData[j];
    if (!isCTCreated) {
      isCTCreated = !!(
        event.iscompletiontriggeractivity &&
        event.activitystatus === 'Unassigned'
      );
      CTData = {
        fileId: event.woincomingfileid,
        name: event.filename,
        type: event.filetype,
        wfeventId: event.wfeventid,
      };
    }
    if (!isCompletedStage) {
      isCompletedStage = !!event.iscompletiontriggeractivity;
    }
  }
  return { isCTCreated, isCompletedStage, CTData, files };
};

export const getWOStageLists = async (req, res) => {
  try {
    const { woId, pageNo, recordPerPage } = req.body;
    const offset = (pageNo - 1) * recordPerPage;
    let stagesql = `with cte as (SELECT DISTINCT ON (wms_workorder_stage.wostageid) wms_workorder_stage.wostageid,
    wms_workorder_stage.wfstageid,
	date_part('day'::text, CURRENT_TIMESTAMP::timestamp without time zone -
			  COALESCE(wms_workorder_stage.revisedenddatetime::timestamp without time zone, 
			  wms_workorder_stage.plannedenddate::timestamp without time zone)
			 ) AS overdue,
    wms_workorder_stage.workorderid,
    wms_mst_stage.stagename,
    wms_workorder_stage.stageiterationcount,
    wms_workorder_service.assignedduid AS duid,
    org_mst_deliveryunit.duname,
    wms_workorder_stage.serviceid,
    wms_workorder_stage.plannedstartdate + INTERVAL '5 hours 30 minutes' AS plannedstartdate,
    wms_workorder_stage.plannedenddate + INTERVAL '5 hours 30 minutes' AS plannedenddate,
    wms_workorder_stage.startdate,
    wms_workorder_stage.enddate,
    wms_workorder_stage.updatedby,
    wms_workorder_stage.ordermaildate,
    wms_workorder_stage.deliverymodeid,
    wms_workorder_stage.updatedon + INTERVAL '5 hours 30 minutes' AS updatedon,
    wms_workorder_stage.status,
    wms_workorder_stage.emailpath,
    wms_workorder_stage.emailpathuuid,
    wms_mst_service.servicename,
    wms_workorder_stage.ismilestone,
    wms_workorder_stage.sequence,
    wms_workorder_stage.startdatetime + INTERVAL '5 hours 30 minutes' AS startdatetime,
    wms_workorder_stage.enddatetime + INTERVAL '5 hours 30 minutes' AS enddatetime,
    wms_workorder_stage.ordermaildatetime + INTERVAL '5 hours 30 minutes' AS ordermaildatetime,
    wms_workorder_stage.revisedenddatetime + INTERVAL '5 hours 30 minutes' AS revisedenddatetime,
	wms_workorder_service.wfid, 
    wms_workflow.wfname, 
    wms_workflow.wfcategory, 
    wms_workflow.config as wfconfig		 
   FROM wms_workorder 
   JOIN wms_workorder_stage ON wms_workorder_stage.workorderid = wms_workorder.workorderid
   JOIN wms_mst_stage ON wms_workorder_stage.wfstageid = wms_mst_stage.stageid
   JOIN wms_mst_service ON wms_workorder_stage.serviceid = wms_mst_service.serviceid
   JOIN wms_workorder_service ON wms_workorder_service.serviceid = wms_workorder_stage.serviceid
   and wms_workorder_service.workorderid  = wms_workorder.workorderid
   JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder_service.assignedduid     
   JOIN wms_workflow ON wms_workflow.wfid = wms_workorder_service.wfid
   WHERE wms_workorder.workorderid = $1 AND 
   (wms_workorder_stage.wfstageid !=10 OR wms_workorder.customerid = 15)) 
   
   SELECT * FROM cte
   ORDER BY cte.sequence ASC, cte.stageiterationcount  ASC LIMIT $2 OFFSET $3`;

    // let sql = `SELECT COUNT(*) FROM public.wms_wo_stagelist
    //     join wms_workorder_service on wms_workorder_service.serviceid = wms_wo_stagelist.serviceid and wms_workorder_service.workorderid = wms_wo_stagelist.workorderid
    //     join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
    //     WHERE wms_wo_stagelist.workorderid=$1 and wfstageid !=10 `;
    // console.log('sql', sql);
    // const [{ count }] = await query(sql, [woId]);
    // console.log('count', count);
    // sql = `SELECT *,
    //   date_part('day'::text, CURRENT_TIMESTAMP::timestamp without time zone - coalesce(revisedenddatetime::timestamp without time zone, plannedenddate::timestamp without time zone)) AS overdue
    //   from (SELECT wms_wo_stagelist.*, wms_workorder_service.wfid, wms_workflow.wfname, wms_workflow.wfcategory, wms_workflow.config as wfconfig FROM public.wms_wo_stagelist
    //     join wms_workorder_service on wms_workorder_service.serviceid = wms_wo_stagelist.serviceid and wms_workorder_service.workorderid = wms_wo_stagelist.workorderid
    //     join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
    //     WHERE wms_wo_stagelist.workorderid=$1 and wfstageid !=10  ORDER BY wostageid ASC) as sageList ORDER BY sequence ASC, stageiterationcount ASC LIMIT $2 OFFSET $3`;

    //
    const stageData = await query(stagesql, [woId, recordPerPage, offset]);
    let count = stageData ? stageData.length : 0;

    res.status(200).json({ data: stageData, total: count });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const triggerMultipleInstance = async (req, res) => {
  const {
    selectedFiles,
    customerid,
    duId,
    woId,
    serviceId,
    wfStageId,
    stageIterationCount,
  } = req.body;

  try {
    const processInstanceId = await getProcessInstance(woId);
    for (let i = 0; i < selectedFiles.length; i++) {
      const payload = {
        skipCustomListeners: false,
        skipIoMappings: false,
        instructions: [
          {
            type: 'startBeforeActivity',
            activityId: 'Activity_1n8xrjo',
            variables: {
              __file__: {
                value: `{\"id\": \"${selectedFiles[i].id}\",\"name\": \"${selectedFiles[i].name}\",\"filetypeid\": \"2\",\"mspages\": null,\"estimatedpages\": null,\"isChecked\": "${selectedFiles[i].isChecked}"}`,
                type: 'Json',
                local: true,
              },
            },
          },
        ],
        annotation: 'Modified to resolve an error.',
      };
      console.log(payload);
      await service.post(
        `${process.env.CAMUNDA_NATIVE_URL}process-instance/${processInstanceId}/modification`,
        payload,
      );

      const payloads = {
        duId,
        woId,
        customerId: customerid,
        serviceId,
        currentStage: {
          id: wfStageId,
          iteration: stageIterationCount,
        },
        files: selectedFiles,
      };

      console.log(payloads, 'payloadssss');
      /// don't do enable without confirmation
      await multipleInstance(payloads);
    }
    res.status(200).json({ message: 'File Added successfully' });
  } catch (e) {
    res.status(400).send({ message: 'File Added failed' });
  }
};

export const triggerWOStageWf = async (req, res) => {
  try {
    const retresult = await triggerWOStageWf_logic(req, res);
    if (retresult.issuccess == true) {
      res.status(200).json({ message: retresult.message });
    } else {
      res.status(400).send({ message: retresult.message });
    }
  } catch (e) {
    res.status(400).send({ message: 'Next stage initiated/iterated failed' });
  }
};

export const triggerKLIWOStageWf = async (req, res) => {
  try {
    const {
      ismscompleted,
      woId,
      stageId,
      IssuemstId,
      customerId,
      activityId,
      duId,
      wfId,
    } = req.body;

    let triggerRes = false;

    const sql1 = `select count(*) from wms_workorder where issuemstid =${IssuemstId}`;
    const issuecount = await query(sql1);
    const sql2 = `select evl.taskinstanceid,evl.wfeventid,issuem.issuename,evl.activitystatus,wo.workorderid,journ.journalacronym,wo.itemcode,wo.journalid,evl.wfdefid,
        def.activityid,def.stageid,evl.stageiterationcount,evl.userid,service.serviceid
              from wms_workorder wo
              join wms_workflow_eventlog evl on wo.workorderid = evl.workorderid
            join wms_workorder_service service on wo.workorderid = service.workorderid
            join wms_workflowdefinition def on evl.wfdefid = def.wfdefid
            join pp_mst_issue_master issuem on issuem.issuemstid = wo.issuemstid
			      join pp_mst_journal journ on journ.journalid = wo.journalid
            where  wo.issuemstid = ${IssuemstId}  
            and evl.activitystatus ='Unassigned' and def.activityid = 21 and def.stageid = ${stageId}`;

    const allIssueDetails = await query(sql2);

    const isItracksAPI = await checkItracksExits(req, res, false);
    console.log(isItracksAPI, 'isItracksAPI');
    const { status } = isItracksAPI;

    if (status) {
      let data = {
        issuename: allIssueDetails[0].issuename,
        type: 'stagemerge',
      };
      await mergeIssueForBatchFloq(data);
      let payload = {
        duId: duId,
        customerId: customerId,
        jobId: allIssueDetails[0].issuename,
        stageId: stageId,
        receiptdate: '',
        duedate: '',
        wfId: wfId,
      };
      await addKLISatge(payload);
    }
    const sql3 = `select isonlineissue from wms_workorder where workorderid = ${woId}`;
    const isonlineissue = await query(sql3);

    if (
      allIssueDetails.length == issuecount[0].count &&
      !isonlineissue[0].isonlineissue
    ) {
      for (let i = 0; i < allIssueDetails.length; i++) {
        req.body = {
          actionType: 'Save',
          workorderId: allIssueDetails[i].workorderid,
          serviceId: allIssueDetails[i].serviceid,
          stageId: allIssueDetails[i].stageid,
          stageIterationCount: allIssueDetails[i].stageiterationcount,
          activityId: allIssueDetails[i].activityid,
          pmUserId: allIssueDetails[i].userid,
          IssuemstId,
          ismscompleted,
          articlename: allIssueDetails[i].itemcode,
          wfeventid: allIssueDetails[i].wfeventid,
          iteration: 1,
          isonline: isonlineissue[0].isonlineissue,
          journalid: allIssueDetails[i].journalid,
          isAttachment: false,
          issueName: allIssueDetails[i].issuename,
          journalName: allIssueDetails[i].journalacronym,
          flowtype: 'issueproofflow',
        };
        triggerRes = await _nextIssueStageTransferCheckTrigger(req, res);
      }
    } else if (isonlineissue[0].isonlineissue && stageId == 21) {
      req.body = {
        actionType: 'Save',
        workorderId: allIssueDetails[0].workorderid,
        serviceId: allIssueDetails[0].serviceid,
        stageId: allIssueDetails[0].stageid,
        stageIterationCount: allIssueDetails[0].stageiterationcount,
        activityId: allIssueDetails[0].activityid,
        pmUserId: allIssueDetails[0].userid,
        IssuemstId,
        ismscompleted,
        articlename: allIssueDetails[0].itemcode,
        wfeventid: allIssueDetails[0].wfeventid,
        iteration: 1,
        isonline: isonlineissue[0].isonlineissue,
        journalid: allIssueDetails[0].journalid,
        isAttachment: false,
        issueName: allIssueDetails[0].issuename,
        journalName: allIssueDetails[0].journalacronym,
        flowtype: 'prepubflow',
      };
      triggerRes = await _nextIssueStageTransferCheckTrigger(req, res);
    } else if (
      isonlineissue[0].isonlineissue &&
      stageId == 78 &&
      ismscompleted
    ) {
      for (let i = 0; i < allIssueDetails.length; i++) {
        req.body = {
          actionType: 'Save',
          workorderId: allIssueDetails[i].workorderid,
          serviceId: allIssueDetails[i].serviceid,
          stageId: allIssueDetails[i].stageid,
          stageIterationCount: allIssueDetails[i].stageiterationcount,
          activityId: allIssueDetails[i].activityid,
          pmUserId: allIssueDetails[i].userid,
          IssuemstId,
          ismscompleted,
          articlename: allIssueDetails[i].itemcode,
          wfeventid: allIssueDetails[i].wfeventid,
          iteration: 1,
          isonline: isonlineissue[0].isonlineissue,
          journalid: allIssueDetails[i].journalid,
          isAttachment: false,
          issueName: allIssueDetails[i].issuename,
          journalName: allIssueDetails[i].journalacronym,
          flowtype: 'issueproofflow',
        };
        triggerRes = await _nextIssueStageTransferCheckTrigger(req, res);
      }
    } else if (allIssueDetails.length == issuecount[0].count && stageId == 25) {
      req.body = {
        actionType: 'Save',
        workorderId: allIssueDetails[0].workorderid,
        serviceId: allIssueDetails[0].serviceid,
        stageId: allIssueDetails[0].stageid,
        stageIterationCount: allIssueDetails[0].stageiterationcount,
        activityId: allIssueDetails[0].activityid,
        pmUserId: allIssueDetails[0].userid,
        IssuemstId,
        ismscompleted,
        articlename: allIssueDetails[0].itemcode,
        wfeventid: allIssueDetails[0].wfeventid,
        iteration: 1,
        isonline: isonlineissue[0].isonlineissue,
        journalid: allIssueDetails[0].journalid,
        isAttachment: false,
        issueName: allIssueDetails[0].issuename,
        journalName: allIssueDetails[0].journalacronym,
        flowtype: 'eldsflow',
      };
      triggerRes = await _nextIssueStageTransferCheckTrigger(req, res);
    } else {
      res
        .status(200)
        .json({ message: 'Not All collation activity compeleted' });
    }

    if (triggerRes == true) {
      res.status(200).json({ message: 'Next stage initiated/iterated' });
    }
  } catch (e) {
    res.status(400).send({ message: 'Next stage initiated/iterated failed' });
  }
};

export const addKLISatge = data => {
  const { duId, customerId, jobId } = data;
  let { receiptdate, duedate } = data;

  return new Promise(async (resolve, reject) => {
    try {
      receiptdate = receiptdate
        ? receiptdate.trim().replace('T', ' ').substring(0, 19)
        : receiptdate;
      // plannedenddate = plannedenddate
      //   ? plannedenddate.trim().replace('T', ' ').substring(0, 19)
      //   : plannedenddate;
      if (typeof duedate == 'object') {
        duedate = duedate
          ? duedate.toISOString().trim().replace('T', ' ').substring(0, 19)
          : duedate;
      } else if (typeof duedate == 'string') {
        duedate = duedate
          ? duedate.trim().replace('T', ' ').substring(0, 19)
          : duedate;
      } else {
        duedate = duedate
          ? duedate.trim().replace('T', ' ').substring(0, 19)
          : duedate;
      }

      const iDuId = await getiTracksDuId(duId);
      const iCustomerId = await getiTracksCustomerId(customerId);
      const iStageId = await getiTracksStageId(data);
      // const fileDetails = await getFileDetails(data);
      // if (isrelatedstage) {
      //   const relatedStagedet = await getTATforStage(woId, stageId);
      //   if (relatedStagedet != undefined && relatedStagedet.data.length) {
      //     tmp_plannedenddate = relatedStagedet.data[0].plannedenddate;
      //     if (tmp_plannedenddate != undefined) {
      //       plannedenddate = tmp_plannedenddate
      //         .toISOString()
      //         .replace('T', ' ')
      //         .substring(0, 19);
      //     }
      //   }
      // }

      //
      if (iDuId && iCustomerId && iStageId) {
        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname: config.iTracks.uri.journal.addStage,
        };
        const payload = {
          BookCode: jobId,
          DivisionId: iDuId,
          CustomerId: iCustomerId,
          StageId: iStageId,
          ReceiveDate:
            receiptdate ||
            moment().toISOString().replace('T', ' ').substring(0, 19),
          DueDate: duedate,
          MSPage: 1,
        };

        const result = await service.iPost(url, payload, headers);
        // const result = {status: true,data: {status: true,test:""}}

        const { status, Result } = result.data;
        if (status == false) {
          const itrackloginput = {
            url: '',
            payloaddata: '',
            headers: '',
            paramdata: '',
            iduid: 0,
            icustomerid: 0,
            status: '',
            failureplace: '',
            saveaction: '',
            isproduction: '',
            iscustomer: '',
            remarks: '',
          };

          const igerUrl = await axios
            .get(config.iTracks.switch_url)
            .catch(() => {
              reject({
                status: false,
                message: 'Unable to reach the ipswitch server.',
              });
            });

          if (!igerUrl?.data || !isValidiTracksUrl(igerUrl.data)) {
            reject({
              status: false,
              message: 'Unable to fetch the iTracks URL (ipswitch).',
            });
          }

          let iurl = `https://${igerUrl.data}/${config.iTracks.service_url}`;

          itrackloginput.url = iurl;
          itrackloginput.payloaddata = payload;
          itrackloginput.headers = headers;
          itrackloginput.paramdata = JSON.stringify(data);
          itrackloginput.iduid = iDuId;
          itrackloginput.icustomerid = iCustomerId;
          itrackloginput.status = status;
          itrackloginput.failureplace = 'addstage';
          itrackloginput.saveaction = '';
          itrackloginput.isproduction = false;
          itrackloginput.iscustomer = false;
          itrackloginput.remarks = Result;

          await insert_itrackservicecall(itrackloginput);
        }

        resolve({
          status,
          message: status
            ? Result
            : `${Result}. Please contact the iTrack Administrator`,
        });
      } else {
        resolve({
          status: false,
          message: `iTracks duid / stageid / customerid / file info not fount in iWMS`,
        });
      }
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const _triggerWOStageWf = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    try {
      const retresult = await triggerWOStageWf_logic(req, res);
      if (retresult.issuccess == true) {
        resolve(retresult);
      } else {
        reject(retresult);
      }
    } catch (e) {
      reject(e);
    }
  });
};
// start
export const triggerWOStageWf_logic = async (req, res) => {
  const {
    duId,
    woId,
    customerId,
    wfId,
    wfeventId,
    serviceId,
    userId,
    targetStage,
    category,
    files,
    entityId,
    serviceName,
    woType,
    currentStage,
    type,
    isbnUpdateConfirmation,
    isbnLabel,
    newISBN,
    oldISBN,
    jobType,
    isAutoStageTrigger,
    ismscompleted,
    isonlineissue,
  } = req.body;

  return new Promise(async resolve => {
    try {
      // check the iTracks call
      const isItracksAPI = await checkItracksExits(req, res);

      const { status } = isItracksAPI;
      let iTracksObj = { status: true, message: '' };

      const { isgraphicsData, graphicsData } =
        await checkGraphicCompletionTrigger(wfId, woId);

      let setrevisedduedate = false;

      if (type == 'complete' && !isgraphicsData) {
        // res.status(400).send({ message: "Please Complete the Graphic Stage" });
        resolve({
          message: 'Please Complete the Graphic Stage',
          issuccess: false,
        });
      } else {
        // get revised end date
        const addeddate = new Date();
        addeddate.setHours(addeddate.getHours() + 5);
        addeddate.setMinutes(addeddate.getMinutes() + 30);

        const tomorrowdate = new Date(addeddate);
        tomorrowdate.setDate(addeddate.getDate() + 1);
        tomorrowdate.setHours(0, 0, 0, 0);
        // targetStage.name == 'Collation'

        const currentdate = convertDateFormat(addeddate);

        let datebegin = currentdate;

        if (woType === 'Journal' && type != 'complete') {
          setrevisedduedate = await checkduedateconfig(wfId, targetStage.id);

          if (
            targetStage.name == 'Revises' &&
            targetStage.iteration == 1 &&
            customerId === '8'
          ) {
            setrevisedduedate = false;
          }

          // if (
          //   targetStage.name == 'Collation' ||
          //   targetStage.name == 'First View' ||
          //   targetStage.name == 'Revised First View' ||
          //   (targetStage.name == 'Revises' &&
          //     targetStage.iteration > 1 &&
          //     customerId === '8') ||
          //   targetStage.name == 'Stage200 Revises' ||
          //   targetStage.name == 'Stage 300'
          // ) {
          //   setrevisedduedate = true;
          // }
        }

        if (setrevisedduedate == true) {
          if (customerId === '8') {
            datebegin = convertDateFormat(tomorrowdate);
          }

          // let currentdate =  new Date().toLocaleDateString();

          const psql = `SELECT  
           (SELECT add_hours_exclude_weekends_and_holidays 
           FROM add_hours_exclude_weekends_and_holidays($3::timestamp(0), duc.articleduedays ::integer))::timestamp(0) as revisedenddate
           FROM wms_workorder as wo
           JOIN public.org_mst_journal_dueconfig as duc on duc.journalid = wo.journalid
           WHERE wo.workorderid = $1 and duc.stageid = $2 and duc.stageiterationcount = $4 and duc.isactive = true`;
          console.log(psql);
          await query(psql, [
            woId,
            targetStage.id,
            datebegin,
            targetStage.iteration,
          ]).then(async dataresult => {
            if (dataresult && dataresult.length) {
              console.log(dataresult);
              const newreviseddate = convertDateFormat(
                dataresult[0].revisedenddate,
              );
              targetStage.revisedenddate = newreviseddate;

              if (
                !(
                  customerId === '8' &&
                  targetStage.name === 'Revises' &&
                  targetStage.iteration === 1
                )
              ) {
                targetStage.plannedStart = datebegin;
                targetStage.plannedEnd = newreviseddate;
              }

              // if (customerId === '8') {
              //   if (
              //     targetStage.name == 'First View' ||
              //     targetStage.name == 'Revised First View' ||
              //     (targetStage.name == 'Revises' && targetStage.iteration > 1)
              //   ) {
              //     targetStage.plannedStart = datebegin;
              //     targetStage.plannedEnd = newreviseddate;
              //   }
              // } else {
              //   targetStage.plannedStart = datebegin;
              //   targetStage.plannedEnd = newreviseddate;
              // }
            } else {
              targetStage.revisedenddate = datebegin;
            }
          });
        } else {
          targetStage.revisedenddate = datebegin;
        }

        if (isbnUpdateConfirmation && newISBN && oldISBN && isbnLabel) {
          await updateIsbn(woId, isbnLabel, newISBN, oldISBN, woType);
          // get file details
          const sql = `SELECT woincomingfileid, filename FROM public.wms_workorder_incomingfiledetails
                where woincomingfileid IN (${files
                  .map(file => file.id)
                  .join(',')})`;
          const newFiles = await query(sql);
          // need to replace name value from newfiles array in files array
          newFiles.forEach(file => {
            files.forEach(file1 => {
              if (file.woincomingfileid == file1.id) {
                file1.name = file.filename;
              }
            });
          });
        }

        if (status && type != 'complete') {
          // iTracks API call
          req.body.stageId = targetStage.id;
          req.body.stageIterationCount = targetStage.iteration;

          if (woType === 'Book') {
            const subJobRes = await addSubJob(files, req.body, true, false);
            iTracksObj = subJobRes;
          } else {
            // Journal
            // if coming from customer we start from next day date variable "datebegin"
            if (setrevisedduedate == true) {
              req.body.plannedstartdate = datebegin;
              req.body.plannedenddate = targetStage.revisedenddate;
              req.body.ordermaildate = targetStage.receiptdate;
            } else {
              req.body.plannedstartdate = targetStage.plannedStart;
              req.body.plannedenddate = targetStage.plannedEnd;
              req.body.ordermaildate = targetStage.receiptdate;
            }
            let stageResponse;
            //woId > 1976
            if (targetStage.iteration == 1 && customerId != 11) {
              const relatedstagedet = await relatedStageInfo(
                wfId,
                customerId,
                targetStage.id,
                woId,
              );
              const relatedstageObj = relatedstagedet.data.length
                ? relatedstagedet.data
                : [];
              if (relatedstageObj.length) {
                for (
                  let rindex = 0;
                  rindex < relatedstageObj.length;
                  rindex++
                ) {
                  if (targetStage.id != relatedstageObj[rindex].stageid) {
                    req.body.stageId = relatedstageObj[rindex].stageid;
                    req.body.isrelatedstage = true;
                  } else {
                    req.body.isrelatedstage = false;
                  }
                  stageResponse = await addSatge(req.body);
                  if (
                    stageResponse.status == undefined ||
                    stageResponse.status == false
                  ) {
                    break;
                  }
                }
              } else {
                stageResponse = { status: true, message: '' };
              }
            } else if (customerId == 11) {
              stageResponse = await oupaddstage(req.body);
            } else {
              stageResponse = await addSatge(req.body);
            }
            // const stageResponse = await addSatge(req.body);
            iTracksObj = stageResponse;
          }
          req.body.stageId = targetStage.id;
        }

        if (iTracksObj.status) {
          let wfDefId = '';
          try {
            let sql = ``;
            // camunda call
            if (
              !isAutoStageTrigger ||
              isAutoStageTrigger == undefined ||
              isAutoStageTrigger == null
            ) {
              const url = config.camnunda.uri.completeTask;
              // await transaction(async (client) => {
              sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1 WHERE wfeventid = $2 returning taskinstanceid, wfdefid`;
              const resOfWWE = await query(sql, ['Completed', wfeventId]);
              const { taskinstanceid: taskInstanceId, wfdefid: wfdefId } =
                resOfWWE[0];
              const variables1 = {};
              variables1.__isfirstiteration__ = {
                value: !(targetStage.iteration > 1), // added iteration camunda update
                type: 'Boolean',
              };

              const data = {
                taskId: taskInstanceId,
                variables: variables1,
              };
              wfDefId = wfdefId;
              sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid) VALUES ($1, $2, $3, $4)`;
              await query(sql, [wfeventId, 'Completed', currentdate, userId]);
              await service.post(`${config.camnunda.base_url}${url}`, data);
              // end camunda call
            }

            if (targetStage.name) {
              sql = `SELECT wostageid, startdatetime FROM public.wms_workorder_stage where workorderid = $1 and serviceid = $2 and wfstageid = $3 and stageiterationcount = $4`;
              const targetWoStageData = await query(sql, [
                woId,
                serviceId,
                targetStage.id,
                targetStage.iteration,
              ]);

              if (targetWoStageData.length) {
                const {
                  startdatetime,
                  wostageid,
                  ordermaildate,
                  plannedstartdate,
                  plannedenddate,
                } = targetWoStageData[0];

                console.log(startdatetime);
                console.log(ordermaildate);
                // sql = `UPDATE public.wms_workorder_stage SET status=$1, startdate=$2, enddate=$3, plannedstartdate= $4, plannedenddate = $5, ordermaildate = $6,updatedon = current_timestamp, triggeredstagefromid=$7, triggeredstageitrationfromid=$8  where wostageid =$9`;
                if (targetStage.name == 'Collation') {
                  await updateRevisesduedate(woId, targetStage.revisedenddate);
                }
                if (setrevisedduedate == true) {
                  sql = `UPDATE public.wms_workorder_stage 
                  SET status=$1, startdatetime=$2, 
                  enddatetime=$3, plannedstartdate= $4, 
                  plannedenddate = $5, ordermaildatetime = $6,updatedon = current_timestamp, 
                  triggeredstagefromid=$7, triggeredstageitrationfromid=$8, revisedenddatetime='${targetStage.revisedenddate}'                          
                  where wostageid =$9`;
                } else {
                  sql = `UPDATE public.wms_workorder_stage 
                  SET status=$1, startdatetime=$2, 
                  enddatetime=$3, plannedstartdate= $4, 
                  plannedenddate = $5, ordermaildatetime = $6,updatedon = current_timestamp, 
                  triggeredstagefromid=$7, triggeredstageitrationfromid=$8                         
                  where wostageid =$9`;
                }
                //  targetStage.revisedenddate || new Date(),
                await query(sql, [
                  'In Process',
                  currentdate,
                  null,
                  plannedstartdate || targetStage.plannedStart,
                  plannedenddate || targetStage.plannedEnd,
                  currentdate,
                  currentStage.id,
                  currentStage.iteration,
                  wostageid,
                ]);
                await updateStageHistory({
                  id: wostageid,
                  plannedstartdate:
                    plannedstartdate || targetStage.plannedStart,
                  plannedenddate: plannedenddate || targetStage.plannedEnd,
                  userid: userId,
                });
              } else {
                sql = `INSERT INTO wms_workorder_stage(serviceid, wfstageid,updatedby, workorderid, 
                  status, stageiterationcount, startdatetime, plannedstartdate, plannedenddate,
                   ordermaildatetime,updatedon,triggeredstagefromid, 
                   triggeredstageitrationfromid, sequence,revisedenddatetime) VALUES 
                   ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,current_timestamp,$11,$12,$13,$14)
                    returning wostageid`;

                await query(sql, [
                  serviceId,
                  targetStage.id,
                  userId,
                  woId,
                  'In Process',
                  targetStage.iteration,
                  currentdate,
                  targetStage.plannedStart,
                  targetStage.plannedEnd,
                  currentdate,
                  currentStage.id,
                  currentStage.iteration,
                  targetStage.sequence,
                  targetStage.revisedenddate,
                ]).then(async val => {
                  await updateStageHistory({
                    id: val[0].wostageid,
                    plannedstartdate: targetStage.plannedStart,
                    plannedenddate: targetStage.plannedEnd,
                    userid: userId,
                  });
                });
              }
            }
            // });
            sql = `SELECT processinstanceid, isbookcompleted FROM public.wms_workorder_service where serviceid = $1 and workorderid = $2`;
            const [
              {
                processinstanceid: processInstanceId,
                isbookcompleted: isBookCompleted,
              },
            ] = await query(sql, [serviceId, woId]);
            if (targetStage.name) {
              const stage = {
                type: targetStage.name.toLowerCase().replace(/ /g, '_'),
                iteration: targetStage.iteration,
              };
              await triggerStageWorkflow(
                category,
                stage,
                files,
                processInstanceId,
                type,
                customerId,
                currentStage.id,
                ismscompleted,
                isonlineissue,
              );
              // Trigger mail
              const payload = {
                duId,
                entityId,
                workorderId: woId,
                serviceId,
              };
              const resForConfig = await getNotificationConfig(
                payload,
                'iterate/next',
              );
              let data;
              if (resForConfig.length > 0) {
                const {
                  workorderid,
                  type: type1,
                  notificationconfig,
                  customername,
                  duname,
                  itemcode,
                  services,
                  totalchaptercount,
                  printisbn,
                  totalarticlecount,
                  totalnonarticlecount,
                  wotype,
                  jobtype,
                  title,
                  journalname,
                  doinumber,
                  journalacronym,
                } = resForConfig[0];
                let isTrigger = false;
                if (
                  notificationconfig.jobTypes.length &&
                  notificationconfig.jobTypes.includes(jobtype)
                ) {
                  isTrigger = true;
                } else if (notificationconfig.jobTypes.length == 0) {
                  isTrigger = true;
                }

                if (type1 === 'mail' && isTrigger) {
                  const pmI = resForConfig.findIndex(
                    val => val.contactrole === 'PM' && val.isprimary,
                  );
                  const spmI = resForConfig.findIndex(
                    val => val.contactrole === 'SPM' && !val.isprimary,
                  );
                  const authorI = resForConfig.findIndex(
                    val =>
                      val.contactrole === 'AUTHOR' &&
                      val.contacttype === 'Customer',
                  );
                  const mailObj = {};
                  if (pmI != -1) {
                    mailObj.toPm = resForConfig[pmI].contactemail;
                  }
                  if (spmI != -1) {
                    mailObj.toSpm = resForConfig[spmI].contactemail;
                  }
                  if (authorI != -1) {
                    mailObj.toAuthor = resForConfig[authorI].contactemail;
                  }
                  const fromArray = [];
                  const toMailArray = [];
                  const ccMailArray = [];
                  const bccMailArray = [];

                  if (Array.isArray(notificationconfig.from)) {
                    notificationconfig.from.forEach(item => {
                      if (mailObj[item]) {
                        fromArray.push(mailObj[item]);
                      } else {
                        fromArray.push(item);
                      }
                    });
                  } else {
                    fromArray.push(notificationconfig.from);
                  }
                  notificationconfig.to.forEach(item => {
                    if (mailObj[item]) {
                      toMailArray.push(mailObj[item]);
                    } else {
                      toMailArray.push(item);
                    }
                  });
                  notificationconfig.cc.forEach(item => {
                    if (mailObj[item]) {
                      ccMailArray.push(mailObj[item]);
                    } else {
                      ccMailArray.push(item);
                    }
                  });
                  notificationconfig.bcc.forEach(item => {
                    if (mailObj[item]) {
                      bccMailArray.push(mailObj[item]);
                    } else {
                      bccMailArray.push(item);
                    }
                  });

                  console.log(toMailArray, 'toMailArray');
                  console.log(ccMailArray, 'ccMailArray');
                  console.log(bccMailArray, 'bccMailArray');
                  data = {
                    actionType: type1,
                    date: moment(currentdate || new Date()).format(
                      'DD-MM-YYYY',
                    ),
                    workorderId: workorderid,
                    noOfChapter: totalchaptercount,
                    noOfArticle: totalarticlecount,
                    noOfNonArticle: totalnonarticlecount,
                    printIsbn: printisbn,
                    woType: wotype,
                    jobType: jobtype,
                    service: services,
                    doiNumber: doinumber,
                    jobId: itemcode,
                    jobName: title,
                    journalAcronym: journalacronym,
                    journalName: journalname,
                    customerName: customername,
                    duName: duname,
                    pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
                    spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
                    spmMail: spmI != -1 ? resForConfig[spmI].contactemail : '',
                    authorName:
                      authorI != -1 ? resForConfig[authorI].contactname : '',
                    ...notificationconfig,
                    from: fromArray,
                    toMail: toMailArray,
                    cc: ccMailArray,
                    bcc: bccMailArray,
                    tlName: 'TL',
                    serviceName,
                    stageName: targetStage.name,
                    iteration: targetStage.iteration,
                    plannedStartDate: targetStage.plannedStart,
                    plannedEndDate: targetStage.plannedEnd,
                    serviceId,
                    stageId: targetStage.id,
                    stageIterationCount: targetStage.iteration,
                    wfDefId,
                    mailType: 'general',
                  };

                  //  emitAction(data);
                }

                // emitAction(data);
              }
              // Trigger Trackit API
              if (
                customerId == '6' &&
                woType == 'Journal' &&
                (jobType == '3' || jobType == '1')
              ) {
                await trackitAPITrigger(
                  data.doiNumber,
                  woId,
                  serviceId,
                  targetStage.id,
                  targetStage.iteration,
                );
              }
            }
            await updateServiceStatus(
              woId,
              serviceId,
              processInstanceId,
              isBookCompleted,
              graphicsData,
              type,
            );
            if (
              (req.body.currentStage.iteration && req.body.woType == 'Book') ||
              (req.body.woType == 'Journal' && req.body.category == 'Issuewise')
            ) {
              await multipleInstance(req.body);
            }

            // res.status(200).json({ message: 'Next stage initiated/iterated successfully' });
            resolve({
              message: 'Next stage initiated/iterated successfully',
              issuccess: true,
            });
          } catch (error) {
            // res.status(400).send({ message: 'Next stage initiated/iterated failed' });
            resolve({
              message: 'Next stage initiated/iterated failed',
              issuccess: false,
            });
          }
        } else {
          // res.status(400).send({ message: iTracksObj.message });
          resolve({ message: iTracksObj.message, issuccess: false });
        }
      }
    } catch (e) {
      // rollback the isbn update
      // if (isbnUpdateConfirmation) {
      //     await updateIsbn(woId, isbnLabel, oldISBN, newISBN);
      // }
      // res.status(400).send({ message: 'Next stage initiated/iterated failed' });
      resolve({
        message: 'Next stage initiated/iterated failed',
        issuccess: false,
      });
    }
  });
};
// end

export const graphicFilenameUpdateNewISBN = async (woId, newISBN, oldISBN) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `select fmap.actfilemapid,fmap.wfeventid ,fmap.repofilepath ,* from wms_workflow_eventlog as ed
       join wms_workflowactivitytrn_file_map as fmap on ed.wfeventid =fmap.wfeventid 
      where workorderid=${woId} and wfdefid in (501,502,503,504,505)`;
      const isgraphicsDetails = await query(sql1);
      for (let i = 0; i < isgraphicsDetails.length; i++) {
        const list = isgraphicsDetails[i];
        if (list.repofilepath.includes(oldISBN)) {
          const newname = list.repofilepath.replace(oldISBN, newISBN);
          await renameBlob({
            srcPath: list.repofilepath,
            name: basename(newname),
            destBasePath: `${dirname(newname)}/`,
          });
          // await removeFolder(list.repofilepath);
          const sql2 = `UPDATE wms_workflowactivitytrn_file_map
          SET repofilepath = '${newname}'
          WHERE actfilemapid  =  ${list.actfilemapid}`;
          await query(sql2);
        }
      }
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
export const triggerNextStagewf = async (req, res) => {
  const trresp = await settriggerNextStagewf(req, res);

  if (trresp) {
    if (trresp.issuccess == true) {
      res.status(200).json({ message: trresp.message });
    } else {
      res.status(400).send({ message: trresp.message });
    }
  }
};

export const settriggerNextStagewf = async (req, res) => {
  return new Promise(async resolve => {
    const {
      duId,
      woId,
      customerId,
      serviceId,
      targetStage,
      category,
      files,
      entityId,
      serviceName,
      woType,
      jobType,
      type,
    } = req.body;
    // check the iTracks call
    const isItracksAPI = await checkItracksExits(req, res);

    const { status } = isItracksAPI;
    let iTracksObj = { status: true, message: '' };

    // resolve({issuccess:false, message: "test" });

    // let {isgraphicsData,graphicsData} = await checkGraphicCompletionTrigger(graphicCompletionTriggerWfDefid, woId)

    if (type == 'complete') {
      resolve({
        issuccess: false,
        message: 'Please Complete the Graphic Stage',
      });
      // res.status(400).send({ message: "Please Complete the Graphic Stage" });
    } else {
      if (status && type != 'complete') {
        // iTracks API call
        req.body.stageId = targetStage.id;
        req.body.stageIterationCount = targetStage.iteration;

        if (woType === 'Book') {
          const subJobRes = await addSubJob(files, req.body, false, false);
          iTracksObj = subJobRes;
        } else {
          // Journal
          req.body.plannedstartdate = targetStage.plannedStart;
          req.body.plannedenddate = targetStage.plannedEnd;
          req.body.ordermaildate = targetStage.receiptdate;

          const stageResponse = await addSatge(req.body);
          iTracksObj = stageResponse;
        }
      }

      if (iTracksObj.status) {
        const wfDefId = '';
        try {
          // let url = config.camnunda.uri.completeTask;
          // await transaction(async (client) => {
          //     let sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1 WHERE wfeventid = $2 returning taskinstanceid, wfdefid`;
          //     const { rows: [{ taskinstanceid: taskInstanceId, wfdefid: wfdefId }] } = await client.query(sql, ['Completed', wfeventId]);
          //     let data = {
          //         taskId: taskInstanceId
          //     };
          //     wfDefId = wfdefId;
          //     sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid) VALUES ($1, $2, $3, $4)`;
          //     await client.query(sql, [wfeventId, 'Completed', new Date(), userId]);
          //     await service.post(`${config.camnunda.base_url}${url}`, data);
          //     if (targetStage.name) {
          //
          //         sql = `SELECT wostageid, startdate FROM public.wms_workorder_stage where workorderid = $1 and serviceid = $2 and wfstageid = $3 and stageiterationcount = $4`;
          //         let { rows: targetWoStageData } = await client.query(sql, [woId, serviceId, targetStage.id, targetStage.iteration]);
          //         if (targetWoStageData.length) {

          //             const { startdate, wostageid, ordermaildate, plannedstartdate, plannedenddate } = targetWoStageData[0];
          //             sql = `UPDATE public.wms_workorder_stage SET status=$1, startdate=$2, enddate=$3, plannedstartdate= $4, plannedenddate = $5, ordermaildate = $6,updatedon = current_timestamp, triggeredstagefromid=$7, triggeredstageitrationfromid=$8  where wostageid =$9`;
          //             await client.query(sql, ['In Process', startdate ? startdate : new Date(), null, plannedstartdate ? plannedstartdate : targetStage.plannedStart, plannedenddate ? plannedenddate : targetStage.plannedEnd, ordermaildate ? ordermaildate : new Date(), currentStage.id, currentStage.iteration, wostageid]);
          //             setTimeout(async () => {
          //                 await updateStageHistory({
          //                     id: wostageid,
          //                     plannedstartdate: plannedstartdate ? plannedstartdate : targetStage.plannedStart,
          //                     plannedenddate: plannedenddate ? plannedenddate : targetStage.plannedEnd,
          //                     userid: userId
          //                 });
          //             }, 1000)
          //         } else {
          //             sql = `INSERT INTO wms_workorder_stage(serviceid, wfstageid,updatedby, workorderid, status, stageiterationcount, startdate, plannedstartdate, plannedenddate, ordermaildate,updatedon,triggeredstagefromid, triggeredstageitrationfromid, sequence) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,current_timestamp,$11,$12,$13) returning wostageid`;
          //             await client.query(sql, [serviceId, targetStage.id, userId, woId, 'In Process', targetStage.iteration, new Date(), targetStage.plannedStart, targetStage.plannedEnd, new Date(), currentStage.id, currentStage.iteration, targetStage.sequence]).then((data => {
          //                 setTimeout(async () => {
          //                     await updateStageHistory({
          //                         id: data.rows[0].wostageid,
          //                         plannedstartdate: targetStage.plannedStart,
          //                         plannedenddate: targetStage.plannedEnd,
          //                         userid: userId
          //                     });
          //                 }, 1000)
          //             }))
          //         }
          //     }
          // });
          const sql = `SELECT processinstanceid, isbookcompleted FROM public.wms_workorder_service where serviceid = $1 and workorderid = $2`;
          const [{ processinstanceid: processInstanceId }] = await query(sql, [
            serviceId,
            woId,
          ]);
          if (targetStage.name) {
            const stage = {
              type: targetStage.name.toLowerCase().replace(/ /g, '_'),
              iteration: targetStage.iteration,
            };
            await triggerStageWorkflow(
              category,
              stage,
              files,
              processInstanceId,
              type,
            );
            // Trigger mail
            const payload = {
              duId,
              entityId,
              workorderId: woId,
              serviceId,
            };
            const resForConfig = await getNotificationConfig(
              payload,
              'iterate/next',
            );
            let data;
            if (resForConfig.length > 0) {
              const {
                workorderid,
                type: type1,
                notificationconfig,
                customername,
                duname,
                itemcode,
                services,
                totalchaptercount,
                printisbn,
                totalarticlecount,
                totalnonarticlecount,
                wotype,
                jobtype,
                title,
                journalname,
                doinumber,
                journalacronym,
              } = resForConfig[0];
              let isTrigger = false;
              if (
                notificationconfig.jobTypes.length &&
                notificationconfig.jobTypes.includes(jobtype)
              ) {
                isTrigger = true;
              } else if (notificationconfig.jobTypes.length == 0) {
                isTrigger = true;
              }
              console.log(isTrigger, 'isTrigger next stage');
              if (type1 === 'mail' && isTrigger) {
                const pmI = resForConfig.findIndex(
                  val => val.contactrole === 'PM' && val.isprimary,
                );
                const spmI = resForConfig.findIndex(
                  val => val.contactrole === 'SPM' && !val.isprimary,
                );
                const authorI = resForConfig.findIndex(
                  val =>
                    val.contactrole === 'AUTHOR' &&
                    val.contacttype === 'Customer',
                );
                const mailObj = {};
                if (pmI != -1) {
                  mailObj.toPm = resForConfig[pmI].contactemail;
                }
                if (spmI != -1) {
                  mailObj.toSpm = resForConfig[spmI].contactemail;
                }
                if (authorI != -1) {
                  mailObj.toAuthor = resForConfig[authorI].contactemail;
                }
                const fromArray = [];
                const toMailArray = [];
                const ccMailArray = [];
                const bccMailArray = [];

                if (Array.isArray(notificationconfig.from)) {
                  notificationconfig.from.forEach(item => {
                    if (mailObj[item]) {
                      fromArray.push(mailObj[item]);
                    } else {
                      fromArray.push(item);
                    }
                  });
                } else {
                  fromArray.push(notificationconfig.from);
                }
                notificationconfig.to.forEach(item => {
                  if (mailObj[item]) {
                    toMailArray.push(mailObj[item]);
                  } else {
                    toMailArray.push(item);
                  }
                });
                notificationconfig.cc.forEach(item => {
                  if (mailObj[item]) {
                    ccMailArray.push(mailObj[item]);
                  } else {
                    ccMailArray.push(item);
                  }
                });
                notificationconfig.bcc.forEach(item => {
                  if (mailObj[item]) {
                    bccMailArray.push(mailObj[item]);
                  } else {
                    bccMailArray.push(item);
                  }
                });

                console.log(toMailArray, 'toMailArray');
                console.log(ccMailArray, 'ccMailArray');
                console.log(bccMailArray, 'bccMailArray');
                data = {
                  actionType: type1,
                  date: moment(new Date()).format('DD-MM-YYYY'),
                  workorderId: workorderid,
                  noOfChapter: totalchaptercount,
                  noOfArticle: totalarticlecount,
                  noOfNonArticle: totalnonarticlecount,
                  printIsbn: printisbn,
                  woType: wotype,
                  jobType: jobtype,
                  service: services,
                  doiNumber: doinumber,
                  jobId: itemcode,
                  jobName: title,
                  journalAcronym: journalacronym,
                  journalName: journalname,
                  customerName: customername,
                  duName: duname,
                  pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
                  spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
                  spmMail: spmI != -1 ? resForConfig[spmI].contactemail : '',
                  authorName:
                    authorI != -1 ? resForConfig[authorI].contactname : '',
                  ...notificationconfig,
                  from: fromArray,
                  toMail: toMailArray,
                  cc: ccMailArray,
                  bcc: bccMailArray,
                  tlName: 'TL',
                  serviceName,
                  stageName: targetStage.name,
                  iteration: targetStage.iteration,
                  plannedStartDate: targetStage.plannedStart,
                  plannedEndDate: targetStage.plannedEnd,
                  serviceId,
                  stageId: targetStage.id,
                  stageIterationCount: targetStage.iteration,
                  wfDefId,
                  mailType: 'general',
                };

                //  emitAction(data);
              }

              // emitAction(data);
            }
            // Trigger Trackit API
            if (
              (customerId == '6' && woType == 'Journal' && jobType == '3') ||
              jobType == '1'
            ) {
              await trackitAPITrigger(
                data.doiNumber,
                woId,
                serviceId,
                targetStage.id,
                targetStage.iteration,
              );
            }
          }
          // let payload = {
          //     duId : req.body.duId,
          //     woId : req.body.woId,
          //     customerId : customerId,
          //     serviceId : serviceId,
          //     stageId : req.body.currentStage.id,
          //     stageiterationcount : req.body.currentStage.iteration,
          //     files : req.body.files
          // }
          //  await updateServiceStatus(woId, serviceId, processInstanceId, isBookCompleted, graphicsData, type);
          // if (req.body.currentStage.iteration) {
          //     await multipleInstance(req.body);
          // }
          resolve({
            issuccess: true,
            message: 'Next stage initiated/iterated successfully',
          });
          // res.status(200).json({ message: 'Next stage initiated/iterated successfully' });
        } catch (error) {
          resolve({
            issuccess: false,
            message: 'Next stage initiated/iterated failed',
          });
          // res.status(400).send({ message: 'Next stage initiated/iterated failed' });
        }
      } else {
        resolve({ issuccess: false, message: iTracksObj.message });
        // res.status(400).send({ message: iTracksObj.message });
      }
    }
  });
};

export const triggerNextStagewfguid = async (req, res) => {
  try {
    const { id: moveJobId } = req.body;
    let sql = `SELECT * FROM public.iauthor_transactions where guid = $1`;
    const woDetails = await query(sql, [req.body.article_guid]);
    const {
      customerid,
      duid,
      serviceid,
      stageid,
      stageiterationcount,
      workorderid,
    } = woDetails[0];
    // fetch workorder details
    sql = `select itemcode, wotype, wms_workorder_service.wfid, isiauthor, copyeditingworkflow from wms_workorder 
    join wms_workorder_service on wms_workorder_service.workorderid = wms_workorder.workorderid
    join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
    where wms_workorder.workorderid=$1`;
    const workOrderDetails = await query(sql, [workorderid]);
    const { wotype, itemcode, wfid, isiauthor, copyeditingworkflow } =
      workOrderDetails[0];
    const flowType = ['isgeneral'];
    if (isiauthor) {
      flowType.push('isiauthor');
    }
    if (copyeditingworkflow) {
      flowType.push('iscopyeditingworkflow');
    }
    const flows = flowType.join("','");
    // fetch next stage details
    sql = `select stageid as nextstageid, stagename as nextstagename from wms_mst_stage
      where stageid = any (select nextstageid from wms_workflow_stageconfig
      join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
      where wfid=$1 and stageid=$2 and iterationcount=$3 and flowtype in ('${flows}'))`;
    const nextStageDetails = await query(sql, [
      wfid,
      stageid,
      stageiterationcount,
    ]);
    const { nextstageid, nextstagename } = nextStageDetails[0];
    // fetch the target stage iteration count
    sql = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;
    const targetStageInfo = await query(sql, [workorderid, nextstageid]);
    const { sequence, plannedstartdate, plannedenddate } = targetStageInfo[0];
    // fetch the TAT details for the stage
    // commented by suradha - reasen (planned start date enddate should pick from workorder stage.
    // we calculate date during wo auto creation)
    // const duDates = `SELECT * FROM public.org_mst_du_duedates where customerid = $1 and duid = $2 and stageid = $3`;
    // const duDatesDetails = await query(duDates, [
    //   customerid,
    //   duid,
    //   nextstageid,
    // ]);
    // const { dueduration } = duDatesDetails[0];
    // fetch the workflow details
    const workFlow = `SELECT * FROM public.wms_workflow where wfid = $1`;
    const workFlowDetails = await query(workFlow, [wfid]);
    const { wfcategory } = workFlowDetails[0];
    // fetch the service details
    const serviceNameDetail = `SELECT * FROM public.wms_mst_service where serviceid = $1`;
    const serviceNameDetails = await query(serviceNameDetail, [serviceid]);
    // fetch the stage details
    const stageInfo = `SELECT * FROM public.wms_mst_stage where stageid = $1`;
    const stageInfoDetails = await query(stageInfo, [stageid]);
    // fetch the event id
    sql = `select wfeventid, activityid, sequence from wms_workflowdefinition a
            join wms_workflow_eventlog b on a.wfdefid = b.wfdefid   
             where workorderid = $1 and stageid =$2 and wfid = $3 and activityalias = 'Completion Trigger'`;
    const EventIDDetails = await query(sql, [workorderid, stageid, wfid]);
    const { activityid, wfeventid } = EventIDDetails[0];
    // const currentDate = moment(new Date()).format('YYYY-MM-DD');
    // const targetDate = moment(new Date())
    //   .add(dueduration, 'days')
    //   .format('YYYY-MM-DD');
    const addeddate = new Date();
    addeddate.setHours(addeddate.getHours() + 5);
    addeddate.setMinutes(addeddate.getMinutes() + 30);
    const newdate = convertDateFormat(addeddate);

    const psd = plannedstartdate || addeddate;
    const ped = plannedenddate || addeddate;

    const currentDate = convertDateFormat(psd);
    const targetDate = convertDateFormat(ped);
    // const currentDate = moment(plannedstartdate || new Date()).format(
    //   'YYYY-MM-DD HH:mm:ss',
    // );
    // const targetDate = moment(plannedenddate || new Date()).format(
    //   'YYYY-MM-DD HH:mm:ss',
    // );

    const getFileDetailsSql = `SELECT woincomingfileid,filename,filetypeid,mspages,estimatedpages, imagecount,equationcount, tablecount , wwif.duedate FROM public.wms_workorder_incoming 
        JOIN wms_workorder_incomingfiledetails AS wwif ON wwif.woincomingid = wms_workorder_incoming.woincomingid
        WHERE woid=$1`;
    const getFileDetails = await query(getFileDetailsSql, [workorderid]);
    const { duedate } = getFileDetails[0];
    // check the iTracks call
    const customerId = customerid;
    const serviceId = serviceid;
    const woId = workorderid;
    const type = 'next';
    const serviceName = serviceNameDetails[0].servicename;
    const wfId = wfid;
    const category = wfcategory;
    const nextStageIteration = targetStageInfo.filter(
      item => item.status === 'Completed',
    );
    const targetStage = {
      iteration: nextStageIteration.length + 1,
      id: nextstageid,
      name: nextstagename,
      plannedStart: currentDate,
      plannedEnd: targetDate,
      sequence,
      receiptdate: newdate,
    };
    const currentStage = {
      iteration: stageiterationcount,
      id: stageid,
      name: stageInfoDetails[0].stagename,
    };
    const selectedFiles = getFileDetails.filter(item => item.filetypeid !== 1);
    const files = selectedFiles.map(item => {
      return { id: item.woincomingfileid };
    });
    req.body = {
      woId,
      type,
      wfeventId: wfeventid,
      userId: 'System',
      currentStage,
      targetStage,
      files,
      category,
      serviceId,
      serviceName,
      entityId: '8',
      wfId,
      customerId,
      jobcardId: null,
      woType: wotype,
      jobId: itemcode,
      duId: duid,
      activityId: activityid,
      stageId: targetStage.id,
      valuesOfArray: getFileDetails,
      duedate,
    };
    await _triggerWOStageWf(req, res);
    await CallBackToiAuthor(moveJobId);

    // Campus Signal trigger logic
    const stagename = stageInfoDetails[0].stagename;

    if (
      customerid === 8 &&
      ['revises', 'colation'].includes(stagename.toLowerCase())
    ) {
      const campusQuery = `
        SELECT pp_mst_journal.otherdetails ->> 'isSignal' AS iscampustrigger
        FROM wms_workorder
        JOIN pp_mst_journal ON wms_workorder.journalid = pp_mst_journal.journalid
        WHERE wms_workorder.workorderid = $1
      `;

      const response = await query(campusQuery, [workorderid]);

      if (response?.[0]?.iscampustrigger === 'true') {
        const payload = {
          workorderId: workorderid,
          stageName: stagename,
          stageIteration: stageiterationcount,
          payloadType: 'dynamicPayload',
          flowType: 'ftp',
          isRound: true,
          isPagecount: false,
        };

        try {
          const campRes = await _sendCampusSignal(payload);
          console.log('Campus Signal Triggered:', campRes);
        } catch (e) {
          console.error('Failed to send Campus Signal:', e.message || e);
        }
      }
    }

    res
      .status(200)
      .send({ message: 'Next stage triggered - after iAuthor update' });
  } catch (e) {
    res.status(400).send({ message: e.message });
  }
};

export const checkGraphicCompletionTrigger = async (wfId, woId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `select * from wms_workflowdefinition where stageid in (10) and wfid = $1 and activityid = 21 order by sequence`;
      const graphicCompletionTriggerDetails = await query(sql1, [wfId]);
      const graphicCompletionTriggerWfDefid =
        graphicCompletionTriggerDetails &&
        graphicCompletionTriggerDetails.length
          ? graphicCompletionTriggerDetails[0].wfdefid
          : '';
      let sql = `select * from wms_workorder_stage where workorderid =$1
            and wfstageid in (10)`;
      const isgraphicsDetails = await query(sql, [woId]);
      let graphicsData = [];
      if (
        isgraphicsDetails.lenght > 0 &&
        graphicCompletionTriggerDetails &&
        graphicCompletionTriggerDetails.length > 0
      ) {
        sql = `select * from wms_workflow_eventlog where workorderid = $1 and wfdefid = $2`;
        graphicsData = await query(sql, [
          woId,
          graphicCompletionTriggerWfDefid,
        ]);
        resolve({
          isgraphicsData: graphicsData.length > 0,
          graphicsData,
        });
      } else {
        resolve({ isgraphicsData: true, graphicsData });
      }
    } catch (e) {
      reject(e);
    }
  });
};

const trackitAPITrigger = async (
  doiNumber,
  woId,
  serviceId,
  targetStageid,
  targetStageiteration,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const username = process.env.TRACKIT_USERNAME;
      const password = process.env.TRACKIT_PASSWORD;
      const payloadFortrackit = {
        doi: doiNumber,
        stage: 'CREATE_FINAL_PROOF',
        details: 'Author proof returned',
        // "details": "The article proof has been completed by the author",
        source: 'Emerald',
        // "source": "TYPESETTER_INTEGRA",
        runNumber: '1',
        result: 'Passed',
        username,
        password,

        workorderId: woId,
        serviceId,
        stageId: targetStageid,
        stageIterationCount: targetStageiteration,
      };

      const resForTrackitApi = await getAuthAccessWorflow(payloadFortrackit);

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const updateServiceStatus = async (
  woId,
  serviceId,
  processInstanceId,
  isBookCompleted,
  graphicCompletionDetails,
  type,
) => {
  let sql = `SELECT count(*) FROM public.wms_workorder_stage where workorderid = $1 and serviceid = $2 and status = $3`;
  return new Promise(async (resolve, reject) => {
    try {
      if (isBookCompleted) {
        const [{ count }] = await query(sql, [woId, serviceId, 'In Process']);
        if (count == 0) {
          sql = `UPDATE public.wms_workorder_service SET status=$1 where workorderid = $2 and serviceid = $3`;
          await query(sql, ['Completed', woId, serviceId]);
          await triggerBatchCompletion(processInstanceId);
          if (type == 'complete' && graphicCompletionDetails.length > 0) {
            const url = config.camnunda.uri.completeTask;
            const data = {
              taskId: graphicCompletionDetails[0].taskinstanceid,
            };
            await service.post(`${config.camnunda.base_url}${url}`, data);
          }

          await updateWOStatus(woId);
        }
      }
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const updateWOStatus = async woId => {
  let sql = `SELECT count(*) FROM public.wms_workorder_service where workorderid = $1 and status != $2`;
  return new Promise(async (resolve, reject) => {
    try {
      const [{ count }] = await query(sql, [woId, 'Completed']);
      if (count == 0) {
        sql = `UPDATE public.wms_workorder SET status=$1, completeddate=$2 where workorderid=$3`;
        await query(sql, ['Completed', new Date(), woId]);
      }
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getPreviousChapterPath = async (req, res) => {
  try {
    const path = await getFolderStructure({ type: 'okm_common' });
    res.status(200).json({ path });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const updateWoStage = async (req, res) => {
  // check the iTracks call
  // let { status } = await checkItracksExits(req, res);
  // console.log(status, 'status of itracks exist');

  // if (status) {
  //     let { id } = req.body
  //     let isItracksStageTrigger = await checkITrackStageTrigger(id);
  //     console.log(isItracksStageTrigger, 'isItracksStageTrigger');

  //     if (isItracksStageTrigger) {
  //         console.log('alredy exists');
  //         stageUpdateAction(req, res, false);
  //     } else {
  //         console.log(req, 'req fro add stage');
  //         let response = await addSatge(req.body);
  //         console.log(response, 'ress123');

  //         if (response.status) {
  //             stageUpdateAction(req, res, true);
  //         } else {
  //             res.status(400).send(response);
  //         }
  //     }

  // } else {
  //     console.log('without itracks stage');
  //     stageUpdateAction(req, res, false);
  // }

  stageUpdateAction(req, res, false);
};

// ----------------using for autojob creation with promise---------------------//
export const updateWoStage_autoCall = async (req, res) => {
  // check the iTracks call
  return new Promise(async resolve => {
    const stupdate = await stageUpdateAction_autoCall(req, res, false);
    if (stupdate.issuccess) {
      resolve({ message: 'success', issuccess: true });
    } else {
      resolve({ message: 'failed', issuccess: false });
    }

    // TO BE DELETED
    // let { status } = await checkItracksExits(req, res);
    // console.log(status, 'status of itracks exist');

    // if (status) {
    //     let { id } = req.body
    //     let isItracksStageTrigger = await checkITrackStageTrigger(id);
    //     console.log(isItracksStageTrigger, 'isItracksStageTrigger');

    //     if (isItracksStageTrigger) {
    //         console.log('alredy exists');
    //         let stupdate = await stageUpdateAction_autoCall(req, '', false);

    //         if (stupdate.issuccess) {
    //             resolve({ message: "success", issuccess: true });
    //         } else {
    //             resolve({ message: "failed", issuccess: false });
    //         }

    //     } else {
    //         console.log(req, 'req fro add stage');
    //         let response = await addSatge(req.body);
    //         console.log(response, 'ress123');

    //         if (response.status) {
    //             let stupdate = await stageUpdateAction_autoCall(req, res, true);

    //             if (stupdate.issuccess) {
    //                 resolve({ message: "success", issuccess: true });
    //             } else {
    //                 resolve({ message: "failed", issuccess: false });
    //             }

    //         } else {
    //             resolve({ message: "failed", issuccess: false });
    //         }
    //     }

    // } else {
    //     console.log('without itracks stage');
    //     let stupdate = await stageUpdateAction_autoCall(req, res, false);
    //     if (stupdate.issuccess) {
    //         resolve({ message: "success", issuccess: true });
    //     } else {
    //         resolve({ message: "failed", issuccess: false });
    //     }
    // }
  });
};
/*
const checkITrackStageTrigger = id => {
  return new Promise(async resolve => {
    const sql = `SELECT * FROM public.wms_workorder_stage WHERE wostageid=${id} AND istagecreated=true`;
    
    query(sql)
      .then(data => {
        resolve(!!data.length);
      })
      .catch(() => {
        resolve(false);
      });
  });
};
*/
const stageUpdateAction = (req, res) => {
  // let iStageColumn = iStageEntry ? `, istagecreated=true` : ``
  const getData = req.body;
  const sql = `UPDATE wms_workorder_stage
                            SET plannedstartdate=( '${getData.plannedstartdate}'::timestamp - INTERVAL '5 hours 30 minutes'), plannedenddate=('${getData.plannedenddate}'::timestamp - INTERVAL '5 hours 30 minutes'), ordermaildatetime=('${getData.ordermaildate}'::timestamp - INTERVAL '5 hours 30 minutes'),
                            emailpath='${getData.emailpath}',emailpathuuid='${getData.emailpathuuid}',updatedon = current_timestamp, ismilestone= ${getData.ismilestone}  WHERE wostageid = ${getData.id}`;

  query(sql)
    .then(async data => {
      const historyUpdate = await updateStageHistory(getData);

      if (historyUpdate) {
        res
          .status(200)
          .json({ data, message: 'Stage details updated successfully' });
      } else {
        res.status(400).send({ message: 'History update failed' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const stageUpdateAction_autoCall = req => {
  return new Promise(async resolve => {
    // let iStageColumn = iStageEntry ? `, istagecreated=true` : ``
    const getData = req.body;
    const sql = `UPDATE wms_workorder_stage
                            SET plannedstartdate='${getData.plannedstartdate}', plannedenddate='${getData.plannedenddate}', ordermaildatetime='${getData.ordermaildate}',
                            emailpath='${getData.emailpath}',emailpathuuid='${getData.emailpathuuid}',updatedon = current_timestamp, ismilestone= ${getData.ismilestone} WHERE wostageid = ${getData.id}`;

    query(sql)
      .then(async data => {
        const historyUpdate = await updateStageHistory(getData);

        if (historyUpdate) {
          resolve({
            data,
            message: 'Stage details updated successfully',
            issuccess: true,
          });
        } else {
          resolve({ message: 'History update failed', issuccess: false });
        }
      })
      .catch(error => {
        resolve({ message: error, issuccess: false });
      });
  });
};

const updateStageHistory = getData => {
  return new Promise(async resolve => {
    const sql = `INSERT INTO public.wms_workorder_stage_audit(
            wostageid, plannedstartdate, plannedenddate, updatedby, updatedon)
            VALUES ($1, $2, $3,  $4, $5)`;
    query(sql, [
      getData.id,
      getData.plannedstartdate,
      getData.plannedenddate,
      getData.userid,
      new Date(),
    ])
      .then(() => {
        resolve(true);
      })
      .catch(() => {
        resolve(false);
      });
  });
};

export const getStageHistory = async (req, res) => {
  if (req.body.type == 'stage') {
    // const { pageNo } = req.body;
    // const { recordPerPage } = req.body;
    // query(sql).then((count) => {
    //TEt
    const sql = `SELECT  distinct on
            (wms_workorder_stage_audit.wostageid) 
                    wms_workorder_stage_audit.wostageid,
                    wms_wo_stagelist.stagename||'('||stageiterationcount||')' as stagename,
                    wms_wo_stagelist.plannedstartdate + INTERVAL '5 hours 30 minutes' as plannedstartdate,
                    wms_wo_stagelist.plannedenddate + INTERVAL '5 hours 30 minutes' as plannedenddate,
                    wms_wo_stagelist.updatedon + INTERVAL '5 hours 30 minutes' as updatedon,
                    wms_wo_stagelist.servicename,wms_user.username||' ('||wms_user.userid||')' as username
                    from wms_workorder_stage_audit
                       join wms_wo_stagelist on wms_workorder_stage_audit.wostageid = wms_wo_stagelist.wostageid
                       join wms_user on wms_user.userid = wms_wo_stagelist.updatedby
                        WHERE wms_wo_stagelist.workorderid=${req.body.woId} ORDER BY wms_workorder_stage_audit.wostageid ASC`;

    query(sql)
      .then(data => {
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
    // }).catch((error) => {
    //     res.status(400).send({ message: error });
    // })
  } else {
    let sql = '';
    sql = `select count(*)
        from wms_workorder_stage_audit
        where wostageid=${req.body.stageid}`;
    query(sql)
      .then(count => {
        sql = `select wostageid,plannedstartdate,
            plannedenddate,
            updatedon ,updatedby,wms_user.username||' ('||wms_user.userid||')' as username
            from wms_workorder_stage_audit
            join wms_user on wms_user.userid = wms_workorder_stage_audit.updatedby
            where wostageid=${
              req.body.stageid
            } order by wostageauditid desc limit ${
          count[0].count - 1
        } offset 1`;

        query(sql)
          .then(data => {
            res.status(200).json({ data });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};

export const checkMultiInstance = async (req, res) => {
  const { woId, serviceId, stageId, stageiterationcount } = req.body;
  let sql = `SELECT * FROM public.wms_workflow_stagetrn_file WHERE workorderid = ${woId} and serviceid = ${serviceId} and stageid = ${stageId} and stageiterationcount = ${stageiterationcount}`;

  const stagetrn = await query(sql);
  if (stagetrn.length == 0) {
    res.status(200).json({ data: { history: stagetrn } });
  } else {
    try {
      const stageIterationCount = `SELECT stageiterationcount FROM wms_workorder_stage where wfstageid = 2 and workorderid = ${woId} and status='In Process'`;
      const data = await query(stageIterationCount);
      sql = `SELECT workorderid, status, wfstageid,triggeredstagefromid, triggeredstageitrationfromid FROM wms_workorder_stage where workorderid = ${woId} and status='In Process'`;
      const finalData = await query(sql);
      if (data.length == 0) {
        res
          .status(200)
          .json({ data: { history: stagetrn, previousStage: finalData } });
      } else {
        try {
          sql = `SELECT distinct wfeventid,wms_workflow_eventlog.wfdefid,workorderid,stageid,stageiterationcount, activitystatus, activityid 
        FROM public.wms_workflow_eventlog   
        JOIN public.wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
        where workorderid= ${woId} and stageid = 2 and stageiterationcount = ${data[0].stageiterationcount}
        and activitystatus in ('Completed','Rejected','Reset') and activityid=16`;

          const validData = await query(sql);
          sql = `SELECT distinct wfeventid,wms_workflow_eventlog.wfdefid,workorderid,stageid,stageiterationcount, activitystatus, activityid 
            FROM public.wms_workflow_eventlog   
            JOIN public.wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
            where workorderid= ${woId} and stageid = 2 and stageiterationcount = ${data[0].stageiterationcount}
             and activityid=16`;
          const responseData = await query(sql);
          sql = `SELECT workorderid, status, wfstageid,triggeredstagefromid, triggeredstageitrationfromid FROM wms_workorder_stage where workorderid = ${woId} and status='In Process'`;
          const finalData1 = await query(sql);
          res.status(200).json({
            data: {
              history: stagetrn,
              isValidButton:
                responseData.length != 0
                  ? validData.length == responseData.length
                  : false,
              previousStage: finalData1,
            },
          });
        } catch (error) {
          res.status(400).send({ message: error });
        }
      }
    } catch (error) {
      res.status(400).send({ message: error });
    }
  }
};

const updateIsbn = (woId, isbnLabel, newISBN, oldISBN, woType) => {
  // let { woId, isbnLabel, newISBN, oldISBN } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(async client => {
        let sql = `update wms_workorder set ${isbnLabel} = ${newISBN} where workorderid = ${woId} returning workorderid`;

        const {
          rows: [{ workorderid }],
        } = await client.query(sql);

        const sql1 = `update wms_workorder_additionalinfo set hardbackisbn = ${newISBN} where workorderid = ${woId}`;

        await client.query(sql1);

        sql = `select woincomingfileid, filename from public.wms_workorder_incoming
                join public.wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
                where woid=${workorderid}`;

        const getFileList = await client.query(sql);

        getFileList.rows.forEach(async item => {
          const newFileName = item.filename.replace(oldISBN, newISBN);
          sql = `update wms_workorder_incomingfiledetails set filename = '${newFileName}' where woincomingfileid = ${item.woincomingfileid}`;

          await client.query(sql);
        });
      });
      // added for graphics image filename shipping
      if (woType == 'Book') {
        await graphicFilenameUpdateNewISBN(woId, newISBN, oldISBN);
      }

      resolve('ISBN updated successfully');
    } catch (e) {
      reject(e);
    }
  });
};

export const addFileButtonValidation = async (req, res) => {
  const { woId } = req.body;
  const sql = `SELECT table1.workorderid, table1.status, table1.wfstageid, table1.triggeredstagefromid, table1.triggeredstageitrationfromid FROM wms_workorder_stage as table1 JOIN (SELECT * FROM wms_workorder_stage where status='In Process') as table2 ON table1.wfstageid = table2.triggeredstagefromid where table1.workorderid=${woId} and table1.status='In Process'`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getEventlog = async (req, res) => {
  const { woId, stageiterationcount } = req.body;
  const sql = `SELECT * FROM public.wms_workflow_eventlog where wfdefid in (267, 272) and workorderid=${woId} and stageiterationcount =${stageiterationcount}`;
  console.log(sql);

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getProcessInstance = woId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM public.wms_workorder_service WHERE workorderid=${woId}`;
    query(sql)
      .then(res => {
        if (res.length) {
          resolve(res[0].processinstanceid);
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};

// export const getProcessInstance = async (woId) => {
//     debugger
//     const sql = `SELECT * FROM public.wms_workorder_service WHERE workorderid=${woId}`
//     query(sql).then((data) => {
//         res.status(200).json({ data: data[0].processinstanceid });
//     }).catch((error) => {
//         res.status(400).send({ message: error });
//     })
// }

export const getWOStageChapters = async (req, res) => {
  try {
    const { category, wfConfig, stageId, serviceId, stageIteration, woId } =
      req.body;
    const incomingFileTypes =
      wfConfig && wfConfig.incoming && wfConfig.incoming.fileTypes
        ? wfConfig.incoming.fileTypes
        : [];
    const filesData = await queryWOStageChapters(
      category,
      incomingFileTypes,
      stageId,
      serviceId,
      stageIteration,
      woId,
    );
    res.status(200).json({ filesData });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};
export const getWOStageFiles = async (req, res) => {
  try {
    const { category, wfConfig, serviceId, woId } = req.body;
    const incomingFileTypes =
      wfConfig && wfConfig.incoming && wfConfig.incoming.fileTypes
        ? wfConfig.incoming.fileTypes
        : [];
    const filesData = await queryWOStageFiles(
      category,
      incomingFileTypes,
      serviceId,
      woId,
    );
    res.status(200).json({ filesData });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const getStageCompletionStatus = (category, stageDetails) => {
  let isCompleted = false;
  switch (category) {
    case categories.chapter:
    case categories.article:
      isCompleted = stageDetails.files.length
        ? stageDetails.files.every(data => data.isCompletedChapter)
        : false;
      break;
    case categories.book:
    case categories.issue:
      isCompleted = !!stageDetails.isCompletedStage;
      break;
    default:
  }
  return isCompleted;
};

export const getWfTargetStageList = async (req, res) => {
  const { stageId, wfId, workorderId } = req.body;
  if (11 == wfId || 13 == wfId || 14 == wfId || 15 == wfId) {
    let sql = `SELECT nextstages, isiteration, enableisbnupdate FROM public.wms_workflow
  JOIN wms_workflow_stageconfig ON wms_workflow_stageconfig.wfid = wms_workflow.wfid
  WHERE wms_workflow_stageconfig.stageid=${stageId} AND wms_workflow_stageconfig.wfid=${wfId}`;
    console.log(sql, 'sql for target stage IDS');
    query(sql)
      .then(data => {
        if (data.length && data[0].nextstages.length) {
          let stageids = '';
          data[0].nextstages.forEach((item, i) => {
            stageids += data[0].nextstages.length - 1 == i ? item : `${item},`;
          });
          sql = `select * from
      (SELECT row_number() over(partition by wfstageid order by stageiterationcount desc) as rno, * FROM public.wms_workorder_stage
                JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workorder_stage.wfstageid
                WHERE wfstageid IN (${stageids}) AND wms_workorder_stage.workorderid = ${workorderId} order by wostageid desc
          ) as res where res.rno = 1`;
          console.log(sql, 'sql for target stage');
          query(sql)
            .then(result => {
              console.log(result, 'resultresult');
              res.status(200).json({
                data: result,
                isIteration: data.length && data[0].isiteration,
                isbnUpdate: !!(data.length && data[0].enableisbnupdate),
              });
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        } else {
          res.status(200).json({
            data: [],
            isIteration: data.length && data[0].isiteration,
            isbnUpdate: !!(data.length && data[0].enableisbnupdate),
          });
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    let sql = `SELECT nextstages, isiteration, enableisbnupdate FROM public.wms_workflow
  JOIN wms_workflow_stageconfig ON wms_workflow_stageconfig.wfid = wms_workflow.wfid
  WHERE wms_workflow_stageconfig.stageid=${stageId} AND wms_workflow_stageconfig.wfid=${wfId}`;
    console.log(sql, 'sql for target stage IDS');
    query(sql)
      .then(data => {
        sql = `select * from
    (SELECT row_number() over(partition by wfstageid order by stageiterationcount desc) as rno, * FROM public.wms_workorder_stage
              JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workorder_stage.wfstageid
              WHERE wfstageid IN (select nextstageid from public.wms_workflow_nextstage_map where wfstageconfigid in (select wfstageconfigid from public.wms_workflow_stageconfig where wfid=${wfId} and stageid=${stageId}
)) AND wms_workorder_stage.workorderid = ${workorderId} order by wostageid desc
        ) as res where res.rno = 1`;

        console.log(sql, 'sql for target stage');
        query(sql)
          .then(result => {
            console.log(result, 'resultresult');
            if (result.length) {
              res.status(200).json({
                data: result,
                isIteration: data.length && data[0].isiteration,
                isbnUpdate: !!(data.length && data[0].enableisbnupdate),
              });
            } else {
              res.status(200).json({
                data: [],
                isIteration: data.length && data[0].isiteration,
                isbnUpdate: !!(data.length && data[0].enableisbnupdate),
              });
            }
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};
const CallBackToiAuthor = id => {
  return new Promise((resolve, reject) => {
    const input = {
      ids: [id],
    };
    axios({
      method: 'POST',
      url: `${config.iAuthor.base_url()}${config.iAuthor.updateiAuthorMoved}`,
      data: JSON.stringify(input),
      headers: {
        'Content-Type': 'application/json',
        clientid: 'WMS',
        apikey: '84B9A8C7-FDEA-47DC-B1CF-845FD79C4E05',
      },
    })
      .then(() => {
        resolve({ status: true, data: input });
      })
      .catch(err => {
        console.log(err, 'errr CallBackToiAuthor');
        reject({
          status: false,
          message: err.response ? err.response : err.message,
        });
      });
  });
};

export const targeStageInfo = async (req, res) => {
  const { stageId } = req.body;
  try {
    const sql = `select * from public.wms_mst_stage WHERE stageid=${stageId}`;

    query(sql).then(data => {
      res.status(200).send(data);
    });
  } catch (e) {
    res.status(400).send({ message: 'targeStageInfo failed' });
  }
};

export const checkduedateconfig = async (wfId, stageId) => {
  return new Promise(async resolve => {
    try {
      let retval = false;
      const sql = `select coalesce(setduedate,false) as setduedate 
     from wms_config_splited_stage_relation 
     where wfid = $1 and stageid = $2 and isactive = true`;
      const resultdata = await query(sql, [wfId, stageId]);
      if (resultdata && resultdata.length > 0) {
        retval = resultdata[0].setduedate;
      }
      resolve(retval);
    } catch (e) {
      resolve(false);
    }
  });
};

export const updateRevisesduedate = async (woId, startdate) => {
  return new Promise(async resolve => {
    try {
      const stdate = new Date(startdate);
      stdate.setSeconds(stdate.getSeconds() + 1);
      const newstartdate = convertDateFormat(stdate);

      const psql = `SELECT  
             (SELECT add_hours_exclude_weekends_and_holidays 
             FROM add_hours_exclude_weekends_and_holidays($3::timestamp(0), duc.articleduedays ::integer))::timestamp(0) as revisedenddate
             FROM wms_workorder as wo
             JOIN public.org_mst_journal_dueconfig as duc on duc.journalid = wo.journalid
             WHERE wo.workorderid = $1 and duc.stageid = $2 and duc.stageiterationcount = $4 and duc.isactive = true`;
      console.log(psql);
      const revisesdate = await query(psql, [woId, 2, newstartdate, 1]);

      const csql = `select res.stagename,res.stageid,res.nextstageid,res.minseq from 
      (select 
        st.stagename
        ,wf.stageid
        ,lead(wf.stageid,1) over(order by min(sequence)) as nextstageid
        ,min(sequence)  as minseq
      from wms_workflowdefinition as wf
      join wms_mst_stage as st on st.stageid = wf.stageid
      where wfid = (select wfid from wms_workorder_service where workorderid = $1) 
      group by wf.stageid,st.stagename
      order by  minseq) as res where res.stageid = 21`;

      const nextstage = await query(csql, [woId]);
      if (revisesdate && revisesdate.length && nextstage && nextstage.length) {
        const { nextstageid } = nextstage[0];
        const coverteddate = convertDateFormat(revisesdate[0].revisedenddate);

        const wsqry = `update wms_workorder_stage set revisedenddatetime = $2 
          where workorderid = $1 and wfstageid = $3 and stageiterationcount = 1`;
        await query(wsqry, [woId, coverteddate, nextstageid]);
      }
      resolve('success');
    } catch (err) {
      console.log(err);
    }
  });
};

function convertDateFormat(inputDate) {
  // Parse the input date using a JavaScript Date object
  const parsedDate = new Date(inputDate);

  if (Number.isNaN(parsedDate)) {
    return 'Invalid Date'; // Handle invalid date input
  }

  // Format the date into 'YYYY-MM-DD HH:mm:ss' using the Date methods
  const year = parsedDate.getFullYear();
  const month = (parsedDate.getMonth() + 1).toString().padStart(2, '0');
  const day = parsedDate.getDate().toString().padStart(2, '0');
  const hours = parsedDate.getHours().toString().padStart(2, '0');
  const minutes = parsedDate.getMinutes().toString().padStart(2, '0');
  const seconds = parsedDate.getSeconds().toString().padStart(2, '0');

  // Create the formatted date string
  const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  return formattedDate;
}

// --------------------- Auto Stage Trigger Module -------------------- //

export const autoStageTriggerWithoutCamunda = async (req, res) => {
  const {
    stage,
    pii,
    title,
    dueDate,
    type,
    sourcePath,
    woIncomingFileId,
    chapterName,
    isBook,
    activityId,
    isBackpUp,
    plannedEndDate,
    isDeleteBkp,
    isUpdReset = false,
    resetStageId,
    resetActivityId = [],
    isNewIteration = false,
    revisedData = false,
    isFileCopy = true,
    userId,
    comments,
    stageIteration = 1,
    customerId,
    isResetStage = false,
  } = req.body;
  try {
    let resetStage, proofReset, articleguid, iauthorActivityID;
    if (!stage) {
      let sql = `select stagename from wms_mst_stage where  stageid = ${resetStageId}`;
      let result = await query(sql);
      if (result && result.length > 0) {
        resetStage = result[0].stagename;
      } else {
        throw new Error(`Stage name not found for stage ID ${resetStageId}`);
      }
    }
    resetStage = resetStage || stage;
    const payload = await getWoandStageInfo(title, resetStage);
    if (isResetStage) {
      let payloadData = {
        stageId: resetStageId,
        workorderId: payload.workorderId,
        customerId: customerId,
        stageName: payload.stageName,
        stageIterationCount: stageIteration,
      };
      proofReset = await getStageTriggeredActivity(payloadData);
      const {
        guidDetails: { guid },
        overallActivity,
      } = proofReset;
      iauthorActivityID = 38;
      payload.overallActivity = overallActivity;
      if (proofReset?.guidDetails)
        await callIAuthorAPI(iauthorActivityID, guid);
    }
    payload.type = type;
    payload.sourcePath = sourcePath;
    payload.woIncomingFileId = woIncomingFileId ? woIncomingFileId : '';
    payload.chapterName = chapterName ? chapterName : '';
    payload.isBook = isBook ? isBook : false;
    payload.activityId = activityId ? activityId : '';
    payload.pii = pii ? pii : '';
    payload.isBackpUp = isBackpUp ? isBackpUp : false;
    payload.plannedEndDate = plannedEndDate ? plannedEndDate : null;
    payload.isDeleteBkp = isDeleteBkp ? isDeleteBkp : false;

    //Update Reset status in the eventlog based on the activity
    if (isUpdReset) {
      const resetPayload = {
        wfId: payload.wfId,
        workorderId: payload.workorderId,
        stageId: resetStageId,
        activityId: resetActivityId,
        userId: userId || undefined,
        comments: comments || undefined,
      };
      await _updEventLogResetStatus(resetPayload);
    }

    if (!isBook) {
      await checkStageExists(payload);
      //iteration
      if (type === 'trigger' && isNewIteration) {
        const res = await createStageForElsevierResupply(payload);
        payload.stageIteration = res.iterationCount ? res.iterationCount : 1;
      }
    }
    if (isResetStage) await fileBackupforStageReset(payload);
    if (isFileCopy) await fileCopyForStageTrigger(payload);
    let msg = 'Stage file copied successfully';
    if (type === 'trigger') {
      await nextStageTriggerAuto(payload);
      msg = 'Stage triggered successfully';
      if (revisedData) {
        await ElsUpdateRevisedData({ query }, payload.workorderId, revisedData);
      }
    }
    res
      .status(200)
      .send({ status: 'Stage triggered successfully', message: msg });
  } catch (e) {
    res.status(400).send({
      status: false,
      message: e.message || 'Reset stage process failed. Please try again',
    });
  }
};

const callIAuthorAPI = (iauthorActivityID, articleguid) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Build the configuration object for the API request
      //const BearerToken = await getBearerToken();
      const configAPI = {
        method: 'post',
        url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
          config.iAuthor.getiAuthorLinkRest
        }`,
        headers: {
          'Content-Type': 'application/json',
          clientid: config.iAuthor.clientid,
          apikey: config.iAuthor.apikey,
        },
        data: JSON.stringify({
          atyid: iauthorActivityID,
          flag: 1,
          articleguid: articleguid,
        }),
      };
      // Make the axios request
      const response = await axios(configAPI);
      // Resolve the promise with the response data if the request is successful
      resolve(response.data);
    } catch (error) {
      // Reject the promise with the error if it occurs
      if (error.response) {
        reject({
          is_success: false,
          message: error.response.data,
        });
      } else {
        reject({
          is_success: false,
          message:
            error.message ||
            'An error occured while iAuthor reset. Please check with iAuthor team',
        });
      }
    }
  });
};

const getStageTriggeredActivity = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { stageId, workorderId, stageIterationCount, stageName } = payload;

      // let sql = `SELECT status,sequence,wfstageid FROM wms_workorder_stage
      // WHERE wfstageid='${stageId}' AND workorderid=${workorderId}`;

      // let sql = `select * from public.wms_workorder_stage where workorderid=1416
      //  WHERE wfstageid='${stageId}' AND workorderid=${workorderId}
      //  and status = 'Completed'`;
      let sqlQuery = `select count(1) from wms_workorder_stage wws where workorderid  = ${workorderId} and wfstageid = ${stageId} and status = 'Completed'`;
      let stageComp = await query(sqlQuery);
      if (stageComp[0].count == 0) {
        let sql = `select wfd.activityid,wma.activityname ,wfd.activityalias from wms_workflowdefinition wfd join
wms_workflow_eventlog wfe on wfd.wfdefid= wfe.wfdefid
join wms_mst_activity wma on wma.activityid =wfd.activityid
where wfe.workorderid = ${workorderId} and wfd.stageid = ${stageId} order by wfd.sequence `;

        const response = await query(sql);
        let sql1 = `select d.guid, case when e.wfstageid in (92,99, 122, 123, 124) then  c.sequencedetails else f.sequencedetails end as sequencedetails ,b.iauthworkconversionflowid from wms_workorder as a
        join pp_mst_journal as b  on b.journalid = a.journalid
       
        join wms_workorder_stage as e on e.workorderid = a.workorderid
       
        left join iauthor_workflow c on  c.iauthworkflowid = b.iauthworkflowid  
        left join iauthor_workflow f on  f.iauthworkflowid = b.iauthworkconversionflowid
        join iauthor_transactions as d on d.workorderid = a.workorderid or d.stageiterationcount =  e.triggeredstageitrationfromid
        where a.workorderid = ${workorderId}
        and b.isiauthor=true  
        and (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
        e.stageiterationcount=${stageIterationCount} order by d.iauthourtrnsid desc limit 1`;
        const data = await query(sql1);
        // response[0].status
        let overallActivity = response.map(item =>
          item.activityname.replace(/\s+/g, '_'),
        );
        // sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid) VALUES ($1, $2, $3, $4)`

        resolve({ overallActivity, guidDetails: data[0] });
      } else {
        reject(`Stage ${stageName} was already completed. Please contact iWMS`);
      }
    } catch (ex) {
      reject(ex);
    }
  });
};
const getWoandStageInfo = (title, stage) => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `
      select workorderid,itemcode,wfid,org_mst_deliveryunit.duid,org_mst_deliveryunit.duname,org_mst_customer.customerid,org_mst_customer.customername from wms_workorder
      join org_mst_deliveryunit on org_mst_deliveryunit.duid = wms_workorder.duid
      join org_mst_customer on org_mst_customer.customerid = wms_workorder.customerid
      where itemcode='${title}'`;
      const woInfo = await query(sql);
      if (woInfo.length) {
        sql = `select stageid, stagename from wms_workorder_stage 
        join wms_mst_stage on wms_mst_stage.stageid = wms_workorder_stage.wfstageid
        where workorderid=${woInfo[0].workorderid} and stagename='${stage}'`;
        const stageInfo = await query(sql);
        if (stageInfo.length) {
          resolve({
            stageName: stageInfo[0].stagename,
            stageId: stageInfo[0].stageid,
            workorderId: woInfo[0].workorderid,
            wfId: woInfo[0].wfid,
            duId: woInfo[0].duid,
            customerId: woInfo[0].duid,
            du: {
              name: woInfo[0].duname,
              id: woInfo[0].duid,
            },
            customer: {
              name: woInfo[0].customername,
              id: woInfo[0].customerid,
            },
            title: woInfo[0].itemcode,
          });
        } else {
          reject('Trigger stage not found for the title');
        }
      } else {
        reject('Trigger stage title not found, Please check the job title');
      }
    } catch (err) {
      reject(err);
    }
  });
};

const createStageForElsevierResupply = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { stageId, workorderId } = payload;

      // let sql = `SELECT status,sequence,wfstageid FROM wms_workorder_stage
      // WHERE wfstageid='${stageId}' AND workorderid=${workorderId}`;

      // let sql = `select * from public.wms_workorder_stage where workorderid=1416
      //  WHERE wfstageid='${stageId}' AND workorderid=${workorderId}
      //  and status = 'Completed'`;

      let sql = `select wfstageid, serviceid,wfstageid,status,updatedby,
      workorderid,stageiterationcount,sequence,inflow_captured from wms_workorder_stage
      where workorderid =${workorderId} and wfstageid= ${stageId} order by wostageid desc limit 1`;

      const response = await query(sql);

      // response[0].status

      // sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid) VALUES ($1, $2, $3, $4)`;
      sql = `insert into wms_workorder_stage(serviceid,wfstageid,status,updatedby,
      workorderid,stageiterationcount,sequence,inflow_captured) 
      VALUES($1,$2,$3,$4,$5,$6,$7,$8)`;

      const stgRes = await query(sql, [
        response[0].serviceid,
        response[0].wfstageid,
        response[0].status,
        response[0].updatedby,
        response[0].workorderid,
        response[0].stageiterationcount + 1,
        response[0].sequence,
        response[0].inflow_captured,
      ]);

      resolve({ stgRes, iterationCount: response[0].stageiterationcount + 1 });
    } catch (ex) {
      reject(ex);
    }
  });
};

const checkStageExists = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { stageId, workorderId, type } = payload;
      let sql = `SELECT status,sequence,wfstageid FROM wms_workorder_stage  
      WHERE wfstageid='${stageId}' AND workorderid=${workorderId}`;
      const response = await query(sql);
      if (response.length) {
        const status = response[0].status;
        if (status === 'YTS') {
          // check the previous stage status
          sql = `SELECT status,sequence,wfstageid FROM wms_workorder_stage  
          WHERE workorderid=${workorderId} AND sequence < (SELECT sequence FROM wms_workorder_stage  
          WHERE wfstageid='${stageId}' AND workorderid=${workorderId}) -1`;
          const prevStageInfo = await query(sql);
          if (prevStageInfo.length) {
            const status = prevStageInfo[0].status;
            if (status === 'In Process') {
              if (type === 'fileCopy' || type === 'trigger') {
                resolve({
                  status: true,
                  message: 'Stage file copy is ready to be upload',
                });
              } else {
                reject({
                  status: false,
                  message:
                    'Previous stage is still in progress, Please complete it before triggering the currect stage',
                });
              }
            } else {
              resolve({
                status: true,
                message: 'Stage is ready to be triggered',
              });
            }
          } else {
            resolve({
              status: true,
              message: 'Stage is ready to be triggered',
            });
          }
        }
        resolve(true);
      } else {
        reject({ status: false, message: 'Stage information not found' });
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const checkStageExistService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { title, stage, relatedStage = [] } = payload;
      let relatedstageinfo = [];
      let sql = `select ww.workorderid as "workorderId", wws.wfstageid as "stageId", wws.stageiterationcount, wws.status,  wws."sequence"
                from wms_workorder ww
                  join wms_workorder_stage wws on wws.workorderid = ww.workorderid
                  join wms_mst_stage wms on wms.stageid = wws.wfstageid
                where
                  ww.itemcode = $1 and wms.stagename = $2
                order by wws.stageiterationcount desc limit 1`;

      const response = await query(sql, [title, stage]);
      if (response.length > 0) {
        relatedstageinfo.push(response[0]);
        if (relatedStage.length > 0) {
          const relatedStagePromises = relatedStage.map(async stg => {
            const tempRes = await query(sql, [title, stg]);
            if (tempRes.length) {
              relatedstageinfo.push(tempRes[0]);
            }
          });
          await Promise.all(relatedStagePromises);
        }
        resolve({
          status: false,
          message: 'Stage already exists.',
          data: { ...response[0], relatedstageinfo },
        });
      } else {
        resolve({ status: true, message: 'New Stage request.' });
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const checkPBTaskExistService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { title, stage, relatedStage = [] } = payload;
      relatedStage.push(stage);
      let sql = `SELECT tp.stage as pbtstage, wms.stageid as pbtstageid FROM trn_problemtask tp
                  JOIN trn_problemtask_log tpl ON tpl.pb_id = tp.id
                  JOIN wms_mst_stage wms ON wms.stagename = tp.stage 
                  WHERE tp.isactive = 'true' AND tpl.status = 'Approved' AND articleid = $1 AND stage = ANY($2 ::text[])
                  ORDER BY tp.id DESC LIMIT 1`;

      const response = await query(sql, [title, relatedStage]);
      if (response && response.length > 0) {
        resolve({ ...response[0] });
      }
      resolve(false);
    } catch (err) {
      reject(err);
    }
  });
};

const nextStageTriggerAuto = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const data = {
        wfId: payload.wfId,
        workorderId: payload.workorderId,
        serviceId: 1,
        stageId: payload.stageId,
        stageIteration: payload.stageIteration ? payload.stageIteration : 1,
        woIncomingFileId: payload.woIncomingFileId || null,
        activityId: payload.activityId || null,
        plannedEndDate: payload.plannedEndDate || null,
      };
      const response = await _triggerWithoutCamundaWorkflow(data);
      resolve(response);
    } catch (err) {
      reject(err);
    }
  });
};

export const fileBackupforStageReset = async payload => {
  const {
    workorderId,
    stageName,
    title,
    sourcePath,
    isBook,
    chapterName,
    pii,
    stageId,
    isBackUp = true,
    isDeleteBkp,
    overallActivity,
  } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const dmsType = await getdmsType(workorderId);
      payload.dmsType = dmsType;
      const serverbasepath = await getBasePath(payload);
      const activityInfo = await getFirstActivityInfo({
        wfId: payload.wfId,
        stageId: payload.stageId,
      });

      let destinationString = '';
      let bkpDestinationPath = '';
      if (isBook) {
        destinationString = `${serverbasepath}${title}/${stageName}/${activityInfo.activityname}/${title}/${chapterName}`;
      } else {
        const placeHolder = {
          workorderId,
        };
        for (let activityname of overallActivity) {
          destinationString = `${serverbasepath}${title}/${stageName}/${activityname}/${title}/`;
          const bkpFoldName = getCurrentDateTimeString();
          bkpDestinationPath = `${serverbasepath}${title}/${stageName}/${activityname}/Backup/${bkpFoldName}/`;
          // if (isBackpUp === true) {
          const bkpSourcePath = await replacePlaceholders(
            destinationString,
            placeHolder,
          );
          const bkpDestPath = await replacePlaceholders(
            bkpDestinationPath,
            placeHolder,
          );
          const isExist = await localHelper._islocalFileExist(bkpSourcePath);
          if (isExist.exist) {
            await localHelper._localFolderCopy({
              srcPath: bkpSourcePath,
              destBasePath: bkpDestPath,
            });
          }
          //to delete source if req
          // if (isDeleteBkp === true) {
          const delBkpSourcePath = await replacePlaceholders(
            destinationString,
            placeHolder,
          );
          await localHelper._localFolderDelete(delBkpSourcePath);
          // }
        }

        resolve(true);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const fileCopyForStageTrigger = async payload => {
  const {
    workorderId,
    stageName,
    title,
    sourcePath,
    isBook,
    chapterName,
    pii,
    stageId,
    isBackpUp,
    isDeleteBkp,
  } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const dmsType = await getdmsType(workorderId);
      payload.dmsType = dmsType;
      const serverbasepath = await getBasePath(payload);
      const activityInfo = await getFirstActivityInfo({
        wfId: payload.wfId,
        stageId: payload.stageId,
      });

      let destinationString = '';
      let bkpDestinationPath = '';
      if (isBook) {
        destinationString = `${serverbasepath}${title}/${stageName}/${activityInfo.activityname}/${title}/${chapterName}`;
      } else {
        // destinationString = `${serverbasepath}${title}/${stageName}/${activityInfo.activityname}/${title}/`;
        const placeHolder = {
          workorderId,
        };
        destinationString = `${serverbasepath}${title}/Common/${stageName}/Source/`;
        const bkpFoldName = getCurrentDateTimeString();
        bkpDestinationPath = `${serverbasepath}${title}/Common/${stageName}/Backup/${bkpFoldName}`;
        if (isBackpUp === true) {
          const bkpSourcePath = await replacePlaceholders(
            destinationString,
            placeHolder,
          );
          const bkpDestPath = await replacePlaceholders(
            bkpDestinationPath,
            placeHolder,
          );
          const isExist = await localHelper._islocalFileExist(bkpSourcePath);
          if (isExist.exist) {
            await localHelper._localFolderCopy({
              srcPath: bkpSourcePath,
              destBasePath: bkpDestPath,
            });
          }
        }

        //to delete source if req
        if (isDeleteBkp === true) {
          const delBkpSourcePath = await replacePlaceholders(
            destinationString,
            placeHolder,
          );
          await localHelper._localFolderDelete(delBkpSourcePath);
        }

        const destPath = await replacePlaceholders(
          destinationString,
          placeHolder,
        );

        let fileRes = {};
        switch (dmsType) {
          case 'azure':
            // const name = basename(files[0].filepath);
            // fileRes = await azureHelper._copyFile({
            //   srcPath: files[0].filepath,
            //   destBasePath: destPath,
            //   name,
            // });
            // res.fileuuid = 'azure';
            // need to be worked for folder copy
            break;
          case 'local':
            fileRes = await localHelper._localFolderCopy({
              srcPath: sourcePath,
              destBasePath: destPath,
            });
            break;
          default:
            throw new Error(`Unsupported DMS type: ${dmsType}`);
        }

        // if (stageId == 121) {
        //   await srcFileDownloadFromPii({ pii, destPath });
        // }
        resolve(true);
      }
    } catch (e) {
      reject(e);
    }
  });
};

function getCurrentDateTimeString() {
  const currentDate = new Date();

  // Format the date and time as a string without special characters
  const formattedDate =
    currentDate.getFullYear() +
    '-' +
    String(currentDate.getMonth() + 1).padStart(2, '0') +
    '-' +
    String(currentDate.getDate()).padStart(2, '0') +
    'T' +
    String(currentDate.getHours()).padStart(2, '0') +
    '.' +
    String(currentDate.getMinutes()).padStart(2, '0') +
    '.' +
    String(currentDate.getSeconds()).padStart(2, '0');

  return formattedDate;
}

console.log(getCurrentDateTimeString());

//s3 meta data download

export const s3MetaDataDownload = async (req, res) => {
  try {
    const payload = req.body;
    const response = await _s3MetaDataDownload(payload);
    res.status(200).json({ status: true, data: response });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const _s3MetaDataDownload = async () => {
  return new Promise(async (resolve, reject) => {
    const payload = {
      piiNumber: 'S4444-2122(24)00006-7',
      destPath: `//integrafs2/ElsJournals/02_WMS_dev/LatestFiles/`,
    };
    const { piiNumber, destPath } = payload;
    const pii = piiNumber.replace(/[-()]/g, ''); //clean other extentions

    //Get signal audit info against pii
    if (pii) {
      const signalAuditInfo = await getSignalAuidtInfo(pii);
      const { signalauditid: signalAuditId, signalinfo: ackMsgInfo } =
        signalAuditInfo;
      console.log(signalAuditId, 'signalAuditId');
    } else {
      reject('PII number missing');
    }
    try {
      // if (pii) {
      //Get metadata from s3
      const signalAckPayload = {
        signalAuditId,
        piiNumber: pii,
        ackMsgInfo: '',
      };
      const result = await getMetaData(signalAckPayload);
      const jobInfo = await constructMetadata(result);

      // download source files
      const assetDownloadRes = await downloadAssetFile(
        jobInfo.assetInfo,
        signalAckPayload,
      );

      const assetPromises = assetDownloadRes.map(async item => {
        if (item.contentType) {
          const docPath = `${destPath}${item.filename}`;
          const { fullPath } = await localHelper._uploads3FileServer(
            docPath,
            item.sourceContent,
            item.contentType,
          );
          let sasPath = {};
          const extensions = [
            '.pdf',
            '.docx',
            '.doc',
            '.ppt',
            '.pptx',
            '.tiff',
            '.tif',
            '.eps',
            '.jpg',
            '.jpeg',
            '.webp',
            '.bmp',
            '.gif',
            '.tif',
            '.eps',
            '.ico',
            '.svg',
            '.svg+xml',
            '.png',
            '.psd',
            '.ai',
            '.xml',
          ];

          if (extensions.some(ext => fullPath.includes(ext))) {
            const { data } = await localHelper._localdownload(fullPath);
            sasPath = data;
          }
          return {
            allPath: fullPath,
            pathWithSAS: sasPath.path ? sasPath.path : '',
          };
        }
      });
      const assetUploadRes = await Promise.all(assetPromises);

      const allFiles = assetUploadRes
        .filter(item => item !== undefined)
        .map(item => item.allPath);

      const originalFiles = assetUploadRes
        .map(item => item?.pathWithSAS)
        .filter(p => p !== '')
        .filter(item => item !== undefined);

      resolve('Success');
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: error.message ? error.message : error,
        message: 'S3 metadata download failed',
        status: 'Failed',
        processStatusId: 3,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};

export const constructMetadata = result => {
  return new Promise((resolve, reject) => {
    try {
      const jobInfo = {};
      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);
      const allStageSourceInfo = result['bam:hasGeneration'];
      let stageSourceInfo = [];
      stageSourceInfo = result['bam:hasGeneration'].filter(
        item => item['bam:stage'] === 'accepted_manuscript',
      );
      const getMaxVerison = stageSourceInfo.reduce(
        (max, row) =>
          row['bam:generation'] > max['bam:generation'] ? row : max,
        stageSourceInfo[0],
      );
      const assetInfo = getMaxVerison['bam:hasAsset'];
      jobInfo.receivedStage = getMaxVerison['bam:stage'];
      jobInfo.title = result['prism:publicationName'];
      jobInfo.issn = result['prism:issn'].replace(/-/g, '');
      jobInfo.assetInfo = assetInfo;
      jobInfo.dueDate = moment(futureDate).format('YYYY-MM-DD hh:mm:ss');
      jobInfo.userId = 'System';

      resolve(jobInfo);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};

export const updEventLogResetStatus = async (req, res) => {
  try {
    const result = await _updEventLogResetStatus(req.body);
    res.status(200).json(result);
  } catch (e) {
    res
      .status(400)
      .send({ issuccess: false, message: e.message || JSON.stringify(e) });
  }
};

export const _updEventLogResetStatus = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        wfId,
        workorderId,
        stageId,
        stageIterationCount = 1,
        userId = 'System',
        comments = 'This activity has been Reset.',
        fromWfeventId,
      } = payload;
      let Condition = '';
      if (fromWfeventId) {
        Condition += ` and wwe.wfeventid >= ${fromWfeventId} `;
      }
      const sql = `select wwe.wfeventid, wwe.actualactivitycount from public.wms_workflow_eventlog wwe
                    join wms_workflowdefinition ww on ww.wfdefid = wwe.wfdefid
                  where ww.wfid = ${wfId} and wwe.workorderid = ${workorderId} and ww.stageid = ${stageId} and wwe.stageiterationcount = ${stageIterationCount} and activitystatus not in ('Work in progress') ${Condition}`;
      const eventLogData = await query(sql);
      if (!eventLogData || eventLogData.length === 0) {
        return reject({
          issuccess: false,
          message: 'No event logs details found.',
        });
      }
      const wfeventids = eventLogData.map(event => event.wfeventid);

      let sqlQuery = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE wfeventid = ANY($3)`;
      await query(sqlQuery, [userId, 'Reset', wfeventids]);

      const updValues = eventLogData
        .map(
          x =>
            `(${x.wfeventid}, 'Reset', NOW(), '${userId}', '${comments}', ${x.actualactivitycount})`,
        )
        .join(',');
      sqlQuery = `INSERT INTO wms_workflow_eventlog_details(wfeventid, operationtype, timestamp, userid, usercomments, actualactivitycount) VALUES ${updValues}`;
      await query(sqlQuery);

      resolve({ issuccess: true, message: 'Reset success.' });
    } catch (err) {
      reject({
        issuccess: false,
        message:
          'Update eventlog reset failed: ' + err.message || JSON.stringify(err),
      });
    }
  });
};

export const getStageActivityStatus = async (req, res) => {
  try {
    const payload = req.body;

    const sql = `SELECT we.activitystatus, we.wfdefid, we.workorderid, wd.activityalias, wms.stagename 
                 FROM wms_workflow_eventlog we
                 JOIN wms_workflowdefinition wd ON we.wfdefid = wd.wfdefid
                 JOIN wms_mst_stage wms ON wms.stageid = wd.stageid 
                 WHERE wd.wfid = ${payload.wfId}
                 AND wd.stageid = ${payload.stageId}
                 AND we.workorderid = ${payload.workorderId}
                 ORDER BY wd."sequence";`;

    const activities = await query(sql);

    // AI Block if any activity is in 'Work in progress'
    const hasWIP = activities.some(
      act => act.activitystatus === 'Work in progress',
    );
    if (hasWIP) {
      return res.status(200).json({ status: true, wipStatus: true });
    }

    //AI Block if already reset (first is YET, rest are Reset)
    if (
      activities.length > 1 &&
      activities[0].activitystatus === 'Unassigned' &&
      activities.slice(1).every(act => act.activitystatus === 'Reset')
    ) {
      return res.status(200).json({ status: true, alreadyReset: true });
    }

    //AI Allowed to trigger reset
    return res.status(200).json({ status: true, canReset: true });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

//  _s3MetaDataDownload()
