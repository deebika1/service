import { query, transaction } from '../../database/postgres.js';
import { woCreate } from './workorderDynamic.js';

export const createWOBulk = async (req, res) => {
  try {
    const { Exceldata, createdBy } = req.body;
    let isError = false;
    const uploadedFile = [];
    const isJournalExistScript = checkIsJournalExistScript();
    const isRateEntryExistScript = checkIsRateEntryExistScript();
    // const isJobScript = checkIsJobScript();
    await transaction(client => {
      return new Promise(async (tresolve, treject) => {
        try {
          for (const element of Exceldata) {
            const isJournalExist = await client.query(isJournalExistScript, [
              element?.journalId,
            ]);
            const REresult = await client.query(isRateEntryExistScript, [
              element.journalId,
            ]);
            // const Jobresult = await client.query(isJobScript, [
            //   element.articleId,
            //   element.journalId,
            // ]);
            if (isJournalExist.rows.length > 0 && REresult.rows.length > 0) {
              const DuorgData = await getDuandOrgData(element.journalId);
              const payload = {
                jobId: element.articleId,
                jobTitle: element.articleId,
                customer: DuorgData[0]?.customerid,
                division: DuorgData[0]?.divisionid,
                subDivision: DuorgData[0]?.subdivisionid,
                country: DuorgData[0]?.countryid,
                duId: DuorgData[0]?.duid,
                journalAcronym: isJournalExist?.rows[0]?.journalid,
                modifiedBy: createdBy,
                // projectManager: createdBy,
              };
              const WOresult = await woCreate(payload, res);
              console.log('WOresult', WOresult);
              if (WOresult) {
                const StageId = await getStageIdScript(element.fileName);
                const initStageScript = InsertStageScript();
                const stageResult = await query.client(initStageScript, [
                  WOresult.workorderid,
                  1,
                  StageId,
                  'YTS',
                  element.receivedDate,
                  element.receivedDate,
                  element.dispatchedDate,
                  element.dispatchedDate,
                  1,
                  createdBy,
                ]);
                if (stageResult) {
                  const initIncomingScript = InsertIncomingScript();
                  const incomeresult = await client.query(initIncomingScript, [
                    WOresult.workorderid,
                    1,
                    StageId,
                    element.dispatchedDate,
                    element.receivedDate,
                    element.receivedDate,
                    1,
                    createdBy,
                  ]);
                  if (incomeresult) {
                    const IncFileDetscript = InsertIncomingFileDetailsScript();
                    const IncFileDetResult = await client.query(
                      IncFileDetscript,
                      [incomeresult[0].woincomingid],
                    );
                    console.log('IncFileDetResult', IncFileDetResult);
                    element.Remarks = 'Created Successfully';
                  }
                }
              }
            } else if (isJournalExist?.rows?.length == 0) {
              element.Remarks = 'Journal Not Exist';
              isError = true;
            } else if (REresult?.rows?.length == 0) {
              element.Remarks = 'Rate Entry for Journal is Not Exist';
              isError = true;
            }
            if (isError) {
              uploadedFile.push(element);
            }
          }
          if (isError) {
            res.status(200).send({ file: uploadedFile, status: 'failed' });
          } else {
            res.status(200).send({ file: uploadedFile, status: 'success' });
          }
        } catch (error) {
          treject(error);
        }
      });
    });
  } catch (e) {
    console.log(e);
  }
};

const checkIsJournalExistScript = () => {
  const script = `SELECT * FROM public.pp_mst_journal WHERE journalname = $1 AND isactive = 1 ORDER BY 1 DESC LIMIT 1;`;
  return script;
};

const checkIsRateEntryExistScript = () => {
  const script = `SELECT jr.* FROM salespmo.trn_journal_rate jr
    JOIN public.pp_mst_journal j ON j.journalname = $1 AND j.isactive = 1
    WHERE jr.journalid = j.journalid ORDER BY 1 DESC LIMIT 1;`;
  return script;
};

const getDuandOrgData = async journalid => {
  const result =
    await query(`SELECT dmap.duid, co.customerid, co.divisionid, co.subdivisionid, co.countryid 
  FROM public.org_mst_customer_orgmap co
  JOIN PUBLIC.org_mst_customerorg_du_map dmap ON dmap.custorgmapid = co.custorgmapid
  JOIN public.pp_mst_journal j ON j.journalname = '${journalid}' AND j.custorgmapid = dmap.custorgmapid
  WHERE j.isactive = 1 AND co.isactive = 1 ORDER BY 1 LIMIT 1`);
  return result;
};

const getStageIdScript = async stageDes => {
  const result = await query(
    `SELECT stageid from public.wms_mst_stage where stagename ilike '%'${stageDes}'%' order by 1 limit 1;`,
  );
  return result[0].stageid;
};

const InsertStageScript = () => {
  const script = `INSERT INTO wms_workorder_stage (workorderid, serviceid, wfstageid, status, receiveddate,
          plannedstartdate, plannedenddate, revisedenddatetime, stageiterationcount, ordermaildatetime, updatedby)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, current_timestamp, $10) RETURNING wostageid;`;
  return script;
};

const InsertIncomingScript = () => {
  const script = `INSERT INTO wms_workorder_incoming(woid, serviceid, stageid, duedate, receiptdate, receiptdatetime,
          stageiterationcount, updatedby) VALUES ($1, $2, $3, $4, $5 ::Date, $6, $7, $8) RETURNING woincomingid;`;
  return script;
};

const InsertIncomingFileDetailsScript = () => {
  const script = `INSERT INTO wms_workorder_incomingfiledetails (woincomingid, filename, duedate, mspages,
          estimatedpages, imagecount, tablecount, equationcount, boxcount, referencecount, wordcount, filetypeid,
          startpage, endpage, filesequence, isactive)
            SELECT $1, subjobname, $2, mspage, estimatedpages, imagecount, tablecount, equationcount,
            boxcount, referencecount, wordcount, filetypeid, startpage, endpage, sequenceno, true
            FROM subjobdetails s WHERE workorderid = $3 AND subjobname = ANY($4 ::TEXT[]);`;
  return script;
};

// const checkIsJobScript = () => {
//   const script = `SELECT COUNT(*) FROM public.wms_workorder WHERE itemcode = $1 AND journalid =
//     (SELECT journalid FROM public.pp_mst_journal WHERE journalacronym = $2 AND isactive = 1)
//     AND isactive = true;`;
//   return script;
// };
