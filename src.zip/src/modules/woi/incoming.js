/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import { basename, extname, join } from 'path';
import { query, transaction } from '../../database/postgres.js';
import {
  triggerWorkflow,
  triggerBookCompleted,
} from '../utils/wfTrigger/index.js';
import { updateServiceStatus } from './stage.js';
import { exportToExcel } from '../utils/excel/index.js';
import { getdmsType } from '../bpmn/listener/create.js';
import { _copyFile, _createFolder } from '../utils/okm/index.js';
import {
  addSubJob,
  checkItracksExits,
  mergeIssue,
  addSatge,
  relatedStageInfo,
  oupaddstage,
} from '../iTracks/index.js';
import { appConfig } from '../../config/app.js';
import * as azureHelper from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';
import * as fileCopyHelper from '../utils/filecopy/index.js';
import { getFormattedName } from '../utils/fileValidation/utils.js';
import { getFolderStructure, getBasePath } from '../utils/wmsFolder/index.js';
import { getCamundaVariable } from '../task/action/workflow/reset.js';
import { _triggerWithoutCamundaWorkflow } from './workflowTrigger.js';
import { replacePlaceholders } from '../custom-uri/utils.js';
import logger from '../utils/logs/index.js';

const jobTypeObj = {
  1: 'Article',
  2: 'Issue',
  3: 'Non Article',
};
export const getimcomingDetails = async (req, res) => {
  try {
    const { start, end, baseduid } = req.body;
    const sql = `select distinct icf.isactive,wo.isactive,wo.workorderid, wo.itemcode, wo.title, 
    wo.totalchaptercount,wo.doinumber,wo.wotype,TO_CHAR(wo.createdon,'DD-MM-YYYY') as createdon,
    ic.woincomingid, icf.filename,icf.filepath,icf.fileuuid,wo.createdon as actualcreatedon,
    icf.mspages,icf.estimatedpages,icf.imagecount,icf.tablecount,
    icf.equationcount,icf.filesequence,icf.boxcount,icf.typesetpage,icf.wordcount,icf.referencecount
    from wms_workorder_incomingfiledetails as icf join
    wms_workorder_incoming as ic on ic.woincomingid=icf.woincomingid join
    wms_workorder as wo on wo.workorderid=ic.woid join
    wms_workorder_service as ws on ws.workorderid=wo.workorderid
    where wo.isactive !=false and (icf.isactive isnull or 
    icf.isactive = true) and ws.baseduid=${baseduid} and (wo.createdon between '${start}' and '${end}') 
    order by wo.createdon desc`;
    const out = await query(sql);
    res.status(200).json(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const insertWOSourceFileDetails = (req, res) => {
  const {
    duId,
    customerId,
    woId,
    serviceId,
    stageId,
    stageIterationCount,
    uploadPath,
  } = req.body;
  const sql = `INSERT INTO public.wms_workorder_sourcefile_details(
     duid, customerid, workorderid, serviceid, stageid, stageiterationcount, uploadpath, uuid, createdon)
    VALUES ( ${duId}, ${customerId}, ${woId}, ${serviceId}, ${stageId}, ${stageIterationCount}, ${uploadPath}, 'azure', current_timestamp)  RETURNING wosourcefileid`;

  query(sql)
    .then(response => {
      res
        .status(200)
        .send({ message: 'Inserted Successfully', data: response });
    })
    .catch(error => {
      res.status(400).send({ data: error });
    });
};

export const autoIncomingForIssue = async (req, res) => {
  const { workorderId, files } = req.body;
  const logPayload = {
    workorderId,
    payload: req.body,
    message: 'Received request for auto incoming creation',
    status: 'In Progress',
  };
  try {
    logPayload.logId = await autoIncomingLog(logPayload, 'Insert');
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,jo.otherdetails,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,wo.iscoveravailable as cover,wo.isadvertavailable as advert,jo.runontype
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    const sql2 = `select * from pp_mst_filetype where (category = 'Article' or category = 'Issue')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      list.articletype =
        filetedFileType.length > 0 ? filetedFileType[0].articletype : 'Article';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: files.length,
      totalNonArticleCount: 0,
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });

    const fileCopyPayload = {
      resData: response.data,
      woDetails: woDetails[0],
      files,
      jobTypeName: 'Issue',
    };
    await fileCopyForAutoIncoming(fileCopyPayload);

    for (let k = 0; k < files.length; k++) {
      const filteredObj = response.data.find(
        sublist => sublist.filename == files[k].filename,
      );
      files[k].woincomingfileid = files[k].woincomingfileid
        ? files[k].woincomingfileid
        : filteredObj.woincomingfileid;
    }
    const trigerstatus = await wmsWorkflowTrigger({
      woDetails: woDetails[0],
      files,
    });
    logPayload.message = 'Auto incoming creation successfull!';
    logPayload.status = 'Completed';
    await autoIncomingLog(logPayload, 'Update');
    res.send({
      status: trigerstatus,
      message: 'Auto incoming creation successfull!',
    });
  } catch (e) {
    logPayload.message = 'Failed, Please check the log';
    logPayload.status = 'Failed';
    await autoIncomingLog(logPayload, 'Update');
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};

export const autoIncomingForSpringerIssue = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    let doiList = files.filter(list => list.articledoi != '');
    doiList = doiList.map(list => list.articledoi);

    console.log(doiList, 'doiListdoiList');

    const sql3 = `SELECT * FROM public.wms_workorder WHERE doinumber  IN ('${doiList.join(
      "','",
    )}')`;

    const articleNameDetails = await query(sql3);
    files.map(list => {
      const filetedFileType = articleNameDetails.filter(
        sublist => sublist.doinumber == list.articledoi,
      );
      list.filename =
        filetedFileType.length > 0 && list.filetype == 'Article'
          ? `${filetedFileType[0].itemcode}`
          : list.filename;
      return list;
    });

    const sql2 = `select * from pp_mst_filetype where (category = 'Article' or category = 'Issue')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });
    await saveArticleToMappingForSpringerIssue(
      response.data,
      woDetails[0],
      files,
    );
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }
    const trigerstatus = await wmsWorkflowTrigger({
      woDetails: woDetails[0],
      files,
    });
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');
    res.send({ status: trigerstatus });
  } catch (e) {
    res.status(400).send({ status: false, data: e, message: e });
  }
};

export const autoIncomingForSpringer = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype
             , wo.celevelid, jo.isipubeditnewflow  
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    const sql2 = `select * from pp_mst_filetype where (category = 'Article')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });

    await saveArticleToMappingForSpringer(response.data, woDetails[0], files);
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }

    const camundastatus = await wmsWorkflowTrigger({
      woDetails: woDetails[0],
      files,
    });
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');

    res.send({ status: camundastatus });
  } catch (e) {
    res.status(400).send({ status: false, data: e, message: e });
  }
};
export const autoIncomingForSpringerBooks = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype
             , wo.celevelid 
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    const sql2 = `select * from pp_mst_filetype where ( category = 'Book')`;
    files[0].filename = woDetails[0].itemcode;
    const sql3 = `select * from wms_book_master where bookid='${files[0].bookid}' and isactive=true`;
    const bookDetails = await query(sql3);
    if (bookDetails.length > 0) {
      switch (bookDetails[0].celevelid) {
        case '1':
          files[0].isLevel1 = true;
          break;
        case '2':
          files[0].isLevel2 = true;
          break;
        default:
          files[0].isLevel0 = true;
          break;
      }
      files[0].skipEproof = false;
      if (
        files[0]?.filename?.toLowerCase().includes('fm1') ||
        files[0]?.filename?.toLowerCase().includes('bm2') ||
        files[0]?.filename?.toLowerCase().includes('part')
      ) {
        files[0].skipEproof = true;
      }

      files[0].isalttext = bookDetails[0].accesability == 'Yes';
      files[0].isMyCopy = bookDetails[0].mycopy == 'Yes';
      files[0].isIndex = !!bookDetails[0].index;
      files[0].isCover = bookDetails[0].cover == 'Yes';
      files[0].isBook2 = bookDetails[0].book2 == 'Yes';
      files[0].isDirect600 = bookDetails[0].workflow
        .toLowerCase()
        .includes('mono')
        ? true
        : false;
      if (
        woDetails[0].itemcode.toLowerCase().includes('chapter') ||
        woDetails[0].itemcode.toLowerCase().includes('part')
      ) {
        woDetails[0].wfconfig.incoming.fileTypes = '2';
      }
    }
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });

    await saveArticleToMappingForSpringer(response.data, woDetails[0], files);
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }

    const camundastatus = await wmsWorkflowTrigger({
      woDetails: woDetails[0],
      files,
    });
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');

    res.send({ status: camundastatus });
  } catch (e) {
    res.status(400).send({ status: false, data: e, message: e });
  }
};

export const autoIncomingForWKHJournals = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
    case when jo.journaltype = 'online' then true else false end as journaltype,
          wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid
          ,case when org.countryid = 4 then 'true' else 'false' end as isuscustomer
          ,case when org.countryid = 4 and jo.newsletter = true then 'true' else 'false' end as newsletter
          ,case when jo.cereview = true then 'true' else 'false' end as cereview
          ,case when org.countryid = 4 and jo.ispreproof = true then 'true' else 'false' end as ispreproof 
          ,case when jo.revisedtopap = true then 'true' else 'false' end as revisedtopap 
          ,case when jo.pdfjournalpublication = true then 'true' else 'false' end as pdfjournalpublication
          ,case when jo.isiauthor = true then 'true' else 'false' end as isiauthor
          ,jo.iauthworkflowid as iauthworkflowid
          ,jo.articletype as articletype
          ,jo.iauthorreviewworkflow as iauthorreviewworkflow
          from wms_workorder as wo
          join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
          JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
          JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
          JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
          JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
          LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
          join org_mst_customer_orgmap org on org.custorgmapid = jo.custorgmapid
          JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
          JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
          where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    const sql2 = `select * from pp_mst_filetype where (category = 'Article')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });

    await saveArticleToMappingForWKHJournals(
      response.data,
      woDetails[0],
      files,
    );
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }

    const camundastatus = await wmsWorkflowTrigger({
      woDetails: woDetails[0],
      files,
    });
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');

    res.send({ status: camundastatus });
  } catch (e) {
    res.status(400).json({ status: false, data: e, message: e });
  }
};

const deleteAutoIncomingDetails = async workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      let deleteFileDetailsSql = `DELETE FROM wms_workorder_incomingfiledetails WHERE woincomingid IN (SELECT woincomingid FROM public.wms_workorder_incoming WHERE woid = ${workorderId})`;
      let deleteIncomingSql = `DELETE FROM wms_workorder_incoming WHERE woid = ${workorderId}`;
      await query(deleteFileDetailsSql);
      await query(deleteIncomingSql);
      resolve();
    } catch (error) {
      reject(error);
    }
  });
};
export const autoIncomingForACSJournals = async (req, res) => {
  try {
    const { workorderId, files, isRetry } = req.body;
    if (isRetry) {
      await deleteAutoIncomingDetails(workorderId);
    }
    const sql = `select  wo.inputfiletypeid,wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,
            jo.isipubeditnewflow
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    const sql2 = `select * from pp_mst_filetype where (category = 'Article')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });

    await saveArticleToMappingForWKHJournals(
      response.data,
      woDetails[0],
      files,
    );
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }
    logger.info(`ACS Autoincomming process Started, ${workorderId}`);
    let result = await wmsWorkflowTrigger({ woDetails: woDetails[0], files });
    logger.info(
      `ACS Autoincomming process Completed, ${workorderId} as status ${result}`,
    );
    res.send({ status: result });
  } catch (e) {
    logger.info(`ACS Autoincomming process Failed, ${e?.message || e}`);
    res.status(400).send({ status: false, data: e, message: e });
  }
};

export const wmsWorkflowTrigger = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select iscamundaflow from wms_workflow where wfid=${payload.woDetails.wfid}`;
      const response = await query(sql);
      let result = true;
      const withCamunda = response[0].iscamundaflow;
      if (withCamunda) {
        result = await triggerCamundaWorkflow(payload);
      } else {
        const { woDetails, filetypeSkip } = payload;
        const data = {
          wfId: woDetails.wfid,
          workorderId: woDetails.workorderid,
          serviceId: woDetails.serviceid,
          stageId: woDetails.stageid,
          stageIteration: 1,
          filetypeSkip,
        };
        await _triggerWithoutCamundaWorkflow(data);
      }
      resolve(result);
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};

export const triggerCamundaWorkflow = async payload => {
  // eslint-disable-next-line prefer-const
  let { woDetails, files } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      let coverValue = files.filter(list => list.filetypeid == '5');
      let advertValue = files.filter(list => list.filetypeid == '6');
      let runOnValue = files.filter(
        list => list.articletype == 'Other Article',
      );
      coverValue = coverValue.length > 0;
      advertValue = advertValue.length > 0;
      runOnValue = runOnValue.length > 0;
      console.log(coverValue, advertValue);
      const filteredFiles = files.filter(
        list =>
          list.filetypeid == '4' ||
          list.filetypeid == '1' ||
          list.filetypeid == '2',
      );
      const articelIssue = filteredFiles.length > 0;
      const isWordInput = {};
      const isJournalInput = {};
      const iscopyEditingLevel = {};
      const isiAuthor = {};
      const iseonly = {};
      const isNLP = {};
      const isDirectFP = {};
      const flowtype = {};
      const ceLevel = {};
      const isreject = {};
      const camundaFormVariables = {};
      const graphicVariables = {};
      const isPAP = {};
      const isESM = {};
      const isCover = {};
      const isAdvert = {};
      const isTrancheFour = {};
      const word =
        filteredFiles.length > 0 && filteredFiles[0].filepath == ''
          ? true
          : !!(
              woDetails.customerid != '8' &&
              filteredFiles &&
              filteredFiles.length > 0 &&
              (extname(filteredFiles[0].filepath) == '.docx' ||
                extname(filteredFiles[0].filepath) == '.doc')
            );
      camundaFormVariables.__isJournal__ = getCamundaVariable(
        'boolean',
        'true',
      );
      let grpahicValue = files.filter(list => list.imagecount > 0);
      grpahicValue = grpahicValue.length > 0;
      graphicVariables.__isGraphic__ = getCamundaVariable(
        'boolean',
        grpahicValue,
      );
      camundaFormVariables.__isWord__ = getCamundaVariable('boolean', word);
      if (woDetails.celevelid) {
        camundaFormVariables.__CELevel__ = getCamundaVariable(
          'string',
          woDetails.celevelid,
        );
      } else {
        camundaFormVariables.__CELevel__ = getCamundaVariable('string', false);
      }
      camundaFormVariables.__isESM__ = getCamundaVariable('boolean', false);
      camundaFormVariables.__isRejected__ = getCamundaVariable(
        'boolean',
        false,
      );
      camundaFormVariables.__isReset__ = getCamundaVariable('boolean', 'false');
      let tmpiscopyedit = false;
      if (woDetails.celevelid == '0' || woDetails.celevelid == '1') {
        tmpiscopyedit = false;
      } else {
        tmpiscopyedit = true;
      }
      camundaFormVariables.__iscopyEditing__ = getCamundaVariable(
        'boolean',
        tmpiscopyedit,
      );

      if (
        woDetails.wotype == 'Journal' &&
        (['8'].includes(woDetails.customerid.toString()) ||
          ['13', '10'].includes(woDetails.customerid.toString()))
      ) {
        // customerid 1 is not required after the live migration._DU_Segregation_
        camundaFormVariables.__isArticlewiseIssue__ = getCamundaVariable(
          'boolean',
          articelIssue,
        );
        camundaFormVariables.__isEnableForFirstIteration__ = getCamundaVariable(
          'boolean',
          true,
        );
        camundaFormVariables.__isCover__ = getCamundaVariable(
          'boolean',
          coverValue,
        );
        camundaFormVariables.__isRejected__ = getCamundaVariable(
          'boolean',
          false,
        );
        camundaFormVariables.__isAdvert__ = getCamundaVariable(
          'boolean',
          advertValue,
        );
        // variable for WKH specific
        console.log(files[0], ' files[0]');
        if (woDetails.customerid == '13') {
          camundaFormVariables.__isWord__ = getCamundaVariable(
            'boolean',
            files[0].isword,
          );
          camundaFormVariables.__isUSCustomer__ = getCamundaVariable(
            'boolean',
            woDetails.isuscustomer,
          );
          camundaFormVariables.__isPAPWorkflow__ = getCamundaVariable(
            'boolean',
            woDetails.pap,
          );
          camundaFormVariables.__isNewsLetterJournal__ = getCamundaVariable(
            'boolean',
            woDetails.newsletter,
          );
          camundaFormVariables.__isCEreviewForWKH__ = getCamundaVariable(
            'boolean',
            woDetails.cereview,
          );
          camundaFormVariables.__iscopyEditing__ = getCamundaVariable(
            'boolean',
            files[0].iscopy,
          );
          camundaFormVariables.__isPREproof__ = getCamundaVariable(
            'boolean',
            woDetails.ispreproof,
          );
          camundaFormVariables.__isRevisedToPAP__ = getCamundaVariable(
            'boolean',
            woDetails.revisedtopap,
          );
          camundaFormVariables.__isCopyEditingDespatchNeeded__ =
            getCamundaVariable('boolean', files[0].isCopyEditingDespatchNeeded);
          camundaFormVariables.__isPREproof__ = getCamundaVariable(
            'boolean',
            woDetails.ispreproof,
          );
          camundaFormVariables.__isRevisedToPAP__ = getCamundaVariable(
            'boolean',
            woDetails.revisedtopap,
          );
          camundaFormVariables.__isPDFjournal__ = getCamundaVariable(
            'boolean',
            woDetails.pdfjournalpublication,
          );
          camundaFormVariables.__isiAuthor__ = getCamundaVariable(
            'boolean',
            woDetails.isiauthor,
          );

          camundaFormVariables.__isRevisesStageIteration__ = getCamundaVariable(
            'boolean',
            true,
          );
        } else if (
          woDetails.customerid == '8' ||
          woDetails.customerid == '10'
        ) {
          // need to be confirmed with team and deleted unwanted variables
          camundaFormVariables.__isAuthor__ = getCamundaVariable(
            'boolean',
            false,
          );
          camundaFormVariables.__iseonly__ = getCamundaVariable(
            'boolean',
            woDetails.journaltype,
          );
          camundaFormVariables.__isDirectFP__ = getCamundaVariable(
            'boolean',
            false,
          );
          camundaFormVariables.__isNLP__ = getCamundaVariable('boolean', false);
          camundaFormVariables.__isRejected__ = getCamundaVariable(
            'boolean',
            false,
          );
          camundaFormVariables.__isPAP__ = getCamundaVariable('boolean', false);

          camundaFormVariables.__isRunOn__ = getCamundaVariable(
            'boolean',
            runOnValue,
          );
          camundaFormVariables.__isXMLCorr__ = getCamundaVariable(
            'boolean',
            'false',
          );
          camundaFormVariables.__isTextCorr__ = getCamundaVariable(
            'boolean',
            'false',
          );
          camundaFormVariables.__isTrancheFour__ = getCamundaVariable(
            'boolean',
            'false',
          );
        } else if (woDetails.customerid == '70') {
          camundaFormVariables.__isprePub__ = getCamundaVariable(
            'boolean',
            woDetails.isonlineissue,
          );
        }
      } else if (woDetails.customerid == '70') {
        camundaFormVariables.__isprePub__ = getCamundaVariable(
          'boolean',
          woDetails.isonlineissue,
        );
        camundaFormVariables.__isCover__ = getCamundaVariable('boolean', false);
      } else if (woDetails.customerid == '11') {
        camundaFormVariables.__isCover__ = getCamundaVariable('boolean', true);
        camundaFormVariables.__isAdvert__ = getCamundaVariable('boolean', true);
        camundaFormVariables.__isPrint__ = getCamundaVariable(
          'boolean',
          !woDetails.journaltype,
        );
        camundaFormVariables.__isOnline__ = getCamundaVariable('boolean', true);
        const isEO = woDetails.otherdetails.isEO
          ? woDetails.otherdetails.isEO
          : false;
        camundaFormVariables.__isEO__ = getCamundaVariable('boolean', isEO);
      }
      //variable for ACS specific
      else if (woDetails.customerid == '15') {
        camundaFormVariables.__isiPubEdit__ = getCamundaVariable(
          'boolean',
          woDetails.isipubeditnewflow,
        );
        camundaFormVariables.__isTexFlow__ = getCamundaVariable(
          'boolean',
          woDetails.inputfiletypeid == 10 ? true : false,
        );
      }
      if (woDetails.customerid == '10' && woDetails.wotype == 'Journal') {
        camundaFormVariables.__isiPubEdit__ = getCamundaVariable(
          'boolean',
          woDetails.isipubeditnewflow,
        );
      }
      if (woDetails.customerid == '12' && woDetails.wotype == 'Book') {
        camundaFormVariables.__isAltText__ = getCamundaVariable(
          'boolean',
          files[0].isalttext ? files[0].isalttext : false,
        );
        camundaFormVariables.__isCover__ = getCamundaVariable(
          'boolean',
          files[0].isCover ? files[0].isCover : false,
        );
        camundaFormVariables.__isEnableFirstTime__ = getCamundaVariable(
          'boolean',
          true,
        );
        camundaFormVariables.__isIndex__ = getCamundaVariable(
          'boolean',
          files[0].isIndex ? files[0].isIndex : false,
        );
        camundaFormVariables.__isBook2__ = getCamundaVariable(
          'boolean',
          files[0].isBook2 ? files[0].isBook2 : false,
        );
        camundaFormVariables.__isMyCopy__ = getCamundaVariable(
          'boolean',
          files[0].isMyCopy ? files[0].isMyCopy : false,
        );
        if (woDetails.wfstageid == '18') {
          camundaFormVariables.__skipEproof__ = getCamundaVariable(
            'boolean',
            files[0].skipEproof ? files[0].skipEproof : false,
          );
          camundaFormVariables.__isLevel0__ = getCamundaVariable(
            'boolean',
            files[0].isLevel0 ? files[0].isLevel0 : false,
          );
          camundaFormVariables.__isLevel1__ = getCamundaVariable(
            'boolean',
            files[0].isLevel1 ? files[0].isLevel1 : false,
          );
          camundaFormVariables.__isLevel2__ = getCamundaVariable(
            'boolean',
            files[0].isLevel2 ? files[0].isLevel2 : false,
          );
          camundaFormVariables.__isDirect600__ = getCamundaVariable(
            'boolean',
            files[0].isDirect600 ? files[0].isDirect600 : false,
          );
        }
      }
      files = files.filter(list => list.filetypeid != 10);
      const data = {
        woid: woDetails.workorderid,
        workFlow: woDetails.workflow,
        woStageId: woDetails.wostageid,
        service: woDetails.service,
        stagename: woDetails.stagename,
        valuesOfArray: files,
        chapters: {
          received: files.length,
          total:
            woDetails.wotype !== 'Journal'
              ? woDetails.totalchaptercount
              : files.length,
        },
        receiptdate: new Date(woDetails.ordermaildate).toISOString(),
        jobcardId: woDetails.jobcardid,
        userid: 'System',
        wotype: woDetails.wotype,
        customerId: woDetails.customerid,
        duId: woDetails.assignedduid,
        stageId: woDetails.wfstageid,
        wfId: woDetails.wfid,
        camundaFormVariables: camundaFormVariables || {},
        graphicVariables,
        isWordInput,
        isJournalInput,
        iscopyEditingLevel,
        iseonly,
        isiAuthor,
        isNLP,
        isDirectFP,
        ceLevel,
        flowtype,
        isreject,
        isPAP,
        isESM,
        isCover,
        isAdvert,
        duedate: new Date(woDetails.plannedenddate).toISOString(),
        updatedby: 'System',
        fileNameISBN: `${woDetails.itemcode}_Issue`,
        doiNumber: woDetails.doinumber ? woDetails.doinumber : '',
        jobId: woDetails.itemcode,
        jobType: jobTypeObj[woDetails.jobtype],
        isTrancheFour,
      };

      const camundaResponse = await _saveBookCompleted(
        { body: data },
        { res: {} },
      );
      console.log(camundaResponse);
      if (camundaResponse.status == false) {
        reject('camunda Response failed');
      } else {
        resolve(true);
      }
    } catch (error) {
      reject(error.message ? error.message : error);
    }
  });
};
export const saveArticleToMapping = async (resData, woDetails, files) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename,
        );
        const fileType = {
          fileTypeName: filteredFiles[0].filetype,
          fileTypeId: filteredFiles[0].filetypeid,
          fileId: res.woincomingfileid,
        };
        const paths = await getFolderPathForFileType(woDetails, fileType);
        console.log(paths, 'path for issue article file');
        const sql = `select wo.workorderid,woservice.serviceid from wms_workorder  as wo
        join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
        where itemcode = '${res.filename}' `;
        const srcFileDetails = await query(sql);
        if (srcFileDetails && srcFileDetails.length > 0) {
          const data = {
            desFolderPath: paths,
            workorderId: srcFileDetails[0].workorderid,
            serviceId: srcFileDetails[0].serviceid,
            customerId: woDetails.customerid,
          };

          const copyFileDetail = await _copyArticleToIssue(
            { body: data },
            { res: {} },
          );
          console.log('copy file details', copyFileDetail);
          res.fileuuid = copyFileDetail.uuid ? copyFileDetail.uuid : '';
          res.filepath = copyFileDetail.path ? copyFileDetail.path : '';
          const resArray = [];
          resArray.push(res);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }

      // copy non article type to issue zip file copy//

      const nonArticleTypes = files.filter(
        list =>
          list.filetype == 'Cover' ||
          list.filetype == 'TOC' ||
          list.filetype == 'Advert',
      );
      const nonarticlesql = `select woincomingfileid,filetypes.filetype,filename,* from wms_workorder_incoming as incoming
      join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
      join pp_mst_filetype as filetypes on filetypes.filetypeid = indetails.filetypeid
      where incoming.woid = ${woDetails.workorderid} and filetypes.filetypeid in (6,5,17)`;
      const incomingDetails = await query(nonarticlesql);
      for (let j = 0; j < incomingDetails.length; j++) {
        const fileType = {
          fileTypeName: incomingDetails[j].filetype,
          fileTypeId: incomingDetails[j].filetypeid,
          fileId: incomingDetails[j].woincomingfileid,
        };
        const findIndex = files.findIndex(
          list => list.filetype == incomingDetails[j].filetype,
        );
        if (findIndex != -1) {
          files[findIndex].woincomingfileid =
            incomingDetails[j].woincomingfileid;
        }
        const paths = await getFolderPathForFileType(woDetails, fileType);
        const data = {
          desFolderPath: paths,
          srcFilePath:
            nonArticleTypes.length > 0 ? nonArticleTypes[0].filepath : '',
          workorderId: woDetails.workorderid,
        };
        if (nonArticleTypes.length > 0) {
          const copyFileDetail1 = await _copyNonArticleToIssue(
            { body: data },
            { res: {} },
          );
          console.log('copy file details', copyFileDetail1);
          const res = incomingDetails[j];
          res.duedate = new Date(incomingDetails[j].duedate).toISOString();
          res.fileuuid = copyFileDetail1.uuid ? copyFileDetail1.uuid : '';
          res.filepath = copyFileDetail1.path ? copyFileDetail1.path : '';
          const resArray = [];
          resArray.push(res);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const saveArticleToMappingForSpringerIssue = async (
  resData,
  woDetails,
  files,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename && list.filetypeid == '4',
        );
        if (filteredFiles && filteredFiles.length > 0) {
          const fileType = {
            fileTypeName: filteredFiles[0].filetype,
            fileTypeId: filteredFiles[0].filetypeid,
            fileId: res.woincomingfileid,
          };
          const paths = await getFolderPathForFileType(woDetails, fileType);
          console.log(paths, 'path for issue article file');
          const sql = `select wo.workorderid,woservice.serviceid from wms_workorder  as wo
        join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
        where itemcode = '${res.filename}' `;
          const srcFileDetails = await query(sql);
          if (srcFileDetails && srcFileDetails.length > 0) {
            const data = {
              desFolderPath: paths,
              workorderId: srcFileDetails[0].workorderid,
              serviceId: srcFileDetails[0].serviceid,
              customerId: woDetails.customerid,
            };

            const copyFileDetail = await _copyArticleToIssue(
              { body: data },
              { res: {} },
            );
            console.log('copy file details springer issue', copyFileDetail);
            const resArray = [];
            if (copyFileDetail && copyFileDetail.length > 0) {
              res.fileuuid = copyFileDetail[0].uuid
                ? copyFileDetail[0].uuid
                : '';
              res.filepath = copyFileDetail[0].path
                ? copyFileDetail[0].path
                : '';
              resArray.push(res);
            } else {
              res.fileuuid =
                copyFileDetail && copyFileDetail.uuid
                  ? copyFileDetail.uuid
                  : '';
              res.filepath =
                copyFileDetail && copyFileDetail.path
                  ? copyFileDetail.path
                  : '';
              resArray.push(res);
            }

            const data1 = {
              valuesOfArray: resArray,
              action: 'update',
              woid: woDetails.workorderid,
            };
            await _updateChapter({ body: data1 }, { res: {} });
          }
        }
      }
      // copy non article type to issue zip file copy//

      const nonArticleTypes = files.filter(
        list =>
          list.filetype == 'Cover' ||
          list.filetype == 'Frontmatter' ||
          list.filetype == 'Advert' ||
          list.filetype == 'TOC' ||
          list.filetype == 'Backmatter',
      );
      const nonarticlesql = `select woincomingfileid,filetypes.filetype,filename,* from wms_workorder_incoming as incoming
      join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
      join pp_mst_filetype as filetypes on filetypes.filetypeid = indetails.filetypeid
      where incoming.woid = ${woDetails.workorderid} and filetypes.filetypeid in (6,5,18,19)`;
      const incomingDetails = await query(nonarticlesql);
      for (let j = 0; j < incomingDetails.length; j++) {
        const fileType = {
          fileTypeName: incomingDetails[j].filetype,
          fileTypeId: incomingDetails[j].filetypeid,
          fileId: incomingDetails[j].woincomingfileid,
        };
        const findIndex = files.findIndex(
          list => list.filetype == incomingDetails[j].filetype,
        );
        if (findIndex != -1) {
          files[findIndex].woincomingfileid =
            incomingDetails[j].woincomingfileid;
        }
        const paths = await getFolderPathForFileType(woDetails, fileType);
        const data = {
          desFolderPath: paths,
          srcFilePath:
            nonArticleTypes.length > 0 ? nonArticleTypes[0].filepath : '',
          workorderId: woDetails.workorderid,
        };
        if (nonArticleTypes.length > 0) {
          const copyFileDetail1 = await _copyNonArticleToIssue(
            { body: data },
            { res: {} },
          );
          console.log('copy file details', copyFileDetail1);
          const res = incomingDetails[j];
          res.duedate = new Date(incomingDetails[j].duedate).toISOString();
          res.fileuuid = copyFileDetail1.uuid ? copyFileDetail1.uuid : '';
          res.filepath = copyFileDetail1.path ? copyFileDetail1.path : '';
          const resArray = [];
          resArray.push(res);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const saveArticleToMappingForSpringer = async (
  resData,
  woDetails,
  files,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename,
        );
        const fileType = {
          fileTypeName: filteredFiles[0].filetype,
          fileTypeId: filteredFiles[0].filetypeid,
          fileId: res.woincomingfileid,
        };
        const paths = await getFolderPathForFileType(woDetails, fileType);
        console.log(paths, 'path for issue article file');

        // let copyData = {};
        // const dmsType = await getdmsType(woDetails.workorderid);
        // const name = basename(files[0].filepath);
        // switch (dmsType) {
        //   case 'azure':
        //     copyData = await azureHelper._copyFile({
        //       srcPath: files[0].filepath,
        //       destBasePath: path,
        //       name,
        //     });
        //     break;
        //   default:
        //     const destUuid = await _createFolder(path);
        //     copyData = await _copyFile({
        //       src: 'openkm',
        //       dest: destUuid,
        //       destBasePath: path,
        //       name,
        //     });
        // }
        // tempArr.push(copyData);
        // console.log('copied file', copyData);
        //   console.log('copy file details', copyData);
        res.fileuuid = 'azure';
        res.filepath = paths || '';
        const resArray = [];
        resArray.push(res);
        const data1 = {
          valuesOfArray: resArray,
          action: 'update',
          woid: woDetails.workorderid,
        };
        await _updateChapter({ body: data1 }, { res: {} });
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const saveArticleToMappingForWKHJournals = async (
  resData,
  woDetails,
  files,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename,
        );
        const fileType = {
          fileTypeName: filteredFiles[0].filetype,
          fileTypeId: filteredFiles[0].filetypeid,
          fileId: res.woincomingfileid,
        };
        let paths = await getFolderPathForFileType(woDetails, fileType);
        paths = join(paths, '');

        console.log(paths, 'path for issue article file');

        let copyData = {};
        const dmsType = await getdmsType(woDetails.workorderid);
        const name = basename(files[0].filepath);
        const tempArr = [];
        switch (dmsType) {
          case 'azure':
            copyData = await azureHelper._copyFile({
              srcPath: files[0].filepath,
              destBasePath: paths,
              name,
            });
            break;
          case 'local':
            copyData = await localHelper._localcopyFile({
              srcPath: files[0].filepath,
              destBasePath: paths,
              name,
            });
            break;
          default:
            const destUuid = await _createFolder(paths);
            copyData = await _copyFile({
              src: 'openkm',
              dest: destUuid,
              destBasePath: paths,
              name,
            });
        }
        tempArr.push(copyData);
        console.log('copied file', copyData);
        console.log('copy file details', copyData);
        res.fileuuid = 'azure';
        res.filepath = tempArr[0].path || '';
        const resArray = [];
        resArray.push(res);
        const data1 = {
          valuesOfArray: resArray,
          action: 'update',
          woid: woDetails.workorderid,
        };
        await _updateChapter({ body: data1 }, { res: {} });
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const getFolderPathForFileType = (item, fileType) => {
  return new Promise(async (resolve, reject) => {
    const {
      customername,
      customerid,
      assignedduid,
      duname,
      workorderid,
      servicename,
      serviceid,
    } = item;
    const du = { id: assignedduid, name: duname };
    const service = { id: serviceid, name: servicename };
    const folderPathData = {
      // eslint-disable-next-line no-constant-condition
      type: true ? 'wo_incoming_file_subtype' : 'wo_incoming_filetype',
      du,
      customer: {
        name: customername,
        id: customerid,
      },
      workOrderId: workorderid,
      service,
      fileType: {
        name: fileType.fileTypeName,
        id: fileType.fileTypeId,
        fileId: fileType.fileId,
      },
    };
    try {
      const paths = await getFolderStructure(folderPathData);
      resolve(paths);
    } catch (e) {
      reject(e);
    }
  });
};

export const _saveChapter = async (req, res) => {
  console.log(res);
  return new Promise(async (resolve, reject) => {
    const {
      woid,
      service,
      stageid,
      receiptdate,
      duedate,
      updatedby,
      batchno,
      valuesOfArray,
      totalNonArticleCount,
      totalArticleCount,
      jobType,
    } = req.body;
    console.log(req.body);
    try {
      let existingFile_New = '';
      await transaction(async client => {
        let continueFlow = true;
        if (totalNonArticleCount && totalArticleCount) {
          let tempArticleCount = 0;
          let tempNonArticleCount = 0;
          valuesOfArray.forEach(vr => {
            if (vr.filetypeid === '4') {
              tempArticleCount += 1;
            }
            if (vr.filetypeid === '9') {
              tempNonArticleCount += 1;
            }
          });
          const sql = `SELECT filetypeid,count(*) FROM wms_workorder_incomingfiledetails incoming
          LEFT JOIN wms_workorder_incoming incomingfiles ON incomingfiles.woincomingid=incoming.woincomingid 
          WHERE incomingfiles.woid=${woid} GROUP BY filetypeid`;
          const { rows: dataCount } = await client.query(sql);
          if (dataCount && dataCount.length > 0) {
            dataCount.forEach(dc => {
              if (dc.filetypeid === '4' && tempArticleCount > 0) {
                if (+dc.count + tempArticleCount > +totalArticleCount)
                  continueFlow = false;
              } else if (dc.filetypeid === '9' && tempNonArticleCount > 0) {
                if (+dc.count + tempNonArticleCount > +totalNonArticleCount)
                  continueFlow = false;
              }
            });
          }
        }

        if (continueFlow) {
          let insertIncomingSQL = `INSERT INTO public.wms_workorder_incoming(
                                      woid, serviceid, stageid, receiptdate, duedate, updatedby, batchno, updatedon)
                                      VALUES (${woid}, ${service.id}, ${stageid}, '${receiptdate}', '${duedate}', 
                                      '${updatedby}', ${batchno}, current_timestamp) 
                                      RETURNING woincomingid`;
          const { rows: resForEntry } = await client.query(insertIncomingSQL);
          const woincomingid = resForEntry[0].woincomingid;
          const val = [];
          for (const list of valuesOfArray) {
            let checkFileSQL = `SELECT * FROM public.wms_workorder_incomingfiledetails 
                                WHERE woincomingid in (select woincomingid from wms_workorder_incoming where woid=${woid})
                                AND filename = '${list.filename}'`;
            // AND filepath = '${list.filepath}'
            // AND fileuuid = '${list.fileuuid}'
            const { rows: existingFile } = await client.query(checkFileSQL);
            existingFile_New = existingFile;
            if (existingFile.length === 0 || jobType == '2') {
              val.push(
                `(${woincomingid}, '${list.filename}', '${list.filepath}', '${
                  list.fileuuid
                }',
                ${list.duedate ? `'${list.duedate}'` : null},
                ${list.mspages}, ${list.estimatedpages},
                ${list.imagecount || null},
                ${list.tablecount || null}, ${list.equationcount || null},
                ${list.boxcount || null}, ${list.filetypeid || null}, false,
                ${
                  isNaN(parseInt(list.filesequence))
                    ? null
                    : parseInt(list.filesequence)
                },
                ${list.wordcount || null}, ${list.referencecount || null},
                ${list.pii ? `'${list.pii}'` : null},
                ${list.articletype ? `'${list.articletype}'` : null},
                ${list.ishalfpage ? list.ishalfpage : false},
                ${list.articleordersequence || null},
                ${list.runonfilesequence || null}, 
                ${list.subfiletypeid || null},
                ${list.is_correction !== undefined ? list.is_correction : null},
                ${list.folio_type ? `'${list.folio_type}'` : null},
                ${
                  list.article_date
                    ? `'${new Date(list.article_date).toISOString()}'`
                    : 'CURRENT_TIMESTAMP'
                },
                ${list.article_status ? `'${list.article_status}'` : null},
                ${list.assign_status ? `'${list.assign_status}'` : null},
                ${list.issue_type ? `'${list.issue_type}'` : null},
                ${
                  isNaN(parseInt(list.typesetpage))
                    ? null
                    : parseInt(list.typesetpage)
                },
                ${list.is_edit ? list.is_edit : true}
                )`,
              );
            }
          }
          if (val.length > 0) {
            const insertFilesSQL = `INSERT INTO public.wms_workorder_incomingfiledetails(
                                    woincomingid, filename, filepath, fileuuid, duedate, mspages, estimatedpages,
                                    imagecount, tablecount, equationcount, boxcount, filetypeid, istriggered,
                                    filesequence, wordcount, referencecount, piinumber, articletype, ishalfpage, articleordersequence,
                                    runonfilesequence, subfiletypeid, is_correction, folio_type, article_date, article_status, assign_status,
                                    issue_type, typesetpage, is_edit)
                                    VALUES ${val.join(', ')} RETURNING *`;
            const { rows: resForChapter } = await client.query(insertFilesSQL);
            resolve({
              data: resForChapter,
              message: 'Chapter has been added successfully',
            });
          } else {
            resolve({
              data: existingFile_New,
              message: 'Already incoming inserted!',
            });
          }
        } else {
          resolve({ message: 'Total Article or Non-Article count exceeded.' });
        }
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const saveChapter = async (req, res) => {
  try {
    const result = await _saveChapter(req, res);
    res.send({ status: true, ...result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const updateChapter = async (req, res) => {
  try {
    const result = await _updateChapter(req, res);
    res.send({ status: true, ...result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const _updateChapter = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { valuesOfArray, action, woid, jobtype } = req.body;

    try {
      let fileExists = [];
      if (action !== 'add' && valuesOfArray.length === 1) {
        const condition = `AND filename IN ('${
          valuesOfArray[0].filename
        }') AND  woincomingfileid != ${valuesOfArray[0].woincomingfileid}
        ${
          valuesOfArray[0].filepath
            ? `AND filepath = '${valuesOfArray[0].filepath}'`
            : ''
        }`;
        const sqlForFileExists = `SELECT filename FROM wms_workorder_incoming
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
             ${condition}
            WHERE  wms_workorder_incoming.woid = ${woid} `;
        fileExists = await query(sqlForFileExists);
      }
      // have to changes from  > to <
      if (fileExists.length < 1) {
        const files = [];
        for (let i = 0; i < valuesOfArray.length; i++) {
          const {
            woincomingid,
            filetypeid,
            subfiletypeid,
            filename,
            mspages,
            estimatedpages,
            imagecount,
            tablecount,
            equationcount,
            woincomingfileid,
            filepath,
            fileuuid,
            duedate,
            boxcount,
            wordcount,
            referencecount,
            article_status = null,
            assign_status = null,
            typesetpage = null,
            filesequence = null,
            folio_type = null,
            is_correction = null,
            issue_type = null,
            startpage = null,
            endpage = null,
          } = valuesOfArray[i];

          const sql = `UPDATE wms_workorder_incomingfiledetails
            SET woincomingid=${woincomingid}, filetypeid=${filetypeid}, subfiletypeid=${subfiletypeid},
            filename='${filename}', filepath='${filepath}', fileuuid='${fileuuid}', duedate='${duedate}', 
            mspages=${mspages}, estimatedpages=${estimatedpages}, imagecount=${imagecount},
            tablecount=${tablecount}, equationcount=${equationcount}, boxcount=${boxcount},
            wordcount=${wordcount}, referencecount=${referencecount}, article_status='${article_status}',
            assign_status='${assign_status}', typesetpage=${typesetpage}, filesequence=${filesequence},
            folio_type='${folio_type}', is_correction=${is_correction}, issue_type='${issue_type}',
            startpage=${startpage}, endpage=${endpage} WHERE woincomingfileid = ${woincomingfileid}`;
          files.push({ id: woincomingfileid });
          await query(sql);
          const sql1 = `UPDATE public.wms_workorder_incoming SET updatedon = current_timestamp
              WHERE woincomingid = ${woincomingid} `;
          await query(sql1);
        }
        console.log(res);
        // res
        //   .status(200)
        //   .json({ message: 'Chapter has been updated successfully' });
        resolve({ message: 'Chapter has been updated successfully' });
      } else {
        let existFiles = '';
        fileExists.forEach((file, i) => {
          existFiles += `'${file.filename}' ${
            fileExists.length - 1 !== i ? ',' : ''
          }`;
        });
        // res
        //   .status(409)
        //   .json({ message: `Chapter name already exists: ${existFiles}` });
        resolve({ message: `Chapter name already exists: ${existFiles}` });
      }
    } catch (error) {
      reject({ message: error.message ? error.message : error });
      // res.status(400).send({ message: error.message ? error.message : error });
    }
  });
};

// Incoming For Manual Workorder Commented By IS9373
export const _saveBookCompleted = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const {
      woid,
      service,
      stagename,
      workFlow,
      woStageId,
      chapters,
      valuesOfArray,
      wotype,
      camundaFormVariables,
      jobType,
      graphicVariables,
      isWordInput,
      isJournalInput,
      iscopyEditingLevel,
      isiAuthor,
      iseonly,
      isNLP,
      isDirectFP,
      flowtype,
      ceLevel,
      isreject,
      isAltText,
      isPAP,
      isPCPJ,
      isESM,
      isCover,
      isAdvert,
      customerId,
      stageId,
      wfId,
      otherfield,
      isTrancheFour,
    } = req.body;
    const stage = {
      type: stagename.toLowerCase().replace(/ /g, '_'),
      iteration: 1,
    };

    try {
      if (otherfield) {
        const sql_update_otherfields = `UPDATE wms_workorder SET otherfield = '${JSON.stringify(
          otherfield,
        )}' WHERE workorderid = ${woid}`;
        const sql_update_otherfields_data = await query(sql_update_otherfields);
      }
      const files = [];
      const unTriggeredArray = [];
      let iscopyediting = false;
      const wosql = `SELECT 
                    workorderid,itemcode, createdon :: timestamp(0) as jobcreatedon,celevelid, 
                    CASE WHEN customerid = 10 THEN 
                    CASE WHEN celevelid> 2 THEN true ELSE false END
                    ELSE 
                    CASE WHEN celevelid> 1 THEN true ELSE false END
                    END AS iscopyediting
                  FROM wms_workorder 
                  WHERE workorderid = $1`;
      const workorderdata = await query(wosql, [woid]);

      if (workorderdata.length) {
        iscopyediting = workorderdata.length
          ? workorderdata[0].iscopyediting
          : false;
      }

      let sql = `SELECT processinstanceid FROM public.wms_workorder_service where serviceid = $1 and workorderid = $2`;
      let [{ processinstanceid: processInstanceId }] = await query(sql, [
        service.id,
        woid,
      ]);
      const fileids = [];
      valuesOfArray.forEach(ele => {
        fileids.push(ele.woincomingfileid);
      });
      sql = `select istriggered, wms_workorder_incomingfiledetails.filetypeid,imagecount,woincomingfileid,filename,filetypes.filetype,mspages,estimatedpages from wms_workorder_incomingfiledetails
      join pp_mst_filetype as filetypes on filetypes.filetypeid = wms_workorder_incomingfiledetails.filetypeid
       where woincomingfileid in (${fileids.join(',')})`;
      const data = await query(sql, []);
      data.forEach(ele => {
        if (
          !ele.istriggered &&
          workFlow.incoming.fileTypes.includes(parseInt(ele.filetypeid))
        ) {
          if (jobType === 'Issue' && wotype == 'Journal') {
            files.push({
              id: ele.woincomingfileid,
              isGraphic: parseInt(ele.imagecount) > 0,
              type: ele.filetype,
              filetypeid: ele.filetypeid,
              name: ele.filename,
              isChecked: false,
              mspages: ele.mspages,
              estimatedpages: ele.estimatedpages,
            });
          } else {
            files.push({
              id: ele.woincomingfileid,
              isGraphic: parseInt(ele.imagecount) > 0,
            });
          }

          unTriggeredArray.push(
            ...valuesOfArray.filter(
              x => x.woincomingfileid == ele.woincomingfileid,
            ),
          );
        }
      });
      // check the iTracks call
      let iTracksObj = { status: true, message: '' };
      const isItracksAPI = await checkItracksExits(req, res);
      console.log(isItracksAPI, 'isItracksAPI');
      const { status } = isItracksAPI;

      if (customerId == 13) {
        const getwoid = ` select jn.newsletter,wo.workorderid,wo.customerid from wms_workorder as wo
        join pp_mst_journal as jn on jn.journalid = wo.journalid
        where wo.workorderid = ${woid}`;
        const newData = await query(getwoid);
        console.log('newData', newData);
        if (newData.length > 0 && newData[0].newsletter == true) {
          const sqlquery = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
          case when jo.journaltype = 'online' then true else false end as journaltype,
                wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid,
                case when org.countryid = 4 then 'true' else 'false' end as isuscustomer
                ,case when org.countryid = 4 and jo.newsletter = true then 'true' else 'false' end as newsletter
                ,case when org.countryid = 4 then 'true' else 'false' end as iscopyediting
                ,case when jo.cereview = true then 'true' else 'false' end as cereview
                ,case when org.countryid = 4 and jo.ispreproof = true then 'true' else 'false' end as ispreproof
                ,case when jo.revisedtopap = true then 'true' else 'false' end as revisedtopap
                ,case when jo.pdfjournalpublication = true then 'true' else 'false' end as pdfjournalpublication
                ,case when jo.isiauthor = true then 'true' else 'false' end as isiauthor
                ,jo.iauthworkflowid as iauthworkflowid
                ,jo.articletype as articletype
                ,jo.iauthorreviewworkflow as iauthorreviewworkflow
                from wms_workorder as wo
                join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
                JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
                JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
                JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
                JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
                LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
                join org_mst_customer_orgmap org on org.custorgmapid = jo.custorgmapid
                JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
                JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
                where wo.workorderid = ${woid}`;
          const result = await query(sqlquery);

          console.log('result', result);
          if (result[0].customerid == '13') {
            camundaFormVariables.__isUSCustomer__ = getCamundaVariable(
              'boolean',
              result[0].isuscustomer,
            );

            camundaFormVariables.__isNewsLetterJournal__ = getCamundaVariable(
              'boolean',
              result[0].newsletter,
            );
            camundaFormVariables.__isCEreviewForWKH__ = getCamundaVariable(
              'boolean',
              result[0].cereview,
            );
            camundaFormVariables.__isCopyEditingDespatchNeeded__ =
              getCamundaVariable('boolean', false);

            camundaFormVariables.__iscopyEditing__ = getCamundaVariable(
              'boolean',
              result[0].iscopyediting,
            );
            camundaFormVariables.__isPREproof__ = getCamundaVariable(
              'boolean',
              result[0].ispreproof,
            );
            camundaFormVariables.__isRevisedToPAP__ = getCamundaVariable(
              'boolean',
              result[0].revisedtopap,
            );
            camundaFormVariables.__isPDFjournal__ = getCamundaVariable(
              'boolean',
              result[0].pdfjournalpublication,
            );
            camundaFormVariables.__isiAuthor__ = getCamundaVariable(
              'boolean',
              result[0].isiauthor,
            );
            camundaFormVariables.__isRevisesStageIteration__ =
              getCamundaVariable('boolean', false);
          }
        }
      }

      if (wotype === 'Book') {
        if (customerId != 12) {
          // Springer Books
          await addNewFileType(req, 1);
        }
        if (status && unTriggeredArray.length) {
          console.log(appConfig.isItracksAPI, 'start the subjob call');

          sql = `SELECT * FROM public.wms_workorder_incoming as wwi
        JOIN public.wms_workorder_incomingfiledetails as wwif ON wwif.woincomingid = wwi.woincomingid
        where wwi.woid = $1`;
          const getIncomingFiles = await query(sql, [woid]);
          console.log(getIncomingFiles, 'getIncomingFiles');

          // call iTracks API
          req.body.stageIterationCount = 1;
          const subJobRes = await addSubJob(
            getIncomingFiles,
            req.body,
            true,
            false,
          );
          iTracksObj = subJobRes;
        }
      } else if (jobType === 'Issue') {
        // call merge issue
        if (status) {
          const mergeIssueRes = await mergeIssue(unTriggeredArray, req.body);
          iTracksObj = mergeIssueRes;
        }
        // add issue type
        await addNewFileType(req, 10);
        if (status) {
          iTracksObj = await addSatge(req.body);
        }
      } else if (customerId == 11) {
        const stageResponse = await oupaddstage(req.body);
        iTracksObj = stageResponse;
      } else {
        let addStageRes;

        // console.log(relatedstagedet);
        // add stage for journal
        if (status) {
          // if (woid > 1976 && customerId == '13') {
          let relatedstageObj = [];
          const relatedstagedet = await relatedStageInfo(
            wfId,
            customerId,
            stageId,
            woid,
          );

          if (relatedstagedet.issuccess) {
            relatedstageObj = relatedstagedet.data;
          }
          // const objreqbody = req.body;
          for (let rindex = 0; rindex < relatedstageObj.length; rindex++) {
            if (
              relatedstageObj[rindex].stageid == 24 &&
              customerId != '70' &&
              iscopyediting == false
            ) {
              console.log('test');
            } else {
              if (stageId != relatedstageObj[rindex].stageid) {
                req.body.stageId = relatedstageObj[rindex].stageid;
                req.body.isrelatedstage = true;
              } else {
                req.body.isrelatedstage = false;
              }
              addStageRes = await addSatge(req.body);
              if (
                addStageRes.status == undefined ||
                addStageRes.status == false
              ) {
                break;
              }
            }
          }
          // } else {
          //   addStageRes = await addSatge(req.body);
          // }
          iTracksObj = addStageRes;
        }
        req.body.stageId = stageId;
        // if (status) {
        //   addStageRes = await addSatge(req.body);
        //   iTracksObj = addStageRes;
        // }
      }

      // iTracksObj.status = false;
      console.log(iTracksObj, 'iTracksObj');
      if (iTracksObj.status) {
        const addeddate = new Date();

        addeddate.setHours(addeddate.getHours() + 5);
        addeddate.setMinutes(addeddate.getMinutes() + 30);

        const currentdate = convertDateFormat(addeddate);

        console.log(iTracksObj.status, 'iTracksObj.status');
        if (!processInstanceId) {
          // let m_reviseddate = currentdate;
          // if (wotype === 'Journal') {
          //   const psql = `SELECT
          //   (SELECT  add_hours_exclude_weekends_and_holidays
          //   FROM add_hours_exclude_weekends_and_holidays($3::timestamp, duc.articleduedays ::integer))::timestamp(0) as revisedenddate
          //   ,wst.wfstageid
          //   FROM wms_workorder as wo
          //   JOIN wms_workorder_stage AS wst on wst.workorderid = wo.workorderid and wst.wostageid = $2
          //   JOIN public.org_mst_journal_dueconfig as duc on duc.journalid = wo.journalid and duc.stageid = wst.wfstageid
          //   WHERE wo.workorderid = $1   and duc.stageiterationcount = 1 and duc.isactive = true;`;

          //   await query(psql, [woid, woStageId, currentdate]).then(
          //     async dataresult => {
          //       if (dataresult && dataresult.length) {
          //         // console.log(dataresult);
          //         const newreviseddate = convertDateFormat(
          //           dataresult[0].revisedenddate,
          //         );
          //         m_reviseddate = newreviseddate;
          //       } else {
          //         m_reviseddate = currentdate;
          //       }
          //     },
          //   );
          // }

          sql = `UPDATE public.wms_workorder_stage SET status=$1, startdatetime= $2  where wostageid =$3`;
          await query(sql, [
            'In Process',
            // new Date(),
            currentdate,
            woStageId,
          ]);
          processInstanceId = await triggerWorkflow(
            workFlow.category,
            workFlow.id,
            woid,
            service.id,
            stage,
            files,
            workFlow.enableListener,
            undefined,
            camundaFormVariables,
            graphicVariables,
            isWordInput,
            isJournalInput,
            iscopyEditingLevel,
            isiAuthor,
            iseonly,
            isNLP,
            isDirectFP,
            flowtype,
            ceLevel,
            isreject,
            isAltText,
            isPAP,
            isPCPJ,
            isESM,
            isCover,
            isAdvert,
            isTrancheFour,
          );
          // processInstanceId = await triggerWorkflow(workFlow.category, workFlow.id, woid, service.id, stage, files, workFlow.enableListener, undefined, camundaFormVariables);
          sql = `UPDATE public.wms_workorder_service SET processinstanceid=$1, status=$2 where serviceid = $3 and workorderid = $4`;
          await query(sql, [processInstanceId, 'In Process', service.id, woid]);
        } else {
          await triggerWorkflow(
            workFlow.category,
            workFlow.id,
            woid,
            service.id,
            stage,
            files,
            workFlow.enableListener,
            processInstanceId,
          );
        }
        for (let i = 0; i < files.length; i++) {
          sql = `UPDATE public.wms_workorder_incomingfiledetails SET istriggered=true where woincomingfileid=${files[i].id}`;
          await query(sql, []);
        }
        if (chapters.total == chapters.received)
          await bookComplete(
            woid,
            service.id,
            workFlow.category,
            chapters.total,
            stage.type,
            workFlow.enableListener,
            processInstanceId,
          );

        resolve({ message: 'WF Triggered successfully', status: true });
      } else {
        console.log('inside err');
        resolve({ message: iTracksObj.message, status: false });
      }
    } catch (e) {
      reject({ message: e.message ? e.message : e, status: false });
    }
  });
};

export const _getFormattedName = async (req, res) => {
  try {
    const { unFormattedName, placeHolders } = req.body;
    const result = await getFormattedName(unFormattedName, placeHolders);
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};
export const saveBookCompleted = async (req, res) => {
  try {
    let result;
    const woDetails = req.body;
    if (req.body.iscamundaflow) {
      result = await _saveBookCompleted(req, res);
    } else {
      let filetypeSkip = [];
      if (woDetails.wfId == 55) {
        filetypeSkip = [5, 6];
      } else if (woDetails.wfId == 53) {
        filetypeSkip = [5, 6];
      }
      const data = {
        wfId: woDetails.wfId,
        workorderId: woDetails.woid,
        serviceId: woDetails.service.id,
        stageId: woDetails.stageId,
        stageIteration: 1,
        filetypeSkip,
      };
      //Initial Stage Enable
      result = await _triggerWithoutCamundaWorkflow(data);

      //Graphics Stage Enable
      const isGraphic = woDetails.valuesOfArray.some(
        item => item.imagecount > 0,
      );
      if (isGraphic && woDetails.wfId != 53 && woDetails.wfId != 55) {
        const data = {
          wfId: woDetails.wfId,
          workorderId: woDetails.woid,
          serviceId: woDetails.service.id,
          stageId: 10,
          stageIteration: 1,
          filetypeSkip: [],
        };
        result = await _triggerWithoutCamundaWorkflow(data);
      }

      const isAdvert = woDetails.valuesOfArray.some(
        item => item.filetypeid == 6,
      );
      const isCover = woDetails.valuesOfArray.some(
        item => item.filetypeid == 5,
      );

      //Workflow wise parallel stage activity enable config
      if (woDetails.wfId == 48) {
        // Multiple or Sepcific Parallel Activity Enable
        await triggerParallelStagesAndActivitiesWithoutCamunda(
          woDetails.wfId,
          woDetails.woid,
          woDetails.service.id,
          woDetails.stageId, // stage id
          [226, 224], // activity id
          [], // skip file types
        );
      } else if (woDetails.wfId == 55 || woDetails.wfId == 53) {
        if (isAdvert) {
          const data = {
            wfId: woDetails.wfId,
            workorderId: woDetails.woid,
            serviceId: woDetails.service.id,
            stageId: 120,
            stageIteration: 1,
            filetypeSkip: [92, 93, 5],
          };
          result = await _triggerWithoutCamundaWorkflow(data);
        }

        if (isCover) {
          const data = {
            wfId: woDetails.wfId,
            workorderId: woDetails.woid,
            serviceId: woDetails.service.id,
            stageId: 101,
            stageIteration: 1,
            filetypeSkip: [92, 93, 6],
          };
          result = await _triggerWithoutCamundaWorkflow(data);
        }
      }

      // parallel Activity enable
      if (woDetails.wfId == 55) {
        await triggerParallelStagesAndActivitiesWithoutCamunda(
          woDetails.wfId,
          woDetails.woid,
          woDetails.service.id,
          woDetails.stageId, // stage id
          [38], // activity id
          [5, 6], // skip file types
        );
      }

      // else if (woDetails.wfId == 53) {
      //   // parallel stage enable
      //   await triggerParallelStagesAndActivitiesWithoutCamunda(
      //     woDetails.wfId,
      //     woDetails.woid,
      //     woDetails.service.id,
      //     101, // stage id
      //     [201], // activity id
      //     [92, 93, 6], // skip file types
      //   );

      //   // parallel activity enable
      //   await triggerParallelStagesAndActivitiesWithoutCamunda(
      //     woDetails.wfId,
      //     woDetails.woid,
      //     woDetails.service.id,
      //     120, // stage id
      //     [202], // activity id
      //     [92, 93, 5], // skip file types
      //   );
      // }
    }
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const bookComplete = async (
  woid,
  serviceId,
  category,
  totalChapters,
  stageType,
  enableListener,
  processInstanceId,
) => {
  const stage = {
    type: stageType,
  };
  await triggerBookCompleted(
    category,
    processInstanceId,
    stage,
    totalChapters,
    enableListener,
  );
  const sql = `UPDATE wms_workorder_service SET isbookcompleted= true WHERE workorderid=$1 AND serviceid=$2`;
  await query(sql, [woid, serviceId]);
  await updateServiceStatus(woid, serviceId, processInstanceId, true);
};

export const addNewFileType = async (req, fileTypeId) => {
  const {
    woid,
    service,
    stageId,
    receiptdate,
    duedate,
    updatedby,
    fileNameISBN,
    valuesOfArray,
    isElsBooks,
  } = req.body;
  const filteredFiles = valuesOfArray.filter(item => item.filetypeid != 1);
  //const filteredFiles = 5;

  const sql = `SELECT count(*) FROM public.wms_workorder_incoming as wwi
  JOIN public.wms_workorder_incomingfiledetails as wwif ON wwif.woincomingid = wwi.woincomingid
  where wwi.woid = $1 and filetypeid=$2`;
  return new Promise(async (resolve, reject) => {
    try {
      const [{ count }] = await query(sql, [woid, fileTypeId]);
      let incResponse;
      if (count == 0) {
        await transaction(async client => {
          let sqlQuery = `INSERT INTO public.wms_workorder_incoming(woid, serviceid, stageid, receiptdatetime, duedate, updatedby,updatedon)
                    VALUES (${woid}, ${service.id}, ${stageId}, '${receiptdate}', '${duedate}', '${updatedby}',current_timestamp) RETURNING woincomingid`;
          const { rows: resForEntry } = await client.query(sqlQuery);
          sqlQuery = `INSERT INTO public.wms_workorder_incomingfiledetails(
                                    woincomingid, filename, duedate, filetypeid, istriggered, filesequence)
                                    VALUES (${
                                      resForEntry[0].woincomingid
                                    }, '${fileNameISBN}', '${duedate}', ${fileTypeId}, false, ${
            filteredFiles.length + 1
          } ) RETURNING * `;
          incResponse = await client.query(sqlQuery);
        });
      }
      if (isElsBooks) resolve(incResponse.rows[0]);
      else resolve('New File Type has been added successfully');
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

// const deleteChapterEntry = woid => {
//   return new Promise((resolve, reject) => {
//     const sql = `SELECT * FROM wms_workorder_incoming WHERE woid = ${woid}`;
//
//     query(sql)
//       .then(data => {
//         let woincomingid = '';
//         data.map((item, i) => {
//           woincomingid +=
//             data.length - 1 !== i ? `${item.woincomingid},` : item.woincomingid;
//         });
//
//         const sql = `DELETE FROM wms_workorder_incomingfiledetails
//             WHERE woincomingid IN (${woincomingid})`;
//
//         query(sql)
//           .then(data => {
//             const sql = `DELETE FROM wms_workorder_incoming WHERE woid = ${woid}`;
//
//             query(sql)
//               .then(data => {
//                 const sql = resolve(true);
//               })
//               .catch(error => {
//                 reject(false);
//               });
//           })
//           .catch(error => {
//             reject(false);
//           });
//       })
//       .catch(error => {
//         reject(false);
//       });
//   });
// };

export const deleteChapter = (req, res) => {
  const reqData = req.body;
  let sql = `DELETE FROM wms_workorder_incomingfiledetails
    WHERE woincomingfileid = ${reqData.id} returning *`;

  query(sql)
    .then(data => {
      if (reqData.sequence) {
        sql = `update wms_workorder_incomingfiledetails set filesequence=filesequence-1 where woincomingid = ${data[0].woincomingid} and filesequence>${reqData.sequence}`;
        console.log('Reordering the file sequence', sql);
        query(sql).then(() => {
          res.status(200).json({ message: 'Record deleted successfully' });
        });
      } else {
        res.status(200).json({ message: 'Record deleted successfully' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getIncomingData = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.type === 'files') {
    sql = `SELECT woif.woincomingfileid,woif.filetypeid, woif.subfiletypeid, woif.filename,mft.filetype, fd.type as subfiletype, woif.fileuuid, woif.filepath,
    woif.duedate, woif.mspages,woif.wordcount,woif.referencecount, woif.estimatedpages,woif.imagecount,woif.tablecount,
    woif.equationcount,woif.boxcount, woif.woincomingid,woif.istriggered,woif.filesequence, woif.folio_type, woif.article_date, woif.is_correction, woif.issue_type, 
    woif.assign_status, woif.article_status, woif.typesetpage, woif.runonfilesequence, woif.startpage, woif.endpage, woif.is_edit FROM wms_workorder_incoming as wo
    JOIN  wms_workorder_incomingfiledetails as woif ON wo.woincomingid = woif.woincomingid
    left join pp_mst_filetype as mft on mft.filetypeid=woif.filetypeid left join pp_mst_filetype_details as fd on fd.detailid = woif.subfiletypeid
        WHERE wo.woid = ${reqData.workorderId} ORDER BY woif.filesequence ASC`;
  } else if (reqData.type === 'incoming slot') {
    sql = `SELECT * FROM public.wms_workorder_incomingfiledetails as incomingdetails
    left join pp_mst_filetype as filetype on filetype.filetypeid = incomingdetails.filetypeid 
        WHERE woincomingid = ${reqData.woincomingid} ORDER BY woincomingfileid ASC`;
  } else {
    sql = `SELECT  woi.woincomingid,st.stagename,sv.servicename, woi.receiptdatetime, woi.updatedon, woi.duedate, woi.batchno, users.username||' ('|| woi.updatedby||')' as updatedby, (SELECT COUNT (*) FROM wms_workorder_incomingfiledetails 
        JOIN wms_workorder_incoming on wms_workorder_incoming.woincomingid = wms_workorder_incomingfiledetails.woincomingid 
        WHERE wms_workorder_incomingfiledetails.woincomingid = woi.woincomingid) AS noofchapters FROM wms_workorder_incoming as woi
                JOIN  wms_mst_stage as st ON woi.stageid = st.stageid
                JOIN  wms_mst_service as sv ON woi.serviceid = sv.serviceid
                JOIN wms_user as users ON woi.updatedby = users.userid
        WHERE woi.woid = ${reqData.workorderId} ORDER BY woincomingid`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const incomingInfoTriggerWithoutCamunda = async taskDetails => {
  try {
    // Fetch the workflow definition data
    const workFlowDefQuery = `
      SELECT status FROM wms_workorder_stage 
      WHERE workorderid = $1 AND wfstageid = 10 AND status = 'YTS'
      ORDER BY sequence ASC 
      LIMIT 1`;

    const workFlowDefData = await query(workFlowDefQuery, [
      taskDetails.workorderid,
    ]);

    // Ensure there is valid workflow data before proceeding
    if (workFlowDefData.length > 0) {
      const startPayloads = {
        wfId: taskDetails.wfid,
        workorderId: taskDetails.workorderid,
        serviceId: taskDetails.serviceid,
        stageId: 10,
        stageIteration: 1,
        woIncomingFileId: taskDetails.woincomingfileid,
      };

      // Trigger the workflow
      return await _triggerWithoutCamundaWorkflow(startPayloads);
    } else {
      return;
    }
  } catch (error) {
    console.error('Error in incomingInfoTriggerWithoutCamunda:', error);
    throw error;
  }
};

export const updateIncomingData = async (req, res) => {
  try {
    const { taskDetails, updateData } = req.body;

    // Validate input
    if (!Array.isArray(updateData) || updateData.length === 0) {
      return res
        .status(400)
        .json({ message: 'Valid updateData array is required' });
    }

    // Prepare update queries
    const queries = updateData.map(item => {
      const { woincomingfileid, ...fields } = item;

      if (!woincomingfileid) {
        return Promise.reject(
          new Error('woincomingfileid is required for each record'),
        );
      }

      const setClauses = [];
      const values = [];
      let index = 1;

      Object.entries(fields).forEach(([key, value]) => {
        if (value !== undefined) {
          setClauses.push(`${key} = $${index}`);
          values.push(value === '' ? null : Number(value));
          index++;
        }
      });

      if (setClauses.length === 0) {
        return Promise.reject(new Error('No valid fields to update'));
      }

      values.push(woincomingfileid); // Add woincomingfileid for WHERE clause

      const sql = `UPDATE public.wms_workorder_incomingfiledetails 
                   SET ${setClauses.join(', ')}
                   WHERE woincomingfileid = $${index}
                   RETURNING *;`;

      return query(sql, values);
    });

    // Execute all queries concurrently & handle results
    const results = await Promise.allSettled(queries);
    const successfulUpdates = results
      .filter(result => result.status === 'fulfilled')
      .map(result => result.value);

    const failedUpdates = results
      .filter(result => result.status === 'rejected')
      .map(result => result.reason.message);
    let isTriggered = false;
    if (failedUpdates.length > 0) {
      return res.status(400).json({
        message: 'Some updates failed',
        success: successfulUpdates.length > 0 ? successfulUpdates : null,
        failed: failedUpdates,
      });
    } else {
      // Check for image count and trigger
      const imagecount = updateData.filter(record => record.imagecount > 0);
      if (
        imagecount.length > 0 &&
        taskDetails?.workorderid &&
        taskDetails?.wfdefid
      ) {
        const trigger = await incomingInfoTriggerWithoutCamunda(taskDetails);
        if (trigger && trigger?.status === true) {
          isTriggered = true;
        }
      }
    }

    // If all updates succeeded, return a 200 status
    return res.status(200).json({
      message: `Incoming information capture details updated successfully ${
        isTriggered ? ' and Graphics stage triggered successfully' : ''
      }`,
      success: successfulUpdates,
    });
  } catch (error) {
    console.error('Error in updateIncomingData:', error);
    return res
      .status(500)
      .json({ message: 'Internal Server Error', error: error.message });
  }
};

export const exportIncomingData = async (req, res) => {
  try {
    const { id } = req.params;
    const sql = `SELECT infile.filename,ft.filetype,infile.duedate,infile.mspages,infile.estimatedpages,infile.imagecount,infile.tablecount,infile.equationcount	 FROM public.wms_workorder_incomingfiledetails as infile join pp_mst_filetype as ft on ft.filetypeid=infile.filetypeid
        WHERE woincomingid = $1 ORDER BY woincomingfileid ASC`;
    // let sql = `SELECT * FROM public.wms_workorder_incomingfiledetails
    // WHERE woincomingid = $1 ORDER BY woincomingfileid ASC`;
    const wbData = await query(sql, [id]);
    const wbField = {
      'File Name': 'filename',
      'File Type': 'filetype',
      'Chapter / Article': 'filename',
      'MS Pages': 'mspages',
      'Est. Pages': 'estimatedpages',
      'Image Count': 'imagecount',
      Tables: 'tablecount',
      Equations: 'equationcount',
    };
    exportToExcel(
      wbData,
      wbField,
      `incoming-report ${new Date()}`,
      'incoming-report',
      res,
    );
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const remainingChaptersCount = (req, res) => {
  const { workorderId } = req.body;
  const sql = `
    Select count(*), (SELECT totalchaptercount from wms_workorder where workorderid = ${workorderId}) as noofchapters 
    from wms_workorder_incomingfiledetails
      JOIN wms_workorder_incoming on wms_workorder_incoming.woincomingid = wms_workorder_incomingfiledetails.woincomingid
        WHERE wms_workorder_incoming.woid = ${workorderId} AND wms_workorder_incomingfiledetails.filetypeid = 2`;
  query(sql)
    .then(data => {
      const chapterCount =
        data.length > 0 ? data[0].noofchapters - data[0].count : 0;
      res.status(200).json({ data: chapterCount });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// for options in dropdown
export const getTemplateListOptions = (req, res) => {
  const { customerId, softwareId, duId } = req.body;
  const sql = `
  select distinct on (templatename) templateid as value,templatename as label from public.wms_mst_composingsw_templates 
  where duId=${duId} and composingswid=${softwareId} and customerid=${customerId} and isactive = true and isdelete = false
  order by templatename, templateid desc`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// for db entry
export const updateTemplateList = async (req, res) => {
  try {
    await transaction(async client => {
      const { woId, templateId, userId } = req.body;
      let sql = `Update public.wms_workorder_swtemplate SET isactive='false' where workorderid=${woId} RETURNING *;`;
      await client.query(sql, []);
      sql = `INSERT INTO public.wms_workorder_swtemplate(workorderid,templateid,updatedby,updatedon,isactive) VALUES ($1,$2,$3,current_timestamp,true) RETURNING * ;`;
      await client.query(sql, [woId, templateId, userId]);
      res.status(200).json({ message: 'Template Updated' });
    });
  } catch (e) {
    res.status(400).json({ data: 'error', message: e });
  }
};

export const getSelectedTemplate = async (req, res) => {
  const { workorderId } = req.body;
  const sql = `SELECT * FROM public.wms_workorder_swtemplate as wotemplate
        join wms_mst_composingsw_templates as templates on templates.templateid = wotemplate.templateid
        where wotemplate.workorderid = ${workorderId} and wotemplate.isactive = true
        ORDER BY wotemplid ASC `;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// preload the template field
export const templateList = async (req, res) => {
  const { woId } = req.body;
  const sql = `SELECT * FROM public.wms_workorder_swtemplate where workorderid=${woId} and isactive=true`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getArticleIssueList = (req, res) => {
  const reqData = req.body;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` customerid =${reqData.customerid} LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
  }

  sql = `SELECT * FROM public.wms_unassigned_list ${
    condition ? `WHERE${condition}` : `WHERE  customerid =${reqData.customerid}`
  }`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const saveAssignedArticle = (req, res) => {
  console.log('inside insert assigned article', req.body);
  const { workorderId, listOfArray } = req.body;
  for (let i = 0; i < listOfArray.length; i++) {
    const sql = `INSERT INTO public.wms_issue_workorder(
      issueworkorderid, articleworkorderid, woincomingfileid)
       VALUES (${workorderId}, ${listOfArray[i].workorderid}, ${listOfArray[i].woincomingfileid})`;
    query(sql)
      .then(data => {})
      .catch(error => {});
  }
  res.status(200).send({ message: 'Article Assigned Successfully' });
};
export const getAssignedArticleList = (req, res) => {
  const { workorderId } = req.body;
  const sql = `SELECT idetails.filetypeid,filetype.filetype, wo.doinumber,wo.title AS jobname,idetails.filepath,idetails.filename,idetails.fileuuid,
issuewo.assignedissuewoid, issuewo.issueworkorderid,issuewo.articleworkorderid,issuewo.woincomingfileid,wo.workorderid,idetails.mspages,idetails.estimatedpages,idetails.imagecount,idetails.tablecount,idetails.equationcount,idetails.boxcount
  FROM wms_workorder wo
   JOIN wms_workorder_incoming incoming ON incoming.woid = wo.workorderid
    JOIN wms_workorder_incomingfiledetails idetails ON idetails.woincomingid = incoming.woincomingid
    JOIN pp_mst_filetype filetype on filetype.filetypeid=idetails.filetypeid
    LEFT JOIN wms_issue_workorder issuewo ON issuewo.articleworkorderid = wo.workorderid
 WHERE (wo.jobtype::text = '1'::text or wo.jobtype::text = '3'::text) AND issuewo.issueworkorderid=${workorderId}
 ORDER BY wo.workorderid;`;
  query(sql)
    .then(data => {
      res.status(200).send({ data });
    })
    .catch(error => {
      res.status(400).send({ message: 'Error in Fetching Assigned Article' });
    });
};
export const deleteAssignedArticle = (req, res) => {
  const { incomingfileid } = req.body;

  const sql = `DELETE FROM public.wms_issue_workorder WHERE woincomingfileid=${incomingfileid};`;
  query(sql)
    .then(() => {
      res.status(200).send({ message: 'Delete Successfull' });
    })
    .catch(error => {
      res.status(400).send({ message: 'Error in Delete Assigned Article' });
    });
};

export const _copyArticleToIssue = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, serviceId, desFolderPath, customerId, duId, wfId } =
      req.body;
    try {
      const dmsType = await getdmsType(workorderId);
      const fileDetails = await getDespatchFiles(workorderId, serviceId);
      const tempArr = [];
      const isReject = [];
      let resOfOutput = [];
      if (fileDetails && fileDetails.length > 0) {
        for (let j = 0; j < fileDetails.length; j++) {
          const fileDetail = fileDetails[j];
          const name = basename(fileDetail.path);
          let copyData = {};
          switch (dmsType) {
            case 'azure':
              //CUP Issue Workflow
              if (wfId == 53) {
                const placeHolder = {
                  workorderId: workorderId,
                };
                const destPath = await replacePlaceholders(
                  desFolderPath,
                  placeHolder,
                );
                copyData = await fileCopyHelper._blobToLocalCopyFile({
                  srcPath: fileDetail.path,
                  destBasePath: destPath,
                  name,
                });
              } else {
                copyData = await azureHelper._copyFile({
                  srcPath: fileDetail.path,
                  destBasePath: desFolderPath,
                  customerName: 'CUP',
                  name,
                });
              }
              break;
            case 'local':
              copyData = await fileCopyHelper._localcopyFile({
                srcPath: fileDetail.path,
                destBasePath: desFolderPath,
                name,
              });
              break;
            default:
              const destUuid = await _createFolder(desFolderPath);
              copyData = await _copyFile({
                src: fileDetail.uuid,
                dest: destUuid,
                destBasePath: desFolderPath,
                name,
              });
          }
          tempArr.push(copyData);
          if (dmsType == 'local' && !copyData.exist) {
            reject(`src file are not available ${fileDetail.path}`);
          }
          console.log('copied file', copyData);
        }
        if (
          Object.keys(req.body).includes('customerId') &&
          req.body.customerId == 10
        ) {
          resOfOutput = tempArr;
          resolve(resOfOutput);
        } else {
          const resOfOutput2 = tempArr.filter(item =>
            item.path.includes('.pdf'),
          );
          const [firstItem] = resOfOutput2;
          resOfOutput = firstItem;
          resolve(resOfOutput);
        }
      } else {
        isReject.push(workorderId);
      }
      if (isReject.length == 0) {
        resolve(resOfOutput);
      } else {
        reject(`src file are not available for this ${workorderId}`);
      }
      console.log(res, 'resres');

      // res.status(200).send({ data: resOfOutput[0] });
    } catch (error) {
      const mesg = error.message ? error.message : error;
      reject(mesg);
      // res.status(400).send({ message: error.message ? error.message : error });
    }
  });
};

export const _copyNonArticleToIssue = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { desFolderPath, srcFilePath } = req.body;
    try {
      const tempArr = [];
      const srcPath = srcFilePath;
      const srcName = basename(srcFilePath);
      let dmsType = 'azrure';
      if (
        Object.keys(req.body).includes('workorderId') &&
        req.body.workorderId
      ) {
        dmsType = await getdmsType(req.body.workorderId);
      }
      let copyData = {};
      switch (dmsType) {
        case 'azure':
          copyData = await azureHelper._copyFile({
            srcPath,
            destBasePath: desFolderPath,
            name: srcName,
          });
          break;
        case 'local':
          copyData = await fileCopyHelper._localcopyFile({
            srcPath,
            destBasePath: desFolderPath,
            name: srcName,
          });
          break;
        default:
          const destUuid = await _createFolder(desFolderPath);
          copyData = await _copyFile({
            srcPath,
            dest: destUuid,
            destBasePath: desFolderPath,
            name: srcName,
          });
      }

      tempArr.push(copyData);
      console.log('copied file', copyData);
      const resOfOutput = tempArr.filter(item => item.path.includes('.zip'));
      resolve(resOfOutput[0]);
      console.log(res, 'resres');
    } catch (error) {
      const mesg = error.message ? error.message : error;
      reject(mesg);
    }
  });
};

export const copyArticleToIssue = async (req, res) => {
  try {
    const result = await _copyArticleToIssue(req, res);
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, message: e });
  }
};

const getDespatchFiles = async (woID, serviceId) => {
  return new Promise(async (resolve, reject) => {
    const sql = `SELECT wms_workflowactivitytrn_file_map.repofilepath as path, 
  wms_workflowactivitytrn_file_map.repofileuuid as uuid,
  wms_workflowactivitytrn_file_map.woincomingfileid as fileid,
  wms_workorder_incomingfiledetails.filetypeid,
  wms_workorder_incomingfiledetails.filename,
  pp_mst_filetype.filetype
  FROM public.wms_workflowactivitytrn_file_map 
  left join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
  left join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
  where wfeventid = (SELECT eventlog.wfeventid FROM public.wms_workflow_eventlog as eventlog
  where workorderid = $1 and serviceid = $2 ORDER BY wfeventid desc limit 1)`;
    // and  wms_mst_activity.iscompletiontriggeractivity = $3
    try {
      const queryResult = await query(sql, [woID, serviceId]);
      resolve(queryResult);
    } catch (error) {
      reject(error);
    }
  });
};

export const getArticleStatus = async (req, res) => {
  const { workorderId } = req.body;
  const sql = ` select count(1) from wms_issue_workorder where articleworkorderid=$1`;
  try {
    const queryResult = await query(sql, [workorderId]);

    res.status(200).send({ data: queryResult });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getEnableListener = (req, res) => {
  const { workorderId } = req.body;

  const sql = `SELECT * FROM public.wms_workorder_service as service
  left join wms_workflow as workflow on workflow.wfid = service.wfid
  where service.workorderid = ${workorderId}`;
  query(sql)
    .then(response => {
      res.status(200).send({ data: response });
    })
    .catch(error => {
      res.status(400).send({ data: error });
    });
};

export const updateCamundaDetails = async (req, res) => {
  const { camundaVariableObj, woId } = req.body;
  console.log(req.body, 'camundaalal');
  const sql = `UPDATE public.wms_workorder SET camundaform= $1 WHERE workorderid=$2`;
  console.log(sql, 'sqlfoororuoddd');
  await query(sql, [camundaVariableObj, woId])
    .then(() => {
      res.status(200).json({ message: 'camunda details updated successfully' });
    })
    .catch(error => {
      res
        .status(400)
        .send({ data: error.message ? error.message : error, status: false });
    });
};

export const getWOSourceFileDetails = (req, res) => {
  const { duId, woId, serviceId, stageId, stageIterationCount, customerId } =
    req.body;
  const sql = `SELECT *, uploadpath as path FROM public.wms_workorder_sourcefile_details
  where duid=${duId} and workorderid = ${woId} and serviceid=${serviceId} and stageId=${stageId} and stageiterationcount=${stageIterationCount}`;

  query(sql)
    .then(async response => {
      if (duId == '7' && response.length == 0) {
        const uploadPathSql =
          await query(`select trem.uploadpath from public.ftp_audit_wo_creation as trem
                                LEFT JOIN public.log_autowocreate AS la ON la.ftpauditid = trem.auditid
                                LEFT JOIN public.wms_workorder AS wo ON la.trigerarticle = wo.itemcode
                                where wo.workorderid = ${woId}`);
        if (uploadPathSql && uploadPathSql.length > 0) {
          const result =
            await query(`INSERT INTO public.wms_workorder_sourcefile_details(
            duid, customerid, workorderid, serviceid, stageid, stageiterationcount, uploadpath, uuid, createdon)
            VALUES ( ${duId}, ${customerId}, ${woId}, ${serviceId}, ${stageId}, ${stageIterationCount}, '${uploadPathSql[0].uploadpath}', 'azure', current_timestamp) RETURNING wosourcefileid`);
          if (result) {
            response = await query(sql);
            res
              .status(200)
              .send({ data: response.length > 0 ? response[0] : '' });
          }
        }
      } else {
        res.status(200).send({ data: response.length > 0 ? response[0] : '' });
      }
    })
    .catch(error => {
      res.status(400).send({ data: error });
    });
};

function convertDateFormat(inputDate) {
  // Parse the input date using a JavaScript Date object
  const parsedDate = new Date(inputDate);

  if (Number.isNaN(parsedDate)) {
    return 'Invalid Date'; // Handle invalid date input
  }

  // Format the date into 'YYYY-MM-DD HH:mm:ss' using the Date methods
  const year = parsedDate.getFullYear();
  const month = (parsedDate.getMonth() + 1).toString().padStart(2, '0');
  const day = parsedDate.getDate().toString().padStart(2, '0');
  const hours = parsedDate.getHours().toString().padStart(2, '0');
  const minutes = parsedDate.getMinutes().toString().padStart(2, '0');
  const seconds = parsedDate.getSeconds().toString().padStart(2, '0');

  // Create the formatted date string
  const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  return formattedDate;
}

// Auto incoming creation from API trigger based customer
export const _autoIncomingCreationFromAPI = async data => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, files, containerType, jobType, fileType } = data;
    try {
      let sql = `select wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid, wo.isonlineissue
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid 
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId} order by wostageid limit 1`;
      // and updatedon is not null
      const woDetails = await query(sql);
      if (woDetails.length) {
        // files.forEach(async fi => {
        //   sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        //   const fileTypeRes = await query(sql);
        //   fi.filetypeid = fileTypeRes[0].filetypeid;
        //   fi.filetype = fileTypeRes[0].filetype;
        // });
        sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        const fileTypeRes = await query(sql);
        files[0].filetypeid = fileTypeRes[0].filetypeid;
        files[0].filetype = fileTypeRes[0].filetype;

        const workflow = {
          name: woDetails[0].wfname,
          id: woDetails[0].wfname_bpmnid,
          category: woDetails[0].wfcategory,
          enableListener: woDetails[0].wfconfig
            ? !!woDetails[0].wfconfig.enableListener
            : false,
          incoming: {
            fileTypes:
              woDetails[0].wfconfig &&
              woDetails[0].wfconfig.incoming &&
              woDetails[0].wfconfig.incoming.fileTypes
                ? woDetails[0].wfconfig.incoming.fileTypes
                : [],
          },
        };
        const service = {
          id: woDetails[0].serviceid,
          name: woDetails[0].servicename,
        };
        woDetails[0].workflow = workflow;
        woDetails[0].service = service;
        const payload = {
          woid: workorderId,
          service: {
            id: woDetails[0].serviceid,
            name: woDetails[0].servicename,
          },
          stageid: woDetails[0].wfstageid,
          receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
          duedate: new Date(woDetails[0].plannedenddate).toISOString(),
          updatedby: woDetails[0].updatedby,
          batchno: 0,
          valuesOfArray: files,
          totalArticleCount: 1,
          totalNonArticleCount: 0,
          totalCount: 0,
          totalChapterCount: null,
          fileNameISBN: '',
        };
        const response = await _saveChapter({ body: payload }, { res: {} });

        const fileCopyPayload = {
          resData: response.data,
          woDetails: woDetails[0],
          files,
          containerType,
          jobTypeName: jobTypeObj[jobType],
        };
        await fileCopyForAutoIncoming(fileCopyPayload);

        for (let k = 0; k < files.length; k++) {
          const filteredObj = response.data.find(
            sublist => sublist.filename == files[k].filename,
          );
          files[k].woincomingfileid = files[k].woincomingfileid
            ? files[k].woincomingfileid
            : filteredObj.woincomingfileid;
        }
        await wmsWorkflowTrigger({ woDetails: woDetails[0], files });
        resolve({
          message: `Auto incoming success for ${workorderId}`,
          data: {
            stageId: woDetails[0].wfstageid,
            stageName: woDetails[0].stagename,
            iteration: 1,
          },
          status: true,
        });
      } else {
        reject({
          message: `Auto incoming failed due to wokflow details not found for ${workorderId}`,
        });
      }
    } catch (e) {
      reject({
        message: e.message
          ? e.message
          : `Auto incoming failed for ${workorderId}`,
        status: false,
      });
    }
  });
};

export const fileCopyForAutoIncoming = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { resData, woDetails, files, containerType, jobTypeName } = data;
      for (let i = 0; i < resData.length; i++) {
        if (resData[i].filetypeid != 10) {
          resData[i].duedate = new Date(resData[i].duedate).toISOString();
          const filteredObj = files.find(
            list => list.filename == resData[i].filename,
          );
          const fileType = {
            fileTypeName: filteredObj.filetype,
            fileTypeId: filteredObj.filetypeid,
            fileId: resData[i].woincomingfileid,
          };

          const path = await getFolderPathForFileType(woDetails, fileType);
          let fileResponse = {};
          if (jobTypeName == 'Article') {
            // file copy for article
            fileResponse = await fileCopyForArticle({
              containerType,
              woDetails,
              files,
              path,
              fileName: filteredObj.filename + filteredObj.extention,
              woIncomingFileId: resData[i].woincomingfileid,
            });
          } else {
            // copy file for issue
            fileResponse = await fileCopyForIssue({
              containerType,
              woDetails,
              files,
              path,
              fileName: filteredObj.filename,
              woIncomingFileId: resData[i].woincomingfileid,
            });
          }
          resData[i].fileuuid = fileResponse.uuid;
          resData[i].filepath = fileResponse.path;
          const resArray = [];
          resArray.push(resData[i]);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

// file copy for article
export const fileCopyForArticle = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { containerType, woDetails, files, path, fileName } = data;
      let copyData = {};
      const dmsType = await getdmsType(woDetails.workorderid);
      switch (dmsType) {
        case 'azure':
          copyData = await fileCopyHelper.copyExternalBlobToBlob({
            srcPath: files[0].filepath,
            destBasePath: path,
            name: fileName,
            customerName: woDetails.customername,
            customerId: woDetails.customerid,
            containerType,
          });

          break;
        case 'local':
          copyData = await fileCopyHelper.copyExternalBlobToLocal({
            srcPath: files[0].filepath,
            destBasePath: path,
            name: fileName,
            customerName: woDetails.customername,
            customerId: woDetails.customerid,
            containerType,
          });
          break;
        default:
          const destUuid = await _createFolder(path);
          copyData = await _copyFile({
            src: 'openkm',
            dest: destUuid,
            destBasePath: path,
            name: fileName,
          });
      }
      resolve(copyData);
    } catch (e) {
      reject(e);
    }
  });
};
// file copy for issue
export const fileCopyForIssue = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { woDetails, path, fileName, woIncomingFileId } = data;
      const sql = `select wo.workorderid,woservice.serviceid from wms_workorder  as wo
        join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
        where itemcode = '${fileName}' `;
      const srcFileDetails = await query(sql);
      if (srcFileDetails && srcFileDetails.length > 0) {
        const dmsType = await getdmsType(woDetails.workorderid);
        const fileDetails = await getDespatchFilesForIssue(
          srcFileDetails[0].workorderid,
          srcFileDetails[0].serviceid,
        );
        const tempArr = [];
        let resOfOutput = {};
        if (fileDetails && fileDetails.length > 0) {
          for (let j = 0; j < fileDetails.length; j++) {
            const fileDetail = fileDetails[j];
            const name = basename(fileDetail.path);
            let copyData = {};
            switch (dmsType) {
              case 'azure':
                copyData = await azureHelper._copyFile({
                  srcPath: fileDetail.path,
                  destBasePath: path,
                  name,
                });
                tempArr.push(copyData);
                break;
              case 'local':
                copyData = await fileCopyHelper._localcopyFile({
                  srcPath: fileDetail.path,
                  destBasePath: path,
                  name,
                });
                tempArr.push(copyData);
                break;
              default:
                const destUuid = await _createFolder(path);
                copyData = await _copyFile({
                  src: fileDetail.uuid,
                  dest: destUuid,
                  destBasePath: path,
                  name,
                });
                tempArr.push(copyData);
            }
          }
          resOfOutput = tempArr.find(
            item => item.path.includes('.3d') || item.path.includes('.pdf'),
          );
          if (Object.keys(resOfOutput).length > 0) {
            await workorderMappingToIssue({
              sourceWorkorderId: srcFileDetails[0].workorderid,
              issueWorkorderId: woDetails.workorderid,
              woIncomingFileId,
            });
            resolve(resOfOutput);
          } else {
            reject({ message: 'Article file was not found', status: false });
          }
        } else {
          reject({
            status: false,
            message: `src file are not available for this ${woDetails.workorderid}`,
          });
        }
      }
    } catch (error) {
      const mesg = error.message ? error.message : error;
      reject({ status: false, message: mesg });
    }
  });
};

// get dispatch files for issue
const getDespatchFilesForIssue = async (woID, serviceId) => {
  return new Promise(async (resolve, reject) => {
    const sql = `SELECT wms_workflowactivitytrn_file_map.repofilepath as path, 
  wms_workflowactivitytrn_file_map.repofileuuid as uuid,
  wms_workflowactivitytrn_file_map.woincomingfileid as fileid,
  wms_workorder_incomingfiledetails.filetypeid,
  wms_workorder_incomingfiledetails.filename,
  pp_mst_filetype.filetype
  FROM public.wms_workflowactivitytrn_file_map 
  left join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
  left join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
  where wfeventid = (SELECT eventlog.wfeventid FROM public.wms_workflow_eventlog as eventlog
  where workorderid = $1 and serviceid = $2
  ORDER BY wfeventid desc limit 1)`;
    // and  wms_mst_activity.iscompletiontriggeractivity = $3 true
    try {
      const queryResult = await query(sql, [woID, serviceId]);
      resolve(queryResult);
    } catch (error) {
      reject(error);
    }
  });
};
// workorder mapping to issue
const workorderMappingToIssue = async data => {
  return new Promise(async (resolve, reject) => {
    const { sourceWorkorderId, issueWorkorderId, woIncomingFileId } = data;
    const sql = `INSERT INTO public.wms_issue_workorder(issueworkorderid, articleworkorderid, woincomingfileid)
       VALUES (${issueWorkorderId}, ${sourceWorkorderId}, ${woIncomingFileId})`;
    try {
      await query(sql);
      resolve();
    } catch (error) {
      reject(error);
    }
  });
};

// create log for auto incoming
const autoIncomingLog = (data, action) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, payload, status, message, logId } = data;
      let sql = ``;
      if (action == 'Insert') {
        sql = `INSERT INTO log_autoincoming(workorderid, payload, status, createdon, message) VALUES (${workorderId},'${JSON.stringify(
          payload,
        )}','${status}', current_timestamp, '${message}' ) RETURNING autoincominglogid`;
      } else {
        sql = `UPDATE log_autoincoming SET status='${status}', updatedon=current_timestamp, message='${message}'
        WHERE autoincominglogid=${logId} RETURNING autoincominglogid`;
      }
      const response = await query(sql);
      resolve(response.length ? response[0].autoincominglogid : 0);
    } catch (e) {
      reject(e);
    }
  });
};

// -------------------- auto incoming for article flow  ------------------ //
export const _autoIncomingForArticleElsevier = async payload => {
  const { workorderId, files, fileType, jobType, isGraphic } = payload;
  // const { files, containerType, jobType, fileType } = incomingPayload;
  const logPayload = {
    workorderId,
    payload,
    message: 'Received request for auto incoming creation',
    status: 'In Progress',
  };
  return new Promise(async (resolve, reject) => {
    try {
      logPayload.logId = await autoIncomingLog(logPayload, 'Insert');
      let sql = `select wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,stage.stageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid, wo.isonlineissue,
            wo.duid, wo.wfid
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid 
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId} order by wostage.sequence limit 1`;
      // and updatedon is not null
      const woDetails = await query(sql);
      if (woDetails.length) {
        // files.forEach(async fi => {
        //   sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        //   const fileTypeRes = await query(sql);
        //   fi.filetypeid = fileTypeRes[0].filetypeid;
        //   fi.filetype = fileTypeRes[0].filetype;
        // });
        sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        const fileTypeRes = await query(sql);
        files[0].filetypeid = fileTypeRes[0].filetypeid;
        files[0].filetype = fileTypeRes[0].filetype;

        const workflow = {
          name: woDetails[0].wfname,
          id: woDetails[0].wfname_bpmnid,
          category: woDetails[0].wfcategory,
          enableListener: woDetails[0].wfconfig
            ? !!woDetails[0].wfconfig.enableListener
            : false,
          incoming: {
            fileTypes:
              woDetails[0].wfconfig &&
              woDetails[0].wfconfig.incoming &&
              woDetails[0].wfconfig.incoming.fileTypes
                ? woDetails[0].wfconfig.incoming.fileTypes
                : [],
          },
        };
        const serviceInfo = {
          id: woDetails[0].serviceid,
          name: woDetails[0].servicename,
        };
        woDetails[0].workflow = workflow;
        woDetails[0].service = serviceInfo;
        payload = {
          woid: workorderId,
          service: {
            id: woDetails[0].serviceid,
            name: woDetails[0].servicename,
          },
          stageid: woDetails[0].wfstageid,
          receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
          duedate: new Date(woDetails[0].plannedenddate).toISOString(),
          updatedby: woDetails[0].updatedby,
          batchno: 0,
          valuesOfArray: files,
          totalArticleCount: 1,
          totalNonArticleCount: 0,
          totalCount: 0,
          totalChapterCount: null,
          fileNameISBN: '',
        };
        const response = await _saveChapter({ body: payload }, { res: {} });

        const fileCopyPayload = {
          resData: response.data,
          woDetails: woDetails[0],
          files,
          jobTypeName: jobTypeObj[jobType],
        };
        await fileCopyForElsevierJournal(fileCopyPayload);

        for (let k = 0; k < files.length; k++) {
          const filteredObj = response.data.find(
            sublist => sublist.filename == files[k].filename,
          );
          files[k].woincomingfileid = files[k].woincomingfileid
            ? files[k].woincomingfileid
            : filteredObj.woincomingfileid;
        }
        await wmsWorkflowTrigger({
          woDetails: woDetails[0],
          files,
          isGraphic,
        });
        if (isGraphic) {
          const _woDetails = {
            ...woDetails[0],
            stageid: 10,
            stagename: 'Graphics',
          };
          fileCopyPayload.woDetails = _woDetails;
          await fileCopyForElsevierJournal(fileCopyPayload);
          await wmsWorkflowTrigger({
            woDetails: _woDetails,
            files,
            isGraphic,
          });
        }
        logPayload.message = 'Auto incoming creation successfull!';
        logPayload.status = 'Completed';
        await autoIncomingLog(logPayload, 'Update');
        resolve({
          status: true,
          message: 'Auto incoming creation successfull!',
        });
      } else {
        reject({
          message: `Auto incoming failed due to wokflow details not found for ${workorderId}`,
        });
      }
    } catch (e) {
      logPayload.message = 'Failed, Please check the log';
      logPayload.status = 'Failed';
      await autoIncomingLog(logPayload, 'Update');
      reject({ status: false, message: 'Auto incoming creation failed' });
    }
  });
};

export const fileCopyForElsevierJournalFromSignal = async payload => {
  const { resData, woDetails, files } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename,
        );
        const fileType = {
          fileTypeName: filteredFiles[0].filetype,
          fileTypeId: filteredFiles[0].filetypeid,
          fileId: res.woincomingfileid,
        };
        const paths = await getFolderPathForFileType(woDetails, fileType);
        let copyData = {};
        const dmsType = await getdmsType(woDetails.workorderid);
        const name = basename(files[0].filepath);
        const tempArr = [];
        switch (dmsType) {
          case 'azure':
            copyData = await azureHelper._copyFileWithoutFormData({
              srcPath: files[0].filepath,
              destBasePath: paths,
              name,
            });
            break;
          case 'local':
            copyData = await localHelper._localcopyFileWithoutFormData({
              srcPath: files[0].filepath,
              destBasePath: paths,
              name,
            });
            break;
          default:
            const destUuid = await _createFolder(paths);
            copyData = await _copyFile({
              src: 'openkm',
              dest: destUuid,
              destBasePath: paths,
              name,
            });
        }
        tempArr.push(copyData);
        console.log('copied file', copyData);
        console.log('copy file details', copyData);
        res.fileuuid = 'azure';
        res.filepath = tempArr[0].path || '';
        const resArray = [];
        resArray.push(res);
        const data1 = {
          valuesOfArray: resArray,
          action: 'update',
          woid: woDetails.workorderid,
        };
        await _updateChapter({ body: data1 }, { res: {} });
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
export const fileCopyForElsevierJournal = async payload => {
  const { resData, woDetails, files } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        // const filteredFiles = files.filter(
        //   list => list.filename == res.filename,
        // );
        // const fileType = {
        //   fileTypeName: filteredFiles[0].filetype,
        //   fileTypeId: filteredFiles[0].filetypeid,
        //   fileId: res.woincomingfileid,
        // };
        // const paths = await getFolderPathForFileType(woDetails, fileType);
        const dmsType = await getdmsType(woDetails.workorderid);
        payload.dmsType = dmsType;
        const basePathPayload = {
          dmsType,
          du: {
            name: woDetails.duname,
            id: woDetails.assignedduid,
          },
          customer: {
            name: woDetails.customername,
            id: woDetails.customerid,
          },
        };
        const serverbasepath = await getBasePath(basePathPayload);
        const activityInfo = await getFirstActivityInfo({
          wfId: payload.woDetails.wfid,
          stageId: payload.woDetails.stageid,
        });
        const destinationString = `${serverbasepath}${woDetails.itemcode}/Common/${woDetails.stagename}/Source/`;
        const placeHolder = {
          workorderId: woDetails.workorderid,
          JournalAcronym: woDetails.journalacronym,
        };
        const destPath = await replacePlaceholders(
          destinationString,
          placeHolder,
        );
        let copyData = {};
        const tempArr = [];
        switch (dmsType) {
          case 'azure':
            // const name = basename(files[0].filepath);
            // copyData = await azureHelper._copyFile({
            //   srcPath: files[0].filepath,
            //   destBasePath: destPath,
            //   name,
            // });
            // res.fileuuid = 'azure';
            // need to be worked for folder copy
            break;
          case 'local':
            copyData = await localHelper._localFolderCopy({
              srcPath: files[0].filepath,
              destBasePath: destPath,
            });
            res.fileuuid = 'local';
            break;
          default:
            throw new Error(`Unsupported DMS type: ${dmsType}`);
        }
        tempArr.push(copyData);
        res.filepath = tempArr[0].path || '';
        const resArray = [];
        resArray.push(res);
        const data = {
          valuesOfArray: resArray,
          action: 'update',
          woid: woDetails.workorderid,
        };
        await _updateChapter({ body: data }, { res: {} });
      }
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
export const getFirstActivityInfo = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfId, stageId } = payload;
      const sql = `SELECT wms_mst_activity.activityid, wms_mst_activity.activityname FROM wms_workflowdefinition
			JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid 
      WHERE wfid=$1 and stageid=$2 order by sequence limit 1 `;
      const response = await query(sql, [wfId, stageId]);
      if (response.length) {
        resolve(response[0]);
      } else {
        reject('Workflow activity information not found');
      }
    } catch (e) {
      reject(e);
    }
  });
};

// -------------------- auto incoming for issue flow  ------------------ //
export const _autoIncomingForIssue = data => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, files, commonSourcePath } = data;
    const logPayload = {
      workorderId,
      payload: data,
      message: 'Received request for auto incoming creation',
      status: 'In Progress',
    };
    try {
      logPayload.logId = await autoIncomingLog(logPayload, 'Insert');
      const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,jo.otherdetails,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,wo.iscoveravailable as cover,wo.isadvertavailable as advert,jo.runontype, jo.journalacronym as "JournalAcronym"
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId} order by wostage.sequence asc`;
      const woDetails = await query(sql);

      const sql2 = `select * from pp_mst_filetype where (category = 'Article' or category = 'Issue')`;
      const fileTypeDetails = await query(sql2);
      const workflow = {
        name: woDetails[0].wfname,
        id: woDetails[0].wfname_bpmnid,
        category: woDetails[0].wfcategory,
        enableListener: woDetails[0].wfconfig
          ? !!woDetails[0].wfconfig.enableListener
          : false,
        incoming: {
          fileTypes:
            woDetails[0].wfconfig &&
            woDetails[0].wfconfig.incoming &&
            woDetails[0].wfconfig.incoming.fileTypes
              ? woDetails[0].wfconfig.incoming.fileTypes
              : [],
        },
      };
      const service = {
        id: woDetails[0].serviceid,
        name: woDetails[0].servicename,
      };
      woDetails[0].workflow = workflow;
      woDetails[0].service = service;

      if (woDetails[0].wfid != 53 && woDetails[0].wfid != 55) {
        files.map(list => {
          const filetedFileType = fileTypeDetails.filter(
            sublist => sublist.filetype == list.filetype,
          );
          list.filetypeid =
            filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
          list.articletype =
            filetedFileType.length > 0
              ? filetedFileType[0].articletype
              : 'Article';
          return list;
        });
      }
      const payload = {
        woid: workorderId,
        service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
        stageid: woDetails[0].wfstageid,
        receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
        duedate: new Date(woDetails[0].plannedenddate).toISOString(),
        updatedby: woDetails[0].updatedby,
        batchno: 0,
        valuesOfArray: files,
        totalArticleCount: files.length,
        totalNonArticleCount: 0,
        totalCount: 0,
        totalChapterCount: null,
        fileNameISBN: '',
      };
      const response = await _saveChapter({ body: payload }, { res: {} });

      const fileCopyPayload = {
        resData: response.data,
        woDetails: woDetails[0],
        files,
        jobTypeName: 'Issue',
        commonSourcePath,
      };
      // await fileCopyForAutoIncoming(fileCopyPayload);
      await fileCopyForIssueAutoIncomingWithoutCamunda(fileCopyPayload);
      for (let k = 0; k < files.length; k++) {
        const filteredObj = response.data.find(
          sublist => sublist.filename == files[k].filename,
        );
        files[k].woincomingfileid = files[k].woincomingfileid
          ? files[k].woincomingfileid
          : filteredObj.woincomingfileid;
      }

      let filetypeSkip = [];
      if (woDetails[0].wfid == 47) {
        filetypeSkip = [5];
      }

      let trigerstatus;
      if (woDetails[0].wfid != 53 && woDetails[0].wfid != 55) {
        trigerstatus = await wmsWorkflowTrigger({
          woDetails: woDetails[0],
          files,
          filetypeSkip,
        });
      } else {
        trigerstatus = true;
      }

      //Parallel Workflow trigger template use for any other workflow
      // if (woDetails[0].wfid == '') {
      //   For different Stage and different activity
      //   await triggerParallelStagesAndActivitiesWithoutCamunda(
      //     woDetails[0].wfid,
      //     woDetails[0].workorderid,
      //     woDetails[0].serviceid,
      //     101, // stage id
      //     [201], // activity id
      //     [92, 93, 6], // skip file types
      //   );
      //   For same Stage and different activity
      //   await triggerParallelStagesAndActivitiesWithoutCamunda(
      //     woDetails[0].wfid,
      //     woDetails[0].workorderid,
      //     woDetails[0].serviceid,
      //     woDetails[0].wfstageid, // stage id
      //     [202], // activity id
      //     [92, 93, 5], // skip file types
      //   );
      // }

      logPayload.message = 'Auto incoming creation successfull!';
      logPayload.status = 'Completed';
      await autoIncomingLog(logPayload, 'Update');
      resolve({
        status: trigerstatus,
        message: 'Auto incoming creation successfull!',
      });
    } catch (e) {
      logPayload.message = 'Failed, Please check the log';
      logPayload.status = 'Failed';
      await autoIncomingLog(logPayload, 'Update');
      reject({ status: false, message: e.message ? e.message : e });
    }
  });
};

export const fileCopyForIssueAutoIncomingWithoutCamunda = async payload => {
  const { resData, woDetails, files, commonSourcePath } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      let resDmsType = await getdmsType(woDetails.workorderid, true);
      const { dmsType, isLocalIssue = false } = resDmsType;
      let articleDmsType;
      const basePathPayload = {
        dmsType,
        du: {
          name: woDetails.duname,
          id: woDetails.assignedduid,
        },
        customer: {
          name: woDetails.customername,
          id: woDetails.customerid,
        },
        isLocalIssue,
      };
      const serverbasepath = await getBasePath(basePathPayload);
      const activityInfo = await getFirstActivityInfo({
        wfId: woDetails.wfid,
        stageId: woDetails.stageid,
      });
      // Merge Article wise Incoming & File Copy
      for (let i = 0; i < resData.length; i++) {
        const srcInfo = files.find(
          sublist => sublist.filename == resData[i].filename,
        );
        if (!srcInfo.workorderid) {
          continue;
        }
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const sourceActivityInfo = await getSourceActivityInfo(
          srcInfo?.workorderid,
        );
        //CUP Issue Workflow
        if (woDetails.wfid == 53) {
          articleDmsType = await getdmsType(srcInfo.workorderid);
        } else {
          articleDmsType = dmsType;
        }
        console.log(sourceActivityInfo, 'sourceActivityInfo');

        let articleDestinationString;
        if (woDetails.wfid == 47) {
          articleDestinationString = `${serverbasepath}${woDetails.itemcode}/${woDetails.stagename}/${activityInfo.activityname}/${woDetails.itemcode}/${srcInfo.filename}/`;
        } else {
          articleDestinationString = `${serverbasepath}${woDetails.itemcode}/Common/Incoming/${srcInfo.filename}/`;
        }
        const placeHolder = {
          workorderId: woDetails.workorderid,
          JournalAcronym: woDetails.JournalAcronym,
        };
        const articleDestPath = await replacePlaceholders(
          articleDestinationString,
          placeHolder,
        );
        let fileResponse = {};
        fileResponse = await fileCopyForIssueWithoutCamunda({
          woDetails,
          files,
          destPath: articleDestPath,
          fileName: resData[i].filename,
          woIncomingFileId: resData[i].woincomingfileid,
          articleDmsType,
        });
        res.fileuuid = fileResponse.uuid;
        res.filepath = fileResponse.path || '';
        res.article_status = fileResponse.article_status || '';
        res.assign_status = fileResponse.assign_status || '';
        const resArray = [];
        resArray.push(res);
        const data = {
          valuesOfArray: resArray,
          action: 'update',
          woid: woDetails.workorderid,
        };
        await _updateChapter({ body: data }, { res: {} });
      }
      // Merge Article wise Incoming & File Copy

      // Issue Incoming & File Copy
      // upload common files
      let issueDestinationString;
      if (woDetails.wfid == 47) {
        issueDestinationString = `${serverbasepath}${woDetails.itemcode}/${woDetails.stagename}/${activityInfo.activityname}/${woDetails.itemcode}/`;
      } else {
        issueDestinationString = `${serverbasepath}${woDetails.itemcode}/Common/Source/`;
      }
      // const destPath = destinationString.replace(/ /g, '_');
      const placeHolder = {
        workorderId: woDetails.workorderid,
        JournalAcronym: woDetails.JournalAcronym,
      };
      const issueDestPath = await replacePlaceholders(
        issueDestinationString,
        placeHolder,
      );
      switch (dmsType) {
        case 'azure':
          break;
        case 'local':
          await localHelper._localFolderCopy({
            srcPath: commonSourcePath,
            destBasePath: issueDestPath,
          });
          break;
        default:
          throw new Error(`Unsupported DMS type: ${dmsType}`);
      }
      // Issue Incoming & File Copy
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const getSourceActivityInfo = workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select activityalias,wms.stageid, wms.stagename, wwa.activityid, wwa.activityname from wms_workflow_eventlog as wwe
      join wms_workflowdefinition as wwd on wwd.wfdefid = wwe.wfdefid
      join wms_mst_stage as wms on wms.stageid = wwd.stageid
      join wms_mst_activity as wwa on wwa.activityid = wwd.activityid
      where workorderid=${workorderId} and wwd.stageid !=10 order by sequence desc limit 1`;
      const response = await query(sql);
      if (response.length) {
        resolve(response[0]);
      } else {
        reject('Source activity information not found');
      }
    } catch (e) {
      reject(e);
    }
  });
};

// file copy for issue fro without camunda
export const fileCopyForIssueWithoutCamunda = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        woDetails,
        destPath,
        fileName,
        woIncomingFileId,
        articleDmsType,
      } = data;
      const sql = `select wo.workorderid,woservice.serviceid from wms_workorder  as wo
        join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
        where itemcode = '${fileName}' `;
      const srcFileDetails = await query(sql);
      if (srcFileDetails && srcFileDetails.length > 0) {
        const fileDetails = await getDespatchFilesForIssue(
          srcFileDetails[0].workorderid,
          srcFileDetails[0].serviceid,
        );
        const tempArr = [];
        let resOfOutput = {};
        if (fileDetails && fileDetails.length > 0) {
          for (let j = 0; j < fileDetails.length; j++) {
            const fileDetail = fileDetails[j];
            let copyData = {};
            const name = basename(fileDetail.path);
            switch (articleDmsType) {
              case 'azure':
                copyData = await fileCopyHelper._blobToLocalCopyFile({
                  srcPath: fileDetail.path,
                  destBasePath: destPath,
                  name,
                });
                tempArr.push(copyData);
                break;
              case 'local':
                copyData = await localHelper._localcopyFileWithoutFormData({
                  srcPath: fileDetail.path,
                  destBasePath: destPath,
                  name,
                });
                // Commented to change folder copy to file copy
                // copyData = await localHelper._localFolderCopy({
                //   srcPath: fileDetail.path,
                //   destBasePath: destPath,
                // });
                copyData.fileuuid = 'local';
                tempArr.push(copyData);
                break;
              default:
                throw new Error(`Unsupported DMS type: ${dmsType}`);
            }
          }
          resOfOutput = tempArr.find(
            item => item.path.includes('.3d') || item.path.includes('.pdf'),
          );
          if (Object.keys(resOfOutput).length > 0) {
            await workorderMappingToIssue({
              sourceWorkorderId: srcFileDetails[0].workorderid,
              issueWorkorderId: woDetails.workorderid,
              woIncomingFileId,
            });
            let statusInfo = {};
            if (woDetails.wfid == 53 || woDetails.wfid == 55) {
              const sql1 = `with completed_status as (
                                select wms.stagename, wws.typesetpages, wws.status
                                from wms_workorder as wo
                                left join wms_workorder_stage wws on wws.workorderid = wo.workorderid
                                left join wms_mst_stage wms on wms.stageid = wws.wfstageid
                                where wo.itemcode = '${fileName}' and wws.status = 'Completed'
                                order by wws.updatedon desc
                                limit 1
                            ),
                            non_completed_status as (
                                select wms.stagename, wws.typesetpages, wws.status
                                from wms_workorder as wo
                                left join wms_workorder_stage wws on wws.workorderid = wo.workorderid
                                left join wms_mst_stage wms on wms.stageid = wws.wfstageid
                                where wo.itemcode = '${fileName}' and wws.status != 'Completed'
                                order by wws.updatedon desc
                                limit 1
                            )
                            select 
                                coalesce(completed_status.stagename, non_completed_status.stagename) as stagename,
                                coalesce(completed_status.typesetpages, non_completed_status.typesetpages) as typesetpages,
                                coalesce(completed_status.status, non_completed_status.status) as status
                            from completed_status
                            full outer join non_completed_status
                            on true;`;
              const statusDetails = await query(sql1);

              if (statusDetails && statusDetails.length > 0) {
                let readyStage = [];
                if (woDetails.wfid == 53) {
                  readyStage = ['First View', 'Revised First View'];
                } else if (woDetails.wfId == 55) {
                  readyStage = ['PAP'];
                }
                const isReadyToAllocate =
                  readyStage.includes(statusDetails[0].stagename) &&
                  statusDetails[0].status === 'Completed';
                statusInfo = {
                  article_status:
                    statusDetails[0].stagename + ' ' + statusDetails[0].status,
                  assign_status: isReadyToAllocate
                    ? 'Ready to allocate'
                    : 'Get PM Confirmation',
                  typesetpage: !isNaN(parseInt(statusDetails[0].typesetpage))
                    ? statusDetails[0].typesetpage
                    : null,
                };
              } else {
                statusInfo = {
                  article_status: 'Workflow is not Triggered in iWMS',
                  assign_status: 'Get PM Confirmation',
                  typesetpage: null,
                };
              }
            }
            resolve({ ...resOfOutput, ...statusInfo });
          } else {
            reject({ message: 'Article file was not found', status: false });
          }
        } else {
          reject({
            status: false,
            message: `src file are not available for this ${woDetails.workorderid}`,
          });
        }
      }
    } catch (error) {
      const mesg = error.message ? error.message : error;
      reject({ status: false, message: mesg });
    }
  });
};

// Helper function to trigger the parallel activity
// Multiple or Sepcific Parallel Activity Enable
export const triggerParallelStagesAndActivitiesWithoutCamunda = async (
  wfid,
  workorderid,
  serviceid,
  stageid,
  parallelActivityConfig,
  parallelFileTypeSkipForNextActivity,
) => {
  if (parallelActivityConfig && parallelActivityConfig.length) {
    const promises = parallelActivityConfig.map(async parallelactivityid => {
      const startPayload = {
        wfId: wfid,
        workorderId: workorderid,
        serviceId: serviceid,
        stageId: stageid,
        stageIteration: 1,
        actionFlow: 'next',
        activityId: parallelactivityid,
        woIncomingFileId: null,
        filetypeSkip: parallelFileTypeSkipForNextActivity,
      };
      await _triggerWithoutCamundaWorkflow(startPayload);
    });
    await Promise.all(promises);
  }
};
