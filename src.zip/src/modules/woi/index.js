/* eslint-disable no-restricted-globals */
import fetch from 'node-fetch';
import emlformat from 'eml-format';
import moment from 'moment';
import { query } from '../../database/postgres.js';
import { woSchema } from './schema.js';
import { validator } from '../../helper/validator.js';
import { emitAction } from '../activityListener/index.js';
import * as azureHelper from '../utils/azure/index.js';
import { config } from '../../config/restApi.js';
import { getNotificationConfig, getJournalDetail } from '../common/index.js';
import { createJob, checkItracksExits } from '../iTracks/index.js';
import { updateWoStage_autoCall } from './stage.js';
import { getFolderStructure_autowocreate } from '../utils/wmsFolder/index.js';
import { UnreadMailBySubject } from '../mailReader/mailReader.js';
//  import { makeDir } from '../filetransferkit/index.js';
//  import { httpDownload } from './woAutocreation.js';
import { _download } from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';
import { pmRevieewEmailAudit } from '../task/tools/index.js';

export const retriggerAutoWorkorder = async (req, res) => {
  try {
    const { duid } = req.body;
    let output;
    switch (duid) {
      case 7:
        const { subject, tosearch, from } = req.body;
        output = await UnreadMailBySubject(tosearch, from, subject);
        break;
      default:
        throw new Error(`No such duid: ${duid} present.`);
    }
    res
      .status(200)
      .send({ isSuccess: true, message: 'retriggered', data: output });
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error });
  }
};

// this function will get the workorder list
// itrack changes involved
const checkFlowType = async duId => {
  let isnonwms = false;
  const qryflow = `select flowtype from public.trn_customerflowtype_config where duid = $1 limit 1`;
  const getflowtype = await query(qryflow, [duId]);

  if (
    getflowtype &&
    getflowtype.length > 0 &&
    getflowtype[0].flowtype == 'nonwms'
  ) {
    isnonwms = true;
  } else {
    isnonwms = false;
  }
  return isnonwms;
};
// lockjob
export const getWOLists = async (req, res) => {
  const reqData = req.body;

  const qry_wms_workorder_list = ` 
  (SELECT wo.workorderid, wo.itemcode, wo.title, wo.eisbn, wo.printisbn, wo.isbillable,  wo.status,
    wo.camundaform,  wo.wotype,  cus.customername,  cus.customerid,  div.division,  div.divisionid,  sub.subdivision,
    sub.subdivisionid,  cou.countryname,  cou.countrycode,  cou.countryid,  soft.softwarename,  dumap.duid,
    du.duname,  lang.languageid,  lang.languagename,  lang.languagecode,  celevel.celevel,
    ws.jobnormsid AS isjobnorms,wo.flowtype,wo.wfid,
    case when
    coalesce(wst.workorderid,0) = wo.workorderid then true else false end AS isstage
    FROM wms_workorder wo
      JOIN org_mst_subdivision sub ON wo.subdivisionid = sub.subdivisionid
      JOIN org_mst_division div ON wo.divisionid = div.divisionid
      JOIN org_mst_customer cus ON wo.customerid = cus.customerid
      JOIN geo_mst_country cou ON wo.countryid = cou.countryid
      JOIN org_mst_customer_orgmap orgmap ON orgmap.customerid = wo.customerid AND orgmap.divisionid = wo.divisionid AND orgmap.subdivisionid = wo.subdivisionid AND orgmap.countryid = wo.countryid
      JOIN org_mst_customerorg_du_map dumap ON dumap.custorgmapid = orgmap.custorgmapid
      --  JOIN pp_mst_composingsoftware soft ON wo.composingsoftwareid = soft.softwareid
      --  JOIN org_mst_deliveryunit du ON du.duid = dumap.duid
      --  JOIN wms_mst_language lang ON lang.languageid = wo.languageid
      --  JOIN pp_mst_copyeditinglevel celevel ON celevel.celevelid = wo.celevelid
      LEFT JOIN pp_mst_composingsoftware soft ON wo.composingsoftwareid = soft.softwareid
      LEFT JOIN org_mst_deliveryunit du ON du.duid = dumap.duid
      LEFT JOIN wms_mst_language lang ON lang.languageid = wo.languageid
      LEFT JOIN pp_mst_copyeditinglevel celevel ON celevel.celevelid = wo.celevelid
      LEFT JOIN wms_workorder_service ws ON ws.workorderid = wo.workorderid AND ws.jobnormsid IS NOT NULL
      LEFT JOIN (SELECT distinct workorderid from wms_workorder_stage where workorderid IS NOT null ) as
      wst on wst.workorderid = wo.workorderid 
    WHERE wo.isactive <> false AND coalesce(wo.islock,false) = false AND (wo.islock = false or wo.islock is null) and dumap.duid = ${reqData.duId} ) as wms_workorder_list`;

  if (reqData.userid == '') {
    res.status(400).send({ message: 'Userid should not be empty' });
  } else if (reqData.type == '') {
    res.status(400).send({ message: 'Type should not be empty' });
  } else if (reqData.pageNo == '') {
    res.status(400).send({ message: 'Page number should not be empty' });
  } else if (reqData.recordPerPage == '') {
    res.status(400).send({ message: 'Record per page should not be empty' });
  } else {
    let condition = ``;
    if (reqData.type !== 'filter') {
      reqData.searchObj.forEach((item, i) => {
        condition +=
          reqData.searchObj.length - 1 !== i
            ? item.name == 'status'
              ? `wms_workorder_list.${item.name} = '${item.value}' AND `
              : `wms_workorder_list.${item.name} = '${item.value}' OR `
            : `wms_workorder_list.${item.name} = '${item.value}'`;
      });
    }
    // else if (reqData.type === 'filter') {
    //   const { filtervalues, page } = reqData.searchObj;
    //   if (page === 'workorder') {
    //     const output = [];
    //     filtervalues.forEach(function (item) {
    //       const existing = output.filter(function (v) {
    //         return v.name == item.name;
    //       });
    //       if (existing.length) {
    //         const existingIndex = output.indexOf(existing[0]);
    //         output[existingIndex].value = output[existingIndex].value.concat(
    //           item.value,
    //         );
    //       } else {
    //         if (typeof item.value === 'string') item.value = [item.value];
    //         output.push(item);
    //       }
    //     });
    //     output.forEach(data => {
    //       data.setValue = '';
    //       data.value.forEach((data1, i) => {
    //         data.setValue += `'${data1}' ${
    //           data.value.length - 1 !== i ? ',' : ''
    //         }`;
    //       });
    //     });
    //     output.forEach((item, i) => {
    //       condition +=
    //         output.length - 1 !== i
    //           ? `wms_workorder_list.${item.name} IN (${item.setValue}) AND `
    //           : `wms_workorder_list.${item.name} IN (${item.setValue}) `;
    //     });
    //   }
    // }

    let sql = '';
    if (reqData.roleid != 1 && reqData.roleid != 9) {
      sql = `SELECT COUNT(distinct  wms_workorder_stage.workorderid) FROM ${qry_wms_workorder_list}  
            JOIN wms_workorder_stage ON wms_workorder_stage.workorderid = wms_workorder_list.workorderid
            AND wms_workorder_stage.plannedstartdate IS NOT NULL
            WHERE duid = ${reqData.duId}  ${
        condition ? `${'AND '}${condition}` : condition
      }`;
    } else {
      sql = `SELECT COUNT(*) FROM ${qry_wms_workorder_list} WHERE duid = ${
        reqData.duId
      }  ${condition ? `${'AND '}${condition}` : condition}`;
    }

    // itracks changes involved
    if (await checkFlowType(req.body.duId)) {
      const query1 = `(select wo.workorderid, 
      wo.itemcode, 
      wo.title, 
      cust.customername, 
      div.division, 
      sub.subdivision, 
      con.countryname, 
      'action' as action,
      COUNT(*) OVER() AS count
      from public.wms_workorder wo
      left join public.org_mst_customer cust on cust.customerid = wo.customerid and cust.isactive = true
      left join public.org_mst_division div on div.divisionid = wo.divisionid and div.isactive = true
      left join public.org_mst_subdivision sub on sub.subdivisionid = wo.subdivisionid and sub.isactive = true
      left join public.geo_mst_country con on con.countryid = wo.countryid and con.isactive = true
      where wo.flowtype = 'nonwms' and wo.duid = ${reqData.duId}) as wms_workorder_list;`;
      sql = `SELECT COUNT(*) FROM ${query1}`;
    }
    query(sql)
      .then(async totalRecords => {
        if (totalRecords[0].count > 0) {
          const data = await getRecords(reqData, condition, res);
          if (data.length > 0) {
            const total = totalRecords[0].count;
            res.status(200).json({ data, total });
          } else {
            res.status(200).json({ data: [], message: 'No data found' });
          }
        } else {
          res.status(200).json({ data: [], message: 'No data found' });
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};
const getRecords = async (reqData, condition) => {
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  // const offset = reqData.type === 'filter' ? 0 : (pageNo - 1) * recordPerPage;
  // const numOfPages = Math.ceil(total / reqData.recordPerPage);

  const qry_wms_workorder_list = ` 
  (SELECT wo.workorderid, wo.itemcode, wo.title, wo.eisbn, wo.printisbn, wo.isbillable,  wo.status,
    wo.camundaform,  wo.wotype,  cus.customername,  cus.customerid,  div.division,  div.divisionid,  sub.subdivision,
    sub.subdivisionid,  cou.countryname,  cou.countrycode,  cou.countryid,  soft.softwarename,  dumap.duid,
    du.duname,  lang.languageid,  lang.languagename,  lang.languagecode,  celevel.celevel,
    ws.jobnormsid AS isjobnorms,wo.flowtype,wo.wfid,
    case when
    coalesce(wst.workorderid,0) = wo.workorderid then true else false end AS isstage, jour.journalacronym,
    wo.otherfield->> 'pii' as pii ,
    INITCAP(COALESCE(wo.otherfield ->> 'is_re_routed', 'No')) AS isrerouted
    FROM wms_workorder wo
      JOIN org_mst_subdivision sub ON wo.subdivisionid = sub.subdivisionid
      JOIN org_mst_division div ON wo.divisionid = div.divisionid
      JOIN org_mst_customer cus ON wo.customerid = cus.customerid
      JOIN geo_mst_country cou ON wo.countryid = cou.countryid
      JOIN org_mst_customer_orgmap orgmap ON orgmap.customerid = wo.customerid AND orgmap.divisionid = wo.divisionid AND orgmap.subdivisionid = wo.subdivisionid AND orgmap.countryid = wo.countryid
      JOIN org_mst_customerorg_du_map dumap ON dumap.custorgmapid = orgmap.custorgmapid
      --  JOIN pp_mst_composingsoftware soft ON wo.composingsoftwareid = soft.softwareid
      --  JOIN org_mst_deliveryunit du ON du.duid = dumap.duid
      --  JOIN wms_mst_language lang ON lang.languageid = wo.languageid
      --  JOIN pp_mst_copyeditinglevel celevel ON celevel.celevelid = wo.celevelid
      LEFT JOIN pp_mst_composingsoftware soft ON wo.composingsoftwareid = soft.softwareid
      LEFT JOIN org_mst_deliveryunit du ON du.duid = dumap.duid
      LEFT JOIN wms_mst_language lang ON lang.languageid = wo.languageid
      LEFT JOIN pp_mst_copyeditinglevel celevel ON celevel.celevelid = wo.celevelid
      LEFT JOIN wms_workorder_service ws ON ws.workorderid = wo.workorderid AND ws.jobnormsid IS NOT NULL
      LEFT JOIN (SELECT distinct workorderid from wms_workorder_stage where workorderid IS NOT null ) as
      wst on wst.workorderid = wo.workorderid       
      LEFT JOIN pp_mst_journal jour ON jour.journalid = wo.journalid

    WHERE wo.isactive <> false AND (wo.islock = false or wo.islock is null) and dumap.duid = ${reqData.duId} ) as wms_workorder_list`;

  return new Promise(async resolve => {
    let sql = '';
    // if(reqData.skillid.includes('5')){
    if (reqData.roleid != 1 && reqData.roleid != 9) {
      sql = `SELECT DISTINCT ON (wms_workorder_list.workorderid) * FROM ${qry_wms_workorder_list}  
        JOIN wms_workorder_stage ON wms_workorder_stage.workorderid = wms_workorder_list.workorderid
        AND wms_workorder_stage.plannedstartdate IS NOT NULL
        WHERE duid = ${reqData.duId} ${
        condition ? `${'AND '}${condition}` : condition
      }  ORDER BY wms_workorder_list.workorderid DESC  `;
    } else if (reqData.tab == 0) {
      sql = `select * from ${qry_wms_workorder_list} WHERE duid = ${
        reqData.duId
      } ${
        condition ? `${'AND '}${condition}` : condition
      }  ORDER BY wms_workorder_list.workorderid DESC`;
    } else if (reqData.tab == 1) {
      sql = `select serialno,workorderid,itemcode,title,customername,division,subdivision,countryname
      enddatetime
      ,duid,
      customerid,divisionid,subdivisionid,wfid
      from public.getcompletedjobs('{"duId":${reqData.duId} }')
      `;
    } else {
      sql = `select * from ${qry_wms_workorder_list} WHERE duid = ${
        reqData.duId
      } ${
        condition ? `${'AND '}${condition}` : condition
      } ORDER BY wms_workorder_list.workorderid DESC `;
    }
    // lockjob
    // itracks changes involved
    if (await checkFlowType(reqData.duId)) {
      sql = `select  wo.workorderid, wo.itemcode, wo.title,cust.customername,
        div.division,sub.subdivision,con.countryname,'action' as action,wo.flowtype,wo.wfid,wo.duid,
        wo.customerid,wo.divisionid,wo.subdivisionid,wo.countryid
        from public.wms_workorder wo
        left join public.org_mst_customer cust on cust.customerid = wo.customerid and cust.isactive = true
        left join public.org_mst_division div on div.divisionid = wo.divisionid and div.isactive = true
        left join public.org_mst_subdivision sub on sub.subdivisionid = wo.subdivisionid and sub.isactive = true
        left join public.geo_mst_country con on con.countryid = wo.countryid and con.isactive = true
        where wo.flowtype='nonwms' and coalesce(wo.islock,false) = false and wo.duid=${reqData.duId} order by wo.workorderid desc;`;
    }
    const data = await query(sql);
    resolve(data);

    //  query(sql)
    //   .then(data => {
    //     // res.status(200).json({ data });
    //     resolve(data)
    //   })
    //   .catch(error => {
    //
    //     reject(error)
    //   //  res.status(400).send({ message: error });
    //   });
  });
};

export const getFilteredList = (req, res) => {
  const { columnName, text, filtervalues, tab, duId } = req.body;
  console.log(req.body, 'SEARCH1');
  let condition = '';
  const output = [];
  filtervalues.forEach(function (item) {
    const existing = output.filter(function (v) {
      return v.name == item.name;
    });
    if (existing.length) {
      const existingIndex = output.indexOf(existing[0]);
      output[existingIndex].value = output[existingIndex].value.concat(
        item.value,
      );
    } else {
      if (typeof item.value === 'string') item.value = [item.value];
      output.push(item);
    }
  });
  output.forEach(data => {
    data.setValue = '';
    data.value.forEach((data1, i) => {
      data.setValue += `'${data1}' ${data.value.length - 1 !== i ? ',' : ''}`;
    });
  });
  output.forEach(item => {
    condition +=
      tab === 2
        ? `wms_workorder_duelist.${item.name} IN (${item.setValue}) AND `
        : `wms_workorder_list.${item.name} IN (${item.setValue}) AND `;
    // condition += output.length - 1 !== i ?
    //     tab === 2 ? `wms_workorder_duelist.${item.name} IN (${item.setValue}) AND ` : `wms_workorder_list.${item.name} IN (${item.setValue}) AND `
    //     : tab === 2 ? `wms_workorder_duelist.${item.name} IN (${item.setValue}) AND ` : `wms_workorder_list.${item.name} IN (${item.setValue}) AND `;
  });

  condition += `LOWER(${columnName} :: text) like '%${text.toLowerCase()}%'`;
  let sql = '';
  if (tab === 2) {
    sql = `SELECT DISTINCT ${columnName} FROM public.wms_workorder_duelist WHERE duid = ${duId} ${
      condition ? `${'AND '}${condition}` : condition
    }`;
  } else {
    sql = `SELECT DISTINCT ${columnName} FROM public.wms_workorder_list WHERE duid = ${duId} ${
      condition ? `${'AND '}${condition}` : condition
    }`;
  }
  if (filtervalues) {
    sql += `and status='${filtervalues[0].value}' ORDER BY ${columnName} ASC`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWOListById = (req, res) => {
  const { workorderId } = req.body;
  if (workorderId) {
    const sql = `SELECT * FROM wms_workorder_list WHERE workorderid = ${workorderId}`;

    query(sql)
      .then(response => {
        res.status(200).send({ data: response.length ? response[0] : [] });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'Workorder id is missing' });
  }
};

export const getFilteredWorkorder = (req, res) => {
  const { jobId, journalInfo } = req.body;
  let condition = ``;
  if (journalInfo && req.body.journalInfo.id && req.body.journalInfo.name) {
    condition += ` AND journalid = ${journalInfo.id}`;
  }
  const sql = `SELECT workorderid as id, itemcode as name, wfid FROM wms_workorder_list WHERE LOWER(itemcode) LIKE '%${jobId.toLowerCase()}%' ${condition}`;

  query(sql)
    .then(response => {
      res.status(200).send({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFilteredJournal = (req, res) => {
  const { journalId } = req.body;
  const sql = `SELECT journalid as id, journalacronym as name FROM pp_mst_journal WHERE LOWER(journalacronym) LIKE '%${journalId.toLowerCase()}%'`;

  query(sql)
    .then(response => {
      res.status(200).send({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// suradha

export const getStageListById = (req, res) => {
  const reqData = req.body;
  const sql = `SELECT wfstageid,
    (SELECT stagename from wms_mst_stage WHERE wms_mst_stage.stageid = wfstageid) as stagename
    FROM public.wms_workorder_stage WHERE workorderid = ${reqData.workorderId}`;

  query(sql)
    .then(responseStage => {
      const sql1 = `SELECT DISTINCT wms_service_stage_map.serviceid,
        (SELECT servicename from wms_mst_service WHERE wms_mst_service.serviceid = wms_workorder_stage.serviceid)
        FROM wms_workorder_stage
        JOIN wms_service_stage_map ON wms_service_stage_map.serviceid = wms_workorder_stage.serviceid
        WHERE wms_workorder_stage.workorderid = ${reqData.workorderId}`;
      query(sql1)
        .then(responseServices => {
          res.status(200).send({
            data: { stages: responseStage, services: responseServices },
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get the option list
export const getOptionLists = (req, res) => {
  const getData = req.body;
  if (getData.type !== 'basedOnJournal') {
    let sql = ``;
    if (getData.type === 'customer') {
      // SELECT customerid as value, customername as label FROM public.org_mst_customer
      sql = `
            SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label FROM org_mst_customerorg_du_map 
            JOIN org_mst_customer_orgmap ON org_mst_customer_orgmap.custorgmapid = org_mst_customerorg_du_map.custorgmapid
            JOIN org_mst_customer ON org_mst_customer.customerid = org_mst_customer_orgmap.customerid
            WHERE duid = ${getData.duId} AND org_mst_customer.isactive = true `;
    } else if (getData.type === 'division') {
      sql = `SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label FROM org_mst_customer_orgmap  
            JOIN org_mst_division ON org_mst_customer_orgmap.divisionid = org_mst_division.divisionid
            WHERE org_mst_customer_orgmap.customerid = ${getData.customerId} AND org_mst_division.isactive = true `;
    } else if (getData.type === 'subDivision') {
      sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            WHERE org_mst_customer_orgmap.customerid = ${getData.customerId}  AND  org_mst_customer_orgmap.divisionid = ${getData.divisionId} AND org_mst_subdivision.isactive = true`;
    } else if (getData.type === 'country') {
      sql = `SELECT DISTINCT ON (geo_mst_country.countryid)geo_mst_country.countryid as value, geo_mst_country.countryname as label FROM org_mst_customer_orgmap
            JOIN geo_mst_country ON org_mst_customer_orgmap.countryid = geo_mst_country.countryid
            WHERE org_mst_customer_orgmap.customerid = ${getData.customerId}  AND org_mst_customer_orgmap.divisionid= ${getData.divisionId}  AND org_mst_customer_orgmap.subdivisionid= ${getData.subDivisionId}
            AND geo_mst_country.isactive = true`;
    } else if (getData.type === 'journalAcronym') {
      sql = `SELECT tbl2.journalid as value , tbl2.journalacronym as label , tbl2.journalname FROM org_mst_customer_orgmap as tbl1
            JOIN pp_mst_journal as tbl2 ON tbl2.custorgmapid = tbl1.custorgmapid
            WHERE
            tbl1.customerid=${getData.customerId} AND tbl1.divisionid=${getData.divisionId} AND tbl1.subdivisionid=${getData.subDivisionId} AND tbl1.countryid=${getData.countryId} AND tbl2.isactive = 1 `;
    } else if (getData.type === 'allContactList') {
      sql = `SELECT tbl2.custorgconmapid, tbl2.contactname, tbl2.contacttype, tbl2.isprimary, tbl2.contactroleid FROM org_mst_customer_orgmap as tbl1
                JOIN org_mst_customerorg_contact as tbl2 ON tbl2.custorgmapid = tbl1.custorgmapid
                WHERE
                tbl1.customerid=${getData.customerId} AND tbl1.divisionid=${getData.divisionId} AND tbl1.subdivisionid=${getData.subDivisionId} AND tbl1.countryid=${getData.countryId}`;
    } else if (getData.type === 'duServices') {
      sql = `SELECT ms.serviceid as value, ms.servicename as label, csm.custorgmapid FROM public.org_mst_customer_orgmap as com
                JOIN public.org_mst_customerorg_service_map as csm ON csm.custorgmapid = com.custorgmapid
                JOIN public.wms_mst_service as ms ON ms.serviceid = csm.serviceid
                WHERE  com.customerid=${getData.customerId} AND com.divisionid=${getData.divisionId} 
                AND com.subdivisionid=${getData.subDivisionId} AND com.countryid=${getData.countryId}`;
    } else if (getData.type === 'services') {
      sql = `SELECT serviceid as value, servicename as label FROM public.wms_mst_service`;
    } else if (getData.type === 'workflowTemplate') {
      sql = `SELECT wfid as value, wfname as label FROM public.wms_workflow WHERE isactive = true AND wfwisetype IN (${getData.wfType}) AND customerid = ${getData.customerId}`;
    } else if (getData.type === 'du') {
      // sql = `SELECT duid as value, duname as label FROM public.org_mst_deliveryunit WHERE isactive = true`;
      sql = `select delivery.duid as value, delivery.duname as label from org_mst_customer_orgmap cust  join org_mst_customerorg_du_map cust_du on cust.custorgmapid=cust_du.custorgmapid
            join org_mst_deliveryunit delivery on delivery.duid=cust_du.duid
            where delivery.isactive = true and cust.customerid=${getData.customerId} and cust.divisionid=${getData.divisionId} and subdivisionid=${getData.subDivisionId}
            and countryid=${getData.countryId}`;
    } else if (getData.type === 'softwares') {
      sql = `SELECT softwareid as value, softwarename as label FROM public.pp_mst_composingsoftware WHERE isactive = true`;
    } else if (getData.type === 'colours') {
      sql = `SELECT colorid as value, color as label FROM public.pp_mst_color`;
    } else if (getData.type === 'languages') {
      sql = `SELECT languageid as value, languagename as label FROM public.wms_mst_language`;
    } else if (getData.type === 'inputFileTypes') {
      sql = `SELECT filetypeid as value, filetypename as label FROM public.pp_mst_inputfiletype`;
    } else if (getData.type === 'CELevel') {
      sql = `SELECT celevelid as value, celevel as label FROM public.pp_mst_copyeditinglevel`;
    } else if (getData.type === 'indexType') {
      sql = `SELECT indextypeid as value, indextype as label FROM public.pp_mst_indextype`;
    } else if (getData.type === 'category') {
      sql = `SELECT categoryid as value, category as label FROM public.pp_mst_wocategory`;
    } else if (getData.type === 'logoid') {
      sql = `select trndrop.id as value, trndrop.value as label from wms_mst_dropdown as drops
                   join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
                    where drops.fieldname like '%${getData.type}%'`;
    } else if (getData.type === 'dmsid') {
      sql = `SELECT dmsid as value, dmstype as label FROM dms_master WHERE isactive = true`;
    } else if (getData.type === 'servicesWithId') {
      sql = `SELECT serviceid as value, servicename as label FROM public.wms_mst_service WHERE serviceid IN (${getData.serviceId}) `;
    } else if (getData.type === 'workorderServiceList') {
      sql = `SELECT wms_mst_service.serviceid as value,wms_workorder_service.assignedduid as duid,wms_workorder_service.isbookcompleted, org_mst_deliveryunit.duname, wms_mst_service.servicename as label,
            wms_workflow.wfname, wms_workflow.wfcategory, wms_workflow.wfname_bpmnid, wms_workflow.config as wfconfig FROM wms_workorder_service
            JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workorder_service.serviceid
            JOIN  wms_workflow ON wms_workflow.wfid = wms_workorder_service.wfid
            JOIN org_mst_deliveryunit on org_mst_deliveryunit.duid = wms_workorder_service.assignedduid
            WHERE wms_workorder_service.workorderid IN (${getData.workorderId}) ORDER BY sequence ASC `;
    } else if (getData.type === 'workorderStageList') {
      // sql = `SELECT wms_mst_stage.stageid as value, wms_mst_stage.stagename as label,
      // wms_workorder_stage.ordermaildate,
      // wms_workorder_stage.plannedenddate, wms_workorder_stage.wostageid,
      // wms_workorder_stage.status
      // FROM wms_workorder_stage
      // JOIN wms_mst_stage ON wms_workorder_stage.wfstageid = wms_mst_stage.stageid
      // WHERE workorderid = ${getData.workorderId} ORDER BY wms_workorder_stage.sequence, wms_workorder_stage.stageiterationcount ASC  `;
      //            sql= `SELECT wms_mst_stage.stageid as value, wms_mst_stage.stagename as label,
      // wms_workorder_stage.ordermaildate,
      // wms_workorder_stage.plannedenddate, wms_workorder_stage.wostageid,
      // wms_workorder_stage.status,
      // case when wms_mst_stage.stagename='Typescript' and wms_workorder_stage.status ='Completed' then true else false end as checkstatus
      // FROM wms_workorder_stage
      // JOIN wms_mst_stage ON wms_workorder_stage.wfstageid = wms_mst_stage.stageid
      // WHERE workorderid =${getData.workorderId} ORDER BY wms_workorder_stage.sequence, wms_workorder_stage.stageiterationcount ASC`;

      sql = `SELECT wms_mst_stage.stageid as value, 
wms_mst_stage.stagename as label,
wms_workorder_stage.ordermaildatetime,
wms_workorder_stage.plannedenddate, wms_workorder_stage.wostageid,
wms_workorder_stage.status,
case when wms_mst_stage.stagename='Typescript' and wms_workorder_stage.status ='Completed' then true else false end as checkstatus,
 case when coalesce( max(event1.wfeventid) ,0 )  = 0 then false else true end as savestatus
FROM wms_workorder_stage 
JOIN wms_mst_stage ON wms_workorder_stage.wfstageid = wms_mst_stage.stageid
left JOIN wms_workflow_eventlog as event1 ON wms_workorder_stage.workorderid = event1.workorderid 
and event1.activitystatus in ('Work in progress','Reset', 'Completed')
WHERE wms_workorder_stage.workorderid =${getData.workorderId}  
group by 
wms_mst_stage.stageid  , 
wms_mst_stage.stagename ,
wms_workorder_stage.ordermaildatetime,
wms_workorder_stage.plannedenddate, 
wms_workorder_stage.wostageid,
wms_workorder_stage.status
ORDER BY wms_workorder_stage.sequence, wms_workorder_stage.stageiterationcount ASC`;
    } else if (getData.type === 'deliveryMode') {
      sql = `SELECT deliverymodeid as value, deliverymode as label FROM public.pp_mst_deliverymode`;
    } else if (getData.type === 'userList') {
      let condition = '';
      if (getData.woType === 'journal') {
        condition = ``;
      } else if (getData.woType === 'book') {
        condition = `'PED','AUTHOR'`;
      }
      sql = `SELECT wms_role.roleid as value, wms_role.rolename as label,wms_role.roleacronym  FROM wms_role ${
        condition != '' ? `WHERE wms_role.roleacronym IN (${condition})` : ''
      }`;
    } else if (getData.type === 'stage') {
      sql = `SELECT stageid as value, stagename as label FROM wms_mst_stage ORDER BY stageid ASC  `;
      //         sql = `SELECT DISTINCT ON(stage.stageid) stage.stageid as value, stage.stagename as label FROM public.wms_workflowdefinition as def
      // left join wms_mst_stage as stage on stage.stageid = def.stageid
      // where def.wfid = ${getData.workflowId}
      // ORDER BY stage.stageid ASC  `
    } else if (getData.type === 'iWorkflow') {
      sql = `SELECT iworkflow as value, iworkflowalias as label FROM public.itracks_mst_workflow`;
    } else if (getData.type === 'wo_inprogress_stages') {
      // New update added for stage show against completion trigger(changed function)

      sql = `select * from getresetstage(${getData.workorderId});`;

      // 2nd change
      // sql = `SELECT wst.wfstageid as value, st.stagename as label, wst.stageiterationcount
      // FROM public.wms_workorder_stage as wst
      // JOIN wms_mst_stage as st ON st.stageid= wst.wfstageid
      // WHERE wst.workorderid=${getData.workorderId}
      // AND wst.serviceid=${getData.serviceId} AND wst.status='In Process'
      // UNION
      // SELECT wst.wfstageid as value, st.stagename as label, wst.stageiterationcount
      // FROM public.wms_workorder_stage as wst
      // JOIN wms_mst_stage as st ON st.stageid= wst.wfstageid
      // WHERE wst.workorderid=${getData.workorderId}
      // and st.stagename = 'Graphics' and
      // true = (select case when count(0) = 0 then false else true end as col  from wms_workorder_incoming  a
      // join public.wms_workorder_incomingfiledetails b on a.woincomingid = b.woincomingid
      // where a.woid =${getData.workorderId} and b.imagecount >= 1)`

      // 1st change
      // sql = `SELECT wfstageid as value, stagename as label, stageiterationcount FROM public.wms_workorder_stage
      //     JOIN wms_mst_stage ON wms_mst_stage.stageid= wms_workorder_stage.wfstageid
      //     WHERE wms_workorder_stage.workorderid=${getData.workorderId}
      //     AND wms_workorder_stage.serviceid=${getData.serviceId} AND wms_workorder_stage.status='In Process'
      //     ORDER BY stageiterationcount DESC LIMIT 1`;
    } else if (getData.type === 'wo_stage_completed_activities') {
      // sql = `select distinct on (activityid) activityiterationcount,actualactivitycount, activityid as value, activityalias as label, activitystatus, sequence from wms_tasklist where workorderid=${getData.workorderId} and serviceid=${getData.serviceId} and stageid=${getData.stageId}
      //       and activitystatus in ('Completed') and activitytype != 'External Task' and activityid !=21 and POSITION('_F' IN activityname) = 0 `;
      sql = `select distinct on (activityid) activityiterationcount,actualactivitycount, activityid as value, activityalias as label, 
      activitystatus, sequence , stageiterationcount
      from wms_tasklist 
      where workorderid=${getData.workorderId} and serviceid=${getData.serviceId} and stageid=${getData.stageId}
      and activitystatus in ('Completed') and activitytype != 'External Task' and activityid !=21   
      and stageiterationcount = ${getData.stageIterationCount} and
       POSITION('_F' IN activityname) = 0 `;
    } else if (getData.type === 'workflow') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBworkflow'`;
    } else if (getData.type === 'projectmanagement') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBProjectManagement'`;
    } else if (getData.type === 'bookproofing') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBBookProofing'`;
    } else if (getData.type === 'ordered') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBOrdererd'`;
    } else if (getData.type === 'cover') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBCover'`;
    } else if (getData.type === 'index') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBIndex'`;
    } else if (getData.type === 'bookhistory') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBBookHistory'`;
    } else if (getData.type === 'vertical') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBVertical'`;
    } else if (getData.type === 'compcopy') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'compcopy'`;
    } else if (getData.type === 'inputtype') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBInputtype'`;
    } else if (getData.type === 'indextype') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBIndextype'`;
    } else if (getData.type === 'paginationapplication') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBPaginationapplication'`;
    } else if (getData.type === 'fasttrack') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBFasttrack'`;
    } else if (getData.type === 'revisedproof') {
      sql = `select trndrop.value as value, 
                    trndrop.value as label,
                    trndrop.keyid as id
             from wms_mst_dropdown as drops
             join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
             where drops.isactive = true and  trndrop.isactive = true and drops.fieldname = 'SBRevisedproof'`;
    } else if (getData.type === 'onlineprofile') {
      sql = `SELECT 
                    ppd.id, 
                    ppd.profilevalue AS label, 
                    ppd.profilevalue as value
              FROM MST_PITSTOPPROFILE AS pp
              JOIN trn_pitstopprofiledetail AS ppd ON ppd.profileid = pp.profileid
              WHERE pp.isactive = true AND ppd.isactive = true
              AND pp.profileid = 4 and duid = ${getData.duId}`;
    } else if (getData.type === 'printprofile') {
      sql = `SELECT 
                    ppd.id, 
                    ppd.profilevalue AS label, 
                    ppd.profilevalue as value
              FROM MST_PITSTOPPROFILE AS pp
              JOIN trn_pitstopprofiledetail AS ppd ON ppd.profileid = pp.profileid
              WHERE pp.isactive = true AND ppd.isactive = true
              AND pp.profileid = 5 and duid = ${getData.duId}`;
    } else if (getData.type === 'complexity') {
      sql = `SELECT complexityid AS id, complexity AS label, complexityid as value FROM public.wms_mst_complexity 
              WHERE isactive = 1`;
    } else if (getData.type === 'workFlow') {
      sql = `SELECT wf.wfid AS value,wf.wfname AS label FROM wms_config_customertabinfomapping map
          JOIN public.wms_workflow wf ON wf.wfid = ANY(ARRAY[map.workflowid]) AND wf.isactive = true
          WHERE map.duid = ${getData.duId} AND map.customerid = ${getData.customerId} 
          AND ${getData.divisionId} = ANY(map.divisionid) AND map.verticalid = ${getData.subDivisionId} 
          AND ${getData.countryId} = ANY(map.countryid) AND map.isactive = true`;
    } else if (getData.type === 'duServicesNonWMS') {
      sql = `SELECT serviceid as value, servicename as label FROM public.wms_mst_service WHERE isactive= true
             ORDER BY servicename`;
    } else if (getData.type === 'subTypeList') {
      sql = `select detailid as value, type as label, code from public.pp_mst_filetype_details where isactive= true
      `;
    } else if (getData.type === 'currency') {
      sql = `SELECT currencyid AS value, (currencytext || ' (' || currencycode || ')') AS label FROM public.mst_currencymst WHERE isactive = true;`;
    } else if (getData.type === 'role') {
      sql = `SELECT roleid AS value, (rolename || ' (' || roleacronym || ')') AS label FROM public.wms_role WHERE roleacronym IN ('PM','PMTL') AND isactive = true;`;
    } else if (getData.type === 'woUser') {
      sql = `SELECT DISTINCT u.userid AS value, u.username || ' (' || u.userid || ')' AS label from public.wms_user u 
          JOIN public.wms_role as r ON r.roleid = ${getData.role}
          JOIN public.wms_userrole as ur ON ur.userid = u.userid AND ur.roleid = r.roleid
          WHERE (u.duid = ${getData.duId} OR  ${getData.duId} = ANY(u.mappedduid)) AND u.useractive = true ORDER BY label;`;
    }

    console.log(sql, 'sql for optionsj');
    query(sql)
      .then(data => {
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    let sql = `SELECT contacts.custorgconmapid, contacts.contactname, contacts.contacttype, contacts.isprimary, contacts.contactroleid FROM org_mst_customer_orgmap as orgmap
        JOIN org_mst_customerorg_contact as contacts ON contacts.custorgmapid = orgmap.custorgmapid
        WHERE orgmap.customerid=${getData.customerId} AND orgmap.divisionid=${getData.divisionId} AND orgmap.subdivisionid=${getData.subDivisionId} AND orgmap.countryid=${getData.countryId}`;
    console.log(sql, 'sqlsql');
    query(sql)
      .then(resForContacts => {
        sql = `SELECT 
            (SELECT username FROM wms_user WHERE userid = journal.pmid ) as pmname, 
            (SELECT username FROM wms_user WHERE userid = journal.supplierpmid ) as spmname,*
            FROM pp_mst_journal as journal
            WHERE journal.journalid = ${getData.journalId}`;
        query(sql)
          .then(resForJournalData => {
            res
              .status(200)
              .json({ data: resForContacts, journalData: resForJournalData });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};

export const getExternalCustomerContacts = (req, res) => {
  const { journalId } = req.body;
  const sql = `SELECT name, email, phone1, designation as role FROM pp_mst_journal_contacts
    WHERE journalid = ${journalId}`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will check the availability
export const checkAvailability = (req, res) => {
  const { value, type } = req.body;
  const name = value ? value.trim() : '';
  let sql = '';
  if (type === 'jobId') {
    sql = `SELECT itemcode FROM public.wms_workorder WHERE itemcode='${name}'`;
  } else if (type === 'doiNumber') {
    sql = `SELECT doinumber FROM public.wms_workorder WHERE doinumber='${name}'`;
  } else if (type === 'newsletterdoiNumber') {
    sql = `SELECT newsletterdoiNumber FROM public.wms_workorder WHERE newsletterdoiNumber='${name}'`;
  } else if (type === 'WoPaperBackISBN') {
    sql = `SELECT paperbackisbn FROM public.wms_workorder WHERE paperbackisbn='${name}'`;
  } else if (type === 'WoHardBackISBN') {
    // hardback isbn
    sql = `SELECT hardbackisbn FROM public.wms_workorder WHERE hardbackisbn='${name}'`;
  } else if (type === 'WoOcISBN') {
    sql = `SELECT ocisbn FROM public.wms_workorder WHERE ocisbn='${name}'`;
  } else if (type === 'eISBN') {
    sql = `SELECT eisbn FROM public.wms_workorder WHERE eisbn='${name}'`;
  } else if (type === 'printISBN') {
    sql = `SELECT printisbn FROM public.wms_workorder WHERE printisbn='${name}'`;
  } else if (type === 'ISSN') {
    sql = `SELECT issn FROM public.wms_workorder WHERE issn='${name}'`;
  } else if (type === 'NeWWoHardBackISBN') {
    // added for new isbn update for next stage trigger
    sql = `SELECT hardbackisbn FROM public.wms_workorder WHERE hardbackisbn='${name}' and workorderid !=${req.body.woid}`;
  }
  console.log(sql, 'check avail');
  query(sql)
    .then(data => {
      if (data.length) {
        res.status(200).json({ status: false, message: 'Not available' });
      } else {
        res.status(200).json({ status: true, message: 'Available' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const readOrderDateFromEmail = async (req, res) => {
  const reqData = req.body;
  const _output = {};
  try {
    const dmsType = 'azure'; // await getdmsType(reqData.woId);
    let url = '';
    switch (dmsType) {
      case 'azure':
        const out = await azureHelper._download(reqData.path);
        url = out.data.path;
        break;
      case 'local':
        const out1 = await localHelper._localdownload(reqData.path);
        url = out1.data.path;
        break;
      default:
        url =
          config.openKM.base_url + config.openKM.uri.download + reqData.uuId;
        break;
    }
    await fetch(url)
      .then(response => response.text())
      .then(
        async body => {
          // eslint-disable-next-line consistent-return
          await emlformat.read(body, function (error, data) {
            if (error) return;

            console.log(data.headers.Date.split('+'), 'res for fetch date1');
            console.log(data.headers.Date.split('+')[0], 'res for fetch date2');

            _output.data =
              data.date == 'Invalid Date' && data.headers
                ? data.headers.Date.split('+')[0]
                : data.date;
            _output.is_success = true;
            _output.message = 'EML parsed successfully';
          });
        },
        () => {},
      );
  } catch (error) {
    _output.data = error.message;
    _output.isSuccess = false;
    _output.message = error.message;
  }
  res.send(_output);
};

// //This function will get the cutomer list
// export const getCustomerLists = (req, res) => {
//     const sql = `SELECT customerid as value, customername as label FROM public.org_mst_customer`;
//     query(sql).then((data) => {
//         res.status(200).json({ data: data});
//     }).catch((error) => {
//         res.status(400).send({message: error});
//     });

// }
// //This function will get the divison List
// export const getDivisonList = (req, res) => {
//     let getData=req.body;
//     const sql = `SELECT org_mst_division.divisionid as value, org_mst_division.division as label FROM org_mst_customer_orgmap
//     JOIN org_mst_division ON org_mst_customer_orgmap.divisionid = org_mst_division.divisionid
//     WHERE org_mst_customer_orgmap.customerid = ${getData.customerid} `;
//     query(sql).then((data) => {
//         res.status(200).json({ data: data});
//     }).catch((error) => {
//         res.status(400).send({message: error});
//     });

// }
// //This function will get the subDivison List
// export const getSubDivisonList = (req, res) => {
//     let getData=req.body;
//     const sql=`SELECT org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap
//     JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
//     WHERE org_mst_customer_orgmap.customerid = ${getData.customerid}  AND  org_mst_customer_orgmap.divisionid = ${getData.divisionid}`;
//     query(sql).then((data) => {
//         res.status(200).json({ data: data});
//     }).catch((error) => {
//         res.status(400).send({message: error});
//     });
// }
// //This function will get the country List
// export const getLocationList = (req, res) => {
//     let getData=req.body;
//     const sql=`SELECT geo_mst_country.countryid as value, geo_mst_country.countryname as label FROM org_mst_customer_orgmap
//     JOIN geo_mst_country ON org_mst_customer_orgmap.countryid = geo_mst_country.countryid
//     WHERE org_mst_customer_orgmap.customerid = ${getData.customerid}  AND   org_mst_customer_orgmap.divisionid= ${getData.divisionid}  AND org_mst_customer_orgmap.subdivisionid= ${getData.subdivisionid}`;
//     query(sql).then((data) => {
//         res.status(200).json({ data: data});
//     }).catch((error) => {
//         res.status(400).send({message: error});
//     });

// }

// //This function will get the customer contact List
// export const getCustomerContactList = (req, res) => {
//     let getData = req.body;
//     const sql = `SELECT tbl2.custorgconmapid, tbl2.contactname, tbl2.contacttype, tbl2.isprimary, tbl2.contactroleid FROM org_mst_customer_orgmap as tbl1
//     JOIN org_mst_customerorg_contact as tbl2 ON tbl2.custorgmapid = tbl1.custorgmapid
//     WHERE
//     tbl1.customerid= ${getData.customerId} AND tbl1.divisionid= ${getData.divisionId} AND tbl1.subdivisionid= ${getData.subDivisionId} AND tbl1.countryid=${getData.countryId} `;
//     query(sql).then((data) => {
//         res.status(200).json({ data: data});
//     }).catch((error) => {
//         res.status(400).send({message: error});
//     });
// }

export const WorkOrderCreation_xml = async req => {
  return new Promise(async resolve => {
    try {
      const reqData = req.body;

      const response = validator(reqData, woSchema);
      if (response.status) {
        console.log('inside add WO');
        const {
          WoHardBackISBN,
          WoPaperBackISBN,
          WoOcISBN,
          printISBN,
          eISBN,
          ISSN,
        } = req.body;

        const woExists = await checkWOExists(reqData);

        // for cup
        if (WoHardBackISBN) {
          await checkValueExists(
            WoHardBackISBN,
            'hardbackisbn',
            'HardBack ISBN',
          );
        }
        if (WoPaperBackISBN) {
          await checkValueExists(
            WoPaperBackISBN,
            'paperbackisbn',
            'PaperBack ISBN',
          );
        }
        if (WoOcISBN) {
          await checkValueExists(WoOcISBN, 'ocisbn', 'OC ISBN');
        }
        // for hodder printisbn, eisbn, issn,
        if (printISBN) {
          await checkValueExists(printISBN, 'printisbn', 'Print ISBN');
        }
        if (eISBN) {
          await checkValueExists(eISBN, 'eisbn', 'EISBN');
        }
        if (ISSN) {
          await checkValueExists(ISSN, 'issn', 'ISSN');
        }
        console.log(woExists, 'woExists');

        req.body.customerId = reqData.customer;

        console.log('without iTracks WO');
        reqData.jobCardId = null;
        // woCreate(reqData, res);
        const jparam = JSON.stringify(reqData);
        const sql = `select * from workorder_autocreation('${jparam}')`;
        query(sql)
          .then(resp => {
            console.log(resp);
            const res = resp[0];
            resolve({ returnresult: res.returnresult, error: '' });
          })
          .catch(error => {
            resolve({ returnresult: 0, error });
          });
      } else {
        resolve({ returnresult: 0, error: response.message });
      }
    } catch (e) {
      resolve({ returnresult: 0, error: e.message ? e.message : e });
    }
  });
};

const autowocreate = async req => {
  return new Promise(async resolve => {
    // const jparam = JSON.stringify(req);
    let jparam = JSON.stringify(req);
    jparam = jparam.replace(/'/g, "''");

    let sql = '';
    if (req.woType == 'Book') {
      sql = `select * from workorder_autocreation_book('${jparam}')`;
    } else {
      sql = `select * from workorder_autocreation('${jparam}')`;
    }
    //    const sql = `select * from workorder_autocreation_book1('${jparam}')`;
    console.log(sql, 'autocreation sql');
    query(sql)
      .then(resp => {
        console.log(resp);
        let jspayload = '';
        let retres = '';
        let filepathpayload = '';
        let returnmsg = '';
        let retsuccess = false;
        if (resp) {
          const res = resp[0];
          if (res.stagepayload) {
            jspayload = JSON.parse(res.stagepayload);
          }
          if (res.filepathpayload) {
            filepathpayload = JSON.parse(res.filepathpayload);
          }
          if (res.returnresult) {
            retres = res.returnresult;
          }
          if (res.retmsg) {
            returnmsg = res.retmsg;
          }
          if (res.returnresult == '-1') {
            retsuccess = false;
          } else {
            retsuccess = true;
            returnmsg = 'WO Created successfully';
          }
          // if (res.retmsg) {
          //   returnmsg = res.retmsg;
          // } else {
          //   returnmsg = 'WO Created successfully';
          // }
        } else {
          returnmsg = 'WO Creation failed';
        }

        resolve({
          returnresult: retres,
          stagepalyload: jspayload,
          filepathpayload,
          error: returnmsg,
          issuccess: retsuccess,
        });
      })
      .catch(error => {
        resolve({ returnresult: 0, error: error.message, issuccess: false });
      });
  });
};

export const WorkOrderCreation = async (req, res) => {
  try {
    const reqData = req.body;
    const { isauto } = reqData;

    const response = validator(reqData, woSchema);
    if (response.status) {
      if (reqData.workorderId) {
        const { customer, duId } = reqData;
        const sql = ` SELECT dms_master.dmsid, dms_master.dmstype FROM wms_mst_customerconfigdetails 
      JOIN dms_master ON dms_master.dmsid = wms_mst_customerconfigdetails.dmsid
      WHERE customerid=${customer} and duid=${duId} and dms_master.isactive`;

        const dmsInfo = await query(sql);
        reqData.dmsid = reqData.dmsid ? reqData.dmsid : dmsInfo[0]?.dmsid;
        console.log('inside update');
        woUpdate(reqData, res);
      } else {
        console.log('inside add WO');
        const {
          WoHardBackISBN,
          WoPaperBackISBN,
          WoOcISBN,
          printISBN,
          eISBN,
          ISSN,
        } = req.body;

        const woExists = await checkWOExists(reqData);

        // for cup
        if (WoHardBackISBN) {
          await checkValueExists(
            WoHardBackISBN,
            'hardbackisbn',
            'HardBack ISBN',
          );
        }
        if (WoPaperBackISBN) {
          await checkValueExists(
            WoPaperBackISBN,
            'paperbackisbn',
            'PaperBack ISBN',
          );
        }
        if (WoOcISBN) {
          await checkValueExists(WoOcISBN, 'ocisbn', 'OC ISBN');
        }
        // for hodder printisbn, eisbn, issn,
        if (printISBN) {
          await checkValueExists(printISBN, 'printisbn', 'Print ISBN');
        }
        if (eISBN) {
          await checkValueExists(eISBN, 'eisbn', 'EISBN');
        }
        if (ISSN) {
          await checkValueExists(ISSN, 'issn', 'ISSN');
        }
        console.log(woExists, 'woExists');

        req.body.customerId = reqData.customer;
        const isItracksAPI = await checkItracksExits(req, res);
        console.log(isItracksAPI, 'isItracksAPI');
        const { status } = isItracksAPI;

        if (status) {
          // iTracks call
          const jobCardRes = await createJob(reqData);
          console.log(jobCardRes, 'jobCardRes1');
          const { status: status1, message } = jobCardRes;

          if (status1) {
            reqData.jobCardId = message;
            if (isauto) {
              const resultdata = await wmsWOCreate(reqData);
              return resultdata;
            }
            woCreate(reqData, res);
          } else {
            if (isauto) {
              const retrunjson = {
                message: `${message} Please contact the iTrack Administrator`,
                status: false,
                uploadpath: '',
              };
              return retrunjson;
            }
            res.status(400).json({
              message: `${message} Please contact the iTrack Administrator`,
              status: false,
            });
          }
        } else {
          console.log('without iTracks WO');
          reqData.jobCardId = null;
          if (isauto) {
            const resultdata = await wmsWOCreate(reqData);
            return resultdata;
          }
          woCreate(reqData, res);
        }
      }
    } else {
      if (isauto) {
        const retrunjson = {
          message: response.message,
          status: false,
          uploadpath: '',
        };
        return retrunjson;
      }
      res.status(400).send({ message: response.message });
    }
    return false;
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
    return false;
  }
};

export const WorkOrderCreationBook = async (req, res) => {
  try {
    const reqData = req.body;

    // const response = validator(reqData, woSchema);

    // console.log('inside add WO');
    const {
      WoHardBackISBN,
      WoPaperBackISBN,
      WoOcISBN,
      printISBN,
      eISBN,
      ISSN,
    } = req.body;

    const woExists = await checkWOExists(reqData);

    // for cup
    if (WoHardBackISBN) {
      await checkValueExists(WoHardBackISBN, 'hardbackisbn', 'HardBack ISBN');
    }
    if (WoPaperBackISBN) {
      await checkValueExists(
        WoPaperBackISBN,
        'paperbackisbn',
        'PaperBack ISBN',
      );
    }
    if (WoOcISBN) {
      await checkValueExists(WoOcISBN, 'ocisbn', 'OC ISBN');
    }
    // for hodder printisbn, eisbn, issn,
    if (printISBN) {
      await checkValueExists(printISBN, 'printisbn', 'Print ISBN');
    }
    if (eISBN) {
      await checkValueExists(eISBN, 'eisbn', 'EISBN');
    }
    if (ISSN) {
      await checkValueExists(ISSN, 'issn', 'ISSN');
    }
    console.log(woExists, 'woExists');

    req.body.customerId = reqData.customer;
    const isItracksAPI = await checkItracksExits(req, res);
    console.log(isItracksAPI, 'isItracksAPI');
    const { status } = isItracksAPI;

    if (status) {
      // iTracks call
      const jobCardRes = await createJob(reqData);
      console.log(jobCardRes, 'jobCardRes1');
      const { status: status1, message } = jobCardRes;

      if (status1) {
        reqData.jobCardId = message;

        const resultdata = await wmsWOCreate(reqData);
        return resultdata;
      }

      const retrunjson = {
        message: `${message} Please contact the iTrack Administrator`,
        status: false,
        uploadpath: '',
      };
      return retrunjson;
    }
    console.log('without iTracks WO');
    reqData.jobCardId = null;
    const resultdata = await wmsWOCreate(reqData);
    return resultdata;
  } catch (e) {
    return false;
  }
};

export const wmsWOCreate = async reqData => {
  return new Promise(async resolve => {
    try {
      let retrunjson = {
        message: 'Process started',
        status: false,
        uploadpath: '',
      };
      const autoworesp = await autowocreate(reqData);

      if (autoworesp.issuccess) {
        const fileuploadpath = await getFolderStructure_autowocreate({
          body: autoworesp.filepathpayload,
        });
        if (
          autoworesp.stagepalyload != undefined &&
          autoworesp.stagepalyload != ''
        ) {
          autoworesp.stagepalyload.valuesOfArray = [{ mspages: 1 }];

          let checkresp = { message: '', issuccess: true };

          if (autoworesp.stagepalyload.customerId != '11') {
            checkresp = await updateWoStage_autoCall(
              { body: autoworesp.stagepalyload },
              '',
            );
          }
          if (checkresp.issuccess) {
            retrunjson = {
              message: autoworesp.error,
              status: true,
              uploadpath: fileuploadpath,
              woId: autoworesp.returnresult,
            };
          } else {
            retrunjson = {
              message: 'WO Created Stage trigger failed',
              status: false,
              uploadpath: '',
              woId: 0,
            };
          }
        } else {
          retrunjson = {
            message: 'WO Created - Stage trigger payload empty',
            status: false,
            uploadpath: '',
            woId: 0,
          };
        }
      } else {
        retrunjson = {
          message: autoworesp.error,
          status: false,
          uploadpath: '',
          woId: 0,
        };
      }
      resolve(retrunjson);
    } catch (error) {
      resolve({
        message: error.message,
        status: false,
        uploadpath: '',
        woId: 0,
      });
    }
  });
};

const woCreate = async (reqData, res) => {
  // workorder
  try {
    const { articleNumber, piiNumber, customerId, duId } = reqData;
    const sql = ` SELECT dms_master.dmsid, dms_master.dmstype FROM wms_mst_customerconfigdetails 
      JOIN dms_master ON dms_master.dmsid = wms_mst_customerconfigdetails.dmsid
      WHERE customerid=${customerId} and duid=${duId} and dms_master.isactive`;

    const dmsInfo = await query(sql);
    const data = reqData;
    data.dmsId = dmsInfo.length ? dmsInfo[0].dmsid : null;
    const otherFileds = {};
    otherFileds.articleno = articleNumber || null;
    const isOtherFieldsNull = Object.values(otherFileds).every(
      value => value === null,
    );
    otherFileds.pii = piiNumber || null;
    const orderDate = reqData.emailOrderDate
      ? `'${reqData.emailOrderDate}'`
      : null;
    const sqlForCreate = `INSERT INTO public.wms_workorder(
      itemcode, title, projectbrief, printisbn, eisbn, issn, edition, customerid, 
      divisionid, subdivisionid, countryid, colorid, composingsoftwareid, inputfiletypeid, 
      languageid, celevelid, indextypeid, category, status, trimsizewidth, trimsizewidthuom,
      trimsizeheight, trimsizeheightuom, orderemailpath, orderemailpathuuid, totalchaptercount, 
      ordermaildate, journalid, jobtype, doinumber, wotype, totalarticlecount, totalnonarticlecount, 
      issuenumber, volumenumber, jobcardid, 
      iworkflow, paperbackisbn, hardbackisbn, ocisbn, otherfield,logoid,dmsid,iscoveravailable,isadvertavailable,
      newsletterdoinumber, createdby, duid, complexityid, wfid, flowtype
      )
      VALUES (
        '${data.jobId}', 
        '${data.jobTitle}',
        ${data.projectBrief ? `'${data.projectBrief}'` : null},
        ${data.printISBN ? `'${data.printISBN}'` : null},
        ${data.eISBN ? `'${data.eISBN}'` : null},
        ${data.ISSN ? `'${data.ISSN}'` : null},
        ${data.edition ? `'${data.edition}'` : null},
        ${data.customer ? data.customer : null}, 
        ${data.division ? data.division : null}, 
        ${data.subDivision ? data.subDivision : null}, 
        ${data.country ? data.country : null},
        ${data.colours ? data.colours : null}, 
        ${data.softwares ? data.softwares : null}, 
        ${data.inputFileTypes ? data.inputFileTypes : 4},
        ${data.languages ? data.languages : null}, 
        ${data.CELevel ? data.CELevel : null}, 
        ${data.indexType ? data.indexType : null},
        ${data.category ? `'${data.category}'` : null}, 
        'In Process',
        ${data.pageWidth ? data.pageWidth : null},
        ${data.pageWidthUnit ? `'${data.pageWidthUnit}'` : null},
        ${data.pageHeight ? data.pageHeight : null},
        ${data.pageHeightUnit ? `'${data.pageHeightUnit}'` : null},
        ${data.orderEmailPath ? `'${data.orderEmailPath}'` : null},
        ${data.orderEmailPathUuid ? `'${data.orderEmailPathUuid}'` : null},
        ${data.noOfChapters ? data.noOfChapters : null}, 
        ${orderDate || null}, 
        ${data.journalAcronym ? data.journalAcronym : null}, 
        ${data.jobType ? `'${data.jobType}'` : null}, 
        ${data.doiNumber ? `'${data.doiNumber}'` : null},
        ${data.woType ? `'${data.woType}'` : null}, 
        ${!isNaN(parseInt(data.noOfArticles)) ? data.noOfArticles : null},
        ${!isNaN(parseInt(data.noOfNonArticles)) ? data.noOfNonArticles : null},
        ${data.issueNumber ? `'${data.issueNumber}'` : null}, 
        ${data.volumeNumber ? `'${data.volumeNumber}'` : null}, 
        ${data.jobCardId ? data.jobCardId : null}, 

        ${data.iWorkflow ? data.iWorkflow : null}, 
        ${data.WoPaperBackISBN ? data.WoPaperBackISBN : null}, 
        ${data.WoHardBackISBN ? data.WoHardBackISBN : null}, 
        ${data.WoOcISBN ? data.WoOcISBN : null}, 
        ${isOtherFieldsNull ? null : `'${JSON.stringify(otherFileds)}'`},
        ${data.logoid ? data.logoid : null},
        ${data.dmsId ? data.dmsId : null}, 
        ${data.iscoveravailable ? data.iscoveravailable : null},
        ${data.isadvertavailable ? data.isadvertavailable : null},

        ${data.newsletterdoiNumber ? `'${data.newsletterdoiNumber}'` : null},
        ${data.modifiedBy ? `'${data.modifiedBy}'` : null},
        ${data.duId ? `'${data.duId}'` : null},
        ${data.complexity ? `'${data.complexity}'` : null},
        ${data.workFlow ? `'${data.workFlow}'` : null}, NULL
      ) RETURNING workorderid, wfid, customerid`;

    query(sqlForCreate)
      .then(resForCreate => {
        console.log(resForCreate, 'resForCreate');
        // workorder contact
        const getValuesQuery = `SELECT ${
          resForCreate[0].workorderid
        },custorgconmapid, contactname,contactemail,contactphone1,contactphone2,contactroleid,contacttype,isprimary 
            FROM org_mst_customerorg_contact WHERE custorgconmapid IN (${
              reqData.custPrimaryContact
            },${reqData.custSecondaryContact},
                ${reqData.kamName},${reqData.clientManager} ${
          reqData.subDivision !== 9 ? `,${reqData.projectManager}` : ''
        }) `;
        console.log(getValuesQuery, 'getValuesQuery1');
        const sqlForConCreate = `INSERT INTO public.wms_workorder_contacts(workorderid, contactid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary)
            ${getValuesQuery} 
            RETURNING workorderid`;
        console.log(sqlForConCreate, 'sqlForConCreate');

        query(sqlForConCreate)
          .then(async resForConCreate => {
            console.log(resForConCreate, 'resForConCreate');
            if (resForConCreate.length > 0) {
              try {
                if (reqData.subDivision == 9) {
                  const journalMappedPm = await woJournalMappedPmEntry(
                    reqData,
                    resForCreate[0].workorderid,
                  );
                  console.log(journalMappedPm, 'journalMappedPm');
                }
                let externalUserRes = [];
                if (
                  reqData.externalUsers &&
                  Object.keys(reqData.externalUsers).length &&
                  reqData.externalUsers !== '{}'
                ) {
                  externalUserRes = await woExternalUserEntry(
                    reqData,
                    resForCreate[0].workorderid,
                  );
                  console.log(externalUserRes, 'externalUserRes');
                }
                const serviceRes = await woServiceEntry(
                  reqData,
                  resForCreate[0].workorderid,
                );
                console.log(serviceRes, 'serviceRes');
                if (serviceRes) {
                  mailTrigger(reqData, resForCreate[0]);
                  res.status(200).json({
                    data: {
                      id: serviceRes,
                    },
                    message: 'WO Created successfully',
                    status: true,
                  });
                } else {
                  throw new Error('Service entry error');
                }
              } catch (error) {
                res.status(400).send({ message: error });
              }
            }
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (e) {
    console.log(e, 'wo create error');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const checkWOExists = data => {
  const { jobId, doiNumber, isauto } = data;
  const job = jobId ? jobId.trim() : '';
  const doi = doiNumber ? doiNumber.trim() : '';

  let condition = `WHERE itemcode='${job}'`;
  if (doi) {
    condition = `WHERE itemcode='${job}'  OR doinumber='${doi}'`;
  }

  return new Promise((resolve, reject) => {
    const sql = `SELECT itemcode FROM public.wms_workorder ${condition} `;
    console.log(sql, 'sql for wo exists');

    query(sql)
      .then(val => {
        if (val.length) {
          const retobj = { status: false, message: 'WO already exists' };
          if (isauto) {
            resolve(retobj);
          } else {
            reject(retobj);
          }
        } else if (!val.length) {
          resolve({ status: true, message: 'WO available' });
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};

export const checkValueExists = (value, column, evavlue) => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM public.wms_workorder WHERE ${column}='${value}' `;
    console.log(sql, 'sql for value exists');

    query(sql)
      .then(data => {
        if (data.length) {
          reject({
            status: false,
            message: `Work Order ${evavlue} already exists`,
          });
        } else if (!data.length) {
          resolve({ status: true, message: `Work Order ${evavlue} available` });
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};
export const woJournalMappedPmEntry = (reqData, woId) => {
  console.log(reqData, 'reqData');
  const { projectManager, supplierProjectManager } = reqData;
  return new Promise((resove, reject) => {
    const sql = `
        SELECT ${woId}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
        wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
        JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
        JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
        WHERE wms_user.userid = '${projectManager}' AND wms_userrole.roleid = 1
        UNION ALL
        SELECT ${woId}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
        wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
        JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
        JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
        WHERE wms_user.userid = '${supplierProjectManager}' AND wms_userrole.roleid = 9
        `;
    console.log(sql, 'sql for get pm && spm users');
    query(sql)
      .then(data => {
        let userArray = data;
        if (projectManager == supplierProjectManager) {
          userArray = [].concat(data, data);
        }
        console.log(userArray, 'userArray');
        const val = [];
        userArray.forEach((list, i) => {
          val.push(`(${woId},'${list.contactname}','${list.contactemail}','${
            list.contactphone1
          }',
                '${list.roleacronym}', 'Integra' , ${i == 0}, '${
            list.userid
          }',${list.roleid})`);
        });
        console.log(val, 'values for users');
        const sqls = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, 
                contactphone1, contactrole, contacttype, isprimary, userid, roleid)
                VALUES ${val} RETURNING workorderid`;
        console.log(sqls, 'sql for journal mapped');
        query(sqls)
          .then(value => {
            if (value.length) {
              resove(value[0].workorderid);
            } else {
              resove(0);
            }
          })
          .catch(error => {
            reject(error);
          });
      })
      .catch(error => {
        reject(error);
      });
  });
};
export const woExternalUserEntry = (reqData, woId) => {
  const { externalUsers } = reqData;
  return new Promise((resove, reject) => {
    const val = [];
    externalUsers.forEach(list => {
      val.push(`(${woId},'${list.name}','${list.email}','${list.phone1}',
            '${list.roleAcronym}', 'Customer' , false, ${list.role})`);
    });
    console.log(val, 'values for external customer');
    const sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, contactphone1, contactrole, contacttype, isprimary, roleid)
            VALUES ${val} RETURNING contactrole,contactname,contactemail `;
    console.log(sql, 'sql for external customer');
    query(sql)
      .then(data => {
        if (data.length) {
          resove(data);
        } else {
          resove(0);
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};
export const woServiceEntry = (reqData, woId) => {
  const { duId, services, custOrgMapId } = reqData;
  return new Promise((resove, reject) => {
    const getDataQuery = `SELECT org_mst_customerorg_service_map.serviceid,org_mst_deliveryunit.duid, ${woId}, 'YTS' as status, '1'
                        FROM org_mst_customerorg_service_map
                        JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customerorg_service_map.custorgmapid
                        JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = org_mst_customerorg_du_map.duid
                        WHERE  org_mst_customerorg_service_map.serviceid IN (${services}) AND org_mst_customerorg_service_map.custorgmapid = ${custOrgMapId}
                        AND org_mst_deliveryunit.duid = ${duId}`;
    const sql = `INSERT INTO public.wms_workorder_service(serviceid, baseduid ,workorderid, status, complexityid)
        ${getDataQuery} RETURNING woserviceid, workorderid`;
    console.log(sql, 'sqlForServiceEntry');
    query(sql)
      .then(async serviceRes => {
        console.log(serviceRes, 'serviceRes');
        if (serviceRes.length) {
          resove(serviceRes[0].workorderid);
        } else {
          resove(false);
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};
// this function will trigger the mail
export const mailTrigger = async (reqData, data) => {
  const { entityId, services, duId } = reqData;
  const { workorderid, customerid } = data;
  const payload = {
    entityId,
    workorderId: workorderid,
    serviceId: services,
    customerId: customerid,
    duId,
  };
  const serviceId = services;
  const resForConfig = await getNotificationConfig(payload, 'create');
  if (resForConfig.length > 0) {
    const {
      workorderid: woId,
      type,
      notificationconfig,
      customername,
      duname,
      itemcode,
      services: services1,
      totalchaptercount,
      printisbn,
      totalarticlecount,
      totalnonarticlecount,
      wotype,
      jobtype,
      title,
      journalname,
      doinumber,
      newsletterdoinumber,
      journalacronym,
    } = resForConfig[0];
    let isTrigger = false;
    if (
      notificationconfig.jobTypes.length &&
      notificationconfig.jobTypes.includes(jobtype)
    ) {
      isTrigger = true;
    } else if (notificationconfig.jobTypes.length == 0) {
      isTrigger = true;
    }
    console.log(isTrigger, 'isTrigger');

    if (type === 'mail' && isTrigger) {
      const pmI = resForConfig.findIndex(
        val => val.contactrole === 'PM' && val.isprimary,
      );
      const spmI = resForConfig.findIndex(
        val => val.contactrole === 'SPM' && !val.isprimary,
      );
      const authorI = resForConfig.findIndex(
        val => val.contactrole === 'AUTHOR' && val.contacttype === 'Customer',
      );
      const mailObj = {};
      if (pmI != -1) {
        mailObj.toPm = resForConfig[pmI].contactemail;
      }
      if (spmI != -1) {
        mailObj.toSpm = resForConfig[spmI].contactemail;
      }
      if (authorI != -1) {
        mailObj.toAuthor = resForConfig[authorI].contactemail;
      }
      const fromArray = [];
      const toMailArray = [];
      const ccMailArray = [];
      const bccMailArray = [];
      if (Array.isArray(notificationconfig.from)) {
        notificationconfig.from.forEach(item => {
          if (mailObj[item]) {
            fromArray.push(mailObj[item]);
          } else {
            fromArray.push(item);
          }
        });
      } else {
        fromArray.push(notificationconfig.from);
      }

      notificationconfig.to.forEach(item => {
        if (mailObj[item]) {
          toMailArray.push(mailObj[item]);
        } else {
          toMailArray.push(item);
        }
      });
      notificationconfig.cc.forEach(item => {
        if (mailObj[item]) {
          ccMailArray.push(mailObj[item]);
        } else {
          ccMailArray.push(item);
        }
      });
      notificationconfig.bcc.forEach(item => {
        if (mailObj[item]) {
          bccMailArray.push(mailObj[item]);
        } else {
          bccMailArray.push(item);
        }
      });
      console.log(fromArray, 'fromArray');

      emitAction({
        actionType: type,
        date: moment(new Date()).format('DD-MM-YYYY'),
        workorderId: woId,
        noOfChapter: totalchaptercount,
        noOfArticle: totalarticlecount,
        noOfNonArticle: totalnonarticlecount,
        printIsbn: printisbn,
        woType: wotype,
        jobType: jobtype,
        service: services1,
        doiNumber: doinumber,
        newsletterdoiNumber: newsletterdoinumber,
        jobId: itemcode,
        jobName: title,
        journalAcronym: journalacronym,
        journalName: journalname,
        customerName: customername,
        duName: duname,
        pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
        spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
        spmMail: spmI != -1 ? resForConfig[spmI].contactemail : '',
        authorName: authorI != -1 ? resForConfig[authorI].contactname : '',
        ...notificationconfig,
        from: fromArray,
        toMail: toMailArray,
        cc: ccMailArray,
        bcc: bccMailArray,
        tlName: 'TL',
        serviceId,
        mailType: 'general',
      });
    }
  }
};
//
// this function will trigger the mail
export const mailTriggerForAutoWOCreate = async (reqData, mailAction) => {
  const { articlename, journal, customer, message, stageName, iteration } =
    reqData;

  return new Promise(async resolve => {
    try {
      const journaldet = await getJournalDetail({
        journalshortname: journal,
        customershortname: customer,
      });

      if (journaldet && journaldet.length > 0) {
        if (journaldet[0].templatetype == 'defaulttemplate') {
          const { type, notificationconfig, errormessage } = journaldet[0];
          const data = {
            actionType: type,
            ...notificationconfig,
            jobId: articlename,
            subMessage: errormessage,
          };

          emitAction(data);

          resolve('success');
        } else {
          let subMsgToProduction = '';
          // const journaltomail = journaldet[0].cmemail; // journaldet[0].journalemail;
          let toMailArray = [];
          let isfailuremail = false;
          const cmMailArray = [];
          const payload = {
            entityId: 2,
            customerId: +journaldet[0].customerid,
            serviceId: 1,
          };

          console.log(cmMailArray);

          subMsgToProduction = `Message : ${message}`;
          if (mailAction == 'wocreation_error') {
            isfailuremail = true;
            mailAction = 'auto_create_failure';
          } else if (mailAction == 'wocreation_success') {
            mailAction = 'auto_create_success';
          } else if (mailAction == 'stagecreation_success') {
            mailAction = 'auto_stage_trigger_success';
          } else if (mailAction == 'stagecreation_error') {
            isfailuremail = true;
            mailAction = 'auto_stage_trigger_failure';
          }

          const resForConfig = await getNotificationConfig(payload, mailAction);

          let newSubject = '';

          if (isfailuremail == false) {
            journaldet.forEach(element => {
              cmMailArray.push(element.cmemail);
            });

            if (
              stageName.toLowerCase() == 'first proof' ||
              stageName.toLowerCase() == 'incoming inspection'
            ) {
              if (journaldet[0].celevelid != 1) {
                newSubject = 'for copyediting and typesetting';
              } else {
                newSubject = 'for typesetting';
              }
            } else if (stageName.toLowerCase() == 'revises') {
              newSubject = 'for correction';
            }
          } else {
            newSubject = 'Failure notification';
          }

          if (resForConfig.length > 0) {
            const { type, notificationconfig } = resForConfig[0];
            if (type === 'mail') {
              // const mailObj = {};
              // mailObj.toSpm = journaltomail;
              notificationconfig.to.concat(cmMailArray);
              toMailArray = notificationconfig.to.concat(cmMailArray);

              //   const fromArray = [];
              //   if (journaldet[0].journalemail) {
              //   fromArray.push(journaldet[0].journalemail);
              //   notificationconfig.from = fromArray;

              const data = {
                actionType: type,
                ...notificationconfig,
                jobId: articlename,
                subMessage: subMsgToProduction || '',
                toMail: toMailArray,
                stageName,
                iteration,
                newSubject,
              };

              emitAction(data);

              resolve('success');
            } else {
              resolve('Failed sending email- mail type not mapped');
            }
          } else {
            resolve('Failed sending email- mail template not mapped');
          }
        }
      } else {
        resolve('Failed sending email- journal detail not present');
      }
    } catch {
      resolve('Failed sending email');
    }
  });
};

export const mailTriggerForWatcherIdle = async objparam => {
  return new Promise(async resolve => {
    const { customershortname, lastcreatedon } = objparam;
    const sql = `select * from public.wms_notifications where action = 'ftp_failure_notification' limit 1`;
    const getdata = await query(sql);

    if (getdata && getdata.length) {
      const { type, notificationconfig } = getdata[0];

      const data = {
        actionType: type,
        ...notificationconfig,
        customershortname,
        lastruntime: lastcreatedon,
      };

      emitAction(data);
      resolve('success');
    }
  });
};

const woUpdate = (reqData, res) => {
  const { articleNumber, piiNumber } = reqData;
  const otherFileds = {};
  otherFileds.articleno = articleNumber || null;
  const isOtherFieldsNull = Object.values(otherFileds).every(
    value => value === null,
  );
  otherFileds.pii = piiNumber || null;
  // workorder
  const sqlForCreate = `UPDATE public.wms_workorder SET itemcode =$1, title=$2, wfid=$3, printisbn=$4, eisbn=$5, issn=$6, edition=$7, isbillable=$8, customerid=$9, 
    divisionid=$10, subdivisionid=$11, countryid=$12, colorid=$13, composingsoftwareid=$14, inputfiletypeid=$15, languageid=$16, celevelid=$17, indextypeid=$18, 
    projectbrief=$19,category=$20, trimsizewidth=$21, trimsizewidthuom=$22,trimsizeheight=$23, trimsizeheightuom=$24, orderemailpath=$25, 
    orderemailpathuuid=$26, totalchaptercount=$27, totalarticlecount=$28, totalnonarticlecount=$29, issuenumber=$30, volumenumber=$31, iworkflow=$32, paperbackisbn=$34, hardbackisbn=$35, ocisbn=$36, otherfield=$37,logoid=$38, dmsid=$39   WHERE workorderid=$33 `;

  const values = [
    reqData.jobId,
    reqData.jobTitle,
    reqData.workflowTemplate,
    reqData.printISBN,
    reqData.eISBN,
    reqData.ISSN,
    reqData.edition,
    reqData.isBillable,
    reqData.customer,
    reqData.division,
    reqData.subDivision,
    reqData.country,
    reqData.colours,
    reqData.softwares,
    reqData.inputFileTypes,
    reqData.languages,
    reqData.CELevel,
    reqData.indexType,
    reqData.projectBrief,
    reqData.category,
    reqData.pageWidth,
    reqData.pageWidthUnit,
    reqData.pageHeight,
    reqData.pageHeightUnit,
    reqData.orderEmailPath,
    reqData.orderEmailPathUuid,
    reqData.noOfChapters,
    // eslint-disable-next-line radix
    !Number.isNaN(parseInt(reqData.noOfArticles)) ? reqData.noOfArticles : null,
    // eslint-disable-next-line radix
    !Number.isNaN(parseInt(reqData.noOfNonArticles))
      ? reqData.noOfNonArticles
      : null,
    reqData.issueNumber,
    reqData.volumeNumber,
    reqData.iWorkflow,
    reqData.workorderId,
    reqData.WoPaperBackISBN,
    reqData.WoHardBackISBN,
    reqData.WoOcISBN,
    isOtherFieldsNull ? null : JSON.stringify(otherFileds),
    reqData.logoid,
    reqData.dmsid,
  ];

  query(sqlForCreate, values)
    .then(() => {
      // workorder contact
      updateWorkorderContact(reqData, res);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const updateWorkorderContact = async (reqData, res) => {
  try {
    const newUsrData = reqData.externalUsers.filter(
      item => item.disabled === false,
    );
    if (newUsrData && newUsrData.length) {
      const externalUserRes = await woExternalUserEntry(
        reqData,
        reqData.workorderId,
      );
      console.log(externalUserRes, 'update externalUserRes');
    }
    res.status(200).json({
      data: {
        id: reqData.workorderId,
      },
      message: 'WOI Updated successfully',
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
// const updateWorkorderContact_old = (reqData, res) => {
//   const sql = `DELETE FROM wms_workorder_contacts WHERE workorderid = ${reqData.workorderId}`;
//
//   query(sql)
//     .then(resForDelete => {
//
//       const getValuesQuery = `SELECT ${
//         reqData.workorderId
//       },custorgconmapid, contactname,contactemail,contactphone1,contactphone2,contactroleid,contacttype,isprimary
//             FROM org_mst_customerorg_contact WHERE custorgconmapid IN (${
//               reqData.custPrimaryContact
//             },${reqData.custSecondaryContact},
//                 ${reqData.kamName},${reqData.clientManager}  ${
//         reqData.subDivision !== 9 ? `,${reqData.projectManager}` : ''
//       }) `;

//       const sqlForConCreate = `INSERT INTO public.wms_workorder_contacts(workorderid, contactid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary)
//             ${getValuesQuery} RETURNING workorderid`;

//
//

//       query(sqlForConCreate)
//         .then(async resForConCreate => {
//
//           if (resForConCreate.length > 0) {
//             if (reqData.subDivision == 9) {
//               const journalMappedPm = await woJournalMappedPmEntry(
//                 reqData,
//                 reqData.workorderId,
//               );
//               console.log(journalMappedPm, 'journalMappedPm');
//             }
//             if (reqData.externalUsers && reqData.externalUsers.length) {
//               const externalUserRes = await woExternalUserEntry(
//                 reqData,
//                 reqData.workorderId,
//               );
//               console.log(externalUserRes, 'update externalUserRes');
//             }
//             // if (reqData.subDivision == 9 && reqData.noOfChapters == reqData.receivedChapters) {
//             //     updateBCStatus(reqData, res);
//             // } else
//             // if (reqData.subDivision != 9 && reqData.noOfChapters == reqData.receivedChapters) {
//             //     updateBCStatus(reqData, res);
//             // } else {
//             //     res.status(200).json({
//             //         data: {
//             //             id: reqData.workorderId
//             //         }, message: 'WOI Updated successfully'
//             //     });
//             // }

//             res.status(200).json({
//               data: {
//                 id: reqData.workorderId,
//               },
//               message: 'WOI Updated successfully',
//             });
//           }
//         })
//         .catch(error => {
//           res.status(400).send({ message: error });
//         });
//     })
//     .catch(error => {
//       res.status(400).send({ message: error });
//     });
// };

// const updateBCStatus = (reqData, res) => {
//   const sql = `SELECT wms_workorder_service.processinstanceid,wms_mst_stage.stagename, wms_workflow.wfcategory, wms_workflow.config as wfconfig FROM public.wms_workorder_service
//     join wms_workorder_stage on wms_workorder_stage.serviceid = wms_workorder_service.serviceid and wms_workorder_stage.workorderid = wms_workorder_service.workorderid
//     join wms_mst_stage on wms_mst_stage.stageid = wms_workorder_stage.wfstageid
//     join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
//     where wms_workorder_service.workorderid = $1 and wms_workorder_service.serviceid = $2  ORDER BY wostageid ASC limit 1`;
//   query(sql, [reqData.workorderId, reqData.serviceId])
//     .then(bcData => {
//       if (bcData.length) {
//         const { stagename, wfcategory, wfconfig, processinstanceid } =
//           bcData[0];
//         const enableListener = wfconfig ? !!wfconfig.enableListener : false;
//         const stageType = stagename.toLowerCase().replace(/ /g, '_');
//         bookComplete(
//           reqData.workorderId,
//           reqData.serviceId,
//           wfcategory,
//           reqData.noOfChapters,
//           stageType,
//           enableListener,
//           processinstanceid,
//         )
//           .then(() => {
//             res.status(200).json({
//               data: {
//                 id: reqData.workorderId,
//               },
//               message: 'WOI Updated successfully',
//             });
//           })
//           .catch(error => {
//             res.status(400).send({ message: error });
//           });
//       } else {
//         res.status(200).json({
//           data: {
//             id: reqData.workorderId,
//           },
//           message: 'WOI Updated successfully',
//         });
//       }
//     })
//     .catch(error => {
//       res.status(400).send({ message: error });
//     });
// };

export const updateWoReport = (req, res) => {
  const getData = req.body;
  const sql = `UPDATE wms_workorder
    SET incomingreportfilepath='${getData.filePath}', incomingreportfileuuid='${getData.fileUuid}'
    WHERE workorderid = ${getData.workorderId}`;

  query(sql)
    .then(data => {
      res.status(200).json({ data, message: 'Report uploaded successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// get the unique workorder detail
export const getWoDetails = (req, res) => {
  const id = req.body.workorderId;
  if (id) {
    const sql = `SELECT wo.workorderid,wo.itemcode,wo.title,wo.otherfield,wo.wfid,wo.printisbn,wo.eisbn,wo.issn,wo.edition,wo.isbillable,wo.customerid,wo.divisionid,wo.hardbackisbn as wohardbackisbn, wo.paperbackisbn as wopaperbackisbn, wo.ocisbn as woocisbn,
    wo.subdivisionid,wo.countryid,wo.trimsize,wo.colorid,wo.composingsoftwareid,wo.inputfiletypeid,wo.languageid,wo.celevelid,wo.indextypeid,
    wo.projectbrief,wo.incomingreportfilepath,wo.incomingreportfileuuid,wo.category,wo.logoid,wo.dmsid,wo.status,wo.trimsizewidth,wo.trimsizewidthuom,
    wo.trimsizeheight,wo.trimsizeheightuom,wo.orderemailpath,wo.orderemailpathuuid,wo.totalchaptercount,
    wo.completeddate,wo.ordermaildate as woordermaildate,wo.journalid,wo.jobtype,wo.doinumber,wo.newsletterdoinumber,wo.wotype,wo.totalarticlecount,
    wo.totalnonarticlecount,wo.ordermaildate as woordermaildate,wo.issuenumber,wo.volumenumber,wo.jobcardid,wo.camundaform, wo.iworkflow,wo.otherfield->>'articleno' as articleno,wo.otherfield->>'pii' as piino,
    dms_master.dmstype,
    contact.wocontactid,contact.contactname,contact.contactemail,
    contact.contactphone1,contact.contactphone2,contact.contactrole,contact.roleid,contact.contacttype,contact.isprimary,contact.userid,contact.contactid,
    cust.customerid,cust.customercode,cust.customername,cust.customertype,cust.customerid,
    div.divisionid,div.division,
    subdiv.subdivisionid,subdiv.subdivision,
    journal.journalid,journal.custorgmapid,journal.journalname,journal.journalacronym,journal.templateid,journal.printissn,journal.pmid,journal.supplierpmid,
    journal.onlineissn,journal.articletat,journal.issuetat,journal.totalissuecount,journal.budgetedcount,journal.isopenaccessarticle,
    stage.wostageid,stage.serviceid,stage.wfstageid,stage.startdate,stage.enddate,stage.ordermaildate,stage.stageiterationcount,stage.isbookcompleted,stage.ismilestone,
    additionalinfo.additionalinfoid,
	additionalinfo.pitstopprofileid,
	additionalinfo.versoid,
	additionalinfo.rectoid,
	additionalinfo.xmltemplateid,
	additionalinfo.lastpageno,
	additionalinfo.splittingid,
	additionalinfo.indexcorrectionid,
	additionalinfo.mscropneededid,
	additionalinfo.dispatchtypeid,
	additionalinfo.colorprofileid,
	additionalinfo.ocisbn,
	additionalinfo.bookcategoryid,
	additionalinfo.cssvalueid,
	additionalinfo.style1,
	additionalinfo.style2,
	additionalinfo.style3,
	additionalinfo.style4,
	additionalinfo.style5,
	additionalinfo.style6,
	additionalinfo.medicalbook,
	additionalinfo.hardbackisbn,
	additionalinfo.paperbackisbn,
    additionalinfo.watermarkid,
    additionalinfo.smartmetadataid,
    additionalinfo.dtdid,
    additionalinfo.onlinepdfid,
    additionalinfo.printid,
    additionalinfo.additionalpdfid,
    additionalinfo.fpprofileid,
    additionalinfo.rvsprofileid,
    additionalinfo.s300id,
    additionalinfo.o300id,
    additionalinfo.bookprintid,
    additionalinfo.pdfless,
    additionalinfo.indexcorrectionid,
        (SELECT count(workorderid) FROM wms_workorder_stage WHERE workorderid = ${id}) as isserviceadded,
        (SELECT count(workorderid) FROM wms_workorder_stage WHERE plannedstartdate IS NOT NULL AND workorderid = ${id}) as isstageadded
        FROM wms_workorder as wo
        JOIN wms_workorder_contacts as contact ON wo.workorderid = contact.workorderid
            JOIN org_mst_customer as cust ON wo.customerid= cust.customerid
            JOIN org_mst_division as div ON wo.divisionid= div.divisionid
            JOIN org_mst_subdivision as subdiv ON wo.subdivisionid= subdiv.subdivisionid
        LEFT JOIN pp_mst_journal as journal ON journal.journalid = wo.journalid
        LEFT JOIN wms_workorder_additionalinfo as additionalinfo on additionalinfo.workorderid = wo.workorderid
    LEFT JOIN wms_workorder_stage as stage ON stage.workorderid = ${id}
    LEFT JOIN dms_master ON dms_master.dmsid = wo.dmsid

    WHERE wo.workorderid=${id}`;

    query(sql)
      .then(data => {
        const SqlForServiceId = `SELECT wms_mst_service.serviceid as value, wms_workorder_service.isbookcompleted, wms_mst_service.servicename as label,
        wms_workorder_service.jobnormsid, wms_workorder_service.complexityid,wms_workflow.wfid, wms_workflow.wfcategory, wms_workflow.config as wfconfig, iscamundaflow FROM wms_workorder_service 
        JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workorder_service.serviceid
        join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
        WHERE wms_workorder_service.workorderid IN (${id}) `;
        query(SqlForServiceId)
          .then(async resForService => {
            let setObj = {};
            const additionalObj = {};
            data.forEach(list => {
              setObj.customerid = list.customerid;
              setObj.divisionid = list.divisionid;
              setObj.subdivisionid = list.subdivisionid;
              setObj.countryid = list.countryid;
              if (list.contactid) {
                // last update added if contactid avoid null value for contact info page
                if (list.contacttype === 'Customer' && list.isprimary) {
                  setObj.primarycontactid = list.contactid;
                } else if (
                  list.contacttype === 'Customer' &&
                  !list.isprimary &&
                  list.contactrole !== 'PED' &&
                  list.contactrole !== 'AUTHOR'
                ) {
                  setObj.secondarycontactid = list.contactid;
                } else if (
                  list.contacttype === 'Integra' &&
                  list.contactrole === 'KAM'
                ) {
                  setObj.kamcontactid = list.contactid;
                } else if (
                  list.contacttype === 'Integra' &&
                  list.contactrole === 'CM'
                ) {
                  setObj.cmcontactid = list.contactid;
                } else if (
                  list.contacttype === 'Integra' &&
                  list.contactrole === 'PM'
                ) {
                  setObj.pmcontactid = list.contactid;
                } else if (
                  list.contacttype === 'Integra' &&
                  list.contactrole !== 'KAM' &&
                  list.contactrole !== 'CM' &&
                  list.contactrole !== 'PM'
                ) {
                  setObj.okcontactid = list.contactid;
                }
              }
              // if (list.contacttype === 'Customer' && list.contactid == null && list.stageiterationcount == 1) {
              //     externalUsers.push({ role: list.roleid, name: list.contactname, email: list.contactemail, phone1: list.contactphone1 });
              // }
              setObj.itemcode = list.itemcode;
              setObj.title = list.title;
              setObj.isbillable = list.isbillable;
              setObj.projectbrief = list.projectbrief;
              setObj.composingsoftwareid = list.composingsoftwareid;
              setObj.colorid = list.colorid;
              setObj.languageid = list.languageid;
              setObj.inputfiletypeid = list.inputfiletypeid;
              setObj.eisbn = list.eisbn;
              setObj.printisbn = list.printisbn;
              setObj.issn = list.issn;
              setObj.edition = list.edition;
              setObj.celevelid = list.celevelid;
              setObj.itemcode = list.itemcode;
              setObj.indextypeid = list.indextypeid;
              setObj.customername = list.customername;
              setObj.division = list.division;
              setObj.subdivision = list.subdivision;
              setObj.wfname = list.wfname;
              setObj.wfname_bpmnid = list.wfname_bpmnid;
              setObj.status = list.status;

              setObj.totalchaptercount = list.totalchaptercount;
              setObj.otherfield = list.otherfield;
              setObj.category = list.category;
              setObj.logoid = list.logoid;
              setObj.dmsid = list.dmsid;
              setObj.trimsizewidth = list.trimsizewidth;
              setObj.trimsizewidthuom = list.trimsizewidthuom;
              setObj.trimsizeheight = list.trimsizeheight;
              setObj.trimsizeheightuom = list.trimsizeheightuom;
              setObj.orderemailpath = list.orderemailpath;
              setObj.orderemailpathuuid = list.orderemailpathuuid;
              setObj.ordermaildate = list.woordermaildate;
              setObj.incomingreportfileuuid = list.incomingreportfileuuid;
              setObj.incomingreportfilepath = list.incomingreportfilepath;
              // eslint-disable-next-line radix
              setObj.isServiceAdded = !!parseInt(list.isserviceadded);
              // eslint-disable-next-line radix
              setObj.isStageAdded = !!parseInt(list.isstageadded);

              setObj.journalid = list.journalid;
              setObj.jobtype = list.jobtype;
              setObj.doinumber = list.doinumber;
              setObj.newsletterdoiNumber = list.newsletterdoinumber;
              setObj.issuenumber = list.issuenumber;
              setObj.articleno = list.articleno;
              setObj.piino = list.piino;
              setObj.volumenumber = list.volumenumber;
              setObj.wotype = list.wotype;
              setObj.totalarticlecount = list.totalarticlecount;
              setObj.totalnonarticlecount = list.totalnonarticlecount;
              setObj.journalacronym = list.journalacronym;
              setObj.journalname = list.journalname;
              setObj.templateid = list.templateid;
              setObj.jobcardid = list.jobcardid;
              setObj.camundaform = list.camundaform;
              setObj.iworkflow = list.iworkflow;
              setObj.camundaform = list.camundaform;
              setObj.WoHardBackISBN = list.wohardbackisbn;
              setObj.WoPaperBackISBN = list.wopaperbackisbn;
              setObj.WoOcISBN = list.woocisbn;
              setObj.dmstype = list.dmstype;

              additionalObj.additionalinfoid = list.additionalinfoid;
              additionalObj.pitstopprofileid = list.pitstopprofileid;
              additionalObj.versoid = list.versoid;
              additionalObj.rectoid = list.rectoid;
              additionalObj.xmltemplateid = list.xmltemplateid;
              additionalObj.lastpageno = list.lastpageno;
              additionalObj.splittingid = list.splittingid;
              additionalObj.indexcorrectionid = list.indexcorrectionid;
              additionalObj.mscropneededid = list.mscropneededid;
              additionalObj.dispatchtypeid = list.dispatchtypeid;
              additionalObj.colorprofileid = list.colorprofileid;
              additionalObj.ocisbn = list.ocisbn;
              additionalObj.bookcategoryid = list.bookcategoryid;
              additionalObj.cssvalue = list.cssvalueid;
              additionalObj.style1 = list.style1;
              additionalObj.style2 = list.style2;
              additionalObj.style3 = list.style3;
              additionalObj.style4 = list.style4;
              additionalObj.style5 = list.style5;
              additionalObj.style6 = list.style6;
              additionalObj.medicalbook = list.medicalbook;
              additionalObj.hardbackisbn = list.hardbackisbn;
              additionalObj.paperbackisbn = list.paperbackisbn;
              additionalObj.watermarkid = list.watermarkid;
              additionalObj.smartmetadataid = list.smartmetadataid;
              additionalObj.dtdid = list.dtdid;
              additionalObj.onlinepdf = list.onlinepdfid;
              additionalObj.print = list.printid;
              additionalObj.addpdf = list.additionalpdfid;
              additionalObj.pdfless = list.pdfless;
              additionalObj.fpprofileid = list.fpprofileid;
              additionalObj.printprofile = list.bookprintid;
              additionalObj.o300id = list.o300id;
              additionalObj.s300id = list.s300id;
              additionalObj.rvsprofileid = list.rvsprofileid;
              additionalObj.indexcorrectionid = list.indexcorrectionid;
            });

            setObj.jobnormsId = !!(
              resForService.length && resForService[0].jobnormsid
            );
            if (resForService.length && resForService[0].complexityid) {
              const getJobnorms = await getWOJobnormsDetails(
                resForService[0].complexityid,
              );
              setObj = { ...setObj, ...getJobnorms, ...additionalObj };
            } else {
              setObj = { ...setObj, ...additionalObj };
            }

            setObj.wfcategory = resForService.length
              ? resForService[0].wfcategory
              : '';
            setObj.wfconfig = resForService.length
              ? resForService[0].wfconfig
              : '';
            setObj.externalUsers = await getExternalUsers(id);
            setObj.serviceid = resForService;
            setObj.wfid = resForService.length ? resForService[0].wfid : '';
            setObj.isbookcompleted = resForService.length
              ? resForService[0].isbookcompleted
              : false;
            setObj.checkWoChapterEntry = await checkWoChapterEntry(
              id,
              'chapter',
            );
            setObj.checkWoArticleEntry = await checkWoChapterEntry(
              id,
              'article',
            );
            setObj.checkWoNonArtcileEntry = await checkWoChapterEntry(
              id,
              'nonArticle',
            );
            console.log(setObj, 'setvaluesss');
            res.status(200).json({ data: setObj });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(200).json({ data: {} });
  }
};
export const getExternalUsers = id => {
  return new Promise((resove, reject) => {
    const sql = `SELECT wc.roleid as role, wc.contactname as name, wc.contactemail as email, wc.contactphone1 as phone1,
      r.roleacronym
      FROM wms_workorder_contacts wc
      JOIN public.wms_role r ON r.roleid = wc.roleid AND r.isactive = true 
        WHERE wc.workorderid=${id} AND wc.contacttype ='Customer' AND wc.contactid IS NULL`;

    query(sql)
      .then(data => {
        resove(data);
      })
      .catch(error => {
        reject(error);
      });
  });
};
export const getWOJobnormsDetails = id => {
  return new Promise((resove, reject) => {
    const sql = `SELECT complexityid, complexity FROM wms_mst_complexity WHERE complexityid=${id}`;
    console.log(sql, 'sql jobnorms details111');
    query(sql)
      .then(data => {
        if (data.length) {
          resove(data[0]);
        } else {
          resove({});
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};
export const checkWoChapterEntry = (id, type) => {
  return new Promise((resove, reject) => {
    let sql = '';
    if (type === 'article') {
      sql = `SELECT wwif.filetypeid, count(*)
            FROM wms_workorder_incoming 
            JOIN wms_workorder_incomingfiledetails AS wwif ON wwif.woincomingid = wms_workorder_incoming.woincomingid
            WHERE wms_workorder_incoming.woid=${id} AND wwif.filetypeid = 4
            GROUP BY wwif.filetypeid`;
    } else if (type === 'nonArticle') {
      sql = `SELECT wwif.filetypeid, count(*)
            FROM wms_workorder_incoming 
            JOIN wms_workorder_incomingfiledetails AS wwif ON wwif.woincomingid = wms_workorder_incoming.woincomingid
            WHERE wms_workorder_incoming.woid=${id} AND wwif.filetypeid = 9
            GROUP BY wwif.filetypeid`;
    } else {
      sql = `SELECT count(*)
            FROM wms_workorder_incoming 
            LEFT JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
            WHERE wms_workorder_incoming.woid=${id}`;
    }

    query(sql)
      .then(data => {
        if (data.length) {
          // eslint-disable-next-line radix
          resove(parseInt(data[0].count));
        } else {
          resove(0);
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};

export const getWOServiceList = (req, res) => {
  const reqData = req.body;

  const sql = `SELECT * FROM wms_workorder_service
    JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workorder_service.serviceid
    JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder_service.baseduid
    LEFT JOIN wms_workflow ON wms_workflow.wfid = wms_workorder_service.wfid
    WHERE workorderid = ${reqData.woId} AND org_mst_deliveryunit.duid = ${reqData.duId} ORDER BY sequence ASC `;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const deleteWoService = (req, res) => {
  const reqData = req.body;
  const sqlForService = `DELETE FROM wms_workorder_service WHERE woserviceid = ${reqData.woserviceId}`;

  query(sqlForService)
    .then(() => {
      const sqlForCheckStage = `SELECT * FROM wms_workorder_stage WHERE workorderid = ${reqData.workorderId} AND serviceid = ${reqData.serviceId} `;
      query(sqlForCheckStage)
        .then(resForCheckStage => {
          if (resForCheckStage.length > 0) {
            const sqlForStage = `DELETE FROM wms_workorder_stage WHERE workorderid = ${reqData.workorderId} AND serviceid = ${reqData.serviceId} `;
            query(sqlForStage)
              .then(() => {
                res
                  .status(200)
                  .json({ message: 'Record deleted successfully' });
              })
              .catch(error => {
                res.status(400).send({ message: error });
              });
          } else {
            res.status(200).json({ message: 'Record deleted successfully' });
          }
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// suradha ref
// this function will update the WO service
export const updateWoService = (req, res) => {
  const reqData = req.body;
  reqData.valuesOfArray.forEach((list, i) => {
    const sql = `UPDATE wms_workorder_service
        SET serviceid=${list.serviceid}, baseduid=${
      list.baseduid
    }, assignedduid=${list.assignedduid}, iscustomerbillable=${
      list.iscustomerbillable !== null ? list.iscustomerbillable : false
    }, 
        internalbilling=${list.internalbilling}, issharedjob=${
      list.issharedjob ? list.issharedjob : false
    }, wfid=${list.wfid},
        sequence=${i + 1}
        WHERE woserviceid = ${list.woserviceid} RETURNING  wfid`;

    query(sql)
      .then(response => {
        if (response.length > 0) {
          if (reqData.type === 'Save') {
            const sqlQuery = `SELECT DISTINCT ON(stageid) stageid, sequence
                    FROM wms_workflowdefinition
                    WHERE wfid IN (${list.wfid}) AND lock = false order by stageid,sequence`;

            query(sqlQuery)
              .then(resForStages => {
                console.log(resForStages, 'resForStages');

                if (resForStages.length) {
                  const values = [];
                  // resForStages = resForStages.sort((a, b) => parseFloat(a.sequence) - parseFloat(b.sequence));
                  resForStages.forEach(stage => {
                    values.push(
                      `(${list.serviceid},${stage.stageid},'${reqData.userid}',${list.workorderid}, 'YTS', 1, ${stage.sequence})`,
                    );
                  });

                  const sqlForCreateWOS = `INSERT INTO public.wms_workorder_stage(serviceid, wfstageid, updatedby, workorderid, status, stageiterationcount, sequence)
                                VALUES ${values} RETURNING workorderid`;

                  query(sqlForCreateWOS)
                    .then(resForCreateWOS => {
                      if (resForCreateWOS.length > 0) {
                        res.status(200).json({
                          data: {
                            id: resForCreateWOS[0].workorderid,
                          },
                          message: 'Services has been added successfully',
                        });
                      }
                    })
                    .catch(error => {
                      res.status(400).send({ message: error });
                    });
                } else {
                  res
                    .status(400)
                    .send({ message: 'Stages not found corresponding WF' });
                }
              })
              .catch(() => {
                res.status(400).send({ message: 'Stages not found' });
              });
          } else if (list.ischangedwfid) {
            deleteStageData(reqData, list, req, res);
          } else {
            res.status(200).json({
              message: 'Services has been updated successfully',
            });
          }
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  });
};

const deleteStageData = (reqData, list, req, res) => {
  const deleteSql = `DELETE FROM wms_workorder_stage WHERE workorderid = ${list.workorderid} AND serviceid = ${list.serviceid} `;

  query(deleteSql)
    .then(() => {
      const sql = `SELECT DISTINCT ON(stageid) stageid, sequence
            FROM wms_workflowdefinition
            WHERE wfid IN (${list.wfid})`;

      query(sql)
        .then(resForStages => {
          if (resForStages.length) {
            const values = [];
            resForStages.forEach(stage => {
              values.push(
                `(${list.serviceid},${stage.stageid},'${reqData.userid}',${list.workorderid}, 'YTS', 1)`,
              );
            });

            const sqlForCreateWOS = `INSERT INTO public.wms_workorder_stage(serviceid, wfstageid, updatedby, workorderid, status, stageiterationcount)
                        VALUES ${values} RETURNING workorderid`;

            query(sqlForCreateWOS)
              .then(resForCreateWOS => {
                if (resForCreateWOS.length > 0) {
                  res.status(200).json({
                    data: {
                      id: resForCreateWOS[0].workorderid,
                    },
                    message: 'Services has been added successfully',
                  });
                }
              })
              .catch(error => {
                res.status(400).send({ message: error });
              });
          } else {
            res
              .status(400)
              .send({ message: 'Stages not found corresponding WF' });
          }
        })
        .catch(() => {
          res.status(400).send({ message: 'Stages not found' });
        });
    })
    .catch(() => {
      res.status(400).send({ message: 'Faild to delete existing data' });
    });
};

// this function will get the overdue list
export const getOverDueList = (req, res) => {
  const reqData = req.body;
  if (reqData.userid == '') {
    res.status(400).send({ message: 'Userid should not be empty' });
  } else if (reqData.type == '') {
    res.status(400).send({ message: 'Type should not be empty' });
  } else if (reqData.pageNo == '') {
    res.status(400).send({ message: 'Page number should not be empty' });
  } else if (reqData.recordPerPage == '') {
    res.status(400).send({ message: 'Record per page should not be empty' });
  } else {
    let condition = ``;
    if (reqData.type !== 'filter') {
      reqData.searchObj.forEach((item, i) => {
        condition +=
          reqData.searchObj.length - 1 !== i
            ? item.name == 'status'
              ? `wms_workorder_duelist.${item.name} = '${item.value}' AND `
              : `wms_workorder_duelist.${item.name} = '${item.value}' OR `
            : `wms_workorder_duelist.${item.name} = '${item.value}'`;
      });
    }
    // else if (reqData.type === 'filter') {
    //   const { filtervalues, page } = reqData.searchObj;
    //   if (page === 'workorder') {
    //     const output = [];
    //     filtervalues.forEach(function (item) {
    //       const existing = output.filter(function (v) {
    //         return v.name == item.name;
    //       });
    //       if (existing.length) {
    //         const existingIndex = output.indexOf(existing[0]);
    //         output[existingIndex].value = output[existingIndex].value.concat(
    //           item.value,
    //         );
    //       } else {
    //         if (typeof item.value === 'string') item.value = [item.value];
    //         output.push(item);
    //       }
    //     });
    //     output.forEach(data => {
    //       data.setValue = '';
    //       data.value.forEach((data1, i) => {
    //         data.setValue += `'${data1}' ${
    //           data.value.length - 1 !== i ? ',' : ''
    //         }`;
    //       });
    //     });
    //     output.forEach((item, i) => {
    //       condition +=
    //         output.length - 1 !== i
    //           ? `wms_workorder_duelist.${item.name} IN (${item.setValue}) AND `
    //           : `wms_workorder_duelist.${item.name} IN (${item.setValue}) `;
    //     });
    //   }
    // }

    const sql = `SELECT COUNT(*) FROM public.wms_workorder_duelist WHERE duid = ${
      reqData.duId
    }  ${
      condition ? `${'AND '}${condition}` : condition
    } and (islock = false or islock is null) and overdue::bigInt>=1`;

    query(sql)
      .then(totalRecords => {
        if (totalRecords[0].count > 0) {
          getDueRecords(reqData, totalRecords[0].count, condition, res);
        } else {
          res.status(200).json({ data: [], message: 'No data found' });
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};
// getDueRecords will call inside the getOverDueList function
const getDueRecords = (reqData, total, condition, res) => {
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // const offset = (pageNo - 1) * recordPerPage;
  // const numOfPages = Math.ceil(total / reqData.recordPerPage);
  const sql = `SELECT * FROM public.wms_workorder_duelist WHERE duid = ${
    reqData.duId
  } ${
    condition ? `${'AND '}${condition}` : condition
  } and (islock = false or islock is null) and overdue::bigInt>=1 ORDER BY workorderid DESC`;

  query(sql)
    .then(data => {
      console.log('due record0', data, data.length);
      // var overdueList = [];
      // data.map((item, i) => {
      //     if (parseInt(item.overdue) >= 1) {
      //         overdueList.push(item)
      //     }
      // });
      res.status(200).json({ data, total });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageOverdueCount = (req, res) => {
  const reqData = req.body;
  const sql = `SELECT *, date_part('day'::text, CURRENT_TIMESTAMP::timestamp without time zone - plannedenddate::timestamp without time zone) AS overdue from (SELECT wms_wo_stagelist.*, wms_workorder_service.wfid, wms_workflow.wfname, wms_workflow.wfcategory FROM public.wms_wo_stagelist
            join wms_workorder_service on wms_workorder_service.serviceid = wms_wo_stagelist.serviceid and wms_workorder_service.workorderid = wms_wo_stagelist.workorderid
            join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
            WHERE wms_wo_stagelist.workorderid= ${reqData.workorderId}) as sageList ORDER BY wfstageid`;
  console.log(sql, 'sqloverduecountt');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeeefisdofd');
      res.status(200).send({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getBookComplete = (req, res) => {
  const reqData = req.body;
  const sql = `SELECT * FROM public.wms_workorder_service as woservice
        where woservice.workorderid = ${reqData.workorderId}`;
  console.log(sql, 'isbbobk');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeeefisdofd');
      res.status(200).send({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getAdditionalInfo = (req, res) => {
  const reqData = req.body;
  let sql = `SELECT service.workorderid,service.wfid,workflow.config FROM public.wms_workorder_service as service 
    left join wms_workflow as workflow on workflow.wfid = service.wfid
    where service.workorderid = ${reqData.workorderId}
    ORDER BY service.woserviceid ASC `;
  console.log(sql, 'isadditonalinfoo');
  query(sql)
    .then(data => {
      if (data.length && data[0].config.isAdditionalInfo == true) {
        sql = `SELECT * FROM public.wms_workorder_additionalinfo where workorderid = ${data[0].workorderid}
          ORDER BY additionalinfoid ASC `;
        console.log(sql, 'sqllllll');
        query(sql).then(innerdata => {
          console.log(innerdata, 'innnndnn');
          // console.log(data[0].config.isAdditionalInfo, innerdata[0].additionalinfoid,"odoodof")
          if (
            innerdata.length &&
            innerdata[0] &&
            innerdata[0].additionalinfoid
          ) {
            res.status(200).json({
              data: !!(
                data[0].config.isAdditionalInfo == true &&
                innerdata[0].additionalinfoid
              ),
            });
          } else {
            res.status(200).json({ data: !data[0].config.isAdditionalInfo });
          }
        });
      } else {
        res
          .status(200)
          .json({ data: data.length && !data[0].config.isAdditionalInfo });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get the filtered wo stage activity which are completed
// New getwostageactivity completedlist reset filter added new

export const getWoStageActivityCompletedList = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
  }

  sql = ` ;with cte as 
    (SELECT 
      row_number() over( partition by tsk.woincomingfileid,tsk.activityid order by tsk.actualactivitycount desc) as rno, 
     (select to_char(timestamp, 'DD/MM/YYYY HH:MM:SS')
      from wms_workflow_eventlog_details as ted where ted.wfeventid=tsk.wfeventid order by timestamp desc limit 1 ) as completedon,
       tsk.activitystatus, tsk.wfdefid , tsk.filename,tsk.woincomingfileid,
       tsk.stagename,tsk.activityalias,tsk.activityinstanceid,tsk.userid,
       tsk.wfeventid,tsk.workorderid,tsk.serviceid,tsk.stageid,tsk.activityid,tsk.activityinstanceid,    
       tsk.activitymodeltype,tsk.activitymodeltype,tsk.stageiterationcount,tsk.eventdata,
       tsk.parentinstanceid,tsk.activitymodeltypeflow,tsk.activityiterationcount,tsk.instancetype,  
       concat(tsk.username , ' (', tsk.userid, ')') as username,
       CASE WHEN tsk.filename IS NULL THEN 'Chapters' ELSE tsk.filename END as filename, tsk.sequence, tsk.wfid, tsk.filetypeskipfornextactivity
       FROM public.wms_tasklist tsk
       WHERE
       tsk.workorderid=${reqData.workorderId} AND tsk.serviceid=${
    reqData.serviceId
  } AND tsk.stageid=${reqData.stageId} 
       AND tsk.stageiterationcount=${reqData.stageIterationCount}) 
       select * from cte 
       where sequence <= coalesce((select max(sequence) from cte as tc where tc.activitystatus IN ('Unassigned', 'Work in progress', 'YTS' ) 
       and tc.woincomingfileid = woincomingfileid
       limit 1) ,10000000) and
       rno = 1  and activityid=${
         reqData.activityId
       } and activitystatus='Completed' ${
    condition ? ` AND${condition}` : condition
  } `;

  // sql = `select * from  (SELECT DISTINCT ON (tsk.filename)  ev.activitystatus, ev.wfdefid , tsk.filename,
  // tsk.stagename,tsk.activityalias,tsk.activityinstanceid,tsk.userid,
  // tsk.wfeventid,tsk.workorderid,tsk.serviceid,tsk.stageid,tsk.activityid,tsk.activityinstanceid,
  // tsk.activitymodeltype,tsk.activitymodeltype,tsk.stageiterationcount,tsk.eventdata,
  // tsk.parentinstanceid,tsk.activitymodeltypeflow,tsk.activityiterationcount,tsk.instancetype,
  // to_char(ed.timestamp, 'DD/MM/YYYY HH:MM:SS') AS completedon,
  // concat(tsk.username , ' (', tsk.userid, ')') as username,
  // CASE WHEN tsk.filename IS NULL THEN 'Chapters' ELSE tsk.filename END as filename
  // FROM public.wms_tasklist tsk
  // JOIN wms_workflow_eventlog ev  on ev.workorderid = tsk.workorderid and ev.wfdefid = tsk.wfdefid
  // JOIN wms_workflow_eventlog_details ed ON ed.wfeventid=ev.wfeventid
  // WHERE
  // tsk.workorderid=${reqData.workorderId} AND tsk.serviceid=${reqData.serviceId} AND tsk.stageid=${reqData.stageId} and tsk.activityid=${reqData.activityId}
  // AND ev.stageiterationcount=${reqData.stageIterationCount}
  // AND ev.activitystatus = 'Completed' AND coalesce(tsk.isinstancerunning, true) !=false AND tsk.filename not in (select distinct filename from
  //  public.wms_tasklist where workorderid=${reqData.workorderId}
  //  and activitystatus in ('Unassigned','Work in progress','YTS')
  //  and activityid = ${reqData.activityId}  ) AND sequence >= ${reqData.sequence}   ${condition ? 'AND' + condition : condition}) as res`

  query(sql)
    .then(getCount => {
      const numOfPages = Math.ceil(getCount.length / reqData.recordPerPage);

      const sqlForPagination = `${sql} `;

      query(sqlForPagination)
        .then(data => {
          res.status(200).json({
            data,
            total: getCount.length,
            numOfPages,
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWipActivityList = (req, res) => {
  const {
    woId,
    woIncomingFileId,
    instanceType,
    isCamundaFlow = true,
    stageId,
    stageIteractionCount,
    fromWfeventId,
  } = req.body;
  let condition = ``;
  let sql = ``;

  if (isCamundaFlow) {
    if (instanceType === 'Multiple') {
      condition += ` AND woincomingfileid = ${woIncomingFileId}`;
    }
    sql = `SELECT * FROM public.wms_workflow_eventlog where workorderid = ${woId} and activitystatus IN ('Work in progress', 'Hold') ${condition} `;
  } else {
    // Need to check for batch activity
    sql = `select ww.activityalias from
            public.wms_workflow_eventlog wwe
          join wms_workflowdefinition ww on ww.wfdefid = wwe.wfdefid
          where wwe.workorderid = ${woId} and ww.stageid = ${stageId} 
            and wwe.stageiterationcount = ${stageIteractionCount} and wwe.wfeventid >= ${fromWfeventId}
            and activitystatus in ('Work in progress', 'Hold')`;
  }
  query(sql)
    .then(response => {
      res.status(200).send({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// This function used to sent mail pm
export const mailTriggerForPM = async (reqData, filePath, mailAuditPayload) => {
  const {
    stage,
    wfeventId,
    iteration,
    workorder,
    customerid,
    journalid,
    stageid,
    stageiterationcount,
    wfDefId,
  } = reqData;

  return new Promise(async (resolve, reject) => {
    try {
      mailAuditPayload.status =
        'Inside pm review mail trigger function started';
      await pmRevieewEmailAudit(mailAuditPayload);

      let toMailArray = [];
      let cmName = '';
      let authorName = '';
      let editorName = '';

      const statusCheck = `select * from wms_email_audit where workorderid = ${workorder} and stageid =${stageid} and wfdefid =${wfDefId} and stageiterationcount = ${stageiterationcount}  and status ='queuepushed'`;
      const mailInfo = await query(statusCheck);

      if (mailInfo && mailInfo.length == 0) {
        mailAuditPayload.status = 'First time mail trigger function started';
        await pmRevieewEmailAudit(mailAuditPayload);

        const notify = `select * from journal_notification_config where journalid=${journalid} and stageid=${stageid} and (stageiterationcount=${stageiterationcount} or stageiterationcount = 1)
        and customerid=${customerid} and isactive=true order by stageiterationcount desc limit 1`;

        const resForConfig = await query(notify);

        if (
          resForConfig &&
          resForConfig.length > 0 &&
          resForConfig?.[0]?.emailconfig
        ) {
          mailAuditPayload.mailData.template = resForConfig[0].emailconfig;
          mailAuditPayload.status =
            'Inside pm review mail trigger function started';
          await pmRevieewEmailAudit(mailAuditPayload);

          const sql = `
        select roles.roleacronym, journal.journalemail, journal.journalacronym,journalcont.name,journalcont.email from pp_mst_journal as journal
              join pp_mst_journal_contacts as journalcont on journalcont.journalid = journal.journalid
            join wms_role as roles on roles.roleid= journalcont.designation :: bigint
              where journal.journalid =${journalid}`;
          console.log('sql', sql);
          const tomailList = await query(sql);

          if (resForConfig[0]?.emailconfig?.isAuthor) {
            const woContactSql = `select wocontacts.contactrole as roleacronym,
                wocontacts.contactemail as journalemail,
                wocontacts.contactrole as journalacronym,
                wocontacts.contactname as name,
                wocontacts.contactemail as email
                from wms_workorder_contacts as wocontacts
                where wocontacts.workorderid =${workorder} and roleid =7`;

            const toAuthormailList = await query(woContactSql);
            if (toAuthormailList && toAuthormailList.length > 0) {
              tomailList.push(toAuthormailList[0]);
            }
          }

          console.log(tomailList, 'tomailList');

          // tomailList.forEach(list => {
          //   resForConfig[0].emailconfig.to.forEach((sublist, i) => {
          //     if (list.roleacronym == sublist) {
          //       resForConfig[0].emailconfig.to[i] = list.email;
          //       cmName = list.name;
          //     }
          //   });
          // });

          // tomailList.forEach(list => {
          //   resForConfig[0].emailconfig.bcc.forEach((sublist, i) => {
          //     if (list.roleacronym == sublist) {
          //       resForConfig[0].emailconfig.bcc[i] = list.email;
          //     }
          //   });
          // });

          // tomailList.forEach(list => {
          //   resForConfig[0].emailconfig.cc.forEach((sublist, i) => {
          //     if (list.roleacronym == sublist) {
          //       resForConfig[0].emailconfig.cc[i] = list.email;
          //       cmName = list.name;
          //     }
          //   });
          // });

          ['to', 'cc', 'bcc'].forEach(type => {
            const updatedList = resForConfig[0].emailconfig[type].flatMap(
              sublist => {
                const matchedEmails = tomailList
                  .filter(list => list.roleacronym === sublist)
                  .map(list => list.email || list.journalemail)
                  .filter(email => email);
                return matchedEmails.length > 0 ? matchedEmails : [sublist];
              },
            );

            resForConfig[0].emailconfig[type] = [...new Set(updatedList)];
          });

          cmName = tomailList?.filter(list => list?.roleacronym == 'CM')?.[0]
            ?.name;
          editorName = tomailList?.filter(list => list?.roleacronym == 'E')?.[0]
            ?.name;
          authorName = tomailList?.filter(
            list => list?.roleacronym == 'AUTHOR',
          )?.[0]?.name;

          // To get pii numnber
          const piiRes = await query(
            `select otherfield ->> 'pii' as pii from wms_workorder where workorderid  =${workorder}`,
          );

          const piiitem = await query(
            `select j.journalacronym ||'_'|| (w.otherfield ->> 'pii')::text as itemcode from wms_workorder w
               join pp_mst_journal j on j.journalid = w.journalid
            where workorderid  =${workorder}`,
          );

          if (resForConfig.length > 0) {
            resForConfig[0].type = 'mail';
            const { type, emailconfig } = resForConfig[0];
            if (type === 'mail') {
              const outFiles = [];
              const fileNames = [];
              if (filePath.length > 0) {
                for (let i = 0; i < filePath.length; i++) {
                  const fileName = `${piiRes[0].pii}_R${stageiterationcount}.pdf`;
                  const out = await _download(filePath[i]);
                  if (out.path != '') {
                    outFiles.push(out);
                    fileNames.push(fileName);
                  } else {
                    mailAuditPayload.status =
                      'Unable to download attached pdf file';
                    await pmRevieewEmailAudit(mailAuditPayload);
                  }
                }
              }

              toMailArray = `;${resForConfig[0].emailconfig.to
                .toString()
                .split(',')
                .join(';')};`;

              resForConfig[0].emailconfig.to = '';
              const data = {
                actionType: type,
                ...emailconfig,
                jobId: piiitem[0].itemcode,
                cmName,
                subMessage: '',
                toMail: toMailArray,
                stage,
                iteration,
                wfeventId,
                outFiles: outFiles.length > 0 ? outFiles : '',
                fileNames: fileNames.length > 0 ? fileNames : '',
                editorName,
                authorName,
              };

              if (outFiles.length > 0 && filePath.length > 0) {
                mailAuditPayload.mailData.template = data;
                mailAuditPayload.status = 'queuepushed';
                await pmRevieewEmailAudit(mailAuditPayload);
                emitAction(data);

                mailAuditPayload.mailData = data;
                mailAuditPayload.status = 'queuepush completed';
                await pmRevieewEmailAudit(mailAuditPayload);
              } else {
                mailAuditPayload.status =
                  'Attached File Missing Please contact WMS Administrator';
                await pmRevieewEmailAudit(mailAuditPayload);
                reject(
                  'Attached File Missing Please contact WMS Administrator',
                );
              }

              resolve('success');
            }
          } else {
            mailAuditPayload.mailData.template = resForConfig?.[0]?.emailconfig;
            mailAuditPayload.status =
              'Failed sending email- mail template not mapped';
            await pmRevieewEmailAudit(mailAuditPayload);
            reject('Failed sending email- mail template not mapped');
          }
        } else {
          mailAuditPayload.status =
            'Journal Id Not Mapped,Please Contact WMS Administrator';
          await pmRevieewEmailAudit(mailAuditPayload);
          reject('Journal Id Not Mapped,Please Contact WMS Administrator');
        }
      } else {
        mailAuditPayload.status = 'Already mail triggered';
        await pmRevieewEmailAudit(mailAuditPayload);
        resolve('Alreay mail triggered!');
      }
    } catch (error) {
      mailAuditPayload.status = 'Mail trigger pm review final catch error';
      mailAuditPayload.mailData.template = error;
      await pmRevieewEmailAudit(mailAuditPayload);

      reject(`'Failed sending email' ${error}`);
    }
  });
};

export const getWoDetailsForFTP = async (req, res) => {
  try {
    const { jobname, stage, customer, stageiterationcount } = req.body;
    const sql = `select * from public.getstageuploadpath('${jobname}','${stage}','${customer}')`;
    const result = await query(sql);
    if (result.length) {
      const filepathpayload = {
        type: 'wo_stage_iteration_mail',
        du: { name: result[0].duname, id: result[0].duid },
        customer: {
          name: result[0].customername,
          id: result[0].cutomerid,
        },
        workOrderId: result[0].workorderid,
        service: {
          name: result[0].servicename,
          id: result[0].serviceid,
        },
        stage: {
          name: result[0].stagename,

          id: result[0].stageid,
          iteration: stageiterationcount,
        },
      };
      const fileuploadpath = await getFolderStructure_autowocreate({
        body: filepathpayload,
      });
      res.status(200).send({ data: fileuploadpath });
    } else {
      res.status(400).send({ message: 'path structure forming failed' });
    }
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const getWoDetailsForOUP = async (req, res) => {
  try {
    const { jobname, stage, customer, activity, activityId } = req.body;
    const sql = `with cte as (
SELECT row_number() over(partition by wos.wfstageid order by wos.stageiterationcount desc)as nrow,  wo.workorderid,wo.itemcode, st.stageid, st.stagename, srv.serviceid,srv.servicename,du.duid,du.duname,
      cust.customerid ,cust.customername,winf.woincomingfileid,wos.stageiterationcount  
      FROM public.wms_workorder AS wo
      JOIN public.wms_workorder_stage AS wos ON wo.workorderid = wos.workorderid
      JOIN public.wms_mst_stage AS st ON st.stageid = wos.wfstageid AND st.isactive = true
      JOIN public.org_mst_customer AS cust ON cust.customerid = wo.customerid AND cust.isactive= true
      JOIN public.wms_mst_service AS srv ON srv.serviceid = wos.serviceid AND srv.isactive = true
      JOIN public.org_mst_customer_orgmap AS orgmap on orgmap.customerid = wo.customerid 
      and orgmap.divisionid = wo.divisionid and orgmap.subdivisionid = wo.subdivisionid and 
      orgmap.countryid = wo.countryid and orgmap.isactive = 1
      join public.org_mst_customerorg_du_map custdu on custdu.custorgmapid = orgmap.custorgmapid
      join public.org_mst_deliveryunit as du on du.duid = custdu.duid and du.isactive = true
      join public.wms_workorder_incoming wi on wi.woid = wo.workorderid
      join public.wms_workorder_incomingfiledetails winf on winf.woincomingid = wi.woincomingid
      WHERE wo.itemcode = '${jobname}' AND st.stagename = '${stage}' and cust.customername  = '${customer}'
      ) 
      select * from cte where nrow = 1`;

    const result = await query(sql);
    if (result.length) {
      const filepathpayload = {
        type: 'wo_activity_file_subtype',
        du: { name: result[0].duname, id: result[0].duid },
        customer: {
          name: result[0].customername,
          id: result[0].customerid,
        },
        workOrderId: result[0].workorderid,
        service: {
          name: result[0].servicename,
          id: result[0].serviceid,
        },
        stage: {
          name: result[0].stagename,

          id: result[0].stageid,
          iteration: result[0].stageiterationcount,
        },
        activity: {
          name: activity,
          id: activityId,
          iteration: 1,
        },
        fileType: {
          name: 'article',
          id: 4,
          fileId: result[0].woincomingfileid,
        },
      };
      const fileuploadpath = await getFolderStructure_autowocreate({
        body: filepathpayload,
      });
      res.status(200).send({ data: fileuploadpath });
    } else {
      res.status(400).send({ message: 'path structure forming failed' });
    }
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const _getWoDetailsForFTP = async ({
  jobname,
  stage,
  customer,
  stageiterationcount,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select * from public.getstageuploadpath('${jobname}','${stage}','${customer}')`;
      const result = await query(sql);
      if (result.length) {
        const filepathpayload = {
          type: 'wo_stage_iteration_mail',
          du: { name: result[0].duname, id: result[0].duid },
          customer: {
            name: result[0].customername,
            id: result[0].cutomerid,
          },
          workOrderId: result[0].workorderid,
          service: {
            name: result[0].servicename,
            id: result[0].serviceid,
          },
          stage: {
            name: result[0].stagename,

            id: result[0].stageid,
            iteration: stageiterationcount,
          },
        };
        const fileuploadpath = await getFolderStructure_autowocreate({
          body: filepathpayload,
        });
        resolve(fileuploadpath);
      } else {
        reject('path structure forming failed');
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getConvertionFilesList = async (req, res) => {
  try {
    const { wfeventId, stageId, workorderid } = req.body;

    const filesLogQuery = `select convertionfiles from acs_convertionfile_details where workorderid = ${workorderid} and stageid = ${stageId} ORDER BY id DESC LIMIT 1 `;

    const filesLog = await query(filesLogQuery);

    if (filesLog.length > 0) {
      return res.status(200).json(filesLog[0].convertionfiles);
    }
    const fileQuery = `SELECT repofilepath, 
     (
    SELECT COUNT(*) 
    FROM public.wms_workflowactivitytrn_file_map 
    WHERE wfeventid = ${wfeventId} AND repofilepath LIKE '%\\_si\\_%' ESCAPE '\\'
    ) AS si_count
    
    FROM public.wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfeventId}  AND repofilepath LIKE '%_weo_%';`;
    const files = await query(fileQuery);
    if (files.length == 0) {
      return res.status(200).json(files);
    }
    const result = files.map((f, index) => {
      const filename = f.repofilepath.split('/').pop(); // e.g. am3c15802_weo_0010.jpg

      // Extract base (e.g. "am3c15802"), extension (e.g. "jpg"), and si_count
      const [basePart] = filename.split('_weo_'); // remove '_weo_' part
      const extension = filename.split('.').pop(); // file extension

      const siCount = parseInt(f.si_count || '0', 10); // fallback to 0
      const newIndex = siCount + index + 1; // ensure increment per file
      const paddedIndex = String(newIndex).padStart(4, '0'); // "0001"

      return {
        filename,
        updatedFilename: `${basePart}_si_${paddedIndex}.${extension}`,
      };
    });

    return res.status(200).json(result);
  } catch (error) {
    return res
      .status(400)
      .json({ message: error.message || 'An error occurred' });
  }
};

export const createConvertionFilesLog = async (req, res) => {
  try {
    const {
      workorderId,
      stageId,
      activityId,
      stageIterationCount,
      customerId,
      convertionFiles,
      userId,
      actualActivityCount,
      wfeventId,
      duid,
    } = req.body;

    const insertQuery = `
      INSERT INTO public.acs_convertionfile_details (
        workorderid,
        stageid,
        activityid,
        stageiterationcount,
        customerid,
        convertionfiles,
        isactive,
        created_by,
        updated_by,
        activityiterationcount,
        wfeventid,
        duid
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING id;
    `;

    const values = [
      workorderId,
      stageId,
      activityId,
      stageIterationCount,
      customerId,
      convertionFiles,
      true,
      userId,
      userId,
      actualActivityCount,
      wfeventId,
      duid,
    ];

    const result = await query(insertQuery, values);
    res.status(200).json(result);
  } catch (error) {
    console.error('Insert Error:', error);
    res.status(400).json({ message: error.message || 'An error occurred' });
  }
};
