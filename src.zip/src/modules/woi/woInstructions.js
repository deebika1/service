/* eslint-disable prefer-const */
import { query } from '../../database/postgres.js';
import {
  triggerMsgEvent,
  triggervariableEvent,
} from '../utils/wfTrigger/trigger.js';

export const chapterWorkOrder = async bookworkorderid => {
  try {
    const chapterWordOrder = await query(
      `SELECT * from wms_book_workorder_details where bookworkorderid  = ${bookworkorderid}`,
    );
    return chapterWordOrder;
  } catch (error) {
    return error;
  }
};

export const woInstructions = async (req, res) => {
  const { userId, date, type, text, wostageinstid, wotype, woId, customerid } =
    req.body;

  let { wostageids } = req.body;
  let chapterInsertedIds = [];
  let insertedIds = [];
  const isBookWorkOrder = wotype === 'Book';
  let chapterWoId = [];

  if (wostageinstid?.length > 1) {
    const woStageQuery = await query(
      `
        SELECT wostageid
        FROM wms_workorder_stage
        WHERE workorderid = $1;
      `,
      [woId],
    );
    wostageids = woStageQuery.map(row => row.wostageid);
    if (isBookWorkOrder) {
      const chapterWoIDQuery = await query(
        `SELECT workorderid from wms_book_workorder_details where bookworkorderid = ${woId}`,
      );
      chapterWoId = chapterWoIDQuery.map(item => item.workorderid);
    }
  }

  try {
    if (type === 'update') {
      if (!Array.isArray(wostageinstid) || wostageinstid.length === 0) {
        return res
          .status(400)
          .json({ message: 'wostageinstid must be provided for update.' });
      }
    } else {
      const insertSQL = `
    INSERT INTO wms_workorder_stage_instructions (
        wostageid,isforallstages, insttext, addedon, addedby
        ) VALUES ($1, $2, $3, $4, $5)
      RETURNING wostageinstid;
      `;

      const insertPromises = wostageids.map(wostageid =>
        query(insertSQL, [
          wostageid,
          wostageids.length > 1,
          text,
          date,
          userId,
        ]),
      );

      const results = await Promise.all(insertPromises);
      insertedIds = results.flat();

      if (customerid == 12 && chapterWoId.length) {
        const stageQuery = `
        SELECT wostageid
        FROM wms_workorder_stage
        WHERE workorderid = ANY($1::int[]);
      `;
        const stageResult = await query(stageQuery, [chapterWoId]);
        const chapterWostageids = stageResult.map(row => row.wostageid);

        if (chapterWostageids.length) {
          const chapterinsertSQL = `
          INSERT INTO wms_workorder_stage_instructions (
              wostageid, isforallstages, insttext, addedon, addedby
          ) VALUES ($1, $2, $3, $4, $5)
          RETURNING wostageinstid;
        `;

          const ChapterInsertPromises = chapterWostageids.map(wostageid =>
            query(chapterinsertSQL, [
              wostageid,
              true,
              text,
              new Date().toISOString(),
              userId,
            ]),
          );

          const chapterResults = await Promise.all(ChapterInsertPromises);
          chapterInsertedIds = chapterResults.flat();
          console.log('Inserted WOI for chapter stages:', chapterInsertedIds);
        } else {
          console.warn('No wostageids found for given chapterWoIds.');
        }
      }
    }
    if (type === 'update') {
      //   const deleteSQL = `
      //   DELETE FROM wms_workorder_stage_instructions
      //   WHERE wostageinstid = $1;
      // `;

      const chapterWorkList = await chapterWorkOrder(woId);
      if (chapterWorkList.length) {
        const chapterWorkOrderId = chapterWorkList.map(x => x.workorderid);
        if (chapterWorkOrderId.length) {
          const stageQuery = `
          SELECT wostageid
          FROM wms_workorder_stage
          WHERE workorderid = ANY($1::int[]);
        `;
          const stageResult = await query(stageQuery, [chapterWorkOrderId]);
          const chapterWostageids = stageResult.map(row => row.wostageid);
          const oldChapterInstructionList = await query(
            `select * from wms_workorder_stage_instructions where wostageid = ANY($1::int[]);`,
            [chapterWostageids],
          );
          const oldChapterInstructionId = oldChapterInstructionList.map(row =>
            parseInt(row.wostageinstid),
          );

          // let wostageids = chapterInsertedIds.map((list => parseInt(list.wostageinstid)))
          // for (let oldId of oldChapterInstructionId) {
          //   for (let newObj of chapterInsertedIds) {
          //     await query(updateSQL, [newObj.wostageinstid, oldId]);
          //   }
          // }
          let newStageIstructionsIds = [
            ...oldChapterInstructionId,
            ...wostageinstid,
          ];
          const updateSQL = `
          UPDATE wms_workorder_stage_instructions
          SET insttext = '${text}', addedon = CURRENT_TIMESTAMP , addedby = '${userId}'
          WHERE wostageinstid in(${newStageIstructionsIds});
        `;
          const updatePromises = await query(updateSQL);
          await Promise.all(updatePromises);

          console.log(updateSQL);

          // for (let oldId of oldChapterInstructionId) {
          //   await query(deleteSQL, [oldId]);
          // }
        }
      }

      // for (let oldId of wostageinstid) {
      //   for (let newObj of insertedIds) {
      //     await query(updateSQL, [newObj.wostageinstid, oldId]);
      //   }
      // }

      // for (let oldId of wostageinstid) {
      //   await query(deleteSQL, [oldId]);
      // }
    }

    return res.status(200).json({
      data: [...insertedIds, ...chapterInsertedIds],
      message:
        type === 'update'
          ? 'Instructions updated successfully'
          : 'Instructions inserted successfully',
    });
  } catch (e) {
    console.error('woInstructions error:', e);
    return res.status(500).json({
      message: 'Failed to insert/update instructions',
      error: e.message,
    });
  }
};

export const woInstructionsFiles = async (req, res) => {
  const { wostageinstid, filepath, fileuuid, userId, date, type } = req.body;

  if (!Array.isArray(wostageinstid) || wostageinstid.length === 0) {
    return res
      .status(400)
      .json({ message: 'wostageinstid must be a non-empty array.' });
  }

  if (!filepath || !fileuuid || !userId || !date || !type) {
    return res
      .status(400)
      .json({ message: 'Missing required fields in request.' });
  }

  try {
    if (type === 'insert') {
      const insertSQL = `
        INSERT INTO wms_workorder_stage_instructionfiles (
          instfilepath,
          instfileuuid,
          addedon,
          addedby,
          wostageinstid
        ) VALUES ($1, $2, $3, $4, $5)
      `;

      const insertPromises = wostageinstid.map(stageInstId =>
        query(insertSQL, [filepath, fileuuid, date, userId, stageInstId]),
      );

      await Promise.all(insertPromises);

      return res.status(200).json({
        message: 'File successfully mapped to all instructions.',
        mappedTo: wostageinstid,
      });
    }

    return res.status(400).json({ message: 'Invalid type provided.' });
  } catch (e) {
    console.error('woInstructionsFiles error:', e);
    return res.status(500).json({
      message: 'File mapping to instructions failed.',
      error: e.message,
    });
  }
};

export const getWOI = async (req, res) => {
  try {
    const { woId } = req.body;

    const bookDetailsQuery = `select wo.workorderid from wms_book_master as bm
left join wms_workorder as wo on wo.itemcode = bm.bookid
where bm.id = (select bookid from wms_workorder where workorderid = ${woId})`;

    const bookDataResult = await query(bookDetailsQuery);
    let overAllWoId;
    console.log(bookDataResult);
    if (
      bookDataResult &&
      bookDataResult.length > 0 &&
      bookDataResult[0].workorderid != woId
    ) {
      overAllWoId = `( ${woId},${bookDataResult[0].workorderid} )`;
    } else {
      overAllWoId = `( ${woId} )`;
    }
    const sql = `
      WITH total_stage_map AS (
        SELECT serviceid, ARRAY_AGG(wostageid ORDER BY wostageid) AS all_wostages
        FROM wms_workorder_stage
        WHERE workorderid in ${overAllWoId}
        GROUP BY serviceid
      ),
      instruction_group AS (
        SELECT 
          s.insttext,
          s.addedby,
          s.isforallstages,
          MIN(s.addedon) AS addedon,
          ARRAY_AGG(s.wostageid ORDER BY s.wostageid) AS stageids,
          stg.serviceid,
          svc.servicename,
          u.username,
          COUNT(*) as stagecount,
          ARRAY_AGG(s.wostageinstid ORDER BY s.wostageid) AS wostageinstid,
          MAX(stg.workorderid) AS workorderid,
          MAX(stg.stageiterationcount) AS stageiterationcount,
          STRING_AGG(stgname.stagename || '(' || stg.stageiterationcount || ')', ', ') AS stagename,
          MAX(stg.wostageid) AS wostageid,
          STRING_AGG(f.instfilepath, ',') AS instfilepath,
          STRING_AGG(f.instfileuuid, ',') AS instfileuuid
        FROM wms_workorder_stage_instructions s
        JOIN wms_workorder_stage stg ON s.wostageid = stg.wostageid
        JOIN wms_mst_stage stgname ON stg.wfstageid = stgname.stageid
        JOIN wms_mst_service svc ON stg.serviceid = svc.serviceid
        LEFT JOIN wms_user u ON u.userid::text = s.addedby::text
        LEFT JOIN wms_workorder_stage_instructionfiles f ON f.wostageinstid = s.wostageinstid
        WHERE stg.workorderid in ${overAllWoId}
        GROUP BY s.insttext, s.addedby, stg.serviceid, svc.servicename, u.username, s.isforallstages
      )
      SELECT 
        ig.insttext,
        ig.addedby,
        ig.addedon,
        ig.serviceid,
        ig.servicename,
        ig.isforallstages,
        ig.username || '(' || ig.addedby || ')' AS addedbyname,
        ig.wostageinstid,
        STRING_AGG(ig.stageids::text, ',') AS wostageid,
        ig.workorderid,
        ig.stageiterationcount,
        ig.instfilepath,
        ig.instfileuuid,
        CASE 
          WHEN ig.stageids = ts.all_wostages THEN 'ALL'
          ELSE ig.stagename
        END AS stagename
      FROM instruction_group ig
      JOIN total_stage_map ts ON ig.serviceid = ts.serviceid
      GROUP BY 
        ig.insttext, ig.addedby, ig.addedon, ig.serviceid, ig.servicename, 
        ig.username, ig.wostageinstid, ig.stageids, ig.workorderid, ig.isforallstages,
        ig.stageiterationcount, ig.stagename, ig.instfilepath, ig.instfileuuid, ts.all_wostages
      ORDER BY ig.addedon DESC;
    `;

    const fileResultsQuery = `
          SELECT 
            f.wostageinstfilesid,
            f.instfilepath,
            f.instfileuuid,
            f.wostageinstid
          FROM wms_workorder_stage_instructionfiles f
          JOIN wms_workorder_stage_instructions s ON s.wostageinstid = f.wostageinstid
          JOIN wms_workorder_stage stg ON stg.wostageid = s.wostageid
          WHERE stg.workorderid in ${overAllWoId};
        `;

    const fileResults = await query(fileResultsQuery);
    // Group file results by wostageinstid
    const fileMap = [];
    for (const file of fileResults) {
      if (!fileResults.length) {
        return;
      }
      fileMap.push({
        wostageinstfilesid: file.wostageinstfilesid,
        instfilepath: file.instfilepath,
        instfileuuid: file.instfileuuid,
        filename: file.instfilepath?.split('/').pop() || '',
      });
    }
    const WOIData = await query(sql);
    let result = WOIData.map(list => {
      const stageId = list.wostageid.replace(/[{}]/g, '').split(',');
      if (stageId.length > 1) {
        return {
          ...list,
          stagename: 'All',
        };
      }
      return {
        ...list,
      };
    });
    const chapterWorkList = await chapterWorkOrder(woId);
    if (chapterWorkList.length) {
      const chapterWorkOrderId = chapterWorkList.map(x => x.workorderid);
      if (chapterWorkOrderId.length) {
        const stageQuery = `
        SELECT wostageid
        FROM wms_workorder_stage
        WHERE workorderid = ANY($1::int[]);
      `;
        const stageResult = await query(stageQuery, [chapterWorkOrderId]);
        const chapterWostageids = stageResult.map(row => row.wostageid);
        const chapterInstructionList = await query(
          `select * from wms_workorder_stage_instructions where wostageid = ANY($1::int[]);`,
          [chapterWostageids],
        );

        const chapterGroupedMap = {};

        for (const item of chapterInstructionList) {
          const key = item.insttext;
          if (!chapterGroupedMap[key]) {
            chapterGroupedMap[key] = {
              wostageid: [],
              wostageinstid: [],
            };
          }

          chapterGroupedMap[key].wostageid.push(item.wostageid);
          chapterGroupedMap[key].wostageinstid.push(item.wostageinstid);
        }

        const chapterData = Object.entries(chapterGroupedMap).map(
          ([insttext, data]) => ({
            insttext,
            wostageid: `{${data.wostageid.join(',')}}`,
            wostageinstid: data.wostageinstid,
          }),
        );

        for (const r of result) {
          if (r.insttext && r.isforallstages) {
            const match = chapterData.find(c => c.insttext === r.insttext);
            if (match) {
              r.wostageid = match.wostageid;
              r.wostageinstid = match.wostageinstid;
            }
          }
        }
      }
    }
    res.status(200).json({ data: [...result, { files: fileMap }] });
  } catch (error) {
    console.error('getWOI error:', error);
    res.status(400).send({ message: error.message || error });
  }
};

export const edittWOI = async (req, res) => {
  let sql = '';
  try {
    const { id, woId, serviceid, stageid, despatch, vi } = req.body;
    sql = `SELECT DISTINCT ON (wms_workorder_stage.wostageid,files.wostageinstfilesid)
       inst.*, 
       files.*, 
       wms_workorder_stage.wostageid,
       wms_workorder_stage.wfstageid,
       wms_workorder_stage.workorderid,
       wms_mst_stage.stagename,
       wms_workorder_stage.stageiterationcount,
       wms_workorder_service.assignedduid AS duid,
       org_mst_deliveryunit.duname,
       wms_workorder_stage.serviceid,
       wms_workorder_stage.plannedstartdate,
       wms_workorder_stage.plannedenddate,
       wms_workorder_stage.startdate,
       wms_workorder_stage.enddate,
       wms_workorder_stage.updatedby,
       wms_workorder_stage.ordermaildate,
       wms_workorder_stage.deliverymodeid,
       wms_workorder_stage.updatedon,
       wms_workorder_stage.status,
       wms_workorder_stage.emailpath,
       wms_workorder_stage.emailpathuuid,
       wms_mst_service.servicename,
       wms_workorder_stage.ismilestone,
       wms_workorder_stage.sequence,
       wms_workorder_stage.startdatetime,
       wms_workorder_stage.enddatetime,
       wms_workorder_stage.ordermaildatetime,
       wms_workorder_stage.revisedenddatetime
FROM wms_workorder_stage_instructions inst
LEFT JOIN wms_workorder_stage_instructionfiles files 
    ON files.wostageinstid = inst.wostageinstid
JOIN wms_workorder_stage 
    ON wms_workorder_stage.wostageid = inst.wostageid
JOIN wms_mst_stage 
    ON wms_workorder_stage.wfstageid = wms_mst_stage.stageid
JOIN wms_mst_service 
    ON wms_workorder_stage.serviceid = wms_mst_service.serviceid
JOIN wms_workorder_service 
    ON wms_workorder_service.serviceid = wms_workorder_stage.serviceid
JOIN org_mst_deliveryunit 
    ON org_mst_deliveryunit.duid = wms_workorder_service.assignedduid `;
    if (!despatch) {
      sql += ` where inst.wostageinstid=${id}`;
    } else if (vi) {
      sql += `where wms_workorder_stage.workorderid=${woId} and wms_workorder_stage.wfstageid=${stageid} and
            wms_workorder_stage.serviceid=${serviceid}`;
    } else {
      sql += `where wms_workorder_stage.workorderid=${woId} and wms_workorder_stage.wostageid=${stageid} and
                wms_workorder_stage.serviceid=${serviceid}`;
    }
    sql += ' order by files.wostageinstfilesid';

    const WOIeditData = await query(sql);

    res.status(200).json({ data: WOIeditData });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};
export const deleteWOI = async (req, res) => {
  try {
    const { wostageinstfilesid } = req.body;
    const sql = `Delete FROM public.wms_workorder_stage_instructionFiles where wostageinstfilesid in (${wostageinstfilesid})`;
    const WOIDeleteData = await query(sql);
    res.status(200).json({ data: WOIDeleteData });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};
export const getStageList = async (req, res) => {
  try {
    const { woId } = req.body;
    const sql = `SELECT stm.stagename||'('||wos.stageiterationcount::text||')' AS stagename, stm.stagename AS stage, wos.wostageid,wos.status, wos.wfstageid,wser.serviceid,serv.servicename, wser.wfid, wf.wfname, wf.wfcategory FROM wms_workorder as wo 
    JOIN PUBLIC.wms_workorder_stage AS wos on wos.workorderid = wo.workorderid JOIN public.wms_workorder_service  as wser ON wser.workorderid = wo.workorderid 
    JOIN public.wms_mst_stage AS stm ON stm.stageid = wos.wfstageid JOIN public.wms_workflow as wf ON wf.wfid = wser.wfid JOIN public.wms_mst_service as serv on serv.serviceid = wser.serviceid 
    WHERE wo.workorderid =${woId} ORDER BY wos.wfstageid`;
    const WOIStageList = await query(sql);
    res.status(200).json({ data: WOIStageList });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const triggerMessage = async (req, res) => {
  try {
    const { itemCode, messageName, processVariables, woId } = req.body;
    let sql;
    if (!itemCode) {
      sql = `SELECT distinct  eventdata->>'processInstanceId' as processinstanceid FROM public.wms_workflow_eventlog where
      workorderid = ${woId}`;
    } else {
      sql = `Select distinct eventdata->>'processInstanceId' as processinstanceid from wms_workorder wo
      inner join wms_workflow_eventlog el on el.workorderid = wo.workorderid  
      where itemcode='${itemCode}'`;
    }

    console.log(sql);
    const data = await query(sql);
    const processInstanceId = data[0].processinstanceid;
    const result = await triggerMsgEvent(
      processInstanceId,
      messageName,
      processVariables,
    );
    res.send({ status: true, ...result });
  } catch (error) {
    res.send({ status: false, ...error });
    console.log(error);
  }
};
export const triggerVariable = async (req, res) => {
  try {
    const { woid, varStatus, camundaVariable, itemCode } = req.body;
    let sql;
    if (!itemCode) {
      sql = `SELECT distinct  eventdata->>'processInstanceId' as processinstanceid FROM public.wms_workflow_eventlog where
      workorderid = ${woid}`;
    } else {
      sql = `Select distinct eventdata->>'processInstanceId' as processinstanceid from wms_workorder wo
      inner join wms_workflow_eventlog el on el.workorderid = wo.workorderid  
      where itemcode='${itemCode}'`;
    }
    const data = await query(sql);
    const processInstanceId = data[0].processinstanceid;
    const result = await triggervariableEvent(
      processInstanceId,
      varStatus,
      camundaVariable,
    );
    res.send({ status: true, ...result });
  } catch (error) {
    res.send({ status: false, ...error });
    console.log(error);
  }
};
export const getwoidACS = async (req, res) => {
  try {
    const { itemCode } = req.body;
    const sql = `	select workorderid from wms_workorder where  itemcode ='${itemCode}'`;

    console.log(sql);
    const data = await query(sql);
    // const processInstanceId = data[0].workorderid;
    res.status(200).send(data);
  } catch (error) {
    res.send({ status: false, ...error });
    console.log(error);
  }
};
