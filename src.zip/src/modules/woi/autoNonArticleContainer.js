/* eslint-disable no-unused-vars */
/* eslint-disable */
import { transaction, query } from '../../database/postgres.js';
import { _upload } from '../utils/azure/index.js';
import { emitAction } from '../activityListener/index.js';
import { getNotificationTemplate } from '../common/index.js';
import { elsevierArticleSchema } from './schema.js';
import { validator } from '../../helper/validator.js';
import { createJob, checkItracksExits } from '../iTracks/index.js';
import { _autoIncomingForArticleElsevier } from './incoming.js';
import { workorderlog } from './woAutocreation.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import { _nextIssueStageTransferCheckTrigger } from '../task/action/workflow/save.js';

const service = new Service();

const jobTypeObj = {
  1: 'Article',
  2: 'Issue',
  3: 'Non Article',
};
let mailContainer = {
  action: '',
  from: '',
  to: '',
  customerName: '',
  customerId: '',
  stageName: '',
  iteration: '',
  subject: '',
  template: '',
  text: '',
};
let logId = 0;

// Article creation Module
export const autoNonArticleWorkorderCreation = async (req, res) => {
  try {
    const payload = req.body;
    const response = await _nonArticleCreationContainer(payload);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};
// create auto issue workorder creation
export const _nonArticleCreationContainer = async payload => {
  return new Promise(async (resolve, reject) => {
    const { issueDetails, articleDetails, generalDetails } = data;
    // latest update changed multiple wo creationns
    let payload = {
      ...generalDetails,
    };
    const payloadArray = [];
    try {
      const logRes = await woCreateLog(data, 'Insert');
      logId = logRes.autologid;
      // for loop for multiple article details
      for (let i = 0; i < articleDetails.length; i++) {
        let item = articleDetails[i];
        // get extention with dot from file name
        const ext = item.extention.lastIndexOf('.')
          ? item.extention.substr(item.extention.lastIndexOf('.'))
          : item.extention;
        item.extention = ext;
        item = { ...item, ...generalDetails };
        item.issueDetails = issueDetails;
        // construct payload for workorder creation
        payload = await constructPayloadForWorkorderCreation(payload);
        payloadArray.push(payload);
      }
      const promises = [];
      // Make multiple API calls in a loop
      payloadArray.forEach(async item => {
        promises.push(makeApiCallInLoop(item));
      });
      // Use Promise.all() to wait for all promises to resolve
      Promise.all(promises)
        .then(results => {
          resolve({
            message: 'Workorder created successfully',
            status: true,
            workorderId: results.map(list => list.workorderId).join(','),
          });
        })
        .catch(e => {
          reject({
            message: e.message ? e.message : e,
            status: false,
          });
        });
    } catch (e) {
      if (payload.customerId) {
        mailContainer.customerId = payload.customerId;
        mailContainer.action = 'auto_create_failure';
      } else {
        mailContainer.action = 'auto_create_common_failure';
        // get customer details from customer name
        const sql = `SELECT customerid FROM org_mst_customer WHERE LOWER(customername) = LOWER('${payload.customer}')`;
        const response = await query(sql);
        const customerId = response.length ? response[0].customerid : 0;
        mailContainer.customerId = customerId;
      }
      mailContainer.woTypeId = payload.woTypeId;
      mailContainer.subject = mailContainer.subject
        ? mailContainer.subject
        : `Work order creation failed for the title ${payload.title}`;
      mailContainer.message = e.message ? e.message : e;
      mailContainer.title = payload.title;
      mailContainer.stageName = payload.stage;
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      payload.isStagetrigger = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject({
        message: e.message ? e.message : e,
        status: false,
      });
    }
  });
};

// workorder create log
const woCreateLog = (data, action) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        customer,
        jobType,
        woType,
        workorderId,
        logMessage,
        isSuccess,
        isStagetrigger,
        title,
        stage,
        ftpAuditId,
        extention,
      } = data;
      let sql = ``;
      if (action == 'Insert') {
        sql = `INSERT INTO log_autowocreate(apiinput,customer,filetype,wotype,jobtype,trigerarticle,trigerstage,ftpauditid) VALUES ('${JSON.stringify(
          data,
        )}', '${customer}','${extention}','${woType}','${jobType}','${title}','${stage}',${ftpAuditId}  ) RETURNING autologid`;
      } else {
        sql = `UPDATE public.log_autowocreate
        SET customer='${customer}', filetype='${extention}', wotype='${woType}', jobtype='${jobType}', payload='${JSON.stringify(
          data,
        )}', workorderid=${
          workorderId || null
        }, logmessage='${logMessage}', issuccess=${isSuccess}, isstagetrigger=${
          isStagetrigger || false
        }, trigerarticle='${title}', trigerstage='${
          stage || null
        }', ftpauditid=${ftpAuditId}

        WHERE autologid=${logId} RETURNING autologid`;
      }
      const response = await query(sql);
      resolve(response[0]);
    } catch (e) {
      reject(e);
    }
  });
};

// construct payload for workorder creation
const constructPayloadForWorkorderCreation = async item => {
  return new Promise(async (resolve, reject) => {
    const { customer, jobType } = item;
    try {
      // get journal information from customer and journal acronym
      const journalDetail = await getCustomerJournalDetail(item);
      if (journalDetail) {
        // change string to integer from journalDetails array
        journalDetail.customer = parseInt(journalDetail.customer);
        journalDetail.division = parseInt(journalDetail.division);
        journalDetail.subDivision = parseInt(journalDetail.subDivision);
        journalDetail.country = parseInt(journalDetail.country);
        journalDetail.duId = parseInt(journalDetail.duId);
        journalDetail.colours = parseInt(journalDetail.colours);
        journalDetail.softwares = parseInt(journalDetail.softwares);
        journalDetail.languages = parseInt(journalDetail.languages);
        journalDetail.CELevel = parseInt(journalDetail.CELevel);
        journalDetail.journalId = parseInt(journalDetail.journalId);
        journalDetail.custOrgMapId = parseInt(journalDetail.custOrgMapId);
        journalDetail.services = journalDetail.serviceId;
        journalDetail.custPrimaryContact = journalDetail.primaryContact;
        journalDetail.custSecondaryContact = journalDetail.secondaryContact;
        journalDetail.kamName = journalDetail.KAMContact;
        journalDetail.clientManager = journalDetail.CMContact;
        // create payload for workorder creation
        const jobTypeId = Object.keys(jobTypeObj).find(
          key => jobTypeObj[key] === jobType,
        );
        let sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE duid=$1 and customerid=$2`;
        const dmsInfo = await query(sql, [
          journalDetail.duId,
          journalDetail.customer,
        ]);
        const { dmsid } = dmsInfo.length ? dmsInfo[0] : '';
        if (dmsid) {
          const externalUsers = JSON.parse(item.externalUsers);
          const payload = {
            ...item,
            ...journalDetail,
            customerId: journalDetail.customer,
            userId: item.createdBy,
            doiNumber: item.title,
            jobId: item.title,
            jobTitle: item.description,
            jobTypeId: jobTypeId,
            externalUsers: [].concat(
              journalDetail.editorDetails,
              externalUsers,
            ),
            noOfChapters: 1,
            pageWidth: journalDetail.trimesizewidth,
            pageWidthUnit: journalDetail.trimesizewidthuom,
            pageHeight: journalDetail.trimesizeheight,
            pageHeightUnit: journalDetail.trimesizeheightuom,
            dmsId: dmsid,
            otherFields: item.otherdetails,
          };
          resolve(payload);
        } else {
          mailContainer.action = 'common_failure';
          mailContainer.subject = `DMS type not mapping for the customer ${customer}`;
          mailContainer.message = `DMS type not mapping for the customer ${customer}`;
          throw new Error(`DMS type not mapping for the customer ${customer}`);
        }
      } else {
        mailContainer.action = 'common_failure';
        mailContainer.subject = `Work order creation failed for due to journal details not found for the customer ${customer}`;
        mailContainer.message = `Journal details not found for the customer ${customer}`;
        throw new Error(
          `Journal details not found for the customer ${customer}`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Make API call in loop with promise all using axios for workorder creation
const makeApiCallInLoop = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // check iTracks exists for customer
      const iPayload = {
        customerId: payload.customer,
        duId: payload.duId,
        userId: payload.createdBy,
      };
      const { status } = await checkItracksExits({ body: iPayload }, {});
      let jobStatus = true;

      if (status) {
        // fields validation with specific error messages for workorder creation
        if (!payload) {
          throw new Error('Payload is required');
        }
        // const validate = validator(payload, kliSchema);
        // if (!validate.status) {
        //   throw new Error(validate.message);
        // }
        // const woExists = await checkWOExists(payload);
        //  create job card in iTracks
        // jobStatus = await createJob(payload);
      }
      // check title already exists
      if (jobStatus) {
        const result = await autoWorkorderCreation(payload);
        const { data, message } = result;
        // const data = {
        //   workorderid: '2317',
        //   serviceid: '1',
        //   issuemstid: '2',
        // };
        if (true) {
          // auto incoming creation
          const incomingPayload = await constructIncomingPayload(payload);
          const resOfIncoming = await _autoIncomingForArticleElsevier(
            incomingPayload,
          );
        }
        // payload for mail
        mailContainer.action = 'auto_create_success';
        mailContainer.woTypeId = payload.woTypeId;
        mailContainer.subject = `Work order creation successfull for the title ${payload.title}`;
        mailContainer.message = message;
        mailContainer.customerId = payload.customerId;
        mailContainer.title = payload.title;
        mailContainer.stageName = payload.stage;
        // payload for workorder log
        payload.logMessage = message;
        payload.isSuccess = true;
        payload.workorderId = workorderId;
        payload.isStagetrigger = true;
        await woCreateLog(payload, 'Update');
        await sendMail(mailContainer);
        resolve({
          message: message,
          status: true,
          data: {
            workorderId: workorderId,
          },
        });
      } else {
        throw new Error('Job creation failed in iTracks');
      }
      // } else {
      //   mailContainer.action = 'common_failure';
      //   mailContainer.subject = `Work order creation failed for due to iTracks not found for the customer ${payload.customerName}`;
      //   mailContainer.message = `iTracks not found for the customer ${payload.customerName}`;
      //   mailContainer.customerId = payload.customer;
      //   throw new Error('iTracks not found for customer');
      // }
    } catch (e) {
      // Mail trigger for error
      mailContainer = {
        action: 'auto_create_failure',
        articlename: payload.articleName,
        to: [],
        customerId: payload.customer,
        duId: payload.duId,
        serviceId: payload.services,
        subject: `Work order creation failed for the title - ${payload.articleName}`,
        message: e.message ? e.message : e,
      };
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject(e);
    }
  });
};

// workorder creation
const woCreationProcess = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // check iTracks exists for customer
      const iPayload = {
        customerId: payload.customer,
        duId: payload.duId,
        userId: payload.createdBy,
      };
      const { status } = await checkItracksExits({ body: iPayload }, {});
      let jobStatus = true;
      // to be changed once itracks enabled
      if (status) {
        //  create job card in iTracks
        jobStatus = await createJob(payload);
      }
      if (jobStatus) {
        let result = {};
        await transaction(async client => {
          result = await creation(payload, client);
        });
        const { data, message } = result;
        payload.workorderId = data.workorderid;
        resolve({ workorderId: data.workorderid, status: true, message });
      } else {
        throw new Error('Job creation failed in iTracks');
      }
    } catch (e) {
      // Mail trigger for error
      mailContainer = {
        action: 'auto_create_failure',
        woTypeId: payload.woTypeId,
        title: payload.title,
        to: [],
        customerId: payload.customer,
        stageName: payload.stage,
        duId: payload.duId,
        subject: `Work order creation failed for the title - ${payload.title}`,
        message: e.message ? e.message : e,
      };
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject(e);
    }
  });
};

export const checkWOExists = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { title, doiNumber } = data;
      const job = title ? title.trim() : '';
      const doi = doiNumber ? doiNumber.trim() : '';
      let condition = `WHERE itemcode='${job}'`;
      if (doi) {
        condition = `WHERE itemcode='${job}'  OR doinumber='${doi}'`;
      }

      const sql = `SELECT itemcode FROM public.wms_workorder ${condition} `;
      console.log(sql, 'sql for wo exists');
      const result = await query(sql);
      if (result.length) {
        reject({
          status: false,
          message: `Workorder already exists for the title - ${title}`,
        });
      } else {
        resolve({
          status: true,
          message: `Workorder not exists for the title - ${title}`,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        action,
        woTypeId,
        title,
        to,
        customerId,
        workorderId,
        serviceId,
        duId,
        message,
        stageName,
      } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        woTypeId,
        duId,
        customerId,
        workorderId,
        serviceId,
        stageName,
      };
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        stageName,
        subMessage: message,
        toMail: toMailArray,
      };
      emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      console.log(e, 'ee');
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};

// get journal details from customer and journal acronym
const getCustomerJournalDetail = data => {
  const { customer, journalAcronym, duId } = data;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `select a.colorid::bigint as colours ,a.softwareid::bigint  as softwares ,a.languageid::bigint as languages ,a.celevelid::bigint as  "CELevel",a.printissn as "printISSN" ,
        b.divisionid::bigint as division ,b.subdivisionid::bigint as "subDivision",b.countryid::bigint as country ,b.customerid::bigint as  customer,d.duid as "duId",
        a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
        a.journalid as "journalId"
        from pp_mst_journal a
              JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
              JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
              JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid AND d.duid=${duId}
              JOIN org_mst_customer e on e.customerid=b.customerid
              where a.isactive = 1 AND b.isactive = 1
              AND (LOWER(e.customername) = LOWER('${customer}')
              or  LOWER(e.customershortname) = LOWER('${customer}')
              )
              AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;
      const journalRes = await query(sql);
      if (journalRes.length) {
        sql = `select * from org_mst_customerorg_contact where custorgmapid=${journalRes[0].custOrgMapId}`;
        const journalContactRes = await query(sql);
        sql = ` select * from pp_mst_journal as journal join pp_mst_journal_contacts as journalcontact on
          journalcontact.journalid=journal.journalid where journal.journalacronym = '${journalAcronym}'`;
        const journalOtherContactRes = await query(sql);

        const journalInfo = journalRes[0];
        journalContactRes.forEach(list => {
          if (list.isprimary && list.contacttype === 'Customer') {
            journalInfo.primaryContact = list.custorgconmapid;
          } else if (!list.isprimary && list.contacttype === 'Customer') {
            journalInfo.secondaryContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'KAM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.KAMContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'CM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.CMContact = list.custorgconmapid;
          }
        });
        if (journalOtherContactRes.length) {
          let ecInfo = journalOtherContactRes.filter(
            list => list.designation == 10,
          );
          journalInfo.editorDetails = ecInfo.map(item => {
            return {
              name: item.name,
              role: '10',
              email: item.email,
              roleAcronym: 'EC',
            };
          });
        }

        resolve(journalInfo);
      } else {
        reject({
          message: `Journal details not found for the customer ${customer} `,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Workorder creation with transaction
export const creation = async (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { emailOrderDate } = data;
      const orderDate = emailOrderDate
        ? `'${emailOrderDate}'`
        : 'current_timestamp';

      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          if (data[key] === undefined) {
            data[key] = null;
          }
        }
      }
      let otherFields = data.otherFields;

      if (typeof otherFields !== 'string') {
        otherFields = JSON.stringify(otherFields);
      }

      // insert query for workorder creation in wms_workorder table
      let sql = `INSERT INTO public.wms_workorder(
        itemcode, title, projectbrief, printisbn, eisbn, issn, edition, customerid, 
        divisionid, subdivisionid, countryid, colorid, composingsoftwareid, inputfiletypeid, 
        languageid, celevelid, indextypeid, category, status, trimsizewidth, trimsizewidthuom,
        trimsizeheight, trimsizeheightuom, orderemailpath, orderemailpathuuid, totalchaptercount, 
        ordermaildate, journalid, jobtype, doinumber, wotype, totalarticlecount, totalnonarticlecount, 
        issuenumber, volumenumber, jobcardid, dmsid, createdby, duid, wfid, otherfield
        )
        VALUES (
          '${data.jobId}', 
          '${data.jobTitle}',
          ${data.projectBrief ? `'${data.projectBrief}'` : null},
          ${data.printISBN ? `'${data.printISBN}'` : null},
          ${data.eISBN ? `'${data.eISBN}'` : null},
          ${data.ISSN ? `'${data.ISSN}'` : null},
          ${data.edition ? `'${data.edition}'` : null},
          ${data.customer ? data.customer : null}, 
          ${data.division ? data.division : null}, 
          ${data.subDivision ? data.subDivision : null}, 
          ${data.country ? data.country : null},
          ${data.colours ? data.colours : null}, 
          ${data.softwares ? data.softwares : null}, 
          ${data.inputFileTypes ? data.inputFileTypes : 4},
          ${data.languages ? data.languages : null}, 
          ${data.CELevel ? data.CELevel : null}, 
          ${data.indexType ? data.indexType : null},
          ${data.category ? `'${data.category}'` : null}, 
          'In Process',
          ${data.pageWidth ? data.pageWidth : null},
          ${data.pageWidthUnit ? `'${data.pageWidthUnit}'` : null},
          ${data.pageHeight ? data.pageHeight : null},
          ${data.pageHeightUnit ? `'${data.pageHeightUnit}'` : null},
          ${data.orderEmailPath ? `'${data.orderEmailPath}'` : null},
          ${data.orderEmailPathUuid ? `'${data.orderEmailPathUuid}'` : null},
          ${data.noOfChapters ? data.noOfChapters : null}, 
          ${orderDate ? orderDate : null}, 
          ${data.journalId ? data.journalId : null}, 
          ${data.jobTypeId ? `'${data.jobTypeId}'` : null}, 
          ${data.doiNumber ? `'${data.doiNumber}'` : null},
          ${data.woType ? `'${data.woType}'` : null}, 
          ${!isNaN(parseInt(data.noOfArticles)) ? data.noOfArticles : null},
          ${
            !isNaN(parseInt(data.noOfNonArticles)) ? data.noOfNonArticles : null
          },
          ${data.issueNumber ? `'${data.issueNumber}'` : null}, 
          ${data.volumeNumber ? `'${data.volumeNumber}'` : null}, 
          ${data.jobCardId ? data.jobCardId : null}, 
          ${data.dmsId ? data.dmsId : null}, 
          ${data.userId ? `'${data.userId}'` : 'System'}, 
          ${data.duId ? data.duId : null}, 
          ${data.wfId ? data.wfId : null},
          '${otherFields}'
        ) RETURNING workorderid, customerid`;
      const response = await query(sql);
      const { workorderid } = response[0];
      // insert query for workorder contact details in wms_workorder_contact table
      // get contact detsils from org_mst_customerorg_contact_map table
      const getContactValues = `SELECT ${workorderid},custorgconmapid, contactname,contactemail,contactphone1,contactphone2,contactroleid,contacttype,isprimary 
          FROM org_mst_customerorg_contact WHERE custorgconmapid IN (${
            data.custPrimaryContact
          },${data.custSecondaryContact},
              ${data.kamName},${data.clientManager} ${
        data.subDivision !== 9 ? `,'${data.projectManager}'` : ''
      }) `;

      sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary)
          ${getContactValues} 
          RETURNING workorderid`;

      await client.query(sql);
      // insert query for pm entry to wms_workorder_contact table
      if (data.subDivision == 9) {
        const journalMappedPm = await workorderJournalMappedPmEntry(
          {
            projectManager: data.projectManager,
            supplierProjectManager: data.supplierProjectManager,
            workorderid,
          },
          client,
        );
      }
      let externalUserRes = [];
      if (
        data.externalUsers &&
        Object.keys(data.externalUsers).length &&
        data.externalUsers !== '{}'
      ) {
        externalUserRes = await workorderExternalUserEntry(
          { externalUsers: data.externalUsers, workorderid },
          client,
        );
      }
      const serviceResponse = await workorderServiceEntry(
        {
          duId: data.duId,
          services: data.services,
          custOrgMapId: data.custOrgMapId,
          workorderid,
          wfId: data.wfId,
        },
        client,
      );
      const { serviceid } = serviceResponse.data;
      await workorderStageEntry(
        {
          workorderid,
          wfId: data.wfId,
          serviceId: serviceid,
          userId: data.userId,
          plannedStartDate: data.plannedStartDate,
          plannedEndDate: data.plannedEndDate,
          receivedDate: data.plannedStartDate,
        },
        client,
      );
      // TAT calculation for stages
      await tatCalculationForStages(
        {
          workorderid,
          customerId: data.customer,
          journalId: data.journalId,
        },
        client,
      );
      resolve({
        data: { workorderid },
        message: `workorder created successfully (${workorderid})`,
      });
    } catch (e) {
      reject(e);
    }
  });
};

// journal mapped pm entry insert into wms_workorder_contact table
const workorderJournalMappedPmEntry = (payload, client) => {
  const { projectManager, supplierProjectManager, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${projectManager}' AND wms_userrole.roleid = 1
      UNION ALL
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${supplierProjectManager}' AND wms_userrole.roleid = 9
      `;

      const { rows } = await client.query(sql);
      let userArray = rows;
      if (projectManager == supplierProjectManager) {
        userArray = [].concat(rows, rows);
      }

      const val = [];
      userArray.forEach((list, i) => {
        val.push(`(${workorderid},'${list.contactname}','${
          list.contactemail
        }','${list.contactphone1}',
    '${list.roleacronym}', 'Integra' , ${i == 0}, '${list.userid}',${
          list.roleid
        })`);
      });
      sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, 
    contactphone1, contactrole, contacttype, isprimary, userid, roleid)
    VALUES ${val} RETURNING workorderid`;

      await client.query(sql);
      resolve({
        message: `Journal mapped pm added successfully (${workorderid})`,
      });
    } catch (e) {
      reject({ message: `Journal mapped pm added failed (${workorderid})` });
    }
  });
};
// external user entry insert into wms_workorder_contact table
const workorderExternalUserEntry = (payload, client) => {
  const { externalUsers, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const val = [];
      externalUsers.forEach(list => {
        val.push(`(${workorderid},'${list.name}','${list.email}',${
          list.phone1 ? `'${list.phone1}'` : null
        },
              '${list.roleAcronym}', 'Customer' , false, ${list.role})`);
      });

      const sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, contactphone1, contactrole, contacttype, isprimary, roleid)
              VALUES ${val} RETURNING contactrole,contactname,contactemail `;

      await client.query(sql);
      resolve({ message: `External user added successfully (${workorderid})` });
    } catch (e) {
      reject({ message: `External user added failed (${workorderid})` });
    }
  });
};
// workorder service entry insert into wms_workorder_service table
const workorderServiceEntry = (payload, client) => {
  const { duId, services, custOrgMapId, workorderid, wfId } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const getDataQuery = `SELECT DISTINCT ON ( org_mst_customerorg_service_map.serviceid) org_mst_customerorg_service_map.serviceid,org_mst_deliveryunit.duid, org_mst_deliveryunit.duid as assignedduid, org_mst_deliveryunit.duid as internalbilling,true, ${workorderid}, ${wfId}, 'YTS' as status
      FROM org_mst_customerorg_service_map
      JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customerorg_service_map.custorgmapid
      JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = org_mst_customerorg_du_map.duid
      WHERE  org_mst_customerorg_service_map.serviceid IN (${services}) AND org_mst_customerorg_service_map.custorgmapid = ${custOrgMapId}
      AND org_mst_deliveryunit.duid = ${duId}`;
      const sql = `INSERT INTO public.wms_workorder_service(serviceid, baseduid, assignedduid,internalbilling,iscustomerbillable ,workorderid, wfid, status)
      ${getDataQuery} RETURNING woserviceid, workorderid, serviceid`;

      const { rows } = await client.query(sql);
      resove({
        message: `Service added successfully (${workorderid})`,
        data: { ...rows[0] },
      });
    } catch (e) {
      reject({ message: `Service added failed (${workorderid})` });
    }
  });
};
// workorder stage entry insert into wms_workorder_stage table
const workorderStageEntry = (payload, client) => {
  const {
    workorderid,
    wfId,
    serviceId,
    userId,
    plannedStartDate,
    plannedEndDate,
    receivedDate,
  } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const sqlQuery = `with cte as (SELECT DISTINCT ON(stageid) stageid, sequence
      FROM wms_workflowdefinition
      WHERE wfid IN (${wfId}) AND lock = false ) select * from cte order by sequence`;

      const { rows } = await client.query(sqlQuery);
      if (rows.length) {
        const values = [];
        rows.forEach((stage, i) => {
          if (i === 0) {
            values.push(
              `(${serviceId},${
                stage.stageid
              },'${userId}',${workorderid}, 'YTS', 1, ${
                i + 1
              }, current_timestamp, current_timestamp, ${
                plannedEndDate ? `'${plannedEndDate}'` : `current_timestamp`
              }, ${receivedDate ? `'${receivedDate}'` : `current_timestamp`} )`,
            );
          } else {
            values.push(
              `(${serviceId},${stage.stageid},'${userId}',${workorderid}, 'YTS', 1, ${stage.sequence}, current_timestamp, null, null, null)`,
            );
          }
        });
        const sql = `INSERT INTO public.wms_workorder_stage(serviceid, wfstageid, updatedby, workorderid, status, stageiterationcount, sequence, updatedon, plannedstartdate, plannedenddate, ordermaildatetime)
        VALUES ${values} RETURNING workorderid`;

        await client.query(sql);
        resove({ message: `Stage added successfully (${workorderid})` });
      } else {
        reject({ message: `No stages found the workorder (${workorderid})` });
      }
    } catch (e) {
      reject({ message: `Stage added failed (${workorderid})` });
    }
  });
};
// TAT calculation update for stages in wms_workorder_stage table
const tatCalculationForStages = (payload, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderid, customerId, journalId } = payload;
      const sql = `UPDATE wms_workorder_stage AS st SET plannedstartdate = cte.p_startdate ,plannedenddate = cte.p_duedate 
			FROM get_wo_autocreation_tat(${workorderid}::bigint,${customerId}:: bigint,${journalId}::bigint,1::integer) AS cte
			WHERE cte.p_wostageid = st.wostageid;`;

      await client.query(sql);
      resolve({ message: 'Stage TAT updated successfully' });
    } catch (e) {
      reject({ message: 'Stage TAT updated failed' });
    }
  });
};

// create incoming payload for auto incoming creation
export const constructIncomingPayload = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const file = [
        {
          filetypeid: '',
          filetype: '',
          jobType: payload.jobType,
          filename: payload.title,
          extention: payload.extention,
          filepath: payload.sourcePath ? payload.sourcePath : null,
          fileuuid: '',
          duedate: payload.dueDate,
          mspages: payload.msPages,
          imagecount: payload.images,
          estimatedpages: 0,
          tablecount: 0,
          equationcount: 0,
          boxcount: 0,
          wordcount: 0,
          referencecount: 0,
          filesequence: 1,
        },
      ];
      const incomingPayload = {
        workorderId: payload.workorderId,
        files: file,
        jobType: payload.jobType,
        fileType: payload.fileType,
        isGraphic: !!payload.images,
      };
      resolve(incomingPayload);
    } catch (e) {
      reject(e);
    }
  });
};
