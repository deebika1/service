import { basename } from 'path';
import { query } from '../../database/postgres.js';
import { _localdownload } from '../utils/local/index.js';
import { config } from '../../config/restApi.js';
import { _getUuid } from '../utils/okm/index.js';
import * as azureHelper from '../utils/azure/index.js';
import { uploadFileToSFTP, getsftpConfig } from '../filetransferkit/index.js';
import { emitAction } from '../activityListener/index.js';

export const getCurrentZipFileStatus = async (req, res) => {
  try {
    const sql = `select *
     from springer.ice_zipfilesinoutfolder
     where islocked = 'N' and currentfilestatusid = '${req.query.currentfilestatusid}' and filetype='${req.query.filetype}'
     order by positioninqueue asc;`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const sendNotificationMail = async (req, res) => {
  try {
    const { attachmentFileNameWithPath, customerID, action } = req.body;
    const sql = `SELECT * from wms_notifications WHERE customerid=${customerID} and action='${action}' and isactive = true`;
    const filePath = [];
    const fileNames = [];
    const outFiles = [];
    const attachmentFileName = basename(attachmentFileNameWithPath);
    const resnotification = await query(sql);
    const { type, notificationconfig } = resnotification[0];
    if (attachmentFileNameWithPath.length > 0) {
      filePath.push(attachmentFileNameWithPath, {
        data: { path: attachmentFileNameWithPath },
      });
    }
    if (attachmentFileName.length > 0) {
      fileNames.push(attachmentFileName);
    }
    if (type == 'mail') {
      if (filePath.length > 0) {
        const out = await _localdownload(filePath[0]);
        if (out.path != '') {
          outFiles.push(out);
        }
      }
    }
    const mailData = {
      actionType: type,
      ...notificationconfig,
      ...req.body,
      outFiles: outFiles.length > 0 ? outFiles : '',
      fileNames: fileNames.length > 0 ? fileNames : '',
    };
    emitAction(mailData);
    res.status(200).send({ data: 'Mail send success.', isSuccess: true });
  } catch (error) {
    res.status(400).send({ message: error.message, isSuccess: false });
  }
};
export const tablePackageUpdateSpringerBooks = async (req, res) => {
  try {
    const jsonobj = req.body;
    const iDivisionID = 12;
    const sql = `Select jobcodeid,currentstageid,isoasislicensereceived,isoasisworkflow from springer.ice_mstpackage where 
    bookseriesid='${jsonobj.bookSeriesId}' and jobcode='${jsonobj.jobCode}'and islocked='N' and isactive ='Y'`;
    const out = await query(sql);
    if (out.length == 0) {
      const sqlInsert = `INSERT INTO springer.ice_mstpackage(divisionid, jobcode, jobtype, bookid, bookseriesid, peusername, peuseremail_id, sourcezipfileid, currentstageid, islocked, isactive, jobsheetfilename, receiveddate,createddate,isoasisworkflow,isoasislicensereceived)
      VALUES(${iDivisionID},'${jsonobj.jobCode}','${jsonobj.fileType}','${jsonobj.bookID}',
      '${jsonobj.bookSeriesId}','${jsonobj.productionEditorName}','${jsonobj.productionEditorEmailId}',
      '${jsonobj.zipFileId}','${jsonobj.stageID}','N','Y','${jsonobj.jobSheetFileName}','${jsonobj.jobReceivedDate}',(now()::timestamp(0) + interval '330 minute'),'${jsonobj.isOASISWorkFlow}','${jsonobj.isOASISLicenseReceived}')RETURNING jobcodeid`;

      const jobcodeid = await query(sqlInsert);
      res.status(200).json({ data: jobcodeid[0].jobcodeid, status: 'Success' });
    } else if (jsonobj.stageID == 300) {
      let sqlupdate = '';
      if (jsonobj.isOASISWorkFlow == 'Y') {
        sqlupdate = `update springer.ice_mstpackage set isoasisworkflow='Y' where 
        bookseriesid='${jsonobj.bookSeriesId}' and jobcode='${jsonobj.jobCode}'and islocked='N' and isactive ='Y'`;
        await query(sqlupdate);
      } else if (jsonobj.isOASISLicenseReceived == 'Y') {
        sqlupdate = `update springer.ice_mstpackage set isoasisworkflow='Y',isoasislicensereceived='Y' where 
       bookseriesid='${jsonobj.bookSeriesId}' and jobcode='${jsonobj.jobCode}'and islocked='N' and isactive ='Y'`;
        await query(sqlupdate);
      }

      res.status(200).json({ data: out[0].jobcodeid, status: 'Success' });
    } else if (out[0].currentstageid != jsonobj.stageID) {
      const getRepJobDetails = await GetNewFileandRepeatedFileDetails(
        `${jsonobj.jobCode}`,
        `${jsonobj.stageID}`,
        `${jsonobj.bookSeriesId}`,
        `${jsonobj.zipFileId}`,
      );
      await insertRepeatedJobDetails(getRepJobDetails, jsonobj.stageID);
      res.status(200).json({ data: out[0].jobcodeid, status: 'Success' });
    } else {
      res.status(200).json({ data: out[0].jobcodeid, status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};
async function insertRepeatedJobDetails(getRepJobDetails, repeatedStageID) {
  let returnValue = false;
  try {
    const sqlRepInsetrt = `INSERT INTO springer.ICE_RepeatedJobDetails (JobCodeId, JobDetailsId, filenamewithtimestamp, RepeatedStage, CurrentStage, receiveddate, createdby, isactive)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`;
    const params = [
      getRepJobDetails.Newjobcodeid,
      getRepJobDetails.Newjobdetailsid,
      getRepJobDetails.NewZipfilename,
      `${repeatedStageID}`,
      getRepJobDetails.Newjobstage,
      getRepJobDetails.NewDownloadedDate,
      'ICE',
      'Y',
    ];

    const result = await query(sqlRepInsetrt, params);

    if (result.length > 0) {
      returnValue = true;
    }
  } catch (error) {
    returnValue = false;
  }
  return returnValue;
}

async function GetNewFileandRepeatedFileDetails(
  Repjobcode,
  repstage,
  bookseriesid,
  Repeatedzipfileid,
) {
  let returnValue = false;
  let Newjobcode = '';
  let Newjobcodeid = 0;
  let Newjobdetailsid = 0;
  let Newjobstage = 0;
  let Newzipfileid = 0;
  let Newjobfilesize = 0;
  let NewZipfilename = '';
  let NewDownloadedDate = '';
  let repeatedjobfilesize = 0;

  try {
    let sql = `SELECT a.jobcode, a.JobCodeId, a.CurrentStageId, b.jobdetailsid, b.sourcezipfileid
                 FROM springer.ICE_MstPackage a
                 JOIN springer.ice_jobdetails b ON b.jobcodeid = a.jobcodeid
                 WHERE a.bookseriesid = $1 AND a.isActive = 'Y' AND a.islocked = 'N' AND b.isActive = 'Y'
                 ORDER BY a.jobcodeid DESC`;
    const params = [bookseriesid.trim()];
    const result = await query(sql, params);

    if (result.length > 0) {
      Newjobstage = parseInt(result[0].currentstageid);

      if (
        Newjobstage === 200 ||
        Newjobstage === 300 ||
        Newjobstage === 600 ||
        repstage === 200 ||
        repstage === 300 ||
        repstage === 600
      ) {
        Newjobcode = result[0].jobcode;
        Newjobcodeid = parseInt(result[0].jobcodeid);
        Newjobdetailsid = parseInt(result[0].jobdetailsid);
        Newzipfileid = parseInt(result[0].sourcezipfileid);
      } else {
        sql = `SELECT TOP 1 a.jobcode, a.JobCodeId, a.CurrentStageId, b.jobdetailsid, b.sourcezipfileid
                     FROM springer.ice_mstpackage a
                     JOIN springer.ice_jobdetails b ON b.jobcodeid = a.jobcodeid
                     WHERE a.jobcode LIKE $1 AND a.isActive = 'Y' AND b.jobcodeid = a.jobcodeid AND b.isActive = 'Y'`;
        const params2 = [Repjobcode.trim()];
        const result2 = await query(sql, params2);

        if (result2.length > 0) {
          Newjobcode = result2[0].jobcode;
          Newjobcodeid = parseInt(result2[0].jobcodeid);
          Newjobdetailsid = parseInt(result2[0].jobdetailsid);
          Newzipfileid = parseInt(result2[0].sourcezipfileid);
          Newjobstage = parseInt(result2[0].currentstageid);
        }
      }
    }

    sql = `SELECT filenamewithtimestamp, originalfilesize, downloadendtime
             FROM springer.ice_zipfilesinoutfolder
             WHERE zipfileid = $1`;
    const params3 = [Newzipfileid];
    const dtResult = await query(sql, params3);

    if (dtResult.length > 0) {
      Newjobfilesize = parseInt(dtResult[0].originalfilesize);
      NewZipfilename = dtResult[0].filenamewithtimestamp;
      NewDownloadedDate = new Date(dtResult[0].downloadendtime)
        .toISOString()
        .replace('T', ' ')
        .replace('Z', '');

      sql = `SELECT downloadedfilesize AS repeatedfilesize
                 FROM springer.ice_zipfilesinoutfolder
                 WHERE zipfileid = $1`;
      const params4 = [Repeatedzipfileid];
      const dtResult2 = await query(sql, params4);

      if (dtResult2.length > 0) {
        repeatedjobfilesize = parseInt(dtResult2[0].repeatedfilesize);
        returnValue = true;
      }
    }
    return {
      returnValue,
      Newjobcode,
      Newjobcodeid,
      Newjobdetailsid,
      Newjobstage,
      Newzipfileid,
      Newjobfilesize,
      NewZipfilename,
      NewDownloadedDate,
      repeatedjobfilesize,
    };
  } catch (error) {
    return returnValue;
  }
}

export const getLogListSpringerBooks = async (req, res) => {
  try {
    const sql = `SELECT a.*,b.incomingstageid,b.incomingjobstatus,c.jobsheettype,d.bookid,d.chapterid,d.chaptertype,d.chapterdoi
                 FROM springer.ice_iozipfilesinuploadfolder a
                 left join springer.ice_jobdetails b on a.jobdetailsid=b.jobdetailsid and b.isactive='Y'
				         left join springer.ice_mstjobsheettype c on c.jobsheettypeid=a.jobsheettypeid
				         left join springer.ice_mstpackage d on d.jobcodeid=b.jobcodeid
                 WHERE currentfilestatusid in(6,20)
                 AND a.islocked = 'N'
                 AND (
                   (a.islogreceived = 'N' AND a.logstatusid = 3) OR
                   (a.logstatusid = 1 AND a.isautomaticlogupdate = 'Y')
                 )
                 AND a.uploadedfilenamewithtimestamp IS NOT NULL and a.filetype='B'`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const getXMLConfigDetails = async (req, res) => {
  try {
    const sql = `select xmltagconfigjson from springer.ice_mstxmlconfig where stageid='${req.query.stageid}' and customerid='${req.query.customerid}' and isactive='Y'`;
    const out = await query(sql);
    res.status(200).send({ data: out[0].xmltagconfigjson, isSuccess: true });
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message });
  }
};
export const setProofDetails = async (req, res) => {
  try {
    const objProofInfo = new SeteProofInfo(req.body);
    const result = await objProofInfo.startProcess(); // Wait for the asynchronous process to complete
    if (result === true) {
      res.status(200).send({ data: result, isSuccess: true });
    } else {
      res.status(400).send({ isSuccess: false, message: result });
    }
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message });
  }
};

export const pkgUploadToSftp = async (req, res) => {
  const fpathSrc = req.body ? req.body.fPath : '';
  const dmsType = req.body ? req.body.dmsType : '';
  let fileSrc = '';
  const reqInfo = {
    fPath: fpathSrc,
    fileType: req.body ? req.body.fileType : 'zip',
    cusId: req.body ? Number(req.body.cusId) : 0,
    currDate: new Date().toISOString(),
    fName: fpathSrc.toString().split('/').pop(),
    confValue:
      req.body && req.body.confValue
        ? req.body.confValue
        : 'oup_runningorder_upload',
    uploadAction: !!(
      req.body.uploadAction &&
      req.body.uploadAction == 'RunningOrder_Excel_Upload'
    ),
    stagename: req.body && req.body.stageName ? req.body.stageName : '',
    activityname:
      req.body && req.body.activityName ? req.body.activityName : '',
    woId: req.body && req.body.woId ? req.body.woId : 0,
  };
  try {
    switch (dmsType) {
      case 'azure':
        const out = await azureHelper._download(reqInfo.fPath);
        fileSrc = out.data.path;
        break;
      case 'local':
        const out1 = await azureHelper.localFileGetDownload(reqInfo.fPath);
        fileSrc = out1.data.path;
        break;
      default:
        const pc_infileuuid = await _getUuid(reqInfo.fPath);
        fileSrc =
          config.openKM.base_url + config.openKM.uri.viewFile + pc_infileuuid;
        break;
    }
    const sftpConfig = await getsftpConfig(reqInfo.confValue);
    const sftDest =
      sftpConfig && sftpConfig.ftpPath ? sftpConfig.ftpPath : '/IN/';
    let uploadResp = 'Upload Process started';
    if (reqInfo.uploadAction || !reqInfo.uploadAction) {
      uploadResp = await uploadFileToSFTP(
        fileSrc,
        sftpConfig,
        sftDest,
        reqInfo.fName,
      );
    }
    if (uploadResp && reqInfo.uploadAction) {
      reqInfo.issuccess = true;
      await recordUploadInfo(reqInfo);
    } else if (reqInfo.uploadAction) {
      uploadResp = 'package already uploaded';
    }

    res.send({
      isSuccess: uploadResp.uploaded,
      data: uploadResp,
      message: uploadResp.msg,
    });
  } catch (err) {
    if (reqInfo.uploadAction) {
      reqInfo.issuccess = false;
      await recordUploadInfo(reqInfo);
    }
    res.send({ isSuccess: false, message: err.message });
  }
};

const recordUploadInfo = async reqInfo => {
  const recordUploadPrms = new Promise((resolve, reject) => {
    try {
      const fvalues = [];
      fvalues.push(
        `('Integra', ${reqInfo.cusId} , '${reqInfo.fName}', '${
          reqInfo.fileType
        }', 'SFTP Upload','${
          reqInfo.fPath
        }',${null},${null},${null},${true},${null},${true},'${
          reqInfo && reqInfo.activityname ? reqInfo.activityname : null
        }','${reqInfo && reqInfo.stagename ? reqInfo.stagename : null}','${
          reqInfo.currDate
        }',${reqInfo.woId},${
          reqInfo && reqInfo.issuccess != undefined ? reqInfo.issuccess : null
        })`,
      );
      const sql = `INSERT INTO public.wms_ft_transaction_table(
        requestraisedfrom, customerid, filename, packagetype, requesttype, actionrole, nextactionifsuccess, nextactioniffails, transactionstatus, iscompleted, ft_status, isactive, activityname, stagename, createddate, woid,issuccess)
       VALUES  ${fvalues}`;
      query(sql)
        .then(() => {
          resolve();
        })
        .catch(e => {
          reject(e);
        });
    } catch (e) {
      console.log(e);
    }
  });
  return recordUploadPrms.catch(message => {
    console.log(`recordUploadPrms Failed: ${message}`);
  });
};
export const Check_ifAllAuthorsHavingEmailid = async SpringerUserId => {
  let returnValue = -1;
  try {
    const sql = `select emailid 
          from springer.ice_authoreditordetails 
          where springeruserid = $1 
          and isactive = true`;
    const values = [SpringerUserId];
    const result = await query(sql, values);

    if (result.length > 0) {
      if (result[0].emailid && result[0].emailid.trim() !== '') {
        returnValue = 1;
      }
    }
  } catch (error) {
    returnValue = 0;
  }

  return returnValue;
};

export class SeteProofInfo {
  constructor(S300Attributes) {
    this.S300Attributes = S300Attributes;
    this.activeJobCodeId = S300Attributes.jobDetailsId;
    this.ProofRecipientType = '';
    this.ProofRecipientSpringerUserId = '';
    this.AuthorUserId = '';
    this.EditorUserId = '';
    this.ProductionEditorUserId = '';
    this.isAllAuthorsHavingEmailid = false;
    this.ReasonForFailure = '';
    this.activeJobDetailsId = S300Attributes.jobDetailsId;
    // this.eProofResult=this.startProcess()
  }

  startProcess() {
    return new Promise(async resolve => {
      try {
        this.setProofInfoResult = await this.setProofInfo();
        this.tableMstS300650JobDetailsResult =
          await this.tableMstS300650JobDetails();
        resolve(true);
      } catch (ex) {
        resolve(ex.message ? ex.message : ex);
      }
    });
  }

  async Table_ProofRecipientTable(
    UserType,
    GivenName,
    FullName,
    Emailid,
    Contact,
    NameDetails,
  ) {
    let SpringerUserId = false;
    let EGivenName = '';
    let EFullName = '';
    Emailid = Emailid || '';
    const { Street, Postbox, Postcode, City, State, Country, Phone, Fax, URL } =
      Contact;
    const { Prefix, FamilyName } = NameDetails;
    try {
      if (GivenName.trim() !== '') {
        EGivenName = GivenName.trim();
      } else if (FullName.trim() !== '') {
        EGivenName = FullName.trim();
      } else {
        EGivenName = 'AUTO';
      }

      if (FullName.trim() !== '') {
        EFullName = FullName.trim();
      } else if (GivenName.trim() !== '') {
        EFullName = GivenName.trim();
      } else {
        EFullName = 'AUTO';
      }

      let sql = `select springeruserid 
          from springer.ice_authoreditordetails 
          where usertype = $1 
          and fullname = $2 
          and emailid = $3`;
      let values = [UserType, EFullName.trim().replace("'", "''"), Emailid];

      const prooftable = await query(sql, values);

      if (prooftable.length === 0) {
        sql = `insert into springer.ice_authoreditordetails(usertype, username, fullname, jobdetailsid, isactive, emailid,givenname,street,postbox,postcode,city,state,country,phone,fax,url,prefix,familyname) 
              values($1, 'Admin', $2, $3, true, $4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) 
              returning springeruserid`;
        values = [
          UserType,
          EFullName.replace("'", "''"),
          this.activeJobCodeId,
          Emailid.replace("'", "''"),
          EGivenName.replace("'", "''"),
          Street || null,
          Postbox || null,
          Postcode || null,
          City || null,
          State || null,
          Country || null,
          Phone || null,
          Fax || null,
          URL || null,
          Prefix || null,
          FamilyName || null,
        ];

        const insertResult = await query(sql, values);

        if (insertResult.length > 0) {
          SpringerUserId = insertResult[0].springeruserid;
        } else {
          SpringerUserId = -1;
        }
      } else {
        sql = `
              update springer.ice_authoreditordetails 
              set isactive = true
              where usertype = $1 
              and fullname = $2 
              and emailid = $3 
              and springeruserid = $4`;
        values = [
          UserType,
          FullName.trim().replace("'", "''"),
          Emailid.replace("'", "''"),
          prooftable[0].springeruserid,
        ];

        const updateResult = await query(sql, values);

        if (updateResult.length == 0) {
          SpringerUserId = prooftable[0].springeruserid;
        } else {
          SpringerUserId = false;
        }
      }
    } catch (ex) {
      SpringerUserId = false;
    }

    return SpringerUserId;
  }

  async tableMstS300650JobDetails() {
    let returnStatus = false;
    try {
      let sql = `SELECT s300650jobcodeid, processcount, proofcount 
                   FROM springer.ice_msts300650jobdetails 
                   WHERE jobdetailsid = $1 AND isactive = true`;
      let values = [this.activeJobDetailsId];

      const res = await query(sql, values);

      if (res.length === 0) {
        sql = `INSERT INTO springer.ice_msts300650jobdetails 
                   (jobdetailsid, tasktype, actualstatus, internalstatus, proofrecipienttype, peuserid, proofrecipientuserids, proofcorecipientuserids, editoruserids, proofcount, processcount, uploadeddate, isactive, productionclassificationtype, copyeditingcategory) 
                   VALUES ($1, $2, 'PPC', 'NA', $3, $4, $5, $6, $7, $8, $9,(now()::timestamp(0) + interval '330 minute'), true, $10, $11)`;
        values = [
          this.activeJobDetailsId,
          this.S300Attributes.Tasktype || '',
          this.ProofRecipientType || '',
          this.ProductionEditorUserId || '',
          this.ProofRecipientSpringerUserId || '',
          this.ProofCoRecipientSpringerUserId || '',
          this.EditorUserId || '',
          this.ProofCount || 0,
          this.ProcessCount || 0,
          this.S300Attributes.ProductionClassificationType || '',
          this.S300Attributes.CopyEditingCategory || 0,
        ];

        const insertResult = await query(sql, values);

        returnStatus = insertResult.length == 0;
        if (!returnStatus) {
          this.ReasonForFailure =
            'Error in Stage 300 IncomingJob() - Table_MstS300650JobDetails(), ProofRecipient, ProofCoRecipient details insertion failed in ice_msts300650jobdetails table.';
        }
      } else {
        sql = `UPDATE springer.ice_msts300650jobdetails 
                   SET isactive = false 
                   WHERE s300650jobcodeid = $1`;
        values = [res[0].s300650jobcodeid];

        const updateResult = await query(sql, values);

        if (updateResult.length == 0) {
          this.ProcessCount += res[0].processcount;
          this.ProofCount += res[0].proofcount;

          sql = `INSERT INTO springer.ice_msts300650jobdetails 
                       (jobdetailsid, tasktype, actualstatus, internalstatus, proofrecipienttype, peuserid, proofrecipientuserids, proofcorecipientuserids, editoruserids, proofcount, processcount, uploadeddate, isactive, productionclassificationtype, copyeditingcategory) 
                       VALUES ($1, $2, 'PPC', 'NA', $3, $4, $5, $6, $7, $8, $9,(now()::timestamp(0) + interval '330 minute'), true, $10, $11)`;
          values = [
            this.activeJobDetailsId,
            this.S300Attributes.Tasktype || '',
            this.ProofRecipientType || '',
            this.ProductionEditorUserId || '',
            this.ProofRecipientSpringerUserId || '',
            this.ProofCoRecipientSpringerUserId || '',
            this.EditorUserId || '',
            this.ProofCount || 0,
            this.ProcessCount || 0,
            this.S300Attributes.ProductionClassificationType || '',
            this.S300Attributes.CopyEditingCategory || 0,
          ];

          const insertResult = await query(sql, values);

          returnStatus = insertResult.length == 0;
          if (!returnStatus) {
            this.ReasonForFailure =
              'Error in Stage 300 IncomingJob() - Table_MstS300650JobDetails(), ProofRecipient, ProofCoRecipient details insertion failed in ice_msts300650jobdetails table.';
          }
        } else {
          returnStatus = false;
          this.ReasonForFailure =
            'Error in Stage 300 IncomingJob() - Table_MstS300650JobDetails(), isactive = FALSE update failed for new job details in ice_msts300650jobdetails table.';
        }
      }
    } catch (error) {
      this.IsException = true;
      this.ReasonForFailure = `Error in Stage 300 IncomingJob - Table_MstS300650JobDetails(), Validation failed, The exception is ${error.toString()}`;
      returnStatus = false;
    }
    return returnStatus;
  }

  async setProofInfo() {
    let givenName = '';
    let fullName = '';
    let emailId = '';
    let contact = '';
    let nameDetails = '';
    let userId = 0;
    let returnValue = true;

    try {
      if (this.S300Attributes.ProofInfo) {
        if (this.S300Attributes.ProofInfo.ProofRecipient) {
          for (
            let i = 0;
            i < this.S300Attributes.ProofInfo.ProofRecipient.length;
            i++
          ) {
            const proofRecipient =
              this.S300Attributes.ProofInfo.ProofRecipient[i];
            const { Author, Editor, ProductionEditor } = proofRecipient;

            if (Author) {
              ({
                AuthorGivenName: givenName,
                AuthorFullName: fullName,
                AuthorEmail: emailId,
                Contact: contact,
                AuthorName: nameDetails,
              } = Author);

              if (givenName && fullName) {
                userId = await this.Table_ProofRecipientTable(
                  'AU',
                  givenName,
                  fullName,
                  emailId,
                  contact,
                  nameDetails,
                );

                if (userId !== -1) {
                  this.ProofRecipientType += 'AU,';
                  this.ProofRecipientSpringerUserId += `${userId},`;
                  this.AuthorUserId += `${userId},`;
                  userId = -1;
                } else {
                  this.ReasonForFailure = `Error in Insertion of Author details in database, The Author name is ${givenName}`;
                  returnValue = false;
                  break;
                }

                givenName = '';
                fullName = '';
                emailId = '';
                contact = '';
                nameDetails = '';
              }
            }

            if (Editor) {
              ({
                EditorGivenName: givenName,
                EditorFullName: fullName,
                EditorEmail: emailId,
                Contact: contact,
                EditorName: nameDetails,
              } = Editor);

              if (givenName && fullName) {
                userId = await this.Table_ProofRecipientTable(
                  'ED',
                  givenName,
                  fullName,
                  emailId,
                  contact,
                  nameDetails,
                );

                if (userId !== -1) {
                  this.ProofRecipientType += 'ED,';
                  this.ProofRecipientSpringerUserId += `${userId},`;
                  this.EditorUserId += `${userId},`;
                  userId = -1;
                } else {
                  this.ReasonForFailure = `Error in Insertion of Editor details in Database, The Editor name is ${givenName}`;
                  returnValue = false;
                  break;
                }

                givenName = '';
                fullName = '';
                emailId = '';
                contact = '';
                nameDetails = '';
              }
            }

            if (ProductionEditor) {
              ({
                ProductionEditorGivenName: givenName,
                ProductionEditorFullName: fullName,
                ProductionEditorEmail: emailId,
                Contact: contact,
                ProductionEditorName: nameDetails,
              } = ProductionEditor);
              if (givenName && fullName) {
                userId = await this.Table_ProofRecipientTable(
                  'PE',
                  givenName,
                  fullName,
                  emailId,
                  contact,
                  nameDetails,
                );

                if (userId !== -1) {
                  this.ProofRecipientType += 'PE,';
                  this.ProofRecipientSpringerUserId += `${userId},`;
                  this.ProductionEditorUserId += `${userId},`;
                  userId = -1;
                } else {
                  this.ReasonForFailure = `Error in Insertion of ProductionEditor details in Database, The ProductionEditor name is ${givenName}`;
                  returnValue = false;
                  break;
                }

                givenName = '';
                fullName = '';
                emailId = '';
                contact = '';
                nameDetails = '';
              }
            }
          }

          if (this.ProofRecipientSpringerUserId.endsWith(',')) {
            this.ProofRecipientSpringerUserId =
              this.ProofRecipientSpringerUserId.slice(0, -1);
          }

          if (this.ProofRecipientType.endsWith(',')) {
            this.ProofRecipientType = this.ProofRecipientType.slice(0, -1);
          }

          if (this.AuthorUserId.endsWith(',')) {
            this.AuthorUserId = this.AuthorUserId.slice(0, -1);
          }

          if (this.EditorUserId.endsWith(',')) {
            this.EditorUserId = this.EditorUserId.slice(0, -1);
          }
          if (this.ProductionEditorUserId.endsWith(',')) {
            this.ProductionEditorUserId = this.ProductionEditorUserId.slice(
              0,
              -1,
            );
          }
        }

        const proofRecipientUserIds =
          this.ProofRecipientSpringerUserId.split(',').filter(Boolean);

        for (const proofRecpId of proofRecipientUserIds) {
          const prooRecpValue = await Check_ifAllAuthorsHavingEmailid(
            parseInt(proofRecpId, 10),
          );
          if (prooRecpValue === 1) {
            this.isAllAuthorsHavingEmailid = true;
          } else if (prooRecpValue === -1) {
            this.isAllAuthorsHavingEmailid = false;
            break;
          } else if (prooRecpValue === 0) {
            this.isAllAuthorsHavingEmailid = false;
            this.ReasonForFailure =
              'ProofRecipient Emailid validation failed for E-proofing';
            returnValue = false;
            return false;
          }
        }

        givenName = '';
        fullName = '';
        emailId = '';
        contact = '';
        nameDetails = '';
        userId = -1;

        if (this.S300Attributes.ProofInfo.ProofCoRecipient) {
          for (
            let i = 0;
            i < this.S300Attributes.ProofInfo.ProofCoRecipient.length;
            i++
          ) {
            const proofCoRecipient =
              this.S300Attributes.ProofInfo.ProofCoRecipient[i];
            const { ProofCoRecipientName } = proofCoRecipient;
            ({
              ProofCoRecipientGivenName: givenName,
              ProofCoRecipientFullName: fullName,
              ProofCoRecipientEmail: emailId,
              Contact: contact,
              ProofCoRecipientName: nameDetails,
            } = ProofCoRecipientName);
            // if (ProofCoRecipientName.FullName) fullName = ProofCoRecipientName.FullName;
            // if (ProofCoRecipientName.GivenName[0]) givenName = ProofCoRecipientName.GivenName[0];
            // if (proofCoRecipient.Contact.Email) emailId = proofCoRecipient.Contact.Email;

            if (givenName && fullName) {
              userId = await this.Table_ProofRecipientTable(
                'PC',
                givenName,
                fullName,
                emailId,
                contact,
                nameDetails,
              );

              if (userId !== -1) {
                this.ProofCoRecipientSpringerUserId += `${userId},`;
                userId = -1;
              } else {
                this.ReasonForFailure = `Error in Insertion of ProofCoRecipient details in Database, The ProductionEditor name is ${givenName}`;
                returnValue = false;
                break;
              }

              givenName = '';
              fullName = '';
              emailId = '';
              contact = '';
              nameDetails = '';
            }
          }

          if (this.ProofCoRecipientSpringerUserId) {
            if (this.ProofCoRecipientSpringerUserId.endsWith(',')) {
              this.ProofCoRecipientSpringerUserId =
                this.ProofCoRecipientSpringerUserId.slice(0, -1);
            }
          }
        }

        if (this.isAllAuthorsHavingEmailid === false) {
          const sqlQuery = `
                        SELECT springeruserid, usertype, fullname 
                        FROM springer.ice_authoreditordetails 
                        WHERE username LIKE 'admin' AND password LIKE 'admin' AND isactive = true
                    `;

          const result = await query(sqlQuery);
          const dtRecipientDetails = result;

          if (dtRecipientDetails.length > 0) {
            this.ProofRecipientType = dtRecipientDetails[0].usertype;
            this.ProofRecipientSpringerUserId =
              dtRecipientDetails[0].springeruserid;

            if (this.ProofRecipientType && this.ProofRecipientSpringerUserId) {
              this.isAllAuthorsHavingEmailid = true;
              returnValue = true;
            } else {
              this.isAllAuthorsHavingEmailid = false;
              returnValue = false;
            }
          } else {
            returnValue = false;
            this.isAllAuthorsHavingEmailid = false;
            this.ReasonForFailure =
              'Error occurred while receiving the Author and Editor login details for e-Proofing!';
          }
        }
      }
    } catch (error) {
      this.ReasonForFailure = `Error in Stage300 IncomingJob - JobSheetValidation() - setProofInfo(), Validation Failed. The Exception is ${error}`;
      returnValue = false;
    }
    return returnValue;
  }
}

// function getUserType(user) {
//     switch (user.toUpperCase()) {
//         case 'AUTHOR':
//             return 'AU';
//         case 'EDITOR':
//             return 'ED';
//         case 'PRODUCTIONEDITOR':
//             return 'PE';
//         case 'PROOFCORECIPIENT':
//             return 'PC';
//         default:
//             return '';
//     }
// }
