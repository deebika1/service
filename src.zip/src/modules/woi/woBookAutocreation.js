/* eslint-disable no-unused-vars */
import { readFile } from 'fs';
import xmlParser from 'fast-xml-parser';
import moment from 'moment';
import xml2jsonConvertor from 'xml2js';
import { query } from '../../database/postgres.js';
import { woxmlConfig, woKeyConfig } from '../bpmn/parser/core/config.js';
import {
  WorkOrderCreation,
  WorkOrderCreationBook,
  mailTriggerForAutoWOCreate,
} from './index.js';
import { triggerWOStageWf_logic, settriggerNextStagewf } from './stage.js';
import {
  getFolderStructure_autowocreate,
  getFolderStructure,
} from '../utils/wmsFolder/index.js';
import { _upload } from '../utils/azure/index.js';
import { uploadFiletoOpenKM } from '../utils/okm/index.js';
import { emitAction } from '../activityListener/index.js';
import { getJournalDetail } from '../common/index.js';
import { fileTxnUpdate } from '../task/index.js';

export const createBookInfo = async (req, res) => {
  const { stagename, articlename } = req.body;
  const ndate = Date.now();
  const date_ob = new Date(ndate);
  const date = date_ob.getDate();
  const month = date_ob.getMonth() + 1;
  const year = date_ob.getFullYear();
  const hours = date_ob.getHours();
  const minutes = date_ob.getMinutes();
  const seconds = date_ob.getSeconds();

  // prints date & time in YYYY-MM-DD format
  const tdate = `${year}-${month}-${date} ${hours}:${minutes}:${seconds}`;

  let output = {
    issuccess: false,
    message: 'wo creation started',
    workorderid: 0,
    uploadpath: '',
  };
  try {
    const resp = await createBookInfoProcess(req, res);
    if (resp) {
      output = resp;
    } else {
      output.message = 'wo creation failed';
    }
  } catch (error) {
    output.message = error.message;
  } finally {
    const jsonStr = JSON.stringify(output);
    res.end(jsonStr);
  }
};

export const createBookInfoProcess = async (req, res) => {
  let logid = 0;
  let output = '';
  let cparam = '';
  const ismailsend = true;
  let dmstype = 'azure';

  // console.log(ismailsend);
  return new Promise(async resolve => {
    let woDetails1;
    let eventDetails;
    const {
      customer,
      fileType,
      woType,
      stagename,
      articlename,
      stageiterationcount,
      journal,
      tranid,
      remark,
      piivalue,
      jobType,
    } = req.body;

    const initiallogmesage =
      remark == undefined || remark == ''
        ? 'Wo creation process started and incomplete'
        : `failed in reading file: ${remark}`;
    let wfconfdata = {
      issuccess: false,
      message: initiallogmesage,
      articlename,
      journal,
      customer,
      stageName: stagename,
      iteration: stageiterationcount,
    };

    if (remark != '') {
      output = {
        issuccess: false,
        message: initiallogmesage,
        workorderid: 0,
        uploadpath: '',
      };
    }

    let actiontype = 'wocreation_error';

    try {
      const objreqbody = req.body;
      objreqbody.tranid = tranid;
      objreqbody.logmessage = initiallogmesage;

      const logresp = await workorderlog(objreqbody, 'Insert');
      logid = logresp.logid;

      if (
        fileType.toLowerCase() == 'xml' &&
        (remark == '' || remark == undefined)
      ) {
        const retwoexist = await checWoandStageStatus({
          body: {
            articlename,
            stagename,
            stageiterationcount,
          },
        });

        if (
          stageiterationcount == 1 &&
          retwoexist.issuccess == true &&
          retwoexist.iswoexist == false
        ) {
          if (req.body.content.toLowerCase() != '') {
            dmstype = 'azure';

            const wo_response = await getWorkorderxmlData(req, res, logid);
            if (wo_response) {
              if (wo_response.status == true) {
                cparam = {
                  logmessage: wo_response.message,
                  issuccess: true,
                  workorderid: +wo_response.woId,
                  autologid: logid,
                  uploadpath: wo_response.uploadpath,
                  isstagetrigger: false,
                };
                output = {
                  issuccess: true,
                  message: wo_response.message,
                  workorderid: +wo_response.woId,
                  uploadpath: wo_response.uploadpath,
                };
              } else {
                cparam = {
                  logmessage: wo_response.message,
                  issuccess: false,
                  workorderid: 0,
                  autologid: logid,
                  uploadpath: '',
                  isstagetrigger: false,
                };
                output = {
                  issuccess: false,
                  message: wo_response.message,
                  workorderid: 0,
                  uploadpath: '',
                };
              }
            } else {
              cparam = {
                logmessage: 'failed',
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              output = {
                issuccess: false,
                message: 'failed',
                workorderid: 0,
                uploadpath: '',
              };
            }
          } else {
            cparam = {
              logmessage: 'content is empty',
              issuccess: false,
              workorderid: 0,
              autologid: logid,
              uploadpath: '',
              isstagetrigger: false,
            };
            output = {
              issuccess: false,
              message: 'content is empty',
              workorderid: 0,
              uploadpath: '',
            };
          }

          wfconfdata = {
            issuccess: output.issuccess,
            message: output.message,
            articlename,
            journal,
            customer,
            stageName: stagename,
            iteration: stageiterationcount,
          };
          actiontype =
            output.issuccess == true
              ? 'wocreation_success'
              : 'wocreation_error';
        } //* *****Stage trigger Process Start********//

        ///
        if (output.issuccess) {
          if (stagename == 'Revises' && woType == 'Journal') {
            if (woDetails1) {
              let fileuploadpath = '';
              fileuploadpath = await getFolderStructure({
                type: 'wo_activity_file_subtype',
                du: { name: woDetails1[0].duname, id: woDetails1[0].duid },
                customer: {
                  name: woDetails1[0].customername,
                  id: woDetails1[0].customerid,
                },
                workOrderId: woDetails1[0].workorderid,
                service: {
                  name: woDetails1[0].servicename,
                  id: woDetails1[0].serviceid,
                },
                stage: {
                  name: stagename,
                  id: woDetails1[0].stageid,
                  iteration:
                    +stageiterationcount > 1
                      ? +stageiterationcount - 1
                      : +stageiterationcount,
                },
                activity: {
                  name: 'completion trigger',
                  id: 21,
                  iteration: 1,
                },
                fileType: {
                  name: 'article',
                  id: '4',
                  fileId: woDetails1[0].woincomingfileid,
                },
              });

              fileuploadpath = fileuploadpath.replace(
                'completion_trigger_',
                'completion_trigger__',
              );
              output.uploadpath = fileuploadpath;
              cparam.uploadpath = fileuploadpath;
            }
          }
        }
        //* *****uploading process start********//
        if (output.issuccess == true) {
          if (output.uploadpath != '' && req.files && req.files.zip) {
            let OpenKMOutput;

            switch (dmstype) {
              case 'azure':
                OpenKMOutput = await _upload(req.files.zip, output.uploadpath);
                // if (output.uploadpath != '' && req.files && req.files.xml) {
                //     await _upload(req.files.xml, output.uploadpath);
                // }
                break;
              default:
                OpenKMOutput = await uploadFiletoOpenKM(
                  req,
                  output.uploadpath,
                  'zip',
                );
                break;
            }
            //  let oOpenKMOutput = dmstype == 'openkm' ? await uploadFiletoOpenKM(req, output.uploadpath, "zip") :
            //     await _upload(req.files["zip"], output.uploadpath);

            req.body.uid = OpenKMOutput.data.uuid;
            req.body.uploadpath = OpenKMOutput.fullPath;

            const ures = await insert_uploadpath_uid(req);
            if (ures && ures.issuccess == false) {
              cparam = {
                logmessage: 'Failed to insert on table source file details',
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              wfconfdata = {
                issuccess: false,
                message: 'Failed to insert on table source file details',
                articlename,
                journal,
                customer,
                stageName: stagename,
                iteration: stageiterationcount,
              };
            }
          } else {
            cparam = {
              logmessage: 'File upload failed',
              issuccess: false,
              workorderid: 0,
              autologid: logid,
              uploadpath: '',
              isstagetrigger: false,
            };
            wfconfdata = {
              issuccess: false,
              message: 'File upload failed',
              articlename,
              journal,
              customer,
              stageName: stagename,
              iteration: stageiterationcount,
            };
          }
        }
      }
      //* *****uploading process end********//
    } catch (e) {
      cparam = {
        logmessage: e.message,
        issuccess: false,
        workorderid: 0,
        autologid: logid,
        uploadpath: '',
        isstagetrigger: false,
      };
      wfconfdata = {
        issuccess: false,
        message: 'Wo creation failed',
        articlename,
        journal,
        customer,
        stageName: stagename,
        iteration: stageiterationcount,
      };
      output = { issuccess: false, message: e.message, uploadpath: '' };
    } finally {
      workorderlog(cparam, 'Update').catch(err => {});

      if (customer == 'CUP') {
        if (woType == 'Journal' && jobType !== 'Issue') {
          if (ismailsend) {
            // mailTriggerForAutoWOCreate(wfconfdata, actiontype);
          }
        }
      }

      // res.json(output);
      resolve(output);
    }
  });
};

export const TestSendEmail = async (req, res) => {
  const data = req.body;
  emitAction(data);

  res.send('success');
  /*
    data = {
        actionType: "mail",
        jobTypes: [
          "1",
        ],
        from: "iwmssupport@integra.co.in",
        to: [
          "toSpm",
        ],
        cc: [
        ],
        bcc: [
          "gnanamani.murugan@integra.co.in",
          "alaguraj.sannasi@integra.co.in",
        ],
        subject: "Auto workorder created succesfully for <%= data.jobId %>",
        template: "<html><style>.header{color: #ff7904;}.auto-text{color: #70757a;text-align: center;margin-top: 10px;}.footer{margin-top: 10px;}</style><body><div><div class='body'><p>Dear Team,</p><div> <p>We confirm a safe receipt of shared files for new article <%= data.jobId %></p> <br></br><div><span>Regards,</span></br><span>Integra Production team, Journals</span></br></div></div></div></div></body></html>",
        jobId: "PAX_test100",
        subMessage: "Message : success",
        toMail: [
          "suradha.gunaseelan@integra-india.com",
        ],
      };
*/

  /* let { workorderid, message, issuccess, articlename, journal, customer } = data;
    let actiontype = issuccess == true ? "wocreation_success" : "wocreation_error";
    let wfconfdata = { workorderid: workorderid, issuccess: issuccess, message: message, articlename: articlename, journal: journal, customer: customer }
    return new Promise(async (resolve, reject) => {
        logger.info('before mail trigger')
        let resmail = await mailTriggerForAutoWOCreate(wfconfdata, actiontype);
        if (resmail && resmail.isssuccess == true) {
            resolve("Email sent successfully");
        } else {
            resolve("Failed in sending email");
        }

    }).catch((error) => {
        resolve("Failed in sending email");
    }); */
};

const getArticleDetailByPii = async req => {
  const { piivalue } = req;
  return new Promise(async resolve => {
    const sql = `select 
                  wo.workorderid, wo.itemcode, wo.title, wo.customerid, wo.divisionid, 
                  wo.subdivisionid, wo.countryid,  wo.status, wo.journalid, wo.wotype, 
                  wo.doinumber, jo.journalacronym
                 from wms_workorder as wo
                 left join public.pp_mst_journal as jo on jo.journalid = wo.journalid and jo.isactive = 1
                 where wo.isactive = true and wo.otherfield->>'pii' = '${piivalue}'`;
    // console.log(sql, 'logsql');
    query(sql)
      .then(response => {
        if (response.length) {
          resolve({ issuccess: true, data: response });
        } else {
          resolve({ issuccess: false, data: response });
        }
      })
      .catch(() => {
        resolve({ issuccess: false, data: {} });
      });
  });
};

export const checWoandStageStatus = async req => {
  const { articlename, stagename, stageiterationcount } = req.body;

  return new Promise(async resolve => {
    const sql = `SELECT * from checkworkorderstage_exist('${articlename}','${stagename}',${stageiterationcount})`;
    // console.log(sql, 'logsql');

    query(sql)
      .then(response => {
        if (response.length) {
          // let triggerstage = false;
          // if( (response[0].isstagetriggered && response[0].isstagecomplete) || response[0].isstagetriggered == false ) {
          //     triggerstage =   true;
          // }

          resolve({
            issuccess: true,
            iswoexist: response[0].isworkorderexist,
            isstageexist: response[0].isstagetriggered,
            isstagecomplete: response[0].isstagecomplete,
          });
        } else {
          resolve({
            issuccess: false,
            iswoexist: false,
            isstageexist: false,
            isstagecomplete: false,
          });
        }
      })
      .catch(() => {
        resolve({
          issuccess: false,
          iswoexist: false,
          isstageexist: false,
          isstagecomplete: false,
        });
      });
  });
};

const getwostagetrigger = async (req, res) => {
  const { stagename, articlename, stageiterationcount } = req.body;
  // let iparam = JSON.stringify(req);
  return new Promise(async resolve => {
    const respayload = await payloadStagetriggerFileupload(req);

    if (
      (respayload.issuccess == true &&
        stagename == 'AMO' &&
        respayload.amostagepayload != '') ||
      (stagename != 'AMO' && respayload.nextstagepayload != '')
    ) {
      // const stagetrigpayload = respayload.stagetriggerpayload
      //   ? JSON.parse(respayload.stagetriggerpayload)
      //   : '{}';
      const filtepathpayload = respayload.uploadpathpayload
        ? JSON.parse(respayload.uploadpathpayload)
        : '{}';
      const amostagepayload = respayload.amostagepayload
        ? JSON.parse(respayload.amostagepayload)
        : '{}';
      const nextstagepayload = respayload.nextstagepayload
        ? JSON.parse(respayload.nextstagepayload)
        : '{}';

      let checkresp;

      //   const server = http.createServer(async(request, response) => {
      // magic happens here!

      if (stagename == 'AMO') {
        checkresp = await settriggerNextStagewf({ body: amostagepayload }, res);
      } else {
        //  checkresp = await updateWoStage_autoCall({ body: JSON.parse(stagetrigpayload) }, res);
        checkresp = await triggerWOStageWf_logic(
          { body: nextstagepayload },
          res,
        );
      }
      //  });
      if (checkresp && checkresp.issuccess) {
        await updatestagetatdate({
          articlename,
          stagename,
          stageiterationcount,
        });

        const fileuploadpath = await getFolderStructure_autowocreate({
          body: filtepathpayload,
        });

        // if (checkresp && checkresp.issuccess) {
        resolve({
          message: 'success',
          issuccess: true,
          uploadpath: fileuploadpath,
        });
      } else {
        resolve({
          message: `Stage trigger failed -(${checkresp.message})`,
          issuccess: false,
          uploadpath: '',
        });
      }
    } else {
      resolve({
        message: 'Failed on getting payload for stage trigger',
        issuccess: false,
        uploadpath: '',
      });
    }
  });
};

const updatestagetatdate = async req => {
  const { articlename, stagename, stageiterationcount } = req;
  return new Promise(async resolve => {
    const sql = `SELECT * from update_stage_tatdate('${articlename}','${stagename}', ${stageiterationcount})`;
    query(sql)
      .then(() => {
        resolve('success');
      })
      .catch(() => {
        resolve('failed');
      });
  });
};

export const payloadStagetriggerFileupload = async req => {
  const { stagename, articlename, woType, stageiterationcount } = req.body;
  return new Promise(async resolve => {
    const sql = `SELECT * from getarticlestagetrigger('${stagename}','${articlename}','${woType}','${stageiterationcount}')`;

    query(sql)
      .then(async response => {
        if (response) {
          const { fileuploadpayload } = response[0];
          const stagetriggerpayload = response[0].stagepayload;
          const amostagepayload = response[0].amopayload;
          const { nextstagepayload } = response[0];
          resolve({
            issuccess: true,
            uploadpathpayload: fileuploadpayload,
            stagetriggerpayload,
            amostagepayload,
            nextstagepayload,
          });
        }
      })
      .catch(() => {
        resolve({
          issuccess: false,
          uploadpathpayload: '',
          stagetriggerpayload: '',
          amostagepayload: '',
          nextstagepayload: '',
        });
      });
  });
};

export const insert_uploadpath_uid = async req => {
  const { articlename, stagename, stageiterationcount, uploadpath, uid } =
    req.body;
  return new Promise(async resolve => {
    const sql = `select insert_uploadpathuid ('${articlename}','${stagename}',${stageiterationcount},'${uploadpath}','${uid}')`;

    query(sql)
      .then(async response => {
        if (response && response.length) {
          const respid = response[0].insert_uploadpathuid;
          resolve({ issuccess: true, id: respid, message: 'success' });
        } else {
          resolve({ issuccess: false, id: 0, message: 'failed' });
        }
      })
      .catch(error => {
        resolve({ issuccess: false, id: 0, message: error.message });
      });
  });
};

export const insertUploadPathUid = async (req, res) => {
  try {
    const respobj = await insert_uploadpath_uid(req);
    if (respobj && respobj.issuccess == true) {
      res.status(200).send({ issuccess: true, message: respobj.message });
    } else {
      res.status(400).send({ issuccess: false, message: respobj.message });
    }
  } catch (error) {
    res.status(400).send({ issuccess: false, message: error.message });
  }
};

export const workorderlog = async (req, flag) => {
  const iparam = JSON.parse(JSON.stringify(req));
  iparam.content = '';
  return new Promise(async resolve => {
    const sql = `SELECT * from workorder_autolog('${JSON.stringify(
      iparam,
    )}','${flag}')`;

    query(sql)
      .then(response => {
        if (response) {
          const lid = response[0].logresult;
          resolve({ logid: lid });
        } else {
          resolve({ logid: 0 });
        }
      })
      .catch(() => {
        resolve({ logid: 0 });
      });
  });
};

export const getWorkorderxmlData = async (req, res, logid) => {
  const {
    InPath,
    customer,
    woType,
    jobType,
    stagename,
    articlename,
    journal,
    tasktype,
  } = req.body;
  const { content } = req.body;
  let currentkey = '';
  return new Promise(async resolve => {
    try {
      if (customer == 'Springer') {
        currentkey = woKeyConfig.springer_bookxmlkeys;
      }

      const xmlobjdata = content
        ? await readXMLDatafromContent(content, woxmlConfig)
        : await readXMLData(InPath, woxmlConfig);

      const setPayloads = {};
      let errormsg = '';
      if (xmlobjdata) {
        const keyobj = JSON.parse(currentkey);
        // try {
        for (const [key, value] of Object.entries(keyobj[0])) {
          // console.log(key);
          if (key.includes('XML')) {
            if (value.includes(',')) {
              // console.log(value, 'tttt');
              // let xval = readKeyvalue(value, xmlobjdata.article);
              let xval = readKeyvalue(value, Object.values(xmlobjdata)[0]);
              if (xval === undefined) {
                xval = '';
                errormsg =
                  errormsg.length > 0
                    ? `${errormsg}, ${key.replace(/^xml(?:DBID)?/i, '')}`
                    : `${key.replace(/^xml(?:DBID)/i, '')}`;
              }
              xval =
                typeof xval === 'string' || typeof xval === 'number'
                  ? xval
                  : '';
              if (key.includes('XMLDBID'))
                setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
                  value: xval,
                  keyconfig: key,
                });
              else setPayloads[key.replace('XML', '')] = xval;
            } else {
              let dval = Object.values(xmlobjdata)[0][value];
              if (dval === undefined) {
                if (customer == 'Springer' && key === 'XMLarticleno') {
                  dval = '';
                } else {
                  errormsg =
                    errormsg.length > 0
                      ? `${errormsg}, ${key.replace(/^xml(?:DBID)?/i, '')}`
                      : `${key.replace(/^xml(?:DBID)?/i, '')}`;
                  dval = '';
                }
              }
              const fval = typeof dval === 'object' ? dval[0] : dval;
              // console.log(typeof dval);
              if (key.includes('XMLDBID'))
                setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
                  value: fval,
                  keyconfig: key,
                });
              else setPayloads[key.replace('XML', '')] = fval;
            }
          } else {
            setPayloads[key] = value;
          }
        }
      }
      if (errormsg.length > 0) {
        resolve({
          message: `The following element is "${errormsg}" missing in metadata`,
          status: false,
          uploadpath: '',
        });
        return;
      }
      let users = [];
      // eslint-disable-next-line no-const-assign
      users = await constructAuthorDetails(setPayloads);
      if (users.issuccess == true) {
        setPayloads.externalUsers = users.data;
      }

      /*
        const customerName = customer;
        const DBjournaldet = await getCustomerBookDetail({
          customer: customerName
        });
        console.log(DBjournaldet);
        if (DBjournaldet.length > 0) {
          for (const [key, value] of Object.entries(DBjournaldet[0])) {
            if (
              key == 'customer' ||
              key == 'country' ||
              key == 'colours' ||
              key == 'journalId'
            ) {
              setPayloads[key] = +value;
            } else {
              setPayloads[key] =
                typeof setPayloads[key] === 'number' ? +value : value;
            }
          }         
                   
        } else {
          resolve({
            message: 'Book detail not present',
            status: false,
            uploadpath: '',
          });
          return;
        } */

      switch (jobType) {
        case 'Article':
          setPayloads.jobType = 1;
          break;
        case 'Non Article':
          setPayloads.jobType = 3;
          break;
        case 'Issue':
          setPayloads.jobType = 2;
          break;
        default:
      }

      setPayloads.trigerstagename = stagename;
      setPayloads.isauto = true;
      setPayloads.jobId = articlename;
      setPayloads.journalAcronym = journal;
      setPayloads.tasktype = tasktype;
      // console.log({ body: setPayloads });

      // && jobType !== 'Issue'
      // if (woType == 'Book') {
      if (setPayloads.externalUsers == '') {
        resolve({
          message: 'author detail not present in xml',
          status: false,
          uploadpath: '',
        });
        return;
      }
      const param = { payload: setPayloads, autologid: logid };
      const logresp = await workorderlog(param, 'UpdatePayload');
      // console.log(logresp);

      // console.log(setPayloads, 'checking before wocreation');

      // to get no.of.articles from xml

      const woresp = await WorkOrderCreationBook(
        { body: setPayloads },
        res,
        true,
      );
      resolve(woresp);
    } catch (e) {
      // console.log(e, 'ee');
      resolve({
        message: 'Failed on workorder creation',
        status: false,
        uploadpath: '',
      });
    }
  });
};

const constructAuthorDetails = async data => {
  const users = [];
  const rolelist = await getAllRole();

  return new Promise(resolve => {
    if (rolelist.data && rolelist.data.length > 0) {
      const { GivenName, Prefix, SurName, Email } = data;
      let rname = '';
      try {
        if (Prefix) {
          rname = `${Prefix} replace`;
        }
        if (GivenName) {
          rname =
            rname == ''
              ? GivenName
              : `${rname.replace('replace', GivenName)} replace`;
        }
        if (SurName) {
          rname = rname == '' ? SurName : rname.replace('replace', SurName);
        }
        rname = rname.replace('replace', '');
        const roledet = rolelist.data
          .filter(x => x.roleacronym == 'AUTHOR')
          .map(item => item.roleid);
        const pushobj = {
          email: Email,
          name: rname,
          role: roledet[0],
          roleAcronym: 'AUTHOR',
        };
        users.push(pushobj);
        if (users && users.length > 0) {
          resolve({ issuccess: true, data: users });
        } else {
          resolve({ issuccess: false, data: users });
        }
      } catch (e) {
        resolve({ issuccess: false, data: {} });
      }
    } else {
      resolve({ issuccess: false, data: {} });
    }
  });
};

// const generateExternaluser = async data => {
//   const users = [];
//   const rolelist = await getAllRole();
//   if (rolelist.data && rolelist.data.length > 0) {
//     return new Promise(resolve => {
//       const extuser = data;
//       const extdata = extuser
//         .filter(f => f['__WOAttr__contrib-type'] == 'author')
//         .map(md => {
//           const contype = md['__WOAttr__contrib-type'];
//           const corresp = md.__WOAttr__corr;
//           let remail = '';
//           let rname = '';
//           // const roleid = 0;
//           if (contype == 'author' && (corresp == 'yes' || corresp == 1)) {
//             remail = md.email.__WOText__;

//             if (remail == undefined) {
//               const maildtl = md.email.filter(
//                 x => x.__WOAttr__primary == 'True',
//               );
//               if (maildtl.length > 0) {
//                 remail = maildtl[0].__WOText__;
//               }
//             }

//             if (md.name.prefix) {
//               rname = `${md.name.prefix}replace`;
//             }
//             if (md.name['given-name']) {
//               rname =
//                 rname == ''
//                   ? md.name['given-name']
//                   : `${rname.replace(
//                       'replace',
//                       md.name['given-name'],
//                     )} replace`;
//             }
//             if (md.name.surname) {
//               rname =
//                 rname == ''
//                   ? md.name.surname
//                   : rname.replace('replace', md.name.surname);
//             }
//             rname = rname.replace('replace', '');

//             const roledet = rolelist.data
//               .filter(x => x.roleacronym == 'AUTHOR')
//               .map(item => item.roleid);
//             const pushobj = {
//               email: remail,
//               name: rname,
//               role: roledet[0],
//               roleAcronym: 'AUTHOR',
//             };
//             const eindex = users.findIndex(
//               object => object.roleAcronym == 'AUTHOR',
//             );
//             if (eindex === -1) {
//               users.push(pushobj);
//             }
//             console.log(users);
//           }
//         });

//       if (extdata && extdata.length > 0) {
//         resolve({ issuccess: true, data: users });
//       } else {
//         resolve({ issuccess: false, data: users });
//       }
//     });
//   }
// };

// export const getWorkorderExcelData = async (req) => {
//   const resData = req.body;
//   const { InPath, customer } = req.body;
//   // let currentkey = woKeyConfig.cupexcelkeys;
//   const keyobj = JSON.parse(currentkey);
//   const filepath =
//     'C:/Users/is9825/Desktop/New folder/file_example_XLSX_10.xlsx';

//   let currentkey = '';
//   switch (customer) {
//     case 'CUP':
//       currentkey = woKeyConfig.cup_excelkeys;
//       break;
//     case 'EMERALD':
//       currentkey = woKeyConfig.emerald_excelkeys;
//   }

//   const result = excelToJson({
//     sourceFile: InPath,
//   });
//   const excelrst = [];
//   if (result.Sheet1.length > 0) {
//     const FirstRow = result.Sheet1.shift();
//     const Headers = Object.values(FirstRow);
//     result.Sheet1.forEach(element => {
//       const values = Object.values(element);
//       const obj = {};
//       Headers.forEach((val, index) => {
//         obj[val] = values[index];
//       });
//       excelrst.push(obj);
//     });
//   }
//   console.log(excelrst);
//   let val_journalid = '';
//   let val_journaltitle = '';
//   let val_issn = '';

//   excelrst.forEach(val => {
//     // let dval = Object.values(val);
//     const xval = val;
//     val_journalid = val[keyobj.Journalid];
//     val_journaltitle = val[keyobj.Journaltitle];
//     val_issn = val[keyobj.issn];
//     console.log(dval);
//   });
// };

const readKeyvalue = (keytext, xmlobject) => {
  try {
    const keyereplace = keytext.replaceAll('","', '"_"');
    const splitkey = keyereplace.split(',');
    let currxmlobj = xmlobject;
    let indexplus = 0;
    for (let index = 0; index < splitkey.length; index++) {
      // splitkey[indexplus] = splitkey[indexplus].replaceAll("\"_\"", "\",\"");
      if (index > 0) {
        indexplus = index + 1;
      }

      let currentkey = '';
      let currentattribute = '';
      let nextkey = '';
      let nextattribute = '';

      let attrstartindex = -1;
      let attrlastindex = -1;
      if (indexplus < splitkey.length) {
        if (splitkey[indexplus] && splitkey[indexplus].indexOf('{') == -1) {
          currentkey = splitkey[indexplus];
        } else {
          attrstartindex = splitkey[indexplus].indexOf('{');
          attrlastindex = splitkey[indexplus].indexOf('}') + 1;

          currentkey = splitkey[indexplus].substring(0, attrstartindex);
          currentattribute = splitkey[indexplus].substring(
            attrstartindex,
            attrlastindex,
          );
        }

        if (indexplus + 1 < splitkey.length) {
          //  splitkey[indexplus+1] = splitkey[indexplus+1].replaceAll("\"_\"", "\",\"");
          if (splitkey[indexplus + 1].indexOf('{') == -1) {
            nextkey = splitkey[indexplus + 1];
          } else {
            attrstartindex = splitkey[indexplus + 1].indexOf('{');
            attrlastindex = splitkey[indexplus + 1].indexOf('}') + 1;

            nextkey = splitkey[indexplus + 1].substring(0, attrstartindex);
            nextattribute = splitkey[indexplus + 1].substring(
              attrstartindex,
              attrlastindex,
            );
          }
        }
        const retrivedobject = reccall(
          currentkey,
          currxmlobj,
          currentattribute,
        );
        // const retrivedobject_old = currxmlobj[currentkey];
        // console.log(retrivedobject);
        if (retrivedobject && nextkey != '') {
          if (Object.keys(retrivedobject).length > 0) {
            const retcontent = reccall(nextkey, retrivedobject, nextattribute);
            if (nextkey === splitkey[splitkey.length - 1]) {
              // console.log(retcontent, 'rettttt');
              //  const returnresult = typeof retcontent === 'string' ? retcontent :
              //       typeof retcontent === 'object' ? retcontent.length ? retcontent[0]['__WOText__'] : '':'';
              return retcontent;
            }
            currxmlobj = retcontent;
          }
        } else {
          if (
            typeof retrivedobject == 'object' &&
            Object.keys(retrivedobject).includes('__WOText__')
          ) {
            const resultobj1 = Object.keys(retrivedobject).includes(
              '__WOText__',
            )
              ? retrivedobject.__WOText__
              : retrivedobject;
            return resultobj1;
          }
          if (
            Array.isArray(retrivedobject) &&
            retrivedobject.length &&
            Object.keys(retrivedobject[0]).includes('__WOText__')
          ) {
            const resultobj2 = retrivedobject[0].__WOText__;

            return resultobj2;
          }
          return retrivedobject;
        }
      } else {
        // console.log(currxmlobj);
        currxmlobj =
          currxmlobj.length > 0 &&
          Object.keys(currxmlobj[0]).includes('__WOText__')
            ? currxmlobj[0].__WOText__
            : currxmlobj;
        return currxmlobj;
      }
    }
  } catch (error) {
    return undefined;
  }
  return {};
};

const reccall = function (key, xmlobj, attributeType) {
  // console.log(key);
  attributeType = attributeType.replaceAll('"_"', '","');
  let result = '';
  if (attributeType == '') {
    if (xmlobj.length == undefined) {
      result =
        xmlobj.length > 0
          ? xmlobj[0][key]
          : Object.keys(xmlobj).includes(key)
          ? xmlobj[key]
          : xmlobj;
    }
    if (xmlobj.length > 0) {
      if (
        xmlobj[0][key].length != undefined &&
        xmlobj[0][key].length > 1 &&
        Array.isArray(xmlobj[0][key])
      ) {
        // eslint-disable-next-line prefer-destructuring
        result = xmlobj[0][key][0];
      } else {
        result = xmlobj[0][key].__WOText__
          ? xmlobj[0][key].__WOText__
          : xmlobj[0][key];
        //  result = xmlobj[0][key];
      }
    }
  } else if (Object.keys(attributeType).length > 0) {
    const toFilter = JSON.parse(attributeType);
    const keys = Object.keys(toFilter);
    let objectof = {};

    objectof = Array.isArray(xmlobj)
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key]) && xmlobj.length > 0
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key])
      ? xmlobj[key]
      : [xmlobj[key]];

    if (Array.isArray(objectof)) {
      result = objectof.filter(x => {
        // console.log(x, 'testttt');
        if (typeof x === 'object') {
          const matchs = keys
            .map(y => x[`__WOAttr__${y}`] == toFilter[y])
            .filter(z => z == true);
          return matchs.length == keys.length;
        }
        return '';
      });
      // console.log(result);
    } else if (typeof objectof === 'object') {
      let checkloop = true;
      keys.forEach(element => {
        // console.log(toFilter[element]);
        // console.log(objectof[`__WOAttr__${element}`]);
        if (objectof[`__WOAttr__${element}`] == toFilter[element]) {
          // console.log(objectof[`__WOAttr__${element}`]);
        } else {
          // console.log('failed');
          checkloop = false;
        }
      });

      if (checkloop == true && objectof.__WOText__) {
        result = objectof.__WOText__;
      } else {
        result = '';
      }
    }
  }
  // console.log(result);
  return result;
};

export const readXMLData = (wofilename, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      readFile(wofilename, { encoding: 'utf-8' }, (err, xmlData) => {
        if (err) {
          this.emit('error', err);
          return;
        }

        const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
        xmlobjdata = xmlObj;
        resolve(xmlobjdata);
      });
    } catch (error) {
      reject(error);
    }
  });
};
const readXMLDatafromContent = (xmlData, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
      xmlobjdata = xmlObj;
      resolve(xmlobjdata);
    } catch (error) {
      reject(error);
    }
  });
};

const getAllRole = () => {
  return new Promise(resolve => {
    const sql = `select roleid,rolename,roledescription,roleacronym from public.wms_role where isactive = true`;
    query(sql)
      .then(response => {
        resolve({ issuccess: true, data: response });
      })
      .catch(() => {
        resolve({ issuccess: false, data: {} });
      });
  });
};

const getCustomerBookDetail = data => {
  const { customer, journalAcronym } = data;
  return new Promise((resolve, reject) => {
    const sql = `select a.colorid as colours ,a.softwareid as softwares ,a.languageid as languages ,a.celevelid as  "CELevel",a.printissn as "printISSN" , 
         b.divisionid as division ,b.subdivisionid as "subDivision",b.countryid as country ,b.customerid as  customer,d.duid as "duId",
         a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
         a.journalid as "journalId"
         from pp_mst_journal a  
         JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
         JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
         JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid
         JOIN org_mst_customer e on e.customerid=b.customerid 
         where a.isactive = 1 AND b.isactive = 1
         AND LOWER(e.customername) = LOWER('${customer}')
         AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;

    // console.log(sql, 'sql for getJournalDetail');
    query(sql)
      .then(response => {
        resolve(response);
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};

export const getIdFromName = data => {
  const { value, keyconfig } = data;
  const tblkeys = JSON.parse(woKeyConfig.tableKeyConfig);
  const splitval = tblkeys[0][keyconfig].split(',');
  const tableName = splitval[0];
  const columnName = splitval[1];
  const primaryId = splitval[2];

  return new Promise((resolve, reject) => {
    let sql = ``;
    // SELECT customerid as value, customername as label FROM public.org_mst_customer
    sql = `SELECT ${primaryId} as colval FROM ${tableName} WHERE ${columnName} = '${value}' AND isactive = true`;

    // console.log(sql, 'sql for getidfromname');
    query(sql)
      .then(response => {
        const id = response.length ? response[0].colval : '';
        resolve(id);
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};

export const getAutoemailLogdetails = (req, res) => {
  const sql = 'select * from get_autoemail_log()';
  let resobject = [];
  query(sql)
    .then(response => {
      if (
        response != undefined &&
        response.length > 0 &&
        response[0].j.length != undefined
      ) {
        // console.log(response[0].j);
        resobject = response[0].j;
        // console.log(resobject);
      }
      res.send(resobject);
    })
    .catch(() => {
      res.sen({});
    });
};
/*
const getWorkOrderDetail_Itemcode = async itemcode => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select wo.workorderid,wo.dmsid,dms.dmstype  from wms_workorder as wo
            left join dms_master as dms on dms.dmsid = wo.dmsid and dms.isactive = true
            where wo.isactive = true and itemcode = $1`;
      const articledetails = await query(sql, [itemcode]);
      resolve(articledetails);
    } catch (e) {
      reject(e);
    }
  });
}; */

export const getWfEventDetailsForWo = async (
  itemcode,
  stage,
  stageiterationcount,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select  wo.workorderid,ev.wfeventid,ev.woincomingfileid,stg.stagename,act.activityname 
      from  wms_workorder as wo
      join wms_workflow_eventlog as ev on ev.workorderid = wo.workorderid and ev.stageiterationcount = case when ${stageiterationcount}>1 then ${stageiterationcount}-1 else 1 end 
      join wms_workflowdefinition as wfd on wfd.wfdefid = ev.wfdefid 
      join wms_mst_stage as stg on stg.stageid = wfd.stageid
      join wms_mst_activity as act on act.activityid = wfd.activityid
    where wo.itemcode = $1 and stg.stagename = $2 and trim(act.activityname) = 'Completion Trigger'`;
      const eventdetails = await query(sql, [itemcode, stage]);
      resolve(eventdetails);
    } catch (e) {
      reject(e);
    }
  });
};
export const getworkorderdetail_bystage = async (itemcode, stage) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT distinct wo.workorderid,wo.itemcode, st.stageid, st.stagename, srv.serviceid,srv.servicename,du.duid,du.duname,
      cust.customerid ,cust.customername,winf.woincomingfileid 
      FROM public.wms_workorder AS wo
      JOIN public.wms_workorder_stage AS wos ON wo.workorderid = wos.workorderid
      JOIN public.wms_mst_stage AS st ON st.stageid = wos.wfstageid AND st.isactive = true
      JOIN public.org_mst_customer AS cust ON cust.customerid = wo.customerid AND cust.isactive= true
      JOIN public.wms_mst_service AS srv ON srv.serviceid = wos.serviceid AND srv.isactive = true
      JOIN public.org_mst_customer_orgmap AS orgmap on orgmap.customerid = wo.customerid 
      and orgmap.divisionid = wo.divisionid and orgmap.subdivisionid = wo.subdivisionid and 
      orgmap.countryid = wo.countryid and orgmap.isactive = 1
      join public.org_mst_customerorg_du_map custdu on custdu.custorgmapid = orgmap.custorgmapid
      join public.org_mst_deliveryunit as du on du.duid = custdu.duid and du.isactive = true
      join public.wms_workorder_incoming wi on wi.woid = wo.workorderid
      join public.wms_workorder_incomingfiledetails winf on winf.woincomingid = wi.woincomingid
      WHERE wo.itemcode = $1 AND st.stagename = $2`;
      const articledetails = await query(sql, [itemcode, stage]);
      resolve(articledetails);
    } catch (e) {
      reject(e);
    }
  });
};

const isWoCompleted = filenames => {
  return new Promise(async (resolve, reject) => {
    try {
      // const placeholders = Array(filenames.length).fill('filenames').join(',');
      // const sql = `SELECT count(wo.workorderid) FROM public.wms_workorder wo JOIN public.wms_workorder_stage wos ON wo.workorderid = wos.workorderid WHERE wo.itemcode = '${fname}' AND wos.wfstageid = 12 AND wos.status = 'Completed'`;
      const sql = `SELECT count(wo.workorderid) FROM public.wms_workorder wo JOIN public.wms_workorder_stage wos ON wo.workorderid = wos.workorderid WHERE wo.itemcode IN ('${filenames.join(
        "','",
      )}') AND wos.wfstageid = 12 AND wos.status = 'Completed'`;
      // console.log(sql, filenames);
      const res = await query(sql);
      // console.log(res);
      if (filenames.length == Number(res[0].count)) {
        resolve({ issuccess: true, data: res });
      } else {
        resolve({ issuccess: false, data: res });
      }
    } catch (e) {
      reject(e);
    }
  });
};
