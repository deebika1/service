import { readFile } from 'fs';
import xmlParser from 'fast-xml-parser';
import { woKeyConfig } from '../bpmn/parser/core/config.js';
import { query } from '../../database/postgres.js';

export const readXMLDatafromContent = (xmlData, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
      xmlobjdata = xmlObj;
      resolve(xmlobjdata);
    } catch (error) {
      reject(error);
    }
  });
};

export const readXMLData = (wofilename, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      readFile(wofilename, { encoding: 'utf-8' }, (err, xmlData) => {
        if (err) {
          this.emit('error', err);
          return;
        }

        const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
        xmlobjdata = xmlObj;
        resolve(xmlobjdata);
      });
    } catch (error) {
      reject(error);
    }
  });
};
export const getIdFromName = data => {
  const { value, keyconfig } = data;
  const tblkeys = JSON.parse(woKeyConfig.tableKeyConfig);
  const splitval = tblkeys[0][keyconfig].split(',');
  const tableName = splitval[0];
  const columnName = splitval[1];
  const primaryId = splitval[2];
  return new Promise(async (resolve, reject) => {
    try {
      let sql = ``;
      sql = `SELECT ${primaryId} as colval FROM ${tableName} WHERE ${columnName} = '${value}' AND isactive = true`;
      const response = await query(sql);
      const id = response.length ? response[0].colval : '';
      resolve(id);
    } catch (error) {
      reject({ message: error });
    }
  });
};

export const readKeyvalue = (keytext, xmlobject) => {
  try {
    const keyereplace = keytext.replace(/","/g, '"_"');
    const splitkey = keyereplace.split(',');
    let currxmlobj = xmlobject;
    let indexplus = 0;
    let nextkeyindex = 0;
    for (let index = 0; index < splitkey.length; index++) {
      if (index > 0) {
        indexplus = nextkeyindex + 1;
      }

      let currentkey = '';
      let currentattribute = '';
      let nextkey = '';
      let nextattribute = '';

      let attrstartindex = -1;
      let attrlastindex = -1;
      if (indexplus < splitkey.length) {
        if (splitkey[indexplus] && splitkey[indexplus].indexOf('{') == -1) {
          currentkey = splitkey[indexplus];
        } else {
          attrstartindex = splitkey[indexplus].indexOf('{');
          attrlastindex = splitkey[indexplus].indexOf('}') + 1;

          currentkey = splitkey[indexplus].substring(0, attrstartindex);
          currentattribute = splitkey[indexplus].substring(
            attrstartindex,
            attrlastindex,
          );
        }
        if (indexplus + 1 < splitkey.length) {
          nextkeyindex = indexplus + 1;
          if (splitkey[indexplus + 1].indexOf('{') == -1) {
            nextkey = splitkey[indexplus + 1];
          } else {
            attrstartindex = splitkey[indexplus + 1].indexOf('{');
            attrlastindex = splitkey[indexplus + 1].indexOf('}') + 1;

            nextkey = splitkey[indexplus + 1].substring(0, attrstartindex);

            nextattribute = splitkey[indexplus + 1].substring(
              attrstartindex,
              attrlastindex,
            );
          }
        }
        const retrivedobject = reccall(
          currentkey,
          currxmlobj,
          currentattribute,
        );
        if (retrivedobject && nextkey != '') {
          if (Object.keys(retrivedobject).length > 0) {
            const retcontent = reccall(nextkey, retrivedobject, nextattribute);
            if (nextkey === splitkey[splitkey.length - 1]) {
              return retcontent;
            }
            currxmlobj = retcontent;
          }
        } else {
          if (
            typeof retrivedobject == 'object' &&
            Object.keys(retrivedobject).includes('__WOText__')
          ) {
            const resultobj1 = Object.keys(retrivedobject).includes(
              '__WOText__',
            )
              ? retrivedobject.__WOText__
              : retrivedobject;
            return resultobj1;
          }
          if (
            Array.isArray(retrivedobject) &&
            retrivedobject.length &&
            Object.keys(retrivedobject[0]).includes('__WOText__')
          ) {
            const resultobj2 = retrivedobject[0].__WOText__;

            return resultobj2;
          }
          return retrivedobject;
        }
      } else {
        currxmlobj =
          currxmlobj.length > 0 &&
          Object.keys(currxmlobj[0]).includes('__WOText__')
            ? currxmlobj[0].__WOText__
            : currxmlobj;
        return currxmlobj;
      }
    }
  } catch (error) {
    return undefined;
  }
  return {};
};
const reccall = function (key, xmlobj, attributeType) {
  // attributeType = attributeType.replaceAll('"_"', '","');
  attributeType = attributeType.replace(/"_"/g, '","');

  let result = '';
  if (attributeType == '') {
    if (xmlobj.length == undefined) {
      result =
        xmlobj.length > 0
          ? xmlobj[0][key]
          : Object.keys(xmlobj).includes(key)
          ? xmlobj[key]
          : xmlobj;
    }
    if (xmlobj.length > 0) {
      if (
        xmlobj[0][key].length != undefined &&
        xmlobj[0][key].length > 1 &&
        Array.isArray(xmlobj[0][key])
      ) {
        // eslint-disable-next-line prefer-destructuring
        result = xmlobj[0][key][0];
      } else {
        result = xmlobj[0][key].__WOText__
          ? xmlobj[0][key].__WOText__
          : xmlobj[0][key];
        //  result = xmlobj[0][key];
      }
    }
  } else if (Object.keys(attributeType).length > 0) {
    const toFilter = JSON.parse(attributeType);
    const keys = Object.keys(toFilter);
    let objectof = {};

    objectof = Array.isArray(xmlobj)
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key]) && xmlobj.length > 0
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key])
      ? xmlobj[key]
      : [xmlobj[key]];

    if (Array.isArray(objectof)) {
      result = objectof.filter(x => {
        if (typeof x === 'object') {
          const matchs = keys
            .map(y => x[`__WOAttr__${y}`] == toFilter[y])
            .filter(z => z == true);
          return matchs.length == keys.length;
        }
        return '';
      });
      // console.log(result);
    } else if (typeof objectof === 'object') {
      let checkloop = true;
      keys.forEach(element => {
        if (objectof[`__WOAttr__${element}`] == toFilter[element]) {
          console.log(objectof[`__WOAttr__${element}`]);
        } else {
          console.log('failed');
          checkloop = false;
        }
      });

      if (checkloop == true && objectof.__WOText__) {
        result = objectof.__WOText__;
      } else {
        result = '';
      }
    }
  }
  console.log(result);
  return result;
};
