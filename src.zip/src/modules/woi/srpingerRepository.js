/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import { query } from '../../database/postgres.js';
// import { emitAction } from '../activityListener/index.js';
import { Service } from '../../httpClient/index.js';

const service = new Service();
export const insert_ftpdownloadstatus_springerbook = async (req, res) => {
  const output = {
    issuccess: false,
    message: '',
    zipid: 0,
  };

  try {
    const jsonobj = JSON.stringify(req.body);
    const sql = `select * from springer.insert_zipfilesinout('${jsonobj}')`;
    // const sql1 = `select * from springer.insert_book_ftpdownload_details('${jsonobj}')`;
    console.log(sql, 'insert_zipfilesinout');
    const resForEntry = await query(sql);
    if (resForEntry) {
      output.issuccess = true;
      output.message = 'success';
      output.zipid = resForEntry[0].insert_zipfilesinout;
    }
  } catch (e) {
    output.issuccess = false;
    output.message = e.message;
    output.zipid = 0;
  } finally {
    res.json(output);
  }
};
export const getConnectionParameter_Springer = async (req, res) => {
  try {
    const sql = `select serverpath,fileserverpath,downloadfolderpath,repeatedfolderpath,itracksintegrationneeded,uploadfolderpath from springer.ice_integrasettings where isactive='Y'`;
    const out = await query(sql);
    res.status(200).send({ data: out[0], status: 'Success' });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const updateDownloadFileStatus = async (req, res) => {
  try {
    let fileName = req.query.filename;
    let downloadedfilesize = req.query.downloadedfilesize;
    let remarks = req.query.remarks;
    let reasonforfailure = req.query.reasonforfailure;
    let fileStatus = req.query.currentfilestatusid;

    const sql = `update springer.ice_zipfilesinoutfolder set currentfilestatusid=${fileStatus}, downloadedfilesize='${downloadedfilesize}',remarks='${remarks}',reasonforfailure='${reasonforfailure}',downloadendtime=(select now()) where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const intiatefiledownloadupdate = async (req, res) => {
  try {
    let fileName = req.query.filename;
    let duplicatefilename = req.query.duplicatefilename;
    let remarks = req.query.remarks;
    const sql = `update springer.ice_zipfilesinoutfolder set currentfilestatusid =2,duplicatefilename='${duplicatefilename}',remarks='${remarks}',downloadstarttime=(select now()) where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getDownloadList_Springer = async (req, res) => {
  try {
    const sql = `select filenamewithtimestamp, originalfilesize, offsetno, duplicatefilename
     from springer.ice_zipfilesinoutfolder
     where islocked = 'N' and currentfilestatusid = 1
     order by positioninqueue asc;`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const getIncommingJobList = async (req, res) => {
  try {
    const sql = `SELECT zipFileId, fileNameWithTimeStamp, downloadEndTime, originalTimeStamp,filetype,journalid,articleid,journalyear,
     booktitleid,bookeditionnumber,booklanguage,seriesid,seriesyear,serieschapterid,filename
     FROM springer.ice_zipfilesinoutfolder
     WHERE currentFileStatusId = 3
       AND isLocked = 'N'
       AND isAcksent = 'N'
       AND downloadEndTime IS NOT NULL
       AND originalTimeStamp IS NOT NULL
     ORDER BY downloadEndTime ASC
     LIMIT 1`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const insertDuplicateID = async (req, res) => {
  try {
    let fileName = req.query.filename;
    const sql = `Insert into springer.ice_trnduplicateid(filenamewithtimestamp,status) VALUES('${fileName}',1) `;
    const out = await query(sql);
    const sqlSelect = `select duplicateid from springer.ice_trnduplicateid where filenamewithtimestamp ='${fileName}' and status=1 order by duplicateid `;
    const output = await query(sqlSelect);
    if (output.length > 0) {
      const sqlUpdate = `update springer.ice_trnduplicateid set status=2  where filenamewithtimestamp ='${fileName}' and duplicateid=${output[0]['duplicateid']}`;
      const updatestatus = await query(sqlUpdate);
    }
    res.status(200).send(output[0]['duplicateid']);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const insert_ftpFileWatcherStatus_springer = async (req, res) => {
  try {
    let jsonobj = req.body;
    const sql = `select filenamewithtimestamp
                    from springer.ice_zipfilesinoutfolder where filenamewithtimestamp ='${jsonobj.filenamewithtimestamp}' `;
    const out = await query(sql);
    if (out.length == 0) {
      //E => Error
      let max = 0;
      const sqlmax = `select max(positioninqueue)+1 from springer.ice_zipfilesinoutfolder`;
      const maxvalue = await query(sqlmax);
      if (maxvalue[0]['?column?'] == null) {
        max = 1;
      } else {
        max = maxvalue[0]['?column?'];
      }

      let fileStatus = jsonobj.fileType != 'E' ? 1 : 4;
      const sqlInset = `INSERT INTO springer.ice_zipfilesinoutfolder(
          filenamewithtimestamp, filename, filetype,journalid,articleid,journalyear,booktitleid,bookeditionnumber,booklanguage,seriesid,seriesyear,serieschapterid,originaltimestamp,positioninqueue,currentfilestatusid,originalfilesize,remarks,islocked,isacksent)
         VALUES ( '${jsonobj.filenamewithtimestamp}', '${jsonobj.fileName}', '${jsonobj.fileType}','${jsonobj.journalID}','${jsonobj.articleID}','${jsonobj.year}','${jsonobj.bookTitleID}','${jsonobj.editionNumber}','${jsonobj.language}','${jsonobj.seriesID}','${jsonobj.year}','${jsonobj.chapterID}','${jsonobj.ISOTimeStamp}','${max}','${fileStatus}','${jsonobj.fileSize}','${jsonobj.remark}','N','N')`;
      console.log(sqlInset, 'insertingfile');
      await query(sqlInset).then(() => {
        res
          .status(200)
          .json({ data: 'Query Inserted Successfully', status: 'Success' });
      });
    } else {
      res
        .status(200)
        .json({ data: 'Zipfile already available', status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const insert_InIOzipfilesInUpload = async (req, res) => {
  try {
    let jsonobj = req.body;
    const sql = `select iozipfileid
                    from springer.ice_iozipfilesinuploadfolder where filenamewithtimestamp ='${jsonobj.fileNameWithTimeStamp}'`;
    const out = await query(sql);
    if (out.length == 0) {
      let max = 0;
      const sqlmax = `select max(positioninqueue)+1 from springer.ice_iozipfilesinuploadfolder`;
      const maxvalue = await query(sqlmax);
      if (maxvalue[0]['?column?'] == null) {
        max = 1;
      } else {
        max = maxvalue[0]['?column?'];
      }

      const sqlInset = `INSERT INTO springer.ice_iozipfilesinuploadfolder (filenamewithtimestamp,orgzipfileid,jobsheettypeid,jobdetailsid,filename,
          filetype,journalid,articleid,journalyear,booktitleid,bookeditionnumber,booklanguage,originaltimestamp,positioninqueue,
          currentfilestatusid,filesizeretrycount,unzipretrycount,othersretrycount,islocked,resume,offsetno,islogreceived,originalfilesize,logstatusid,isactive,createdby)
          VALUES(
          '${jsonobj.fileNameWithTimeStamp}',
           ${jsonobj.zipFileId},1,0,
          '${jsonobj.fileName}',
          '${jsonobj.fileType}',
          '${jsonobj.journalID}',
          '${jsonobj.articleID}',
          '${jsonobj.journalYear}',
          '${jsonobj.bookTitleID}',
          '${jsonobj.editionNumber}',
          '${jsonobj.language}',
          '${jsonobj.originalTimeStamp}',
          ${max},1,0,0,0,'N','N',0,'N',${jsonobj.fileSize},3,'Y','ICE')`;
      const result = await query(sqlInset);
      if (result.length == 0) {
        const sqlLog = `Select iozipfileid from springer.ice_iozipfilesinuploadfolder where filenamewithtimestamp ='${jsonobj.fileNameWithTimeStamp}'`;
        const logValue = await query(sqlLog);
        if (logValue.length != 0) {
          const sqlLogInsert = `Insert into springer.ice_logfilecontent(iozipfileid,jobsheetcontent)values(${jsonobj.zipFileId},XMLPARSE(CONTENT'${jsonobj.ackJobsheetContent}'))`;
          const LogInsert = await query(sqlLogInsert);
          if (LogInsert.length == 0) {
            res
              .status(200)
              .json({ data: 'Log Inserted Successfully', status: 'Success' });
          }
        }
      }
    } else if (out.length > 0) {
      const sql = `update springer.ice_iozipfilesinuploadfolder set set isactive ='N' where jobdetailsid  ='${jsonobj.activeJobDetailsId}',and iozipfileid ='${out.iozipfileid}'`;
      const out = await query(sql);
      res
        .status(200)
        .json({ data: 'Data already available', status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getspringerbookftpdownloaddetail = async (req, res) => {
  try {
    const sql = `select max(zipid) as zipid,filenamewithtimestamp
                    from springer.trn_book_download_upload where isactive = true and
                    processdate :: date between current_date::date - interval '2 days' and current_date
                    group by filenamewithtimestamp
                    order by zipid`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getftpdownloadwithfilename = async (req, res) => {
  try {
    const { filename } = req.query;
    const sql = `select zipid,filenamewithtimestamp,filename,processdate,
   currentstatus,processtype,retrycount,remarks,jobcodeid,
   logstatus,currentjobsheettype,remotepath,logpath
   from springer.trn_book_download_upload where isactive = true and 
   lower(filenamewithtimestamp) = lower('${filename}')
   order by zipid desc limit 1`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getAllftpdownloaddata = async (req, res) => {
  try {
    // let{filename} = req.query;
    const sql = `select 
		rest.filenamewithtimestamp as parentfilenamewithtimestamp,
		rest.filename as parentfilename,
		res.zipfileid,res.filenamewithtimestamp,res.filename, res.journalid, res.articleid, 
		res.journalyear, res.originaltimestamp,res.createddate,
		res.currentfilestatusid, res.currentstatus,res.processtype,res.remarks,
		res.currentjobsheettype,res.stagename,res.parentzipfileid,res.logminuteswaiting,
		pst.bookstatus as parentzipstatus
			from (
			SELECT 
                row_number() over(partition by filename order by zipfileid desc) as rno,
                zipfileid,filenamewithtimestamp,filename, journalid, articleid, journalyear, originaltimestamp,createddate,
            currentfilestatusid,st.bookstatus as currentstatus,processtype,remarks,
            currentjobsheettype,stagename,parentzipfileid, 
    		(EXTRACT(EPOCH FROM ( now():: timestamp - createddate ::timestamp)) / 60 ) as logminuteswaiting
             from springer.ice_zipfilesinoutfolder as zipf
    		JOIN springer.mst_ftpbookstatus as st on st.bookstatusid = zipf.currentfilestatusid and isactive = true
            WHERE isactive = true and filename != '' and processtype = 2
			) as res 
    JOIN springer.ice_zipfilesinoutfolder as rest on rest.zipfileid= res.parentzipfileid
	JOIN springer.mst_ftpbookstatus as pst on pst.bookstatusid = rest.currentfilestatusid and pst.isactive = true
    where rno = 1 order by res.zipfileid desc;`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const insertsuccesswatcherdetail = async (req, res) => {
  try {
    const { zipfileid, logfilename, logreceivedon, logcontent, remark } =
      req.body;

    const sql = `insert into springer.successwatcherdetail
        (zipfileid,logfilename,logreceivedon,logcontent,remark,createdon) values
        ($1,$2,$3,$4,$5,$6)`;
    const out = await query(sql, [
      zipfileid,
      logfilename,
      logreceivedon,
      logcontent,
      remark,
      new Date(),
    ]);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getdownloadedfile = async (req, res) => {
  try {
    // let{filename} = req.query;
    const sql = `select rno,zipfileid,filename,filenamewithtimestamp from (select 
            row_number() over(partition by filenamewithtimestamp order by zipfileid desc) as rno,
        * from springer.ice_zipfilesinoutfolder ) as res where rno=1`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getEproofDetails = async (req, res) => {
  try {
    const sql = `select rno,xmlfileid,filenamewithtimestamp,statuscode from (select 
            row_number() over(partition by filename order by xmlfileid desc) as rno,
        * from springer.eproof_log_xml_details ) as res where rno=1`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const springerMailForAutoCreate = async (req, res) => {
  try {
    const { customerId, action, articlename } = req.body;

    console.log(articlename);
    // springer_acknowledge
    const sql = `SELECT * from wms_notifications WHERE customerid= ${customerId} and action='${action}' and isactive = true`;

    const resnotification = await query(sql);
    const notifrespdata = resnotification.length > 0 ? resnotification[0] : {};
    console.log(notifrespdata);
    const contactsql = `select cuscon.custorgmapid,contactname,contactemail,isprimary,contacttype,contactroleid
  from public.org_mst_customer as cus  
  join public.org_mst_customer_orgmap as cusorg on cusorg.customerid = cus.customerid 
  join public.org_mst_customerorg_contact as cuscon on cuscon.custorgmapid = cusorg.custorgmapid 
  join public.org_mst_division as div on div.divisionid = cusorg.divisionid and div.isactive = true
  join public.org_mst_subdivision as sdiv on sdiv.subdivisionid = cusorg.subdivisionid and sdiv.isactive = true
  join public.geo_mst_country as coun on coun.countryid = cusorg.countryid and coun.isactive = true
  WHERE cus.customername = 'Springer' and div.division = 'Academic' and sdiv.subdivision = 'Books' and contacttype = 'Customer'
  and cuscon.contactroleid in ('CM');`;

    const contactdata = query(contactsql).then(rescontact => {
      //
      if (rescontact.length > 0) {
        return rescontact;
      }
      return null;
    });

    console.log(contactdata);

    //   let toMailArray = [];
    //   const cmMailArray = [];

    //   cmMailArray.push(element.cmemail);

    //   const { type, notificationconfig } = resForConfig[0];
    //   if (type === 'mail') {
    //     const data = {
    //       actionType: type,
    //       ...notificationconfig,
    //       jobId: articlename,
    //       subMessage: subMsgToProduction || '',
    //       toMail: toMailArray,
    //       stageName,
    //       iteration,
    //       newSubject,
    //     };

    //
    //    // emitAction(data);

    //   }

    res.status(200).send('success');
  } catch (error) {
    res.status(400).send('failedsending email');
  }
};

export const insert_eproof_logDetails_for_springerBooks = async (req, res) => {
  const {
    filenamewithtimestamp,
    journalid,
    articleid,
    articledoi,
    statuscode,
    statusname,
    xmljson,
    filename,
    remarks,
    workorderid,
  } = req.body;
  try {
    const xml = JSON.stringify(xmljson);
    const sql = `INSERT INTO springer.eproof_log_xml_details(
    filenamewithtimestamp, journalid, articleid, articledoi, statuscode, status, xmljson, createdon,filename,remarks,workorderid)
   VALUES ('${filenamewithtimestamp}','${journalid}','${articleid}','${articledoi}','${statuscode}','${statusname}','${xml}',CURRENT_TIMESTAMP,'${filename}','${remarks}','${workorderid}') RETURNING xmlfileid`;
    const out = await query(sql);
    res.status(200).send({ data: out, message: 'success' });
  } catch (error) {
    res.status(400).send({ message: 'insert failed', data: error });
  }
};

export const insert_eproof_outDetails_for_springerBooks = async (req, res) => {
  const {
    filenamewithtimestamp,
    journalid,
    articleid,
    articledoi,
    statuscode,
    statusname,
    filename,
    fileavailable,
    filepath,
    workorderid,
  } = req.body;
  try {
    const sql = `INSERT INTO springer.eproof_log_xml_details(
    filenamewithtimestamp, journalid, articleid, articledoi, statuscode, status, createdon,filename,fileavailable,filepath,workorderid)
   VALUES ('${filenamewithtimestamp}','${journalid}','${articleid}','${articledoi}','${statuscode}','${statusname}',CURRENT_TIMESTAMP,'${filename}',${fileavailable},'${filepath}','${workorderid}') RETURNING xmlfileid`;
    const out = await query(sql);
    res.status(200).send({ data: out, message: 'success' });
  } catch (e) {
    res.status(400).send({ data: e, message: 'insert failed' });
  }
};

// export const insertMailDetails = async (req, res) => {
//   const { postMaildetails, status, xmlfileid } = req.body;
//   const { from, to, cc, subject } = postMaildetails;

//   console.log("output", req.body);

//   try {
//     // Convert status to boolean
//     const isSuccess = status === 'success' || 'Success';

//     const sql = `
//       INSERT INTO springer."stage300_logFolder_emailHistory"(
//         "mailTo", "mailFrom", subject, status, xmlfileid, cc,"mailSentdateTime","createdDateTime"
//       )
//       VALUES ($1, $2, $3, $4, $5, $6,CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata',CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')
//     `;

//     const values = [to, from, subject, isSuccess, xmlfileid, cc];

//     await query(sql, values);
//     res.status(200).send('Data inserted successfully');
//   } catch (error) {
//     res.status(400).send({ message: 'insert failed', data: error });
//   }
// };

export const insertMailDetails = async (req, res) => {
  const { postMaildetails, status, xmlfileid, statuscode } = req.body;
  const { from, to, cc, subject } = postMaildetails;

  console.log('output', req.body);

  try {
    const isSuccess = status.toLowerCase() === 'success';

    const sql = `SELECT COUNT(*) FROM springer."stage300_logFolder_emailHistory" 
                 WHERE xmlfileid = $1`;
    const outdata = await query(sql, [xmlfileid]);

    const { count } = outdata[0];
    if (count == 0) {
      const sql1 = `
      INSERT INTO springer."stage300_logFolder_emailHistory"(
        "mailTo", "mailFrom", subject, status, xmlfileid, cc,"mailSentdateTime","createdDateTime"
      )
      VALUES ($1, $2, $3, $4, $5, $6,CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata',CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')
    `;
      const values = [to, from, subject, isSuccess, xmlfileid, cc];
      const insertedData = await query(sql1, values);
      console.log('insertedData', insertedData);
    }
    if (statuscode == 10) {
      const existingMailDatetime = await query(
        `
        SELECT "mailSentdateTime"
        FROM springer."stage300_logFolder_emailHistory"
        WHERE xmlfileid = $1
        ORDER BY "mailSentdateTime" DESC
        LIMIT 1
      `,
        [xmlfileid],
      );
      console.log('existingMailDatetime', existingMailDatetime);

      // if (!existingMailDatetime[0] || (new Date() - existingMailDatetime[0].mailSentdateTime) >= 5 * 60 * 1000)
      if (
        existingMailDatetime[0] &&
        new Date() - existingMailDatetime[0].mailSentdateTime < 5 * 60 * 1000
      ) {
        const statuscode1 = await query(
          `
        SELECT statuscode
        FROM springer.eproof_log_xml_details
        WHERE xmlfileid = $1
      `,
          [xmlfileid],
        );
        console.log('statuscode1', statuscode1);
      }

      // Proceed with chaser mail calculation based on the status code
      // switch (statuscode) {
      //   case 10:
      //     // Call your chaser mail calculation function here
      //     // chaser_mail_calculation(xmlfileid);
      //     res.status(200).send('Record inserted and chaser mail calculation started successfully');
      //     break;
      //   case 20:
      //   case 50:
      //     // Send mail and insert into table
      //     // Call your send mail function here
      //     // sendMailFunction(postMaildetails, status, xmlfileid);
      //     res.status(200).send('Record inserted and mail sent successfully');
      //     break;
      //   case 30:
      //   case 40:
      //     // Stop chaser mail sending
      //     res.status(200).send('Record inserted, but chaser mail sending stopped');
      //     break;
      //   default:
      //     res.status(200).send('Record inserted successfully');
      //     break;
      // }
    } else {
      res
        .status(200)
        .send('Record not updated. Mail sent within the last 24 hours.');
    }
  } catch (error) {
    res.status(400).send({ message: 'Operation failed', data: error.message });
  }
};

export const getWorkOrderDetailsInfoForSpringer = async (req, res) => {
  try {
    const { articleID } = req.body;
    const sql = `select  eventlog.eventdata->>'processInstanceId' as processinstanceid, eventlog.wfeventid, details.articleid, trn.repofilepath, wo.workorderid, details.articledoi,details.statuscode from wms_workorder  as wo
     join springer.eproof_log_xml_details as details on details.articledoi = wo.doinumber
     left join wms_workflow_eventlog as eventlog on eventlog.workorderid = wo.workorderid
     join wms_workflowactivitytrn_file_map as trn on trn.wfeventid = eventlog.wfeventid
     where eventlog.wfdefid = 732  and details.articleid  = '${articleID}' order by eventlog.wfeventid desc limit 1`;
    const out = await query(sql);
    res.status(200).send({ data: out, message: 'success' });
  } catch (e) {
    res.status(400).send({ data: e, message: 'insert failed' });
  }
};

export const geteProof_log_xml_details = async (req, res) => {
  const sql = `select * from springer.eproof_log_xml_details where xmlfileid = ${req.body.data.xmlfileid}`;
  console.log('eproof_log_xml_details', sql);
  query(sql)
    .then(data => {
      console.log('eproof_log_xml_details', data);
      res.status(200).send({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// export const sendMailtoeProof = async (req, res) => {

// console.log("sendMailtoeProof",req.body);

//  // let toMailArray = [];
//     // const cmMailArray = [];

//     // cmMailArray.push(element.cmemail);

//     // const { type, notificationconfig } = resForConfig[0];
//     // if (type === 'mail') {
//     //   const data = {
//     //     actionType: type,
//     //     ...notificationconfig,
//     //     jobId: articlename,
//     //     subMessage: subMsgToProduction || '',
//     //     toMail: toMailArray,
//     //     stageName,
//     //     iteration,
//     //     newSubject,
//     //   };
//     //
//     // emitAction(data);
//     // }
// };
export const eProofMsgUpdate = async (req, res) => {
  const { msg, processInstanceId } = req.body;

  const variable = {
    messageName: 'eProofStatusMsg',
    processInstanceId,
    processVariables: {
      __isSuccess__: { value: msg, type: 'Boolean' },
    },
  };

  try {
    const triggerResponse = await service.post(
      `${process.env.CAMUNDA_NATIVE_URL}message`,
      variable,
    );
    res.status(200).send({ data: triggerResponse, message: 'success' });
  } catch (e) {
    res.status(400).send({ data: e, message: 'eproof variable update error' });
  }
};
