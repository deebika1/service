/* eslint-disable no-unused-vars */
/* eslint-disable */
import { transaction, query } from '../../database/postgres.js';
import { _upload } from '../utils/azure/index.js';
import { emitAction } from '../activityListener/index.js';
import { getNotificationTemplate } from '../common/index.js';
import { elsevierBookSchema } from './schema.js';
import { validator } from '../../helper/validator.js';
import { createJob, checkItracksExits } from '../iTracks/index.js';
import { _autoIncomingForArticleElsevier } from './incoming.js';
import { workorderlog } from './woAutocreation.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import { _nextIssueStageTransferCheckTrigger } from '../task/action/workflow/save.js';
import { addNewFileType } from '../../../src/modules/woi/incoming.js';

const service = new Service();

let mailContainer = {
  action: '',
  from: '',
  to: '',
  customerName: '',
  customerId: '',
  stageName: '',
  iteration: '',
  subject: '',
  template: '',
  text: '',
};
let logId = 0;
// book creation module
export const autoBookWorkorderCreation = async (req, res) => {
  try {
    const payload = req.body;
    const response = await _autoBookWorkorderCreation(payload);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};
// create auto issue workorder creation
export const _autoBookWorkorderCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      payload.woTypeId = 2;
      // fields validation
      if (!payload) {
        throw new Error('Payload is required');
      }
      let schema = '';
      if (payload.customer === 'Elsevier') {
        schema = elsevierBookSchema;
      }
      // const validate = validator(payload, schema);
      // if (!validate.status) {
      //   throw new Error(validate.message);
      // }
      // --------- start the process ------ //
      const logRes = await woCreateLog(payload, 'Insert');
      logId = logRes.autologid;
      // await checkWOExists(payload);
      payload = await constructPayloadForWorkorderCreation(payload);
      const { workorderId, message } = await woCreationProcess(payload);

      // if (true) {
      //   // auto incoming creation
      //   const incomingPayload = await constructIncomingPayload(payload);
      //   const resOfIncoming = await _autoIncomingForArticleElsevier(
      //     incomingPayload,
      //   );
      // }

      // payload for mail
      mailContainer.action = 'auto_create_success';
      mailContainer.woTypeId = payload.woTypeId;
      mailContainer.subject = `Work order creation successfull for the title ${payload.title}`;
      mailContainer.message = message;
      mailContainer.customerId = payload.customerId;
      mailContainer.title = payload.title;
      mailContainer.stageName = payload.stage;
      // payload for workorder log
      payload.logMessage = message;
      payload.isSuccess = true;
      payload.workorderId = workorderId;
      payload.isStagetrigger = true;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      resolve({
        message: message,
        status: true,
        data: {
          workorderId: workorderId,
          pathToUpload: '',
        },
      });
    } catch (e) {
      if (payload.customerId) {
        mailContainer.customerId = payload.customerId;
        mailContainer.action = 'auto_create_failure';
      } else {
        mailContainer.action = 'auto_create_common_failure';
        // get customer details from customer name
        const sql = `SELECT customerid FROM org_mst_customer WHERE LOWER(customername) = LOWER('${payload.customer}')`;
        const response = await query(sql);
        const customerId = response.length ? response[0].customerid : 0;
        mailContainer.customerId = customerId;
      }
      mailContainer.woTypeId = payload.woTypeId;
      mailContainer.subject = mailContainer.subject
        ? mailContainer.subject
        : `Work order creation failed for the title ${payload.title}`;
      mailContainer.message = e.message ? e.message : e;
      mailContainer.title = payload.title;
      mailContainer.stageName = payload.stage;
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      payload.isStagetrigger = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject({
        message: e.message ? e.message : e,
        status: false,
      });
    }
  });
};

// workorder create log
const woCreateLog = (data, action) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        customer,
        jobType,
        woType,
        workorderId,
        logMessage,
        isSuccess,
        isStagetrigger,
        title,
        stage,
        ftpAuditId,
        extention,
      } = data;
      let sql = ``;
      if (action == 'Insert') {
        sql = `INSERT INTO log_autowocreate(apiinput,customer,filetype,wotype,jobtype,trigerarticle,trigerstage,ftpauditid) VALUES ('${JSON.stringify(
          data,
        )}', '${customer}','${extention}','${woType}','${jobType}','${title}','${stage}',${ftpAuditId}  ) RETURNING autologid`;
      } else {
        sql = `UPDATE public.log_autowocreate
        SET customer='${customer}', filetype='${extention}', wotype='${woType}', jobtype='${jobType}', payload='${JSON.stringify(
          data,
        )}', workorderid=${
          workorderId || null
        }, logmessage='${logMessage}', issuccess=${isSuccess}, isstagetrigger=${
          isStagetrigger || false
        }, trigerarticle='${title}', trigerstage='${
          stage || null
        }', ftpauditid=${ftpAuditId}

        WHERE autologid=${logId} RETURNING autologid`;
      }
      const response = await query(sql);
      resolve(response[0]);
    } catch (e) {
      reject(e);
    }
  });
};

// construct payload for workorder creation
const constructPayloadForWorkorderCreation = async item => {
  return new Promise(async (resolve, reject) => {
    const { customer, duId, serviceId } = item;
    try {
      // get journal information from customer and journal acronym
      const contactDetail = await getCustomerContactDetail(item);
      if (contactDetail) {
        // change string to integer from contactDetails array
        contactDetail.customer = parseInt(item.customer);
        contactDetail.division = parseInt(item.division);
        contactDetail.subDivision = parseInt(item.subDivision);
        contactDetail.country = parseInt(item.country);
        contactDetail.duId = duId;

        contactDetail.custOrgMapId = parseInt(contactDetail.custOrgMapId);
        contactDetail.services = serviceId;
        contactDetail.custPrimaryContact = contactDetail.primaryContact;
        contactDetail.custSecondaryContact = contactDetail.secondaryContact;
        contactDetail.kamName = contactDetail.KAMContact;
        contactDetail.clientManager = contactDetail.CMContact;
        contactDetail.projectManager = contactDetail.PMContact;

        let sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE duid=$1 and customerid=$2`;
        const dmsInfo = await query(sql, [duId, customer]);

        const { dmsid } = dmsInfo.length ? dmsInfo[0] : '';
        if (dmsid) {
          const externalUsers = item.externalUsers;

          //data.colours
          let colorSql = `select colorid, * from public.pp_mst_color where color = '${item.colours}'`;
          const responsecolor = await query(colorSql);
          item.colours = responsecolor[0].colorid;

          //data.languages
          let langSql = `select languageid,* from public.wms_mst_language where languagename = '${item.languages}'`;
          const responselang = await query(langSql);
          item.languages = responselang[0].languageid;

          //ce level
          //data.languages
          let ceSql = `select celevelid from pp_mst_copyeditinglevel pmc  where upper(displayname) = Upper('${item.CELevel}')`;
          const responseCE = await query(ceSql);
          item.CELevel = responseCE[0].celevelid;

          //logoid
          let logosql = `select trndrop.id as value, trndrop.value as label from wms_mst_dropdown as drops
                   join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
                    where drops.fieldname like '%logoid%' and  trndrop.value like '%${item.logo}%'`;
          const responselogo = await query(logosql);
          item.logoid = responselogo[0].value;

          const payload = {
            ...item,
            ...contactDetail,
            customerId: customer,
            userId: item.createdBy,
            jobId: item.title,
            jobTitle: item.description,
            externalUsers: externalUsers,
            dmsId: dmsid,
          };
          resolve(payload);
        } else {
          mailContainer.action = 'common_failure';
          mailContainer.subject = `DMS type not mapping for the customer ${customer}`;
          mailContainer.message = `DMS type not mapping for the customer ${customer}`;
          throw new Error(`DMS type not mapping for the customer ${customer}`);
        }
      } else {
        mailContainer.action = 'common_failure';
        mailContainer.subject = `Work order creation failed for due to journal details not found for the customer ${customer}`;
        mailContainer.message = `Journal details not found for the customer ${customer}`;
        throw new Error(
          `Journal details not found for the customer ${customer}`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

// workorder creation
const woCreationProcess = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // check iTracks exists for customer
      const iPayload = {
        customerId: payload.customer,
        duId: payload.duId,
        userId: payload.createdBy,
      };
      const { status } = await checkItracksExits({ body: iPayload }, {});
      let jobStatus = true;
      // to be changed once itracks enabled
      if (status) {
        //  create job card in iTracks
        jobStatus = await createJob(payload);
      }
      if (jobStatus) {
        let result = {};
        await transaction(async client => {
          result = await creation(payload, client);
        });
        const { data, message } = result;
        payload.workorderId = data.workorderid;
        resolve({ workorderId: data.workorderid, status: true, message });
      } else {
        throw new Error('Job creation failed in iTracks');
      }
    } catch (e) {
      // Mail trigger for error
      mailContainer = {
        action: 'auto_create_failure',
        woTypeId: payload.woTypeId,
        title: payload.title,
        to: [],
        customerId: payload.customer,
        stageName: payload.stage,
        duId: payload.duId,
        subject: `Work order creation failed for the title - ${payload.title}`,
        message: e.message ? e.message : e,
      };
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject(e);
    }
  });
};
export const checkMergingTitleComplete = data => {
  return new Promise(async (resolve, reject) => {
    const { mergeArticleInfo, title } = data;
    try {
      const sql = `SELECT itemcode FROM wms_workorder WHERE itemcode=$1 AND status=$2`;
      console.log(sql, 'sql for wo exists');
      const result = await query(sql, [mergeArticleInfo, 'Completed']);
      if (result.length == mergeArticleInfo.length) {
        resolve(true);
      } else {
        const data = mergeArticleInfo.map(item => `'${item}'`).join(', ');
        const sql = `UPDATE wms_workorder SET status='Completed' WHERE itemcode in (${data}) `;
        console.log(sql, 'sql for wo exists');
        const result = await query(sql);
        resolve(true);
        // reject({
        //   status: false,
        //   message: `One of the articles was not completed for the title - ${title}`,
        // });
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const checkWOExists = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { title, doiNumber } = data;
      const job = title ? title.trim() : '';
      const doi = doiNumber ? doiNumber.trim() : '';
      let condition = `WHERE itemcode='${job}'`;
      if (doi) {
        condition = `WHERE itemcode='${job}'  OR doinumber='${doi}'`;
      }

      const sql = `SELECT itemcode FROM public.wms_workorder ${condition} `;
      console.log(sql, 'sql for wo exists');
      const result = await query(sql);
      if (result.length) {
        reject({
          status: false,
          message: `Workorder already exists for the title - ${title}`,
        });
      } else {
        resolve({
          status: true,
          message: `Workorder not exists for the title - ${title}`,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        action,
        woTypeId,
        title,
        to,
        customerId,
        workorderId,
        serviceId,
        duId,
        message,
        stageName,
      } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        woTypeId,
        duId,
        customerId,
        workorderId,
        serviceId,
        stageName,
      };
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        stageName,
        subMessage: message,
        toMail: toMailArray,
      };
      emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      console.log(e, 'ee');
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};

// get journal details from customer and journal acronym
const getCustomerContactDetail = data => {
  const { customer, division, subDivision, country } = data;
  return new Promise(async (resolve, reject) => {
    try {
      let contactInfo = {};
      let sql = `SELECT tbl1.custorgmapid, tbl2.custorgconmapid, tbl2.contactname, tbl2.contacttype, tbl2.isprimary, tbl2.contactroleid FROM org_mst_customer_orgmap as tbl1
      JOIN org_mst_customerorg_contact as tbl2 ON tbl2.custorgmapid = tbl1.custorgmapid
      WHERE tbl1.customerid=${customer} AND tbl1.divisionid=${division} AND tbl1.subdivisionid=${subDivision} AND tbl1.countryid=${country}`;
      const journalContactRes = await query(sql);
      if (journalContactRes.length) {
        journalContactRes.forEach(list => {
          if (list.isprimary && list.contacttype === 'Customer') {
            contactInfo.primaryContact = list.custorgconmapid;
          } else if (!list.isprimary && list.contacttype === 'Customer') {
            contactInfo.secondaryContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'KAM' &&
            list.contacttype === 'Integra'
          ) {
            contactInfo.KAMContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'CM' &&
            list.contacttype === 'Integra'
          ) {
            contactInfo.CMContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'PM' &&
            list.contacttype === 'Integra'
          ) {
            contactInfo.PMContact = list.custorgconmapid;
          }
        });
        contactInfo.custOrgMapId = journalContactRes[0].custorgmapid;

        resolve(contactInfo);
      } else {
        reject({
          message: `Journal details not found for the customer ${customer} `,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};
// Workorder creation with transaction
export const creation = async (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { emailOrderDate } = data;
      const orderDate = emailOrderDate
        ? `'${emailOrderDate}'`
        : 'current_timestamp';

      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          if (data[key] === undefined) {
            data[key] = null;
          }
        }
      }
      let otherFields = data.otherFields;

      if (typeof otherFields !== 'string') {
        otherFields = JSON.stringify(otherFields);
      }

      // insert query for workorder creation in wms_workorder table
      let sql = `INSERT INTO public.wms_workorder(
        itemcode, title, projectbrief, printisbn, eisbn, issn, edition, customerid, 
        divisionid, subdivisionid, countryid, colorid, composingsoftwareid, inputfiletypeid, 
        languageid, celevelid, indextypeid, category, status, trimsizewidth, trimsizewidthuom,
        trimsizeheight, trimsizeheightuom, orderemailpath, orderemailpathuuid, totalchaptercount, 
        ordermaildate, journalid, jobtype, doinumber, wotype, totalarticlecount, totalnonarticlecount, 
        issuenumber, volumenumber, jobcardid, dmsid, createdby, duid, wfid,logoid,paperbackisbn, otherfield
        )
        VALUES (
          '${data.jobId}', 
          '${data.jobTitle}',
          ${data.projectBrief ? `'${data.projectBrief}'` : null},
          ${data.printISBN ? `'${data.printISBN}'` : null},
          ${data.eISBN ? `'${data.eISBN}'` : null},
          ${data.ISSN ? `'${data.ISSN}'` : null},
          ${data.edition ? `'${data.edition}'` : null},
          ${data.customer ? data.customer : null}, 
          ${data.division ? data.division : null}, 
          ${data.subDivision ? data.subDivision : null}, 
          ${data.country ? data.country : null},
          ${data.colours ? data.colours : null}, 
          ${data.softwares ? data.softwares : null}, 
          ${data.inputFileTypes ? data.inputFileTypes : 4},
          ${data.languages ? data.languages : null}, 
          ${data.CELevel ? data.CELevel : null}, 
          ${data.indexType ? data.indexType : null},
          ${data.category ? `'${data.category}'` : null}, 
          'In Process',
          ${data.pageWidth ? data.pageWidth : null},
          ${data.pageWidthUnit ? `'${data.pageWidthUnit}'` : null},
          ${data.pageHeight ? data.pageHeight : null},
          ${data.pageHeightUnit ? `'${data.pageHeightUnit}'` : null},
          ${data.orderEmailPath ? `'${data.orderEmailPath}'` : null},
          ${data.orderEmailPathUuid ? `'${data.orderEmailPathUuid}'` : null},
          ${data.noOfChapters ? data.noOfChapters : null}, 
          ${orderDate ? orderDate : null}, 
          ${data.journalId ? data.journalId : null}, 
          ${data.jobTypeId ? `'${data.jobTypeId}'` : null}, 
          ${data.doiNumber ? `'${data.doiNumber}'` : null},
          ${data.woType ? `'${data.woType}'` : null}, 
          ${!isNaN(parseInt(data.noOfArticles)) ? data.noOfArticles : null},
          ${
            !isNaN(parseInt(data.noOfNonArticles)) ? data.noOfNonArticles : null
          },
          ${data.issueNumber ? `'${data.issueNumber}'` : null}, 
          ${data.volumeNumber ? `'${data.volumeNumber}'` : null}, 
          ${data.jobCardId ? data.jobCardId : null}, 
          ${data.dmsId ? data.dmsId : null}, 
          ${data.userId ? `'${data.userId}'` : `'System'`}, 
          ${data.duId ? data.duId : null}, 
          ${data.wfId ? data.wfId : null},
           ${data.logoid ? `'${data.logoid}'` : null}, 
          ${data.paperBackISBN ? data.paperBackISBN : null},
          ${otherFields ? `'${otherFields}'` : null}
        ) RETURNING workorderid, customerid`;
      const response = await query(sql);
      const { workorderid } = response[0];
      // insert query for workorder contact details in wms_workorder_contact table
      // get contact detsils from org_mst_customerorg_contact_map table
      const getContactValues = `SELECT ${workorderid},custorgconmapid, contactname,contactemail,contactphone1,contactphone2,contactroleid,contacttype,isprimary 
          FROM org_mst_customerorg_contact WHERE custorgconmapid IN (${
            data.custPrimaryContact
          },${data.custSecondaryContact},
              ${data.kamName},${data.clientManager} ${
        data.subDivision !== 9 ? `,'${data.projectManager}'` : ''
      }) `;

      sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary)
          ${getContactValues} 
          RETURNING workorderid`;

      await client.query(sql);
      // insert query for pm entry to wms_workorder_contact table
      if (data.subDivision == 9) {
        const journalMappedPm = await workorderJournalMappedPmEntry(
          {
            projectManager: data.projectManager,
            supplierProjectManager: data.supplierProjectManager,
            workorderid,
          },
          client,
        );
      }
      let externalUserRes = [];
      if (
        data.externalUsers &&
        Object.keys(data.externalUsers).length &&
        data.externalUsers !== '{}'
      ) {
        externalUserRes = await workorderExternalUserEntry(
          { externalUsers: data.externalUsers, workorderid },
          client,
        );
      }
      const serviceResponse = await workorderServiceEntry(
        {
          duId: data.duId,
          services: data.services,
          custOrgMapId: data.custOrgMapId,
          workorderid,
          wfId: data.wfId,
        },
        client,
      );
      const { serviceid } = serviceResponse.data;
      await workorderStageEntry(
        {
          workorderid,
          wfId: data.wfId,
          serviceId: serviceid,
          userId: data.userId,
          plannedStartDate: data.plannedStartDate,
          plannedEndDate: data.plannedEndDate,
          receivedDate: data.plannedStartDate,
        },
        client,
      );
      resolve({
        data: { workorderid },
        message: `workorder created successfully (${workorderid})`,
      });
    } catch (e) {
      reject(e);
    }
  });
};

// journal mapped pm entry insert into wms_workorder_contact table
const workorderJournalMappedPmEntry = (payload, client) => {
  const { projectManager, supplierProjectManager, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${projectManager}' AND wms_userrole.roleid = 1
      UNION ALL
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${supplierProjectManager}' AND wms_userrole.roleid = 9
      `;

      const { rows } = await client.query(sql);
      let userArray = rows;
      if (projectManager == supplierProjectManager) {
        userArray = [].concat(rows, rows);
      }

      const val = [];
      userArray.forEach((list, i) => {
        val.push(`(${workorderid},'${list.contactname}','${
          list.contactemail
        }','${list.contactphone1}',
    '${list.roleacronym}', 'Integra' , ${i == 0}, '${list.userid}',${
          list.roleid
        })`);
      });
      sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, 
    contactphone1, contactrole, contacttype, isprimary, userid, roleid)
    VALUES ${val} RETURNING workorderid`;

      await client.query(sql);
      resolve({
        message: `Journal mapped pm added successfully (${workorderid})`,
      });
    } catch (e) {
      reject({ message: `Journal mapped pm added failed (${workorderid})` });
    }
  });
};
// external user entry insert into wms_workorder_contact table
const workorderExternalUserEntry = (payload, client) => {
  const { externalUsers, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const val = [];
      externalUsers.forEach(list => {
        val.push(`(${workorderid},'${list.name}','${list.email}',${
          list.phone1 ? `'${list.phone1}'` : null
        },
              '${list.roleAcronym}', 'Customer' , false, ${list.role})`);
      });

      const sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, contactphone1, contactrole, contacttype, isprimary, roleid)
              VALUES ${val} RETURNING contactrole,contactname,contactemail `;

      await client.query(sql);
      resolve({ message: `External user added successfully (${workorderid})` });
    } catch (e) {
      reject({ message: `External user added failed (${workorderid})` });
    }
  });
};
// workorder service entry insert into wms_workorder_service table
const workorderServiceEntry = (payload, client) => {
  const { duId, services, custOrgMapId, workorderid, wfId } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const getDataQuery = `SELECT DISTINCT ON ( org_mst_customerorg_service_map.serviceid) org_mst_customerorg_service_map.serviceid,org_mst_deliveryunit.duid, org_mst_deliveryunit.duid as assignedduid, org_mst_deliveryunit.duid as internalbilling,true, ${workorderid}, ${wfId}, 'YTS' as status
      FROM org_mst_customerorg_service_map
      JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customerorg_service_map.custorgmapid
      JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = org_mst_customerorg_du_map.duid
      WHERE  org_mst_customerorg_service_map.serviceid IN (${services}) AND org_mst_customerorg_service_map.custorgmapid = ${custOrgMapId}
      AND org_mst_deliveryunit.duid = ${duId}`;
      const sql = `INSERT INTO public.wms_workorder_service(serviceid, baseduid, assignedduid,internalbilling,iscustomerbillable ,workorderid, wfid, status)
      ${getDataQuery} RETURNING woserviceid, workorderid, serviceid`;

      const { rows } = await client.query(sql);
      resove({
        message: `Service added successfully (${workorderid})`,
        data: { ...rows[0] },
      });
    } catch (e) {
      reject({ message: `Service added failed (${workorderid})` });
    }
  });
};
// workorder stage entry insert into wms_workorder_stage table
const workorderStageEntry = (payload, client) => {
  const {
    workorderid,
    wfId,
    serviceId,
    userId,
    plannedStartDate,
    plannedEndDate,
    receivedDate,
  } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const sqlQuery = `with cte as (SELECT DISTINCT ON(stageid) stageid, sequence
      FROM wms_workflowdefinition
      WHERE wfid IN (${wfId}) AND lock = false ) select * from cte order by sequence`;

      const { rows } = await client.query(sqlQuery);
      if (rows.length) {
        const values = [];
        rows.forEach((stage, i) => {
          if (i === 0) {
            values.push(
              `(${serviceId},${
                stage.stageid
              },'${userId}',${workorderid}, 'YTS', 1, ${
                i + 1
              }, current_timestamp, current_timestamp, ${
                plannedEndDate ? `'${plannedEndDate}'` : `current_timestamp`
              }, ${receivedDate ? `'${receivedDate}'` : `current_timestamp`} )`,
            );
          } else {
            values.push(
              `(${serviceId},${stage.stageid},'${userId}',${workorderid}, 'YTS', 1, ${stage.sequence}, current_timestamp, null, null, null)`,
            );
          }
        });
        const sql = `INSERT INTO public.wms_workorder_stage(serviceid, wfstageid, updatedby, workorderid, status, stageiterationcount, sequence, updatedon, plannedstartdate, plannedenddate, ordermaildatetime)
        VALUES ${values} RETURNING workorderid`;

        await client.query(sql);
        resove({ message: `Stage added successfully (${workorderid})` });
      } else {
        reject({ message: `No stages found the workorder (${workorderid})` });
      }
    } catch (e) {
      reject({ message: `Stage added failed (${workorderid})` });
    }
  });
};
// TAT calculation update for stages in wms_workorder_stage table
const tatCalculationForStages = (payload, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderid, customerId, journalId } = payload;
      const sql = `UPDATE wms_workorder_stage AS st SET plannedstartdate = cte.p_startdate ,plannedenddate = cte.p_duedate 
			FROM get_wo_autocreation_tat(${workorderid}::bigint,${customerId}:: bigint,${journalId}::bigint,1::integer) AS cte
			WHERE cte.p_wostageid = st.wostageid;`;

      await client.query(sql);
      resolve({ message: 'Stage TAT updated successfully' });
    } catch (e) {
      reject({ message: 'Stage TAT updated failed' });
    }
  });
};

// get common path agdinst the wo and stage
const getCommonPathForStage = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { title, stage } = payload;
      const pathType = 'wo_stage_iteration_mail';
      const sql = `select a.workorderid,  a.customerid,i.customername, d.assignedduid, h.duname, d.wfid ,
         f.stageid,f.stagename, e.stageiterationcount,g.serviceid,g.servicename,
         concat('{"type": "'|| '${pathType}' :: text||'",
         "du":{"name":"', h.duname,'","id":"',d.assignedduid,'"},
         "customer":{"name":"',i.customername,'","id":"',a.customerid,'"},
         "workOrderId":"',a.workorderid,'",
         "service":{"name":"',g.servicename,'","id":"',g.serviceid,'"},
         "stage":{"name":"',f.stagename,'","id":"',f.stageid,'","iteration":"',e.stageiterationcount,'"}}') as stagepathpayload
        from wms_workorder a
        join wms_workorder_service d on d.workorderid = a.workorderid 
        join wms_workorder_stage e on e.workorderid = a.workorderid and d.serviceid = e.serviceid  
        join wms_mst_stage f on f.stageid = e.wfstageid and f.isactive = true
        join wms_mst_service g on g.serviceid = e.serviceid and g.isactive = true
        join org_mst_deliveryunit h on h.duid = d.assignedduid and h.isactive = true
        join org_mst_customer i on i.customerid = a.customerid
        where a.itemcode = '${title}' and f.stagename = '${stage}'`;

      const pathRes = await query(sql);
    } catch (e) {}
  });
};

//get elsevier chapter details
export const getChapterDetails = async (req, res) => {
  try {
    console.log('thii');
    const payload = req.body;
    let sql = `SELECT 
  wo.workorderid, 
  wo.itemcode, 
  woif.woincomingfileid,
  wf.stageid,
  woif.filename as chapterName
FROM 
  wms_workorder AS wo
JOIN 
  wms_workorder_incoming AS woi 
    ON woi.woid = wo.workorderid
JOIN 
  wms_workorder_incomingfiledetails AS woif 
    ON woif.woincomingid = woi.woincomingid 
JOIN
	wms_workflow_eventlog as we
	ON we.workorderid= wo.workorderid
JOIN
	wms_workflowdefinition as wf
	ON wf.wfdefid= we.wfdefid
WHERE 
  woif.piinumber = '${payload.pii}' order by we.wfeventid desc limit 1 `;
    const info = await query(sql);
    if (info.length) res.status(200).json({ status: true, data: info });
    else res.status(400).send({ status: false, data: 'No data' });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

//to enable other filetypes in elsevier books

export const getOtherFiles = async (req, res) => {
  try {
    console.log('thii');
    const payload = req.body;
    let sql = ` select * from wms_workorder_stage where workorderid = (select workorderid from wms_workorder 
 where itemcode = '${payload.isbn}') and wfstageid = 2 and status = 'YTS'`;
    const info = await query(sql);

    if (info.length) {
      let sql1 = `SELECT woincomingfileid 
FROM public.wms_workorder_incomingfiledetails 
WHERE woincomingid IN (
    SELECT woincomingid 
    FROM public.wms_workorder_incoming 
    WHERE woid = (
        SELECT workorderid 
        FROM public.wms_workorder 
        WHERE itemcode = '${payload.isbn}'
    )
) 
AND filetypeid <> 2 
ORDER BY 1 DESC`;
      const info1 = await query(sql1);
      if (info1.length) {
        res.status(200).json({ status: true, data: info1 });
      } else res.status(400).send({ status: false, data: 'No data' });
    } else {
      res
        .status(400)
        .send({ status: false, data: 'Non Chapters are note available' });
    }
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

//to get all the files of els books

export const getAllFiles = async (req, res) => {
  try {
    console.log('thii');
    const payload = req.body;

    // let sql= `select workorderid from wms_workorder where itemcode = ''${payload.itemcode}'' and isactive ='true'`;

    //     const info = await query(sql);
    //     payload.woid=  info[0].itemcode
    //     payload.fileTypeId= 5;
    // await addNewFileType(payload,5);

    let sql1 = `SELECT woincomingfileid ,filename as chapterName, filetypeid
FROM public.wms_workorder_incomingfiledetails 
WHERE woincomingid IN (
    SELECT woincomingid 
    FROM public.wms_workorder_incoming 
    WHERE woid = (
        SELECT workorderid 
        FROM public.wms_workorder 
        WHERE itemcode = '${payload.isbn}'
    )
) 
ORDER BY 1 DESC`;
    const info1 = await query(sql1);
    if (info1.length) {
      res.status(200).json({ status: true, data: info1 });
    } else res.status(400).send({ status: false, data: 'No data' });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

//to add cover file for els books

export const addCoverFiles = async (req, res) => {
  try {
    console.log('add cover file');
    const payload = req.body;

    let sql = `select workorderid from wms_workorder where itemcode = '${payload.itemcode}' and isactive ='true'`;

    const info = await query(sql);
    req.body.woid = info[0].workorderid;
    req.body.fileTypeId = 5;
    req.body.isElsBooks = true;
    req.body.service = {};
    req.body.service.id = 1;

    let sql1 = `SELECT woincomingfileid ,filename as chapterName, filetypeid
    FROM public.wms_workorder_incomingfiledetails 
    WHERE woincomingid IN (
        SELECT woincomingid 
        FROM public.wms_workorder_incoming 
        WHERE woid = (
            SELECT workorderid 
            FROM public.wms_workorder 
            WHERE itemcode = '${payload.itemcode}'
        )
    ) 
    ORDER BY 1 DESC`;
    const info1 = await query(sql1);
    req.body.valuesOfArray = info1;

    const response = await addNewFileType(req, 15);

    if (response) {
      res.status(200).json({ status: true, data: response });
    } else res.status(400).send({ status: false, data: 'No data' });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

//to get the workflowid

export const getWorkflowId = async (req, res) => {
  try {
    console.log('thii');
    const payload = req.body;

    let sql1 = `select wfid from pp_mst_journal_workflow jw join pp_mst_journal j on jw.journalid = j.journalid 
where journalacronym = '${payload.journalacronym}'`;
    const info1 = await query(sql1);
    if (info1.length) {
      res.status(200).json({ status: true, data: info1 });
    } else res.status(400).send({ status: false, data: 'No data' });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
