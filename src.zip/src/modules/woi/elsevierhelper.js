import {
  updStageTatJouConfig,
  updStageTatAudit,
} from './autoArticleWoContainer.js';

export const ElsUpdPckgReqpbTask = async (
  client,
  workorderId,
  relatedStageInfo,
) => {
  return new Promise((resolve, reject) => {
    try {
      const promises = relatedStageInfo.map(x => {
        const sql1 = `
          WITH updreq AS (
            UPDATE public.trn_updatedrequest
            SET isactive = false
            WHERE workorderid = $1 AND stageid = $2
              AND stageiterationcount = $3 AND isactive = true
            RETURNING true as res
          ),
          updPrbTsk AS (
            UPDATE public.trn_problemtask pt
            SET isactive = false
            FROM wms_mst_stage wms
            JOIN trn_problemtask_log tpl ON tpl.pb_id = tpl.pb_id
            WHERE wms.stagename = pt.stage AND
                  pt.woid = $1 AND wms.stageid = $2 
                  AND stage_iteration = $3 AND pt.isactive = true AND tpl.status = 'Approved' AND tpl.pb_id = pt.id
            RETURNING true as res
          )
          SELECT updreq.res, updPrbTsk.res FROM updreq, updPrbTsk;
        `;

        return client.query(sql1, [
          workorderId,
          x.stageId,
          x.stageiterationcount,
        ]);
      });

      // Wait for all promises to resolve
      Promise.all(promises)
        .then(() => resolve())
        .catch(err => reject(err));
    } catch (e) {
      reject(e);
    }
  });
};

export const ElsInsertUpdPckgReq = async (
  client,
  workorderId,
  relatedStageInfo,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const insValues = relatedStageInfo
        .map(
          x => `(${workorderId}, ${x.stageId}, ${x.stageiterationcount}, true)`,
        )
        .join(',');

      const sql2 = `
        INSERT INTO public.trn_updatedrequest (workorderid, stageid, stageiterationcount, isactive) 
        VALUES ${insValues};
      `;
      await client.query(sql2);
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const ElsUpdStageAutoTat = async (client, workorderId, revisedTat) => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        workorderid: workorderId,
        stages: revisedTat.stageIds,
        revisedTat: true,
      };
      await updStageTatJouConfig(payload, client);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const ElsUpdStageTat = async (client, workorderId, revisedTat) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `update wms_workorder_stage set plannedenddate = $1, revisedenddatetime = $1, updatedon = current_timestamp where workorderid = $2 and wfstageid= $3`;
      await client.query(sql, [
        revisedTat.plannedEndDate,
        workorderId,
        revisedTat.stageId,
      ]);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const ElsUpdStageTatAudit = async (client, workorderId, revisedTat) => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        workorderid: workorderId,
        stages: revisedTat.stageIds
          ? revisedTat.stageIds
          : [revisedTat.stageId],
      };
      await updStageTatAudit(payload, client);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const ElsUpdateRevisedData = async (
  client,
  workorderId,
  revisedData,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const WOUpdQuery = await ElsWOUpdQuery(revisedData, workorderId);
      if (WOUpdQuery) await client.query(WOUpdQuery);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const ElsWOUpdQuery = async (revisedData, workorderId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { suppliment } = revisedData;
      const setClause = [];
      if (suppliment) {
        setClause.push(
          `otherfield = jsonb_set(otherfield::jsonb, '{suppliment}', '${suppliment}')::json`,
        );
      }

      if (setClause.length === 0) {
        resolve(false);
      }

      const query = `UPDATE wms_workorder SET ${setClause.join(
        ', ',
      )} WHERE workorderid = ${workorderId}`;

      resolve(query);
    } catch (e) {
      reject(e);
    }
  });
};
