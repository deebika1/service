// import { basename } from 'path';
import { query } from '../../database/postgres.js';
import { emitAction } from '../activityListener/index.js';
import { _localdownload } from '../utils/local/index.js';

export const iceNotification = async (req, res) => {
  try {
    // springer_acknowledge
    const {
      subject,
      fileNameWithTimeStamp,
      journalID,
      articleID,
      stageID,
      status,
      remarks,
      dateTime,
      attachmentFilePath,
      attachmentFileName,
    } = req.body;
    const sql = `SELECT * from wms_notifications WHERE customerid= 10 and action='ice_springer' and isactive = true`;
    const filePath = [];
    const fileNames = [];
    const outFiles = [];
    const resnotification = await query(sql);
    const { type, notificationconfig } = resnotification[0];
    if (attachmentFilePath.length > 0) {
      filePath.push(attachmentFilePath, { data: { path: attachmentFilePath } });
    }
    if (attachmentFileName.length > 0) {
      fileNames.push(attachmentFileName);
    }
    if (type === 'mail') {
      if (filePath.length > 0) {
        const out = await _localdownload(filePath[0]);
        if (out.path != '') {
          outFiles.push(out);
        }
      }
    }
    const mailData = {
      actionType: type,
      ...notificationconfig,
      subject,
      fileNameWithTimeStamp,
      journalID,
      articleID,
      stageID,
      status,
      remarks,
      dateTime,
      outFiles: outFiles.length > 0 ? outFiles : '',
      fileNames: fileNames.length > 0 ? fileNames : '',
    };
    emitAction(mailData);
    res.status(200).send({ data: 'Mail send success.', status: 'Success' });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const sendMail = async (req, res) => {
  try {
    const { attachmentFilePath, attachmentFileName, type } = req.body;
    // const sql = `SELECT * from wms_notifications WHERE customerid= 10 and action='ice_springer' and isactive = true`;
    const filePath = [];
    const fileNames = [];
    const outFiles = [];
    // const resnotification = await query(sql);
    // const { type, notificationconfig } = resnotification[0];
    if (attachmentFilePath.length > 0) {
      filePath.push(attachmentFilePath, { data: { path: attachmentFilePath } });
    }
    if (attachmentFileName.length > 0) {
      fileNames.push(attachmentFileName);
    }
    if (type == 'mail') {
      if (filePath.length > 0) {
        const out = await _localdownload(filePath[0]);
        if (out.path != '') {
          outFiles.push(out);
        }
      }
    }
    const mailData = {
      actionType: type,
      ...req.body,
      outFiles: outFiles.length > 0 ? outFiles : '',
      fileNames: fileNames.length > 0 ? fileNames : '',
    };
    emitAction(mailData);
    res.status(200).send({ data: 'Mail send success.', isSuccess: true });
  } catch (error) {
    res.status(400).send({ message: error.message, isSuccess: false });
  }
};

export const executeQuerySpringer = async (req, res) => {
  try {
    const jsonobj = req.body;
    const { sql } = jsonobj;
    // const sql = `select xmltagconfigjson from springer.ice_mstxmltagsettings where stageid='${req.query.stageid}' and isactive='Y'`;
    const out = await query(sql);
    res.status(200).send({ data: out, isSuccess: true });
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message });
  }
};

export const getXMLTagConfigDetails = async (req, res) => {
  try {
    const sql = `select xmltagconfigjson from springer.ice_mstxmltagsettings where stageid='${req.query.stageid}' and isactive='Y'`;
    const out = await query(sql);
    res.status(200).send({ data: out[0].xmltagconfigjson, status: 'Success' });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getConnectionParameter_Springer = async (req, res) => {
  try {
    const sql = `select serverpath,fileserverpath,downloadfolderpath,repeatedfolderpath,itracksintegrationneeded,uploadfolderpath,successfolderpath,redofolderpath from springer.ice_integrasettings where isactive='Y'`;
    const out = await query(sql);
    res.status(200).send({ data: out[0], status: 'Success' });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const getCommonPathForSpringer = async (req, res) => {
  try {
    const { itemcode, stageid } = req.query;
    const sql = `select sd.* from public.wms_workorder_sourcefile_details sd
    join wms_workorder wo on wo.workorderid = sd.workorderid 
    where sd.stageid = '${stageid}' and wo.itemcode = '${itemcode}' order by stageiterationcount desc limit 1`;
    const out = await query(sql);
    res.status(200).send({ data: out[0], isSuccess: true });
  } catch (error) {
    res.status(400).send({ message: error.message, isSuccess: false });
  }
};
export const updateRetryCountInDatabase = async (req, res) => {
  try {
    let { filesizeretrycount, fileStatus, unzipretrycount, othersretrycount } =
      req.body;
    const { filename, remarks, reasonforretry } = req.body;
    filesizeretrycount = filesizeretrycount || 0;
    unzipretrycount = unzipretrycount || 0;
    othersretrycount = othersretrycount || 0;
    const sqlSelect = `select filenamewithtimestamp,currentfilestatusid,isworkordersuccess
    from springer.ice_zipfilesinoutfolder where filenamewithtimestamp ='${filename}' and islocked='N'`;
    const outRecord = await query(sqlSelect);
    if (outRecord.length > 0) {
      const currentStatus = outRecord[0].currentfilestatusid;
      if (currentStatus <= 4) {
        fileStatus = 1;
      } else if (
        currentStatus >= 11 &&
        currentStatus <= 14 &&
        currentStatus != 13
      ) {
        fileStatus = 3;
      } else {
        res.status(200).send({
          isSuccess: false,
          message: 'Invalid Request. Please contact to WMS Team.',
        });
      }

      const sql = `UPDATE springer.ice_zipfilesinoutfolder
       SET
       currentfilestatusid = ${fileStatus},
       filesizeretrycount = COALESCE(${filesizeretrycount}, 0) + 1,
       unzipretrycount = COALESCE(${unzipretrycount}, 0) + 1,
       othersretrycount = COALESCE(${othersretrycount}, 0) + 1,
       remarks = '${remarks}',
       reasonforretry = '${reasonforretry}',
       updatedon = (now()::timestamp(0) + interval '330 minute'),
       isretrigger=true
       WHERE
       filenamewithtimestamp = '${filename}' AND
       islocked = 'N'`;
      const out = await query(sql);
      res.status(200).send(out);
    } else {
      res
        .status(200)
        .send({ isSuccess: false, message: 'Record not exit in DB.' });
    }
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message });
  }
};

export const getZipFileDetailOnId = async (req, res) => {
  try {
    const { zipfileid } = req.body;
    const sql = `SELECT * FROM springer.ice_zipfilesinoutfolder where zipfileid = ${zipfileid};`;
    const response = await query(sql);
    res.status(200).send({ data: response });
  } catch (e) {
    res.status(400).send({ e });
  }
};
export const updateDownloadFileStatus = async (req, res) => {
  try {
    const fileName = req.query.filename;
    const { downloadedfilesize } = req.query;
    const { remarks } = req.query;
    const { reasonforfailure } = req.query;
    const fileStatus = req.query.currentfilestatusid;
    const { isworkordersuccess } = req.query;
    const { manuscriptzipfilestatus } = req.query;
    let sql = '';
    if (downloadedfilesize != null && downloadedfilesize != '') {
      sql = `update springer.ice_zipfilesinoutfolder set currentfilestatusid=${fileStatus}, downloadedfilesize='${downloadedfilesize}',remarks='${remarks}',reasonforfailure='${reasonforfailure.replace(
        /'/g,
        "''",
      )}',downloadendtime=(now()::timestamp(0) + interval '330 minute'),updatedon=(now()::timestamp(0) + interval '330 minute') where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    } else if (fileStatus == 12) {
      sql = `update springer.ice_zipfilesinoutfolder set currentfilestatusid=${fileStatus},remarks='${remarks}',manuscriptzipfilestatus='${manuscriptzipfilestatus}',updatedon=(now()::timestamp(0) + interval '330 minute') ,isworkordersuccess = ${isworkordersuccess} where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    } else {
      sql = `update springer.ice_zipfilesinoutfolder set currentfilestatusid=${fileStatus},remarks='${remarks}',reasonforfailure='${reasonforfailure.replace(
        /'/g,
        "''",
      )}',updatedon=(now()::timestamp(0) + interval '330 minute') where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    }
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const updatefileuploadstatus = async (req, res) => {
  try {
    const fileName = req.query.filename;
    const { uploadfilesize } = req.query;
    const { remarks } = req.query;
    const { reasonforfailure } = req.query;
    const fileStatus = req.query.currentfilestatusid;
    const { uploadedfilenamewithtimestamp } = req.query;

    let sql = '';
    if (fileStatus == 5 || fileStatus == 18) {
      sql = `update springer.ice_iozipfilesinuploadfolder set currentfilestatusId='${fileStatus}',uploadedfilenamewithtimestamp='${uploadedfilenamewithtimestamp}',uploadstarttime=(now()::timestamp(0) + interval '330 minute') where filenamewithtimestamp='${fileName}'`;
    } else if (fileStatus == 6 || fileStatus == 20) {
      sql = `update springer.ice_iozipfilesinuploadfolder set currentfilestatusId='${fileStatus}',uploadcount=coalesce(uploadcount,0)+1,remarks='${remarks}',uploadedfilesize=${uploadfilesize},uploadedfilenamewithtimestamp='${uploadedfilenamewithtimestamp}',uploadendtime=(now()::timestamp(0) + interval '330 minute') where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    } else {
      sql = `update springer.ice_iozipfilesinuploadfolder set currentfilestatusId='${fileStatus}',remarks='${remarks}',reasonforfailure='${reasonforfailure}' where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    }
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const updateeProoffilestatus = async (req, res) => {
  try {
    const jsonobj = req.body;
    const fileStatus = jsonobj.currentFilestatusId;
    const remarks = jsonobj.remark;
    const reasonforfailure = jsonobj.reasonForFailure;

    const { zipFileName, iozipFileId, statusCode } = req.body;
    let sql = '';
    if (statusCode == 40) {
      sql = `update springer.ice_iozipfilesinuploadfolder set currentfilestatusId='26',eproofdownloadedfilename='${zipFileName}',eproofdownloadedtime=(now()::timestamp(0) + interval '330 minute') where iozipfileid='${iozipFileId}'`;
    } else {
      sql = `update springer.ice_iozipfilesinuploadfolder set currentfilestatusId='${fileStatus}',remarks='${remarks}',reasonforfailure='${reasonforfailure}' where iozipfileid='${iozipFileId}' and islocked = 'N'`;
    }
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const updateLogUploadStatus = async (req, res) => {
  try {
    // const {logFileName,iozipFileId,logFileContent,fileStatus,remarks,reasonforfailure}=req.body
    const jsonobj = req.body;
    const { logFileName } = jsonobj;
    const { iozipFileId, jobdetailsId } = jsonobj;
    const { logFileContent } = jsonobj;
    const fileStatus = jsonobj.currentFilestatusId;
    const remarks = jsonobj.remark;
    const reasonforfailure = jsonobj.reasonForFailure;
    // const fileName = '';
    let sql = '';
    if (fileStatus == 16) {
      sql = `update springer.ice_jobdetails set logstatusid=1,currentstatusid=16 where jobdetailsid ='${jobdetailsId}' and isactive='Y'`;
      await query(sql);
      sql = `UPDATE springer.ice_iozipfilesinuploadfolder
        SET
        islogreceived = 'Y',
        logstatusid = 1,
        logreceiveddate = (now()::timestamp(0) + interval '330 minute'),
        isautomaticlogupdate = 'N',
        remarks='${remarks}'
        WHERE iozipfileid = '${iozipFileId}' `;
      const out1 = await query(sql);
      if (out1.length == 0) {
        sql = `SELECT logfilenamewithtimestamp
          FROM springer.ice_logfilecontent
          WHERE logfilenamewithtimestamp ='${logFileName}'`;
        const out2 = await query(sql);
        if (out2.length == 0) {
          sql = `update springer.ice_logfilecontent
            set logfilenamewithtimestamp = '${logFileName}',
                logfilecontent = '${logFileContent}',
                islogfiledeletedinftp = 'N',
                logreceiveddate=(now()::timestamp(0) + interval '330 minute')
            where iozipfileid ='${iozipFileId}' `;
        }
      }
    } else if (fileStatus == 15) {
      // Redo
      sql = `update springer.ice_jobdetails set logstatusid=2,currentstatusid=15,iswmsprocesscompleted='N',isreadyfornexttimeeproof='Y' where jobdetailsid ='${jobdetailsId}' and isactive='Y'`;
      await query(sql);
      sql = `UPDATE springer.ice_iozipfilesinuploadfolder
        SET
        islogreceived = 'Y',
        isreuploaded='Y',
        logstatusid = 2,
        logreceiveddate =(now()::timestamp(0) + interval '330 minute'),
        isautomaticlogupdate = 'N',
        remarks='${remarks}'
        WHERE iozipfileid = '${iozipFileId}' and islogreceived = 'N'`;
      const out3 = await query(sql);
      if (out3.length == 0) {
        sql = `SELECT logfilenamewithtimestamp
          FROM springer.ice_logfilecontent
          WHERE logfilenamewithtimestamp ='${logFileName}'`;
        const out4 = await query(sql);
        if (out4.length == 0) {
          sql = `update springer.ice_logfilecontent
            set logfilenamewithtimestamp = '${logFileName}',
                logfilecontent = '${logFileContent}',
                islogfiledeletedinftp = 'N',
                isactive='N',
                logreceiveddate=(now()::timestamp(0) + interval '330 minute')
            where iozipfileid ='${iozipFileId}' and isactive='Y'`;
        }
      }
    } else {
      sql = `update springer.ice_iozipfilesinuploadfolder set currentfilestatusId=${fileStatus},remarks='${remarks}',reasonforfailure='${reasonforfailure}' where iozipfileid = '${iozipFileId}' and islocked = 'N'`;
    }
    const out5 = await query(sql);
    res.status(200).send(out5);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const updateContentCheckerLogDetails = async (req, res) => {
  try {
    const jsonobj = req.body;
    const { iozipFileId, jobsheetContent64, isccPassedbyICE, logcontent } =
      jsonobj;
    const sql = `update springer.ice_logfilecontent
                set jobsheetcontent64 = '${jobsheetContent64}',
                ccstdoutbyice = '${logcontent}',
                isccbyice='Y',
                isccpassedbyice='${isccPassedbyICE}'
                where iozipfileid ='${iozipFileId}' and isactive='Y'`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const intiatefiledownloadupdate = async (req, res) => {
  try {
    const fileName = req.query.filename;
    const { duplicatefilename } = req.query;
    const { remarks } = req.query;
    const sql = `update springer.ice_zipfilesinoutfolder set currentfilestatusid =2,duplicatefilename='${duplicatefilename}',remarks='${remarks}',downloadstarttime=(now()::timestamp(0) + interval '330 minute'),updatedon=(now()::timestamp(0) + interval '330 minute') where filenamewithtimestamp='${fileName}' and islocked = 'N'`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getDownloadList_Springer = async (req, res) => {
  try {
    const sql = `select filenamewithtimestamp, originalfilesize, offsetno, duplicatefilename
     from springer.ice_zipfilesinoutfolder
     where islocked = 'N' and currentfilestatusid = 1 and filetype='J'
     order by positioninqueue asc;`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const geteProofDownloadList_Springer = async (req, res) => {
  try {
    const sql = `select filenamewithtimestamp, originalfilesize, offsetno, duplicatefilename,filename
     from springer.ice_zipfilesinoutfolder
     where islocked = 'N' and currentfilestatusid = 17 and filetype='J'
     order by positioninqueue asc;`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const getFileUploadList_Springer = async (req, res) => {
  try {
    const sql = `select a.filenamewithtimestamp,a.originalfilesize,a.iozipfileid,a.jobdetailsid,
    a.currentfilestatusid,a.uploadedfilenamewithtimestamp,a.uploadCount,a.journalid,a.articleid,
    a.journalyear,a.jobsheettypeid,b.jobsheettype from springer.ice_iozipfilesinuploadfolder a 
    left join springer.ice_mstjobsheettype b on a.jobsheettypeid=b.jobsheettypeid 
    where  a.CurrentFileStatusId in (1) and a.jobsheettypeid not in(6,7) and a.filetype='J' order by a.positionInQueue asc`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const getLogJobList = async (req, res) => {
  try {
    const sql = `SELECT a.iozipfileid, a.uploadedfilenamewithtimestamp, a.jobdetailsid, a.jobsheettypeid,
                 a.orgzipfileid, a.uploadendtime,a.journalid,a.articleid,a.journalyear,b.incomingstageid,b.incomingjobstatus
                 FROM springer.ice_iozipfilesinuploadfolder a
                 left join springer.ice_jobdetails b on a.jobdetailsid=b.jobdetailsid and b.isactive='Y'
                 WHERE currentfilestatusid in(6,20)
                 AND a.islocked = 'N'
                 AND (
                   (a.islogreceived = 'N' AND a.logstatusid = 3) OR
                   (a.logstatusid = 1 AND a.isautomaticlogupdate = 'Y')
                 )
                 AND a.uploadedfilenamewithtimestamp IS NOT NULL`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};
export const geteProofLogJobList = async (req, res) => {
  try {
    const sql = ` SELECT a.*,b.incomingstageid,b.incomingjobstatus,c.bookid
    FROM springer.ice_iozipfilesinuploadfolder a
    left join springer.ice_jobdetails b on a.jobdetailsid=b.jobdetailsid and b.isactive='Y'
	  left join springer.ice_mstpackage c on b.jobcodeid=c.jobcodeid
    WHERE a.currentfilestatusid in(20) AND a.islocked = 'N' AND a.isactive = 'N' 
    and a.eproofdownloadedfilename IS NULL and a.eproofdownloadedtime is null and a.islogreceived = 'Y'
    AND a.uploadedfilenamewithtimestamp IS NOT NULL and a.logstatusid=1`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const getIncommingJobList = async (req, res) => {
  try {
    const sql = `SELECT zipFileId, fileNameWithTimeStamp, downloadEndTime, originalTimeStamp,filetype,journalid,articleid,journalyear,
     booktitleid,bookeditionnumber,booklanguage,seriesid,seriesyear,serieschapterid,filename
     FROM springer.ice_zipfilesinoutfolder
     WHERE   currentFileStatusId = 3
       AND isLocked = 'N'
       AND isAcksent = 'N'
       AND downloadEndTime IS NOT NULL
       AND originalTimeStamp IS NOT NULL
       AND filetype='J'
     ORDER BY downloadEndTime ASC
     LIMIT 1`;
    const out1 = await query(sql);

    res.status(200).send(out1);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const insertDuplicateID = async (req, res) => {
  try {
    const fileName = req.query.filename;
    const sql = `Insert into springer.ice_trnduplicateid(filenamewithtimestamp,status) VALUES('${fileName}',1) `;
    await query(sql);
    const sqlSelect = `select duplicateid from springer.ice_trnduplicateid where filenamewithtimestamp ='${fileName}' and status=1 order by duplicateid `;
    const output = await query(sqlSelect);
    if (output.length > 0) {
      const sqlUpdate = `update springer.ice_trnduplicateid set status=2  where filenamewithtimestamp ='${fileName}' and duplicateid=${output[0].duplicateid}`;
      await query(sqlUpdate);
    }
    res.status(200).send(output[0].duplicateid);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const tableJobDetailsUpdate = async (req, res) => {
  try {
    const jsonobj = req.body;
    let isNewJob = 0;
    let reworkCount = 0;
    let getRepJobDetails = '';
    // const iDivisionID = 9;
    // console.log(iDivisionID);
    const sql = `SELECT jobcodeid, incomingstageid, jobdetailsid, logstatusid,iswmsprocesscompleted,reworkcount,incomingjobstatus
    FROM springer.ice_jobdetails
    WHERE jobcodeid = '${jsonobj.jobCodeId}' AND incomingstageid='${jsonobj.stageID}' AND isactive = 'Y'`;
    const out = await query(sql);
    if (out.length > 0) {
      reworkCount = out[0].reworkcount;
    }
    // New Job
    if (out.length == 0) {
      isNewJob = 1;
      const sqlInset = `INSERT INTO springer.ice_jobdetails(jobcodeid, incomingjobstatus, reworkcount, incomingstageid, sourcezipfileid,
        currentstatusid, logstatusid, jobsheetcontent, isactive, receiveddate,createddate)
        VALUES('${jsonobj.jobCodeId}','N', 0, '${jsonobj.stageID}','${jsonobj.zipFileId}',0,0,'${jsonobj.jobSheetContent}','Y',
        '${jsonobj.jobReceivedDate}',(now()::timestamp(0) + interval '330 minute'))RETURNING jobdetailsid`;
      const jobdetailsid = await query(sqlInset);
      res.status(200).json({
        data: jobdetailsid[0].jobdetailsid,
        isNewJob,
        reworkCount,
        status: 'Success',
      });
    } else if (out[0].incomingstageid == jsonobj.stageID) {
      // Suspended Job.. need to develop
      if (out[0].iswmsprocesscompleted == 'Y') {
        const sqlUpdate = `Update springer.ice_jobdetails set isactive='N' where jobdetailsid= '${out[0].jobdetailsid}' and isactive='Y' `;
        await query(sqlUpdate);

        isNewJob = 2; // s200 revices // R

        const sqlInsert = `INSERT INTO springer.ice_jobdetails(jobcodeid, incomingjobstatus, reworkcount, incomingstageid, sourcezipfileid,
          currentstatusid, logstatusid, jobsheetcontent, isactive, receiveddate,previousjobdetailsid,createddate)
          VALUES('${jsonobj.jobCodeId}','R','${reworkCount + 1}', '${
          jsonobj.stageID
        }','${jsonobj.zipFileId}',0,0,'${jsonobj.jobSheetContent}','Y',
          '${jsonobj.jobReceivedDate}','${
          out[0].jobdetailsid
        }',(now()::timestamp(0) + interval '330 minute'))RETURNING jobdetailsid`;
        const s200jobdetailsid = await query(sqlInsert);
        res.status(200).json({
          data: s200jobdetailsid[0].jobdetailsid,
          isNewJob,
          reworkCount: reworkCount + 1,
          status: 'Success',
        });
      } else {
        isNewJob = 1;
        if (out[0].incomingjobstatus == 'R') {
          isNewJob = 2;
        }
        // for failure retrigger so we set 1
        getRepJobDetails = await GetNewFileandRepeatedFileDetails(
          `${jsonobj.jobCode}`,
          `${jsonobj.stageID}`,
          `${jsonobj.bookSeriesId}`,
          `${jsonobj.zipFileId}`,
        );
        await insertRepeatedJobDetails(getRepJobDetails, jsonobj.stageID);
        res.status(200).json({
          data: out[0].jobdetailsid,
          isNewJob,
          reworkCount,
          status: 'Success',
        });
      }
    } else {
      getRepJobDetails = await GetNewFileandRepeatedFileDetails(
        `${jsonobj.jobCode}`,
        `${jsonobj.stageID}`,
        `${jsonobj.bookSeriesId}`,
        `${jsonobj.zipFileId}`,
      );
      await insertRepeatedJobDetails(getRepJobDetails, jsonobj.stageID);
      res.status(200).json({
        data: out[0].jobdetailsid,
        reworkCount: reworkCount + 1,
        isNewJob,
        status: 'Success',
      });
    }
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const checkArticleOASISWorkflow = async (req, res) => {
  try {
    const { bookid } = req.query;
    const sql = `Select jobcodeid,currentstageid,isoasislicensereceived,isoasisworkflow from springer.ice_mstpackage where bookid='${bookid}'and islocked='N' and isactive ='Y'`;
    const out = await query(sql);
    if (
      out.length > 0 &&
      out[0].isoasisworkflow == 'Y' &&
      out[0].isoasislicensereceived == 'Y'
    ) {
      res.status(200).send({
        isSuccess: true,
        message: 'The OASIS license received for this article.',
      });
    } else if (
      out.length > 0 &&
      out[0].isoasisworkflow == 'Y' &&
      out[0].isoasislicensereceived != 'Y'
    ) {
      res.status(200).send({
        isSuccess: false,
        message: 'OASIS for this article not yet received.',
      });
    } else {
      res.status(200).send({
        isSuccess: true,
        message: 'It is not an OASIS workflow article.',
      });
    }
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message });
  }
};
export const tablePackageUpdate = async (req, res) => {
  try {
    const jsonobj = req.body;
    const iDivisionID = jsonobj.duID ? jsonobj.duID : 9;
    const sql = `Select jobcodeid,currentstageid,isoasislicensereceived,isoasisworkflow from springer.ice_mstpackage where 
    bookseriesid='${jsonobj.bookSeriesId}' and jobcode='${jsonobj.jobCode}'and islocked='N' and isactive ='Y'`;
    const out = await query(sql);
    if (out.length == 0) {
      const sqlInsert = `INSERT INTO springer.ice_mstpackage(divisionid, jobcode, jobtype, bookid, bookseriesid, peusername, peuseremail_id, sourcezipfileid, currentstageid, islocked, isactive, jobsheetfilename, receiveddate,createddate,isoasisworkflow,isoasislicensereceived,chapterid,chaptertype,chaptersequencenumber,chapterdoi,languageid)
      VALUES(${iDivisionID},'${jsonobj.jobCode}','${jsonobj.fileType}','${
        jsonobj.bookID
      }',
      '${jsonobj.bookSeriesId}','${jsonobj.productionEditorName}','${
        jsonobj.productionEditorEmailId
      }',
      '${jsonobj.zipFileId}','${jsonobj.stageID}','N','Y','${
        jsonobj.jobSheetFileName
      }','${
        jsonobj.jobReceivedDate
      }',(now()::timestamp(0) + interval '330 minute'),'${
        jsonobj.isOASISWorkFlow
      }','${jsonobj.isOASISLicenseReceived}','${
        jsonobj.chapterID ? jsonobj.chapterID : ''
      }','${jsonobj.chapterType ? jsonobj.chapterType : ''}','${
        jsonobj.chapterSeqNumber ? jsonobj.chapterSeqNumber : ''
      }','${jsonobj.doiNumber ? jsonobj.doiNumber : ''}','${
        jsonobj.language ? jsonobj.language : ''
      }')RETURNING jobcodeid`;

      const jobcodeid = await query(sqlInsert);
      res.status(200).json({ data: jobcodeid[0].jobcodeid, status: 'Success' });
    } else if (jsonobj.stageID == 300) {
      let sqlupdate = '';
      if (jsonobj.isOASISWorkFlow == 'Y') {
        sqlupdate = `update springer.ice_mstpackage set isoasisworkflow='Y' where 
        bookseriesid='${jsonobj.bookSeriesId}' and jobcode='${jsonobj.jobCode}'and islocked='N' and isactive ='Y'`;
        await query(sqlupdate);
      } else if (jsonobj.isOASISLicenseReceived == 'Y') {
        sqlupdate = `update springer.ice_mstpackage set isoasisworkflow='Y',isoasislicensereceived='Y' where 
       bookseriesid='${jsonobj.bookSeriesId}' and jobcode='${jsonobj.jobCode}'and islocked='N' and isactive ='Y'`;
        await query(sqlupdate);
      }

      res.status(200).json({ data: out[0].jobcodeid, status: 'Success' });
    } else if (out[0].currentstageid != jsonobj.stageID) {
      const getRepJobDetails = await GetNewFileandRepeatedFileDetails(
        `${jsonobj.jobCode}`,
        `${jsonobj.stageID}`,
        `${jsonobj.bookSeriesId}`,
        `${jsonobj.zipFileId}`,
      );
      await insertRepeatedJobDetails(getRepJobDetails, jsonobj.stageID);
      res.status(200).json({ data: out[0].jobcodeid, status: 'Success' });
    } else {
      res.status(200).json({ data: out[0].jobcodeid, status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

async function insertRepeatedJobDetails(getRepJobDetails, repeatedStageID) {
  let returnValue = false;
  try {
    const sqlRepInsetrt = `INSERT INTO springer.ICE_RepeatedJobDetails (JobCodeId, JobDetailsId, filenamewithtimestamp, RepeatedStage, CurrentStage, receiveddate, createdby, isactive)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`;
    const params = [
      getRepJobDetails.Newjobcodeid,
      getRepJobDetails.Newjobdetailsid,
      getRepJobDetails.NewZipfilename,
      `${repeatedStageID}`,
      getRepJobDetails.Newjobstage,
      getRepJobDetails.NewDownloadedDate,
      'ICE',
      'Y',
    ];

    const result = await query(sqlRepInsetrt, params);

    if (result.length > 0) {
      returnValue = true;
    }
  } catch (error) {
    returnValue = false;
  }
  return returnValue;
}

async function GetNewFileandRepeatedFileDetails(
  Repjobcode,
  repstage,
  bookseriesid,
  Repeatedzipfileid,
) {
  let returnValue = false;
  let Newjobcode = '';
  let Newjobcodeid = 0;
  let Newjobdetailsid = 0;
  let Newjobstage = 0;
  let Newzipfileid = 0;
  let Newjobfilesize = 0;
  let NewZipfilename = '';
  let NewDownloadedDate = '';
  let repeatedjobfilesize = 0;

  try {
    let sql = `SELECT a.jobcode, a.JobCodeId, a.CurrentStageId, b.jobdetailsid, b.sourcezipfileid
                 FROM springer.ICE_MstPackage a
                 JOIN springer.ice_jobdetails b ON b.jobcodeid = a.jobcodeid
                 WHERE a.bookseriesid = $1 AND a.isActive = 'Y' AND a.islocked = 'N' AND b.isActive = 'Y'
                 ORDER BY a.jobcodeid DESC`;
    const params = [bookseriesid.trim()];
    const result = await query(sql, params);

    if (result.length > 0) {
      Newjobstage = parseInt(result[0].currentstageid);

      if (
        Newjobstage === 200 ||
        Newjobstage === 300 ||
        Newjobstage === 600 ||
        repstage === 200 ||
        repstage === 300 ||
        repstage === 600
      ) {
        Newjobcode = result[0].jobcode;
        Newjobcodeid = parseInt(result[0].jobcodeid);
        Newjobdetailsid = parseInt(result[0].jobdetailsid);
        Newzipfileid = parseInt(result[0].sourcezipfileid);
      } else {
        sql = `SELECT TOP 1 a.jobcode, a.JobCodeId, a.CurrentStageId, b.jobdetailsid, b.sourcezipfileid
                     FROM springer.ice_mstpackage a
                     JOIN springer.ice_jobdetails b ON b.jobcodeid = a.jobcodeid
                     WHERE a.jobcode LIKE $1 AND a.isActive = 'Y' AND b.jobcodeid = a.jobcodeid AND b.isActive = 'Y'`;
        const params2 = [Repjobcode.trim()];
        const result2 = await query(sql, params2);

        if (result2.length > 0) {
          Newjobcode = result2[0].jobcode;
          Newjobcodeid = parseInt(result2[0].jobcodeid);
          Newjobdetailsid = parseInt(result2[0].jobdetailsid);
          Newzipfileid = parseInt(result2[0].sourcezipfileid);
          Newjobstage = parseInt(result2[0].currentstageid);
        }
      }
    }

    sql = `SELECT filenamewithtimestamp, originalfilesize, downloadendtime
             FROM springer.ice_zipfilesinoutfolder
             WHERE zipfileid = $1`;
    const params3 = [Newzipfileid];
    const dtResult = await query(sql, params3);

    if (dtResult.length > 0) {
      Newjobfilesize = parseInt(dtResult[0].originalfilesize);
      NewZipfilename = dtResult[0].filenamewithtimestamp;
      NewDownloadedDate = new Date(dtResult[0].downloadendtime)
        .toISOString()
        .replace('T', ' ')
        .replace('Z', '');

      sql = `SELECT downloadedfilesize AS repeatedfilesize
                 FROM springer.ice_zipfilesinoutfolder
                 WHERE zipfileid = $1`;
      const params4 = [Repeatedzipfileid];
      const dtResult2 = await query(sql, params4);

      if (dtResult2.length > 0) {
        repeatedjobfilesize = parseInt(dtResult2[0].repeatedfilesize);
        returnValue = true;
      }
    } else {
      returnValue = false;
    }
    return {
      returnValue,
      Newjobcode,
      Newjobcodeid,
      Newjobdetailsid,
      Newjobstage,
      Newzipfileid,
      Newjobfilesize,
      NewZipfilename,
      NewDownloadedDate,
      repeatedjobfilesize,
    };
  } catch (error) {
    // console.error('GetNewFileandRepeatedFileDetails()', error.message);
    returnValue = false;
  }
}

export const insert_ftpFileWatcherStatus_springer = async (req, res) => {
  try {
    let getzipfileid = 0;
    const jsonobj = req.body;
    const sql = `select filenamewithtimestamp,zipfileid
                    from springer.ice_zipfilesinoutfolder where filenamewithtimestamp ='${jsonobj.filenamewithtimestamp}' `;
    const out = await query(sql);
    if (out.length == 0) {
      // E => Error
      let max = 0;
      const sqlmax = `select max(positioninqueue)+1 from springer.ice_zipfilesinoutfolder`;
      const maxvalue = await query(sqlmax);
      if (maxvalue[0]['?column?'] == null) {
        max = 1;
      } else {
        max = maxvalue[0]['?column?'];
      }

      let fileStatus = jsonobj.fileType != 'E' ? 1 : 4;
      fileStatus = jsonobj.currentFilestatusId
        ? jsonobj.currentFilestatusId
        : fileStatus;
      const sqlInset = `INSERT INTO springer.ice_zipfilesinoutfolder(
          filenamewithtimestamp, filename, filetype,journalid,articleid,journalyear,booktitleid,bookeditionnumber,booklanguage,seriesid,seriesyear,serieschapterid,originaltimestamp,positioninqueue,currentfilestatusid,originalfilesize,remarks,islocked,isacksent,createddate)
         VALUES ( '${jsonobj.filenamewithtimestamp}', '${jsonobj.fileName}', '${
        jsonobj.fileType
      }','${jsonobj.journalID}','${jsonobj.articleID}','${jsonobj.year}','${
        jsonobj.bookTitleID
      }','${jsonobj.editionNumber}','${jsonobj.language}','${
        jsonobj.seriesID
      }','${jsonobj.year}','${jsonobj.chapterID}','${
        jsonobj.ISOTimeStamp
      }','${max}','${fileStatus}','${
        jsonobj.fileSize ? jsonobj.fileSize : 0
      }','${
        jsonobj.remark
      }','N','N',(now()::timestamp(0) + interval '330 minute'))RETURNING zipfileid`;
      // console.log(sqlInset, 'insertingfile');
      getzipfileid = await query(sqlInset).then(() => {
        res.status(200).json({
          data: 'Query Inserted Successfully',
          status: 'Success',
          zipFileId: getzipfileid,
        });
      });
    } else {
      res.status(200).json({
        data: 'Zipfile already available',
        status: 'Success',
        zipFileId: out[0].zipfileid,
      });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const insert_eProof_ZipDetails = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select filenamewithtimestamp
                    from springer.ice_zipfilesinoutfolder where filenamewithtimestamp ='${jsonobj.zipFileName}' `;
    const out = await query(sql);
    if (out.length == 0) {
      // E => Error
      let max = 0;
      const sqlmax = `select max(positioninqueue)+1 from springer.ice_zipfilesinoutfolder`;
      const maxvalue = await query(sqlmax);
      if (maxvalue[0]['?column?'] == null) {
        max = 1;
      } else {
        max = maxvalue[0]['?column?'];
      }

      const fileStatus = 17;
      const sqlInset = `INSERT INTO springer.ice_zipfilesinoutfolder(
          filenamewithtimestamp, filename, filetype,journalid,articleid,journalyear,positioninqueue,currentfilestatusid,remarks,islocked,isacksent,createddate)
         VALUES ( '${jsonobj.zipFileName}', '${jsonobj.fileName}', 'J','${jsonobj.journalId}','${jsonobj.articleId}','${jsonobj.journalYear}','${max}','${fileStatus}','${jsonobj.remark}','N','N',(now()::timestamp(0) + interval '330 minute'))`;
      // console.log(sqlInset, 'insertingfile');
      await query(sqlInset).then(() => {
        res
          .status(200)
          .json({ data: 'Query Inserted Successfully', status: 'Success' });
      });
    } else {
      res
        .status(200)
        .json({ data: 'Zipfile already available', status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const insert_InIOzipfilesInUpload = async (req, res) => {
  try {
    const jsonobj = req.body;
    jsonobj.fileNameWithTimeStamp =
      jsonobj.fileNameWithTimeStamp || jsonobj.filenamewithtimestamp;
    const sql = `select iozipfileid
                    from springer.ice_iozipfilesinuploadfolder where filenamewithtimestamp ='${jsonobj.fileNameWithTimeStamp}'`;
    const out = await query(sql);
    if (out.length == 0) {
      const sqlActive = `select iozipfileid
                    from springer.ice_iozipfilesinuploadfolder where jobdetailsid ='${jsonobj.jobDetailsId}' and isactive ='Y'`;
      const outActive = await query(sqlActive);
      if (outActive.length > 0) {
        const sqlqry = `update springer.ice_iozipfilesinuploadfolder  set isactive ='N' where jobdetailsid  ='${jsonobj.jobDetailsId}' and iozipfileid ='${outActive[0].iozipfileid}' and isactive ='Y'`;
        await query(sqlqry);
      }
      let max = 0;
      const sqlmax = `select max(positioninqueue)+1 from springer.ice_iozipfilesinuploadfolder`;
      const maxvalue = await query(sqlmax);
      if (maxvalue[0]['?column?'] == null) {
        max = 1;
      } else {
        max = maxvalue[0]['?column?'];
      }

      const sqlInset = `INSERT INTO springer.ice_iozipfilesinuploadfolder (filenamewithtimestamp,orgzipfileid,jobsheettypeid,jobdetailsid,filename,
          filetype,journalid,articleid,journalyear,booktitleid,bookeditionnumber,booklanguage,originaltimestamp,positioninqueue,
          currentfilestatusid,filesizeretrycount,unzipretrycount,othersretrycount,islocked,resume,offsetno,islogreceived,originalfilesize,logstatusid,isactive,createdby,createddate)
          VALUES(
          '${jsonobj.fileNameWithTimeStamp}',
          '${jsonobj.zipFileId}',
          '${
            jsonobj.jobSheetTypeid
              ? jsonobj.jobSheetTypeid
              : '' || jsonobj.jobSheetTypeId
              ? jsonobj.jobSheetTypeId
              : '' || jsonobj.jobsheetTypeId
              ? jsonobj.jobsheetTypeId
              : ''
          }',
          '${jsonobj.jobDetailsId}',
          '${jsonobj.fileName}',
          '${jsonobj.fileType}',
          '${jsonobj.journalID}',
          '${jsonobj.articleID}',
          '${jsonobj.journalYear ? jsonobj.journalYear : ''}',
          '${jsonobj.bookTitleID}',
          '${jsonobj.editionNumber}',
          '${jsonobj.language}',
          '${
            jsonobj.ISOTimeStamp
              ? jsonobj.ISOTimeStamp
              : jsonobj.originalTimeStamp
          }',
          ${max},1,0,0,0,'N','N',0,'N','${
        jsonobj.fileSize
      }',3,'Y','ICE',(now()::timestamp(0) + interval '330 minute')) RETURNING iozipfileid`;
      const result = await query(sqlInset);
      if (result.length > 0) {
        const sqlLog = `Select iozipfileid from springer.ice_iozipfilesinuploadfolder where filenamewithtimestamp ='${jsonobj.fileNameWithTimeStamp}'`;
        const logValue = await query(sqlLog);
        if (logValue.length != 0) {
          const sqlLogInsert = `Insert into springer.ice_logfilecontent(iozipfileid,jobsheetcontent,isactive,createddate)values(${logValue[0].iozipfileid},'${jsonobj.ackJobsheetContent}','Y',(now()::timestamp(0) + interval '330 minute'))`;
          console.log(sqlLogInsert);
          const LogInsert = await query(sqlLogInsert);
          if (LogInsert.length == 0) {
            res.status(200).json({
              message: 'Log Inserted Successfully',
              status: 'Success',
              iozipFileId: logValue[0].iozipfileid,
            });
          } else {
            res
              .status(200)
              .json({ message: 'Log Insertion is Failed.', status: 'Failure' });
          }
        }
      }
    } else if (out.length > 0) {
      // const sqlqry = `update springer.ice_iozipfilesinuploadfolder set set isactive ='N' where jobdetailsid  ='${jsonobj.jobDetailsId}',and iozipfileid ='${out.iozipfileid}'`;
      // await query(sqlqry);
      res.status(200).json({
        message: 'The Upload zip filename is already exists.',
        status: 'Failure',
      });
    }
  } catch (error) {
    res.status(400).send({ message: error.message, status: 'Failure' });
  }
};

export const getDispatchDetails = async (req, res) => {
  try {
    const sql = `select a.jobcode,a.bookid,b.jobdetailsid,b.incomingstageid,b.sourcezipfileid,b.zippackagefilesize,
    b.iswmsprocesscompleted,b.wmsdispatchzipfilenamewithpath,b.currentstatusid,b.logstatusid,b.incomingjobstatus,b.reworkcount,b.isreadyfornexttimeeproof
    from springer.ice_mstpackage a
    join springer.ice_jobdetails b on a.jobcodeid=b.jobcodeid
    where b.incomingstageid='${req.query.stageid}' and a.bookid='${req.query.filename}'and b.isactive='Y' and coalesce(a.isjobdispatched,'N') !='Y'`;
    const out = await query(sql);
    if (out && out.length > 0) {
      res.status(200).send({ data: out[0], isSuccess: true });
    } else {
      res.status(200).send({ message: 'Record not found.', isSuccess: false });
    }
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message });
  }
};

export const updateDispatchDetails = async (req, res) => {
  try {
    const jsonobj = req.body;
    let sql = '';
    if (jsonobj.jobSheetTypeid == 6) {
      // dispatch
      sql = `update springer.ice_jobdetails set zippackagefilesize='${jsonobj.remoteFileSize}',iswmsprocesscompleted='Y',wmsdispatchzipfilenamewithpath='${jsonobj.localFileNameWithPath}'
     WHERE jobdetailsid = '${jsonobj.jobDetailsId}' AND incomingstageid='${jsonobj.stageID}' AND isactive = 'Y'`;
    } else if (jsonobj.jobSheetTypeid == 7) {
      // eProof
      sql = `update springer.ice_jobdetails set zippackagefilesize='${jsonobj.remoteFileSize}',eproofrequried='Y',isreadyfornexttimeeproof='N',eproofdispatchpath='${jsonobj.localFileNameWithPath}'
      WHERE jobdetailsid = '${jsonobj.jobDetailsId}' AND incomingstageid='${jsonobj.stageID}' AND isactive = 'Y'`;
    }
    await query(sql);
    res
      .status(200)
      .send({ message: 'Record updated successfully..', isSuccess: true });
  } catch (error) {
    res.status(400).send({ isSuccess: false, message: error.message });
  }
};

export const checkSuccessLogForPreviousUploaded = async (req, res) => {
  // let {jobDetailsId, ioZipFileId, uploadFileJobSheetTypeId, fileNameWithTimeStamp}=req.query;
  const jobDetailsId = req.query.jobdetailsid;
  const uploadFileJobSheetTypeId = req.query.jobsheettypeid;
  const fileNameWithTimeStamp = req.query.filenamewithtimestamp;
  let ioZipFileId = 0;

  let returnValue = false;
  let reason = '';
  let previousJobSheetTypeId = -1;
  let previousLogStatusId = -1;
  try {
    const getioZipFileId = `SELECT iozipfileid,logstatusid, jobsheettypeid FROM springer.ice_iozipfilesinuploadfolder WHERE jobsheettypeid <> 7 AND fileNameWithTimeStamp = $1 ORDER BY iozipfileid DESC LIMIT 1`;
    const ioZipFileIdResult = await query(getioZipFileId, [
      fileNameWithTimeStamp,
    ]);
    ioZipFileId = ioZipFileIdResult[0].iozipfileid;
    // Query to get previous log information
    const getPreviousLogSQL = `SELECT logstatusid, jobsheettypeid FROM springer.ice_iozipfilesinuploadfolder WHERE jobsheettypeid <> 7 AND jobdetailsid = $1 AND iozipfileid NOT IN ($2) ORDER BY iozipfileid DESC LIMIT 1`;
    const previousLogResult = await query(getPreviousLogSQL, [
      jobDetailsId,
      ioZipFileId,
    ]);

    if (previousLogResult.length > 0) {
      previousJobSheetTypeId = parseInt(previousLogResult[0].jobsheettypeid);
      previousLogStatusId = parseInt(previousLogResult[0].logstatusid);

      if (previousJobSheetTypeId == uploadFileJobSheetTypeId) {
        if (previousLogStatusId == 2) {
          returnValue = true;
        } else {
          // Check whether the package has been re-uploaded or not.
          const getReuploadInfoSQL = `SELECT logstatusid, jobsheettypeid, isreuploaded FROM springer.ice_iozipfilesinuploadfolder WHERE iozipfileid = $1 AND isactive = 'Y' ORDER BY iozipfileid DESC LIMIT 1`;
          const reuploadInfoResult = await query(getReuploadInfoSQL, [
            ioZipFileId,
          ]);

          if (reuploadInfoResult.length > 0) {
            const isReupload = reuploadInfoResult[0].isreuploaded;

            if (isReupload && isReupload.trim().toUpperCase() == 'Y') {
              returnValue = true;
            } else {
              const getJobsheetTypeSQL = `SELECT jobsheettype FROM springer.ice_mstjobsheettype WHERE jobsheettypeid = $1`;
              const jobsheetTypeResult = await query(getJobsheetTypeSQL, [
                previousJobSheetTypeId,
              ]);

              const reasonForFailure = `Uploading Rejected - Previous ${jobsheetTypeResult[0].jobsheettype} should be Redo Log`;
              reason = reasonForFailure;

              const updateFailureSQL = `UPDATE springer.ice_iozipfilesinuploadfolder SET currentfilestatusid = 13, reasonforfailure = $2 WHERE iozipfileid = $1`;
              const updateResult = await query(updateFailureSQL, [
                ioZipFileId,
                reasonForFailure,
              ]);

              if (updateResult.length > 0) {
                returnValue = false;
                // await sentMailToICETeamForErrorOccuredInIncomingJobProcess(fileNameWithTimeStamp, reasonForFailure, ice_uploading);
              }
            }
          } else {
            const getJobsheetTypeSQL = `SELECT jobsheettype FROM springer.ice_mstjobsheettype WHERE jobsheettypeid = $1`;
            const jobsheetTypeResult = await query(getJobsheetTypeSQL, [
              previousJobSheetTypeId,
            ]);

            const reasonForFailure = `Uploading Rejected - Previous ${jobsheetTypeResult[0].jobsheettype} should be Redo Log`;
            reason = reasonForFailure;

            const updateFailureSQL = `UPDATE springer.ice_iozipfilesinuploadfolder SET currentfilestatusid = 13, reasonforfailure = $2 WHERE iozipfileid = $1`;
            const updateResult = await query(updateFailureSQL, [
              ioZipFileId,
              reasonForFailure,
            ]);

            if (updateResult.length > 0) {
              returnValue = false;
              // await sentMailToICETeamForErrorOccuredInIncomingJobProcess(fileNameWithTimeStamp, reasonForFailure, ice_uploading);
            }
          }
        }
      } else if (previousLogStatusId == 1) {
        returnValue = true;
      } else {
        const getJobsheetTypeSQL = `SELECT jobsheettype FROM springer.ice_mstjobsheettype WHERE jobsheettypeid = $1`;
        const jobsheetTypeResult = await query(getJobsheetTypeSQL, [
          previousJobSheetTypeId,
        ]);

        const reasonForFailure = `Uploading Rejected - Success Log of ${jobsheetTypeResult[0].jobsheettype} (Previous Uploaded Package) is Not Received`;
        reason = reasonForFailure;

        const updateFailureSQL = `UPDATE springer.ice_iozipfilesinuploadfolder SET currentfilestatusid = 13, reasonforfailure = $2 WHERE iozipfileid = $1`;
        const updateResult = await query(updateFailureSQL, [
          ioZipFileId,
          reasonForFailure,
        ]);

        if (updateResult.length > 0) {
          returnValue = false;
          // await sentMailToICETeamForErrorOccuredInIncomingJobProcess(fileNameWithTimeStamp, reasonForFailure, ice_uploading);
        }
      }
    } else {
      const checkRejectionSQL = `SELECT incomingjobstatus, reworkcount FROM springer.ice_jobdetails WHERE incomingjobstatus ='R' AND reworkcount > 0 AND jobdetailsid = $1 AND isactive ='Y'`;
      const rejectionResult = await query(checkRejectionSQL, [jobDetailsId]);

      if (rejectionResult.length > 0) {
        returnValue = true;
      } else {
        returnValue = true;
        // const reasonForFailure = ` Error! - Inconsistency in the database, Last uploaded package does not exist in ice_iozipfilesinuploadfolder table`;
        // reason = reasonForFailure;

        // const updateFailureSQL = `UPDATE springer.ice_iozipfilesinuploadfolder SET currentfilestatusid = 13, reasonforfailure = $2 WHERE iozipfileid = $1`;
        // const updateResult = await query(updateFailureSQL, [
        //   ioZipFileId,
        //   reasonForFailure,
        // ]);

        // if (updateResult.length == 0) {
        //   returnValue = false;
        // }
      }
    }
  } catch (ex) {
    reason = ex.message;
    // console.error(Error In File Uploading - checkSuccessLogForPreviousUploaded(),  + ex.toString());
    returnValue = false;
  }

  res.status(200).send({ message: reason, isSuccess: returnValue });
};
