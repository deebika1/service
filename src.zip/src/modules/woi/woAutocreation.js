/* eslint-disable no-unused-vars */
/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import { readFile } from 'fs';
import xmlParser from 'fast-xml-parser';
import moment from 'moment';
import xml2jsonConvertor from 'xml2js';
import { query } from '../../database/postgres.js';
import { woxmlConfig, woKeyConfig } from '../bpmn/parser/core/config.js';
import {
  WorkOrderCreation,
  mailTriggerForAutoWOCreate,
  mailTriggerForWatcherIdle,
} from './index.js';
import { triggerWOStageWf_logic, settriggerNextStagewf } from './stage.js';
import {
  getFolderStructure_autowocreate,
  getFolderStructure,
} from '../utils/wmsFolder/index.js';
import {
  _blobExist,
  _copyFileWithoutFormData,
  _download,
  _upload,
  renameBlob,
  writeRawcontentToBlob,
} from '../utils/azure/index.js';
import { uploadFiletoOpenKM } from '../utils/okm/index.js';
import { emitAction } from '../activityListener/index.js';
import { getJournalDetail } from '../common/index.js';
import { fileTxnUpdate } from '../task/index.js';
import {
  ubrIntegrationService,
  updateWoJournalCurrency,
} from '../../odoo/service/index.js';
import { triggerMsgEvent } from '../utils/wfTrigger/trigger.js';
import {
  checkItracksExits,
  getiTracksActivityId,
  getiTracksCustomerId,
  getiTracksDuId,
  getiTracksStageId,
  taskDespatchJournal,
} from '../iTracks/index.js';
import { _insertCAMSAcknowledge } from '../report/wip/index.js';
import { getdmsType } from '../bpmn/listener/create.js';
import { _localdownload } from '../utils/local/index.js';
import pdfjsLib from 'pdfjs-dist/legacy/build/pdf.js';
import axios from 'axios';
import dayjs from 'dayjs';
import xmlformat from 'xml-formatter';
import { Service } from '../../httpClient/index.js';
import { basename, dirname } from 'path';
import { xmlContentsUpdate } from '../../iAlt/blobService/utils/blob.js';

const service = new Service();

export const readWorkorderInfo = async (req, res) => {
  const { stagename, articlename } = req.body;
  const ndate = Date.now();
  const date_ob = new Date(ndate);
  const date = date_ob.getDate();
  const month = date_ob.getMonth() + 1;
  const year = date_ob.getFullYear();
  const hours = date_ob.getHours();
  const minutes = date_ob.getMinutes();
  const seconds = date_ob.getSeconds();

  // prints date & time in YYYY-MM-DD format
  const tdate = `${year}-${month}-${date} ${hours}:${minutes}:${seconds}`;

  let output = {
    issuccess: false,
    message: 'wo creation started',
    workorderid: 0,
    uploadpath: '',
  };
  try {
    const resp = await readWorkorderInfoprocess(req, res);
    if (resp) {
      output = resp;
    } else {
      output.message = 'wo creation failed';
    }
  } catch (error) {
    output.message = error.message;
  } finally {
    res.json(output);
    res.end('Response sent message');
  }
};

export const itracksFinancialIntegration = async (
  workorderId,
  stagename,
  woType,
  inputfiletype = 1,
  // eslint-disable-next-line consistent-return
) => {
  try {
    // woType.toLowerCase() != 'book'
    // Check if any of the parameters are undefined
    if (workorderId === undefined || woType === undefined) {
      throw new Error(
        'All parameters (workorderId, woType) are required and cannot be undefined',
      );
    }

    let jobcreate = true;
    if (woType?.toLowerCase() == 'book' && inputfiletype == 2) {
      jobcreate = false;
    }
    if (jobcreate) {
      const getstage = await query(
        `select stageid from wms_mst_stage where isactive = true and stagename = $1`,
        [stagename],
      );
      let mstageid = 0;
      if (getstage != undefined && getstage.length) {
        mstageid = getstage[0].stageid;
      }

      if (woType.toLowerCase() == 'journal') {
        await updateWoJournalCurrency(workorderId);
      }

      const resjobcreate = await ubrIntegrationService({
        workorderId,
        stageId: mstageid,
        servicetype: 'jobcardcreation',
        woId: 0,
        woType,
      });

      if (resjobcreate.status && woType?.toLowerCase() != 'book') {
        await ubrIntegrationService({
          workorderId,
          stageId: mstageid,
          // servicetype: 'articlecreation',
          servicetype: 'servicecreation',
          woId: 0,
        });
      }
    }
    return 'Success';
  } catch (e) {
    console.log(e.message, 'failed-itracksFinancialIntegration');
  }
};

export const woInstructions = async instruction => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wostageid, userId, date, text } = instruction;
      const sql = `INSERT INTO wms_workorder_stage_instructions(wostageid, insttext,addedon,addedby) VALUES ($1,$2,$3,$4) RETURNING wostageinstid;`;
      const resForEntry = await query(sql, [wostageid, text, date, userId]);
      resolve(resForEntry, 'woInstructions success');
    } catch (e) {
      reject(e);
    }
  });
};

export const getWKjournals = async (req, res) => {
  // const { piivalue } = req;
  return new Promise(async resolve => {
    const sql = `select mp.ftpaliasname,jo.journalacronym  from pp_mst_journal jo  
    inner join org_mst_customer_orgmap om on om.custorgmapid=jo.custorgmapid 
    inner join pp_mst_journal_alias_ftp mp on lower(mp.journalacronym)=lower(jo.journalacronym)
    where customerid=13
     `;
    await query(sql)
      .then(response => {
        if (response.length) {
          res.status(200).send({ issuccess: true, data: response });
        } else {
          res.status(200).send({ issuccess: false, data: response });
        }
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

export const getWKjournalsForNewsLetter = async (req, res) => {
  const sql = ` select mp.ftpaliasname,jo.journalacronym 
  ,case when jo.newsletter = true then true else false end as newsletter 
  from pp_mst_journal jo  
  left join org_mst_customer_orgmap om on om.custorgmapid=jo.custorgmapid 
  left join pp_mst_journal_alias_ftp mp on lower(mp.journalacronym)=lower(jo.journalacronym)
  where customerid=13
  and newsletter = true
     `;
  await query(sql)
    .then(response => {
      if (response.length) {
        res.status(200).send({ issuccess: true, data: response });
      } else {
        res.status(200).send({ issuccess: false, data: response });
      }
    })
    .catch(error => {
      res.status(400).send({ issuccess: false, message: error });
    });
};
export const checkWorkflowType = async jnlId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = ` select newsletter from pp_mst_journal where journalid = ${jnlId}`;
      const JournalDetails = await query(sql);
      resolve(JournalDetails);
    } catch (error) {
      reject(error);
    }
  });
};
export const getWKjournalsByFTPName = async (req, res) => {
  const { ftpname } = req.body;
  return new Promise(async resolve => {
    const sql = `select mp.ftpaliasname,jo.journalacronym,jo.cereview,jo.isiauthor  from pp_mst_journal jo  
    inner join org_mst_customer_orgmap om on om.custorgmapid=jo.custorgmapid 
    inner join pp_mst_journal_alias_ftp mp on lower(mp.journalacronym)=lower(jo.journalacronym)
    where customerid=13 and lower(mp.ftpaliasname) = lower('${ftpname}');`;
    await query(sql)
      .then(response => {
        if (response.length) {
          res.status(200).send({ issuccess: true, data: response });
        } else {
          res.status(200).send({ issuccess: false, data: response });
        }
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

export const UpdateManuscriptzipname = async (req, res) => {
  const { itemcode, manuscriptzipname } = req.body;
  return new Promise(async resolve => {
    const sql = `UPDATE wms_workorder
    SET otherfield = jsonb_set(otherfield::jsonb, '{manuscriptzipname}', '"${manuscriptzipname}"', true)
    WHERE itemcode = '${itemcode}';`;
    await query(sql)
      .then(response => {
        res.status(200).send({ issuccess: true, data: response });
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};
export const UpdateOUPDetails = async (req, res) => {
  const jsonData = req.body;
  return new Promise(async resolve => {
    const sqlSelect = `select * from wms_workorder WHERE itemcode = '${jsonData.Article}'`;
    const out = await query(sqlSelect);
    if (out.length > 0) {
      jsonData.isPAP = out[0].otherfield.isPAP;
      const jsonString = JSON.stringify(jsonData);
      const sql = `UPDATE wms_workorder
    SET otherfield = '${jsonString}'::json, ceddetails='${jsonData.copyrightType}'
    WHERE itemcode = '${jsonData.Article}'`;
      await query(sql)
        .then(response => {
          res.status(200).send({ issuccess: true, data: response });
        })
        .catch(error => {
          res.status(400).send({ issuccess: false, message: error });
        });
    } else {
      res.status(200).send({ issuccess: false, message: 'Record not found.' });
    }
  });
};

export const getExistarticleList = async (req, res) => {
  console.log(req);
  const sql = `select * from public.ftp_audit_wo_creation 
    where duname = 'WKH'  and issuccess = true 
    and createdon between (CURRENT_DATE - 1)::timestamp(0) and now ()::timestamp(0)
    order by 1 desc;`;
  await query(sql)
    .then(response => {
      res.status(200).send({ data: response });
    })
    .catch(error => {
      res.status(400).send({ issuccess: false, message: error });
    });
};
export const getStageIterationCount = async (req, res) => {
  const { wfstageid, itemcode } = req.body;
  return new Promise(async resolve => {
    const sql = `select ww.workorderid, wws.wostageid, wws.wfstageid  ,wws.stageiterationcount ,wws.status
    from wms_workorder ww  
    join wms_workorder_stage wws on ww.workorderid = wws.workorderid 
    where wfstageid = $1 and ww.itemcode  = $2 order by wws.wostageid desc limit 1`;
    await query(sql, [wfstageid, itemcode])
      .then(response => {
        if (response.length) {
          res.status(200).send({ issuccess: true, data: response });
        } else {
          res.status(200).send({ issuccess: false, data: response });
        }
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

export const readWorkorderInfoprocess = async (req, res) => {
  let logid = 0;
  let output = '';
  let cparam = '';
  let ismailsend = true;
  let dmstype = 'azure';
  let isuploadfile = true;
  let err_message = '';

  console.log(ismailsend);
  return new Promise(async resolve => {
    let woDetails1;
    let eventDetails;
    const {
      customer,
      fileType,
      woType,
      stagename,
      articlename,
      stageiterationcount,
      journal,
      tranid,
      remark,
      piivalue,
      jobType,
      otherInput,
      content,
    } = req.body;

    const initiallogmesage =
      remark == undefined || remark == ''
        ? 'Wo creation process started and incomplete'
        : `failed in reading file: ${remark}`;

    let levelofeffort = 0;
    let levelEffortProb1 = 0;
    let levelEffortProb2 = 0;
    let levelEffortProb3 = 0;
    let grammarmatch = '';
    let taskduedate = '';

    let wfconfdata = {
      issuccess: false,
      message: initiallogmesage,
      articlename,
      journal,
      customer,
      stageName: stagename,
      iteration: stageiterationcount,
    };

    if (remark != '') {
      output = {
        issuccess: false,
        message: initiallogmesage,
        workorderid: 0,
        uploadpath: '',
      };
    }

    let actiontype = 'wocreation_error';

    try {
      const objreqbody = req.body;
      objreqbody.tranid = tranid;
      objreqbody.logmessage = initiallogmesage;

      const logresp = await workorderlog(objreqbody, 'Insert');
      logid = logresp.logid;

      if (customer == 'CUP') {
        dmstype = 'azure';
        isuploadfile = true;
      } else {
        dmstype = 'local';
        isuploadfile = false;
      }

      if (
        (fileType.toLowerCase() == 'xml' &&
          (remark == '' || remark == undefined)) ||
        ((fileType.toLowerCase() == 'docx' ||
          fileType.toLowerCase() == 'pdf') &&
          (remark == '' || remark == undefined))
      ) {
        const checkjournaldetail = await getJournalDetail({
          journalshortname: journal,
          customershortname: customer,
        });

        // const wodetails = await getWorkOrderDetail_Itemcode(articlename);
        // if (wodetails.length > 0) {
        //   dmstype = wodetails[0].dmstype;
        //   console.log(dmstype, 'dmstype');
        // }
        const retwoexist = await checWoandStageStatus({
          body: {
            articlename,
            stagename,
            stageiterationcount,
          },
        });

        let alljobcompleted = true;

        if (
          customer.toLowerCase() == 'springer' &&
          woType == 'Journal' &&
          jobType == 'Issue'
        ) {
          const jsoninput = JSON.parse(otherInput);
          const getstatus = await checkworkorderstatus(jsoninput.doilist);
          if (getstatus && getstatus.issuccess) {
            alljobcompleted = true;
            await updatewocolorprint(jsoninput.colorinprintlist);
          } else {
            alljobcompleted = false;
          }
        }

        if (customer.toLowerCase() === 'acs') {
          levelofeffort = req.body.levelofeffort;
          levelEffortProb1 = req.body.levelEffortProb1;
          levelEffortProb2 = req.body.levelEffortProb2;
          levelEffortProb3 = req.body.levelEffortProb3;
          grammarmatch = req.body.gramarmatch;
        }

        if (customer.toLowerCase() === 'wkh') {
          taskduedate = req.body.taskduedate;
        }

        let valid = true;
        if (
          checkjournaldetail.error != undefined &&
          stagename != 'First View' &&
          woType.toLowerCase() != 'book'
        ) {
          valid = false;
          err_message = 'Email and other details not present for journal';
        } else if (alljobcompleted == false) {
          valid = false;
          err_message = 'Stage 600 chapters not fully completed';
        } else {
          valid = true;
        }

        if (valid) {
          /** ****WORKORDER CREATION PROCESS******** */
          if (
            stageiterationcount == 1 &&
            stagename != 'First View' &&
            stagename != 'Revised First View' &&
            retwoexist.issuccess == true &&
            retwoexist.iswoexist == false
          ) {
            if (req.body.content.toLowerCase() != '') {
              const wo_response = await getWorkorderxmlData(req, res, logid);
              if (wo_response) {
                if (wo_response.status == true) {
                  cparam = {
                    logmessage: wo_response.message,
                    issuccess: true,
                    workorderid: +wo_response.woId,
                    autologid: logid,
                    uploadpath: wo_response.uploadpath,
                    isstagetrigger: false,
                  };
                  output = {
                    issuccess: true,
                    message: wo_response.message,
                    workorderid: +wo_response.woId,
                    uploadpath: wo_response.uploadpath,
                  };

                  try {
                    itracksFinancialIntegration(
                      output.workorderid,
                      stagename,
                      woType,
                      req.body.inputFileTypes,
                    );
                  } catch (er) {
                    console.log(er);
                  }

                  //To trigger campus signal - Start
                  if (customer.toLowerCase() === 'cup') {
                    const campusQuery = `
                    SELECT pp_mst_journal.otherdetails ->> 'isSignal' AS iscampustrigger 
                    FROM wms_workorder 
                    JOIN pp_mst_journal ON wms_workorder.journalid = pp_mst_journal.journalid 
                    WHERE wms_workorder.workorderid = $1
                    `;

                    const response = await query(campusQuery, [
                      wo_response.woId,
                    ]);

                    if (
                      response &&
                      response.length > 0 &&
                      response[0].iscampustrigger === 'true'
                    ) {
                      // Trigger Campus Signal
                      const payload = {
                        workorderId: wo_response.woId,
                        stageName: stagename,
                        stageIteration: stageiterationcount,
                        payloadType: 'dynamicPayload',
                        flowType: 'ftp',
                        isRound: false,
                        isPagecount: false,
                      };
                      const campRes = await _sendCampusSignal(payload);
                      console.log(campRes, 'campRes');
                    }
                  }

                  // To trigger campus signal - End
                } else {
                  cparam = {
                    logmessage: wo_response.message,
                    issuccess: false,
                    workorderid: 0,
                    autologid: logid,
                    uploadpath: '',
                    isstagetrigger: false,
                  };
                  output = {
                    issuccess: false,
                    message: wo_response.message,
                    workorderid: 0,
                    uploadpath: '',
                  };
                }
              } else {
                cparam = {
                  logmessage: 'failed',
                  issuccess: false,
                  workorderid: 0,
                  autologid: logid,
                  uploadpath: '',
                  isstagetrigger: false,
                };
                output = {
                  issuccess: false,
                  message: 'failed',
                  workorderid: 0,
                  uploadpath: '',
                };
              }
            } else {
              cparam = {
                logmessage: 'Workorder XML content is empty',
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              output = {
                issuccess: false,
                message: 'Workorder XML content is empty',
                workorderid: 0,
                uploadpath: '',
              };
            }

            wfconfdata = {
              issuccess: output.issuccess,
              message: output.message,
              articlename,
              journal,
              customer,
              stageName: stagename,
              iteration: stageiterationcount,
            };
            actiontype =
              output.issuccess == true
                ? 'wocreation_success'
                : 'wocreation_error';
          } //* *****Stage trigger Process Start********//
          else if (
            (retwoexist.issuccess == true &&
              retwoexist.iswoexist == true &&
              (retwoexist.isstageexist == false ||
                retwoexist.isstagecomplete == true)) ||
            stagename == 'First View' ||
            stagename == 'Revised First View'
          ) {
            if (customer.toLowerCase().includes('springer')) {
              dmstype = 'local';
              isuploadfile = false;
            } else if (customer.toLowerCase() == 'wkh') {
              dmstype = 'local';
              isuploadfile = false;
            } else {
              dmstype = 'azure';
              isuploadfile = true;
            }

            const reqobj = {
              stagename,
              articlename,
              woType,
              stageiterationcount,
              journal,
            };
            console.log(reqobj);

            actiontype = 'stagecreation_error';
            if (
              stagename != 'First View' ||
              stagename != 'Revised First View'
            ) {
              woDetails1 = await getworkorderdetail_bystage(
                articlename,
                stagename,
              );

              eventDetails = await getWfEventDetailsForWo(
                articlename,
                stagename,
                +stageiterationcount,
              );
            }

            console.log(eventDetails);
            if (
              stagename == 'First View' ||
              stagename == 'Revised First View'
            ) {
              // ismailsend = false;
              const getjob = await getArticleDetailByPii({ piivalue });
              if (getjob.issuccess) {
                reqobj.articlename = getjob.data[0].itemcode;
                reqobj.journal = getjob.data[0].journalacronym;
                // articlename = getjob.data[0].itemcode;
                // journal = reqobj.journal;
              }
            }

            let trigstat = {
              message: '',
              issuccess: false,
              uploadpath: '',
            };
            if (customer == 'ACS') {
              await articleTAT_ACS(
                woDetails1[0].workorderid,
                stagename,
                levelofeffort,
              );

              if (stagename == 'Copy Editing') {
                await updatecelevel_ACS(
                  woDetails1[0].workorderid,
                  levelofeffort,
                  levelEffortProb1,
                  levelEffortProb2,
                  levelEffortProb3,
                  grammarmatch,
                );
              }
            }

            // for cup journals vaithi
            if (stagename === 'First View' && customer === 'CUP') {
              try {
                const getjob = await getArticleDetailByPii({ piivalue });

                if (getjob?.issuccess && getjob.data?.length) {
                  const {
                    itemcode: articlenameID,
                    journalacronym: journalID,
                    workorderid: woID,
                  } = getjob.data[0];
                  const isContPubReq = await isContinuePub(journalID);
                  if (isContPubReq.issuccess) {
                    await getEllocationID(journalID, Number(woID));
                  }
                } else {
                  console.warn('No valid job data found for PII:', piivalue);
                }
              } catch (error) {
                console.error('Error processing EllocationID', error);
                resolve({
                  issuccess: false,
                  data: { remarks: 'Error processing EllocationID' },
                });
              }
            }

            //

            if (customer == 'OUP') {
              const xmlobjdata = content
                ? await readXMLDatafromContent(content, woxmlConfig)
                : {};

              const objoupstagedata = await oupstageconstruction(
                Object.values(xmlobjdata)[0],
                journal,
              );

              const oupstagedata = objoupstagedata.data;

              await insert_Additional_WoStage_Oup(
                woDetails1[0].workorderid,
                oupstagedata,
              );
            } else {
              //CAMPUS API integration for CUP  Colation & Revises
              // if (
              //   customer.toLowerCase() === 'cup' &&
              //   ['revises', 'collation'].includes(stagename.toLowerCase())
              // ) {
              //   const campusQuery = `
              // SELECT pp_mst_journal.otherdetails ->> 'isSignal' AS iscampustrigger
              // FROM wms_workorder
              // JOIN pp_mst_journal ON wms_workorder.journalid = pp_mst_journal.journalid
              // WHERE wms_workorder.workorderid = $1
              // `;

              //   const response = await query(campusQuery, [
              //     woDetails1[0].workorderid,
              //   ]);

              //   if (
              //     response &&
              //     response.length > 0 &&
              //     response[0].iscampustrigger === 'true'
              //   ) {
              //     // Trigger Campus Signal
              //     const payload = {
              //       workorderId: woDetails1[0].workorderid,
              //       stageName: stagename,
              //       stageIteration: stageiterationcount,
              //       payloadType: 'dynamicPayload',
              //       flowType: 'ftp',
              //       isRound: true,
              //       isPagecount: false,
              //     };
              //     const campRes = await _sendCampusSignal(payload);
              //     console.log(campRes, 'campRes');
              //   }
              // }
              // //
              trigstat = await getwostagetrigger({ body: reqobj }, res);
              // trigstat = { issuccess: 'success' };
            }
            if (trigstat.issuccess && customer == 'WKH' && taskduedate !== '') {
              await updateduedate_wkh(
                woDetails1[0].workorderid,
                woDetails1[0].customerid,
                woDetails1[0].duid,
                woDetails1[0].stageid,
                taskduedate,
              );
            }

            if (trigstat.issuccess == true) {
              actiontype = 'stagecreation_success';

              if (
                stagename == 'First View' ||
                stagename == 'Revised First View'
              ) {
                ismailsend = false;
              }
              cparam = {
                logmessage: 'success',
                issuccess: true,
                workorderid: 0,
                autologid: logid,
                uploadpath: trigstat.uploadpath,
                isstagetrigger: true,
              };
              output = {
                issuccess: true,
                message: 'success',
                uploadpath: trigstat.uploadpath,
              };
            } else {
              cparam = {
                logmessage: trigstat.message,
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: true,
              };
              output = {
                issuccess: false,
                message: trigstat.message,
                uploadpath: '',
              };
            }

            wfconfdata = {
              issuccess: output.issuccess,
              message: output.message,
              articlename: reqobj.articlename,
              journal: reqobj.journal,
              customer,
              stageName: stagename,
              iteration: stageiterationcount,
            };
          } else if (
            retwoexist.issuccess == true &&
            retwoexist.iswoexist == true &&
            retwoexist.isstageexist == true
          ) {
            ismailsend = false;
            if (retwoexist.isstagecomplete == false) {
              cparam = {
                logmessage: 'Current stage is In progres cannot trigger stage',
                issuccess: false,
                workorderid: -1,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              output = {
                issuccess: false,
                message: 'Current stage is In progres cannot trigger stage',
                uploadpath: '',
              };
            } else {
              const respayload = await payloadStagetriggerFileupload({
                body: {
                  stagename,
                  articlename,
                  woType,
                  stageiterationcount,
                },
              });
              if (respayload.issuccess) {
                const fileuploadpath = await getFolderStructure_autowocreate({
                  body: JSON.parse(respayload.uploadpathpayload),
                });

                if (fileuploadpath) {
                  cparam = {
                    logmessage: 'success',
                    issuccess: true,
                    workorderid: -1,
                    autologid: logid,
                    uploadpath: fileuploadpath,
                    isstagetrigger: false,
                  };
                  output = {
                    issuccess: false,
                    message: 'success',
                    uploadpath: fileuploadpath,
                  };
                } else {
                  const msg =
                    'File upload path is not available while stage trigger';
                  cparam = {
                    logmessage: msg,
                    issuccess: false,
                    workorderid: -1,
                    autologid: logid,
                    uploadpath: '',
                    isstagetrigger: false,
                  };
                  output = { issuccess: false, message: msg, uploadpath: '' };
                }
              } else {
                const msg = 'Failed on getting payload for stage trigger';
                cparam = {
                  logmessage: msg,
                  issuccess: false,
                  workorderid: -1,
                  autologid: logid,
                  uploadpath: '',
                  isstagetrigger: false,
                };
                output = { issuccess: false, message: msg, uploadpath: '' };
              }
            }
          } else {
            output = {
              issuccess: false,
              message: 'Workorder and stage details not found.',
              uploadpath: '',
            };
          }
        } else {
          cparam = {
            logmessage: err_message,
            issuccess: false,
            workorderid: 0,
            autologid: logid,
            uploadpath: '',
            isstagetrigger: false,
          };
          wfconfdata = {
            issuccess: false,
            message: err_message,
            articlename,
            journal,
            customer,
            stageName: stagename,
            iteration: stageiterationcount,
          };
          output = {
            issuccess: false,
            message: err_message,
            workorderid: 0,
            uploadpath: '',
          };
        }

        ///
        if (output.issuccess) {
          if (
            stagename == 'Revises' &&
            customer == 'CUP' &&
            woType == 'Journal'
          ) {
            if (woDetails1) {
              let fileuploadpath = '';

              const filepathpayload = {
                type: 'wo_activity_file_subtype',
                du: { name: woDetails1[0].duname, id: woDetails1[0].duid },
                customer: {
                  name: woDetails1[0].customername,
                  id: woDetails1[0].customerid,
                },
                workOrderId: woDetails1[0].workorderid,
                service: {
                  name: woDetails1[0].servicename,
                  id: woDetails1[0].serviceid,
                },
                stage: {
                  name: stagename,
                  id: woDetails1[0].stageid,
                  iteration:
                    +stageiterationcount > 1
                      ? +stageiterationcount - 1
                      : +stageiterationcount,
                },
                activity: {
                  name: 'completion trigger',
                  id: 21,
                  iteration: 1,
                },
                fileType: {
                  name: 'article',
                  id: '4',
                  fileId: woDetails1[0].woincomingfileid,
                },
              };

              fileuploadpath = await getFolderStructure_autowocreate({
                body: filepathpayload,
              });

              // fileuploadpath = getFolderStructure({
              //   type: 'wo_activity_file_subtype',
              //   du: { name: woDetails1[0].duname, id: woDetails1[0].duid },
              //   customer: {
              //     name: woDetails1[0].customername,
              //     id: woDetails1[0].customerid,
              //   },
              //   workOrderId: woDetails1[0].workorderid,
              //   service: {
              //     name: woDetails1[0].servicename,
              //     id: woDetails1[0].serviceid,
              //   },
              //   stage: {
              //     name: stagename,
              //     id: woDetails1[0].stageid,
              //     iteration:
              //       +stageiterationcount > 1
              //         ? +stageiterationcount - 1
              //         : +stageiterationcount,
              //   },
              //   activity: {
              //     name: 'completion trigger',
              //     id: 21,
              //     iteration: 1,
              //   },
              //   fileType: {
              //     name: 'article',
              //     id: '4',
              //     fileId: woDetails1[0].woincomingfileid,
              //   },
              // });

              fileuploadpath = fileuploadpath.replace(
                'completion_trigger_',
                'completion_trigger__',
              );
              output.uploadpath = fileuploadpath;
              cparam.uploadpath = fileuploadpath;
            }
          }
        }

        ///

        // else if (req.body.fileType.toLowerCase() == 'excel') {
        //   const wo_response = await getWorkorderExcelData(req, res);
        //   console.log(wo_response);
        // }

        //* *****uploading process start********//
        if (
          isuploadfile == true &&
          output.issuccess == true &&
          stagename != 'First View' &&
          stagename != 'Revised First View'
        ) {
          if (
            output.uploadpath != '' &&
            req.files &&
            (req.files.zip || req.files.xml)
          ) {
            let OpenKMOutput;

            switch (dmstype) {
              case 'azure':
                if (customer == 'CUP') {
                  if (woType == 'Journal' && jobType == 'Issue') {
                    OpenKMOutput = await _upload(
                      req.files.zip,
                      `${output.uploadpath}ZIP/`,
                    );
                    if (output.uploadpath != '' && req.files && req.files.xml) {
                      await _upload(req.files.xml, `${output.uploadpath}XML/`);
                    }
                  } else {
                    OpenKMOutput = await _upload(
                      req.files.zip,
                      output.uploadpath,
                    );
                    if (output.uploadpath != '' && req.files && req.files.xml) {
                      await _upload(req.files.xml, output.uploadpath);
                    }
                  }
                } else {
                  OpenKMOutput = await _upload(
                    req.files.zip,
                    output.uploadpath,
                  );
                  if (output.uploadpath != '' && req.files && req.files.xml) {
                    await _upload(req.files.xml, output.uploadpath);
                  }
                }
                break;
              default:
                OpenKMOutput = await uploadFiletoOpenKM(
                  req,
                  output.uploadpath,
                  'zip',
                );
                break;
            }
            //  let oOpenKMOutput = dmstype == 'openkm' ? await uploadFiletoOpenKM(req, output.uploadpath, "zip") :
            //     await _upload(req.files["zip"], output.uploadpath);

            req.body.uid = OpenKMOutput.data.uuid;
            req.body.uploadpath = OpenKMOutput.fullPath;

            if (stagename == 'Revises' && woType == 'Journal') {
              if (eventDetails && eventDetails.length > 0) {
                await fileTxnUpdate(
                  eventDetails[0].wfeventid,
                  OpenKMOutput.uuid,
                  OpenKMOutput.fullPath,
                  eventDetails[0].woincomingfileid,
                );
              }
            }
            const ures = await insert_uploadpath_uid(req);
            if (ures && ures.issuccess == false) {
              cparam = {
                logmessage: 'Failed to insert on table source file details',
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              wfconfdata = {
                issuccess: false,
                message: 'Failed to insert on table source file details',
                articlename,
                journal,
                customer,
                stageName: stagename,
                iteration: stageiterationcount,
              };
            }
          } else {
            cparam = {
              logmessage: 'File upload failed',
              issuccess: false,
              workorderid: 0,
              autologid: logid,
              uploadpath: '',
              isstagetrigger: false,
            };
            wfconfdata = {
              issuccess: false,
              message: 'File upload failed',
              articlename,
              journal,
              customer,
              stageName: stagename,
              iteration: stageiterationcount,
            };
          }
        }

        if (output.issuccess == true && isuploadfile == false) {
          req.body.uid = 'local';
          req.body.uploadpath = output.uploadpath;
          await insert_uploadpath_uid(req);
        }
      }
      //* *****uploading process end********//
    } catch (e) {
      cparam = {
        logmessage: e.message,
        issuccess: false,
        workorderid: 0,
        autologid: logid,
        uploadpath: '',
        isstagetrigger: false,
      };
      wfconfdata = {
        issuccess: false,
        message: 'Wo creation failed',
        articlename,
        journal,
        customer,
        stageName: stagename,
        iteration: stageiterationcount,
      };
      if (e.code === 'ECONNRESET') {
        output = {
          issuccess: false,
          message: 'Connection was reset. Please Retry.',
          uploadpath: '',
        };
        // Retry logic here
      } else {
        output = { issuccess: false, message: e.message, uploadpath: '' };
      }
    } finally {
      workorderlog(cparam, 'Update').catch(err => {});

      if (customer == 'CUP') {
        if (woType == 'Journal' && jobType !== 'Issue') {
          if (ismailsend) {
            const sql2 = `select j.journalacronym ||'_'|| (w.otherfield ->> 'pii')::text as itemcode from wms_workorder w
            join pp_mst_journal j on j.journalid = w.journalid
         where itemcode  ='${wfconfdata.articlename}'`;
            console.log(sql2, 'sql2');
            const data = await query(sql2);
            wfconfdata.articlename =
              data && data.length > 0
                ? data[0].itemcode
                : wfconfdata.articlename;
            mailTriggerForAutoWOCreate(wfconfdata, actiontype);
          }
        }
      }

      // res.json(output);
      resolve(output);
    }
  });
};

export const TestSendEmail = async (req, res) => {
  const {
    workorderId,
    stageId,
    servicetype,
    subjobname,
    subJobId,
    woType,
    stagename,
    inputfiletype,
  } = req.body;
  // emitAction(data);
  // await insert_Additional_WoStage_Oup(500);

  await itracksFinancialIntegration(
    workorderId,
    stagename,
    woType,
    inputfiletype,
  );

  console.log(inputfiletype);
  console.log(stagename);

  // const rstatus = await ubrIntegrationService({
  //   workorderId,
  //   stageId,
  //   servicetype,
  //   woId: 0,
  //   subjobname,
  //   subJobId,
  //   woType,
  // });
  // console.log(rstatus);
  res.send('success');
};

const getArticleDetailByPii = async req => {
  const { piivalue } = req;
  return new Promise(async resolve => {
    const sql = `select 
                  wo.workorderid, wo.itemcode, wo.title, wo.customerid, wo.divisionid, 
                  wo.subdivisionid, wo.countryid,  wo.status, wo.journalid, wo.wotype, 
                  wo.doinumber, jo.journalacronym
                 from wms_workorder as wo
                 left join public.pp_mst_journal as jo on jo.journalid = wo.journalid and jo.isactive = 1
                 where wo.isactive = true and wo.otherfield->>'pii' = '${piivalue}'`;
    // console.log(sql, 'logsql');
    query(sql)
      .then(response => {
        if (response.length) {
          resolve({ issuccess: true, data: response });
        } else {
          resolve({ issuccess: false, data: response });
        }
      })
      .catch(() => {
        resolve({ issuccess: false, data: {} });
      });
  });
};

export const getEllocationID = async (jouranlID, woid) => {
  try {
    const sql = `SELECT elocationid FROM public.wms_workorder wo join pp_mst_journal jo on wo.journalid = wo.journalid
WHERE wo.elocationid IS NOT NULL AND wo.customerid = 8 AND wo.isactive = 'true' and jo.journalacronym = '${jouranlID}'
ORDER BY wo.elocationid DESC LIMIT 1`;

    const response1 = await query(sql);

    if (response1.length) {
      //
      const sql3 = `
UPDATE public.wms_workorder 
SET elocationid = $1 
WHERE workorderid = $2 AND isactive = 'true';
`;

      const response2 = await query(sql3, [
        Number(response1[0].elocationid) + 1,
        woid,
      ]);
      //

      return { issuccess: true, data: response2 };
    }

    const sql2 = `
      SELECT otherdetails->>'erratumid' AS elocationid  
      FROM public.pp_mst_journal 
      WHERE journalacronym = '${jouranlID}' 
      LIMIT 10`;

    const response3 = await query(sql2);

    if (response3.length) {
      //
      const sql3 = `
UPDATE public.wms_workorder 
SET elocationid = $1 
WHERE workorderid = $2 AND isactive = 'true'
RETURNING *;
`;

      const response4 = await query(sql3, [
        Number(response3[0].elocationid) + 1,
        Number(woid),
      ]);
      //

      return { issuccess: true, data: response4 };
    }

    return { issuccess: false, data: {} }; // If both queries return empty results
  } catch (error) {
    console.error('Error fetching elocation ID:', error);
    return {
      issuccess: false,
      error: 'An error occurred while fetching data.',
    };
  }
};

export const updateEllocationID = async (woid, elocationID) => {
  try {
    if (!woid || !elocationID) {
      throw new Error(
        'Invalid input: Work Order ID and eLocation ID are required.',
      );
    }

    const sql3 = `
      UPDATE public.wms_workorder 
      SET elocationid = $1 
      WHERE workorderid = $2 AND isactive = 'true'
      RETURNING *;
    `;

    const response = await query(sql3, [elocationID, woid]);

    if (response?.length) {
      return { issuccess: true, data: response };
    }
    return {
      issuccess: false,
      error: 'No records updated. Check if Work Order ID exists.',
    };
  } catch (error) {
    console.error('Error updating eLocation ID:', error);
    return {
      issuccess: false,
      error: error.message || 'An error occurred while updating data.',
    };
  }
};

export const isContinuePub = async journalID => {
  return new Promise(async resolve => {
    const sql = ` SELECT otherdetails->>'erratumid' AS elocationid  
  FROM public.pp_mst_journal 
  WHERE journalacronym = '${journalID}' 
  LIMIT 10`;
    console.log(sql, 'logsql');
    const response = await query(sql);

    if (Number(response[0]?.elocationid)) {
      resolve({
        issuccess: true,
      });
    } else {
      resolve({
        issuccess: false,
      });
    }
  });
};

export const checWoandStageStatus = async req => {
  const { articlename, stagename, stageiterationcount } = req.body;

  return new Promise(async resolve => {
    const sql = `SELECT * from checkworkorderstage_exist('${articlename}','${stagename}',${stageiterationcount})`;
    console.log(sql, 'logsql');

    query(sql)
      .then(response => {
        if (response.length) {
          // let triggerstage = false;
          // if( (response[0].isstagetriggered && response[0].isstagecomplete) || response[0].isstagetriggered == false ) {
          //     triggerstage =   true;
          // }

          resolve({
            issuccess: true,
            iswoexist: response[0].isworkorderexist,
            isstageexist: response[0].isstagetriggered,
            isstagecomplete: response[0].isstagecomplete,
          });
        } else {
          resolve({
            issuccess: false,
            iswoexist: false,
            isstageexist: false,
            isstagecomplete: false,
          });
        }
      })
      .catch(() => {
        resolve({
          issuccess: false,
          iswoexist: false,
          isstageexist: false,
          isstagecomplete: false,
        });
      });
  });
};

const getwostagetrigger = async (req, res) => {
  const { stagename, articlename, stageiterationcount } = req.body;
  // let iparam = JSON.stringify(req);
  return new Promise(async resolve => {
    const respayload = await payloadStagetriggerFileupload(req);

    if (
      (respayload.issuccess == true &&
        stagename == 'AMO' &&
        respayload.amostagepayload != '') ||
      (stagename != 'AMO' && respayload.nextstagepayload != '')
    ) {
      const filtepathpayload = respayload.uploadpathpayload
        ? JSON.parse(respayload.uploadpathpayload)
        : '{}';
      const amostagepayload = respayload.amostagepayload
        ? JSON.parse(respayload.amostagepayload)
        : '{}';
      const nextstagepayload = respayload.nextstagepayload
        ? JSON.parse(respayload.nextstagepayload)
        : '{}';

      let checkresp;

      if (stagename == 'AMO') {
        checkresp = await settriggerNextStagewf({ body: amostagepayload }, res);
      } else if (stagename == 'Revised First View') {
        nextstagepayload.files.forEach(fi => {
          fi.__isTextCorr__ = true;
        });
        checkresp = await triggerWOStageWf_logic(
          { body: nextstagepayload },
          res,
        );
      } else if (stagename == 'First View') {
        nextstagepayload.files.forEach(fi => {
          fi.__isCPreq__ = false;
        });
        checkresp = await triggerWOStageWf_logic(
          { body: nextstagepayload },
          res,
        );
      } else {
        checkresp = await triggerWOStageWf_logic(
          { body: nextstagepayload },
          res,
        );
      }
      //  });
      if (checkresp && checkresp.issuccess) {
        await updatestagetatdate({
          articlename,
          stagename,
          stageiterationcount,
        });

        const fileuploadpath = await getFolderStructure_autowocreate({
          body: filtepathpayload,
        });

        resolve({
          message: 'success',
          issuccess: true,
          uploadpath: fileuploadpath,
        });
      } else {
        resolve({
          message: `Stage trigger failed -(${checkresp.message})`,
          issuccess: false,
          uploadpath: '',
        });
      }
    } else {
      resolve({
        message: 'Failed on getting payload for stage trigger',
        issuccess: false,
        uploadpath: '',
      });
    }
  });
};

const updatestagetatdate = async req => {
  const { articlename, stagename, stageiterationcount } = req;
  return new Promise(async resolve => {
    const sql = `SELECT * from update_stage_tatdate('${articlename}','${stagename}', ${stageiterationcount})`;
    query(sql)
      .then(() => {
        resolve('success');
      })
      .catch(() => {
        resolve('failed');
      });
  });
};

export const test = async (req, res) => {
  const payload = {
    woId: '567',
    type: 'next',
    wfeventId: '4070',
    userId: 'System',
    currentStage: { iteration: 1, id: 24, name: 'Copy Editing' },
    targetStage: {
      iteration: 1,
      id: 1,
      name: 'First Proof',
      plannedStart: '2024-06-18T17:42:36',
      plannedEnd: '2024-06-18T17:42:36',
      sequence: 9,
      receiptdate: null,
    },
    files: [
      {
        id: '1704',
        name: 'ANCv55j66',
        type: 'Article',
        filetypeid: '4',
        mspages: null,
        estimatedpages: null,
        isChecked: true,
      },
      {
        id: '1705',
        name: 'ANCv55j66_TOC',
        type: 'TOC',
        filetypeid: '17',
        mspages: null,
        estimatedpages: null,
        isChecked: true,
      },
    ],
    category: 'Articlewise',
    serviceId: '1',
    serviceName: 'Typesetting',
    entityId: 8,
    wfId: '31',
    customerId: '13',
    jobcardId: 'ANCv55j66',
    woType: 'Journal',
    jobId: 'ANCv55j66',
    duId: '12',
    processInstance: [],
    isbnUpdateConfirmation: false,
    newISBN: '',
    oldISBN: 'null',
    isbnLabel: 'printisbn',
  };

  const checkresult = await triggerWOStageWf_logic({ body: payload }, res);
};

export const payloadStagetriggerForNewsLetter = async (req, res) => {
  const articlename = req.body.result.itemocde[0];
  try {
    console.log(req.body);
    const sql = `select orgmap.duid,wo.workorderid,wo.itemcode,wo.customerid,wo.journalid,wf.wfid,eventlog.wfeventid,
    def.wfdefid,eventlog.activityinstanceid,eventlog.activitystatus,eventlog.parentinstanceid,
    eventlog.taskinstanceid,eventlog.eventdata,def.stageid,def.activityid,def.activitytype,
    eventlog.userid,wf.wfcategory,woservice.serviceid,service.servicename,wo.wotype,
    wo.printisbn,wostage.stageiterationcount,wostage.plannedstartdate,wostage.plannedenddate,wostage.sequence
    from wms_workorder wo 
    join pp_mst_journal journal on journal.journalid = wo.journalid
    join wms_workorder_stage wostage on wostage.workorderid = wo.workorderid
    join wms_workflow_eventlog eventlog on eventlog.workorderid = wo.workorderid
    join wms_workflowdefinition def on def.wfdefid = eventlog.wfdefid
    join wms_workorder_service woservice on woservice.workorderid = wo.workorderid
    join wms_workflow wf on wf.wfid = woservice.wfid
   join wms_mst_service service on service.serviceid = woservice.serviceid 
   join public.org_mst_customer_orgmap cust on cust.customerid = wo.customerid
   join public.org_mst_customerorg_du_map orgmap on orgmap.custorgmapid = cust.custorgmapid
   where wo.itemcode = '${articlename}'
   order by eventlog.wfeventid desc limit 1`;

    const resultdata = await query(sql);

    if (resultdata.length > 0) {
      if (
        resultdata[0].stageid == 24 &&
        resultdata[0].activityid == 380 &&
        resultdata[0].activitystatus == 'Completed'
      ) {
        const sql1 = `select elog.wfeventid,elog.workorderid,elog.wfdefid from wms_workflow_eventlog elog
            join wms_workflowdefinition def on def.wfdefid = elog.wfdefid
            where elog.wfdefid = ${resultdata[0].wfdefid} and elog.activitystatus = '${resultdata[0].activitystatus}' 
            and elog.workorderid = ${resultdata[0].workorderid}`;
        const copyeventid = await query(sql1);

        const resultRecord = resultdata[0];

        const sql2 = `SELECT json_agg(t) :: text  FROM
         (SELECT b.woincomingfileid :: character varying as "id", b.filename as "name", c.filetype as "type", c.filetypeid :: character varying, null as mspages, null as estimatedpages,
          true as "isChecked"
         FROM wms_workorder_incoming a 
         JOIN wms_workorder_incomingfiledetails b ON b.woincomingid = a.woincomingid
         JOIN pp_mst_filetype c ON c.filetypeid = b.filetypeid
         WHERE a.woid = ${resultRecord.workorderid} AND b.filetypeid NOT IN (1,15))t `;
        const filedata = await query(sql2);
        const jsonArray = JSON.parse(filedata[0].json_agg);

        const selectedFiles = jsonArray.filter(item => item.filetypeid !== 1);
        const fileobj = selectedFiles.map(item => {
          return { id: item.id };
        });
        console.log('fileobj', fileobj);

        if (copyeventid.length > 0) {
          const currentstagepayload = {
            iteration: resultRecord.stageiterationcount,
            id: resultRecord.stageid,
            name: 'Copy Editing',
          };
          const payload = {
            woId: resultRecord.workorderid,
            type: 'next',
            wfeventId: copyeventid[0].wfeventid,
            userId: resultRecord.userid,
            currentStage: currentstagepayload,
            targetStage: {
              iteration: 1,
              id: 1,
              name: 'First Proof',
              plannedStart: resultRecord.plannedstartdate,
              plannedEnd: resultRecord.plannedenddate,
              sequence: resultRecord.sequence,
              receiptdate: null,
            },
            files: fileobj,
            category: 'Articlewise',
            serviceId: resultRecord.serviceid,
            serviceName: resultRecord.servicename,
            entityId: 8,
            wfId: resultRecord.wfid,
            customerId: resultRecord.customerid,
            jobcardId: resultRecord.itemcode,
            woType: resultRecord.wotype,
            jobId: resultRecord.itemcode,
            duId: resultRecord.duid,
            processInstance: [],
            isbnUpdateConfirmation: false,
            newISBN: '',
            oldISBN: 'null',
            isbnLabel: resultRecord.printisbn,
            isAutoStageTrigger: true,
          };
          console.log('payload', payload);
          const checkresultdata = await triggerWOStageWf_logic(
            { body: payload },
            res,
          );
          res.status(200).send({ ...checkresultdata });
        } else {
          res
            .status(400)
            .send({ wfeventid: [], message: 'wfeventid is not found' });
        }
      }
    } else {
      res.status(400).send({ message: 'No matching data found.' });
    }
  } catch (error) {
    res.status(400).send({ message: 'First Proof Stage trigger Failed' });
  }
};

export const payloadStagetriggerForNewsLetterRevises = async (req, res) => {
  const articlename = req.body.result.itemocde[0];
  try {
    console.log(req.body);
    const sql = `select orgmap.duid,wo.workorderid,wo.itemcode,wo.customerid,wo.journalid,wf.wfid,eventlog.wfeventid,
    def.wfdefid,eventlog.activityinstanceid,eventlog.activitystatus,eventlog.parentinstanceid,
    eventlog.taskinstanceid,eventlog.eventdata,def.stageid,stg.stagename,def.activityid,def.activitytype,
    eventlog.userid,wf.wfcategory,woservice.serviceid,service.servicename,wo.wotype,
    wo.printisbn,wostage.stageiterationcount,wostage.plannedstartdate,wostage.plannedenddate,wostage.sequence
    from wms_workorder wo 
    join pp_mst_journal journal on journal.journalid = wo.journalid
    join wms_workorder_stage wostage on wostage.workorderid = wo.workorderid
    join wms_workflow_eventlog eventlog on eventlog.workorderid = wo.workorderid
    join wms_workflowdefinition def on def.wfdefid = eventlog.wfdefid
    join wms_workorder_service woservice on woservice.workorderid = wo.workorderid
    join wms_workflow wf on wf.wfid = woservice.wfid
   join wms_mst_service service on service.serviceid = woservice.serviceid 
   join public.org_mst_customer_orgmap cust on cust.customerid = wo.customerid
   join public.org_mst_customerorg_du_map orgmap on orgmap.custorgmapid = cust.custorgmapid
   join public.wms_mst_stage stg on stg.stageid= def.stageid
   where wo.itemcode = '${articlename}'
   order by eventlog.wfeventid desc limit 1`;

    const resultdata = await query(sql);

    if (resultdata.length > 0) {
      if (
        resultdata[0].stageid == 1 &&
        resultdata[0].activityid == 21 &&
        resultdata[0].activitystatus == 'Unassigned'
      ) {
        const sql1 = `select elog.wfeventid,elog.workorderid,elog.wfdefid from wms_workflow_eventlog elog
            join wms_workflowdefinition def on def.wfdefid = elog.wfdefid
            where elog.wfdefid = ${resultdata[0].wfdefid} and elog.activitystatus = '${resultdata[0].activitystatus}' 
            and elog.workorderid = ${resultdata[0].workorderid}`;
        const copyeventid = await query(sql1);

        const resultRecord = resultdata[0];

        const sql2 = `SELECT json_agg(t) :: text  FROM
         (SELECT b.woincomingfileid :: character varying as "id", b.filename as "name", c.filetype as "type", c.filetypeid :: character varying, null as mspages, null as estimatedpages,
          true as "isChecked"
         FROM wms_workorder_incoming a 
         JOIN wms_workorder_incomingfiledetails b ON b.woincomingid = a.woincomingid
         JOIN pp_mst_filetype c ON c.filetypeid = b.filetypeid
         WHERE a.woid = ${resultRecord.workorderid} AND b.filetypeid NOT IN (1,15))t `;
        const filedata = await query(sql2);

        const jsonArray = JSON.parse(filedata[0].json_agg);

        const selectedFiles = jsonArray.filter(item => item.filetypeid !== 1);
        const fileobj = selectedFiles.map(item => {
          return { id: item.id };
        });
        console.log('fileobj', fileobj);
        const flowType = ['isgeneral'];
        const flows = flowType.join("','");
        const sql3 = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
        join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
        join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
        and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
        where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
        and iterationcount=$3 and flowtype   in ('${flows}')
        group by nextstageid, stagename order by min(sequence)`;
        const nextStageDetails = await query(sql3, [
          resultdata[0].wfid,
          resultdata[0].stageid,
          resultdata[0].stageiterationcount,
        ]);
        console.log('nextStageDetails', nextStageDetails);
        const { workorderid } = resultdata[0];
        const { nextstageid } = nextStageDetails[0];

        const sqlquery = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;

        const targetStageInfo = await query(sqlquery, [
          workorderid,
          nextstageid,
        ]);
        console.log('targetStageInfo', targetStageInfo);
        const { sequence, plannedstartdate, plannedenddate } =
          targetStageInfo[0];

        const nextStageIteration = targetStageInfo.filter(
          item => item.status === 'Completed',
        );

        if (copyeventid.length > 0) {
          const currentstagepayload = {
            iteration: resultRecord.stageiterationcount,
            id: resultRecord.stageid,
            name: 'First Proof',
          };
          const payload = {
            woId: resultRecord.workorderid,
            type: 'next',
            wfeventId: copyeventid[0].wfeventid,
            userId: resultRecord.userid,
            currentStage: currentstagepayload,
            targetStage: {
              iteration: nextStageIteration.length + 1,
              id: nextStageDetails[0].nextstageid,
              name: nextStageDetails[0].nextstagename,
              plannedStart: resultRecord.plannedstartdate,
              plannedEnd: resultRecord.plannedenddate,
              sequence: resultRecord.sequence,
              receiptdate: null,
            },
            files: fileobj,
            category: 'Articlewise',
            serviceId: resultRecord.serviceid,
            serviceName: resultRecord.servicename,
            entityId: 8,
            wfId: resultRecord.wfid,
            customerId: resultRecord.customerid,
            jobcardId: resultRecord.itemcode,
            woType: resultRecord.wotype,
            jobId: resultRecord.itemcode,
            duId: resultRecord.duid,
            processInstance: [],
            isbnUpdateConfirmation: false,
            newISBN: '',
            oldISBN: 'null',
            isbnLabel: resultRecord.printisbn,
            isAutoStageTrigger: true,
          };
          console.log('payload', payload);
          const checkresultdata = await triggerWOStageWf_logic(
            { body: payload },
            res,
          );
          res.status(200).send({ ...checkresultdata });
        } else {
          res
            .status(400)
            .send({ wfeventid: [], message: 'wfeventid is not found' });
        }
      }
    } else {
      res.status(400).send({ message: 'No matching data found.' });
    }
  } catch (error) {
    res.status(400).send({ message: 'Revises Stage trigger Failed' });
  }
};

export const payloadStagetriggerForNewsLetterPrinter = async (req, res) => {
  const articlename = req.body.result.itemocde[0];
  try {
    console.log(req.body);
    const sql = `select orgmap.duid,wo.workorderid,wo.itemcode,wo.customerid,wo.journalid,wf.wfid,eventlog.wfeventid,
    def.wfdefid,eventlog.activityinstanceid,eventlog.activitystatus,eventlog.parentinstanceid,
    eventlog.taskinstanceid,eventlog.eventdata,def.stageid,def.activityid,def.activitytype,
    eventlog.userid,wf.wfcategory,woservice.serviceid,service.servicename,wo.wotype,
    wo.printisbn,wostage.stageiterationcount,wostage.plannedstartdate,wostage.plannedenddate,wostage.sequence
    from wms_workorder wo 
    join pp_mst_journal journal on journal.journalid = wo.journalid
    join wms_workorder_stage wostage on wostage.workorderid = wo.workorderid
    join wms_workflow_eventlog eventlog on eventlog.workorderid = wo.workorderid
    join wms_workflowdefinition def on def.wfdefid = eventlog.wfdefid
    join wms_workorder_service woservice on woservice.workorderid = wo.workorderid
    join wms_workflow wf on wf.wfid = woservice.wfid
   join wms_mst_service service on service.serviceid = woservice.serviceid 
   join public.org_mst_customer_orgmap cust on cust.customerid = wo.customerid
   join public.org_mst_customerorg_du_map orgmap on orgmap.custorgmapid = cust.custorgmapid
   where wo.itemcode = '${articlename}'
   order by eventlog.wfeventid desc limit 1`;

    const resultdata = await query(sql);

    if (resultdata.length > 0) {
      if (
        resultdata[0].stageid == 2 &&
        resultdata[0].activityid == 21 &&
        resultdata[0].activitystatus == 'Unassigned'
      ) {
        const sql1 = `select elog.wfeventid,elog.workorderid,elog.wfdefid from wms_workflow_eventlog elog
            join wms_workflowdefinition def on def.wfdefid = elog.wfdefid
            where elog.wfdefid = ${resultdata[0].wfdefid} and elog.activitystatus = '${resultdata[0].activitystatus}' 
            and elog.workorderid = ${resultdata[0].workorderid}`;
        const copyeventid = await query(sql1);

        const resultRecord = resultdata[0];

        const sql2 = `SELECT json_agg(t) :: text  FROM
         (SELECT b.woincomingfileid :: character varying as "id", b.filename as "name", c.filetype as "type", c.filetypeid :: character varying, null as mspages, null as estimatedpages,
          true as "isChecked"
         FROM wms_workorder_incoming a 
         JOIN wms_workorder_incomingfiledetails b ON b.woincomingid = a.woincomingid
         JOIN pp_mst_filetype c ON c.filetypeid = b.filetypeid
         WHERE a.woid = ${resultRecord.workorderid} AND b.filetypeid NOT IN (1,15))t `;
        const filedata = await query(sql2);

        const jsonArray = JSON.parse(filedata[0].json_agg);

        const selectedFiles = jsonArray.filter(item => item.filetypeid !== 1);
        const fileobj = selectedFiles.map(item => {
          return { id: item.id };
        });
        console.log('fileobj', fileobj);

        const flowType = ['isnewsletter'];
        const flows = flowType.join("','");
        const sql3 = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
        join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
        join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
        and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
        where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
        and iterationcount=$3 and flowtype   in ('${flows}')
        group by nextstageid, stagename order by min(sequence)`;
        const nextStageDetails = await query(sql3, [
          resultdata[0].wfid,
          resultdata[0].stageid,
          resultdata[0].stageiterationcount,
        ]);
        console.log('nextStageDetails', nextStageDetails);
        const { workorderid } = resultdata[0];
        const { nextstageid } = nextStageDetails[0];

        const sqlquery = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;

        const targetStageInfo = await query(sqlquery, [
          workorderid,
          nextstageid,
        ]);
        console.log('targetStageInfo', targetStageInfo);
        const { sequence, plannedstartdate, plannedenddate } =
          targetStageInfo[0];

        if (copyeventid.length > 0) {
          const currentstagepayload = {
            iteration: resultRecord.stageiterationcount,
            id: resultRecord.stageid,
            name: 'Revises',
          };
          const payload = {
            woId: resultRecord.workorderid,
            type: 'next',
            wfeventId: copyeventid[0].wfeventid,
            userId: resultRecord.userid,
            currentStage: currentstagepayload,
            targetStage: {
              iteration: 1,
              id: nextStageDetails[0].nextstageid,
              name: nextStageDetails[0].nextstagename,
              plannedStart: resultRecord.plannedstartdate,
              plannedEnd: resultRecord.plannedenddate,
              sequence: resultRecord.sequence,
              receiptdate: null,
            },
            files: fileobj,
            category: 'Articlewise',
            serviceId: resultRecord.serviceid,
            serviceName: resultRecord.servicename,
            entityId: 8,
            wfId: resultRecord.wfid,
            customerId: resultRecord.customerid,
            jobcardId: resultRecord.itemcode,
            woType: resultRecord.wotype,
            jobId: resultRecord.itemcode,
            duId: resultRecord.duid,
            processInstance: [],
            isbnUpdateConfirmation: false,
            newISBN: '',
            oldISBN: 'null',
            isbnLabel: resultRecord.printisbn,
            isAutoStageTrigger: true,
          };
          console.log('payload', payload);
          const checkresultdata = await triggerWOStageWf_logic(
            { body: payload },
            res,
          );
          res.status(200).send({ ...checkresultdata });
        } else {
          res
            .status(400)
            .send({ wfeventid: [], message: 'wfeventid is not found' });
        }
      }
    } else {
      res.status(400).send({ message: 'No matching data found.' });
    }
  } catch (error) {
    res.status(400).send({ message: 'Printer Stage trigger Failed' });
  }
};

export const payloadStagetriggerFileupload = async req => {
  const { stagename, articlename, woType, stageiterationcount } = req.body;
  return new Promise(async resolve => {
    const sql = `SELECT * from getarticlestagetrigger('${stagename}','${articlename}','${woType}','${stageiterationcount}')`;

    query(sql)
      .then(async response => {
        if (response) {
          const { fileuploadpayload } = response[0];
          const stagetriggerpayload = response[0].stagepayload;
          const amostagepayload = response[0].amopayload;
          const { nextstagepayload } = response[0];
          resolve({
            issuccess: true,
            uploadpathpayload: fileuploadpayload,
            stagetriggerpayload,
            amostagepayload,
            nextstagepayload,
          });
        }
      })
      .catch(() => {
        resolve({
          issuccess: false,
          uploadpathpayload: '',
          stagetriggerpayload: '',
          amostagepayload: '',
          nextstagepayload: '',
        });
      });
  });
};

export const insert_uploadpath_uid = async req => {
  const { articlename, stagename, stageiterationcount, uploadpath, uid } =
    req.body;
  return new Promise(async resolve => {
    const sql = `select insert_uploadpathuid ('${articlename}','${stagename}',${stageiterationcount},'${uploadpath}','${uid}')`;

    query(sql)
      .then(async response => {
        if (response && response.length) {
          const respid = response[0].insert_uploadpathuid;
          resolve({ issuccess: true, id: respid, message: 'success' });
        } else {
          resolve({ issuccess: false, id: 0, message: 'failed' });
        }
      })
      .catch(error => {
        resolve({ issuccess: false, id: 0, message: error.message });
      });
  });
};
export const insertUploadPathUid = async (req, res) => {
  try {
    const respobj = await insert_uploadpath_uid(req);
    if (respobj && respobj.issuccess == true) {
      res.status(200).send({ issuccess: true, message: respobj.message });
    } else {
      res.status(400).send({ issuccess: false, message: respobj.message });
    }
  } catch (error) {
    res.status(400).send({ issuccess: false, message: error.message });
  }
};

export const workorderlog = async (req, flag) => {
  const iparam = JSON.parse(JSON.stringify(req));
  iparam.content = '';
  return new Promise(async resolve => {
    const sql = `SELECT * from workorder_autolog('${JSON.stringify(
      iparam,
    )}','${flag}')`;

    query(sql)
      .then(response => {
        if (response) {
          const lid = response[0].logresult;
          resolve({ logid: lid });
        } else {
          resolve({ logid: 0 });
        }
      })
      .catch(() => {
        resolve({ logid: 0 });
      });
  });
};

export const getWorkorderxmlData = async (req, res, logid) => {
  const {
    InPath,
    customer,
    woType,
    jobType,
    stagename,
    articlename,
    journal,
    tasktype,
    springerinput,
    // manuscriptzipname,
    otherInput,
    prog1,
    prog2,
    prog3,
    grammer,
    levelofeffort,
    taskduedate,
    inputFileTypes,
  } = req.body;
  const { content } = req.body;
  let currentkey = '';
  let oupstagedata = [];
  return new Promise(async resolve => {
    try {
      const setPayloads = {};
      if (customer == 'CUP') {
        if (woType == 'Journal') {
          if (jobType == 'Issue') {
            currentkey = woKeyConfig.cup_bookxmlkeys;
          } else {
            currentkey = woKeyConfig.cup_journalxmlkeys;
          }
        } else {
          // book
          currentkey = woKeyConfig.cup_bookxmlkeys;
        }
      } else if (customer == 'Emerald') {
        if (woType == 'Journal')
          currentkey = woKeyConfig.emerald_journalxmlkeys;
        if (woType == 'Book') currentkey = woKeyConfig.emerald_bookxmlkeys;
      } else if (customer == 'IOPP') {
        if (woType == 'Journal') currentkey = woKeyConfig.iopp_journalxmlkeys;
      } else if (customer.toLowerCase() == 'springer') {
        if (jobType == 'Issue') {
          currentkey = woKeyConfig.springer_issuexmlkeys;
        } else {
          currentkey = woKeyConfig.springer_journalxmlkeys;
        }
        // currentkey = woKeyConfig.springer_journalxmlkeys;
      } else if (customer == 'WKH') {
        currentkey = woKeyConfig.WKH_journalxmlkeys;
      } else if (customer == 'ACS') {
        currentkey = woKeyConfig.ACS_journalxmlkeys;
        setPayloads.inputFileTypes = Number.isNaN(inputFileTypes)
          ? 1
          : parseInt(inputFileTypes);
      } else if (customer == 'OUP') {
        currentkey = woKeyConfig.OUP_journalxmlkeys;
      } else if (customer == 'Springer Books') {
        currentkey = woKeyConfig.springer_bookxmlkeys;
      }
      //
      const xmlobjdata = content
        ? await readXMLDatafromContent(content, woxmlConfig)
        : await readXMLData(InPath, woxmlConfig);
      //

      let errormsg = '';
      if (xmlobjdata) {
        const keyobj = JSON.parse(currentkey);

        for (const [key, value] of Object.entries(keyobj[0])) {
          if (key.includes('XML')) {
            if (value.includes(',')) {
              let xval = readKeyvalue(value, Object.values(xmlobjdata)[0]);

              if (xval === undefined) {
                xval = '';
                errormsg =
                  errormsg.length > 0
                    ? `${errormsg}, ${key.replace(/^xml(?:DBID)?/i, '')}`
                    : `${key.replace(/^xml(?:DBID)/i, '')}`;
              }
              xval =
                typeof xval === 'string' || typeof xval === 'number'
                  ? xval
                  : '';
              if (key.includes('XMLDBID'))
                setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
                  value: xval,
                  keyconfig: key,
                });
              else setPayloads[key.replace('XML', '')] = xval;
            } else {
              let dval = Object.values(xmlobjdata)[0][value];
              if (dval === undefined) {
                if (
                  customer == 'CUP' &&
                  woType == 'Journal' &&
                  key === 'XMLarticleno'
                ) {
                  dval = '';
                } else {
                  errormsg =
                    errormsg.length > 0
                      ? `${errormsg}, ${key.replace(/^xml(?:DBID)?/i, '')}`
                      : `${key.replace(/^xml(?:DBID)?/i, '')}`;
                  dval = '';
                }
              }
              const fval = typeof dval === 'object' ? dval[0] : dval;

              if (key.includes('XMLDBID'))
                setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
                  value: fval,
                  keyconfig: key,
                });
              else setPayloads[key.replace('XML', '')] = fval;
            }
          } else {
            setPayloads[key] = value;
          }
        }
      }

      if (errormsg.length > 0) {
        resolve({
          message: `The following element is "${errormsg}" missing in metadata`,
          status: false,
          uploadpath: '',
        });
        return;
      }
      let users = [];
      // (customer == 'CUP' || customer == 'IOPP') &&
      if (woType == 'Journal') {
        const customerName = customer == 'CUP' ? 'CUP Journals' : customer;
        const DBjournaldet = await getCustomerJournalDetail({
          customer: customerName,
          journalAcronym: journal,
        });

        if (DBjournaldet.length > 0) {
          for (const [key, value] of Object.entries(DBjournaldet[0])) {
            if (
              key == 'customer' ||
              key == 'country' ||
              key == 'colours' ||
              key == 'journalId'
            ) {
              setPayloads[key] = +value;
            } else {
              setPayloads[key] =
                typeof setPayloads[key] === 'number' ? +value : value;
            }
          }
          if (customer == 'CUP' || customer == 'WKH') {
            if (woType == 'Journal' && jobType !== 'Issue') {
              // eslint-disable-next-line no-const-assign
              users = await constructAuthorDetails(setPayloads);
              if (users.issuccess == true) {
                setPayloads.externalUsers = users.data;
              }
            }
          }
          if (customer.toLowerCase() == 'springer') {
            if (woType == 'Journal' && jobType !== 'Issue') {
              const lstusers = [];
              // eslint-disable-next-line no-const-assign
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };

              const spaudet = JSON.parse(
                JSON.parse(springerinput).articleauthor,
              );
              pushobj.email = spaudet.email;
              pushobj.name = spaudet.name;
              lstusers.push(pushobj);

              setPayloads.externalUsers = lstusers;
              setPayloads.isESM = JSON.parse(springerinput).isESM;
              setPayloads.flowtype = JSON.parse(springerinput).flowtype;
              setPayloads.CELevel = JSON.parse(springerinput).copyEditingValue;
            } else if (woType == 'Journal' && jobType === 'Issue') {
              const lstusers = [];
              // eslint-disable-next-line no-const-assign
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };

              pushobj.email = 'test@integra.co.in';
              pushobj.name = 'Springer Issue';
              lstusers.push(pushobj);

              setPayloads.externalUsers = lstusers;
              setPayloads.jobTitle = `${articlename}-Issue`;

              setPayloads.frontmatterPrintPDF =
                JSON.parse(otherInput).frontmatterPrintPDF;
              setPayloads.backmatterPrintPDF =
                JSON.parse(otherInput).backmatterPrintPDF;
              setPayloads.coverPrintPDF = JSON.parse(otherInput).coverPrintPDF;
              setPayloads.advertisementPrintPDF =
                JSON.parse(otherInput).advertisementPrintPDF;

              setPayloads.iscolorinprint =
                JSON.parse(otherInput).iscolorinprint;
            }
          }

          if (customer.toLowerCase() == 'acs') {
            if (woType == 'Journal' && jobType !== 'Issue') {
              const lstusers = [];
              // eslint-disable-next-line no-const-assign
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };
              pushobj.email = 'abc@gmail.com';
              pushobj.name = 'acs customer';
              lstusers.push(pushobj);
              setPayloads.journalAcronym = journal;
              setPayloads.externalUsers = lstusers;
              setPayloads.prog1 = prog1;
              setPayloads.prog2 = prog2;
              setPayloads.prog3 = prog3;
              setPayloads.grammer = grammer;
              setPayloads.levelofeffort = levelofeffort;
            }
          }
          if (customer.toLowerCase() == 'oup') {
            const objoupstagedata = await oupstageconstruction(
              Object.values(xmlobjdata)[0],
              journal,
              setPayloads.CELevel,
            );

            oupstagedata = objoupstagedata.data;

            if (woType == 'Journal' && jobType !== 'Issue') {
              // eslint-disable-next-line no-const-assign
              const { doiNumber, email, name } = req.body;
              setPayloads.journalAcronym = journal;
              setPayloads.doiNumber = doiNumber;
              const lstusers = [];
              // eslint-disable-next-line no-const-assign
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };
              pushobj.email = email;
              pushobj.name = name;
              lstusers.push(pushobj);
              setPayloads.externalUsers = lstusers;
            }
          }

          if (customer.toLowerCase() == 'wkh') {
            setPayloads.manuscriptzipname =
              JSON.parse(otherInput).manuscriptzipname;
            setPayloads.CELevel =
              JSON.parse(otherInput).iscopyediting == true ? 2 : 1;
            setPayloads.taskduedate = taskduedate;
            setPayloads.metafilename = JSON.parse(otherInput).metafilename;
          }
          // users = await constructAuthorDetails(setPayloads);
          // if (users.issuccess == true) {
          //   setPayloads.externalUsers = users.data;
          // }
        } else {
          resolve({
            message: 'journal detail not present',
            status: false,
            uploadpath: '',
          });
          return;
        }
      }
      if (woType.toLowerCase() == 'book') {
        const customerName = customer == 'CUP' ? 'CUP Journals' : customer;
        const DBBookdet = await getCustomerBookDetail({
          customer: customerName,
          journalAcronym: journal,
        });
        if (DBBookdet.length > 0) {
          for (const [key, value] of Object.entries(DBBookdet[0])) {
            if (
              key == 'customer' ||
              key == 'country' ||
              key == 'colours' ||
              key == 'edition'
            ) {
              setPayloads[key] = +value;
            } else {
              setPayloads[key] =
                typeof setPayloads[key] === 'number' ? +value : value;
            }
          }
          if (customer.toLowerCase() == 'springer books') {
            if (woType == 'Book') {
              const lstusers = [];
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };

              const spaudet = JSON.parse(
                JSON.parse(springerinput).articleauthor,
              );
              pushobj.email = spaudet.email;
              pushobj.name = spaudet.name;
              lstusers.push(pushobj);
              setPayloads.externalUsers = lstusers;
              setPayloads.isESM = JSON.parse(springerinput).isESM;
              setPayloads.flowtype = JSON.parse(springerinput).flowtype;
              setPayloads.CELevel = JSON.parse(springerinput).copyEditingValue;
              setPayloads.bookid = JSON.parse(springerinput).bookid;
              setPayloads.edition = JSON.parse(springerinput).edition;
              setPayloads.tasktype = JSON.parse(springerinput).tasktype
                ? JSON.parse(springerinput).tasktype
                : '';
              setPayloads.isalttext = JSON.parse(springerinput).isalttext;
              setPayloads.doiNumber = JSON.parse(springerinput).doiNumber;
              setPayloads.jobTitle = JSON.parse(springerinput).jobTitle;
              setPayloads.noOfChapters = JSON.parse(springerinput).noOfChapters
                ? JSON.parse(springerinput).noOfChapters
                : 0;
              setPayloads.inputFileTypes = JSON.parse(springerinput)
                .inputFileTypes
                ? JSON.parse(springerinput).inputFileTypes
                : 1;
            }
          }
        } else {
          resolve({
            message: 'Book detail not present',
            status: false,
            uploadpath: '',
          });
          return;
        }
      }

      switch (jobType) {
        case 'Article':
          setPayloads.jobType = 1;
          break;
        case 'Non Article':
          setPayloads.jobType = 3;
          break;
        case 'Issue':
          setPayloads.jobType = 2;
          break;
        default:
      }

      setPayloads.trigerstagename = stagename;
      setPayloads.isauto = true;
      setPayloads.jobId = articlename;
      setPayloads.journalAcronym = journal;
      setPayloads.tasktype = tasktype;

      if (customer == 'CUP' || customer == 'WKH') {
        if (woType == 'Journal' && jobType !== 'Issue') {
          if (setPayloads.externalUsers == '') {
            resolve({
              message: 'author detail not present in xml',
              status: false,
              uploadpath: '',
            });
            return;
          }
          // add instruction in wms_workorder_stage
          const instructions = {
            wostageid: null,
            text: setPayloads.Instruction ? setPayloads.Instruction : '',
            date: moment(new Date()).format('YYYY-MM-DD'),
            userId: 'IS4615',
          };
          if (setPayloads.Instruction && setPayloads.Instruction.length > 0) {
            const wostageinstid = await woInstructions(instructions);
            setPayloads.wostageinstid =
              wostageinstid && wostageinstid.length > 0
                ? wostageinstid[0].wostageinstid
                : '';
          }
        }
      }
      const param = { payload: setPayloads, autologid: logid };

      await workorderlog(param, 'UpdatePayload');

      // to get no.of.articles from xml

      if (customer == 'CUP' && woType == 'Journal' && jobType == 'Issue') {
        xml2jsonConvertor.parseString(content, async (err, xmlResult) => {
          if (err) {
            console.error('Error parsing Xml:', err);
          }
          const filenamecount =
            xmlResult &&
            xmlResult['issue-order'] &&
            xmlResult['issue-order']['issue-running-order'][0] &&
            xmlResult['issue-order']['issue-running-order'][0].filename
              ? xmlResult['issue-order']['issue-running-order'][0].filename
                  .length
              : '';
          // console.log('Number of <filename> tags:', filenamecount);
          setPayloads.noOfArticles = filenamecount;
          // console.log(setPayloads);
          setPayloads.jobTitle = setPayloads.jobId;
          // checking articles completed in firstview or not
          setPayloads.backPii =
            xmlResult &&
            xmlResult['issue-order'] &&
            xmlResult['issue-order']['issue-running-order'][0] &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover
              .length > 0 &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover[0]
              .$ &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover[0].$
              .PII
              ? xmlResult['issue-order']['issue-running-order'][0].back_cover[0]
                  .$.PII
              : '';
          setPayloads.frontPii =
            xmlResult &&
            xmlResult['issue-order'] &&
            xmlResult['issue-order']['issue-running-order'][0] &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover
              .length > 0 &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover[0]
              .$ &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover[0].$
              .PII
              ? xmlResult['issue-order']['issue-running-order'][0]
                  .front_cover[0].$.PII
              : '';
          const xmlFileNames = Object.values(
            xmlResult['issue-order']['issue-running-order'][0].filename,
          );

          const fileNames = xmlFileNames.map(item => item._);
          // console.log(fileNames);
          const result = await isWoCompleted(fileNames);
          // console.log(result);

          if (result.issuccess == false) {
            resolve({
              message:
                'Failed on workorder creation, given Articles are not completed in iWms',
              status: false,
              uploadpath: '',
            });
          }
        });
      }

      const woresp = await WorkOrderCreation({ body: setPayloads }, res, true);
      // let woresp = {
      //   message: 'success',
      //   status: true,
      //   uploadpath: 'fileuploadpath',
      //   woId: 2755 }

      if (woresp.status && customer == 'ACS') {
        await articleTAT_ACS(
          woresp.woId,
          stagename,
          '',
          Object.values(xmlobjdata)[0],
        );
        console.log('wait');
      }

      if (woresp.status && customer == 'OUP') {
        await articleTAT_OUP(woresp.woId, stagename, oupstagedata);
        console.log('wait');
      }

      if (woresp.status && customer == 'WKH' && taskduedate !== '') {
        const wodetails = await getworkorderdetail_bystage(
          articlename,
          stagename,
        );

        if (wodetails != undefined && wodetails.length) {
          await updateduedate_wkh(
            woresp.woId,
            wodetails[0].customerid,
            wodetails[0].duid,
            wodetails[0].stageid,
            taskduedate,
          );
        }
      }

      resolve(woresp);
    } catch (e) {
      console.log(e, 'ee');
      resolve({
        message: 'Failed on workorder creation',
        status: false,
        uploadpath: '',
      });
    }
  });
};

const oupstageconstruction = async (xmlobjdata, journalcode, celevel = 0) => {
  return new Promise(async resolve => {
    const wrkflowstep = xmlobjdata.Workflows.Workflow;
    let currentstepcode = [];
    let rstagedata = [];
    let modeltype = '';
    for (let index = 0; index < wrkflowstep.length; index++) {
      const subwrkflow = wrkflowstep[index];
      if (subwrkflow && subwrkflow.__WOAttr__Step == 'Current') {
        const isteps = subwrkflow.Steps.Step;
        if (Array.isArray(isteps)) {
          const filterstep = isteps.filter(item =>
            ['PROOFOUT', 'MSTOCE', 'CVR PAP A', 'CVR PAP A,PROOFOUT'].includes(
              item.__WOAttr__Code,
            ),
          );
          currentstepcode = filterstep.map(item => item.__WOAttr__Code);
        } else if (typeof isteps == 'object') {
          currentstepcode.push(isteps.__WOAttr__Code);
        }
        modeltype = await getoupmodeltype(journalcode);
        rstagedata = await getouprelatedstage(currentstepcode, modeltype);
        if (celevel > 1) {
          rstagedata.push({ stageid: 24, stage: 'Copy Editing' });
        }
      }
      if (subwrkflow && subwrkflow.__WOAttr__Step == 'ALL') {
        if (rstagedata.length > 0) {
          const allsteps = subwrkflow.Steps.Step;
          console.log(allsteps);
          const stagedate = allsteps.map(item => ({
            stage: item.__WOAttr__Code,
            ScheduledEnd: item.ScheduledEnd,
          }));
          if (stagedate.filter(x => x.stage === 'CVR PAP A').length > 0) {
            if (rstagedata.filter(x => x.stageid == 33).length == 0) {
              rstagedata.push({ stageid: 33, stage: 'PAP Model A' });
            }
          }
          const removeByAttr = function (arr, attr, value) {
            let i = arr.length;
            while (i--) {
              if (arr[i] && arguments.length > 2 && arr[i][attr] === value) {
                arr.splice(i, 1);
              }
            }
            return arr;
          };

          if (journalcode == 'OXARTJ') {
            if (rstagedata.filter(x => x.stageid == 34).length > 0) {
              removeByAttr(rstagedata, 'stageid', 34);
            }
          }

          const stageMapping = {
            PROOFOUT: 'First Proof',
            'ALL CORRS RECVD': 'From Proof Reader',
            APPROVE: 'Revises',
            PAP: 'PAP Model B',
            CP: 'PAP Model B',
            'CVR PAP A': 'PAP Model A',
          };

          const updatedstageData = stagedate.map(item => ({
            stage: stageMapping[item.stage] || item.stage, // Use the mapping or fallback to the original value if not found
            ScheduledEnd: item.ScheduledEnd,
          }));

          const updatedRelatedStage = rstagedata.map(item => {
            // Find the corresponding stage in stageduedate
            const dueDate = updatedstageData.find(
              due => due.stage === item.stage,
            );
            // Return a new object with the existing properties and the ScheduledEnd
            return {
              ...item,
              ScheduledEnd: dueDate ? dueDate.ScheduledEnd : null, // Use null if no match is found
            };
          });
          resolve({
            data: updatedRelatedStage,
            stepcode: JSON.stringify(currentstepcode),
          });
        }
      }
    }
  });
};

const articleTAT_ACS = async (
  workorderid,
  stage,
  pleveleffort,
  xmlobjdata = {},
) => {
  return new Promise(async resolve => {
    const xmldata = xmlobjdata;
    const levelofeffort =
      Object.keys(xmldata).length && xmldata.attributeList
        ? xmldata.attributeList.levelOfEffort
        : pleveleffort;
    const objparam = {
      workorderid,
      stage,
      levelofeffort,
    };
    const jsonparam = JSON.stringify(objparam);

    const sql = `select * from articleTAT('${jsonparam}')`;

    const resdata = await query(sql);

    if (resdata && resdata.length) {
      resolve('test');
    }
  });
};

const constructAuthorDetails = async data => {
  const users = [];
  const rolelist = await getAllRole();

  return new Promise(resolve => {
    if (rolelist.data && rolelist.data.length > 0) {
      const { GivenName, Prefix, SurName, Email } = data;
      let rname = '';
      try {
        if (Prefix) {
          rname = `${Prefix} replace`;
        }
        if (GivenName) {
          rname =
            rname == ''
              ? GivenName
              : `${rname.replace('replace', GivenName)} replace`;
        }
        if (SurName) {
          rname = rname == '' ? SurName : rname.replace('replace', SurName);
        }
        rname = rname.replace('replace', '');
        const roledet = rolelist.data
          .filter(x => x.roleacronym == 'AUTHOR')
          .map(item => item.roleid);
        const pushobj = {
          email: Email,
          name: rname,
          role: roledet[0],
          roleAcronym: 'AUTHOR',
        };
        users.push(pushobj);
        if (users && users.length > 0) {
          resolve({ issuccess: true, data: users });
        } else {
          resolve({ issuccess: false, data: users });
        }
      } catch (e) {
        resolve({ issuccess: false, data: {} });
      }
    } else {
      resolve({ issuccess: false, data: {} });
    }
  });
};

// const generateExternaluser = async data => {
//   const users = [];
//   const rolelist = await getAllRole();
//   if (rolelist.data && rolelist.data.length > 0) {
//     return new Promise(resolve => {
//       const extuser = data;
//       const extdata = extuser
//         .filter(f => f['__WOAttr__contrib-type'] == 'author')
//         .map(md => {
//           const contype = md['__WOAttr__contrib-type'];
//           const corresp = md.__WOAttr__corr;
//           let remail = '';
//           let rname = '';
//           // const roleid = 0;
//           if (contype == 'author' && (corresp == 'yes' || corresp == 1)) {
//             remail = md.email.__WOText__;

//             if (remail == undefined) {
//               const maildtl = md.email.filter(
//                 x => x.__WOAttr__primary == 'True',
//               );
//               if (maildtl.length > 0) {
//                 remail = maildtl[0].__WOText__;
//               }
//             }

//             if (md.name.prefix) {
//               rname = `${md.name.prefix}replace`;
//             }
//             if (md.name['given-name']) {
//               rname =
//                 rname == ''
//                   ? md.name['given-name']
//                   : `${rname.replace(
//                       'replace',
//                       md.name['given-name'],
//                     )} replace`;
//             }
//             if (md.name.surname) {
//               rname =
//                 rname == ''
//                   ? md.name.surname
//                   : rname.replace('replace', md.name.surname);
//             }
//             rname = rname.replace('replace', '');

//             const roledet = rolelist.data
//               .filter(x => x.roleacronym == 'AUTHOR')
//               .map(item => item.roleid);
//             const pushobj = {
//               email: remail,
//               name: rname,
//               role: roledet[0],
//               roleAcronym: 'AUTHOR',
//             };
//             const eindex = users.findIndex(
//               object => object.roleAcronym == 'AUTHOR',
//             );
//             if (eindex === -1) {
//               users.push(pushobj);
//             }
//             console.log(users);
//           }
//         });

//       if (extdata && extdata.length > 0) {
//         resolve({ issuccess: true, data: users });
//       } else {
//         resolve({ issuccess: false, data: users });
//       }
//     });
//   }
// };

// export const getWorkorderExcelData = async (req) => {
//   const resData = req.body;
//   const { InPath, customer } = req.body;
//   // let currentkey = woKeyConfig.cupexcelkeys;
//   const keyobj = JSON.parse(currentkey);
//   const filepath =
//     'C:/Users/is9825/Desktop/New folder/file_example_XLSX_10.xlsx';

//   let currentkey = '';
//   switch (customer) {
//     case 'CUP':
//       currentkey = woKeyConfig.cup_excelkeys;
//       break;
//     case 'EMERALD':
//       currentkey = woKeyConfig.emerald_excelkeys;
//   }

//   const result = excelToJson({
//     sourceFile: InPath,
//   });
//   const excelrst = [];
//   if (result.Sheet1.length > 0) {
//     const FirstRow = result.Sheet1.shift();
//     const Headers = Object.values(FirstRow);
//     result.Sheet1.forEach(element => {
//       const values = Object.values(element);
//       const obj = {};
//       Headers.forEach((val, index) => {
//         obj[val] = values[index];
//       });
//       excelrst.push(obj);
//     });
//   }
//   console.log(excelrst);
//   let val_journalid = '';
//   let val_journaltitle = '';
//   let val_issn = '';

//   excelrst.forEach(val => {
//     // let dval = Object.values(val);
//     const xval = val;
//     val_journalid = val[keyobj.Journalid];
//     val_journaltitle = val[keyobj.Journaltitle];
//     val_issn = val[keyobj.issn];
//     console.log(dval);
//   });
// };

const readKeyvalue = (keytext, xmlobject) => {
  try {
    const keyereplace = keytext.replace(/","/g, '"_"');

    // const keyereplaceold = keytext.replaceAll('","', '"_"');
    //

    const splitkey = keyereplace.split(',');
    let currxmlobj = xmlobject;
    let indexplus = 0;
    let nextkeyindex = 0;

    for (let index = 0; index < splitkey.length; index++) {
      // splitkey[indexplus] = splitkey[indexplus].replaceAll("\"_\"", "\",\"");
      if (index > 0) {
        // indexplus = index + 1;
        indexplus = nextkeyindex + 1;
      }

      let currentkey = '';
      let currentattribute = '';
      let nextkey = '';
      let nextattribute = '';

      let attrstartindex = -1;
      let attrlastindex = -1;
      if (indexplus < splitkey.length) {
        if (splitkey[indexplus] && splitkey[indexplus].indexOf('{') == -1) {
          currentkey = splitkey[indexplus];
        } else {
          attrstartindex = splitkey[indexplus].indexOf('{');
          attrlastindex = splitkey[indexplus].indexOf('}') + 1;

          currentkey = splitkey[indexplus].substring(0, attrstartindex);
          currentattribute = splitkey[indexplus].substring(
            attrstartindex,
            attrlastindex,
          );
        }

        if (indexplus + 1 < splitkey.length) {
          nextkeyindex = indexplus + 1;

          //  splitkey[indexplus+1] = splitkey[indexplus+1].replaceAll("\"_\"", "\",\"");
          if (splitkey[indexplus + 1].indexOf('{') == -1) {
            nextkey = splitkey[indexplus + 1];
          } else {
            attrstartindex = splitkey[indexplus + 1].indexOf('{');
            attrlastindex = splitkey[indexplus + 1].indexOf('}') + 1;

            nextkey = splitkey[indexplus + 1].substring(0, attrstartindex);

            nextattribute = splitkey[indexplus + 1].substring(
              attrstartindex,
              attrlastindex,
            );
          }
        }
        const retrivedobject = reccall(
          currentkey,
          currxmlobj,
          currentattribute,
        );
        // const retrivedobject_old = currxmlobj[currentkey];
        console.log(retrivedobject);

        if (retrivedobject && nextkey != '') {
          if (Object.keys(retrivedobject).length > 0) {
            const retcontent = reccall(nextkey, retrivedobject, nextattribute);
            if (nextkey === splitkey[splitkey.length - 1]) {
              console.log(retcontent, 'rettttt');
              //  const returnresult = typeof retcontent === 'string' ? retcontent :
              //       typeof retcontent === 'object' ? retcontent.length ? retcontent[0]['__WOText__'] : '':'';
              return retcontent;
            }
            currxmlobj = retcontent;
          }
        } else {
          if (
            typeof retrivedobject == 'object' &&
            Object.keys(retrivedobject).includes('__WOText__')
          ) {
            const resultobj1 = Object.keys(retrivedobject).includes(
              '__WOText__',
            )
              ? retrivedobject.__WOText__
              : retrivedobject;
            return resultobj1;
          }
          if (
            Array.isArray(retrivedobject) &&
            retrivedobject.length &&
            Object.keys(retrivedobject[0]).includes('__WOText__')
          ) {
            const resultobj2 = retrivedobject[0].__WOText__;

            return resultobj2;
          }
          return retrivedobject;
        }
      } else {
        console.log(currxmlobj);
        currxmlobj =
          currxmlobj.length > 0 &&
          Object.keys(currxmlobj[0]).includes('__WOText__')
            ? currxmlobj[0].__WOText__
            : currxmlobj;
        return currxmlobj;
      }
    }
  } catch (error) {
    return undefined;
  }
  return {};
};

const reccall = function (key, xmlobj, attributeType) {
  // attributeType = attributeType.replaceAll('"_"', '","');
  attributeType = attributeType.replace(/"_"/g, '","');

  let result = '';
  if (attributeType == '') {
    if (xmlobj.length == undefined) {
      result =
        xmlobj.length > 0
          ? xmlobj[0][key]
          : Object.keys(xmlobj).includes(key)
          ? xmlobj[key]
          : xmlobj;
    }
    if (xmlobj.length > 0) {
      if (
        xmlobj[0][key].length != undefined &&
        xmlobj[0][key].length > 1 &&
        Array.isArray(xmlobj[0][key])
      ) {
        // eslint-disable-next-line prefer-destructuring
        result = xmlobj[0][key][0];
      } else {
        result = xmlobj[0][key].__WOText__
          ? xmlobj[0][key].__WOText__
          : xmlobj[0][key];
        //  result = xmlobj[0][key];
      }
    }
  } else if (Object.keys(attributeType).length > 0) {
    const toFilter = JSON.parse(attributeType);
    const keys = Object.keys(toFilter);
    let objectof = {};

    objectof = Array.isArray(xmlobj)
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key]) && xmlobj.length > 0
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key])
      ? xmlobj[key]
      : [xmlobj[key]];

    if (Array.isArray(objectof)) {
      result = objectof.filter(x => {
        if (typeof x === 'object') {
          const matchs = keys
            .map(y => x[`__WOAttr__${y}`] == toFilter[y])
            .filter(z => z == true);
          return matchs.length == keys.length;
        }
        return '';
      });
      // console.log(result);
    } else if (typeof objectof === 'object') {
      let checkloop = true;
      keys.forEach(element => {
        if (objectof[`__WOAttr__${element}`] == toFilter[element]) {
          console.log(objectof[`__WOAttr__${element}`]);
        } else {
          console.log('failed');
          checkloop = false;
        }
      });

      if (checkloop == true && objectof.__WOText__) {
        result = objectof.__WOText__;
      } else {
        result = '';
      }
    }
  }
  console.log(result);
  return result;
};

export const readXMLData = (wofilename, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      readFile(wofilename, { encoding: 'utf-8' }, (err, xmlData) => {
        if (err) {
          this.emit('error', err);
          return;
        }

        const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
        xmlobjdata = xmlObj;
        resolve(xmlobjdata);
      });
    } catch (error) {
      reject(error);
    }
  });
};
const readXMLDatafromContent = (xmlData, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
      xmlobjdata = xmlObj;
      resolve(xmlobjdata);
    } catch (error) {
      reject(error);
    }
  });
};

const getAllRole = () => {
  return new Promise(resolve => {
    const sql = `select roleid,rolename,roledescription,roleacronym from public.wms_role where isactive = true`;
    query(sql)
      .then(response => {
        resolve({ issuccess: true, data: response });
      })
      .catch(() => {
        resolve({ issuccess: false, data: {} });
      });
  });
};

const getCustomerJournalDetail = data => {
  const { customer, journalAcronym } = data;
  return new Promise((resolve, reject) => {
    const sql = `select a.colorid as colours ,a.softwareid as softwares ,a.languageid as languages ,a.celevelid as  "CELevel",a.printissn as "printISSN" , 
         b.divisionid as division ,b.subdivisionid as "subDivision",b.countryid as country ,b.customerid as  customer,d.duid as "duId",
         a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
         a.journalid as "journalId"
         from pp_mst_journal a  
         JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
         JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
         JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid
         JOIN org_mst_customer e on e.customerid=b.customerid 
         where a.isactive = 1 AND b.isactive = 1
         AND (LOWER(e.customername) = LOWER('${customer}')
         or  LOWER(e.customershortname) = LOWER('${customer}')
         )
        AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;

    console.log(sql, 'sql for getJournalDetail');
    query(sql)
      .then(response => {
        resolve(response);
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};
const getCustomerBookDetail = data => {
  const { customer, journalAcronym } = data;
  return new Promise((resolve, reject) => {
    const sql = `select b.divisionid as division ,b.subdivisionid as "subDivision",b.countryid as country ,b.customerid as  customer,d.duid as "duId", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId" 
         from org_mst_customer_orgmap b 
         JOIN org_mst_customerorg_service_map c on c.custorgmapid = b.custorgmapid
         JOIN org_mst_customerorg_du_map d on d.custorgmapid =  b.custorgmapid
         JOIN org_mst_customer e on e.customerid=b.customerid 
         where  b.isactive = 1
         AND (LOWER(e.customername) = LOWER('${customer}')
         or  LOWER(e.customershortname) = LOWER('${customer}'))`;

    console.log(sql, 'sql for getBookDetail');
    query(sql)
      .then(response => {
        resolve(response);
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};

export const getIdFromName = data => {
  const { value, keyconfig } = data;
  const tblkeys = JSON.parse(woKeyConfig.tableKeyConfig);
  const splitval = tblkeys[0][keyconfig].split(',');
  const tableName = splitval[0];
  const columnName = splitval[1];
  const primaryId = splitval[2];

  return new Promise((resolve, reject) => {
    let sql = ``;
    // SELECT customerid as value, customername as label FROM public.org_mst_customer
    sql = `SELECT ${primaryId} as colval FROM ${tableName} WHERE ${columnName} = '${value}' AND isactive = true`;

    query(sql)
      .then(response => {
        const id = response.length ? response[0].colval : '';
        resolve(id);
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};

export const getAutoemailLogdetails = (req, res) => {
  const sql = 'select * from get_autoemail_log()';
  let resobject = [];
  query(sql)
    .then(response => {
      if (
        response != undefined &&
        response.length > 0 &&
        response[0].j.length != undefined
      ) {
        resobject = response[0].j;
      }
      res.send(resobject);
    })
    .catch(() => {
      res.sen({});
    });
};
/*
const getWorkOrderDetail_Itemcode = async itemcode => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select wo.workorderid,wo.dmsid,dms.dmstype  from wms_workorder as wo
            left join dms_master as dms on dms.dmsid = wo.dmsid and dms.isactive = true
            where wo.isactive = true and itemcode = $1`;
      const articledetails = await query(sql, [itemcode]);
      resolve(articledetails);
    } catch (e) {
      reject(e);
    }
  });
}; */

export const getWfEventDetailsForWo = async (
  itemcode,
  stage,
  stageiterationcount,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select  wo.workorderid,ev.wfeventid,ev.woincomingfileid,stg.stagename,act.activityname 
      from  wms_workorder as wo
      join wms_workflow_eventlog as ev on ev.workorderid = wo.workorderid and ev.stageiterationcount = case when ${stageiterationcount}>1 then ${stageiterationcount}-1 else 1 end 
      join wms_workflowdefinition as wfd on wfd.wfdefid = ev.wfdefid 
      join wms_mst_stage as stg on stg.stageid = wfd.stageid
      join wms_mst_activity as act on act.activityid = wfd.activityid
    where wo.itemcode = $1 and stg.stagename = $2 and trim(act.activityname) = 'Completion Trigger'`;
      const eventdetails = await query(sql, [itemcode, stage]);
      resolve(eventdetails);
    } catch (e) {
      reject(e);
    }
  });
};
export const getworkorderdetail_bystage = async (itemcode, stage) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT distinct wo.workorderid,wo.itemcode, st.stageid, st.stagename, srv.serviceid,srv.servicename,du.duid,du.duname,
      cust.customerid ,cust.customername,winf.woincomingfileid 
      FROM public.wms_workorder AS wo
      JOIN public.wms_workorder_stage AS wos ON wo.workorderid = wos.workorderid
      JOIN public.wms_mst_stage AS st ON st.stageid = wos.wfstageid AND st.isactive = true
      JOIN public.org_mst_customer AS cust ON cust.customerid = wo.customerid AND cust.isactive= true
      JOIN public.wms_mst_service AS srv ON srv.serviceid = wos.serviceid AND srv.isactive = true
      JOIN public.org_mst_customer_orgmap AS orgmap on orgmap.customerid = wo.customerid 
      and orgmap.divisionid = wo.divisionid and orgmap.subdivisionid = wo.subdivisionid and 
      orgmap.countryid = wo.countryid and orgmap.isactive = 1
      join public.org_mst_customerorg_du_map custdu on custdu.custorgmapid = orgmap.custorgmapid
      join public.org_mst_deliveryunit as du on du.duid = custdu.duid and du.isactive = true
      left join public.wms_workorder_incoming wi on wi.woid = wo.workorderid
      left join public.wms_workorder_incomingfiledetails winf on winf.woincomingid = wi.woincomingid
      WHERE wo.itemcode = $1 AND st.stagename = $2`;
      const articledetails = await query(sql, [itemcode, stage]);
      resolve(articledetails);
    } catch (e) {
      reject(e);
    }
  });
};

const isWoCompleted = filenames => {
  return new Promise(async (resolve, reject) => {
    try {
      // const placeholders = Array(filenames.length).fill('filenames').join(',');
      // const sql = `SELECT count(wo.workorderid) FROM public.wms_workorder wo JOIN public.wms_workorder_stage wos ON wo.workorderid = wos.workorderid WHERE wo.itemcode = '${fname}' AND wos.wfstageid = 12 AND wos.status = 'Completed'`;
      const sql = `SELECT count(wo.workorderid) FROM public.wms_workorder wo JOIN public.wms_workorder_stage wos ON wo.workorderid = wos.workorderid WHERE wo.itemcode IN ('${filenames.join(
        "','",
      )}') AND wos.wfstageid = 12 AND wos.status = 'Completed'`;

      const res = await query(sql);

      if (filenames.length == Number(res[0].count)) {
        resolve({ issuccess: true, data: res });
      } else {
        resolve({ issuccess: false, data: res });
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getworkorderwithdoinumber = async (req, res) => {
  const { doinumber } = req.body;
  // console.log(doiarray);

  try {
    const doiarray = JSON.parse(doinumber);

    const sql = `SELECT 
    wo.itemcode,wo.doinumber,wo.status
    FROM public.wms_workorder wo    
    WHERE  wo.doinumber IN ('${doiarray.join("','")}')`;

    const wodata = await query(sql);
    res.send({ data: wodata, issuccess: true });
  } catch (error) {
    res.send({ data: {}, issuccess: false });
  }
};

const updatewocolorprint = async updatedData => {
  return new Promise(async resolve => {
    try {
      // Constructing the CASE statement for the update query

      const caseStatements = updatedData
        .map((data, index) => {
          const { doi, colorinprint } = data;
          return `
          WHEN '${doi}' THEN 
            CASE 
              WHEN otherfield IS NULL THEN jsonb_set('{}'::jsonb, '{colorinprint}', '${colorinprint}', true)::json
              ELSE jsonb_set(otherfield::jsonb, '{colorinprint}', '${colorinprint}', true)::json
            END
        `;
        })
        .join(' ');

      // Extracting the DOI numbers from the updatedData array
      const dois = updatedData.map(data => data.doi);

      // Update query
      const sql = `UPDATE wms_workorder
        SET otherfield = (CASE doinumber ${caseStatements} ELSE otherfield END)
        WHERE doinumber IN ('${dois.join("','")}')`;
      console.log(sql, '');
      // Executing the query
      await query(sql);
      resolve(true);
    } catch (error) {
      // console.error('Error updating data:', error.stack);

      resolve(false);
    }
  });
};

const checkworkorderstatus = async doinumber => {
  // let doiarray = JSON.parse(doinumber)
  const doiarray = doinumber;
  // console.log(doiarray);
  return new Promise(async resolve => {
    const sql = `SELECT 
     COUNT(wo.doinumber) AS alljobstatus
     FROM public.wms_workorder wo    
     WHERE wo.doinumber IN ('${doiarray.join("','")}')`;

    const res = await query(sql);
    if (res != undefined && res.length > 0) {
      if (doinumber.length == Number(res[0].alljobstatus)) {
        const tsql = `update public.wms_workorder set status = 'Completed'
        WHERE doinumber IN ('${doiarray.join("','")}')`;
        await query(tsql);

        resolve({ issuccess: true, data: res });
      } else {
        resolve({ issuccess: false, data: res });
      }
    } else {
      resolve({ issuccess: false, data: [] });
    }
  });
};

export const checkFtpWatcherIdleNotification = async (req, res) => {
  let outputmessage = '';
  try {
    const sql = `select duname,to_char(createdon, 'yyyy-mm-dd hh24:mi:ss') as createdon, difference, case when difference > 6 then true else false end as latehours from 
            (select duname,  max(createdon) as createdon,
            ((extract(epoch from  now() - max(createdon) ) / 60)/60)::numeric(10,2)  as difference
            from public.ftp_audit_wo_creation group by duname
            ) as res`;

    const resdata = await query(sql);

    if (resdata && resdata.length) {
      for (let index = 0; index < resdata.length; index++) {
        const islatehour = resdata[index].latehours;
        if (islatehour) {
          const objparam = {
            customershortname: resdata[index].duname,
            lastcreatedon: resdata[index].createdon,
            hoursdifference: resdata[index].difference,
          };
          const mres = await mailTriggerForWatcherIdle(objparam);
          console.log(mres);
        }
      }
    }
    outputmessage = 'completed';
  } catch (er) {
    console.log(er);
    outputmessage = er.message;
  } finally {
    res.status(200).send({ outputmessate: outputmessage });
  }
};

export const getouprelatedstage = async (p_stepcode, p_model) => {
  return new Promise(async resolve => {
    try {
      //  const formattedStepcodeArray = `{'${p_stepcode.join("','")}'}`;

      const sql = `select res.stageid,st.stagename as stage from (select distinct unnest(relatedstage)  as stageid
      from wms_config_oupstage 
      where stepcode = ANY ($1) AND model = $2
	    ) as res
	    join wms_mst_stage st on st.stageid = res.stageid`;

      const resdata = await query(sql, [p_stepcode, p_model]);
      resolve(resdata);
    } catch (e) {
      resolve({});
    }
  });
};

export const getoupmodeltype = async journal => {
  return new Promise(async resolve => {
    try {
      //  const formattedStepcodeArray = `{'${p_stepcode.join("','")}'}`;

      const sql = `select coalesce(modeltype,'A')as modeltype from pp_mst_journal where journalacronym = $1`;
      const resdata = await query(sql, [journal]);
      const { modeltype } = resdata[0];
      resolve(modeltype);
    } catch (e) {
      resolve({});
    }
  });
};

const articleTAT_OUP = async (workorderid, stage, stagedata) => {
  return new Promise(async resolve => {
    const xmldata = stagedata;

    const stageIds = xmldata.map(item => item.stageid);

    // Convert to JSON format
    // const stageIdsJson = JSON.stringify(stageIds);

    const objparam = {
      workorderid,
      stages: stageIds,
    };

    // need this code
    for (let index = 0; index < xmldata.length; index++) {
      const element = xmldata[index];
      if (element.ScheduledEnd) {
        const wresult = await updatearticleTAT_OUP(
          workorderid,
          element.stageid,
          element.ScheduledEnd,
        );
        console.log(wresult);
      }
    }

    const jsonparam = JSON.stringify(objparam);

    const sql = `select * from articletat_oup('${jsonparam}')`;

    const resdata = await query(sql);

    if (resdata && resdata.length) {
      resolve('success');
    }
  });
};

const updatearticleTAT_OUP = async (workorderid, stageid, enddate) => {
  return new Promise(async resolve => {
    try {
      const sql = `update wms_workorder_stage 
      set revisedenddatetime = '${enddate} 23:59:59'::timestamp(0), 
      plannedenddate = '${enddate} 23:59:59'::timestamp(0)
      where workorderid = ${workorderid} and wfstageid = ${stageid}`;

      await query(sql);

      resolve('success');
    } catch (e) {
      resolve('failed');
    }
  });
};

const updatecelevel_ACS = async (
  workorderid,
  celevel,
  levelEffortProb1,
  levelEffortProb2,
  levelEffortProb3,
  grammarmatch,
) => {
  return new Promise(async resolve => {
    try {
      // let complexityid = '';
      celevel = celevel ?? 0;

      // switch (true) {
      //   case +celevel == 0:
      //     celevel = 2;
      //     complexityid = 3;
      //     break;
      //   case +celevel == 1:
      //     celevel = 3;
      //     complexityid = 6;
      //     break;
      //   case +celevel == 2:
      //     celevel = 4;
      //     complexityid = 4;
      //     break;
      //   default:
      //     console.log('Data page ID does not match current options');
      // }
      const levelqry = ` select celevelid from pp_mst_copyeditinglevel where levelofeffort = ${celevel}`;
      const levelofeffoert = await query(levelqry);

      const bqry = `SELECT omd.itrackduid,mc.customerid, mcom.complexityid
          FROM PUBLIC.wms_workorder ww
          JOIN public.org_mst_customer_orgmap m ON m.divisionid = ww.divisionid 
          AND m.subdivisionid = ww.subdivisionid AND m.countryid = ww.countryid
          AND ww.customerid = m.customerid AND m.isactive = 1
          JOIN public.org_mst_customerorg_du_map as du ON du.custorgmapid = m.custorgmapid
          JOIN public.org_mst_deliveryunit as omd ON omd.duid = du.duid
          LEFT JOIN public.mst_deliveryunit as d ON d.duid = omd.itrackduid
          LEFT JOIN public.org_mst_customer as org ON org.customerid = ww.customerid
          LEFT JOIN public.mst_customer as mc ON mc.customerid = org.itrack_customerid
          LEFT JOIN mst_ce_complexity as mcom ON mcom.customerid = mc.customerid and mcom.duid = omd.itrackduid AND
          ceid = ${levelofeffoert[0].celevelid} :: integer
          WHERE ww.workorderid = ${workorderid}`;
      const bresult = await query(bqry);

      if (bresult) {
        const sql = `UPDATE wms_workorder
SET celevelid = '${levelofeffoert[0].celevelid}',
    complexityid = ${bresult[0].complexityid},
    otherfield = COALESCE(otherfield::jsonb, '{}'::jsonb) 
    || jsonb_build_object(
        'levelEffortProb1', '${levelEffortProb1}'::text,
        'levelEffortProb2', '${levelEffortProb2}'::text,
        'levelEffortProb3', '${levelEffortProb3}'::text,
        'grammarscore', '${grammarmatch}'::text,
        'celevel', '${celevel}'::text
    )
WHERE workorderid = ${workorderid}::bigint;`;
        await query(sql);
      }

      resolve('success');
    } catch (e) {
      resolve('failed');
    }
  });
};

const insert_Additional_WoStage_Oup = async (workorderid, stagedata) => {
  return new Promise(async resolve => {
    try {
      const sql = `select distinct wfstageid from wms_workorder_stage 
      where workorderid = ${workorderid}`;

      let wostagedata = await query(sql);

      const wfstageids = new Set(
        wostagedata.map(stage => parseInt(stage.wfstageid, 10)),
      );

      const missingStageIds = stagedata.filter(
        stage => !wfstageids.has(stage.stageid),
      );
      // .map(stage => stage.stageid);

      const sqry = `SELECT stageid , min(sequence) as seq
      FROM wms_workflowdefinition WHERE wfid = 30 group by stageid
      order by seq`;

      const seqdata = await query(sqry);

      for (let i = 0; i < missingStageIds.length; i++) {
        const mStageid = +missingStageIds[i].stageid;
        const mScheduledEnd = missingStageIds[i].ScheduledEnd;
        const msequence = +seqdata.filter(x => x.stageid == mStageid)[0].seq;

        const insql = `insert into wms_workorder_stage(serviceid,wfstageid,status,workorderid,plannedstartdate,plannedenddate,sequence,revisedenddatetime,stageiterationcount,updatedby) 
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`;
        wostagedata = await query(insql, [
          1,
          mStageid,
          'YTS',
          workorderid,
          new Date(),
          mScheduledEnd,
          msequence,
          mScheduledEnd,
          1,
          'System',
        ]);
        console.log(wostagedata);
      }

      console.log(missingStageIds);

      resolve('success');
    } catch (e) {
      resolve('failed');
    }
  });
};
const updateduedate_wkh = async (
  workorderid,
  customer,
  duid,
  stageid,
  taskduedate,
) => {
  return new Promise(async resolve => {
    try {
      const qry = ` select get_prod_tat_due_date(${customer},
														 ${duid},
                              ${workorderid},
														  ${stageid},
														  '${taskduedate}'
														)::text as duedate `;
      const duedate = await query(qry);
      // old -get_prod_due_date
      if (duedate != undefined && duedate) {
        const dateresult = duedate[0]?.duedate;
        const sql = `UPDATE wms_workorder_stage AS st SET revisedenddatetime = '${dateresult}'::timestamp 
					  where st.workorderid =  ${workorderid} :: bigint and st.wfstageid =  ${stageid}  `;
        await query(sql);
      }

      resolve('success');
    } catch (e) {
      resolve('failed');
    }
  });
};

export const getJournalDetails = async (req, res) => {
  try {
    const { customerid, journalAcronym } = req.body;
    const sql = `select a.colorid as colours ,a.softwareid as softwares ,a.languageid as languages ,a.celevelid as  "CELevel",a.printissn as "printISSN" , 
    b.divisionid as division ,b.subdivisionid as "subDivision",b.countryid as country ,b.customerid as  customer,d.duid as "duId",
    a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
    a.journalid as "journalId"
    from pp_mst_journal a  
    JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
    JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
    JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid
    JOIN org_mst_customer e on e.customerid=b.customerid 
    where a.isactive = 1 AND b.isactive = 1 and b.customerid ='${customerid}'
   AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;
    const out = await query(sql);
    res.status(200).send({ issuccess: true, data: out });
  } catch (error) {
    res.status(400).send({
      issuccess: false,
      message: error.message ? error.message : error,
    });
  }
};

export const getArticleStageDetailByPii = async (req, res) => {
  const { piivalue, stageName } = req.body;
  const sql = `select
               wo.workorderid, wo.itemcode, wostage.status, wostage.stageiterationcount
               from wms_workorder as wo
               LEFT JOIN wms_workorder_stage wostage ON wo.workorderid = wostage.workorderid
               LEFT JOIN wms_mst_stage mststage ON mststage.stageid = wostage.wfstageid
               where wo.isactive = true and wo.otherfield->>'pii' = '${piivalue}' AND mststage.stagename = '${stageName}' ORDER BY wostage.stageiterationcount desc`;
  query(sql)
    .then(response => {
      if (response.length) {
        res.status(200).send({ issuccess: true, data: response[0] });
      } else {
        res.status(200).send({ issuccess: false, data: {} });
      }
    })
    .catch(error => {
      res.status(200).send({ issuccess: false, message: error });
    });
};

export const nWmsStageUpdation1 = async payload => {
  try {
    const {
      itemcode,
      stagename,
      stageid,
      islock,
      activitystatus,
      stageiterationcount,
      duid,
      customerid,
      created_by,
      updated_by,
      activityiteration,
    } = payload;
    let sql;

    const checkSql = `SELECT workorderid FROM public.wms_workorder where itemcode ='${itemcode}'`;
    const ackInfo = await query(checkSql);

    if (!islock) {
      sql = `INSERT INTO public.ewms_stage_updation(
	workorderid, activitystatus, stagename, stageid, stageiterationcount, created_by, created_time, customerid,
	duid, activityiteration,islock)
	VALUES ('${ackInfo[0].workorderid}', '${activitystatus}','${stagename}', ${stageid},${stageiterationcount},
   ${created_by}, CURRENT_TIMESTAMP, ${customerid}, ${duid}, ${activityiteration}, ${islock});`;
    } else if (islock) {
      sql = `UPDATE public.ewms_stage_updation
	SET workorderid='${ackInfo[0].workorderid}', activitystatus='${activitystatus}', stagename='${stagename}',
  stageid= ${stageid}, stageiterationcount=${stageiterationcount},   activityiteration=${activityiteration},
  updated_by='${updated_by}', updated_time=CURRENT_TIMESTAMP, islock= ${islock}
	WHERE workorderid='${ackInfo[0].workorderid}' and stageid= ${stageid} and stageiterationcount=${stageiterationcount}`;
    }

    query(sql)
      .then(response => {
        if (response.length) {
          return {
            status: true,
            message: 'Updated successfully',
          };
        } else {
          return {
            status: false,
            message: 'Updated successfully',
          };
        }
      })
      .catch(error => {
        return {
          status: false,
          message: 'Updation failed',
        };
      });
  } catch (error) {
    console.log(error, 'error');
    return {
      status: false,
      message: 'Updation failed',
    };
  }
};

export const nWmsStageUpdationAPI = async (req, res) => {
  const resp = await nWmsStageUpdation(req.body);

  if (resp.status) {
    res
      .status(200)
      .send({ issuccess: true, data: 'New WMS stage Updation completed' });
  } else {
    res.status(200).send({ issuccess: false, data: 'Failure in updation' });
  }
};

export const nWmsStageUpdation = async payload => {
  const {
    itemcode,
    stagename,
    stageid,
    activitystatus,
    stageiterationcount,
    duid,
    customerid,
    created_by,
    updated_by,
    activityiteration,
  } = payload;

  try {
    const checkSql = `SELECT workorderid FROM public.wms_workorder WHERE itemcode = $1`;
    const ackInfo = await query(checkSql, [itemcode]);
    const islock = payload.islock.toLowerCase() == 'true';
    if (!ackInfo.length) {
      return { status: false, message: 'Workorder not found' };
    }

    const workorderid = ackInfo[0].workorderid;

    if (!islock) {
      const insertSql = `
        INSERT INTO public.ewms_stage_updation (
          workorderid, activitystatus, stagename, stageid,
          stageiterationcount, created_by, created_time,
          customerid, duid, activityiteration, islock
        )
        VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP, $7, $8, $9, $10)
      `;

      await query(insertSql, [
        workorderid,
        activitystatus,
        stagename,
        stageid,
        stageiterationcount,
        created_by,
        customerid,
        duid,
        activityiteration,
        islock,
      ]);
    } else {
      const updateSql = `
        UPDATE public.ewms_stage_updation
        SET activitystatus = $1,
            stagename = $2,
            stageid = $3,
            stageiterationcount = $4,
            activityiteration = $5,
            updated_by = $6,
            updated_time = CURRENT_TIMESTAMP,
            islock = $7
        WHERE workorderid = $8 AND stageid = $3 AND stageiterationcount = $4
      `;

      await query(updateSql, [
        activitystatus,
        stagename,
        stageid,
        stageiterationcount,
        activityiteration,
        updated_by,
        islock,
        workorderid,
      ]);
    }

    return {
      status: true,
      message: 'Updated successfully',
    };
  } catch (error) {
    console.error('Error during stage updation:', error);
    return {
      status: false,
      message: 'Updation failed',
    };
  }
};

export const getMsgStatus = async (req, res) => {
  const { subject } = req.body;
  const sql = `select id, issuccess from tran_emailreader where subject = '${subject}' and issuccess = true`;
  query(sql)
    .then(response => {
      if (response.length) {
        res
          .status(200)
          .send({ issuccess: response[0].issuccess, id: response[0].id });
      } else {
        res.status(200).send({ issuccess: false });
      }
    })
    .catch(error => {
      res.status(200).send({ issuccess: false, message: error });
    });
};

export const getCurrentStageIteration = async (req, res) => {
  const { wfstageid, itemcode } = req.body;
  return new Promise(async resolve => {
    const sql = `  SELECT b.stageid, 'Revised PAP' as stagename ,
    COALESCE((SELECT MAX(stageiterationcount) 
                       FROM wms_workorder_stage a 
                       JOIN wms_mst_stage b ON a.wfstageid = b.stageid  
                       join wms_workorder w on w.workorderid = a.workorderid 
                       WHERE w.itemcode = $1 
                         AND b.stagename = 'Revised PAP'
                         AND a.status = 'Completed'), 1)  as stageiterationcount
   FROM wms_workflow_eventlog a
   JOIN wms_workflowdefinition b on b.wfdefid = a.wfdefid
   join wms_workorder w on w.workorderid = a.workorderid 
   JOIN wms_mst_stage c on c.stageid =  b.stageid  and c.isactive = true
   WHERE w.itemcode = $1 and b.activityid = 21
   AND a.activitystatus = 'Unassigned'	
   AND c.stageid != 10
   ORDER BY a.stageiterationcount DESC, a.activityiterationcount DESC LIMIT 1;`;

    await query(sql, [itemcode])
      .then(response => {
        if (response.length) {
          res.status(200).send({ issuccess: true, data: response });
        } else {
          res.status(200).send({ issuccess: false, data: response });
        }
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

//Cams acknowledge notification start

export const camsAcknowledgeNotification = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _camsAcknowledgeNotification(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _camsAcknowledgeNotification = async payload => {
  const { stagename, issuccess, pii } = payload;
  let data = {
    packagefilename: '',
    customername: '',
    customerid: '',
    duid: '',
    journalcode: '',
    stagename,
    activityname: '',
    remarks: '',
    issuccess,
    modeid: 2,
    messageName: '',
    pii,
    wfdefid: '',
    wfeventid: '',
    statusid: '',
    created_by: 'System',
    workorderid: '',
    status: '',
    userId: '',
    isProduction: false,
    isCustomer: true,
    stage: stagename,
    stageid: '',
  };

  try {
    if (stagename === 'First View') {
      data.messageName = 'Upload to FTP_firstview';
      data.wfdefid = 596;
    } else {
      data.messageName = 'Upload to FTP_revisedfirstview';
      data.wfdefid = 678;
    }

    const sql1 = `
  SELECT DISTINCT ON (itemcode, w.workorderid)
       itemcode, customer.customerid, customer.customername, we.wfeventid,
       journal.journalacronym, w.workorderid, wf.activityid, wf.stageid, wf.wfid,
       we.stageiterationcount, we.actualactivitycount, we.wfeventid,
       l1.duname, l1.duid, we.woincomingfileid, h1.servicename, h1.serviceid, at.activityname,
       we.userid
FROM wms_workorder AS w
JOIN wms_workflow_eventlog AS we ON w.workorderid = we.workorderid
JOIN pp_mst_journal AS journal ON w.journalid = journal.journalid
JOIN org_mst_customer AS customer ON w.customerid = customer.customerid
JOIN wms_workflowdefinition AS wf ON we.wfdefid = wf.wfdefid
JOIN wms_workorder_service AS e1 ON e1.workorderid = w.workorderid
JOIN wms_workflowdefinition AS f1 ON f1.wfid = e1.wfid
JOIN wms_mst_stage AS st ON st.stageid = wf.stageid
JOIN wms_mst_activity AS at ON at.activityid = wf.activityid
JOIN wms_mst_service AS h1 ON h1.serviceid = e1.serviceid
JOIN org_mst_deliveryunit AS l1 ON l1.duid = e1.assignedduid
WHERE otherfield ->> 'pii' ='${pii}'
  AND w.isactive = TRUE
  AND we.wfdefid =${data.wfdefid}
  and we.stageiterationcount =
      (select max(el.stageiterationcount) as stageiterationcount from wms_workflow_eventlog el
       where activitystatus = 'Completed' and  el.workorderid  = we.workorderid and el.wfdefid =${data.wfdefid})
ORDER BY itemcode, w.workorderid, we.wfeventid DESC;
`;

    let woInfo = await query(sql1);

    if (!woInfo || woInfo.length === 0) {
      throw new Error(
        `Workorder info missing, Please contact IWMS administrator pii: ${data.pii} stage : ${stagename} status : ${issuccess}`,
      );
    }

    Object.assign(data, {
      customername: woInfo[0].customername,
      customerId: woInfo[0].customerid,
      wfeventid: woInfo[0].wfeventid,
      journalcode: woInfo[0].journalacronym,
      workorderid: woInfo[0].workorderid,
      stageId: woInfo[0].stageid,
      activityId: woInfo[0].activityid,
      wfId: woInfo[0].wfid,
      stageIterationCount: woInfo[0].stageiterationcount,
      actualActivityCount: woInfo[0].actualactivitycount,
      jobId: woInfo[0].itemcode,
      wfeventId: woInfo[0].wfeventid,
      duname: woInfo[0].duname,
      duId: woInfo[0].duid,
      woincomingfileid: woInfo[0].woincomingfileid,
      servicename: woInfo[0].servicename,
      serviceid: woInfo[0].serviceid,
      activityname: woInfo[0].activityname,
      article: woInfo[0].itemcode,
      userId: woInfo[0].userid,
    });
    console.log(woInfo, 'woInfo');
    const checkSql = `select * from itrack_dispatch_log where workorderid = ${data.workorderid} and 
                      status = 'Acknowledged' and stage='${stagename}' and stageiteration=${data.stageIterationCount}`;
    const ackInfo = await query(checkSql);

    if (ackInfo && ackInfo.length > 0) {
      data.statusid = 200;
      data.remarks = `Job already acknowledged ${data.pii} stage : ${stagename} status : ${issuccess}`;
      await _camsAcknowledgeAuditLog(data);
      data.status = 'Acknowledged';
      await _insertCAMSAcknowledge(data);
      return 'CAMS package already acknowledgement notified successfully!';
    }

    data.statusid = 201;
    data.remarks = `CAMS acknowledge process started after payload construction pii: ${data.pii} stage : ${stagename} status : ${issuccess}`;
    await _camsAcknowledgeAuditLog(data);

    const processVariables = {
      __isSuccess__: { value: data.issuccess, type: 'Boolean' },
    };

    let sql;
    if (data.workorderid) {
      sql = `select processinstanceid from wms_workorder_service where workorderid=${data.workorderid}`;
    }
    console.log(sql);
    const resInfo = await query(sql);

    if (!resInfo || resInfo.length === 0) {
      throw new Error(
        `processInstanceId missing for the pii :  ${data.pii} stage : ${stagename}, Please contact IWMS administrator`,
      );
    }

    //Instance enable based on customer mail acknowledge
    const processInstanceId = resInfo[0].processinstanceid;
    const triggerResult = await triggerMsgEvent(
      processInstanceId,
      data.messageName,
      processVariables,
    );
    console.log(triggerResult, 'triggerResult');

    const sql5 = `select * from wms_workflow_eventlog_details where wfeventid =${data.wfeventid}
                order by 1 desc`;
    let resEvent = await query(sql5);

    await query(
      `update wms_workflow_eventlog_details set usercomments= 'Recreated due to CAMS package mail acknowledgement failed' where wfeventdetailid = ${resEvent[0].wfeventdetailid}`,
    );

    data.remarks = `Camunda response : ${
      triggerResult?.data ? triggerResult.data : 'Success'
    } status : ${triggerResult?.status} pii : ${data.pii} stage : ${stagename}`;
    await _camsAcknowledgeAuditLog(data);

    //Customer dispatch only

    let req = {
      body: data,
    };
    const isItracksAPI = await checkItracksExits(req, 'res');
    let { status } = isItracksAPI;
    if (status && issuccess) {
      data.statusid = 201;
      data.remarks = `Itracks customer dispatch process started pii: ${data.pii} stage : ${stagename}`;
      await _camsAcknowledgeAuditLog(data);

      const iStageId = await getiTracksStageId(req.body);
      const iActivityId = await getiTracksActivityId(req.body);
      data.iStageId = iStageId;
      data.iActivityId = iActivityId;
      data.userid = data.userId;
      data.subjobArray = [];
      const iDuId = await getiTracksDuId(data.duId);
      const iCustomerId = await getiTracksCustomerId(data.customerId);

      const custDespatch = await taskDespatchJournal(
        { ...req.body, iDuId, iCustomerId },
        'customer',
      );

      data.remarks = `iTracks response : ${
        custDespatch?.Result ? custDespatch?.Result : custDespatch
      } status: ${custDespatch?.status} ${data.pii} stage : ${stagename}`;
      await _camsAcknowledgeAuditLog(data);
      console.log(custDespatch, 'custDespatch');
    } else {
      let msg =
        status && !issuccess
          ? 'iTracks customer dispatch skipped due cams mail acknowledge failed'
          : !status && issuccess
          ? 'iTracks customer dispatch skipped due to itracks config disabled'
          : 'iTracks customer dispatch skipped please check the itracks config and cams acknowledge mail';

      data.remarks = `iTracks response : ${msg} status:false pii : ${data.pii} stage : ${stagename}`;
      await _camsAcknowledgeAuditLog(data);
    }

    data.statusid = 200;
    data.remarks = `CAMS acknowledge process completed ${data.pii}, stage : ${stagename}`;
    await _camsAcknowledgeAuditLog(data);
    data.status = 'Acknowledged';
    await _insertCAMSAcknowledge(data);

    return 'CAMS package acknowledgement notified successfully!';
  } catch (error) {
    data.statusid = 400;
    data.remarks = `CAMS acknowledge process failed ${
      data.pii
    } - stage : ${stagename} : ${error?.message ? error?.message : error}`;
    await _camsAcknowledgeAuditLog(data);

    if (data.article && data.workorderid) {
      data.status = 'Failed';
      await _insertCAMSAcknowledge(data);
    } else {
      console.log('Workorder info missing please contact iwms administrator');
    }
    let errorMsg = `${error?.message ? error?.message : error}`;
    throw errorMsg;
  }
};

export const _camsAcknowledgeAuditLog = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      customername,
      journalcode,
      stagename,
      jobId,
      statusid,
      remarks,
      modeid,
      pii,
    } = payload;
    let itemcode = jobId ? jobId : pii;
    const jsonString = JSON.stringify(payload);
    try {
      const sql = `Insert into wms_trnfileinflow_details (customername,journalcode,stagename,articlename,
      emailcontent,statusid,remarks,modeid) values('${customername}','${journalcode}','${stagename}','${itemcode}',
      '${jsonString}',${statusid},'${remarks}',${modeid})`;

      await query(sql);

      resolve(true);
    } catch (error) {
      resolve(false);
    }
  });
};

export const getTotalPageNumForCAMS = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { path, workorderid } = payload;

      const dmsType = await getdmsType(workorderid);
      let file = {};
      switch (dmsType) {
        case 'azure':
          const out = await _download(path);
          file = out.data.path;
          break;
        case 'local':
          const out1 = await _localdownload(path);
          file = out1.data.path;
          break;
        default:
          file =
            config.openKM.base_url +
            config.openKM.uri.viewFile +
            req.body.fileId;
          break;
      }

      console.log(file, 'fileelel');
      const loadingTask = pdfjsLib.getDocument(file);
      let count = 0;
      loadingTask.promise
        .then(async pdf => {
          count = pdf.numPages;
          if (count) {
            resolve(count);
          } else {
            reject('Page count not found');
          }
        })
        .catch(e => {
          reject({ message: e.message ? e.message : e });
        });
    } catch (error) {
      reject(`Get pagecount error ${error}`);
    }
  });
};

//CUP Journal CAMPUS Acknowledgement Integration Start

export const getArticlePII = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _getArticlePII(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _getArticlePII = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { articleName, PII, type } = payload;
      let sql = ``;
      if (type == 'validatePII') {
        sql = `select * from wms_workorder where otherfield ->> 'pii' ='${PII}' and isactive = true and customerid = 8`;
      } else {
        sql = `select otherfield ->> 'pii' as pii,workorderid from wms_workorder where itemcode = '${articleName}' and isactive = true and customerid = 8`;
      }
      const response = await query(sql);

      resolve(response.length ? response : []);
    } catch (error) {
      reject(error);
    }
  });
};

export const sendCampusSignal = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _sendCampusSignal(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _sendCampusSignal = async payload => {
  return new Promise(async (resolve, reject) => {
    let signalName = null;
    try {
      const url = process.env.CAMPUS_BASEURL;
      console.log(url, 'Campus Signal URL');

      const {
        signalPayload,
        payloadType,
        stageName,
        stageIteration,
        flowType,
      } = payload;
      let finalPayload;

      let workorderId = 0;

      if (payload?.workorderId == 0) {
        if (signalPayload?.PII) {
          const getWOQuery = `SELECT workorderid FROM wms_workorder WHERE otherfield ->> 'pii' = $1`;
          const result = await query(getWOQuery, [signalPayload.PII]);
          if (result && result.length > 0) {
            workorderId = result[0].workorderid;
          } else {
            workorderId = 0;
          }
        } else {
          workorderId = 0;
        }
      } else {
        workorderId = payload?.workorderId || 0;
      }

      const dateQuery = `SELECT to_char(current_timestamp AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI:SS')
AS current_ist_time`;
      const dateRes = await query(dateQuery);
      const dateQueryWOT = `SELECT to_char(current_timestamp AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD')
AS current_ist_time`;
      const dateResWOT = await query(dateQueryWOT);

      if (payloadType === 'staticPayload') {
        finalPayload = signalPayload;
        if (signalPayload.dateTime) {
          finalPayload.dateTime = dateRes[0]?.current_ist_time;
        }
        if (signalPayload.metaValue == '') {
          finalPayload.metaValue = dateResWOT[0]?.current_ist_time;
        }
        signalName = signalPayload?.stage || null;
      } else {
        const sql = `
          SELECT
            w.otherfield ->> 'pii' AS pii,
            j.journalacronym,
            fawc.package,
            s.signalname,
            s.signaltype,
            COALESCE (typesetpages,0) as typesetpages,
           s.payload
          FROM wms_workorder w
          JOIN pp_mst_journal j ON j.journalid = w.journalid
            AND j.otherdetails ->> 'isSignal' = 'true'
          LEFT JOIN LATERAL (
            SELECT get_ftp_filename(w.workorderid::int) AS package
          ) AS fawc ON true
          LEFT JOIN mst_stage_signal_map s ON s.stagename = $1 AND (s.package = fawc.package or  s.package = 'NA')
          JOIN wms_mst_stage st on st.stagename = $1
          JOIN wms_workorder_stage wws on wws.wfstageid =  st.stageid and wws.stageiterationcount = $3 and wws.workorderid = w.workorderid
          WHERE w.workorderid = $2 and s.flowtype = '${flowType}'
        `;

        const result = await query(sql, [
          stageName,
          workorderId,
          stageIteration,
        ]);

        if (result && result.length > 0) {
          const row = result[0];
          signalName = row.signalname;
          row.dateTime = dateRes[0]?.current_ist_time;
          row.journalMnemonic = row.journalacronym;
          row.PII = row.pii;
          row.round = Number(stageIteration);
          row.pageCount = Number(row.typesetpages);
          if (payload && payload?.differentTypesetPageCount) {
            row.pageCount = Number(payload?.differentTypesetPage);
          }
          if (
            row?.payload &&
            row?.payload?.metaField == 'retroOAProofReceivedDate'
          ) {
            row.metaValue = dateResWOT[0]?.current_ist_time;
          }
          if (row?.payload && row?.payload?.metaField == 'pageCount') {
            row.metaValue = Number(row.typesetpages);
          }
          if (row?.payload && row?.payload?.metaField == 'subjectCategory') {
            row.metaValue = payload.subjectCategory;
          }
          if (
            (row?.payload &&
              row?.payload?.stage == 'allCorrectionsReceived' &&
              Number(stageIteration) > 1) ||
            (row?.payload &&
              row?.payload?.stage == 'revises' &&
              Number(stageIteration) > 1)
          ) {
            row?.payload && (row.payload.round = '');
          }
          let unformattedPayload = row.payload;
          for (let key in unformattedPayload) {
            if (unformattedPayload[key] === '' && row.hasOwnProperty(key)) {
              unformattedPayload[key] = String(row[key]);
            }
          }
          finalPayload = unformattedPayload;
        } else {
          throw new Error(
            'Campus Workorder payload info missing, please contact iwms admin',
          );
        }
      }

      //Check for duplicate signal
      const checkLogSql = `
       SELECT payload ::json ->>'issue' as pii,* FROM trn_cup_signal_log
        WHERE workorderid = $1 AND stagename = $2 AND stageiteration = $3
       AND signalname = $4 AND status = 'Success'
        AND isactive = true
        AND (payload ::json ->>'PII' = '${finalPayload?.PII}' or payload ::json ->>'issue' = '${finalPayload?.issue}' )
      `;
      const existingSignal = await query(checkLogSql, [
        workorderId,
        stageName,
        stageIteration,
        signalName,
      ]);

      if (existingSignal.length > 0 && signalName != 'sentToTypesetter') {
        console.log(
          'Signal already sent for this stage & iteration. Skipping...',
        );

        //Log duplicate attempt
        const logSql = `
          INSERT INTO trn_cup_signal_log (
            workorderid, stagename, stageiteration, signalname,
            payload, responce, remarks, status, createby
          )
          VALUES ($1, $2, $3, $4, $5, null, $6, $7, $8)
        `;
        await query(logSql, [
          workorderId,
          stageName,
          stageIteration,
          signalName,
          JSON.stringify(finalPayload),
          'Duplicate signal attempt - already sent',
          'Duplicate',
          'System',
        ]);

        return resolve('Signal already sent. Skipped duplicate.');
      }

      //Send signal
      const response = await axios.post(`${url}/send-signal`, finalPayload);

      // const response = {
      //   data: {
      //     message: 'Dummy signal sent successfully!',
      //     payload: finalPayload,
      //     timestamp: new Date().toISOString(),
      //   },
      // };

      console.log(response.data, 'Campus signal response');

      //Log success
      const logSql = `
        INSERT INTO trn_cup_signal_log (
          workorderid, stagename, stageiteration, signalname,
          payload, responce, remarks, status, createby
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      `;
      await query(logSql, [
        workorderId,
        stageName,
        stageIteration,
        signalName,
        JSON.stringify(finalPayload),
        JSON.stringify(response.data),
        'Signal sent successfully',
        'Success',
        'System',
      ]);

      //To update the meta value to main meta xml in blob storage start
      if (
        (finalPayload && finalPayload?.metaField == 'subjectCategory') ||
        (finalPayload && finalPayload?.metaField == 'esuppMaterial')
      ) {
        let xmlPayload = {
          blobPath: `CUP/Journal/PII/${finalPayload.PII}.xml`,
          updates: {},
        };
        //If already exist need to take backup the file
        const retreivedFiles = await _blobExist(xmlPayload.blobPath);

        if (
          Object.keys(retreivedFiles).includes('exist') &&
          retreivedFiles.exist
        ) {
          if (
            payload.subjectCategory &&
            finalPayload?.metaField == 'subjectCategory'
          ) {
            xmlPayload.updates.subjectCategory = payload.subjectCategory;
          }
          if (finalPayload?.metaField == 'esuppMaterial') {
            xmlPayload.updates.supplMaterials = 'Yes';
          }

          const xmlRes = await xmlContentsUpdate(xmlPayload);

          const metaUpdatePayload = {
            payloadType: 'metaData',
            PII: finalPayload.PII,
            payloadMedata: xmlRes,
            isEmail: false,
          };
          const receiveRes = await _receiveCampusSignal(metaUpdatePayload);
          console.log(receiveRes, 'receiveRes');
        }
      }
      //To update the meta value to main meta xml in blob storage end

      resolve('Signal sent successfully!');
    } catch (error) {
      const errorMsg = error?.message || error.toString();
      console.error('Error in _sendCampusSignal:', errorMsg);

      try {
        // Log error
        const logSql = `
          INSERT INTO trn_cup_signal_log (
            workorderid, stagename, stageiteration, signalname,
            payload, responce, remarks, status, createby
          )
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        `;
        await query(logSql, [
          payload.workorderId,
          payload.stageName,
          payload.stageIteration,
          signalName,
          JSON.stringify(payload),
          null,
          errorMsg,
          'Error',
          'System',
        ]);
      } catch (logError) {
        console.error(
          'Failed to log signal error:',
          logError.message || logError,
        );
      }

      reject(errorMsg);
    }
  });
};

//CUP Journal CAMPUS Acknowledgement Integration End

//CUP Journal MetaXML
export const saveMetaUpdateXml = async (req, res) => {
  try {
    const rawXml = req.body; // assuming raw xml is posted directly
    const parsed = await parseStringPromise(rawXml, { explicitArray: false });
    const signal = parsed?.signal;

    const {
      signalType = '',
      journalMnemonic = '',
      PII = '',
      metaField = '',
      metaValue = '',
    } = signal || {};

    const fileName = `metaUpdate_${dayjs().format('YYYYMMDD_HHmmss')}.xml`;
    const filePath = `upload/metaupdate/${fileName}`;

    // Save XML file locally
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, rawXml);

    const dmsType = await getdmsTypeFromPII(PII); // or workorderId if needed
    let blobPath = '';

    switch (dmsType) {
      case 'azure':
        await azureHelper._upload(
          { name: fileName, tempFilePath: filePath },
          '/metaupdate/',
        );
        blobPath = `/metaupdate/${fileName}`;
        break;
      case 'local':
        await localHelper._uploadlocal(
          { name: fileName, tempFilePath: filePath },
          '/metaupdate/',
        );
        blobPath = `/metaupdate/${fileName}`;
        break;
      default:
        blobPath = await checkInFiles(filePath, null, 'metaupdate');
        break;
    }

    // Save to DB
    const insertSQL = `
      INSERT INTO trn_meta_signal_log (
        signaltype, journalmnemonic, pii,
        metafield, metavalue, xml_payload, blobpath, createdby
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `;
    await query(insertSQL, [
      signalType,
      journalMnemonic,
      PII,
      metaField,
      metaValue,
      rawXml,
      blobPath,
      'System',
    ]);

    res
      .status(200)
      .json({ status: true, message: 'MetaUpdate XML saved successfully!' });
  } catch (err) {
    console.error('MetaUpdate XML save failed:', err);
    res
      .status(500)
      .json({ status: false, message: 'Error saving MetaUpdate XML.' });
  }
};

export const receiveCampusSignal = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _receiveCampusSignal(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _receiveCampusSignal = async payload => {
  return new Promise(async (resolve, reject) => {
    const { payloadType, payloadMedata, PII } = payload;
    let isEmail = payload?.isEmail == false ? false : true;
    const campusQuery = `select workorderid,itemcode,wms_workorder.journalid,journalacronym from wms_workorder
    join pp_mst_journal on wms_workorder.journalid = pp_mst_journal.journalid
     where otherfield ->>'pii' ='${PII}'`;
    const response = await query(campusQuery);
    let workorderId =
      response && response.length > 0 ? response[0].workorderid : 0;

    try {
      if (response && response.length > 0 && payloadType == 'retroOAUpdate') {
        //to put audit for retro oa update start

        const logSql = `
      INSERT INTO trn_cup_signal_log (
        workorderid, stagename, stageiteration, signalname,
        payload, responce, remarks, status, createby,pii,signaltype
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    `;
        await query(logSql, [
          workorderId,
          'Retro OA',
          1,
          'Retro Signal',
          JSON.stringify(payloadMedata),
          JSON.stringify(payloadMedata),
          'Retro signal received successfully',
          'Started',
          'System',
          PII,
          'Received',
        ]);

        //to put audit for retro oa update end

        //to write a meta text in blob storage
        const payload = {
          destPath: `prodrepository/cup_journals_7/cup_journals_8/${workorderId}/typesetting_1/retro_oa_128/1/Common/mail/${PII}.txt`,
          content: payloadMedata?.metaValue || 'Meta value not fond',
          contentType: 'text/plain',
        };
        console.log(payload?.destPath, 'destpath');
        const blobRes = await writeRawcontentToBlob(payload);
        console.log(blobRes, 'blobRes');

        //To trigger retro stage
        const stagePayload = {
          itemcode: `${response[0].itemcode}`,
          stageName: 'Retro OA',
          stageIteration: 1,
          PII: PII,
        };
        await signalBasedStageTriggger(stagePayload);
        const logSql1 = `
        INSERT INTO trn_cup_signal_log (
          workorderid, stagename, stageiteration, signalname,
          payload, responce, remarks, status, createby,pii,signaltype
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      `;
        await query(logSql1, [
          workorderId,
          'Retro OA',
          1,
          'Retro Signal',
          JSON.stringify(payloadMedata),
          JSON.stringify(payloadMedata),
          'Retro signal received and process completed',
          'Completed',
          'System',
          PII,
          'Received',
        ]);
      }
      if (payloadType == 'metaData') {
        //To trigger mail and update the metadata for particular workorder

        if (response && response.length > 0) {
          const { workorderid, journalid, journalacronym, itemcode } =
            response[0];
          const sql = `SELECT
'xml_export_' ||
LOWER(LEFT(itemcode, 3)) || '_' ||
 '${PII}' AS formatted_name
FROM
wms_workorder
WHERE
otherfield ->>'pii' = '${PII}'
order by workorderid desc limit 1;`;
          const resName = await query(sql);

          const formattedXml = xmlformat(payloadMedata, {
            indentation: '',
            collapseContent: true,
          });

          //Need to check if already exist need to take backup
          let destinationPath = `prodrepository/cup_journals_7/cup_journals_8/${workorderid}/typesetting_1/incoming_inspection_22/1/Common/updatedmeta/${resName[0].formatted_name}.xml`;
          const woPayload = {
            destPath: destinationPath,
            content: formattedXml,
            contentType: 'application/xml',
          };
          console.log(woPayload?.destPath, 'destpath');
          const blobRes = await writeRawcontentToBlob(woPayload);
          console.log(blobRes, 'blobRes');
          if (blobRes && isEmail) {
            response[0].destinationPath = destinationPath;
            await metaXMLTriggerMail(response[0]);
          }
        }

        //To trigger without mail and update the metadata for common
        const formattedXml = xmlformat(payloadMedata, {
          indentation: '',
          collapseContent: true,
        });

        //If already exist need to take backup the file
        let destinationPath = `CUP/Journal/PII/${PII}.xml`;
        const retreivedFiles = await _blobExist(destinationPath);
        let replacePath = ``;

        try {
          if (
            Object.keys(retreivedFiles).includes('exist') &&
            retreivedFiles.exist
          ) {
            const formattedDateTime = moment(new Date())
              .format('yyyy-MM-DD HH:mm:ss')
              .replace(' ', '_')
              .replace(':', '-')
              .replace(':', '-');
            replacePath =
              `${dirname(destinationPath)}/` +
              `${PII}_${formattedDateTime}.xml`;
            await _copyFileWithoutFormData({
              srcPath: destinationPath,
              destBasePath: `${dirname(destinationPath)}/`,
              name: `${PII}_${formattedDateTime}.xml`,
            });
          }

          const sql2 = `select * from trn_cup_signal_log where pii='${PII}' and signaltype ='Received'`;
          let auditInfo = await query(sql2);

          if (auditInfo && auditInfo.length > 0 && replacePath) {
            const updateSql = `update trn_cup_signal_log set path = '${replacePath}' where logid = ${auditInfo[0].logid}`;
            await query(updateSql);
          }

          const logSql = `
        INSERT INTO trn_cup_signal_log (workorderid,
          stagename, stageiteration, signalname,
          payload, responce, remarks, status, createby,pii,signaltype,path
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      `;
          await query(logSql, [
            workorderId,
            'Meta Signal',
            1,
            'Meta Signal',
            JSON.stringify(payloadMedata),
            JSON.stringify(payloadMedata),
            workorderId == 0 ? 'Package yet to receive' : 'Meta xml received',
            workorderId == 0 ? 'YTR' : 'Received',
            'System',
            PII,
            'Received',
            destinationPath,
          ]);
        } catch (error) {
          console.log(error, 'blob backup rename error');
        }

        const writePayload = {
          destPath: destinationPath,
          content: formattedXml,
          contentType: 'application/xml',
        };

        console.log(writePayload?.destPath, 'destpath');
        const blobRes = await writeRawcontentToBlob(writePayload);
        console.log(blobRes, 'blobRes');
      }
      resolve('Message acknowledged successfully!');
    } catch (error) {
      //Error log
      const logSql = `
      INSERT INTO trn_cup_signal_log (
       workorderid, stagename, stageiteration, signalname,
        payload, responce, remarks, status, createby,pii,signaltype
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    `;
      await query(logSql, [
        workorderId || 0,
        payloadType == 'metaData' ? 'Meta Signal' : 'Retro OA',
        1,
        payloadType == 'metaData' ? 'Meta Signal' : 'Retro Signal',
        JSON.stringify(payloadMedata),
        JSON.stringify(payloadMedata),
        `${payloadType} signal received failed`,
        'Failed',
        'System',
        PII,
        'Received',
      ]);
      reject(error);
    }
  });
};
export const readXmlExport = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _readXmlExport(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _readXmlExport = async payload => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, value, woincomingFileId, type } = payload;
    try {
      const sql = `UPDATE wms_workorder_incomingfiledetails
SET otherdetails = (
  SELECT jsonb_pretty(
    (COALESCE(other_json, '{}'::jsonb) - '${type}') || jsonb_build_object(
      '${type}', to_jsonb(${value}::boolean)
    )
  )::text
  FROM (
    SELECT otherdetails::jsonb AS other_json
  ) AS temp
) where woincomingfileid = ${woincomingFileId}`;

      await query(sql);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const signalBasedStageTriggerAPI = async (req, res) => {
  try {
    const resp = await signalBasedStageTriggger(req.body);
    res.status(200).json({ status: resp.status });
  } catch (error) {
    res.status(200).json({ status: false });
  }
};

export const signalBasedStageTriggger = async payload => {
  return new Promise(async (resolve, reject) => {
    let output;
    try {
      //To trigger send signal start
      const { stageIteration, PII } = payload;
      const sql = `select workorderid from wms_workorder where otherfield ->>'pii'='${PII}'`;
      const resultWO = await query(sql);
      const signalPayload = {
        workorderId: resultWO?.[0]?.workorderid,
        stageName: payload.stageName,
        stageIteration: stageIteration || 1,
        payloadType: 'dynamicPayload',
        flowType: 'ftp',
      };
      const campRes = await _sendCampusSignal(signalPayload);
      console.log(campRes, 'campRes');
      //To trigger send signal end

      const mysql = `SELECT ws.processinstanceid as pinstanceid,wf.woincomingfileid as incomingfileid FROM public.wms_workorder wo join wms_workorder_service ws on
    wo.workorderid = ws.workorderid join wms_workorder_incoming wi on wi.woid = wo.workorderid join
    wms_workorder_incomingfiledetails wf on wf.woincomingid = wi.woincomingid
    where wo.itemcode = '${payload.itemcode}'`;

      const filedataRes = await query(mysql);

      //  const processInstanceId = "44a58cac-1d04-11f0-b925-6045bd735325";
      const processInstanceId = filedataRes[0].pinstanceid;
      const messageName = 'BatchMsg';
      // const fileId = "44305"; // dynamic ID
      const fileId = filedataRes[0].incomingfileid;
      const isGraphic = false;
      let stageName = payload.stageName;
      stageName = stageName.toLowerCase().replace(/\s+/g, '_');

      const stageInfoObj = {
        type: stageName,
        iteration: 1,
        file: {
          id: fileId, // set dynamically
        },
      };

      // Final payload
      const payload2 = {
        processInstanceId,
        messageName,
        processVariables: {
          __stageInfo__: {
            value: JSON.stringify(stageInfoObj),
            type: 'Json',
          },
          __isGraphic__: {
            value: isGraphic,
            type: 'Boolean',
          },
        },
      };

      const camunda_posturi = `${process.env.CAMUNDA_NATIVE_URL}message`;

      if (payload2) {
        //  camunda_posturi = 'http://20.244.47.169:8080/engine-rest/message';
        const resetResponse = await service.post(camunda_posturi, payload2);
        if (resetResponse.status) {
          const script = `
          UPDATE public.wms_workorder_stage
          SET
            status = 'In Process',
            startdatetime = current_timestamp,
            plannedstartdate = current_timestamp,
            plannedenddate= current_timestamp + interval '1 day',
            enddatetime= current_timestamp + interval '1 day',
            ordermaildatetime= current_timestamp,
            revisedenddatetime= current_timestamp + interval '1 day'
          WHERE
            workorderid = (SELECT workorderid FROM public.wms_workorder WHERE itemcode = '${payload.itemcode}')
            AND wfstageid = (SELECT stageid FROM wms_mst_stage WHERE stagename = '${payload.stageName}');
        `;
          const retroStageTrigger = await query(script);
          console.log('retroStageTrigger', retroStageTrigger);

          //res.status(200).json({status: true });
          output = { status: resetResponse.status, data: resetResponse.data };
        } else {
          // res.status(400).json({status: false});
          output = { status: resetResponse.status, data: resetResponse.data };
        }
        console.log(resetResponse, 'after create response');
        resolve(output);
      }
    } catch (error) {
      output = { status: false, data: error.message.toString() };
      reject(output);
    }
  });
};

export const getCAMPUSSignalOptions = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _getCAMPUSSignalOptions(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _getCAMPUSSignalOptions = async payload => {
  return new Promise(async (resolve, reject) => {
    const { type, customerId, journalId } = payload;
    let sql = ``;
    try {
      if (type == 'journalacronym') {
        sql = `SELECT tbl2.journalid as id, tbl2.journalacronym as value , tbl2.journalacronym as label , tbl2.journalname FROM org_mst_customer_orgmap as tbl1
JOIN pp_mst_journal as tbl2 ON tbl2.custorgmapid = tbl1.custorgmapid
WHERE tbl1.customerid=${customerId} AND tbl1.subdivisionid in  (1,9) AND tbl2.isactive = 1 order by tbl2.journalid desc`;
      } else if (type == 'article') {
        sql = `select workorderid as id,itemcode
as value, itemcode 
as label,otherfield ->> 'pii' as pii from wms_workorder where customerid = ${customerId} and isactive =true and journalid =${journalId} order by workorderid desc`;
      } else if (type == 'signalname') {
        sql = `select mapid as id,stagename ||'-'|| signalname as value ,stagename ||'-'|| signalname as label from mst_stage_signal_map order by mapid desc`;
      }
      const result = await query(sql);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const toConstructSignalPayload = async (req, res) => {
  try {
    const { journalMnemonic, PII } = req.body;
    const sql = `select wms_workorder_stage.stageiterationcount from public.wms_workorder_stage 
join wms_workorder on wms_workorder_stage.workorderid = wms_workorder.workorderid
join wms_mst_stage on wms_mst_stage.stageid = wms_workorder_stage.wfstageid
where wms_workorder_stage.workorderid =${req.body.workorderId}  
and wms_mst_stage.stagename='${req.body.stageName.split('-')[0].trim()}'`;
    const item = await query(sql);
    if (item && item.length > 0) {
      const payload = {
        workorderId: req.body.workorderId,
        stageName: req.body.stageName.split('-')[0],
        stageIteration: item[0].stageiterationcount,
        signalName: req.body.stageName.split('-')[1],
      };
      const result = await _toConstructSignalPayload(payload);
      res.status(200).send({ issuccess: true, message: result });
    } else {
      // throw new Error('Stage info missing please complete the corresponding stage');
      const sql1 = `select payload from mst_stage_signal_map  where stagename ='${req.body.stageName
        .split('-')[0]
        .trim()}'
                and signalname ='${req.body.stageName.split('-')[1].trim()}'`;
      let unformPayload = await query(sql1);
      if (unformPayload?.[0]?.payload) {
        const dateQuery = `SELECT to_char(current_timestamp AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI:SS')
        AS current_ist_time`;
        const dateRes = await query(dateQuery);
        const dateQueryWOT = `SELECT to_char(current_timestamp AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD')
        AS current_ist_time`;
        const dateResWOT = await query(dateQueryWOT);

        const payload = unformPayload[0].payload;

        if (payload.PII === '' && PII) {
          payload.PII = PII;
        }

        if (payload.journalMnemonic === '' && journalMnemonic) {
          payload.journalMnemonic = journalMnemonic;
        }

        if (payload.metaValue === '') {
          payload.metaValue = dateResWOT[0]?.current_ist_time;
        }

        if (payload.dateTime === '') {
          payload.dateTime = dateRes[0]?.current_ist_time;
        }
      }

      res
        .status(200)
        .send({ issuccess: true, message: unformPayload?.[0]?.payload || {} });
    }
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _toConstructSignalPayload = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, stageName, stageIteration, signalName } = payload;
      let finalPayload;

      const dateQuery = `SELECT to_char(current_timestamp AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI:SS')
AS current_ist_time`;
      const dateRes = await query(dateQuery);
      const dateQueryWOT = `SELECT to_char(current_timestamp AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD')
AS current_ist_time`;
      const dateResWOT = await query(dateQueryWOT);

      const sql = `
          SELECT
            w.otherfield ->> 'pii' AS pii,
            j.journalacronym,
            fawc.package,
            s.signalname,
            s.signaltype,
            COALESCE (typesetpages,0) as typesetpages,
           s.payload
          FROM wms_workorder w
          JOIN pp_mst_journal j ON j.journalid = w.journalid
            AND j.otherdetails ->> 'isSignal' = 'true'
          LEFT JOIN LATERAL (
            SELECT get_ftp_filename(w.workorderid::int) AS package
          ) AS fawc ON true
          LEFT JOIN mst_stage_signal_map s ON s.stagename = $1 AND (s.package = fawc.package or  s.package = 'NA')
          JOIN wms_mst_stage st on st.stagename = $1
          JOIN wms_workorder_stage wws on wws.wfstageid =  st.stageid and wws.stageiterationcount = $3 and wws.workorderid = w.workorderid
          WHERE w.workorderid = $2 and s.signalname = '${signalName}'
        `;

      const result = await query(sql, [stageName, workorderId, stageIteration]);

      if (result && result.length > 0) {
        const row = result[0];
        row.dateTime = dateRes[0]?.current_ist_time;
        row.journalMnemonic = row.journalacronym;
        row.PII = row.pii;
        row.round = Number(stageIteration);
        row.pageCount = Number(row.typesetpages);
        if (payload && payload?.differentTypesetPageCount) {
          row.pageCount = Number(payload?.differentTypesetPage);
        }
        if (
          row?.payload &&
          row?.payload?.metaField == 'retroOAProofReceivedDate'
        ) {
          row.metaValue = dateResWOT[0]?.current_ist_time;
        }
        if (row?.payload && row?.payload?.metaField == 'pageCount') {
          row.metaValue = Number(row.typesetpages);
        }
        if (row?.payload && row?.payload?.metaField == 'subjectCategory') {
          row.metaValue = payload.subjectCategory || '';
        }
        if (
          (row?.payload &&
            row?.payload?.stage == 'allCorrectionsReceived' &&
            Number(stageIteration) > 1) ||
          (row?.payload &&
            row?.payload?.stage == 'revises' &&
            Number(stageIteration) > 1)
        ) {
          row?.payload && (row.payload.round = '');
        }
        let unformattedPayload = row.payload;
        for (let key in unformattedPayload) {
          if (unformattedPayload[key] === '' && row.hasOwnProperty(key)) {
            unformattedPayload[key] = String(row[key]);
          }
        }
        finalPayload = unformattedPayload;
      } else {
        throw new Error(
          'Campus Workorder payload info missing, please contact iwms admin',
        );
      }
      resolve(finalPayload);
    } catch (error) {
      const errorMsg = error?.message || error.toString();
      console.error('Error in _sendCampusSignal:', errorMsg);
      reject(error);
    }
  });
};

export const metaXMLTriggerMail = async reqData => {
  const { workorderid, journalid, journalacronym, itemcode, destinationPath } =
    reqData;

  return new Promise(async (resolve, reject) => {
    try {
      let toMailArray = [];
      let cmName = '';
      let authorName = '';
      let editorName = '';
      let pmName = '';

      const sql1 = `select notificationconfig,type from wms_notifications where action='campus-email'`;
      const resForConfig = await query(sql1);

      if (
        resForConfig &&
        resForConfig.length > 0 &&
        resForConfig?.[0]?.notificationconfig
      ) {
        const sql = `
        select roles.roleacronym, journal.journalemail, journal.journalacronym,journalcont.name,journalcont.email from pp_mst_journal as journal
              join pp_mst_journal_contacts as journalcont on journalcont.journalid = journal.journalid
            join wms_role as roles on roles.roleid= journalcont.designation :: bigint
              where journal.journalid =${journalid}`;
        console.log('sql', sql);
        const tomailList = await query(sql);

        tomailList.push({
          email: `${journalacronym.toLowerCase()}production@integra.co.in`,
          journalacronym: 'PARENT',
          journalemail: `${journalacronym.toLowerCase()}production@integra.co.in`,
          name: 'Joseph Martin and Coreen McGuire ',
          roleacronym: 'PARENT',
        });

        const woRes = await query(
          `select contactemail,contactname from wms_workorder_contacts where workorderid  =${workorderid} and contactrole='PM'`,
        );
        tomailList.push({
          email: `${woRes[0].contactemail}`,
          journalacronym: 'PM',
          journalemail: `${woRes[0].contactemail}`,
          name: `${woRes[0].contactname}`,
          roleacronym: 'PM',
        });

        console.log(tomailList, 'tomailList');
        ['to', 'cc', 'bcc'].forEach(type => {
          const updatedList = resForConfig[0].notificationconfig[type].flatMap(
            sublist => {
              const matchedEmails = tomailList
                .filter(list => list.roleacronym === sublist)
                .map(list => list.email || list.journalemail)
                .filter(email => email);
              return matchedEmails.length > 0 ? matchedEmails : [sublist];
            },
          );

          resForConfig[0].notificationconfig[type] = [...new Set(updatedList)];
        });

        cmName = tomailList?.filter(list => list?.roleacronym == 'CM')?.[0]
          ?.name;
        editorName = tomailList?.filter(list => list?.roleacronym == 'E')?.[0]
          ?.name;
        authorName = tomailList?.filter(
          list => list?.roleacronym == 'AUTHOR',
        )?.[0]?.name;
        pmName = tomailList?.filter(list => list?.roleacronym == 'PM')?.[0]
          ?.name;

        //Updated meta XML File attachment
        const outFiles = [];
        const fileNames = [];
        const fileName = basename(destinationPath);
        const out = await _download(destinationPath);
        if (out.path != '') {
          outFiles.push(out);
          fileNames.push(fileName);
        }

        // To get pii numnber
        const piiRes = await query(
          `select otherfield ->> 'pii' as pii from wms_workorder where workorderid  =${workorderid}`,
        );
        resForConfig[0].type = 'mail';
        const { type, notificationconfig } = resForConfig[0];
        if (type === 'mail') {
          toMailArray = `;${resForConfig[0].notificationconfig.to
            .toString()
            .split(',')
            .join(';')};`;

          resForConfig[0].notificationconfig.to = '';
          const data = {
            actionType: type,
            ...notificationconfig,
            PII: piiRes[0].pii,
            cmName,
            toMail: toMailArray,
            pmName,
            outFiles: outFiles.length > 0 ? outFiles : '',
            fileNames: fileNames.length > 0 ? fileNames : '',
          };
          emitAction(data);
          resolve('success');
        }
      } else {
        reject('Email notification config missing');
      }
    } catch (error) {
      reject(`'Failed sending email' ${error}`);
    }
  });
};

export const getIsUpdatedCampusXML = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _getIsUpdatedCampusXML(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _getIsUpdatedCampusXML = async payload => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, wfdefId } = payload;
    let sql = ``;
    try {
      sql = `SELECT 
    min(wms_workflow_eventlog_details.timestamp) as timestamp,
    to_char(max(trn_cup_signal_log.createddate), 'DD-MM-YYYY HH24:MI:SS') as createddate,
    CASE 
        WHEN max(trn_cup_signal_log.createddate) > min(wms_workflow_eventlog_details.timestamp) 
        THEN true 
        ELSE false 
    END AS isShow
FROM 
    trn_cup_signal_log  
JOIN 
    wms_workorder 
    ON trn_cup_signal_log.workorderid = wms_workorder.workorderid  
JOIN 
    wms_workflow_eventlog 
    ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid 
JOIN 
    wms_workflow_eventlog_details 
    ON wms_workflow_eventlog.wfeventid = wms_workflow_eventlog_details.wfeventid
WHERE 
    wms_workorder.workorderid = ${workorderId} AND wms_workflow_eventlog.wfdefid = ${wfdefId}
    AND trn_cup_signal_log.stagename ='Meta Signal'
    AND wms_workflow_eventlog_details.operationtype = 'YTS' AND trn_cup_signal_log.signaltype='Received'`;
      const result = await query(sql);
      let obj = {
        isShow: false,
        createddate: '',
      };

      if (result && result.length > 0) {
        obj.isShow = result[0].isshow;
        obj.createddate = result[0].createddate;
      }
      resolve(obj);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateWoContacts = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _updateWoContacts(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _updateWoContacts = async payload => {
  try {
    const { workorderId, newArray } = payload;

    for (let i = 0; i < newArray.length; i++) {
      const data = newArray[i];

      const sql = `
        INSERT INTO wms_workorder_contacts (
          workorderid, contactname, contactemail, contactrole,
          contacttype, isprimary, roleid
        ) VALUES ($1, $2, $3, 'AUTHOR', 'Customer', false, 7)
      `;

      const values = [workorderId, data.author_name, data.author_email];

      await query(sql, values);
    }

    return 'WO contact updated successfully';
  } catch (error) {
    throw error;
  }
};

export const checkPIIValue = async (req, res) => {
  try {
    const { pii, customerid } = req.body;
    if (!pii) {
      return res.status(400).send({ message: 'Invalid or missing PII value.' });
    }
    if (!customerid || isNaN(Number(customerid))) {
      return res
        .status(400)
        .send({ message: 'Invalid or missing customerid.' });
    }

    const sql = `SELECT otherfield->>'pii' as pii,workorderid,itemcode,otherfield
        FROM wms_workorder
        WHERE otherfield->>'pii' ='${pii}' and customerid=${customerid} and isactive = true`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getSignalHistory = async (req, res) => {
  try {
    const payload = req.body;
    const result = await _getSignalHistory(payload);

    res.status(200).send({ issuccess: true, message: result });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({
      issuccess: false,
      message: error?.message ? error?.message : error,
    });
  }
};

export const _getSignalHistory = payload => {
  return new Promise(async (resolve, reject) => {
    const { PII, workorderId } = payload;
    try {
      const sql = `SELECT stagename,createddate,signalname,to_char(createddate, 'DD-MM-YYYY') as formatteddate,signaltype, workorderid, pii,
          CASE 
        WHEN path IS NULL THEN CONCAT('CUP/Journal/PII/', pii, '.xml')
        ELSE path
    END AS finalpath
FROM public.trn_cup_signal_log
WHERE signaltype = 'Sent'
  AND workorderid IS NOT NULL
  AND workorderid =${workorderId}

UNION ALL

SELECT stagename,createddate,signalname, to_char(createddate, 'DD-MM-YYYY') as formatteddate, signaltype, workorderid, pii,
    CASE 
        WHEN path IS NULL THEN CONCAT('CUP/Journal/PII/', pii, '.xml')
        ELSE path
    END AS finalpath
FROM public.trn_cup_signal_log
WHERE signaltype = 'Received'
  AND pii = '${PII}'

ORDER BY createddate asc`;

      const result = await query(sql);

      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
