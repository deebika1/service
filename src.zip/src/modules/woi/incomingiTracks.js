import { query } from '../../database/postgres.js';
import {
  checkProductionDispatchCompleted,
  getWorkflowDefinitions,
  getProductionDispatchActivities,
} from './manualLogisticEntry.js';

export const insertSubjobdetail = async (req, res) => {
  const {
    workorderid,
    chaptername,
    userid,
    mspages,
    estimatedpages,
    imagecount,
    tablecount,
    boxcount,
    equationcount,
    filetypeid,
    // suffixid,
    startpage,
    endpage,
    sequenceno,
    referencecount,
    wordcount,
    customerid,
  } = req.body;

  const returnmsg = {
    message: '',
    issucccess: false,
    subjobid: 0,
  };
  try {
    returnmsg.message =
      'PENDING INSERT WORKORDER , WOSERVICE, BOOKWORKORDERDETAILS, INCOMING , INCOMING FILEDETAILS';

    const qry_subjob = `INSERT INTO public.subjobdetails (
          workorderid, customerid, sequenceno, filetypeid, subjobname, startpage, endpage,
          mspage, referencecount, estimatedpages, imagecount, tablecount, equationcount,
          wordcount, boxcount, created_by
        )
        SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16
        WHERE NOT EXISTS (
          SELECT 1 FROM public.subjobdetails 
          WHERE customerid = $2 AND workorderid = ${workorderid} AND subjobname ILIKE '${chaptername}'
        )
        RETURNING subjobid;
      `;
    const subjobresult = await query(qry_subjob, [
      workorderid,
      customerid,
      sequenceno,
      filetypeid,
      chaptername,
      // suffixid,
      startpage,
      endpage,
      mspages,
      referencecount,
      estimatedpages,
      imagecount,
      tablecount,
      equationcount,
      wordcount,
      boxcount,
      userid,
    ]);

    if (subjobresult != undefined && subjobresult.length > 0) {
      returnmsg.issucccess = true;
      returnmsg.message = 'success';
      returnmsg.subjobid = subjobresult[0].subjobid;
    } else {
      returnmsg.issucccess = false;
      returnmsg.message = 'subjob allready exist';
      returnmsg.subjobid = -1;
    }
    res.status(200).json(returnmsg);
  } catch (error) {
    res.status(400).send({ issucccess: false, message: returnmsg.message });
  }
};

export const updateSubjobdetail = async (req, res) => {
  const returnmsg = {
    message: '',
    issucccess: false,
    subjobid: 0,
  };
  try {
    const {
      workorderid,
      sequenceno,
      filetypeid,
      chaptername,
      // suffixid,
      startpage,
      endpage,
      mspages,
      referencecount,
      estimatedpages,
      imagecount,
      tablecount,
      equationcount,
      wordcount,
      boxcount,
      userid,
      isactive,
      subjobid,
      customerid,
      chapterNo,
    } = req.body;

    const qry_update_subjob = `UPDATE public.subjobdetails
    SET 
      workorderid = $1,
      sequenceno = $2,
      filetypeid = $3,
      subjobname = $4,
      startpage = $5,
      endpage = $6,
      mspage = $7,
      referencecount = $8,
      estimatedpages = $9,
      imagecount = $10,
      tablecount = $11,
      equationcount = $12,
      wordcount = $13,
      boxcount = $14,
      updated_by = $15,
      isactive = $16
    WHERE subjobid = $17
    AND NOT EXISTS (
      SELECT 1 FROM public.subjobdetails 
      WHERE customerid = $18
      AND subjobname ILIKE '${chaptername}'
      AND workorderid = ${workorderid}
      AND subjobid != $17  
    )
    RETURNING subjobid;
  `;

    const updateResult = await query(qry_update_subjob, [
      workorderid,
      sequenceno,
      filetypeid,
      chaptername,
      startpage,
      endpage,
      mspages,
      referencecount,
      estimatedpages,
      imagecount,
      tablecount,
      equationcount,
      wordcount,
      boxcount,
      userid,
      isactive,
      subjobid,
      customerid,
    ]);
    let sql = `select wid.woincomingfileid from public.wms_workorder_incoming  wi
    join public.wms_workorder_incomingfiledetails wid on wid.woincomingid = wi.woincomingid
    where wi.woid = $1 and  lower(wid.filename)=lower($2)`;
    const incomingrow = await query(sql, [workorderid, chapterNo]);
    let updateIncoming = [];
    if (incomingrow?.length > 0) {
      sql = `update wms_workorder_incomingfiledetails set
        filename = $1,mspages = $2 ,estimatedpages =$3 ,imagecount = $4 ,tablecount = $5,boxcount = $6
        ,equationcount = $7,filetypeid = $8
        ,startpage = $9,endpage = $10,wordcount = $11,referencecount = $12
        where woincomingfileid=$13 and  lower(filename)=lower($14) RETURNING woincomingfileid`;
      updateIncoming = await query(sql, [
        chaptername,
        mspages,
        estimatedpages,
        imagecount,
        tablecount,
        boxcount,
        equationcount,
        filetypeid,
        startpage,
        endpage,
        referencecount,
        wordcount,
        incomingrow[0]?.woincomingfileid,
        chapterNo,
      ]);
    }

    if (
      updateResult != undefined &&
      updateResult.length > 0 &&
      ((incomingrow?.length > 0 && updateIncoming.length > 0) ||
        incomingrow?.length === 0)
    ) {
      returnmsg.issucccess = true;
      returnmsg.message = 'success';
      returnmsg.subjobid = updateResult[0].subjobid;
    } else if (updateResult.length === 0) {
      returnmsg.issucccess = false;
      returnmsg.message = 'subjob allready exist';
      returnmsg.subjobid = -1;
    } else {
      returnmsg.issucccess = false;
      returnmsg.message = 'Failed to update the subjob in incoming table';
      returnmsg.subjobid = -1;
    }
    res.status(200).json(returnmsg);
  } catch (error) {
    res.status(400).send({ issucccess: false, message: error.message });
  }
};

export const getSubjobdetail = async (req, res) => {
  try {
    const { workorderid } = req.body;

    const getqry = `select  
	 sub.subjobid,sub.subjobname,sub.workorderid,sub.customerid,omc.customername ,
	 sub.sequenceno,sub.filetypeid,pmf.filetype ,
   --sub.suffixid, ms.suffix ,
   sub.startpage,
	 sub.endpage,sub.mspage,sub.referencecount,sub.estimatedpages,
	 sub.imagecount,sub.tablecount,sub.equationcount,sub.wordcount,
	 sub.boxcount,sub.created_by,sub.created_time,sub.updated_by,
	 sub.updated_time,sub.isactive,
   'action' as action
 from public.subjobdetails as sub
 left join org_mst_customer omc on omc.customerid = sub.customerid and omc.isactive = true
 left join pp_mst_filetype pmf on pmf.filetypeid  = sub.filetypeid 
 where sub.workorderid = $1 and sub.isactive=true order by sub.sequenceno`;

    const updateResult = await query(getqry, [workorderid]);

    res.status(200).json(updateResult);
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const insertBookIncoming = async (req, res) => {
  const returnmsg = {
    message: '',
    issucccess: false,
    subjobid: 0,
    woincomingid: 0,
    woincomingfileid: 0,
  };

  try {
    const {
      bookworkorderid,
      serviceid,
      stageid,
      receiptdate,
      duedate,
      userid,
      filename,
      mspages,
      estimatedpages,
      imagecount,
      tablecount,
      boxcount,
      equationcount,
      filesequence,
      filetypeid,
      startpage,
      endpage,
    } = req.body;
    const qry_incoming = `INSERT INTO public.wms_workorder_incoming ( woid, serviceid, stageid, 
            receiptdate, duedate,  isassigned) 
            VALUES ($1,$2,$3,$4,$5,false) returning woincomingid`;

    const incoming_result = await query(qry_incoming, [
      bookworkorderid,
      serviceid,
      stageid,
      receiptdate,
      duedate,
      userid,
    ]);

    if (incoming_result != undefined && incoming_result[0].woincomingid) {
      const qry_incomingfiledet = `insert into wms_workorder_incomingfiledetails ( 
                woincomingid ,filename 
                ,mspages ,estimatedpages ,imagecount ,tablecount ,boxcount
                ,equationcount ,filesequence ,filetypeid 
                ,
                --suffixid,
                 startpage ,endpage
                )
                VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) returning woincomingfileid`;

      const incomingfiledet_result = await query(qry_incomingfiledet, [
        incoming_result[0].woincomingid,
        filename,
        mspages,
        estimatedpages,
        imagecount,
        tablecount,
        boxcount,
        equationcount,
        filesequence,
        filetypeid,
        // suffixid,
        startpage,
        endpage,
      ]);

      if (
        incomingfiledet_result != undefined &&
        incomingfiledet_result[0].woincomingfileid
      ) {
        returnmsg.issucccess = true;
        returnmsg.message = 'Success';
        returnmsg.woincomingfileid = incomingfiledet_result[0].woincomingfileid;
        returnmsg.woincomingid = incoming_result[0].woincomingid;
      }
    }
  } catch (error) {
    returnmsg.issucccess = false;
    returnmsg.message = error.message;
  } finally {
    if (returnmsg.issucccess == true) {
      res.status(200).json(returnmsg);
    } else {
      res.status(400).send({ issucccess: false, message: returnmsg.message });
    }
  }
};

export const insertSubjobIncoming = async (req, res) => {
  const returnmsg = {
    wostageid: 0,
    incomingid: 0,
    message: '',
    issucccess: false,
  };

  try {
    const {
      stageid,
      workorderid,
      serviceid,
      receiveddate,
      plannedstartdate,
      plannedenddate,
      subjobs,
      userid,
      skill,
      systemInfo,
      wfid,
      iteration,
      duId,
      customerId,
    } = req.body;

    let { wostageid } = req.body;
    let override_insert = false;
    let prev_iterationcompleted = false;
    let previousiteration = 1;

    if (iteration > 1) {
      previousiteration = iteration - 1;
      const qrycheck = `select * from  wms_workorder_stage where workorderid = $1 and wfstageid = $2 and stageiterationcount = $3 and  status = 'Completed' and enddatetime is not null `;
      const result = await query(qrycheck, [
        workorderid,
        stageid,
        previousiteration,
      ]);
      if (result != undefined && result.length > 0) {
        prev_iterationcompleted = true;
      }
    } else {
      prev_iterationcompleted = true;
    }
    const checkuom_productinDispatch = await checkAssignStageValidation(
      workorderid,
      stageid,
      wfid,
      subjobs,
      duId,
      customerId,
      iteration,
    );
    if (checkuom_productinDispatch?.isCheck) {
      if (wostageid != undefined && wostageid == 0) {
        const qry_stageexist = `select * from  wms_workorder_stage where workorderid = $1 and wfstageid = $2 and stageiterationcount = $3`;
        const checkdata = await query(qry_stageexist, [
          workorderid,
          stageid,
          iteration,
        ]);
        if (checkdata != undefined && checkdata.length > 0) {
          const qrywostage = `update wms_workorder_stage set
          receiveddate = $1,
          plannedstartdate = COALESCE($2, plannedstartdate),
          plannedenddate = COALESCE($3, plannedenddate),
          revisedenddatetime = COALESCE($3, revisedenddatetime)
          where wostageid = $4 and stageiterationcount = $5 returning wostageid`;

          await query(qrywostage, [
            receiveddate,
            plannedstartdate,
            plannedenddate,
            checkdata[0].wostageid,
            iteration,
          ]);

          wostageid = checkdata[0].wostageid;
          override_insert = true;
          prev_iterationcompleted = true;
          // } else {
          //   returnmsg.message = checkuom_productinDispatch?.message;
          //   returnmsg.issucccess = checkuom_productinDispatch?.isCheck;
          //   return;
          // }
        } else if (prev_iterationcompleted == false) {
          returnmsg.message = 'Previous stage iteration not completed';
        } else if (prev_iterationcompleted == true) {
          if (checkuom_productinDispatch?.isCheck) {
            const qry_wostage = `insert into wms_workorder_stage (
          workorderid, serviceid,
          wfstageid, status, receiveddate ,
          plannedstartdate,
          plannedenddate,revisedenddatetime,stageiterationcount,ordermaildatetime)
          values ($1, $2, $3, $4, $5, $6, $7, $8,$9,current_timestamp) returning wostageid;`;

            const stage_result = await query(qry_wostage, [
              workorderid,
              serviceid,
              stageid,
              'In Process',
              receiveddate,
              plannedstartdate,
              plannedenddate,
              plannedenddate,
              iteration,
            ]);

            wostageid = stage_result[0].wostageid;
            await createEventlog(
              workorderid,
              wfid,
              stageid,
              iteration,
              skill,
              systemInfo,
              serviceid,
            );
          } else {
            returnmsg.message = checkuom_productinDispatch?.message;
            returnmsg.issucccess = checkuom_productinDispatch?.isCheck;
          }
        }
        if (prev_iterationcompleted == true) {
          if (wostageid > 0) {
            if (override_insert == false) {
              const qry_incoming = `insert into wms_workorder_incoming
                (woid,serviceid,stageid,duedate,receiptdate,receiptdatetime, stageiterationcount)
                values ($1, $2, $3, $4, $5 ::Date, $6, $7) returning woincomingid;`;

              const incoming_result = await query(qry_incoming, [
                workorderid,
                serviceid,
                stageid,
                plannedenddate,
                receiveddate,
                receiveddate,
                iteration,
              ]);
              returnmsg.incomingid = incoming_result[0].woincomingid;
            } else {
              const qryincome = `update wms_workorder_incoming set  
              duedate = $1,
              receiptdate = $2::date,
              receiptdatetime = $3 ,
              updatedby = $6,
              updatedon = current_timestamp
              where woid = $4 and stageid = $5 and stageiterationcount = $7 returning woincomingid`;
              const incomeresult = await query(qryincome, [
                plannedenddate,
                receiveddate,
                receiveddate,
                workorderid,
                stageid,
                userid,
                iteration,
              ]);
              returnmsg.incomingid = incomeresult[0].woincomingid;
            }

            if (returnmsg.incomingid > 0) {
              // let activeSubjob = subjobs.find(subjob => subjob.isactive);

              const activeSubjobs = subjobs
                .filter(subjob => subjob.isactive)
                .map(subjob => subjob.subjobname);

              const qry_incomfile = `insert into wms_workorder_incomingfiledetails(
                  woincomingid,filename ,duedate ,mspages
                ,estimatedpages ,imagecount ,tablecount ,equationcount
                ,boxcount ,referencecount ,wordcount ,filetypeid
                 ,startpage ,endpage ,filesequence ,isactive
                )
                  select
                  $1, subjobname, $2, mspage
                  ,estimatedpages ,imagecount ,tablecount ,equationcount
                  ,boxcount ,referencecount ,wordcount ,filetypeid
                  ,startpage ,endpage ,sequenceno,true
                  from subjobdetails s where workorderid = $3 and subjobname = ANY($4 ::TEXT[])`;

              await query(qry_incomfile, [
                returnmsg.incomingid,
                plannedenddate,
                workorderid,
                activeSubjobs,
              ]);
              if (checkdata.length > 0) {
                // "Update the event log status to 'In Progress' if it is currently marked as 'Completed' when assign the new subjob
                await updateeventlogActivity(
                  workorderid,
                  wfid,
                  stageid,
                  iteration,
                );
              }
              for (const subjob of subjobs) {
                if (subjob.isactive && subjob.subjobid != 0) {
                  const histquery = `Insert into public.subjob_duedate_history (workorderid,stageid,stageiterationcount,plannedstartdate,
                    plannedenddate,revisedenddatetime,subjobname,duedate,created_by)
                    values($1,$2,$3,$4,$5,$6,$7,$8,$9)`;
                  await query(histquery, [
                    workorderid,
                    stageid,
                    iteration,
                    plannedstartdate,
                    plannedenddate,
                    receiveddate,
                    subjob.subjobname,
                    plannedenddate,
                    userid,
                  ]);
                }
              }

              returnmsg.message = 'stage and chapter created successfully';
              returnmsg.issucccess = true;
            } else {
              returnmsg.message = 'workorder incoming insert failed';
            }
          } else {
            returnmsg.message = 'failed in insert stage';
          }
        } else {
          returnmsg.message = 'Previous stage iteration not completed';
        }
      } else {
        const qrywostage = `UPDATE wms_workorder_stage
        SET 
            receiveddate = $1,
            plannedstartdate = COALESCE($2, plannedstartdate),
            plannedenddate = COALESCE($3, plannedenddate),
            revisedenddatetime = COALESCE($3, revisedenddatetime)
        WHERE wostageid = $4
        RETURNING wostageid;`;

        const wostageresult = await query(qrywostage, [
          receiveddate,
          plannedstartdate,
          plannedenddate,
          wostageid,
        ]);

        if (wostageresult.length > 0) {
          const qryincome = `update wms_workorder_incoming set  
         duedate = $1,
         receiptdate = $2::date,
         receiptdatetime = $3 ,
         updatedby = $6,
         updatedon = current_timestamp
         where woid = $4 and stageid = $5 and stageiterationcount = $7 returning woincomingid`;
          const incomeresult = await query(qryincome, [
            plannedenddate,
            receiveddate,
            receiveddate,
            workorderid,
            stageid,
            userid,
            iteration,
          ]);

          if (incomeresult.length > 0) {
            for (const subjob of subjobs) {
              const qrycheck = `select * from wms_workorder_incomingfiledetails where
              woincomingid = $1 and filename = $2`;

              const checkresult = await query(qrycheck, [
                incomeresult[0].woincomingid,
                subjob.subjobname,
              ]);

              if (checkresult && checkresult.length > 0) {
                const qryincomfile = `update wms_workorder_incomingfiledetails set                                
                duedate = $3
                where woincomingid = $1 and filename = $2`;

                const incomingfileresult = await query(qryincomfile, [
                  incomeresult[0].woincomingid,
                  subjob.subjobname,
                  plannedenddate,
                ]);

                console.log(incomingfileresult, 'incomingupdate');

                returnmsg.message = 'updated subjobs in incoming';
                returnmsg.issucccess = true;
              } else {
                const qryincomingfile = `insert into wms_workorder_incomingfiledetails(
                  woincomingid,filename ,duedate ,mspages
                 ,estimatedpages ,imagecount ,tablecount ,equationcount
                 ,boxcount ,referencecount ,wordcount ,filetypeid ,startpage ,endpage ,filesequence ,isactive
                 )
                  select
                  $1, subjobname, $2, mspage
                  ,estimatedpages ,imagecount ,tablecount ,equationcount
                  ,boxcount ,referencecount ,wordcount ,filetypeid
                  ,startpage ,endpage ,sequenceno,true
                  from subjobdetails s where workorderid = $3 and subjobname = $4`;

                const incomingfileresult = await query(qryincomingfile, [
                  incomeresult[0].woincomingid,
                  plannedenddate,
                  workorderid,
                  subjob.subjobname,
                ]);
                if (subjob.subjobid != 0) {
                  const histquery = `Insert into public.subjob_duedate_history (workorderid,stageid,stageiterationcount,plannedstartdate,
                  plannedenddate,revisedenddatetime,subjobname,duedate,created_by)
                  values($1,$2,$3,$4,$5,$6,$7,$8,$9)`;
                  await query(histquery, [
                    workorderid,
                    stageid,
                    iteration,
                    plannedstartdate,
                    plannedenddate,
                    receiveddate,
                    subjob.subjobname,
                    plannedenddate,
                    userid,
                  ]);
                }
                console.log(incomingfileresult, 'incomingfileresult');
                returnmsg.message = 'created new subjobs in incoming';
                returnmsg.issucccess = true;
              }
            }
            // "Update the event log status to 'In Progress' if it is currently marked as 'Completed' when assign the new subjob
            await updateeventlogActivity(
              workorderid,
              wfid,
              stageid,
              iteration,
              subjobs,
            );
          } else {
            returnmsg.message = 'update incoming table failed';
          }
        } else {
          returnmsg.message = 'update stage table failed';
        }
      }
    } else {
      returnmsg.message = checkuom_productinDispatch?.message;
      returnmsg.issucccess = checkuom_productinDispatch?.isCheck;
    }
  } catch (error) {
    returnmsg.message = error.message;
    returnmsg.issucccess = false;
  } finally {
    if (returnmsg.issucccess) {
      res.status(200).json(returnmsg);
    } else {
      res.status(400).json(returnmsg);
    }
  }
};
export const createEventlog = async (
  woId,
  wfId,
  stageId,
  iteration,
  skill,
  systemInfo,
  serviceid,
) => {
  try {
    let script =
      'select * from public.wms_workflowdefinition where wfid=$1 and stageid=$2  order by sequence';
    const defid = await query(script, [wfId, stageId]);
    if (defid.length > 0) {
      script = `INSERT INTO public.wms_workflow_eventlog (workorderid , wfdefid, activitystatus,serviceid,stageiterationcount,skillid,activityiterationcount)
    VALUES ($1, $2,$3,$4,$5,$6,$7)`;
      await Promise.all(
        defid.map(async id => {
          const status = 'Unassigned';
          return query(script, [
            woId,
            id?.wfdefid,
            status,
            serviceid,
            iteration,
            id?.skillid,
            1,
          ]);
        }),
      );
    } else {
      throw new Error('Failed to insert event log entry');
    }
  } catch (e) {
    throw new Error('Failed to insert event log entry');
  }
};

/*    if (chapter_result != undefined) {
        returnmsg.message = 'PENDING INSERT INCOMING AND INCOMING FILEDETAILS';

        const qry_incoming = `INSERT INTO public.wms_workorder_incoming ( woid, serviceid, stageid, 
                    receiptdate, duedate, updatedby,  updatedon,  isassigned) 
                    VALUES ($1,$2,$3,$4,$5,$6,current_timestamp,false) returning woincomingid`;

        const incoming_result = await query(qry_incoming, [
          subjobworkorderid,
          serviceid,
          stageid,
          receiptdate,
          duedate,
          userid,
        ]);

        if (incoming_result != undefined && incoming_result[0].woincomingid) {
          returnmsg.message = 'PENDING INCOMING FILEDETAILS';

          const qry_incomingfiledet = `insert into wms_workorder_incomingfiledetails ( 
                         woincomingid ,filename 
                        ,mspages ,estimatedpages ,imagecount ,tablecount ,boxcount
                        ,equationcount ,filesequence ,filetypeid 
                        ,suffixid, startpage ,endpage
                        )
                        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) returning woincomingfileid`;

          const incomingfiledet_result = await query(qry_incomingfiledet, [
            incoming_result[0].woincomingid,
            filename,
            mspages,
            estimatedpages,
            imagecount,
            tablecount,
            boxcount,
            equationcount,
            filesequence,
            filetypeid,
            suffixid,
            startpage,
            endpage,
          ]);

          if (
            incomingfiledet_result != undefined &&
            incomingfiledet_result[0].woincomingfileid
          ) {
            returnmsg.issucccess = true;
            returnmsg.message = 'Success';
            returnmsg.subjobid = subjobworkorderid;
            returnmsg.woincomingfileid =
              incomingfiledet_result[0].woincomingfileid;
            returnmsg.woincomingid = incoming_result[0].woincomingid;
          }
        } else {
          returnmsg.message = 'FAILED ON INSERTIN IN INCOMING TABLE';
        }
      } else {
        returnmsg.message = 'FAILED ON MAPPING IN BOOK WORKORDER TABLE';
      }
    } else {
      returnmsg.message = 'FAILED ON INSERT SUBJOB IN WORKORDER TABLE';
    }
*/

export const getDropdown = async (req, res) => {
  const returnmsg = {
    message: '',
    issucccess: false,
    data: [],
  };
  try {
    let sql = '';
    switch (req.params.type) {
      case 'type':
        sql = `select filetypeid as value,filetype as label from pp_mst_filetype pmf
      where subdivisionid = $1`;
        break;
      default:
        throw new Error('Invalid Param');
    }
    const result = await query(sql, [req.params.subdivionid]);
    returnmsg.issucccess = true;
    returnmsg.data = result;
  } catch (error) {
    returnmsg.issucccess = false;
    returnmsg.message = error.message;
  } finally {
    if (returnmsg.issucccess == true) {
      res.status(200).json(returnmsg.data);
    } else {
      res.status(400).send({ issucccess: false, message: returnmsg.message });
    }
  }
};

export const checkStageExist = async (req, res) => {
  const returnmsg = {
    message: '',
    issucccess: false,
    data: [],
  };
  try {
    const { workorderid, stageid, iteration } = req.body;
    const sql = `select TO_CHAR(plannedstartdate, 'YYYY-MM-DD HH24:mi') AS plannedstartdate,
    TO_CHAR(receiveddate, 'YYYY-MM-DD HH24:mi') AS receiveddate from wms_workorder_stage where workorderid = $1 AND wfstageid = $2
    AND stageiterationcount = $3;`;
    const result = await query(sql, [workorderid, stageid, iteration]);
    returnmsg.issucccess = true;
    returnmsg.data = result;
  } catch (error) {
    returnmsg.issucccess = false;
    returnmsg.message = error.message;
  } finally {
    if (returnmsg.issucccess == true) {
      res.status(200).json(returnmsg.data);
    } else {
      res.status(400).send({ issucccess: false, message: returnmsg.message });
    }
  }
};

export const getAssignStage = async (req, res) => {
  const returnmsg = {
    message: '',
    issucccess: false,
    data: [],
  };
  try {
    const { workorderid, type } = req.body;
    const dynamicCondition =
      type === 'duedate' ? 'and wid.duedate is null' : '';
    const sql = `select  ROW_NUMBER() OVER (ORDER BY ws.plannedstartdate desc) AS serial,
    ws.workorderid,ws.wfstageid,ws.serviceid, wid.filesequence as sequence,
    TO_CHAR(ws.plannedstartdate, 'YYYY-MM-DD HH24:mi') AS plannedstartdate,
    TO_CHAR(ws.receiveddate, 'YYYY-MM-DD HH24:mi') AS receiveddate,
    TO_CHAR(ws.ordermaildatetime + interval '330 minutes','YYYY-MM-DD HH24:mi') AS createddate,
    TO_CHAR (wid.duedate ,'YYYY-MM-DD HH24:mi') AS plannedenddate,win.woincomingid,ws.stageiterationcount,
    wid.filename as subjob,s.stagename,ws.wostageid,'action' as action,
    case 
    when ws.status = 'YTS' then 'YET TO START'
    when ws.status = 'In Process' then 'WIP'
    else ws.status end as status,
    lower(ws.status) as statusclass
    from public.wms_workorder_stage ws 
     join public.wms_mst_stage s on s.stageid = ws.wfstageid and s.isactive = true
     join public.wms_workorder_incoming win on win.woid = ws.workorderid and win.stageid = ws.wfstageid and win.stageiterationcount = ws.stageiterationcount
     join public.wms_workorder_incomingfiledetails wid on wid.woincomingid = win.woincomingid and wid.isactive=true ${dynamicCondition}
    where ws.workorderid=$1`;
    const result = await query(sql, [workorderid]);
    returnmsg.issucccess = true;
    returnmsg.data = result;
  } catch (error) {
    returnmsg.issucccess = false;
    returnmsg.message = error.message;
  } finally {
    if (returnmsg.issucccess == true) {
      res.status(200).json(returnmsg.data);
    } else {
      res.status(400).send({ issucccess: false, message: returnmsg.message });
    }
  }
};

export const updateStageDuedate = async (req, res) => {
  const returnmsg = {
    wostageid: 0,
    incomingid: 0,
    message: '',
    issucccess: false,
  };

  try {
    const { tableData, plannedStartDate, dueDate, wfId, userId } = req.body;

    const workflowDefinitions = await getWorkflowDefinitions(
      wfId,
      tableData[0]?.wfstageid,
    );
    const proDispatches = getProductionDispatchActivities(workflowDefinitions);
    let isProductionCompleted = false;
    if (proDispatches.length) {
      isProductionCompleted = await checkProductionDispatchCompleted(
        tableData[0]?.workorderid,
        tableData[0]?.wfstageid,
        proDispatches[0]?.wfdefid,
        tableData[0]?.stageiterationcount,
      );

      if (isProductionCompleted) {
        returnmsg.message =
          'Production dispatch has been completed. Updates are no longer allowed.';
        returnmsg.issucccess = false;
      }
    }

    if (!isProductionCompleted) {
      const qrywostage = `update wms_workorder_stage set
          plannedstartdate = $4,
          plannedenddate = $5,
          revisedenddatetime = $5
          where workorderid=$1 and wostageid = $2 and stageiterationcount = $3 returning wostageid`;

      const result = await query(qrywostage, [
        tableData[0]?.workorderid,
        tableData[0]?.wostageid,
        tableData[0]?.stageiterationcount,
        plannedStartDate,
        dueDate,
      ]);

      if (result.length && result[0]?.wostageid) {
        for (const data of tableData) {
          const qryInc = `update wms_workorder_incomingfiledetails set duedate=$3
            where woincomingid=$1 and filename=$2 returning woincomingfileid`;
          const incres = await query(qryInc, [
            data?.woincomingid,
            data?.subjob,
            dueDate,
          ]);
          if (incres.length && incres[0]?.woincomingfileid) {
            const histquery = `Insert into public.subjob_duedate_history (workorderid,stageid,stageiterationcount,plannedstartdate,
                  plannedenddate,revisedenddatetime,subjobname,duedate,created_by)
                  values($1,$2,$3,$4,$5,$6,$7,$8,$9)`;
            await query(histquery, [
              tableData[0]?.workorderid,
              tableData[0]?.wfstageid,
              tableData[0]?.stageiterationcount,
              plannedStartDate,
              dueDate,
              dueDate,
              data?.subjob,
              dueDate,
              userId,
            ]);

            returnmsg.message = 'Due date updated successfully';
            returnmsg.issucccess = true;
          } else {
            returnmsg.message =
              'Failed to update the duedate in incoming details table';
            returnmsg.issucccess = false;
          }
        }
      } else {
        returnmsg.message = 'Failed to update the duedate in stage';
        returnmsg.issucccess = false;
      }
    }
  } catch (error) {
    returnmsg.message = error.message;
    returnmsg.issucccess = false;
  } finally {
    if (returnmsg.issucccess) {
      res.status(200).json(returnmsg);
    } else {
      res.status(400).json(returnmsg);
    }
  }
};

const checkUomUnit = async (woId, wfId, stageId, subjob, duId, customerId) => {
  const sql = `
    SELECT 
      df.activityalias,
      sb.subjobname,
      CASE 
        WHEN uom IN ('article', 'titles') THEN 100
        WHEN uom = 'ms pages' THEN sb.mspage
       WHEN uom IN ('std. pages', 'word count') THEN sb.wordcount
       WHEN uom = 'images' THEN sb.imagecount
        WHEN uom IN ('pdf pages', 'no. of pages') THEN sb.estimatedpages
        ELSE null
      END AS uomvalue,
      uom AS uomname
    FROM (
      SELECT 
        df.activityalias, 
        LOWER(COALESCE(df.itracksconfig->>'uom_unit', '')) AS uom
      FROM public.wms_workflowdefinition df
      WHERE df.wfid = $2 AND df.stageid = $3 AND df.itracksconfig IS NOT NULL
    ) df
    LEFT JOIN public.subjobdetails sb 
      ON sb.workorderid = $1 AND sb.subjobname IN (${subjob});
  `;

  const uomCheck = await query(sql, [woId, wfId, stageId]);

  if (!uomCheck.length) {
    return {
      message: 'No Activities in Workflow definition for this stage',
      isCheck: false,
    };
  }

  const uomNotMap = uomCheck.filter(
    item => !item.uomname && item.uomvalue === null,
  );
  if (uomNotMap.length) {
    // const activityNames = uomNotMap
    //   .map((item, index) => `${index + 1}. ${item.activityalias}`)
    //   .join('\n');
    const activityNames = Array.from(
      new Set(uomNotMap.map(item => item.activityalias)),
    )
      .map((activityalias, index) => `${index + 1}. ${activityalias}`)
      .join('\n');
    return {
      message: `The activity doesn't have the UOM. Please map the UOM for the below-mentioned activities in the workflow list screen:\n${activityNames}`,
      isCheck: false,
    };
  }

  const uomValueNotUpdate = uomCheck.filter(
    item => item.uomname && item.uomvalue === null,
  );
  if (uomValueNotUpdate.length) {
    // Group uomname by subjobname
    const groupedSubjobs = uomValueNotUpdate.reduce((acc, item) => {
      if (!acc[item.subjobname]) {
        acc[item.subjobname] = [];
      }
      acc[item.subjobname].push(item.uomname);
      return acc;
    }, {});

    // Generate the message with grouped uomnames
    const subjobNames = Object.entries(groupedSubjobs)
      .map(
        ([subjobname, uomnames], index) =>
          `${
            index + 1
          }. SubjobName: ${subjobname}, Estimated Fields: ${uomnames.join(
            ', ',
          )}`,
      )
      .join('\n');

    return {
      message: `The following subjob UOMs are not added. Please update the estimated values on the incoming subjob screen:\n${subjobNames}`,
      isCheck: false,
    };
  }

  const stdPageVal = uomCheck.filter(item => item.uomname === 'std. pages');
  if (stdPageVal.length) {
    const stdPageSql = `
      SELECT msm.wordcount_per_page
      FROM public.org_mst_customer omc
      JOIN public.org_mst_deliveryunit odu ON odu.duid = $2
      JOIN public.mst_standardpage_measure msm 
        ON msm.customerid = omc.itrack_customerid AND msm.duid = odu.itrackduid
      WHERE omc.customerid = $1;
    `;
    const stdPageResult = await query(stdPageSql, [customerId, duId]);

    if (!stdPageResult.length) {
      return {
        message: 'No word count per page found in mst_standardpage_measure.',
        isCheck: false,
      };
    }

    const stdValue = Number(stdPageResult[0]?.wordcount_per_page);
    const uniqueSubjobs = Object.values(
      stdPageVal.reduce((acc, item) => {
        if (!acc[item.subjobname]) {
          acc[item.subjobname] = item; // Take the first occurrence
        }
        return acc;
      }, {}),
    );
    const uomValueless = uniqueSubjobs.filter(
      item => Number(item.uomvalue) < stdValue,
    );

    if (uomValueless.length) {
      const stdNames = uomValueless
        .map((item, index) => `${index + 1}.${item.subjobname}`)
        .join('\n');
      return {
        message: `The word count for the following subjobs is less than the mapped standard page value. Please update the word count on the incoming subjob screen:\n${stdNames}`,
        isCheck: false,
      };
    }
  }

  return { message: 'UOMs are mapped', isCheck: true };
};

const checkAssignStageValidation = async (
  workorderid,
  stageid,
  wfId,
  subjob,
  duId,
  customerId,
  iteration,
) => {
  try {
    const workflowDefinitions = await getWorkflowDefinitions(wfId, stageid);
    const proDispatches = getProductionDispatchActivities(workflowDefinitions);

    if (proDispatches.length) {
      const isProductionCompleted = await checkProductionDispatchCompleted(
        workorderid,
        stageid,
        proDispatches[0]?.wfdefid,
        iteration,
      );

      if (isProductionCompleted) {
        return {
          message:
            'Production dispatch is completed. Assigning a new subjob is not allowed.',
          isCheck: false,
        };
      }
    }
    const subjobNames = subjob
      .filter(item => item.subjobid !== '0' && item.isactive)
      .map(item => `'${item.subjobname}'`)
      .join(',');

    if (subjobNames.length > 0) {
      return await checkUomUnit(
        workorderid,
        wfId,
        stageid,
        subjobNames,
        duId,
        customerId,
      );
    }

    return { message: 'Can assign the stage', isCheck: true };
  } catch (error) {
    console.error('Error in production dispatch update:', error);
    throw new Error('Failed to update production dispatch.');
  }
};

export const stageCreationForIntegration = async (req, res) => {
  const returnmsg = {
    wostageid: 0,
    incomingid: 0,
    message: '',
    issucccess: false,
  };

  try {
    const {
      stageid,
      workorderid,
      serviceid,
      receiveddate,
      plannedstartdate,
      plannedenddate,
      iteration,
    } = req.body;

    let { wostageid } = req.body;
    if (wostageid != undefined && wostageid == 0) {
      const qry_wostage = `insert into wms_workorder_stage (
          workorderid, serviceid,
          wfstageid, status, receiveddate ,
          plannedstartdate,
          plannedenddate,revisedenddatetime,stageiterationcount,ordermaildatetime)
          values ($1, $2, $3, $4, $5, $6, $7, $8,$9,current_timestamp) returning wostageid;`;

      const stage_result = await query(qry_wostage, [
        workorderid,
        serviceid,
        stageid,
        'In Process',
        receiveddate,
        plannedstartdate,
        plannedenddate,
        plannedenddate,
        iteration,
      ]);

      wostageid = stage_result[0].wostageid;
      // await createEventlog(
      //   workorderid,
      //   wfid,
      //   stageid,
      //   iteration,
      //   skill,
      //   systemInfo,
      //   serviceid,
      // );
    }
    if (wostageid > 0) {
      const qry_incoming = `insert into wms_workorder_incoming
                (woid,serviceid,stageid,duedate,receiptdate,receiptdatetime, stageiterationcount)
                values ($1, $2, $3, $4, $5 ::Date, $6, $7) returning woincomingid;`;

      const incoming_result = await query(qry_incoming, [
        workorderid,
        serviceid,
        stageid,
        plannedenddate,
        receiveddate,
        receiveddate,
        iteration,
      ]);
      returnmsg.incomingid = incoming_result[0].woincomingid;
      if (returnmsg.incomingid > 0) {
        // create subjob master entry
        //   const qry_subjob = `INSERT INTO public.subjobdetails (
        //     workorderid, customerid, sequenceno, filetypeid, subjobname, startpage, endpage,
        //     mspage, referencecount, estimatedpages, imagecount, tablecount, equationcount,
        //     wordcount, boxcount, created_by
        //   )
        //   SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16
        //   WHERE NOT EXISTS (
        //     SELECT 1 FROM public.subjobdetails
        //     WHERE customerid = $2 AND workorderid = ${workorderid} AND subjobname ILIKE '${chaptername}'
        //   )
        //   RETURNING subjobid;
        // `;
        //   const subjobresult = await query(qry_subjob, [
        //     workorderid,
        //     customerid,
        //     sequenceno,
        //     filetypeid,
        //     chaptername,
        //     // suffixid,
        //     startpage,
        //     endpage,
        //     mspages,
        //     referencecount,
        //     estimatedpages,
        //     imagecount,
        //     tablecount,
        //     equationcount,
        //     wordcount,
        //     boxcount,
        //     userid,
        //   ]);
        const subjobid = '';
        const qry_incomfile = `insert into wms_workorder_incomingfiledetails(
                  woincomingid,filename ,duedate ,mspages
                ,estimatedpages ,imagecount ,tablecount ,equationcount
                ,boxcount ,referencecount ,wordcount ,filetypeid
                 ,startpage ,endpage ,filesequence ,isactive
                )
                  select
                  $1, subjobname, $2, mspage
                  ,estimatedpages ,imagecount ,tablecount ,equationcount
                  ,boxcount ,referencecount ,wordcount ,filetypeid
                  ,startpage ,endpage ,sequenceno,true
                  from subjobdetails s where workorderid = $3 and subjobid = $4`;

        await query(qry_incomfile, [
          returnmsg.incomingid,
          plannedenddate,
          workorderid,
          subjobid,
        ]);
        returnmsg.message = 'stage created successfully';
        returnmsg.issucccess = true;
      } else {
        returnmsg.message = 'workorder incoming insert failed';
      }
    } else {
      returnmsg.message = 'failed in insert stage';
    }
  } catch (error) {
    returnmsg.message = error.message;
    returnmsg.issucccess = false;
  } finally {
    if (returnmsg.issucccess) {
      res.status(200).json(returnmsg);
    } else {
      res.status(400).json(returnmsg);
    }
  }
};

export const updateeventlogActivity = async (
  woId,
  wfId,
  stageId,
  iteration,
) => {
  try {
    let script =
      'select * from public.wms_workflowdefinition where wfid=$1 and stageid=$2  order by sequence';
    const defid = await query(script, [wfId, stageId]);
    if (defid.length > 0) {
      script = `update wms_workflow_eventlog set activitystatus = 'Work in progress' where workorderid = $1 and wfdefid = $2 
      and activitystatus = 'Completed' and stageiterationcount = $3 and activitystatus = 'Completed' returning wfeventid`;
      const removeclaim = `delete from  subjob_claimed_user where workorderid=$1 AND
      stageid=$2 and activityid=$3 and stageiterationcount = $4`;
      // for all chapter
      // const subjobupdate = `update public.subjob_eventlog_details set
      // status = 'Work in progress',
      // updated_time = current_timestamp,
      // assigneduserid = ''
      // where
      // workorderid = $1 and
      // stageid = $2 and
      // stageiterationcount = $3
      // returning subjobid`;
      await Promise.all(
        defid.map(async id => {
          if (id?.instancetype != 'Multiple') {
            const updateres = query(script, [woId, id?.wfdefid, iteration]);
            // remove the data from the claimed user table
            if (updateres && updateres?.length)
              query(removeclaim, [woId, stageId, id?.activityid, iteration]);
            // for all chapter
            // query(subjobupdate, [
            //   woId,
            //   stageId,
            //   iteration
            // ]);
          }
        }),
      );
    } else {
      throw new Error('Failed to update event log entry');
    }
  } catch (e) {
    throw new Error('Failed to update event log entry');
  }
};
