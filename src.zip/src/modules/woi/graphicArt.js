import { query, transaction } from '../../database/postgres.js';
import { Service } from '../../httpClient/index.js';
import {
  _getStageInfoFromCamunda,
  _updateStageInfoToCamunda,
  _updateActivityStageInfoToCamunda,
} from '../bpmn/listener/create.js';

const service = new Service();
// import { NULL } from 'json-validator';
// import { resolve } from 'path';

export const graphicArt = async (req, res) => {
  const { stageid, fileuuid, filepath, userid, updatedon, type, wostagegacid } =
    req.body;
  try {
    await transaction(async client => {
      if (type === 'insert') {
        let sql = `INSERT INTO public.wms_workorder_stage_graphicartcut(
            wostageid, graphicartcutfileuuid, graphicartcutfilepath, updatedby, updatedon)
            VALUES ($1,$2,$3,$4,$5) RETURNING * ;`;
        const { rows: resForEntry } = await client.query(sql, [
          stageid,
          fileuuid,
          filepath,
          userid,
          updatedon,
        ]);

        sql = `INSERT INTO wms_workorder_stage_graphicartcut_audit( wostagegacid,graphicartcutfileuuid, graphicartcutfilepath, updatedby,updatedon) VALUES ($1, $2, $3, $4,$5) RETURNING wostagegacid;`;
        // let { rows: resForEntry } = await client.query(sql, [userid, updatedon, wostagegacid]);
        await client.query(sql, [
          resForEntry[0].wostagegacid,
          fileuuid,
          filepath,
          userid,
          updatedon,
        ]);
        res.status(200).json({ data: resForEntry, message: 'File Updated' });
      } else if (type === 'update') {
        let sql = `UPDATE public.wms_workorder_stage_graphicartcut SET updatedby=$1, updatedon=$2,graphicartcutfileuuid=$3 WHERE wostagegacid=$4 RETURNING * ;`;
        const { rows: resForEntry } = await client.query(sql, [
          userid,
          updatedon,
          fileuuid,
          wostagegacid,
        ]);

        sql = `INSERT INTO wms_workorder_stage_graphicartcut_audit( wostagegacid,graphicartcutfileuuid, graphicartcutfilepath, updatedby,updatedon) VALUES ($1, $2, $3, $4,$5) RETURNING wostagegacid;`;
        // let { rows: resForEntry } = await client.query(sql, [userid, updatedon, wostagegacid]);
        await client.query(sql, [
          resForEntry[0].wostagegacid,
          fileuuid,
          filepath,
          userid,
          updatedon,
        ]);
        res.status(200).json({ data: resForEntry, message: 'File Updated' });
      }
    });
  } catch (e) {
    console.log(e);
  }
};

export const getGraphicLists = async (req, res) => {
  try {
    const reqData = req.body;
    const { woId } = req.body;
    let sql = '';
    const { type } = req.body;
    let condition = '';
    if (type === 'filter') {
      reqData.filter.forEach((item, i) => {
        condition +=
          reqData.filter.length - 1 !== i
            ? ` LOWER(${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%' AND `
            : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
      });

      sql = `SELECT COUNT(1) FROM  public.wms_graphicart_details as graphic
                WHERE graphic.workorderid=$1 ${
                  condition ? `AND${condition}` : condition
                }`;
    } else {
      sql = `SELECT COUNT(1) FROM public.wms_graphicart_details as graphic
                WHERE graphic.workorderid=$1 ${
                  condition ? `AND${condition}` : condition
                }`;
    }
    // let sql = `SELECT COUNT(1) FROM public.wms_wo_stagelist
    // join wms_workorder_service on wms_workorder_service.serviceid = wms_wo_stagelist.serviceid and wms_workorder_service.workorderid = wms_wo_stagelist.workorderid
    // join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
    // join wms_user on wms_user.userid=updatedby
    // left join wms_workorder_stage_graphicartcut gp on wms_wo_stagelist.wostageid=gp.wostageid
    // WHERE wms_wo_stagelist.workorderid=$1`;
    const [{ count }] = await query(sql, [woId]);
    sql = `SELECT * FROM public.wms_graphicart_details as graphic
                    WHERE graphic.workorderid=$1 ${
                      condition ? `AND${condition}` : condition
                    }`;

    const servicesData = await query(sql, [woId]);
    res.status(200).json({ data: servicesData, total: count });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const getGraphicAuditLists = async (req, res) => {
  try {
    const reqData = req.body;
    const { woId } = req.body;
    let sql = '';
    const { type } = req.body;
    let condition = '';
    if (type === 'filter') {
      reqData.filter.forEach((item, i) => {
        condition +=
          reqData.filter.length - 1 !== i
            ? ` LOWER(graphic.${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%' AND `
            : ` LOWER(graphic.${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%'`;
      });
      sql = `SELECT COUNT(1)  FROM public.wms_graphicart_details as graphic
             join wms_workorder_stage_graphicartcut_audit as audit on audit.wostagegacid=graphic.wostagegacid
             where graphic.workorderid=$1 ${
               condition ? `AND${condition}` : condition
             }`;
    } else {
      sql = `SELECT audit.updatedon,((wms_user.username::text || '('::text) || audit.updatedby::text) || ')'::text AS updateduser, 
                  graphic.stagename,graphic.servicename,graphic.graphicartcutfilepath
                  FROM public.wms_graphicart_details as graphic
                              join wms_workorder_stage_graphicartcut_audit as audit
                              on audit.wostagegacid=graphic.wostagegacid
                              join wms_user on wms_user.userid=audit.updatedby
                              where graphic.workorderid=$1 ${
                                condition ? `AND${condition}` : condition
                              }`;
    }
    const [{ count }] = await query(sql, [woId]);
    sql = `SELECT audit.updatedon,((wms_user.username::text || '('::text) || audit.updatedby::text) || ')'::text AS updateduser, 
            graphic.stagename,graphic.servicename,graphic.graphicartcutfilepath
            FROM public.wms_graphicart_details as graphic
                        join wms_workorder_stage_graphicartcut_audit as audit
                        on audit.wostagegacid=graphic.wostagegacid
                        join wms_user on wms_user.userid=audit.updatedby
                        where graphic.workorderid=$1  ${
                          condition ? `AND${condition}` : condition
                        }`;
    const auditData = await query(sql, [woId]);
    res.status(200).json({ data: auditData, total: count });
  } catch (error) {
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const tocFileEnableE2E = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfId, workorderid, instancecode, instancetype } = payload;
      const sql1 = `select distinct eventdata->>'processInstanceId' as processinstanceid,taskinstanceid from wms_workflow_eventlog where workorderid = ${workorderid}`;
      const data = await query(sql1);
      const processInstanceId = data[0].processinstanceid;
      const sql3 = `select wf_definitionid from wms_workflow where wfid = ${wfId}`;
      const resetactivity = await query(sql3);
      const camunda_posturi = `${process.env.CAMUNDA_NATIVE_URL}modification/execute`;
      const definitionId = resetactivity[0].wf_definitionid;
      const response = await createInstance(
        processInstanceId,
        instancecode,
        definitionId,
        camunda_posturi,
        instancetype,
      );
      console.log(response, 'ressssss');
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const addFileGraphicImage = async (req, res) => {
  let resmessage = {
    data: 'Process not completed',
    status: false,
    showtoaster: true,
  };
  let statuscode = 200;
  try {
    const { filteredListFiles, alltaskDetails } = req.body;
    const woid = alltaskDetails.workorderid;
    const wfId = alltaskDetails.wfid;

    let existingdata = [];

    // .......GETTING PROCESS INSTANCEID.......//
    let processInstanceId = '';
    // let taskInstanceId = '';
    // .......GETTING PROCESS INSTANCEID.......//
    const sql1 = `select distinct eventdata->>'processInstanceId' as processinstanceid,taskinstanceid from wms_workflow_eventlog where workorderid = $1`;
    await query(sql1, [woid]).then(async response => {
      if (response && response.length) {
        processInstanceId = response[0].processinstanceid;
        // taskInstanceId = response[0].taskinstanceid;
      }
    });
    // .......GETTING resettoactivityid  wf_definitionid.......//

    // let sql3 = `select resettoactivityid  from wms_workflowdefinition where wfid=$1 and stageid=10`;
    const sql3 = `SELECT a1.resettoactivityid, b1.wf_definitionid
        FROM wms_workflowdefinition a1
        JOIN wms_workflow b1 ON  a1.wfid = b1.wfid
        WHERE a1.wfid= $1 AND a1.stageid=10 and a1.activityid=101`;
    const resetactivity = await query(sql3, [wfId]);

    // .......GETTING EXISTING IMAGE COUNT WHICH IS NULL.......//
    const sql2 = `select a.woincomingfileid,a.woincomingid,a.filename,a.imagecount,a.filetypeid,a.istriggered 
        from public.wms_workorder_incomingfiledetails a
                join wms_workorder_incoming b on b.woincomingid = a.woincomingid
                where b.woid = $1 and a.filetypeid != 1 and a.imagecount is null
                order by a.woincomingfileid desc`;
    await query(sql2, [woid]).then(async response => {
      if (response && response.length) {
        existingdata = response;
      }
    });

    // .......COMPARE EXISTING IMAGE AND NEW IMAGE COUNT.......//
    const lstjob = filteredListFiles.filter(ob1 => {
      return existingdata.some(ob2 => {
        return (
          ob1.woincomingfileid === ob2.woincomingfileid &&
          ob1.imagecount != null
        );
      });
    });

    const chksamecount = filteredListFiles.filter(ob1 => {
      return existingdata.some(ob2 => {
        return (
          ob1.woincomingfileid === ob2.woincomingfileid &&
          ob1.imagecount != null &&
          ob1.imagecount != ob2.imagecount
        );
      });
    });

    // .....CONSTRUCT CAMUNDA URI FOR SERVICE CALL.....//
    const camunda_geturi = `${process.env.CAMUNDA_NATIVE_URL}process-instance/${processInstanceId}/variables/__stageInfo__?deserializeValue=false`;
    // const camunda_puturi = `${process.env.CAMUNDA_NATIVE_URL}process-instance/${processInstanceId}/variables/__stageInfo__`;
    const camunda_posturi = `${process.env.CAMUNDA_NATIVE_URL}modification/execute`;

    if (lstjob != undefined && lstjob.length > 0) {
      if (chksamecount != undefined && chksamecount.length > 0) {
        // .......CAMUNDA SERVICE CALL 1.......//
        await service
          .get(camunda_geturi)
          .then(async resdata => {
            if (
              resdata != undefined &&
              resdata.data != undefined &&
              resdata.data.value != undefined
            ) {
              const jsobj = JSON.parse(resdata.data.value);

              /* ......MAKING GRAPHIC TRUE FOR GIVEN FILES AND MAKING FALSE FOR NOT GIVEN FILES........
                          ......ADDING NEW KEY isupated FOR LOGIC PURPOSE........ */

              // jsobj.file = Array.isArray(jsobj.file)
              //   ? jsobj.file
              //   : [jsobj.file];
              // let isJournal = false;
              // if (Array.isArray(jsobj.file))
              //   isJournal = false;
              // } else {
              //   isJournal = true;
              //   jsobj.file = [jsobj.file];
              // }
              let isJournal = false;
              if (!Array.isArray(jsobj.file)) {
                isJournal = true;
                jsobj.file = [jsobj.file];
              }

              const updateimage = [];
              jsobj.file.filter(x => {
                lstjob.some(y => {
                  if (x.id == y.woincomingfileid && x.isupdated == undefined) {
                    x.isGraphic = true;
                    x.isupdated = true;
                    updateimage.push({
                      woincomingfileid: +y.woincomingfileid,
                      imagecount: +y.imagecount,
                    });
                  } else if (x.isupdated == undefined && x.isupdated != true) {
                    x.isGraphic = false;
                  }
                  return true;
                });
                return true;
              });
              // .....REMOVING KEY isupated AFTER ACHIEVING LOGIC.....//
              jsobj.file.forEach(list => {
                if (list.isupdated != undefined) {
                  delete list.isupdated;
                }
              });

              // .....TAKING COUNT OF ISGRAPHIC = TRUE.....//
              const truecount = jsobj.file.filter(x => x.isGraphic == true);
              truecount.map(x => x.id).toString();
              let camundaType = `startAfterActivity`;
              if (isJournal) {
                const journalFile = jsobj.file[0];
                jsobj.file = journalFile;
                camundaType = `startBeforeActivity`;
              }
              // .....JSON PARAMETER FOR BULK UPDATE IMAGE COUNT IN TABLE.....//
              const pimageupdate = JSON.stringify(updateimage);

              // let jsonval = JSON.stringify(jsobj);
              //   console.log(jsonval, 'newarray');

              // .....CONSTRUCTING PARAMS FOR URI.....//
              // ..NEED DOUBLE TIME STRINGIFY SO ADDED...//
              //   let jsonparam = `{"type": "Json","value": ${JSON.stringify(jsobj)} , "valueInfo": {}}`;

              // .....CALLING CAMUNDA SERVICE 2.....//

              const updateCamundaStageInfo = await _updateStageInfoToCamunda(
                jsobj,
                processInstanceId,
              );
              // let updateTaskInstanceInfo = await _updateActivityStageInfoToCamunda(jsobj, taskInstanceId)

              //  await service.put(camunda_puturi, jsonparam).then(async (putresp) => {

              if (
                updateCamundaStageInfo != undefined &&
                updateCamundaStageInfo
              ) {
                // .....CALLING CAMUNDA SERVICE 3 FOR EACH GRAPHIC IMAGE IS TRUE.....//
                const result = await createInstance(
                  processInstanceId,
                  resetactivity[0].resettoactivityid,
                  resetactivity[0].wf_definitionid,
                  camunda_posturi,
                  camundaType,
                );

                if (result.issuccess == true) {
                  const sql4 = `update wms_workorder_incomingfiledetails set imagecount = subres.imagecount
                                from (select * from json_to_recordset('${pimageupdate}') as x("woincomingfileid" bigint, "imagecount" bigint)) as subres
                                where wms_workorder_incomingfiledetails.woincomingfileid = subres.woincomingfileid`;

                  await query(sql4).then(async sql4res => {
                    if (sql4res && sql4res.length) {
                      /* log removed */
                    }
                  });

                  resmessage = {
                    data: result.data,
                    status: true,
                    showtoaster: true,
                  };
                } else {
                  resmessage = {
                    data: `Camunda error after post uri service: ${result.data} update processDefinitionId`,
                    status: false,
                    showtoaster: true,
                  };
                }
              } else {
                resmessage = {
                  data: 'Camunda error after put uri service ',
                  status: false,
                  showtoaster: true,
                };
              }

              // }).catch((error) => {
              //     resmessage = { data: 'Camunda error in put uri service call: ' + error.message.data.message, status: false };
              // });
            } else {
              resmessage = {
                data: 'Camunda data getting undefined',
                status: false,
                showtoaster: true,
              };
            }
          })
          .catch(e => {
            resmessage = { data: e.message, status: false, showtoaster: true };
            statuscode = 400;
          });
      } else {
        resmessage = {
          data: 'No change in image count',
          status: false,
          showtoaster: false,
        };
      }
    } else {
      resmessage = {
        data: 'Data not found in db',
        status: false,
        showtoaster: false,
      };
    }
  } catch (error) {
    resmessage = { data: error.message, status: false, showtoaster: true };
    statuscode = 400;
  } finally {
    res.status(statuscode).send(resmessage);
  }
};

export const fileNameUpdate = async (req, res) => {
  try {
    const { filteredListFiles, alltaskDetails } = req.body;

    let taskInstanceId = '';
    // let processInstanceId = '';
    // .......GETTING PROCESS INSTANCEID.......//
    const sql1 = `select distinct eventdata->>'processInstanceId' as processinstanceid,taskinstanceid from wms_workflow_eventlog where workorderid = $1`;
    await query(sql1, [alltaskDetails.workorderid]).then(async response => {
      if (response && response.length) {
        // processInstanceId = response[0].processinstanceid;
        taskInstanceId = response[0].taskinstanceid;
      }
    });

    // select already fileslist against woid
    const sql = `select a.woincomingfileid,a.woincomingid,a.filename,a.imagecount,a.filetypeid,a.istriggered 
from public.wms_workorder_incomingfiledetails a
join wms_workorder_incoming b on b.woincomingid = a.woincomingid
where b.woid =${alltaskDetails.workorderid} and a.filetypeid !=1
order by a.woincomingfileid desc`;
    const fileNameList = await query(sql);

    const updatefileList = [];
    filteredListFiles.forEach(list => {
      updatefileList.push({
        woincomingfileid: list.woincomingfileid,
        filename: list.filename + list.suffix,
      });
    });

    const checkStatus = fileNameList.filter(item =>
      updatefileList.some(compareItem => {
        return (
          item.woincomingfileid == compareItem.woincomingfileid &&
          item.filename != compareItem.filename
        );
      }),
    );

    if (checkStatus.length > 0) {
      // camunda filename variable update
      const getCamundaStageInfo = await _getStageInfoFromCamunda(
        alltaskDetails.workorderid,
      );

      // camunda filename variable update
      let testobj = [];
      testobj = JSON.parse(getCamundaStageInfo.__stageInfo.data.value);
      testobj.files.map(x => {
        const temp = updatefileList.find(
          element => element.woincomingfileid == x.id,
        );
        x.name = temp.filename;
        return x;
      });

      getCamundaStageInfo.__stageInfo.data.value = JSON.stringify(testobj);

      const updateCamundaStageInfo = await _updateStageInfoToCamunda(
        JSON.parse(getCamundaStageInfo.__stageInfo.data.value),
        getCamundaStageInfo.processInstanceId,
      );
      await _updateActivityStageInfoToCamunda(testobj, taskInstanceId);
      // update new filesname against updatefileList
      if (updateCamundaStageInfo) {
        const sql2 = `update wms_workorder_incomingfiledetails set filename = subres.filename
from (select * from json_to_recordset(
'${JSON.stringify(updatefileList)}' ) 
	as x("woincomingfileid" bigint, "filename" character varying(1000))) as subres
where wms_workorder_incomingfiledetails.woincomingfileid = subres.woincomingfileid`;

        const updatefileNameList = await query(sql2);

        // sql = `SELECT * FROM public.wms_workorder_incoming as wwi
        //   JOIN public.wms_workorder_incomingfiledetails as wwif ON wwif.woincomingid = wwi.woincomingid
        //   where wwi.woid = $1`;
        // let getIncomingFiles = await query(sql, [alltaskDetails.workorderid]);
        // console.log(getIncomingFiles, 'getIncomingFiles')

        // // call iTracks API
        // let data ={};
        // data.woid=alltaskDetails.workorderid,
        // data.userid='IS7471',
        // data.wotype=alltaskDetails.wotype,
        // data.receiptdate= new Date().toJSON().slice(0, 10);
        // data.stageId=stageId,
        // data.wfId=alltaskDetails.wfid,
        // data.stageIterationCount = 1;
        // data.jobcardId =alltaskDetails.jobcardid

        // let subJobRes = await addSubJob(getIncomingFiles, data, true, false);

        if (updatefileNameList) {
          res.status(200).send({
            message: 'Filename enabled successfully',
            status: true,
            update: true,
          });
        } else {
          res.status(400).send({
            message: 'itracks update failed',
            status: false,
            update: true,
          });
        }
      } else {
        res.status(400).send({
          message: 'Camunda api update failed ',
          status: false,
          update: true,
        });
      }
    } else {
      res.status(200).send({
        message: 'No camunda changes files names same',
        update: false,
      });
    }
  } catch (error) {
    res.status(400).send({
      message: error.message ? error.message : error,
      status: false,
      update: true,
    });
  }
};

const createInstance = async (
  processInstanceId,
  resetactivity,
  wf_definitionid,
  camunda_posturi,
  camundaType,
) => {
  const processDefinitionId = wf_definitionid; // 'CUP_BOOKS:5:3e9127c1-df3e-11ed-884e-005056b20c9b'

  return new Promise(async resolve => {
    try {
      const payload = `{"processDefinitionId": "${processDefinitionId}",
                "instructions": [
                    {
                        "type": "${camundaType}",
                        "activityId": "${resetactivity}"
                    }
                ],
                "processInstanceIds": ["${processInstanceId}"],
                "skipCustomListeners": false,
                "annotation": "Modified to resolve an error."
            }`;

      if (payload) {
        const resetResponse = await service.post(camunda_posturi, payload);
        // response.data = resetResponse.data ? resetResponse.data : resetResponse;
        // resolve(resetResponse);
        console.log(resetResponse, 'after create response');
        if (resetResponse != undefined && resetResponse.status) {
          resolve({ issuccess: true, data: 'success' });
        } else {
          resolve({ issuccess: false, data: resetResponse.data });
        }
      }
    } catch (error) {
      resolve({ issuccess: false, data: error.message });
    }
  });
};
