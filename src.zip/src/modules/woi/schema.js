// schema for workorder create
const woSchema = {
  customer: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  division: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  subDivision: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  country: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  custPrimaryContact: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  custSecondaryContact: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  kamName: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  clientManager: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  projectManager: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  okContact: {
    required: false,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  jobId: {
    required: true,
    type: 'string',
    isLength: { min: 0, max: 255 },
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  jobTitle: {
    required: true,
    type: 'string',
    isLength: { min: 0, max: 1000 },
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  services: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  emailAttachment: {
    required: false,
    type: 'string',
    validate(name, path) {
      console.log(name, path);
      const data = { isValid: true };
      return data;
    },
  },
  // workflowTemplate: {
  //   required: true,
  //   type: 'number',
  //   validate: function (name, path) {
  //     let data = { isValid: true };
  //     if (name == "") {
  //       data.isValid = false,
  //         data.message = `${path} should not be empty`
  //     }
  //     return data;
  //   }
  // },
  // isBillable: {
  //   required: false,
  //   type: 'boolean',
  //   validate: function (name, path) {
  //     let data = { isValid: true };
  //     return data;
  //   }
  // },
  // projectBrief: {
  //   required: false,
  //   type: 'string',
  //  isLength:[0,10000],
  //   validate: function (name, path) {
  //     let data = { isValid: true };
  //     return data;
  //   }
  // },
  softwares: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  colours: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  languages: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  inputFileTypes: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  eISBN: {
    required: false,
    type: 'string',
    isLength: { min: 0, max: 20 },
    validate(name, path) {
      console.log(name, path);
      const data = { isValid: true };
      // if (name == "") {
      //   data.isValid = false,
      //     data.message = `${path} should not be empty`
      // }
      return data;
    },
  },
  printISBN: {
    required: false,
    type: 'string',
    isLength: { min: 0, max: 20 },
    validate(name, path) {
      console.log(name, path);
      const data = { isValid: true };
      // if (name == "") {
      //   data.isValid = false,
      //     data.message = `${path} should not be empty`
      // }
      return data;
    },
  },
  edition: {
    required: false,
    type: 'string',
    isLength: { min: 0, max: 20 },
    validate(name, path) {
      console.log(name, path);
      const data = { isValid: true };
      // if (name == "") {
      //   data.isValid = false,
      //     data.message = `${path} should not be empty`
      // }
      return data;
    },
  },
  ISSN: {
    required: false,
    type: 'string',
    isLength: { min: 0, max: 20 },
    validate(name, path) {
      console.log(name, path);
      const data = { isValid: true };
      // if (name == "") {
      //   data.isValid = false,
      //     data.message = `${path} should not be empty`
      // }
      return data;
    },
  },
  CELevel: {
    required: false,
    type: 'number',
    validate(name, path) {
      console.log(name, path);
      const data = { isValid: true };
      return data;
    },
  },
  category: {
    required: false,
    type: 'number',
    isLength: { min: 0, max: 1000 },
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  noOfChapters: {
    required: false,
    type: 'number',
    validate(name, path) {
      console.log(name, path);
      const data = { isValid: true };
      return data;
    },
  },
  indexType: {
    required: false,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
};

// fields schema for workorder create - WK-KLI
const kliSchema = {
  // check filed empty and validate and throw error with specific message
  customer: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  division: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  subDivision: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  country: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  journalId: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  projectManager: {
    required: true,
    type: 'string',
    isLength: { min: 0, max: 255 },
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  supplierProjectManager: {
    required: true,
    type: 'string',
    isLength: { min: 0, max: 255 },
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
};
// fields schema for workorder create - OUP ISSUE
const oupIssueSchema = {
  // check filed empty and validate and throw error with specific message
  woType: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  jobType: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  customer: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  ftpAuditId: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  extention: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  journalAcronym: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  title: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  issueNumber: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  volumeNumber: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  stage: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  stageIteration: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  createdBy: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  mergeArticleInfo: {
    required: true,
    type: 'object',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
};
// fields schema for workorder create - Elsevier Article
const elsevierArticleSchema = {
  // check filed empty and validate and throw error with specific message
  woType: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  jobType: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  customer: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  ftpAuditId: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  extention: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  journalAcronym: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  title: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  stage: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  stageIteration: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  createdBy: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
};
// fields schema for workorder create - OUP ISSUE
const elsevierIssueSchema = {
  // check filed empty and validate and throw error with specific message
  woType: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  jobType: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  customer: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  ftpAuditId: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  extention: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  journalAcronym: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  title: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  issueNumber: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  volumeNumber: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  stage: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  stageIteration: {
    required: true,
    type: 'number',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  createdBy: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  mergeArticleInfo: {
    required: true,
    type: 'object',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
};
// fields schema for workorder create - Elsevier Article
const elsevierBookSchema = {
  // check filed empty and validate and throw error with specific message
  woType: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
  customer: {
    required: true,
    type: 'string',
    validate(name, path) {
      const data = { isValid: true };
      if (name == '') {
        data.isValid = false;
        data.message = `${path} should not be empty`;
      }
      return data;
    },
  },
};
export {
  woSchema,
  kliSchema,
  oupIssueSchema,
  elsevierArticleSchema,
  elsevierIssueSchema,
  elsevierBookSchema,
};
