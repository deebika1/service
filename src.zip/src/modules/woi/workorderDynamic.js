import { query, transaction } from '../../database/postgres.js';
import {
  checkWOExists,
  checkValueExists,
  // mailTrigger,
  woJournalMappedPmEntry,
  // wmsWOCreate,
  getWOJobnormsDetails,
  getExternalUsers,
  checkWoChapterEntry,
} from './index.js';
import { itracksFinancialIntegration } from './woAutocreation.js';

export const getUserDU = async (req, res) => {
  try {
    let customeroptions = [];
    let divisionoptions = [];
    let verticaloptions = [];
    let countryoptions = [];
    let userDUList = [];
    const existIds = new Set();

    const { duid, woId } = req.body;
    // const userDUList = await getUserDUDetails(userid);
    // const DuList = userDUList.map(data => parseInt(data.value));
    let userCusDivVertCountryList;
    if (woId > 0) {
      userCusDivVertCountryList = await getWODetails(woId);
    } else {
      userCusDivVertCountryList = await CusDivVertCountryDetails(duid);
    }

    if (userCusDivVertCountryList.length > 0) {
      userDUList = userCusDivVertCountryList.reduce((options, data) => {
        if (!existIds.has(data.duid)) {
          existIds.add(data.duid);
          options.push({
            value: data.duid,
            label: data.duname,
          });
        }
        return options;
      }, []);
      existIds.clear();
      customeroptions = userCusDivVertCountryList.reduce((options, data) => {
        if (!existIds.has(data.customerid)) {
          existIds.add(data.customerid);
          options.push({
            value: data.customerid,
            label: data.customername,
          });
        }
        return options;
      }, []);
      existIds.clear();
      divisionoptions = userCusDivVertCountryList.reduce((options, data) => {
        if (!existIds.has(data.divisionid)) {
          existIds.add(data.divisionid);
          options.push({
            value: data.divisionid,
            label: data.division,
          });
        }
        return options;
      }, []);
      existIds.clear();
      verticaloptions = userCusDivVertCountryList.reduce((options, data) => {
        if (!existIds.has(data.subdivisionid)) {
          existIds.add(data.subdivisionid);
          options.push({
            value: data.subdivisionid,
            label: data.subdivision,
          });
        }
        return options;
      }, []);
      existIds.clear();
      countryoptions = userCusDivVertCountryList.reduce((options, data) => {
        if (!existIds.has(data.countryid)) {
          existIds.add(data.countryid);
          options.push({
            value: data.countryid,
            label: data.countryname,
          });
        }
        return options;
      }, []);
      existIds.clear();
    }
    res.status(200).send({
      du: userDUList,
      customer: customeroptions.sort((a, b) => a.label.localeCompare(b.label)),
      division: divisionoptions.sort((a, b) => a.label.localeCompare(b.label)),
      vertical: verticaloptions.sort((a, b) => a.label.localeCompare(b.label)),
      country: countryoptions.sort((a, b) => a.label.localeCompare(b.label)),
      wholeData: userCusDivVertCountryList,
    });
  } catch (e) {
    console.log(e);
  }
};

// const getUserDUDetails = async userId => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const sql = `SELECT u.duid AS value, du.duname AS label
//           FROM public.wms_user u
//           JOIN public.org_mst_deliveryunit du ON du.duid = u.duid AND du.isactive = true
//           WHERE u.userid = $1 AND u.useractive = true
//           UNION
//           SELECT mapped_duid AS value, du.duname AS label
//           FROM public.wms_user u
//           CROSS JOIN LATERAL unnest(u.mappedduid) AS mapped_duid
//           JOIN public.org_mst_deliveryunit du ON du.duid = mapped_duid AND du.isactive = true
//           WHERE u.userid = $1 AND u.useractive = true ORDER BY label`;
//       const result = await query(sql, [userId]);
//       resolve(result);
//     } catch (e) {
//       reject(e);
//     }
//   });
// };

const CusDivVertCountryDetails = async duId => {
  return new Promise(async (resolve, reject) => {
    try {
      // const sql = `SELECT org.divisionid,divi.division,org.customerid,cust.customername,
      //   org.subdivisionid,sdivi.subdivision,
      //   org.countryid,geo.countryname
      //   FROM public.org_mst_customer_orgmap AS org
      //   JOIN PUBLIC.org_mst_customerorg_du_map AS dmap ON dmap.custorgmapid = org.custorgmapid
      //   JOIN public.org_mst_division AS divi on divi.divisionid = org.divisionid AND divi.isactive = true
      //   JOIN public.org_mst_subdivision AS sdivi on sdivi.subdivisionid = org.subdivisionid AND sdivi.isactive = true
      //   JOIN public.geo_mst_country AS geo on geo.countryid = org.countryid AND geo.isactive = true
      //   JOIN public.org_mst_customer AS cust on cust.customerid = org.customerid AND cust.isactive = true
      //   WHERE dmap.duid = $1`;
      const sql = `SELECT org.duid, du.duname, divi.divisionid, divi.division, org.customerid, cust.customername,
          org.verticalid AS subdivisionid, sdivi.subdivision, geo.countryid, geo.countryname 
          FROM public.wms_config_customertabinfomapping org
          JOIN public.org_mst_deliveryunit AS du ON du.duid = org.duid AND du.isactive = true
          JOIN public.org_mst_division AS divi ON divi.divisionid = ANY(org.divisionid) AND divi.isactive = true
          JOIN public.org_mst_subdivision AS sdivi ON sdivi.subdivisionid = org.verticalid AND sdivi.isactive = true
          JOIN public.geo_mst_country AS geo ON geo.countryid = ANY(org.countryid) AND geo.isactive = true
          JOIN public.org_mst_customer AS cust ON cust.customerid = org.customerid AND cust.isactive = true
          WHERE org.duid = $1 AND org.isactive = true`;
      const result = await query(sql, [duId]);
      resolve(result);
    } catch (e) {
      reject(e);
    }
  });
};

export const getTabandInfo = async (req, res) => {
  const { duId, cusId, divId, verId, counId } = req.body;
  const Tab = await workorderTabDetails(duId, cusId, divId, verId, counId);
  // const Info = await workorderInfoDetails(duId, cusId, divId, verId, counId);
  const field = await workorderInfoFieldDetails(
    duId,
    cusId,
    divId,
    verId,
    counId,
  );
  res.status(200).send({
    tab: Tab,
    // info: Info,
    infofields: field,
  });
};

const workorderTabDetails = async (duId, cusId, divId, verId, counId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT DISTINCT ta.tabid AS id, ta.tabname AS title, org.custorgmapid, ta.sequence
        FROM public.wms_config_customertabinfomapping cmap
        JOIN public.wms_config_tabs ta ON ta.tabid = ANY(cmap.tabid)
        JOIN public.org_mst_customer_orgmap org ON org.customerid = $2 AND org.divisionid = $3 AND 
          org.subdivisionid = $4 AND org.countryid = $5 AND org.isactive = 1
        JOIN org_mst_customerorg_du_map omcdm ON omcdm.custorgmapid = org.custorgmapid AND omcdm.duid = cmap.duid
        WHERE cmap.duid = $1 AND cmap.customerid = $2 AND $3 = ANY(cmap.divisionid) AND 
          cmap.verticalid = $4 AND $5 = ANY(cmap.countryid) AND cmap.isactive = true ORDER BY ta.sequence;`;
      const result = await query(sql, [duId, cusId, divId, verId, counId]);
      resolve(result);
    } catch (e) {
      reject(e);
    }
  });
};

// const workorderInfoDetails = async (duId, cusId, divId, verId, counId) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const sql = `SELECT DISTINCT wi.infoid AS id, wi.infoname AS title
//         FROM public.wms_config_customertabinfomapping cmap
//         JOIN public.wms_config_workorderinfo wi ON wi.infoid = ANY(cmap.infoid)
//         WHERE duid = $1 AND customerid = $2 AND $3 = ANY(divisionid) AND
//           verticalid = $4 AND $5 = ANY(countryid);`;
//       const result = await query(sql, [duId, cusId, divId, verId, counId]);
//       resolve(result);
//     } catch (e) {
//       reject(e);
//     }
//   });
// };

const workorderInfoFieldDetails = async (duId, cusId, divId, verId, counId) => {
  return new Promise(async (resolve, reject) => {
    try {
      // const sql = `SELECT conmap.mappingid, conmap.infoid, wi.infoid AS id, wi.infoname AS title,
      //   json_build_object(
      //     'formArray', json_agg(json_build_object(
      //       'label', conmap.labelname,
      //       'placeHolder', conmap.placeholder,
      //       'fieldName', conmap.keyname,
      //       'fieldType', conmap.fieldtype,
      //       'required', conmap.mandatory,
      //       'disabled', conmap.disabled,
      //       'pattern', conmap.pattern,
      //       'maxLength', conmap.maxlength,
      //       'value', '' ) ORDER BY conmap.sequence
      //     )) AS fields
      //     FROM public.wms_config_customertabinfomapping cmap
      //     JOIN public.wms_config_customerfieldmapping conmap ON conmap.mappingid = cmap.custmapping AND conmap.isactive = true
      //     JOIN public.wms_config_workorderinfo wi ON wi.infoid = conmap.infoid AND wi.isactive = true
      //     WHERE cmap.duid = $1 AND cmap.customerid = $2 AND $3 = ANY(cmap.divisionid) AND
      //     cmap.verticalid = $4 AND $5 = ANY(cmap.countryid)
      //     GROUP BY conmap.mappingid, conmap.infoid, wi.infoid, wi.infoname;`;
      const sql = `SELECT conmap.mappingid, conmap.infoid, wi.infoid AS id, wi.infoname AS title,
        json_build_object(
          'formArray', json_agg(json_build_object(
            'label', conmap.labelname,
            'placeHolder', conmap.placeholder,
            'fieldName', conmap.keyname,
            'fieldType', conmap.fieldtype,
            'required', conmap.mandatory,
            'disabled', conmap.disabled,
            'pattern', conmap.pattern,
            'maxLength', conmap.maxlength,
            'dataType', conmap.datatype,
            'value', '',
            'child', COALESCE((SELECT json_agg(json_build_object(
                    'label', child.labelname,
                    'placeHolder', child.placeholder,
                    'fieldName', child.bindname,
                    'fieldType', child.fieldtype,
                    'pattern', child.regexpattern,
                    'maxLength', child.maxlength,
                    'dataType', child.datatype,
                    'value', '' )  ORDER BY child.sequence) FROM public.wms_config_fields_map child WHERE child.parentid = 
                    (SELECT fieldmapid FROM public.wms_config_fields_map WHERE fieldtype = conmap.fieldtype AND labelname = conmap.labelname AND screenname = 'Workorder') AND child.screenname = 'Workorder'),
                '[]'::json
              )
            ) ORDER BY conmap.sequence
        )) AS fields
      FROM public.wms_config_customertabinfomapping cmap
      JOIN public.wms_config_customerfieldmapping conmap ON conmap.mappingid = cmap.custmapping AND conmap.isactive = true
      JOIN public.wms_config_workorderinfo wi ON wi.infoid = conmap.infoid AND wi.isactive = true
      WHERE cmap.duid = $1 AND cmap.customerid = $2 AND $3 = ANY(cmap.divisionid) AND 
        cmap.verticalid = $4 AND $5 = ANY(cmap.countryid) AND conmap.infoid = ANY(cmap.infoid)
        AND cmap.isactive = true AND conmap.isactive = true
      GROUP BY conmap.mappingid, conmap.infoid, wi.infoid, wi.infoname;`;
      const result = await query(sql, [duId, cusId, divId, verId, counId]);
      resolve(result);
    } catch (e) {
      reject(e);
    }
  });
};

export const checkIsDUWms = async (req, res) => {
  try {
    const { duId } = req.params;
    // const sql = `SELECT flowtype FROM public.org_mst_deliveryunit WHERE duid = $1 AND isactive = true;`;
    const sql = `SELECT DISTINCT flowtype FROM public.trn_customerflowtype_config WHERE duid = $1;`;
    const result = await query(sql, [duId]);
    res.status(200).send(result);
  } catch (e) {
    console.log(e);
  }
};

// eslint-disable-next-line consistent-return
export const DynamicWorkOrderCreation = async (req, res) => {
  try {
    const reqData = req.body;
    // const { isauto } = reqData;

    if (reqData.workorderId) {
      woUpdate(reqData, res);
    } else {
      const {
        WoHardBackISBN,
        WoPaperBackISBN,
        WoOcISBN,
        printISBN,
        eISBN,
        ISSN,
      } = req.body;

      const woExists = await checkWOExists(reqData);

      // for cup
      if (WoHardBackISBN) {
        await checkValueExists(WoHardBackISBN, 'hardbackisbn', 'HardBack ISBN');
      }
      if (WoPaperBackISBN) {
        await checkValueExists(
          WoPaperBackISBN,
          'paperbackisbn',
          'PaperBack ISBN',
        );
      }
      if (WoOcISBN) {
        await checkValueExists(WoOcISBN, 'ocisbn', 'OC ISBN');
      }
      // for hodder printisbn, eisbn, issn,
      if (printISBN) {
        await checkValueExists(printISBN, 'printisbn', 'Print ISBN');
      }
      if (eISBN) {
        await checkValueExists(eISBN, 'eisbn', 'EISBN');
      }
      if (ISSN) {
        await checkValueExists(ISSN, 'issn', 'ISSN');
      }
      console.log(woExists, 'woExists');

      console.log('without iTracks WO');
      reqData.jobCardId = null;
      // if (isauto) {
      //   const resultdata = await wmsWOCreate(reqData);
      //   return resultdata;
      // }
      await woCreate(reqData, res);
    }
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
    return false;
  }
};

export const woCreate = async (reqData, res) => {
  // workorder
  try {
    const { articleNumber, piiNumber } = reqData;
    const otherFileds = articleNumber
      ? `{"articleno": "${articleNumber}", "pii": "${piiNumber}" }`
      : null;
    const orderDate = reqData.emailOrderDate
      ? `'${reqData.emailOrderDate}'`
      : null;
    const sqlForCreate = ` INSERT INTO public.wms_workorder(
        itemcode, title,projectbrief,printisbn, eisbn, issn, edition,customerid, 
        divisionid, subdivisionid, countryid, colorid, composingsoftwareid, inputfiletypeid, 
        languageid, celevelid, indextypeid,category, status, trimsizewidth, trimsizewidthuom,
        trimsizeheight, trimsizeheightuom, orderemailpath, orderemailpathuuid, totalchaptercount, 
        ordermaildate, journalid, jobtype, doinumber,newsletterdoinumber, wotype, totalarticlecount, 
        totalnonarticlecount, issuenumber, volumenumber, jobcardid, iworkflow, paperbackisbn, hardbackisbn, 
        ocisbn, otherfield,logoid,dmsid,iscoveravailable,isadvertavailable, createdby, duid, complexityid, wfid, flowtype, currencyid, islock )
        VALUES (
        '${reqData.jobId}', 
         ${reqData.jobTitle ? `'${reqData.jobTitle}'` : null}, 
        ${reqData.projectBrief ? `'${reqData.projectBrief}'` : null}, 
        ${reqData.printISBN ? `'${reqData.printISBN}'` : null},
        ${reqData.eISBN ? `'${reqData.eISBN}'` : null}, 
        ${reqData.ISSN ? `'${reqData.ISSN}'` : null}, 
        ${reqData.edition ? `'${reqData.edition}'` : null},
         ${reqData.customer}, ${reqData.division}, 
         ${reqData.subDivision}, ${reqData.country}, 
         ${reqData.colours ? reqData.colours : null}, 
         ${reqData.softwares ? reqData.softwares : null}, 
         ${reqData.inputFileTypes ? reqData.inputFileTypes : null},
         ${reqData.languages ? reqData.languages : null}, 
         ${reqData.CELevel ? reqData.CELevel : null}, 
         ${reqData.indexType ? reqData.indexType : null},
         ${reqData.category ? reqData.category : null}, 'In Process',
         ${reqData.pageWidth ? reqData.pageWidth : null},
         ${reqData.pageWidthUnit ? `'${reqData.pageWidthUnit}'` : null},        
         ${reqData.pageHeight ? reqData.pageHeight : null},
         ${reqData.pageHeightUnit ? `'${reqData.pageHeightUnit}'` : null},
         ${reqData.orderEmailPath ? `'${reqData.orderEmailPath}'` : null},
         ${
           reqData.orderEmailPathUuid ? `'${reqData.orderEmailPathUuid}'` : null
         }, 
         ${reqData.noOfChapters ? reqData.noOfChapters : null}, ${orderDate}, 
         ${reqData.journalAcronym ? reqData.journalAcronym : null}, 
         ${reqData.jobType ? reqData.jobType : null}, 
         ${reqData.doiNumber ? `'${reqData.doiNumber}'` : null},
         ${
           reqData.newsletterdoiNumber
             ? `'${reqData.newsletterdoiNumber}'`
             : null
         },
         ${reqData.woType ? `'${reqData.woType}'` : null}, 
         ${
           !Number.isNaN(parseInt(reqData.noOfArticles))
             ? reqData.noOfArticles
             : null
         },
         ${
           !Number.isNaN(parseInt(reqData.noOfNonArticles))
             ? reqData.noOfNonArticles
             : null
         }, 
         ${reqData.issueNumber ? `'${reqData.issueNumber}'` : null},
         ${reqData.volumeNumber ? `'${reqData.volumeNumber}'` : null}, 
         ${reqData.jobCardId ? reqData.jobCardId : null}, 
         ${reqData.iWorkflow ? `'${reqData.iWorkflow}'` : null}, 
         ${reqData.WoPaperBackISBN ? `'${reqData.WoPaperBackISBN}'` : null},
         ${reqData.WoHardBackISBN ? `'${reqData.WoHardBackISBN}'` : null},
         ${reqData.WoOcISBN ? `'${reqData.WoOcISBN}'` : null},  
         ${otherFileds ? `'${otherFileds}'` : null},
         ${reqData.logoid ? reqData.logoid : null},
         ${reqData.dmsid ? reqData.dmsid : 3}, 
         ${reqData.iscoveravailable || false},
         ${reqData.isadvertavailable || false}, 
         ${reqData.modifiedBy ? `'${reqData.modifiedBy}'` : null}, 
         ${reqData.duId}, 
         ${reqData.complexity || null},
         ${reqData.workFlow || null}, 'nonwms', 
         ${reqData.currency || null}, false)
         RETURNING workorderid, wfid, customerid `;
    console.log(sqlForCreate, 'sqlForCreate');

    await query(sqlForCreate)
      .then(async resForCreate => {
        console.log(resForCreate, 'resForCreate');
        // workorder contact
        const getValuesQuery = `SELECT ${
          resForCreate[0].workorderid
        },custorgconmapid, contactname,contactemail,contactphone1,contactphone2,contactroleid,contacttype,isprimary 
            FROM org_mst_customerorg_contact WHERE custorgconmapid IN (${
              reqData.custPrimaryContact ? reqData.custPrimaryContact : null
            },${
          reqData.custSecondaryContact ? reqData.custSecondaryContact : null
        }, ${reqData.projectManager ? reqData.projectManager : null}, ${
          reqData.supplierProjectManager ? reqData.supplierProjectManager : null
        },${reqData.clientManager ? reqData.clientManager : null} ${
          reqData.subDivision !== 9
            ? `,(SELECT custorgconmapid FROM org_mst_customerorg_contact WHERE custorgmapid IN ( 
        (SELECT custorgmapid FROM org_mst_customerorg_contact  WHERE custorgconmapid = ${
          reqData.custPrimaryContact ? reqData.custPrimaryContact : null
        }))
        and custorgconmapid not in (${
          reqData.custPrimaryContact ? reqData.custPrimaryContact : null
        },${reqData.custSecondaryContact ? reqData.custSecondaryContact : null},
        ${reqData.clientManager ? reqData.clientManager : null}))`
            : ''
        }) `;
        const sqlForConCreate = `INSERT INTO public.wms_workorder_contacts(workorderid, contactid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary)
            ${getValuesQuery}`;
        // RETURNING workorderid`;
        console.log(sqlForConCreate, 'sqlForConCreate');

        await query(sqlForConCreate)
          .then(async resForConCreate => {
            console.log(resForConCreate, 'resForConCreate');
            // if (resForConCreate.length > 0) {
            if (resForConCreate) {
              try {
                if (reqData.kamName) {
                  const userDet = await getUserDetails(reqData?.kamName);
                  await query(`INSERT INTO public.wms_workorder_contacts (workorderid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary, userid, roleid)
                  VALUES (${resForCreate[0].workorderid},'${userDet[0].username}','${userDet[0].useremail}','${userDet[0].userphone}','${userDet[0].userphone}','KAM','Integra',true,'${reqData?.kamName}',
                  (SELECT roleid FROM public.wms_role WHERE roleacronym = 'KAM'));`);
                }

                if (
                  reqData.subDivision == 9 &&
                  (reqData.projectManager || reqData.supplierProjectManager)
                ) {
                  const journalMappedPm = await woJournalMappedPmEntry(
                    reqData,
                    resForCreate[0].workorderid,
                  );
                  console.log(journalMappedPm, 'journalMappedPm');
                }
                let externalUserRes = [];
                if (
                  reqData.externalUsers &&
                  Object.keys(reqData.externalUsers).length &&
                  reqData.externalUsers !== '{}'
                ) {
                  externalUserRes = await woExternalUserEntry(
                    reqData,
                    resForCreate[0].workorderid,
                  );
                  console.log(externalUserRes, 'externalUserRes');
                }
                const serviceRes = await woServiceEntry(
                  reqData,
                  resForCreate[0].workorderid,
                );
                console.log(serviceRes, 'serviceRes');
                if (serviceRes) {
                  // mailTrigger(reqData, resForCreate[0]);

                  // Insert Unallocated Articles and Issues
                  if (reqData.unAllocatedList?.length > 0) {
                    const result = await insertAllocatedJob(
                      resForCreate[0].workorderid,
                      reqData.unAllocatedList,
                    );
                    console.log(result, 'UnallocatedJobRes');
                  }
                  // call odoo integration while workorder create
                  if (reqData.jobType != 2 || reqData.jobType != 4) {
                    const result1 = await itracksFinancialIntegration(
                      resForCreate[0].workorderid,
                      '',
                      reqData.woType,
                      1,
                    );
                    console.log(result1, 'odooIntegrationRes');
                  }
                  res.status(200).json({
                    data: {
                      id: serviceRes,
                    },
                    message: 'WO Created successfully',
                    status: true,
                  });
                } else {
                  throw new Error('Service entry error');
                }
              } catch (error) {
                res.status(400).send({ message: error });
              }
            }
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (e) {
    console.log(e, 'wo create error');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

const woExternalUserEntry = (reqData, woId) => {
  const { externalUsers } = reqData;
  return new Promise((resove, reject) => {
    const val = [];
    externalUsers.forEach(list => {
      val.push(`(${woId},'${list.find(data => data.fieldName == 'name')?.name}',
        '${list.find(data => data.fieldName == 'email')?.email}',
         ${
           list.find(data => data.fieldName == 'phone')?.phone
             ? `${list.find(data => data.fieldName == 'phone')?.phone}`
             : null
         },
        '${list.find(data => data.fieldName == 'role')?.roleAcronym}', 
        'Customer' , false, 
        ${list.find(data => data.fieldName == 'role')?.role})`);
    });
    console.log(val, 'values for external customer');
    const sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, contactphone1, contactrole, contacttype, isprimary, roleid)
            VALUES ${val}`;
    // RETURNING contactrole,contactname,contactemail `;
    console.log(sql, 'sql for external customer');
    query(sql)
      .then(data => {
        if (data.length) {
          resove(data);
        } else {
          resove(0);
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};

const woUpdate = (reqData, res) => {
  const { articleNumber, piiNumber } = reqData;
  const otherFileds = articleNumber
    ? `{"articleno": "${articleNumber}", "pii": "${piiNumber}" }`
    : null;
  // workorder
  const sqlForCreate = `UPDATE public.wms_workorder SET itemcode =$1, title=$2, wfid=$3, printisbn=$4, eisbn=$5, issn=$6, edition=$7, isbillable=$8, customerid=$9, 
    divisionid=$10, subdivisionid=$11, countryid=$12, colorid=$13, composingsoftwareid=$14, inputfiletypeid=$15, languageid=$16, celevelid=$17, indextypeid=$18, 
    projectbrief=$19,category=$20, trimsizewidth=$21, trimsizewidthuom=$22,trimsizeheight=$23, trimsizeheightuom=$24, orderemailpath=$25, orderemailpathuuid=$26, 
    totalchaptercount=$27, totalarticlecount=$28, totalnonarticlecount=$29, issuenumber=$30, volumenumber=$31, iworkflow=$32, paperbackisbn=$34, 
    hardbackisbn=$35, ocisbn=$36, otherfield=$37,logoid=$38, dmsid=$39, complexityid = $40
    WHERE workorderid=$33 `;

  const values = [
    reqData.jobId || '',
    reqData.jobTitle || '',
    reqData.workFlow || null,
    reqData.printISBN || '',
    reqData.eISBN || '',
    reqData.ISSN || '',
    reqData.edition || '',
    reqData.isBillable,
    reqData.customer,
    reqData.division,
    reqData.subDivision,
    reqData.country,
    reqData.colours || null,
    reqData.softwares || null,
    reqData.inputFileTypes || null,
    reqData.languages || null,
    reqData.CELevel || null,
    reqData.indexType || null,
    reqData.projectBrief,
    reqData.category || null,
    reqData.pageWidth || null,
    reqData.pageWidthUnit,
    reqData.pageHeight || null,
    reqData.pageHeightUnit,
    reqData.orderEmailPath,
    reqData.orderEmailPathUuid,
    reqData.noOfChapters,
    // eslint-disable-next-line radix
    !Number.isNaN(parseInt(reqData.noOfArticles)) ? reqData.noOfArticles : null,
    // eslint-disable-next-line radix
    !Number.isNaN(parseInt(reqData.noOfNonArticles))
      ? reqData.noOfNonArticles
      : null,
    reqData.issueNumber,
    reqData.volumeNumber,
    reqData.iWorkflow,
    reqData.workorderId,
    reqData.WoPaperBackISBN,
    reqData.WoHardBackISBN,
    reqData.WoOcISBN,
    otherFileds,
    reqData.logoid || null,
    reqData.dmsid || 3,
    reqData.complexity || null,
  ];

  query(sqlForCreate, values)
    .then(() => {
      query(
        `UPDATE wms_workorder_service SET wfid = $2,complexityid = $3 WHERE workorderid = $1`,
        [
          reqData.workorderId,
          reqData.workFlow || null,
          reqData.complexity || null,
        ],
      );

      // workorder contact
      updateKAMContact(reqData);
      updateWorkorderContact(reqData, res);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const updateKAMContact = async reqData => {
  try {
    const userDet = await getUserDetails(reqData?.kamName);
    const roleId = await query(
      `SELECT roleid FROM public.wms_role WHERE roleacronym = 'KAM' AND isactive = true`,
    );
    await query(
      `UPDATE public.wms_workorder_contacts SET contactname = $3, contactemail = $4, contactphone1 = $5,
      contactphone2 = $5, userid = $6 WHERE workorderid = $1 AND contactrole = 'KAM' AND roleid = $2`,
      [
        reqData.workorderId,
        roleId[0]?.roleid,
        userDet[0]?.username,
        userDet[0]?.useremail,
        userDet[0]?.userphone,
        reqData?.kamName,
      ],
    );
  } catch (error) {
    console.log(error);
  }
};

const updateWorkorderContact = async (reqData, res) => {
  try {
    // const newUsrData = reqData.externalUsers.filter(
    //   item => item.disabled === false,
    // );

    let newUsrData = await filtercontactList(
      reqData.externalUsers,
      reqData.workorderId,
    );
    newUsrData = newUsrData.filter(item => item);
    reqData.externalUsers = newUsrData.filter(item => item);

    if (newUsrData && newUsrData.length) {
      const externalUserRes = await woExternalUserEntry(
        reqData,
        reqData.workorderId,
      );
      console.log(externalUserRes, 'update externalUserRes');
    }
    res.status(200).json({
      data: {
        id: reqData.workorderId,
      },
      message: 'WOI Updated successfully',
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// eslint-disable-next-line consistent-return
const getWODetails = async woId => {
  try {
    const sql = `SELECT wo.duid, du.duname, wo.customerid, cust.customername, wo.divisionid, divi.division,
        wo.subdivisionid, sdivi.subdivision, wo.countryid, geo.countryname 
        FROM public.wms_workorder wo
        JOIN public.org_mst_deliveryunit du ON du.duid = wo.duid AND du.isactive = true
        JOIN public.org_mst_division AS divi on divi.divisionid = wo.divisionid AND divi.isactive = true
        JOIN public.org_mst_subdivision AS sdivi on sdivi.subdivisionid = wo.subdivisionid AND sdivi.isactive = true
        JOIN public.geo_mst_country AS geo on geo.countryid = wo.countryid AND geo.isactive = true
        JOIN public.org_mst_customer AS cust on cust.customerid = wo.customerid AND cust.isactive = true
        WHERE workorderid = $1`;
    const result = await query(sql, [woId]);
    return result;
  } catch (e) {
    console.log(e);
  }
};

const filtercontactList = async (externalUsersList, woId) => {
  try {
    const script = `SELECT COUNT(*) FROM public.wms_workorder_contacts WHERE workorderid = $1 AND contactname = $2 AND 
    contactemail = $3 AND contactphone1 = $4 AND contactrole = $5 AND roleid = $6`;
    let filteredList;
    // Wrap the transaction in a Promise to handle async operations
    await transaction(async client => {
      // Use map to create an array of Promises
      const promises = externalUsersList.map(async list => {
        // Extract field values from the list
        const name = list.find(data => data.fieldName === 'name')?.value;
        const email = list.find(data => data.fieldName === 'email')?.value;
        const phone = list.find(data => data.fieldName === 'phone')?.value;
        const role = list.find(data => data.fieldName === 'role')?.roleAcronym;
        const roleId = list.find(data => data.fieldName === 'role')?.value;

        // Execute the query
        const result = await client.query(script, [
          woId,
          name,
          email,
          phone,
          role,
          roleId,
        ]);
        const count = parseInt(result.rows[0].count, 10);

        // If count is 0, return the list, otherwise return null
        return count === 0 && list;
      });

      // Wait for all Promises to resolve and filter out null results
      const results = await Promise.all(promises);
      filteredList = results.filter(item => item !== null);
    });

    return filteredList;
  } catch (error) {
    throw new Error(`Error in filtercontactList: ${error.message}`);
  }
};

export const woServiceEntry = (reqData, woId) => {
  const { duId, services, workFlow, complexity } = reqData;
  return new Promise((resove, reject) => {
    // const getDataQuery = `SELECT org_mst_customerorg_service_map.serviceid,org_mst_deliveryunit.duid, ${woId}, 'YTS' as status
    //                     FROM org_mst_customerorg_service_map
    //                     JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customerorg_service_map.custorgmapid
    //                     JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = org_mst_customerorg_du_map.duid
    //                     WHERE  org_mst_customerorg_service_map.serviceid IN (${services}) AND org_mst_customerorg_service_map.custorgmapid = ${custOrgMapId}
    //                     AND org_mst_deliveryunit.duid = ${duId}`;
    const getDataQuery = `SELECT serviceid, ${duId}, ${duId}, ${woId}, 'YTS' as status, 
    ${workFlow || null}, ${complexity || null} from public.wms_mst_service
          where serviceid IN (${services}) AND isactive= true`;
    const sql = `INSERT INTO public.wms_workorder_service(serviceid, baseduid, assignedduid, workorderid, status, wfid, complexityid)
        ${getDataQuery} RETURNING woserviceid, workorderid`;
    console.log(sql, 'sqlForServiceEntry');
    query(sql)
      .then(async serviceRes => {
        console.log(serviceRes, 'serviceRes');
        if (serviceRes.length) {
          resove(serviceRes[0].workorderid);
        } else {
          resove(false);
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};

export const getUserName = async (req, res) => {
  try {
    const { userId } = req.params;
    const script = `SELECT username FROM public.wms_user WHERE userid = $1`;
    const result = await query(script, [userId]);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const updateWOPMContacts = async (req, res) => {
  try {
    const { custOrgMapId, userId, roleAcronym, duId } = req.body;
    let result = '';
    const userDet = await query(
      `SELECT username,useremail,useraddress,userphone FROM public.wms_user WHERE userid = $1`,
      [userId],
    );
    const script = `SELECT count(*) FROM public.org_mst_customerorg_contact WHERE custorgmapid = $1 AND contactname = $2 AND contactroleid = $2`;
    const isExist = await query(script, [
      custOrgMapId,
      userDet[0].username,
      roleAcronym,
    ]);
    if (isExist[0].count == 0) {
      const insertScript = `INSERT INTO public.org_mst_customerorg_contact (custorgconmapid,custorgmapid,contactname,contactemail,
      contactaddress,contactphone1,contactphone2,isprimary,contacttype,contactroleid) VALUES
      ((select MAX(custorgconmapid)+1 from org_mst_customerorg_contact),$1,$2,$3,$4,$5,$5,$6,$7,$8)
      RETURNING custorgconmapid AS value, contactname || ' (' || $9 ||')' as label;`;
      result = await query(insertScript, [
        custOrgMapId,
        userDet[0].username,
        userDet[0].useremail,
        userDet[0].useraddress,
        userDet[0].userphone,
        true,
        'Integra',
        // 'PM',
        roleAcronym || 'PM',
        userId,
      ]);
      // } else {
      // result = await query(
      //   `SELECT custorgconmapid AS value, contactname || ' (' || $3 ||')' as label FROM public.org_mst_customerorg_contact WHERE custorgmapid = $1 AND contactname = $2 AND contactroleid = 'PM'`,
      //   [custOrgMapId, userDet[0].username, userId],
      // );
    }
    result = await getPMCMoptions(custOrgMapId, duId, roleAcronym);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// get the unique workorder detail
export const getDynamicWoDetails = (req, res) => {
  const id = req.body.workorderId;
  if (id) {
    const sql = `SELECT wo.workorderid,wo.itemcode,wo.title,wo.otherfield,wo.wfid,wo.printisbn,wo.eisbn,wo.issn,wo.edition,wo.isbillable,wo.customerid,wo.divisionid,wo.hardbackisbn as wohardbackisbn, wo.paperbackisbn as wopaperbackisbn, wo.ocisbn as woocisbn,
    wo.subdivisionid,wo.countryid,wo.trimsize,wo.colorid,wo.composingsoftwareid,wo.inputfiletypeid,wo.languageid,wo.celevelid,wo.indextypeid,
    wo.projectbrief,wo.incomingreportfilepath,wo.incomingreportfileuuid,wo.category,wo.logoid,wo.dmsid,wo.status,wo.trimsizewidth,wo.trimsizewidthuom,
    wo.trimsizeheight,wo.trimsizeheightuom,wo.orderemailpath,wo.orderemailpathuuid,wo.totalchaptercount,
    wo.completeddate,wo.ordermaildate as woordermaildate,wo.journalid,wo.jobtype,wo.doinumber,wo.newsletterdoinumber,wo.wotype,wo.totalarticlecount,
    wo.totalnonarticlecount,wo.ordermaildate as woordermaildate,wo.issuenumber,wo.volumenumber,wo.jobcardid,wo.camundaform, wo.iworkflow,wo.otherfield->>'articleno' as articleno,wo.otherfield->>'pii' as piino,
    dms_master.dmstype,
    contact.wocontactid,contact.contactname,contact.contactemail,
    contact.contactphone1,contact.contactphone2,contact.contactrole,contact.roleid,contact.contacttype,contact.isprimary,contact.userid,contact.contactid,
    cust.customerid,cust.customercode,cust.customername,cust.customertype,cust.customerid,
    div.divisionid,div.division,
    subdiv.subdivisionid,subdiv.subdivision,
    journal.journalid,journal.custorgmapid,journal.journalname,journal.journalacronym,journal.templateid,journal.printissn,journal.pmid,journal.supplierpmid,
    journal.onlineissn,journal.articletat,journal.issuetat,journal.totalissuecount,journal.budgetedcount,journal.isopenaccessarticle,
    stage.wostageid,stage.serviceid,stage.wfstageid,stage.startdate,stage.enddate,stage.ordermaildate,stage.stageiterationcount,stage.isbookcompleted,stage.ismilestone,
    additionalinfo.additionalinfoid,
	additionalinfo.pitstopprofileid,
	additionalinfo.versoid,
	additionalinfo.rectoid,
	additionalinfo.xmltemplateid,
	additionalinfo.lastpageno,
	additionalinfo.splittingid,
	additionalinfo.indexcorrectionid,
	additionalinfo.mscropneededid,
	additionalinfo.dispatchtypeid,
	additionalinfo.colorprofileid,
	additionalinfo.ocisbn,
	additionalinfo.bookcategoryid,
	additionalinfo.cssvalueid,
	additionalinfo.style1,
	additionalinfo.style2,
	additionalinfo.style3,
	additionalinfo.style4,
	additionalinfo.style5,
	additionalinfo.style6,
	additionalinfo.medicalbook,
	additionalinfo.hardbackisbn,
	additionalinfo.paperbackisbn,
    additionalinfo.watermarkid,
    additionalinfo.smartmetadataid,
    additionalinfo.dtdid,
    additionalinfo.onlinepdfid,
    additionalinfo.printid,
    additionalinfo.additionalpdfid,
    (SELECT count(workorderid) FROM wms_workorder_stage WHERE workorderid = ${id}) as isserviceadded,
    (SELECT count(workorderid) FROM wms_workorder_stage WHERE plannedstartdate IS NOT NULL AND workorderid = ${id}) as isstageadded,
    wo.currencyid
    FROM wms_workorder as wo
    LEFT JOIN wms_workorder_contacts as contact ON wo.workorderid = contact.workorderid
    LEFT JOIN org_mst_customer as cust ON wo.customerid= cust.customerid
    LEFT JOIN org_mst_division as div ON wo.divisionid= div.divisionid
    LEFT JOIN org_mst_subdivision as subdiv ON wo.subdivisionid= subdiv.subdivisionid
    LEFT JOIN pp_mst_journal as journal ON journal.journalid = wo.journalid
    LEFT JOIN wms_workorder_additionalinfo as additionalinfo on additionalinfo.workorderid = wo.workorderid
    LEFT JOIN wms_workorder_stage as stage ON stage.workorderid = ${id}
    LEFT JOIN dms_master ON dms_master.dmsid = wo.dmsid 
    WHERE wo.workorderid=${id}`;

    query(sql)
      .then(data => {
        const SqlForServiceId = `SELECT wms_mst_service.serviceid as value, wms_workorder_service.isbookcompleted, wms_mst_service.servicename as label,
        wms_workorder_service.jobnormsid, wms_workorder_service.complexityid FROM wms_workorder_service 
        JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workorder_service.serviceid
        WHERE wms_workorder_service.workorderid IN (${id}) `;
        query(SqlForServiceId)
          .then(async resForService => {
            let setObj = {};
            const additionalObj = {};
            data.forEach(list => {
              setObj.customerid = list.customerid;
              setObj.divisionid = list.divisionid;
              setObj.subdivisionid = list.subdivisionid;
              setObj.countryid = list.countryid;
              // if (list.contactid) {
              //   // last update added if contactid avoid null value for contact info page
              //   if (list.contacttype === 'Customer' && list.isprimary) {
              //     setObj.primarycontactid = list.contactid;
              //   } else if (
              //     list.contacttype === 'Customer' &&
              //     !list.isprimary &&
              //     list.contactrole !== 'PED' &&
              //     list.contactrole !== 'AUTHOR'
              //   ) {
              //     setObj.secondarycontactid = list.contactid;
              //   } else if (
              //     list.contacttype === 'Integra' &&
              //     list.contactrole === 'KAM'
              //   ) {
              //     setObj.kamcontactid = list.contactid;
              //   } else if (
              //     list.contacttype === 'Integra' &&
              //     list.contactrole === 'CM'
              //   ) {
              //     setObj.cmcontactid = list.contactid;
              //   } else if (
              //     list.contacttype === 'Integra' &&
              //     list.contactrole === 'PM'
              //   ) {
              //     setObj.pmcontactid = list.contactid;
              //   } else if (
              //     list.contacttype === 'Integra' &&
              //     list.contactrole !== 'KAM' &&
              //     list.contactrole !== 'CM' &&
              //     list.contactrole !== 'PM'
              //   ) {
              //     setObj.okcontactid = list.contactid;
              //   }
              // }
              if (list.contactrole === 'PM') {
                setObj.pmcontactid = list.contactid;
              } else if (list.contactrole === 'PMTL') {
                setObj.cmcontactid = list.contactid;
              } else if (list.contactrole === 'KAM') {
                setObj.kamcontactid = list.userid;
              }
              // if (list.contacttype === 'Customer' && list.contactid == null && list.stageiterationcount == 1) {
              //     externalUsers.push({ role: list.roleid, name: list.contactname, email: list.contactemail, phone1: list.contactphone1 });
              // }
              setObj.itemcode = list.itemcode;
              setObj.title = list.title;
              setObj.isbillable = list.isbillable;
              setObj.projectbrief = list.projectbrief;
              setObj.composingsoftwareid = list.composingsoftwareid;
              setObj.colorid = list.colorid;
              setObj.languageid = list.languageid;
              setObj.inputfiletypeid = list.inputfiletypeid;
              setObj.eisbn = list.eisbn;
              setObj.printisbn = list.printisbn;
              setObj.issn = list.issn;
              setObj.edition = list.edition;
              setObj.celevelid = list.celevelid;
              setObj.itemcode = list.itemcode;
              setObj.indextypeid = list.indextypeid;
              setObj.customername = list.customername;
              setObj.division = list.division;
              setObj.subdivision = list.subdivision;
              setObj.wfname = list.wfname;
              setObj.wfname_bpmnid = list.wfname_bpmnid;
              setObj.wfid = list.wfid;
              setObj.status = list.status;

              setObj.totalchaptercount = list.totalchaptercount;
              setObj.otherfield = list.otherfield;
              setObj.category = list.category;
              setObj.logoid = list.logoid;
              setObj.dmsid = list.dmsid;
              setObj.trimsizewidth = list.trimsizewidth;
              setObj.trimsizewidthuom = list.trimsizewidthuom;
              setObj.trimsizeheight = list.trimsizeheight;
              setObj.trimsizeheightuom = list.trimsizeheightuom;
              setObj.orderemailpath = list.orderemailpath;
              setObj.orderemailpathuuid = list.orderemailpathuuid;
              setObj.ordermaildate = list.woordermaildate;
              setObj.incomingreportfileuuid = list.incomingreportfileuuid;
              setObj.incomingreportfilepath = list.incomingreportfilepath;
              // eslint-disable-next-line radix
              setObj.isServiceAdded = !!parseInt(list.isserviceadded);
              // eslint-disable-next-line radix
              setObj.isStageAdded = !!parseInt(list.isstageadded);

              setObj.journalid = list.journalid;
              setObj.jobtype = list.jobtype;
              setObj.doinumber = list.doinumber;
              setObj.newsletterdoinumber = list.newsletterdoinumber;
              setObj.issuenumber = list.issuenumber;
              setObj.articleno = list.articleno;
              setObj.piino = list.piino;
              setObj.volumenumber = list.volumenumber;
              setObj.wotype = list.wotype;
              setObj.totalarticlecount = list.totalarticlecount;
              setObj.totalnonarticlecount = list.totalnonarticlecount;
              setObj.journalacronym = list.journalacronym;
              setObj.journalname = list.journalname;
              setObj.templateid = list.templateid;
              setObj.jobcardid = list.jobcardid;
              setObj.camundaform = list.camundaform;
              setObj.iworkflow = list.iworkflow;
              setObj.wfid = list.wfid;
              setObj.camundaform = list.camundaform;
              setObj.WoHardBackISBN = list.wohardbackisbn;
              setObj.WoPaperBackISBN = list.wopaperbackisbn;
              setObj.WoOcISBN = list.woocisbn;
              setObj.dmstype = list.dmstype;
              setObj.currencyid = list.currencyid;

              additionalObj.additionalinfoid = list.additionalinfoid;
              additionalObj.pitstopprofileid = list.pitstopprofileid;
              additionalObj.versoid = list.versoid;
              additionalObj.rectoid = list.rectoid;
              additionalObj.xmltemplateid = list.xmltemplateid;
              additionalObj.lastpageno = list.lastpageno;
              additionalObj.splittingid = list.splittingid;
              additionalObj.indexcorrectionid = list.indexcorrectionid;
              additionalObj.mscropneededid = list.mscropneededid;
              additionalObj.dispatchtypeid = list.dispatchtypeid;
              additionalObj.colorprofileid = list.colorprofileid;
              additionalObj.ocisbn = list.ocisbn;
              additionalObj.bookcategoryid = list.bookcategoryid;
              additionalObj.cssvalue = list.cssvalueid;
              additionalObj.style1 = list.style1;
              additionalObj.style2 = list.style2;
              additionalObj.style3 = list.style3;
              additionalObj.style4 = list.style4;
              additionalObj.style5 = list.style5;
              additionalObj.style6 = list.style6;
              additionalObj.medicalbook = list.medicalbook;
              additionalObj.hardbackisbn = list.hardbackisbn;
              additionalObj.paperbackisbn = list.paperbackisbn;
              additionalObj.watermarkid = list.watermarkid;
              additionalObj.smartmetadataid = list.smartmetadataid;
              additionalObj.dtdid = list.dtdid;
              additionalObj.onlinepdf = list.onlinepdfid;
              additionalObj.print = list.printid;
              additionalObj.addpdf = list.additionalpdfid;
            });

            setObj.jobnormsId = !!(
              resForService.length && resForService[0].jobnormsid
            );
            if (resForService.length && resForService[0].complexityid) {
              const getJobnorms = await getWOJobnormsDetails(
                resForService[0].complexityid,
              );
              setObj = { ...setObj, ...getJobnorms, ...additionalObj };
            } else {
              setObj = { ...setObj, ...additionalObj };
            }

            setObj.wfcategory = resForService.length
              ? resForService[0].wfcategory
              : '';
            setObj.wfconfig = resForService.length
              ? resForService[0].wfconfig
              : '';
            setObj.externalUsers = await getExternalUsers(id);
            setObj.serviceid = resForService;
            // setObj.wfid = resForService.length ? resForService[0].wfid : '';
            setObj.isbookcompleted = resForService.length
              ? resForService[0].isbookcompleted
              : false;
            setObj.checkWoChapterEntry = await checkWoChapterEntry(
              id,
              'chapter',
            );
            setObj.checkWoArticleEntry = await checkWoChapterEntry(
              id,
              'article',
            );
            setObj.checkWoNonArtcileEntry = await checkWoChapterEntry(
              id,
              'nonArticle',
            );
            console.log(setObj, 'setvaluesss');
            res.status(200).json({ data: setObj });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(200).json({ data: {} });
  }
};
// lockjob
export const getUnallocatedArticlesandIssues = async (req, res) => {
  try {
    const { journalId, jobType } = req.body;
    const script = `SELECT w.workorderid AS value, w.itemcode AS label FROM public.wms_workorder w 
        WHERE coalesce(w.islock,false) = false and w.workorderid NOT IN (SELECT iw.issueworkorderid FROM public.wms_issue_workorder iw
        JOIN public.wms_workorder w ON w.workorderid = iw.issueworkorderid AND w.isactive=true
        JOIN public.pp_mst_journal j ON w.journalid = j.journalid AND j.isactive=1
        WHERE j.journalid = $1) AND w.journalid = $1 AND w.jobtype = $2;`;
    const result = await query(script, [journalId, jobType]);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// eslint-disable-next-line consistent-return
export const insertAllocatedJob = async (workorderId, unallocatedJobId) => {
  await transaction(client => {
    return new Promise(async (tresolve, treject) => {
      try {
        let result = '';
        const script = `INSERT INTO public.wms_issue_workorder (issueworkorderid,articleworkorderid) VALUES ($1,$2)`;
        unallocatedJobId.forEach(async jobId => {
          result = await client.query(script, [jobId, workorderId]);
        });
        tresolve(result);
      } catch (error) {
        treject(error);
      }
    });
  });
};

export const getPMCMList = async (req, res) => {
  try {
    const { duId, roleAcronym } = req.body;
    const script = `SELECT u.userid,u.username,r.rolename,r.roleacronym,u.duid FROM public.wms_user u
      JOIN public.wms_userrole ur ON ur.userid = u.userid AND ur.isactive = true
      JOIN public.wms_role r ON r.roleid = ur.roleid AND r.roleacronym = $2 AND r.isactive = true
      JOIN public.org_mst_deliveryunit d ON d.duid = u.duid
      WHERE d.duid = $1;`;
    const result = await query(script, [duId, roleAcronym]);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getPMCMoptions = async (req, res) => {
  try {
    const { custOrgMapId, duId, roleAcronym } = req.body;
    const result = await query(
      `SELECT DISTINCT c.custorgconmapid AS value, c.contactname || ' (' || u.userid ||')' as label
        FROM public.org_mst_customerorg_contact c
        JOIN public.wms_user u ON u.username = c.contactname AND (u.duid = $2 OR $2 = ANY(u.mappedduid))
        WHERE c.custorgmapid = $1 AND c.contactroleid = $3;`,
      [custOrgMapId, duId, roleAcronym],
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getKAMOptions = async (req, res) => {
  try {
    const { duId, customerId, divisionId, verticalName, countryId } = req.body;
    const result = await query(
      `SELECT DISTINCT kam.kamempcode AS value, u.username || ' (' || kam.kamempcode || ')' AS label
       FROM salespmo.trn_kamcustomerrel kam
       JOIN public.org_mst_deliveryunit d ON d.duid = $1 AND d.isactive = true
       JOIN public.org_mst_customer c ON c.customerid = $2 AND c.isactive = true
       JOIN public.wms_mst_vertical v ON v.verticalname = $4 AND v.isactive = true
       JOIN public.wms_user u ON u.userid = kam.kamempcode
       WHERE kam.duid = d.itrackduid AND kam.customerid = c.itrack_customerid AND kam.divisionid = $3 
       AND kam.countryid = $5 AND kam.verticalid = v.verticalid`,
      [duId, customerId, divisionId, verticalName, countryId],
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// eslint-disable-next-line consistent-return
export const getUserDetails = async userId => {
  try {
    const userDet = await query(
      'SELECT * FROM public.wms_user WHERE userid = $1',
      [userId],
    );
    return userDet;
  } catch (err) {
    console.log(err);
  }
};
