import { query } from '../../database/postgres.js';
import { sendMail } from '../filetransferkit/proofcentral.js';

export const getQueryBuilderOptions = (req, res) => {
  const getData = req.body;
  let sql = '';

  /*
    SELECT stagelist.stagename||'('||stagelist.stageiterationcount||')' as stagename,stagelist.wostageid,stagelist.status,stagelist.wfstageid,stagelist.serviceid,stagelist.servicename, wms_workorder_service.wfid, wms_workflow.wfname, wms_workflow.wfcategory FROM public.wms_wo_stagelist stagelist
        join wms_workorder_service on wms_workorder_service.serviceid = stagelist.serviceid and 
	  wms_workorder_service.workorderid = stagelist.workorderid
        join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
        WHERE stagelist.workorderid=${woId} order by stagelist.wfstageid
        */
  if (getData.type === 'service') {
    sql = `SELECT  wms_workorder_stage.serviceid as value ,
    wms_mst_service.servicename as label
   FROM wms_workorder_stage
     JOIN wms_mst_stage ON wms_workorder_stage.wfstageid = wms_mst_stage.stageid
     JOIN wms_mst_service ON wms_workorder_stage.serviceid = wms_mst_service.serviceid
     JOIN wms_workorder_service ON wms_workorder_service.serviceid = wms_workorder_stage.serviceid
         JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder_service.assignedduid
    where wms_workorder_stage.workorderid = ${getData.woId} group by wms_workorder_stage.serviceid,
   wms_mst_service.servicename`;
  } else if (getData.type === 'stage') {
    sql = `SELECT DISTINCT ON (wms_workorder_stage.wfstageid)
    concat(wms_mst_stage.stagename, ' (', wms_workorder_stage.stageiterationcount, ')') AS label,
    wms_workorder_stage.wfstageid AS value,
    wms_workorder_stage.stageiterationcount
FROM wms_workorder_stage
JOIN wms_mst_stage ON wms_workorder_stage.wfstageid = wms_mst_stage.stageid
JOIN wms_mst_service ON wms_workorder_stage.serviceid = wms_mst_service.serviceid
JOIN wms_workorder_service ON wms_workorder_service.serviceid = wms_workorder_stage.serviceid
JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder_service.assignedduid
where wms_workorder_stage.workorderid = ${getData.woId}
ORDER BY wms_workorder_stage.wfstageid, wms_workorder_stage.stageiterationcount DESC`;
    // sql = `SELECT DISTINCT ON( stage.stageid) stage.stageid as value, (concat(stage.stagename, ' (', eventlog.stageiterationcount, ')')) as label FROM public.wms_workflow_eventlog as eventlog
    // join wms_workflowdefinition as wfdef on wfdef.wfdefid = eventlog.wfdefid
    // join wms_mst_stage as stage on stage.stageid = wfdef.stageid
    // where eventlog.workorderid = ${getData.woId}`
  } else if (getData.type === 'classification') {
    sql = `select queryclassificationid as value, classificationname as label from wms_mst_query_classification`;
  } else if (getData.type === 'assignTo') {
    sql = `SELECT  skillid as value, skillname as label FROM public.wms_mst_skill`;
  } else if (getData.type === 'status') {
    sql = `SELECT  status as label, querystatusid as value FROM public.wms_mst_query_status`;
  }
  console.log(sql, 'sqlforToolOption');
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getQueryListforDespatch = async (req, res) => {
  const reqData = req.body;
  try {
    let sql = '';
    sql = `SELECT * FROM wms_workorder_query_list as list
        WHERE list.workorderid = ${reqData.woId} `;
    const response = await query(sql);
    res.status(200).send({ data: response, status: true });
  } catch (e) {
    console.log(e);
    res.status(400).send({ message: e, data: [], status: false });
  }
};

export const getLastActivityForQueryCheck = async (req, res) => {
  const reqData = req.body;
  try {
    let sql = '';
    sql = `SELECT * FROM wms_workflowdefinition as workflow
        WHERE workflow.wfid = ${reqData.wfId}  and workflow.stageid = ${reqData.stageId} order by sequence`;
    const response = await query(sql);
    let completiontrigger = false;

    const fileterddata = response.filter(list => list.activityid == 21);
    completiontrigger = fileterddata.length > 0;
    let lastActivity = '';
    if (completiontrigger) {
      lastActivity = response[response.length - 2].wfdefid;
    } else {
      lastActivity = response[response.length - 1].wfdefid;
    }
    res.status(200).send({ data: lastActivity, status: true });
  } catch (e) {
    console.log(e);
    res.status(400).send({ message: e, data: [], status: false });
  }
};

export const queryInsertion = (req, res) => {
  const getData = req.body;
  const list = getData.queryList;
  console.log(getData, 'getdataaaa');
  let sql = '';
  const val = [];
  const val1 = [];
  if (getData.type == 'Workorder') {
    val.push(
      `(${list.du},${list.woId},${list.service},${list.stage},${
        list.stageItertaion
      },${list.activityId ? list.activityId : 'null'},${
        list.activityIteration ? list.activityIteration : 'null'
      },${list.fileName ? `'${list.fileName} '` : 'null'},${
        list.classification
      },1,'${list.createdBy}',current_timestamp,null,'${list.subject}',${
        list.wfeventid ? list.wfeventid : 'null'
      })`,
    );
  }
  console.log(val, 'vallllalauee');
  sql = `INSERT INTO public.wms_query( duid, workorderid, serviceid, stageid, stageiterationcount, activityid, activityiterationcount, filename, classificationid, querystatusid, createdby, createdon, updatedon, subject,wfeventid)
    VALUES ${val} RETURNING queryid;`;
  console.log(sql, 'insertforquery');
  query(sql)
    .then(data => {
      const dataobj = {};
      dataobj.queryid = data[0].queryid;
      dataobj.message = 'Query Inserted Successfully';
      const escapedDescription = list.description.replace(/'/g, "''");
      val1.push(
        `(${data[0].queryid},'${escapedDescription}',1,'${list.createdBy}',current_timestamp)`,
      );
      console.log(val1, 'val11');
      const insertHistory = `INSERT INTO public.wms_query_history(queryid, description, querystatusid, createdby, createdon)
            VALUES ${val1} RETURNING queryhistoryid;`;
      console.log(insertHistory, 'insertHistoryinsertHistory');
      query(insertHistory)
        .then(async response => {
          dataobj.queryhistoryid = response[0].queryhistoryid;
          const val2 = [];
          list.assignTo.forEach(assig => {
            val2.push(`(${data[0].queryid},${assig})`);
          });
          sql = `INSERT INTO public.wms_query_assigned(queryid, skillid)
            VALUES ${val2}`;
          await query(sql)
            .then(() => {
              res.status(200).json({ data: dataobj, status: true });
            })
            .catch(error => {
              res.status(400).send({ message: error, status: false, data: [] });
            });
          if (
            list.classification == '4' &&
            list.du == '5' &&
            list.activityId == '30'
          ) {
            const reqMailData = {
              duId: Number(list.du),
              entityId: 60,
              services: `${list.service}`,
            };
            const wfconfdata = {
              workorderid: Number(list.woId),
              wfid: list.wfeventid,
              customerid: 6,
            };
            sendMail(
              reqMailData,
              wfconfdata,
              `${list.description}`,
              'cv_errForSkipApproval',
            );
          }
          // list.assignTo.map((data1) => {
          //     let insertskill = `INSERT INTO public.wms_query_assigned(queryid, skillid)
          //         VALUES (${data[0].queryid},${data1})`
          //     console.log(insertskill, "insertskill")
          //     query(insertskill).then((response1) => {
          //     })
          //     res.status(200).json({ data: dataobj, status: true });
          // }).catch((error) => {
          //     res.status(400).send({ message: error, status: false, data: [] });
          // });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const queryFile = (req, res) => {
  const { queryhistoryid, path, repofileuuid } = req.body;
  const sql = `INSERT INTO public.wms_query_files(
        queryhistoryid, filepath, fileuuid)
       VALUES ( ${queryhistoryid}, '${path}', '${repofileuuid}')`;
  console.log(sql, 'insertingfile');
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ data: 'Query Inserted Successfully', status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getQueryList = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });

    sql = `SELECT COUNT(*) FROM wms_workorder_query_list as list
        WHERE list.workorderid = ${reqData.woId} ${
      condition ? `AND${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM wms_workorder_query_list as list
        WHERE list.workorderid = ${reqData.woId} ${
      condition ? `AND${condition}` : condition
    }`;
  }

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sql1 = `SELECT * FROM wms_workorder_query_list as list
             WHERE list.workorderid = ${reqData.woId} ${
          condition ? `AND${condition}` : condition
        } LIMIT ${recordPerPage} OFFSET ${offset}`;
        console.log(sql1, 'sqlforquerryy');
        query(sql1)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ status: false, data: [] });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getQueryHistory = async (req, res) => {
  console.log('Req data for get query history');
  const reqData = req.body;
  let sql = `select status.status,concat(users.username, ' (', wms_query.createdby, ')') AS raisedby,wms_query.*, omd.duname, wms.servicename from wms_query join wms_mst_query_status status on status.querystatusid=wms_query.querystatusid LEFT
    JOIN wms_user users ON users.userid::text = wms_query.createdby::text 
    LEFT JOIN org_mst_deliveryunit omd ON	omd.duid = wms_query.duid 
    LEFT JOIN wms_mst_service wms ON wms.serviceid = wms_query.serviceid where queryid=${reqData.queryId}`;
  const finalData = {};
  await query(sql)
    .then(async queryData => {
      finalData.queryData = queryData;
      if (queryData.length) {
        sql = `select status.status,wms_query_history.*,concat(users.username, ' (', wms_query_history.createdby, ')') AS raisedby from wms_query_history join wms_mst_query_status status on status.querystatusid=wms_query_history.querystatusid
            left JOIN wms_user users ON users.userid::text = wms_query_history.createdby::text where queryid=${reqData.queryId}  order by wms_query_history.createdon asc`;
        await query(sql)
          .then(async historyData => {
            historyData.map(async (hd, index) => {
              sql = `select * from wms_query_files where queryhistoryid=${hd.queryhistoryid}`;
              console.log('yuvaraj', sql);
              await query(sql).then(fileData => {
                hd.file = fileData;
              });
              if (historyData.length - 1 === index) {
                finalData.historyData = historyData;
                sql = `select skill.skillname as label,skill.skillid as value,assigned.* from wms_query_assigned assigned join wms_mst_skill skill on skill.skillid=assigned.skillid where queryid=${reqData.queryId}`;
                await query(sql).then(async assignedData => {
                  finalData.assignedData = assignedData;
                  res.status(200).send({ data: finalData, status: true });
                });
              }
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, data: [], status: false });
          });
      } else {
        res.status(200).send({ data: finalData, status: true });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, data: [], status: false });
    });
};
export const postReply = async (req, res) => {
  const {
    replyDesc,
    createdBy,
    status,
    assigned,
    uploadedFileDetails,
    queryId,
  } = req.body;
  let sql = `update wms_query set querystatusid=${status},updatedon=current_timestamp where queryid=${queryId}`;
  try {
    console.log(sql);
    await query(sql);
    const val = [];
    val.push(
      `(${queryId},'${replyDesc}',${status},'${createdBy}',current_timestamp)`,
    );
    sql = `INSERT INTO public.wms_query_history(queryid, description, querystatusid, createdby, createdon)
        VALUES ${val} RETURNING queryhistoryid;`;
    console.log(sql);
    const historyData = await query(sql);
    console.log(historyData);
    if (uploadedFileDetails.length) {
      const val1 = [];
      uploadedFileDetails.forEach(uf => {
        val1.push(
          `( ${historyData[0].queryhistoryid}, '${uf.path}', '${uf.uuid}')`,
        );
      });
      sql = `INSERT INTO public.wms_query_files(queryhistoryid, filepath, fileuuid) VALUES ${val1}`;
      console.log(sql);
      await query(sql);
    }
    if (assigned.length) {
      sql = `delete from wms_query_assigned where queryid=${queryId}`;
      await query(sql);
      const val2 = [];
      assigned.forEach(assig => {
        val2.push(`(${queryId},${assig.value})`);
      });
      sql = `INSERT INTO public.wms_query_assigned(queryid, skillid)
            VALUES ${val2}`;
      await query(sql);
    }
    res
      .status(200)
      .send({ data: 'Reply has been posted sucessfully', status: true });
  } catch (error) {
    console.log(error);
    res.status(400).send({ message: error, data: [], status: false });
  }
};

export const getGraphicsQueries = async (req, res) => {
  try {
    const {
      workorderid,
      stageid,
      activityid,
      wfeventid,
      files = [],
    } = req.body;

    if (
      !workorderid ||
      !stageid ||
      !activityid ||
      !wfeventid ||
      !Array.isArray(files) ||
      files.length === 0
    ) {
      return res
        .status(400)
        .send({ message: 'Missing input', status: false, data: [] });
    }

    const sql = `
      SELECT filename, query, isactive
      FROM trn_graphicsqueries 
      WHERE isactive = true 
        AND workorderid = $1
        AND stageid = $2
        AND activityid = $3
        AND wfeventid = $4
        AND filename = ANY($5::text[])
    `;
    const dbRows = await query(sql, [
      workorderid,
      stageid,
      activityid,
      wfeventid,
      files,
    ]);

    const dbMap = Object.fromEntries(dbRows.map(row => [row.filename, row]));

    const result = files.map(
      filename =>
        dbMap[filename] || {
          filename,
          query: '',
          isactive: false,
        },
    );

    return res.status(200).json({ data: result, status: true });
  } catch (error) {
    return res.status(400).send({ message: error, status: false, data: [] });
  }
};

export const postGraphicsQueries = async (req, res) => {
  try {
    const {
      workorderid,
      stageid,
      activityid,
      files = [],
      userid,
      wfeventid,
    } = req.body;

    if (!workorderid || !stageid || !activityid || !userid) {
      return res
        .status(400)
        .send({ message: 'Missing input', status: false, data: [] });
    }

    await query(
      `UPDATE trn_graphicsqueries SET isactive = false, updatedon = current_timestamp, updatedby = $5 
       WHERE isactive = true AND workorderid = $1 AND stageid = $2 AND activityid = $3 AND wfeventid = $4`,
      [workorderid, stageid, activityid, wfeventid, userid],
    );
    if (files.length > 0) {
      const values = [];
      const params = [];
      let paramIndex = 1;
      for (const { filename, query: queryText } of files) {
        values.push(
          `($${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++})`,
        );
        params.push(
          workorderid,
          stageid,
          activityid,
          wfeventid,
          filename,
          queryText.trim(),
          userid,
        );
      }
      const insertSql = `
      INSERT INTO trn_graphicsqueries (workorderid, stageid, activityid, wfeventid, filename, query, createdby)
      VALUES ${values.join(', ')}
      `;
      await query(insertSql, params);
    }

    return res
      .status(200)
      .json({ status: true, message: 'Graphics query updated successfully' });
  } catch (error) {
    return res.status(400).send({ message: error, status: false, data: [] });
  }
};
