import fs, { createReadStream } from 'fs';
import moment from 'moment';
import download from 'download';
import FormData from 'form-data';
import ejs from 'ejs';
import { query } from '../../database/postgres.js';
import { emitAction } from '../activityListener/index.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import * as azureHelper from '../utils/azure/index.js';

const service = new Service();

export const getDynamicColumns = (req, res) => {
  const { entityId, roleid, skillid, screenId, userid } = req.body;
  let entityIdArray = '';
  if (entityId instanceof Array) {
    entityIdArray = entityId;
  } else {
    entityIdArray = [entityId];
  }
  const condition = `entityid = any($1) AND ( userid = $2 OR (roleid = $3 AND (skillid = any($4) OR skillid IS NULL))) AND screenid = $5`;
  const sql = `SELECT *,filterValues as defaultFilterValues FROM public.wms_viewconfig_details WHERE ${condition} ORDER BY viewid ASC `;
  query(sql, [entityIdArray, userid, roleid, skillid, screenId])
    .then(data => {
      console.log('dataaa', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJournalDetail = async data => {
  const { journalshortname, customershortname } = data;
  return new Promise(async resolve => {
    const sql = `SELECT * from public.getjournaldetail('${journalshortname}', '${customershortname}')`;
    query(sql)
      .then(response => {
        console.log(response);
        if (response && response.length) {
          if (response[0].j && response[0].j.length) {
            resolve(response[0].j);
          } else {
            resolve({ error: 'Journal data not found in new wms' });
          }
        } else {
          resolve({ error: 'Journal data not found in new wms' });
        }
      })
      .catch(() => {
        resolve({ error: 'Journal data not found in new wms' });
      });
  });
};

export const getNotificationConfig = (data, action) => {
  return new Promise(async resolve => {
    try {
      const { entityId, workorderId, serviceId, customerId, duId, wfeventId } =
        data;
      let sql = '';
      if (
        action != 'create' &&
        action != 'iterate/next' &&
        action != 'onlineproof' &&
        action != 'notify_production' &&
        action != 'auto_create_success' &&
        action != 'auto_create_failure' &&
        action != 'auto_stage_trigger_success' &&
        action != 'auto_stage_trigger_failure' &&
        action != 'save_pm' &&
        action != 'common_failure'
      ) {
        sql = `
                    SELECT wmc.isprimary ,wo.workorderid,wmc.contactid,wmc.contactname,wmc.contactemail,wmc.contactrole,wo.itemcode,oms.customername,
                    wo.totalchaptercount, wo.printisbn, wo.totalarticlecount, wo.totalnonarticlecount,
                    wo.wotype, wo.jobtype, wo.doinumber, du.duname, wmc.contacttype, wo.title, journal.journalname,journal.journalacronym,wo.doinumber,
                    wif.filename, wo.issuenumber, wo.volumenumber FROM wms_workorder as wo
                    JOIN wms_workorder_contacts wmc ON wmc.workorderid = wo.workorderid
                    JOIN org_mst_customer as oms ON oms.customerid = wo.customerid
                    JOIN wms_workflow_eventlog as wfel ON wfel.workorderid = wo.workorderid
				left JOIN wms_workorder_incomingfiledetails as wif ON wif.woincomingfileid = wfel.woincomingfileid
                    JOIN org_mst_deliveryunit as du ON du.duid = ${duId}
                    left  JOIN pp_mst_journal as journal ON journal.journalid = wo.journalid
                    WHERE wo.workorderid = ${workorderId} AND wmc.contactrole IN ('PM','SPM','AUTHOR','CO-AUTHOR','PED') ${
          wfeventId ? `AND wfel.wfeventid = ${wfeventId}` : ''
        }
                   `;
      } else if (
        action === 'auto_create_success' ||
        action === 'auto_create_failure' ||
        action === 'auto_stage_trigger_success' ||
        action === 'save_pm' ||
        action === 'auto_stage_trigger_failure'
      ) {
        sql = `SELECT * from wms_notifications WHERE customerid= ${customerId} and action='${action}'`;
      } else if (action == 'common_failure') {
        sql = `SELECT * from wms_notifications WHERE customerid= ${customerId} and action='${action}'`;
      } else {
        sql = `SELECT wmc.isprimary ,wo.workorderid,wmc.contactid,wmc.contactname,wmc.contactemail,wmc.contactrole,wo.itemcode,oms.customername,
                    notif.notificationconfig, notif.type,wo.totalchaptercount, wo.printisbn, wo.totalarticlecount, wo.totalnonarticlecount,
                    wo.wotype, wo.jobtype, wo.doinumber, du.duname, wmc.contacttype, wo.title, journal.journalname, journal.journalacronym, wo.issuenumber, wo.volumenumber ,
                    journal.journalemail
                    FROM wms_workorder as wo
                    JOIN wms_workorder_contacts wmc ON wmc.workorderid = wo.workorderid
                    JOIN org_mst_customer as oms ON oms.customerid = wo.customerid
                    JOIN wms_notifications as notif ON notif.customerid = wo.customerid
                    LEFT JOIN pp_mst_journal as journal ON journal.journalid = wo.journalid
                    JOIN org_mst_deliveryunit as du ON du.duid = ${duId}
                    WHERE wo.workorderid = ${workorderId} AND notif.entityid = ${entityId}
                    AND wmc.contactrole IN ('PM','SPM','AUTHOR') AND notif.action = '${action}' `;
      }

      query(sql).then(resForConfig => {
        if (resForConfig.length > 0 && action == 'common_failure') {
          resolve(resForConfig);
        } else if (resForConfig.length > 0) {
          if (serviceId) {
            sql = `SELECT servicename FROM wms_mst_service WHERE serviceid IN(${serviceId})`;
            query(sql).then(resForServices => {
              let services = '';
              if (resForServices && resForServices.length) {
                resForServices.forEach((item, i) => {
                  services +=
                    resForServices.length - 1 != i
                      ? `${item.servicename}, `
                      : item.servicename;
                });
              }
              resForConfig.forEach(item => {
                item.services = services;
              });
              resolve(resForConfig);
            });
          } else {
            resolve(resForConfig);
          }
        } else {
          resolve(false);
        }
      });
    } catch (e) {
      resolve(false);
    }
  });
};

export const getWorkflowConfig = (data, action) => {
  const {
    duId,
    entityId,
    workorderId,
    serviceId,
    wfdefid,
    stageName,
    stageDuedate,
    iteration,
    stageId,
    wfeventId,
    userName,
    lstArticle,
    issueName,
  } = data;
  return new Promise(async resolve => {
    try {
      const sql = `SELECT config FROM wms_workflowdefinition WHERE wfdefid = ${wfdefid}`;

      query(sql).then(async resForWfConfig => {
        if (resForWfConfig.length > 0) {
          const getObj = resForWfConfig[0];
          console.log(
            getObj.config.actions.workflow[action].capture,
            'getObj.config.actions.workflow[action].capture',
          );
          const { email, emailConfig, emailtemplate } =
            getObj.config.actions.workflow[action].capture;

          if (email === true) {
            let template;
            let subject;
            let from;
            let to;
            let cc;
            let bcc;
            if (emailConfig) {
              ({ template, subject, from, to, cc, bcc } = emailConfig);
            } else if (emailtemplate && emailtemplate != 'undefined') {
              if (!emailtemplate) {
                resolve(false);
                return;
              }
              const templateSql = `SELECT notificationconfig FROM wms_notifications WHERE notificationid = ${emailtemplate}`;

              const templateRes = await query(templateSql);
              if (templateRes.length > 0) {
                const emailConfigFromDB = templateRes[0].notificationconfig;
                ({ template, subject, from, to, cc, bcc } = emailConfigFromDB);
              } else {
                resolve(false);
                return;
              }
            } else {
              resolve(false);
              return;
            }

            const payload = {
              entityId,
              workorderId,
              serviceId,
              duId,
              wfeventId,
            };
            const resForConfig = await getNotificationConfig(payload, action);
            if (resForConfig.length > 0) {
              const pmI = resForConfig.findIndex(
                val => val.contactrole === 'PM' && val.isprimary,
              );

              const spmI = resForConfig.findIndex(
                val => val.contactrole === 'SPM' && !val.isprimary,
              );

              const authorI = resForConfig.findIndex(
                val =>
                  val.contactrole === 'AUTHOR' &&
                  val.contacttype === 'Customer',
              );

              const {
                workorderid,
                customername,
                duname,
                itemcode,
                services,
                totalchaptercount,
                printisbn,
                totalarticlecount,
                totalnonarticlecount,
                wotype,
                jobtype,
                title,
                journalname,
                doinumber,
                journalacronym,
                filename,
                issuenumber,
                volumenumber,
              } = resForConfig[0];
              const mailObj = {};
              if (pmI != -1) {
                console.log('inside pm');
                mailObj.toPm = resForConfig[pmI].contactemail;
              }
              if (spmI != -1) {
                console.log('inside spm');
                mailObj.toSpm = resForConfig[spmI].contactemail;
              }
              if (authorI != -1) {
                console.log('inside spm');
                mailObj.toAuthor = resForConfig[authorI].contactemail;
              }
              const fromArray = [];
              const toMailArray = [];
              const ccMailArray = [];
              const bccMailArray = [];
              if (Array.isArray(from)) {
                from.forEach(item => {
                  if (mailObj[item]) {
                    fromArray.push(mailObj[item]);
                  } else {
                    fromArray.push(item);
                  }
                });
              } else {
                fromArray.push(from);
              }

              to.forEach(item => {
                if (mailObj[item]) {
                  toMailArray.push(mailObj[item]);
                } else {
                  toMailArray.push(item);
                }
              });
              cc.forEach(item => {
                if (mailObj[item]) {
                  ccMailArray.push(mailObj[item]);
                } else {
                  ccMailArray.push(item);
                }
              });
              bcc.forEach(item => {
                if (mailObj[item]) {
                  bccMailArray.push(mailObj[item]);
                } else {
                  bccMailArray.push(item);
                }
              });
              console.log(toMailArray, 'toMailArray');
              console.log(ccMailArray, 'toMailArray');
              console.log(bccMailArray, 'toMailArray');
              const payld = {
                actionType: 'mail',
                date: moment(new Date()).format('DD-MM-YYYY'),
                workorderId: workorderid,
                noOfChapter: totalchaptercount,
                noOfArticle: totalarticlecount,
                noOfNonArticle: totalnonarticlecount,
                printIsbn: printisbn,
                woType: wotype,
                jobType: jobtype,
                service: services,
                doiNumber: doinumber,
                jobId: itemcode,
                jobName: title,
                journalAcronym: journalacronym,
                journalName: journalname,
                customerName: customername,
                duName: duname,
                pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
                spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
                spmMail:
                  authorI != -1 ? resForConfig[authorI].contactemail : '',
                authorName:
                  authorI != -1 ? resForConfig[authorI].contactname : '',
                tlName: 'TL',
                stageName,
                iteration,
                stageDuedate: moment(stageDuedate).format('DD-MM-YYYY'),
                from: fromArray,
                toMail: toMailArray,
                cc: ccMailArray,
                bcc: bccMailArray,
                subject,
                template,
                serviceId,
                stageId,
                stageIterationCount: iteration,
                wfDefId: wfdefid,
                mailType: 'workflow',
                fileName: filename,
                issueNumber: issuenumber,
                volumeNumber: volumenumber,
                issueName,
                lstArticle,
                Getdate: moment(new Date()).format('DD-MM-YYYY'),
                userName,
                issueRecDate: moment(stageDuedate).format('DD-MM-YYYY'),
                iTrackStageId: stageId,
                issueDueDate: moment(stageDuedate).format('DD-MM-YYYY'),
              };

              emitAction(payld);
              resolve(true);
            } else {
              resolve(false);
            }
          } else {
            resolve(false);
          }
        } else {
          resolve(false);
        }
      });
    } catch (e) {
      resolve(false);
    }
  });
};

export const createReportView = (client, data) => {
  const { wfeventId, userId, uomValue, duId } = data;
  return new Promise(async resolve => {
    try {
      const now = new Date();
      const then = new Date(data.timestamp);
      const hour = moment
        .utc(
          moment(now, 'DD/MM/YYYY HH:mm:ss').diff(
            moment(then, 'DD/MM/YYYY HH:mm:ss'),
          ),
        )
        .format('HH:mm:ss');

      const sql = `SELECT taskreportid, totaltime, uomvalue FROM wms_task_report_view WHERE wfeventid =$1 and userid=$2`;
      const { rows } = await client.query(sql, [wfeventId, userId]);

      if (rows.length > 0) {
        let newHour = '';
        if (rows[0].totaltime) {
          const a = moment.duration(rows[0].totaltime);
          const b = moment.duration(hour);
          const c = a.add(b);
          newHour = `${c.hours()}:${c.minutes()}:${c.seconds()}`;
        }

        const totalUom = rows[0].uomvalue
          ? parseInt(rows[0].uomvalue) + parseInt(uomValue || 0)
          : parseInt(uomValue || 0);

        const sqlQuery = `UPDATE public.wms_task_report_view SET uomvalue =$1, totaltime=$2 WHERE taskreportid=$3 `;
        client
          .query(sqlQuery, [totalUom, newHour, rows[0].taskreportid])
          .then(() => {
            resolve(true);
          });
      } else {
        const uom = uomValue ? parseInt(uomValue) : 0;
        const getValueSql = `SELECT DISTINCT ON (incoming.woincomingfileid)
                    wms_user.duid,wms_user.userid,wms_user.username,eventlog.workorderid,workorder.itemcode,
                    service.servicename,stage.stagename,activity.activityname,
                    COALESCE(incoming.filename,'All Chapters') as filename,
                    skill.skillname,skilllevel.skilllevel,${uom}, '${hour}', current_timestamp,
                    eventlog.wfeventid, eventlog.stageiterationcount, eventlog.actualactivitycount, wfdef.activityalias
                    FROM wms_workorder workorder
                    JOIN wms_workflow_eventlog eventlog ON eventlog.workorderid = workorder.workorderid
                    LEFT JOIN wms_workorder_incomingfiledetails incoming ON incoming.woincomingfileid = eventlog.woincomingfileid
                    JOIN wms_workflowdefinition wfdef ON eventlog.wfdefid = wfdef.wfdefid
                    JOIN wms_mst_service service ON service.serviceid = eventlog.serviceid
                    JOIN wms_mst_stage stage ON stage.stageid = wfdef.stageid
                    JOIN wms_mst_activity activity ON activity.activityid = wfdef.activityid
                    JOIN wms_mst_skill skill ON skill.skillid = eventlog.skillid
                    JOIN wms_userskill userskill ON userskill.skillid = eventlog.skillid AND userskill.userid::text = eventlog.userid::text
                    LEFT JOIN wms_mst_skilllevel skilllevel ON skilllevel.skilllevelid = userskill.skillelvelid
                    JOIN wms_workflow_eventlog_details eventdetails ON eventdetails.wfeventid = eventlog.wfeventid
                    JOIN wms_user ON wms_user.userid = eventlog.userid
                    WHERE wms_user.duid = ${duId} AND wms_user.userid = '${userId}' AND eventlog.wfeventid = ${wfeventId}
                    `;

        const sqlQuery = `INSERT INTO public.wms_task_report_view(duid, userid, username, workorderid,
                         itemcode, servicename, stagename, activityname, filename, skillname, skilllevel, uomvalue,
                         totaltime, updatedon, wfeventid, stageiterationcount, activityiterationcount, activityalias )
                    ${getValueSql}`;

        client.query(sqlQuery).then(() => {
          resolve(true);
        });
      }
    } catch (e) {
      resolve(false);
    }
  });
};
export const emailAudit = (req, res) => {
  // logger.info("Failure Email Audit==>", req.body)
  const { mailData, errorMsg = null, status = null } = req.body;
  const {
    subject = null,
    workorderId = null,
    serviceId = null,
    stageId = null,
    stageIterationCount = null,
    wfDefId = null,
    mailType = null,
  } = mailData;
  // console.log('yuvarajmlmlml', mailData.template.toString().replace(/'/g, '#$'))
  const tempMailData = mailData.template.toString().replace(/'/g, '#$');
  mailData.template = tempMailData;
  const wfeventid = mailData && mailData.wfeventId ? mailData.wfeventId : null;

  let sql = `INSERT INTO public.wms_email_audit(workorderid, serviceid, stageid, stageiterationcount, wfdefid, "timestamp", status,wfeventid) 
     VALUES (${workorderId},${serviceId},${stageId},${stageIterationCount},${wfDefId},current_timestamp,'${status}',${wfeventid}) RETURNING *`;

  query(sql, [])
    .then(data => {
      const { emailauditid } = data[0];

      sql = `INSERT INTO public.wms_email_audit_history( emailauditid, mailtype, paylod, errorlog, "timestamp", status, subject)
      VALUES ( ${emailauditid},'${mailType}','${mailData}','${errorMsg}', current_timestamp,'${status}', '${subject}');`;
      query(sql, [])
        .then(rest => {
          res.status(200).json({ data: rest });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const pkgDepositTrigger = async (reqData, wfData) => {
  return new Promise(async (resolve, reject) => {
    try {
      const authPaylod = {
        userId: process.env.EMDEPOSIT_USR,
        password: process.env.EMDEPOSIT_PWD,
      };
      const pkgDepositAuth = await service.post(
        `${config.pkgDepositApi.base_url}${config.pkgDepositApi.uri.deposit_auth}`,
        authPaylod,
        {},
      );

      let authToken = '';
      if (
        pkgDepositAuth.data &&
        pkgDepositAuth.data.entry &&
        pkgDepositAuth.data.entry.id
      ) {
        authToken = Buffer.from(pkgDepositAuth.data.entry.id).toString(
          'base64',
        );
        console.log(authToken, 'api deposit_ticket');
      }
      const formData = new FormData();
      const headers = {
        Authorization: `Basic ${authToken}`,
      };
      const pkgFileuuid = reqData.uuid;
      const pkgFileName = reqData.name;
      let pkgPath;
      switch (wfData.dmsType) {
        case 'azure':
          const azureDownload = await azureHelper._download(reqData.path);
          pkgPath = azureDownload.data.path;
          break;
        default:
          pkgPath =
            config.openKM.base_url + config.openKM.uri.viewFile + pkgFileuuid;
          break;
      }
      // -----------------START UPLOAD CHECK WITH OKM---------------------//
      // let okmpathh = { "type": "okm_common" }
      // let okmPath = await getFolderStructure(okmpathh, []);
      // formData.append('content', createReadStream(`uploads/` + pkgFileName));
      // formData.append('docPath', okmPath);
      // const header = {
      //   'Content-Type': 'multipart/form-data; boundary=' + formData._boundary
      // };
      //  const response = await service.upload(`${config.openKM.base_url}${config.openKM.uri.upload}`, formData , header);
      //  console.log(response);
      // -----------------END UPLOAD CHECK WITH OKM---------------------//
      await download(pkgPath, `uploads`);
      formData.append('filedata', createReadStream(`uploads/${pkgFileName}`));
      const depositResp = await service.post(
        `${config.pkgDepositApi.base_url}${config.pkgDepositApi.uri.pre_pub}`,
        formData,
        headers,
      );
      // const depositResp = await service.post(`www.test.com/${config.pkgDepositApi.uri.pre_pub}`, formData , headers);

      console.log(depositResp, 'depositResp');
      if (depositResp) {
        const apiDepositRes = await contentDepositAPIAudit(
          depositResp,
          wfData,
          pkgFileName,
          'success',
        );
        resolve(apiDepositRes);
      } else {
        const apiDepositRes = await contentDepositAPIAudit(
          depositResp,
          wfData,
          pkgFileName,
          'failed',
        );
        resolve(apiDepositRes);
      }
      fs.unlink(`uploads/${pkgFileName}`, function (err) {
        if (err) reject(err);
      });
    } catch (error) {
      await contentDepositAPIAudit(
        {
          status: error.status,
          message: `Package upload Api failed${error.message}`,
        },
        wfData,
        reqData.name,
        'failed',
      );
      reject({
        status: error.status,
        message: `Package upload Api failed${error.message}`,
      });
    }
  });
};
export const triggerTrackItAPI = async (req, res) => {
  try {
    console.log(req.body, 'req from external-task on trackit');

    const result = await getAuthAccessWorflow(req.body);
    console.log(result, 'resultforacesssstype');
    if (result) {
      res.status(200).send({ data: result });
    } else {
      res.status(400).send({ data: 'Trackit audit entry failed' });
    }
  } catch (error) {
    res
      .status(400)
      .send({ status: error.status, message: 'Trackit API failed' });
  }
};

export const getAuthAccessWorflow = data => {
  const { doi, stage, details, source, runNumber, result, username, password } =
    data;

  const payload = {
    doi,
    stage,
    details,
    source,
    runNumber,
    result,
    dateTime: moment(new Date()).format('YYYYMMDDhhmmss'),
    username,
    password,
  };
  data.jsonData = payload;
  console.log(payload, 'req data for API');

  return new Promise(async resolve => {
    // let username = process.env.TRACKIT_USERNAME;
    // let password = process.env.TRACKIT_PASSWORD;
    // const auth = Buffer.from(username + ":" + password).toString("base64");
    // console.log(auth, "authththh")
    // const headers = {
    //      "Authorization": `Basic ${auth}`
    // }
    const headers = {};

    const url = config.trackletApi.base_url;

    try {
      const response = await service.post(`${url}`, payload, headers);

      const rest = {
        status: response.status,
        statusCode: response.data && response.data.statusCode,
        message: response.data,
      };
      if (rest.statusCode == '200') {
        const trackItRes = await tractItAPIAudit(data, 'success');
        resolve(trackItRes);
      } else {
        const trackItRes = await tractItAPIAudit(data, 'failed');
        resolve(trackItRes);
      }
    } catch (error) {
      const trackItRes = await tractItAPIAudit(data, 'failed');
      resolve(trackItRes);
    }
  });
};

// this function will insert the tractit API audit
export const tractItAPIAudit = (data, status) => {
  const {
    jsonData,
    workorderId,
    serviceId,
    stageId,
    stageIterationCount,
    stage,
  } = data;

  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO public.wms_trackit_api_audit(apiaction, workorderid, serviceid, stageid, stageiterationcount, payload, timestamp, status)
               VALUES ( '${stage}', ${workorderId}, ${serviceId}, ${stageId}, ${stageIterationCount}, '${JSON.stringify(
      jsonData,
    )}', current_timestamp, '${status}')`;

    query(sql, [])
      .then(() => {
        resolve(true);
      })
      .catch(() => {
        reject(false);
      });
  });
};
// this function will insert the content Deposit API audit
export const contentDepositAPIAudit = async (
  data,
  wfdata,
  filename,
  status,
) => {
  return new Promise((resolve, reject) => {
    try {
      const { workorderId, serviceId, stageId, stageIterationCount } = wfdata;

      const sql = `INSERT INTO public.wms_contentdeposit_api_audit(apiaction, workorderid,filename, serviceid, stageid, stageiterationcount, payload, timestamp, status)
               VALUES ( 'apiDeposit', ${workorderId}, '${filename}', ${serviceId}, ${stageId}, ${stageIterationCount}, '${JSON.stringify(
        data,
      )}', current_timestamp, '${status}')`;

      query(sql, [])
        .then(() => {
          resolve(true);
        })
        .catch(() => {
          reject(false);
        });
    } catch (err) {
      console.log(err);
    }
  });
};
// ///camunda performence testing API.
// const startInstance = async (variables, wfKey, userid) => {
//      return new Promise(async (resolve, reject) => {
//      let returnvalue;
//      try {
//           let triggerResponse;
//           let triggerUserTask;
//           let triggerExternalTask;

//           triggerResponse = await service.post(`http://172.16.200.181:8080/engine-rest/process-definition/key/${wfKey}/start`, variables);
//           console.log(triggerResponse, "sfjsdfjsd")
//           triggerUserTask = await service.get(`http://172.16.200.181:8080/engine-rest/task?processInstanceId=${triggerResponse.data.id}`);
//           triggerExternalTask = await service.get(`http://172.16.200.181:8080/engine-rest/external-task?processInstanceId=${triggerResponse.data.id}`)
//           console.log(triggerUserTask, triggerExternalTask, "triggerUserTask");
//           var BookCompleted = false
//           while ((triggerUserTask && triggerExternalTask &&  Object.keys(triggerUserTask).length > 0  && triggerUserTask.data && triggerUserTask.data.length > 0) || (Object.keys(triggerExternalTask).length > 0 && triggerExternalTask.data && triggerExternalTask.data.length > 0)) {
//                if (triggerUserTask && Object.keys(triggerUserTask).length > 0 &&  triggerUserTask.data && triggerUserTask.data.length > 0) {
//                     for (var i = 0; i < triggerUserTask.data.length; i++) {
//                          var calimResult = await claimTask(triggerUserTask.data[i].id, userid);
//                          console.log(calimResult, "calimResult");
//                          if (calimResult && Object.keys(calimResult).length > 0) {
//                               var completePayload = { taskId: triggerUserTask.data[i].id, variables: {} }
//                               var completeResponse = await completeTask(completePayload)
//                               if (completeResponse && Object.keys(completeResponse).length > 0) {
//                                    if(triggerUserTask.data[i].name == 'Completion Trigger'){
//                                         BookCompleted = true
//                                    }
//                                    triggerUserTask = await service.get(`http://172.16.200.181:8080/engine-rest/task?processInstanceId=${triggerResponse.data.id}`);
//                                    triggerExternalTask = await service.get(`http://172.16.200.181:8080/engine-rest/external-task?processInstanceId=${triggerResponse.data.id}`)

//                               }
//                          }

//                     }
//                     if(BookCompleted){
//                          triggerBatchCompletion(triggerResponse.data.id)
//                     }
//                }
//                console.log(triggerExternalTask, "triggerExternalTask")
//                if (triggerExternalTask && Object.keys(triggerExternalTask).length > 0 && triggerExternalTask.data && triggerExternalTask.data.length > 0) {
//                     for (var i = 0; i < triggerExternalTask.data.length; i++) {
//                          let lockPaylod = {
//                               topicName: triggerExternalTask.data[i].topicName,
//                               processInstanceId: triggerExternalTask.data[i].processInstanceId,
//                               activityId: triggerExternalTask.data[i].activityId,
//                               "workerId": "System"
//                          }
//                          let lockPayload2 = {
//                               "lockDuration": 36000000,
//                               "workerId": "System"
//                          }
//                          var LockResult = await LockExternalTask(triggerExternalTask.data[0].id, lockPayload2);
//                          console.log(LockResult, "LockResult");
//                          if (LockResult && Object.keys(LockResult).length > 0) {
//                               await CompleteExternalTask(triggerExternalTask.data[0].id, lockPaylod);
//                               triggerExternalTask = await service.get(`http://172.16.200.181:8080/engine-rest/external-task?processInstanceId=${triggerResponse.data.id}`)
//                               triggerUserTask = await service.get(`http://172.16.200.181:8080/engine-rest/task?processInstanceId=${triggerResponse.data.id}`);

//                          }
//                     }
//                }
//           }

//           if(('data' in triggerUserTask &&  !triggerUserTask.data.length ) && ('data' in triggerExternalTask &&  !triggerExternalTask.data.length ) ){
//                console.log("Instance Completed");
//                returnvalue ='completed';
//                resolve(returnvalue)

//           }

//      }
//      catch (e) {
//           reject(e);
//           console.log(e, 'error occured')
//      }
// })
// }
// const claimTask = async (taskInstanceId, userid) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let data = { id: taskInstanceId, userId: userid };
//                let claimData = await service.post('http://172.16.200.197:8085/claimtask', data);
//                console.log(claimData, "claimDataclaimData")
//                resolve(claimData)
//           }
//           catch (e) {
//                reject(e)
//                console.log(e, "error in claim task")
//           }
//      })

// }

// const LockExternalTask = async (taskInstanceId, lockPaylod) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let LockData = await service.post(`http://172.16.200.181:8080/engine-rest/external-task/${taskInstanceId}/lock/`, lockPaylod);
//                console.log(LockData, "LockData")
//                resolve(LockData)
//           }
//           catch (e) {
//                reject(e)
//                console.log(e, "error in claim task")
//           }
//      })

// }

// const CompleteExternalTask = async (taskInstanceId, lockPaylod) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let CompleteExternalData = await service.post(`http://172.16.200.181:8080/engine-rest/external-task/${taskInstanceId}/complete`, lockPaylod);
//                console.log(CompleteExternalData, "CompleteExternalData")
//                resolve(CompleteExternalData)
//           }
//           catch (e) {
//                reject(e)
//                console.log(e, "error in claim task")
//           }
//      })

// }

// const unclaimTask = async (taskInstanceId, userid) => {
//      try {
//           let data = { id: taskInstanceId, userId: userid };
//           await service.post('http://172.16.200.197:8085/unclaimtask', data);
//      } catch (e) {
//           console.log(e)
//      }

// }

// const completeTask = async (payload) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let completeData = await service.post('http://172.16.200.197:8085/commonCompleteTask', payload);
//                console.log(completeData, "completedata")
//                resolve(completeData)
//           } catch (e) {
//                reject(e)
//                console.log(e, "complete task error")
//           }
//      })

// }

// export const CamundaAPI = async (req, res) => {
//      let variables = req.body.variables;

//      let promises = [];
//      let start = moment().format('hh:mm:ss');
//      console.log(start, 'start time');

//      for(var i=1; i <= 50; i++) {
//           let userid = i+1;
//           promises.push(startInstance(variables, req.body.wfKey, userid));
//      }

//      Promise.all(promises).then((result) => {
//           console.log(result, 'result');
//           let end = moment().format('hh:mm:ss');
//           console.log(end, 'end time');
//           res.status(200).json({ data: {start, end }});

//      }).catch((e) => {
//           console.log(e, 'failed');
//      });

// }

// let startInstances = await startInstance(variables, req.body.wfKey, userid);
// console.log(startInstances, "startInstancesstartInstances")
// if(startInstances == 'completed'){
//      res.status(200).json({ data: startInstances });
// }

export const getRoleBasedMail = async role => {
  const mails = await query(
    `SELECT ud.useremail
    FROM public.wms_user_details ud
    LEFT JOIN public.wms_userrole ur ON ur.userid = ud.userid
    LEFT JOIN public.wms_role r ON r.roleid = ur.roleid
    WHERE r.roleacronym = $1
    GROUP BY ud.useremail`,
    [role],
  );
  return mails.map(emailObj => emailObj.useremail);
};

export const getUserMail = async userid => {
  const mails = await query(
    `SELECT ud.useremail
    FROM public.wms_user_details ud
    WHERE ud.userid = $1`,
    [userid],
  );
  return mails.map(emailObj => emailObj.useremail);
};

export const getConversionFactor = woid => {
  const script = `select j.conversionfactor from public.wms_workorder wo
  join public.pp_mst_journal j on j.journalid = wo.journalid
  where wo.workorderid = $1`;
  const result = query(script, [woid]);
  return result;
};

export const updateEstimatedValue = async (req, res) => {
  try {
    const { stageId, woId, pagecount } = req.body;
    const cf = await getConversionFactor(woId);
    if (
      cf != undefined &&
      cf.length > 0 &&
      cf[0]?.conversionfactor != null &&
      Number(cf[0]?.conversionfactor) != 0
    ) {
      const estimatedvalue =
        Number(cf[0]?.conversionfactor) * Number(pagecount);
      const roundedValue = Math.round(estimatedvalue);
      const script = `update  public.wms_workorder_stage set estimatedpages = $3
    where wfstageid=$1 and workorderid=$2`;
      query(script, [stageId, woId, roundedValue])
        .then(async data => {
          await updateMspage(stageId, woId, pagecount);
          res.status(200).json({ status: true, data });
        })
        .catch(error => {
          res
            .status(400)
            // .send({ message: error.message ? error.message : error });
            .send({
              message: `Estimated page calculation failed.`,
              errormsg: error,
            });
        });
    } else if (cf.length && Number(cf[0]?.conversionfactor) === 0) {
      res.status(400).send({
        message: `Estimated Page Calculation failed: Conversion factor cannot be zero in journal master.`,
      });
    } else {
      res.status(400).send({
        message:
          'Estimated Page Calculation failed: Conversionfactor is not found in journal master',
      });
    }
  } catch (e) {
    res.status(400).send({ message: 'Failed to update the mspage' });
  }
};
export const getNextStage = async (woId, stageId) => {
  const script = `select wostageid,workorderid,wfstageid, LEAD(wfstageid, 1) OVER (ORDER BY sequence) next_stageid, 
  typesetpages ,enddatetime,stageiterationcount from wms_workorder_stage 
  where workorderid = $1
  order by workorderid ,sequence`;
  const result = await query(script, [woId]);
  if (result.length > 0) {
    const stageid = result.filter(
      row => Number(row.wfstageid) === Number(stageId),
    );
    return stageid[0].next_stageid;
  }
  return 0;
};

export const getMspage = async (woId, stageId) => {
  const script = `select wid.mspages,wid.woincomingfileid from public.wms_workorder_incoming wi
  left join public.wms_workorder_incomingfiledetails wid on wi.woincomingid=wid.woincomingid 
  where wi.woid=$1 and wi.stageid=$2 limit 1`;
  const result = await query(script, [woId, stageId]);
  return result;
};

export const getPreStageTypeset = async (stageId, woId) => {
  return new Promise(async resolve => {
    const sql = `SELECT wostageid, workorderid, wfstageid, 
                        LAG(typesetpages, 1) OVER (ORDER BY sequence) AS prev_typesetpage, 
                        LAG(estimatedpages, 1) OVER (ORDER BY sequence) AS prev_estimatedpages, 
                        typesetpages, enddatetime, stageiterationcount,estimatedpages 
                 FROM wms_workorder_stage 
                 WHERE workorderid = $1 --AND wfstageid = $2 
                 ORDER BY workorderid, sequence`;

    try {
      const response = await query(sql, [woId]);
      if (response && response.length) {
        const stageid = response.filter(
          row => Number(row.wfstageid) === Number(stageId),
        );
        resolve(
          stageid.length && stageid[0].prev_typesetpage === null
            ? stageid[0].prev_estimatedpages
            : stageid[0].prev_typesetpage,
        );
      } else {
        resolve(null); // Resolve with null if no data found
      }
    } catch (error) {
      resolve(null); // Resolve with null in case of error
    }
  });
};

export const calculateEstimatedPage = (stageId, woId) => {
  return new Promise(async resolve => {
    try {
      const nextStage = await getNextStage(woId, stageId);
      // const mspage = await getMspage(woId);
      const typeset = await getPreStageTypeset(nextStage, woId);
      if (
        // mspage != undefined &&
        // mspage.length > 0 &&
        // mspage[0]?.mspages != null &&
        typeset != undefined &&
        typeset != null &&
        Number(nextStage) != 0
      ) {
        const estimatedvalue = Number(typeset);
        const script = `update public.wms_workorder_stage set estimatedpages = $3
      where wfstageid=$1 and workorderid=$2`;
        await query(script, [nextStage, woId, estimatedvalue])
          .then(response => {
            if (response) {
              resolve(true);
            } else {
              resolve(true);
            }
          })
          .catch(() => {
            resolve(true);
          });
      } else {
        resolve(true);
      }
    } catch (e) {
      resolve(true);
    }
  });
};

export const updateMspage = async (stageId, woId, pagecount) => {
  return new Promise(async resolve => {
    try {
      const id = await getMspage(woId, stageId);
      if (id != undefined && id.length > 0 && id[0]?.woincomingfileid != null) {
        const script = `update public.wms_workorder_incomingfiledetails set mspages = $2
        where woincomingfileid=$1`;
        await query(script, [id[0]?.woincomingfileid, pagecount]);
      }
      resolve(true);
    } catch (e) {
      resolve(true);
    }
  });
};
// get the notification template
export const getNotificationTemplate = (data, action) => {
  return new Promise(async resolve => {
    try {
      const { customerId, woTypeId } = data;
      let sql = '';
      if (
        action === 'common_failure' ||
        action === 'job_receive_success' ||
        action === 'job_receive_failure' ||
        action === 'auto_create_failure' ||
        action === 'auto_create_success' ||
        action === 'auto_create_success_no_package'
      ) {
        sql = `SELECT * from wms_notifications WHERE customerid= ${customerId} and action='${action}' and jobflowtypeid=${woTypeId}`;
      } else {
        sql = `SELECT * FROM wms_notifications WHERE action = '${action}'`;
        if (woTypeId !== undefined) {
          sql += ` AND jobflowtypeid = ${woTypeId}`;
        } else {
          sql += ` AND jobflowtypeid IS NULL`;
        }
      }

      const response = await query(sql);
      resolve(response);
    } catch (e) {
      resolve(false);
    }
  });
};

export const commontriggerMailWithAction = async (req, res) => {
  try {
    const result = await _triggerMailWithAction(req.body);
    return res
      .status(200)
      .json({ status: result, message: 'Mail sent successfully' });
  } catch (error) {
    console.error('Mail trigger failed:', error);
    return res.status(400).send({
      message: `Mail trigger failed: ${error.message} || ${JSON.stringify(
        error,
      )}`,
    });
  }
};

export const triggerMailWithAction = async (req, res) => {
  try {
    const result = await _triggerMailWithAction(req);
    return res
      .status(200)
      .json({ status: result, message: 'Mail sent successfully' });
  } catch (error) {
    console.error('Mail trigger failed:', error);
    return res.status(400).send({
      message: `Mail trigger failed: ${error.message} || ${JSON.stringify(
        error,
      )}`,
    });
  }
};

export const _triggerMailWithAction = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { from = null, to = [], cc = [], bcc = [], data, action } = payload;
      const mailTemp = await getNotificationTemplate({}, action);
      if (mailTemp.length !== 1) {
        throw new Error(
          mailTemp.length === 0
            ? 'No mail template found.'
            : 'More than one mail template found.',
        );
      }

      const notificationConfig = mailTemp[0]?.notificationconfig;

      notificationConfig.from =
        from || notificationConfig.from || 'iwmssupport@integra.co.in';

      // Helper Function
      const appendRecipients = async (field, newRecipients = []) => {
        if (newRecipients.length) {
          notificationConfig[field] = [
            ...new Set([...notificationConfig[field], ...newRecipients]),
          ];
        }
      };

      // Helper Function
      const getUniqueRecipients = async (toArr, ccArr, bccArr) => {
        const allRecipients = [...toArr, ...ccArr, ...bccArr];
        const uniqueRecipients = [...new Set(allRecipients)];

        const filterRecipients = (arr, exclude) =>
          arr.filter(email => !exclude.includes(email));

        const uniqueTo = uniqueRecipients.filter(email =>
          toArr.includes(email),
        );
        const uniqueCc = filterRecipients(
          uniqueRecipients.filter(email => ccArr.includes(email)),
          toArr,
        );
        const uniqueBcc = filterRecipients(
          uniqueRecipients.filter(email => bccArr.includes(email)),
          [...toArr, ...ccArr],
        );

        return { uniqueTo, uniqueCc, uniqueBcc };
      };

      // Helper Function
      const renderEmailContent = async (mailConfig, maildata) => {
        const [subject, content] = await Promise.all([
          ejs.render(mailConfig.subject, { data: maildata }),
          ejs.render(mailConfig.template, { data: maildata }),
        ]);
        return { subject, content };
      };

      // Append recipients
      await appendRecipients('to', to);
      await appendRecipients('cc', cc);
      await appendRecipients('bcc', bcc);

      // Get unique recipients after appending
      const { uniqueTo, uniqueCc, uniqueBcc } = await getUniqueRecipients(
        notificationConfig.to,
        notificationConfig.cc,
        notificationConfig.bcc,
      );
      notificationConfig.to = uniqueTo;
      notificationConfig.cc = uniqueCc;
      notificationConfig.bcc = uniqueBcc;

      // Render Mail content
      const { subject, content } = await renderEmailContent(
        notificationConfig,
        data,
      );

      // Update the notificationConfig with rendered subject and content
      notificationConfig.subject = subject;
      notificationConfig.template = content;

      // Emit the action to send the email
      await emitAction(notificationConfig);

      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
