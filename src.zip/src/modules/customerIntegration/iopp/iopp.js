import { basename } from 'path';
import { IoppAPIService } from './ioppApiIntegration.js';
import { config } from '../../../config/restApi.js';
import { getCurrentiAuthorLink } from '../../utils/tools/index.js';
import * as azureHelper from '../../utils/azure/index.js';
import * as localHelper from '../../utils/local/index.js';
import { getdmsType } from '../../bpmn/listener/create.js';
import { query } from '../../../database/postgres.js';

export const IOPPLanguageEditUpdate = async (req, res) => {
  const { workOrderId, stage, service } = req.body;
  try {
    let sql = `select  COALESCE(d.typesetpages,0) as typesetpages, 
        a.otherfield ->>'articleno' as articleno, 
        doinumber as articlename,
        title as articletitle,
        b.isiauthor, 
        b.iauthworkflowid,
        a.wotype, 
        b.journalacronym, 
        b.journalname,
        c.score as nlpTrack,
        d.stageiterationcount 
            from wms_workorder a 
            join public.pp_mst_journal b on a.journalid=b.journalid 
            join public.wms_workorder_Stage d on d.workorderid=a.workorderid
            left join public.inlp_transactions c on d.workorderid=c.workorderid and d.wfstageid = c.stageid
            where a.workorderid=${workOrderId} and d.wfstageid=${stage.id} and c.serviceid=${service.id}`;
    const mstJournal = await query(sql);
    if (mstJournal.length == 0) {
      throw new Error(`invalid workorderid : ${workOrderId}`);
    }
    sql = `Select incf.filename from public.wms_workorder_incoming as inc
        left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
        where woid=${workOrderId}`;
    const Filename = await query(sql);
    const data = {
      articleName: Filename,
      stage: stage.name,
      nlpTrack: mstJournal[0].nlpTrack,
      journalAcronym: mstJournal[0].journalacronym,
    };
    const _iopp = new IoppAPIService(data);
    await _iopp
      .IOPPStageUpdateProcess(data)
      .then(result => {
        res.status(200).send(result);
      })
      .catch(error => {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};

export const IOPPStatusUpdate = async (req, res) => {
  const { workOrderId, stage, service, eventId } = req.body;
  try {
    const dmsType = await getdmsType(workOrderId);
    let sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
        where wfeventid=${eventId}`;
    const eventDetails = await query(sql);
    if (eventDetails.length == 0) {
      throw new Error(`File mapping missing for workorderid : ${eventId}`);
    }
    sql = `select  COALESCE(d.typesetpages,0) as typesetpages, 
            a.otherfield ->>'articleno' as articleno, 
            doinumber as articlename,
            title as articletitle,
            b.isiauthor, 
            b.iauthworkflowid,
            a.wotype, 
            b.journalacronym, 
            b.journalname,
            c.score as nlpTrack,
            c.guid as nlpGuid,
            d.stageiterationcount 
                from wms_workorder a 
                join public.pp_mst_journal b on a.journalid=b.journalid 
                join public.wms_workorder_Stage d on d.workorderid=a.workorderid
                left join public.inlp_transactions c on d.workorderid=c.workorderid and d.wfstageid = c.stageid
                where a.workorderid=${workOrderId} and d.wfstageid=${stage.id}`;
    const mstJournal = await query(sql);
    if (mstJournal.length == 0) {
      throw new Error(`invalid workorderid : ${workOrderId}`);
    }
    sql = `Select incf.filename from public.wms_workorder_incoming as inc
        left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
        where woid=${workOrderId}`;
    const Filename = await query(sql);
    // const _iopp = new ioppAPIService().IOPPStageUpdateProcess(data);
    const data = {
      articleName: Filename[0].filename,
      stage: stage.name,
      journalAcronym: mstJournal[0].journalacronym,
      ActualFiles: [],
      SupplementFiles: [],
    };
    const _iopp = new IoppAPIService(data);
    if (stage.name == 'Structure_PreEditing' || stage.name == 'FromAuthor') {
      sql = `select guid from public.iauthor_transactions where 
            stageiterationcount = ${stage.iteration}
            and serviceid=${service.id} and stageid=${stage.id}
            and workorderid=${workOrderId}`;
      const iAuthorGuid = await query(sql);
      if (iAuthorGuid.length > 0) {
        const iauthorURL = await getCurrentiAuthorLink(iAuthorGuid[0].guid);
        if (iauthorURL.is_success == true) {
          data.iAuthorURL = iauthorURL.data;
        } else {
          throw new Error(data.message);
        }
      }
    }
    sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                where wfeventid =${eventId} and isactive=true`;
    let Files = await query(sql);
    Files.forEach(element => {
      element.FileName = basename(element.repofilepath);
    });
    for (let index = 0; index < Files.length; index++) {
      const element = Files[index];
      switch (dmsType) {
        case 'azure':
          const out = await azureHelper._download(element.repofilepath);
          data.SupplementFiles.push({
            url: out.data.path,
            fileName: element.FileName,
          });
          break;
        case 'local':
          const out1 = await localHelper._localdownload(element.repofilepath);
          data.SupplementFiles.push({
            url: out1.data.path,
            fileName: element.FileName,
          });
          break;
        default:
          data.SupplementFiles.push({
            url:
              config.openKM.base_out_url +
              config.openKM.uri.download +
              element.repofileuuid,
            fileName: element.FileName,
          });
          break;
      }
    }
    for (let index = 0; index < _iopp.stageInput.Files.length; index++) {
      const element = _iopp.stageInput.Files[index];
      const file = Files.filter(
        x => x.FileName.toLocaleLowerCase() == element.toLocaleLowerCase(),
      );
      Files = Files.filter(
        x => x.FileName.toLocaleLowerCase() != element.toLocaleLowerCase(),
      );
      if (file.length > 0) {
        switch (dmsType) {
          case 'azure':
            const out = await azureHelper._download(file[0].repofilepath);
            data.ActualFiles.push({
              url: out.data.path,
              fileName: element,
            });
            break;
          case 'local':
            const out1 = await localHelper._localdownload(file[0].repofilepath);
            data.ActualFiles.push({
              url: out1.data.path,
              fileName: element,
            });
            break;
          default:
            data.ActualFiles.push({
              url:
                config.openKM.base_out_url +
                config.openKM.uri.download +
                file[0].repofileuuid,
              fileName: element,
            });
            break;
        }
      }
    }
    await _iopp
      .IOPPStageUpdateProcess(data)
      .then(result => {
        res.status(200).send({ is_success: true, message: result.message });
      })
      .catch(error => {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};
