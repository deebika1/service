import axios from 'axios';
import {
  uploadFileToSFTP,
  getsftpConfig,
} from '../../filetransferkit/index.js';

export class IoppAPIService {
  constructor(data) {
    this.inlpTrackStages = {
      A: {
        languageEditMethod: 'autocomplete',
        languageEditTask: 'In-House Edit',
      },
      B: {
        languageEditMethod: 'manual',
        languageEditTask: 'In-House Edit',
      },
      C: {
        languageEditMethod: 'manual',
        languageEditTask: 'Freelance Edit',
      },
    };
    this.ioppAPICredentials = {
      Token:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImlBdXRob3IiLCJwYXNzd29yZCI6ImlhdXRob3JsaXZlIn0.arMB_-8fDVP4CE81BiUr7i3_vIiSQhHhRql39j4sqjQ',
      ProtanApiUsrName: 'iAuthor',
      ProtanApiPassword: 'iauthorlive',
    };
    this.ioppApiURL = {
      LanguageEdit:
        'https://staging.mpstrak-service.mpstechnologies.com/mpstrak-service/rest/languageedit',
      TaskStatus:
        'https://staging-mpstrak-service-taskstatus.mpstechnologies.com/mpstrak-service-taskStatus/rest/article/taskStatus/Articleid=',
      ProtonCall:
        'https://staging.mpstrak-service.mpstechnologies.com/mpstrak-service/rest/digiedit',
    };
    this.stageInputs = {
      Structure_PreEditing: {
        OnlyUpload: false,
        TaskName: 'Structure & Pre-Edit',
        Files: ['<<articleid>>.docx', '<<articleid>>.pdf'],
        FtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/Pre-EditedSource/',
          'Signals/',
      },
      'First Proof': {
        OnlyUpload: false,
        TaskName: 'Composition',
        Files: ['<<articleid>>.pdf'],
        FtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/Proof/',
          'Signals/',
      },
      Revises: {
        OnlyUpload: false,
        TaskName: 'Composition',
        Files: ['<<articleid>>.pdf'],
        FtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/Proof/',
          'Signals/',
      },
      'From Author': {
        OnlyUpload: false,
        TaskName: 'Author Proof',
        Files: ['<<articleid>>.pdf', '<<articleid>>.html'],
        FtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/AuthorCorrections/',
          'Signals/',
        SupplementFtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/ReplacementFiles/',
          'Signals/',
      },
      'From PE': {
        OnlyUpload: false,
        TaskName: 'In-House Proofread',
        Files: ['<<articleid>>.pdf', '<<articleid>>.html'],
        FtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/CorrectedProof/',
          'Signals/',
        SupplementFtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/ReplacementFiles/',
          'Signals/',
      },
      'From Copyeditor': {
        OnlyUpload: true,
        FtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/EditedSource/',
          'Signals/',
        SupplementFtpPath:
          // 'Content Management/bookname/Article_Content/<<articleid>>/ReplacementFiles/',
          'Signals/',
        Files: ['<<articleid>>.pdf', '<<articleid>>.html'],
      },
    };
    this.inlpTrackStage = {};
    this.stageInput = {};
    this.ftpDetails = {};
    this.inlpTrackStage = this.inlpTrackStages[data.nlpTrack || ''];
    this.stageInput = this.stageInputs[data.stage];
    this.uploadFileToSFTP = uploadFileToSFTP;
    this.getsftpConfig = getsftpConfig;
    if (this.stageInput.Files) {
      this.stageInput.Files = this.stageInput.Files.map(ele =>
        ele.replace('<<articleid>>', data.articleName),
      );
    }
    if (this.stageInput.FtpPath)
      this.stageInput.FtpPath = this.stageInput.FtpPath.replace(
        '<<articleid>>',
        data.articleName,
      );
    if (this.stageInput.SupplementFtpPath)
      this.stageInput.SupplementFtpPath =
        this.stageInput.SupplementFtpPath.replace(
          '<<articleid>>',
          data.articleName,
        );
  }

  IOPPStageUpdateProcess(data) {
    return new Promise(async (resolve, reject) => {
      try {
        if (this.inlpTrackStage) {
          await this.callIOPPLanguageEditUpdate(data);
        } else {
          // let CurrentIOPPStage = await this.getTaskStatus(data.articleName);
          // if (CurrentIOPPStage != this.stageInput.TaskName && this.stageInput.OnlyUpload == false) {
          //     throw new Error(`Current IOPP Stage is ${CurrentIOPPStage}, but trying to update ${this.stageInput.TaskName}`);
          // }
          const getftpConfig = await this.getsftpConfig('iopp_file_dispatch');
          if (this.stageInput.FtpPath)
            if (data.ActualFiles == undefined) {
              throw new Error('ActualFiles not provided.');
            }
          for (let index = 0; index < data.ActualFiles.length; index++) {
            const element = data.ActualFiles[index];
            const uploadRemark = await this.uploadFileToSFTP(
              element.url,
              getftpConfig,
              this.stageInput.FtpPath,
              element.fileName,
            );
            console.log(uploadRemark);
          }
          if (this.stageInput.SupplementFtpPath)
            if (data.SupplementFiles)
              for (
                let index = 0;
                index < data.SupplementFiles.length;
                index++
              ) {
                const element = data.SupplementFiles[index];
                await this.uploadFileToSFTP(
                  element.url,
                  getftpConfig,
                  this.stageInput.SupplementFtpPath,
                  element.fileName,
                );
              }
          if (this.stageInput.OnlyUpload == false) {
            // await this.callIOPPStageUpdate(data);
            console.log('Files to Custommer FTP');
          }
        }
        resolve(true);
      } catch (error) {
        reject(error);
      }
    });
  }

  callIOPPLanguageEditUpdate(data) {
    return new Promise((resolve, reject) => {
      try {
        if (data.articleName == '' || data.articleName == undefined) {
          throw new Error('articleName must be provided.');
        } else {
          const config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: `${this.ioppApiURL.LanguageEdit}`,
            headers: this.ioppAPICredentials,
            data: {
              articleId: data.articleName,
              languageEditMethod: this.inlpTrackStage.languageEditMethod,
              languageEditTask: this.inlpTrackStage.languageEditTask,
            },
          };
          axios
            .request(config)
            .then(response => {
              resolve(response.data);
            })
            .catch(error => {
              if (error.response) {
                reject(error.response.data);
              } else {
                reject(error.message);
              }
            });
        }
      } catch (error) {
        reject(error);
      }
    });
  }

  callIOPPStageUpdate(data) {
    return new Promise((resolve, reject) => {
      try {
        if (data.journalAcronym == '' || data.journalAcronym == undefined) {
          throw new Error('journalAcronym must be provided.');
        } else if (data.articleName == '' || data.articleName == undefined) {
          throw new Error('articleName must be provided.');
        } else if (this.stageInput == undefined) {
          throw new Error('TaskName must be provided.');
        } else {
          const config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: `${this.ioppApiURL.ProtonCall}`,
            headers: this.ioppAPICredentials,
            data: {
              url:
                data.iAuthorURL == '' || data.iAuthorURL == undefined
                  ? undefined
                  : data.iAuthorURL,
              journalAcronym: data.journalAcronym,
              articleId: data.articleName,
              taskName: this.stageInput.TaskName,
              urlType: '',
            },
          };
          axios
            .request(config)
            .then(response => {
              resolve(response.data);
            })
            .catch(error => {
              if (error.response) {
                reject(error.response.data);
              } else {
                reject(error.message);
              }
            });
        }
      } catch (error) {
        reject(error);
      }
    });
  }

  getTaskStatus(articleName) {
    return new Promise((resolve, reject) => {
      try {
        const config = {
          method: 'get',
          maxBodyLength: Infinity,
          url: `${this.ioppApiURL.TaskStatus}${articleName}`,
          headers: this.ioppAPICredentials,
        };
        axios
          .request(config)
          .then(response => {
            resolve(response.data);
          })
          .catch(error => {
            if (error.response) {
              reject(error.response.data);
            } else {
              reject(error.message);
            }
          });
      } catch (error) {
        reject(error);
      }
    });
  }

  // #ftpLiveDetails = {
  //     "Host": "ioplive-sftp.mpstechnologies.com",
  //     "Username": "iopliveIntegra",
  //     "Password": '"ZT&S-#r%[6*`B',
  //     "Port": 22
  // }

  // #ftpTestDetails = {
  //     "Host": "iopstg-sftp.mpstechnologies.com",
  //     "Username": "iopstagingIntegra",
  //     "Password": 'f_XX%A$h/D7aKW',
  //     "Port": 22
  // }
}
