/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import FormData from 'form-data';
import { fileURLToPath } from 'url';
import { join } from 'path';
import fs from 'fs';
import { getBasePath } from '../../utils/wmsFolder/index.js';
import { query } from '../../../database/postgres.js';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';

// const path = require('path');

// Function to get wip  Report
export const getWIPReport = (req, res) => {
  const reqData = req.body;

  const sql = `select service.servicename as service,stage.stagename as stage,
    division.division,customer.customername as customer,
    workflow.wfname as workflow,wostage.status as stagestatus,software.softwarename as software,
    customermap.custorgmapid , contacts.contactname as PM,
    CASE
    WHEN wostage.plannedenddate isnull
    THEN 'Blank'
    when wostage.plannedenddate <= CURRENT_DATE + INTERVAL '${reqData.month} months' and wostage.plannedenddate>=CURRENT_DATE
    then TO_CHAR(wostage.plannedenddate :: DATE, 'Mon yy')
    when wostage.plannedenddate<CURRENT_DATE
    then TO_CHAR(CURRENT_DATE :: DATE, 'Mon yy')
    END as month,TO_CHAR(wostage.plannedenddate :: DATE, 'Mon yy')as actualdate
    from wms_workorder wo
    left join wms_workorder_service woservice on woservice.workorderid=wo.workorderid
    join wms_workorder_stage wostage on wostage.workorderid=wo.workorderid
    join wms_mst_service service on service.serviceid=wostage.serviceid
    join wms_mst_stage stage on stage.stageid=wostage.wfstageid
    join org_mst_division division on division.divisionid=wo.divisionid
    join org_mst_customer customer on customer.customerid=wo.customerid
    join org_mst_customer_orgmap as customermap on (customermap.customerid = wo.customerid and customermap.divisionid = wo.divisionid and customermap.subdivisionid = wo.subdivisionid and customermap.countryid = wo.countryid)
    join wms_workorder_contacts contacts on wo.workorderid=contacts.workorderid and contacts.contactrole='PM' and isprimary=true and contacttype='Integra'
    join wms_workflow workflow on workflow.wfid=woservice.wfid
    join pp_mst_composingsoftware software on software.softwareid=wo.composingsoftwareid
    join org_mst_customerorg_du_map du_map on du_map.custorgmapid = customermap.custorgmapid
    where wostage.status!='Completed' and wostage.stageiterationcount=(select stageiterationcount from wms_workorder_stage
    where wms_workorder_stage.workorderid=wo.workorderid  and
    wms_workorder_stage.wfstageid=wostage.wfstageid 
    order by stageiterationcount desc limit 1 )and du_map.duid =  ${reqData.duID} and (wostage.plannedenddate <= CURRENT_DATE + INTERVAL '${reqData.month} months' or wostage.plannedenddate isnull)
    order by wostage.plannedenddate , wfstageid`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// suradha (12-12-2022)
export const getWIPWorkorderReport1 = (req, res) => {
  const reqData = req.body;
  const jdata = JSON.stringify(reqData);

  const sql = `select * from public.getwip_workorderdata('${jdata}')`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getWIPChapterReport = (req, res) => {
  const reqData = req.body;
  const jdata = JSON.stringify(reqData);

  const sql = `select row_number()over(order by chapter) as "S.No", 
              chapter as "Chapter", service as "Service", stage as "Stage",mspages as "MS_Page", actstatus as "Status", 
              currentactivity as "Current_Activity", assignedto as "Assigned_To", 
              priority as "Priority"
            from public.getwip_workorderchapterdata('${jdata}')`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const exportWOReport = (req, res) => {
  const reqData = req.body;
  const jdata = JSON.stringify(reqData);

  const sql = `select
  row_number() over(order by itemcode) as "S.No",
  itemcode as "Book Code", filename as "Chapter", division as "Division",stage as "Stage",
  workflow as "Workflow",receiveddate as "Received Date",duedate as "Due Date",
  proddespatchdate as "Prod.Despatch.Date",hoursleft as "Days Left",overdue as "Is Overdue" ,querystatus as "Query Status",
  querycount as "Query Count",querytext as "Query",pmname as "Project Manager",assigned as "Assigned To", inputtype as "Input Type",
  activities as "Current Activity",filepriority as "Priority",wipnotes as "Notes"
  from getwip_workorderdata_export('${jdata}')`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWIPWorkorderReport = (req, res) => {
  const reqData = req.body;
  const jdata = reqData.params;
  let querySP = 'getwip_workorderdata_cupjournal';
  // getwip_workorderdata_cupjournal_delay
  // JSON.parse(jdata).duID == '7'
  //   ? 'getwip_workorderdata_cupjournal'
  //   : 'getwip_workorderdata';

  if (JSON.parse(jdata).duID == '5') {
    querySP = 'getwip_workorderdata';
  }

  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
  }
  sql = `SELECT COUNT(*) FROM public.${querySP}('${jdata}') ${
    condition ? `WHERE${condition}` : condition
  }`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);

        const sqlQuery = `select * from public.${querySP}('${jdata}') ${
          condition ? `WHERE${condition}` : condition
        }`; // LIMIT ${recordPerPage} OFFSET ${offset}
        //  const sql = `select * from (select * from public.getwip_workorderdata('${jdata}')  LIMIT ${recordPerPage} OFFSET ${offset}) as res
        //               ${condition ? ' WHERE' + condition : condition}`;

        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const testFunction = async (req, res) => {
  try {
    const woid = 2;
    const zipFileName = 'book_zipfilename_1232424.zip';

    // const sql1=`update wms_workorder SET otherfield =
    //    CASE WHEN otherfield IS NULL THEN
    //    jsonb_build_object('BookZipFileName', $2::text)
    //    jsonb_set(otherfield::jsonb, '{BookZipFileName}', to_jsonb($2::text), true)
    //    END WHERE workorderid = $1;`;

    const sql = `UPDATE wms_workorder
                 SET otherfield = CASE WHEN otherfield is null THEN
                              '{"BookZipFileName": "${zipFileName}"}'::jsonb
                          ELSE
                              jsonb_set(otherfield::jsonb, '{BookZipFileName}', '"${zipFileName}"', true)
                      END
                 WHERE workorderid = ${woid}`;

    const fileDetails = await query(sql);
    res.status(200).json(fileDetails);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getWIPReportTwo = async (req, res) => {
  const { duID } = req.body;

  const sql = await getWIPQueryBasedOnDuid(duID);
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Function to get wip detailed Report
export const getWIPDetailedReport = (req, res) => {
  const reqData = req.body;
  const type =
    req.body.type === 'default'
      ? ' or wostage.plannedenddate<CURRENT_DATE'
      : ' and 1=1';

  let sql = `select  distinct activity,stage,* from(select wf.activityalias,wf.sequence,wms_workorder.workorderid as WOID, priority.priority,wms_workorder.itemcode,service.servicename as service,software.softwarename as software, 
    case
	when (select userid from wms_user where username=contacts.contactname) isnull
	then contacts.contactname
	else contacts.contactname||' (' ||  (select userid from wms_user where username=contacts.contactname)||')'
	end as PM,
    customer.customername as customer,wms_workorder.workorderid,wostage.plannedenddate as actualdate,wms_workorder_incomingfiledetails.woincomingfileid,wms_mst_activity.activityname as activity,
    workflow.wfname as workflow,wms_mst_stage.stagename as stage,
    wms_workflow_eventlog.stageiterationcount,wms_workflow_eventlog.actualactivitycount,wms_workflow_eventlog.activitystatus, wms_workflowactivitytrn_file_map.woincomingfileid,wms_workorder.itemcode,
     wms_workorder_incomingfiledetails.filename,wms_workflow_eventlog.wfeventid ,
     users.username ||' (' || wms_workflow_eventlog.userid  || ')' as userid,
	 CASE
    WHEN wostage.plannedenddate isnull
    THEN null
    when wostage.plannedenddate >= '${reqData.startdate}' and wostage.plannedenddate<='${reqData.enddate}'
    then wostage.plannedenddate
    when wostage.plannedenddate<CURRENT_DATE
    then CURRENT_DATE
    END as date
	 from wms_workflow_eventlog   
    JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
    JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid 
    JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
    JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
    JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
    JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
	JOIN wms_workorder_stage wostage on wostage.workorderid=wms_workorder.workorderid and wms_mst_stage.stageid=wostage.wfstageid
	JOIN org_mst_customer customer on customer.customerid=wms_workorder.customerid
	JOIN wms_workorder_contacts contacts on wms_workorder.workorderid=contacts.workorderid and contacts.contactrole='PM' and isprimary=true and contacttype='Integra'
  JOIN org_mst_customer_orgmap as customermap on (customermap.customerid = wms_workorder.customerid and customermap.divisionid = wms_workorder.divisionid and customermap.subdivisionid = wms_workorder.subdivisionid and customermap.countryid = wms_workorder.countryid)
  JOIN org_mst_customerorg_du_map du_map on du_map.custorgmapid = customermap.custorgmapid    
	JOIN pp_mst_composingsoftware software on software.softwareid=wms_workorder.composingsoftwareid
	left JOIN wms_workorder_service woservice on woservice.workorderid=wms_workorder.workorderid
	JOIN wms_workflow workflow on workflow.wfid=woservice.wfid
	JOIN wms_mst_service service on service.serviceid=wostage.serviceid
    left join wms_mst_priority priority on priority.priorityid=wms_workflow_eventlog.priority
    LEFT JOIN wms_user as users on users.userid = wms_workflow_eventlog.userid
	where actualactivitycount=(SELECT actualactivitycount FROM public.wms_workflow_eventlog ev
        JOIN wms_workflowdefinition  wf1 on wf1.wfdefid = ev.wfdefid
        JOIN wms_workflowactivitytrn_file_map wft1 ON ev.wfeventid = wft1.wfeventid
        JOIN wms_workorder_incomingfiledetails wdti1 ON wft1.woincomingfileid = wdti1.woincomingfileid
        JOIN wms_mst_stage on wms_mst_stage.stageid = wf1.stageid
        where  ev.stageiterationcount =wms_workflow_eventlog.stageiterationcount and wft1.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid and  wf1.activityid=wf.activityid
        order by ev.wfeventid desc limit 1) and (activitystatus!='Completed' and activitystatus!='Rejected' and activitystatus!='Reset') and du_map.duid = ${reqData.duID} and wostage.stageiterationcount=(select stageiterationcount from wms_workorder_stage
    where wms_workorder_stage.workorderid=wms_workorder.workorderid  and
    wms_workorder_stage.wfstageid=wostage.wfstageid 
    order by stageiterationcount desc limit 1 ) and (wostage.plannedenddate <= '${reqData.enddate}' and  wostage.plannedenddate >= '${reqData.startdate}' ${type} or wostage.plannedenddate isnull) 
    ) as table1  order by actualdate,sequence`;

  query(sql)
    .then(data => {
      sql = `select   stagename as stage,activityName as activity,sequence,activityalias from (select distinct stagename,activityName,sequence,wms_workflowdefinition.activityalias from wms_workflowdefinition 
        join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
      where  (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
      ) as table1 order by sequence`;
      query(sql).then(stageActivity => {
        res.status(200).json({ data, stageActivity });
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get productivity report
export const getProductivityReport = (req, res) => {
  const {
    duId,
    filterObj,
    type,
    selectedUser,
    dateRange: { startDate, endDate },
  } = req.body;
  let condition = '';

  let index = 0;
  for (const key in filterObj) {
    if (Object.prototype.hasOwnProperty.call(filterObj, key)) {
      let value = '';
      filterObj[key].forEach((data, i) => {
        value += filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
      });
      index += 1;
      condition += ` ${
        Object.keys(filterObj).length == index
          ? `${key} IN (${value})`
          : `${key} IN (${value}) AND`
      } `;
    }
  }
  let sql = '';
  if (type == 'groupByUser') {
    sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, sum(totaltime) as totalhours, skillname, skilllevel, COALESCE(sum(uomvalue), 0) as uomvalue
        FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
        duid = ${duId} ${condition ? `AND${condition}` : ''}
        GROUP BY duid, username,userid,skillname, skilllevel`;
  } else if (type == 'groupByDate') {
    sql = `SELECT duid,sum(totaltime) as totalhours, to_char(DATE(updatedon),'DD-Mon-YY') as date, COALESCE(sum(uomvalue), 0) as uomvalue
        FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
        duid = ${duId} AND userid = '${selectedUser}'
        GROUP BY duid, DATE(updatedon)`;
  } else if (type == 'groupByTask') {
    sql = `SELECT duid,concat(username, ' (', userid, ')') as employee, totaltime as totalhours, itemcode, servicename, 
    concat(stagename,' (',stageiterationcount,')') as stagename, COALESCE(uomvalue, 0) as uomvalue,
    filename,concat(activityalias,' (',activityiterationcount,')') as activityname, skillname, skilllevel
        FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND duid = ${duId} AND userid = '${selectedUser}' ${
      condition ? `AND${condition}` : ''
    }`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// will get dropdwon option for productivity report
export const getReportOptionLists = (req, res) => {
  const {
    duId,
    type,
    selectedUser,
    dateRange: { startDate, endDate },
    skill,
  } = req.body;
  let sql = '';
  if (type === 'employee') {
    sql = `SELECT DISTINCT ON (userid) userid as value, concat(username, ' (', userid ,')') as label
            FROM wms_task_report_view WHERE activityname != 'Despatch' `;
  } else if (type === 'jobId') {
    sql = `SELECT DISTINCT ON (itemcode) itemcode as value, itemcode as label FROM wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND skillname = '${skill}'
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  } else if (type === 'stage') {
    sql = `SELECT DISTINCT ON(stagename) stagename, stagename as label, stagename as value, duid, userid FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' 
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  } else if (type === 'activity') {
    sql = `SELECT DISTINCT ON (activityalias) activityalias as value, activityalias as label FROM wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  } else if (type === 'skill') {
    sql = `SELECT DISTINCT ON (skillname) skillname, skillname as value, skillname as label FROM wms_task_report_view
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'chapter') {
    sql = `SELECT DISTINCT ON (filename) filename as value, filename as label FROM wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get quality report
export const getQualityReport = (req, res) => {
  const {
    duId,
    filterObj,
    type,
    selectedUser,
    dateRange: { startDate, endDate },
  } = req.body;
  let condition = '';

  let index = 0;
  for (const key in filterObj) {
    if (Object.prototype.hasOwnProperty.call(filterObj, key)) {
      let value = '';
      filterObj[key].forEach((data, i) => {
        value += filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
      });
      index += 1;
      condition += ` ${
        Object.keys(filterObj).length == index
          ? `${key} IN (${value})`
          : `${key} IN (${value}) AND`
      } `;
    }
  }
  let sql = '';
  if (type == 'groupByUser') {
    sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, sum(totaltime) as totalhours,
      skillname, skilllevel, COALESCE(sum(uomvalue), 0) as uomvalue, sum(defects.defectcount) as defectcount,
      COALESCE(case when sum(uomvalue)=0 then round(sum(defects.defectcount)/NULLIF(sum(uomvalue), 0))
      else round(sum(defects.defectcount)/sum(uomvalue))
      end, 0) as defectPerPage
      FROM public.wms_task_report_view
      JOIN wms_sum_of_defects as defects ON defects.wfeventid = wms_task_report_view.wfeventid
      WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
      duid = ${duId} ${condition ? `AND${condition}` : ''}
      GROUP BY duid, username,userid,skillname, skilllevel`;
  } else if (type == 'groupByDate') {
    sql = `SELECT to_char(DATE(updatedon),'DD-Mon-YY') as date, sum(totaltime) as totalhours, sum(uomvalue) as uomvalue,
      COALESCE(sum(defects.defectcount), 0) as defectcount,
      COALESCE(case when sum(uomvalue)=0 then round(sum(defects.defectcount)/NULLIF(sum(uomvalue), 0))
      else round(sum(defects.defectcount)/sum(uomvalue))
      end, 0) as defectPerPage
      FROM public.wms_task_report_view
      join wms_sum_of_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
      WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
      duid = ${duId} AND userid = '${selectedUser}'
      GROUP BY duid, DATE(updatedon)`;
  } else if (type == 'groupByTask') {
    sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, uomvalue,itemcode,
    concat(stagename,' (',stageiterationcount,')') as stagename,concat(activityalias,' (',activityiterationcount,')') as activityname,
    filename,defects.defectcount,
    COALESCE(case when sum(uomvalue)=0 then round(defects.defectcount/NULLIF(sum(uomvalue), 0))
    else round(defects.defectcount/sum(uomvalue))
    end, 0) as defectPerPage
    FROM public.wms_task_report_view
    join wms_sum_of_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
    duid = ${duId} AND userid = '${selectedUser}' ${
      condition ? `AND${condition}` : ''
    }
    GROUP BY duid, username,userid,itemcode,stagename,stageiterationcount,activityname,activityalias,activityiterationcount,filename,defects.defectcount,
    uomvalue`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
//   const {
//     duId,
//     filterObj,
//     type,
//     selectedUser,
//     dateRange: { startDate, endDate },
//   } = req.body;
//   let condition = "";
//
//   let index = 0;
//   for (const key in filterObj) {
//     let value = "";
//     filterObj[key].map((data, i) => {
//       value += filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
//     });
//

//     index += 1;
//     condition += ` ${
//       Object.keys(filterObj).length == index
//         ? key + " IN" + `(${value})`
//         : key + " IN" + `(${value}) AND`
//     } `;
//   }

//   let sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, sum(totaltime) as totalhours, skillname, skilllevel, sum(uomvalue) as uomvalue,itemcode,
//   concat(stagename,' (',stageiterationcount,')') as stagename,concat(activityname,' (',activityiterationcount,')') as activityname,filename,defects.defectcount,
//   case when sum(uomvalue)=0 then round(defects.defectcount/1)
//   else round(defects.defectcount/sum(uomvalue))
//   end as defectPerPage
//   FROM public.wms_task_report_view
//   join wms_sum_of_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
//   WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
//   duid = ${duId} ${condition ? "AND" + condition : ""}
//   GROUP BY duid, username,userid,skillname, skilllevel,itemcode,stagename,stageiterationcount,activityname,activityiterationcount,filename,defects.defectcount`;
//
//   query(sql)
//     .then((data) => {
//       res.status(200).json({ data: data });
//     })
//     .catch((error) => {
//       res.status(400).send({ message: error });
//     });
// };

// will get dropdwon option for Quality report
export const getQualityReportOptionLists = (req, res) => {
  const {
    duId,
    type,
    dateRange: { startDate, endDate },
  } = req.body;
  let sql = '';
  if (type === 'employee') {
    sql = `SELECT DISTINCT ON (userid) userid as value, concat(username, ' (', userid ,')') as label
    FROM wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE wms_task_report_view.activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'skill') {
    sql = `SELECT DISTINCT ON (skillname) skillname, skillname as value, skillname as label FROM wms_task_report_view
    JOIN wms_workflow_eventlog_defects as defects ON defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'jobId') {
    sql = `SELECT DISTINCT ON (itemcode) itemcode as value, itemcode as label FROM wms_task_report_view
    join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'stage') {
    sql = `SELECT DISTINCT ON(stagename) stagename, stagename as label, stagename as value, duid, userid FROM public.wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'activity') {
    sql = `SELECT DISTINCT ON (activityalias) activityalias as value, activityalias as label FROM wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'chapter') {
    sql = `SELECT DISTINCT ON (filename) filename as value, filename as label FROM wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get quality report
export const getMonitoringReport = (req, res) => {
  const {
    duId,
    filterObj,
    type,
    dateRange: { startDate, endDate },
    stageid,
    stageiterationcount,
  } = req.body;

  let condition = ``;
  let index = 0;
  for (const key in filterObj) {
    if (Object.prototype.hasOwnProperty.call(filterObj, key)) {
      let value = '';
      if (Array.isArray(filterObj[key])) {
        filterObj[key].forEach((data, i) => {
          value +=
            filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
        });
      } else {
        value += filterObj[key];
      }
      index += 1;
      condition += ` ${
        Object.keys(filterObj).length == index
          ? `${key} IN (${value})`
          : `${key} IN (${value}) AND`
      } `;
    }
  }
  let sql = '';
  // As of now not in use
  const qry_wms_delivery_monitoring_report = ` SELECT 
  DISTINCT ON (wms_workorder_incomingfiledetails.filename, (concat(wms_mst_stage.stagename, ' (', wms_workorder_stage.stageiterationcount, ')')), wms_workorder_stage.workorderid)     
   to_char(wms_workorder_stage.enddatetime, 'dd Mon') AS "Date",
 CASE
     WHEN wms_mst_stage.stagename::text = 'Stage 200'::text THEN 'S200'::text
     WHEN wms_mst_stage.stagename::text = 'Stage 300'::text THEN
     CASE
         WHEN wms_workorder_stage.stageiterationcount = 1 THEN 'S300'::text
         ELSE concat('S300 R', ' (', (wms_workorder_stage.stageiterationcount - 1)::text, ')')
     END
     WHEN wms_mst_stage.stagename::text = 'Stage200 Revises'::text THEN concat('S200 R', ' (', wms_workorder_stage.stageiterationcount::text, ')')
     WHEN wms_mst_stage.stagename::text = 'Stage 600'::text THEN
     CASE
         WHEN wms_workorder_stage.stageiterationcount = 1 THEN 'S600'::text
         ELSE concat('S600', ' (', wms_workorder_stage.stageiterationcount::text, ')')
     END
     WHEN wms_mst_stage.stagename in ('Stage 50') THEN 'S50'  
	 	 WHEN wms_mst_stage.stagename in ('Stage 200 Rejection') THEN 'S200_Rejection'
     ELSE
     CASE
         WHEN wms_workorder_stage.stageiterationcount = 1 AND lower(wms_mst_stage.stagename::text) <> 'revises'::text THEN wms_mst_stage.stagename::text
         ELSE concat(wms_mst_stage.stagename, ' (', wms_workorder_stage.stageiterationcount::text, ')')
     END
 END AS "Stage",
org_mst_deliveryunit.duid,
wms_workorder_stage.status,
division.division,
wms_workorder_stage.stageiterationcount,
wms_workorder.workorderid,
wms_workorder.title AS jobname,
wms_workorder.customerid,
wms_workorder_incomingfiledetails.filename,
wms_userrole.roleid,
wms_mst_service.serviceid,
wms_workflowdefinition.stageid,
wms_workflow.wfid,
org_mst_customer.customername,
wms_mst_service.servicename,
 CASE
     WHEN wms_mst_stage.stagename::text = 'Stage 200'::text THEN 'S200'::character varying
     WHEN wms_mst_stage.stagename::text = 'Stage 300'::text THEN
     CASE
         WHEN wms_workorder_stage.stageiterationcount = 1 THEN 'S300'::character varying
         ELSE concat('S300 R', ' (', (wms_workorder_stage.stageiterationcount - 1)::character varying, ')')::character varying
     END
     WHEN wms_mst_stage.stagename::text = 'Stage200 Revises'::text THEN concat('S200 R', ' (', wms_workorder_stage.stageiterationcount::character varying, ')')::character varying
     WHEN wms_mst_stage.stagename::text = 'Stage 600'::text THEN
     CASE
         WHEN wms_workorder_stage.stageiterationcount = 1 THEN 'S600'::character varying
         ELSE concat('S600', ' (', wms_workorder_stage.stageiterationcount::text, ')')::character varying
     END
      WHEN wms_mst_stage.stagename in ('Stage 50') THEN 'S50'  
	 	 WHEN wms_mst_stage.stagename in ('Stage 200 Rejection') THEN 'S200_Rejection'
     ELSE
     CASE
         WHEN wms_workorder_stage.stageiterationcount = 1 AND lower(wms_mst_stage.stagename::text) <> 'revises'::text THEN wms_mst_stage.stagename::character varying
         ELSE concat(wms_mst_stage.stagename, ' (', wms_workorder_stage.stageiterationcount::character varying, ')')::character varying
     END
 END AS stagename,
mst_country.countryname,
wms_workflow.wfname,
wms_user.userid,
wms_user.username,
pp_mst_composingsoftware.softwareid,
pp_mst_composingsoftware.softwarename,
wms_workflow.wfcategory,
wms_workorder.itemcode,
 CASE
     WHEN wms_workorder.wotype::text = 'Journal'::text THEN
     CASE
         WHEN wms_workorder.jobtype::text = '1'::text THEN 'Article'::text
         ELSE 'Issue'::text
     END
     ELSE 'Book'::text
 END AS type,
wms_workorder.title,
wms_workorder_stage.ordermaildate  ::text,
	case
	when org_mst_deliveryunit.duid in (7, 12)
	and wms_workorder_stage.wfstageid = any ('{22,24,23,27,1,18}')
		then  
		 (
	select
		case
			when org_mst_deliveryunit.duid = 92 then 
		  coalesce(to_char(subws.ordermaildatetime,
			'dd-Mon-yyyy hh24:mi:ss'),
			'')
			else
		  coalesce(to_char(subws.ordermaildatetime,
			'dd-Mon-yyyy'),
			'')
		end
		  as subordermaildate
	from
		wms_workorder_stage as subws
	where
		subws.workorderid = wms_workorder_stage.workorderid
		and 
		  subws.wfstageid = (
		select
			stageid
		from
			wms_workflowdefinition
		where
			wfid = wms_workorder_service.wfid
		order by
			sequence
		limit 1)
	limit 1)
	when org_mst_deliveryunit.duid in (7, 12)
	and wms_workorder_stage.wfstageid = 2
	and wms_workorder_stage.stageiterationcount = 1
		then
		 (
	select 
		  case
			when org_mst_deliveryunit.duid in (92, 12, 63) then 
		  coalesce(to_char(subr.ordermaildatetime,
			'dd-Mon-yyyy hh24:mi:ss'),
			'')
			else coalesce(to_char(subr.ordermaildatetime,
			'dd-Mon-yyyy'),
			'')
		end
		  as subordermaildate
	from
		wms_workorder_stage as subr
	where
		subr.workorderid = wms_workorder_stage.workorderid
		and 
		  subr.wfstageid = 21
	limit 1)
	when org_mst_deliveryunit.duid in (7)
			and wms_workorder_stage.wfstageid = 10
		then  
		 (
			select
				coalesce(to_char(ordermaildatetime,
				'dd-Mon-yyyy'),
				'')
			from
				wms_workorder_stage
			where
				workorderid = wms_workorder_stage.workorderid
				and wfstageid = 22
			limit 1)
	else
			 case
		when org_mst_deliveryunit.duid in (92, 12, 63) then 
				 case
			when wms_workflowdefinition.stageid = 10 then 
	 				 (
			select
				coalesce(to_char(ordermaildatetime,
				'dd-Mon-yyyy hh24:mi:ss'),
				'')
			from
				wms_workorder_stage
			where
				workorderid = wms_workorder_stage.workorderid
				and wfstageid = 72
			limit 1)
			else
					coalesce(to_char(wms_workorder_stage.ordermaildatetime,
			'dd-Mon-yyyy hh24:mi:ss'),
			'')
		end
		else
				coalesce(to_char(wms_workorder_stage.ordermaildatetime,
		'dd-Mon-yyyy'),
		'')
	end
end as receiveddate,
wms_workorder_stage.plannedstartdate ::text,
wms_workorder_stage.startdate  ::text, 
wms_workorder_stage.plannedenddate  ::text,
wms_workorder_stage.enddatetime ::text,
wms_workorder_stage.typesetpages  ::text,
wms_workorder_incomingfiledetails.mspages,
wms_workorder_incomingfiledetails.estimatedpages,
date_part('day'::text, age(wms_workorder_stage.enddatetime, wms_workorder_stage.startdate::timestamp with time zone)) AS totaldays,
wms_workorder.itemcode AS jobid,
 CASE
     WHEN wms_workorder_stage.plannedenddate::date = wms_workorder_stage.enddatetime::date THEN 'Ontime'::text
     WHEN wms_workorder_stage.plannedenddate::date > wms_workorder_stage.enddatetime::date THEN 'Ahead'::text
     WHEN wms_workorder_stage.plannedenddate::date < wms_workorder_stage.enddatetime::date THEN 'Delay'::text
     ELSE ''::text
 END AS ostatus,
wocpm.contactname,
wocpe.contactname AS "PM",
 CASE
     WHEN querys.createdby IS NOT NULL THEN 'YES'::text
     ELSE 'NO'::text
 END AS oquery,
querys.createdon ::TEXT AS querydate,
wms_workorder.volumenumber,
wms_workorder.issuenumber,
querys.updatedon ::TEXT AS replydate,
wipnotes.notestext,
cat.category AS "Workflow",
prd."timestamp" AS productiondespatchdate,
cust."timestamp" AS customerdespatchdate,
(enddatetime::date - startdatetime::date) as totaltaken 
FROM wms_workorder
JOIN geo_mst_country mst_country ON mst_country.countryid = wms_workorder.countryid
JOIN org_mst_division division ON division.divisionid = wms_workorder.divisionid
JOIN wms_workorder_service ON wms_workorder_service.workorderid = wms_workorder.workorderid
JOIN wms_workflow_eventlog ON wms_workflow_eventlog.workorderid = wms_workorder.workorderid
LEFT JOIN wms_workorder_contacts wocpe ON wocpe.workorderid = wms_workorder.workorderid AND wocpe.contactrole::text = 'PED'::text
LEFT JOIN wms_workorder_contacts wocpm ON wocpm.workorderid = wms_workorder.workorderid AND wocpm.isprimary = true AND wocpm.contactrole::text = 'PM'::text
LEFT JOIN wms_user ON wms_user.userid::text = wocpm.userid::text
JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
JOIN wms_workorder_stage ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid
JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workorder_service.serviceid
JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
JOIN wms_workflow ON wms_workflow.wfid = wms_workorder_service.wfid
JOIN pp_mst_composingsoftware ON pp_mst_composingsoftware.softwareid = wms_workorder.composingsoftwareid
LEFT JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder_service.assignedduid
JOIN org_mst_customer ON org_mst_customer.customerid = wms_workorder.customerid
LEFT JOIN wms_userrole ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
LEFT JOIN wms_query querys ON querys.workorderid = wms_workorder.workorderid
LEFT JOIN wms_wip_wostage_notes wipnotes ON wipnotes.workorderid = wms_workorder.workorderid AND wms_workorder_stage.wfstageid = wipnotes.stageid
LEFT JOIN pp_mst_wocategory cat ON cat.categoryid = COALESCE(wms_workorder.category::bigint, 0::bigint)
LEFT JOIN ( SELECT row_number() OVER (PARTITION BY s1.workorderid, s1.stageid ORDER BY s2.wfeventid DESC) AS prdrow,
     s2."timestamp",
     s1.workorderid,
     s1.stageid
    FROM wms_tasklist s1
      JOIN wms_workflow_eventlog_details s2 ON s2.wfeventid = s1.wfeventid
   WHERE ((s1.itracksconfig ->> 'isProduction'::text)::boolean) = true AND s2.operationtype::text = 'Completed'::text
   GROUP BY s2."timestamp", s1.workorderid, s1.stageid, s2.wfeventdetailid
   ORDER BY s2.wfeventdetailid DESC) prd ON prd.workorderid = wms_workorder.workorderid AND prd.stageid = wms_workorder_stage.wfstageid AND prd.prdrow = 1
LEFT JOIN (SELECT row_number() OVER (PARTITION BY s1.workorderid, s1.stageid ORDER BY s2.wfeventid DESC) AS prdrow,
     s2."timestamp",
     s1.workorderid,
     s1.stageid
    FROM wms_tasklist s1
      JOIN wms_workflow_eventlog_details s2 ON s2.wfeventid = s1.wfeventid
  WHERE ((s1.itracksconfig ->> 'isCustomer'::text)::boolean) = true AND s2.operationtype::text = 'Completed'::text
   GROUP BY s2."timestamp", s1.workorderid, s1.stageid, s2.wfeventdetailid
   ORDER BY s2.wfeventdetailid DESC) cust ON cust.workorderid = wms_workorder.workorderid
   AND cust.stageid = wms_workorder_stage.wfstageid AND cust.prdrow = 1`;
  if (type === 'stage') {
    let inValues = '';
    if (stageid.length) {
      stageid.forEach((data, i) => {
        inValues += stageid.length - 1 != i ? `${data},` : data;
      });
    }
    sql = `SELECT DISTINCT ON (res.stage) stage FROM (${qry_wms_delivery_monitoring_report}
      WHERE duid = ${duId} ${
      inValues ? `AND wms_workflowdefinition.stageid IN (${inValues}) ` : ' '
    } ${
      filterObj.customerid
        ? `AND wms_workorder.customerid IN (${filterObj.customerid})`
        : ''
    }  )as res`;

    // sql = `SELECT wms_mst_stage.stagename as stage FROM wms_mst_stage
    // ORDER BY stageid ASC  `;
  } else if (type === 'groupByDate') {
    // As of now not in use
    // sql = `select * from (${qry_wms_delivery_monitoring_report}
    // WHERE wms_workorder_stage.status = 'Completed' AND DATE(wms_workorder_stage.enddatetime) >= '${startDate}' AND DATE(wms_workorder_stage.enddatetime) <= '${endDate}'
    // AND org_mst_deliveryunit.duid = ${duId} ${
    //   condition ? `AND ${condition}` : ''
    // }) as res ORDER BY res.enddatetime asc`;

    // new sql
    sql = `SELECT *
            FROM (
                SELECT DISTINCT ON (
                    wi.filename,
                    CONCAT(ms.stagename, ' (', ws.stageiterationcount, ')'),
                    ws.workorderid
                )    
                    TO_CHAR(ws.enddatetime, 'DD Mon') AS "Date",
                  
                    -- Optimized stage name logic
                    CASE
                        WHEN ms.stagename = 'Stage 200' THEN 'S200'
                        WHEN ms.stagename = 'Stage 300' THEN
                            CASE
                                WHEN ws.stageiterationcount = 1 THEN 'S300'
                                ELSE CONCAT('S300 R (', (ws.stageiterationcount - 1), ')')
                            END
                        WHEN ms.stagename = 'Stage200 Revises' THEN CONCAT('S200 R (', ws.stageiterationcount, ')')
                        WHEN ms.stagename = 'Stage 600' THEN
                            CASE
                                WHEN ws.stageiterationcount = 1 THEN 'S600'
                                ELSE CONCAT('S600 (', ws.stageiterationcount, ')')
                            END
                        WHEN ms.stagename = 'Stage 50' THEN 'S50'
                        WHEN ms.stagename = 'Stage 200 Rejection' THEN 'S200_Rejection'
                        ELSE
                            CASE
                                WHEN ws.stageiterationcount = 1 AND LOWER(ms.stagename) <> 'revises' THEN ms.stagename
                                ELSE CONCAT(ms.stagename, ' (', ws.stageiterationcount, ')')
                            END
                    END AS "Stage",
            
                    du.duid,
                    ws.status,
                    d.division,
                    ws.stageiterationcount,
                    wo.workorderid,
                    wo.title AS jobname,
                    wo.customerid,
                    wi.filename,
                    ur.roleid,
                    msrv.serviceid,
                    wfd.stageid,
                    wf.wfid,
                    c.customername,
                    msrv.servicename,
            
                    -- stagename (duplicate of "Stage", possibly remove)
                    CASE
                        WHEN ms.stagename = 'Stage 200' THEN 'S200'
                        WHEN ms.stagename = 'Stage 300' THEN
                            CASE
                                WHEN ws.stageiterationcount = 1 THEN 'S300'
                                ELSE CONCAT('S300 R (', ws.stageiterationcount - 1, ')')
                            END
                        WHEN ms.stagename = 'Stage200 Revises' THEN CONCAT('S200 R (', ws.stageiterationcount, ')')
                        WHEN ms.stagename = 'Stage 600' THEN
                            CASE
                                WHEN ws.stageiterationcount = 1 THEN 'S600'
                                ELSE CONCAT('S600 (', ws.stageiterationcount, ')')
                            END
                        WHEN ms.stagename = 'Stage 50' THEN 'S50'
                        WHEN ms.stagename = 'Stage 200 Rejection' THEN 'S200_Rejection'
                        ELSE
                            CASE
                                WHEN ws.stageiterationcount = 1 AND LOWER(ms.stagename) <> 'revises' THEN ms.stagename
                                ELSE CONCAT(ms.stagename, ' (', ws.stageiterationcount, ')')
                            END
                    END AS stagename,
            
                    cn.countryname,
                    wf.wfname,
                    u.userid,
                    u.username,
                    cs.softwareid,
                    cs.softwarename,
                    wf.wfcategory,
                    wo.itemcode,
                    
                    -- type logic
                    CASE
                        WHEN wo.wotype = 'Journal' THEN
                            CASE
                                WHEN wo.jobtype = '1' THEN 'Article'
                                ELSE 'Issue'
                            END
                        ELSE 'Book'
                    END AS type,
            
                    wo.title,
                    ws.ordermaildate::text,
            
                    -- Received Date Logic (unchanged; complex conditions retained)
                    CASE
                        WHEN du.duid IN (7, 12) AND ws.wfstageid = ANY('{22,24,23,27,1,18}'::int[]) THEN  
                            (
                                SELECT
                                    CASE
                                        WHEN du.duid = 92 THEN TO_CHAR(subws.ordermaildatetime, 'DD-Mon-YYYY HH24:MI:SS')
                                        ELSE TO_CHAR(subws.ordermaildatetime, 'DD-Mon-YYYY')
                                    END
                                FROM wms_workorder_stage subws
                                WHERE subws.workorderid = ws.workorderid
                                AND subws.wfstageid = (
                                    SELECT stageid FROM wms_workflowdefinition
                                    WHERE wfid = wos.wfid
                                    ORDER BY sequence LIMIT 1)
                                LIMIT 1
                            )
                        WHEN du.duid IN (7, 12) AND ws.wfstageid = 2 AND ws.stageiterationcount = 1 THEN
                            (
                                SELECT
                                    CASE
                                        WHEN du.duid IN (92, 12, 63) THEN TO_CHAR(subr.ordermaildatetime, 'DD-Mon-YYYY HH24:MI:SS')
                                        ELSE TO_CHAR(subr.ordermaildatetime, 'DD-Mon-YYYY')
                                    END
                                FROM wms_workorder_stage subr
                                WHERE subr.workorderid = ws.workorderid AND subr.wfstageid = 21
                                LIMIT 1
                            )
                        WHEN du.duid = 7 AND ws.wfstageid = 10 THEN
                            (
                                SELECT TO_CHAR(ordermaildatetime, 'DD-Mon-YYYY')
                                FROM wms_workorder_stage
                                WHERE workorderid = ws.workorderid AND wfstageid = 22
                                LIMIT 1
                            )
                        ELSE
                            CASE
                                WHEN du.duid IN (92, 12, 63) THEN
                                    CASE
                                        WHEN wfd.stageid = 10 THEN
                                            (
                                                SELECT TO_CHAR(ordermaildatetime, 'DD-Mon-YYYY HH24:MI:SS')
                                                FROM wms_workorder_stage
                                                WHERE workorderid = ws.workorderid AND wfstageid = 72
                                                LIMIT 1
                                            )
                                        ELSE TO_CHAR(ws.ordermaildatetime, 'DD-Mon-YYYY HH24:MI:SS')
                                    END
                                ELSE TO_CHAR(ws.ordermaildatetime, 'DD-Mon-YYYY')
                            END
                    END AS receiveddate,
            
                    ws.plannedstartdate::text,
                    ws.startdatetime::text AS startdate,
                    ws.plannedenddate::text,
                    ws.enddatetime::text,
                    ws.typesetpages::text,
                    wi.mspages,
                    wi.estimatedpages,
                    DATE_PART('day'::text, age(ws.enddatetime, ws.startdatetime)) AS totaldays,
                    wo.itemcode AS jobid,
            
                    -- On-time status
                    CASE
                        WHEN ws.plannedenddate::date = ws.enddatetime::date THEN 'Ontime'
                        WHEN ws.plannedenddate::date > ws.enddatetime::date THEN 'Ahead'
                        WHEN ws.plannedenddate::date < ws.enddatetime::date THEN 'Delay'
                        ELSE ''
                    END AS ostatus,
            
                    wocpm.contactname,
                    wocpe.contactname AS "PM",
                    CASE WHEN q.createdby IS NOT NULL THEN 'YES' ELSE 'NO' END AS oquery,
                    q.createdon::text AS querydate,
                    wo.volumenumber,
                    wo.issuenumber,
                    q.updatedon::text AS replydate,
                    wn.notestext,
                    cat.category AS "Workflow",
                    prd.timestamp AS productiondespatchdate,
                    cust.timestamp AS customerdespatchdate,
                    (ws.enddatetime::date - ws.startdatetime::date) AS totaltaken
            
                FROM wms_workorder wo
                -- Join structure below (aliased for readability)
                JOIN geo_mst_country cn ON cn.countryid = wo.countryid
                JOIN org_mst_division d ON d.divisionid = wo.divisionid
                JOIN wms_workorder_service wos ON wos.workorderid = wo.workorderid
                JOIN wms_workflow_eventlog we ON we.workorderid = wo.workorderid
                LEFT JOIN wms_workorder_contacts wocpe ON wocpe.workorderid = wo.workorderid AND wocpe.contactrole = 'PED'
                LEFT JOIN wms_workorder_contacts wocpm ON wocpm.workorderid = wo.workorderid AND wocpm.isprimary = true AND wocpm.contactrole = 'PM'
                LEFT JOIN wms_user u ON u.userid = wocpm.userid
                JOIN wms_workflowdefinition wfd ON wfd.wfdefid = we.wfdefid
                JOIN wms_workorder_stage ws ON ws.workorderid = we.workorderid AND ws.serviceid = we.serviceid AND ws.wfstageid = wfd.stageid
                JOIN wms_mst_service msrv ON msrv.serviceid = wos.serviceid
                JOIN wms_mst_stage ms ON ms.stageid = wfd.stageid
                JOIN wms_workflow wf ON wf.wfid = wos.wfid
                JOIN pp_mst_composingsoftware cs ON cs.softwareid = wo.composingsoftwareid
                LEFT JOIN wms_workorder_incomingfiledetails wi ON wi.woincomingfileid = we.woincomingfileid
                JOIN org_mst_deliveryunit du ON du.duid = wos.assignedduid
                JOIN org_mst_customer c ON c.customerid = wo.customerid
                LEFT JOIN wms_userrole ur ON ur.userid = we.userid
                LEFT JOIN wms_query q ON q.workorderid = wo.workorderid
                LEFT JOIN wms_wip_wostage_notes wn ON wn.workorderid = wo.workorderid AND ws.wfstageid = wn.stageid
                LEFT JOIN pp_mst_wocategory cat ON cat.categoryid = COALESCE(wo.category::bigint, 0)
            
                -- Production and Customer dispatch subqueries
                LEFT JOIN (
                    SELECT DISTINCT ON (s1.workorderid, s1.stageid)
                        s2.timestamp, s1.workorderid, s1.stageid
                    FROM wms_tasklist s1
                    JOIN wms_workflow_eventlog_details s2 ON s2.wfeventid = s1.wfeventid
                    WHERE (s1.itracksconfig ->> 'isProduction')::boolean = true
                        AND s2.operationtype = 'Completed'
                ) prd ON prd.workorderid = wo.workorderid AND prd.stageid = ws.wfstageid
            
                LEFT JOIN (
                    SELECT DISTINCT ON (s1.workorderid, s1.stageid)
                        s2.timestamp, s1.workorderid, s1.stageid
                    FROM wms_tasklist s1
                    JOIN wms_workflow_eventlog_details s2 ON s2.wfeventid = s1.wfeventid
                    WHERE (s1.itracksconfig ->> 'isCustomer')::boolean = true
                        AND s2.operationtype = 'Completed'
                ) cust ON cust.workorderid = wo.workorderid AND cust.stageid = ws.wfstageid
            
                WHERE
                    ws.status = 'Completed'
                    AND DATE(ws.enddatetime) BETWEEN '${startDate}' AND '${endDate}'
                    AND du.duid = ${duId}
                    ${condition ? `AND ${condition}` : ''}
            
            ) res
            ORDER BY res.enddatetime ASC
            `;
  } else if (type === 'groupByTask') {
    sql = `${qry_wms_delivery_monitoring_report} 
    WHERE wms_workorder_stage.status = 'Completed' AND DATE(wms_workorder_stage.enddatetime) >= '${startDate}' AND DATE(wms_workorder_stage.enddatetime) <= '${endDate}'
    AND org_mst_deliveryunit.duid = ${duId} AND wms_workorder_stage.stageiterationcount = ${stageiterationcount}  ${
      condition ? `AND ${condition}` : ''
    }`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getMonitoringReportOptionList = (req, res) => {
  const { duId, type, filterObj } = req.body;
  const customerCon = filterObj;
  const serviceCon = filterObj;
  const stageCon = filterObj;
  const pmCon = filterObj;
  const workflowCon = filterObj;
  const softwareCon = filterObj;

  let sql = '';
  if (type === 'customer') {
    for (const key in customerCon) {
      if (key == 'customerid') {
        delete customerCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in customerCon) {
      if (Object.prototype.hasOwnProperty.call(customerCon, key)) {
        let value = '';
        if (Array.isArray(customerCon[key])) {
          customerCon[key].forEach((data, i) => {
            value +=
              customerCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += customerCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(customerCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (customerid) customerid as value, customername as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
    `;
    // else {
    //   sql = `SELECT customerid as value, customername as label  FROM org_mst_customer
    //     WHERE duid = ${duId} ORDER BY stageid ASC `;
    // }
  } else if (type === 'service') {
    for (const key in serviceCon) {
      if (key == 'customerid') {
        delete serviceCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in serviceCon) {
      if (Object.prototype.hasOwnProperty.call(serviceCon, key)) {
        let value = '';
        if (Array.isArray(serviceCon[key])) {
          serviceCon[key].forEach((data, i) => {
            value +=
              serviceCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += serviceCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(serviceCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (serviceid) serviceid as value, servicename as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
   `;
  } else if (type === 'stage') {
    for (const key in stageCon) {
      if (key == 'stageid') {
        delete stageCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in stageCon) {
      if (Object.prototype.hasOwnProperty.call(stageCon, key)) {
        let value = '';
        if (Array.isArray(stageCon[key])) {
          stageCon[key].forEach((data, i) => {
            value +=
              stageCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += stageCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(stageCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (stageid) stageid as value, stagename as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
   `;
  } else if (type === 'pm') {
    for (const key in pmCon) {
      if (key == 'userid') {
        delete pmCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in pmCon) {
      if (Object.prototype.hasOwnProperty.call(pmCon, key)) {
        let value = '';
        if (Array.isArray(pmCon[key])) {
          pmCon[key].forEach((data, i) => {
            value += pmCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += pmCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(pmCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (contactname) contactname as value, contactname as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId} AND contactname IS NOT NULL  ${
      condition ? `AND${condition}` : ''
    }
   `;
  } else if (type === 'workflow') {
    for (const key in workflowCon) {
      if (key == 'workflowid') {
        delete workflowCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in workflowCon) {
      if (Object.prototype.hasOwnProperty.call(workflowCon, key)) {
        let value = '';
        if (Array.isArray(workflowCon[key])) {
          workflowCon[key].forEach((data, i) => {
            value +=
              workflowCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += workflowCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(workflowCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    let inValues = '';
    if ('customerid' in filterObj && filterObj.customerid === '5') {
      inValues = `'Bookwise','Chapterwise'`;
    } else if ('customerid' in filterObj && filterObj.customerid === '6') {
      inValues = `'Articlewise','Issuewise'`;
    }
    sql = `SELECT DISTINCT ON (wfid) wfid as value, wfname as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    } ${inValues ? `AND wfcategory IN (${inValues})` : ''}
   `;
  } else if (type === 'software') {
    for (const key in softwareCon) {
      if (key == 'softwareid') {
        delete softwareCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in softwareCon) {
      if (Object.prototype.hasOwnProperty.call(softwareCon, key)) {
        let value = '';
        if (Array.isArray(softwareCon[key])) {
          softwareCon[key].forEach((data, i) => {
            value +=
              softwareCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += softwareCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(softwareCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (softwareid) softwareid as value, softwarename as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
   `;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const insertWipStageNotes = (req, res) => {
  const bodyparam = JSON.stringify(req.body);

  const sql = `select * from  insert_wipstage_notes ('${bodyparam}')`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).sen({ data: error.message() });
    });
};

export const ftpjobretrigger = (req, res) => {
  const { emailtranid, userid } = req.body;
  const sql = `UPDATE ftp_audit_wo_creation SET isactive = false,isretrigger = true,userid='${userid}',updatedon = now() WHERE auditid = ${emailtranid}`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).sen({ data: error.message() });
    });
};

export const getdownloadmanuscript = async (req, res) => {
  const reqData = req.body;
  const jdata = reqData.params;

  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  // let condition = '';
  // if (reqData.type === 'filter') {
  //   offset = 0;
  //   reqData.filter.forEach((item, i) => {
  //     condition +=
  //       reqData.filter.length - 1 !== i
  //         ? ` LOWER(${
  //             item.name
  //           }::text) LIKE '%${item.value.toLowerCase()}%' AND `
  //         : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
  //   });
  //
  // }
  sql = `SELECT COUNT(*) FROM public.getdownload_manuscript('${jdata}')`;

  await query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        // const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);

        const sqlQuery = `select * from public.getdownload_manuscript('${jdata}')`;

        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getManuscriptStatus = (req, res) => {
  const reqData = req.body;

  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
  }
  sql = `SELECT COUNT(*) from springer.trn_jobdetails ${
    condition ? `WHERE${condition}` : condition
  } where duid = ${req.body.duid}`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);

        const sqlQuery = `SELECT * from springer.trn_jobdetails ${
          condition ? `WHERE${condition}` : condition
        } where duid = ${
          req.body.duid
        } LIMIT ${recordPerPage} OFFSET ${offset}`;

        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getdownloadmanuscriptfile = (req, res) => {
  try {
    let sql = '';
    sql = `SELECT * FROM springer.trn_jobdetails a1 INNER JOIN  springer.trn_download_upload a2
    ON a1.jobcodeid = a2.jobcodeid INNER JOIN springer.mst_jobsheettype a3 ON 
    a2.currentjobsheettype = a3.jobsheettypeid INNER JOIN public.mst_jobstatus a4 ON a2.currentstatus = a4.statusid and a2.logstatus = a4.statusid where a1.jobcodeid = ${req.body.jobcodeid} ORDER BY a1.jobcodeid ASC `;

    query(sql)
      .then(data => {
        res.status(200).json({
          data,
        });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const getSwiftXMLReport = async (req, res) => {
  const { fromdate, todate } = JSON.parse(req.body.params);
  const sql = `select bookcode,stepcode,requestbody,response,case when issuccess=true then 'Success' when issuccess=false then 'Failed' else 'WIP'  end as issuccess,TO_CHAR(createddate::timestamp(0) +interval '330 minute', 'dd-Mon-YYYY HH:MI:SS') as createddate from trn_swiftapicalldetails where
  createddate BETWEEN '${fromdate}' and '${todate}' order by createddate desc`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getLicenseChaserReport = async (req, res) => {
  const { fromdate, todate, duId } = JSON.parse(req.body.params);
  const sql = `select j.journalacronym || '(1,2,2,5,1)' as journalacronym,wo.itemcode,TO_CHAR(wo.createdon::timestamp(0) +interval '330 minute', 'dd-Mon-YYYY HH:MI:SS') as createdon,
  CASE WHEN chasercount = 1 THEN TO_CHAR(cm.created_time::timestamp(0) +interval '330 minute', 'dd-Mon-YYYY HH:MI:SS') end as remainder1,
  CASE WHEN chasercount = 2 THEN TO_CHAR(cm.created_time::timestamp(0) +interval '330 minute', 'dd-Mon-YYYY HH:MI:SS') end as remainder2,
  CASE WHEN chasercount = 3 THEN TO_CHAR(cm.created_time::timestamp(0) +interval '330 minute', 'dd-Mon-YYYY HH:MI:SS') end as remainder3,
  CASE WHEN chasercount = 4 THEN TO_CHAR(cm.created_time::timestamp(0) +interval '330 minute', 'dd-Mon-YYYY HH:MI:SS') end as remainder4,
  CASE WHEN chasercount = 5 THEN TO_CHAR(cm.created_time::timestamp(0) +interval '330 minute', 'dd-Mon-YYYY HH:MI:SS') end as escalation,
  CASE WHEN chasercount = 1 THEN 'Received'
  WHEN chasercount = 2 THEN 'Received'
  WHEN chasercount = 3 THEN 'Received' 
  WHEN chasercount = 4 THEN 'Received'
  WHEN chasercount = 5 THEN 'Received'
  else 'Not Received'
  end as received 
  from public.wms_workorder wo
  left join public.trn_ChaserMail cm ON wo.workorderid = cm.workorderid
  join public.pp_mst_journal j ON j.journalid = wo.journalid
  join public.org_mst_customerorg_du_map du on du.custorgmapid=j.custorgmapid where wo.createdon BETWEEN '${fromdate}' and '${todate}' and du.duid='${duId}' order by wo.createdon desc`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const activityTrackList = async (req, res) => {
  try {
    const reqData = req.body;
    // const { pageNo } = reqData;
    // const { recordPerPage } = reqData;
    // let offset = (pageNo - 1) * recordPerPage;
    let sql = '';
    let condition = '';
    if (reqData.type === 'filter') {
      //  offset = 0;
      reqData.filter.forEach((item, i) => {
        condition +=
          reqData.filter.length - 1 !== i
            ? ` LOWER(${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%' :: text AND `
            : ` LOWER(${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%' :: text`;
      });
    }
    sql = `select count(*) from wms_workorder_activity_audit as wwaa
    join wms_workflow_eventlog on wms_workflow_eventlog.wfeventid = wwaa.wfeventid
    join wms_workorder on wms_workorder.workorderid= wms_workflow_eventlog.workorderid
    join wms_workflowdefinition  on wms_workflowdefinition.wfdefid=wms_workflow_eventlog.wfdefid
    join wms_mst_activity on wms_mst_activity.activityid= wms_workflowdefinition.activityid
    join wms_mst_stage on wms_mst_stage.stageid= wms_workflowdefinition.stageid  ${
      condition ? `WHERE${condition}` : condition
    }`;

    const getCount = await query(sql);

    if (getCount[0].count > 0) {
      // const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
      const sqlQuery = `select itemcode,stagename,activityname,actiontype, age(updatedon, wwaa.createdon)::text as duration, concat(username, ' (', wms_user.userid, ')') as updatedby, 
      case when systeminfo::JSON->> 'systemIP' is null 
	  	then systeminfo::JSON->> 'SYSTEM_NAME' 
			else systeminfo::JSON->> 'systemIP' end as systemip 
      from wms_workorder_activity_audit as wwaa
          join wms_workflow_eventlog on wms_workflow_eventlog.wfeventid = wwaa.wfeventid
          join wms_workorder on wms_workorder.workorderid= wms_workflow_eventlog.workorderid
          join wms_workflowdefinition  on wms_workflowdefinition.wfdefid=wms_workflow_eventlog.wfdefid
          join wms_mst_activity on wms_mst_activity.activityid= wms_workflowdefinition.activityid
          join wms_mst_stage on wms_mst_stage.stageid= wms_workflowdefinition.stageid 
          join wms_user on wms_user.userid= wwaa.updatedby  ${
            condition ? `WHERE${condition}` : condition
          }
        ORDER BY activityauditid DESC `;

      const data = await query(sqlQuery);
      res.status(200).json({
        data,
      });
    } else {
      res.status(200).json({ data: [], message: 'No data found' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getactivitystartend = (req, res) => {
  // select * from getactivity_startend('{"startdate":"2023-02-28 00:00:00","enddate":"2023-03-28 00:00:00","stagename":"Typescript","activity":"FQA","itemcode":"testing-template02"}');
  const reqData = req.body;
  const jdata = reqData.params;
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.getactivity_startend('${jdata}')`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `select * from public.getactivity_startend('${jdata}')`;

        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageCreatedCount = (req, res) => {
  const { duID, startdate, enddate } = req.body;

  const sql = `WITH inflow_data AS (
                  SELECT
                      org_mst_customer.customername::varchar AS customer_name,
                      ww1.wfname::varchar AS workflow,
                      pmj.journalacronym::varchar AS journal,
                      ww.itemcode::varchar AS job_id,
                      REPLACE(ww.itemcode, pmj.journalacronym, '')::varchar AS aid,
                      ww.title::varchar AS job_name,
                      COALESCE(ww.otherfield ->> 'pii', 'NA')::varchar AS pii,
                      COALESCE(INITCAP(ww.otherfield ->> 'is_re_routed'), 'NA') AS isrerouted,
                      wws.plannedenddate,
                      wws.ordermaildatetime,
                      wws.updatedby,
                      wms_user.username,
                      wms.stagename,
                      wws.stageiterationcount,
                      COALESCE(incfd.mspages, 0) AS mspages
                  FROM wms_workorder_stage wws
                  JOIN wms_workorder ww ON ww.workorderid = wws.workorderid AND ww.isactive = true
                  LEFT JOIN wms_workflow ww1 ON ww1.wfid = ww.wfid
                  LEFT JOIN pp_mst_journal pmj ON pmj.journalid = ww.journalid
                  JOIN wms_mst_service ON wms_mst_service.serviceid = wws.serviceid
                  LEFT JOIN wms_workorder_stage_instructions wi ON wi.wostageid = wws.wostageid
                  JOIN org_mst_customer ON org_mst_customer.customerid = ww.customerid
                  JOIN org_mst_customer_orgmap AS customermap 
                      ON customermap.customerid = ww.customerid 
                      AND customermap.divisionid = ww.divisionid 
                      AND customermap.subdivisionid = ww.subdivisionid 
                      AND customermap.countryid = ww.countryid
                  JOIN org_mst_customerorg_du_map du_map ON du_map.custorgmapid = customermap.custorgmapid
                  JOIN org_mst_deliveryunit du ON du.duid = du_map.duid
                  JOIN wms_mst_stage wms ON wms.stageid = wws.wfstageid AND wms.stageid <> 10
                  JOIN wms_user ON wms_user.userid = wws.updatedby
                  LEFT JOIN (
                      SELECT woincomingid, woid, stageid FROM public.wms_workorder_incoming
                  ) AS inc ON inc.woid = ww.workorderid
                  LEFT JOIN (
                      SELECT woincomingid, mspages FROM PUBLIC.wms_workorder_incomingfiledetails
                  ) AS incfd ON incfd.woincomingid = inc.woincomingid
                  WHERE du.duid = $1
                    AND wws.ordermaildatetime IS NOT NULL
                    AND wws.wfstageid IS NOT NULL
                    AND (wws.ordermaildatetime + INTERVAL '5 hours 30 minutes')::DATE BETWEEN $2 AND $3
              )
              SELECT
                  customer_name AS "Customer",
                  workflow AS "Workflow",
                  journal AS "Journal",
                  job_id AS "Job Code",
                  aid AS "AID",
                  job_name AS "Job Name",
                  pii AS "PII",
                  isrerouted AS "Rerouted",
                  ordermaildatetime AS "Created On",
                  plannedenddate AS "Due On",
                  CASE 
                      WHEN updatedby ILIKE '%System%' THEN 'WMS'
                      ELSE CONCAT(username, ' (', updatedby, ')')::varchar
                  END AS "Created By",
                  CASE
                      WHEN stagename = 'Stage 200' THEN 'S200'
                      WHEN stagename = 'Stage 300' THEN 
                          CASE WHEN stageiterationcount = 1 THEN 'S300'
                              ELSE CONCAT('S300 R',' (', (stageiterationcount-1)::text, ')') END
                      WHEN stagename = 'Stage200 Revises' THEN 
                          CONCAT('S200 R',' (', stageiterationcount::text, ')')
                      WHEN stagename = 'Stage 600' THEN 
                          CASE WHEN stageiterationcount = 1 THEN 'S600'
                              ELSE CONCAT('S600',' (', stageiterationcount::text, ')') END
                      ELSE
                          CONCAT(stagename,' (', stageiterationcount::text, ')')
                  END::character varying AS "Stage",
                  mspages AS "Mspages"
              FROM inflow_data
              ORDER BY ordermaildatetime DESC;`;

  query(sql, [duID, startdate, enddate])
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getDespatchFailureReport = async (req, res) => {
  const { duID } = req.body;

  const sql = `select * from get_despatchfailure_report_data(${duID}) `;
  // const sql = `select * from get_despatchfailure_report_data_fpfw(${duID})`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWipEngineActivityReport = async (req, res) => {
  // const { duID } = req.body;

  const sql = `SELECT * FROM public.getwip_engine_status_report()`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getAuditReport = async (req, res) => {
  const { duId, startdate, enddate } = req.body;
  // dummy data entry into the table
  const sql = `select  * from public.wms_toolsupload_actions_audit where duid = (${duId})
  and createdon BETWEEN '${startdate}' and '${enddate}'`;

  query(sql)
    // eslint-disable-next-line no-unused-vars
    .then(data => {
      // data.forEach(list => {
      //   const fileName = list.filename;
      //
      //   const parsedFileName = path.parse(fileName);
      //   list.filename = parsedFileName.base;
      //
      // });
      //
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getToolsMasterAccessRightsReport = async (req, res) => {
  const { duId } = req.body;

  const sql = `select * from public.wms_toolsmasteraccessrights_report where duid = (${duId})`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getToolsMasterAccessRights = async (req, res) => {
  const { duId, userid } = req.body;

  // const sql = `select * from public.wms_toolsmasteraccessrights_report where duid = (${duId})`;
  const sql = `select * from wms_tools_accessrights rights
  join wms_toolsmaster_serverpath toolsmaster ON toolsmaster.exeid = rights.exeid
  where toolsmaster.duid =${duId} and rights.userid = '${userid}'`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getToolsListServerPath = async (req, res) => {
  // const sql = `select * from wms_toolsmaster_serverpath `;
  const sql = `select tool.toolid as exeid,type.tooltype,tool.toolname as exename,tool.tooldescription,tool.customerid,((tool.payload->>'dependentFiles')::json)->0->'src' as path  
  from pp_mst_tool tool
  join pp_mst_tooltype type on type.tooltypeid = tool.tooltypeid
  where tool.tooltypeid = 2 and tool.toolstatus = true`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
//  getUsersByCustomer
export const getUsersByCustomer = async (req, res) => {
  const datas = req.body;

  const { toolname } = datas;

  const { customername } = req.body;
  const customerNameString = customername
    .map(name => `'${name.trim()}'`)
    .join(', ');

  const sql = `SELECT res1.username,res1.userid, acr.read as checked,acr.upload as isUpchecked,acr.delete as isDownchecked  FROM
  (
    select wuser.username,wuser.userid,wuser.useractive,wuser.duid,
    customer.customerid,customer.customername
    from  
    public.org_mst_customer customer 
    join org_mst_customer_orgmap custmap ON custmap.customerid = customer.customerid
    join org_mst_customerorg_du_map dumap ON dumap.custorgmapid = custmap.custorgmapid
    join org_mst_deliveryunit du ON du.duid =dumap.duid
    left join wms_user wuser ON wuser.duid = du.duid
    where customer.customername IN (${customerNameString}) 
    group by wuser.username,wuser.userid,wuser.useractive,wuser.duid,
    customer.customerid,customer.customername
  ) AS res1
  LEFT JOIN wms_tools_accessrights as acr on acr.userid = res1.userid and acr.customerid = res1.customerid and acr.toolname = ('${toolname}')
  group by res1.username,res1.userid, acr.read,acr.upload,acr.delete`;

  query(sql)
    .then(data => {
      data.forEach(list => {
        list.isUpchecked = list.isupchecked;
        list.isDownchecked = list.isdownchecked;
      });

      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Get users by DU
export const getUsersByDeliveryUnit = async (req, res) => {
  const datas = req.body;
  const { toolname } = datas;
  console.log('toolname', toolname);

  const { customername } = req.body;
  if (!customername || !Array.isArray(customername)) {
    return res.status(400).send({ message: 'Invalid deliveryunit data' });
  }

  const deliveryUnitString = customername
    .map(unit => `'${unit.trim()}'`)
    .join(', ');
  const sql = `SELECT res1.username, res1.userid, acr.read as checked, acr.upload as isUpchecked, acr.delete as isDownchecked FROM
  (
    SELECT wuser.username, wuser.userid, wuser.useractive, du.duid as wuser_duid,
    du.duid as du_duid, du.duname
    FROM  
    public.org_mst_deliveryunit du
    LEFT JOIN wms_user wuser ON wuser.duid = du.duid
    WHERE du.duname IN (${deliveryUnitString}) 
    GROUP BY wuser.username, wuser.userid, wuser.useractive, wuser.duid,
    du.duid, du.duname
  ) AS res1
  LEFT JOIN wms_tools_accessrights acr ON acr.userid = res1.userid AND acr.duid = res1.wuser_duid AND acr.toolname = ('${toolname}')
  GROUP BY res1.username, res1.userid, acr.read, acr.upload, acr.delete`;

  try {
    const data = await query(sql);
    data.forEach(list => {
      list.isUpchecked = list.isupchecked;
      list.isDownchecked = list.isdownchecked;
    });
    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ message: error });
  }
  return '';
};

export const postToolsMasterAccessRights = async (req, res) => {
  try {
    const { toolslist, toolsdescription, toolpath, checkedData, customername } =
      req.body;

    const toolSql = `
      SELECT toolid FROM pp_mst_tool tool
      JOIN pp_mst_tooltype type ON type.tooltypeid = tool.tooltypeid
      WHERE tool.tooltypeid = 2 AND tool.toolstatus = true AND tool.toolname = $1
    `;
    const toolResult = await query(toolSql, [toolslist]);
    const exeid = toolResult[0]?.toolid;

    if (!exeid) {
      throw new Error('Tool not found');
    }

    for (const data of checkedData) {
      const detailsSql = `
        SELECT wuser.useractive, wuser.duid
        FROM wms_user wuser
        JOIN org_mst_deliveryunit du ON du.duid = wuser.duid
        WHERE du.duname = $1 AND wuser.userid = $2
      `;
      const detailsResult = await query(detailsSql, [
        customername[0].value,
        data.userid,
      ]);
      const userDetails = detailsResult[0];

      if (!userDetails) {
        return;
      }

      const deleteSql = `
        DELETE FROM wms_tools_accessrights 
        WHERE userid = $1 
        AND duid = $2
        AND toolname = $3
      `;
      await query(deleteSql, [data.userid, userDetails.duid, toolslist]);

      const insertSql = `
        INSERT INTO wms_tools_accessrights (
          exeid, toolname, tooldescription, toolpath, username, userid,
          useractive, read, upload, delete, duid, customerid, customername
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $11, $12)
      `;

      await query(insertSql, [
        exeid,
        toolslist,
        toolsdescription,
        toolpath,
        data.username,
        data.userid,
        userDetails.useractive,
        data.checked || false,
        data.isUpchecked || false,
        data.isDownchecked || false,
        userDetails.duid,
        customername[0].value,
      ]);
    }

    res.status(200).json({ message: 'Records updated successfully' });
  } catch (err) {
    console.error('postToolsMasterAccessRights error:', err);
    res.status(500).send({
      message: err.message || 'Internal server error',
      error: err,
    });
  }
};

export const addNewTool = async (req, res) => {
  try {
    const {
      exename,
      tooldescription,
      path,
      customername,
      tooltype,
      servername,
    } = req.body;

    const sql = `
      SELECT * from public.add_new_tool(
        $1, $2, $3, $4, $5, $6
      ) AS result;
    `;

    const result = await query(sql, [
      exename,
      tooldescription,
      path,
      customername,
      tooltype,
      servername,
    ]);

    if (result && result[0].result == -1) {
      res.status(200).json({ message: 'Tool already exist' });
    } else {
      res.status(200).json({ success: 'Tool Added Successfully' });
    }
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const getCompletedWorkOrders = async (req, res) => {
  const jsonparam = JSON.stringify(req.body);

  try {
    const sql = `
      SELECT serialno, workorderid, itemcode, title, customername, division, subdivision, countryname,
      enddatetime, duid, customerid, divisionid, subdivisionid, wfid
      FROM public.getcompletedjobs('${jsonparam}')
    `;

    query(sql)
      .then(data => {
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error.message });
      });
  } catch (err) {
    console.error(err);
  }
};

export const getFTPAuditReport = async (req, res) => {
  const { duID } = req.body;

  const sql = `select * from public.get_ftpreport_data(${duID})`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFTPDownloadReportSpringer = async (req, res) => {
  // const { duID } = req.body;

  const sql = `select journalname  ,bookcode  ,downloadstarttime ,downloadendtime , filepath  , receiveddate ,packagename ,packagetype ,
  statusdescription  ,status , remarks ,duid ,zipfileid , processtype,stageid, retrycount
  from springer.get_ftpdownloaduploadspringer()`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFilepathforSpringer = async (req, res) => {
  try {
    const { stageid, duID } = req.body;
    const sqlqry = `SELECT * FROM springer.ice_integrasettings where iceuserid='${duID}' and lock = false`;
    const data = await query(sqlqry);
    let response = '';
    switch (stageid) {
      case 5:
        response = data[0].s5ftppath;
        break;
      case 50:
        response = data[0].s50ftppath;
        break;
      case 200:
        response = data[0].s200ftppath;
        break;
      case 210:
        response = data[0].s210ftppath;
        break;
      case 300:
        response = data[0].s300ftppath;
        break;
      case 600:
        response = data[0].s600ftppath;
        break;
      case 650:
        response = data[0].s650ftppath;
        break;
      default:
        response = '';
        break;
    }
    res.status(200).send({ response, fileserverpath: data[0].fileserverpath });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getDownloadUploadManuscriptReport = async (req, res) => {
  const { duID, stageid, start, end } = req.body;

  try {
    const sql = `select * from springer.get_downloadmanuscriptreport_data(${duID},'${stageid}', '${start}', '${end}') `;
    query(sql)
      .then(data => {
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
    // eslint-disable-next-line no-empty
  } catch (error) {}
};

export const getJobsheetHistoryforSpringer = async (req, res) => {
  try {
    const { stageid, duID, bookcode } = req.body;
    const sqlqry = `select * from springer.get_jobsheet_history_data(${duID},'${stageid}', '${bookcode}')`;

    const data = await query(sqlqry);
    //
    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getOverallJobHistory = async (req, res) => {
  try {
    const { duId, fromdate, todate } = req.body;

    const sqlqry = `SELECT 
    jo.journalacronym as journalname  ,wo.itemcode, mst.stagename, 
    ws.status, ws.ordermaildatetime, ws.enddatetime, 
    round ((extract(epoch from ws.enddatetime - ws.ordermaildatetime)/ 60 )/60) as hours
    FROM wms_workorder AS wo
    JOIN pp_mst_journal AS jo ON jo.journalid = wo.journalid
    JOIN wms_workorder_stage AS ws ON ws.workorderid = wo.workorderid 
    JOIN wms_mst_stage AS mst ON mst.stageid = ws.wfstageid
    JOIN org_mst_customer_orgmap AS org ON org.customerid = wo.customerid 
    AND org.divisionid = wo.divisionid AND org.subdivisionid = wo.subdivisionid AND org.countryid = wo.countryid
    JOIN org_mst_customerorg_du_map AS cdm ON cdm.custorgmapid = org.custorgmapid
    WHERE cdm.duid = ${duId}     
    and ws.ordermaildatetime is not null 
    and ws.enddatetime is not null 
    and ws.ordermaildatetime between ('${fromdate}'::Date)::timestamp(0) and  ('${todate}'::Date)::timestamp(0) 
    ORDER BY wo.workorderid , ws.wostageid`;

    const data = await query(sqlqry);

    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getFTPDownloadReportACS = async (req, res) => {
  const { duID } = req.body;

  const sql = `select c.journalacronym as journalname,a.mscno as bookcode, case when a.transcode =100 then 
  'Conversion' when a.transcode = 140 then 'Graphics' when a.transcode= 840 then 'Copyediting' when a.transcode =111 
  then 'ConversionACK' when a.transcode = 151 then 'GraphicsACK' when a.transcode= 851 then 'CopyeditingACK' else ''
  end as stagename,  a.zipname as Packagename,a.createddate,case when a.statusid = 4 then 'Success' 
  when a.statusid = 5 then 'Failure' when  a.statusid = 1 or a.statusid = 11 or a.statusid = 21 then 'YTS' else 'WIP'end as status,
  a.remarks,a.xmlnotificationid from public.acs_mst_notificationdetails a 
  left join public.wms_workorder b on b.itemcode =a.mscno left join pp_mst_journal c on b.journalid = c.journalid
   
  LEFT JOIN org_mst_customer_orgmap AS customermap ON (
      customermap.customerid = b.customerid 
      AND customermap.divisionid = b.divisionid 
      AND customermap.subdivisionid = b.subdivisionid 
      AND customermap.countryid = b.countryid
    )
    LEFT JOIN org_mst_customerorg_du_map du_map ON du_map.custorgmapid = customermap.custorgmapid
    LEFT JOIN org_mst_deliveryunit du ON du.duid = du_map.duid
    where du.duid = ${duID}
    ORDER BY a.createddate desc`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getCopyeditingQueACS = async (req, res) => {
  // const { duID } = req.body;

  // const sql = `SELECT wo.itemcode , jm.journalacronym , wo.workorderid, am.createddate as receiveddate,inc.wordcount,
  //    inc.referencecount,inc.imagecount,inc.equationcount,inc.tablecount FROM wms_workorder wo left join
  //    pp_mst_journal jm on wo.journalid = jm.journalid  left join public.acs_mst_notificationdetails am
  //   on am.mscno=wo.itemcode   join wms_workorder_incomingfiledetails inc on wo.itemcode=inc.filename
  //    where  am.transcode=840 and wo.customerid = ${duID} `;

  const sql = `select distinct
    pmj.journalacronym as journalname
    ,ww.itemcode as bookcode
    ,ww.workorderid as workorderid
    ,wwi.wordcount as wordcount
    ,amn.createddate as receiveddate
    ,wws.plannedenddate as ceduedate  
    ,wws.plannedenddate as customerduedate  
    ,c.name as pme
  ,activitystatus as status
    ,wwi.equationcount as equationcount
    ,wwi.referencecount as referencecount
    ,wwi.tablecount as tablecount
    ,wwi.imagecount as imagecount
    from wms_workorder ww
    inner join pp_mst_journal pmj on pmj.journalid=ww.journalid and pmj.isactive =1
    inner join wms_workorder_incomingfiledetails wwi on wwi.filename = ww.itemcode
    inner join acs_mst_notificationdetails amn on amn.mscno = ww.itemcode and amn.islock ='N'
    inner join wms_workorder_stage wws on wws.workorderid=ww.workorderid and wws.wfstageid =24
    left join pp_mst_journal_contacts c on c.journalid = pmj.journalid and designation='6'
   join wms_workflow_eventlog wwe on wwe.workorderid=ww.workorderid and wwe.activitystatus<>'Completed'   
    where ww.customerid = 15 and amn.transcode = 840
    and ww.isactive ='true'`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFilepathforACS = async (req, res) => {
  try {
    const sqlqry = `select iceserverpath,sourcepath from public.acs_integrasettings`;

    const data = await query(sqlqry);
    const response = data;
    res.status(200).send({ response });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getAcknowledgementReportACS = async (req, res) => {
  try {
    const { fromdate, todate } = req.body;

    const sqlqry = `WITH res1 AS (
      SELECT 
          wo.workorderid,
          wo.itemcode,
          jo.journalacronym,
          ws.wfstageid,
          st.stagename,
          CASE 
              WHEN wfstageid = 72 THEN 'convert_response_ack'
              WHEN wfstageid = 10 THEN 'graphics_response_ack'
              WHEN wfstageid = 24 THEN 'vendor_tech_edit_response_ack'
              ELSE ''
          END AS transdesc
      FROM wms_workorder AS wo
      JOIN pp_mst_journal AS jo ON jo.journalid = wo.journalid
      JOIN wms_workorder_stage AS ws ON ws.workorderid = wo.workorderid
      JOIN wms_mst_stage AS st ON st.stageid = ws.wfstageid
      WHERE wo.customerid = 15
        AND wo.isactive = TRUE
      ORDER BY wo.itemcode
  ),
  res2 AS (
      SELECT 
          wo.workorderid,
          wo.itemcode,
          stg.stagename,
          wfdef.stageid,
          an.transdesc,
          an.packageack,
          an.remarks,
          wfdef.seq,
          evd.timestamp AS completedon,
          CASE 
              WHEN an.createddate IS NULL THEN ROUND(EXTRACT(EPOCH FROM NOW()::timestamp - evd.timestamp) / 60)
              ELSE ROUND(EXTRACT(EPOCH FROM an.createddate::timestamp - evd.timestamp::timestamp) / 60)
          END AS diff,
          an.createddate AS receivedon,
          an.notification_count,
          an.updated_pkg_count,
          (SELECT COUNT(*) from wms_tools_api where  toolid =413 
       and status ='Success' and remarks !='skipped'
       and wfeventid = ev.wfeventid) AS completed_count
      FROM wms_workorder AS wo
      JOIN public.wms_workflow_eventlog AS ev 
          ON wo.workorderid = ev.workorderid
         AND ev.activitystatus = 'Completed'
      JOIN (
          SELECT wfdefid, stageid, sequence AS seq
          FROM public.wms_workflowdefinition
          WHERE wfid = 35
            AND activityid IN (22)
          ORDER BY sequence ASC
      ) AS wfdef ON wfdef.wfdefid = ev.wfdefid
      JOIN public.wms_mst_stage AS stg ON stg.stageid = wfdef.stageid
      JOIN public.wms_workflow_eventlog_details AS evd 
          ON evd.wfeventid = ev.wfeventid
         AND evd.operationtype = 'Completed'
         AND evd.wfeventdetailid = (
             SELECT MAX(wfeventdetailid)
             FROM public.wms_workflow_eventlog_details
             WHERE wfeventid = ev.wfeventid
               AND operationtype = 'Completed'
         )
      LEFT JOIN (
          SELECT 
              CASE 
                  WHEN transcode = 111 THEN 72
                  WHEN transcode = 151 THEN 10
                  ELSE 24
              END AS stageid,
              transcode,
              CASE 
                  WHEN transcode = 111 THEN 'convert_response_ack'
                  WHEN transcode = 151 THEN 'graphics_response_ack'
                  ELSE 'vendor_tech_edit_response_ack'
              END AS transdesc,
              mscno,
              packageack,
              createddate,
              remarks,
              xmlnotificationid,
              (SELECT COUNT(*) 
               FROM public.acs_mst_notificationdetails AS sub
               WHERE sub.mscno = acs_mst_notificationdetails.mscno
                 AND sub.transcode = acs_mst_notificationdetails.transcode) AS notification_count,
              (SELECT COUNT(*) 
               FROM public.acs_mst_notificationdetails AS sub
               WHERE sub.mscno = acs_mst_notificationdetails.mscno
                 AND sub.transcode = 
                 CASE 
                     WHEN acs_mst_notificationdetails.transcode = 111 THEN 100
                     WHEN acs_mst_notificationdetails.transcode = 151 THEN 140
                     ELSE 840 
                 END
                 AND remarks = 'Updated Package') AS updated_pkg_count
          FROM public.acs_mst_notificationdetails
          WHERE transcode IN (111, 151, 851)
      ) AS an ON an.mscno = wo.itemcode
             AND an.stageid = wfdef.stageid
             AND an.xmlnotificationid = (
                 SELECT MAX(xmlnotificationid)
                 FROM public.acs_mst_notificationdetails
                 WHERE mscno = an.mscno
                   AND transcode = an.transcode
             )
      WHERE wo.workorderid IN (SELECT DISTINCT workorderid FROM res1)
        AND wo.customerid = 15
        AND wo.isactive = TRUE
      ORDER BY wo.itemcode, wfdef.seq
  ),
  res3 AS (
      SELECT 
          res1.workorderid,
          res1.itemcode,
          res1.stagename,
          res2.stageid,
          res1.transdesc,
          res2.packageack,
          CASE 
              WHEN res2.remarks IS NULL THEN 'Waiting for package'
              ELSE res2.remarks
          END AS remarks,
          res2.seq,
          res2.receivedon,
          res2.completedon::timestamp(0),
          res2.diff AS hours,
          res2.notification_count,
          res2.updated_pkg_count,res2.completed_count
      FROM res1
      LEFT JOIN res2 ON res1.workorderid = res2.workorderid
                    AND res1.wfstageid = res2.stageid
      WHERE res2.completedon::DATE BETWEEN '${fromdate}'::DATE AND '${todate}'::DATE
      ORDER BY res1.workorderid, res1.stagename
  )
  SELECT 
      res1.workorderid,
      res1.itemcode,
      res1.journalacronym,
      res1.stagename,
      res1.transdesc,
      res3.packageack,
      CASE 
          WHEN (notification_count - updated_pkg_count) < (completed_count)THEN 'Waiting for ack'
          ELSE 
              CASE 
                  WHEN res3.remarks IS NULL THEN 'Waiting for package'
                  ELSE res3.remarks
              END
      END AS remarks,
      CASE 
          WHEN res3.receivedon::timestamp < res3.completedon::timestamp THEN ''
          ELSE COALESCE((res3.receivedon + INTERVAL '5 hours 30 minutes')::timestamp(0)::TEXT, '')
      END AS receivedon,
      COALESCE((res3.completedon + INTERVAL '5 hours 30 minutes')::timestamp(0)::TEXT, '') AS completedon,
      CASE 
          WHEN res3.receivedon::timestamp < res3.completedon::timestamp THEN 
              TO_CHAR(CURRENT_TIMESTAMP - res3.completedon, 'HH24:MI')
          ELSE 
              CONCAT(
                  EXTRACT(HOUR FROM (res3.hours || ' minutes')::INTERVAL), ':',
                  EXTRACT(MINUTE FROM (res3.hours || ' minutes')::INTERVAL)
              )
      END AS hours,
      res3.notification_count,
      res3.updated_pkg_count,res3.completed_count
  FROM res1
  LEFT JOIN res3 ON res3.workorderid = res1.workorderid
                AND res3.stageid = res1.wfstageid
  WHERE res1.workorderid IN (SELECT workorderid FROM res3)
    AND res3.completedon IS NOT NULL
  ORDER BY res3.completedon DESC;`;

    const data = await query(sqlqry);

    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getFTPReport = async (req, res) => {
  const { duID } = req.body;

  const sql = `SELECT la.autologid, la.customer, la.filetype, la.wotype, la.jobtype, la.apiinput, la.payload,
       la.workorderid, la.logmessage,  TO_CHAR(la.createdon, 'YYYY-MM-DD HH24:MI:SS') AS createdon, la.trigerarticle, la.trigerstage,
       la.ftpauditid, c.auditid, c.ftpfilename, c.ftpfilepath, cc.customerid, omcdm.duid,
       case when la.issuccess  = 'true' then 'Completed'  when  la.issuccess  = 'false' then 'In Procress' 
         else 'N/A' end as status
  FROM log_autowocreate la
  LEFT JOIN ftp_audit_wo_creation c ON c.auditid = la.ftpauditid
  LEFT JOIN org_mst_customer cc ON UPPER(cc.customershortname) = UPPER(la.customer)
  LEFT JOIN wms_workorder ww ON ww.workorderid = la.workorderid
  LEFT JOIN org_mst_customer_orgmap omco ON omco.customerid = ww.customerid
      AND omco.divisionid = ww.divisionid
      AND omco.subdivisionid = ww.subdivisionid
      AND omco.countryid = ww.countryid
  LEFT JOIN org_mst_customerorg_du_map omcdm ON omcdm.custorgmapid = omco.custorgmapid
  WHERE 
      (
          omcdm.duid IS NULL AND 
          CASE 
              WHEN la.customer = 'OUP' THEN 63
              WHEN la.customer = 'WKH' THEN 12
              WHEN la.customer = 'KLI' THEN 93
              WHEN la.customer = 'ACS' THEN 92
              WHEN la.customer = 'CUP' THEN 7
              WHEN la.customer = 'Springer' THEN 9
              WHEN la.customer = 'Springer Books' THEN 11
          END = $1
      ) 
      OR (omcdm.duid = $1)
  ORDER BY la.autologid DESC;`;

  try {
    const data = await query(sql, [duID]);

    res.status(200).json({ data });
  } catch (error) {
    console.error('getFTPReport error:', error);
    res.status(400).send({ message: error.message });
  }
};

export const getTATWKH = async (req, res) => {
  const { stageID, endDate, country } = req.body;

  // SQL query to call the stored procedure
  const sql = `SELECT  public.get_final_time_test($1 ::integer, $2 ::date, $3 ::text) ::TEXT `;

  try {
    // Execute the query with parameters
    const data = await query(sql, [stageID, endDate, country]);

    // Send back the response with the data
    res.status(200).json({ data });
  } catch (error) {
    console.error('get_final_time error:', error);
    res.status(400).send({ message: error.message });
  }
};

export const getnotefromcustomerACS = async (req, res) => {
  try {
    const { duId, fromdate, todate } = req.body;

    const sqlqry = `WITH RankedNotes AS (
  SELECT 
    workorderid,
    stageid,
    activityid,
    customerid,
    92 as duid,
    note,
    createddate,
    ROW_NUMBER() OVER (
      PARTITION BY workorderid, customerid 
      ORDER BY createddate DESC
    ) AS rn
  FROM notestoacslog
)
SELECT 
 ROW_NUMBER() OVER (ORDER BY r.createddate DESC) AS serial,
  r.workorderid,
  w.itemcode,
  r.stageid,
  s.stagename,
  r.activityid,
  a.activityname,
  r.customerid,
  r.duid,
  r.note,
  TO_CHAR(r.createddate, 'YYYY-MM-DD HH24:MI:SS') AS createddate
FROM RankedNotes r
JOIN wms_workorder w 
  ON w.workorderid = r.workorderid AND w.isactive = true
join wms_mst_stage s 
  ON  s.stageid = r.stageid
join wms_mst_activity a
  ON  a.activityid = r.activityid
WHERE rn = 1 and  r.duid = ${duId}
and r.createddate::Date BETWEEN ('${fromdate}'::Date)::timestamp(0) and ('${todate}'::Date)::timestamp(0) 
ORDER BY r.createddate desc`;

    const data = await query(sqlqry);

    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getnotefromVendorReport = async (req, res) => {
  try {
    const { fromdate, todate } = req.body;

    if (!fromdate || !todate) {
      return res
        .status(400)
        .json({ error: 'Both fromdate and todate are required' });
    }

    const sqlqry = `
    SELECT
    no.workorderid,
    wo.itemcode,
    CONCAT(st.stagename, ' (', no.stageiterationcount, ')') AS stagename,
    CONCAT(COALESCE(at.activityname, 'NA'), ' (', COALESCE(no.activityiterationcount, '1'), ')') AS activityname,
    at.activityid,
    no.stageiterationcount,
    no.activityiterationcount,

    CASE
        WHEN no.createdby IS NULL THEN 'NA'
        ELSE CONCAT(us.username, ' (', no.createdby, ')')
    END AS username,
    no.note,

    TO_CHAR(no.createddate + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as createddate
    from notestoacslog no
    join wms_workorder wo  on no.workorderid = wo.workorderid
    join wms_mst_stage st on no.stageid = st.stageid
    join wms_mst_activity at on no.activityid = at.activityid
    left join wms_user us on no.createdby = us.userid
    WHERE
      no.createddate::date BETWEEN '${fromdate}'::date AND '${todate}'::date
    order by no.createddate desc
    `;

    // const sqlqry = `
    // SELECT
    // no.workorderid,
    // wo.itemcode,
    // CONCAT(st.stagename, ' (', no.stageiterationcount, ')') AS stagename,
    // CONCAT(at.activityname, ' (', et.activityiterationcount, ')') AS activityname,

    // at.activityid,
    // no.stageiterationcount,
    // et.activityiterationcount,

    // CONCAT(us.username, ' (', et.userid, ')') AS username,
    // no.note,

    // TO_CHAR(no.createddate + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as createddate
    // from notestoacslog no
    // join wms_workorder wo  on no.workorderid = wo.workorderid
    // join wms_mst_stage st on no.stageid = st.stageid
    // join wms_mst_activity at on no.activityid = at.activityid
    // join wms_workflow_eventlog et on et.workorderid = no.workorderid
    // AND
    //  et.wfdefid = case
    // when at.activityid = 130 then 1107
    // when at.activityid = 163 then 1106
    // when at.activityid = 137 then 1108
    // when at.activityid = 338 then 1109
    // else et.wfdefid
    // END
    // join wms_user us on us.userid = et.userid
    // WHERE
    //   no.createddate::date BETWEEN '${fromdate}'::date AND '${todate}'::date
    // order by 1 desc
    // `;

    const data = await query(sqlqry);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const doNotPublishReport = async (req, res) => {
  try {
    const { fromdate, todate } = req.body;

    if (!fromdate || !todate) {
      return res
        .status(400)
        .json({ error: 'Both fromdate and todate are required' });
    }

    // Enable this after 3 months
    const sqlqry = `select
        no.workorderid,
    wo.itemcode,

    CONCAT(st.stagename, ' (', no.stageiterationcount, ')') AS stagename,

    CONCAT(COALESCE(at.activityname, 'NA'), ' (', COALESCE(no.activityiterationcount, '1'), ')') AS activityname,

    at.activityid,
    no.stageiterationcount,
    no.activityiterationcount,

     CASE
             WHEN no.created_by IS NULL THEN 'NA'
             ELSE CONCAT(us.username, ' (', no.created_by, ')')
         END AS username,

    no.donotpublish,
    TO_CHAR(no.created_time + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as created_time
    from acs_donotpublish_details no
    join wms_workorder wo on no.workorderid = wo.workorderid
    join wms_mst_stage st on no.stageid = st.stageid
    join wms_mst_activity at on no.activityid = at.activityid
    left join wms_user us on no.created_by = us.userid
    WHERE
      no.created_time::date BETWEEN '${fromdate}'::date AND '${todate}'::date

    order by no.created_time desc`;

    // const sqlqry = `
    // SELECT
    // no.workorderid,
    // wo.itemcode,
    // CONCAT(st.stagename, ' (', no.stageiterationcount, ')') AS stagename,
    // CONCAT(at.activityname, ' (', et.activityiterationcount, ')') AS activityname,

    // at.activityid,
    // no.stageiterationcount,
    // et.activityiterationcount,

    // CONCAT(us.username, ' (', no.updated_by, ')') AS username,
    // no.donotpublish,

    // TO_CHAR(no.created_time + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as created_time
    // from acs_donotpublish_details no
    // join wms_workorder wo  on no.workorderid = wo.workorderid
    // join wms_mst_stage st on no.stageid = st.stageid
    // join wms_mst_activity at on no.activityid = at.activityid
    // join wms_workflow_eventlog et on et.workorderid = no.workorderid
    // AND
    //  et.wfdefid = case
    // when at.activityid = 130 then 1107
    // when at.activityid = 163 then 1106
    // when at.activityid = 137 then 1108
    // when at.activityid = 338 then 1109
    // else et.wfdefid
    // END
    // join wms_user us on us.userid = no.updated_by
    // WHERE
    //   no.created_time::date BETWEEN '${fromdate}'::date AND '${todate}'::date
    // order by 1 desc
    // `;

    const data = await query(sqlqry);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const convertFilesReport = async (req, res) => {
  try {
    const { fromdate, todate, duid } = req.body;

    if (!fromdate || !todate) {
      return res
        .status(400)
        .json({ error: 'Both fromdate and todate are required' });
    }

    // Enable this after 3 months
    const sqlqry = `select
        no.workorderid,
        wo.itemcode,
        CONCAT(st.stagename, ' (', no.stageiterationcount, ')') AS stagename,
        CONCAT(COALESCE(at.activityname, 'NA'), ' (', COALESCE(no.activityiterationcount, '1'), ')') AS activityname,
        at.activityid,
        no.stageiterationcount,
        no.activityiterationcount,
     CASE
        WHEN no.created_by IS NULL THEN 'NA'
        ELSE CONCAT(us.username, ' (', no.created_by, ')')
        END AS username,
    no.convertionfiles,
    TO_CHAR(no.created_time + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as created_time
    from acs_convertionfile_details no
    join wms_workorder wo on no.workorderid = wo.workorderid
    join wms_mst_stage st on no.stageid = st.stageid
    join wms_mst_activity at on no.activityid = at.activityid
    left join wms_user us on no.created_by = us.userid
    WHERE
      no.created_time::date BETWEEN '${fromdate}'::date AND '${todate}'::date AND no.duid = ${duid}
      order by no.created_time desc`;

    let data = await query(sqlqry);
    data = data.map(item => ({
      ...item,
      convertionfiles: item.convertionfiles
        .map(file => file.updatedFilename)
        .filter(name => name !== ''),
    }));
    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const getOverallFileOptionLists = async (req, res) => {
  try {
    const { customerid, duId } = req.body;
    // const sqlqry = `SELECT wfid as value, wfname as label FROM public.wms_workflow WHERE isactive = true AND customerid = ${customerid}`;
    const sqlqry = `SELECT DISTINCT ww2.wfid AS value, ww2.wfname AS label
                    FROM wms_workorder ww
                    JOIN wms_workflow ww2 ON ww2.wfid = ww.wfid AND ww2.isactive = true
                    WHERE ww.isactive = true AND ww.duid = ${duId}
                    ORDER BY ww2.wfname`;

    const data = await query(sqlqry);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const getOverallFileStatusReport = async (req, res) => {
  try {
    const { fromdate, todate, wfid } = req.body;

    if (!fromdate || !todate) {
      return res
        .status(400)
        .json({ error: 'Both fromdate and todate are required' });
    }

    const sqlqry = `
WITH cte AS (
    SELECT 
        wf.wfname,
        wf.wfid,
        jn.journalacronym,
        wo.itemcode,
        stage.stagename,
        stage.stageid,
        wo.workorderid,
        wo.otherfield::json ->> 'pii' AS pii,
        wos.status,
        wos.stageiterationcount,
        wos.wostageid,
        TO_CHAR(wo.createdon + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') AS createdon
    FROM wms_workorder wo
    JOIN pp_mst_journal jn ON wo.journalid = jn.journalid
    JOIN wms_workorder_stage wos ON wos.workorderid = wo.workorderid
    JOIN wms_mst_stage stage ON stage.stageid = wos.wfstageid
    JOIN wms_workflow wf ON wf.wfid = wo.wfid
    WHERE wf.wfid = ${wfid} AND wo.isactive = true
    AND wo.createdon + INTERVAL '5 hours 30 minutes'
    BETWEEN TO_DATE('${fromdate}', 'YYYY-MM-DD')
    AND TO_DATE('${todate}', 'YYYY-MM-DD') + INTERVAL '1 day' - INTERVAL '1 second'

), 
workflow AS (
    SELECT stageid, MIN(sequence) AS seq 
    FROM wms_workflowdefinition 
    WHERE wfid = ${wfid} 
    GROUP BY stageid
), 
aggregated AS (
    SELECT 
        cte.wfname,
        cte.wfid,
        cte.journalacronym,
        cte.itemcode,
        cte.createdon,
        cte.workorderid,
        cte.pii,
        json_agg(
            json_build_object(
                'stage', cte.stagename || ' (' || cte.stageiterationcount || ')',
                'status', CASE 
                    WHEN cte.status = 'YTS' THEN 'YTR'
                    WHEN cte.status = 'In Process' THEN 'In Progress'
                    ELSE cte.status
                     END,
                'activity', CASE
                    WHEN cte.status = 'In Process' THEN (
                        SELECT STRING_AGG(w.activityalias, ', ') AS activityaliases
                        FROM wms_workflowdefinition w
                        JOIN wms_workflow_eventlog e
                            ON w.wfdefid = e.wfdefid
                        WHERE w.wfid = cte.wfid
                          AND w.stageid = cte.stageid
                          AND e.workorderid = cte.workorderid
                          AND e.activitystatus NOT IN ('Completed', 'Reset', 'Reject')
                    )
                    ELSE NULL
                END
            )
            ORDER BY workflow.seq, cte.stageiterationcount
        ) AS stage_status,

        -- Count stages 103 or 121
        (
            SELECT COUNT(*) 
            FROM cte s
            WHERE s.workorderid = cte.workorderid AND s.stageid IN (103, 121)
        ) AS count_stage_103_121,

        -- Count how many of those stages have valid status
        (
            SELECT COUNT(*) 
            FROM cte s
            WHERE s.workorderid = cte.workorderid 
              AND s.stageid IN (103, 121)
              AND s.status IN ('Completed', 'YTR')
        ) AS count_completed_103_121

    FROM cte
    JOIN workflow ON cte.stageid = workflow.stageid
    GROUP BY 
        cte.wfname,
        cte.wfid,
        cte.journalacronym,
        cte.itemcode,
        cte.createdon,
        cte.workorderid,
        cte.pii
), 
problem_tasks AS (
    SELECT DISTINCT ON (woid) woid, isactive
    FROM trn_problemtask
    WHERE isactive = true
    ORDER BY woid
)
SELECT 
    a.wfname,
    a.wfid,
    a.journalacronym,
    a.itemcode,
    a.createdon,
    a.workorderid,
    a.pii,
    a.stage_status::text,
    RIGHT(a.itemcode, LENGTH(a.itemcode) - LENGTH(a.journalacronym)) AS articleid,
    
    CASE 
        WHEN pt.woid IS NOT NULL THEN 'Problem Task Raised'
        
        -- Condition where stage 103 is not completed
        WHEN 
            (
                SELECT status 
                FROM cte s 
                WHERE s.workorderid = a.workorderid AND s.stageid = 103
                LIMIT 1
            ) != 'Completed'
        THEN 'WIP'

        -- Condition where stage 103 is completed and stage 121 is completed or YTS
        WHEN 
            (
                SELECT status 
                FROM cte s 
                WHERE s.workorderid = a.workorderid AND s.stageid = 103
                LIMIT 1
            ) = 'Completed' AND
            (
                SELECT status 
                FROM cte s 
                WHERE s.workorderid = a.workorderid AND s.stageid = 121
                LIMIT 1
            ) IN ('Completed', 'YTS')
        THEN 'Delivered'

        -- Condition where stage 103 is completed and stage 121 is In Process
        WHEN 
            (
                SELECT status 
                FROM cte s 
                WHERE s.workorderid = a.workorderid AND s.stageid = 103
                LIMIT 1
            ) = 'Completed' AND
            (
                SELECT status 
                FROM cte s 
                WHERE s.workorderid = a.workorderid AND s.stageid = 121
                LIMIT 1
            ) = 'In Process'
        THEN 'WIP'

        -- Default case for all other conditions
        ELSE 'WIP'
    END AS current_status,
    
    e.activitystatus,
    string_agg(w.activityalias, ',') AS active_activity

FROM aggregated a
LEFT JOIN problem_tasks pt 
    ON pt.woid = a.workorderid
LEFT JOIN wms_workflow_eventlog e 
    ON e.workorderid = a.workorderid AND e.activitystatus = 'Work in progress'
LEFT JOIN wms_workflowdefinition w 
    ON w.wfdefid = e.wfdefid

GROUP BY
    a.wfname,
    a.wfid,
    a.journalacronym,
    a.itemcode,
    a.createdon,
    a.workorderid,
    a.pii,
    a.stage_status::text,
    e.activitystatus,
    a.count_stage_103_121,
    a.count_completed_103_121,
    pt.woid

ORDER BY a.workorderid;

`;

    const data = await query(sqlqry);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const getWipNonWms = async (req, res) => {
  const { userId } = req.body;
  // lockjob
  // SQL query to call the stored procedure
  const sql = `;with workordercte AS (
	SELECT wo.workorderid,wo.itemcode,wo.title,
	du.duname,wo.duid,cu.customername,
	wo.customerid, wo.divisionid, 
	wo.subdivisionid, wo.countryid,
	wo.celevelid, wo.status AS wostatus,
	wo.journalid, wo.doinumber, 
	wo.wotype, to_char(wo.createdon,'YYYY-MM-DD') AS jobcreatedon,
	wo.currencyid, wo.softwareid, wo.composingsoftwareid, wo.category, wo.complexityid
	FROM wms_workorder wo
	JOIN mst_deliveryunit du ON du.duid = wo.duid
	JOIN mst_customer cu ON cu.customerid = wo.customerid
	JOIN wms_workflow AS workflow ON workflow.wfid=wo.wfid
	WHERE 
		wo.isactive = true AND 
		wo.flowtype = 'nonwms' AND 
    coalesce(wo.islock,false) = false AND
		wo.duid = ANY (
					(
					  SELECT (duid||mappedduid) :: BIGINT[]
					  FROM wms_user WHERE userid =  $1
					)::bigint[]
 		)
)
,wostagecte AS (
	SELECT 
	row_number() OVER(partition by ws.workorderid ORDER BY CASE WHEN status = 'In Process' THEN 1 ELSE 2 END, ws.wostageid) AS rownumber,	
	ws.workorderid, ws.wostageid, mstg.stagename, ws.wfstageid as stageid, 
	ws.status AS stagestatus,  
	stageiterationcount, 
	to_char(startdatetime,'YYYY-MM-DD') as startdatetime,
	to_char(enddatetime,'YYYY-MM-DD') as enddatetime , 
	to_char(ordermaildatetime,'YYYY-MM-DD') as ordermaildatetime,
	to_char(revisedenddatetime,'YYYY-MM-DD') AS stageduedate,	
	typesetpages, 
	to_char(productiondespatchdate,'YYYY-MM-DD') as productiondespatchdate , 
	to_char(customerdespatchdate,'YYYY-MM-DD') as customerdespatchdate
	FROM wms_workorder_stage AS ws
	JOIN wms_mst_stage mstg ON mstg.stageid = ws.wfstageid
	WHERE 
	ws.status IN ('YTS','In Process') 
  AND ws.plannedenddate IS NOT null
  AND ws.revisedenddatetime is not null
	AND workorderid IN
	(SELECT workorderid FROM workordercte)
	
)
,woincomingcte AS (	
SELECT 
	inc.woid AS workorderid,
	MAX(inc.woincomingid), 
	inc.stageid,
	SUM(COALESCE(inf.estimatedpages,0)) AS estimatedpages,
	SUM(COALESCE(inf.mspages,0)) AS mspages,
	SUM(COALESCE(inf.imagecount,0)) AS imagecount,
	SUM(COALESCE(inf.typesetpage,0)) AS typesetpage,
	SUM(COALESCE(inf.wordcount,0)) AS wordcount
FROM wms_workorder_incoming AS inc
JOIN wms_workorder_incomingfiledetails AS inf ON inf.woincomingid = inc.woincomingid
join wostagecte as stg on stg.workorderid = inc.woid and stg.stageid = inc.stageid 
where stg.rownumber = 1 
GROUP BY inc.woid, inc.stageid , stg.rownumber
ORDER BY workorderid  
), finalrecord AS (
SELECT 
	wo.workorderid,wo.itemcode,wo.title,
	wo.duname,wo.duid,wo.customername as "Customer",
	wo.customerid, wo.divisionid, 
	wo.subdivisionid, wo.countryid,
	wo.celevelid, wo.wostatus,
	wo.journalid, wo.doinumber, 
	wo.wotype, wo.jobcreatedon,
	wo.currencyid, wo.softwareid, wo.composingsoftwareid,   wo.complexityid,
	coalesce (sof.softwarename,'NA') as "Software",
	con.countryname,
	COALESCE(cat.categoryalias,'') as category,
	comp.complexity,
	(SELECT contactname FROM wms_workorder_contacts WHERE workorderid = wo.workorderid AND contactrole = 'PM' limit 1) as "PM",
	(SELECT contactname FROM wms_workorder_contacts WHERE workorderid = wo.workorderid AND contactrole = 'AUTHOR' limit 1) as authorname,
	(SELECT contactname FROM wms_workorder_contacts WHERE workorderid = wo.workorderid AND contactrole = 'PED' limit 1) as pename,
	ABS(CURRENT_DATE - wo.jobcreatedon::date) AS day_count,

 	wst.wostageid, wst.stagename as "Stage", wst.stageid, 
	wst.stagestatus,
	wst.stageiterationcount, wst.startdatetime, wst.enddatetime, wst.ordermaildatetime,
    CASE when wst.stageduedate :: DATE >=  CURRENT_TIMESTAMP :: DATE
			then wst.stageduedate::DATE
			when wst.stageduedate:: DATE < CURRENT_TIMESTAMP  :: DATE
			then current_timestamp ::Date  -1
  END as "Date",
  coalesce(wst.typesetpages, winc.typesetpage) as typesetpages, 
	wst.productiondespatchdate as "Actualdate", 
	wst.customerdespatchdate as customerdespatchdate,
	winc.estimatedpages, winc.mspages, winc.imagecount, winc.wordcount,	
	COALESCE(wno.notestext,'')::Text AS wipnotes ,
  COALESCE(wno.addedby,'')::Text AS notesaddedby ,
	COALESCE(qrst.qrystatus,'No Query') AS querystatus,	  
	CASE WHEN qrst.qrystatus = 'Open' OR qrst.qrystatus = 'Re-opened' THEN qrst.qrycount ELSE 0 END AS qrycount,
	CASE WHEN qrst.qrystatus IS NULL THEN '' ELSE 'view query' END AS querytext,
  qrst.queryhistory
FROM workordercte AS wo
JOIN wostagecte AS wst ON wo.workorderid = wst.workorderid and wst.rownumber = 1
LEFT JOIN woincomingcte AS winc ON winc.workorderid = wo.workorderid
left JOIN pp_mst_composingsoftware AS sof ON sof.softwareid = wo.composingsoftwareid
left JOIN geo_mst_country AS con on con.countryid = wo.countryid 
LEFT JOIN pp_mst_wocategory as cat on cat.categoryid = COALESCE(NULLIF(wo.category, 'null')::bigint, 0)
LEFT JOIN public.wms_mst_complexity AS comp on comp.complexityid = wo.complexityid 

LEFT JOIN view_wostage_querylist AS qrst on qrst.workorderid =  wo.workorderid 
AND qrst.stageid = wst.stageid 
AND qrst.stageiterationcount = wst.stageiterationcount
LEFT JOIN wms_wip_wostage_notes AS wno ON wno.workorderid =wo.workorderid AND 
		  wno.stageid = wst.stageid AND wno.stageiterationcount = wst.stageiterationcount
ORDER BY wo.workorderid , wst.stageid
)
select 
	 rec.workorderid,rec.itemcode as "Itemcode",rec.title as "Title",rec.duname as "Du"
	,rec.duid,rec."Customer",rec.customerid,rec.divisionid
	,rec.subdivisionid,rec.countryid,rec.celevelid,rec.wostatus
	,rec.journalid,rec.doinumber as "Doi",rec.wotype,rec.jobcreatedon as "JobCreatedOn"
	,rec.currencyid
  ,rec.softwareid
  ,rec.composingsoftwareid
	,rec.complexityid,rec."Software"
  ,rec.countryname as "Country"
	,rec.category as "Category"
  ,rec.complexity as "Complexity"
  ,COALESCE(rec."PM",'NA') as "PM"
  ,rec.authorname as "Author"
  ,rec.pename as "PE"
	,rec.day_count as "Day Count"
  ,rec.wostageid
  ,rec."Stage"
  ,rec.stageid
  ,rec.stagestatus as "Stage Status"
	,rec.stageiterationcount 
	,rec.startdatetime,rec.enddatetime,rec.ordermaildatetime as "Received Date"
	,rec."Date"
  ,EXTRACT(YEAR FROM rec."Date") AS "Year"
  ,EXTRACT(MONTH FROM rec."Date") AS "Month"
  ,EXTRACT(DAY FROM rec."Date") AS "Day"
	,rec.typesetpages as "Typeset Qty"
  ,rec."Actualdate"
  ,rec.customerdespatchdate as "Cust Despatch"
	,rec.estimatedpages as "Estimated Page"
  ,rec.mspages as "Ms Page"
  ,rec.imagecount "Image Qty"
	,rec.wordcount as "Word Count", rec.wipnotes , rec.notesaddedby as "Notes Addedby"
  ,COALESCE(rec.querystatus,'NA') AS "Query Status"
  ,rec.qrycount,rec.querytext ,rec.queryhistory
FROM finalrecord as rec`;

  try {
    // Execute the query with parameters
    const data = await query(sql, [userId]);
    // console.log('getwipnonwms data:', data);
    // Send back the response with the data
    res.status(200).json({ data });
  } catch (error) {
    // console.error('get_final_time error:', error);
    res.status(400).send({ message: error.message });
  }
};

export const getMonthwiseDelivery = async (req, res) => {
  try {
    const { custId, fromdate, todate } = req.body;

    const sqlqry = `WITH received_dates AS (
    SELECT
        workorderid,
        MAX(CASE
            WHEN wfstageid = 22 THEN startdatetime
            ELSE NULL
        END) AS received_stage_22_date,
        MAX(CASE
            WHEN wfstageid = 23 THEN startdatetime
            ELSE NULL
        END) AS received_stage_23_date
    FROM
        wms_workorder_stage
    WHERE
        wfstageid IN (22, 23)
    GROUP BY
        workorderid
)
SELECT
    ww.itemcode AS article,
    CASE
        WHEN wws.wfstageid = 1 THEN rd.received_stage_22_date
        WHEN wws.wfstageid = 2 AND wws.stageiterationcount = 1 THEN rd.received_stage_23_date
        ELSE wws.startdatetime
    END AS receiveddate,
    wws.updatedon AS completeddate,
    s.stagename AS stage,
    COALESCE(wws.revisedenddatetime, wws.enddatetime) AS duedate,
    NULL AS TAT,
    NULL AS OntimeDelay,
    id.mspages AS MSPage,
    id.typesetpage AS TSPage
FROM
    wms_workorder_stage wws
JOIN
    wms_workorder ww
    ON wws.workorderid = ww.workorderid AND ww.customerid =  ${custId}
JOIN
    wms_mst_stage s
    ON s.stageid = wws.wfstageid
JOIN
    wms_workorder_incoming i
    ON i.woid = ww.workorderid
JOIN
    wms_workorder_incomingfiledetails id
    ON id.woincomingid = i.woincomingid
LEFT JOIN
    received_dates rd
    ON rd.workorderid = ww.workorderid AND  ${custId} = ww.customerid
WHERE
    TO_CHAR(wws.updatedon, 'MMYYYY') IN ('102024', '112024')
    AND wws.status = 'Completed'
    and ww.createdon::Date BETWEEN ('${fromdate}'::Date)::timestamp(0) and ('${todate}'::Date)::timestamp(0)
    AND wws.wfstageid IN (1, 2, 12, 32)
ORDER BY
    wws.updatedon,
    ww.itemcode,wws.wfstageid ;`;

    const data = await query(sqlqry);

    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getPBTaskData = async (req, res) => {
  const { duID, submittedData, from, rejectionFeedBack } = req.body;

  let updatedStage = '';
  let updatedActivity = '';
  let updatedItemCode = '';

  if (submittedData) {
    const { stage, activity, journalid, articleid } = submittedData;

    updatedStage = stage.replace(/\s*\(.*?\)/g, '');
    updatedActivity = activity.replace(/\s*\(.*?\)/g, '');

    const articleLength = articleid.length;
    let zeroString = '';
    for (let i = 0; i < 5 - articleLength; i++) {
      zeroString += '0'; // Append zeros manually
    }

    updatedItemCode = journalid + zeroString + articleid;
  }

  if (from == 'toApprove') {
    const sql = `update trn_problemtask set updateddate = current_timestamp ,updatedby = '${duID}',isreject = false  where
                 articleid = '${updatedItemCode}'and activity = '${updatedActivity}' and isactive = true and
                 stage ='${updatedStage}' RETURNING id`;

    const fileDetails = await query(sql);
    const logSql = `insert into trn_problemtask_log(pb_id,createdby,createddate,status,remarks) 
    values('${fileDetails[0].id}','${duID}',current_timestamp,'Approved','Waiting in customer que')`;
    await query(logSql);
    res.status(200).json(fileDetails);
  } else if (from == 'toReject') {
    const sql = `update trn_problemtask set updateddate = current_timestamp ,updatedby = '${duID}' , isactive = false, rejectionfeedback= '${rejectionFeedBack}', isreject = true where isactive = true and
articleid = '${updatedItemCode}'and activity = '${updatedActivity}' and stage ='${updatedStage}' RETURNING id`;

    const fileDetails = await query(sql);
    const logSql = `insert into trn_problemtask_log(pb_id,createdby,createddate,status,remarks) 
    values('${fileDetails[0].id}','${duID}',current_timestamp,'Rejected','Problem Task rejected')`;
    await query(logSql);
    res.status(200).json(fileDetails);
  } else {
    // const sql = ` select journalid as journalid,articleid as articleid,stage as stage,activity as activity,signal_description as signaldescription, xmldata as xmldata from trn_problemtask where isactive = 'true'`;
    // const sql = `SELECT journalid AS journalid,articleid AS articleid,stage AS stage,activity AS activity,
    // signal_description AS signaldescription,xmldata AS xmldata , problemgroup as problemgroup, createddate as createddate, createdby as createdby FROM trn_problemtask pb WHERE
    // pb.isactive = 'true' AND pb.isreject is null and pb.createdby NOT IN (SELECT ac.userid FROM mst_user_access ac where isactive= true)`;
    const sql = `
SELECT 
    pb.journalid AS journalid,
    pb.articleid AS articleid,
    pb.zip_path AS zip_path,
    pb.rejectionfeedback AS rejectionfeedback,
    pb.stage AS stage,
    pb.activity AS activity,
    pb.signal_description AS signaldescription,
    pb.xmldata AS xmldata,
    pb.problemgroup AS problemgroup,
    pb.createddate AS createddate,
    pb.createdby AS createduser,
	pb.stage_iteration As stageIteration,
  	pb.activity_iteration As activityiteration,
    wu.username AS createdby -- Replaced createdby with username from wms_user table
FROM 
    trn_problemtask pb
JOIN 
    wms_user wu ON pb.createdby = wu.userid 
WHERE 
    pb.isactive = 'true' 
    AND pb.isreject IS NULL 
    AND pb.createdby NOT IN (SELECT ac.userid FROM mst_user_access ac WHERE ac.isactive = true);
`;
    console.log('getPBTaskData', sql);
    query(sql)
      .then(data => {
        console.log('getPBTaskData', data);
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};

export const getElsBasePath = async (req, res) => {
  try {
    //  const { dmsType, du, customer } = req.body;
    const { submittedData } = req.body;

    const bData = await getBasePath(req.body);
    const basePath = bData.replace(';JournalAcronym;', submittedData.journalid);
    // const serverPbFilePath = join(
    //   basePath,
    //   submittedData.articleid,
    //   'ProblemTask',
    // );
    const serverPbFilePath = `${basePath}${submittedData.articleid}/ProblemTask`;

    //  const service = new Service();

    const __filename = fileURLToPath(import.meta.url);
    // const outputFilePath = join(__filename.replace('index.js', ''), 'PbTask');
    const outputFilePath = `${__filename.replace('index.js', '')}\\PbTask`;

    // get file path alone   __filename.replace('\\index.js','')
    if (!fs.existsSync(outputFilePath)) {
      fs.mkdirSync(outputFilePath, { recursive: true });
      console.log('Folder created successfully!');
    }

    // const msgTime = await generateDateTime();
    const regex = /<message id="([^"]+)"/;

    const match = submittedData.xmldata.match(regex);
    // Destructuring
    const [, messageId] = match;

    // const xmlFileName = `${submittedData.journalid + msgTime}.xml`;

    const xmlFileName = `${messageId}.xml`;

    const fullFilePath = join(outputFilePath, xmlFileName);

    fs.writeFileSync(fullFilePath, submittedData.xmldata);

    const localFilePath = join(outputFilePath, xmlFileName);
    const fileDetails = {
      tempFilePath: outputFilePath,
      name: xmlFileName,
    };

    const uploadRes = await _upload(fileDetails, serverPbFilePath);

    const { okmPath, name, fullPath } = uploadRes.data;
    const oPath = join(outputFilePath, xmlFileName);
    const stats = fs.statSync(oPath);
    console.log(fullPath);
    // let replacedFullePath = fullPath.replace('/','\');
    const replacedFullPath = okmPath.replace(/\//g, '\\');

    const toolsPayload = {
      ftpFolder: '',
      fileName: name,
      destPath: replacedFullPath,
      stagename: submittedData.stage,
      activityname: submittedData.activity,
      typeID: 2,
      ftpName: 'elsevier_upload_signal',
      customerID: 14,
      articlename: submittedData.articleid,
      journalcode: submittedData.journalid,
      dmsType: 'local',
      messageName: '',
      filesize: stats.size,
      wfeventid: '',
      isPbTask: true,
    };

    // https://tools3.integra.co.in/iftp-wms-test/api/iftp/iFTPDispatch

    // await post(`${iftpconfig.baseUrl}${iftpconfig.localUrl}`, payLoadData, headers);

    // const headers = {
    //   'Authorization': `Bearer ${config.iwmsServer.getToken(iwms.env)}`
    // };

    const service = new Service();
    const url = config.iftp.base_url + config.iftp.uri.getiFTPDispatch;

    if (submittedData?.zip_path?.trim()) {
      const toolsPayloads = {
        ftpFolder: '',
        // fileName: 'problemtask2025-02-28_05-20-05.zip',
        fileName: submittedData.zip_path.split(/[\\/]/).pop(),
        destPath: submittedData.zip_path.substring(
          0,
          submittedData.zip_path.lastIndexOf('/'),
        ),
        stagename: submittedData.stage,
        activityname: submittedData.activity,
        typeID: 2,
        ftpName: 'elsevier_upload_signal',
        customerID: 14,
        articlename: submittedData.articleid,
        journalcode: submittedData.journalid,
        dmsType: 'local',
        messageName: '',
        filesize: stats.size,
        wfeventid: '',
        isPbTask: true,
      };
      await service.pbTaskPost(url, toolsPayloads);
    }

    // const payloadTool = {};
    const result = await service.pbTaskPost(url, toolsPayload);
    const { status, message, data } = result;

    console.log(status, message);
    fs.unlinkSync(localFilePath);
    res.status(200).json({ data, status: true });
  } catch (ex) {
    console.error('error in problem task:', ex);
    res.status(400).send({ message: ex.message });
  }
};

export const decodeSymbol = async EncodeURL => {
  return new Promise(resolve => {
    resolve(EncodeURL.replace(/%20/g, ' ').replace(/%25/g, ' '));
  });
};

const _upload = (file, docPath) => {
  return new Promise(async (resolve, reject) => {
    try {
      const service = new Service();
      if (docPath != '') {
        const url = config.local_rest.uri.localupload;
        const formData = new FormData();
        // const fPath = `${docPath}${file.name}`;
        const fPath = join(docPath, file.name);
        let encodedURL = encodeURI(fPath);
        encodedURL = await decodeSymbol(encodedURL);
        console.log(encodedURL);
        const serverFilePath = join(file.tempFilePath, file.name);
        formData.append('content', fs.createReadStream(serverFilePath));
        formData.append('docPath', fPath);
        const headers = {
          'Content-Type': 'multipart/form-data',
          ...formData.getHeaders(),
        };
        const result = await service.uploadPost(
          `${config.local_rest.base_url}${url}`,
          formData,
          headers,
        );
        const { data, status } = result;
        const response = {
          data: {
            ...data,
            okmPath: docPath,
            name: file.name,
            fullPath: join(docPath, file.name).replace(/\\/g, '/'),
          },
          status,
          fullPath: join(docPath, file.name).replace(/\\/g, '/'),
        };
        resolve(response);
      }
    } catch (err) {
      reject(err);
    }
  });
};

// async function generateDateTime() {
//   const now = new Date();
//   const year = now.getFullYear();
//   const month = String(now.getMonth() + 1).padStart(2, '0');
//   const day = String(now.getDate()).padStart(2, '0');
//   const hours = String(now.getHours()).padStart(2, '0');
//   const minutes = String(now.getMinutes()).padStart(2, '0');
//   const seconds = String(now.getSeconds()).padStart(2, '0');
//   const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
//   return `${year}${month}${day}${hours}${minutes}${seconds}${milliseconds}`;
// }

export const getEngineFailure = async (req, res) => {
  try {
    const { duId, fromdate, todate, status } = req.body;
    const formattedStatus = status.map(s => `'${s}'`).join(', ');

    const sqlqry = `
              WITH LatestEventDetails AS (
              SELECT 
                  wwed.wfeventid,
                  MAX(wwed.wfeventdetailid) AS latest_wfeventdetailid
              FROM 
                  wms_workflow_eventlog_details wwed
              GROUP BY 
                  wwed.wfeventid
          ),
          LatestEvents AS (
              SELECT 
                  wwe.wfeventid,
                  wwe.workorderId,
                  ww.activityid,
                  wwe.activitystatus,
                  wwe.createdon,
                  ROW_NUMBER() OVER (
                      PARTITION BY ww.activityid, wwe.workorderId
                      ORDER BY wwe.createdon DESC
                  ) AS rn
              FROM 
                  wms_workflow_eventlog wwe
              JOIN 
                  wms_workflowdefinition ww ON ww.wfdefid = wwe.wfdefid
              WHERE 
                  wwe.activitystatus IN (${formattedStatus})
          ),
          CTE AS (
            SELECT     
                ROW_NUMBER() OVER (ORDER BY wwe.createdon DESC) AS serial,
                wo.itemcode,
                wwe.activitystatus as operationtype,
                a.activityname || ' (' || wwe.activityiterationcount || ')' AS activityname,
                wwe.wfeventid,
                wwe.workorderId,
                ww.wfid,
                ww.filetypeskipfornextactivity,
                ww.instancetype,
                wwe.externaltaskdata,
                wwe.taskinstanceid,
                to_char(wwe.createdon AT TIME ZONE 'Asia/Kolkata', 'DD-MM-YYYY HH12:MI:SS AM') AS timestamp,
                wwe.createdon ::DATE as timestamp_12hr,
                COALESCE(wwed.usercomments, 'Engine Failed, Please Check the Input Files') AS usercomments,
                ww.stageid,
                s.stagename || ' (' || wwe.stageiterationcount || ')' AS stagename,
                wwe.stageiterationcount,
                ww.activityid,
                wwe.woincomingfileid,
                i.filename,
                i.duedate,
                wo.customerid
            FROM
                wms_workflow_eventlog wwe
            JOIN
                LatestEvents le ON wwe.wfeventid = le.wfeventid
            JOIN
                wms_workflowdefinition ww ON ww.wfdefid = wwe.wfdefid
            JOIN
                wms_workorder wo ON wwe.workorderid = wo.workorderid
            JOIN  
                org_mst_customer_orgmap omco ON omco.customerid = wo.customerid
                AND omco.divisionid = wo.divisionid
                AND omco.subdivisionid = wo.subdivisionid
                AND omco.countryid = wo.countryid
            JOIN  
                org_mst_customerorg_du_map omcdm ON omcdm.custorgmapid = omco.custorgmapid
            JOIN
                wms_mst_stage s ON s.stageid = ww.stageid
            JOIN
                wms_mst_activity a ON a.activityid = ww.activityid
            LEFT JOIN
                wms_workorder_incomingfiledetails i ON i.woincomingfileid = wwe.woincomingfileid
            LEFT JOIN
                LatestEventDetails led ON wwe.wfeventid = led.wfeventid
            LEFT JOIN
                wms_workflow_eventlog_details wwed ON wwed.wfeventdetailid = led.latest_wfeventdetailid
            WHERE  
                activitytype = 'External Task'
                AND omcdm.duid = ${duId}
                AND wwe.activitystatus IN (${formattedStatus})
                AND le.rn = 1
          )
          SELECT * FROM CTE
          WHERE CTE.timestamp_12hr BETWEEN '${fromdate}' AND '${todate}';`;

    const data = await query(sqlqry);
    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ error });
  }
};

// //For Ready XML Tracker Report Logics
export const getXMLtrackerReportACS = async (req, res) => {
  const { fromdate, todate } = req.body;

  const sql = `
    SELECT 
      atr.workorderid,
      wo.itemcode, 
      atr.guid,
      ppm.journalacronym,
      adp.iauthorsignal, 
      adp.status,
      adp.remarks,
      to_char(adp.created_time AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata', 'DD-MM-YYYY HH24:MI:SS') AS created_time_ist,
      to_char(adp.updated_time AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata', 'DD-MM-YYYY HH24:MI:SS') AS updated_time_ist,
      adp.filepath 
    FROM 
      iauthor_transactions atr
    JOIN 
      iauthor_dispatch_trns adp 
      ON atr.guid = adp.guid
    JOIN 
      wms_workorder wo 
      ON wo.workorderid = atr.workorderid
    JOIN
      pp_mst_journal ppm 
      ON wo.journalid = ppm.journalid
    WHERE 
      adp.created_time::date BETWEEN '${fromdate}'::date AND '${todate}'::date
    ORDER BY 
      atr.iauthourtrnsid DESC;
  `;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error.message });
    });
};

export const getFTPFailure = async (req, res) => {
  try {
    const { duId, fromdate, todate, type, status, stage, support } = req.body;

    const sqlqry = ` WITH WorkOrders AS (
    SELECT 
        wo.workorderid,
        wo.itemcode,
        wo.otherfield->>'pii' AS pii,
        wo.isactive,
        omcdm.duid
    FROM wms_workorder wo
    JOIN org_mst_customer_orgmap omco 
        ON omco.customerid = wo.customerid
        AND omco.divisionid = wo.divisionid
        AND omco.subdivisionid = wo.subdivisionid
        AND omco.countryid = wo.countryid
    JOIN org_mst_customerorg_du_map omcdm 
        ON omcdm.custorgmapid = omco.custorgmapid
    WHERE 
        wo.otherfield->>'pii' IS NOT NULL  
        AND wo.otherfield->>'pii' <> ''
        AND omcdm.duid = $1
)
SELECT 
    ROW_NUMBER() OVER (ORDER BY t.id DESC) AS serial,
    t.id,
    t.emailreaderid,
    WO.workorderid,
    CASE 
        WHEN t.body ILIKE '%Issue%' THEN 'Issue' 
        ELSE WO.itemcode 
    END AS itemcode,
    CASE 
        WHEN t.emailreaderid = 6 THEN 'First View' 
        WHEN t.emailreaderid = 7 THEN 'Revised First View'
        ELSE 'Anonymous'
    END AS stage,
    CASE 
        WHEN t.issuccess THEN 'Success' 
        ELSE 'Failed' 
    END AS status,
    t.subject,
    COALESCE(NULLIF(t.issuccess, false)::TEXT, COALESCE(t.remark, 'N/A')) AS remark,
    t.createddate,
    t.support_remark,
    CASE WHEN t.islock = TRUE THEN 'Yes'  ELSE 'No' END AS issupport,
    CASE WHEN t.issuccess = FALSE OR  t.islock = TRUE THEN 'action' ELSE '' END AS action
FROM tran_emailreader t
LEFT JOIN WorkOrders WO 
    ON t.body ILIKE '%' || WO.pii || '%' 
    AND WO.pii IS NOT NULL  
    AND WO.isactive = TRUE
    AND WO.duid = $1
WHERE 
     t.emailreaderid IN (6,7,8)  
    AND t.createddate ::date BETWEEN $2 ::date AND $3 ::date
    AND ($4 = 'All' OR t.body ILIKE '%' || $4 || '%')
    AND ($6 = 'All' OR (t.emailreaderid = 6 AND $6 = 'First View') OR (t.emailreaderid = 7 AND $6 = 'Revised First View') OR (t.emailreaderid = 8 AND $6 = 'Anonymous') )
    AND ($5 = 'All' OR (t.issuccess = TRUE AND $5 = 'Success') OR (t.issuccess = FALSE AND $5 = 'Failed'))
    AND ($7 = 'All' OR (t.islock = TRUE AND $7 = 'Yes') OR (t.islock = FALSE AND $7 = 'No'))
ORDER BY t.id DESC;
    `;

    const values = [duId, fromdate, todate, type, status, stage, support];

    const data = await query(sqlqry, values);
    res.status(200).json({ data });
  } catch (error) {
    console.error('Error in getFTPFailure:', error);
    res.status(400).json({ error: error.message || 'An error occurred' });
  }
};

export const updateFTPFailure = async (req, res) => {
  try {
    const { id, support_remark, status } = req.body;

    const istatus = status === 'Support';

    const sqlqry = ` 
      UPDATE tran_emailreader 
      SET islock = $3, 
          issuccess = $3,
          support_remark = $2,
          updateddate = current_timestamp
      WHERE id = $1 
    `;

    const values = [id, support_remark, istatus];

    const data = await query(sqlqry, values);
    res.status(200).json({ data });
  } catch (error) {
    console.error('Error in updateFTPFailure:', error);
    res.status(400).json({ error: error.message || 'An error occurred' });
  }
};

export const getCAMSAcknowledge = async (req, res) => {
  try {
    const paylaod = req.body;
    const data = await _getCAMSAcknowledge(paylaod);

    res.status(200).json({ data });
  } catch (error) {
    console.error('Error in updateFTPFailure:', error);
    res.status(400).json({ error: error.message || 'An error occurred' });
  }
};

export const _getCAMSAcknowledge = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { todate, fromdate, stage, status } = payload;

      const sql = `SELECT
    ROW_NUMBER() OVER (ORDER BY a.createddate DESC) AS serial_no,  -- Serial Number
    a.customername,
    a.journalcode,
    j.journalacronym as journal,
    j.pmid ,
    u.username as pm,
    a.stagename,
    a.articlename,
    a.packagefilename,
    b.status,
    a.remarks,
    c.modename,
    a.retriggercount,
    a.stageiterationcount,
    TO_CHAR(a.createddate, 'dd-Mon-YYYY HH:MI:SS') AS createddate,
    w.workorderid,
    e.activitystatus,
    il.status AS ack_status,
    n.username as dispatched_by,
   TO_CHAR(il.dispatched_on + INTERVAL '5 hours 30 minutes', 'dd-Mon-YYYY HH:MI:SS')  AS dispatched_on,
     CASE
           WHEN e.updated_date <= NOW() - INTERVAL '24 hours' and il.status <> 'Acknowledged' THEN 'action'
           ELSE ''
       END AS action,
   w.otherfield->>'pii' as pii
FROM public.wms_trnfileinflow_details a
JOIN public.wms_mst_statuscode b ON a.statusid = b.statusid
JOIN public.wms_mst_inflowmode c ON c.modeid = a.modeid
JOIN public.wms_workorder w ON w.itemcode = a.articlename
join public.pp_mst_journal j on j.journalid = w.journalid
JOIN public.wms_workflow_eventlog e ON e.workorderid = w.workorderid
join public.wms_user u on u.userid = j.pmid
    AND (
        (a.stagename = 'First View' AND e.wfdefid = 596 AND e.activitystatus = 'Completed')
        OR
        (a.stagename = 'Revised First View' AND e.wfdefid = 678 AND e.activitystatus = 'Completed')
        OR
        (a.stagename NOT IN ('First View', 'Revised First View'))
    )
LEFT JOIN itrack_dispatch_log il
    ON il.articlename = a.articlename  
    AND il.stage = a.stagename
    left join public.wms_user n on n.userid = il.dispatched_by
join (select  max(inflowid)inflowid , a.customername,
    a.journalcode,
    a.stagename,
    a.articlename,
    a.packagefilename
from wms_trnfileinflow_details  a
JOIN public.wms_mst_statuscode b ON a.statusid = b.statusid
JOIN public.wms_mst_inflowmode c ON c.modeid = a.modeid
WHERE
  a.customername = 'CUP' and  b.status in
('Upload - initialization' , 'Upload - Completed')
group by    a.customername,
    a.journalcode,
    a.stagename,
    a.articlename,
    a.packagefilename) as chk on chk.inflowid = a.inflowid
WHERE
    b.status in ('Upload - initialization' , 'Upload - Completed')
    AND a.customername = 'CUP'  
    AND ('${stage}' IS NULL OR a.stagename = '${stage}'  or '${stage}' = 'All')
    AND (
    '${status}' = '' AND il.status IS NULL 
    OR il.status = '${status}' 
    OR '${status}' = 'All'
)
   AND a.createddate ::date BETWEEN '${fromdate}' ::date AND '${todate}' ::date    
ORDER BY a.createddate DESC;`;

      const result = await query(sql);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertCAMSAcknowledge = async (req, res) => {
  try {
    const paylaod = req.body;
    const data = await _insertCAMSAcknowledge(paylaod);

    res.status(200).json({ data });
  } catch (error) {
    console.error('Error in insert acknowledge:', error);
    res.status(400).json({ error: error.message || 'An error occurred' });
  }
};

export const _insertCAMSAcknowledge = async paylaod => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        article,
        workorderid,
        stage,
        created_by,
        status,
        stageIterationCount,
      } = paylaod;
      const sqlqry = ` 
    INSERT INTO itrack_dispatch_log (
    articlename,
    workorderid,
    stage,
    created_by,
    status,
    dispatched_by,
    stageiteration
) VALUES ($1, $2, $3, $4, $5,$6,$7);
    `;

      const values = [
        article,
        workorderid,
        stage,
        created_by,
        status,
        created_by,
        stageIterationCount,
      ];
      await query(sqlqry, values);
      resolve(true);
    } catch (error) {
      console.error('Error in updateFTPFailure:', error);
      reject(error);
    }
  });
};

export const GetShiftWiseInflowReport = async (req, res) => {
  try {
    const {
      fromdate,
      todate,
      duid,
      wfid = null,
      journalid = null,
      stageid = null,
      shift = null,
    } = req.body;

    if (!fromdate || !todate || !duid) {
      return res
        .status(400)
        .json({ error: 'Both fromdate and todate and Duid are required' });
    }

    const sqlqry = `
      WITH inflow_data AS (
        SELECT pmj.journalacronym, ww2.wfname, ww.itemcode, wms.stagename ||' ('||wws.stageiterationcount||')' as stagename,
          COALESCE(INITCAP(ww.otherfield ->> 'is_re_routed'), 'NA') AS isrerouted,
          TO_CHAR(wws.ordermaildatetime + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as receivedon,
          CASE
            WHEN EXTRACT(HOUR FROM wws.ordermaildatetime + INTERVAL '5 hours 30 minutes') BETWEEN 6 AND 13 THEN 'First (6am - 2pm)'
            WHEN EXTRACT(HOUR FROM wws.ordermaildatetime + INTERVAL '5 hours 30 minutes') BETWEEN 14 AND 21 THEN 'Second (2pm - 10pm)'
            WHEN EXTRACT(HOUR FROM wws.ordermaildatetime + INTERVAL '5 hours 30 minutes') BETWEEN 22 AND 23 OR EXTRACT(HOUR FROM wws.ordermaildatetime + INTERVAL '5 hours 30 minutes') BETWEEN 0 AND 5 THEN 'Night (10pm - 6am)'
          END AS shift
        FROM wms_workorder ww
        JOIN pp_mst_journal pmj ON pmj.journalid = ww.journalid
        JOIN wms_workflow ww2 ON ww2.wfid = ww.wfid
        JOIN wms_workorder_stage wws ON wws.workorderid = ww.workorderid AND wws.status <> 'YTS'
        JOIN wms_mst_stage wms ON wms.stageid = wws.wfstageid AND wws.wfstageid <> 10
        WHERE
          ww.isactive = true AND wws.ordermaildatetime::date BETWEEN $1::date AND $2::date AND ww.duid = $3
          AND ($4::int[] IS NULL OR ww.wfid = ANY($4))
          AND ($5::int[] IS NULL OR ww.journalid = ANY($5))
          AND ($6::int[] IS NULL OR wws.wfstageid = ANY($6))
        ORDER BY wws.ordermaildatetime DESC
      )
      SELECT *
      FROM inflow_data
      WHERE ($7::text[] IS NULL OR shift = ANY($7));`;

    const data = await query(sqlqry, [
      fromdate,
      todate,
      duid,
      wfid,
      journalid,
      stageid,
      shift,
    ]);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const GetShiftWiseInOutReportMaster = async (req, res) => {
  try {
    const { duid, wfid = null, journalid = null } = req.body;

    if (!duid) {
      return res
        .status(400)
        .json({ error: 'Du id and Cusromer id are required' });
    }

    const jQry = `SELECT DISTINCT pmj.journalid as value, pmj.journalacronym as label
                  FROM  wms_workorder ww
                  JOIN pp_mst_journal pmj ON pmj.journalid = ww.journalid
                  WHERE ww.isactive = true AND pmj.isactive = 1 AND ww.duid = $1 order by pmj.journalacronym`;

    const wQry = `SELECT DISTINCT ww2.wfid as value, ww2.wfname as label
                  FROM  wms_workorder ww
                  JOIN wms_workflow ww2 ON ww2.wfid = ww.wfid AND ww2.isactive = true
                  WHERE ww.isactive = true AND ww.duid = $1 AND ($2::int[] is null or ww.journalid = ANY($2)) order by ww2.wfname`;

    const sQry = `SELECT min(ww3.sequence) seq, wms.stageid as value, wms.stagename as label
                  FROM  wms_workorder ww
                  JOIN pp_mst_journal pmj ON pmj.journalid = ww.journalid
                  JOIN wms_workflow ww2 ON ww2.wfid = ww.wfid
                  JOIN wms_workflowdefinition ww3 ON ww3.wfid = ww2.wfid AND ww3.lock = false
                  JOIN wms_mst_stage wms ON wms.stageid = ww3.stageid AND ww3.stageid <> 10
                  WHERE ww.duid = $1 AND ($2::int[] IS NULL OR ww.wfid = ANY($2))
                    AND ($3::int[] IS NULL OR ww.journalid = ANY($3)) group by wms.stageid, wms.stagename order by seq asc`;

    const journalMst = await query(jQry, [duid]);

    const wfMst = await query(wQry, [duid, journalid]);

    const stageMst = await query(sQry, [duid, wfid, journalid]);

    return res.status(200).json({ journalMst, wfMst, stageMst });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const GetShiftWiseOutflowReport = async (req, res) => {
  try {
    const {
      fromdate,
      todate,
      duid,
      wfid = null,
      journalid = null,
      stageid = null,
      shift = null,
    } = req.body;

    if (!fromdate || !todate || !duid) {
      return res
        .status(400)
        .json({ error: 'Both fromdate and todate and Duid are required' });
    }

    const sqlqry = `
      WITH outflow_data AS (
        SELECT pmj.journalacronym, ww2.wfname, ww.itemcode, wms.stagename || '('||wws.stageiterationcount||')' as stagename,
          COALESCE(INITCAP(ww.otherfield ->> 'is_re_routed'), 'NA') AS isrerouted,
          TO_CHAR(wws.ordermaildatetime + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as receivedon,
          TO_CHAR(wws.plannedstartdate + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as pstart,
          TO_CHAR(wws.startdatetime + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as astart,
          TO_CHAR(wws.plannedenddate + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as pend,
          TO_CHAR(wws.enddatetime + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') as aend,
          CASE
            WHEN EXTRACT(HOUR FROM wws.enddatetime + INTERVAL '5 hours 30 minutes') BETWEEN 6 AND 13 THEN 'First (6am - 2pm)'
            WHEN EXTRACT(HOUR FROM wws.enddatetime + INTERVAL '5 hours 30 minutes') BETWEEN 14 AND 21 THEN 'Second (2pm - 10pm)'
            WHEN EXTRACT(HOUR FROM wws.enddatetime + INTERVAL '5 hours 30 minutes') BETWEEN 22 AND 23 OR EXTRACT(HOUR FROM wws.enddatetime + INTERVAL '5 hours 30 minutes') BETWEEN 0 AND 5 THEN 'Night (10pm - 6am)'
          END AS shift,
          CASE
            WHEN wws.enddatetime > wws.plannedenddate THEN 'Yes'
            ELSE 'No'
          END AS isoverdue
        FROM wms_workorder ww
        JOIN pp_mst_journal pmj ON pmj.journalid = ww.journalid
        JOIN wms_workflow ww2 ON ww2.wfid = ww.wfid
        JOIN wms_workorder_stage wws ON wws.workorderid = ww.workorderid AND wws.status = 'Completed'
        JOIN wms_mst_stage wms ON wms.stageid = wws.wfstageid AND wws.wfstageid <> 10
        WHERE
          ww.isactive = true AND wws.enddatetime::date BETWEEN $1::date AND $2::date AND ww.duid = $3
          AND ($4::int[] IS NULL OR ww.wfid = ANY($4))
          AND ($5::int[] IS NULL OR ww.journalid = ANY($5))
          AND ($6::int[] IS NULL OR wws.wfstageid = ANY($6))
        ORDER BY wws.enddatetime DESC
      )
      SELECT *
      FROM outflow_data
      WHERE ($7::text[] IS NULL OR shift = ANY($7));`;

    const data = await query(sqlqry, [
      fromdate,
      todate,
      duid,
      wfid,
      journalid,
      stageid,
      shift,
    ]);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const GetOutflowPivotReport = async (req, res) => {
  try {
    const { duID, startdate, enddate } = req.body;

    if (!startdate || !enddate || !duID) {
      return res
        .status(400)
        .json({ error: 'Both fromdate and todate and Duid are required' });
    }

    const sqlqry = `
      SELECT pmj.journalacronym AS "Journal", ww2.wfname AS "Workflow",
        REPLACE(ww.itemcode, pmj.journalacronym, '')::varchar AS "AID",
        ww.itemcode AS "Job Code", COALESCE(ww.otherfield ->> 'pii', 'NA')::varchar AS "PII",
        COALESCE(INITCAP(ww.otherfield ->> 'is_re_routed'), 'NA') AS "Rerouted",
        wms.stagename || '('||wws.stageiterationcount||')' AS "Stage",
        wws.ordermaildatetime AS "Received On",
        wws.plannedenddate AS "Due On",
        wws.enddatetime AS "Completed On"
      FROM wms_workorder ww
      JOIN pp_mst_journal pmj ON pmj.journalid = ww.journalid
      JOIN wms_workflow ww2 ON ww2.wfid = ww.wfid
      JOIN wms_workorder_stage wws ON wws.workorderid = ww.workorderid AND wws.status = 'Completed'
      JOIN wms_mst_stage wms ON wms.stageid = wws.wfstageid AND wws.wfstageid <> 10
      WHERE
        ww.isactive = true AND (wws.enddatetime + INTERVAL '5 hours 30 minutes')::date BETWEEN $1::date AND $2::date AND ww.duid = $3
      ORDER BY wws.enddatetime DESC`;

    const data = await query(sqlqry, [startdate, enddate, duID]);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};

export const getCampusSignalAuditReport = async (req, res) => {
  const { fromdate, todate, itemcode, stagename, status, type } = req.body;

  const sql = `WITH combined_result AS (
    SELECT 
        wo.workorderid,
        wo.itemcode,
        stagem.stagename AS stagename,
        wostage.stageiterationcount AS stageiteration,
        'proofapproved' AS signalname,
        '' AS payload,
        '' AS responce,
        'Signal Yet to Send' AS remarks,
        'YTS' AS status,
        'YTS' AS type,
        TO_CHAR(we.updated_date AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata', 'DD-MM-YYYY HH24:MI:SS') AS signal_time
    FROM wms_workflow_eventlog AS we
    JOIN wms_workflowdefinition AS wf ON we.wfdefid = wf.wfdefid AND wf.wfdefid IN (564)
    JOIN wms_workorder AS wo ON we.workorderid = wo.workorderid
    JOIN pp_mst_journal AS journal ON wo.journalid = journal.journalid
    JOIN wms_workorder_stage AS wostage ON wostage.workorderid = wo.workorderid
        AND wostage.wfstageid = wf.stageid
        AND wostage.stageiterationcount = we.stageiterationcount
    JOIN wms_mst_stage AS stagem ON stagem.stageid = wf.stageid
    WHERE we.activitystatus = 'Completed'
      AND we.updated_date::date > '2025-04-24'
      AND wf.wfid = 25
      AND wf.stageid IN (2)
      AND wo.workorderid NOT IN (
          SELECT workorderid 
          FROM trn_cup_signal_log 
          WHERE signalname = 'proofapproved'
      )
      ${itemcode ? `AND wo.itemcode = '${itemcode}'` : ''}
     ${type ? `AND 'YTS' = '${type}'` : ''}
      ${stagename ? `AND stagem.stagename ILIKE '${stagename}'` : ''}
      ${status ? `AND 'YTS' = '${status}'` : ''}
      ${
        fromdate && todate
          ? `AND we.updated_date::DATE BETWEEN '${fromdate}'::DATE AND '${todate}'::DATE`
          : ''
      }

    UNION ALL

    SELECT
        w.workorderid,
        CASE WHEN w.workorderid IS NOT NULL THEN w.itemcode ELSE l.pii END AS itemcode,
        l.stagename,
        l.stageiteration,
        l.signalname,
        l.payload,
        l.responce,
        l.remarks,
        l.status,
        l.signaltype AS type,
        TO_CHAR(l.createddate AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata', 'DD-MM-YYYY HH24:MI:SS') AS signal_time
    FROM trn_cup_signal_log l
    LEFT JOIN wms_workorder w ON l.workorderid = w.workorderid
    LEFT JOIN wms_workorder ww 
        ON ww.customerid = 8 AND ww.isactive = true AND ww.otherfield ->> 'pii' = l.pii
    WHERE ww.workorderid IS NULL
      ${itemcode ? `AND w.itemcode = '${itemcode}'` : ''}
         ${type ? `AND  l.signaltype = '${type}'` : ''}
      ${stagename ? `AND l.stagename ILIKE '${stagename}'` : ''}
      ${status ? `AND l.status = '${status}'` : ''}
      ${
        fromdate && todate
          ? `AND l.createddate::DATE BETWEEN '${fromdate}'::DATE AND '${todate}'::DATE`
          : ''
      }

    UNION ALL

    SELECT  
        NULL AS workorderid,
        itemcode,      
        'Incoming Inspection' AS stagename,
        1 AS stageiteration,
        '' AS signalname,
        '' AS payload,
        '' AS responce,
        'Package Received, Signal Yet to Receive' AS remarks,
        'YTR' AS status,
        'YTR' AS type,
        TO_CHAR(MAX(createdon) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata', 'DD-MM-YYYY HH24:MI:SS') AS signal_time 
    FROM (
        SELECT 
            DISTINCT RIGHT(articlename, 17) AS itemcode,
            createdon
        FROM ftp_audit_wo_creation a
        WHERE 
            a.remark IN ('Workorder XML content is empty','Metadata XML is Missing')
            AND a.remark NOT ILIKE '%Journal Details Not Found for JournalAcronym%'
            AND LENGTH(a.articlename) > 13
    ) AS q
    WHERE q.itemcode NOT IN (
        SELECT pii FROM trn_cup_signal_log WHERE status = 'Received'
    )
    AND q.itemcode NOT IN (
        SELECT DISTINCT RIGHT(articlename, 17)
        FROM ftp_audit_wo_creation a
        WHERE 
            a.remark IN ('Workorder XML content is empty','Metadata XML is Missing')
            AND a.remark NOT ILIKE '%Journal Details Not Found for JournalAcronym%'
            AND LENGTH(a.articlename) > 13
            AND RIGHT(articlename, 17) IN (
                SELECT otherfield ->> 'pii' 
                FROM wms_workorder 
                WHERE customerid = 8 AND isactive = true
            )
    ) AND 1 = 1   ${type ? `and 'YTR' = '${type}'` : ''}
          ${
            itemcode
              ? `AND DISTINCT RIGHT(articlename, 17) = '${itemcode}'`
              : ''
          }
      ${stagename ? `AND 'Incoming Inspection' ILIKE '${stagename}'` : ''}
      ${status ? `AND 'YTR' = '${status}'` : ''}
            ${
              fromdate && todate
                ? `AND createdon::DATE BETWEEN '${fromdate}'::DATE AND '${todate}'::DATE`
                : ''
            }
    GROUP BY itemcode
),

ranked_result AS (
    SELECT *,
        ROW_NUMBER() OVER (PARTITION BY itemcode ORDER BY TO_TIMESTAMP(signal_time, 'DD-MM-YYYY HH24:MI:SS') DESC) AS rn
    FROM combined_result
)

SELECT * 
FROM ranked_result
WHERE rn = 1
ORDER BY TO_TIMESTAMP(signal_time, 'DD-MM-YYYY HH24:MI:SS') DESC`;

  try {
    const data = await query(sql);
    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

const getWIPQueryBasedOnDuid = async duid => {
  switch (duid) {
    case 95:
    case '95':
      return `WITH problemtask AS (
                  SELECT
                      ROW_NUMBER() OVER (PARTITION BY articleid, stage, activity ORDER BY id DESC) AS frno,
                      articleid,
                      CASE 
                          WHEN isactive = true THEN 'Open'
                          WHEN isreject = true THEN 'Rejected'
                          ELSE 'Close'
                      END AS prblmtskstatus,
                      signal_description AS prblmtsktext,
                      xmldata AS prblmtskhistory,
                      stage,
                      activity
                  FROM trn_problemtask
              )

              SELECT
                  ROW_NUMBER() OVER (ORDER BY ww.itemcode) AS serial,
                  ww.itemcode AS bookcode,
                  pmj.journalacronym,
                  REPLACE(ww.itemcode, pmj.journalacronym, '') AS articleid,
                  COALESCE(ww.otherfield ->> 'pii', '') AS pii,
                  INITCAP(COALESCE(ww.otherfield ->> 'is_re_routed', 'No')) AS isrerouted,
                  ww2.wfname AS "Workflow",
                  ww2.wfname AS "workflow",
                  CASE 
                      WHEN wws.stageiterationcount = 1 THEN wms.stagename
                      ELSE CONCAT(wms.stagename, ' (', wws.stageiterationcount::text, ')')::varchar 
                  END AS "Stage",
                  CASE 
                      WHEN wws.stageiterationcount = 1 THEN wms.stagename
                      ELSE CONCAT(wms.stagename, ' (', wws.stageiterationcount::text, ')')::varchar 
                  END AS stage,
                  ww3.activityalias,
                  wwe.activitystatus,
                  TO_CHAR(wws.ordermaildatetime + INTERVAL '5 hours 30 minutes', 'dd-Mon-yyyy hh24:mi:ss') AS receiveddate,
                  TO_CHAR(wws.plannedenddate + INTERVAL '5 hours 30 minutes', 'dd-Mon-yyyy hh24:mi:ss') AS duedate,
                  CASE
                    WHEN EXTRACT(EPOCH FROM (wws.plannedenddate - NOW())) < 0
                        AND ABS(EXTRACT(EPOCH FROM (wws.plannedenddate - NOW())) / 86400) < 1 THEN 0
                    ELSE (EXTRACT(EPOCH FROM (wws.plannedenddate - NOW())) / 86400)::integer
                  END AS daysleft,
                  (EXTRACT(EPOCH FROM ((wws.plannedenddate) - NOW())) / 3600)::integer AS hoursleft,
                  CASE 
                      WHEN wws.plannedenddate < NOW() THEN 'YES' 
                      ELSE 'NO' 
                  END AS overdue,
                  wwifd.mspages,
                  COALESCE(wu.username || '(' || wu.userid || ')', '') AS assigned,
                  COALESCE(wmp.priority, 'NA') AS filepriority,
                  COALESCE(wmp2.priority, 'NA') AS "Journal Priority",
                  COALESCE(wmp2.priority, 'NA') AS priority,
                  gmc.countryname AS country,
                  omd.divisionalias AS "Division",
                  omd.divisionalias AS division,
                  COALESCE(pt.prblmtskstatus, 'NA') AS prblmtskstatus,
                  COALESCE(pt.prblmtsktext, 'NA') AS prblmtsktext,
                  CASE
                      WHEN wws.plannedenddate::DATE >= CURRENT_DATE
                          THEN wws.plannedenddate::DATE
                      ELSE (CURRENT_DATE - INTERVAL '1 DAY')::DATE
                  END AS "Date"
              FROM wms_workorder ww
              JOIN org_mst_division omd ON omd.divisionid = ww.divisionid
              JOIN wms_workflow ww2 ON ww2.wfid = ww.wfid
              JOIN wms_workorder_stage wws ON wws.workorderid = ww.workorderid --AND wws.wfstageid != 10
              JOIN wms_mst_stage wms ON wms.stageid = wws.wfstageid
              JOIN wms_workflowdefinition ww3 ON ww3.wfid = ww.wfid AND ww3.stageid = wws.wfstageid
              JOIN wms_workflow_eventlog wwe ON wwe.workorderid = ww.workorderid 
                  AND wwe.wfdefid = ww3.wfdefid 
                  AND wwe.activitystatus NOT IN ('Completed', 'Rejected', 'Reset')
              LEFT JOIN wms_workorder_incomingfiledetails wwifd ON wwifd.woincomingfileid = wwe.woincomingfileid
              LEFT JOIN wms_user wu ON wu.userid = wwe.userid
              LEFT JOIN wms_mst_priority wmp ON wmp.priorityid = wwe.priority
              JOIN pp_mst_journal pmj ON pmj.journalid = ww.journalid
              LEFT JOIN wms_mst_priority wmp2 ON wmp2.priorityid = pmj.priorityid
              JOIN org_mst_customer_orgmap omco ON omco.custorgmapid = pmj.custorgmapid
              JOIN geo_mst_country gmc ON gmc.countryid = omco.countryid
              LEFT JOIN problemtask pt ON pt.articleid = ww.itemcode 
                  AND pt.stage = wms.stagename 
                  AND pt.activity = ww3.activityalias 
                  AND pt.frno = 1
              WHERE 
                  ww.duid = ${duid} AND ww.isactive = true AND wws.status = 'In Process' AND wws.plannedenddate IS NOT NULL
              ORDER BY ww.itemcode ASC;`;
    default:
      return `select row_number() over(order by bookcode) as "serial", service as "Service",stage as "Stage", division as "Division",
              customername as "Customer", workflow as "Workflow",software  as "Software" ,pmname as "PM", duedate as "Date",
              proddespatchdate as "Actualdate", querystatus as "Query Status", error_details as "Error Details", cup_celevel,
              celevel, grammarscore, journal_cetype, prob1, prob2, prob3, status, priority as "Journal Priority",
              groupstage as "Group Stage", *
              from wip_report where duid = ${duid}`;
  }
};
