import { query } from '../../../database/postgres.js';

export const getJobSummaryReport = (req, res) => {
  const reqData = req.body;
  const jdata = JSON.stringify(reqData);

  // const jdata = {"startdate":"2023-05-31 00:00:00","enddate":"2023-05-31 23:59:00", "customerid":8}
  const sql = `select * from public.getjobsummaryreport('${jdata}')`;

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// select stages based on customer
export const stageListForCustomer = (req, res) => {
  const sql = `SELECT c.stagename AS value,c.stagename AS label,b.stageid,MIN(b.sequence) AS minseq
FROM public.wms_workflow AS ad
JOIN wms_workflowdefinition AS b ON ad.wfid = b.wfid
JOIN wms_mst_stage AS c ON c.stageid = b.stageid AND c.isactive = true
JOIN org_mst_customerorg_du_map AS du_map ON  du_map.duid = ${req.body.duId}
JOIN org_mst_customer_orgmap AS org_map ON org_map.custorgmapid = du_map.custorgmapid
JOIN org_mst_customer AS customer ON customer.customerid = org_map.customerid
WHERE ad.isactive = true AND customer.isactive = true
GROUP BY c.stagename, b.stageid
ORDER BY minseq`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// select actvity name based on stage
export const activityListForStage = (req, res) => {
  const sql = `select b.activityalias as value,b.activityalias as label
  from 
  public.wms_workflow as ad 
  join wms_workflowdefinition as b on ad.wfid=b.wfid
  join wms_mst_stage as c on c.stageid=b.stageid and c.isactive= true
  where ad.customerid = ${req.body.customerid} and ad.isactive=true  and c.stagename = '${req.body.stagename}' and b.enablefilestatusreport=true 		  
  order by  b.sequence `;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// select users for a DU
export const getUserList = (req, res) => {
  const sql = `select userid as value, username||' ('||userid||')' as label from wms_user where duid=${req.body.duId} order by userid desc`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
