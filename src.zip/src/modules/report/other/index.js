import { query } from '../../../database/postgres.js';

export const GetQualityRemarks = async (req, res) => {
  try {
    const { workorderId, stageId } = req.body;

    if (!workorderId || !stageId) {
      return res
        .status(400)
        .json({ error: 'workorderid & stageid is required' });
    }

    const sqlqry = `SELECT ROW_NUMBER() OVER (ORDER BY tqr.created_time DESC) AS serial, wms.stagename || '(' || tqr.stageiterationcount || ')' AS stage, 
                        ww2.activityalias || '(' || tqr.activityiterationcount || ')' AS activity, tqr.remarks,
                        UPPER(wu.username || ' (' || wu.userid || ')') AS remarksby,
                        TO_CHAR(tqr.created_time + INTERVAL '5 hours 30 minutes', 'DD-MM-YYYY HH12:MI:SS AM') AS remarkson
                    FROM trn_quality_remarks tqr
                    JOIN wms_workorder ww ON ww.workorderid = tqr.workorderid
                    JOIN wms_mst_stage wms ON wms.stageid = tqr.stageid
                    JOIN wms_workflowdefinition ww2 ON ww2.wfid = ww.wfid AND ww2.stageid = wms.stageid AND ww2.activityid = tqr.activityid
                    JOIN wms_user wu ON wu.userid = tqr.created_by
                    WHERE tqr.isactive = TRUE AND tqr.workorderid = $1 AND tqr.stageid = $2
                    ORDER BY tqr.created_time DESC;`;

    const data = await query(sqlqry, [workorderId, stageId]);

    return res.status(200).json({ data });
  } catch (error) {
    return res.status(400).send({ error: error.message });
  }
};
