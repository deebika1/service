import { query } from '../../database/postgres.js';

export const getNotificationOptions = (req, res) => {
  const { type, divisionId, subDivisionId, duId, customerId, entityTypeId } =
    req.body;
  let sql = ``;
  if (type === 'roles') {
    sql = `SELECT * FROM wms_role`;
  }
  if (type === 'du') {
    sql = `SELECT DISTINCT ON (org_mst_deliveryunit.duid) org_mst_deliveryunit.duid as value, 
		org_mst_deliveryunit.duname as label FROM org_mst_customer_orgmap 
			JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
			 JOIN org_mst_deliveryunit ON org_mst_customerorg_du_map.duid = org_mst_deliveryunit.duid
            WHERE org_mst_customer_orgmap.divisionid = ${divisionId} and
            org_mst_customer_orgmap.subdivisionid = ${subDivisionId}  
            and  org_mst_deliveryunit.isactive=true order by org_mst_deliveryunit.duid`;
  } else if (type === 'division') {
    sql = `
        SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value,org_mst_division.division as label
        from org_mst_division
        WHERE org_mst_division.isactive=true order by org_mst_division.divisionid`;
  } else if (type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap  
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${divisionId}  and org_mst_subdivision.isactive=true`;
  } else if (type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label FROM org_mst_customer_orgmap  
            JOIN org_mst_customer ON org_mst_customer_orgmap.customerid = org_mst_customer.customerid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${divisionId}  AND 
            org_mst_customer_orgmap.subdivisionid = ${subDivisionId} and org_mst_customerorg_du_map.duid=${duId}  and org_mst_customer.isactive=true`;
  } else if (type === 'service') {
    sql = `SELECT  DISTINCT ON (service.serviceid)  service.serviceid as value, service.servicename as label FROM public.org_mst_customer_orgmap as custmap
                JOIN public.org_mst_customerorg_service_map as custservice ON custservice.custorgmapid = custmap.custorgmapid
                JOIN public.wms_mst_service as service ON service.serviceid = custservice.serviceid
                JOIN org_mst_customerorg_du_map as dumap ON dumap.custorgmapid = custmap.custorgmapid 
                WHERE  custmap.customerid=${customerId} AND custmap.divisionid=${divisionId} 
                AND custmap.subdivisionid=${subDivisionId} AND dumap.duid = ${duId}  and service.isactive=true`;
  } else if (type === 'workflow') {
    sql = `SELECT workflow.wfid as value, workflow.wfname as label
        FROM public.wms_workflow as workflow
        WHERE workflow.isactive = true AND  workflow.customerid =${customerId}
        ORDER BY workflow.wfid ASC`;
  } else if (type === 'journal') {
    sql = `SELECT DISTINCT ON(journal.journalid) journal.journalid as value, journal.journalacronym as label FROM pp_mst_journal as journal
        JOIN org_mst_customer_orgmap as custmap ON custmap.customerid=${customerId} AND custmap.divisionid=${divisionId} 
        AND custmap.subdivisionid=${subDivisionId}
        WHERE journal.custorgmapid = custmap.custorgmapid
        ORDER BY journal.journalid ASC`;
  } else if (type === 'notificationType') {
    sql = `SELECT notificationtypeid as value, notificationtype as label FROM wms_mst_notification_type ORDER BY notificationtypeid ASC`;
  } else if (type === 'template') {
    sql = `SELECT notiftemplateid as value, templatename as label FROM wms_mst_notification_template ORDER BY notiftemplateid ASC`;
  } else if (type === 'sender') {
    sql = `SELECT senderid as value, sender as label FROM wms_mst_notification_sender ORDER BY senderid ASC`;
  } else if (type === 'alertOnTaskStatus') {
    sql = `SELECT actionid as value, action as label FROM wms_mst_actions  WHERE entitytypeid = ${entityTypeId}
        ORDER BY actionid ASC`;
  } else if (type === 'alertOnDueDateType') {
    sql = `SELECT duedatetypeid as value, duedatetype as label FROM wms_mst_duedatetype ORDER BY duedatetypeid ASC`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

// this function will create notification sender
export const createNotificationSender = (req, res) => {
  const { senderType, email, status } = req.body;
  let sql = `SELECT * FROM wms_mst_notification_sender WHERE sender = '${email}'`;
  console.log(sql, 'sql for sender');
  query(sql)
    .then(data => {
      if (data.length) {
        res.status(409).send({ message: 'Given sender is already exits' });
      } else {
        sql = `INSERT INTO public.wms_mst_notification_sender(sendertype, sender, isactive) 
            VALUES ('${senderType}','${email}', ${status})`;
      }
      query(sql)
        .then(() => {
          res
            .status(200)
            .json({ message: `Sender has been added successfully` });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// this function will update notification sender
export const updateNotificationSender = (req, res) => {
  const { senderId, senderType, email, status } = req.body;
  console.log(req.body, 'bodydyy');
  let sql = `SELECT * FROM wms_mst_notification_sender WHERE senderid != ${senderId} AND sender = '${email}'`;
  query(sql)
    .then(data => {
      if (data.length) {
        res.status(409).send({ message: 'Given sender is already exits' });
      } else {
        sql = `UPDATE public.wms_mst_notification_sender
            SET sendertype='${senderType}', sender='${email}', isactive=${status}
            WHERE senderid =${senderId}`;
      }
      query(sql)
        .then(() => {
          res
            .status(200)
            .json({ message: `Sender has been updated successfully` });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const deleteNotificationSenderMap = (req, res) => {
  const { senderId } = req.body;
  const sql = `DELETE FROM wms_mst_notification_sender WHERE senderid = ${senderId}`;
  console.log(sql, 'sql for delete sender');
  query(sql)
    .then(data => {
      res.status(200).json({ data, message: 'Deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// this function will get notification sender list

export const getNotificationSenderList = (req, res) => {
  let sql = '';
  sql = `select count(1) from wms_mst_notification_sender where 1=1`;
  console.log(sql, 'sender list ft');
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        sql = `select * from wms_mst_notification_sender where 1=1 ORDER BY senderid DESC`;
        query(sql)
          .then(getToolData => {
            res.status(200).json({
              data: {
                data: getToolData,
                total: getCount[0].count,
              },
              Success: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, Success: false, data: [] });
          });
      } else {
        res.status(200).json({
          data: { data: [] },
          message: 'No data found',
          Success: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, Success: false, data: [] });
    });
};

// this function will create notification master
export const createNotification = (req, res) => {
  const {
    notificationname,
    division,
    subdivision,
    customer,
    du,
    journal,
    workflow,
    service,
    entityType,
    alertOnTaskStatus,
    alertOnDueStatus,
    taskData,
    dueData,
  } = req.body;
  let journalCon = '';
  if (journal) {
    journalCon = `AND journalid = ${journal}`;
  }
  let sql = `SELECT * FROM wms_mst_notification WHERE notificationname = '${notificationname}' AND divisionid = ${division} AND subdivisionid = ${subdivision} AND customerid = ${customer} 
    AND duid = ${du} AND wfid = ${workflow} AND serviceid = ${service} ${
    journalCon || ''
  } `;
  console.log(sql, 'sql for check exists');
  query(sql)
    .then(data => {
      if (data.length) {
        res
          .status(409)
          .send({ message: 'Given notification combination is already exits' });
      } else {
        sql = `INSERT INTO public.wms_mst_notification(
                notificationname, divisionid, subdivisionid, customerid, duid, journalid, wfid, serviceid, entitytypeid, isalerttaskstatus, isalertduestatus)
                VALUES ('${notificationname}', ${division}, ${subdivision}, ${customer},
                ${du}, ${journal}, ${workflow}, ${service}, ${entityType}, ${alertOnTaskStatus}, ${alertOnDueStatus}) RETURNING notificationid`;
        console.log(sql, 'sql for notif');
        query(sql)
          .then(async resForNotif => {
            if (resForNotif.length) {
              let taskNotifRes = true;
              if (taskData.length) {
                taskNotifRes = await taskNotificationAdd(
                  taskData,
                  resForNotif[0].notificationid,
                );
              }
              let dueNotifRes = true;
              if (dueData.length) {
                dueNotifRes = await dueNotificationAdd(
                  dueData,
                  resForNotif[0].notificationid,
                );
              }
              console.log(taskNotifRes, 'taskNotifRes');
              if (taskNotifRes && dueNotifRes) {
                res
                  .status(200)
                  .json({ message: `Notification created successfully` });
              }
            }
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// this function will update notification master
export const updateNotification = (req, res) => {
  const {
    notificationId,
    notificationname,
    division,
    subdivision,
    customer,
    du,
    journal,
    workflow,
    service,
    entityType,
    alertOnTaskStatus,
    alertOnDueStatus,
    taskData,
    dueData,
  } = req.body;
  let journalCon = '';
  if (journal) {
    journalCon = `AND journalid = ${journal}`;
  }
  let sql = `SELECT * FROM wms_mst_notification WHERE notificationid !=${notificationId} AND notificationname = '${notificationname}' AND divisionid = ${division} AND subdivisionid = ${subdivision} AND customerid = ${customer} 
    AND duid = ${du} AND wfid = ${workflow} AND serviceid = ${service} ${
    journalCon || ''
  } `;
  console.log(sql, 'sql for check exists');
  query(sql)
    .then(data => {
      if (data.length) {
        res
          .status(409)
          .send({ message: 'Given notification combination is already exits' });
      } else {
        sql = `UPDATE public.wms_mst_notification
            SET notificationname='${notificationname}', divisionid=${division}, subdivisionid=${subdivision}, customerid=${customer},
            duid=${du}, journalid=${journal}, wfid=${workflow}, entitytypeid=${entityType}, isalerttaskstatus=${alertOnTaskStatus}, isalertduestatus=${alertOnDueStatus}, serviceid=${service}
            WHERE notificationid=${notificationId} RETURNING notificationid`;

        console.log(sql, 'sql for notif update');
        query(sql)
          .then(async resForNotif => {
            if (resForNotif.length) {
              let taskNotifRes = true;
              if (taskData.length) {
                taskNotifRes = await taskNotificationAdd(
                  taskData,
                  resForNotif[0].notificationid,
                );
              }
              let dueNotifRes = true;
              if (dueData.length) {
                dueNotifRes = await dueNotificationAdd(
                  dueData,
                  resForNotif[0].notificationid,
                );
              }
              console.log(taskNotifRes, 'taskNotifRes');
              if (taskNotifRes && dueNotifRes) {
                res
                  .status(200)
                  .json({ message: `Notification updated successfully` });
              }
            }
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
const taskNotificationAdd = (taskData, id) => {
  console.log(taskData, 'taskData');
  console.log(id, 'id');
  const values = [];
  taskData.forEach(item => {
    values.push(`('${id}',${item.stage},${item.activity},${item.action},
        ${item.notificationType}, ${item.template}, ${
      item.sender
    }, '${JSON.stringify(item.recipietns)}', ${item.status})`);
  });
  console.log(values, 'values for task notif');
  return new Promise((resove, reject) => {
    let sql = `DELETE FROM wms_mst_notification_details WHERE notificationid = ${id}`;
    query(sql)
      .then(deleteRes => {
        console.log(deleteRes, 'res for delete notif details');
        sql = `INSERT INTO public.wms_mst_notification_details(
            notificationid, stageid, activityid, actionid, notificationtypeid, notiftemplateid, senderid, recipient, isactive)
            VALUES ${values} RETURNING notifdetailsid`;
        console.log(sql, 'sql for task notif details');
        query(sql)
          .then(data => {
            console.log(data, 'res for notif details');
            if (data.length) {
              console.log(data, 'inside res for notif details');
              resove(data[0].notifdetailsid);
            } else {
              resove(0);
            }
          })
          .catch(error => {
            reject(error);
          });
      })
      .catch(error => {
        reject(error);
      });
  });
};
const dueNotificationAdd = (dueData, id) => {
  console.log(dueData, 'dueData');
  console.log(id, 'id');
  const values = [];
  dueData.forEach(item => {
    values.push(`('${id}',${item.dueCriteriaId},${item.dueDays},${item.stage},${
      item.activity
    },${item.action},
        ${item.notificationType}, ${item.template}, ${
      item.sender
    }, '${JSON.stringify(item.recipietns)}', ${item.status})`);
  });
  console.log(values, 'values for task notif due');
  return new Promise((resove, reject) => {
    let sql = `DELETE FROM wms_mst_duedate_notification_details WHERE notificationid = ${id}`;
    query(sql)
      .then(deleteRes => {
        console.log(deleteRes, 'res for delete notif details due');
        sql = `INSERT INTO public.wms_mst_duedate_notification_details(
                notificationid, duedatetypeid, noofdays, stageid, activityid, actionid, notificationtypeid, notiftemplateid, senderid, recipient, isactive)
                VALUES ${values} RETURNING notifduedatedetailsid`;
        console.log(sql, 'sql for task notif due details');
        query(sql)
          .then(data => {
            console.log(data, 'res for notif details due');
            if (data.length) {
              console.log(data, 'inside res for notif details due');
              resove(data[0].notifduedatedetailsid);
            } else {
              resove(0);
            }
          })
          .catch(error => {
            reject(error);
          });
      })
      .catch(error => {
        reject(error);
      });
  });
};

// this function will get notification list
export const getNotificationList = (req, res) => {
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // const offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  sql = `select count(1) from wms_notification_list where 1=1`;
  console.log(sql, 'notification list');
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        // const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        sql = `select * from wms_notification_list where 1=1 ORDER BY notificationid DESC`;
        query(sql)
          .then(response => {
            res.status(200).json({
              data: {
                data: response,
              },
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, data: [] });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, data: [] });
    });
};

// this function will get notification details list
export const getNotificationDetailList = (req, res) => {
  const { notificationId } = req.body;
  let sql = `SELECT dnd.notificationid, dnd.stageid, dnd.activityid, dnd.actionid, dnd.notificationtypeid, dnd.notiftemplateid, dnd.senderid, dnd.recipient, dnd.isactive,
        actions.actionid, actions.action, stage.stagename, activity.activityname  FROM wms_mst_notification_details as dnd
        JOIN wms_mst_actions as actions ON actions.actionid = dnd.actionid
        LEFT JOIN wms_mst_stage as stage ON stage.stageid = dnd.stageid
	    LEFT JOIN wms_mst_activity as activity ON activity.activityid = dnd.activityid
        WHERE notificationid =${notificationId} ORDER BY notifdetailsid ASC`;
  console.log(sql, 'notification detail list');
  query(sql)
    .then(resForStatus => {
      sql = `SELECT dnd.notifduedatedetailsid, dnd.notificationid, dnd.duedatetypeid, dnd.noofdays, dnd.stageid, dnd.activityid, dnd.actionid, dnd.notificationtypeid, dnd.notiftemplateid, dnd.senderid, dnd.recipient, dnd.isactive,
        actions.actionid, actions.action, dueType.duedatetypeid, dueType.duedatetype, stage.stagename, activity.activityname    FROM wms_mst_duedate_notification_details as dnd
        JOIN wms_mst_actions as actions ON actions.actionid = dnd.actionid
        JOIN wms_mst_duedatetype as dueType ON dueType.duedatetypeid = dnd.duedatetypeid
        LEFT JOIN wms_mst_stage as stage ON stage.stageid = dnd.stageid
	    LEFT JOIN wms_mst_activity as activity ON activity.activityid = dnd.activityid
        WHERE notificationid =${notificationId} ORDER BY notifduedatedetailsid ASC`;
      console.log(sql, 'notification due date detail list');
      query(sql)
        .then(resForDueDate => {
          res.status(200).json({
            data: { taskStatus: resForStatus, taskDueDate: resForDueDate },
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will delete notification
export const deleteNotification = (req, res) => {
  const { notificationId } = req.body;
  let sql = `DELETE FROM wms_mst_notification_details WHERE notificationid =${notificationId}`;
  console.log(sql, 'notification details list');
  query(sql)
    .then(() => {
      sql = `DELETE FROM wms_mst_notification WHERE notificationid =${notificationId}`;
      console.log(sql, 'notification list');
      query(sql)
        .then(() => {
          res.status(200).json({ data: 'Notification deleted successfully' });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
