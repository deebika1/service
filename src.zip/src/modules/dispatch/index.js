// import moment from 'moment';
import axios from 'axios';
import { query } from '../../database/postgres.js';
import { sendToFTPOUTQueue } from '../../mq/index.js';
import { config } from '../../config/restApi.js';
import logger from '../utils/logs/index.js';

// export const _dispatchFromIauthor = async (req, res) => {
const delayProcess = ms =>
  new Promise(resolve => {
    setTimeout(resolve, ms);
  });

export const _dispatchFromIauthor = async payloadData => {
  return new Promise(async (resolve, reject) => {
    const { iAuthorLink, pdfpageCount, correctionCount, article_guid } =
      payloadData;
    const payload = payloadData;
    try {
      await dispatchTansLog(payload);
      const woInfo = await getWoInfo(payload);
      let dataMissing = false;
      if (
        payload.flowtype == 'author_signal' ||
        payload.flowtype == 'editor_signal'
      ) {
        if (!pdfpageCount || correctionCount == undefined || !article_guid) {
          dataMissing = true;
        }
      }

      if (dataMissing) {
        throw new Error('The input data is missing. Please check the request');
      } else {
        payload.status = 'In Progress';
        // await dispatchTansLog(payload);
        // const woInfo = await getWoInfo(payload);
        const data = {
          ...payload,
          workorderId: woInfo.workorderid,
          title: woInfo.itemcode,
          stageId: woInfo.stageid,
          stagename: woInfo.stagename,
          pii: woInfo.piivalue,
          isReadyXML: true,
          articlename: woInfo.itemcode,
          journalcode: woInfo.itemcode,
          customerID: woInfo.custoemrid,
          typeID: 2,
          iAuthorLink,
          supplier: woInfo.supplier,
          iauthorsignal: payload.flowtype,
          iauthorWorkflowId: woInfo.iauthworkflow,
        };
        logger.info(
          `before sending ready xml - ${woInfo.itemcode} - ${payload.flowtype}`,
        );
        let attempts = 1;
        while (attempts <= 3) {
          try {
            await dispatch(data);
            break;
          } catch (err) {
            if (++attempts > 3) throw err;
            await delayProcess(60000);
          }
        }

        logger.info(
          `after sending ready xml - ${woInfo.itemcode} - ${payload.flowtype}`,
        );
        resolve({
          status: true,
          data: 'Successfully updated.',
        });
      }
      // res
      //   .status(200)
      //   .send({ status: 'Submission request acknowledged successfully' });
    } catch (err) {
      logger.info(
        `failed sending ready xml (guid) - ${article_guid} - ${payload.flowtype}`,
      );
      payload.status = 'Failed';
      payload.remarks = err.message ? err.message.replaceAll("'", "''") : err;
      await dispatchTansLog(payload);
      // res.status(400).send({
      //   status: false,
      //   message: 'Submission request acknowledgment failed',
      // });
      reject({
        status: false,
      });
    }
  });
};

// Article creation Module
export const dispatchFromIauthor = async (req, res) => {
  try {
    const payload = req.body;
    const response = await _dispatchFromIauthor(payload);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};

const dispatchTansLog = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        article_guid = null,
        id = null,
        iAuthorLink = null,
        aty_id = null,
        flowtype = 'link_generation_signal',
        status = null,
        remarks = null,
      } = payload;
      const flowtypeMap = {
        83: 'author_signal',
        84: 'editor_signal',
      };
      const finalFlowtype = flowtypeMap[aty_id] || flowtype;
      payload.flowtype = finalFlowtype;
      const payloadData = JSON.stringify(payload);
      console.log(status);
      const selectQuery = `select * from iauthor_dispatch_trns where guid = ${payload.article_guid} and 
      iauthorsignal ='${payload.flowtype}' order by 1 desc`;
      const data = await query(selectQuery);
      payload.remarks = payload.remarks ?? '';
      payload.server_filepath = payload.server_filepath
        ? payload.server_filepath
        : '';
      if (data.length > 0) {
        // const sql = `update iauthor_dispatch_trns set status='${payload.status}', remarks='${payload.remarks}' where guid='${payload.article_guid}' and iauthorsignal ='${payload.flowtype}'`;
        const sql = `update iauthor_dispatch_trns set status='${payload.status}', remarks='${payload.remarks}', filepath='${payload.server_filepath}', updated_time = TO_TIMESTAMP(NOW()::TEXT, 'YYYY-MM-DD HH24:MI:SS.US') where guid='${payload.article_guid}' and iauthorsignal ='${payload.flowtype}'`;
        await query(sql);

        if (
          payload.flowtype == 'author_signal' ||
          payload.flowtype == 'editor_signal'
        ) {
          const iAuthorInputData = {
            logId: data[0].iauthorid,
            isSuccess: payload.status == 'Completed' ? 1 : 0,
            responseMessage:
              payload.status == 'Completed'
                ? 'File Uploaded successfully'
                : 'Failure file upload.',
          };

          const configAPI = {
            method: 'post',
            url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
              config.iAuthor.elsevierStatusUpdate
            }`,
            headers: {
              'Content-Type': 'application/json',
              clientid: config.iAuthor.clientid,
              apikey: config.iAuthor.apikey,
            },
            data: JSON.stringify(iAuthorInputData),
          };

          const myResut = axios(configAPI)
            .then(() => {
              return true;
            })
            .catch(function () {
              return false;
            });

          console.log(myResut);
        }
        // axios(configAPI)
        //   .then()
        //   .catch(function (error) {
        //     error
        //       .status(400)
        //       .send({ is_success: false, message: error.message });
        //   });
      } else {
        const sql = `
      INSERT INTO iauthor_dispatch_trns (
        guid,
        iauthorid,
        iauthorlink,
        iauthoractivityid,
        iauthorsignal,
        payload,
        status,
        remarks,
        isactive,
        created_by
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10
      )
    `;
        const values = [
          article_guid,
          id,
          iAuthorLink,
          aty_id,
          finalFlowtype,
          payloadData,
          'In Process',
          remarks,
          'Y',
          'system',
        ];

        await query(sql, values);
      }

      resolve(true);
    } catch (err) {
      reject(err);
    }
  });
};

const getWoInfo = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { article_guid } = payload;
      // const sql = `SELECT otherfield->>'pii' AS piivalue,otherfield->>'supplier' AS supplier,wms_workorder.customerid as custoemrid,guid,wms_workorder.workorderid,wms_workorder.itemcode,wms_mst_stage.stageid, wms_mst_stage.stagename FROM iauthor_transactions
      //   JOIN wms_workorder ON wms_workorder.workorderid = iauthor_transactions.workorderid
      //   JOIN wms_mst_stage ON wms_mst_stage.stageid = iauthor_transactions.stageid
      //   WHERE guid = ${article_guid}`;

      const sql = `SELECT otherfield->>'pii_org' AS piivalue,otherfield->>'supplier' AS supplier,pp_mst_journal.iauthworkconversionflowid as iauthworkflow,wms_workorder.customerid as custoemrid,guid,wms_workorder.workorderid,wms_workorder.itemcode,wms_mst_stage.stageid, wms_mst_stage.stagename FROM iauthor_transactions 
        JOIN wms_workorder ON wms_workorder.workorderid = iauthor_transactions.workorderid
        JOIN wms_mst_stage ON wms_mst_stage.stageid = iauthor_transactions.stageid
		join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
        WHERE guid = ${article_guid}`;
      const getInfo = await query(sql);
      if (getInfo.length) {
        resolve(getInfo[0]);
      } else {
        reject('WO transaction info not found');
      }
    } catch (err) {
      reject(err);
    }
  });
};

const dispatch = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      await sendToFTPOUTQueue(payload);
      resolve(true);
    } catch (err) {
      reject(err);
    }
  });
};

export const updateDispatchFromIauthor = async (req, res) => {
  const payload = req.body;
  try {
    await dispatchTansLog(payload);

    res
      .status(200)
      .send({ status: 'Submission request acknowledged successfully' });
  } catch (err) {
    payload.status = 'Failed';
    payload.remarks = err.message ? err.message : err;
    await dispatchTansLog(payload);
    res.status(400).send({
      status: false,
      message: 'Submission request acknowledgment failed',
    });
  }
};
