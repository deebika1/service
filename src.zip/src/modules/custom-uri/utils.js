/* eslint-disable */
import { query, transaction } from '../../database/postgres.js';
import {
  getFileInfoDetails,
  fetchValidationDetails,
  _getIssueWorkorderInfo,
  _getNonArticleList,
  getWorkflowPlaceHolders,
} from '../task/fileDetails.js';
import { getBasicToolsData } from '../utils/tools/index.js';
import { getsftpConfig } from '../filetransferkit/index.js';
import { getFileSequenceForIssue } from '../woi/autoWorkorderCreationContainer.js';
import { copyExternalBlobToLocal } from '../utils/filecopy/index.js';
import { basename, dirname, extname } from 'path';
import { getBookDetailsTemplateElse } from '../woi/additionalInfo.js';
import { getSignalAuidtInfo } from '../../signalIntegration/service/index.js';
import { ialtSignalLogHistory } from '../../iAlt/service/index.js';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import {
  mandatoryInFileCheck,
  _localcopyFileWithoutFormData,
  _localFolderCopy,
} from '../utils/local/index.js';
import { getBasePath } from '../utils/wmsFolder/index.js';
import { getdmsType } from '../bpmn/listener/create.js';
import { writeSmallFile } from '../utils/custom/io.js';
import { v4 as uuidv4 } from 'uuid';
import { unlink } from 'fs/promises';
import * as azureHelper from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';
const service = new Service();

export const getToolDetail = async (req, res) => {
  const { toolId } = req.body;
  try {
    const toolsDetail = await getBasicToolsData(toolId);
    res.send(toolsDetail ? toolsDetail[0] : []);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const getFileDetails = async (req, res) => {
  let {
    wfEventId,
    workOrderId,
    du,
    customer,
    service,
    stage,
    activity,
    softwareId,
    fileConfig,
    placeHolders,
    mandatorySaveFile,
    eventData,
    issuemstid,
    activitymodeltypeflow,
    wfDefId,
    fileTypeId,
    isOtherArticle,
    articleOrderSequence,
    iscamundaflow,
  } = req.body;
  try {
    const otherArticleList = [];
    const validationFileConfig =
      fileConfig && fileConfig.fileTypes ? fileConfig.fileTypes : {};
    if (
      (activitymodeltypeflow == 'Partial' || customer.id == '13') &&
      isOtherArticle
    ) {
      const data = {
        workOrderId,
      };
      const info = await _getNonArticleList(data);

      const keys = Object.keys(fileConfig.fileTypes);
      const isOtherArticle = keys.filter(list => list == '83');
      const otherArticleConfig =
        isOtherArticle && isOtherArticle.length > 0
          ? fileConfig.fileTypes[isOtherArticle[0]]
          : fileConfig.fileTypes['83'];

      for (let i = 0; i < info.length; i++) {
        const datas = info[i];
        if (isOtherArticle && isOtherArticle.length > 0 && otherArticleConfig) {
          otherArticleList.push({ [datas.filetypeid]: otherArticleConfig });
        }
      }
      const uniqueData = otherArticleList.reduce((acc, obj) => {
        const existingObject = acc.find(item => item.name === obj.name);
        if (!existingObject) {
          acc.push(obj);
        }
        return acc;
      }, []);
      console.log(uniqueData);
      uniqueData.map(ele => {
        const key = Object.keys(ele);
        validationFileConfig[key] = ele[key];
      });
    }

    const typesId =
      fileConfig && fileConfig.fileTypesId ? fileConfig.fileTypesId : [];
    const softwareDetails = await getSoftwareDetails(softwareId);
    const fileTypes = await getFileTypes();
    const filesInfo = await getFileInfoDetails({
      wfEventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId,
      activitymodeltypeflow,
      issuemstid,
      wfDefId,
      fileTypeId,
      isOtherArticle,
      articleOrderSequence,
    });
    const filesData = await fetchValidationDetails(
      filesInfo,
      validationFileConfig,
      placeHolders,
      eventData,
      mandatorySaveFile,
      workOrderId,
    );
    filesData.filesAdditionalInfo.extractedFiles = [];
    if (!iscamundaflow) {
      fileTypeId = fileTypeId ? fileTypeId : '4';
      const isReject = req.body.isReject || false;

      if (fileConfig.fileTypes[fileTypeId]?.files?.length > 0) {
        let extractedFiles = '';
        const fetchFiles = async (files, placeholder) => {
          return isReject
            ? getConvertedRejectPath(files, placeholder)
            : getConvertedPath(files, placeholder);
        };

        if (isReject) {
          const sql = `SELECT rejectconfig FROM wms_workflowdefinition WHERE wfdefid = ${wfDefId}`;
          const rejectConfig = await query(sql);

          if (
            rejectConfig &&
            rejectConfig?.length > 0 &&
            rejectConfig?.[0].rejectconfig?.files
          ) {
            const unLockFiles = rejectConfig?.[0]?.rejectconfig.files.filter(
              list => !list.isLock,
            );
            extractedFiles = await fetchFiles(unLockFiles, placeHolders);
          } else {
            throw new Error(
              'Reject config missing. Please contact the IWMS administrator.',
            );
          }
        } else {
          //added only file extract in or out
          const isDownload = req.body.isDownload || false;
          let actualFiles = [];
          if (isDownload) {
            actualFiles = fileConfig.fileTypes[fileTypeId].files.filter(
              file =>
                (file.fileFlowType || []).filter(
                  x => x.toLocaleLowerCase() === 'in',
                ).length > 0,
            );
          } else {
            actualFiles = fileConfig.fileTypes[fileTypeId].files.filter(
              file =>
                (file.fileFlowType || []).filter(
                  x => x.toLocaleLowerCase() === 'out',
                ).length > 0,
            );
          }
          const unLockFiles = actualFiles.filter(list => !list.isLock);
          extractedFiles = await fetchFiles(unLockFiles, placeHolders);
        }

        if (extractedFiles?.length > 0) {
          filesData.filesAdditionalInfo.extractedFiles = extractedFiles;

          const newFileCopyBasePath = await getNewCopyBasePath(placeHolders);
          filesData.filesAdditionalInfo.newFileCopyBasePath =
            newFileCopyBasePath;
        } else {
          throw new Error(
            'Config missing.Please contact the IWMS administrator',
          );
        }
      } else {
        throw new Error(
          'File configuration missing. Please contact the IWMS administrator.',
        );
      }
    }

    res.send({
      ...filesData,
      fileTypes,
      validationFileConfig,
      softwareDetails,
    });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

//Elsevier Latest Folder files
export const getLatestStgActy = async (req, res) => {
  try {
    const payload = req.body;
    const latestIndex = await _getLatestStgActy(payload);
    res.status(200).json(latestIndex);
  } catch (error) {
    console.error(error);
    res.status(400).send({ message: error.message || JSON.stringify(error) });
  }
};

export const _getLatestStgActy = async payload => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, wfId, stgActyInfo } = payload;
    try {
      const wfdefids = [];
      for (let i = 0; i < stgActyInfo.length; i++) {
        const { stage, activity } = stgActyInfo[i];
        const sql = `SELECT wfdefid 
                    FROM wms_workflowdefinition 
                    WHERE wfid = $1 AND stageid = $2 AND activityid = $3`;

        const data = await query(sql, [wfId, stage, activity]);
        if (data && data.length > 0) {
          wfdefids.push({ wfdefid: data[0].wfdefid, index: i });
        }
      }

      if (wfdefids.length > 0) {
        const wfdefidList = wfdefids.map(item => item.wfdefid);
        const sqlEventLog = `SELECT wwe.wfdefid 
                            FROM wms_workflow_eventlog wwe
                            JOIN wms_workflow_eventlog_details wwed on wwed.wfeventid = wwe.wfeventid 
                            WHERE wwe.workorderid = $1
                            AND wwed.operationtype in ('Completed', 'Pending')
                            AND wwe.wfdefid = ANY($2) 
                            ORDER BY wwed.timestamp DESC LIMIT 1`;

        const latestEvent = await query(sqlEventLog, [
          workorderId,
          wfdefidList,
        ]);
        let latestIndex = -1;
        if (latestEvent && latestEvent.length > 0) {
          const latestWfdefid = latestEvent[0].wfdefid;
          latestIndex = wfdefids.find(
            item => item.wfdefid === latestWfdefid,
          )?.index;
          resolve(latestIndex);
        }
        resolve(latestIndex);
      } else {
        reject({
          message:
            'No valid wfdefid found for the provided stages and activities.',
        });
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const getIssueWorkorderInfo = async (req, res) => {
  try {
    const data = {
      wfDefId: req.body.wfDefId,
      issuemstid: req.body.issuemstid,
      workorderid: req.body.workorderid,
      runonFileSequence: req.body.runonfilesequence,
    };
    const issueWoInfo = await _getIssueWorkorderInfo(data);

    res.send({
      issueWoInfo,
    });
  } catch (error) {
    res.status(400).json(error);
  }
};

export const getFormattedGraphicPath = async (req, res) => {
  try {
    const { placeHolders } = req.body;
    const data = {
      duid: req.body.duid,
      customerid: req.body.customerid,
      //Changes reviewed by vinoth added for OUP Journal Image Upload
      isServerPath:
        req.body.isServerPath && req.body.isServerPath.length > 0
          ? req.body.isServerPath
          : '',
    };
    const correctpath = await _getFormattedGraphicPath(
      data,
      placeHolders,
      'genaral',
    );
    res.send({
      correctpath,
    });
  } catch (error) {
    res.status(400).json(error);
  }
};

export const _getFormattedGraphicPath = (data, placeHolders, type) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (type != 'graphictoolspath') {
        if (data.isServerPath.length == 0) {
          const sql1 = `select localgraphicfilepath from  wms_mst_customerconfigdetails  where customerid =${data.customerid} and duid =${data.duid}`;
          const serverpath = await query(sql1);
          if (serverpath.length > 0) {
            data.isServerPath = serverpath[0].localgraphicfilepath;
          } else {
            reject(
              'Graphics Serverpath not mapped please contact wms administrator',
            );
          }
        }
      } else {
        if (data.isServerPath.length == 0) {
          const sql1 = `select graphictoolspath from  wms_mst_customerconfigdetails  where customerid =${data.customerid} and duid =${data.duid}`;
          const serverpath = await query(sql1);
          if (serverpath.length > 0) {
            data.isServerPath = serverpath[0].graphictoolspath;
          } else {
            reject(
              'Graphics Serverpath not mapped please contact wms administrator',
            );
          }
        }
      }
      const pattern = ';{{placeholder}};';
      const placeHolderkeys = Object.keys(placeHolders);
      let formattedName = data.isServerPath;
      for (let i = 0; i < placeHolderkeys.length; i++) {
        const placeHolder = placeHolders[placeHolderkeys[i]]
          ? placeHolders[placeHolderkeys[i]]
          : `{{${placeHolderkeys[i]}}}`;
        if (typeof placeHolder != 'string' && placeHolder.length > 0) {
          if (formattedName.includes(placeHolderkeys[i])) {
            refOptions.hasMultiple = true;
            refOptions.paths = [];
            placeHolder.forEach(ele => {
              refOptions.paths.push(
                formattedName.replace(
                  new RegExp(
                    pattern.replace(/{{placeholder}}/, placeHolderkeys[i]),
                    'g',
                  ),
                  ele,
                ),
              );
            });
          }
        } else {
          formattedName = formattedName.replace(
            new RegExp(
              pattern.replace(/{{placeholder}}/, placeHolderkeys[i]),
              'g',
            ),
            placeHolder,
          );
        }
      }

      resolve(formattedName);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRevisedFileInfoE2E = async (req, res) => {
  try {
    const { customerid, issuemstid, isrevises, workorderid } = req.body;
    const sql = `select e2epath from wms_e2e_revisedtrn_file_map where issuemstid = ${issuemstid} and isrevises = ${isrevises}`;
    let response = await query(sql);

    if (response && response.length > 0) {
      let data = {
        srcPath: response[0].e2epath,
        destBasePath: req.body.destpath,
        name: basename(response[0].e2epath),
        customerName: 'KLI',
        customerId: customerid,
        containerType: 'e2e',
      };
      await copyExternalBlobToLocal(data);
    }
    res.status(200).json({ status: true });
    // const { customerid, issuemstid, isrevises, workorderid } = req.body;
    // const configDetails = await getsftpConfig(
    //   customerid.id,
    //   'e2e',
    //   workorderid,
    // );
    // if (configDetails) {
    //   const sql = `select e2epath from wms_e2e_revisedtrn_file_map where issuemstid = ${issuemstid} and isrevises = ${isrevises}`;
    //   let response = await query(sql);
    //   res.status(200).json({ config: configDetails, path: response });
    // }
  } catch (error) {
    res.status(400).json(error);
  }
};

const getSoftwareDetails = softwareId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM public.wms_mst_software where appid = any($1) and isactive = $2`;
      const softwareDetails = await query(sql, [softwareId, true]);
      resolve(softwareDetails);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

const getFileTypes = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT filetypeid, filetype FROM public.pp_mst_filetype
            ORDER BY filetypeid ASC `;
      const fileTpes = await query(sql);
      resolve(fileTpes);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

const getFileTrnQuery = type => {
  switch (type) {
    case 'insert_new_file':
      return `INSERT INTO wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES ($1, $2, $3, $4, $5, $6)`;
    case 'update_existing_file':
      return `UPDATE wms_workflowactivitytrn_file_map SET ischeckedout = $1 WHERE actfilemapid = $2`;
    case 'open_files':
      return `UPDATE wms_workflowactivitytrn_file_map SET isdownloaded = $1, workingfolderpath = $2, ischeckedout = $3 WHERE actfilemapid = $4`;
    default:
      return '';
  }
};

const getFileTrnQueryParams = (type, payload) => {
  switch (type) {
    case 'insert_new_file':
      return [
        payload.wfEventId,
        payload.uuid,
        payload.path,
        true,
        false,
        payload.fileId,
      ];
    case 'update_existing_file':
      return [false, payload.actFileMapId];
    case 'open_files':
      return [true, payload.path, payload.isCheckedOut, payload.actFileMapId];
    default:
      return [];
  }
};

export const updateFileTRNLog = (req, res) => {
  const { type, payload } = req.body;
  const sql = getFileTrnQuery(type);
  const params = getFileTrnQueryParams(type, payload);
  query(sql, params)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      res.status(400).send(e.message ? e.message : e);
    });
};
export const updateNewFileName = (req, res) => {
  const { incomingFileId, newFileName, piiNumber } = req.body;
  let sql = piiNumber
    ? `UPDATE public.wms_workorder_incomingfiledetails
	SET newfilename='${newFileName}', piinumber= '${piiNumber}'
	WHERE woincomingfileid=${incomingFileId};`
    : `UPDATE public.wms_workorder_incomingfiledetails
	SET newfilename='${newFileName}'
	WHERE woincomingfileid=${incomingFileId};`;
  query(sql)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      res.status(400).send(e.message ? e.message : e);
    });
};

export const updateNewFileNameFromTools = (req, res) => {
  const { incomingFileId, newFileName } = req.body;
  const sql = `UPDATE public.wms_workorder_incomingfiledetails
	SET newfilename='${newFileName}'
	WHERE woincomingfileid=${incomingFileId};`;
  query(sql)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      res.status(200).send(false);
    });
};
export const UpdateManuscriptzipnameforElseJNL = async (req, res) => {
  try {
    const { woId, manuscriptzipname } = req.body.data;
    const sql = `UPDATE wms_workorder
  SET otherfield = jsonb_set(otherfield::jsonb, '{manuscriptzipname}', '"${manuscriptzipname}"', true)
  WHERE workorderid = '${woId}';`;
    await query(sql)
      .then(response => {
        res.status(200).send({ issuccess: true, data: response });
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  } catch (error) {
    console.error('Error UpdateManuscriptzipnameforElseJNL:', error);
    res.status(500).send({ message: false });
  }
};
export const getFileSequence = (req, res) => {
  const { woid } = req.body;
  const sql = `select woin.filename,woin.filesequence,woin.filetypeid,woin.runonfilesequence,ftype.filetype,ftype.articletype  from wms_workorder_incoming as wo
  join  wms_workorder_incomingfiledetails as woin on woin.woincomingid = wo.woincomingid
  join pp_mst_filetype as ftype on ftype.filetypeid = woin.filetypeid
  where wo.woid = ${woid}  and woin.filetypeid != 10 order by woin.filesequence;`;
  query(sql)
    .then(response => {
      res.status(200).send({ data: response, status: true });
    })
    .catch(e => {
      res.status(200).send(false);
    });
};

export const getFileSequenceTemplate = (req, res) => {
  const { workorderId } = req.body;
  const sql = `select woin.filename,woin.filesequence,woin.filetypeid,woin.runonfilesequence,ftype.filetype,ftype.articletype, woin.startpage, woin.endpage, woin.typesetpage  from wms_workorder_incoming as wo
  join  wms_workorder_incomingfiledetails as woin on woin.woincomingid = wo.woincomingid
  join pp_mst_filetype as ftype on ftype.filetypeid = woin.filetypeid
  where wo.woid = ${workorderId}  and woin.filetypeid != 10 order by woin.filesequence;`;
  query(sql)
    .then(response => {
      res.status(200).send({ data: response, status: true });
    })
    .catch(e => {
      res.status(200).send(false);
    });
};

export const getBaseServerPath = async (req, res) => {
  try {
    const { customername, customerid, workOrderId } = req.body;
    const sql1 = `
    SELECT a.baseduid, a.wfid, b.duname
    FROM wms_workorder_service a
    JOIN org_mst_deliveryunit b ON b.duid = a.baseduid
    WHERE workorderid = $1
    ORDER BY woserviceid
  `;
    const [responseData] = await query(sql1, [workOrderId]);
    if (responseData) {
      const { baseduid, duname } = responseData;
      const dmsType = await getdmsType(workOrderId);
      const basePathPayload = {
        dmsType,
        du: {
          name: duname,
          id: baseduid,
        },
        customer: {
          name: customername,
          id: customerid,
        },
      };
      let response = await getBasePath(basePathPayload);
      res.status(200).send({ data: response, status: true });
    } else {
      throw `No data found for this workOrderId`;
    }
  } catch (e) {
    res.status(200).send(false);
  }
};
export const getFmFileSequenceElsBook = (req, res) => {
  const { woid, fileType } = req.body;
  const sql = `select woin.filename,woin.filesequence,woin.filetypeid,woin.runonfilesequence,ftype.filetype,ftype.articletype  from wms_workorder_incoming as wo
  join  wms_workorder_incomingfiledetails as woin on woin.woincomingid = wo.woincomingid
  join pp_mst_filetype as ftype on ftype.filetypeid = woin.filetypeid
  where wo.woid = ${woid}  and woin.filetypeid in (${fileType}) order by woin.filesequence;`;
  query(sql)
    .then(response => {
      res.status(200).send({ data: response, status: true });
    })
    .catch(e => {
      res.status(200).send(false);
    });
};

export const getFileSequenceIssueE2E = async (req, res) => {
  try {
    const { woid } = req.body;

    const sql = `select ppissue.issuename from wms_workorder as wo join pp_mst_issue_master as ppissue on ppissue.issuemstid = 
wo.issuemstid where wo.workorderid =${woid}`;
    const response = await query(sql);
    const data = await getFileSequenceForIssue(response[0].issuename);
    let payload = '';
    if (data && data.Status) {
      let fileOrder = [];
      data.Errormsg = JSON.parse(data.Errormsg);
      data.Errormsg.map(list => {
        fileOrder.push({
          filename: list.articleName,
          filesequence: list.fileSequence,
        });
      });

      payload = {
        data: fileOrder,
        status: true,
      };
    }

    res.status(200).send(payload);
  } catch (error) {
    res.status(400).send(false);
  }
};

//added for acs error content write
export const acsErrorContent = async (req, res) => {
  const { errorMessage, stageId, workOrderId } = req.body;
  try {
    const sql2 = `insert into acs_errorhandling_audit(workorderid,stageid,message,islock) values(${workOrderId},${stageId},'${errorMessage}','Y')`;
    await query(sql2);

    res.status(200).send({ status: true });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const replacePlaceholders = async (input, replacements) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (replacements?.workorderId) {
        const response = await query(
          `select journalid,wotype from wms_workorder where workorderid = ${replacements?.workorderId}`,
        );
        let res1 = '';
        if (response?.[0]?.journalid) {
          res1 = await query(
            `select journalacronym from pp_mst_journal where journalid = ${response?.[0]?.journalid}`,
          );
          replacements.JournalAcronym =
            response[0]?.wotype == 'Journal'
              ? res1?.[0]?.journalacronym
              : replacements.bookcode;
        } else {
          replacements.JournalAcronym = replacements.bookcode;
        }
      }
      const placeholderRegex = /;([^;]+);/g;
      const result = input.replace(placeholderRegex, (match, key) => {
        if (replacements.hasOwnProperty(key)) {
          return replacements[key];
        } else {
          return match;
        }
      });
      resolve(result.replace(/\s+/gi, '_'));
    } catch (error) {
      reject(`Error replacing placeholders: ${error.message}`);
    }
  });
};

export const getConvertedPath = (data, payload) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Fetch serverbasepath only once
      let resDmsType = await getdmsType(payload.workorderId, true);
      const { dmsType, isLocalIssue = false } = resDmsType;
      const basePathPayload = {
        dmsType,
        du: {
          id: payload.duid,
        },
        customer: {
          id: payload.customerid,
        },
        isLocalIssue,
      };
      let serverbasepath = await getBasePath(basePathPayload);
      if (serverbasepath.endsWith('/')) {
        serverbasepath = serverbasepath.slice(0, -1);
      }

      //Handled commonly
      const sql = `SELECT localserverpath,localgraphicfilepath,localtoolspath FROM public.wms_mst_customerconfigdetails WHERE customerid = ${payload.customerid} AND duid = ${payload.duid}`;
      const result = await query(sql);

      payload.serverbasepath = await replacePlaceholders(
        serverbasepath,
        payload,
      );

      payload.localgraphicfilepath = await replacePlaceholders(
        result[0]?.localgraphicfilepath,
        payload,
      );
      payload.localtoolspath = await replacePlaceholders(
        result[0]?.localtoolspath,
        payload,
      );
      //OLD logic
      // const sql = `SELECT localserverpath FROM public.wms_mst_customerconfigdetails WHERE customerid = ${payload.customerid} AND duid = ${payload.duid}`;
      // const result = await query(sql);
      // payload.serverbasepath = await replacePlaceholders(
      //   result[0]?.localserverpath,
      //   payload,
      // );
      payload.localworkingfolder = payload?.__WF__ || ';localworkingfolder;';
      // payload.bookcode = payload.BookCode;
      // payload.filename = payload.BookCode;
      // payload.foldername = payload.BookCode;

      for (let item of data) {
        const copyPaths = [];

        if (item.copydetail && item.copydetail.length > 0) {
          let placeholderinpath = item.name;
          let placeholderoutpath = item.outfileName;

          for (let detail of item.copydetail) {
            const [result1, result2] = await Promise.all([
              query(
                `SELECT stagename FROM wms_mst_stage WHERE stageid = ${detail.stage} ORDER BY 1 DESC LIMIT 1`,
              ),
              query(
                `SELECT activityname FROM wms_mst_activity WHERE activityid = ${detail.activity} ORDER BY 1 DESC LIMIT 1`,
              ),
            ]);

            const replacements = {
              ...payload,
              stagecode: result1[0]?.stagename || '',
              activitycode: result2[0]?.activityname || '',
            };

            copyPaths.push({
              sourcepath: await replacePlaceholders(
                placeholderinpath,
                replacements,
              ),
              destpath: await replacePlaceholders(
                placeholderoutpath,
                replacements,
              ),
            });

            (item.name = await replacePlaceholders(item.name, replacements)),
              (item.outfileName = await replacePlaceholders(
                item.outfileName,
                replacements,
              ));
          }
        } else {
        }

        item.copyPaths = copyPaths; // Assign generated copyPaths to item
      }

      resolve(data);
    } catch (error) {
      console.error('Error processing data:', error);
      reject(error);
    }
  });
};

export const getConvertedRejectPath = (data, payload) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Fetch serverbasepath only once
      const sql = `SELECT localserverpath FROM public.wms_mst_customerconfigdetails WHERE customerid = ${payload.customerid} AND duid = ${payload.duid}`;
      const result = await query(sql);
      payload.serverbasepath = await replacePlaceholders(
        result[0]?.localserverpath,
        payload,
      );
      //  payload.serverbasepath = result[0]?.localserverpath || ''; // Fallback to empty string if not found
      payload.localworkingfolder = payload.__WF__;
      // payload.bookcode = payload.BookCode;
      // payload.filename = payload.BookCode;
      // payload.foldername = payload.BookCode;

      for (let item of data) {
        const copyPaths = [];

        if (
          item.fromDetail &&
          item.fromDetail.length > 0 &&
          item.toDetail &&
          item.toDetail.length > 0
        ) {
          for (let i = 0; i < item.fromDetail.length; i++) {
            const fromDetail = item.fromDetail[i];
            const toDetail = item.toDetail[i];

            const [result1, result2, result3, result4] = await Promise.all([
              query(
                `SELECT stagename FROM wms_mst_stage WHERE stageid = ${fromDetail.stage} ORDER BY 1 DESC LIMIT 1`,
              ),
              query(
                `SELECT activityname FROM wms_mst_activity WHERE activityid = ${fromDetail.activity} ORDER BY 1 DESC LIMIT 1`,
              ),
              query(
                `SELECT stagename FROM wms_mst_stage WHERE stageid = ${toDetail.stage} ORDER BY 1 DESC LIMIT 1`,
              ),
              query(
                `SELECT activityname FROM wms_mst_activity WHERE activityid = ${toDetail.activity} ORDER BY 1 DESC LIMIT 1`,
              ),
            ]);

            const replacementsFrom = {
              ...payload,
              stagecode: result1[0]?.stagename || '',
              activitycode: result2[0]?.activityname || '',
            };

            const replacementsTo = {
              ...payload,
              stagecode: result3[0]?.stagename || '',
              activitycode: result4[0]?.activityname || '',
            };

            copyPaths.push({
              sourcepath: await replacePlaceholders(
                item.name,
                replacementsFrom,
              ),
              destpath: await replacePlaceholders(
                item.outfileName,
                replacementsTo,
              ),
            });

            // Update item paths
            (item.name = await replacePlaceholders(
              item.name,
              replacementsFrom,
            )),
              (item.outfileName = await replacePlaceholders(
                item.outfileName,
                replacementsTo,
              ));
          }
        } else {
        }

        item.copyPaths = copyPaths; // Assign generated copyPaths to item
      }

      resolve(data);
    } catch (error) {
      console.error('Error processing data:', error);
      reject(error);
    }
  });
};

export const getNewCopyBasePath = payload => {
  return new Promise(async (resolve, reject) => {
    const sql = `SELECT cloudfilereceivedpath, localfilereceivedpath FROM public.wms_mst_customerconfigdetails WHERE customerid = ${payload.customerid} AND duid = ${payload.duid}`;
    const result = await query(sql);
    payload.localworkingfolder = payload.__WF__ || ';localworkingfolder;';
    // payload.bookcode = payload.BookCode;
    // payload.filename = payload.BookCode;
    // payload.foldername = payload.BookCode;
    // payload.stagecode = payload?.stage?.name;
    // payload.activitycode = payload?.activity?.name;
    const serverPath =
      payload.dmsType === 'local'
        ? result[0]?.cloudfilereceivedpath
        : result[0]?.localfilereceivedpath;
    const newBasePath = await replacePlaceholders(serverPath, payload);
    resolve(newBasePath);
  });
};

export const extractFileConfig = async (req, res) => {
  try {
    const { fileconfig, placeHolders } = req.body;
    const extractedFiles = await getConvertedPath(fileconfig, placeHolders);
    res.status(200).send(extractedFiles);
  } catch (error) {
    res.status(400).send(error);
  }
};

export const getS3UploadDetails = async (req, res) => {
  const { workOrderId, logHistoryPayload } = req.body;
  try {
    const s3Config = await getsftpConfig('s3_upload');

    const sql = `select  otherfield->>'pii' as pii  from wms_workorder where workorderid = ${workOrderId}`;
    const data = await query(sql);

    if (data && data.length > 0 && data?.[0]?.pii) {
      let pii = data[0].pii.replace(/[-()]/g, '');
      const signalAuditInfo = await getSignalAuidtInfo(pii);
      const { signalauditid: signalAuditId, signalinfo: ackMsgInfo } =
        signalAuditInfo;
      console.log(signalAuditId, 'signalAuditId');

      if (signalAuditId) {
        const logHisPayload = {
          signalAuditId,
          ...logHistoryPayload,
        };
        await ialtSignalLogHistory(logHisPayload);
      }
    }
    res.status(200).send({ status: true, data: s3Config });
  } catch (error) {
    res.status(400).send(error);
  }
};

export const uploadS3Payload = async (req, res) => {
  const { workOrderId, payloadData } = req.body;
  try {
    let logHistoryPayload = {
      request: '',
      response: '',
      message: '',
      status: '',
      processStatusId: 0,
    };
    let signalAuditId = '';
    const s3Config = await getsftpConfig('s3_upload');

    const sql = `select  otherfield->>'pii' as pii  from wms_workorder where workorderid = ${workOrderId}`;
    const data = await query(sql);

    if (data && data.length > 0 && data?.[0]?.pii) {
      let pii = data[0].pii.replace(/[-()]/g, '');
      const signalAuditInfo = await getSignalAuidtInfo(pii);
      const { signalauditid, signalinfo: ackMsgInfo } = signalAuditInfo;
      signalAuditId = signalauditid;

      console.log(signalAuditId, 'signalAuditId');
    }
    if (signalAuditId) {
      //Audit entry
      logHistoryPayload.request = payloadData;
      logHistoryPayload.response = 'Payload upload process started';
      logHistoryPayload.message = 'Payload upload process started';
      logHistoryPayload.status = 'Started';
      logHistoryPayload.processStatusId = 1;
      if (signalAuditId) {
        const logHisPayload = {
          signalAuditId,
          ...logHistoryPayload,
        };
        await ialtSignalLogHistory(logHisPayload);
      }
    }
    const dbusername = s3Config?.userName;
    const dbpassword = s3Config?.password;
    // Need upload payload here
    const url = `${config.iAlt.else_vier.base_url}/${config.iAlt.else_vier.uri.upload}`;
    const result = await service.ialtPost(
      url,
      payloadData,
      {},
      dbusername,
      dbpassword,
    );

    if (signalAuditId) {
      //Audit entry
      logHistoryPayload.request = payloadData;
      logHistoryPayload.response = 'Payload upload process completed';
      logHistoryPayload.message = 'Payload upload process completed';
      logHistoryPayload.status = 'Completed';
      logHistoryPayload.processStatusId = 4;
      if (signalAuditId) {
        const logHisPayload = {
          signalAuditId,
          ...logHistoryPayload,
        };
        await ialtSignalLogHistory(logHisPayload);
      }
    }

    res.status(200).send({ status: true, data: 'Payload process completed' });
  } catch (error) {
    res.status(400).send(error);
  }
};

export const engineFileCopy = async (req, res) => {
  try {
    const payload = req.body;
    await _engineFileCopy(payload);
    res
      .status(200)
      .send({ status: true, message: 'Engine file copied successfully' });
  } catch (error) {
    res.status(400).json(error);
  }
};

export const _engineFileCopy = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        wfId,
        nextActivityId,
        stageId,
        fileTypeId,
        wfeventId,
        activityId,
        workorderId,
      } = payload;

      const isDownload = true;

      const sql = `
        SELECT stage.stagename, activity.activityname AS nextactivityname,fileconfig,config
        FROM wms_workflowdefinition AS wf
        JOIN wms_mst_stage AS stage ON wf.stageid = stage.stageid
        JOIN wms_mst_activity AS activity ON wf.activityid = activity.activityid
        WHERE wfid = ${wfId} AND wf.activityid = ${activityId}
        AND wf.stageid = ${stageId} AND lock = false 
        ORDER BY sequence LIMIT 1`;

      const data = await query(sql);

      let fileConfig = data?.[0]?.fileconfig?.files.filter(file =>
        (file.fileTypes || []).includes(parseInt(fileTypeId)),
      );

      if (!fileConfig) {
        return resolve(
          'Engine file configuration missing. Please contact the IWMS administrator.',
        );
      }

      // Get placeHolders and add next activity code
      const placeHolders = await getWorkflowPlaceHolders(wfeventId);
      placeHolders.nextactivitycode = data?.[0]?.nextactivityname;

      // Filter files based on flow type and lock status
      const filterFilesByFlowType = flowType =>
        fileConfig.filter(
          file =>
            (file.fileFlowType || [])
              .map(x => x.toLowerCase())
              .includes(flowType) && !file.isLock,
        );

      const getLatestFolderFiles = async folderInput => {
        let filteredFolderFiles = [];
        for (const file of folderInput) {
          if (file.copydetail.length > 1) {
            const latestIndex = await _getLatestStgActy({
              wfId,
              workorderId,
              stgActyInfo: file.copydetail,
            });
            //To handle false value
            if (latestIndex >= 0) {
              file.name = file.copyPaths[latestIndex].sourcepath;
              file.copydetail = [file.copydetail[latestIndex]];
              file.copyPaths = [file.copyPaths[latestIndex]];
            }
            filteredFolderFiles.push(file);
          } else {
            filteredFolderFiles.push(file);
          }
        }
        return filteredFolderFiles;
      };

      const actualFiles = isDownload
        ? filterFilesByFlowType('in')
        : filterFilesByFlowType('out');

      if (actualFiles.length === 0) {
        return resolve('No files available for processing.');
      }
      const convertedFiles = await getConvertedPath(actualFiles, placeHolders);
      const extractedFiles = await getLatestFolderFiles(convertedFiles);

      if (extractedFiles.length > 0) {
        const validateFiles = await mandatoryInFileCheck(
          extractedFiles,
          'local',
        );
        const missedFiles = validateFiles?.data.filter(
          file => !file.isexists && file.mandatoryCheck?.save,
        );

        if (missedFiles.length > 0) {
          const missingFilesMessage = missedFiles
            .map(file => basename(file.name) || 'Unknown Name')
            .join(', ');
          return resolve(
            `Following mandatory files are missing in storage. Please contact IWMS administrator:\n ${missingFilesMessage}`,
          );
        }

        const copyFiles = validateFiles?.data.filter(
          file =>
            file.isexists &&
            !file.outfileName?.includes(';localworkingfolder;'),
        );

        let bookDetails = extractedFiles.find(
          file => file.custom == 'generate_bookdetails',
        );
        let figuresTxt = extractedFiles.find(
          file => file.custom == 'generate_graphicstext',
        );
        if (figuresTxt) {
          let filePath = figuresTxt.customFilePath;
          if (!filePath) {
            payload.isServerPath = [];
            payload.customerid = placeHolders.customerid;
            payload.duid = placeHolders.duid;
            const newFile = await _getFormattedGraphicPath(
              payload,
              placeHolders,
              'figure',
            );
            const tempFilePath = `uploads/figuretxt_${uuidv4()}.txt`;
            await writeSmallFile(tempFilePath, newFile, `uploads/`);

            switch (payload.dmsType) {
              case 'azure':
                await azureHelper._upload(
                  {
                    name: '',
                    tempFilePath,
                  },
                  figuresTxt.outfileName,
                );
                break;
              case 'local':
                await localHelper._uploadlocal(
                  {
                    name: '',
                    tempFilePath,
                  },
                  figuresTxt.outfileName,
                );
                break;
              default:
                throw new Error('Invalid DMS type.');
            }
            unlink(tempFilePath);
          }
        }
        if (bookDetails) {
          payload.ext = extname(bookDetails.name);
          payload.fileDetails = {};
          payload.fileDetails.path = bookDetails.outfileName;
          let bookDetailsContent = await getBookDetailsTemplateElse(payload);
          console.log(bookDetailsContent);
        }
        // Use Promise.all to execute file copy operations in parallel
        await Promise.all(
          copyFiles.map(file => {
            const srcPath = file.name;
            const destBasePath = file.isFile
              ? dirname(file.outfileName) + '/'
              : file.outfileName;
            const name = basename(file.outfileName);
            if (file.name != file.outfileName) {
              return file.isFile
                ? _localcopyFileWithoutFormData({ srcPath, name, destBasePath })
                : _localFolderCopy({ srcPath, destBasePath });
            } else {
              return '';
            }
          }),
        );
        payload.placeHolders = placeHolders;
        resolve('File copied successfully!');
      } else {
        resolve('No files extracted for processing.');
      }
    } catch (error) {
      resolve(error);
    }
  });
};

export const insertTrnFiles = async (req, res) => {
  try {
    const { type, files, wfeventId } = req.body;

    if (!Array.isArray(files) || files.length === 0) {
      return res
        .status(400)
        .send({ issuccess: false, message: 'No files provided.' });
    }

    await transaction(async client => {
      if (type === 'insert_new_file') {
        await bulkInsertFileTRNLog(files, wfeventId, client);
      } else {
        await bulkUpdateFileTRNMap(files, client);
      }
    });

    res
      .status(200)
      .send({ issuccess: true, message: 'Payload process compeleted!' });
  } catch (error) {
    console.error('Error in insertTrnFiles:', error);
    res
      .status(500)
      .send({ issuccess: false, message: 'Internal server error' });
  }
};

export const bulkInsertFileTRNLog = (fileTrnData, wfeventId, client) => {
  return new Promise((resolve, reject) => {
    const values = [];
    fileTrnData.forEach(fileTrn => {
      const { path, uuid, fileId } = fileTrn;
      values.push(
        `(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`,
      );
    });
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES ${values};`;
    console.log(sql, 'sql for insert');
    if (client) {
      client
        .query(sql)
        .then(() => {
          resolve();
        })
        .catch(e => {
          reject(e);
        });
    } else {
      query(sql)
        .then(() => resolve())
        .catch(e => reject(e));
    }
  });
};

export const bulkUpdateFileTRNMap = (fileTrnData, client) => {
  return new Promise((resolve, reject) => {
    if (!fileTrnData || fileTrnData.length === 0) return resolve();

    const updates = fileTrnData.map(
      ({ actFileMapId }) => `(${actFileMapId}, false)`,
    );
    const sql = `
      UPDATE wms_workflowactivitytrn_file_map AS original
      SET ischeckedout = update_values.ischeckedout
      FROM (VALUES ${updates.join(
        ', ',
      )}) AS update_values (actfilemapid, ischeckedout)
      WHERE original.actfilemapid = update_values.actfilemapid;
    `;
    console.log(sql, 'sql for update trn');

    client
      .query(sql)
      .then(() => resolve())
      .catch(e => reject(e));
  });
};
