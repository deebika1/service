import { emitEvent } from '../../socket/index.js';

export const updateStatus = (req, res) => {
  const { sid, data, status } = req.body;
  try {
    emitEvent(sid, 'okmStatus', { data, status });
    res.send();
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
