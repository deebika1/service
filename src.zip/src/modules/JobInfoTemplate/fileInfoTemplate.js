export const FileInfoTemplate = {
  ul: `{{li}}`,
  li: `<FileInfo>
    <fileName>{{fileName}}</fileName>
    <ChapterType>{{chapterType}}</ChapterType>
    <ChapterNumber>{{chapterNumber}}</ChapterNumber>
    <SequenceID>{{sequenceNumber}}</SequenceID>
    </FileInfo>
    `,
};
