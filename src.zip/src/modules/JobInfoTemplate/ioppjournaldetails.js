export const ioppJournalDetails = {
  ul: `{{li}}`,
  li: `
<DocumentElement>
<BookDetails>
<Title>{{jobname}}</Title>
<IseOnlyNeeded>{{journaltype}}</IseOnlyNeeded>
<FinalPitstopProfile>{{profilepath}}</FinalPitstopProfile>
<JounalCode>{{journalacronym}}</JounalCode>
<TemplateVersion>V1</TemplateVersion>
<Format>{{templateformat}}</Format>
<TextColumn>{{textcolumnid}}</TextColumn>
<Issue>No</Issue>
<Internal_x0020_iAuthor>{{isiauthor}}</Internal_x0020_iAuthor>
<Stage>{{stagename}}</Stage>
<Activity>{{activityname}}</Activity>
</BookDetails>
</DocumentElement>
`,
};
