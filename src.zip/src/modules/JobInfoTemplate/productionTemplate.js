export const ProductionTemplates = {
  ul: `{{li}}`,
  li: `
<WMSID>{{wmsid}}</WMSID>
<BookId>{{bookid}}</BookId>
<Country>{{countryid}}</Country>
<BookName>{{jobname}}</BookName>
<FileID>{{woincomingfileid}}</FileID>
<FileName>{{filename}}</FileName>
<VolumeId>{{volumeid}}</VolumeId>
<VolumeName/>
<StageID>{{stageid}}</StageID>
<StageName>{{stagename}}</StageName>
<ActivityId>{{activityid}}</ActivityId>
<ActivityName>{{activityname}}</ActivityName>
<BatchId>None</BatchId>
<iTracksStageid>{{itrackstageid}}</iTracksStageid>
<Jobcardid>{{jobcardid}}</Jobcardid>
<SubJobcardid/>
<TemplateName>{{templatename}}</TemplateName>
<Sessionid>{{folderid}}</Sessionid>
<Templateid>{{templateid}}</Templateid>
<WorkingPath>{{workingpath}}</WorkingPath>
<ISnum>{{userid}}</ISnum>
<Category>{{category}}</Category>  
`,
  oup: `<?xml version="1.0" standalone="yes"?>
<DocumentElement>
<BookDetails>
<JournalCode>{{JournalAcronym}}</JournalCode>
<FinalPitstopProfile>{{onlineprofile}}</FinalPitstopProfile>
<TemplateVersion>V1</TemplateVersion>
<AccessModel>Model {{modeltype}}</AccessModel>
<ColourModel>{{journaltype}}</ColourModel>
<IsCERequired>{{ceValue}}</IsCERequired>
<StageID>{{stageid}}</StageID>
<Stage>{{stagename}}</Stage>
<ActivityId>{{activityid}}</ActivityId>
<Activity>{{activityname}}</Activity>
<IssueBased>{{isCP}}</IssueBased>
</BookDetails>
</DocumentElement>`,
};
