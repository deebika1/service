import { templates } from './template.js';
import { ProductionTemplates } from './productionTemplate.js';
import { JobInfoTemplates } from './jobInfoTemplate.js';
import { FileInfoTemplate } from './fileInfoTemplate.js';

export const jobInfoXmlCreate = req => {
  const { prodcutionList, jobInfoList, fileInfoList } = req.body;
  try {
    const prodOut = [];
    const jobInfoOut = [];
    const fileInfoOut = [];
    let finalTemplate = [];
    for (let i = 0; i < prodcutionList.length; i++) {
      const {
        wmsid,
        bookid,
        countryid,
        jobname,
        woincomingfileid,
        filename,
        stageid,
        stagename,
        activityid,
        activityname,
        itrackstageid,
        jobcardid,
        templatename,
        folderid,
        templateid,
        workingpath,
        userid,
        category,
      } = prodcutionList[i];
      prodOut.push(
        ProductionTemplates.li
          .replace(/{{wmsid}}/, wmsid)
          .replace(/{{bookid}}/, bookid)
          .replace(/{{countryid}}/, countryid)
          .replace(/{{jobname}}/, jobname)
          .replace(/{{woincomingfileid}}/, woincomingfileid)
          .replace(/{{filename}}/, filename)
          .replace(/{{stageid}}/, stageid)
          .replace(/{{stagename}}/, stagename)
          .replace(/{{activityid}}/, activityid)
          .replace(/{{activityname}}/, activityname)
          .replace(/{{itrackstageid}}/, itrackstageid)
          .replace(/{{jobcardid}}/, jobcardid)
          .replace(/{{templatename}}/, templatename)
          .replace(/{{folderid}}/, folderid)
          .replace(/{{templateid}}/, templateid)
          .replace(/{{workingpath}}/, workingpath)
          .replace(/{{userid}}/, userid)
          .replace(/{{category}}/, category),
      );
    }
    const a = ProductionTemplates.ul.replace(/{{li}}/, prodOut.join('\n'));
    const b = templates.ProductionInfo.replace(/{{ProductionTemplates}}/, a);

    for (let j = 0; j < jobInfoList.length; j++) {
      const { fieldName, value } = jobInfoList[j];
      jobInfoOut.push(
        JobInfoTemplates.li
          .replace(/{{fieldName}}/, fieldName)
          .replace(/{{value}}/, value),
      );
    }
    const c = templates.JobInfo.replace(
      /{{JobInfoTemplate}}/,
      jobInfoOut.join('\n'),
    );

    for (let k = 0; k < fileInfoList.length; k++) {
      const { fileName, chapterType, chapterNumber, sequenceNumber } =
        fileInfoList[k];
      fileInfoOut.push(
        FileInfoTemplate.li
          .replace(/{{fileName}}/, fileName)
          .replace(/{{chapterType}}/, chapterType)
          .replace(/{{chapterNumber}}/, chapterNumber)
          .replace(/{{sequenceNumber}}/, sequenceNumber),
      );
    }
    const d = templates.FileInfo.replace(
      /{{FileInfotTemplate}}/,
      fileInfoOut.join('\n'),
    );

    finalTemplate = templates.xml + b + c + d;
    Promise.resolve(finalTemplate);
  } catch (e) {
    console.log(e, 'error in job info xml');
  }
};
