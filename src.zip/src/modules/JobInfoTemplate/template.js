export const templates = {
  xml: `<?xml version="1.0" standalone="yes"?>
    <MetaInfo>
    <xs:schema xmlns:msdata="urn:schemas-microsoft-com:xml-msdata" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="" id="MetaInfo">
    <xs:element msdata:UseCurrentLocale="true" msdata:IsDataSet="true" name="MetaInfo">
    <xs:complexType>
    <xs:choice maxOccurs="unbounded" minOccurs="0">
    <xs:element name="ProductionInfo">
    <xs:complexType>
    <xs:sequence>
    <xs:element name="WMSID" minOccurs="0" type="xs:string"/>
    <xs:element name="BookId" minOccurs="0" type="xs:string"/>
    <xs:element name="Country" minOccurs="0" type="xs:string"/>
    <xs:element name="BookName" minOccurs="0" type="xs:string"/>
    <xs:element name="FileID" minOccurs="0" type="xs:string"/>
    <xs:element name="FileName" minOccurs="0" type="xs:string"/>
    <xs:element name="VolumeId" minOccurs="0" type="xs:string"/>
    <xs:element name="VolumeName" minOccurs="0" type="xs:string"/>
    <xs:element name="StageID" minOccurs="0" type="xs:string"/>
    <xs:element name="StageName" minOccurs="0" type="xs:string"/>
    <xs:element name="ActivityId" minOccurs="0" type="xs:string"/>
    <xs:element name="ActivityName" minOccurs="0" type="xs:string"/>
    <xs:element name="BatchId" minOccurs="0" type="xs:string"/>
    <xs:element name="iTracksStageid" minOccurs="0" type="xs:string"/>
    <xs:element name="Jobcardid" minOccurs="0" type="xs:string"/>
    <xs:element name="SubJobcardid" minOccurs="0" type="xs:string"/>
    <xs:element name="TemplateName" minOccurs="0" type="xs:string"/>
    <xs:element name="Sessionid" minOccurs="0" type="xs:string"/>
    <xs:element name="SessionPath" minOccurs="0" type="xs:string"/>
    <xs:element name="Templateid" minOccurs="0" type="xs:string"/>
    <xs:element name="WorkingPath" minOccurs="0" type="xs:string"/>
    <xs:element name="ISnum" minOccurs="0" type="xs:string"/>
    <xs:element name="Category" minOccurs="0" type="xs:string"/>
    </xs:sequence>
    </xs:complexType>
    </xs:element>
    <xs:element name="JobInfo">
    <xs:complexType>
    <xs:sequence>
    <xs:element name="FieldName" minOccurs="0" type="xs:string"/>
    <xs:element name="Value" minOccurs="0" type="xs:string"/>
    </xs:sequence>
    </xs:complexType>
    </xs:element>
    <xs:element name="FileInfo">
    <xs:complexType>
    <xs:sequence>
    <xs:element name="fileName" minOccurs="0" type="xs:string"/>
    <xs:element name="ChapterType" minOccurs="0" type="xs:string"/>
    <xs:element name="ChapterNumber" minOccurs="0" type="xs:short"/>
    <xs:element name="SequenceID" minOccurs="0" type="xs:short"/>
    </xs:sequence>
    </xs:complexType>
    </xs:element>
    </xs:choice>
    </xs:complexType>
    </xs:element>
    </xs:schema>
    `,
  ProductionInfo: `<ProductionInfo>{{ProductionTemplates}}</ProductionInfo>
    `,
  JobInfo: `{{JobInfoTemplate}}
    `,
  FileInfo: `{{FileInfotTemplate}}</MetaInfo>`,
};
