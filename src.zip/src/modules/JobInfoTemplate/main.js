import { writeFileSync } from 'fs';
import { templates } from './template.js';
import { ProductionTemplates } from './productionTemplate.js';
import { JobInfoTemplates } from './jobInfoTemplate.js';
import { FileInfoTemplate } from './fileInfoTemplate.js';

// for test purpose this file was created
function generateList(prodcutionList, jobInfoList, fileInfoList) {
  const prodOut = [];
  const jobInfoOut = [];
  const fileInfoOut = [];
  let finalTemplate = [];
  for (let i = 0; i < prodcutionList.length; i++) {
    const {
      wmsid,
      bookid,
      countryid,
      jobname,
      woincomingfileid,
      filename,
      stageid,
      stagename,
      activityid,
      activityname,
      itrackstageid,
      jobcardid,
      templatename,
      folderid,
      templateid,
      workingpath,
      userid,
      category,
    } = prodcutionList[i];
    prodOut.push(
      ProductionTemplates.li
        .replace(/{{wmsid}}/, wmsid)
        .replace(/{{bookid}}/, bookid)
        .replace(/{{countryid}}/, countryid)
        .replace(/{{jobname}}/, jobname)
        .replace(/{{woincomingfileid}}/, woincomingfileid)
        .replace(/{{filename}}/, filename)
        .replace(/{{stageid}}/, stageid)
        .replace(/{{stagename}}/, stagename)
        .replace(/{{activityid}}/, activityid)
        .replace(/{{activityname}}/, activityname)
        .replace(/{{itrackstageid}}/, itrackstageid)
        .replace(/{{jobcardid}}/, jobcardid)
        .replace(/{{templatename}}/, templatename)
        .replace(/{{folderid}}/, folderid)
        .replace(/{{templateid}}/, templateid)
        .replace(/{{workingpath}}/, workingpath)
        .replace(/{{userid}}/, userid)
        .replace(/{{category}}/, category),
    );
  }
  const a = ProductionTemplates.ul.replace(/{{li}}/, prodOut.join('\n'));
  const b = templates.ProductionInfo.replace(/{{ProductionTemplates}}/, a);

  for (let j = 0; j < jobInfoList.length; j++) {
    const { fieldName, value } = jobInfoList[j];
    jobInfoOut.push(
      JobInfoTemplates.li
        .replace(/{{fieldName}}/, fieldName)
        .replace(/{{value}}/, value),
    );
  }
  const c = templates.JobInfo.replace(
    /{{JobInfoTemplate}}/,
    jobInfoOut.join('\n'),
  );

  for (let k = 0; k < fileInfoList.length; k++) {
    const { fileName, chapterType, chapterNumber, sequenceNumber } =
      fileInfoList[k];
    fileInfoOut.push(
      FileInfoTemplate.li
        .replace(/{{fileName}}/, fileName)
        .replace(/{{chapterType}}/, chapterType)
        .replace(/{{chapterNumber}}/, chapterNumber)
        .replace(/{{sequenceNumber}}/, sequenceNumber),
    );
  }
  const d = templates.FileInfo.replace(
    /{{FileInfotTemplate}}/,
    fileInfoOut.join('\n'),
  );

  finalTemplate = templates.xml + b + c + d;
  return finalTemplate;
}

const prodcutionList = [
  {
    wmsid: '26',
    bookid: '26791',
    countryid: 'UK',
    jobname: 'Mumford-ELE-OPM',
    woincomingfileid: '990484',
    filename: '9781108811705c01',
    stageid: '38',
    stagename: 'Typescript',
    activityid: '4405',
    activityname: 'Pre-Editing',
    itrackstageid: '38',
    jobcardid: '1030720',
    templatename: '55',
    folderid: '39912191',
    templateid: '33',
    workingpath: 'C:\\iTools\\WMS\\CUP-New\\39912191\\WorkingFolder',
    userid: 'IS8223',
    category: 'Project Management',
  },
];

const jobInfoList = [
  { fieldName: 'Customer Name', value: 'UK' },
  { fieldName: 'DTD', value: 'BITS' },
  { fieldName: 'ISBN', value: '9781108811705' },
  { fieldName: 'JobTitle', value: 'Leading for Innovation' },
  { fieldName: 'OutFilePath', value: '9781108811705Book.docx' },
  { fieldName: 'software', value: '3B2' },
  { fieldName: 'Verso Format', value: 'ChapterTitle' },
];

const fileInfoList = [
  {
    fileName: '9781108811705pre',
    chapterType: 'Prelims',
    chapterNumber: '1',
    sequenceNumber: '1',
  },
  {
    fileName: '9781108811705c01',
    chapterType: 'Chapter',
    chapterNumber: '2',
    sequenceNumber: '2',
  },
  {
    fileName: '9781108811705rfa',
    chapterType: 'Chapter',
    chapterNumber: '3',
    sequenceNumber: '3',
  },
  {
    fileName: '9781108811705ack',
    chapterType: 'Chapter',
    chapterNumber: '4',
    sequenceNumber: '4',
  },
];

const ul = generateList(prodcutionList, jobInfoList, fileInfoList);

writeFileSync('./data/a.xml', ul, { encoding: 'utf-8' });
