import { basename, extname, dirname } from 'path';
import micromatch from 'micromatch';
import globParent from 'glob-parent';
import isGlob from 'is-glob';
import { getFormattedName } from './utils.js';
import { _getConitionalTags } from '../../task/fileDetails.js';

export const ReStructureFileConfig = fileConfig => {
  let newFileConfig = {};
  newFileConfig = { ...fileConfig };
  delete newFileConfig.files;
  newFileConfig.fileTypes = {};
  if (fileConfig && fileConfig.files) {
    let fileTypes = [];
    fileConfig.files.forEach(x => {
      fileTypes = [...new Set([...fileTypes, ...(x.fileTypes || [])])];
    });
    fileTypes.forEach(x => {
      newFileConfig.fileTypes[x] = {};
      newFileConfig.fileTypes[x].files = fileConfig.files.filter(
        y => (y.fileTypes || []).includes(x) && y.isactive != false,
      );
    });
  } else {
    newFileConfig = fileConfig;
  }
  return newFileConfig;
};

const actions = {
  save: 'save',
  reject: 'reject',
  pending: 'pending',
  hold: 'hold',
  isCompulsoryCheck: 'isCompulsoryCheck',
};

export const getFileValidationStatus = async (
  validationFileConfig,
  filesInfo,
  placeHolders,
  eventData,
  mandatorySaveFile,
  workOrderId,
) => {
  const response = {
    backupFiles: [],
    missedFiles: [],
    requiredFiles: [],
    readOnlyFiles: [],
    overwriteFiles: [],
    globPatternFiles: [],
    extractedFiles: [],
    newFileCopyBasePath: '',
    lwfFiles: [],
    UOMFile: {},
    validationFileConfig,
    eventData,
  };
  console.log(workOrderId, 'workOrderId');
  const validationConfigKeys = Object.keys(validationFileConfig);
  for (let i = 0; i < validationConfigKeys.length; i++) {
    console.log(
      validationFileConfig[validationConfigKeys[i]],
      'validationFileConfig[validationConfigKeys[i]]',
    );
    let validationFiles =
      validationFileConfig[validationConfigKeys[i]] &&
      validationFileConfig[validationConfigKeys[i]].files
        ? validationFileConfig[validationConfigKeys[i]].files
        : [];
    // const checkOnExist = !!(
    //   validationFileConfig[validationConfigKeys[i]] &&
    //   !!validationFileConfig[validationConfigKeys[i]].checkOnExist
    // );
    const fileSet = filesInfo.filter(
      file => file.typeId == validationConfigKeys[i],
    );
    const fileConfig = await _getConitionalTags(
      validationFiles,
      workOrderId,
      placeHolders,
    );
    if (fileConfig.message) {
      validationFiles = fileConfig.data;
    }
    if (fileSet.length) {
      // if (!(!fileSet.length && checkOnExist)) {
      validationFiles = validationFiles.filter(it => it.isactive != 'false');
      for (let j = 0; j < validationFiles.length; j++) {
        console.log(validationFiles[j], 'validationFiles[j]');
        let { name } = validationFiles[j];
        const {
          mandatoryCheck,
          fileFlowType,
          overwrite,
          isUOM,
          softwareOpen,
          newName,
          backup,
          custom,
          conditionalTags,
          skippapFiles,
        } = validationFiles[j];
        const isReadOnly =
          (fileFlowType || []).length == 1 &&
          (fileFlowType || []).filter(x => x.toUpperCase() == 'IN').length > 0;
        const isRoman =
          (custom || []).length > 0 &&
          (custom || []).filter(x => x.toUpperCase() === 'ISROMAN').length > 0;
        name = name ? (name[0] == '/' ? name.substring(1) : name) : '*';
        const isMandatory = mandatoryCheck
          ? !!mandatoryCheck[actions.save] ||
            !!mandatoryCheck[actions.reject] ||
            !!mandatoryCheck[actions.pending]
          : false;
        const isOptional = !!mandatoryCheck && !isMandatory;
        // const outConditionalPath1 = outConditionalPath || '';
        const newName1 = newName || '';
        const romanRequried = isRoman || false;
        // const lwfDetails =
        //   lwf && lwf.src
        //     ? {
        //         src: lwf.src,
        //         isRoot: !!lwf.isRoot,
        //       }
        //     : { src: '', isRoot: false };
        const isSoftwareOpen = !!softwareOpen;
        // const isInputFile = !!(isMandatory && mandatoryCheck.isInputFile);
        const isIO = !!(
          (fileFlowType || []).length == 2 ||
          (fileFlowType || []).filter(x => x.toUpperCase() == 'IN').length > 0
        );
        const isInputFile = isIO;
        const mandatoryCheckActions = mandatoryCheck;
        const conditional = conditionalTags != undefined ? conditionalTags : '';
        console.log(conditional);
        const skippapafilesforWKH =
          skippapFiles != undefined ? skippapFiles : '';
        console.log('skippapafilesforWKH', skippapafilesforWKH);
        // ? {
        //     // save:  'isCompulsoryCheck' in mandatoryCheck  ? mandatorySaveFile && Object.keys(mandatorySaveFile).length > 0 && 'isCompulsoryCheck' in mandatoryCheck && mandatorySaveFile[mandatoryCheck[actions.isCompulsoryCheck]] && Object.keys(mandatorySaveFile[mandatoryCheck[actions.isCompulsoryCheck]]).length >0 && mandatorySaveFile[mandatoryCheck[actions.isCompulsoryCheck]].value ? true : !mandatoryCheck[actions.save] : !!mandatoryCheck[actions.save],
        //     save:
        //       'isCompulsoryCheck' in mandatoryCheck
        //         ? mandatorySaveFile &&
        //           Object.keys(mandatorySaveFile).length > 0 &&
        //           Object.keys(mandatorySaveFile).includes(
        //             mandatoryCheck[actions.isCompulsoryCheck],
        //           ) &&
        //           mandatorySaveFile[
        //             mandatoryCheck[actions.isCompulsoryCheck]
        //           ] &&
        //           mandatorySaveFile[mandatoryCheck[actions.isCompulsoryCheck]]
        //             .value
        //           ? true
        //           : !mandatoryCheck[actions.save]
        //         : !!mandatoryCheck[actions.save],
        //     reject: !!mandatoryCheck[actions.reject],
        //     pending: !!mandatoryCheck[actions.pending],
        //     hold: !!mandatoryCheck[actions.pending],
        //   }
        // : {};
        for (let k = 0; k < fileSet.length; k++) {
          const { files, key, name: fileTypeName, basePath } = fileSet[k];
          const springerZipFileName =
            files.length > 0 ? files[0].newfilename : '';
          let { placeHolders: fileSetPlaceHolders } = fileSet[k];
          fileSetPlaceHolders = fileSetPlaceHolders || {};
          placeHolders.zipFileName = springerZipFileName;
          placeHolders.articletype = (
            (placeHolders.ArticleTypeList || [])
              .filter(x => x.FileTypeName == fileTypeName)
              .pop() || {}
          ).articletype;
          // let piivalue = await _getFileNameForPii(workOrderId, fileTypeName);
          const piivalue = (
            (placeHolders.ArticleTypeList || [])
              .filter(x => x.FileTypeName == fileTypeName)
              .pop() || {}
          ).piinumber;
          const PiiPlaceHolders = { IssuePII: piivalue };
          const combinedPlaceHolders = {
            ...placeHolders,
            ...fileSetPlaceHolders,
            ...PiiPlaceHolders,
          };
          const outfileName =
            validationFiles[j].outfileName &&
            validationFiles[j].outfileName.length > 0
              ? validationFiles[j].outfileName
              : '';
          const formattedName = getFormattedName(name, combinedPlaceHolders);
          const formattedOutName = getFormattedName(
            outfileName,
            combinedPlaceHolders,
          );
          // const formattedLWFSrcName = getFormattedName(
          //   lwfDetails.src,
          //   combinedPlaceHolders,
          // );
          let isValidFile = false;
          let isValid = false;
          for (let l = 0; l < files.length; l++) {
            const { path, uuid } = files[l];
            isValidFile = micromatch.isMatch(path, basePath + formattedName);
            if (isValidFile) {
              if (!isValid) isValid = true;
              response.lwfFiles.push({
                key,
                path,
                name: formattedName,
                outfileName: formattedOutName,
                // src: formattedLWFSrcName,
                // isRoot: lwfDetails.isRoot,
                isSoftwareOpen,
                newName: newName1,
                isRoman: romanRequried,
                isInputFile,
              });
              if (isReadOnly) response.readOnlyFiles.push({ key, path });
              if (overwrite) response.overwriteFiles.push({ key, path });
              if (!!isUOM && Object.keys(response.UOMFile).length == 0)
                response.UOMFile = {
                  key,
                  path,
                  name: formattedName,
                  outfileName: formattedOutName,
                  uuid,
                  newName: newName1,
                  isRoman: romanRequried,
                  isInputFile,
                };
            }
            if (romanRequried) {
              response.lwfFiles.push({
                key,
                path,
                name: formattedName,
                outfileName: formattedOutName,
                // src: formattedLWFSrcName,
                // isRoot: lwfDetails.isRoot,
                isSoftwareOpen,
                newName: newName1,
                isRoman: romanRequried,
                isInputFile,
              });
            }
          }

          if (isMandatory || isOptional) {
            if (!isValid)
              response.missedFiles.push({
                key,
                name: formattedName,
                outfileName: formattedOutName,
                typeId: validationConfigKeys[i],
                isMandatory,
                isOptional,
                actions: mandatoryCheckActions,
                // lwfDetails: {
                //   name: formattedName,
                //   src: formattedLWFSrcName,
                //   isRoot: lwfDetails.isRoot,
                // },
                isSoftwareOpen,
                // outConditionalPath: outConditionalPath1,
                newName: newName1,
                isRoman: romanRequried,
                isInputFile,
                conditionalTags: conditional,
                skippapFiles: skippapafilesforWKH,
              });
            if (!!isUOM && Object.keys(response.UOMFile).length == 0)
              response.UOMFile = {
                key,
                name: formattedName,
                typeId: validationConfigKeys[i],
              };
            if (isGlob(formattedName))
              response.globPatternFiles.push({
                key,
                typeId: validationConfigKeys[i],
                name: formattedName,
                outfileName: formattedOutName,
                isMandatory,
                isOptional,
                isSoftwareOpen,
                // outConditionalPath: outConditionalPath1,
                newName: newName1,
                isRoman: romanRequried,
                isInputFile,
              });
            response.requiredFiles.push({
              key,
              typeId: validationConfigKeys[i],
              typeName: fileTypeName,
              name: formattedName,
              outfileName: formattedOutName,
              isMandatory,
              isOptional,
              actions: mandatoryCheckActions,
              // lwfDetails: {
              //   name: formattedName,
              //   src: formattedLWFSrcName,
              //   isRoot: lwfDetails.isRoot,
              // },
              isSoftwareOpen,
              // outConditionalPath: outConditionalPath1,
              newName: newName1,
              isRoman: romanRequried,
              isInputFile,
              skippapFiles: skippapafilesforWKH,
            });
          }
          if (backup && backup.enable) {
            response.backupFiles.push({ filename: formattedName, ...backup });
          }
        }
        if (!fileSet.length && (isMandatory || isOptional)) {
          if (!!isUOM && Object.keys(response.UOMFile).length == 0)
            response.UOMFile = {
              name: getFormattedName(name, placeHolders),
              typeId: validationConfigKeys[i],
            };
          response.missedFiles.push({
            typeId: validationConfigKeys[i],
            name: getFormattedName(name, placeHolders),
            isMandatory,
            isOptional,
            actions: mandatoryCheckActions,
            isSoftwareOpen,
            // outConditionalPath: outConditionalPath1,
            newName: newName1,
            isRoman: romanRequried,
            isInputFile,
            skippapFiles: skippapafilesforWKH,
          });
          response.requiredFiles.push({
            typeId: validationConfigKeys[i],
            name: getFormattedName(name, placeHolders),
            isMandatory,
            isOptional,
            actions: mandatoryCheckActions,
            // lwfDetails: {
            //   name: getFormattedName(name, placeHolders),
            //   src: getFormattedName(lwfDetails.src, placeHolders),
            //   isRoot: lwfDetails.isRoot,
            // },
            isSoftwareOpen,
            // outConditionalPath: outConditionalPath1,
            newName: newName1,
            isRoman: romanRequried,
            isInputFile,
            skippapFiles: skippapafilesforWKH,
          });
        }
      }
      validationFiles.forEach(list => {
        if (
          list.mandatoryCheck &&
          list.mandatoryCheck.isCompulsoryCheck &&
          list.mandatoryCheck.isCompulsoryCheck.includes(
            list.mandatoryCheck.checkCompulsorykey,
          )
        ) {
          // const camVariable = list.mandatoryCheck.checkCompulsorykey;
          const fileTypename = list.name.split(';');
          const fileTypeNameExt = fileTypename[fileTypename.length - 1];
          const result = response.requiredFiles.filter(fname =>
            fname.name.includes(fileTypeNameExt),
          );

          if (eventData == true) {
            if (result.length > 0) {
              result[0].actions.save = true;
              result[0].isMandatory = true;
            }
          } else {
            result[0].isOptional = true;
            result[0].isMandatory = false;
          }
          return true;
        }
        if (
          mandatorySaveFile &&
          mandatorySaveFile.__isEnableEngine__ &&
          mandatorySaveFile.__isEnableEngine__.value == true
        ) {
          response.requiredFiles.forEach(lst => {
            lst.actions.save = false;
            lst.isOptional = true;
            lst.isMandatory = false;
          });
          return true;
        }
        return false;
      });
    }
  }
  return response;
};

export const isValidFile = (validationFiles, file, files, placeHolders) => {
  const response = {
    isValid: false,
    isAlreadyExist: false,
    name: '',
    existedFileInfo: { name: '', uuid: '' },
    lwfDetails: { name: '', src: '' },
  };
  for (let i = 0; i < validationFiles.length; i++) {
    const validationFile = validationFiles[i];
    const isMandatory = validationFile.mandatoryCheck
      ? !!validationFile.mandatoryCheck[actions.save] ||
        !!validationFile.mandatoryCheck[actions.reject] ||
        !!validationFile.mandatoryCheck[actions.pending]
      : false;
    const isOptional = !!validationFile.mandatoryCheck && !isMandatory;
    // lwf changes for cup
    // const lwfDetails = customer.id != '1' ?  validationFile.lwf && validationFile.lwf.src ? {
    //     src: validationFile.lwf.src, isRoot: !!validationFile.lwf.isRoot} : { src: '', isRoot: false } : { src: '', isRoot: false };

    const lwfDetails = { src: '', isRoot: false };
    if (!(!isMandatory && !isOptional)) {
      const name = validationFile.name
        ? validationFile.name[0] == '/'
          ? validationFile.name.substring(1)
          : validationFile.name
        : '*';
      const formattedName = validationFile.name
        ? getFormattedName(name, placeHolders)
        : '';
      const formattedLWFSrcName = lwfDetails.src
        ? getFormattedName(lwfDetails.src, placeHolders)
        : '';
      const { path, basePath, isRoot = false } = file;
      let pattern = lwfDetails.src ? formattedLWFSrcName : formattedName;
      pattern = pattern
        ? pattern[0] == '/'
          ? pattern.substring(1)
          : pattern
        : '*';
      response.isValid =
        isRoot == lwfDetails.isRoot &&
        micromatch.isMatch(path, pattern) &&
        !pattern.includes('{{');
      if (response.isValid) {
        response.lwfDetails = { name: formattedName, src: formattedLWFSrcName };
        response.name = formattedName;
        const _path = lwfDetails.src ? formattedName : file.path;
        const matchedFile = files.find(
          fileData => fileData.path == basePath + _path,
        );
        response.isAlreadyExist = !!matchedFile;
        if (response.isAlreadyExist) {
          response.existedFileInfo.name = matchedFile.path;
          response.existedFileInfo.uuid = matchedFile.uuid;
        }
        break;
      }
    }
  }
  return response;
};

export const getToolsFileDetail = (
  validationFile,
  file,
  files,
  placeHolders,
) => {
  const response = {
    isValid: false,
    isAlreadyExist: false,
    name: '',
    existedFileInfo: { name: '', uuid: '' },
    lwfDetails: { name: '', src: '' },
  };
  const lwfDetails =
    validationFile.lwf && validationFile.lwf.src
      ? {
          src: validationFile.lwf.src,
          isRoot: !!validationFile.lwf.isRoot,
        }
      : { src: '', isRoot: false };
  const name = validationFile.name
    ? validationFile.name[0] == '/'
      ? validationFile.name.substring(1)
      : validationFile.name
    : '*';
  const formattedName = validationFile.name
    ? getFormattedName(name, placeHolders)
    : '';
  const formattedLWFSrcName = lwfDetails.src
    ? getFormattedName(lwfDetails.src, placeHolders)
    : '';
  const { basePath, isRoot = false } = file;
  let pattern = lwfDetails.src ? formattedLWFSrcName : formattedName;
  pattern = pattern
    ? pattern[0] == '/'
      ? pattern.substring(1)
      : pattern
    : '*';
  response.isValid = isRoot == lwfDetails.isRoot && !pattern.includes('{{');
  response.lwfDetails = { name: formattedName, src: formattedLWFSrcName };
  response.name = formattedName;
  const _path = lwfDetails.src ? formattedName : file.path;
  const matchedFile = files.find(fileData => fileData.path == basePath + _path);
  response.isAlreadyExist = !!matchedFile;
  if (response.isAlreadyExist) {
    response.existedFileInfo.name = matchedFile.path;
    response.existedFileInfo.uuid = matchedFile.uuid;
  }
  return response;
};

export const getFilteredFiles = (filesInfo, filesData, placeHolders) => {
  let { source, destination } = filesInfo;
  const { basePath } = filesInfo;
  source = source ? (source[0] == '/' ? source.substring(1) : source) : '*';
  destination = destination
    ? destination[0] === '/'
      ? destination.substring(1)
      : destination
    : '';
  const filesDataObj = {};
  filesData.forEach(file => {
    filesDataObj[file.path] = file;
  });
  const formattedSource = getFormattedName(source, placeHolders);
  const formattedDestination = getFormattedName(destination, placeHolders);
  const files = Object.keys(filesDataObj);
  const matchedFiles = micromatch(files, basePath.src + formattedSource);
  const filteredFiles = matchedFiles.map(matchedFile => {
    const fileData = filesDataObj[matchedFile];
    const destFileName = formattedDestination
      ? formattedDestination[formattedDestination.length - 1] === '/'
        ? basename(fileData.path)
        : basename(formattedDestination, extname(formattedDestination)) +
          extname(fileData.path)
      : basename(fileData.path);
    const destFolderName = formattedDestination
      ? formattedDestination.includes('/')
        ? formattedDestination[formattedDestination.length - 1] === '/'
          ? formattedDestination
          : `${dirname(formattedDestination)}/`
        : ''
      : '';
    const relativeSrcPath = fileData.path.split(
      basePath.src +
        (globParent(formattedSource) === '.'
          ? ''
          : `${globParent(formattedSource)}/`),
    )[1];
    if (!relativeSrcPath) throw new Error('Intermediate path is undefined');
    const destIntermediatePath = relativeSrcPath.includes('/')
      ? `${dirname(relativeSrcPath)}/`
      : '';
    return {
      ...fileData,
      dest: {
        name: destFileName,
        basePath: basePath.dest + destFolderName + destIntermediatePath,
      },
    };
  });
  return filteredFiles;
};
