const pattern = ';{{placeholder}};';

export const getFormattedName = (unFormattedName, placeHolders) => {
  const placeHolderkeys = Object.keys(placeHolders);
  let formattedName = unFormattedName;
  for (let i = 0; i < placeHolderkeys.length; i++) {
    const placeHolder = placeHolders[placeHolderkeys[i]]
      ? placeHolders[placeHolderkeys[i]]
      : `{{${placeHolderkeys[i]}}}`;
    formattedName = formattedName.replace(
      new RegExp(pattern.replace(/{{placeholder}}/, placeHolderkeys[i]), 'g'),
      placeHolder,
    );
  }
  return formattedName;
};

export const _getFormattedName = async (req, res) => {
  try {
    const { unFormattedName, placeHolders } = req.body;
    const result = await getFormattedName(unFormattedName, placeHolders);
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const isInvalid = value => {
  return (
    value === undefined ||
    value === null ||
    value === false ||
    (typeof value === 'string' &&
      ['null', 'undefined', 'false', ''].includes(value.trim().toLowerCase()))
  );
};

export const validateRequiredFields = (obj, requiredFields) => {
  const missingFields = requiredFields.filter(field => isInvalid(obj[field]));

  if (missingFields.length > 0) {
    throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
  }
};
