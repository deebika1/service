import { extname } from 'path';
import * as validationModule from './validate.js';
import { query } from '../../../database/postgres.js';

export const getFileValidationStatus = (req, res) => {
  const {
    validationFileConfig,
    filesInfo,
    placeHolders,
    eventdata,
    action,
    workOrderId,
  } = req.body;
  try {
    res.send(
      validationModule.getFileValidationStatus(
        validationFileConfig,
        filesInfo,
        placeHolders,
        eventdata,
        action,
        workOrderId,
      ),
    );
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const isValidFile = (req, res) => {
  const { validationFiles, file, files, placeHolders, customer } = req.body;
  try {
    res.send(
      validationModule.isValidFile(
        validationFiles,
        file,
        files,
        placeHolders,
        customer,
      ),
    );
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getToolsFileDetail = (req, res) => {
  const { validationFile, file, files, placeHolders } = req.body;
  try {
    res.send(
      validationModule.getToolsFileDetail(
        validationFile,
        file,
        files,
        placeHolders,
      ),
    );
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getFilteredFiles = (req, res) => {
  const { filesInfo, filesData, placeHolders } = req.body;
  try {
    res.send(
      validationModule.getFilteredFiles(filesInfo, filesData, placeHolders),
    );
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _getIncomingFileType = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select incomingfiledetails.filetypeid,incomingfiledetails.filename,incomingfiledetails.newfilename,incomingfiledetails.woincomingfileid,filetype.filetype,filetype.articletype,incomingfiledetails.runonfilesequence,incomingfiledetails.articleordersequence from wms_workorder_incoming as incoming
join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
join pp_mst_filetype as filetype on filetype.filetypeid = incomingfiledetails.filetypeid
where incoming.woid = $1 order by incomingfiledetails.filesequence asc`;
      const FileDetails = await query(sql, [workOrderId]);
      console.log(FileDetails, 'FileDetails');
      resolve(FileDetails);
    } catch (e) {
      reject(e);
    }
  });
};

export const getIncomingFileType = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const incomingFileDetails = await _getIncomingFileType(workOrderId);
    res.send(incomingFileDetails);
  } catch (err) {
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const checkWipActivity = async (req, res) => {
  const { wfEventId } = req.body;
  try {
    const sql = `SELECT eventlog.wfeventid,eventlog.workorderid,wo.customerid,eventlogdetails.operationtype, eventlog.actualactivitycount,eventlogdetails.actualactivitycount FROM public.wms_workflow_eventlog as eventlog
      join  wms_workflow_eventlog_details as eventlogdetails on eventlog.wfeventid = eventlogdetails.wfeventid and eventlog.actualactivitycount =eventlogdetails.actualactivitycount 
      join  wms_workorder as wo on wo.workorderid = eventlog.workorderid
      join  wms_mst_customerconfigdetails as customerconfig on customerconfig.customerid = wo.customerid   
      where eventlog.wfeventid = $1 and eventlogdetails.operationtype = 'Work in progress'
      order by eventlogdetails.wfeventdetailid asc`;
    const FileDetails = await query(sql, [wfEventId]);

    res.send(FileDetails);
  } catch (e) {
    res.status(400).send({ message: e.message?.data ? e.message?.data : e });
  }
};
// export const deleteTranscationEnterisForCancel = async (req, res) => {
//     const { wfEventId,repoFilePath } = req.body;
//     let sql1 = `select * from wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`
//     query(sql1).then((response1) => {
//         console.log(response1,"responsefordelte");
//         if(response1.length > 0){
//         let sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
//         WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`;
//         console.log(sql,"sql for transcation enteris")
//         query(sql).then((response) => {
//             console.log(response, "responseformemail")
//             res.status(200).json({ data: response });
//         }).catch((error) => {
//             res.status(400).send({ message: error });
//         }).catch((error) => {
//             res.status(400).send({ message: error });
//         });
//     }else{
//         res.status(200).json({ data: response1 });
//     }

// })
// }

export const deleteTranscationEnterisForCancel = async (req, res) => {
  const { wfEventId, repoFilePath, formattedSubLikeKey, ext } = req.body;
  let extensionFile = '';
  if (!formattedSubLikeKey) {
    const sql1 = `select * from wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`;
    query(sql1).then(response1 => {
      console.log(response1, 'responsefordelte');
      if (response1.length > 0) {
        const sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
            WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`;
        console.log(sql, 'sql for transcation enteris');
        query(sql)
          .then(response => {
            console.log(response, 'responseformemail');
            res.status(200).json({ data: response });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: response1 });
      }
    });
  } else {
    const sql1 = `select * from wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfEventId} and repofilepath like '%${repoFilePath}%'`;
    query(sql1).then(response1 => {
      console.log(response1, 'responsefordelte');
      if (response1.length > 0) {
        const extensionArray = [];
        for (let j = 0; j < response1.length; j++) {
          extensionFile = extname(response1[j].repofilepath);
          if (extensionFile != ext) {
            extensionArray.push(response1[j]);
          }
        }
        if (extensionArray.length > 0) {
          for (let k = 0; k < extensionArray.length; k++) {
            let lastIteration = false;
            if (k == extensionArray.length - 1) {
              lastIteration = true;
            }
            const sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
                            WHERE wfeventid = ${wfEventId} and actfilemapid = '${extensionArray[k].actfilemapid}'`;
            console.log(sql, `sql for transcation enteris${lastIteration}`);
            query(sql)
              .then(response => {
                if (lastIteration) {
                  res.status(200).json({ data: response });
                }
                console.log(response, 'responseformemail');
              })
              .catch(error => {
                res.status(400).send({ message: error });
              })
              .catch(error => {
                res.status(400).send({ message: error });
              });
          }
        } else {
          for (let i = 0; i < response1.length; i++) {
            let lastIteration1 = false;
            extensionFile = extname(response1[i].repofilepath);
            let sql = '';
            if (i == response1.length - 1) {
              lastIteration1 = true;
            }
            if (ext != '') {
              if (extensionFile != ext) {
                sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
                            WHERE wfeventid = ${wfEventId} and actfilemapid = '${response1[i].actfilemapid}'`;
                console.log(sql, 'sql for transcation enteris1');
              }
            } else {
              sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
                            WHERE wfeventid = ${wfEventId} and actfilemapid = '${response1[i].actfilemapid}'`;
              console.log(sql, 'sql for transcation enteris2');
            }
            query(sql)
              .then(response => {
                if (lastIteration1) {
                  res.status(200).json({ data: response });
                }
                console.log(response, 'responseformemail');
              })
              .catch(error => {
                res.status(400).send({ message: error });
              })
              .catch(error => {
                res.status(400).send({ message: error });
              });
          }
        }
      } else {
        res.status(200).json({ data: response1 });
      }
    });
  }
};

export const getPreviousActivitiesForCancel = async (req, res) => {
  const { workOrderId, WfDefId } = req.body;
  try {
    const sql = `select * from wms_workflow_eventlog where workorderid = $1 and wfdefid =$2`;
    const FileDetails = await query(sql, [workOrderId, WfDefId]);
    if (FileDetails.length > 0) {
      res.send(true);
    } else {
      res.send(false);
    }
    console.log(FileDetails, 'FileDetails');
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

// added by vaithi
export const checkPendingStatus = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `SELECT * FROM wms_workflow_eventlog_details where wfeventid= ${jsonobj.wfEventId} and operationtype = 'Pending' `;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// added by vaithi
export const getdataACSnotes = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select note from notestoacslog where workorderid = ${jsonobj.workorderId} and stageid = ${jsonobj.stageId} order by id desc limit 1`;
    const out = await query(sql);
    if (out.length > 0) {
      res.status(200).send(out);
    } else {
      res.status(200).send({ message: 'no data' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// For convert file
export const getdataConvertFile = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sqlQuery = `select convertionfiles from acs_convertionfile_details where workorderid = ${jsonobj.workorderId} and stageid = ${jsonobj.stageId} ORDER BY created_time DESC LIMIT 1`;
    // const sql = `select note from notestoacslog where workorderid = ${jsonobj.workorderId} and stageid = ${jsonobj.stageId} order by createddate desc limit 1`;
    let out = await query(sqlQuery);
    if (out.length > 0) {
      out = out.flatMap(item =>
        item.convertionfiles
          .filter(file => file.updatedFilename !== '')
          .map(file => ({
            sourceName: file.filename,
            targetName: file.updatedFilename,
          })),
      );
      res.status(200).send(out);
    } else {
      res.status(200).send({ message: 'no data' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const getEllocationID = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select  elocationid from public.wms_workorder where workorderid = ${jsonobj.workorderId} and isactive = 'true' limit 1`;
    const out = await query(sql);
    if (out.length > 0) {
      res.status(200).send(out);
    } else {
      res.status(200).send({ message: 'no data' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getdataACSDNP = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select donotpublish from public.acs_donotpublish_details where workorderid = ${jsonobj.workorderId} and stageid = ${jsonobj.stageId} order by updated_time desc limit 1`;
    const out = await query(sql);
    if (out.length > 0) {
      res.status(200).send(out);
    } else {
      res.status(200).send({ message: 'no data' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getVtwJsonServiceCall = async (req, res) => {
  try {
    const { pii } = req.params;
    const sql = `select
                    message,
                    response
                  from
                    public.wms_mst_signal_audit_trns wmsat 
                    join public.wms_mst_signal_audit wmsa on wmsa.signalauditid = wmsat.signalauditid
                  where
                    wmsa.pii = '${pii}'
                  order by
                    signalaudittrnsid asc
                  limit 1`;
    const out = await query(sql);
    if (out.length > 0) {
      res.status(200).send({ issuccess: true, data: out[0].response });
    } else {
      res.status(200).send({ issuccess: false, message: 'no data' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
