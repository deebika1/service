import { join } from 'path';
import fs, { promises, existsSync } from 'fs';

export const makeDir = async path => {
  console.log(path);
  if (!fs.existsSync(path)) {
    return promises.mkdir(path);
  }
  return true;
};
export const writeSmallFile = async (filepath, content, dirpath) => {
  return new Promise(async (resolve, reject) => {
    try {
      const fileSize = Buffer.byteLength(content, 'utf8');
      const fileSizeInKB = fileSize / 5000;
      if (fileSizeInKB < 5000) {
        await makeDir('uploads/');
        await makeDir(dirpath);
        const fileContent = await promises.writeFile(filepath, content, {
          encoding: 'utf8',
        });
        resolve(fileContent);
      } else {
        reject(`File exceeds maximum limit (max - 1MB)`);
      }
    } catch (err) {
      reject(err);
    }
  });
};
export const stat = async path => {
  return promises.lstat(path);
};
export const removeFile = async path => {
  if (await isFileExist(path)) return promises.unlink(path);
  return Promise.resolve();
};
export const isPathExist = path => {
  return existsSync(path);
};
export const isFileExist = async path => {
  if (existsSync(path) && !(await stat(path)).isDirectory()) {
    return true;
  }
  return false;
};
export const readDir = async path => {
  return promises.readdir(path);
};
export const removeDir = async path => {
  return promises.rmdir(path);
};
export const removeFolder = path => {
  return new Promise(async (resolve, reject) => {
    try {
      if (isPathExist(path)) {
        const dirPaths = await readDir(path);
        for (let i = 0; i < dirPaths.length; i++) {
          const currentPath = join(path, dirPaths[i]);
          const fstat = await stat(currentPath);
          if (fstat.isDirectory()) {
            await removeFolder(currentPath);
          } else {
            try {
              await removeFile(currentPath);
            } catch (e) {
              console.log(e, 'removeFolder');
              reject(e);
            }
          }
        }
        try {
          await removeDir(path);
        } catch (e) {
          console.log(e, 'removeFolder');
          reject(e);
        }
      }
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
