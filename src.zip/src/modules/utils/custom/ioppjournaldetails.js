import { ioppJournalDetails } from '../../JobInfoTemplate/ioppjournaldetails.js';
import { query } from '../../../database/postgres.js';

const journalDetailsXmlCreate = async prodcutionList => {
  return new Promise(async (resolve, reject) => {
    try {
      const prodOut = [];
      let finalTemplate = [];
      const {
        jobname,
        stagename,
        activityname,
        isiauthor,
        journalacronym,
        textcolumnid,
        templateformat,
        journaltype,
        profilepath,
      } = prodcutionList;
      prodOut.push(
        ioppJournalDetails.li
          .replace(/{{jobname}}/, jobname)
          .replace(/{{stagename}}/, stagename)
          .replace(/{{activityname}}/, activityname)
          .replace(/{{isiauthor}}/, isiauthor)
          .replace(/{{journalacronym}}/, journalacronym)
          .replace(/{{textcolumnid}}/, textcolumnid)
          .replace(/{{templateformat}}/, templateformat)
          .replace(/{{journaltype}}/, journaltype)
          .replace(/{{profilepath}}/, profilepath),
      );

      finalTemplate = ioppJournalDetails.ul.replace(
        /{{li}}/,
        prodOut.join('\n'),
      );

      resolve(finalTemplate);
    } catch (e) {
      reject(e);
      console.log(e, 'error in job info xml');
    }
  });
};

export const getIoppJournalDetails = async (req, res) => {
  const { wfEventId } = req.body;
  const prodcutionList = {};
  try {
    const sql = `SELECT * from wms_jobinfoxml_new where wfeventid=${wfEventId}`;
    const jobInfoDetails = await query(sql, []);
    jobInfoDetails.map(async list => {
      prodcutionList.jobname = list.itemcode;
      prodcutionList.journalacronym = list.journalacronym;
      prodcutionList.stagename = list.stagename;
      prodcutionList.isiauthor = list.isiauthor;
      prodcutionList.activityname = list.activityname;
      prodcutionList.textcolumnid = list.textcolumnid;
      prodcutionList.templateformat = list.templateformat;
      prodcutionList.journaltype = list.journaltype == 'print' ? 'YES' : 'NO';
      prodcutionList.profilepath =
        list.journaltype == 'print' ? list.printprofile : list.onlineprofile;
    });
    console.log(prodcutionList, 'prodcutionList');
    let ul = {};
    if (Object.keys(prodcutionList).length) {
      ul = await journalDetailsXmlCreate(prodcutionList);
    }
    res.send({ data: ul });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};
