import { _completeAPIRequestId } from './api.js';
import { acknowledge as ackForegroundTask } from '../../task/tools/ack.js';
import { acknowledge as ackExternalTask } from '../../externalTask/tools/ack.js';
import { isNullorUndefined } from './index.js';
import { query } from '../../../database/postgres.js';
import {
  _updateDb,
  _updateEventDatilsForBtach,
} from '../../externalTask/index.js';
import {
  _triggerWithoutCamundaWorkflow,
  _stageCompleteUpdate,
} from '../../woi/workflowTrigger.js';
import logger from '../logs/index.js';
import {
  checkAllSigngleActivityCompleted,
  paralleStageConfigEnable,
} from '../../task/action/workflow/save.js';

export const initialAcknowledge = async (req, res) => {
  try {
    const sql = `update public.wms_tools_api set isinitiated = true where apiid=${req.body.apiid}`;
    await query(sql);
    res
      .status(200)
      .send({ issuccess: true, message: 'Tools initial Acknowledged' });
  } catch (e) {
    res
      .status(400)
      .send({ issuccess: false, message: e.message ? e.message : e });
  }
};
export const acknowledge = async (req, res) => {
  const { iwms, data, message, is_success, isBPCorrection, isFileAvailable } =
    req.body;

  try {
    const remarks =
      !isNullorUndefined(data) &&
      (Object.prototype.toString.call(data) == '[object String]' ||
        Object.prototype.toString.call(data) == '[object Boolean]')
        ? data
        : !isNullorUndefined(message) &&
          (Object.prototype.toString.call(message) == '[object String]' ||
            Object.prototype.toString.call(message) == '[object Boolean]')
        ? message
        : data || message || 'Remarks missing';
    const { wfeventId, isForegroundService, toolsId, getToolsEntry } =
      await _completeAPIRequestId({
        apiId: iwms.id,
        status: is_success ? 'Success' : 'Failure',
        remarks: remarks.toString(),
        response: req.body,
        sId: iwms.sId,
        tooloutputid: iwms.tooloutputid,
        isFileAvailable,
        actualActivityCount: iwms.actualActivityCount,
      });
    if (is_success) {
      if (isForegroundService) {
        await ackForegroundTask(wfeventId, toolsId, {}, iwms.dmsType);
      } else if ('iscamundaflow' in iwms && !iwms.iscamundaflow) {
        if (
          getToolsEntry &&
          getToolsEntry.length > 0 &&
          getToolsEntry[0].activitytype == 'External Task'
        ) {
          const activityStatusForExternalTask = is_success
            ? 'Completed'
            : 'Failed';
          if (iwms.activitymodeltypeflow === 'Batch') {
            await _updateEventDatilsForBtach(
              iwms.woId,
              iwms.wfDefid,
              activityStatusForExternalTask,
              remarks.toString(),
            );
          } else {
            await _updateDb(
              wfeventId,
              remarks.toString(),
              [],
              activityStatusForExternalTask,
              iwms.iscamundaflow,
            );
          }
          if (iwms.nextActivityId) {
            let fileId = null;
            let isTriggerNext = true;
            if (iwms.activitymodeltypeflow === 'Batch') {
              fileId = null;
            } else {
              const { status, nextActivityType } =
                await checkAllSigngleActivityCompleted(
                  iwms.woId,
                  iwms.wfDefid,
                  iwms.nextActivityId,
                  iwms.wfId,
                  iwms.filetypeskipfornextactivity,
                  iwms.stageId,
                  iwms.fileTypeId,
                );
              isTriggerNext = status;
              fileId =
                nextActivityType === 'Batch' ? null : iwms.woIncomingFileId;
            }
            if (isTriggerNext) {
              const payload = {
                wfId: iwms.wfId,
                workorderId: iwms.woId,
                stageId: iwms.stageId,
                stageIteration: iwms.stageIteration,
                serviceId: iwms.serviceId,
                actionFlow: 'next',
                activityId: iwms.nextActivityId,
                woIncomingFileId: fileId,
                filetypeSkip: iwms.filetypeskipfornextactivity,
              };
              await _triggerWithoutCamundaWorkflow(payload);
            }
          } else if (iwms.nextActivityId == null) {
            await _stageCompleteUpdate({
              workorderId: iwms.woId,
              stageId: iwms.stageId,
              wfId: iwms.wfId,
              activityId: iwms.activityId,
            });
          }
          // Condition for Stage Trigger for Engine task.
          if (iwms.enableAutoStageTrnsf) {
            const wfid = iwms.wfId;
            const stageid = iwms.stageId;
            const sql = `SELECT stageid
          FROM (
          SELECT stageid, MAX(sequence) AS sequence
          FROM wms_workflowdefinition
          WHERE wfid = ${wfid}
          GROUP BY stageid
          ) AS q
          WHERE q.sequence > (
          SELECT MAX(sequence)
          FROM wms_workflowdefinition
          WHERE wfid = ${wfid} AND stageid = ${stageid}
          )
          ORDER BY q.sequence ASC
          LIMIT 1;`;
            const response = await query(sql);

            let fileId = null;
            let isTriggerNext = true;
            if (iwms.activitymodeltypeflow === 'Batch') {
              fileId = null;
            } else {
              const { status, nextActivityType } =
                await checkAllSigngleActivityCompleted(
                  iwms.woId,
                  iwms.wfDefid,
                  iwms.nextActivityId,
                  iwms.wfId,
                  iwms.filetypeskipfornextactivity,
                  iwms.stageId,
                  iwms.fileTypeId,
                );
              isTriggerNext = status;
              fileId =
                nextActivityType === 'Batch' ? null : iwms.woIncomingFileId;
            }
            if (isTriggerNext) {
              const payload = {
                wfId: iwms.wfId,
                workorderId: iwms.woId,
                stageId: response.length ? response[0].stageid : null,
                stageIteration: iwms.stageIteration,
                serviceId: iwms.serviceId,
                actionFlow: null,
                activityId: iwms.nextActivityId,
                woIncomingFileId: fileId,
                filetypeSkip: iwms.filetypeskipfornextactivity,
              };
              await _triggerWithoutCamundaWorkflow(payload);
            }
          }
          // Elsevier Parallel stage config
          // get the workflow config
          const { wfId, activityId, stageId, serviceId, woId } = iwms;
          let sql = `select config  from wms_workflowdefinition where wfid = ${wfId} and stageid = ${stageId} and activityid = ${activityId}  order by sequence`;
          const getConfigJson = await query(sql);
          const parallelStageConfig = getConfigJson.length
            ? getConfigJson[0]?.config?.parallelStageConfig || []
            : [];
          if (parallelStageConfig && parallelStageConfig.length > 0) {
            // specific for elsevier journals cas flow supplimentery flow
            sql = `select otherfield from wms_workorder where workorderid = ${woId}`;
            const otherFieldResp = await query(sql);
            const otherfieldJson = otherFieldResp.length
              ? otherFieldResp[0]?.otherfield || {}
              : [];
            let nextactivityid = iwms.nextActivityId;
            if (wfId == 43 && stageId == 102) {
              nextactivityid = 555;
              if (
                otherfieldJson?.suppliment !== undefined &&
                otherfieldJson.suppliment == 0
              ) {
                nextactivityid = null;
              }
            }
            if (nextactivityid) {
              const { nextActivityType } =
                await checkAllSigngleActivityCompleted(
                  iwms.woId,
                  iwms.wfDefid,
                  iwms.nextActivityId,
                  iwms.wfId,
                  iwms.filetypeskipfornextactivity,
                  iwms.stageId,
                );

              const fileId =
                nextActivityType === 'Batch' ? null : iwms.woIncomingFileId;
              const Payload = {
                wfId,
                workorderId: woId,
                stageId,
                serviceId,
                parallelStageConfig,
                woIncomingFileId: fileId,
                actionFlow: 'next',
                currentActivityId: activityId,
                activityId: nextactivityid,
              };
              await paralleStageConfigEnable(Payload);
            }
          }
        }
      } else {
        await ackExternalTask(
          wfeventId,
          toolsId,
          {},
          is_success,
          getToolsEntry,
          remarks,
          iwms.dmsType,
          isBPCorrection,
        );
      }
    } else if ('iscamundaflow' in iwms && !iwms.iscamundaflow) {
      /* removed log */
      if (!isForegroundService) {
        const activityStatusForExternalTask = is_success
          ? 'Completed'
          : 'Failed';
        if (iwms.activitymodeltypeflow === 'Batch') {
          // need to be handled
        } else {
          await _updateDb(
            wfeventId,
            remarks.toString(),
            [],
            activityStatusForExternalTask,
            iwms.iscamundaflow,
          );
        }
      }
    } else {
      await ackExternalTask(
        wfeventId,
        toolsId,
        {},
        is_success,
        getToolsEntry,
        remarks,
        iwms.dmsType,
        isBPCorrection,
      );
    }
    res.send(true);
  } catch (e) {
    logger.info(`Tool acknowledge final catch ${e.message ? e.message : e}`);
    res.status(400).send(e.message ? e.message : e);
  }
};
