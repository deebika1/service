/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import { query } from '../../../database/postgres.js';

export const updateBackupFile = async (req, res) => {
  try {
    const { wfeventid, filename, path, rowlimit } = req.body;
    const sql = `select public.insert_backupfiles(${wfeventid}, '${filename}', '${path}', ${rowlimit})`;
    await query(sql);
    res.status(200).send({ issuccess: true, message: 'Backup Successfull.' });
  } catch (e) {
    res
      .status(400)
      .send({ issuccess: false, message: e.message ? e.message : e });
  }
};
export const getBackupFileDetails = async (req, res) => {
  try {
    const { wfeventid, filename } = req.body;
    let sql = `select * from public.wms_backup_files where wfeventid = ${wfeventid}`;
    if (filename) {
      sql = `${sql} and filename = '${filename}'`;
    }
    sql = `${sql} order by backupid desc`;
    const data = await query(sql);
    res
      .status(200)
      .send({ issuccess: true, data, message: 'Backup Successfull.' });
  } catch (e) {
    res
      .status(400)
      .send({ issuccess: false, message: e.message ? e.message : e });
  }
};

export const updateBulkBackupFile = async (req, res) => {
  try {
    if (req.body && req.body.length > 1) {
      if (!Array.isArray(req.body) || req.body.length === 0) {
        return res
          .status(400)
          .send({ issuccess: false, message: 'Invalid input data.' });
      }
      const queries = req.body.map(
        ({ wfeventid, filename, path, rowlimit }) => {
          const sql = `SELECT public.insert_backupfiles($1, $2, $3, $4)`;
          return query(sql, [wfeventid, filename, path, rowlimit]);
        },
      );
      await Promise.all(queries);
    } else {
      const { wfeventid, filename, path, rowlimit } = req.body[0];
      const sql = `select public.insert_backupfiles(${wfeventid}, '${filename}', '${path}', ${rowlimit})`;
      await query(sql);
    }

    res.status(200).send({ issuccess: true, message: 'Backup Successful.' });
  } catch (e) {
    console.error('Error in updateBackupFile:', e); // Log error for debugging
    res.status(400).send({ issuccess: false, message: e.message || e });
  }
};
