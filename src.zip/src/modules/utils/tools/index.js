import path, { join, parse, dirname } from 'path';
import axios from 'axios';
import moment from 'moment';
import { fileURLToPath } from 'url';
import ExcelJS from 'exceljs';
import { query } from '../../../database/postgres.js';
import { getWorkflowPlaceHolders } from '../../task/fileDetails.js';
import { getFormattedName } from '../fileValidation/utils.js';
import { okmFolderCopy } from './io.js';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import { getdmsType } from '../../bpmn/listener/create.js';
import * as azureHelper from '../azure/index.js';
import * as localHelper from '../local/index.js';
import { ReStructureFileConfig } from '../fileValidation/validate.js';
import { emitAction } from '../../activityListener/activityListener.js';
import { _retreiveLocalFiles } from '../local/index.js';
import { getBasePath, getFolderStructure } from '../wmsFolder/index.js';
import { _dispatchFromIauthor } from '../../dispatch/index.js';
import { makeDir, removeFolder } from '../custom/io.js';
import { copyXlsxFile } from '../../task/tools/index.js';
import { _upload } from '../azure/index.js';
import { invokeFileUploadToFTP } from '../../filetransferkit/index.js';
import { validateExcel } from '../../../customers/springerBooks/helpers/validation.js';
import logger from '../logs/index.js';
import { _sendCampusSignal } from '../../woi/woAutocreation.js';

const __filename = fileURLToPath(import.meta.url);

const iservice = new Service();

export const iNLPScoreGeneration = async (req, res) => {
  const { workOrderId, stage, service, eventId, graphicEventId } = req.body;
  try {
    const dmsType = await getdmsType(workOrderId);
    let sql = `select  COALESCE(d.typesetpages,0) as typesetpages, 
        a.otherfield ->>'articleno' as articleno, 
        doinumber as articlename,title as articletitle,
        b.isiauthor, b.iauthworkflowid,a.wotype, 
        b.journalacronym, b.journalname ,c.iauthcustomerid ,
        d.stageiterationcount 
            from wms_workorder a 
            join public.pp_mst_journal b on a.journalid=b.journalid 
            join public.wms_workorder_Stage d on d.workorderid=a.workorderid
            left join public.iauthor_mst_customer c on c.custorgmapid=b.custorgmapid 
                where a.workorderid=${workOrderId} and d.wfstageid=${stage.id}`;

    const mstJournal = await query(sql);
    if (mstJournal.length == 0) {
      throw new Error(`invalid workorderid : ${workOrderId}`);
    }
    sql = `Select incf.filename from public.wms_workorder_incoming as inc
        left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
        where woid=${workOrderId}`;
    let Filename = await query(sql);
    Filename = Filename[0].filename;
    let logFilePath = [];
    if (graphicEventId != null) {
      sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                    where wfeventid =${graphicEventId} and isactive=true and repofilepath like '%${Filename}_log.xml'`;
      logFilePath = await query(sql);
    }
    sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                where wfeventid =${eventId} and isactive=true and repofilepath like '%${Filename}.xml'`;
    const XMLFilePath = await query(sql);
    const data = {
      CustomerID: mstJournal[0].iauthcustomerid,
      JournalCode: mstJournal[0].journalacronym,
      isNewWMS: true,
      XMLFileName: `${Filename}.xml`,
      NLP_version: 'V2',
    };
    switch (dmsType) {
      case 'azure':
        let out = await azureHelper._download(XMLFilePath[0].repofilepath);
        data.XMLFile = out.data.path;
        if (logFilePath.length > 0) {
          out = await azureHelper._download(logFilePath[0].repofilepath);
          data.XMLLogFile = out.data.path;
          data.XMLLogFileName = `${Filename}_log.xml`;
        }
        break;
      case 'local':
        let out1 = await localHelper._localdownload(
          XMLFilePath[0].repofilepath,
        );
        data.XMLFile = out1.data.path;
        if (logFilePath.length > 0) {
          out1 = await localHelper._localdownload(logFilePath[0].repofilepath);
          data.XMLLogFile = out1.data.path;
          data.XMLLogFileName = `${Filename}_log.xml`;
        }
        break;
      default:
        data.XMLFile =
          config.openKM.base_out_url +
          config.openKM.uri.download +
          XMLFilePath[0].repofileuuid;
        if (logFilePath.length > 0) {
          data.XMLLogFile =
            config.openKM.base_out_url +
            config.openKM.uri.download +
            logFilePath[0].repofileuuid;
          data.XMLLogFileName = `${Filename}_log.xml`;
        }
        break;
    }
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.nlp
      }`,
      headers: {
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data,
    };
    axios(configAPI)
      .then(async function (response) {
        try {
          sql = `select * from insert_inlptran('${JSON.stringify({
            workorderid: (workOrderId || '').toString(),
            stageid: (stage.id || '').toString(),
            serviceid: (service.id || '').toString(),
            guid: (response.data.NLPGuid || '').toString(),
            stageiterationcount: (stage.stageiterationcount || 1).toString(),
            Score: (response.data.Score || '').toString(),
            TrackGrade: (response.data.TrackGrade || '').toString(),
          })}')`;
          await query(sql);
          res.status(200).send(response.data);
        } catch (error) {
          res.status(400).send({ is_success: false, message: error.message });
        }
      })
      .catch(function (error) {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};

export const iAuthorLinkGeneration = async (req, res) => {
  const {
    workOrderId,
    stage,
    service,
    eventId,
    graphicEventId,
    skipFileValidation,
  } = req.body;
  try {
    const dmsType = await getdmsType(workOrderId);

    // added to get the customer details

    // const { customer } = req.body;

    const SupplimentryFiles = [];
    let sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map
                    where wfeventid=${eventId}`;
    // let sql = `SELECT *
    // FROM public.wms_workflowactivitytrn_file_map
    // WHERE wfeventid = ${eventId}
    // AND repofilepath NOT LIKE '%.tif'
    // AND repofilepath NOT LIKE '%.eps'
    // AND repofilepath NOT LIKE '%.zip';`;
    const eventDetails = await query(sql);
    let additionalFiles;

    // let sqlACS = `SELECT * FROM public.wms_workflowactivitytrn_file_map
    // where wfeventid =${graphicEventId} and repofilepath not like '%.eps'`;
    if (graphicEventId != null) {
      sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                    where wfeventid =${graphicEventId} and repofilepath not like '%.eps'`;
      additionalFiles = await query(sql);
      const supplementaryArray = [];
      additionalFiles.forEach(element => {
        element.FileName = path.basename(element.repofilepath);
        switch (dmsType) {
          case 'azure':
            supplementaryArray.push(
              azureHelper._download(element.repofilepath),
            );
            break;
          case 'local':
            supplementaryArray.push(
              localHelper._localdownload(element.repofilepath),
            );
            break;
          default:
            supplementaryArray.push({
              path:
                config.openKM.base_out_url +
                config.openKM.uri.download +
                element.repofileuuid,
            });
            break;
        }
      });
      const supplementary = await Promise.all(supplementaryArray);
      supplementary.forEach(ele => {
        SupplimentryFiles.push({
          flag: 'article_resource',
          url: ele.path ? ele.path : ele.data.path,
        });
      });
    }
    if (eventDetails.length == 0) {
      throw new Error(`File mapping missing for workorderid : ${eventId}`);
    }
    let articletype;

    if (dmsType === 'azure') {
      const sqlquery = `SELECT jl.isactive,jl.isiauthor,jl.iauthworkflowid,
      jl.articletype,jl.iauthorreviewworkflow, 
      * FROM wms_workorder wo
      left join pp_mst_journal jl on jl.journalid = wo.journalid
      WHERE wo.workorderid = ${workOrderId}`;
      articletype = await query(sqlquery);
      console.log('articletype:', articletype);
    }

    let workflowFieldMapping = {};
    let articleType;
    if (
      articletype?.[0]?.customerid === '8' &&
      articletype?.[0]?.otherfield?.articletype &&
      articletype?.[0]?.otherfield?.articletype &&
      articletype?.[0]?.articletype !== 'NA'
    ) {
      articleType = articletype[0].otherfield.articletype;
      console.log('articleType:', articleType);

      if (articleType === 'book-review') {
        workflowFieldMapping = {
          'book-review': 'b.iauthorreviewworkflow',
        };
      }
    } // else {
    //   throw new Error('Invalid or missing article type');
    // }

    let iAuthorWorkFlowField = '';

    // Handle cases where `iauthorreviewworkflow` is null
    if (
      articletype?.[0]?.customerid === '8' &&
      articletype?.[0]?.iauthorreviewworkflow == null
    ) {
      iAuthorWorkFlowField = 'b.iauthworkflowid';
    } else {
      switch (stage.id) {
        case '13':
          iAuthorWorkFlowField = 'b.copyeditingworkflow';
          break;
        case '72':
          iAuthorWorkFlowField = 'b.iauthworkconversionflowid';
          break;
        default:
          // Dynamically select the workflow field based on article type
          iAuthorWorkFlowField =
            workflowFieldMapping[articleType] || 'b.iauthworkflowid';
          break;
      }
    }
    sql = `select  COALESCE(d.typesetpages,0) as typesetpages, a.otherfield ->>'articleno' as articleno, doinumber as articlename,title as articletitle,b.isiauthor, 
                ${iAuthorWorkFlowField} as iauthworkflowid,a.wotype, b.journalacronym, b.journalname ,c.iauthcustomerid ,d.stageiterationcount,
                b.iauthworkconversionflowid,a.otherfield ->>'pii' as pii,a.customerid,b.otherdetails,a.journalid
                from wms_workorder a 
                join public.pp_mst_journal b on a.journalid=b.journalid 
                join public.wms_workorder_Stage d on d.workorderid=a.workorderid
                left join public.iauthor_mst_customer c on c.custorgmapid=b.custorgmapid 
                where a.workorderid=${workOrderId} and d.wfstageid=${stage.id}`;
    const mstJournal = await query(sql);
    sql = `Select incf.filename,wo.doinumber,wo.otherfield,wo.customerid from public.wms_workorder_incoming as inc
    left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
    left join wms_workorder wo on wo.workorderid = inc.woid
    where woid=${workOrderId}`;
    const Filename = await query(sql);
    if (mstJournal.length == 0) {
      throw new Error(`invalid workorderid : ${workOrderId}`);
    }

    // if (Filename[0].customerid == '8') {
    //   if (Filename[0].otherfield.articletype == 'book-review') {
    //     console.log("book-review");
    //   }
    // }

    // to be deleted
    // if (mstJournal[0].typesetpages == 0) {
    //   throw new Error(`Typeset Pages not updated.`);
    // }
    const supplementaryArray = [];
    eventDetails.forEach(element => {
      element.FileName = path.basename(element.repofilepath);

      if (element.FileName.toLowerCase().endsWith('.zip')) {
        return;
      }
      switch (dmsType) {
        case 'azure':
          supplementaryArray.push(azureHelper._download(element.repofilepath));
          break;
        case 'local':
          supplementaryArray.push(
            localHelper._localdownload(element.repofilepath),
          );
          break;
        default:
          supplementaryArray.push({
            path:
              config.openKM.base_out_url +
              config.openKM.uri.download +
              element.repofileuuid,
          });
          break;
      }
    });
    const supplementary = await Promise.all(supplementaryArray);
    supplementary.forEach(ele => {
      SupplimentryFiles.push({
        flag: 'article_resource',
        url: ele.path ? ele.path : ele.data.path,
      });
    });
    const inputXML = eventDetails.filter(
      x => x.FileName == `${Filename[0].filename}.xml`,
    );

    // To change iauthor link generation filename to pii start

    if (mstJournal?.[0]?.customerid == 8 && mstJournal?.[0]?.pii) {
      console.log(inputXML, 'input xml');
      const destinationPath = inputXML[0].repofilepath;
      const piiPathRes = await azureHelper._copyFileWithoutFormData({
        srcPath: destinationPath,
        destBasePath: `${dirname(destinationPath)}/`,
        name: `${mstJournal[0].journalacronym}_${mstJournal[0].pii}.xml`,
      });
      console.log(piiPathRes, 'piiPathRes');
      inputXML[0].repofilepath = piiPathRes?.path;
    }

    // end

    let logXML =
      additionalFiles && additionalFiles.length
        ? additionalFiles.filter(
            x => x.FileName == `${Filename[0].filename}_log.xml`,
          )
        : [];
    if (logXML.length == 0) {
      logXML = eventDetails.filter(
        x => x.FileName == `${Filename[0].filename}_log.xml`,
      );
    }

    if (inputXML.length == 0) {
      throw new Error(`${`${Filename[0].filename}.xml`} file missing.`);
    }
    sql = `SELECT guid FROM inlp_transactions 
        WHERE workorderid = ${workOrderId}
        AND stageid = ${stage.id}
        AND serviceid = ${service.id}
        AND stageiterationcount = ${mstJournal[0].stageiterationcount} order by inlptrnsid limit 1`;
    let NLPGuid = await query(sql);
    if (NLPGuid.length > 0) {
      NLPGuid = NLPGuid[0].guid;
    } else {
      NLPGuid = undefined;
    }
    sql = `select contactname ,contactemail ,contactrole from public.wms_workorder_contacts 
                where workorderid=${workOrderId} order by wocontactid`;
    const workorderContacts = await query(sql);
    if (workorderContacts.length == 0) {
      throw new Error(`Workorder Contacts are missing.`);
    }
    // const peDetails = workorderContacts.filter(
    //   x =>
    //     x.contactrole == 'PED' ||
    //     x.contactrole == 'CM' ||
    //     x.contactrole == 'PM',
    // );

    sql = `select * from public.iauthor_workflow 
                where iauthworkflowid=${mstJournal[0].iauthworkflowid}`;
    const iAuthorWorkFlow = await query(sql);
    if (iAuthorWorkFlow.length == 0) {
      throw new Error(
        `iAuthorWorkFlow is not mapped for this journal (${mstJournal[0].journalacronym})`,
      );
    } else if (
      mstJournal[0].typesetpages == 0 &&
      iAuthorWorkFlow[0].compoulsaryrole?.skipTypesetPageCount != 'true'
    ) {
      throw new Error(`Typeset Pages not updated.`);
    }

    const peDetails =
      iAuthorWorkFlow[0]?.compoulsaryrole.isACS == 'true'
        ? workorderContacts.filter(
            x =>
              x.contactrole == 'PED' ||
              x.contactrole == 'CM' ||
              x.contactrole == 'PM',
          )
        : workorderContacts.filter(
            x => x.contactrole == 'PED' || x.contactrole == 'CM',
          );

    const authorDetails = workorderContacts.filter(
      x => x.contactrole == 'AUTHOR',
    );
    const EditorDetails = workorderContacts.filter(
      x => x.contactrole == 'EC' || x.contactrole == 'E',
    );
    const spmDetails = workorderContacts.filter(x => x.contactrole == 'SPM');
    if (peDetails.length == 0) {
      throw new Error('Production Editor is not mapped.');
    }

    const SequenceDetails = [];
    for (const activity of iAuthorWorkFlow[0].sequencedetails.activities) {
      if (activity.contactrole == 'DEFAULT') {
        SequenceDetails.push({
          ActivityID: activity.ActivityID,
          RoleID: activity.RoleID,
          userDetails: [
            {
              UserName: 'admin',
              Email: 'admin@integra.co.in',
            },
          ],
        });
      } else {
        const user = workorderContacts.filter(
          x => x.contactrole == activity.contactrole,
        );
        if (user.length == 0) {
          throw new Error(
            `Workorder Contacts are missing for ${activity.contactrole}`,
          );
        }
        SequenceDetails.push({
          ActivityID: activity.ActivityID,
          RoleID: activity.RoleID,
          userDetails: [
            {
              UserName: remove_linebreaksAndSpace(user[0].contactname),
              Email: remove_linebreaksAndSpace(user[0].contactemail),
            },
          ],
        });
      }
    }
    const articlemeta = {
      manuscriptid:
        mstJournal[0].customerid == 8
          ? `${mstJournal[0].journalacronym}_${mstJournal[0].pii}`
          : Filename[0].filename,
      manuscripttitle: mstJournal[0].articletitle,
      DOI: Filename[0].doinumber,
      journaltitle: mstJournal[0].journalname,
      Articlenumber: mstJournal[0].articleno,
      Pageno: mstJournal[0].typesetpages,
    };

    if (authorDetails.length > 0) {
      articlemeta.Authoremail = remove_linebreaksAndSpace(
        authorDetails[0].contactemail,
      );
      articlemeta.Authorname = remove_linebreaksAndSpace(
        authorDetails[0].contactname,
      );
    }
    if (peDetails.length > 0) {
      articlemeta.Pemailid = remove_linebreaksAndSpace(
        peDetails[0].contactemail,
      );
      articlemeta.Pename = remove_linebreaksAndSpace(peDetails[0].contactname);
    }
    if (EditorDetails.length > 0) {
      if (EditorDetails.length > 1) {
        const additionalEditor = EditorDetails.splice(1, EditorDetails.length);
        articlemeta.AdditionalEditorMail = additionalEditor
          .map(x => remove_linebreaksAndSpace(x.contactemail))
          .join(';');
      }
      articlemeta.Editoremailid = remove_linebreaksAndSpace(
        EditorDetails[0].contactemail,
      );
      articlemeta.Editorname = remove_linebreaksAndSpace(
        EditorDetails[0].contactname,
      );
    }
    if (spmDetails.length > 0) {
      articlemeta.SPMemailid = remove_linebreaksAndSpace(
        spmDetails[0].contactemail,
      );
      articlemeta.SPMname = remove_linebreaksAndSpace(
        spmDetails[0].contactname,
      );
    }

    if (articletype?.[0]?.otherdetails?.isMultiEditor) {
      const editorInfo =
        workorderContacts?.filter(
          x => x.contactrole === 'EC' || x.contactrole === 'E',
        ) || [];

      if (editorInfo.length > 1) {
        const editorMail = editorInfo
          .map(list => remove_linebreaksAndSpace(list.contactemail))
          .join(';');

        articlemeta.Editoremailid = editorMail;
        articlemeta.AdditionalEditorMail = '';
        articlemeta.Editorname = 'Editors';
      }
    }

    // CUP journals Tranch-6 ENG/NCM journal update start
    if (
      mstJournal.length > 0 &&
      mstJournal[0]?.otherdetails?.isTranche &&
      articletype?.[0]?.customerid === '8'
    ) {
      const journalId = mstJournal[0].journalid;
      const woarticleType = Filename?.[0]?.otherfield?.articletype || '';

      console.log('Filename:', Filename);
      console.log('Journal ID:', journalId);

      const woSql = `SELECT * FROM get_journal_article_type($1, $2)`;
      const result = await query(woSql, [journalId, woarticleType]);

      if (result && result.length > 0) {
        const mailInfo = result[0];

        articlemeta.Editoremailid = mailInfo.contactemail;
        articlemeta.Editorname = mailInfo.contactname;
        articlemeta.AdditionalEditorMail = '';

        if (Array.isArray(SequenceDetails)) {
          const iauthorActivity = SequenceDetails.find(
            list =>
              list.ActivityID == '84' &&
              Array.isArray(list.userDetails) &&
              list.userDetails.length > 0,
          );

          if (iauthorActivity) {
            iauthorActivity.userDetails[0].Email = mailInfo.contactemail;
            iauthorActivity.userDetails[0].UserName = mailInfo.contactname;
          }
        }
      } else {
        throw new Error(
          'Journal article type mail info missing. Please contact the IWMS admin.',
        );
      }
    }

    // end

    const iAuthorInputData = {
      isNewWMS: true,
      NLPGuid,
      supplementary: SupplimentryFiles,
      JobType: mstJournal[0].wotype,
      CustomerID: mstJournal[0].iauthcustomerid,
      isEDAjrnl: 0,
      ProofType: 'A',
      PEUser: {
        UserName: remove_linebreaksAndSpace(peDetails[0].contactname),
        Email: remove_linebreaksAndSpace(peDetails[0].contactemail),
      },
      JourFileToUpload: [],
      JournalDetails: {
        journalcode: mstJournal[0].journalacronym,
        journalname: mstJournal[0].journalname,
        journaltitle: mstJournal[0].journalname,
        journaltoc: [
          {
            ArticleGUID: null,
            title: mstJournal[0].articletitle,
            orderid: 1,
            type: null,
            code:
              mstJournal[0].customerid == 8
                ? `${mstJournal[0].journalacronym}_${mstJournal[0].pii}`
                : Filename[0].filename,
            FileName:
              mstJournal[0].customerid == 8
                ? `${mstJournal[0].journalacronym}_${mstJournal[0].pii}`
                : Filename[0].filename,
            IsOnshore: 0,
          },
        ],
      },
      workflowDetails: {
        isNeedActivitySkip:
          iAuthorWorkFlow[0].sequencedetails.isNeedActivitySkip,
        RevisionCount: mstJournal[0].stageiterationcount,
        WorkflowID: mstJournal[0].iauthworkflowid,
        SequenceDetails,
      },
      articlemeta,
      conversion_id:
        iAuthorWorkFlow[0]?.compoulsaryrole?.isACSConversion ===
        req.body.stage.id
          ? 1
          : iAuthorWorkFlow[0]?.compoulsaryrole?.isConversionId
          ? 2
          : 1,

      skipFileValidation,
    };
    switch (dmsType) {
      case 'azure':
        const awt = [];
        awt.push(azureHelper._download(inputXML[0].repofilepath));
        // awt.push(azureHelper._download(inputXML[0].repofilepath));
        const out = await Promise.all(awt);
        iAuthorInputData.JourFileToUpload.push({
          isArticle: true,
          url: out[0].data.path,
          Code:
            mstJournal[0].customerid == 8
              ? `${mstJournal[0].journalacronym}_${mstJournal[0].pii}`
              : Filename[0].filename,
        });
        if (logXML.length > 0) {
          iAuthorInputData.JourFileToUpload.push({
            isArticle: false,
            url: out[0].data.path,
            Code: Filename[0].filename,
          });
        }
        break;
      case 'local':
        const awt1 = [];
        awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
        // awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
        if (
          'isACS' in iAuthorWorkFlow[0].compoulsaryrole &&
          logXML.length > 0
        ) {
          awt1.push(localHelper._localdownload(logXML[0].repofilepath));
        } else if (logXML.length) {
          awt1.push(localHelper._localdownload(logXML[0].repofilepath));
        }

        const out1 = await Promise.all(awt1);
        iAuthorInputData.JourFileToUpload.push({
          isArticle: true,
          url: out1[0].data.path,
          Code: Filename[0].filename,
        });
        if (logXML.length > 0) {
          iAuthorInputData.JourFileToUpload.push({
            isArticle: false,
            url: out1[1].data.path,
            Code: `${Filename[0].filename}`,
          });
        }
        break;
      default:
        iAuthorInputData.JourFileToUpload.push({
          isArticle: true,
          url:
            config.openKM.base_out_url +
            config.openKM.uri.download +
            inputXML[0].repofileuuid,
          Code: Filename[0].filename,
        });
        if (logXML.length > 0) {
          iAuthorInputData.JourFileToUpload.push({
            isArticle: false,
            url:
              config.openKM.base_out_url +
              config.openKM.uri.download +
              logXML[0].repofileuuid,
            Code: Filename[0].filename,
          });
        }
        break;
    }
    const configAPI = {
      method: 'post',
      // url:`http://bv-s125:7070/integra/ips/ijps/v2/wms-jrnl-createjob-new`,
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.createjob
      }`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data: JSON.stringify(iAuthorInputData),
    };
    axios(configAPI)
      .then(async function (response) {
        try {
          sql = `select * from insert_iauthortran('${JSON.stringify({
            workorderid: (workOrderId || '').toString(),
            stageid: (stage.id || '').toString(),
            serviceid: (service.id || '').toString(),
            guid: (response.data.data.jobid || '').toString(),
            stageiterationcount: (stage.stageiterationcount || 1).toString(),
          })}')`;
          await query(sql);
          res.status(200).send(response.data);
        } catch (error) {
          res.status(400).send({ is_success: false, message: error.message });
        }
      })
      .catch(function (error) {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};
export const iAuthorLinkGenerationwithoutCamundaTool = async (req, res) => {
  const {
    workOrderId,
    stageId,
    stageName,
    activityName,
    serviceId,
    eventId,
    stageIterationCount,
    customername,
    customerid,
    activityId,
  } = req.body;
  try {
    const skipFileValidation = false;
    let graphicEvtId = null;
    let iAuthorImgRes = {};
    if (eventId) {
      const sql1 = `
      SELECT a.baseduid, a.wfid, b.duname
      FROM wms_workorder_service a
      JOIN org_mst_deliveryunit b ON b.duid = a.baseduid
      WHERE workorderid = $1
      ORDER BY woserviceid
    `;
      const [responseData] = await query(sql1, [workOrderId]);
      if (responseData) {
        const { baseduid: duId, duname } = responseData;
        req.body.wfId = responseData.wfid;
        console.log(responseData, 'responseData');

        iAuthorImgRes = await getiAuthorImgsWithoutCamunda(req);

        if (graphicEvtId != null || iAuthorImgRes?.isSuccess == true) {
          graphicEvtId =
            iAuthorImgRes && iAuthorImgRes.graphicDetails
              ? iAuthorImgRes.graphicDetails.wfeventid
              : null;

          const dmsType = await getdmsType(workOrderId);

          const SupplimentryFiles = [];
          let graphicPath;
          let sql = `select  COALESCE(d.typesetpages,0) as typesetpages, a.itemcode,a.otherfield ->>'articleno' as articleno, doinumber as articlename,title as articletitle,b.isiauthor, 
        c.iauthorworkflowid,a.wotype, b.journalacronym, b.journalname ,c.iauthcustomerid ,d.stageiterationcount,
        b.iauthworkconversionflowid,c.compulsaryrole,c.sequencedetails
        from wms_workorder a 
        join public.pp_mst_journal b on a.journalid=b.journalid 
        join public.wms_workorder_Stage d on d.workorderid=a.workorderid
        left join public.iauthor_new_workflow c on  c.stageid=d.wfstageid and c.journalid = b.journalid
        where a.workorderid=${workOrderId} and d.wfstageid=${stageId}
        AND (c.wmsactivityid IS NULL OR c.wmsactivityid = ${activityId}) 
         and c.wfid=${req.body.wfId}`;

          const mstJournal = await query(sql);
          if (mstJournal.length == 0) {
            throw new Error(`invalid workorderid : ${workOrderId}`);
          }

          const piiSql = `SELECT otherfield->>'pii' AS piivalue from wms_workorder
          WHERE workorderid = ${workOrderId}`;
          const piiDetails = await query(piiSql);
          const piiValue = piiDetails[0]?.piivalue || null;

          const basePathPayload = {
            dmsType,
            du: {
              name: duname,
              id: duId,
            },
            customer: {
              name: customername,
              id: customerid,
            },
          };
          const placeHolders = await getWorkflowPlaceHolders(eventId);

          let serverbasepath = await getBasePath(basePathPayload);
          serverbasepath = getFormattedName(serverbasepath, {
            ...placeHolders,
          });
          const destinationString = `${serverbasepath}${mstJournal[0].itemcode}/${stageName}/${activityName}/${mstJournal[0].itemcode}`;
          let iauthPath = destinationString.replace(/ /g, '_');
          iauthPath = iauthPath.replace(/\//g, '\\');

          const graphicSql = `select localgraphicfilepath from wms_mst_customerconfigdetails where customerid = ${customerid} and duid= ${duId}`;
          const graphicDetail = await query(graphicSql);
          if (graphicDetail && graphicDetail.length > 0) {
            const graphicPathDetail = graphicDetail[0].localgraphicfilepath;
            graphicPath = getFormattedName(graphicPathDetail, {
              ...placeHolders,
            });
          }

          //  let iauthPath1 = '\\\\integrafs2\\ElsJournals\\02_WMS_dev\\INTCON\\INTCON00686\\S5\\iAuthor_link_generation\\INTCON00686\\';
          //  let graphicPath = `\\\\integrafs2\\ElsJournals\\02-WMS-Graphics\\INTCON\\01_Upload\\INTCON00687\\`;
          const eventDetails = await _retreiveLocalFiles(iauthPath);
          let additionalFiles = await _retreiveLocalFiles(graphicPath);
          if (req.body?.wfId == 43) {
            additionalFiles = additionalFiles.filter(
              item => !item.path.includes('Print/'),
            );
          }
          const supplementaryArray = [];
          additionalFiles.forEach(element => {
            element.FileName = path.basename(element.path);

            switch (dmsType) {
              case 'azure':
                supplementaryArray.push(azureHelper._download(element.path));
                break;
              case 'local':
                supplementaryArray.push(
                  localHelper._localdownload(element.path),
                );
                break;
              default:
                supplementaryArray.push({
                  path:
                    config.openKM.base_out_url +
                    config.openKM.uri.download +
                    element.repofileuuid,
                });
                break;
            }
          });
          const graphicsSupplementary = await Promise.all(supplementaryArray);
          graphicsSupplementary.forEach(ele => {
            SupplimentryFiles.push({
              flag: 'article_resource',
              url: ele.path ? ele.path : ele.data.path,
              type: 'figure',
            });
          });
          // }
          if (eventDetails.length == 0) {
            throw new Error(
              `File mapping missing for workorderid : ${eventId}`,
            );
          }

          sql = `Select incf.filename from public.wms_workorder_incoming as inc
          left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
          where woid=${workOrderId}`;
          const Filename = await query(sql);

          const iAuthsupplementaryArray = [];
          eventDetails.forEach(element => {
            element.FileName = path.basename(element.path);
            if (element.path.includes('/Supplementary_Folder/')) {
              switch (dmsType) {
                case 'azure':
                  iAuthsupplementaryArray.push(
                    azureHelper._download(element.path),
                  );
                  break;
                case 'local':
                  iAuthsupplementaryArray.push(
                    localHelper._localdownload(element.path),
                  );
                  break;
                default:
                  iAuthsupplementaryArray.push({
                    path:
                      config.openKM.base_out_url +
                      config.openKM.uri.download +
                      element.repofileuuid,
                  });
                  break;
              }
            }
          });
          const iAuthsupplementary = await Promise.all(iAuthsupplementaryArray);
          iAuthsupplementary.forEach(ele => {
            SupplimentryFiles.push({
              flag: 'article_resource',
              url: ele.path ? ele.path : ele.data.path,
              type: 'supplementary',
            });
          });
          const iAuthFileSql = `select filename from public.iauthor_new_workflow  where duid =${duId} and wfid =${req.body.wfId} and stageId=${stageId} and wmsactivityid=${activityId}`;
          const iAuthFileData = await query(iAuthFileSql);
          const iAuthDetails = iAuthFileData?.[0]?.filename?.files;

          const requiredFiles = {};
          if (!iAuthDetails) {
            throw new Error(
              `Mandatory File configuration missing. Please check.`,
            );
          } else {
            // Filter the required files from iAuthor, and form a json
            iAuthDetails.forEach(iAuthorDetil => {
              if (iAuthorDetil.required) {
                const name = getFormattedName(iAuthorDetil.name, {
                  ...placeHolders,
                });
                requiredFiles[name] = iAuthorDetil.isArticle; // set isArticle value for each files
              }
            });
          }

          const activityFiles = [];
          eventDetails.forEach(eachEvent => {
            // if (requiredFiles.hasOwnProperty(eachEvent.FileName)) {
            if (
              !eachEvent.path.includes('/Supplementary_Folder/') &&
              eachEvent.FileName in requiredFiles
            ) {
              activityFiles.push({
                ...eachEvent,
                isArticle: requiredFiles[eachEvent.FileName],
              });
            }
          });
          const graphicInputFiles = [];

          additionalFiles.forEach(eachGrphics => {
            // to add log.xml from graphics
            if (eachGrphics.FileName in requiredFiles) {
              graphicInputFiles.push({
                ...eachGrphics,
                isArticle: requiredFiles[eachGrphics.FileName],
              });
            }
          });

          const overallReqFiles = [...activityFiles, ...graphicInputFiles];
          const iAuthFiles = eventDetails.map(f => f.FileName);
          const graphicFiles = additionalFiles.map(f => f.FileName);

          Object.keys(requiredFiles).forEach(reqFile => {
            if (
              !iAuthFiles.includes(reqFile) &&
              !graphicFiles.includes(reqFile)
            ) {
              throw new Error(`Error: ${reqFile} is missing`);
            }
          });

          sql = `SELECT guid FROM inlp_transactions 
          WHERE workorderid = ${workOrderId}
          AND stageid = ${stageId}
          AND serviceid = ${serviceId}
          AND stageiterationcount = ${mstJournal[0].stageiterationcount} order by inlptrnsid limit 1`;
          let NLPGuid = await query(sql);
          if (NLPGuid.length > 0) {
            NLPGuid = NLPGuid[0].guid;
          } else {
            NLPGuid = undefined;
          }
          sql = `select contactname ,contactemail ,contactrole from public.wms_workorder_contacts 
                  where workorderid=${workOrderId} order by wocontactid`;
          const workorderContacts = await query(sql);
          if (workorderContacts.length == 0) {
            throw new Error(`Workorder Contacts are missing.`);
          }

          if (
            mstJournal[0].typesetpages == 0 &&
            mstJournal[0].compulsaryrole?.skipTypesetPageCount != 'true'
          ) {
            throw new Error(`Typeset Pages not updated.`);
          }

          const peDetails =
            mstJournal[0]?.compulsaryrole.isACS == 'true'
              ? workorderContacts.filter(
                  x =>
                    x.contactrole == 'PED' ||
                    x.contactrole == 'CM' ||
                    x.contactrole == 'PM',
                )
              : workorderContacts.filter(
                  x => x.contactrole == 'PED' || x.contactrole == 'CM',
                );

          const authorDetails = workorderContacts.filter(
            x => x.contactrole == 'AUTHOR',
          );
          const EditorDetails = workorderContacts.filter(
            x => x.contactrole == 'EC' || x.contactrole == 'E',
          );
          const spmDetails = workorderContacts.filter(
            x => x.contactrole == 'SPM',
          );
          if (peDetails.length == 0) {
            throw new Error('Production Editor is not mapped.');
          }

          const SequenceDetails = [];
          for (const activity of mstJournal[0].sequencedetails.activities) {
            if (activity.contactrole == 'DEFAULT') {
              SequenceDetails.push({
                ActivityID: activity.ActivityID,
                RoleID: activity.RoleID,
                userDetails: [
                  {
                    UserName: 'admin',
                    Email: 'admin@integra.co.in',
                  },
                ],
              });
            } else {
              const user = workorderContacts.filter(
                x => x.contactrole == activity.contactrole,
              );
              if (user.length == 0) {
                throw new Error(
                  `Workorder Contacts are missing for ${activity.contactrole}`,
                );
              }
              SequenceDetails.push({
                ActivityID: activity.ActivityID,
                RoleID: activity.RoleID,
                userDetails: [
                  {
                    UserName: remove_linebreaksAndSpace(user[0].contactname),
                    Email: remove_linebreaksAndSpace(user[0].contactemail),
                  },
                ],
              });
            }
          }
          const articlemeta = {
            manuscriptid:
              Filename[0].filename.match(/\d+/)?.[0].replace(/^0+/, '') || '',
            manuscripttitle: mstJournal[0].articletitle,
            DOI: Filename[0].filename,
            journaltitle: mstJournal[0].journalname,
            Articlenumber: Filename[0].filename,
            Pageno: mstJournal[0].typesetpages,
            PIIValue: piiValue,
          };

          if (authorDetails.length > 0) {
            articlemeta.Authoremail = remove_linebreaksAndSpace(
              authorDetails[0].contactemail,
            );
            articlemeta.Authorname = remove_linebreaksAndSpace(
              authorDetails[0].contactname,
            );
          }
          if (peDetails.length > 0) {
            articlemeta.Pemailid = remove_linebreaksAndSpace(
              peDetails[0].contactemail,
            );
            articlemeta.Pename = remove_linebreaksAndSpace(
              peDetails[0].contactname,
            );
          }
          if (EditorDetails.length > 0) {
            if (EditorDetails.length > 1) {
              const additionalEditor = EditorDetails.splice(
                1,
                EditorDetails.length,
              );
              articlemeta.AdditionalEditorMail = additionalEditor
                .map(x => remove_linebreaksAndSpace(x.contactemail))
                .join(';');
            }
            articlemeta.Editoremailid = remove_linebreaksAndSpace(
              EditorDetails[0].contactemail,
            );
            articlemeta.Editorname = remove_linebreaksAndSpace(
              EditorDetails[0].contactname,
            );
          }
          if (spmDetails.length > 0) {
            articlemeta.SPMemailid = remove_linebreaksAndSpace(
              spmDetails[0].contactemail,
            );
            articlemeta.SPMname = remove_linebreaksAndSpace(
              spmDetails[0].contactname,
            );
          }
          let revisionCount = mstJournal[0]?.stageiterationcount;
          if (stageId == '123' || stageId == '124') {
            revisionCount = Number(mstJournal[0].stageiterationcount) + 1;
          }
          const iAuthorInputData = {
            isNewWMS: true,
            NLPGuid,
            supplementary: SupplimentryFiles,
            JobType: mstJournal[0].wotype,
            CustomerID: mstJournal[0].iauthcustomerid,
            isEDAjrnl: 0,
            ProofType: 'A',
            PEUser: {
              UserName: remove_linebreaksAndSpace(peDetails[0].contactname),
              Email: remove_linebreaksAndSpace(peDetails[0].contactemail),
            },
            JourFileToUpload: [],
            JournalDetails: {
              journalcode: mstJournal[0].journalacronym,
              journalname: mstJournal[0].journalacronym,
              journaltitle: mstJournal[0].journalname,
              journaltoc: [
                {
                  ArticleGUID: null,
                  title: mstJournal[0].articletitle,
                  orderid: 1,
                  type: null,
                  code: Filename[0].filename,
                  FileName: Filename[0].filename,
                  IsOnshore: 0,
                },
              ],
            },
            workflowDetails: {
              isNeedActivitySkip:
                mstJournal[0].sequencedetails.isNeedActivitySkip,
              RevisionCount: revisionCount,
              WorkflowID: mstJournal[0].iauthorworkflowid,
              SequenceDetails,
            },
            articlemeta,
            conversion_id: mstJournal[0]?.compulsaryrole?.isConversionId ?? 1,
            skipFileValidation,
          };
          let filePath;
          switch (dmsType) {
            case 'azure':
              break;

            case 'local':
              for (const file of overallReqFiles) {
                filePath = await localHelper._localdownload(file.path);
                iAuthorInputData.JourFileToUpload.push({
                  isArticle: file.isArticle,
                  url: filePath.path ? filePath.path : filePath.data.path,
                  Code: Filename[0].filename,
                });
              }
              break;

            default:
              for (const file of overallReqFiles) {
                filePath = await localHelper._localdownload(file.path);
                iAuthorInputData.JourFileToUpload.push({
                  isArticle: file.isArticle,
                  url: filePath.path ? filePath.path : filePath.data.path,
                  Code: Filename[0].filename,
                });
              }
              break;
          }

          const configAPI = {
            method: 'post',
            // url: "http://bv-s125:7070/integra/ips/ijps/v2/wms-jrnl-createjob-new",
            url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
              config.iAuthor.createjob
            }`,
            headers: {
              'Content-Type': 'application/json',
              clientid: config.iAuthor.clientid,
              apikey: config.iAuthor.apikey,
            },
            data: JSON.stringify(iAuthorInputData),
          };
          axios(configAPI)
            .then(async function (response) {
              try {
                sql = `select * from insert_iauthortran('${JSON.stringify({
                  workorderid: (workOrderId || '').toString(),
                  stageid: (stageId || '').toString(),
                  serviceid: (serviceId || '').toString(),
                  guid: (response.data.data.jobid || '').toString(),
                  stageiterationcount: (stageIterationCount || 1).toString(),
                })}')`;
                await query(sql);
                if (
                  (stageId == '122' || stageId == '124') &&
                  customerid == '14' &&
                  (mstJournal[0]?.iauthorworkflowid == '84' ||
                    mstJournal[0]?.iauthorworkflowid == '85')
                ) {
                  const redyxmlPayload = {
                    article_guid: response.data.data.jobid,
                    iAuthorLink: response.data.data.link,
                  };

                  await _dispatchFromIauthor(redyxmlPayload);
                }
                res.status(200).send(response.data);
              } catch (error) {
                res
                  .status(400)
                  .send({ is_success: false, message: error.message });
              }
            })
            .catch(function (error) {
              if (error.response) {
                res.status(400).send(error.response.data);
              } else {
                res
                  .status(400)
                  .send({ is_success: false, message: error.message });
              }
            });
        } else {
          // payload.log =
          // 'iAuthor Image Conversion in Graphics stage is not completed';
          res.status(200).send({
            completeTask: true,
            error:
              'iAuthor Image Conversion in Graphics stage is not completed',
            isSuccess: false,
          });
        }
      } else {
        throw new Error('No data found for the given workOrderId');
      }
    }
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};
export const getiAuthorImgsWithoutCamunda = async req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workOrderId, wfId, wfdefId } = req.body;
      const sql = `select fileconfig from wms_workflowdefinition where wfid = ${wfId} and wfdefid = ${wfdefId}`;
      const data = await query(sql);
      const imageCopy = data[0].fileconfig.files
        ? data[0].fileconfig.files.filter(
            file =>
              (file.custom || []).filter(
                x => x.toLocaleLowerCase() === 'copygraphicsfile',
              ).length > 0,
          )
        : 0;

      if (imageCopy && imageCopy.length > 0) {
        const graphicEnabledActivities = [];

        let chkApiin = 0;
        const graphicswfdefids = imageCopy[0].customwfdefid;
        if (graphicswfdefids.length > 0) {
          for (let i = 0; i < graphicswfdefids.length; i++) {
            console.log(graphicswfdefids[i], 'sdfsfdj');
            if (chkApiin == 0) {
              chkApiin = 1;
              const payload = {
                activityName: '',
                wfdefid: graphicswfdefids[i],
              };
              const details = await getGraphicStageActivityDetailsTool(payload);
              console.log(details, 'sdfsdfsd');
              if (Array.isArray(details)) {
                details.forEach((_details, index) => {
                  if (index == 0) {
                    graphicEnabledActivities.push(_details);
                  }
                });
              } else if (Object.keys(details).length > 0) {
                graphicEnabledActivities.push(details);
              }
              console.log(graphicEnabledActivities, 'graphicEnabledActivities');
              for (let j = 0; j < graphicEnabledActivities.length; j++) {
                try {
                  // const Url = apiConfig.server.uri.getGraphicIterationDetail;
                  const filePayload = {
                    stageId: graphicEnabledActivities[j].stageId,
                    activityId: graphicEnabledActivities[j].activityId,
                    woId: workOrderId,
                    needOnlyCompleted: true,
                  };
                  // const hdr = {
                  //   Authorization: `Bearer ${process.env.SERVER_TOKEN}`,
                  // };
                  // const graphicItDetails = await post(
                  //   `${apiConfig.server.baseUrl}${Url}`,
                  //   filePayload,
                  //   hdr,
                  // );
                  const graphicItDetails = await getGraphicIterationDetailTool(
                    filePayload,
                  );
                  console.log(graphicItDetails, 'graphicItDetails');

                  if (Object.keys(graphicItDetails).length > 0) {
                    resolve({
                      graphicDetails: graphicItDetails[0],
                      isSuccess: true,
                    });
                  } else {
                    resolve({
                      completeTask: true,
                      error:
                        'iAuthor Image Conversion in Graphics stage is not completed',
                      isSuccess: false,
                    });
                  }
                } catch (error) {
                  resolve({ completeTask: true, error, isSuccess: false });
                }
              }
            }
          }
        }
      } else {
        resolve({ isSuccess: true, message: 'without graphic images' });
      }
    } catch (error) {
      reject(error);
    }
  });
};
// export const iAuthorLinkGenerationTool = async (req, res) => {
//   const {
//     workOrderId,
//     stageId,
//     serviceId,
//     eventId,
//     stageIterationCount,
//     wfdefId,
//   } = req.body;
//   try {
//     // wfId,
//     // duId,

//     const skipFileValidation = false;
//     let graphicEvtId = null;
//     let iAuthorImgRes = {};
//     let duId = '';
//     let variables;

//     if (eventId) {
//       const sql1 = `select baseduid,wfid from wms_workorder_service where workorderid = ${workOrderId} order by woserviceid desc limit 10`;
//       const response = await query(sql1);
//       duId = response[0].baseduid;
//       req.body.wfId = response[0].wfid;
//       console.log(response, 'response');

//       const sql = `
//       SELECT eventdata->'variables' as variables
//       FROM wms_workflow_eventlog
//       WHERE wfdefid =${wfdefId} and workorderid =${workOrderId} and wfeventid = ${eventId}
//       ORDER BY wfeventid DESC`;
//       const data = await query(sql);
//       variables = data?.[0]?.variables;
//       console.log(variables, 'variable');
//     }

//     iAuthorImgRes = await getiAuthorImgs(req);

//     const acsgraphicscondition = duId;
//     if (acsgraphicscondition == '92' && variables.__isGraphic__ === true) {
//       variables.__isGraphic__ = false;
//     }

//     if (
//       variables.__isGraphic__ == false ||
//       graphicEvtId != null ||
//       iAuthorImgRes.isSuccess == true
//     ) {
//       graphicEvtId =
//         iAuthorImgRes && iAuthorImgRes.graphicDetails
//           ? iAuthorImgRes.graphicDetails.wfeventid
//           : null;

//       const dmsType = await getdmsType(workOrderId);
//       const SupplimentryFiles = [];
//       let sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map
//                       where wfeventid=${eventId}`;

//       const eventDetails = await query(sql);
//       let additionalFiles;

//       if (graphicEvtId != null) {
//         sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map
//                       where wfeventid =${graphicEvtId} and repofilepath not like '%.eps'`;
//         additionalFiles = await query(sql);
//         const supplementaryArray = [];
//         additionalFiles.forEach(element => {
//           element.FileName = path.basename(element.repofilepath);
//           switch (dmsType) {
//             case 'azure':
//               supplementaryArray.push(
//                 azureHelper._download(element.repofilepath),
//               );
//               break;
//             case 'local':
//               supplementaryArray.push(
//                 localHelper._localdownload(element.repofilepath),
//               );
//               break;
//             default:
//               supplementaryArray.push({
//                 path:
//                   config.openKM.base_out_url +
//                   config.openKM.uri.download +
//                   element.repofileuuid,
//               });
//               break;
//           }
//         });
//         const supplementary = await Promise.all(supplementaryArray);
//         supplementary.forEach(ele => {
//           SupplimentryFiles.push({
//             flag: 'article_resource',
//             url: ele.path ? ele.path : ele.data.path,
//           });
//         });
//       }
//       if (eventDetails.length == 0) {
//         throw new Error(`File mapping missing for workorderid : ${eventId}`);
//       }
//       let iAuthorWorkFlowField = '';
//       switch (stageId) {
//         case '13':
//           iAuthorWorkFlowField = 'b.copyeditingworkflow';
//           break;
//         case '72':
//           iAuthorWorkFlowField = 'b.iauthworkconversionflowid';
//           break;
//         default:
//           iAuthorWorkFlowField = 'b.iauthworkflowid';
//           break;
//       }
//       sql = `select  COALESCE(d.typesetpages,0) as typesetpages, a.otherfield ->>'articleno' as articleno, doinumber as articlename,title as articletitle,b.isiauthor,
//                   ${iAuthorWorkFlowField} as iauthworkflowid,a.wotype, b.journalacronym, b.journalname ,c.iauthcustomerid ,d.stageiterationcount,
//                   b.iauthworkconversionflowid
//                   from wms_workorder a
//                   join public.pp_mst_journal b on a.journalid=b.journalid
//                   join public.wms_workorder_Stage d on d.workorderid=a.workorderid
//                   left join public.iauthor_mst_customer c on c.custorgmapid=b.custorgmapid
//                   where a.workorderid=${workOrderId} and d.wfstageid=${stageId}`;
//       const mstJournal = await query(sql);
//       sql = `Select incf.filename from public.wms_workorder_incoming as inc
//           left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
//           where woid=${workOrderId}`;
//       const Filename = await query(sql);
//       if (mstJournal.length == 0) {
//         throw new Error(`invalid workorderid : ${workOrderId}`);
//       }

//       const supplementaryArray = [];
//       eventDetails.forEach(element => {
//         element.FileName = path.basename(element.repofilepath);
//         switch (dmsType) {
//           case 'azure':
//             supplementaryArray.push(
//               azureHelper._download(element.repofilepath),
//             );
//             break;
//           case 'local':
//             supplementaryArray.push(
//               localHelper._localdownload(element.repofilepath),
//             );
//             break;
//           default:
//             supplementaryArray.push({
//               path:
//                 config.openKM.base_out_url +
//                 config.openKM.uri.download +
//                 element.repofileuuid,
//             });
//             break;
//         }
//       });
//       const supplementary = await Promise.all(supplementaryArray);
//       supplementary.forEach(ele => {
//         SupplimentryFiles.push({
//           flag: 'article_resource',
//           url: ele.path ? ele.path : ele.data.path,
//         });
//       });
//       const inputXML = eventDetails.filter(
//         x => x.FileName == `${Filename[0].filename}.xml`,
//       );
//       let logXML =
//         additionalFiles && additionalFiles.length
//           ? additionalFiles.filter(
//               x => x.FileName == `${Filename[0].filename}_log.xml`,
//             )
//           : [];
//       if (logXML.length == 0) {
//         logXML = eventDetails.filter(
//           x => x.FileName == `${Filename[0].filename}_log.xml`,
//         );
//       }

//       if (inputXML.length == 0) {
//         throw new Error(`${`${Filename[0].filename}.xml`} file missing.`);
//       }
//       sql = `SELECT guid FROM inlp_transactions
//           WHERE workorderid = ${workOrderId}
//           AND stageid = ${stageId}
//           AND serviceid = ${serviceId}
//           AND stageiterationcount = ${mstJournal[0].stageiterationcount} order by inlptrnsid limit 1`;
//       let NLPGuid = await query(sql);
//       if (NLPGuid.length > 0) {
//         NLPGuid = NLPGuid[0].guid;
//       } else {
//         NLPGuid = undefined;
//       }
//       sql = `select contactname ,contactemail ,contactrole from public.wms_workorder_contacts
//                   where workorderid=${workOrderId} order by wocontactid`;
//       const workorderContacts = await query(sql);
//       if (workorderContacts.length == 0) {
//         throw new Error(`Workorder Contacts are missing.`);
//       }

//       sql = `select * from public.iauthor_workflow
//                   where iauthworkflowid=${mstJournal[0].iauthworkflowid}`;
//       const iAuthorWorkFlow = await query(sql);
//       if (iAuthorWorkFlow.length == 0) {
//         throw new Error(
//           `iAuthorWorkFlow is not mapped for this journal (${mstJournal[0].journalacronym})`,
//         );
//       } else if (
//         mstJournal[0].typesetpages == 0 &&
//         iAuthorWorkFlow[0].compoulsaryrole?.skipTypesetPageCount != 'true'
//       ) {
//         throw new Error(`Typeset Pages not updated.`);
//       }

//       const peDetails =
//         iAuthorWorkFlow[0]?.compoulsaryrole.isACS == 'true'
//           ? workorderContacts.filter(
//               x =>
//                 x.contactrole == 'PED' ||
//                 x.contactrole == 'CM' ||
//                 x.contactrole == 'PM',
//             )
//           : workorderContacts.filter(
//               x => x.contactrole == 'PED' || x.contactrole == 'CM',
//             );

//       const authorDetails = workorderContacts.filter(
//         x => x.contactrole == 'AUTHOR',
//       );
//       const EditorDetails = workorderContacts.filter(
//         x => x.contactrole == 'EC' || x.contactrole == 'E',
//       );
//       const spmDetails = workorderContacts.filter(x => x.contactrole == 'SPM');
//       if (peDetails.length == 0) {
//         throw new Error('Production Editor is not mapped.');
//       }

//       const SequenceDetails = [];
//       for (const activity of iAuthorWorkFlow[0].sequencedetails.activities) {
//         if (activity.contactrole == 'DEFAULT') {
//           SequenceDetails.push({
//             ActivityID: activity.ActivityID,
//             RoleID: activity.RoleID,
//             userDetails: [
//               {
//                 UserName: 'admin',
//                 Email: 'admin@integra.co.in',
//               },
//             ],
//           });
//         } else {
//           const user = workorderContacts.filter(
//             x => x.contactrole == activity.contactrole,
//           );
//           if (user.length == 0) {
//             throw new Error(
//               `Workorder Contacts are missing for ${activity.contactrole}`,
//             );
//           }
//           SequenceDetails.push({
//             ActivityID: activity.ActivityID,
//             RoleID: activity.RoleID,
//             userDetails: [
//               {
//                 UserName: remove_linebreaksAndSpace(user[0].contactname),
//                 Email: remove_linebreaksAndSpace(user[0].contactemail),
//               },
//             ],
//           });
//         }
//       }
//       const articlemeta = {
//         manuscriptid: Filename[0].filename,
//         manuscripttitle: mstJournal[0].articletitle,
//         DOI: Filename[0].filename,
//         journaltitle: mstJournal[0].journalname,
//         Articlenumber: mstJournal[0].articleno,
//         Pageno: mstJournal[0].typesetpages,
//       };

//       if (authorDetails.length > 0) {
//         articlemeta.Authoremail = remove_linebreaksAndSpace(
//           authorDetails[0].contactemail,
//         );
//         articlemeta.Authorname = remove_linebreaksAndSpace(
//           authorDetails[0].contactname,
//         );
//       }
//       if (peDetails.length > 0) {
//         articlemeta.Pemailid = remove_linebreaksAndSpace(
//           peDetails[0].contactemail,
//         );
//         articlemeta.Pename = remove_linebreaksAndSpace(
//           peDetails[0].contactname,
//         );
//       }
//       if (EditorDetails.length > 0) {
//         if (EditorDetails.length > 1) {
//           const additionalEditor = EditorDetails.splice(
//             1,
//             EditorDetails.length,
//           );
//           articlemeta.AdditionalEditorMail = additionalEditor
//             .map(x => remove_linebreaksAndSpace(x.contactemail))
//             .join(';');
//         }
//         articlemeta.Editoremailid = remove_linebreaksAndSpace(
//           EditorDetails[0].contactemail,
//         );
//         articlemeta.Editorname = remove_linebreaksAndSpace(
//           EditorDetails[0].contactname,
//         );
//       }
//       if (spmDetails.length > 0) {
//         articlemeta.SPMemailid = remove_linebreaksAndSpace(
//           spmDetails[0].contactemail,
//         );
//         articlemeta.SPMname = remove_linebreaksAndSpace(
//           spmDetails[0].contactname,
//         );
//       }
//       const iAuthorInputData = {
//         isNewWMS: true,
//         NLPGuid,
//         supplementary: SupplimentryFiles,
//         JobType: mstJournal[0].wotype,
//         CustomerID: mstJournal[0].iauthcustomerid,
//         isEDAjrnl: 0,
//         ProofType: 'A',
//         PEUser: {
//           UserName: remove_linebreaksAndSpace(peDetails[0].contactname),
//           Email: remove_linebreaksAndSpace(peDetails[0].contactemail),
//         },
//         JourFileToUpload: [],
//         JournalDetails: {
//           journalcode: mstJournal[0].journalacronym,
//           journalname: mstJournal[0].journalname,
//           journaltitle: mstJournal[0].journalname,
//           journaltoc: [
//             {
//               ArticleGUID: null,
//               title: mstJournal[0].articletitle,
//               orderid: 1,
//               type: null,
//               code: Filename[0].filename,
//               FileName: Filename[0].filename,
//               IsOnshore: 0,
//             },
//           ],
//         },
//         workflowDetails: {
//           isNeedActivitySkip:
//             iAuthorWorkFlow[0].sequencedetails.isNeedActivitySkip,
//           RevisionCount: mstJournal[0].stageiterationcount,
//           WorkflowID: mstJournal[0].iauthworkflowid,
//           SequenceDetails,
//         },
//         articlemeta,
//         conversion_id:
//           iAuthorWorkFlow[0]?.compoulsaryrole?.isACSConversion ===
//           req.body.stageId
//             ? 1
//             : iAuthorWorkFlow[0]?.compoulsaryrole?.isConversionId
//             ? 2
//             : 1,

//         skipFileValidation,
//       };
//       switch (dmsType) {
//         case 'azure':
//           const awt = [];
//           awt.push(azureHelper._download(inputXML[0].repofilepath));
//           // awt.push(azureHelper._download(inputXML[0].repofilepath));
//           const out = await Promise.all(awt);
//           iAuthorInputData.JourFileToUpload.push({
//             isArticle: true,
//             url: out[0].data.path,
//             Code: Filename[0].filename,
//           });
//           if (logXML.length > 0) {
//             iAuthorInputData.JourFileToUpload.push({
//               isArticle: false,
//               url: out[0].data.path,
//               Code: Filename[0].filename,
//             });
//           }
//           break;
//         case 'local':
//           const awt1 = [];
//           awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
//           // awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
//           if (
//             'isACS' in iAuthorWorkFlow[0].compoulsaryrole &&
//             logXML.length > 0
//           ) {
//             awt1.push(localHelper._localdownload(logXML[0].repofilepath));
//           } else if (logXML.length) {
//             awt1.push(localHelper._localdownload(logXML[0].repofilepath));
//           }

//           const out1 = await Promise.all(awt1);
//           iAuthorInputData.JourFileToUpload.push({
//             isArticle: true,
//             url: out1[0].data.path,
//             Code: Filename[0].filename,
//           });
//           if (logXML.length > 0) {
//             iAuthorInputData.JourFileToUpload.push({
//               isArticle: false,
//               url: out1[1].data.path,
//               Code: `${Filename[0].filename}`,
//             });
//           }
//           break;
//         default:
//           iAuthorInputData.JourFileToUpload.push({
//             isArticle: true,
//             url:
//               config.openKM.base_out_url +
//               config.openKM.uri.download +
//               inputXML[0].repofileuuid,
//             Code: Filename[0].filename,
//           });
//           if (logXML.length > 0) {
//             iAuthorInputData.JourFileToUpload.push({
//               isArticle: false,
//               url:
//                 config.openKM.base_out_url +
//                 config.openKM.uri.download +
//                 logXML[0].repofileuuid,
//               Code: Filename[0].filename,
//             });
//           }
//           break;
//       }
//       const configAPI = {
//         method: 'post',
//         url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
//           config.iAuthor.createjob
//         }`,
//         headers: {
//           'Content-Type': 'application/json',
//           clientid: config.iAuthor.clientid,
//           apikey: config.iAuthor.apikey,
//         },
//         data: JSON.stringify(iAuthorInputData),
//       };
//       axios(configAPI)
//         .then(async function (response) {
//           try {
//             sql = `select * from insert_iauthortran('${JSON.stringify({
//               workorderid: (workOrderId || '').toString(),
//               stageid: (stageId || '').toString(),
//               serviceid: (serviceId || '').toString(),
//               guid: (response.data.data.jobid || '').toString(),
//               stageiterationcount: (stageIterationCount || 1).toString(),
//             })}')`;
//             await query(sql);
//             res.status(200).send(response.data);
//
//           } catch (error) {
//
//             res.status(400).send({ is_success: false, message: error.message });
//           }
//         })
//         .catch(function (error) {
//           if (error.response) {
//             res.status(400).send(error.response.data);
//           } else {
//             res.status(400).send({ is_success: false, message: error.message });
//           }
//         });
//     } else {
//       // payload.log =
//       // 'iAuthor Image Conversion in Graphics stage is not completed';
//       res.status(200).send({
//         completeTask: true,
//         error: 'iAuthor Image Conversion in Graphics stage is not completed',
//         isSuccess: false,
//       });
//     }
//   } catch (error) {
//
//     res.status(400).send({
//       is_success: false,
//       message: error.message ? error.message : error,
//     });
//   }
// };

// export const getiAuthorImgs = async req => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       // const { workOrderId, variables } = payload;
//       const { workOrderId, wfId, wfdefId } = req.body;
//       const sql = `select fileconfig from wms_workflowdefinition where wfid = ${wfId} and wfdefid = ${wfdefId}`;
//       const data = await query(sql);
//       const imageCopy = data[0].fileconfig.files
//         ? data[0].fileconfig.files.filter(
//             file =>
//               (file.custom || []).filter(
//                 x => x.toLocaleLowerCase() === 'copygraphicsfile',
//               ).length > 0,
//           )
//         : 0;

//       if (imageCopy && imageCopy.length > 0) {
//         console.log('HI');
//         const graphicEnabledActivities = [];

//         let chkApiin = 0;
//         const graphicswfdefids = imageCopy[0].customwfdefid;
//         for (let i = 0; i < graphicswfdefids.length; i++) {
//           console.log(graphicswfdefids[i], 'sdfsfdj');
//           if (chkApiin == 0) {
//             chkApiin = 1;
//             // const payld = {
//             //   wfdefid: graphicswfdefids[i],
//             // };
//             // const headers = {
//             //   Authorization: `Bearer ${process.env.SERVER_TOKEN}`,
//             // };
//             // const url = apiConfig.server.uri.getGraphicStageActivityDetails;
//             // const details = await post(
//             //   `${apiConfig.server.baseUrl}${url}`,
//             //   payld,
//             //   headers,
//             // );
//             const payload = {
//               activityName: '',
//               wfdefid: graphicswfdefids[i],
//             };
//             const details = await getGraphicStageActivityDetailsTool(payload);
//             console.log(details, 'sdfsdfsd');
//             if (Array.isArray(details)) {
//               details.forEach((_details, index) => {
//                 if (index == 0) {
//                   graphicEnabledActivities.push(_details);
//                 }
//               });
//             } else if (Object.keys(details).length > 0) {
//               graphicEnabledActivities.push(details);
//             }
//             console.log(graphicEnabledActivities, 'graphicEnabledActivities');
//             for (let j = 0; j < graphicEnabledActivities.length; j++) {
//               try {
//                 // const Url = apiConfig.server.uri.getGraphicIterationDetail;
//                 const filePayload = {
//                   stageId: graphicEnabledActivities[j].stageId,
//                   activityId: graphicEnabledActivities[j].activityId,
//                   woId: workOrderId,
//                   needOnlyCompleted: true,
//                 };
//                 // const hdr = {
//                 //   Authorization: `Bearer ${process.env.SERVER_TOKEN}`,
//                 // };
//                 // const graphicItDetails = await post(
//                 //   `${apiConfig.server.baseUrl}${Url}`,
//                 //   filePayload,
//                 //   hdr,
//                 // );
//                 const graphicItDetails = await getGraphicIterationDetailTool(
//                   filePayload,
//                 );
//                 console.log(graphicItDetails, 'graphicItDetails');

//                 if (Object.keys(graphicItDetails).length > 0) {
//                   resolve({
//                     graphicDetails: graphicItDetails[0],
//                     isSuccess: true,
//                   });
//                 } else {
//                   resolve({
//                     completeTask: true,
//                     error:
//                       'iAuthor Image Conversion in Graphics stage is not completed',
//                     isSuccess: false,
//                   });
//                 }
//               } catch (error) {
//                 resolve({ completeTask: true, error, isSuccess: false });
//               }
//             }
//           }
//         }
//       } else {
//         resolve();
//       }
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

// export const getGraphicStageActivityDetailsTool = async payload => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const { activityName, wfdefid } = payload;
//       // let sql = `select activityid,activityname from wms_mst_activity where lower(activityname) like '${activityName}' `
//       const sql = `select act.activityid,act.activityname,wf.activitytype from wms_mst_activity  as act
//         join wms_workflowdefinition as wf on wf.activityid = act.activityid
//         where lower(act.activityname) like '${activityName}' or wf.wfdefid = ${wfdefid} `;
//       let sourceActivityName = await query(sql, []);
//       let sourceActivityFailedName = [];
//       console.log(sourceActivityName, 'sourceActivityName');
//       if (
//         sourceActivityName &&
//         sourceActivityName.length > 0 &&
//         sourceActivityName[0].activitytype == 'External Task'
//       ) {
//         const activityNewName = `${activityName}_f`;
//         const sql1 = `select act.activityid,act.activityname,wf.activitytype from wms_mst_activity  as act
//             join wms_workflowdefinition as wf on wf.activityid = act.activityid
//             where lower(act.activityname) like '${activityNewName}' `;
//         sourceActivityFailedName = await query(sql1, []);
//       }
//       if (
//         sourceActivityName &&
//         sourceActivityName.length > 0 &&
//         sourceActivityName[0].activitytype == 'External Task'
//       ) {
//         const result = [];
//         sourceActivityName = [
//           ...sourceActivityName,
//           ...sourceActivityFailedName,
//         ];
//         sourceActivityName.forEach(list => {
//           result.push({
//             activityId: list.activityid,
//             activityName: list.activityname,
//             stageId: 10,
//             stageName: 'Graphics',
//             activityType: list.activitytype,
//           });
//         });
//         resolve(result);
//       } else if (
//         sourceActivityName &&
//         sourceActivityName.length > 0 &&
//         sourceActivityName[0].activitytype == 'User Task'
//       ) {
//         resolve({
//           activityId: sourceActivityName[0].activityid,
//           activityName: sourceActivityName[0].activityname,
//           stageId: 10,
//           stageName: 'Graphics',
//           activityType: sourceActivityName[0].activitytype,
//         });
//       } else {
//         resolve({});
//       }
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

// export const getGraphicIterationDetailTool = payload => {
//   return new Promise((resolve, reject) => {
//     try {
//       let sql = '';
//       const { woId, activityId, stageId, needOnlyCompleted } = payload;
//       if (needOnlyCompleted) {
//         sql = `select * from wms_workflow_eventlog as eventlog
//           join wms_workflowdefinition as wfd on wfd.wfdefid = eventlog.wfdefid
//           where eventlog.workorderid = ${woId} and wfd.stageid =${stageId} and wfd.activityid = ${activityId}  and activitystatus ='Completed'order by wfeventid desc limit  1`;
//       } else {
//         sql = `select * from wms_workflow_eventlog as eventlog
//           join wms_workflowdefinition as wfd on wfd.wfdefid = eventlog.wfdefid
//           where eventlog.workorderid = ${woId} and wfd.stageid =${stageId} and wfd.activityid = ${activityId} order by wfeventid desc`;
//       }
//
//       query(sql)
//         .then(response => {
//           // updated for fileconfig restructure
//           response.forEach(item => {
//             item.fileconfig = ReStructureFileConfig(item.fileconfig);
//           });
//           resolve(response);
//         })
//         .catch(error => {
//           reject({ message: error });
//         });
//     } catch (error) {
//       console.log(error, 'error');
//     }
//   });
// };

function remove_linebreaksAndSpace(str) {
  return (str || '')
    .toString()
    .replace(/[\r\n]+/gm, '')
    .trim();
}

export const getCurrentiAuthorLink = async guid => {
  return new Promise((resolve, reject) => {
    try {
      const configAPI = {
        method: 'get',
        url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
          config.iAuthor.getCurrentiAuthorLink
        }?articleguid=${guid}`,
        headers: {
          'Content-Type': 'application/json',
          clientid: config.iAuthor.clientid,
          apikey: config.iAuthor.apikey,
        },
      };
      axios(configAPI)
        .then(async function (response) {
          resolve(response.data);
        })
        .catch(err => {
          if (err.response) reject(err.response.data);
          else reject({ is_success: false, message: err.message });
        });
    } catch (error) {
      reject({
        is_success: false,
        message: error.message ? error.message : error,
      });
    }
  });
};

export const getiAuthorActivityLink = async (req, res) => {
  try {
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.getiAuthorLink
      }`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data: JSON.stringify({
        JobID: req.body.jobid,
        ActivityId: req.body.activityid,
        RoleID: req.body.roleid,
        isCompletedLink: req.body.isCompletedLink
          ? req.body.isCompletedLink
          : false,
        userDetails: {
          UserName: remove_linebreaksAndSpace(req.body.username),
          Email: remove_linebreaksAndSpace(req.body.email),
        },
      }),
    };
    axios(configAPI)
      .then(async function (response) {
        res.status(200).send(response.data);
      })
      .catch(err => {
        if (err.response) res.status(400).send(err.response.data);
        else res.status(400).send({ is_success: false, message: err.message });
      });
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};
const getBearerToken = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const configAPI = {
        method: 'post',
        url: `${config.iAuthor.base_url()}${config.iAuthor.getiAuthorToken}`,
        headers: {
          'Content-Type': 'application/json',
          clientid: config.iAuthor.clientid,
          apikey: config.iAuthor.apikey,
        },
        data: JSON.stringify({
          UserName: 'is8784',
          FirstName: 'is8784',
          RoleId: 12,
          EmailId: 'is8784@integra.co.in',
        }),
      };
      axios(configAPI)
        .then(async function (response) {
          resolve(response.data);
        })
        .catch(err => {
          reject(err.response);
        });
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const getiAuthorLinkReset = async (req, res) => {
  try {
    const BearerToken = await getBearerToken();
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.getiAuthorLinkRest
      }`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
        Authorization: `Bearer ${BearerToken.token}`,
      },
      data: JSON.stringify({
        atyid: req.body.activityid,
        flag: req.body.flag,
        articleguid: req.body.articleguid,
      }),
    };
    axios(configAPI)
      .then(async function (response) {
        res.status(200).send(response.data);
      })
      .catch(err => {
        if (err.response) res.status(400).send(err.response.data);
        else res.status(400).send({ is_success: false, message: err.message });
      });
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};
export const FolderCopy = async (req, res) => {
  try {
    const result = await okmFolderCopy(req.body);
    res.status(200).send(result);
  } catch (e) {
    res.status(400).send('Folder copy Failed.');
  }
};

export const getiAuthorActivityFiles = async (req, res) => {
  try {
    const configAPI = {
      method: 'get',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.checkiAuthorStatus
      }?jobid=${req.body.jobid}&activityid=${req.body.activityid}`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
    };
    axios(configAPI)
      .then(async function (response) {
        try {
          if (response.data.is_success) {
            if (response.data.data.status_id == 4) {
              const configAPI2 = {
                method: 'post',
                url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
                  config.iAuthor.getiAuthorActivityFiles
                }`,
                headers: {
                  'Content-Type': 'application/json',
                  clientid: config.iAuthor.clientid,
                  apikey: config.iAuthor.apikey,
                },
                data: JSON.stringify(req.body),
              };
              axios(configAPI2)
                .then(async function (response1) {
                  response1.data.data.files = response1.data.data.files.filter(
                    x => !['Input', 'Resource'].includes(x.folderName),
                  );
                  const temp = [];
                  response1.data.data.files.forEach(ele => {
                    ele.paths.forEach(el => {
                      temp.push({ folder: ele.folderName, url: el });
                    });
                  });
                  if (
                    temp.filter(
                      x =>
                        x.folder == 'Output' &&
                        (x.url.includes('.xml') || x.url.includes('.tex')),
                    ).length < 1
                  ) {
                    throw new Error('Output xml missing');
                  }
                  response1.data.data.files = temp;
                  res.status(200).send(response1.data);
                })
                .catch(err => {
                  if (err.response) {
                    res.status(400).send(err.response.data);
                  } else {
                    res
                      .status(400)
                      .send({ is_success: false, message: err.message });
                  }
                });
            } else {
              res.status(200).send({
                is_success: false,
                message: 'iAuthor link is not submitted.',
              });
            }
          } else {
            res
              .status(400)
              .send({ is_success: false, message: response.data.message });
          }
        } catch (error) {
          res.status(400).send({ is_success: false, message: error.message });
        }
      })
      .catch(function (error) {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getToolsData = async (req, res) => {
  const { toolsId, wfeventId, toolsPlaceHolder = {} } = req.body;
  try {
    const placeHolders = await getWorkflowPlaceHolders(wfeventId);
    const combinedPlaceHolders = { ...placeHolders, ...toolsPlaceHolder };
    const toolsData = await _getToolsData(toolsId, combinedPlaceHolders);
    res.status(200).json(toolsData);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _getToolsData = async (toolsId, placeHolders) => {
  const commanUrl = await getCommanToolsUrl();

  const sql = `SELECT payload as apiconfig, isasync,tooltypeid,toolstatus FROM public.pp_mst_tool where toolid = $1 and toolstatus = $2`;
  const toolsData = await query(sql, [toolsId, true]);
  if (toolsData.length) {
    // const sql2 = `SELECT * FROM public.pp_mst_tool_serverpath where servermode = '${process.env.MODE}'`;
    // const serverUrlDetails = await query(sql2);

    const serverUrl = `${config.toolWrapperService.base_url()}`;
    toolsData[0].basePath = commanUrl ? commanUrl + serverUrl : serverUrl;
    const apiConfig = formattedApiConfig(toolsData[0].apiconfig, placeHolders);
    toolsData[0].apiconfig = apiConfig;
    return toolsData[0];
  }

  return {};
};

export const formattedApiConfig = (apiConfig, placeHolders) => {
  apiConfig = apiConfig || {};
  if (!apiConfig.input) apiConfig.input = {};
  if (!apiConfig.input.rawData) apiConfig.input.rawData = {};
  const inputKeys = Object.keys(apiConfig.input.rawData);
  for (let i = 0; i < inputKeys.length; i++) {
    const inputField = apiConfig.input.rawData[inputKeys[i]];
    if (Object.prototype.toString.call(inputField) == '[object String]') {
      apiConfig.input.rawData[inputKeys[i]] = getFormattedName(inputField, {
        ...placeHolders,
      });
    }
  }
  return apiConfig;
};

export const formattedProfileConfig = (apiConfig, placeHolders) => {
  const inputKeys = Object.keys(apiConfig);
  for (let i = 0; i < inputKeys.length; i++) {
    const inputField = apiConfig[inputKeys[i]];
    if (Object.prototype.toString.call(inputField) == '[object String]') {
      apiConfig[inputKeys[i]] = getFormattedName(inputField, {
        ...placeHolders,
      });
    }
  }
  return apiConfig;
};

export const getBasicToolsData = async toolsId => {
  return new Promise(async (resolve, reject) => {
    try {
      const commanUrl = await getCommanToolsUrl();

      toolsId = toolsId instanceof Array ? toolsId : [toolsId];
      const sql = `SELECT toolid, toolname, tooltypeid, toolstatus, tooldescription, payload as apiconfig, isasync,tooloutputid,toolvalidation FROM public.pp_mst_tool where toolid = Any($1)`;
      const data = await query(sql, [toolsId]);
      const sql2 = `SELECT * FROM public.pp_mst_tool_serverpath where servermode = '${process.env.MODE}'`;

      const serverUrlDetails = await query(sql2);

      if (data && data.length > 0) {
        data.forEach(list => {
          let newUrl = '';
          if (
            Object.keys(list.apiconfig).length > 0 &&
            list.apiconfig.url &&
            list.tooltypeid == 1
          ) {
            // if(process.env.MODE == 'dev'){
            //      newUrl = list.apiconfig.url
            // }else{
            //     var remainingUrl = list.apiconfig.url.replace('https://tools.integra.co.in/wrapper-service-dev','')
            //     newUrl = 'https://tools.integra.co.in/wrapper-service' + remainingUrl
            // }
            newUrl = commanUrl
              ? commanUrl + serverUrlDetails[0].serverurl + list.apiconfig.url
              : serverUrlDetails[0].serverurl + list.apiconfig.url;
            list.apiconfig.url = newUrl;
          }
        });
      }

      resolve(data);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getCommanToolsUrl = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const Comurl =
        process.env.MODE == 'dev' ||
        process.env.MODE == 'prod' ||
        process.env.MODE == 'test' ||
        process.env.MODE == 'uat'
          ? 'https://ispswitch.integra.co.in/ipswitch?serverName=is-srv165&getIP=false'
          : 'https://ispswitch.integra.co.in/ipswitch?serverName=is-srv135&getIP=false';
      // url: "https://ispswitch.integra.co.in/ipswitch?serverName=is-srv135&getIP=false",
      axios({
        method: 'get',
        url: Comurl,
      }).then(response => {
        const commanurl = `https://${response.data}`;
        resolve(commanurl);
      });
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const generateiAuthorHtml = async (req, res) => {
  const { conversion_type, conversion_method, DOMContent, configuration } =
    req.body;

  try {
    if (!conversion_type && !conversion_method) {
      throw new Error('Mandatory fields required');
    }
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.iauthorhtml}${config.iAuthor.generateiAuthorhtml}`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data: JSON.stringify({
        conversion_type,
        conversion_method,
        DOMContent,
        configuration,
      }),
    };
    axios(configAPI)
      .then(async function (response) {
        res.status(200).send(response.data);
      })
      .catch(err => {
        if (err.response) res.status(400).send(err.response.data);
        else res.status(400).send({ is_success: false, message: err.message });
      });
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};

export const saveiNetLink = async (req, res) => {
  const { iwms } = req.body;
  const { woId, serviceId, stageId, stageIteration } = iwms;
  const toolId = req.body.apiDetails.newToolId;
  const output = req.body.remarks;
  // const wfEventId = iwms.wfEventId ? iwms.wfEventId : '';

  let articleFileId = iwms.woIncomingFileId;
  const toolType = req.body.toolType ? req.body.toolType : '';
  let updatesql = '';
  let checksql;
  if (iwms.additionalInfo.length && iwms.additionalInfo[0].isBatch) {
    checksql = `SELECT COUNT(*) FROM wms_toolsoutput_details where workorderid =${woId} and serviceid= ${serviceId} and stageid= ${stageId} and stageiterationcount =${stageIteration} and toolid=${toolId} and tooltype = '${toolType}' and  (incomingfileid in (${articleFileId}) or incomingfileid is null)`;
  } else {
    checksql = `SELECT COUNT(*) FROM wms_toolsoutput_details where workorderid =${woId} and serviceid= ${serviceId} and stageid= ${stageId} and stageiterationcount =${stageIteration} and toolid=${toolId} and tooltype = '${toolType}' and  (incomingfileid=${articleFileId} or incomingfileid is null)`;
  }
  await query(checksql)
    .then(async getCount => {
      if (getCount[0].count > 0) {
        updatesql = `UPDATE wms_toolsoutput_details SET output ='${output}' WHERE workorderid = ${woId} and serviceid= ${serviceId} and stageid= ${stageId} and stageiterationcount =${stageIteration} and toolid=${toolId} and tooltype = '${toolType}' and incomingfileid=${articleFileId} RETURNING output`;
        await query(updatesql)
          .then(async data => {
            res.status(200).json({
              data,
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({
              data: error.message ? error.message : error,
              status: false,
              message: 'Save link for inetCompare failed.',
            });
          });
      } else {
        if (iwms.additionalInfo.length && iwms.additionalInfo[0].isBatch) {
          articleFileId = parseInt(articleFileId.pop());
        }
        const sql = `Insert into wms_toolsoutput_details(workorderid,serviceid,stageid,stageiterationcount,toolid,output,incomingfileid,tooltype) values (${woId},${serviceId},${stageId},${stageIteration},${toolId},'${output}',${articleFileId},'${toolType}') RETURNING output`;
        await query(sql)
          .then(async data => {
            res.status(200).json({
              data,
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({
              data: error.message ? error.message : error,
              status: false,
              message: 'Save link for inetCompare failed.',
            });
          });
      }
    })
    .catch(error => {
      res.status(400).send({
        data: error.message ? error.message : error,
        status: false,
        message: 'Save link for inetCompare failed.',
      });
    });
};
export const gettoolLink = async (req, res) => {
  const { woId, serviceId, stageId, stageIteration, toolId, iwms } = req.body;

  const toolType = req.body.toolType ? req.body.toolType : '';
  if (iwms.instanceType == 'Batch') {
    const fileID = `'{${iwms.woIncomingFileId}}'`;
    const sql = `select b.filename ,a.output, a. tooltype from  wms_toolsoutput_details a join wms_workorder_incomingfiledetails b
    on a.incomingfileid = b.woincomingfileid  where a.workorderid =${woId} and a.serviceid= ${serviceId} and a.stageid = ${stageId} and a.stageiterationcount=${stageIteration} and a.toolid=${toolId}
    and a.incomingfileid = any(${fileID})  order by a.toolsoutputid `;
    await query(sql)
      .then(async data => {
        if (data.length > 0) {
          res.status(200).json({
            data: data[0],
            status: true,
          });
        } else {
          res.status(400).json({
            data: [],
            status: false,
            message: 'iNet link was not updated',
          });
        }
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          status: false,
          message: 'iNet link was not updated',
        });
      });
  } else {
    const tmpwoIncomingFileId =
      iwms.woIncomingFileId == null ? 0 : iwms.woIncomingFileId;
    // const toolType = req.body.toolType ? req.body.toolType : '';
    const sql = `select output from  wms_toolsoutput_details where workorderid =${woId} and serviceid= ${serviceId} and stageid = ${stageId} and stageiterationcount=${stageIteration} and toolid=${toolId} and (tooltype='${toolType}' or tooltype is null) and (coalesce(incomingfileid,0) =${tmpwoIncomingFileId})order by toolsoutputid limit 1`;
    await query(sql)
      .then(async data => {
        res.status(200).json({
          data: data[0],
          status: true,
        });
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          status: false,
          message: 'iNet link was not updated',
        });
      });
  }
};
export const swiftsignal = async (req, res) => {
  const file = req.body;

  {
    const sql = `select xmltemplate , isarticle ,templatename from tools_xmltemplate_details where stageid = ${file.stageId}  and activityid =${file.activityId}  and customerid =${file.custId}   limit 1`;
    await query(sql)
      .then(async data => {
        res.status(200).json({
          xmlTemplate: data,
        });
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          status: false,
          message: 'iNet link was not updated',
        });
      });
  }
};
export const getProfilePath = async (req, res) => {
  const { custId, profileType } = req.body;

  {
    const sql = `select profilevalue from public.trn_pitstopprofiledetail where customerid=${custId} and profileid=${profileType} order by 1 desc `;
    await query(sql)
      .then(async data => {
        res.status(200).send({
          data,
        });
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          status: false,
          message: 'iNet link was not updated',
        });
      });
  }
};
export const swiftsTemplate_old = async (req, res) => {
  const template = req.templateName;
  {
    const sql = `select xmltemplate,isarticle from tools_xmltemplate_details where templatename = '${template}'  limit 1`;
    await query(sql)
      .then(async data => {
        res(data);
      })
      .catch(err => {
        res.status(400).send({
          data: err,
          status: false,
          message: 'iNet link was not updated',
        });
      });
  }
};
export const swiftsTemplate = async template => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select xmltemplate,isarticle from tools_xmltemplate_details where templatename = '${template}'  limit 1`;
      const templateDetails = await query(sql);
      resolve(
        templateDetails && templateDetails.length ? templateDetails[0] : null,
      );
    } catch (e) {
      reject(e);
    }
  });
};

export const getDOIDetails = async (req, res) => {
  const { woId } = req.body;

  {
    const sql = `select doinumber from wms_workorder where workorderid = ${woId}`;
    await query(sql)
      .then(async data => {
        res.status(200).json({
          data: data[0],
        });
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          status: false,
          message: 'iNet link was not updated',
        });
      });
  }
};

export const getJobDetails = async (bookcode, isArticle) => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = '';
      if (isArticle) {
        sql = `select doinumber from wms_workorder where itemcode = '${bookcode}' limit 1`;
      } else {
        sql = `select journalname from pp_mst_journal where journalacronym = '${bookcode}'`;
      }
      const doiDetails = await query(sql);
      resolve(
        doiDetails && doiDetails.length ? doiDetails[0].journalname : null,
      );
    } catch (e) {
      reject(e);
    }
  });
};

export const createManualReport = (req, res) => {
  const payload = req.body;
  let doinumber;
  let bookCode;
  let journalname;
  let updatedTemplate;
  let template;
  return new Promise(async (resolve, reject) => {
    try {
      template = await swiftsTemplate(payload.templateName);
      if (template.isarticle == true) {
        doinumber = await getJobDetails(payload.bookcode, true);
        if (!doinumber) {
          reject('Invalid Article Book Code, Please check and update');
          throw new Error('Invalid Article Book Code, Please check and update');
        }
      } else if (template.isarticle == false) {
        bookCode = payload.bookcode.split('_');
        journalname = await getJobDetails(bookCode[0], false);
        if (!journalname) {
          reject('Invalid Journal Details, Please check and update');
          throw new Error('Invalid Journal Details, Please check and update');
        }
      } else {
        throw new Error('Invalid Template, Please check Input details');
      }
      const completionDate = moment(payload.completedDate).format('DD-MM-YYYY');
      updatedTemplate = template.xmltemplate
        .replace(/;doi;/, doinumber)
        .replace(/;journalCode;/, bookCode[0])
        .replace(/;journalname;/, journalname)
        .replace(/;volumecode;/, bookCode[1])
        .replace(/;issuecode;/, bookCode[2])
        .replace(/;completiondate;/, completionDate)
        .replace(/;year;/, moment(payload.completedDate).format('YYYY'));

      const headers = {
        'Ocp-Apim-Subscription-Key': 'f8a97c747ebd4894abe7d69c472f8e52',
        'Content-Type': 'application/xml',
      };

      const url = template.isarticle
        ? `https://api-test.oup.com/uat-swift/v1/Manuscripts`
        : `https://api-test.oup.com/uat-swift/v1/issueScript`;

      const result = await iservice.put(url, updatedTemplate, headers);
      const sql = `insert into trn_swiftapicalldetails(bookcode,stageid,activityid,requestbody,response,issuccess,createdby,httpstatuscode,stepcode) values(
        '${payload.bookcode}',100,101,'${template.xmltemplate}','${updatedTemplate}',${result.status},'${payload.userId}',${result.message.status},'${payload.templateName}')`;
      await query(sql);
      res.status(200).send(result);
      // resolve(true);
    } catch (err) {
      if (template && updatedTemplate) {
        const sql = `insert into trn_swiftapicalldetails(bookcode,stageid,activityid,requestbody,response,issuccess,createdby,httpstatuscode,stepcode) values(
        '${payload.bookcode}',100,101,'${
          template.xmltemplate
        }','${updatedTemplate}',${false},'${payload.userId}',${
          err.message.status
        },'${payload.templateName}')`;
        await query(sql);
        res.status(400).send(err.message.data);
      }

      res.status(400).send(err);
    }
  });
};

export const checkSwiftCompleted = (req, res) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { payload } = req.body;
      // const wfeventId=req.body.wfEventId

      const sql = `select status from wms_tools_api where wfeventid=${payload.wfEventId} and status='Success' and toolid=${payload.toolId} order by apiid desc`;
      const response = await query(sql);
      res.status(200).json({
        data: response.length > 0,
      });

      resolve();
    } catch (e) {
      reject('FTP upload not done, Please check the FTP upload status');
    }
  });
};

export const getiAuthorWorkFlowDetails = async (req, res) => {
  const { woId } = req.body;
  {
    const sql = `
    SELECT string_agg(activity->>'ActivityID', ',') AS ActivityIDs
    FROM (
      SELECT jsonb_array_elements(sequencedetails::jsonb->'activities') AS activity
      FROM wms_workorder AS a1
      LEFT JOIN pp_mst_journal AS a2 ON a1.journalid = a2.journalid
      LEFT JOIN iauthor_workflow AS a3 ON a3.iauthworkflowid = a2.iauthworkflowid
      WHERE  a1.workorderid=${woId} ) AS activities
    WHERE (activity->>'contactrole') NOT IN ('SPM', 'DEFAULT');`;
    await query(sql)
      .then(async data => {
        res.status(200).json({
          data: data[0],
          issuccess: true,
        });
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          issuccess: false,
          message: 'iAuthor link was not updated',
        });
      });
  }
};

export const saveSwiftSignalReport = async (req, res) => {
  const {
    bookcode,
    stageid,
    activityid,
    requestbody,
    response,
    issuccess,
    createdby,
    httpstatuscode,
    stepcode,
  } = req.body;
  {
    const sql = `insert into trn_swiftapicalldetails(bookcode,stageid,activityid,requestbody,response,issuccess,createdby,httpstatuscode,stepcode) values(
      '${bookcode}',${stageid},${activityid},'${requestbody}','${response}',${issuccess},'${createdby}',${httpstatuscode},'${stepcode}')`;
    await query(sql)
      .then(async data => {
        res.status(200).json({
          data: data[0],
          issuccess: true,
        });
      })
      .catch(err => {
        res.status(400).send({
          data: [],
          issuccess: false,
          message: err,
        });
      });
  }
};
export const isNullorUndefined = data => {
  return data == null || data == undefined || data.toString() == '';
};

export const updateWordCountFromiAuthor = async (req, res) => {
  const { itemcode, wordcount, stageiteration, guid } = req.body;
  try {
    logger.info('updateWordCount request receive from iAuthor', req.body);

    if (!itemcode || !wordcount || !guid || !stageiteration) {
      throw new Error('Mandatory field missing. Please check!');
    }

    // Update wordcount_response in iauthor_transactions for audit
    const sql = `UPDATE iauthor_transactions 
    SET wordcount_response = $1 
    WHERE workorderid = (SELECT workorderid FROM wms_workorder WHERE itemcode = $2 LIMIT 1) 
    AND stageiterationcount = $3 
    AND guid = $4`;

    await query(sql, [
      JSON.stringify(wordcount),
      itemcode,
      stageiteration,
      guid,
    ]);
    logger.info(
      `update iauthor transaction audit updated successfully for ${itemcode}. Guid: ${guid}`,
    );

    const getIncomingFileDetailsSql = `
      SELECT inco.woincomingid
      FROM wms_workorder AS wo
      JOIN wms_workorder_incoming AS woi ON wo.workorderid = woi.woid
      JOIN wms_workorder_incomingfiledetails AS inco ON inco.woincomingid = woi.woincomingid 
      WHERE wo.itemcode = $1;
    `;

    const woincomingData = await query(getIncomingFileDetailsSql, [itemcode]);

    if (woincomingData && woincomingData.length > 0) {
      const { woincomingid } = woincomingData[0];

      // Update wordcount details in wms_workorder_incomingfiledetails
      const updateSql = `
        UPDATE public.wms_workorder_incomingfiledetails
        SET wordcount = $1, referencecount = $2, tablecount = $3, imagecount = $4, equationcount = $5
        WHERE woincomingid = $6;
      `;

      await query(updateSql, [
        wordcount.totwordcount,
        wordcount.refcount,
        wordcount.tables,
        wordcount.figures,
        wordcount.equations,
        woincomingid,
      ]);
      logger.info(
        `Word count details updated successfully for ${itemcode}. Guid: ${guid}`,
      );
      let itrackcustomerid = 0;
      let wordcountperpage = 1.0;
      let customershortname = '';
      let conversionfactor = 0.0;
      // let retstatus = false;
      // let retdata;
      // const checksql = `Select woincomingid from public.wms_workorder_incoming where woid=${workorder}`;

      const checksql = `select  cus.itrack_customerid ,cus.customershortname, wi.woincomingid , jr.conversionfactor
        from public.wms_workorder_incoming as wi
        join wms_workorder as wo on wo.workorderid = wi.woid  
        join org_mst_customer cus on cus.customerid = wo.customerid
        join public.pp_mst_journal as jr on jr.journalid = wo.journalid
        where woid=(SELECT workorderid FROM wms_workorder WHERE itemcode = $1 LIMIT 1)`;
      await query(checksql, [itemcode]).then(async getCount => {
        if (getCount[0].woincomingid > 0) {
          const woIncomingId = +getCount[0].woincomingid
            ? +getCount[0].woincomingid
            : {};

          itrackcustomerid = +getCount[0].itrack_customerid
            ? +getCount[0].itrack_customerid
            : 0;

          customershortname = getCount[0].customershortname
            ? getCount[0].customershortname
            : '';

          conversionfactor = +getCount[0].conversionfactor
            ? +getCount[0].conversionfactor
            : 1.0;

          try {
            if (customershortname == 'ACS') {
              const getstandardpage = `SELECT wordcount_per_page::numeric(5,2) wordcount_per_page  FROM public.mst_standardpage_measure where customerid = ${itrackcustomerid}`;

              const respage = await query(getstandardpage);
              if (respage != undefined && respage.length > 0) {
                wordcountperpage = respage[0].wordcount_per_page
                  ? +respage[0].wordcount_per_page
                  : 1;
              }

              const qrypageupdate = `update wms_workorder_incomingfiledetails set 
            estimatedpages = round(round(wordcount/ ${wordcountperpage}) * ${conversionfactor})  , 
            typesetpage = round(round(wordcount/ ${wordcountperpage}) * ${conversionfactor}) ,
            mspages =  round(wordcount/ ${wordcountperpage})            
            where woincomingid = ${woIncomingId}`;

              await query(qrypageupdate);
            }
          } catch (error) {
            logger.info(`Error while updating estimated pages:`, error);
          }
        }
      });
    } else {
      throw new Error('No incoming file data found for the provided itemcode');
    }

    res.status(200).send({
      is_success: true,
      message: 'Wordcount data updated successfully',
    });
  } catch (error) {
    logger.info(
      `Error in updateWordCountFromiAuthor ${itemcode}. Guid: ${guid}`,
      error,
    );
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};
export const iAuthorLinkGenerationTool = async (req, res) => {
  const {
    workOrderId,
    stageId,
    serviceId,
    eventId,
    stageIterationCount,
    wfdefId,
  } = req.body;
  try {
    // wfId,
    // duId,

    const skipFileValidation = false;
    let graphicEvtId = null;
    let iAuthorImgRes = {};
    let duId = '';
    let variables;

    if (eventId) {
      const sql1 = `select baseduid,wfid from wms_workorder_service where workorderid = ${workOrderId} order by woserviceid desc limit 10`;
      const response = await query(sql1);
      duId = response[0].baseduid;
      req.body.wfId = response[0].wfid;

      const sql = `
      SELECT eventdata->'variables' as variables
      FROM wms_workflow_eventlog 
      WHERE wfdefid =${wfdefId} and workorderid =${workOrderId} and wfeventid = ${eventId}
      ORDER BY wfeventid DESC`;
      const data = await query(sql);
      variables = data?.[0]?.variables;
    }

    iAuthorImgRes = await getiAuthorImgs(req);

    const acsgraphicscondition = duId;
    if (acsgraphicscondition == '92' && variables.__isGraphic__ === true) {
      variables.__isGraphic__ = false;
    }

    if (
      variables.__isGraphic__ == false ||
      graphicEvtId != null ||
      iAuthorImgRes.isSuccess == true
    ) {
      graphicEvtId =
        iAuthorImgRes && iAuthorImgRes.graphicDetails
          ? iAuthorImgRes.graphicDetails.wfeventid
          : null;

      const dmsType = await getdmsType(workOrderId);
      const SupplimentryFiles = [];
      let sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map
                      where wfeventid=${eventId}`;

      const eventDetails = await query(sql);
      let additionalFiles;

      if (graphicEvtId != null) {
        sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                      where wfeventid =${graphicEvtId} and repofilepath not like '%.eps'`;
        additionalFiles = await query(sql);
        const supplementaryArray = [];
        additionalFiles.forEach(element => {
          element.FileName = path.basename(element.repofilepath);
          switch (dmsType) {
            case 'azure':
              supplementaryArray.push(
                azureHelper._download(element.repofilepath),
              );
              break;
            case 'local':
              supplementaryArray.push(
                localHelper._localdownload(element.repofilepath),
              );
              break;
            default:
              supplementaryArray.push({
                path:
                  config.openKM.base_out_url +
                  config.openKM.uri.download +
                  element.repofileuuid,
              });
              break;
          }
        });
        const supplementary = await Promise.all(supplementaryArray);
        supplementary.forEach(ele => {
          SupplimentryFiles.push({
            flag: 'article_resource',
            url: ele.path ? ele.path : ele.data.path,
          });
        });
      }
      if (eventDetails.length == 0) {
        throw new Error(`File mapping missing for workorderid : ${eventId}`);
      }
      let iAuthorWorkFlowField = '';
      switch (stageId) {
        case '13':
          iAuthorWorkFlowField = 'b.copyeditingworkflow';
          break;
        case '72':
          iAuthorWorkFlowField = 'b.iauthworkconversionflowid';
          break;
        default:
          iAuthorWorkFlowField = 'b.iauthworkflowid';
          break;
      }
      sql = `select  COALESCE(d.typesetpages,0) as typesetpages, a.otherfield ->>'articleno' as articleno, doinumber as articlename,title as articletitle,b.isiauthor, 
                  ${iAuthorWorkFlowField} as iauthworkflowid,a.wotype, b.journalacronym, b.journalname ,c.iauthcustomerid ,d.stageiterationcount,
                  b.iauthworkconversionflowid, a.otherfield ->> 'pii' as pii
                  from wms_workorder a 
                  join public.pp_mst_journal b on a.journalid=b.journalid 
                  join public.wms_workorder_Stage d on d.workorderid=a.workorderid
                  left join public.iauthor_mst_customer c on c.custorgmapid=b.custorgmapid 
                  where a.workorderid=${workOrderId} and d.wfstageid=${stageId}`;
      const mstJournal = await query(sql);
      sql = `Select incf.filename from public.wms_workorder_incoming as inc
          left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
          where woid=${workOrderId}`;
      const Filename = await query(sql);
      if (mstJournal.length == 0) {
        throw new Error(`invalid workorderid : ${workOrderId}`);
      }

      const supplementaryArray = [];
      eventDetails.forEach(element => {
        element.FileName = path.basename(element.repofilepath);
        switch (dmsType) {
          case 'azure':
            supplementaryArray.push(
              azureHelper._download(element.repofilepath),
            );
            break;
          case 'local':
            supplementaryArray.push(
              localHelper._localdownload(element.repofilepath),
            );
            break;
          default:
            supplementaryArray.push({
              path:
                config.openKM.base_out_url +
                config.openKM.uri.download +
                element.repofileuuid,
            });
            break;
        }
      });
      const supplementary = await Promise.all(supplementaryArray);
      supplementary.forEach(ele => {
        SupplimentryFiles.push({
          flag: 'article_resource',
          url: ele.path ? ele.path : ele.data.path,
        });
      });
      const inputXML = eventDetails.filter(
        x => x.FileName == `${Filename[0].filename}.xml`,
      );
      let logXML =
        additionalFiles && additionalFiles.length
          ? additionalFiles.filter(
              x => x.FileName == `${Filename[0].filename}_log.xml`,
            )
          : [];
      if (logXML.length == 0) {
        logXML = eventDetails.filter(
          x => x.FileName == `${Filename[0].filename}_log.xml`,
        );
      }

      if (inputXML.length == 0) {
        throw new Error(`${`${Filename[0].filename}.xml`} file missing.`);
      }
      sql = `SELECT guid FROM inlp_transactions 
          WHERE workorderid = ${workOrderId}
          AND stageid = ${stageId}
          AND serviceid = ${serviceId}
          AND stageiterationcount = ${mstJournal[0].stageiterationcount} order by inlptrnsid limit 1`;
      let NLPGuid = await query(sql);
      if (NLPGuid.length > 0) {
        NLPGuid = NLPGuid[0].guid;
      } else {
        NLPGuid = undefined;
      }
      sql = `select contactname ,contactemail ,contactrole from public.wms_workorder_contacts 
                  where workorderid=${workOrderId} order by wocontactid`;
      const workorderContacts = await query(sql);
      if (workorderContacts.length == 0) {
        throw new Error(`Workorder Contacts are missing.`);
      }

      sql = `select * from public.iauthor_workflow 
                  where iauthworkflowid=${mstJournal[0].iauthworkflowid}`;
      const iAuthorWorkFlow = await query(sql);
      if (iAuthorWorkFlow.length == 0) {
        throw new Error(
          `iAuthorWorkFlow is not mapped for this journal (${mstJournal[0].journalacronym})`,
        );
      } else if (
        mstJournal[0].typesetpages == 0 &&
        iAuthorWorkFlow[0].compoulsaryrole?.skipTypesetPageCount != 'true'
      ) {
        throw new Error(`Typeset Pages not updated.`);
      }

      const peDetails =
        iAuthorWorkFlow[0]?.compoulsaryrole.isACS == 'true'
          ? workorderContacts.filter(
              x =>
                x.contactrole == 'PED' ||
                x.contactrole == 'CM' ||
                x.contactrole == 'PM',
            )
          : workorderContacts.filter(
              x => x.contactrole == 'PED' || x.contactrole == 'CM',
            );

      const authorDetails = workorderContacts.filter(
        x => x.contactrole == 'AUTHOR',
      );
      const EditorDetails = workorderContacts.filter(
        x => x.contactrole == 'EC' || x.contactrole == 'E',
      );
      const spmDetails = workorderContacts.filter(x => x.contactrole == 'SPM');
      if (peDetails.length == 0) {
        throw new Error('Production Editor is not mapped.');
      }

      const SequenceDetails = [];
      for (const activity of iAuthorWorkFlow[0].sequencedetails.activities) {
        if (activity.contactrole == 'DEFAULT') {
          SequenceDetails.push({
            ActivityID: activity.ActivityID,
            RoleID: activity.RoleID,
            userDetails: [
              {
                UserName: 'admin',
                Email: 'admin@integra.co.in',
              },
            ],
          });
        } else {
          const user = workorderContacts.filter(
            x => x.contactrole == activity.contactrole,
          );
          if (user.length == 0) {
            throw new Error(
              `Workorder Contacts are missing for ${activity.contactrole}`,
            );
          }
          SequenceDetails.push({
            ActivityID: activity.ActivityID,
            RoleID: activity.RoleID,
            userDetails: [
              {
                UserName: remove_linebreaksAndSpace(user[0].contactname),
                Email: remove_linebreaksAndSpace(user[0].contactemail),
              },
            ],
          });
        }
      }
      const articlemeta = {
        manuscriptid: Filename[0].filename,
        manuscripttitle: mstJournal[0].articletitle,
        DOI: Filename[0].filename,
        journaltitle: mstJournal[0].journalname,
        Articlenumber: mstJournal[0].articleno,
        Pageno: mstJournal[0].typesetpages,
      };

      if (authorDetails.length > 0) {
        articlemeta.Authoremail = remove_linebreaksAndSpace(
          authorDetails[0].contactemail,
        );
        articlemeta.Authorname = remove_linebreaksAndSpace(
          authorDetails[0].contactname,
        );
      }
      if (peDetails.length > 0) {
        articlemeta.Pemailid = remove_linebreaksAndSpace(
          peDetails[0].contactemail,
        );
        articlemeta.Pename = remove_linebreaksAndSpace(
          peDetails[0].contactname,
        );
      }
      if (EditorDetails.length > 0) {
        if (EditorDetails.length > 1) {
          const additionalEditor = EditorDetails.splice(
            1,
            EditorDetails.length,
          );
          articlemeta.AdditionalEditorMail = additionalEditor
            .map(x => remove_linebreaksAndSpace(x.contactemail))
            .join(';');
        }
        articlemeta.Editoremailid = remove_linebreaksAndSpace(
          EditorDetails[0].contactemail,
        );
        articlemeta.Editorname = remove_linebreaksAndSpace(
          EditorDetails[0].contactname,
        );
      }
      if (spmDetails.length > 0) {
        articlemeta.SPMemailid = remove_linebreaksAndSpace(
          spmDetails[0].contactemail,
        );
        articlemeta.SPMname = remove_linebreaksAndSpace(
          spmDetails[0].contactname,
        );
      }
      const iAuthorInputData = {
        isNewWMS: true,
        NLPGuid,
        supplementary: SupplimentryFiles,
        JobType: mstJournal[0].wotype,
        CustomerID: mstJournal[0].iauthcustomerid,
        isEDAjrnl: 0,
        ProofType: 'A',
        PEUser: {
          UserName: remove_linebreaksAndSpace(peDetails[0].contactname),
          Email: remove_linebreaksAndSpace(peDetails[0].contactemail),
        },
        JourFileToUpload: [],
        JournalDetails: {
          journalcode: mstJournal[0].journalacronym,
          journalname: mstJournal[0].journalname,
          journaltitle: mstJournal[0].journalname,
          journaltoc: [
            {
              ArticleGUID: null,
              title: mstJournal[0].articletitle,
              orderid: 1,
              type: null,
              code: Filename[0].filename,
              FileName: Filename[0].filename,
              IsOnshore: 0,
            },
          ],
        },
        workflowDetails: {
          isNeedActivitySkip:
            iAuthorWorkFlow[0].sequencedetails.isNeedActivitySkip,
          RevisionCount: mstJournal[0].stageiterationcount,
          WorkflowID: mstJournal[0].iauthworkflowid,
          SequenceDetails,
        },
        articlemeta,
        conversion_id:
          iAuthorWorkFlow[0]?.compoulsaryrole?.isACSConversion ===
          req.body.stageId
            ? 1
            : iAuthorWorkFlow[0]?.compoulsaryrole?.isConversionId
            ? 2
            : 1,

        skipFileValidation,
      };
      switch (dmsType) {
        case 'azure':
          const awt = [];
          awt.push(azureHelper._download(inputXML[0].repofilepath));
          // awt.push(azureHelper._download(inputXML[0].repofilepath));
          const out = await Promise.all(awt);
          iAuthorInputData.JourFileToUpload.push({
            isArticle: true,
            url: out[0].data.path,
            Code: Filename[0].filename,
          });
          if (logXML.length > 0) {
            iAuthorInputData.JourFileToUpload.push({
              isArticle: false,
              url: out[0].data.path,
              Code: Filename[0].filename,
            });
          }
          break;
        case 'local':
          const awt1 = [];
          awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
          // awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
          if (
            'isACS' in iAuthorWorkFlow[0].compoulsaryrole &&
            logXML.length > 0
          ) {
            awt1.push(localHelper._localdownload(logXML[0].repofilepath));
          } else if (logXML.length) {
            awt1.push(localHelper._localdownload(logXML[0].repofilepath));
          }

          const out1 = await Promise.all(awt1);
          iAuthorInputData.JourFileToUpload.push({
            isArticle: true,
            url: out1[0].data.path,
            Code: Filename[0].filename,
          });
          if (logXML.length > 0) {
            iAuthorInputData.JourFileToUpload.push({
              isArticle: false,
              url: out1[1].data.path,
              Code: `${Filename[0].filename}`,
            });
          }
          break;
        default:
          iAuthorInputData.JourFileToUpload.push({
            isArticle: true,
            url:
              config.openKM.base_out_url +
              config.openKM.uri.download +
              inputXML[0].repofileuuid,
            Code: Filename[0].filename,
          });
          if (logXML.length > 0) {
            iAuthorInputData.JourFileToUpload.push({
              isArticle: false,
              url:
                config.openKM.base_out_url +
                config.openKM.uri.download +
                logXML[0].repofileuuid,
              Code: Filename[0].filename,
            });
          }
          break;
      }
      const configAPI = {
        method: 'post',
        url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
          config.iAuthor.createjob
        }`,
        headers: {
          'Content-Type': 'application/json',
          clientid: config.iAuthor.clientid,
          apikey: config.iAuthor.apikey,
        },
        data: JSON.stringify(iAuthorInputData),
      };
      axios(configAPI)
        .then(async function (response) {
          try {
            sql = `select * from insert_iauthortran('${JSON.stringify({
              workorderid: (workOrderId || '').toString(),
              stageid: (stageId || '').toString(),
              serviceid: (serviceId || '').toString(),
              guid: (response.data.data.jobid || '').toString(),
              stageiterationcount: (stageIterationCount || 1).toString(),
            })}')`;
            await query(sql);
            res.status(200).send(response.data);
          } catch (error) {
            res.status(400).send({ is_success: false, message: error.message });
          }
        })
        .catch(function (error) {
          if (error.response) {
            res.status(400).send(error.response.data);
          } else {
            res.status(400).send({ is_success: false, message: error.message });
          }
        });
    } else {
      // payload.log =
      // 'iAuthor Image Conversion in Graphics stage is not completed';
      res.status(200).send({
        completeTask: true,
        error: 'iAuthor Image Conversion in Graphics stage is not completed',
        isSuccess: false,
      });
    }
  } catch (error) {
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};
export const getiAuthorImgs = async req => {
  return new Promise(async (resolve, reject) => {
    try {
      // const { workOrderId, variables } = payload;
      const { workOrderId, wfId, wfdefId } = req.body;
      const sql = `select fileconfig from wms_workflowdefinition where wfid = ${wfId} and wfdefid = ${wfdefId}`;
      const data = await query(sql);
      const imageCopy = data[0].fileconfig.files
        ? data[0].fileconfig.files.filter(
            file =>
              (file.custom || []).filter(
                x => x.toLocaleLowerCase() === 'copygraphicsfile',
              ).length > 0,
          )
        : 0;

      if (imageCopy && imageCopy.length > 0) {
        const graphicEnabledActivities = [];

        let chkApiin = 0;
        const graphicswfdefids = imageCopy[0].customwfdefid;
        for (let i = 0; i < graphicswfdefids.length; i++) {
          if (chkApiin == 0) {
            chkApiin = 1;
            // const payld = {
            //   wfdefid: graphicswfdefids[i],
            // };
            // const headers = {
            //   Authorization: `Bearer ${process.env.SERVER_TOKEN}`,
            // };
            // const url = apiConfig.server.uri.getGraphicStageActivityDetails;
            // const details = await post(
            //   `${apiConfig.server.baseUrl}${url}`,
            //   payld,
            //   headers,
            // );
            const payload = {
              activityName: '',
              wfdefid: graphicswfdefids[i],
            };
            const details = await getGraphicStageActivityDetailsTool(payload);
            if (Array.isArray(details)) {
              details.forEach((_details, index) => {
                if (index == 0) {
                  graphicEnabledActivities.push(_details);
                }
              });
            } else if (Object.keys(details).length > 0) {
              graphicEnabledActivities.push(details);
            }
            for (let j = 0; j < graphicEnabledActivities.length; j++) {
              try {
                // const Url = apiConfig.server.uri.getGraphicIterationDetail;
                const filePayload = {
                  stageId: graphicEnabledActivities[j].stageId,
                  activityId: graphicEnabledActivities[j].activityId,
                  woId: workOrderId,
                  needOnlyCompleted: true,
                };
                // const hdr = {
                //   Authorization: `Bearer ${process.env.SERVER_TOKEN}`,
                // };
                // const graphicItDetails = await post(
                //   `${apiConfig.server.baseUrl}${Url}`,
                //   filePayload,
                //   hdr,
                // );
                const graphicItDetails = await getGraphicIterationDetailTool(
                  filePayload,
                );

                if (Object.keys(graphicItDetails).length > 0) {
                  resolve({
                    graphicDetails: graphicItDetails[0],
                    isSuccess: true,
                  });
                } else {
                  resolve({
                    completeTask: true,
                    error:
                      'iAuthor Image Conversion in Graphics stage is not completed',
                    isSuccess: false,
                  });
                }
              } catch (error) {
                resolve({ completeTask: true, error, isSuccess: false });
              }
            }
          }
        }
      } else {
        resolve();
      }
    } catch (error) {
      reject(error);
    }
  });
};
export const getGraphicStageActivityDetailsTool = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { activityName, wfdefid } = payload;
      // let sql = `select activityid,activityname from wms_mst_activity where lower(activityname) like '${activityName}' `
      const sql = `select act.activityid,act.activityname,wf.activitytype from wms_mst_activity  as act
        join wms_workflowdefinition as wf on wf.activityid = act.activityid
        where lower(act.activityname) like '${activityName}' or wf.wfdefid = ${wfdefid} `;
      let sourceActivityName = await query(sql, []);
      let sourceActivityFailedName = [];
      if (
        sourceActivityName &&
        sourceActivityName.length > 0 &&
        sourceActivityName[0].activitytype == 'External Task'
      ) {
        const activityNewName = `${activityName}_f`;
        const sql1 = `select act.activityid,act.activityname,wf.activitytype from wms_mst_activity  as act
            join wms_workflowdefinition as wf on wf.activityid = act.activityid
            where lower(act.activityname) like '${activityNewName}' `;
        sourceActivityFailedName = await query(sql1, []);
      }
      if (
        sourceActivityName &&
        sourceActivityName.length > 0 &&
        sourceActivityName[0].activitytype == 'External Task'
      ) {
        const result = [];
        sourceActivityName = [
          ...sourceActivityName,
          ...sourceActivityFailedName,
        ];
        sourceActivityName.forEach(list => {
          result.push({
            activityId: list.activityid,
            activityName: list.activityname,
            stageId: 10,
            stageName: 'Graphics',
            activityType: list.activitytype,
          });
        });
        resolve(result);
      } else if (
        sourceActivityName &&
        sourceActivityName.length > 0 &&
        sourceActivityName[0].activitytype == 'User Task'
      ) {
        resolve({
          activityId: sourceActivityName[0].activityid,
          activityName: sourceActivityName[0].activityname,
          stageId: 10,
          stageName: 'Graphics',
          activityType: sourceActivityName[0].activitytype,
        });
      } else {
        resolve({});
      }
    } catch (error) {
      reject(error);
    }
  });
};
export const getGraphicIterationDetailTool = payload => {
  return new Promise((resolve, reject) => {
    try {
      let sql = '';
      const { woId, activityId, stageId, needOnlyCompleted } = payload;
      if (needOnlyCompleted) {
        sql = `select * from wms_workflow_eventlog as eventlog
          join wms_workflowdefinition as wfd on wfd.wfdefid = eventlog.wfdefid
          where eventlog.workorderid = ${woId} and wfd.stageid =${stageId} and wfd.activityid = ${activityId}  and activitystatus ='Completed'order by wfeventid desc limit  1`;
      } else {
        sql = `select * from wms_workflow_eventlog as eventlog
          join wms_workflowdefinition as wfd on wfd.wfdefid = eventlog.wfdefid
          where eventlog.workorderid = ${woId} and wfd.stageid =${stageId} and wfd.activityid = ${activityId} order by wfeventid desc`;
      }

      query(sql)
        .then(response => {
          // updated for fileconfig restructure
          response.forEach(item => {
            item.fileconfig = ReStructureFileConfig(item.fileconfig);
          });
          resolve(response);
        })
        .catch(error => {
          reject({ message: error });
        });
    } catch (error) {
      console.log(error, 'error');
    }
  });
};
export const getCupExpireDate = async (req, res) => {
  // Access `cust_Id` from query parameters
  const { cust_Id } = req.query;

  // Ensure `cust_Id` is provided
  if (!cust_Id) {
    return res.status(400).json({
      status: false,
      message: 'Customer ID is required',
    });
  }

  try {
    // SQL query to get `intervaldays` based on `cust_Id`
    const sql = `SELECT  (current_date + intervaldays) ::text as intervaldays  FROM mst_link_expire WHERE customerid = ${cust_Id}`;
    const data = await query(sql);

    // If data is returned successfully
    if (data.length > 0) {
      return res.status(200).json({
        status: true,
        data: data[0],
      });
    }
    // If no matching records are found
    return res.status(404).json({
      status: false,
      message: 'No expiration interval found for the provided Customer ID',
    });
  } catch (error) {
    // Error handling if query fails
    console.error('Error executing query:', error);
    return res.status(500).json({
      status: false,
      message: 'Failed to retrieve CUP Expire Date',
    });
  }
};

export const authoremailController = async (req, res) => {
  try {
    const out = await authoremailService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const authoremailService = async authorInfo => {
  let mailData = null; // Declare mailData in a broader scope

  try {
    let result = [];
    let itemresult = [];
    let pmresult = [];
    let mailresult = [];

    let script = '';
    script = `SELECT j.journalacronym ||'_'||  (ww.otherfield ->> 'pii')::text as itemcode, j.journalname ,ww.workorderid ,wd.stageid ,wd.wfdefid,
s.typesetpages ,
case when ww.otherfield ->> 'articletype' = 'book-review'
    and  coalesce (defaultauthor,FALSE) = FALSE then case 
	 when rr.role > 1 then 'Editors' else  'Editor' end 
 else 
 'Author' end as receiver ,j.journalid
FROM wms_workorder ww 
JOIN pp_mst_journal j ON j.journalid = ww.journalid
left join (select COUNT(r.roleid) as role, c.journalid from pp_mst_journal_contacts c 
join wms_role r on r.roleid = c.designation ::BIGINT and r.roleacronym = 'E'  group by  c.journalid) as rr on rr.journalid = j.journalid
join wms_workflowdefinition wd on wd.wfid = 25 and activityalias= 'PDF Despatch'
join wms_workorder_stage s on s.wfstageid = wd.stageid and ww.workorderid = s.workorderid 
left join (select TRUE as defaultauthor ,journalid from public.journal_notification_config  where stageid = 1 and emailconfig->>'to' = '["AUTHOR"]') as n on n.journalid = j.journalid
WHERE ww.workorderid = $1 
GROUP BY itemcode, j.journalname,ww.workorderid,wd.stageid ,wd.wfdefid,s.typesetpages,j.journalid,rr.role ,n.defaultauthor`;
    itemresult = await query(script, [authorInfo.authorInfo]);

    script = `select cm.contactemail from (  SELECT string_agg(contactemail,',')  as contactemail 
FROM public.wms_workorder_contacts 
JOIN wms_workorder ww 
  ON ww.workorderid = wms_workorder_contacts.workorderid 
WHERE wms_workorder_contacts.workorderid = $1 
   AND (
    ((otherfield ->> 'articletype' IS DISTINCT FROM 'book-review' OR otherfield ->> 'articletype' IS NULL OR TRIM(otherfield ->> 'articletype') = '') 
     AND contactrole = 'AUTHOR')
  )
     union all 
     SELECT string_agg(email,',')  as contactemail
from wms_workorder w
join pp_mst_journal_contacts c  on c.journalid = w.journalid
join wms_role r on r.roleid = c.designation ::BIGINT 
  AND (
        r.roleacronym = 'E' 
        OR r.roleacronym ILIKE '%'||(
            SELECT json_array_elements_text(emailconfig->'bookreview_to') 
            FROM public.journal_notification_config 
            WHERE journalid = w.journalid and stageid = 1 
        )||'%'
    )
WHERE w.workorderid = $1 
  AND   otherfield ->> 'articletype' = 'book-review' 
  ) as cm
  where cm.contactemail  is not null`;
    result = await query(script, [authorInfo.authorInfo]);

    script = `SELECT contactname, contactemail, contactrole FROM public.wms_workorder_contacts WHERE workorderid = $1 AND contactrole = 'PM'`;
    pmresult = await query(script, [authorInfo.authorInfo]);

    script = ` select case when count (ww.workorderid)  >= 1 then true else false end as mailsent
    from cup_mail_service_logs cmsl  
    join wms_workorder ww on ww.otherfield ->> 'pii' = cmsl.item 
    where  ww.workorderid = $1  LIMIT 1`;
    mailresult = await query(script, [authorInfo.authorInfo]);

    if (pmresult.length === 0) {
      const mailLogData = {
        username: result[0]?.contactname || '',
        toemail:
          typeof result[0]?.contactemail === 'string' &&
          result[0]?.contactemail.trim() !== ''
            ? result[0].contactemail.split(',').map(email => email.trim())
            : [],
        firstname: result[0]?.contactname || '',
        pmname: pmresult[0]?.contactname || '',
        pmemail: pmresult[0]?.contactemail || '',
        URL: authorInfo.link,
        item: itemresult?.[0]?.itemcode || '',
        journal: itemresult?.[0]?.journalname || '',
        journalid: itemresult?.[0]?.journalid,
        year: new Date().getFullYear(),
        workorderId: itemresult?.[0]?.workorderid || '',
        stageId: itemresult?.[0]?.stageid || '',
        wfDefId: itemresult?.[0]?.wfdefid || '',
        prevmailsent: mailresult?.[0]?.mailsent || false,
        page: itemresult?.[0]?.typesetpages || '',
        receiver: itemresult?.[0]?.receiver || '',
        mailAction: 'cupauthor-email',
      };

      await saveMailLog(mailLogData, 'FAILED', 'PM Email address not found.');
      throw new Error(
        'From Email address not found. Please enter a valid email.',
      );
    }

    if (result.length === 0) {
      const mailLogData = {
        username: result[0]?.contactname || '',
        toemail:
          typeof result[0]?.contactemail === 'string' &&
          result[0]?.contactemail.trim() !== ''
            ? result[0].contactemail.split(',').map(email => email.trim())
            : [],
        firstname: result[0]?.contactname || '',
        pmname: pmresult[0]?.contactname || '',
        pmemail: pmresult[0]?.contactemail || '',
        URL: authorInfo.link,
        item: itemresult?.[0]?.itemcode || '',
        journal: itemresult?.[0]?.journalname || '',
        journalid: itemresult?.[0]?.journalid,
        year: new Date().getFullYear(),
        workorderId: itemresult?.[0]?.workorderid || '',
        stageId: itemresult?.[0]?.stageid || '',
        wfDefId: itemresult?.[0]?.wfdefid || '',
        prevmailsent: mailresult?.[0]?.mailsent || false,
        page: itemresult?.[0]?.typesetpages || '',
        receiver: itemresult?.[0]?.receiver || '',
        mailAction: 'cupauthor-email',
      };

      await saveMailLog(mailLogData, 'FAILED', 'To address not found.');
      throw new Error('To address not found. Please enter a valid email.');
    }

    console.log('url', authorInfo.link);

    mailData = {
      username: result[0].contactname,
      toemail:
        typeof result[0]?.contactemail === 'string' &&
        result[0]?.contactemail.trim() !== ''
          ? result[0].contactemail.split(',').map(email => email.trim())
          : [],
      firstname: result[0].contactname,
      pmname: pmresult[0]?.contactname || '',
      pmemail: pmresult[0]?.contactemail || '',
      URL: authorInfo.link,
      item: itemresult?.[0]?.itemcode || '',
      journal: itemresult?.[0]?.journalname || '',
      journalid: itemresult?.[0]?.journalid,
      year: new Date().getFullYear(),
      workorderId: itemresult?.[0]?.workorderid || '',
      stageId: itemresult?.[0]?.stageid || '',
      wfDefId: itemresult?.[0]?.wfdefid || '',
      prevmailsent: mailresult?.[0]?.mailsent || false,
      page: itemresult?.[0]?.typesetpages || '',
      receiver: itemresult?.[0]?.receiver || '',
      mailAction: 'cupauthor-email',
    };

    try {
      await sendAuthorMail(mailData);
    } catch (mailError) {
      console.error('Mail Service Error:', mailError);

      await saveMailLog(mailData, 'FAILED', mailError.message);

      return {
        isSuccess: false,
        message: 'Failed to send email',
      };
    }

    return {
      isSuccess: true,
      message: 'Email sent successfully',
      data: result,
    };
  } catch (error) {
    console.error('Service Error:', error);

    if (mailData) {
      await saveMailLog(mailData, 'FAILED', error.message);
    }

    return { isSuccess: false, message: error.message };
  }
};

export async function sendAuthorMail(data) {
  const {
    username,
    toemail,
    firstname,
    URL,
    pmname,
    pmemail,
    edemail,
    item,
    journal,
    journalid,
    workorderId,
    stageId,
    wfDefId,
    prevmailsent,
    page,
    receiver,
  } = data;

  let mailData;
  let script = '';
  let emailconfig;

  try {
    const resForConfig = await getauthorpdfEmailTemplate(journalid);
    if (!resForConfig || resForConfig.length === 0) {
      throw new Error('Email template not found.');
    }

    script = `
   select contactrole as roleacronym, trim(contactemail)  as email from wms_workorder_contacts wwc where workorderid = $1 
and contactrole = 'AUTHOR' group by contactemail,contactrole
union all
select roleacronym,trim(email) as email from pp_mst_journal_contacts pmjc 
join wms_role r on pmjc.designation ::int  = r.roleid and r.roleid <> 7
where journalid = $2 group by roleacronym,email`;
    const defaultmail = await query(script, [workorderId, journalid]);

    //  const { emailconfig } = resForConfig[0];
    emailconfig = resForConfig?.[0]?.emailconfig;
    if (!emailconfig || !emailconfig.from || !emailconfig.to) {
      throw new Error('Invalid email configuration retrieved.');
    }

    ['to', 'cc', 'bcc'].forEach(type => {
      const updatedList = resForConfig[0].emailconfig[type].flatMap(sublist => {
        const matchedEmails = defaultmail
          .filter(list => list.roleacronym === sublist)
          .map(list => list.email || list.journalemail)
          .filter(email => email);
        return matchedEmails.length > 0 ? matchedEmails : [sublist];
      });
      resForConfig[0].emailconfig[type] = [...new Set(updatedList)];
    });

    if (receiver != 'Author') {
      ['bookreview_cc'].forEach(type => {
        const updatedList = resForConfig[0].emailconfig[type].flatMap(
          sublist => {
            const matchedEmails = defaultmail
              .filter(list => list.roleacronym === sublist)
              .map(list => list.email || list.journalemail)
              .filter(email => email);
            return matchedEmails.length > 0 ? matchedEmails : [sublist];
          },
        );
        resForConfig[0].emailconfig.cc = [...new Set(updatedList)];
      });
    }

    if (resForConfig[0]?.emailconfig.to_authoronly != true) {
      emailconfig.to.push(...toemail);
    }

    emailconfig.cc = emailconfig.cc.filter(email => email.includes('.'));
    emailconfig.to = emailconfig.to.filter(email => email.includes('.'));

    mailData = {
      ...emailconfig,
      username,
      toemail,
      URL,
      pmname,
      pmemail,
      edemail,
      item,
      journal,
      firstname,
      workorderId,
      stageId,
      wfDefId,
      prevmailsent,
      receiver,
      page,
    };

    // Ftp upload process started
    // Ftp typeimp sheet upload  pdf dispatch/firstproof stage cup journal start

    const sql1 = `  select dm.duid ,
	   	      du.duname ,
	   	      ww.customerid,
            ww.itemcode,
	   	      cu.customername ,
	   	      ws.serviceid ,
	   	      s.servicename ,
	   	      w.stageid ,
	   	      st.stagename ,
	   	      e.stageiterationcount ,
	   	      w.activityid ,
	   	      a.activityname ,
	   	      w.activityalias ,
	   	    e.activityiterationcount,
			   e.actualactivitycount,
	   	      i.woincomingid ,
	   	      id.woincomingfileid ,
	   	      e.wfeventid ,
	   	      ww.workorderid
	   			from wms_workflow_eventlog e
        join wms_workflowdefinition w on e.wfdefid = w.wfdefid
        join wms_workorder ww on e.workorderid = ww.workorderid
        join org_mst_customer_orgmap c on c.countryid = ww.countryid
             and c.customerid = ww.customerid
             and c.divisionid = ww.divisionid
             and c.subdivisionid = ww.subdivisionid
       join org_mst_customerorg_du_map dm on dm.custorgmapid = c.custorgmapid
       join org_mst_deliveryunit du on du.duid = dm.duid
       join org_mst_customer cu on cu.customerid = ww.customerid
       join wms_workorder_service ws on ws.workorderid  = ww.workorderid
       join wms_mst_service s on s.serviceid = ws.serviceid
       join wms_mst_stage st on st.stageid = w.stageid
       join wms_mst_activity a on a.activityid = w.activityid
       left join wms_workorder_incoming i on i.woid = ww.workorderid
       		and i.serviceid = ws.serviceid
       left join wms_workorder_incomingfiledetails id on id.woincomingid = i.woincomingid 
	   where ww.workorderid =${workorderId} and w.wfdefid =${wfDefId}`;

    const woInfo = await query(sql1);
    if (woInfo && woInfo.length > 0) {
      const woData = (woInfo.length > 0 && woInfo[0]) || [];
      let ftpRes = false;
      const validationFtp = `select * from wms_ftp_audit where wfeventid =${woData?.wfeventid} and status = 'Success'`;
      const validationCount = await query(validationFtp);

      if (validationCount && validationCount.length == 0) {
        const folderPathData = {
          type: 'wo_activity_file_subtype',
          du: {
            name: woData?.duname,
            id: woData?.duid,
          },
          customer: {
            name: woData?.customername,
            id: woData?.customerid,
          },
          workOrderId: workorderId,
          service: {
            name: woData?.servicename,
            id: woData?.serviceid,
          },
          stage: {
            name: woData?.stagename,
            id: woData?.stageid,
            iteration: woData?.stageiterationcount,
          },
          activity: {
            name: woData?.activityname,
            id: woData?.activityid,
            iteration: woData?.activityiterationcount,
            activityalias: woData?.activityalias,
            actualIteration: woData?.actualactivitycount,
          },
          fileType: {
            name: 'article',
            id: 4,
            fileId: woData?.woincomingfileid,
          },
        };
        const basePath = await getFolderStructure(folderPathData);
        const ftpPayload = {
          workorder: workorderId,
          stage: woData?.stagename,
          excelfilename: `${woData?.itemcode}.xlsx`,
          stageid: woData?.stageid,
          duid: woData?.duid,
          customerid: woData?.customerid,
          basePath,
          isEmail: false,
          attachFiles: [],
          wfeventId: woData?.wfeventid,
        };

        ftpRes = await ftpXLSheetUpload(ftpPayload);
      }
      if (ftpRes == true || validationCount.length > 0) {
        if (!prevmailsent == true) {
          emitAction(mailData);
          console.log('Email dispatched successfully:', mailData);

          await saveMailLog(mailData, 'SENT');
        } else {
          await saveMailLog(mailData, 'RESENT');
          console.log(
            `Email for item ${item} was already sent previously. Skipping emitAction.`,
          );
        }
      }
    } else {
      throw new Error('Workorder info not found.');
    }
    // Ftp typeimp sheet upload  pdf dispatch/firstproof stage cup journal end

    return true;
  } catch (error) {
    console.error('Error in sendPasswordMail:', error.message, {
      mailData,
      errorStack: error.stack,
    });

    if (mailData) {
      await saveMailLog(mailData, 'FAILED', error.message);
    }

    throw error;
  }
}

export const getauthorpdfEmailTemplate = async journalid => {
  try {
    const sql = `SELECT * from public.journal_notification_config WHERE journalid = ${journalid} and stageid = 1`;
    const resForConfig = await query(sql);
    if (resForConfig.length > 0) {
      return resForConfig;
    }
    return false;
  } catch (error) {
    return false;
  }
};

async function saveMailLog(mailData, status, errorMessage = null) {
  const logData = {
    to: mailData.toemail,
    from: mailData.journal,
    subject: mailData.notificationconfig?.subject || 'No Subject',
    body: JSON.stringify(mailData),
    item: mailData.item || 'N/A',
    journal: mailData.journal || 'N/A',
    status,
    errorMessage,
    timestamp: new Date().toISOString(),
  };

  const script = `
    INSERT INTO cup_mail_service_logs (
      to_email, from_email, subject, body, item, journal, status, error_message, timestamp
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`;
  const values = [
    logData.to,
    logData.from,
    logData.subject,
    logData.body,
    logData.item,
    logData.journal,
    logData.status,
    logData.errorMessage,
    logData.timestamp,
  ];

  try {
    await query(script, values);
    console.log('Mail log saved successfully:', logData);
  } catch (dbError) {
    console.error('Failed to save mail log:', dbError.message, logData);
  }
}

export const addiAuthorLog = async (req, res) => {
  const { iAuthorLog, iwms } = req.body;
  const iAuthorDetails = JSON.stringify(iAuthorLog);
  let updatesql = '';
  const checksql = `select dispatchtrnsid from iauthor_dispatch_trns where guid = (select guid from public.iauthor_transactions
     where workorderid = ${iwms.woId}  order by iauthourtrnsid desc limit 1)
     order by 1 desc limit 1`;

  await query(checksql)
    .then(async dispatchId => {
      if (dispatchId[0]?.dispatchtrnsid) {
        updatesql = `update iauthor_dispatch_trns set correction_payload='${iAuthorDetails}' where dispatchtrnsid = ${dispatchId[0]?.dispatchtrnsid}`;
        await query(updatesql)
          .then(async data => {
            res.status(200).json({
              data,
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({
              data: error.message ? error.message : error,
              status: false,
              message: 'Save link for inetCompare failed.',
            });
          });
      }
    })
    .catch(error => {
      res.status(400).send({
        data: error.message ? error.message : error,
        status: false,
        message: 'Save link for inetCompare failed.',
      });
    });
};

// Upload typeimp xl sheet in ftp
export const ftpXLSheetUpload = async payload => {
  return new Promise(async (resolve, reject) => {
    const {
      workorder,
      stage,
      excelfilename,
      stageid,
      customerid,
      duid,
      basePath,
      wfeventId,
    } = payload;

    let blobPath = '';
    try {
      const sql = `select journalacronym as "mnemonic",doi,typesetpages as "number of pages",title,'' as"copy to copyed",'' as "copy to typesetter",
    to_char(ipdfproofcreated, 'DD-MM-YYYY') as "first proof rec'd",
    to_char(collationenabled, 'DD-MM-YYYY') as "for correction",
    to_char(pmreviewcompleted1, 'DD-MM-YYYY') as "revised proof",
    to_char(revisesreceived2, 'DD-MM-YYYY') as "for correction v1",
    to_char(pmreviewcompleted2, 'DD-MM-YYYY')  as "revised proof 1",
    to_char(revisesreceived3, 'DD-MM-YYYY') as "for correction v2",
    to_char(pmreviewcompleted3, 'DD-MM-YYYY') as "revised proof 2",
    to_char(firstview, 'DD-MM-YYYY') as "firstview",
    to_char(revisedfirstview1, 'DD-MM-YYYY') as "revised firstview1",
    to_char(revisedfirstview2, 'DD-MM-YYYY') as "revised firstview2",
    to_char(revisedfirstview3, 'DD-MM-YYYY') as "revised firstview3"  
             from getpdfproof_report_new('${workorder}','${stage}')`;

      console.log(sql, 'getcollationreport');
      const report = await query(sql);
      const validationFtp = `select * from wms_ftp_audit where wfeventid =${wfeventId} and status = 'Success'`;
      const validationCount = await query(validationFtp);
      if (validationCount && validationCount.length == 0) {
        // to read the xlsx file from selected path
        let outputFilePath = join(__filename, '../../../../../');

        outputFilePath = join(outputFilePath, 'upload/cupJournals.xlsx');

        let tempFilePath = join(__filename, '../../../../../');

        const temp1 = `${tempFilePath}upload/temps`;
        await makeDir(temp1);
        const temp2 = `${tempFilePath}upload/temps/${workorder}`;
        await removeFolder(temp2);
        await makeDir(temp2);

        tempFilePath = join(
          tempFilePath,
          `upload/temps/${workorder}/cupJournals.xlsx`,
        );
        await copyXlsxFile(outputFilePath, tempFilePath);

        const cells = [
          'A2',
          'B2',
          'C2',
          'D2',
          'E2',
          'F2',
          'G2',
          'H2',
          'I2',
          'J2',
          'K2',
          'L2',
          'M2',
        ];
        const cells1 = [
          'A1',
          'B1',
          'C1',
          'D1',
          'E1',
          'F1',
          'G1',
          'H1',
          'I1',
          'J1',
          'K1',
          'L1',
          'M1',
        ];

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(tempFilePath);
        const worksheet = workbook.getWorksheet('Sheet1'); // Replace 'Sheet1' with the actual sheet name
        for (let i = 0; i < cells.length; i++) {
          const cell = worksheet.getCell(cells[i]);
          const cell1 = worksheet.getCell(cells1[i]);
          cell.value =
            typeof report[0][cell1] === 'number'
              ? +report[0][cell1]
              : report[0][cell1];
        }
        const xlFilenameForUpload =
          appendUnderscoreBeforeFirstNumber(excelfilename);
        // Save the changes
        await workbook.xlsx.writeFile(tempFilePath);
        const fileDetails = {
          tempFilePath,
          name: xlFilenameForUpload,
        };

        const uploadRes = await _upload(fileDetails, basePath);
        console.log('Kaniiiiii', uploadRes);
        blobPath = uploadRes.fullPath;
        const srcInfo = {
          path: `${tempFilePath}`,
        };
        const targetInfo = {
          filename: `${report[0].doi}.xlsx`,
        };
        const checkValidExcel = await validateExcel(tempFilePath);
        if (!checkValidExcel.isValid) {
          throw checkValidExcel;
        }

        targetInfo.tempFileName = `${parse(targetInfo.filename).name}.io`;
        const ftpRes = await invokeFileUploadToFTP(
          'cup_ftp_fileUpload',
          srcInfo,
          targetInfo,
        );

        if (ftpRes && ftpRes.isSuccess) {
          // To send customer campus signal start
          const campusQuery = `SELECT wms_mst_stage.stagename,pp_mst_journal.journalid,pp_mst_journal.otherdetails ->> 'isSignal' AS iscampustrigger,
          wms_workflow_eventlog.stageiterationcount,wms_workflow_eventlog.wfdefid
          FROM wms_workorder 
          JOIN pp_mst_journal ON wms_workorder.journalid = pp_mst_journal.journalid 
          JOIN wms_workflow_eventlog on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
          JOIN wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid and issignal = true
          JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
          where wfeventid = ${wfeventId}`;

          const response = await query(campusQuery);

          if (
            response &&
            response.length > 0 &&
            response[0].iscampustrigger === 'true'
          ) {
            // Trigger Campus Signal
            const signalPayload = {
              workorderId: workorder,
              stageName: response[0].stagename,
              stageIteration: response[0].stageiterationcount,
              payloadType: 'dynamicPayload',
              flowType: 'activity',
              isRound: response[0].stagename != 'First Proof',
              isPagecount: response[0].stagename == 'First Proof',
            };
            const campRes = await _sendCampusSignal(signalPayload);
            console.log(campRes, 'campRes');
          }
          // To send customer campus signal end
          const sql2 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,remarks,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Success', 'File Uploaded Successfully' ,current_timestamp,${wfeventId},'${blobPath}')`;
          const reponse2 = await query(sql2);
          await removeFolder(temp2);
          resolve(ftpRes.isSuccess);
          console.log(reponse2, 'reponse2');
        } else {
          await removeFolder(temp2);
          throw ftpRes;
        }
      } else {
        resolve(true);
      }
    } catch (e) {
      const message = e.message ? e.message : e;
      const sql3 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,remarks,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Failed','${message}', current_timestamp,${wfeventId},'${blobPath}')`;
      await query(sql3);
      reject(message);
    }
  });
};

function appendUnderscoreBeforeFirstNumber(inputString) {
  const match = inputString.match(/\d/);
  if (match) {
    // Insert an underscore before the first numeric character
    const { index } = match;
    const modifiedString = `${inputString.slice(0, index)}_${inputString.slice(
      index,
    )}`;
    return modifiedString;
  }
  return inputString;
}

export const getPii = async (req, res) => {
  const { authorInfo } = req.body;

  if (!authorInfo) {
    return res.status(400).json({
      status: false,
      message: 'Workorder ID is required',
    });
  }

  try {
    const sql = `SELECT  otherfield ->> 'pii' ||'.pdf' ::text as pii  FROM wms_workorder WHERE workorderid = ${authorInfo}`;
    const data = await query(sql);

    if (data.length > 0) {
      return res.status(200).json({
        status: true,
        data: data[0],
      });
    }

    return res.status(404).json({
      status: false,
      message: 'No Pii found for the provided Workorder ID',
    });
  } catch (error) {
    console.error('Error executing query:', error);
    return res.status(500).json({
      status: false,
      message: 'Failed to retrieve Pii',
    });
  }
};
