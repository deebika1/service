import axios from 'axios';
import { query } from '../../../database/postgres.js';
import { buildConfig } from '../../../httpClient/builder.js';
import { config } from '../../../config/restApi.js';
import { emitEvent } from '../../../socket/index.js';
import { getNotificationTemplate } from '../../common/index.js';
import { emitAction } from '../../activityListener/activityListener.js';
import logger from '../logs/index.js';

export const createAPIRequestId = async (req, res) => {
  try {
    const {
      wfeventId,
      toolsId,
      isForegroundService,
      userId,
      actualActivityCount,
    } = req.body;
    const apiId = await _createAPIRequestId({
      wfeventId,
      toolsId,
      isForegroundService,
      userId,
      actualActivityCount,
    });
    res.status(200).json(apiId);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _createAPIRequestId = ({
  wfeventId,
  toolsId,
  isForegroundService,
  userId,
  actualActivityCount,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `INSERT INTO wms_tools_api(wfeventid, toolid, status, isforegroundservice, userid, actualactivitycount,isactive) VALUES ($1, $2, $3, $4, $5,$6,$7) returning apiid`;
      const [{ apiid: apiId }] = await query(sql, [
        wfeventId,
        toolsId,
        'InProgress',
        isForegroundService,
        userId,
        actualActivityCount,
        true,
      ]);

      const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
      await query(sql1, [
        apiId,
        wfeventId,
        toolsId,
        'Created',
        new Date(),
        userId,
      ]);
      resolve(apiId);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const updateAPIRequestId = async (req, res) => {
  try {
    const { apiId, inputParams } = req.body;
    await _updateAPIRequestId({ apiId, inputParams });
    res.status(200).send(true);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _updateAPIRequestId = ({ apiId, inputParams }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `UPDATE wms_tools_api SET inputparams = $1, status = $2, starttime =$3 WHERE apiid = $4 returning apiid, wfeventid,toolid,userid`;
      const [{ wfeventid: wfeventId, toolid: toolsId, userid: userId }] =
        await query(sql, [inputParams, 'InProgress', new Date(), apiId]);
      if (wfeventId && toolsId && userId) {
        const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
        await query(sql1, [
          apiId,
          wfeventId,
          toolsId,
          'InProgress',
          new Date(),
          userId,
        ]);
      }

      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const _updatePitstopProfile = ({ apiId, pitstopPath }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `UPDATE wms_tools_api SET profilepath = $1 WHERE apiid = $2 returning toolid`;
      const [{ toolid: toolsId }] = await query(sql, [pitstopPath, apiId]);

      console.log('toolid', toolsId);
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const _updateIntermediateAPIRequestId = ({ apiId }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `UPDATE wms_tools_api SET status = $1, remarks = $2 WHERE apiid = $3 returning apiid, wfeventid,toolid,userid`;
      const [{ wfeventid: wfeventId, toolid: toolsId, userid: userId }] =
        await query(sql, ['Failure', 'Due to Max Retry exhausted', apiId]);
      if (wfeventId && toolsId && userId) {
        const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
        await query(sql1, [
          apiId,
          wfeventId,
          toolsId,
          'Failure',
          new Date(),
          userId,
        ]);
      }

      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const completeAPIRequestId = async (req, res) => {
  try {
    const {
      apiId,
      status,
      remarks,
      onSave,
      response = {},
      sId,
      tooloutputid,
      isFileAvailable,
      actualActivityCount,
    } = req.body;
    const apiDetails = await _completeAPIRequestId({
      apiId,
      status,
      remarks,
      response,
      onSave,
      sId,
      tooloutputid,
      isFileAvailable,
      actualActivityCount,
    });
    res.status(200).send(apiDetails);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _completeAPIRequestId = ({
  apiId,
  onSave,
  status,
  remarks,
  response = {},
  sId,
  isFileAvailable = true,
  actualActivityCount,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      let getToolsEntry = [];
      const sql = `UPDATE wms_tools_api SET status = $1, endtime = $2, remarks = $3, response = $4, isfileavailable=$6 WHERE apiid = $5 returning wfeventid, isforegroundservice, toolid,userid`;
      const [
        {
          wfeventid: wfeventId,
          isforegroundservice: isForegroundService,
          toolid: toolsId,
          userid: userId,
        },
      ] = await query(sql, [
        status,
        new Date(),
        remarks,
        response,
        apiId,
        isFileAvailable,
      ]);

      if (wfeventId && toolsId && userId) {
        const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
        await query(sql1, [
          apiId,
          wfeventId,
          toolsId,
          status,
          new Date(),
          userId,
        ]);
      }

      // send signal for complete
      if (remarks !== 'On save validation failed' && onSave != true) {
        emitEvent(sId, 'okmStatus', {
          data: { toolid: toolsId, response, remarks },
          status,
          isToolCompleted: status === 'Success',
        });
      }
      // const sql2 = `SELECT * FROM  wms_tools_api  WHERE wfeventid = $1 `;
      const sql2 = `SELECT tool.apiid,tool.wfeventid,tool.toolid,tool.inputparams,tool.status,tool.starttime,tool.endtime,tool.isforegroundservice,tool.userid,tool.remarks,tool.response,eventlog.workorderid,eventlog.wfdefid,wfdef.activitytype,tool.isfileavailable FROM public.wms_tools_api as tool
            join wms_workflow_eventlog as eventlog on eventlog.wfeventid = tool.wfeventid
            join wms_workflowdefinition as wfdef on wfdef.wfdefid = eventlog.wfdefid
             WHERE tool.wfeventid = $1 and tool.actualactivitycount = $2 and tool.isactive = $3`;
      getToolsEntry = await query(sql2, [wfeventId, actualActivityCount, true]);
      console.log(getToolsEntry, 'getToolsEntry');
      resolve({
        wfeventId,
        isForegroundService,
        toolsId,
        getToolsEntry,
      });
    } catch (e) {
      logger.info(`_completeAPIRequestId ${e.message ? e.message : e}`);
      reject(e.message ? e.message : e);
    }
  });
};

export const buildApiConfig = async (req, res) => {
  try {
    const { iwms, files, apiConfig, basePath } = req.body;
    // eslint-disable-next-line no-shadow
    const config = await _buildApiConfig(iwms, files, apiConfig, basePath);
    res.status(200).send(config);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _buildApiConfig = (iwms, files, apiConfig, basePath = '') => {
  return new Promise(async (resolve, reject) => {
    try {
      apiConfig.input = apiConfig.input ? apiConfig.input : {};
      apiConfig.input.rawData = apiConfig.input.rawData
        ? apiConfig.input.rawData
        : {};
      apiConfig.input.rawData.files = files;
      apiConfig.input.rawData.iwms = iwms;
      apiConfig.url = basePath ? basePath + apiConfig.url : apiConfig.url;
      // eslint-disable-next-line no-shadow
      const config = buildConfig(apiConfig);
      resolve(config);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getToolsStatusForServiceTask = async (req, res) => {
  try {
    const { wfeventId, toolId } = req.body;

    const response = await startPollingForServiceUserTask(wfeventId, toolId);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
export const checkToolLatestStatus = async (req, res) => {
  try {
    const { wfeventId, toolId } = req.body;
    const response = await toolSuccessStatus(wfeventId, toolId);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send(e.message || e);
  }
};

export const toolSuccessStatus = async (wfeventId, toolId) => {
  try {
    const result = await query(
      `SELECT status FROM wms_tools_api WHERE wfeventid = $1 AND toolid = $2 ORDER BY apiid DESC LIMIT 1`,
      [wfeventId, toolId],
    );
    return result?.[0]?.status === 'Success';
  } catch (e) {
    throw new Error(e.message || e);
  }
};
export const getToolsStatusForAsync = (wfeventId, toolId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM public.wms_tools_api where wfeventid=$1 and toolid =$2 order by apiid desc limit 1`;
      const toolStatus = await query(sql, [wfeventId, toolId]);

      resolve(toolStatus);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const startPollingForServiceUserTask = async (wfeventId, toolId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const entries = await getToolsStatusForAsync(wfeventId, toolId);

      if (
        (entries && entries.length > 0 && entries[0].status === 'Success') ||
        (entries && entries.length > 0 && entries[0].status === 'Failure')
      ) {
        resolve(entries);
      } else {
        resolve(entries);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getNLPDetails = async (req, res) => {
  console.log('Received Payload:', req.body);
  const {
    workorderId,
    stageId,
    activityId,
    duId,
    xmlContent,
    woName,
    is_iNLP_Queue = false,
    iwms,
    retryDetails,
  } = req.body;

  try {
    if (retryDetails?.isRetry) {
      const failureEntryLog = {
        wfeventId: iwms.wfEventId,
        status: 'Failed',
        userId: iwms.userId,
        actualActivityCount: iwms.actualActivityCount,
        usercomments: retryDetails.errMsg,
      };
      await AddUpdateEventLogDetails(failureEntryLog);
    }
    // Check if the process is API-based
    const apiCheckSql = `
      SELECT isapicheck
      FROM public.mst_language_variant
      WHERE duid = $1
      LIMIT 1;
    `;

    const apiCheckResult = await query(apiCheckSql, [duId]);
    const isApiBased = apiCheckResult[0]?.is_api_check === true;

    if (isApiBased) {
      const apiResponse = await axios.post(
        'http://apibroker-live.6d5dbbfb059a436da511.centralindia.aksapp.io/v3/langDetect',
        xmlContent,
        {
          headers: {
            'Content-Type': 'application/xml',
          },
        },
      );

      const { languageVariant } = apiResponse.data;
      // Insert the language variant into the mst_language_variant table
      const insertLanguageVariantSql = `
            INSERT INTO public.mst_language_variant (duid, languagevariant)
            VALUES ($1, $2)
            ON CONFLICT (duid) DO UPDATE SET languagevariant = EXCLUDED.languagevariant;
          `;
      await query(insertLanguageVariantSql, [duId, languageVariant]);
      console.log('Language variant inserted successfully');
    }
    // Check if the process is score-based
    const scoreCheckSql = `
      SELECT is_score_check
      FROM mst_nlpscore
      WHERE duid = $1
      LIMIT 1;
    `;
    const scoreCheckResult = await query(scoreCheckSql, [duId]);
    const isScoreBased = scoreCheckResult[0]?.is_score_check === true;

    if (!isScoreBased) {
      // Normal workflow if not score-based
      res.json({
        completeTask: true,
        isSuccess: true,
        message: 'Normal workflow executed as scorecheck is NO',
      });
      return;
    }

    const sql = `
           SELECT
    it.guid AS article_guid,
    35 AS aty_id,
    imc.iauthcustomerid AS customerid,
    j.journalacronym AS JournalCode,
    'v2' AS NLP_version,
    ww.workorderid,
    ml.languagecode,
  mlv.languagevariant,
  mcv.customer,
  mcv.customervariant
FROM wms_workorder ww
JOIN iauthor_transactions it ON it.workorderid = ww.workorderid
JOIN org_mst_customer_orgmap co ON co.customerid = ww.customerid
JOIN iauthor_mst_customer imc ON imc.custorgmapid = co.custorgmapid
JOIN pp_mst_journal j ON j.journalid = ww.journalid
JOIN public.mst_language_variant mlv ON mlv.languageid = ww.languageid and mlv.customerid = ww.customerid and (ww.duid is null or mlv.duid = ww.duid)
JOIN wms_mst_language ml on ml.languageid = mlv.languageid
LEFT JOIN mst_customer_variant mcv on mcv.customerid = ww.customerid and mcv.wfid = ww.wfid and mcv.isactive = true
WHERE ww.workorderid = $1
  AND it.stageid = $2
LIMIT 1;
`;

    const toolStatus = await query(sql, [workorderId, stageId]);
    console.log('Tool Status:', toolStatus);

    if (toolStatus && toolStatus.length > 0) {
      const {
        article_guid,
        aty_id,
        customerid: CustomerID,
        journalcode: JournalCode,
        nlp_version: NLP_version,
        languagecode: Language,
        languagevariant: Language_variant,
        customer,
        customervariant: customer_variant,
      } = toolStatus[0];

      let requestPayload = {
        article_guid,
        aty_id,
        CustomerID,
        JournalCode,
        NLP_version,
        Language,
        Language_variant,
        customer,
        customer_variant,
      };

      if (is_iNLP_Queue) {
        requestPayload = {
          ...requestPayload,
          iwms,
        };
      }

      console.log('Request Payload for NLP API:', requestPayload);
      const finalUrl = `${config.iAuthor.base_url()}${
        is_iNLP_Queue ? config.iAuthor.nlpScoreQueue : config.iAuthor.nlpScore
      }`;
      console.log('Final URL:', finalUrl);

      const configAPI = {
        method: 'post',
        url: finalUrl,
        headers: {
          clientid: config.iAuthor.clientid,
          apikey: config.iAuthor.apikey,
        },
        data: requestPayload,
      };
      console.log('API Request Config:', configAPI);

      try {
        const response = await axios(configAPI);
        console.log('NLP API Response:', response.data);

        if (response.data.NLPGuid) {
          const insertSql = `
            INSERT INTO public.inlp_transactions
              ( customerid, workorderid, stageid, activityId,  guid, score, trackgrade, remarks)
            VALUES
              ($1, $2,  $3, $4, $5, $6 ::varchar, $7 ::varchar, $8);
          `;

          const { NLPGuid, Score, TrackGrade } = response.data;
          await query(insertSql, [
            CustomerID,
            workorderId,
            stageId,
            activityId,
            NLPGuid,
            Score,
            TrackGrade,
            'iNLP Transaction Successful',
          ]);
          response.data.is_success = true;
          console.log('NLP Transaction Inserted Successfully');
        }
        res.status(200).send(response.data);
      } catch (apiError) {
        console.error('API Error Response:', apiError.response?.data);
        // Insert failure record into the failure table
        const insertFailureSql = `
  INSERT INTO public.inlp_transactions
    ( customerid, workorderid, stageid, activityId, guid, remarks)
            VALUES
              ($1, $2,  $3, $4, $5, $6);
          `;
        await query(insertFailureSql, [
          CustomerID,
          workorderId,
          stageId,
          activityId,
          article_guid,
          apiError.response?.data?.message ||
            apiError.message ||
            'Unknown error',
        ]);
        if (!is_iNLP_Queue) {
          const mailPayload = {
            action: 'acsnlpfailure_emailsent',
            workorderId,
            woTypeId: 1,
            customerId: '',
            to: [],
            title: workorderId,
            chapterName: '',
            stageName: 'Test',
            message: 'Nlp failure for this workorderid',
            woName,
          };
          await sendMailForCamsJob(mailPayload);
        }
        res.status(apiError.response?.status || 500).json({
          completeTask: false,
          is_success: false,
          error:
            apiError.response?.data?.message ||
            apiError.message ||
            'Error calling NLP API',
        });
      }
    } else {
      res.json({
        completeTask: true,
        is_success: false,
        error: 'Tool status is invalid or empty',
      });
    }
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({
      completeTask: false,
      is_success: false,
      error: error.message || 'Internal Server Error',
    });
  }
};

const AddUpdateEventLogDetails = (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { status } = data;
      let sql = ``;
      let { wfeventId } = data;
      const val = [];
      wfeventId = Array.isArray(wfeventId) ? wfeventId : [wfeventId];
      wfeventId.forEach(id => {
        val.push(
          `(${id},'${status}',current_timestamp, '${data.usercomments || ''}')`,
        );
      });
      sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp,usercomments) VALUES ${val}`;
      if (client) {
        await client.query(sql);
      } else {
        await query(sql);
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
const sendMailForCamsJob = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        action,
        to,
        customerId,
        message,
        title,
        stageName,
        woTypeId,
        woName,
      } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        customerId,
        woTypeId,
      };
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        woName,
        stageName,
        subMessage: message,
        toMail: toMailArray,
      };
      await emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};
