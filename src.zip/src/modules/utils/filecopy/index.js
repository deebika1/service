import { Service } from '../../../httpClient/index.js';
import { query } from '../../../database/postgres.js';
import { config } from '../../../config/restApi.js';
import { getWorkflowPlaceHolders } from '../../task/fileDetails.js';
import { getFormattedName } from '../fileValidation/utils.js';

const service = new Service();
// file copy external blob to local
export const copyExternalBlobToLocal = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        srcPath,
        destBasePath,
        name,
        customerName,
        customerId,
        containerType,
      } = data;
      const { confvalue, type } = await getContainerInfo({
        customerId,
        containerType,
      });
      if (type == 'e2e') {
        const containerInfo = confvalue;
        const source = encodeURI(srcPath);
        const dest = encodeURI(destBasePath + name);
        const sourceCustomer = customerName;
        const payload = {
          source,
          dest,
          sourceCustomer,
          containerInfo,
        };
        const response = await service.post(
          config.local_rest.base_url +
            config.local_rest.uri.copyExternalBlobToLocal,
          payload,
        );
        resolve(response.data);
      } else {
        reject('Customer container info not found');
      }
    } catch (error) {
      reject(error);
    }
  });
};
// file copy external blob to blob
export const copyExternalBlobToBlob = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        srcPath,
        destBasePath,
        name,
        customerName,
        customerId,
        containerType,
      } = data;
      const { confvalue, type } = await getContainerInfo({
        customerId,
        containerType,
      });
      if (type == 'e2e') {
        const containerInfo = confvalue;
        const source = encodeURI(srcPath);
        const dest = encodeURI(destBasePath + name);
        const sourceCustomer = customerName;
        const payload = {
          source,
          dest,
          sourceCustomer,
          containerInfo,
        };
        const response = await service.post(
          config.blob_rest.base_url +
            config.blob_rest.uri.copyExternalBlobToBlob,
          payload,
        );
        resolve(response.data);
      } else {
        reject('Customer container info not found');
      }
    } catch (error) {
      reject(error);
    }
  });
};

// get container info based on customer
const getContainerInfo = data => {
  const { customerId, containerType } = data;
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select confvalue::json, type from wms_mst_configurationdetails where customerid = ${customerId} and isactive = true and type = '${containerType}'`;
      const result = await query(sql);
      if (result.length > 0) {
        resolve(result[0]);
      } else {
        reject('Customer container info not found');
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const _localcopyFile = ({ srcPath, name, destBasePath }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        docId: srcPath,
        dstId: destBasePath + name,
      };
      const response = await service.post(
        config.local_rest.base_url +
          config.local_rest.uri.localmultiplefileCopy,
        payload,
      );
      resolve(response.data);
    } catch (err) {
      reject('File copy failed');
    }
  });
};

export const _blobToLocalCopyFile = ({ srcPath, name, destBasePath }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        source: srcPath,
        dest: destBasePath + name,
      };
      const response = await service.post(
        config.blob_rest.base_url + config.blob_rest.uri.copyBlobToLocal,
        payload,
      );
      resolve(response.data);
    } catch (err) {
      reject('File copy failed');
    }
  });
};

export const latexGraphicsCopy = async input => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, customerId, wfeventId } = input;
      const placeHolders = await getWorkflowPlaceHolders(wfeventId);
      const graphicSql = `select localgraphicfilepath from wms_mst_customerconfigdetails where customerid = ${customerId} and duid= ${duId}`;
      const graphicDetail = await query(graphicSql);
      const iauthrSql = `select iauthcustomerid from iauthor_mst_customer imc join org_mst_customer_orgmap co ON imc.custorgmapid = co.custorgmapid where co.customerid = ${customerId}`;
      const iauthrDetail = await query(iauthrSql);
      if (graphicDetail?.length && iauthrDetail?.length) {
        const graphicPathDetail = graphicDetail[0].localgraphicfilepath;
        const graphicPath = getFormattedName(graphicPathDetail, {
          ...placeHolders,
        });
        const payload = {
          cust_id: iauthrDetail[0].iauthcustomerid,
          journalAcronym: placeHolders.JournalAcronym,
          articleName: placeHolders.BookCode,
          graphicsPath: `${config.blob_rest.base_url}${config.blob_rest.uri.ZIPDownloadLocalFolder}${graphicPath}`,
        };
        const url = config.iAuthor.vmfilecopy;
        const headers = {
          'Content-Type': 'application/json',
          clientid: config.iAuthor.clientid,
          apikey: config.iAuthor.apikey,
        };
        const result = await service.post(
          `${config.iAuthor.base_url()}${url}`,
          payload,
          headers,
        );
        resolve(result);
      } else if (!graphicDetail?.length) {
        throw new Error('Graphics Path is not found');
      } else {
        throw new Error('iAuthor Customer ID is not found');
      }
    } catch (error) {
      const err =
        error?.message?.data ?? error?.message ?? 'latexGraphicsCopy failed';
      reject(typeof err === 'object' ? JSON.stringify(err) : err);
    }
  });
};
