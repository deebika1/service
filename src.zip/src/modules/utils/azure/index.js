/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies

import { createReadStream } from 'fs';
import path from 'path';
import FormData from 'form-data';
import axios from 'axios';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import {
  getsftpConfig,
  getsftpConfigforNewsLetter,
} from '../../filetransferkit/index.js';
import { query } from '../../../database/postgres.js';
import { _localdownload } from '../local/index.js';
import logger from '../logs/index.js';
import { getDownloadURL } from '../../../iAlt/blobService/utils/blob.js';

const service = new Service();

export const fileUpload = async (req, res) => {
  try {
    const { docPath } = req.body;
    const fileName = 'content';
    const newName =
      req.body && req.body.key && req.body.key == 'test'
        ? req.body.file
        : req.files[fileName];
    const result = await _upload(newName, docPath);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const listCurrentDirectory = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.retreiveBlobRootList;
      let encodedURL = encodeURI(pth);
      encodedURL = await decodeSymbol(encodedURL);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const _upload = (file, docPath) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (docPath != '') {
        const url = config.blob_rest.uri.upload;
        const formData = new FormData();
        const fPath = `${docPath}${file.name}`;
        let encodedURL = encodeURI(fPath);
        encodedURL = await decodeSymbol(encodedURL);
        formData.append('content', createReadStream(file.tempFilePath));
        formData.append('docPath', encodedURL);
        const headers = {
          'Content-Type': 'multipart/form-data',
          ...formData.getHeaders(),
        };
        const result = await service.uploadPost(
          `${config.blob_rest.base_url}${url}`,
          formData,
          headers,
        );
        const { data, status } = result;
        const response = {
          data: {
            ...data,
            okmPath: docPath,
            name: file.name,
            fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
          },
          status,
          fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
        };
        resolve(response);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const fileDelete = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _delete(pth);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const listAllFiles = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _listAllFiles(pth);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _listAllFiles = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.retreiveBlobFiles;
      let encodedURL = encodeURI(pth);
      encodedURL = await decodeSymbol(encodedURL);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const _listAllFilePath = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.retreiveBlobFilesURL;
      let encodedURL = encodeURI(pth);
      encodedURL = await decodeSymbol(encodedURL);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const _blobExist = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.blobExist;
      const encodedURL = encodeURI(pth);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      logger.info(err);
      reject(err);
    }
  });
};
export const _delete = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.delete;
      let encodedURL = encodeURI(pth);
      encodedURL = await decodeSymbol(encodedURL);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docId=${encodedURL}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};

export const fileDownload = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _download(pth);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const DeleteFilesInBlobFolder = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _DeleteFilesInBlobFolder(pth);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};
export const _DeleteFilesInBlobFolder = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.deleteFilesInBlobFolder;
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(result);
    } catch (err) {
      reject(err);
    }
  });
};

export const _download = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.download;
      let encodedURL = encodeURI(pth);
      encodedURL = await decodeSymbol(encodedURL);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(result);
    } catch (err) {
      reject(err);
    }
  });
};
export const localFileGetDownload = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localdownload;
      const docPath1 = pth.body.path;
      // let fileName = path.basename(docPath1)
      // const folderPat = path.join('uploads',fileName)
      // resolve(docPath1);
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${docPath1}`,
      );
      // let writeStream = createWriteStream(folderPat);
      // result.data.pipe(writeStream);
      // writeStream.on('finish', () => {
      //     console.log('success')
      //     resolve();
      // })
      // writeStream.on('error', (error) => {
      //    reject(error);
      // })
      resolve(result);
    } catch (err) {
      reject(err);
    }
  });
};
export const _copyFile = async (
  { srcPath, name, destBasePath },
  isNewmsContainer = true,
) => {
  const url = isNewmsContainer
    ? config.blob_rest.uri.copy
    : config.blob_rest.uri.copyExternalBlobToBlob;
  const targetPath = destBasePath + name;
  let encodedSrcURL = encodeURI(srcPath);
  encodedSrcURL = await decodeSymbol(encodedSrcURL);
  let encodedTargetURL = encodeURI(targetPath);
  encodedTargetURL = await decodeSymbol(encodedTargetURL);

  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('docId', encodedSrcURL);
      formData.append('dstId', encodedTargetURL);
      // formData.append('customerName', customerName);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.blob_rest.base_url}${url}`,
        formData,
        headers,
      );
      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};
export const _copyFileWithoutFormData = async ({
  srcPath,
  name,
  destBasePath,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      const source = srcPath;
      const dest = destBasePath + name;
      const payload = {
        source,
        dest,
      };
      const response = await service.post(
        config.blob_rest.base_url + config.blob_rest.uri.copyBlobToBlob,
        payload,
      );
      resolve(response.data);
      resolve({ path: dest, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};

export const renameBlob = ({ srcPath, name, destBasePath }) => {
  const url = config.blob_rest.uri.rename;
  const targetPath = destBasePath + name;
  let encodedSrcURL = encodeURI(srcPath);
  let encodedTargetURL = encodeURI(targetPath);
  return new Promise(async (resolve, reject) => {
    try {
      encodedSrcURL = await decodeSymbol(encodedSrcURL);
      encodedTargetURL = await decodeSymbol(encodedTargetURL);
      const formData = new FormData();
      formData.append('docId', encodedSrcURL);
      formData.append('dstId', encodedTargetURL);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.blob_rest.base_url}${url}`,
        formData,
        headers,
      );
      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};

export const _downloadBlobFiles = async (req, res) => {
  try {
    const { dmsType } = req.body.data.iwms;
    const newsletter = req.body.data.isNewsletter;
    let fileDetails = {};
    switch (dmsType) {
      case 'azure':
        fileDetails = await _download(req.body.data.source);
        break;
      case 'local':
        fileDetails = await _localdownload(req.body.data.source);
        break;
      default:
        break;
    }
    let configDetails;
    if (newsletter) {
      configDetails = await getsftpConfigforNewsLetter(
        req.body.data.iwms.custId,
        req.body.data.type,
        req.body.data.uploadType,
      );
    }
    configDetails = await getsftpConfig(
      req.body.data.iwms.custId,
      req.body.data.type,
      req.body.data.iwms.woId,
    );
    const statusCheck = await ftpUploadStatusCheck(req.body.data);
    res.status(200).send({ result: configDetails, fileDetails, statusCheck });
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};
export const _ftpUploadStatusCheck = async (req, res) => {
  try {
    const statusCheck = await ftpUploadStatusCheck(req.body);
    res.status(200).send({ statusCheck });
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};
export const ftpUploadStatusCheck = async data => {
  try {
    const custId = data.iwms?.custId || data.custId;
    const woId = data.iwms?.woId || data.woId;
    const stageId = data.iwms?.stageId || data.stageId;
    const activityId = data.iwms?.activityId || data.activityId;
    const wfEventId = data.iwms?.wfEventId || data.wfEventId;
    const apiId = data.iwms?.id || data.id;
    const actualActivityCount =
      data.iwms?.actualActivityCount || data.actualActivityCount;

    let sql;

    if (data.iFTPupload == true) {
      sql = `SELECT count(*) FROM wms_tools_api_list WHERE workorderid = ${woId} AND stageid = ${stageId} AND activityid = ${activityId} AND toolid = 425 AND status = 'Success' AND wfeventid = ${wfEventId}`;
    } else if (custId == 8) {
      sql = `SELECT count(*) FROM wms_tools_api_list WHERE workorderid = ${woId} AND stageid = ${stageId} AND toolid = 346 AND status = 'Success'`;
    } else if (custId == 15) {
      const hasSuccessQuery = `
        SELECT 1 AS has_success
        FROM wms_tools_api_list
        WHERE workorderid = ${woId}
          AND stageid = ${stageId}
          AND activityid = ${activityId}
          AND toolid = 413
          AND status = 'Success'
          AND actualActivityCount = ${actualActivityCount}
          AND (remarks IS NULL OR remarks <> 'skipped')
        LIMIT 1;
      `;
      const hasSuccess = await query(hasSuccessQuery);
      if (hasSuccess.length > 0) {
        return false;
      }
      const inProgressQuery = `
        SELECT 
          CASE 
            WHEN apiid = ${apiId} THEN true
            ELSE false
          END AS result
        FROM wms_tools_api_list
        WHERE workorderid = ${woId}
          AND stageid = ${stageId}
          AND activityid = ${activityId}
          AND toolid = 413
          AND status = 'InProgress'
          AND actualActivityCount = ${actualActivityCount}
        ORDER BY apiid ASC
        LIMIT 1;
      `;
      const inProgress = await query(inProgressQuery);
      if (inProgress.length > 0) {
        return inProgress[0].result;
      }
      return true;
    } else if (custId == 13) {
      sql = `SELECT count(*) FROM wms_tools_api_list WHERE workorderid = ${woId} AND stageid = ${stageId} AND activityid = ${activityId} AND toolid = 346 AND status = 'Success' AND wfeventid = ${wfEventId}`;
    } else {
      sql = `SELECT count(*) FROM wms_tools_api_list WHERE workorderid = ${woId} AND stageid = ${stageId} AND activityid = ${activityId} AND toolid = 346 AND status = 'Success'`;
    }

    const result = await query(sql);
    return result[0].count == 0;
  } catch (err) {
    console.log('ftpUploadStatusCheck error:', err);
    throw err;
  }
};
export const decodeSymbol = async EncodeURL => {
  return new Promise(resolve => {
    resolve(EncodeURL.replace(/%20/g, ' ').replace(/%25/g, ' '));
  });
};
export const getToolListPath = async (req, res) => {
  try {
    const sql = `select tool.toolid as "ExeId",type.tooltype,tool.toolname as "ExeName",tool.tooldescription,tool.customerid,((tool.payload->>'dependentFiles')::json)->0->'src' as "Path"  
    ,toolsrights.read, 
    toolsrights.upload,toolsrights.delete from pp_mst_tool tool
    join pp_mst_tooltype type on type.tooltypeid = tool.tooltypeid
    join  wms_tools_accessrights as toolsrights on toolsrights.exeid= tool.toolid
    where tool.tooltypeid = 2 and tool.toolstatus = true and toolsrights.duid=${req.body.data} and toolsrights.userid ='${req.body.userId}'
    and toolsrights.useractive=true`;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _uploads3File = (docPath, fileContent, contentType) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (docPath !== '') {
        const url = config.blob_rest.uri.upload;
        const formData = new FormData();

        const buffer = Buffer.from(fileContent);

        formData.append('content', buffer, {
          filename: docPath,
          contentType,
        });
        formData.append('docPath', docPath);
        formData.append('contentType', contentType);

        const headers = {
          ...formData.getHeaders(),
          'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
        };
        const axiosConfig = {
          headers,
          maxBodyLength: Infinity, // Removes the limit for the request body
          maxContentLength: Infinity, // Removes the limit for the content length
        };

        const result = await axios.post(
          `${config.blob_rest.base_url}${url}`,
          formData,
          axiosConfig,
        );

        const { data, status } = result;
        const response = {
          data: {
            ...data,
            okmPath: docPath,
            name: docPath, // Adjusted name to docPath or the actual name if available
            fullPath: path.join(docPath).replace(/\\/g, '/'),
          },
          status,
          fullPath: path.join(docPath).replace(/\\/g, '/'),
        };
        resolve(response);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const _downloadForIalt = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      let encodedURL = encodeURI(pth);
      encodedURL = await decodeSymbol(encodedURL);
      const result = await getDownloadURL(encodedURL);
      resolve({ data: { path: result } });
    } catch (err) {
      reject(err);
    }
  });
};

export const writeRawcontentToBlob = payload => {
  const url = config.blob_rest.uri.writeRawcontentToBlob;
  return new Promise(async (resolve, reject) => {
    try {
      const headers = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      };
      await service.post(
        `${config.blob_rest.base_url}${url}`,
        payload,
        headers,
      );
      resolve({ path: payload, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};
