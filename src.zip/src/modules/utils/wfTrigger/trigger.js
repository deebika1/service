import { Service } from '../../../httpClient/index.js';

const service = new Service();

export const triggerStartEvent = (wfKey, variables) => {
  return new Promise(async (resolve, reject) => {
    const triggerData = { variables };
    try {
      const triggerResponse = await service.post(
        `${process.env.CAMUNDA_NATIVE_URL}process-definition/key/${wfKey}/start`,
        triggerData,
      );
      resolve(triggerResponse.data ? triggerResponse.data : triggerResponse);
    } catch (e) {
      reject(e.message?.data ? e.message.data : e);
    }
  });
};

export const triggerMsgEvent = (
  processInstanceId,
  messageName,
  variables = {},
) => {
  return new Promise(async (resolve, reject) => {
    const triggerData = {
      processInstanceId,
      messageName,
      processVariables: variables,
    };
    try {
      const triggerResponse = await service.post(
        `${process.env.CAMUNDA_NATIVE_URL}message`,
        triggerData,
      );
      resolve(triggerResponse.data ? triggerResponse.data : triggerResponse);
    } catch (e) {
      reject(e.message?.data ? e.message.data : e);
    }
  });
};
export const triggervariableEvent = (
  processInstanceId,
  varStatus,
  camundaVariable,
) => {
  return new Promise(async (resolve, reject) => {
    const triggerData = {
      value: varStatus,
      type: 'Boolean',
    };
    try {
      const triggerResponse = await service.put(
        `${process.env.CAMUNDA_NATIVE_URL}process-instance/${processInstanceId}/variables/${camundaVariable}`,
        triggerData,
      );
      resolve(triggerResponse.data ? triggerResponse.data : triggerResponse);
    } catch (e) {
      reject(e.message?.data ? e.message.data : e);
    }
  });
};
