import { triggerStartEvent, triggerMsgEvent } from './trigger.js';
import {
  getBWStageListenerVariables,
  getBWVariables,
  getBWStageVariables,
  getCWVariables,
  getCWStageVariables,
} from './variables.js';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import { isContinuePub } from '../../woi/woAutocreation.js';

const service = new Service();
const categories = {
  chapter: 'Chapterwise',
  book: 'Bookwise',
  article: 'Articlewise',
  issue: 'Issuewise',
};

const triggerChapterWiseWf = (
  wfKey,
  workOrderId,
  serviceId,
  stage,
  files,
  // eslint-disable-next-line default-param-last
  processInstanceId = undefined,
  // eslint-disable-next-line default-param-last
  camundaFormVariables = {},
  graphicVariables,
  isWordInput,
  isJournalInput,
  iscopyEditingLevel,
  isiAuthor,
  iseonly,
  isNLP,
  isDirectFP,
  flowtype,
  ceLevel,
  isreject,
  isAltText,
  isPAP,
  isPCPJ,
  isESM,
  isAdvert,
  isCover,
  isTrancheFour,
) => {
  const isSignal = processInstanceId !== undefined;
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < files.length; i++) {
        if (!isSignal && i === 0) {
          const variables = await getCWVariables(
            workOrderId,
            serviceId,
            stage,
            files[i],
            camundaFormVariables,
            graphicVariables,
            isWordInput,
            isJournalInput,
            iscopyEditingLevel,
            isiAuthor,
            iseonly,
            isNLP,
            isDirectFP,
            flowtype,
            ceLevel,
            isreject,
            isPAP,
            isESM,
            isCover,
            isAdvert,
            isTrancheFour,
          );

          const triggerStartResponse = await triggerStartEvent(
            wfKey,
            variables,
          );
          processInstanceId = triggerStartResponse.id;
        } else if (processInstanceId) {
          const variables = await getCWStageVariables(stage, files[i]);

          await triggerMsgEvent(processInstanceId, 'BatchMsg', variables);
        } else {
          throw new Error(`Process Instance Id is not defined`);
        }
      }
      resolve(processInstanceId);
    } catch (e) {
      reject(e);
    }
  });
};

const triggerChapterwiseStageWf = (
  stage,
  files,
  processInstanceId,
  iterationType,
  customerId,
  currentStageid,
  ismscompleted,
  isonlineissue,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (processInstanceId) {
        const variables = await getCWStageVariables(
          stage,
          files[0],
          iterationType,
        );
        const txtFiles = files.filter(
          list =>
            list.__isTextCorr__ == true &&
            (list.filetypeid == 4 || list.filetypeid == 16),
        );
        if (txtFiles && txtFiles.length > 0) {
          variables.__isTextCorr__ = { value: true, type: 'Boolean' };
        } else {
          variables.__isTextCorr__ = { value: false, type: 'Boolean' };
        }
        if (customerId == '70' && currentStageid == '21' && !isonlineissue) {
          variables.__isCover__ = { value: true, type: 'Boolean' };
        }
        if (customerId == '70' && currentStageid == '21' && isonlineissue) {
          variables.__isprePub__ = { value: true, type: 'Boolean' };
        }
        if (
          customerId == '70' &&
          currentStageid == '78' &&
          ismscompleted == true
        ) {
          variables.__isprePub__ = { value: true, type: 'Boolean' };
          variables.__isCover__ = { value: true, type: 'Boolean' };
        }

        if (customerId == '8' && currentStageid == '2') {
          const str1 = files[0].name.match(/^[A-Za-z]+/)[0];
          const isContPubReq = await isContinuePub(str1);
          if (isContPubReq.issuccess) {
            variables.__isCPreq__ = { value: true, type: 'Boolean' };
          }
        }

        await triggerMsgEvent(processInstanceId, 'BatchMsg', variables);
      } else {
        throw new Error(`Process Instance Id is not defined`);
      }
      resolve(processInstanceId);
    } catch (e) {
      reject(e);
    }
  });
};

// const triggerBookWiseWf = (wfKey, workOrderId, serviceId, stage, files, enableListener, processInstanceId = undefined, camundaFormVariables = {}) => {
const triggerBookWiseWf = (
  wfKey,
  workOrderId,
  serviceId,
  stage,
  files,
  enableListener,
  // eslint-disable-next-line default-param-last
  processInstanceId = undefined,
  // eslint-disable-next-line default-param-last
  camundaFormVariables = {},
  graphicVariables,
  isJournalInput,
  flowtype,
  isAltText,
  isCover,
  isAdvert,
) => {
  const isSignal = processInstanceId !== undefined;
  return new Promise(async (resolve, reject) => {
    try {
      if (!isSignal) {
        const variables = getBWVariables(
          workOrderId,
          serviceId,
          stage,
          files,
          enableListener,
          camundaFormVariables,
          graphicVariables,
          isJournalInput,
          flowtype,
          isAltText,
          isCover,
          isAdvert,
        );

        // const variables = getBWVariables(workOrderId, serviceId, stage, files, enableListener, camundaFormVariables);
        const triggerStartResponse = await triggerStartEvent(wfKey, variables);
        processInstanceId = triggerStartResponse.id;
      } else if (enableListener) {
        if (processInstanceId) {
          const variables = getBWStageListenerVariables(files, -1);
          await triggerMsgEvent(
            processInstanceId,
            `${stage.type}_msg`,
            variables,
          );
        } else {
          throw new Error(`Process Instance Id is not defined`);
        }
      } else {
        throw new Error(`Enable Listener is set to false`);
      }

      resolve(processInstanceId);
    } catch (e) {
      reject(e);
    }
  });
};

const triggerBookWiseStageWf = (
  stage,
  files,
  processInstanceId,
  customerId,
  currentStageid,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (processInstanceId) {
        files = files.filter(list => list.filetypeid != 10);
        const variables = getBWStageVariables(stage, files);
        const tocFiles = files.filter(list => list.filetypeid == 17);
        const coverFiles = files.filter(list => list.filetypeid == 5);
        const AdvertFiles = files.filter(list => list.filetypeid == 6);
        const xmlFiles = files.filter(
          list =>
            list.__isXMLCorr__ == true &&
            (list.filetypeid == 4 || list.filetypeid == 16),
        );
        const txtFiles = files.filter(
          list =>
            list.__isTextCorr__ == true &&
            (list.filetypeid == 4 || list.filetypeid == 16),
        );
        const isCorrection = files.filter(list => list.isChecked == true);

        if (tocFiles && tocFiles.length == files.length) {
          variables.__isTocOnly__ = { value: true, type: 'Boolean' };
        } else {
          variables.__isTocOnly__ = { value: false, type: 'Boolean' };
        }

        if (coverFiles && coverFiles.length == files.length) {
          variables.__isCoverOnly__ = { value: true, type: 'Boolean' };
        } else {
          variables.__isCoverOnly__ = { value: false, type: 'Boolean' };
        }
        if (AdvertFiles && AdvertFiles.length > 0) {
          variables.__isAdvert__ = { value: true, type: 'Boolean' };
        } else {
          variables.__isAdvert__ = { value: false, type: 'Boolean' };
        }

        if (xmlFiles && xmlFiles.length > 0) {
          variables.__isXMLCorr__ = { value: true, type: 'Boolean' };
        } else {
          variables.__isXMLCorr__ = { value: false, type: 'Boolean' };
        }
        if (txtFiles && txtFiles.length > 0) {
          variables.__isTextCorr__ = { value: true, type: 'Boolean' };
        } else {
          variables.__isTextCorr__ = { value: false, type: 'Boolean' };
        }

        if (isCorrection && isCorrection.length > 0) {
          variables.__isCorrection__ = { value: true, type: 'Boolean' };
        } else {
          variables.__isCorrection__ = { value: false, type: 'Boolean' };
        }

        if (customerId == '12' && currentStageid == '18') {
          const bookFile = files.filter(list => list.filetypeid == 1);

          variables.__isEnableFirstTime__ = { value: true, type: 'Boolean' };

          variables.__isCover__ = {
            value: bookFile[0]?.isCover ? bookFile[0].isCover : false,
            type: 'Boolean',
          };
          variables.__isIndex__ = {
            value: bookFile[0]?.isIndex ? bookFile[0].isIndex : false,
            type: 'Boolean',
          };
          variables.__isMyCopy__ = {
            value: bookFile[0]?.isMyCopy ? bookFile[0].isMyCopy : false,
            type: 'Boolean',
          };
        }

        await triggerMsgEvent(processInstanceId, `BatchMsg`, variables);
      } else {
        throw new Error(`Process Instance Id is not defined`);
      }
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

// export const triggerWorkflow = (category, wfKey, workOrderId, serviceId, stage, files, enableListener, processInstanceId = undefined, camundaFormVariables ={}) => {
export const triggerWorkflow = async (
  category,
  wfKey,
  workOrderId,
  serviceId,
  stage,
  files,
  enableListener,
  // eslint-disable-next-line default-param-last
  processInstanceId = undefined,
  // eslint-disable-next-line default-param-last
  camundaFormVariables = {},
  graphicVariables,
  isWordInput,
  isJournalInput,
  iscopyEditingLevel,
  isiAuthor,
  iseonly,
  isNLP,
  isDirectFP,
  flowtype,
  ceLevel,
  isreject,
  isAltText,
  isPAP,
  isPCPJ,
  isESM,
  isCover,
  isAdvert,
  isTrancheFour,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      switch (category) {
        case categories.chapter:
        case categories.article:
          processInstanceId = await triggerChapterWiseWf(
            wfKey,
            workOrderId,
            serviceId,
            stage,
            files,
            processInstanceId,
            camundaFormVariables,
            graphicVariables,
            isWordInput,
            isJournalInput,
            iscopyEditingLevel,
            isiAuthor,
            iseonly,
            isNLP,
            isDirectFP,
            flowtype,
            ceLevel,
            isreject,
            isAltText,
            isPAP,
            isPCPJ,
            isESM,
            isAdvert,
            isCover,
            isTrancheFour,
          );
          // processInstanceId = await triggerChapterWiseWf(wfKey, workOrderId, serviceId, stage, files, processInstanceId, camundaFormVariables);

          break;
        case categories.book:
          processInstanceId = await triggerBookWiseWf(
            wfKey,
            workOrderId,
            serviceId,
            stage,
            files,
            enableListener,
            processInstanceId,
            camundaFormVariables,
            graphicVariables,
            isJournalInput,
            flowtype,
            isAltText,
            isCover,
            isAdvert,
          );
          break;
        case categories.issue:
          processInstanceId = await triggerBookWiseWf(
            wfKey,
            workOrderId,
            serviceId,
            stage,
            files,
            enableListener,
            processInstanceId,
            camundaFormVariables,
            graphicVariables,
            isJournalInput,
            flowtype,
            isAltText,
            isCover,
            isAdvert,
          );
          // processInstanceId = await triggerBookWiseWf(wfKey, workOrderId, serviceId, stage, files, enableListener, processInstanceId, camundaFormVariables);
          break;
        default:
          throw new Error('No Matching WF category found');
      }

      resolve(processInstanceId);
    } catch (e) {
      reject(e);
    }
  });
};

export const triggerStageWorkflow = (
  category,
  stage,
  files,
  processInstanceId,
  iterationType,
  customerId,
  currentStageid,
  ismscompleted,
  isonlineissue,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      switch (category) {
        case categories.chapter:
        case categories.article:
          await triggerChapterwiseStageWf(
            stage,
            files,
            processInstanceId,
            iterationType,
            customerId,
            currentStageid,
            ismscompleted,
            isonlineissue,
          );
          break;
        case categories.book:
        case categories.issue:
          await triggerBookWiseStageWf(
            stage,
            files,
            processInstanceId,
            customerId,
            currentStageid,
          );
          break;
        default:
          throw new Error('No Matching WF category found');
      }
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const triggerBookCompleted = (
  category,
  processInstanceId,
  stage,
  totalChapters,
  enableListener,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      switch (category) {
        case categories.book:
        case categories.issue:
          if (enableListener) {
            const variables = getBWStageListenerVariables([], totalChapters);
            await triggerMsgEvent(
              processInstanceId,
              `${stage.type}_msg`,
              variables,
            );
            await triggerMsgEvent(
              processInstanceId,
              `${stage.type}_CompletionMsg`,
            );
          }
          break;
        default:
      }
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const triggerBatchCompletion = processInstanceId => {
  return new Promise(async (resolve, reject) => {
    try {
      await triggerMsgEvent(processInstanceId, `BatchCompletionMsg`);
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const killActiveInstance = async (req, res) => {
  const { processInstanceId } = req.body;
  try {
    const response = {};
    const triggerUserTask = await service.get(
      `http://172.16.200.181:8080/engine-rest/task?processInstanceId=${processInstanceId}`,
    );
    const taskId = [];
    if (
      Object.keys(triggerUserTask).length > 0 &&
      triggerUserTask.data &&
      Array.isArray(triggerUserTask.data)
    ) {
      triggerUserTask.data.forEach(list => {
        if (list && Object.keys(list).length > 0 && list.taskDefinitionKey) {
          if (
            taskId.filter(sublist => sublist == list.taskDefinitionKey)
              .length == 0
          ) {
            taskId.push(list.taskDefinitionKey);
          }
        }
      });
    }
    console.log(taskId, 'taskId');
    if (Array.isArray(taskId)) {
      for (let i = 0; i < taskId.length > 0; i++) {
        await cancelInstance(taskId[i], processInstanceId);
      }
      response.message = `Cancel All Active Instance`;
    }
    res.status(200).json(response);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const cancelInstance = (data, processInstanceId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        skipCustomListeners: false,
        skipIoMappings: false,
        instructions: [],
        annotation: 'clear all activie instance',
      };
      const response = {};
      const url =
        config.camnundaNative.uri.externalTask.resetModification.replace(
          /{{id}}/,
          processInstanceId,
        );
      const setURL = `${config.camnundaNative.base_url}${url}`;
      const createInstructions = [
        {
          type: 'cancel',
          activityId: data,
          cancelCurrentActiveActivityInstances: true,
        },
      ];
      payload.instructions = createInstructions;

      if (
        payload &&
        Object.keys(payload).length > 0 &&
        payload.instructions &&
        payload.instructions.length > 0
      ) {
        const resetResponse = await service.post(setURL, payload);
        response.data = resetResponse.data ? resetResponse.data : resetResponse;
        console.log(resetResponse, 'cancel active instance');
        resolve(response);
      }
    } catch (e) {
      reject(e);
    }
  });
};
