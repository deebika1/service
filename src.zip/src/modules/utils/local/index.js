/* eslint-disable no-unused-vars */
import { createReadStream } from 'fs';
import path from 'path';
import FormData from 'form-data';
import axios from 'axios';
import querystring from 'querystring';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import logger from '../logs/index.js';

const service = new Service();

export const localproperties = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.delete;
      const result = await service.get(
        `${config._rest.base_url}${url}?docId=${pth}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};

export const localfileUpload = async (req, res) => {
  try {
    const { docPath } = req.body;
    const fileName = 'content';
    const result = await _uploadlocal(req.files[fileName], docPath);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _uploadlocal = (file, docPath) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (docPath != '') {
        const url = config.local_rest.uri.localupload;
        const formData = new FormData();
        formData.append('content', createReadStream(file.tempFilePath));
        formData.append('docPath', `${docPath}${file.name}`);
        const headers = {
          'Content-Type': 'multipart/form-data',
          ...formData.getHeaders(),
        };
        const result = await service.uploadPost(
          `${config.local_rest.base_url}${url}`,
          formData,
          headers,
        );
        const { data, status } = result;
        const response = {
          data: {
            ...data,
            okmPath: docPath,
            name: file.name,
            fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
          },
          status,
          fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
        };
        resolve(response);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const locallistCurrentDirectory = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.retreiveLocalRootList;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const localfileDelete = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _localdelete(pth);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _localdelete = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localdelete;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docId=${pth}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};

export const locallistAllFiles = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _locallistAllFiles(pth);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _locallistAllFiles = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.retreiveLocalFiles;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const localfileDownload = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _localdownload(pth);

    res.status(200).send(result);
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _localdownload = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localdownload;
      // const result = await service.get(
      //   `${config.blob_rest.base_url}${url}?docPath=${pth}`,
      // );
      resolve({
        data: { path: `${config.local_rest.base_url}${url}?docPath=${pth}` },
      });
    } catch (err) {
      reject(err);
    }
  });
};

export const _islocalFileExist = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localisExists;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const _localcopyFile = (
  { srcPath, name, destBasePath, customerName = '' },
  isNewmsContainer = true,
) => {
  const url = isNewmsContainer
    ? config.local_rest.uri.localcopy
    : config.local_rest.uri.copyExternalBlobToLocal;
  const targetPath = destBasePath + name;
  // eslint-disable-next-line no-unused-vars
  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('docId', srcPath);
      formData.append('dstId', targetPath);
      formData.append('customerName', customerName);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.local_rest.base_url}${url}`,
        formData,
        headers,
      );

      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      if (!isNewmsContainer) {
        reject('File copy failed');
      } else {
        resolve({ path: targetPath, uuid: 'azure' });
      }
    }
  });
};

export const localrenameBlob = ({ srcPath, name, destBasePath }) => {
  const url = config.local_rest.uri.localrename;
  const targetPath = destBasePath + name;
  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('docId', srcPath);
      formData.append('dstId', targetPath);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.local_rest.base_url}${url}`,
        formData,
        headers,
      );
      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};
export const _localcopyFileWithoutFormData = ({
  srcPath,
  name,
  destBasePath,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      const source = srcPath;
      const dest = destBasePath + name;
      const payload = {
        source,
        dest,
      };
      const response = await service.post(
        config.local_rest.base_url + config.local_rest.uri.copyLocalToLocal,
        payload,
      );
      resolve(response.data);
      resolve({ path: dest, uuid: 'local' });
    } catch (err) {
      reject('File copy failed');
    }
  });
};
export const _localFolderCopy = ({ srcPath, destBasePath }) => {
  return new Promise(async (resolve, reject) => {
    try {
      logger.info(srcPath, 'srcPath');
      logger.info(destBasePath, 'destBasePath');

      const payload = {
        source: srcPath,
        dest: destBasePath,
      };
      const response = await service.post(
        config.local_rest.base_url +
          config.local_rest.uri.copyLocalToLocalFolder,
        payload,
      );
      resolve({ path: destBasePath, ...response.data });
    } catch (err) {
      logger.info(destBasePath, 'Folder copy failed');

      reject('Folder copy failed');
    }
  });
};

export const _localFolderDelete = srcPath => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        deletePath: srcPath,
      };
      const response = await service.post(
        config.local_rest.base_url + config.local_rest.uri.localFolderDelete,
        payload,
      );
      resolve(true);
    } catch (err) {
      reject('Folder Deletion failed');
    }
  });
};

export const _retreiveLocalFiles = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const data = querystring.stringify({
        docPath: pth,
      });
      const url = config.local_rest.uri.retreivelocalFilesURL;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?${data}`,
        {},
        {},
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const _uploads3FileServer = (docPath, fileContent, contentType) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (docPath !== '') {
        const url = config.local_rest.uri.localupload;
        const formData = new FormData();

        const buffer = Buffer.from(fileContent);

        formData.append('content', buffer, {
          filename: docPath,
          contentType,
        });
        formData.append('docPath', docPath);
        formData.append('contentType', contentType);

        const headers = {
          ...formData.getHeaders(),
          'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
        };

        const result = await axios.post(
          `${config.blob_rest.base_url}${url}`,
          formData,
          { headers },
        );

        const { data, status } = result;
        const response = {
          data: {
            ...data,
            okmPath: docPath,
            name: docPath, // Adjusted name to docPath or the actual name if available
            fullPath: path.join(docPath).replace(/\\/g, '/'),
          },
          status,
          fullPath: path.join(docPath).replace(/\\/g, '/'),
        };
        resolve(response);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const mandatoryInFileCheck = (unOptionalFiles, dmsType) => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        dmsType,
        data: unOptionalFiles,
      };
      const response = await service.get(
        config.local_rest.base_url +
          config.local_rest.uri.downloadMandatoryCheck,
        payload,
      );
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
export const _localZIPCopyWithExtract = payload => {
  return new Promise(async (resolve, reject) => {
    logger.info('_localZIPCopyWithExtract Payload: ', payload);
    try {
      // Create a new FormData object
      const { sourceInfo } = payload;
      const formData = new FormData();
      formData.append('file', sourceInfo.sourceContent, {
        filename: sourceInfo.filename,
      });

      for (const key in payload) {
        if (Array.isArray(payload[key])) {
          formData.append(key, JSON.stringify(payload[key]));
        } else if (key != 'sourceInfo') {
          formData.append(key, payload[key]);
        }
      }

      const header = {
        'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
      };
      // Send the form data in the uploadPost request
      const response = await service.uploadPost(
        config.local_rest.base_url +
          config.local_rest.uri.localZIPCopyWithExtract,
        formData,
        header,
      );
      logger.info('_localZIPCopyWithExtract Success: ', response?.data);
      resolve(response?.data);
    } catch (err) {
      logger.info('_localZIPCopyWithExtract Failed: ', err);
      reject('Local ZIP Copy With Buffer failed.');
    }
  });
};
