/* eslint-disable prefer-const */
import moment from 'moment';
import plimit from 'p-limit';
import axios from 'axios';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import { query } from '../../database/postgres.js';
import * as azureHelper from '../utils/azure/index.js';
import { emitAction } from '../activityListener/activityListener.js';
// import { _localdelete } from '../utils/local/index.js';
import { _getIncomingFileType } from '../utils/fileValidation/index.js';
// import { checkWorkflowType } from '../woi/woAutocreation.js';
import {
  createManualLogisticService,
  updateRemainingQty,
} from '../../iProductivity/service/index.js';
import { isValidiTracksUrl } from '../../helper/validator.js';
import { _locallistAllFiles, _localdelete } from '../utils/local/index.js';

const _plimit = plimit(1);

const service = new Service();

export const checkItracksExits = async (req, res, workflow = false) => {
  const { customerId, duId, stageId, activityId, wfId } = req.body;
  const userid = req.body.userid || req.body.userId;
  // const jnlId = req.body.journalAcronym;
  let isNewsletter = false;
  return new Promise(async (resolve, reject) => {
    // if (customerId == 13) {
    //   let wfInfoRes = await checkWorkflowType(jnlId);
    //
    //   isNewsletter =
    //     wfInfoRes && wfInfoRes[0] && wfInfoRes[0].newsletter
    //       ? wfInfoRes[0].newsletter
    //       : false;
    // }
    const sql = `SELECT * FROM public.itracks_config
            WHERE duid = ${duId} AND customerid = ${customerId} AND isactive = 1 AND not ('${userid}' ilike 'BCP%' or 
            '${userid}' ilike 'INT%')`;
    query(sql)
      .then(response => {
        if (response.length && workflow) {
          const sqlQuery = `SELECT itracksconfig FROM public.wms_workflowdefinition
            WHERE wfid = ${wfId} AND stageid = ${stageId} AND activityid = ${activityId}`;
          query(sqlQuery)
            .then(wfData => {
              if (wfData.length && wfData[0].itracksconfig) {
                const { isTrigger, isProduction, isCustomer } =
                  wfData.length && wfData[0].itracksconfig;
                resolve({
                  status: isTrigger,
                  isProduction: isProduction || false,
                  isCustomer: isCustomer || false,
                });
              } else if (isNewsletter) {
                resolve({
                  status: false,
                  isProduction: false,
                  isCustomer: false,
                });
              } else {
                resolve({
                  status: false,
                  isProduction: false,
                  isCustomer: false,
                });
              }
            })
            .catch(() => {
              resolve({ status: false });
            });
        } else {
          resolve({ status: !!response.length });
        }
      })
      .catch(() => {
        reject({ message: 'Error for itracks config details' });
      });
  });
};
export const createJob = params => {
  return new Promise(async resolve => {
    const { woType, jobType } = params;
    if (woType === 'Book') {
      try {
        const iPayload = await getBookPayload(params);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.book.iendpointKey,
          iendpointname: config.iTracks.uri.book.createJob,
        };

        const result = await service.iPost(url, iPayload, headers);

        const { status, Result } = result.data;
        resolve({ status, message: Result });
      } catch (e) {
        resolve({ status: false, message: e.message ? e.message : e });
      }
    } else {
      try {
        const iPayload = await getJournalPayload(params);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname:
            jobType == 2
              ? config.iTracks.uri.journal.createIssueJob
              : config.iTracks.uri.journal.createJob,
        };

        const result = await service.iPost(url, iPayload, headers);

        const { status, Result } = result.data;
        resolve({ status, message: Result });
      } catch (e) {
        resolve({ status: false, message: e.message ? e.message : e });
      }

      // resolve({ status: true, message: '' });
    }
  });
};

export const create_CoverArticle = async (req, res) => {
  const { coverdata } = req.body;
  let status = false;
  let Result = '';
  try {
    let coverlist = JSON.parse(coverdata);
    // const iPayload = await getJournalPayload(params);
    for (let index = 0; index < coverlist.length; index++) {
      if (index == 0 || (index > 0 && status == true)) {
        let iPayload = coverlist[index];
        console.log(iPayload);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname: config.iTracks.uri.journal.createJob,
        };
        const result = await service.iPost(url, iPayload, headers);
        status = result.data.status;
        Result = result.data.Result;
      }
    }
    res.status(200).send({ status, message: Result });
  } catch (e) {
    res.status(400).send({ status: false, message: Result });
  }
};

const getBookPayload = params => {
  const {
    jobId,
    jobTitle,
    CELevel,
    WoHardBackISBN,
    WoOcISBN,
    country,
    customer,
    division,
    languages,
    subDivision,
    externalUsers,
    projectManager,
    duId,
    category,
    iWorkflow,
    softwares,
  } = params;

  return new Promise((resolve, reject) => {
    let sql = ` SELECT cus.customeralias,cus.customerid,div.divisionalias,div.divisionid,sub.subdivisionalias,
        sub.verticalcode,sub.subdivisionid,cou.countrycode,cou.countryid,du.duid,du.dualias,lang.languageid,
        lang.languagecode,celevel.celevel,celevel.celevelid, category.categoryalias, software.softwarename
        FROM org_mst_customer cus
        JOIN org_mst_subdivision sub ON sub.subdivisionid = ${subDivision}
        JOIN org_mst_division div ON div.divisionid = ${division}
        JOIN geo_mst_country cou ON cou.countryid = ${country}
        JOIN org_mst_deliveryunit du ON du.duid = ${duId}
        JOIN wms_mst_language lang ON lang.languageid = ${languages}
        JOIN pp_mst_copyeditinglevel celevel ON celevel.celevelid = ${CELevel}
        JOIN pp_mst_wocategory category ON category.categoryid = ${category}
        JOIN pp_mst_composingsoftware software ON software.softwareid = ${softwares}

        WHERE cus.customerid = ${customer}`;

    query(sql)
      .then(async data => {
        if (data.length) {
          sql = `SELECT contact.contactname, contact.contactemail, contact.contactroleid,contact.contacttype, wms_users.userid 
                    FROM org_mst_customerorg_contact as contact
                    JOIN wms_users ON wms_users.username = contact.contactname
                    WHERE custorgconmapid IN (${projectManager})`;

          query(sql)
            .then(async pmData => {
              if (pmData.length) {
                const otherUsers = {};
                if (externalUsers && externalUsers.length) {
                  externalUsers.forEach(item => {
                    if (item.roleAcronym == 'AUTHOR') {
                      otherUsers.Author = item.name;
                      otherUsers.AuthorMailId = item.email;
                    } else if (item.roleAcronym == 'PED') {
                      otherUsers.ProductionEditor = item.name;
                    } else if (item.roleAcronym == 'PM') {
                      otherUsers.CSEEmpCode = item.userid;
                    }
                  });
                }

                const comapanyDetails = await getComapanyDetails();
                const { companyname } =
                  comapanyDetails.length && comapanyDetails[0];
                const {
                  dualias,
                  customeralias,
                  divisionalias,
                  verticalcode,
                  countrycode,
                  languagecode,
                  celevel,
                  categoryalias,
                  softwarename,
                } = data[0];
                let iPayload = {};
                iPayload = {
                  ...otherUsers,
                  BookCode: jobId,
                  JobTitle: jobTitle,
                  DivisionName: dualias,
                  CustomerName: customeralias,
                  // "ProductionEditor": "James W Dunn",
                  EISBN: WoOcISBN,
                  ISBN: WoHardBackISBN,
                  CompanyName: companyname,
                  CountryName: countrycode,
                  CustomerDivisionName: divisionalias,
                  CustomerSubDivisionName: 'N/A',
                  strWorkFlowName: iWorkflow,
                  LanguageName: languagecode,
                  CSEEmpCode: pmData[0].userid,
                  VerticalCode: verticalcode,
                  strCELevel: celevel,
                  CategoryName: categoryalias,
                  SoftWareName: softwarename,
                };

                resolve(iPayload);
              } else {
                reject({ status: false, message: 'PM details not found' });
              }
            })
            .catch(() => {
              reject({ status: false, message: 'Error for PM details get' });
            });
        } else {
          reject({ status: false, message: 'Combination not found' });
        }
      })
      .catch(() => {
        reject({
          status: false,
          message: 'Error for customer combination get',
        });
      });
  });
};
const getJournalPayload = params => {
  const {
    jobType,
    doiNumber,
    jobId,
    jobTitle,
    journalAcronym,
    emailOrderDate,
    customer,
    externalUsers,
    duId,
    journalId,
    isauto,
  } = params;

  return new Promise((resolve, reject) => {
    const sql = ` SELECT cus.icustomerid,cus.customerid,du.duid,du.iduid
        FROM org_mst_customer cus
        JOIN org_mst_deliveryunit du ON du.duid = ${duId}
        WHERE cus.customerid = ${customer}`;
    query(sql)
      .then(async data => {
        if (data.length) {
          const jId = isauto ? journalId : journalAcronym;
          const jsql = `SELECT journalacronym FROM pp_mst_journal
          WHERE journalid IN (${jId})`;
          query(jsql)
            .then(async jData => {
              if (jData.length) {
                const otherUsers = {};
                if (externalUsers && externalUsers.length) {
                  externalUsers.forEach(item => {
                    if (item.roleAcronym == 'AUTHOR') {
                      otherUsers.Author = item.name;
                      otherUsers.AuthorMailId = item.email;
                    }
                  });
                }
                const { iduid, icustomerid } = data[0];

                let iPayload = {};
                iPayload = {
                  ...otherUsers,
                  JobNature: jobType == '2' ? 'I' : 'A',
                  DOI: doiNumber,
                  JournalCode: jData[0].journalacronym, // "JCOM",
                  Title: jobTitle,
                  CustomerOrderDate:
                    emailOrderDate || moment().format('YYYY-MM-DD'),
                  BookCode: jobId,
                  Manuscriptid: jobId,
                  CustomerId: icustomerid,
                  DivisionId: iduid,
                  ReceivedDate: moment().format('YYYY-MM-DD'),
                  isBillable: true,
                };
                resolve(iPayload);
              } else {
                reject({ status: false, message: 'Journal details not found' });
              }
            })
            .catch(() => {
              reject({
                status: false,
                message: 'Error for Journal details get',
              });
            });
        } else {
          reject({ status: false, message: 'Combination not found' });
        }
      })
      .catch(() => {
        reject({
          status: false,
          message: 'Error for customer combination get',
        });
      });
  });
};
const getComapanyDetails = () => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM wms_mst_company `;
    query(sql)
      .then(res => {
        resolve(res);
      })
      .catch(error => {
        reject(error);
      });
  });
};
// const createWoAudit = (payload, response, woId) => {
//   const { status, Result } = response;
//   return new Promise((resolve, reject) => {
//     if (status) {
//       const sql = `UPDATE public.wms_workorder SET jobcardid=${Result}
//             WHERE workorderid=${woId} `;
//       query(sql)
//         .then(res => {
//
//         })
//         .catch(error => {
//
//         });
//     }

//     const sql = `INSERT INTO public.wms_workorder_audit(workorderid, createdon, updatedon, status)
//             VALUES (${woId}, current_timestamp, current_timestamp, ${status} ) RETURNING woauditid `;
//     query(sql)
//       .then(data => {
//         if (data.length) {
//           const sql = `INSERT INTO public.wms_workorder_audit_history(woauditid, payload, status, log, timestamp)
//                 VALUES ( ${data[0].woauditid}, '${JSON.stringify(
//             payload,
//           )}', ${status}, '${Result}', current_timestamp ) RETURNING woaudithistoryid `;
//
//           query(sql)
//             .then(auditData => {
//
//               resolve(status);
//             })
//             .catch(error => {
//               reject(error);
//             });
//         }
//       })
//       .catch(error => {
//         reject(error);
//       });
//   });
// };
// {"status":true,"Result":928853}
// {"status":false,"Result":"CSE Employee Code should not be empty"}

export const addSubJob = async (jobArray, data, isUpdateSubjobId, isMerge) => {
  const {
    woId,
    woid,
    woType,
    wotype,
    userid,
    userId,
    receiptdate,
    jobcardId,
    jobcardid,
    targetStage,
  } = data;
  let subjobArray = await getSubjobIds({
    workorderId: woId || woid,
    taskType: 'General',
  });
  if (isMerge) {
    subjobArray = subjobArray.concat(jobArray);
  }

  return new Promise(async (resolve, reject) => {
    try {
      if (wotype === 'Book' || woType === 'Book') {
        const iStageName = await getiTracksStageName(data);
        let response = { status: false, Result: '' };

        const payload = [];
        const woincomingId = [];
        const promises = subjobArray.map(async item => {
          const iFileType = await getiTracksFileType(item.filetypeid);
          woincomingId.push(item.woincomingfileid || item.id);
          payload.push({
            jobCardId: jobcardId || jobcardid,
            subJobDesc: item.filename || item.name,
            subJobType: iFileType, // "T",
            Remark: 'test',
            stageName: iStageName, // "Finals",
            dueDate: targetStage ? targetStage.plannedEnd : item.duedate, // "2022-02-08 00:00:00.000",
            ReceiptDate: receiptdate || moment().toISOString(), // "2022-02-06 00:00:00.000",
            empcode: userid || userId, // "is4748",
            EstimatedPages: item.estimatedpages || 0, // 6,
            mspage: item.mspages || 0, // "12",
            subjobId: item.subjobid || 0,
            // newly added for subjob id
          });
        });

        await Promise.all(promises).then(async () => {
          // do something with the finalized list of albums here

          const url = config.iTracks.base_url;
          const headers = {
            iendpointkey: config.iTracks.uri.book.iendpointKey,
            iendpointname: config.iTracks.uri.book.addSubJob,
          };

          const chunkSize = 75;
          const awt = [];
          for (let i = 0; i < payload.length; i += chunkSize) {
            const chunk = payload.slice(i, i + chunkSize);
            awt.push(_plimit(() => service.iPost(url, chunk, headers)));
          }
          const result = await Promise.all(awt);

          const failedResult = result.filter(x => x.data.status == false);
          if (failedResult.length > 0) {
            response.status = false;
            response.message = [];
            response.Result = [];
            result.forEach(x => response.Result.push(...x.data.Result));
            failedResult.forEach(x => response.message.push(...x.data.Result));
          } else {
            response.status = true;
            response.message = [];
            response.Result = [];
            result.forEach(x => response.Result.push(...x.data.Result));
          }

          const { status, Result } = response;
          response.status = status;
          response.message = Result;

          if (!status) {
            resolve(response);
          } else if (status && isUpdateSubjobId) {
            const auditRes = await subJobAudit(Result, woincomingId);
            response = auditRes;

            resolve(response);
          } else if (status && !isUpdateSubjobId) {
            resolve(response);
          }
        });
      } else {
        resolve({ status: true, message: '' });
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const subJobAudit = (subjobId, woincomingfileid) => {
  return new Promise((resolve, reject) => {
    let sql = `select * from public.wms_workorder_incomingfiledetails
        WHERE woincomingfileid = ANY ($1)`;

    query(sql, [woincomingfileid])
      .then(res => {
        if (res.length) {
          const val = [];
          subjobId.forEach(rItem => {
            res.forEach(sItem => {
              if (rItem.subJobDesc === sItem.filename) {
                val.push(`(${sItem.woincomingfileid}, ${rItem.subJobID})`);
              }
            });
          });

          sql = `update wms_workorder_incomingfiledetails as wwi set
                        subjobid = wwi2.subjobid
                    from (values
                        ${val}
                    ) as wwi2(woincomingfileid, subjobid)
                    where wwi2.woincomingfileid = wwi.woincomingfileid`;

          query(sql)
            .then(() => {
              resolve({
                status: true,
                message: 'subjobid updated successfully',
              });
            })
            .catch(() => {
              reject({ status: false, message: 'Error for subjob id update' });
            });
        } else {
          reject({ status: false, message: 'Woicomingfileid not found' });
        }
      })
      .catch(() => {
        reject({ status: false, message: 'Error for filter woicomingfileid' });
      });
  });
};

export const validateTask = async (req, res) => {
  return new Promise(async resolve => {
    const isCanWork = await canWorkActivity(req.body);
    const { status } = isCanWork;
    if (status) {
      const isEntryExists = await openEntryExists(req.body);
      const { status: stat } = isEntryExists;
      if (stat) {
        resolve(stat);
      } else {
        res.status(400).send(isEntryExists);
      }
    } else {
      res.status(400).send(isCanWork);
    }
  });
};

export const canWorkActivity = data => {
  const { woType, userid, jobCardId, duId, customerId, jobId, jobType } = data;
  return new Promise(async resolve => {
    const iStageId = await getiTracksStageId(data);
    const iActivityId = await getiTracksActivityId(data);
    if (iStageId && iActivityId) {
      if (woType === 'Book') {
        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.book.iendpointKey,
          iendpointname: config.iTracks.uri.book.canWorkActivity,
        };
        const payload = {
          empId: userid,
          jobCardid: jobCardId,
          stageId: iStageId, // 2,
          activityId: iActivityId, // 5902
        };

        const result = await service.iPost(url, payload, headers);

        const { status, Result } = result.data;
        resolve({
          status,
          iStageId,
          iActivityId,
          message: status
            ? Result
            : `${Result}. Please contact the iTrack Administrator`,
        });
      } else {
        const iDuId = await getiTracksDuId(duId);
        const iCustomerId = await getiTracksCustomerId(customerId);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname: config.iTracks.uri.journal.canWorkActivity,
        };
        const payload = {
          BookCode: jobId,
          IsIssue: jobType === '2' ? 'Y' : 'N',
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          EmpCode: userid,
          StageId: iStageId,
          ActivityId: iActivityId,
        };

        const result = await service.iPost(url, payload, headers);

        const { status, Result } = result.data;
        resolve({
          status,
          iStageId,
          iActivityId,
          message: status
            ? Result
            : `${Result}. Please contact the iTrack Administrator`,
        });
      }
    } else {
      resolve({
        status: false,
        message: 'iTracks stageid / activityid not fount in iWMS',
      });
    }
  });
};

export const getiTracksFileType = id => {
  return new Promise((resolve, reject) => {
    const sql = `select filetypecode from pp_mst_filetype where filetypeid= ${id}`;
    query(sql)
      .then(res => {
        if (res.length) {
          resolve(res[0].filetypecode);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        reject(false);
      });
  });
};

// export const constructPayload = (jobArray, jobcardId) => {
//   return new Promise((resolve, reject) => {
//     const payload = [];
//     const woincomingId = [];
//     const promises = jobArray.map(async item => {
//       const iFileType = await getiTracksFileType(item.filetypeid);
//       woincomingId.push(item.woincomingfileid || item.id);
//       payload.push({
//         jobCardId: jobcardId,
//         subJobDesc: item.filename || item.name, // "chapter1",
//         subJobType: iFileType, // "T",
//         Remark: 'test',
//         stageName: iStageName, // "Finals",
//         dueDate: item.duedate || targetStage.plannedEnd, // "2022-02-08 00:00:00.000",
//         ReceiptDate: receiptdate || moment().format('YYYY-MM-DD hh:mm:ss'), // "2022-02-06 00:00:00.000",
//         empcode: userid || userId, // "is4748",
//         EstimatedPages: item.estimatedpages || 0, // 6,
//         mspage: item.mspages || 0, // "12"
//       });
//     });

//     Promise.all(promises).then(function () {
//       // do something with the finalized list of albums here
//     });
//   });
// };

export const getiTracksStageName = data => {
  const { stageId, wfId, stageIterationCount } = data;

  return new Promise((resolve, reject) => {
    const sql = `SELECT iws.istageid,iws.istagename,ism.stageid, ism.iterationcount FROM itracks_mst_stage_map as ism 
        JOIN itracks_mst_stage as iws ON ism.itracksstageid = iws.itracksstageid
        WHERE ism.wfid= ${wfId} AND ism.stageid = ${stageId} AND iws.isactive=1`;
    query(sql)
      .then(res => {
        if (res.length) {
          let iStageName = '';
          res.forEach(item => {
            if (
              item.stageid == stageId &&
              item.iterationcount == stageIterationCount
            ) {
              iStageName = item.istagename;
            }
          });
          if (!iStageName) {
            iStageName = res[res.length - 1].istagename;
          }
          resolve(iStageName);
        } else {
          reject('iTracks stage Name not found');
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};
export const getiTracksStageId = data => {
  const { stageId, wfId, stageIterationCount } = data;
  return new Promise(resolve => {
    const sql = `SELECT iws.istageid,iws.istagename,ism.stageid, ism.iterationcount FROM itracks_mst_stage_map as ism 
        JOIN itracks_mst_stage as iws ON ism.itracksstageid = iws.itracksstageid
        WHERE ism.wfid= ${wfId} AND ism.stageid = ${stageId} AND iws.isactive=1`;
    query(sql)
      .then(res => {
        if (res.length) {
          let iStageId = '';
          res.forEach(item => {
            if (
              item.stageid == stageId &&
              item.iterationcount == stageIterationCount
            ) {
              iStageId = item.istageid;
            }
          });
          if (!iStageId) {
            iStageId = res[res.length - 1].istageid;
          }
          resolve(iStageId);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        resolve(false);
      });
  });
};
export const getFileDetails = data => {
  const { woid, woId } = data;
  const workorderId = woid || woId;
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT woincomingfileid,filename,filetypeid,mspages,estimatedpages, imagecount,equationcount, tablecount , wwif.duedate FROM public.wms_workorder_incoming 
      JOIN wms_workorder_incomingfiledetails AS wwif ON wwif.woincomingid = wms_workorder_incoming.woincomingid
      WHERE woid=$1 order by coalesce ( mspages,0) desc`;
      const fileDetails = await query(sql, [workorderId]);
      resolve(fileDetails);
    } catch (error) {
      reject(error);
    }
  });
};

export const getiTracksActivityId = data => {
  const { stageId, activityId, wfId, actualActivityCount } = data;
  return new Promise((resolve, reject) => {
    const sql = `
        SELECT iwa.iactivityid,iwa.iactivityname,imam.activityid,imam.iterationcount FROM itracks_mst_activity_map as imam 
        JOIN itracks_mst_activity as iwa ON iwa.itracksactivityid = imam.itracksactivityid
        WHERE imam.wfid= ${wfId} AND imam.stageid = ${stageId} AND imam.activityid = ${activityId} AND iwa.isactive=1`;
    query(sql)
      .then(res => {
        if (res.length) {
          let iActivityId = '';
          res.forEach(item => {
            if (
              item.activityid == activityId &&
              item.iterationcount == actualActivityCount
            ) {
              iActivityId = item.iactivityid;
            }
          });
          if (!iActivityId) {
            iActivityId = res[res.length - 1].iactivityid;
          }
          resolve(iActivityId);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        reject(false);
      });
  });
};
// export const getSubjobIdsFromTrnFile = (data) => {
//     const { wfeventid, taskType, workorderId } = data;
//     return new Promise((resolve, reject) => {
//         let sql = '';
//         if (taskType == 'Single') {
//             sql = `SELECT subjobid FROM public.wms_workorder_incoming
//             JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
//             WHERE wms_workorder_incoming.woid=${workorderId} AND wms_workorder_incomingfiledetails.filetypeid=1 AND subjobid IS NOT NULL`;
//         } else {
//             sql = `SELECT  DISTINCT ON (wfeventid) subjobid FROM public.wms_workflowactivitytrn_file_map
//             JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
//             WHERE wfeventid=${wfeventid} AND wms_workorder_incomingfiledetails.subjobid IS NOT NULL`;
//         }
//         query(sql).then((res) => {
//             resolve(res);
//         }).catch((error) => {
//             reject("");
//         });
//     });
// }
export const getSubjobIds = data => {
  const { wfeventId, wfeventid, workorderId, taskType } = data;
  return new Promise((resolve, reject) => {
    let sql = '';
    if (taskType == 'General') {
      sql = `SELECT subjobid, filetypeid, filename, woincomingfileid, wms_workorder_incomingfiledetails.duedate, estimatedpages, mspages, uomvalue, typesetpage FROM public.wms_workorder_incoming
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
            WHERE wms_workorder_incoming.woid=${workorderId} AND filetypeid NOT IN (5, 15)
			`;
    } else if (taskType == 'Single') {
      sql = `SELECT subjobid, filetypeid, filename, woincomingfileid, wms_workorder_incomingfiledetails.duedate, estimatedpages, mspages, uomvalue, typesetpage FROM public.wms_workorder_incoming
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
            WHERE wms_workorder_incoming.woid=${workorderId} AND subjobid IS NOT NULL
			`;
    } else {
      // sql = `SELECT  DISTINCT ON (wfeventid) subjobid, filetypeid, uomvalue, typesetpage FROM public.wms_workflowactivitytrn_file_map
      // JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
      // WHERE wfeventid=${wfeventId || wfeventid} AND wms_workorder_incomingfiledetails.subjobid IS NOT NULL
      // `;

      sql = `SELECT  DISTINCT ON (wfeventid) subjobid, filetypeid, uomvalue, typesetpage FROM public.wms_workflow_eventlog
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
            WHERE wfeventid=${
              wfeventId || wfeventid
            } AND wms_workorder_incomingfiledetails.subjobid IS NOT NULL
            `;
    }

    // SELECT * FROM public.wms_workorder_incomingfiledetails
    // WHERE wms_workorder_incomingfiledetails.woincomingfileid IN (${incomingFileId}) AND subjobid IS NOT NUll
    query(sql)
      .then(res => {
        resolve(res);
      })
      .catch(() => {
        reject([]);
      });
  });
};

export const openEntryExists = data => {
  const { userid } = data;
  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.openEntry,
    };
    const payload = {
      empCode: userid,
    };

    const result = await service.iPost(url, payload, headers);

    const { status, Result } = result.data;
    resolve({
      status,
      message: status
        ? Result
        : `${Result} Please contact the iTrack Administrator`,
    });
  });
};

export const logisticEntryInsert = data => {
  const {
    taskType,
    userid,
    jobCardId,
    subjobArray,
    iStageId,
    iActivityId,
    startPage,
    endPage,
    wfeventid,
  } = data;

  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.logisticEntryInsert,
    };
    let response = { status: false, message: '' };

    // filter the subjob id based on task type
    let subjobIds = subjobArray;
    if (taskType == 'Single') {
      subjobIds = subjobArray.filter(item => item.filetypeid == 1);
    }
    await Promise.all(
      subjobIds.map(async item => {
        const payload = {
          trandate: moment().toISOString(),
          subjobid: item.subjobid,
          activityId: iActivityId,
          stageid: iStageId,
          startDate: moment().toISOString(),
          empCode: userid,
          jobCardid: jobCardId,
          startPage: startPage || 0,
          endPage: endPage || 0,
        };

        const result = await service.iPost(url, payload, headers);

        const { status, Result } = result.data;
        let worksheetRes = false;
        if (status) {
          worksheetRes = await addWorksheetId(Result, wfeventid);
        } else {
          resolve({
            status,
            message: `${Result}. Please contact the iTrack Administrator`,
          });
        }

        if (worksheetRes) {
          resolve({ status, message: Result });
        } else {
          resolve({ status, message: 'Worksheet id update failed' });
        }
        response = result.data;
      }),
    );

    resolve(response);
  });
};

export const logisticEntryUpdate = (
  data,
  isProduction,
  isCustomer,
  actionId,
  action,
) => {
  const {
    taskType,
    subjobArray,
    userid,
    userId,
    jobCardId,
    iStageId,
    iActivityId,
    startPage,
    endPage,
    quantity,
    wfeventId,
  } = data;

  return new Promise(async resolve => {
    const totMins = await calculateTaskTOT(wfeventId, userId);
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.logisticEntryUpdate,
    };
    let response = { status: false, Result: '' };
    // filter the subjob id based on task type
    let subjobIds = subjobArray;
    if (taskType == 'Single') {
      subjobIds = subjobArray.filter(item => item.filetypeid == 1);
    }
    data.subjobIds = subjobIds;

    const iWorksheetId = await _getWorksheetId(wfeventId);

    await Promise.all(
      subjobIds.map(async item => {
        const payload = {
          worksheetid: iWorksheetId,
          finishDate: moment().toISOString(),
          totMins,
          // "quantity": taskType === 'Single' ? isBatchTaskUom ? quantity || 0 : item.uomvalue : quantity || 0,
          quantity: taskType === 'Single' ? quantity || 0 : item.uomvalue,
          statusId: actionId,
          subjobid: item.subjobid,
          activityId: iActivityId,
          remarks: 'testing',
          stageid: iStageId,
          empCode: userid || userId,
          jobCardid: jobCardId,
          startPage: startPage || 0,
          endPage: taskType === 'Single' ? endPage || 0 : item.uomvalue,
          // to be confirmed
          // "startPage": taskType === 'Single' ? isBatchTaskUom ? startPage || 0 : 1 : startPage || 0,
          // "endPage": taskType === 'Single' ? isBatchTaskUom ? endPage || 0 : item.uomvalue : endPage || 0
        };

        const result = await service.iPost(url, payload, headers);

        const { status, Result } = result.data;
        response = result.data;
        if (!status) {
          resolve({
            status,
            Result: status
              ? Result
              : `${Result}. Please contact the iTrack Administrator`,
          });
        }
      }),
    );

    if (response.status && action === 'save') {
      if (isProduction) {
        const prodDespatch = await taskDespatch(data, 'production');
        resolve(prodDespatch);
      } else if (isCustomer) {
        const custDespatch = await taskDespatch(data, 'customer');
        resolve(custDespatch);
      } else {
        resolve(response);
      }
    } else {
      resolve(response);
    }
  });
};

// export const despatchAction = (isProduction, isCustomer) => {
//   return new Promise(async resolve => {
//     try {
//       if (response.status) {
//         if (isProduction) {
//           const prodDespatch = await taskDespatch(data, 'production');
//           resolve(prodDespatch);
//         } else if (isCustomer) {
//           const custDespatch = await taskDespatch(data, 'customer');
//           resolve(custDespatch);
//         } else {
//           resolve(response);
//         }
//       } else {
//       }
//     } catch (e) {}
//   });
// };

const calculateTaskTOT = (wfeventId, userId) => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `SELECT taskreportid, totaltime, uomvalue FROM wms_task_report_view WHERE wfeventid = ${wfeventId} and userid='${userId}'`;

      query(sql)
        .then(exData => {
          sql = `SELECT timestamp FROM wms_workflow_eventlog_details
                    WHERE wfeventid=${wfeventId} AND operationtype = 'Work in progress' ORDER BY wfeventdetailid DESC
                    LIMIT 1 `;

          query(sql)
            .then(res => {
              if (res.length) {
                const now = moment();
                const then = moment(res[0].timestamp).format(
                  'DD/MM/YYYY HH:mm:ss',
                );
                const ms = moment(now, 'DD/MM/YYYY HH:mm:ss').diff(
                  moment(then, 'DD/MM/YYYY HH:mm:ss'),
                );
                const d = moment.duration(ms);

                const getPreMinutes = exData.length
                  ? moment(exData[0].totaltime, 'HH:mm:ss').diff(
                      moment().startOf('day'),
                      'minutes',
                    )
                  : 0;
                const totalMinutes = d.asMinutes() + getPreMinutes;

                resolve(totalMinutes);
              }
            })
            .catch(error => {
              reject(error);
            });
        })
        .catch(error => {
          reject(error);
        });
    } catch (e) {
      reject(e);
    }
  });
};

export const logisticEntryDelete = async data => {
  const { wfeventId } = data;

  const iWorksheetId = await _getWorksheetId(wfeventId);

  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.logisticEntryDelete,
    };
    const payload = {
      worksheetid: iWorksheetId, // 19557403
    };

    const result = await service.iPost(url, payload, headers);

    resolve(result.data);
  });
};

export const taskDespatch = (data, type) => {
  const { jobCardId, subjobArray, iStageId, userId } = data;
  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = { iendpointkey: config.iTracks.uri.book.iendpointKey };
    let payload = {};
    const setSubjobs = [];
    if (type === 'production') {
      subjobArray.forEach(sId => {
        setSubjobs.push({
          SubJobId: sId.subjobid,
          Quantity: sId.typesetpage,
          // to be confirmed
          // "Quantity": taskType === 'Single' ? isBatchTaskUom ? quantity || 0 : item.uomvalue : quantity || 0
        });
      });
      payload = {
        JobCardId: jobCardId,
        StageId: iStageId,
        SubJob: setSubjobs,
        EmpCode: userId,
        Finishdate: moment().format('YYYY-MM-DD hh:mm:ss'),
        PMEInstruction: 'testing',
      };
      headers.iendpointname = config.iTracks.uri.book.productionDispatch;
    } else {
      subjobArray.forEach(sId => {
        setSubjobs.push(sId.subjobid);
      });
      payload = {
        JobCardId: jobCardId,
        StageId: iStageId,
        SubJob: setSubjobs,
        EmpCode: userId,
        Finishdate: moment().format('YYYY-MM-DD hh:mm:ss'),
      };
      headers.iendpointname = config.iTracks.uri.book.customerDispatch;
    }

    const result = await service.iPost(url, payload, headers);

    resolve(result.data);
  });
};
const addWorksheetId = (worksheetId, wfeventid) => {
  return new Promise((resolve, reject) => {
    const sql = `UPDATE public.wms_workflow_eventlog SET worksheetid=${worksheetId}
        WHERE wfeventid=${wfeventid} `;
    query(sql)
      .then(() => {
        resolve(true);
      })
      .catch(() => {
        reject(false);
      });
  });
};

// const despatchAudit = (payload, response, woincomingfileid) => {
//   const { status, Result } = response;
//   return new Promise((resolve, reject) => {
//     if (status) {
//       const sql = `UPDATE public.wms_workorder_incomingfiledetails SET subjobid=${Result}
//             WHERE woincomingfileid=${woincomingfileid} `;
//       query(sql)
//         .then(res => {
//
//           resolve(status);
//         })
//         .catch(error => {
//           reject(error);
//         });
//     }
//   });
// };

/// get worksheet id
export const getWorksheetId = (req, res) => {
  const { wfeventId } = req.body;
  const sql = `SELECT worksheetid FROM public.wms_workflow_eventlog WHERE wfeventid = ${wfeventId}`;
  query(sql)
    .then(ressult => {
      res
        .status(200)
        .json({ data: ressult.length ? ressult[0].worksheetid : '' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const _getWorksheetId = wfeventId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT worksheetid FROM public.wms_workflow_eventlog WHERE wfeventid = ${wfeventId}`;
    query(sql)
      .then(ressult => {
        resolve(ressult.length ? ressult[0].worksheetid : '');
      })
      .catch(error => {
        reject(error);
      });
  });
};

export const iTracksReset = async (req, res) => {
  const { jobCardId, woType, duId, customerId, jobId, resetType } = req.body;
  try {
    const iStageId = await getiTracksStageId(req.body);

    let url = '';
    let headers = '';
    let payload = {};

    if (woType === 'Book') {
      const subjobArray = await getSubjobIds(req.body);

      const setSubjobs = [];
      subjobArray.forEach(sId => {
        setSubjobs.push(sId.subjobid);
      });
      payload = {
        jobcardid1: jobCardId,
        SubJobId: setSubjobs,
        stageId: iStageId,
      };
      url = config.iTracks.base_url;
      headers = {
        iendpointkey: config.iTracks.uri.book.iendpointKey,
        iendpointname: config.iTracks.uri.book.productionDispatchReset,
      };
    } else {
      const iDuId = await getiTracksDuId(duId);
      const iCustomerId = await getiTracksCustomerId(customerId);
      payload = {
        BookCode: jobId,
        DivisionID: iDuId,
        CustomerID: iCustomerId,
        StageId: iStageId,
      };
      url = config.iTracks.base_url;
      headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname:
          resetType === 'prodDesp'
            ? config.iTracks.uri.journal.productionDispatchReset
            : config.iTracks.uri.journal.customerDispatchReset,
      };
    }

    const result = await service.iPost(url, payload, headers);

    if (result.status) {
      res.status(200).json({ message: 'Production reset successfully' });
    } else {
      res.status(400).json({ message: 'Production reset failed' });
    }
  } catch (error) {
    res.status(400).json({ message: error });
  }
};

export const getProofingType = (req, res) => {
  const { journalid } = req.body;
  const sql = `SELECT proofingtype FROM public.pp_mst_journal where journalid = ${journalid}`;
  query(sql)
    .then(ressult => {
      res.status(200).send(ressult);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getTrnImages = (req, res) => {
  const { wfeventid, wfid } = req.body;
  let sql;
  if (wfid == 43) {
    sql = `select reverse(substr(reverse(repofilepath),0,strpos(reverse(repofilepath),'/'))),repofilepath 
  from  public.wms_workflowactivitytrn_file_map where 
  wfeventid =${wfeventid} and( repofilepath ilike '%.eps' or repofilepath ilike '%.tif' 
   or repofilepath ilike '%.gif' or repofilepath ilike '%.pdf')`;
  } else {
    sql = `select reverse(substr(reverse(repofilepath),0,strpos(reverse(repofilepath),'/'))),repofilepath 
  from  public.wms_workflowactivitytrn_file_map where 
  wfeventid =${wfeventid} and( repofilepath ilike '%.eps' or repofilepath ilike '%.tif' 
   or repofilepath ilike '%.gif')`;
  }

  query(sql)
    .then(ressult => {
      res.status(200).send(ressult);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getSupplimentFilesList = async (req, res) => {
  try {
    const { path } = req.body;

    // Get the file list
    const fileList = await _locallistAllFiles(path);

    // Extract filename, basePath, path, and uuid
    const extractedData = fileList.map(file => {
      const pathParts = file.path.split('/');
      const name = pathParts.pop(); // Get the last part (filename)
      const basePath = pathParts.join('/'); // Join remaining path parts
      return {
        name,
        basePath,
        path: file.path,
        uuid: file.uuid,
        reverse: name,
        repofilepath: basePath,
      };
    });

    res.status(200).json(extractedData);
  } catch (error) {
    res.status(400).json({ message: error.message || 'An error occurred' });
  }
};

export const deleteSupplimentFiles = async (req, res) => {
  try {
    const { filesPath } = req.body;

    // Delete each file asynchronously
    const deletionResults = await Promise.all(
      filesPath.map(async filePath => {
        try {
          await _localdelete(filePath.path);
          return { filePath, status: 'Deleted successfully' };
        } catch (error) {
          return { filePath, status: `Failed to delete: ${error.message}` };
        }
      }),
    );

    res.status(200).json({
      message: 'File deletion process completed',
      results: deletionResults,
    });

    // Get the file list
    // const fileList = await _localdelete(path);

    // res.status(200).json(extractedData);
  } catch (error) {
    res.status(400).json({ message: error.message || 'An error occurred' });
  }
};

export const graphicsImageActions = async (req, res) => {
  const { taskDetails, actionType, systemInfo, userid } = req.body;
  try {
    let { images } = req.body;

    if (actionType != 'SkipImage') {
      let countSql1 = `update public.wms_workorder_incomingfiledetails set
      imagecount = 1 where woincomingid in (select woincomingid from public.wms_workorder_incoming  where woid = ${taskDetails.workorderid})`;
      await query(countSql1);
    }

    if (actionType == 'Deleted') {
      const newDeletePath = JSON.stringify(images);
      const sql1 = `select regexp_replace(repofilepath, '.*/', ''), * from wms_workflowactivitytrn_file_map where woincomingfileid=${
        taskDetails.woincomingfileid
      }
        and regexp_replace(repofilepath, '.*/', '') = any (  
        (
        (select replace (replace (replace(aggval::Text,'{','{"') :: text, '}','"}')::text, ',','","')  
        from
        (select array_agg(reverse) as aggval from
        ( select reverse from json_to_recordset
         ('${newDeletePath}')
        as x(reverse text)
         union
        select  
           CASE WHEN '.pdf' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.pdf') ELSE null end as reverse
         from json_to_recordset
         ('${newDeletePath}')
        as x(reverse text)
         union
        select  
           CASE WHEN '.png' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.png') ELSE null end as reverse
         from json_to_recordset
         ('${newDeletePath}')
        as x(reverse text)
        ) as finalres where  coalesce (finalres.reverse,'') != '' 
        ) as ressub
           )::text[]))`;

      const response = await query(sql1);
      images = response;
    }
    const val = [];
    if (images && images.length) {
      images.forEach(list => {
        val.push(
          `(${taskDetails.workorderid}, '${
            list && list.reverse
              ? list.reverse
              : list.file && list.file.reverse
              ? list.file.reverse
              : list.regexp_replace
          }', ${taskDetails.stageid}, ${taskDetails.activityid}, ${
            taskDetails.wfeventid
          }, '${actionType}', '${systemInfo}', '${userid}',${
            taskDetails.customerid
          },'${
            list && list.path
              ? list.path
              : list.file && list.file.path
              ? list.file.path
              : list.repofilepath
          }' )`,
        );
      });

      const sql2 = `INSERT INTO wms_imageupload_actions_audit(workorderid,imagename,stageid,activityid,wfeventid,operationtype,
        systeminfo,userid,customerid,repofilepath) values ${val}`;

      await query(sql2);
    }

    if (actionType == 'SkipImage') {
      let countSql = `update public.wms_workorder_incomingfiledetails set
imagecount = 0 where woincomingid in (select woincomingid from public.wms_workorder_incoming  where woid = ${taskDetails.workorderid})`;
      await query(countSql);

      // let eventSql = `update public.wms_workflow_eventlog set
      // activitystatus = 'Completed' where workorderid   = ${taskDetails.workorderid})`
      //       await query(eventSql);

      const sql2 = `INSERT INTO wms_imageupload_actions_audit(workorderid,imagename,stageid,activityid,wfeventid,operationtype,
  systeminfo,userid,customerid) values ( ${taskDetails.workorderid},'skipped image upload',${taskDetails.stageid}, ${taskDetails.activityid}, ${taskDetails.wfeventid}, '${actionType}', '${systemInfo}', '${userid}',${taskDetails.customerid})`;

      await query(sql2);
    }

    res.status(200).json({
      status: true,
      data: 'audit table inserted successfully',
    });
  } catch (error) {
    res.status(400).send({ message: error, status: false });
  }
};
export const updateImagepathtrn = async (req, res) => {
  let { taskDetails, uploadedPaths } = req.body;

  try {
    if (taskDetails.woincomingfileid == null) {
      let incomingDetails = await _getIncomingFileType(taskDetails.workorderid);
      console.log(incomingDetails, 'incomingDetailsh');
      incomingDetails = incomingDetails.filter(list => list.filetypeid == 2);
      taskDetails.woincomingfileid = incomingDetails[0].woincomingfileid;
    }

    for (const list of uploadedPaths) {
      const sql = `INSERT INTO wms_workflowactivitytrn_file_map(
wfeventid, repofileuuid,repofilepath,workingfolderpath,isvisible, isdownloaded, woincomingfileid, ischeckedout, isactive)
select ${taskDetails.wfeventid}, 'local', '${
        list.path
      }', null, ${true}, ${false}, '${
        taskDetails.woincomingfileid
      }',null,${true}
where not exists (
  select 1 from wms_workflowactivitytrn_file_map
      where wfeventid = ${taskDetails.wfeventid}
      and repofilepath = '${list.path}'
      and woincomingfileid = '${taskDetails.woincomingfileid}'
)`;

      await query(sql);
    }
    res.status(200).json({
      status: true,
      data: 'Trancesection table inserted successfully',
    });
  } catch (error) {
    res.status(400).send({ message: error, status: false });
  }
};

export const deleteImagepathtrn = async (req, res) => {
  const { deletePaths, taskDetails } = req.body;
  const newDeletePath = JSON.stringify(deletePaths);

  if (taskDetails.customerid == '8') {
    const sql = `select regexp_replace(repofilepath, '.*/', ''), * from wms_workflowactivitytrn_file_map where woincomingfileid=${
      taskDetails.woincomingfileid
    }
    and regexp_replace(repofilepath, '.*/', '') = any (  
    (
    (select replace (replace (replace(aggval::Text,'{','{"') :: text, '}','"}')::text, ',','","')  
    from
    (select array_agg(reverse) as aggval from
    ( select reverse from json_to_recordset
     ('${newDeletePath}')
    as x(reverse text)
     union
    select  
       CASE WHEN '.pdf' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.pdf') ELSE null end as reverse
     from json_to_recordset
     ('${newDeletePath}')
    as x(reverse text)
     union
    select  
       CASE WHEN '.png' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.png') ELSE null end as reverse
     from json_to_recordset
     ('${newDeletePath}')
    as x(reverse text)
    ) as finalres where finalres.reverse is not null
    ) as ressub
       )::text[]))`;

    const response = await query(sql);

    const awt = [];
    for (let i = 0; i < response.length; i++) {
      // const chunk = payload.slice(i, i + chunkSize);
      awt.push(_plimit(() => azureHelper._delete(response[i].repofilepath)));
    }
    await Promise.all(awt);

    const Deletesql = `Delete from wms_workflowactivitytrn_file_map where woincomingfileid=${
      taskDetails.woincomingfileid
    }
    and regexp_replace(repofilepath, '.*/', '') = any (  
    (
    (select replace (replace (replace(aggval::Text,'{','{"') :: text, '}','"}')::text, ',','","')  
    from
    (select array_agg(reverse) as aggval from
    ( select reverse from json_to_recordset
     ('${newDeletePath}')
    as x(reverse text)
     union
    select  
       CASE WHEN '.pdf' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.pdf') ELSE null end as reverse
     from json_to_recordset
     ('${newDeletePath}')
    as x(reverse text)
     union
    select  
       CASE WHEN '.png' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.png') ELSE null end as reverse
     from json_to_recordset
     ('${newDeletePath}')
    as x(reverse text)
    ) as finalres where finalres.reverse is not null
    ) as ressub
       )::text[]))`;

    await query(Deletesql)
      .then(async datastrn => {
        console.log(datastrn, 'datacontacts');
        res.status(200).json({
          status: true,
          data: 'Trancesection table deleted successfully',
        });
      })
      .catch(error => {
        res.status(400).send({ message: error, status: false });
      });
  } else {
    let condition = '';
    if (deletePaths.length > 0) {
      deletePaths.forEach((list, index) => {
        condition += `%${list}%`;
        if (index !== deletePaths.length - 1) {
          condition += '|';
        }
      });
    }
    let sql = `select * from wms_workflowactivitytrn_file_map where wfeventid=${taskDetails.wfeventid} and repofilepath SIMILAR TO '${condition}'`;

    const response = await query(sql);

    // const awt = [];
    // await deleteImagesStorage(response, taskDetails);
    // await Promise.all(awt);
    sql = `DELETE from wms_workflowactivitytrn_file_map where wfeventid=${taskDetails.wfeventid} and repofilepath SIMILAR TO '${condition}'`;
    await query(sql);
    res.status(200).json({
      status: true,
      data: response,
      message: 'Transaction table deleted successfully',
    });
  }
};
// export const deleteImagesStorage = async (response, taskDetails) => {
//   return new Promise((resolve, reject) => {
//     try {
//       const awt = [];
//       for (let i = 0; i < response.length; i++) {
//         switch (taskDetails.dmstype) {
//           case 'azure':
//             awt.push(
//               _plimit(() => azureHelper._delete(response[i].repofilepath)),
//             );
//             break;
//           case 'local':
//             awt.push(_plimit(() => _localdelete(response[i].repofilepath)));
//             break;
//           default:
//             awt.push(_plimit(() => _localdelete(response[i].repofilepath)));
//             break;
//         }
//       }
//       Promise.all(awt)
//         .then(() => resolve(true))
//         .catch(error => reject(error));
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

// function deleteImagesStorage(response, taskDetails, awt) {
// for (let i = 0; i < response.length; i++) {
//   // const chunk = payload.slice(i, i + chunkSize);
//   // eslint-disable-next-line default-case
//   switch (taskDetails.dmstype) {
//     case 'azure':
//       awt.push(_plimit(() => azureHelper._delete(response[i].repofilepath)));
//       break;
//     case 'local':
//       awt.push(_plimit(() => _localdelete(response[i].repofilepath)));
//       break;
//   }
// }
// }

export const deleteGraphicToolImagepath = async (req, res) => {
  const { deletePaths, taskDetails } = req.body;
  const newDeletePath = JSON.stringify(deletePaths);

  const sql = `Delete from wms_workflowactivitytrn_file_map where woincomingfileid=${taskDetails.woincomingfileid} 
  and 
  repofilepath = any (  
  (select array_agg(repofilepath) from json_to_recordset('${newDeletePath}') as x(repofilepath text)
  )::text[] 
  )`;

  const awt = [];
  for (let i = 0; i < deletePaths.length; i++) {
    // const chunk = payload.slice(i, i + chunkSize);
    awt.push(_plimit(() => azureHelper._delete(deletePaths[i].repofilepath)));
  }
  await Promise.all(awt);

  await query(sql)
    .then(async datastrn => {
      console.log(datastrn, 'datacontacts');
      res.status(200).json({
        status: true,
        data: 'Trancesection table deleted successfully',
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const getLastFileName = async (req, res) => {
  const { woID } = req.body;
  try {
    const lastfilename = await _getLastFileName(woID);
    res.send(lastfilename);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const _getLastFileName = async woID => {
  const sql = `select a.woincomingid , a.filename , a.newfilename  from wms_workorder_incomingfiledetails as a 
     left join wms_workorder_incoming as b on a.woincomingid = b.woincomingid 
     where b.woid = $1 and newfilename is not null order by a.filesequence  desc limit 1`;
  const data = await query(sql, [woID]);
  if (data.length > 0) {
    const { woincomingid, filename, newfilename } = data[0];
    return {
      woIncomingId: woincomingid,
      fileName: filename,
      newFileName: newfilename,
    };
  }
  const array = {};
  return array;
};

// tools Upload Actions
export const toolsUploadActions = async (req, res) => {
  console.log(req.body, 'neww', res);
  try {
    const { files, actionType, props, systemInfo, userid } = req.body;
    console.log(props, 'props');
    const val = [];
    files.forEach(list => {
      val.push(
        `('${list.name}', '${userid}', '${systemInfo}', '${list.data.replace(
          /\\/g,
          '/',
        )}', '${actionType}', ${props.profile.duId} )`,
      );
    });

    const sql2 = `INSERT INTO wms_toolsupload_actions_audit(filename,userid,systeminfo,actionpath,actiontype
      ,duid) values ${val}`;

    await query(sql2);
    res.status(200).json({
      status: true,
      data: 'audit table inserted successfully',
    });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({ message: error, status: false });
  }
};

export const iTracksCall = async (req, res) => {
  // const url = 'http://localhost:8081/api/testDll';
  // let result = await service.get(`${url}`);
  res.send(true);
};

// Journal API module

export const addSatge = data => {
  const {
    duId,
    customerId,
    // receiptdate,
    // receiptdate,
    jobId,
    wotype,
    // eslint-disable-next-line no-unused-vars
    valuesOfArray,
    // duedate,
    // duedate,
    woid,
    isrelatedstage,
    stageId,
  } = data;
  let { plannedenddate, receiptdate, duedate, woId } = data;
  woId = woid || woId;
  let { woType } = data;
  return new Promise(async (resolve, reject) => {
    try {
      let tmp_plannedenddate;
      receiptdate = receiptdate
        ? receiptdate.trim().replace('T', ' ').substring(0, 19)
        : receiptdate;
      plannedenddate = plannedenddate
        ? plannedenddate.trim().replace('T', ' ').substring(0, 19)
        : plannedenddate;
      if (typeof duedate == 'object') {
        duedate = duedate
          ? duedate.toISOString().trim().replace('T', ' ').substring(0, 19)
          : duedate;
      } else if (typeof duedate == 'string') {
        duedate = duedate
          ? duedate.trim().replace('T', ' ').substring(0, 19)
          : duedate;
      } else {
        duedate = duedate
          ? duedate.trim().replace('T', ' ').substring(0, 19)
          : duedate;
      }

      woType = woType || wotype;
      if (woType === 'Journal') {
        const iDuId = await getiTracksDuId(duId);
        const iCustomerId = await getiTracksCustomerId(customerId);
        const iStageId = await getiTracksStageId(data);
        const fileDetails = await getFileDetails(data);
        if (isrelatedstage) {
          const relatedStagedet = await getTATforStage(woId, stageId);
          if (relatedStagedet != undefined && relatedStagedet.data.length) {
            tmp_plannedenddate = relatedStagedet.data[0].plannedenddate;
            if (tmp_plannedenddate != undefined) {
              plannedenddate = tmp_plannedenddate
                .toISOString()
                .replace('T', ' ')
                .substring(0, 19);
            }
          }
        }

        if (iDuId && iCustomerId && iStageId && fileDetails.length) {
          const url = config.iTracks.base_url;
          const headers = {
            iendpointkey: config.iTracks.uri.journal.iendpointKey,
            iendpointname: config.iTracks.uri.journal.addStage,
          };
          const payload = {
            BookCode: jobId,
            DivisionId: iDuId,
            CustomerId: iCustomerId,
            StageId: iStageId,
            ReceiveDate:
              receiptdate ||
              moment().toISOString().replace('T', ' ').substring(0, 19),
            DueDate: plannedenddate || duedate,
            MSPage: fileDetails[0].mspages,
          };

          const result = await service.iPost(url, payload, headers);
          // const result = {status: true,data: {status: true,test:""}}

          const { status, Result } = result.data;
          if (status == false) {
            const itrackloginput = {
              url: '',
              payloaddata: '',
              headers: '',
              paramdata: '',
              iduid: 0,
              icustomerid: 0,
              status: '',
              failureplace: '',
              saveaction: '',
              isproduction: '',
              iscustomer: '',
              remarks: '',
            };

            const igerUrl = await axios
              .get(config.iTracks.switch_url)
              .catch(() => {
                reject({
                  status: false,
                  message: 'Unable to reach the ipswitch server.',
                });
              });

            if (!igerUrl?.data || !isValidiTracksUrl(igerUrl.data)) {
              reject({
                status: false,
                message: 'Unable to fetch the iTracks URL (ipswitch).',
              });
            }

            let iurl = `https://${igerUrl.data}/${config.iTracks.service_url}`;

            itrackloginput.url = iurl;
            itrackloginput.payloaddata = payload;
            itrackloginput.headers = headers;
            itrackloginput.paramdata = JSON.stringify(data);
            itrackloginput.iduid = iDuId;
            itrackloginput.icustomerid = iCustomerId;
            itrackloginput.status = status;
            itrackloginput.failureplace = 'addstage';
            itrackloginput.saveaction = '';
            itrackloginput.isproduction = false;
            itrackloginput.iscustomer = false;
            itrackloginput.remarks = Result;

            await insert_itrackservicecall(itrackloginput);
          }

          resolve({
            status,
            message: status
              ? Result
              : `${Result}. Please contact the iTrack Administrator`,
          });
        } else {
          resolve({
            status: false,
            message: `iTracks duid / stageid / customerid / file info not fount in iWMS`,
          });
        }
      } else {
        resolve({ status: true });
      }
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getiTracksCustomerId = customerId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT icustomerid FROM org_mst_customer WHERE customerid= ${customerId} AND isactive=true`;
    query(sql)
      .then(res => {
        if (res.length) {
          resolve(res[0].icustomerid);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        reject(false);
      });
  });
};

export const getiTracksDuId = duId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT iduid FROM org_mst_deliveryunit WHERE duid= ${duId} AND isactive=true`;

    query(sql)
      .then(res => {
        if (res.length) {
          resolve(res[0].iduid);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        reject(false);
      });
  });
};

export const logisticEntryInsertJournal = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        userid,
        iStageId,
        iActivityId,
        startPage,
        endPage,
        wfeventid,
        duId,
        customerId,
        taskType,
        jobType,
      } = data;
      let { jobId } = data;

      const iDuId = await getiTracksDuId(duId);
      const iCustomerId = await getiTracksCustomerId(customerId);
      if (taskType == 'Multiple' && jobType == '2') {
        jobId = await getSubIssues(data);
      }

      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.logisticEntryInsert,
      };
      const payload = {
        BookCode: jobId,
        DivisionID: iDuId,
        CustomerID: iCustomerId,
        trandate: moment().toISOString(),
        activityId: iActivityId,
        startDate: moment().toISOString(),
        StageId: iStageId,
        EmpCode: userid,
        startPage: startPage || 1,
        endPage: endPage || 1,
      };

      const result = await service.iPost(url, payload, headers);

      const { status, Result } = result.data;
      let worksheetRes = false;
      if (status) {
        worksheetRes = await addWorksheetId(Result, wfeventid);
      } else {
        resolve({
          status,
          message: `${Result}. Please contact the iTrack Administrator`,
        });
      }
      if (worksheetRes) {
        resolve({ status, message: Result });
      } else {
        resolve({ status, message: 'Worksheet id update failed' });
      }
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const logisticEntryUpdateJournal = async (
  data,
  isProduction,
  isCustomer,
  actionId,
  action,
) => {
  const {
    duId,
    customerId,
    userid,
    iStageId,
    iActivityId,
    endPage,
    quantity,
    wfeventId,
    jobId,
  } = data;

  const itrackloginput = {
    url: '',
    payloaddata: '',
    headers: '',
    paramdata: '',
    iduid: 0,
    icustomerid: 0,
    status: '',
    failureplace: '',
    saveaction: '',
    isproduction: '',
    iscustomer: '',
    remarks: '',
  };

  const iDuId = await getiTracksDuId(duId);
  const iCustomerId = await getiTracksCustomerId(customerId);
  return new Promise(async (resolve, reject) => {
    try {
      const totMins = await calculateTaskTOT(wfeventId, userid);
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.logisticEntryUpdate,
      };
      let response = { status: false, Result: '' };

      const iWorksheetId = await _getWorksheetId(wfeventId);

      const payload = {
        BookCode: jobId,
        DivisionID: iDuId,
        CustomerID: iCustomerId,
        worksheetid: iWorksheetId,
        totMins,
        quantity: quantity || 0,
        statusId: actionId,
        remarks: 'test',
        activityId: iActivityId,
        StageId: iStageId,
        EmpCode: userid,
        Finishdate: moment().toISOString(),
        startPage: endPage ? 1 : 0,
        endPage: endPage || 0,
      };

      const result = await service.iPost(url, payload, headers);

      const { status, Result } = result.data;
      response = result.data;
      if (!status) {
        itrackloginput.url = url;
        itrackloginput.payloaddata = payload;
        itrackloginput.headers = headers;
        itrackloginput.paramdata = JSON.stringify(data);
        itrackloginput.iduid = iDuId;
        itrackloginput.icustomerid = iCustomerId;
        itrackloginput.status = status;
        itrackloginput.failureplace = 'logisticEntryUpdate';
        itrackloginput.saveaction = action;
        itrackloginput.isproduction = isProduction;
        itrackloginput.iscustomer = isCustomer;
        itrackloginput.remarks = Result;

        await insert_itrackservicecall(itrackloginput);

        resolve({
          status,
          Result: status
            ? Result
            : `${Result}. Please contact the iTrack Administrator`,
        });
      }
      if (response.status && action === 'save') {
        data.isProduction = isProduction;
        data.isCustomer = isCustomer;

        if (!isProduction && !isCustomer) {
          resolve(response);
        } else if (isProduction && isCustomer) {
          const prodDespatch = await taskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
          );
          if (prodDespatch.status) {
            const custDespatch = await taskDespatchJournal(
              { ...data, iDuId, iCustomerId },
              'customer',
            );
            resolve(custDespatch);
          } else {
            resolve(prodDespatch);
          }
        } else if (isProduction && !isCustomer) {
          const prodDespatch = await taskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
          );
          resolve(prodDespatch);
        } else if (!isProduction && isCustomer) {
          const custDespatch = await taskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'customer',
          );
          resolve(custDespatch);
        }
      } else {
        resolve(response);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const taskDespatchJournal = (data, type) => {
  const { userid, iStageId, quantity, jobId, iDuId, iCustomerId } = data;

  const itrackloginput = {
    url: '',
    payloaddata: '',
    headers: '',
    paramdata: JSON.stringify(data),
    iduid: iDuId,
    icustomerid: iCustomerId,
    status: '',
    failureplace: '',
    saveaction: '',
    isproduction: '',
    iscustomer: '',
    remarks: '',
  };

  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iTracks.base_url;
      const headers = { iendpointkey: config.iTracks.uri.book.iendpointKey };
      let payload = {};
      if (type === 'production') {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          pagecount: quantity || 0,
          Finishdate: moment().toISOString(),
          PMEInstruction: 'testing',
        };
        itrackloginput.failureplace = 'ProductionDispatch';
        headers.iendpointname = config.iTracks.uri.journal.productionDispatch;
      } else {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          Finishdate: moment().toISOString(),
        };
        itrackloginput.failureplace = 'CustomerDispatch';
        headers.iendpointname = config.iTracks.uri.journal.customerDispatch;
      }

      const result = await service.iPost(url, payload, headers);

      if (result.status) {
        const { status, Result } = result.data;

        if (status == false) {
          itrackloginput.url = url;
          itrackloginput.payloaddata = payload;
          itrackloginput.headers = headers;
          itrackloginput.status = status;
          // itrackloginput.failureplace ='logisticEntryUpdate',
          itrackloginput.saveaction = 'save';
          itrackloginput.isproduction = data.isProduction;
          itrackloginput.iscustomer = data.isCustomer;
          itrackloginput.remarks = Result;

          await insert_itrackservicecall(itrackloginput);
        }
      }
      resolve(result.data);
    } catch (e) {
      reject(e);
    }
  });
};

export const mergeIssue = async (articlesArray, data) => {
  let filename = '';
  for (let i = 0; i < articlesArray.length; i++) {
    filename += `'${articlesArray[i].filename}' ${
      articlesArray.length - 1 !== i ? ',' : ''
    } `;
  }
  if (filename.length > 0) {
    const sql = `select case when wwif.filetypeid = 4 then  ww.itemcode else  wwif.filename end as itemcode from wms_workorder_incomingfiledetails as wwif
        join wms_workorder_incoming as wwi on wwi.woincomingid=wwif.woincomingid
        join wms_workorder as ww on  ww.workorderid=wwi.woid
		    join pp_mst_filetype as filetype on filetype.filetypeid = wwif.filetypeid
        where replace(wwif.filename,'_Article','') IN  (${filename})  
       and (case when (wwif.filetypeid = 4 or filetype.articletype = 'Other Article') then ww.workorderid NOT IN (${data.woid})
        and ww.status='Completed' else true end)`;

    const result = await query(sql, []);

    const articles = result.map(item => {
      return item.itemcode;
    });
    return new Promise(async resolve => {
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.mergeIssue,
      };
      const payload = {
        Articles: articles,
        Issue: data.jobId,
      };

      const rest = await service.iPost(url, payload, headers);
      const { status, Result } = rest.data;
      resolve({ status, message: Result });
    });
  }
  return Promise.resolve({ status: false, message: 'No filenames provided.' });
};

export const mergeIssueForBatchFloq = async data => {
  const { issuename, type } = data;
  let articles;
  if (type == 'stagemerge') {
    const sql = `select * from wms_workorder as wo join 
  public.pp_mst_issue_master as issuemst on wo.issuemstid = issuemst.issuemstid
  where issuemst.issuename = '${issuename}'`;

    const result = await query(sql);
    articles = result.map(item => {
      return item.itemcode;
    });
  } else {
    articles = [data.articlename];
  }
  // const sql = `select * from wms_workorder as wo join
  //   public.pp_mst_issue_master as issuemst on wo.issuemstid = issuemst.issuemstid
  //   where issuemst.issuename = '${issuename}'`;
  //
  // const result = await query(sql);
  // const articles = result.map(item => {
  //   return item.itemcode;
  // });
  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.journal.iendpointKey,
      iendpointname: config.iTracks.uri.journal.mergeIssue,
    };
    const payload = {
      Articles: articles,
      Issue: issuename,
    };

    const rest = await service.iPost(url, payload, headers);
    const { status, Result } = rest.data;
    resolve({ status, message: Result });
  });
};

const getSubIssues = data => {
  const { fileName, customerId, workorderId } = data;
  return new Promise((resolve, reject) => {
    const sql = `select ww.itemcode from wms_workorder_incomingfiledetails as wwif
    join wms_workorder_incoming as wwi on wwi.woincomingid=wwif.woincomingid
    join pp_mst_filetype as filetype on filetype.filetypeid = wwif.filetypeid
    join wms_workorder as ww on  ww.workorderid=wwi.woid
    where replace(wwif.filename,'_Article','') ='${fileName}'  and ww.customerid=${customerId}
    and case when (wwif.filetypeid = 4  or filetype.articletype = 'Other Article' )then
     ww.workorderid NOT IN (${workorderId})
    and ww.status='Completed' else true end`;

    query(sql)
      .then(res => {
        resolve(res.length ? res[0].itemcode : '');
      })
      .catch(error => {
        reject(error);
      });
  });
};

// newItracks email trigger

export const getEmailTemplate = async (entityid, action) => {
  try {
    const sql = `SELECT * from wms_notifications WHERE entityid = ${entityid} and action = '${action}'`;

    const resForConfig = await query(sql);
    if (resForConfig.length > 0) {
      return resForConfig;
    }
    return false;
  } catch (error) {
    return false;
  }
};

export const getDivisionGroupMailid = async (divisionid, customerid) => {
  try {
    const sql = `select mailtype, mailid from iquality.svnd_trn_divisiongroupmail where divisionid = ${divisionid} and customerid = ${customerid} and modulename = 'quality'`;
    const divGropuMailid = await query(sql);
    if (divGropuMailid.length > 0) {
      return divGropuMailid;
    }
    return [];
  } catch (error) {
    return [];
  }
};

export function extractEmails(emails) {
  return emails.filter(email => email.includes('@'));
}

async function getMailCentralQuality() {
  const centralQualitySQL = `
    SELECT ud.useremail
    FROM public.wms_user_details ud
    LEFT JOIN public.wms_userrole ur ON ur.userid = ud.userid
    LEFT JOIN public.wms_role r ON r.roleid = ur.roleid
    WHERE r.roleacronym = 'CQH'
    GROUP BY ud.useremail
  `;
  const mailForCQH = await query(centralQualitySQL);
  return mailForCQH.map(emailObj => emailObj.useremail);
}

async function getMailForTo(TOGroup, RaisedToId) {
  const toSQL = `
    SELECT ud.useremail
    FROM public.wms_user_details ud
    LEFT JOIN public.wms_userrole ur ON ur.userid = ud.userid
    LEFT JOIN public.wms_role r ON r.roleid = ur.roleid
    WHERE ud.duid IN (${RaisedToId})
    AND r.roleacronym IN (${TOGroup.map(role => `'${role}'`).join(', ')})
    GROUP BY ud.useremail
  `;

  const mailForTo = await query(toSQL);
  return mailForTo.map(emailObj => emailObj.useremail);
}

async function getMailForCC(CCGroup, RaisedFrom, userid) {
  const toSQL = `
  select ud.useremail from  public.wms_user_details ud
  left join public.wms_userrole ur on ur.userid = ud.userid
  left join public.wms_role r on r.roleid = ur.roleid
  where ud.duid IN (${RaisedFrom})
  and r.roleacronym IN (${CCGroup.map(role => `'${role}'`).join(
    ', ',
  )}) group by ud.useremail
  union all
  select ud.useremail from  public.wms_user_details ud where 	 ud.userid = '${userid}'
  `;
  const mailForCC = await query(toSQL);
  return mailForCC.map(emailObj => emailObj.useremail);
}

function modifyNotificationConfigFromEmails(
  mailConfig,
  mailCentralQuality,
  mailTo,
  mailCC,
  mailIDinTO,
  mailIDinCC,
  KAMmail,
  CMmail,
  PMmail,
) {
  // Combine all email IDs
  const allEmails = [
    ...mailCentralQuality,
    ...mailTo,
    ...mailIDinTO,
    ...KAMmail,
    ...CMmail,
    ...PMmail,
  ];

  // Deduplicate and filter out null values
  mailConfig.to = [...new Set(allEmails)].filter(
    email => email && email !== 'null',
  );
  mailConfig.cc = [...new Set([...mailCC, ...mailIDinCC])].filter(
    email => email && email !== 'null',
  );

  // Remove email IDs that exist in both to and cc arrays
  mailConfig.cc = mailConfig.cc.filter(email => !mailConfig.to.includes(email));
  return mailConfig;
}

function checkAndPushKAMMailIfConditionMet(
  mailAction,
  mailConfig,
  roleToCheck,
  emailToPush,
  feedbackId,
) {
  if (
    mailAction !== 'IC' &&
    feedbackId?.split('-')[0] !== 'IA' &&
    (mailConfig.to.includes(roleToCheck) ||
      (mailConfig.cc.includes(roleToCheck) && emailToPush != null))
  ) {
    const uniqueEmails = [...new Set(emailToPush)];
    return uniqueEmails;
  }
  return [];
}
function checkAndPushMailIfConditionMet(mailConfig, roleToCheck, emailToPush) {
  if (
    mailConfig.to.includes(roleToCheck) ||
    (mailConfig.cc.includes(roleToCheck) && emailToPush != null)
  ) {
    const uniqueEmails = [...new Set(emailToPush)];
    return uniqueEmails;
  }
  return [];
}

export async function sendMail(data) {
  const endpointUrl = `${process.env.CLIENT_HOST}:${process.env.CLIENT_PORT}`;
  const {
    feedbackId,
    encryptedID,
    mailAction,
    entityid,
    BookCode,
    Raisedby,
    RaisedFrom,
    RaisedFromDU,
    RaisedTo,
    RaisedToId,
    CustomerId,
    RaisedOn,
    CustomerName,
    CustomerDivision,
    CustomerCountry,
    Description,
    userid,
    SubDu,
    JobFamily,
    BookCodekamEmail,
    BookCodeCMEmail,
    BookCodePMEmail,
    MisStatus,
  } = data;

  const resForConfig = await getEmailTemplate(entityid, mailAction);
  const { notificationconfig } = resForConfig[0];

  const mailIDinTO = extractEmails(notificationconfig.to);
  const mailIDinCC = extractEmails(notificationconfig.cc);
  const mailCentralQuality =
    notificationconfig.to.includes('CQH') ||
    notificationconfig.cc.includes('CQH')
      ? await getMailCentralQuality(notificationconfig)
      : [];

  const TOGroup = notificationconfig.to;
  const CCGroup = notificationconfig.cc;
  const mailTo =
    RaisedToId != null && RaisedToId != ''
      ? await getMailForTo(TOGroup, RaisedToId)
      : await getMailForTo(TOGroup, RaisedFrom);
  const mailCC = await getMailForCC(CCGroup, RaisedFrom, userid);
  let KAMmail = [];
  let CMmail = [];
  let PMmail = [];
  KAMmail = checkAndPushKAMMailIfConditionMet(
    mailAction,
    notificationconfig,
    'KAM',
    BookCodekamEmail,
    feedbackId,
  );
  CMmail = checkAndPushMailIfConditionMet(
    notificationconfig,
    'CM',
    BookCodeCMEmail,
  );
  PMmail = checkAndPushMailIfConditionMet(
    notificationconfig,
    'PME',
    BookCodePMEmail,
  );
  const divisionGroupMailid = await getDivisionGroupMailid(
    RaisedToId,
    CustomerId,
  );
  divisionGroupMailid.forEach(item => {
    if (item.mailtype.toLowerCase() === 'cc') {
      if (Array.isArray(item.mailid)) {
        mailCC.push(...item.mailid);
      } else {
        mailCC.push(item.mailid);
      }
    } else if (item.mailtype.toLowerCase() === 'to') {
      if (Array.isArray(item.mailid)) {
        mailTo.push(...item.mailid);
      } else {
        mailTo.push(item.mailid);
      }
    }
  });

  const updatedNotificationConfig = await modifyNotificationConfigFromEmails(
    notificationconfig,
    mailCentralQuality,
    mailTo,
    mailCC,
    mailIDinTO,
    mailIDinCC,
    KAMmail,
    CMmail,
    PMmail,
  );

  const mailData = {
    ...updatedNotificationConfig,
    feedbackId,
    BookCode,
    encryptedID,
    Raisedby,
    RaisedFrom,
    RaisedFromDU,
    RaisedTo,
    RaisedOn,
    CustomerName,
    CustomerDivision,
    CustomerCountry,
    Description,
    userid,
    SubDu,
    JobFamily,
    endpointUrl,
    MisStatus,
  };
  console.log(mailData);
  emitAction(mailData);
  return true;
}

export const mailTriggerForiTracks = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      // eslint-disable-next-line prefer-template, prettier/prettier
      const endpointUrl =
        // eslint-disable-next-line prefer-template
        process.env.CLIENT_HOST + ':' + process.env.CLIENT_PORT;
      const {
        feedbackId,
        encryptedID,
        mailAction,
        entityid,
        BookCode,
        Raisedby,
        RaisedFrom,
        RaisedTo,
        RaisedOn,
        CustomerName,
        CustomerDivision,
        CustomerCountry,
        Description,
        userid,
        SubDu,
        JobFamily,
      } = data;
      try {
        const mailTo = [];
        const mailCentralQuality = [];
        const mailCC = [];
        const mailIDinTO = [];
        const mailIDinCC = [];
        const resForConfig = await getiTracksNotificationConfig(
          entityid,
          mailAction,
        );
        const { notificationconfig } = resForConfig[0];
        // mail ID's from Central Quality
        for (const item of resForConfig[0].notificationconfig.to) {
          if (item.includes('@')) {
            const emails = item.match(/\S+@\S+\.\S+/);
            if (emails) {
              mailIDinTO.push(emails[0]);
            }
          }
        }
        for (const item of resForConfig[0].notificationconfig.cc) {
          if (item.includes('@')) {
            const emails = item.match(/\S+@\S+\.\S+/);
            if (emails) {
              mailIDinCC.push(emails[0]);
            }
          }
        }
        if (
          resForConfig[0].notificationconfig.to.length > 0 &&
          resForConfig[0].notificationconfig.to.includes('CQH')
        ) {
          const centralQuality = `select ud.useremail from  public.wms_user_details ud
          left join public.wms_userrole ur on ur.userid = ud.userid
          left join public.wms_role r on r.roleid = ur.roleid
          where  r.roleacronym = 'CQH' group by ud.useremail
          `;
          const mailForCQH = await query(centralQuality);
          if (mailForCQH.length > 0) {
            for (const emailObj of mailForCQH) {
              mailCentralQuality.push(emailObj.useremail);
            }
          }
        }

        // mail ID's from To Roles
        if (resForConfig[0].notificationconfig.to.length > 0) {
          const TOGroup =
            // eslint-disable-next-line prefer-template
            "'" + resForConfig[0].notificationconfig.to.join("', '") + "'";
          const ToQL = `select ud.useremail from  public.wms_user_details ud
          left join public.wms_userrole ur on ur.userid = ud.userid
          left join public.wms_role r on r.roleid = ur.roleid
          where ud.duid in (select udd.duid from public.wms_user_details udd
          where udd.duname = '${RaisedTo}')
          and r.roleacronym IN (${TOGroup}) group by ud.useremail
          `;
          const mailForTo = await query(ToQL);
          if (mailForTo.length > 0) {
            for (const emailObj of mailForTo) {
              mailTo.push(emailObj.useremail);
            }
          }
        }
        resForConfig[0].notificationconfig.to.length = 0;
        resForConfig[0].notificationconfig.to.push(
          ...mailCentralQuality,
          ...mailTo,
          ...mailIDinTO,
        );
        if (resForConfig[0].notificationconfig.cc.length > 0) {
          const CCGroup =
            // eslint-disable-next-line prefer-template
            "'" + resForConfig[0].notificationconfig.cc.join("', '") + "'";
          const CCTL = `select ud.useremail from  public.wms_user_details ud
          left join public.wms_userrole ur on ur.userid = ud.userid
          left join public.wms_role r on r.roleid = ur.roleid
          where ud.duid in (select udd.duid from public.wms_user_details udd
          where udd.userid = '${userid}')
          and r.roleacronym IN (${CCGroup}) group by ud.useremail
          union all
          select ud.useremail from  public.wms_user_details ud where 	 ud.userid = '${userid}'
          `;
          const mailForCC = await query(CCTL);
          if (mailForCC.length > 0) {
            resForConfig[0].notificationconfig.cc.length = 0;
            for (const emailObj of mailForCC) {
              mailCC.push(emailObj.useremail);
            }
          }
        }
        resForConfig[0].notificationconfig.cc.length = 0;
        resForConfig[0].notificationconfig.cc.push(...mailCC, ...mailIDinCC);
        const mailData = {
          ...notificationconfig,
          feedbackId,
          encryptedID,
          BookCode,
          Raisedby,
          RaisedFrom,
          RaisedTo,
          RaisedOn,
          CustomerName,
          CustomerDivision,
          CustomerCountry,
          Description,
          userid,
          SubDu,
          JobFamily,
          endpointUrl,
        };
        emitAction(mailData);
        resolve(true);
      } catch (error) {
        console.log(error, 'mail sending error');
        // res.status(400).send({ message: 'Failed sending email', error });
        reject(false);
      }
      // });
      resolve(true);
    } catch (e) {
      reject(false);
    }
  });
};

export const getiTracksNotificationConfig = (entityid, action) => {
  return new Promise(async resolve => {
    try {
      let sql = '';
      sql = `SELECT * from wms_notifications WHERE entityid= ${entityid} and action='${action}'`;

      query(sql).then(resForConfig => {
        if (resForConfig.length > 0) {
          resolve(resForConfig);
        } else {
          resolve(false);
        }
      });
    } catch (e) {
      resolve(false);
    }
  });
};

export const relatedStageInfo = async (wfId, customerId, stageId) => {
  return new Promise(async resolve => {
    // and wcssr.triggerrelatedstage = case when (wcssr.stageid = 2 and wcssr.customerid = 13 and (select count(1) from wms_workorder_stage where workorderid=${woId} and wfstageid=2 and status !='YTS' )>0) then false else true end
    try {
      const sql = `select  resq.wfid,resq.stageid,resq.stagename,wfsub.seq from
    (
      select wcssr.wfid,st.stageid,st.stagename FROM wms_config_splited_stage_relation wcssr 
      join wms_mst_stage st ON st.stageid = any(wcssr.relatedstage)  
      WHERE wcssr.stageid = ${stageId}  and wcssr.customerid =  ${customerId}  
      and wcssr.triggerrelatedstage = true
      and wcssr.isactive = true
      order by wcssr.wfid , wcssr.stageid
    ) as resq
    join (select stageid, min(sequence) as seq from wms_workflowdefinition where wfid = ${wfId}  
    group by stageid   order by seq) as wfsub on wfsub.stageid =  resq.stageid
    order by wfsub.seq`;

      console.log(sql);
      await query(sql).then(data => {
        resolve({ issuccess: true, data, message: 'success' });
      });
    } catch (error) {
      resolve({ issuccess: false, message: error?.message });
    }
  });
};
export const getTATforStage = async (workorderId, stageId) => {
  return new Promise(async resolve => {
    const sql = `select plannedstartdate, plannedenddate from wms_workorder_stage where workorderid = ${workorderId} and wfstageid = ${stageId}`;
    await query(sql).then(data => {
      resolve({ issuccess: true, data, message: 'success' });
    });
  });
};

export const insert_itrackservicecall = async inputdata => {
  // try {
  const {
    url,
    payloaddata,
    headers,
    paramdata,
    iduid,
    icustomerid,
    status,
    failureplace,
    saveaction,
    isproduction,
    iscustomer,
    remarks,
  } = inputdata;
  const jsongpayload = JSON.stringify(payloaddata);
  const jsonheaders = JSON.stringify(headers);
  return new Promise(async resolve => {
    try {
      const sql = `insert into wms_servicecall_entry (url,payloaddata,headers,paramdata, iduid, icustomerid,status,failureplace,saveaction,isproduction,iscustomer,remarks)
                VALUES ('${url}','${jsongpayload}','${jsonheaders}','${paramdata}',
                        ${iduid}, ${icustomerid}, ${status},'${failureplace}','${saveaction}',
                        ${isproduction},${iscustomer},'${remarks}')`;
      await query(sql).then(data => {
        console.log(data);
        // resolve({ issuccess: true,  message: 'success' });
      });
      resolve({ issuccess: true, message: 'success' });
    } catch (error) {
      console.log(error);
      resolve({ issuccess: false, message: 'failed' });
    }
  });
};

export const stageRetrigger = async (req, res) => {
  try {
    console.log(req);
    const sql = `select replace(replace(payloaddata->>'Finishdate','T',' '),'Z',''):: timestamp AS finisheddate, servicecallid,url,payloaddata,headers,paramdata,iduid,icustomerid,status,saveaction,failureplace,
    isproduction,iscustomer,remarks,isretriggered
    from public.wms_servicecall_entry
    where coalesce(isretriggered,false) = false 
    and failureplace in ('addstage')
    order by servicecallid`;

    const getdata = await query(sql);

    if (getdata && getdata.length) {
      for (let index = 0; index < getdata.length; index++) {
        const { servicecallid, url, payloaddata } = getdata[index];
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname: config.iTracks.uri.journal.addStage,
        };
        let result = await service.iPost(url, payloaddata, headers);
        // const { status : rstatus } = result.data;

        if (result) {
          const retriggerstatus = result.status;
          const retriggerremarks = result.Result;

          const upsql = `update public.wms_servicecall_entry set 
          isretriggered = ${retriggerstatus}, retriggerremarks = '${retriggerremarks}', retriggerdate = now()
          where servicecallid = ${servicecallid}`;
          await query(upsql);
        }
      }
    }
  } catch (e) {
    console.log(e);
  } finally {
    res.status(200).send({ status: 'completed' });
  }
};

export const logisticEntryUpdateRetrigger = async (req, res) => {
  try {
    const sql = `select replace(replace(payloaddata->>'Finishdate','T',' '),'Z',''):: timestamp AS finisheddate, servicecallid,url,payloaddata,headers,paramdata,iduid,icustomerid,status,saveaction,failureplace,
                isproduction,iscustomer,remarks,isretriggered
                from public.wms_servicecall_entry
                where coalesce(isretriggered,false) = false 
                and failureplace in ('ProductionDispatch','logisticEntryUpdate','CustomerDispatch')
                order by servicecallid`;
    console.log(req);
    const getdata = await query(sql);

    if (getdata && getdata.length) {
      for (let index = 0; index < getdata.length; index++) {
        const {
          servicecallid,
          url,
          payloaddata,
          headers,
          paramdata,
          iduid,
          icustomerid,
          status,
          saveaction,
          failureplace,
          isproduction,
          iscustomer,
        } = getdata[index];
        console.log(status);
        const retstatus = await retriggerUpdateLogisticeEntry(
          url,
          payloaddata,
          headers,
          paramdata,
          iduid,
          icustomerid,
          isproduction,
          iscustomer,
          saveaction,
          failureplace,
        );

        if (retstatus) {
          const retriggerstatus = retstatus.status;
          const retriggerremarks = retstatus.Result;

          const upsql = `update public.wms_servicecall_entry set 
          isretriggered = ${retriggerstatus}, retriggerremarks = '${retriggerremarks}', retriggerdate = now()
          where servicecallid = ${servicecallid}`;
          await query(upsql);
        }
      }
    }
  } catch (error) {
    console.log(error);
  } finally {
    res.status(200).send({ status: 'completed' });
  }
};

const retriggerUpdateLogisticeEntry = async (
  url,
  payload,
  headers,
  paramdata,
  iduid,
  icustomerid,
  isProduction,
  isCustomer,
  saveaction,
  failureplace,
) => {
  return new Promise(async resolve => {
    try {
      const data = paramdata;
      const iDuId = iduid;
      const iCustomerId = icustomerid;
      const { Finishdate } = payload;
      let result = { status: true, data: { status: true, Result: '' } };
      payload.Finishdate = Finishdate.replace('T', ' ').substring(0, 19);

      if (failureplace == 'logisticEntryUpdate') {
        result = await service.iPost(url, payload, headers);
      }

      const { status } = result.data;

      console.log(status);
      data.isProduction = isProduction;
      data.isCustomer = isCustomer;

      if (status && saveaction == 'save') {
        if (isProduction && isCustomer) {
          const prodDespatch = await retriggerTaskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
            payload,
          );
          if (prodDespatch.status) {
            const custDespatch = await retriggerTaskDespatchJournal(
              { ...data, iDuId, iCustomerId },
              'customer',
              payload,
            );
            resolve(custDespatch);
          } else {
            resolve(prodDespatch);
          }
        } else if (isProduction && !isCustomer) {
          const prodDespatch = await retriggerTaskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
            payload,
          );
          resolve(prodDespatch);
        } else if (!isProduction && isCustomer) {
          const custDespatch = await retriggerTaskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'customer',
            payload,
          );
          resolve(custDespatch);
        } else {
          resolve({ status: false, Result: 'no codition execute' });
        }
      } else {
        resolve(result.data);
      }
    } catch (er) {
      // console.log(er.message);
      resolve({ status: true, Result: er.message });
    }
  });
};

export const retriggerTaskDespatchJournal = async (
  data,
  type,
  parampayload,
) => {
  const { userid, iStageId, quantity, jobId, iDuId, iCustomerId } = data;
  const { Finishdate } = parampayload;
  return new Promise(async resolve => {
    try {
      const url = config.iTracks.base_url;
      const headers = { iendpointkey: config.iTracks.uri.book.iendpointKey };
      let payload = {};
      if (type === 'production') {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          pagecount: quantity || 0,
          Finishdate:
            Finishdate.replace('T', ' ').substring(0, 19) ||
            moment().toISOString(),
          PMEInstruction: 'testing',
        };

        headers.iendpointname = config.iTracks.uri.journal.productionDispatch;
      } else {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          Finishdate:
            Finishdate.replace('T', ' ').substring(0, 19) ||
            moment().toISOString(),
        };

        headers.iendpointname = config.iTracks.uri.journal.customerDispatch;
      }

      const result = await service.iPost(url, payload, headers);

      resolve(result.data);
    } catch (e) {
      resolve({ status: false, Result: e.message });
      // console.log(e)
    }
  });
};

export const oupaddstage = async req => {
  let lstatus = true;
  let remarks = '';
  return new Promise(async resolve => {
    try {
      let { woid, woId } = req;

      woId = woid || woId;

      const sql = `select res."BookCode", row_to_json(res) as payloaddata from
   (
   SELECT
   wo.itemcode AS "BookCode",  
     imst.istageid as "StageId", orgdu.iduid as "DivisionId" , orgcust.icustomerid as "CustomerId",
     to_char(wo.createdon + interval '330 minutes','yyyy-mm-dd hh:mi:ss') as"ReceiveDate"
    , to_char(st.revisedenddatetime,'yyyy-mm-dd hh:mi:ss') as "DueDate", 1 as "MSPage"
   FROM wms_workorder AS wo
   JOIN wms_workorder_stage AS st ON wo.workorderid = st.workorderid and st.revisedenddatetime is not null
   JOIN itracks_mst_stage_map AS ist ON ist.stageid = st.wfstageid AND ist.iterationcount = 1
   JOIN itracks_mst_stage AS imst ON imst.itracksstageid = ist.itracksstageid
   JOIN org_mst_customer_orgmap AS org on org.customerid = wo.customerid and wo.divisionid = org.divisionid  and
     wo.subdivisionid = org.subdivisionid and wo.countryid = org.countryid and org.isactive = 1
   AND ist.iterationcount = 1 AND imst.isactive = 1
   JOIN org_mst_customerorg_du_map as custdu on custdu.custorgmapid = org.custorgmapid
   JOIN org_mst_customer as orgcust on orgcust.customerid = wo.customerid
   JOIN org_mst_deliveryunit as orgdu on custdu.duid= orgdu.duId AND orgdu.isactive=true
   WHERE wo.workorderid = ${woId} AND ist.wfid = 30
   ) as res`;

      const getdata = await query(sql);

      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.addStage,
      };
      if (getdata && getdata.length) {
        for (let index = 0; index < getdata.length; index++) {
          const { payloaddata } = getdata[index];

          let result = await service.iPost(url, payloaddata, headers);

          if (result) {
            remarks = result.data.Result;
            // lstatus= result.data.status;
          }
        }
      }
    } catch (e) {
      // console.log(e);
      lstatus = false;
      remarks = e.message;
    } finally {
      resolve({ status: lstatus, Remarks: remarks });
    }
  });
};
export const checkiTrackNorms = async (info, flowtype) => {
  return new Promise(async resolve => {
    try {
      const {
        activityId,
        customerId,
        duId,
        stageId,
        wfDefId,
        wfId,
        userid,
        workorderId,
        wfeventId,
      } = info;
      // check trigger true or fase
      let script = `SELECT itracksconfig,activitytype FROM public.wms_workflowdefinition
          WHERE wfid = $1 AND stageid = $2 AND activityid = $3`;
      const config1 = await query(script, [wfId, stageId, activityId]);
      if (config1.length && !config1[0].itracksconfig?.isNewiTrackTrigger) {
        resolve({ status: true, message: 'No productivity' });
      }
      // check engine or user activity
      // script =
      //   'select activitytype from public.wms_workflowdefinition where wfdefid=$1';
      // const checkactivity = await query(script, [wfDefId]);
      if (
        config1.length &&
        config1[0].activitytype.toLowerCase() === 'user task'
      ) {
        script = `select new_itrack_intg,itrackduid from public.org_mst_deliveryunit where duid=$1`;
        const itack = await query(script, [duId]);
        // if (itack.length && itack[0].new_itrack_intg) {
        // if (config.length && !config[0].config?.uom_unit) {
        const values = await getProductivityValues(
          duId,
          wfDefId,
          userid,
          workorderId,
          wfId,
          stageId,
          activityId,
          customerId,
          'claim',
          config1,
          itack[0].itrackduid,
          flowtype,
          0,
          wfeventId,
        );
        if (values.issuccess) {
          let sql = `SELECT *
      FROM iproductivity.mst_cust_info c
      LEFT JOIN iproductivity.mst_norms_config mnc ON mnc.custinfoid = c.custinfoid
      WHERE c.duid = $1
        AND c.customerid = $2
        AND c.stageid = $3
        AND mnc.activityid = $4
        AND (mnc.effto - CURRENT_DATE >= 1 OR mnc.effto IS NULL OR mnc.effto = CURRENT_DATE)
        AND mnc.efffrom <= CURRENT_DATE
        AND mnc.isactive = true
        AND c.isactive = true
        AND c.wfid = $5
        AND c.divisionid = $6
        AND c.verticalid = $7
        AND mnc.complexityid = $8
        AND mnc.noofiteration >= 1
        AND mnc.skilllevelid = $9
        AND mnc.uomid = $10
        AND mnc.appid = $11
        order by  mnc.noofiteration desc limit 1;`;
          await query(sql, [
            itack[0].itrackduid,
            customerId,
            stageId,
            activityId,
            wfId,
            values.data.values[0].divisionid,
            values.data.vertical[0].verticalid,
            values.data.complexity[0].complexityid,
            values.data.skill[0].skillelvelid,
            values.data.uom.uomDetails.uomid,
            values.data.values[0].composingsoftwareid,
          ])
            .then(async res => {
              if (res.length) {
                resolve({ status: true, message: 'Norms mapped', data: res });
              } else {
                sql = `SELECT du.duname, v.verticalname, com.complexity, s.stagename, 
                  a.activityname, w.wfname, sk.skilllevel,d.division,ap.softwarename,u.uom 
           FROM public.org_mst_deliveryunit du
           LEFT JOIN public.mst_customer c ON c.customerid = $2
           LEFT JOIN public.wms_mst_stage s ON s.stageid = $3
           LEFT JOIN public.wms_mst_activity a ON a.activityid = $4
           LEFT JOIN public.wms_workflow w ON w.wfid = $5
           left join public.org_mst_division d on d.divisionid=$6
           LEFT JOIN public.wms_mst_vertical v ON v.verticalid = $7
           LEFT JOIN public.wms_mst_complexity com ON com.complexityid = $8
           LEFT JOIN public.wms_mst_skilllevel sk ON sk.skilllevelid = $9
           left join public.wms_mst_uom u on u.uomid=$10
           left join public.pp_mst_composingsoftware ap on ap.softwareid=$11
           WHERE du.duid = $1
           LIMIT 1;`;
                const shownames = await query(sql, [
                  duId,
                  customerId,
                  stageId,
                  activityId,
                  wfId,
                  values.data.values[0].divisionid,
                  values.data.vertical[0].verticalid,
                  values.data.complexity[0].complexityid,
                  values.data.skill[0].skillelvelid,
                  values.data.uom.uomDetails.uomid,
                  values.data.values[0].composingsoftwareid,
                ]);
                resolve({
                  status: false,
                  message: 'Norms not mapped',
                  remarks: `Norms not mapped for the mentioned combination.Du: ${shownames[0]?.duname} |
                  Vertical: ${shownames[0]?.verticalname} | Complexity: ${shownames[0]?.complexity} | Stage: ${shownames[0]?.stagename}
                  | Activity: ${shownames[0]?.activityname} | WorkFlow: ${shownames[0]?.wfname} | SkillLevel: ${shownames[0]?.skilllevel}
                  | Division: ${shownames[0]?.division} | Software: ${shownames[0]?.softwarename} | UOM: ${shownames[0]?.uom}`,
                });
              }
            })
            .catch(() => {
              resolve({ status: true });
            });
        } else {
          resolve({ status: false, remarks: values?.message });
        }
        // } else {
        //   resolve({ status: true, remarks: 'iTrack Integration False' });
        // }
      } else {
        resolve({ status: true, remarks: 'Activity Type is not User Type' });
      }
    } catch (e) {
      resolve(true);
    }
  });
};
export const newItrackLogistic = async (
  iTrackInfo,
  itrackdu,
  flowtype,
  config1,
) => {
  return new Promise(async resolve => {
    try {
      const {
        duId,
        wfdefid,
        userId,
        workorderId,
        wfId,
        stageId,
        activityId,
        customerId,
        jobId,
        subJobId,
        serviceId,
        activityIterationCount,
        uomScore,
        stageIterationCount,
        wfeventId,
        // productivityqty,
      } = iTrackInfo;
      const startTime = await getTaskStartTime(
        iTrackInfo?.wfeventId,
        workorderId,
        stageId,
        activityId,
        subJobId,
        stageIterationCount,
      );
      const res = await getProductivityValues(
        duId,
        wfdefid,
        userId,
        workorderId,
        wfId,
        stageId,
        activityId,
        customerId,
        'save',
        config1,
        itrackdu,
        flowtype,
        uomScore,
        wfeventId,
      );
      if (res?.issuccess) {
        const newItrackLogisticInfo = {
          empcode: userId,
          duid: duId, // inside the function it will take itrack duid
          customerid: customerId,
          bookcode: jobId,
          subjob: subJobId,
          divisionid: res?.data?.values[0]?.divisionid,
          verticalid: res?.data?.vertical[0].verticalid,
          serviceid: serviceId,
          stageid: stageId,
          activityid: activityId,
          skilllevelid: res?.data?.skill[0]?.skillelvelid,
          complexityid: res?.data?.complexity[0]?.complexityid,
          iteration: activityIterationCount,
          appid: res?.data?.values[0]?.composingsoftwareid,
          starttime: startTime?.data[0]?.starttime,
          endtime: new Date(),
          queryraised: false,
          uomid: res?.data?.uom?.uomDetails?.uomid,
          // need to be check with wms
          actual:
            res.data.uom.uomDetails.uomunit.toLowerCase() === 'article' ||
            res.data.uom.uomDetails.uomunit.toLowerCase() === 'titles'
              ? Number(uomScore / 100)
              : res.data.uom.uomDetails.actual,
          createddate: moment().format('YYYY-MM-DD'),
          wfid: wfId,
        };
        const newItrackUpdate = await createManualLogisticService(
          newItrackLogisticInfo,
        );
        if (newItrackUpdate?.status) {
          resolve({ status: true });
        } else {
          resolve({ status: false, params: newItrackUpdate?.params });
        }
        console.log(newItrackLogisticInfo);
      } else {
        resolve({ status: false, error: res?.message, params: iTrackInfo });
      }
    } catch (e) {
      resolve({ status: false, error: e?.message, params: iTrackInfo });
    }
  });
};

export const checkitrackIntegration = async (info, flowtype) => {
  // 1.check itrack integration
  // 2.if track inegration true - > check engine or user activity
  // 3.if user activity-> check trigger is true or false
  // 4.if trigger true-> check norms
  // 5.if norms true -> calculate productivity when the calculation faild -> record it in failure table
  // 6.if trigger false -> no need to calculate but show enter the data in faild data table
  // 7.itrack integration false-> no need to calculate productivity
  // 8.if activity type is engine -> no need to calculate productivity(skip the calucation) proceed next step
  // 9.for productivity WMS customer and itrack DU

  return new Promise(async resolve => {
    try {
      const { duId, wfId, stageId, activityId, workorderId } = info;
      // if (checkitrack.length && checkitrack[0].new_itrack_intg) {
      // check trigger true or fase
      let script = `SELECT itracksconfig,activitytype FROM public.wms_workflowdefinition
                WHERE wfid = $1 AND stageid = $2 AND activityid = $3`;
      const config1 = await query(script, [wfId, stageId, activityId]);
      if (
        config1.length &&
        config1[0].activitytype.toLowerCase() === 'user task'
      ) {
        // trigger
        if (config1.length && config1[0].itracksconfig?.isNewiTrackTrigger) {
          script = `select new_itrack_intg,itrackduid from public.org_mst_deliveryunit where duid=$1`;
          const [itrack] = (await query(script, [duId])) || [];
          const itrackdu = itrack?.itrackduid || null;

          const result = await newItrackLogistic(
            info,
            itrackdu,
            flowtype,
            config1,
          );
          if (result?.status) {
            resolve({ status: true });
          } else {
            await recordFailureCase(
              workorderId,
              stageId,
              activityId,
              result?.params,
              result?.error,
            );
            resolve({ status: false, error: result?.error });
          }
        } else {
          resolve({ status: true, message: 'Productivity trigger false' });
        }
      } else {
        resolve({ status: true });
      }
      // } else {
      //   resolve({ status: true });
      // }
    } catch (e) {
      resolve({ status: false, error: e });
    }
  });
};

export const recordFailureCase = async (
  woId,
  stageId,
  activityId,
  desc,
  remark,
) => {
  return new Promise(async resolve => {
    try {
      const sql = `INSERT INTO iproductivity.trn_ProductivityEntryFailure (workorderid,stageid,activityid,description,remarks)
      VALUES ($1,$2,$3,$4,$5);`;
      await query(sql, [woId, stageId, activityId, desc, remark]).then(data => {
        resolve({ issuccess: true, data, message: 'success' });
      });
    } catch (error) {
      resolve({ issuccess: false, message: error?.message });
    }
  });
};

// 1.get start time from eventlog details table

export const getTaskStartTime = async (
  wfeventId,
  workorderId,
  stageId,
  activityId,
  subJobId,
  stageitertion,
) => {
  return new Promise(async resolve => {
    try {
      let wotypeQuery = `	select * from public.wms_workorder where workorderid=$1`;
      let wotype = await query(wotypeQuery, [workorderId]);
      if (wotype.length && wotype[0]?.flowtype === 'nonwms') {
        // COALESCE(TO_CHAR(starttime + INTERVAL '330 minutes', 'YYYY-MM-DD HH24:mi'), '-') AS starttime
        const sql = `select starttime,endtime from subjob_eventlog_details where workorderid = $1 and 
        stageid = $2 and 
        activityid = $3 and stageiterationcount = $5 and 
        lower(subjobname) = lower($4);`;
        await query(sql, [
          workorderId,
          stageId,
          activityId,
          subJobId,
          stageitertion,
        ]).then(data => {
          resolve({ issuccess: true, data, message: 'success' });
        });
      } else {
        const sql = `SELECT timestamp as starttime FROM public.wms_workflow_eventlog_details 
        WHERE wfeventid = $1 AND operationtype = 'Claimed' ORDER BY timestamp DESC LIMIT 1;`;
        await query(sql, [wfeventId]).then(data => {
          resolve({ issuccess: true, data, message: 'success' });
        });
      }
    } catch (error) {
      resolve({ issuccess: false, message: error.message });
    }
  });
};

export const getProductivityValues = async (
  duId,
  wfDefId,
  userid,
  workorderId,
  wfId,
  StageId,
  activityId,
  customerId,
  type,
  config1,
  itrackdu,
  flowtype,
  quantity,
  wfeventId,
) => {
  return new Promise(async resolve => {
    try {
      // Query Definitions
      const queries = {
        skill: `
          SELECT usk.skillelvelid 
          FROM public.wms_workflowdefinition wfd
          LEFT JOIN public.wms_userskill usk ON usk.skillid = wfd.skillid
          WHERE wfdefid=$2 AND usk.userid=$1 AND usk.isactive = true LIMIT 1
        `,
        workOrder: `
          SELECT subdivisionid, complexityid, divisionid, composingsoftwareid 
          FROM public.wms_workorder 
          WHERE workorderid=$1
        `,
        vertical: `
          SELECT iv.verticalid 
          FROM public.org_mst_subdivision sd
          LEFT JOIN public.wms_mst_vertical iv ON iv.verticalid = sd.itrack_vertical_id
          WHERE sd.isactive=true AND iv.isactive = true AND sd.subdivisionid=$1
        `,
        complexity: `
        select complexityid from iproductivity.job_norms_map_details where customerid =$1 and duid =$2 and stageid =$3 and activityid =$4
        and workorderid = $5 and isactive = true
        `,
      };

      // Fetch Data
      const skill = await query(queries.skill, [userid, wfDefId]);
      const values = await query(queries.workOrder, [workorderId]);
      const vertical = values.length
        ? await query(queries.vertical, [values[0]?.subdivisionid])
        : [];
      const complexity = skill.length
        ? await query(queries.complexity, [
            customerId,
            duId,
            StageId,
            activityId,
            workorderId,
          ])
        : [];
      // Validation
      const isValid =
        itrackdu != null &&
        skill.length &&
        skill[0]?.skillelvelid != null &&
        values.length &&
        values[0]?.composingsoftwareid != null &&
        complexity.length &&
        complexity[0]?.complexityid != null &&
        vertical.length &&
        vertical[0]?.verticalid != null;

      if (isValid) {
        const uom =
          flowtype === 'wms'
            ? await getUOMQuantity(
                itrackdu,
                customerId,
                workorderId,
                type,
                config1,
                quantity,
                wfeventId,
              )
            : await getiTracksUOMQuantity(
                itrackdu,
                customerId,
                workorderId,
                type,
                config1,
                quantity,
              );

        if (uom?.issuccess) {
          resolve({
            issuccess: true,
            data: {
              skill,
              values,
              itrackdu,
              config: config1,
              uom,
              vertical,
              complexity,
            },
          });
        } else {
          resolve({ issuccess: false, message: uom?.message });
        }
      } else {
        // Error Handling
        const errors = {
          itrackdu: 'The iTrack DU ID is not mapped.',
          skill: 'Skill level details are not found.',
          complexity: 'Complexity is not mapped in the Job Norms.',
          software: 'Software ID is null.',
          vertical: 'Vertical ID is null.',
          default:
            'Productivity data is missing the following information: Skill, DU, Software, or Vertical.',
        };

        const errorMessage =
          itrackdu === null
            ? errors.itrackdu
            : skill.length && skill[0]?.skillelvelid === null
            ? errors.skill
            : complexity.length == 0
            ? errors.complexity
            : values.length && values[0]?.composingsoftwareid === null
            ? errors.software
            : vertical.length || vertical[0]?.verticalid === null
            ? errors.vertical
            : errors.default;

        resolve({ issuccess: false, message: errorMessage });
      }
    } catch (error) {
      resolve({ issuccess: false, message: error?.message });
    }
  });
};

// export const getUOMQuantity = async (
//   itrackduid,
//   customerId,
//   workorderId,
//   type,
//   config1,
//   _noOfPages,
// ) => {
//   return new Promise(async resolve => {
//     try {
//       let uomDetails = {};
//       // get iTrack customer id
//       const sql = `select itrack_customerid from public.org_mst_customer where customerid=$1`;
//       const itrack = await query(sql, [customerId]);

//       if (itrack.length && itrack[0]?.itrack_customerid != null) {
//         // Fetch workflow definition config
//         // const script2 = `SELECT itracksconfig FROM public.wms_workflowdefinition WHERE wfid = $1 AND stageid = $2 AND activityid = $3`;
//         // const configRes = await query(script2, [wfId, StageId, activityId]);

//         if (!config1[0]?.itracksconfig?.uom_unit) {
//           resolve({
//             issuccess: false,
//             message:
//               'UOM unit details are not found in the iTrack configuration.',
//           });
//         }
//         // Get uom id
//         const script3 = `select uomid from public.wms_mst_uom where Lower(uom) = LOWER($1)`;
//         const uom = await query(script3, [config1[0]?.itracksconfig?.uom_unit]);

//         uomDetails.uomid = uom.length ? uom[0].uomid : 0;
//         const uomUnit = config1[0]?.itracksconfig?.uom_unit.toLowerCase();
//         uomDetails.uomunit = uomUnit;
//         if (type === 'save' && uomUnit != 'article' && uomUnit != 'titles') {
//           let resultstd = [];
//           if (uomUnit === 'std. pages') {
//             // Fetch wordcount_per_page
//             const script1 = `SELECT wordcount_per_page FROM public.mst_standardpage_measure WHERE customerid = $1 AND duid = $2`;
//             resultstd = await query(script1, [
//               itrack[0].itrack_customerid,
//               itrackduid,
//             ]);

//             if (resultstd.length === 0) {
//               resolve({
//                 issuccess: false,
//                 message:
//                   'No wordcount per page found in mst_standardpage_measure',
//               });
//             }
//           }

//           // let column = '';
//           // if (uomUnit === 'std. pages' || uomUnit === 'word count') {
//           //   column = 'wordcount';
//           // } else if (uomUnit === 'ms pages') {
//           //   column = 'mspages';
//           // } else if (uomUnit === 'images' || uomUnit === 'cover') {
//           //   column = 'imagecount';
//           // } else if (
//           //   uomUnit === 'pdf pages' ||
//           //   uomUnit === 'no. of pages' ||
//           //   uomUnit === 'ts pages'
//           // ) {
//           //   column = 'estimatedpages';
//           // }
//           // if (column != '') {
//           // column = uomUnit === 'std. pages' ? 'wordcount' : 'imagecount';
//           // const script4 = `SELECT wid.${column} FROM public.wms_workorder_incoming wi
//           //              LEFT JOIN public.wms_workorder_incomingfiledetails wid ON wi.woincomingid = wid.woincomingid
//           //              WHERE wi.woid = $1`;
//           // const incoming = await query(script4, [workorderId]);
//           // if (incoming.length && incoming[0]?.[column] != null) {
//           uomDetails.actual =
//             uomUnit === 'std. pages' && Number(_noOfPages) != 0
//               ? Math.round(
//                   Number(_noOfPages) / Number(resultstd[0]?.wordcount_per_page),
//                 )
//               : Number(_noOfPages);
//           // } else {
//           //   resolve({
//           //     issuccess: false,
//           //     message: `${column} is null in incoming details`,
//           //   });
//           // }
//           // } else {
//           //   resolve({ issuccess: false, message: 'UOM Unit not match' });
//           // }
//         }
//         resolve({ issuccess: true, uomDetails });
//       } else {
//         resolve({
//           issuccess: false,
//           message: 'iTrack customer ID is not mapped',
//         });
//       }
//     } catch (error) {
//       resolve({ issuccess: false, message: error.message });
//     }
//   });
// };

export const getiTracksUOMQuantity = async (
  itrackduid,
  customerId,
  workorderId,
  type,
  config1,
  quantity,
) => {
  return new Promise(async resolve => {
    try {
      let uomDetails = {};
      if (!config1[0]?.itracksconfig?.uom_unit) {
        resolve({
          issuccess: false,
          message:
            'UOM unit details are not found in the iTrack configuration.',
        });
      }
      // get iTrack customer id
      const sql = `select itrack_customerid from public.org_mst_customer where customerid=$1`;
      const itrack = await query(sql, [customerId]);

      if (itrack.length && itrack[0]?.itrack_customerid != null) {
        const script3 = `select uomid from public.wms_mst_uom where Lower(uom) = LOWER($1)`;
        const uom = await query(script3, [config1[0]?.itracksconfig?.uom_unit]);
        // uom id is for check the combination
        uomDetails.uomid = uom.length ? uom[0].uomid : 0;
        const uomUnit = config1[0]?.itracksconfig?.uom_unit.toLowerCase();
        uomDetails.uomunit = uomUnit;
        if (uomUnit != 'article' && uomUnit != 'titles') {
          let stpageresult = [];
          // Fetch wordcount_per_page for std. pages
          if (uomUnit === 'std. pages') {
            const script1 = `SELECT wordcount_per_page FROM public.mst_standardpage_measure WHERE customerid = $1 AND duid = $2`;
            stpageresult = await query(script1, [
              itrack[0].itrack_customerid,
              itrackduid,
            ]);
            if (stpageresult.length === 0) {
              resolve({
                issuccess: false,
                message:
                  'No wordcount per page found in mst_standardpage_measure',
              });
            }
          }
          if (type === 'save') {
            uomDetails.actual =
              uomUnit === 'std. pages'
                ? Math.round(
                    Number(quantity) /
                      Number(stpageresult[0]?.wordcount_per_page),
                  )
                : Number(quantity);
          }
        }
        resolve({ issuccess: true, uomDetails });
      } else {
        resolve({
          issuccess: false,
          message: 'iTrack customer ID is not mapped',
        });
      }
    } catch (error) {
      resolve({ issuccess: false, message: error.message });
    }
  });
};

export const getUOMQuantity = async (
  itrackduid,
  customerId,
  workorderId,
  type,
  config1,
  quantity,
  wfeventId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const uomDetails = {};
      const uomUnit = config1?.[0]?.itracksconfig?.uom_unit?.toLowerCase();

      if (!uomUnit) {
        resolve({
          issuccess: false,
          message:
            'UOM unit details are not found in the iTrack configuration.',
        });
      }

      // Get iTrack customer ID
      const sql = `SELECT itrack_customerid FROM public.org_mst_customer WHERE customerid = $1`;
      const itrack = await query(sql, [customerId]);

      if (!(itrack.length && itrack[0]?.itrack_customerid)) {
        resolve({
          issuccess: false,
          message: 'iTrack customer ID is not mapped',
        });
      }

      const itrackCustomerId = itrack[0].itrack_customerid;

      // Get UOM ID
      const script3 = `SELECT uomid FROM public.wms_mst_uom WHERE LOWER(uom) = LOWER($1)`;
      const uom = await query(script3, [uomUnit]);
      uomDetails.uomid = uom.length ? uom[0].uomid : 0;
      uomDetails.uomunit = uomUnit;

      let wordcountPerPage = null;

      if (uomUnit === 'std. pages') {
        const wordCountScript = `SELECT wordcount_per_page FROM public.mst_standardpage_measure WHERE customerid = $1 AND duid = $2`;
        const stpageresult = await query(wordCountScript, [
          itrackCustomerId,
          itrackduid,
        ]);
        if (stpageresult.length === 0) {
          resolve({
            issuccess: false,
            message: 'No wordcount per page found in mst_standardpage_measure',
          });
        }
        wordcountPerPage = Number(stpageresult[0]?.wordcount_per_page);
      }

      // For "save" operation, calculate actual quantity
      if (type === 'save') {
        uomDetails.actual = Number(quantity);
      } else if (type === 'claim') {
        // --- Additional logic from insertProductivityremQtyService ---
        let column = '';
        if (['std. pages', 'word count'].includes(uomUnit)) {
          column = 'wordcount';
        } else if (uomUnit === 'ms pages') {
          column = 'mspages';
        } else if (['images', 'cover'].includes(uomUnit)) {
          column = 'imagecount';
        } else if (
          ['pdf pages', 'no. of pages', 'ts pages'].includes(uomUnit)
        ) {
          column = 'estimatedpages';
        }

        let result = [];
        if (column) {
          const dataQuery = `
          SELECT wid.${column} FROM public.wms_workorder_incoming wi
          LEFT JOIN public.wms_workorder_incomingfiledetails wid ON wi.woincomingid = wid.woincomingid
          WHERE wi.woid = $1`;
          result = await query(dataQuery, [workorderId]);
        }

        const valueuom =
          result.length && result[0][column] != null
            ? uomUnit === 'std. pages'
              ? Number(result[0][column]) / wordcountPerPage
              : Number(result[0][column])
            : 0;

        // Check for NULL in remaininguomcount
        const isnullquery = `
        SELECT COUNT(*) > 0 AS is_null
        FROM public.wms_workflow_eventlog
        WHERE wfeventid = $1 AND remaininguomcount IS NULL`;
        const isnull = await query(isnullquery, [wfeventId]);

        if (isnull.length && isnull[0]?.is_null) {
          await updateRemainingQty(wfeventId, valueuom, valueuom);
        }
      }
      // Final return
      resolve({
        issuccess: true,
        uomDetails,
        message: 'UOM quantity processed successfully.',
      });
    } catch (error) {
      reject({
        issuccess: false,
        message: error.message,
      });
    }
  });
};
