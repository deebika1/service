import { query } from '../../../database/postgres.js';

export const trackitTrigger = (req, res) => {
  let sql = '';
  sql = `SELECT  COUNT(*) FROM public.wms_trackit_api_audit as trackitapi
        left JOIN wms_mst_service as service ON service.serviceid = trackitapi.serviceid
        left JOIN wms_mst_stage as stage ON stage.stageid = trackitapi.stageid`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT trackitapi.trackitapiid,trackitapi.apiaction , trackitapi.workorderid,
            trackitapi.serviceid,trackitapi.stageid,trackitapi.payload,trackitapi.timestamp,trackitapi.status,
            service.servicename ,stage.stagename 
            FROM public.wms_trackit_api_audit as trackitapi
            left JOIN wms_mst_service as service ON service.serviceid = trackitapi.serviceid
            left JOIN wms_mst_stage as stage ON stage.stageid = trackitapi.stageid 
            ORDER BY trackitapi.trackitapiid ASC`;
        console.log(sqlQuery, 'trackitapi');
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
