import { query } from '../../../database/postgres.js';

export const emailTrigger = (req, res) => {
  let sql = '';
  sql = `SELECT count(*) FROM public.wms_email_audit as email
            left join wms_email_audit_history as audithistory  on audithistory.emailauditid = email.emailauditid
            left JOIN wms_mst_service as service ON service.serviceid = email.serviceid
            left JOIN wms_mst_stage as stage ON stage.stageid = email.stageid
            left join wms_workflowdefinition as workflow on workflow.wfdefid = email.wfdefid
            left JOIN wms_mst_activity as activity ON activity.activityid = workflow.activityid`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        sql = `SELECT email.emailauditid,email.workorderid , email.serviceid, email.wfdefid,email.stageid, email.timestamp, 
                    email.status,service.servicename as service, 
                    stage.stagename as stage,workflow.activityid,activity.activityname as activity,type
                    FROM public.wms_email_audit as email
                    left join (select emailauditid,mailtype as type from public.wms_email_audit_history) as audithistory  on audithistory.emailauditid = email.emailauditid
                    left JOIN wms_mst_service as service ON service.serviceid = email.serviceid
                    left JOIN wms_mst_stage as stage ON stage.stageid = email.stageid
                    left join wms_workflowdefinition as workflow on workflow.wfdefid = email.wfdefid
                    left JOIN wms_mst_activity as activity ON activity.activityid = workflow.activityid 
                    ORDER BY email.emailauditid ASC`;

        console.log(sql, 'sqlforquerryy');
        query(sql)
          .then(data => {
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
