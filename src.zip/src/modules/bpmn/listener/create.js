import { query } from '../../../database/postgres.js';
import { createEventLog } from './updatedb.js';
import {
  queryWOStageChapters,
  getStageCompletionStatus,
} from '../../woi/stage.js';
import { triggerBatchCompletion } from '../../utils/wfTrigger/index.js';
import { GetAllMsgInTaskQueue, sendToTaskQueue } from '../../../mq/index.js';
import { config } from '../../../config/restApi.js';
import { getFolderStructure } from '../../utils/wmsFolder/index.js';
import {
  okmFolderCopy,
  azureFolderCopy,
  localFolderCopy,
} from '../../utils/tools/io.js';
import { Service } from '../../../httpClient/index.js';
import { ReStructureFileConfig } from '../../utils/fileValidation/validate.js';

const categories = {
  chapter: 'Chapterwise',
  book: 'Bookwise',
  article: 'Articlewise',
  issue: 'Issuewise',
};

export const getLatestWorkedActivityDetails = async (req, res) => {
  const { workOrderId, fileMovementConfig } = req.body;
  try {
    let wfdefids = fileMovementConfig
      .map(x => x.filesrcactivity)
      .filter(x => x != undefined);
    // eslint-disable-next-line prefer-const
    let finalResult = [];
    if (wfdefids.length > 0) {
      wfdefids = wfdefids.join(',');
      // const sql = `SELECT distinct( wfdefid ) FROM public.wms_workflow_eventlog where  workorderid = ${workOrderId} and wfdefid in
      //   (${wfdefids})`;
      const sql = `with cte as (
        SELECT  wfdefid,wfeventdetailid,
        ROW_NUMBER() OVER (partition by wfdefid ORDER BY wfeventdetailid desc) AS row_num
        FROM public.wms_workflow_eventlog 
        join public.wms_workflow_eventlog_details 
        on public.wms_workflow_eventlog.wfeventid = public.wms_workflow_eventlog_details.wfeventid 
        where public.wms_workflow_eventlog.workorderid = ${workOrderId} 
        and public.wms_workflow_eventlog.wfdefid in (${wfdefids})
        order by wfeventdetailid desc
        )select wfdefid from cte where row_num =1`;
      let data = await query(sql);
      data = data.map(x => x.wfdefid);
      // to be deleted
      // fileMovementConfig.forEach(x => {
      //   if (data.includes(x.filesrcactivity) || x.filesrcactivity == undefined)
      //     finalResult.push(x);
      //   testingArry.push(x);
      // });

      data.forEach(y => {
        fileMovementConfig.forEach(x => {
          if (y == x.filesrcactivity) {
            finalResult.push(x);
          }
        });
      });
    }

    fileMovementConfig.forEach(x => {
      const validCheck =
        x.filesrcactivity == '' ||
        x.filesrcactivity == null ||
        x.filesrcactivity == 'null' ||
        x.filesrcactivity == undefined ||
        x.filesrcactivity == 'undefined';
      if (validCheck) {
        finalResult.push(x);
      }
    });

    // let out = [];
    // finalResult.forEach(x => {
    //     if (out.filter(y => (y.destination == x.destination && y.source == x.source && y.srcfiletypeid == x.srcfiletypeid && y.destfiletypeid == x.destfiletypeid)).length == 0) {
    //         out.push(x)
    //     }
    // }
    // );
    res.status(200).json(finalResult);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getLatestActivityDetails = async (req, res) => {
  const {
    workOrderId,
    service,
    stageIterationCount,
    wfdefId,
    fileId,
    isCurrentIteration,
  } = req.body;
  console.log(isCurrentIteration, 'HEEE');

  const iterationCondition = isCurrentIteration
    ? `stageiterationcount='${stageIterationCount}'`
    : `stageiterationcount is not null`;

  let sql = `SELECT eventlog.wfeventid, eventlog.wfdefid, wms_mst_stage.stageid, wms_mst_stage.stagename, wms_mst_activity.activityid, wms_mst_activity.activityname, eventlog.stageiterationcount, eventlog.activityiterationcount FROM public.wms_workflow_eventlog as eventlog
    JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = eventlog.wfdefid
    JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
    JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
    where eventlog.wfeventid= (SELECT eventlog.wfeventid FROM public.wms_workflow_eventlog as eventlog
        where workorderid = $1 and serviceid = $2 and wfdefid= $3 and activitystatus != $4 and ${
          fileId ? `woincomingfileid='${fileId}'` : `woincomingfileid is null`
        }  and ${iterationCondition}
        ORDER BY wfeventid desc limit 1)`;
  console.log(sql, isCurrentIteration, stageIterationCount, 'SINDHU');
  try {
    const latestActivityDetails = {
      stage: { name: '', id: '', iteration: '' },
      activity: { name: '', id: '', iteration: '' },
      isActivityFound: false,
      files: [],
    };
    const eventlog = await query(sql, [
      workOrderId,
      service.id,
      wfdefId,
      'Inprocess',
    ]);
    if (eventlog.length) {
      latestActivityDetails.stage.name = eventlog[0].stagename;
      latestActivityDetails.stage.id = eventlog[0].stageid;
      latestActivityDetails.stage.iteration = eventlog[0].stageiterationcount;
      latestActivityDetails.activity.name = eventlog[0].activityname;
      latestActivityDetails.activity.id = eventlog[0].activityid;
      latestActivityDetails.activity.iteration =
        eventlog[0].activityiterationcount;
      latestActivityDetails.isActivityFound = true;
      sql = `SELECT wms_workflowactivitytrn_file_map.repofilepath as path, 
            wms_workflowactivitytrn_file_map.repofileuuid as uuid,
            wms_workflowactivitytrn_file_map.woincomingfileid as fileid,
            wms_workorder_incomingfiledetails.filetypeid,
            wms_workorder_incomingfiledetails.filename,
            wms_workorder_incomingfiledetails.newfilename,
            pp_mst_filetype.filetype,
            pp_mst_filetype.allowsubfiletype
            FROM public.wms_workflowactivitytrn_file_map 
            left join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
            left join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
            where wfeventid = $1`;
      const latestActivityFiles = await query(sql, [eventlog[0].wfeventid]);
      latestActivityDetails.files = latestActivityFiles;
    }
    res.status(200).json(latestActivityDetails);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const RepushtheJobtoMQ = async () => {
  try {
    const QueueMsgs = await GetAllMsgInTaskQueue();
    if (QueueMsgs.status == true) {
      const sqlQuery = `select * from getrepushdata()`;
      const fileDetails = await query(sqlQuery);
      const ActualQueueMsg = [];
      QueueMsgs.message.forEach(ele => {
        try {
          ActualQueueMsg.push(JSON.parse(ele));
        } catch (err) {
          //
        }
      });
      for (let index = 0; index < fileDetails.length; index++) {
        const element = fileDetails[index];
        const sql = `select * from public.deleteeventid(${element.wfeventid})`;
        await query(sql);
        if (
          ActualQueueMsg.filter(
            x => x.processInstanceId == element.eventdata.processInstanceId,
          ).length == 0
        ) {
          await sendToTaskQueue(element.eventdata);
        }
      }
    }
  } catch (e) {
    console.log(e);
  }
};

export const runWipRefresh = async () => {
  try {
    const res = await query('SELECT public.wip_refresh();');
    console.log('wip_refresh executed:', res);
  } catch (err) {
    console.error('Error executing wip_refresh:', err.stack);
  }
};

// Function to log cron job status to the database
export const logJobStatus = async (jobName, status, message = '') => {
  const sql = `
    INSERT INTO cron_job_logs (job_name, status, message)
    VALUES ($1, $2, $3)
  `;
  const values = [jobName, status, message];

  try {
    await query(sql, values);
    console.log(`Logged ${jobName} status: ${status}`);
  } catch (err) {
    console.error('Error logging cron job status:', err);
  }
};

export const updateOtherfieldForWorkorder = async (req, res) => {
  const { workOrderId, zipFileName } = req.body;
  // const sql = `UPDATE wms_workorder
  // SET otherfield = CASE WHEN otherfield is null THEN
  //              '{"BookZipFileName": "${zipFileName}"}'::jsonb
  //          ELSE
  //              jsonb_set(otherfield::jsonb, '{BookZipFileName}', '"${zipFileName}"', true)
  //      END
  // WHERE workorderid = ${workOrderId}`;
  // console.log('sql', sql);
  let sql = `select inco.woincomingfileid from wms_workorder_incoming  as wo
  join  wms_workorder_incomingfiledetails as inco on inco.woincomingid = wo.woincomingid
  where wo.woid= ${workOrderId}`;
  const data = await query(sql);
  const incomingId = data.length > 0 ? data[0].woincomingfileid : null;
  sql = `UPDATE public.wms_workorder_incomingfiledetails
    SET newfilename='${zipFileName}'
    WHERE woincomingfileid=${incomingId};`;
  try {
    const fileDetails = await query(sql);
    res.status(200).json(fileDetails);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getIncomingFileDetails = async (req, res) => {
  const { workOrderId } = req.body;
  const sql = `SELECT wms_workorder_incoming.woid, wms_workorder_incomingfiledetails.newfilename, wms_workorder_incomingfiledetails.woincomingfileid as fileid, wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.filetypeid,wms_workorder_incomingfiledetails.subfiletypeid, pp_mst_filetype.filetype, pp_mst_filetype.allowsubfiletype,pp_mst_filetype.articletype
    FROM public.wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
    where woid = $1`;
  try {
    const fileDetails = await query(sql, [workOrderId]);
    res.status(200).json(fileDetails);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getFileNameForPii = async (req, res) => {
  try {
    const { workorderId, filename } = req.body;
    // const sql = `select woincomingfileid,filename,piinumber,* from wms_workorder_incoming as incoming
    // join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
    // where incoming.woid = ${workorderId} and filename like '%${filename}%'`;
    // const result = await query(sql, []);
    const result = await _getFileNameForPii(workorderId, filename);
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const _getFileNameForPii = async (workorderId, filename) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select woincomingfileid,filename,piinumber,* from wms_workorder_incoming as incoming
      join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
      where incoming.woid = ${workorderId} and filename like '%${filename}%'`;
      const result = await query(sql, []);
      resolve(result);
    } catch (e) {
      reject(e);
    }
  });
};

export const getIncomingFileDetailsWithfiletype = async (woId, filetypeId) => {
  const sql = `SELECT wms_workorder_incoming.woid, wms_workorder_incomingfiledetails.newfilename, wms_workorder_incomingfiledetails.woincomingfileid as fileid, wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.filetypeid, pp_mst_filetype.filetype, pp_mst_filetype.allowsubfiletype
    FROM public.wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
    where woid = $1 and wms_workorder_incomingfiledetails.filetypeid=$2`;
  // eslint-disable-next-line no-useless-catch
  try {
    const fileDetails = await query(sql, [woId, filetypeId]);
    return fileDetails;
  } catch (e) {
    throw e;
  }
};

export const getWfDetails = async (req, res) => {
  const { workOrderId, serviceId, stageId, activityId, stageIteration } =
    req.body;
  const sql = `SELECT * FROM public.wms_workflow_details
    where workorderid = $1 and serviceid = $2 and stageid = $3 and activityid = $4 and stageiterationcount = $5`;
  try {
    const wfDetails = await query(sql, [
      workOrderId,
      serviceId,
      stageId,
      activityId,
      stageIteration,
    ]);
    wfDetails.forEach(item => {
      item.fileconfig = ReStructureFileConfig(item.fileconfig);
    });
    res.status(200).json(wfDetails);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getWoEventLogDetails = async (req, res) => {
  const { workOrderId, fileId, serviceId, stage, category } = req.body;
  const isBook = category == categories.book || category == categories.issue;
  const sql = `SELECT wms_workflow_eventlog.*, wms_workflowdefinition.stageid, wms_workflowdefinition.activityid FROM public.wms_workflow_eventlog
    join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
    where activitystatus <> 'Unassigned' and workorderid = $1 and stageid = $2 and stageiterationcount = $3 and serviceid= $4 and activitystatus not in ('Inprocess','Error') ${
      isBook
        ? fileId
          ? `and (woincomingfileid = ${fileId} or woincomingfileid is null)`
          : ''
        : `and woincomingfileid = ${fileId}`
    } 
    order by wfeventid desc`;
  try {
    const eventLogsData = await query(sql, [
      workOrderId,
      stage.id,
      stage.iteration,
      serviceId,
    ]);
    res.status(200).json(eventLogsData);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getPreviousEventLogDetail = async (req, res) => {
  const { workOrderId, fileId, serviceId, incomingFlows, category } = req.body;
  const isBook = category == categories.book || category == categories.issue;
  const sql = `SELECT wms_workflow_eventlog.*, wms_workflowdefinition.stageid, wms_workflowdefinition.activityid FROM public.wms_workflow_eventlog
    join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
    join wms_workflow_eventlog_details on wms_workflow_eventlog_details.wfeventid=wms_workflow_eventlog.wfeventid
    where workorderid = $1 and serviceid = $2 and wms_workflow_eventlog.wfdefid = any($3) and (activitystatus = $4 or activitystatus = $5 or activitystatus = $6 or activitystatus = $7 ) ${
      isBook
        ? fileId
          ? `and (woincomingfileid = ${fileId} or woincomingfileid is null)`
          : ''
        : `and woincomingfileid = ${fileId}`
    }
     order by wms_workflow_eventlog_details.wfeventdetailid desc limit 1`;
  try {
    const previousData = await query(sql, [
      workOrderId,
      serviceId,
      incomingFlows,
      'Completed',
      'Rejected',
      'Failed',
      'Reset',
    ]);
    res.status(200).json(previousData);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getFileMovementConfig = async (req, res) => {
  const { flowTo, customerId, workOrderId, wfId } = req.body;

  const sql1 = `select dmsid from wms_workorder where workorderid = $1`;
  const sql2 = `select localserverpath from wms_mst_customerconfigdetails where customerid = $1`;
  const dmsid = await query(sql1, [workOrderId]);
  const basepath = await query(sql2, [customerId]);

  if (customerId == '1') {
    const sql = `SELECT fmc.fmconfigid, fmc.flowfrom, fmc.flowto, fmc.source, fmc.destination,
          fmc.filesrcactivity, fmc.isincomingsrc, fmc.commonfolderpath,
          srcwfdef.instancetype as instancetype_source,
              fmc.filepriority,srcfiletype.filetype as srcfiletype,
              srcfiletype.filetypeid as srcfiletypeid, srcfiletype.allowsubfiletype as srcallowsubfiletype,
              destfiletype.filetype as destfiletype,
              destfiletype.filetypeid as destfiletypeid,
              destfiletype.allowsubfiletype as destallowsubfiletype,
              fmc.istemplatesrc,fmc.iscurrentiteration
                  FROM public.wms_filemovementconfig as fmc
                  left join pp_mst_filetype as srcfiletype on srcfiletype.filetypeid = fmc.srcfiletypeid
                  left join pp_mst_filetype as destfiletype on destfiletype.filetypeid = fmc.destfiletypeid
                  left join wms_workflowdefinition as srcwfdef on srcwfdef.wfdefid = fmc.filesrcactivity
                  WHERE  flowto = $1  
                 and case when fmc.iscurrentiteration = 'false' then fmc.filesrcactivity in (
                 SELECT wfdefid FROM public.wms_previousstage
          where workorderid=$2 and wfid = $3  order by sequence desc limit 1
                  ) else CAST (fmc.filesrcactivity AS text) not in (select array_to_string("prevComplTr",',') from wms_prev_stage_creationconfig where flowtype = $1 and prevtriggerfrom 
                    in (SELECT wfdefid FROM public.wms_previousstage
          where workorderid=$2 and wfid = $3  order by sequence desc limit 1)) end  
              and flowto = $1 ORDER BY filepriority ASC, fmconfigid ASC `;
    try {
      const fileMovementConfig = await query(sql, [flowTo, workOrderId, wfId]);
      res.status(200).json({ fileMovementConfig, dmsid, basepath });
    } catch (e) {
      res.status(400).send(e.message ? e.message : e);
    }
  } else {
    const sql = `SELECT fmc.fmconfigid, fmc.flowfrom, fmc.flowto, fmc.source, fmc.destination, fmc.filesrcactivity, fmc.isincomingsrc, fmc.commonfolderpath, srcwfdef.instancetype as instancetype_source, 
    fmc.filepriority,srcfiletype.filetype as srcfiletype, srcfiletype.filetypeid as srcfiletypeid, srcfiletype.allowsubfiletype as srcallowsubfiletype,
    destfiletype.filetype as destfiletype, destfiletype.filetypeid as destfiletypeid, destfiletype.allowsubfiletype as destallowsubfiletype,fmc.istemplatesrc,fmc.iscurrentiteration
        FROM public.wms_filemovementconfig as fmc
        left join pp_mst_filetype as srcfiletype on srcfiletype.filetypeid = fmc.srcfiletypeid
        left join pp_mst_filetype as destfiletype on destfiletype.filetypeid = fmc.destfiletypeid
        left join wms_workflowdefinition as srcwfdef on srcwfdef.wfdefid = fmc.filesrcactivity
    where flowto = $1 ORDER BY filepriority ASC, fmconfigid ASC  `;

    try {
      const fileMovementConfig = await query(sql, [flowTo]);

      res.status(200).json({ fileMovementConfig, dmsid, basepath });
    } catch (e) {
      res.status(400).send(e.message ? e.message : e);
    }
  }
};
export const getBookDetails = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const result = await bookDetails(workOrderId);
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
export const getBookDetailsForCupJournals = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const result = await getBookDetailsTemplateForCupJournals(workOrderId);
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

// generate BookDetails.xml for WKH Issue
export const getBookDetailsForWKHIssueAPI = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const result = await getBookDetailsForWKHIssue(workOrderId);
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getBookDetailsForOupJournals = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const result = await getBookDetailsTemplateForOupJournals(workOrderId);
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const bookDetails = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select
        wo.title as bookname,
        wo.itemcode as bookcode,
        wo.wotype,
        cust.customername,
        ai.paperbackisbn as paperbackno,
        ai.hardbackisbn as hardbackno,
        ai.ocisbn as ocno,
        bc.bookcategory,
        ai.style1,
        ai.style2,
        ai.style3,
        ai.style4,
        ai.style5,
        ai.style6,
        css.cssvalue as css,
        service.wfid as workflowid,
        division.division,
        profile.profilevalue as printprofile,
        profile1.profilevalue as onlineprofile,r.contact, *
      from
        wms_workorder_additionalinfo ai
      join wms_workorder wo on
        ai.workorderid = wo.workorderid
      join org_mst_customer cust on
        cust.customerid = wo.customerid
      left join wms_mst_bookcategory bc on
        bc.bookcategoryid = ai.bookcategoryid
      left join wms_mst_cssvalue css on
        css.cssvalueid = ai.cssvalueid
      left join wms_workorder_service as service on
        service.workorderid = ai.workorderid
      left join org_mst_division as division on
        division.divisionid = wo.divisionid
      left join trn_pitstopprofiledetail as profile on
        profile.id = ai.printid
      left join trn_pitstopprofiledetail as profile1 on
        profile.id = ai.onlinepdfid
      left join (SELECT json_agg(
          json_build_object(
              'contactname', wwc.contactname,
              'rolename', r.rolename,
              'roleid', r.roleid
          )
      ) AS contact ,workorderid
      FROM wms_workorder_contacts wwc
      LEFT JOIN wms_role r ON r.roleid = wwc.roleid group by workorderid) as r on r.workorderid =  ai.workorderid
      where
        ai.workorderid = $1
      order by
        additionalinfoid asc `;
      const bookDetail = await query(sql, [workOrderId]);
      let bookDetails2;
      if (bookDetail.length == 0) {
        const sql2 = `select service.wfid as workflowid,woi.title as bookname,woi.itemcode as bookcode,division.division,
                * from wms_workorder as woi    
                left join wms_workorder_service as service on service.workorderid = woi.workorderid
                left join org_mst_division as division on division.divisionid = woi.divisionid
                where woi.workorderid=$1`;
        console.log(sql2, 'sql2 for book details');
        bookDetails2 = await query(sql2, [workOrderId]);
      }
      const result =
        bookDetail && bookDetail.length > 0 ? bookDetail : bookDetails2;
      resolve(result);
    } catch (e) {
      reject(e);
    }
  });
};

export const getBookDetailsTemplateForCupJournals = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `  select journal.journalname,printprofile.printprofile,textcolumn.textcolumn,onlineprofile.onlineprofile,templates.templatefilepath,templates.filename,journal.runon,journal.runontype,journal.journaltype,woi.category as wocategory,
      case when fawc.package = 'PR' then 'Pre Editing' else 'Type Setting' end as reqtype,
* from wms_workorder as woi
      left join pp_mst_journal  as journal on journal.journalid = woi.journalid
      left join wms_mst_printprofile as printprofile on printprofile.printprofileid = journal.printprofileid
      left join wms_mst_onlineprofile as onlineprofile on onlineprofile.onlineprofileid = journal.onlineprofileid
      left join wms_mst_textcolumn as textcolumn on textcolumn.textcolumnid = journal.textcolumnid
      left join wms_workorder_swtemplate as wotemplate on wotemplate.workorderid = woi.workorderid
       left join wms_mst_composingsw_templates as templates on templates.templateid = wotemplate.templateid
       left join LATERAL (select 
		get_ftp_filename (woi.workorderid::int) as package
 )  as fawc ON true 
      where  woi.workorderid=$1 order by journal.journalid asc`;
      const bookDetailsJournals = await query(sql, [workOrderId]);
      resolve(bookDetailsJournals);
    } catch (e) {
      reject(e);
    }
  });
};

export const getBookDetailsForWKHIssue = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = ` select journal.journalname,printprofile.printprofile,textcolumn.textcolumn,onlineprofile.onlineprofile,templates.templatefilepath,templates.filename,journal.runon,journal.runontype,journal.journaltype,woi.category as wocategory,* from wms_workorder as woi
      left join pp_mst_journal  as journal on journal.journalid = woi.journalid
      left join wms_mst_printprofile as printprofile on printprofile.printprofileid = journal.printprofileid
      left join wms_mst_onlineprofile as onlineprofile on onlineprofile.onlineprofileid = journal.onlineprofileid
      left join wms_mst_textcolumn as textcolumn on textcolumn.textcolumnid = journal.textcolumnid
      left join wms_workorder_swtemplate as wotemplate on wotemplate.workorderid = woi.workorderid
       left join wms_mst_composingsw_templates as templates on templates.templateid = wotemplate.templateid
      where  woi.workorderid=$1 order by journal.journalid asc`;
      const bookDetailsJournals = await query(sql, [workOrderId]);
      resolve(bookDetailsJournals);
    } catch (e) {
      reject(e);
    }
  });
};

export const getBookMasterDetailsTemplate = async (
  workOrderId,
  stagename,
  activityname,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select generate_bookmaster_xml($1,$2,$3)`;
      const bookMasterDetails = await query(sql, [
        workOrderId,
        stagename,
        activityname,
      ]);
      resolve(bookMasterDetails);
    } catch (e) {
      reject(e);
    }
  });
};

export const getIncomingFileDetailsForRunOnFile = async (
  workOrderId,
  woIncomingFileId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select ifd.filename,ifd.filesequence,ifd.woincomingfileid,ifd.runonfilesequence from wms_workorder_incoming incoming
      join wms_workorder_incomingfiledetails ifd on incoming.woincomingid=ifd.woincomingid
      where incoming.woid=$1 and ifd.woincomingfileid = $2  and  ifd.runonfilesequence  = 1 order by ifd.filesequence`;
      const runOnDetails = await query(sql, [workOrderId, woIncomingFileId]);
      resolve(runOnDetails);
    } catch (e) {
      reject(e);
    }
  });
};
export const getBookDetailsTemplateForOupJournals = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = ` select journal.*,printprofile.printprofile,textcolumn.textcolumn,onlineprofile.onlineprofile,templates.templatefilepath,templates.filename,woi.category as wocategory,* from wms_workorder as woi
      left join pp_mst_journal  as journal on journal.journalid = woi.journalid
      left join wms_mst_printprofile as printprofile on printprofile.printprofileid = journal.printprofileid
      left join wms_mst_onlineprofile as onlineprofile on onlineprofile.onlineprofileid = journal.onlineprofileid
      left join wms_mst_textcolumn as textcolumn on textcolumn.textcolumnid = journal.textcolumnid
      left join wms_workorder_swtemplate as wotemplate on wotemplate.workorderid = woi.workorderid
       left join wms_mst_composingsw_templates as templates on templates.templateid = wotemplate.templateid
       where  woi.workorderid=$1 order by journal.journalid asc`;
      const bookDetailsJournals = await query(sql, [workOrderId]);
      resolve(bookDetailsJournals);
    } catch (e) {
      reject(e);
    }
  });
};

export const getFileSeqDetails = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const fileSeqDetails = await getFileSeq(workOrderId);
    res.status(200).json({ fileSeqDetails });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
export const getFileSeq = workOrderId => {
  return new Promise(async (resolve, reject) => {
    const sql = `select pp.pitstopprofile,ft.filetype,ifd.filename,ifd.filesequence,ifd.woincomingfileid from wms_workorder_incoming incoming 
    join wms_workorder_incomingfiledetails ifd on incoming.woincomingid=ifd.woincomingid
     join pp_mst_filetype ft on ft.filetypeid=ifd.filetypeid
     left join wms_mst_pitstopprofile pp on pp.pitstopprofileid=ifd.pitstopprofile
    where incoming.woid=$1 and ft.filetypeid NOT IN (1, 15) order by ifd.filesequence`;
    try {
      const fileSeqDetails = await query(sql, [workOrderId]);
      resolve(fileSeqDetails);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const createDb = async (req, res) => {
  try {
    const { eventLogData } = req.body;
    let wfeventId = null;
    wfeventId = await createEventLog(eventLogData);
    res.status(200).send(wfeventId);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const updateAsUnassigned = async (req, res) => {
  try {
    const { eventLogData } = req.body;
    const { wfeventId } = eventLogData;
    await query(
      `UPDATE public.wms_workflow_eventlog SET activitystatus = 'Unassigned' WHERE wfeventid = ${wfeventId}`,
    );
    res.status(200).json({ status: 'Success' });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const entrytofileTrnDetails = async (req, res) => {
  try {
    const { wfeventId, fileTrnData } = req.body;
    const ids = fileTrnData.map(o => o.path);
    const filtered = fileTrnData.filter(
      ({ path }, index) => !ids.includes(path, index + 1),
    );
    const selectSql = `SELECT * FROM public.wms_workflowactivitytrn_file_map where wfeventid=${wfeventId}`;
    const ExistingEntries = await query(selectSql);
    const toInsert = [];
    const toUpdate = [];
    filtered.forEach(ele => {
      ele.path = ele.path.replace("'", "''"); // this code added for to handle file names with single quote that leads to perform SQL Injection.
      if (
        ExistingEntries.filter(
          x => ele.fileId == x.woincomingfileid && ele.path == x.repofilepath,
        ).length == 0
      ) {
        const { path, uuid, fileId } = ele;
        toInsert.push(
          `(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`,
        );
      } else {
        const { path, uuid, fileId } = ele;
        toUpdate.push(
          `(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`,
        );
      }
    });
    if (toInsert.length > 0) {
      const insertQuery = `INSERT INTO public.wms_workflowactivitytrn_file_map
      (wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
      values ${toInsert}`;
      await query(insertQuery);
    }
    if (toUpdate.length > 0) {
      const updateQuery = `update public.wms_workflowactivitytrn_file_map as t set
      repofileuuid = c.repofileuuid
      from (values ${toUpdate}) as c(wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid) 
      where c.woincomingfileid = t.woincomingfileid and c.repofilepath=t.repofilepath;`;
      await query(updateQuery);
    }
    res.status(200).send({ issuccess: true });
  } catch (e) {
    res
      .status(400)
      .send({ issuccess: false, message: e.message ? e.message : e });
  }
};

export const updateDb = async (req, res) => {
  try {
    const { eventLogData, fileTrnData } = req.body;
    const { wfeventId, activity } = eventLogData;
    const ids = fileTrnData.map(o => o.path);
    const filtered = fileTrnData.filter(
      ({ path }, index) => !ids.includes(path, index + 1),
    );
    const WorkOrderFileMapp = [];
    console.log(filtered, 'filtered files');
    filtered.forEach(fileTrn => {
      const { path, uuid, fileId } = fileTrn;
      WorkOrderFileMapp.push({
        wfeventid: wfeventId,
        repofileuuid: uuid,
        repofilepath: path,
        isvisible: true,
        isdownloaded: false,
        woincomingfileid: fileId,
      });
    });
    const {
      category,
      wfConfig,
      workOrderId,
      service,
      stage,
      processInstanceId,
      isBookCompleted,
      taskInstanceId,
    } = eventLogData;
    let { wfDefConfig } = eventLogData;
    const incomingFileTypes =
      wfConfig && wfConfig.incoming && wfConfig.incoming.fileTypes
        ? wfConfig.incoming.fileTypes
        : [];
    const stageDetails = await queryWOStageChapters(
      category,
      incomingFileTypes,
      stage.id,
      service.id,
      stage.iteration,
      workOrderId,
    );
    const isStageCompleted = getStageCompletionStatus(category, stageDetails);
    wfDefConfig = wfDefConfig == null ? {} : wfDefConfig;
    wfDefConfig.completeWorkOrder = !!wfDefConfig.completeWorkOrder;
    const sqlout = await query(`select * from updateDbProcess(
                    ${wfeventId},
                    '${JSON.stringify(WorkOrderFileMapp)}',
                    ${!!isStageCompleted},
                    ${!!wfDefConfig.completeWorkOrder},
                    ${!!isBookCompleted},
                    ${workOrderId},
                    ${service.id},
                    ${stage.id},
                    ${stage.iteration},
                    ${activity.actualIteration}
                    )`);
    if (isStageCompleted) {
      if (wfDefConfig.completeWorkOrder) {
        const data = {
          taskId: taskInstanceId,
        };
        const url = config.camnunda.uri.completeTask;
        const httpService = new Service();
        await httpService.post(`${config.camnunda.base_url}${url}`, data);
        if (sqlout.rows[0].updatedbprocess > 0) {
          await triggerBatchCompletion(processInstanceId);
        }
      }
    }
    // wfeventId = await updateEventLog(eventLogData, client);
    // if (fileTrnData.length) await updateFileTRNLog(fileTrnData, wfeventId, client);
    // await updateEventLogDetails(wfeventId, client);
    // await updateStageStatus(eventLogData);
    res.status(200).json({ status: 'Success' });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const updateDbError = async (req, res) => {
  try {
    const { wfeventId, Error } = req.body;
    const sql = `UPDATE public.wms_workflow_eventlog SET activitystatus = $1, remark = $3 WHERE wfeventid = $2 `;
    await query(sql, ['Error', wfeventId, Error]);
    res.status(200).json({ status: 'Success' });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const updateDbRemark = async (req, res) => {
  try {
    const { wfeventId, Remark } = req.body;
    const sql = `UPDATE public.wms_workflow_eventlog SET remark = $1 WHERE wfeventid = $2 `;
    await query(sql, [Remark, wfeventId]);
    res.status(200).json({ status: 'Success' });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

// export const externalTaskPayload = async (req, res) => {
//   const { wfeventId, externalTaskData, msg } = req.body;
//   try {
//     const sql = `UPDATE public.wms_workflow_eventlog SET  externaltaskdata='${JSON.stringify(
//       externalTaskData,
//     )}' , externaltasklog = '${JSON.stringify(msg ?? {})}' WHERE wfeventid=${wfeventId}`;
//     await query(sql);
//     res.status(200).json({ status: 'Success' });
//   } catch (e) {
//     res.status(400).send(e.message ? e.message : e);
//   }
// };

export const externalTaskPayload = async (req, res) => {
  const { wfeventId, externalTaskData, msg } = req.body;
  try {
    const sql = `UPDATE public.wms_workflow_eventlog 
                 SET externaltaskdata = $1, externaltasklog = $2 
                 WHERE wfeventid = $3`;
    const values = [
      JSON.stringify(externalTaskData ?? {}),
      JSON.stringify(msg ?? {}),
      wfeventId,
    ];

    await query(sql, values);
    res.status(200).json({ status: 'Success' });
  } catch (e) {
    res.status(400).send(e.message || e);
  }
};

export const fetchPayloadForAricleOrderSequence = async (req, res) => {
  const { workOrderId, woIncomingFileId } = req.body;
  try {
    const sql = `select woincomingfileid,filename,piinumber,* from wms_workorder_incoming as incoming
    join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
    where incoming.woid = ${workOrderId} and woincomingfileid = ${woIncomingFileId}`;
    const data = await query(sql);
    res.status(200).json(data.length > 0 ? data[0].articleordersequence : null);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const resetFileDetails = async (req, res) => {
  try {
    const {
      workOrderId,
      wfdefId,
      woincomingFileId,
      type,
      stage,
      activity,
      du,
      service,
      customer,
    } = req.body;
    let sql;
    let resetDetails = [];
    let newTrnFileDetails = [];
    let preTrnFileDetails = [];
    if (woincomingFileId != null) {
      sql = `SELECT * FROM public.wms_workflow_eventlog where workorderid = $1 and wfdefid=$2 and woincomingfileid =$3 and stageiterationcount = $4 order by wfeventid desc`;
      resetDetails = await query(sql, [
        workOrderId,
        wfdefId,
        woincomingFileId,
        stage.iteration,
      ]);
    } else {
      sql = `SELECT * FROM public.wms_workflow_eventlog where workorderid = $1 and wfdefid=$2  and stageiterationcount = $3 order by wfeventid desc`;
      resetDetails = await query(sql, [workOrderId, wfdefId, stage.iteration]);
    }
    let isResetFile = false;
    const sql1 = `SELECT public.isReset($1,$2,$3,$4,$5)`;
    const resetLogDetails = await query(sql1, [
      workOrderId,
      activity.id,
      stage.id,
      stage.iteration,
      woincomingFileId,
    ]);
    isResetFile = !!(
      resetLogDetails &&
      resetLogDetails.length > 0 &&
      resetLogDetails[0].isreset == true
    );
    if (resetDetails.length >= 2) {
      if (
        isResetFile &&
        (((resetDetails[0].activitystatus == 'Unassigned' ||
          resetDetails[0].activitystatus == 'Inprocess') &&
          resetDetails[1].activitystatus == 'Reset') ||
          ((resetDetails[0].activitystatus == 'Unassigned' ||
            resetDetails[0].activitystatus == 'Inprocess') &&
            resetDetails[1].activitystatus == 'Completed'))
      ) {
        const sql2 = `SELECT * FROM public.wms_workflowactivitytrn_file_map where wfeventid =$1`;
        newTrnFileDetails = await query(sql2, [resetDetails[0].wfeventid]);

        const sql3 = `SELECT * FROM public.wms_workflowactivitytrn_file_map where wfeventid =$1 and isactive= true `;
        preTrnFileDetails = await query(sql3, [resetDetails[1].wfeventid]);

        const responseIterationFile =
          await getPreviouseFileDetailsEnteriesForReset(
            type,
            preTrnFileDetails,
            newTrnFileDetails,
            woincomingFileId,
            stage,
            activity,
            du,
            service,
            customer,
            workOrderId,
          );

        if (responseIterationFile) {
          res.status(200).send({ data: 'Data Transfered Successfully' });
        }
      } else {
        res.status(200).send({ data: 'No Data Found' });
      }
    } else {
      res.status(200).send({ data: 'No Data Found' });
    }
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getPreviouseFileDetailsEnteriesForReset = async (
  type,
  preTrnFileDetails,
  newTrnFileDetails,
  woincomingFileId,
  stage,
  activity,
  du,
  service,
  customer,
  workOrderId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const dmsType = await getdmsType(workOrderId);
      if (preTrnFileDetails.length > 0 && newTrnFileDetails.length > 0) {
        const wfeventidNew = newTrnFileDetails[0].wfeventid;
        let currentActBaseFolderNamePayload = '';
        let dirPreActBaseFolderNamePayload = '';

        const preStageIteration =
          stage.iteration > 1 ? stage.iteration - 1 : stage.iteration;
        const preActivityIteration =
          activity.iteration > 1 ? activity.iteration - 1 : activity.iteration;
        let isMultiple = false;
        if (type == 'Multiple') {
          isMultiple = true;
          const sql = `select wms_workorder_incomingfiledetails.filetypeid, filetype from wms_workorder_incomingfiledetails 
                    join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
                    WHERE woincomingfileid = $1`;
          const getFileDetails = await query(sql, [woincomingFileId]);
          const { filetypeid, filetype } =
            getFileDetails.length > 0 ? getFileDetails[0] : {};
          currentActBaseFolderNamePayload = {
            type: 'wo_activity_filetype',
            workOrderId,
            du,
            customer,
            service,
            stage,
            activity,
            fileType: {
              name: filetype,
              id: filetypeid,
              fileId: woincomingFileId,
            },
          };
          dirPreActBaseFolderNamePayload = {
            type: 'wo_activity_filetype',
            workOrderId,
            du,
            customer,
            service,
            stage: {
              name: stage.name,
              id: stage.id,
              iteration: preStageIteration,
            },
            activity: {
              name: activity.name,
              id: activity.id,
              iteration: preActivityIteration,
            },
            fileType: {
              name: filetype,
              id: filetypeid,
              fileId: woincomingFileId,
            },
          };
        } else {
          currentActBaseFolderNamePayload = {
            type: 'wo_activity_iteration',
            workOrderId,
            du,
            customer,
            service,
            stage,
            activity,
          };
          dirPreActBaseFolderNamePayload = {
            type: 'wo_activity_iteration',
            workOrderId,
            du,
            customer,
            service,
            stage: {
              name: stage.name,
              id: stage.id,
              iteration: preStageIteration,
            },
            activity: {
              name: activity.name,
              id: activity.id,
              iteration: preActivityIteration,
            },
          };
        }

        const currentActBaseFolderName = await getFolderStructure(
          currentActBaseFolderNamePayload,
        );
        const dirPreActBaseFolderName = await getFolderStructure(
          dirPreActBaseFolderNamePayload,
        );
        const data = {
          destinationPath: currentActBaseFolderName,
          sourcePath: dirPreActBaseFolderName,
          isMultiple,
          woincomingFileId,
        };
        let resOfFileCopy = [];
        switch (dmsType) {
          case 'azure':
            resOfFileCopy = await azureFolderCopy(data);
            break;
          case 'local':
            resOfFileCopy = await localFolderCopy(data);
            break;
          default:
            resOfFileCopy = await okmFolderCopy(data);
            break;
        }
        const sql = `select * from public.insert_workflo_activity_filemap($1, $2)`;
        await query(sql, [JSON.stringify(resOfFileCopy), wfeventidNew]);
        resolve(true);
      } else {
        resolve('file not present');
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getStageInfoFromCamunda = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const response = await _getStageInfoFromCamunda(workOrderId);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _getStageInfoFromCamunda = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      let processInstanceId = '';
      let taskInstanceId = '';
      // let sql1 = `select distinct eventdata->>'processInstanceId' as processinstanceid, taskinstanceid, wfeventid, activitystatus from wms_workflow_eventlog where workorderid = $1 and activitystatus != $2 order by wfeventid desc limit 1`;
      const sql1 = `select distinct eventdata->>'processInstanceId' as processinstanceid, taskinstanceid, wfeventid, activitystatus from wms_workflow_eventlog
            join public.wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
            where workorderid = $1 and activitystatus != $2 and stageid !=$3 order by wfeventid desc limit 1
            `;
      await query(sql1, [workOrderId, 'Completed', 10]).then(response => {
        if (response && response.length) {
          processInstanceId = response[0].processinstanceid;
          taskInstanceId = response[0].taskinstanceid;
        }
      });

      const url = config.camnundaNative.uri.getStageInfo.replace(
        /{{id}}/,
        processInstanceId,
      );
      const setURL = `${config.camnundaNative.base_url}${url}`;
      const httpService = new Service();
      const __stageInfo = await httpService.get(setURL);
      console.log(__stageInfo);
      resolve({ __stageInfo, processInstanceId, taskInstanceId });
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const updateStageInfoToCamunda = async (req, res) => {
  const { stageInfo, processInstanceId } = req.body;
  try {
    await _updateStageInfoToCamunda(stageInfo, processInstanceId);
    res.status(200).json({ status: 'Success' });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
export const _updateStageInfoToCamunda = async (files, processInstanceId) => {
  return new Promise(async (resolve, reject) => {
    console.log(files, processInstanceId, 'datas');
    try {
      const payload = {
        type: 'Json',
        value: JSON.stringify(files),
        valueInfo: {},
      };
      const url = config.camnundaNative.uri.putStageInfo.replace(
        /{{id}}/,
        processInstanceId,
      );
      const setURL = `${config.camnundaNative.base_url}${url}`;
      const httpService = new Service();
      await httpService.put(setURL, JSON.stringify(payload));
      resolve(true);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const _updateActivityStageInfoToCamunda = async (
  files,
  taskInstanceId,
) => {
  return new Promise(async (resolve, reject) => {
    console.log(files, taskInstanceId, 'datas for activity');
    try {
      const payload = {
        type: 'Json',
        value: JSON.stringify(files),
        valueInfo: {},
      };
      const url = config.camnundaNative.uri.putActivityStageInfo.replace(
        /{{id}}/,
        taskInstanceId,
      );
      const setURL = `${config.camnundaNative.base_url}${url}`;
      const httpService = new Service();
      await httpService.put(setURL, JSON.stringify(payload));
      resolve(true);
    } catch (e) {
      console.log(e, 'camunda error');
      reject(e.message ? e.message : e);
    }
  });
};
export const updateStageInfoForSequence = async (req, res) => {
  const { workOrderId, fileseq, taskInstanceId } = req.body;
  try {
    const awt = await updateStageSequence(workOrderId, fileseq, taskInstanceId);
    console.log(awt, 'awtawt');
    res
      .status(200)
      .send('File Sequence Updated Successfully in Camunda StageInfo');
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const blobStorageDetails = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const dmsType = await getdmsType(workOrderId);
    res.status(200).send({ dmsType });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getdmsType = async (workOrderId, checkLocalIssue = false) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select wo.dmsid,dms.dmstype,wo.jobtype from wms_workorder as wo
       left join dms_master as dms on dms.dmsid = wo.dmsid
       where workorderid =${workOrderId}`;
      const blobDetails = await query(sql);
      if (checkLocalIssue) {
        resolve(
          blobDetails && blobDetails.length
            ? {
                dmsType: blobDetails[0].dmstype,
                isLocalIssue:
                  blobDetails[0].jobtype == 2 &&
                  blobDetails[0].dmstype == 'local',
              }
            : null,
        );
      } else {
        resolve(
          blobDetails && blobDetails.length ? blobDetails[0].dmstype : null,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const updateStageSequence = async (workOrderId, fileseq) => {
  const updatedStageInfo = [];
  const _stageInfo = await _getStageInfoFromCamunda(workOrderId);
  const stageInfo1 = JSON.parse(_stageInfo.__stageInfo.data.value);
  const stageInfo =
    Object.keys(stageInfo1).includes('data') &&
    Object.keys(stageInfo1).includes('value') &&
    stageInfo1.data.value
      ? JSON.parse(stageInfo1.data.value)
      : stageInfo1;
  console.log(fileseq, 'filesequence updated');
  for (let i = 0; i < fileseq.length; i++) {
    const exitsFile = stageInfo.files.filter(
      x => x.id == fileseq[i].woincomingfileid,
    );
    if (exitsFile && exitsFile.length > 0) {
      updatedStageInfo.push(...exitsFile);
    } else {
      updatedStageInfo.push({
        id: fileseq[i].woincomingfileid,
        name: fileseq[i].filename,
        type: fileseq[i].filetype,
      });
    }
  }
  console.log(updatedStageInfo, 'camunda stage');
  stageInfo.files = updatedStageInfo;
  console.log(stageInfo);
  const awt = [];
  awt.push(
    await _updateStageInfoToCamunda(stageInfo, _stageInfo.processInstanceId),
  );
  // let taskInstId = await getTaskInstanceId(workOrderId, stageInfo.type);
  if (_stageInfo.taskInstanceId) {
    awt.push(
      await _updateActivityStageInfoToCamunda(
        stageInfo,
        _stageInfo.taskInstanceId,
      ),
    );
  }
  await Promise.all(awt);
  return awt;
};

export const getTaskInstanceId = async (workOrderId, stage) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `select taskinstanceid from wms_tasklist where workorderid=$1 and lower(stagename) = $2 and activitystatus != $3 order by wfeventid desc limit 1`;
      await query(sql1, [workOrderId, stage, 'Completed'])
        .then(response => {
          if (response.length > 0) {
            resolve(response[0].taskinstanceid);
          } else {
            reject('TaskInstanceId not found');
          }
        })
        .catch(err => {
          reject(err);
        });
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

// update variable values in specified instance in camunda
export const updateVariableValueToCamunda = async (req, res) => {
  try {
    const { value, name } = req.body;

    // const sql = `with cte as (
    //   select eventdata->>'processInstanceId' as processinstanceid  ,* from wms_workflow_eventlog
    //   join wms_workflowdefinition on wms_workflowdefinition.wfdefid =  wms_workflow_eventlog.wfdefid
    //   where wfid=27 ) select distinct on (processinstanceid) processinstanceid, workorderid from cte`;
    // const result = await query(sql);
    const result = [
      { processInstanceId: 'a5c2d816-f576-11ee-bfd3-000d3af05eb9' },
    ];
    result.forEach(async item => {
      const { processInstanceId } = item;
      const payload = {
        type: 'Json',
        value: JSON.stringify(value),
      };
      const url = config.camnundaNative.uri.updateVariableValue.replace(
        /{{id}}/,
        processInstanceId,
      );
      const setURL = `${config.camnundaNative.base_url}${url}/${name}`;
      const httpService = new Service();
      await httpService.put(setURL, JSON.stringify(payload));
    });
    res.status(200).json({ status: 'Variable Updated Successfully' });
  } catch (e) {
    res.status(400).send(e ? e.message : e);
  }
};

export const getBookMasterDetails = async (req, res) => {
  const { workOrderId, stagename, activityname } = req.body;
  try {
    const result = await getBookMasterDetailsTemplate(
      workOrderId,
      stagename,
      activityname,
    );
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
