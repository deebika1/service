/* eslint-disable no-continue */
import {
  isAllNodeVisited,
  updateVisitedNodeDetails,
  updateTaskDetails,
} from './helper.js';

export const startBfsTraversal = bpmnParser => {
  const traverseDetails = {
    visited: {},
    parallelTaskVisited: {},
    yetToVisit: [{ id: bpmnParser.getStartEventsId()[0], isValidTask: false }],
    taskDetails: [],
    lastCount: 0,
  };
  traverseBPMN(bpmnParser, traverseDetails);
  return traverseDetails.taskDetails;
};

const traverseBPMN = (bpmnParser, traverseDetails) => {
  const { yetToVisit, visited, parallelTaskVisited } = traverseDetails;
  if (yetToVisit.length) {
    const isValidTaskSet = yetToVisit.every(
      ({ type, isWait, isValidTask }) =>
        (type === 'parallelGateway' && isWait) || isValidTask,
    );
    const ytv = yetToVisit.slice();
    for (let i = 0; i < ytv.length; i++) {
      const { id, type, isWait, isValidTask } = ytv[i];
      const yetToVisitIndex = yetToVisit.indexOf(ytv[i]);
      if (isValidTaskSet) {
        if (type === 'parallelGateway' && isWait) continue;
        yetToVisit.splice(yetToVisitIndex, 1);
        const isAlreadyVisited = updateVisitedNodeDetails(id, visited);
        if (isAlreadyVisited) continue;
        updateTaskDetails(bpmnParser, id, traverseDetails);
        yetToVisit.splice(i, 0, ...getNextNodeDetails(bpmnParser, id));
      } else {
        if (isValidTask) continue;
        const isAlreadyVisited = updateVisitedNodeDetails(id, visited);
        if (isAlreadyVisited) {
          yetToVisit.splice(yetToVisitIndex, 1);
          continue;
        }
        if (type === 'parallelGateway') {
          if (parallelTaskVisited[id]) {
            yetToVisit.splice(yetToVisitIndex, 1);
            continue;
          }
          if (isAllNodeVisited(bpmnParser, id, visited)) {
            parallelTaskVisited[id] = true;
            yetToVisit.splice(yetToVisitIndex, 1);
          } else {
            yetToVisit[yetToVisitIndex].isWait = true;
            traverseDetails.visited[id] = false;
            continue;
          }
        } else {
          yetToVisit.splice(yetToVisitIndex, 1);
        }
        yetToVisit.splice(i, 0, ...getNextNodeDetails(bpmnParser, id));
      }
    }
    traverseBPMN(bpmnParser, traverseDetails);
  }
};

const getNextNodeDetails = (bpmnParser, id) => {
  const nodeList = [];
  const nodes = bpmnParser.search.findNextNode(id);
  nodes.forEach(node => {
    const type = node.getType();
    const Id = node.getId();
    const name = node.getName();
    const isValidTask = type == 'userTask' || type === 'serviceTask';
    nodeList.push({ id: Id, name, type, isValidTask });
  });
  return nodeList;
};
