import { getAttributeName } from './core/utils.js';

export const isAllNodeVisited = (bpmnParser, id, visited) => {
  const node = bpmnParser.search.getNodeById(id);
  const incoming =
    typeof node.incoming === 'string' ? [node.incoming] : node.incoming;
  return incoming.every(incomingNode => {
    const srcRef =
      bpmnParser.search.sequences[incomingNode][getAttributeName('sourceRef')];
    return !!visited[srcRef];
  });
};

export const updateVisitedNodeDetails = (id, visited) => {
  if (!visited[id]) {
    visited[id] = true;
    return false;
  }
  return true;
};

export const updateTaskDetails = (bpmnParser, id, traverseDetails) => {
  const node = bpmnParser.search.getNodeById(id);
  const type = node.getType();
  const taskDetail =
    type === 'userTask'
      ? bpmnParser.getUserTaskDetail(node)
      : type === 'serviceTask'
      ? bpmnParser.getServiceTaskDetail(node)
      : undefined;
  if (taskDetail) {
    const {
      general: { name, id: Id, description },
      activityType,
      instanceType,
      inputParams,
      formData,
    } = taskDetail;
    ++traverseDetails.lastCount;
    traverseDetails.taskDetails.push({
      id: Id,
      name,
      description,
      type,
      activityType,
      instanceType,
      inputParams,
      formData,
      sequence: traverseDetails.lastCount,
    });
  }
};
