import {
  isAllNodeVisited,
  updateVisitedNodeDetails,
  updateTaskDetails,
} from './helper.js';

export const startDfsTraversal = bpmnParser => {
  const traverseDetails = {
    visited: {},
    taskDetails: [],
    lastCount: 0,
  };
  traverseBPMN(bpmnParser, bpmnParser.getStartEventsId()[0], traverseDetails);
  return traverseDetails.taskDetails;
};

const traverseBPMN = (bpmnParser, id, traverseDetails) => {
  const { visited } = traverseDetails;
  const isAlreadyVisited = updateVisitedNodeDetails(id, visited);
  if (isAlreadyVisited) return;
  updateTaskDetails(bpmnParser, id, traverseDetails);
  const nodes = bpmnParser.search.findNextNode(id);
  nodes.forEach(node => {
    const type = node.getType();
    const Id = node.getId();
    if (type === 'parallelGateway') {
      if (isAllNodeVisited(bpmnParser, Id, visited)) {
        traverseBPMN(bpmnParser, Id, traverseDetails);
      }
    } else {
      traverseBPMN(bpmnParser, Id, traverseDetails);
    }
  });
};
