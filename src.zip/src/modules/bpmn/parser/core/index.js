import { BPMNParser } from './parser.js';

export { BPMNParser };
