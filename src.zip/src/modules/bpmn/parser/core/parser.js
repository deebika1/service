/* eslint-disable class-methods-use-this */
import EventEmitter from 'events';
import xmlParser from 'fast-xml-parser';
import { readFile } from 'fs';
import { xmlConfig } from './config.js';
import { getAttributeName, getTextValue } from './utils.js';
import { BPMNSearch } from './search.js';

export class BPMNParser extends EventEmitter {
  constructor(fileName) {
    super();
    this.processObj = {};
    this.xmlContent = {};
    this.search = undefined;
    this.parseXML(fileName);
  }

  parseXML(fileName) {
    readFile(fileName, { encoding: 'utf-8' }, (err, xmlData) => {
      if (err) {
        this.emit('error', err);
        return;
      }
      this.xmlContent = xmlData;
      const xmlObj = xmlParser.parse(xmlData, xmlConfig);
      const processObj =
        xmlObj && xmlObj.definitions && xmlObj.definitions.process;
      if (!processObj) {
        this.emit('error', 'Process Model Not found');
        return;
      }
      this.processObj = processObj;
      this.search = new BPMNSearch(this);
      this.emit('parsed', this.processObj);
    });
  }

  getBasicDetails(activity) {
    const description = activity.documentation || '';
    const id = activity[getAttributeName('id')];
    const name = activity[getAttributeName('name')] || '';
    return { name, id, description };
  }

  getProcessDetails() {
    return this.getBasicDetails(this.processObj);
  }

  getStartEventsId() {
    const startEvents =
      this.processObj.startEvent instanceof Array
        ? this.processObj.startEvent
        : [this.processObj.startEvent];
    return startEvents.map(startEvent => startEvent[getAttributeName('id')]);
  }

  getUserTasksId() {
    if (this.processObj.userTask) {
      const userTasks =
        this.processObj.userTask instanceof Array
          ? this.processObj.userTask
          : [this.processObj.userTask];
      return userTasks.map(userTask => userTask[getAttributeName('id')]);
    }
    return [];
  }

  getServiceTasksId() {
    if (this.processObj.serviceTask) {
      const serviceTasks =
        this.processObj.serviceTask instanceof Array
          ? this.processObj.serviceTask
          : [this.processObj.serviceTask];
      return serviceTasks.map(
        serviceTask => serviceTask[getAttributeName('id')],
      );
    }
    return [];
  }

  getUserTaskDetail(userTask) {
    this.getFormData(userTask);
    const { multiInstanceLoopCharacteristics } = userTask;
    const activityType = 'User Task';
    const instanceType =
      multiInstanceLoopCharacteristics !== undefined ? 'Multiple' : 'Single';
    const inputParams = this.getInputParams(userTask);
    const formData = this.getFormData(userTask);
    return {
      general: this.getBasicDetails(userTask),
      activityType,
      instanceType,
      inputParams,
      formData,
    };
  }

  getServiceTaskDetail(serviceTask) {
    const { multiInstanceLoopCharacteristics } = serviceTask;
    const activityType =
      serviceTask[getAttributeName('type')] === 'external'
        ? 'External Task'
        : 'Service Task';
    const instanceType =
      multiInstanceLoopCharacteristics !== undefined ? 'Multiple' : 'Single';
    const inputParams = this.getInputParams(serviceTask);
    return {
      general: this.getBasicDetails(serviceTask),
      activityType,
      instanceType,
      inputParams,
    };
  }

  getInputParams(activity) {
    const inputOutput =
      activity.extensionElements && activity.extensionElements.inputOutput;
    if (inputOutput) {
      const { inputParameter = [] } = inputOutput;
      return inputParameter.map(param => {
        return {
          name: param[getAttributeName('name')],
          value: param[getTextValue()],
        };
      });
    }
    return [];
  }

  getFormData(activity) {
    let formFields =
      activity.extensionElements &&
      activity.extensionElements.formData &&
      activity.extensionElements.formData.formField;
    const formDetails = [];
    if (formFields) {
      formFields = formFields instanceof Array ? formFields : [formFields];
      formFields.forEach(formField => {
        formDetails.push({
          id: formField[getAttributeName('id')],
          label: formField[getAttributeName('label')] || '',
          type: formField[getAttributeName('type')],
          defaultValue: formField[getAttributeName('defaultValue')] || '',
          validation: this.getFormValidationDetails(formField),
          options: this.getFormOptions(formField),
        });
      });
      return formDetails;
    }
    return formDetails;
  }

  getFormOptions(formField) {
    const type = formField[getAttributeName('type')];
    const optionDetails = [];
    if (type === 'enum' && formField.value) {
      const options =
        formField.value instanceof Array ? formField.value : [formField.value];
      options.forEach(option => {
        const id = option[getAttributeName('id')];
        const name = option[getAttributeName('name')] || '';
        if (id && name) {
          optionDetails.push({ id, name });
        }
      });
      return optionDetails;
    }
    return optionDetails;
  }

  getFormValidationDetails(formField) {
    let validations = formField.validation && formField.validation.constraint;
    const validationDetails = {};
    const constraintDetails = {
      required: 'boolean',
      minlength: 'number',
      maxlength: 'number',
      min: 'number',
      max: 'number',
      readonly: 'boolean',
    };
    if (validations) {
      validations = validations instanceof Array ? validations : [validations];
      validations.forEach(fmField => {
        const name = fmField[getAttributeName('name')];
        const config = fmField[getAttributeName('config')] || true;
        if (
          name &&
          constraintDetails[name] &&
          // eslint-disable-next-line valid-typeof
          typeof config === constraintDetails[name]
        ) {
          validationDetails[name] = config;
        }
      });
      return validationDetails;
    }
    return validationDetails;
  }
}
