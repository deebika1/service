import schedule from 'node-schedule';
import { transaction } from '../../database/postgres.js';

export const startCronJob = name => {
  // To cancel the job on a certain condition (uniqueJobName must be known)
  if (schedule.scheduledJobs[name]) {
    const current_job = schedule.scheduledJobs[name];
    current_job.cancel();
  }

  const uniqueJobName = name;
  // Shedule job according to timed according to cron expression
  schedule.scheduleJob(uniqueJobName, '*/2 * * * * *', async () => {
    // Bar the foo..

    await isTriggerCheck(name);
    // await updateWFAction(name);
  });
  // Inspect the job object (i.E.: job.name etc.)

  //
};

const isTriggerCheck = async wfeventId => {
  // return new Promise(async (resolve, reject) => {
  try {
    await transaction(async client => {
      const sql = `SELECT * FROMF wms_workflow_eventlog WHERE wfeventid = $1 `;
      const {
        rows: [data],
      } = await client.query(sql, [wfeventId]);
      if (data) {
        console.log(data);
      }
      // resolve('Task status updated by cron');
    });
  } catch (e) {
    // reject('Failed! Task status updated by cron');
  }
  // });
};
// const updateWFAction = async wfeventId => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       await transaction(async client => {
//         const sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1, isfilesynced =$2 WHERE wfeventid = $3 `;
//         await client.query(sql, ['Hold', false, wfeventId]);
//         resolve('Task status updated by cron');
//       });
//     } catch (e) {
//       reject('Failed! Task status updated by cron');
//     }
//   });
// };
