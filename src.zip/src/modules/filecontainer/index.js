// import { config } from '../../config/restApi.js';
import { query } from '../../database/postgres.js';
// import { Service } from '../../httpClient/index.js';

// this function will add the typeset page of corresponding stage
export const filesContainer = async (req, res) => {
  try {
    const { woid } = req.body;
    const sql = `select * from woi where woid='${woid}'`;
    await query(sql);
    res.status(200).json({ message: 'success' });
  } catch (e) {
    console.log(e);
  }
};
