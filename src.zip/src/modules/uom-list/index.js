import { query } from '../../database/postgres.js';

export const getUomList = async (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  const offset = (pageNo - 1) * recordPerPage;

  let sql = '';
  try {
    sql = `select max(stageiterationcount),count(wfeventid),wfeventid FROM public.wms_uom_details WHERE (operationtype='Pending' or operationtype='Hold') and wfeventid=${reqData.wfEventId} group by wfeventid`;
    const values = await query(sql);
    const result = [];
    if (values[0].count > 0) {
      for (let index = 0; index < values.length; index++) {
        const data = values[index];
        sql = `SELECT * FROM public.wms_uom_details WHERE (operationtype='Pending' or operationtype='Hold') and wfeventid= ${data.wfeventid} and uomvalue is not null ORDER BY wfeventdetailid ASC limit ${recordPerPage} OFFSET ${offset}`;
        result.push(...(await query(sql)));
      }
    }
    res.status(200).json({ data: result, total: values[0].count });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const updateUomList = async (req, res) => {
  const reqData = req.body;

  try {
    let sql = `UPDATE  wms_workflow_eventlog_details SET uomvalue=${reqData.uomValue} WHERE wfeventdetailid =${reqData.wfEventDetailId}`;
    await query(sql);
    sql = `SELECT sum(uomvalue) as uomvalue from wms_workflow_eventlog_details WHERE wfeventid=${reqData.wfEventId}`;
    const data = await query(sql);
    const uom = data.length ? data[0].uomvalue : 0;
    sql = `UPDATE  wms_task_report_view SET uomvalue=${uom} WHERE wfeventid =${reqData.wfEventId} and userid ='${reqData.userId}'`;

    await query(sql);
    res
      .status(200)
      .json({ message: `UOM Value has been Updated successfully` });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
