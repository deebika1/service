/* eslint-disable */

import {
  getWorkflowPlaceHolders,
  getFileInfoDetails,
} from '../../task/fileDetails.js';
import { getFileTrnData, getFilesData } from '../../utils/tools/io.js';
import { getFileTrnDetails } from '../../utils/tools/utils.js';
import {
  getNewCopyBasePath,
  replacePlaceholders,
  _getFormattedGraphicPath,
} from '../../custom-uri/utils.js';

export const getIOFilesData = async (req, res) => {
  const {
    stage,
    activity,
    service,
    du,
    customer,
    fileId,
    toolsConfig,
    workOrderId,
    wfeventId,
    wfDefId,
    fileTypeId,
    activitymodeltypeflow,
    isOtherArticle,
    articleOrderSequence,
    isCamundaFlow,
  } = req.body;
  let { placeHolders } = req.body;
  try {
    if (isCamundaFlow) {
      const fileConfig = {};
      fileConfig.input = toolsConfig.files
        ? toolsConfig.files.filter(x => (x.fileFlowType || []).includes('IN'))
        : [];
      fileConfig.output = toolsConfig.files
        ? toolsConfig.files.filter(x => (x.fileFlowType || []).includes('OUT'))
        : [];
      const placeHolders = await getWorkflowPlaceHolders(wfeventId);
      const workorderDetails = {
        stage,
        activity,
        service,
        du,
        customer,
        workOrderId,
        fileId,
      };
      const fileDetails = await getFileInfoDetails({
        wfEventId: wfeventId,
        workOrderId,
        du,
        customer,
        service,
        stage,
        activity,
        typesId: [],
        activitymodeltypeflow,
        issuemstid: '',
        wfDefId,
        fileTypeId,
        isOtherArticle,
        articleOrderSequence,
      });
      res.status(200).json({
        in: await getFilesData({
          workorderDetails,
          IOFiles: fileConfig.input,
          fileDetails,
          placeHolders,
          isOtherArticle,
        }),
        out: await getFilesData({
          workorderDetails,
          IOFiles: fileConfig.output,
          fileDetails,
          placeHolders,
          isOtherArticle,
        }),
      });
    } else {
      // incomingDetails = placeHolders.ArticleTypeList;
      let fileType = toolsConfig.files.filter(a => a.name.includes('filename'));
      // New Payload Construction for Batch activity
      if (activitymodeltypeflow == 'Batch' && fileType?.length > 0) {
        let filesArray = [];
        const fileTypesInArray1 = new Set(
          toolsConfig.files.flatMap(item => item.fileTypes),
        );
        const matchingFileTypes = placeHolders.ArticleTypeList.filter(item =>
          fileTypesInArray1.has(parseInt(item.FileTypeId)),
        );
        matchingFileTypes.forEach(newItem => {
          toolsConfig.files.forEach(baseItem => {
            const newName = baseItem.name.replace(
              ';filename;',
              newItem.FileTypeName,
            );
            const newObject = {
              ...baseItem,
              name: newName, // Set the new name
              fileId: newItem.woincomingid,
            };
            filesArray.push(newObject);
          });
        });
        toolsConfig.files = filesArray;
      }

      let files = {
        in: [],
        out: [],
      };
      if (!placeHolders) {
        placeHolders = await getWorkflowPlaceHolders(wfeventId);
      }
      // const placeHolders = await getWorkflowPlaceHolders(wfeventId);
      const activityBasePath = await getNewCopyBasePath(placeHolders);
      let inFiles = toolsConfig.files.filter(
        file =>
          (file.fileFlowType || []).filter(x => x.toLocaleLowerCase() === 'in')
            .length > 0,
      );
      let outFiles = toolsConfig.files.filter(
        file =>
          (file.fileFlowType || []).filter(x => x.toLocaleLowerCase() === 'out')
            .length > 0,
      );

      for (const list of inFiles) {
        const name = await replacePlaceholders(list.name, placeHolders);
        // let isFolder = !!list.isFolder;
        if (!list?.isServerPath) {
          files.in.push({
            actualPath: activityBasePath,
            aliasKey: list.aliasKey,
            path: `${activityBasePath}${name}`,
            // Code command by anand for externa; task issue need to check where we use isFolderConcept
            // path: isFolder
            //   ? `${activityBasePath}${name}`
            //   : `${activityBasePath}`,
            fileId: list.fileId,
            fileName: name,
            fileType: 'Chapter',
          });
        } else {
          const data = {
            duid: du.id,
            customerid: customer.id,
            isServerPath: '',
          };
          const graphicPath = await _getFormattedGraphicPath(
            data,
            placeHolders,
            'genaral',
          );

          files.in.push({
            actualPath: graphicPath,
            aliasKey: list.aliasKey,
            path: graphicPath,
            fileId: fileId,
            fileName: name,
            fileType: 'Chapter',
          });
        }
      }

      for (const list of outFiles) {
        const name = await replacePlaceholders(list.name, placeHolders);
        // let isFolder = !!list.isFolder;
        files.out.push({
          actualPath: activityBasePath,
          aliasKey: list.aliasKey,
          path: `${activityBasePath}${name}`,
          // isFolder ? `${activityBasePath}${name}` : `${activityBasePath}`,
          fileId: list.fileId,
          fileName: name,
          fileType: 'Chapter',
        });
      }

      res.status(200).json({ in: files.in, out: files.out });
    }
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getIOFilesTrnData = async (req, res) => {
  const {
    stage,
    activity,
    service,
    du,
    customer,
    fileId,
    toolsConfig,
    workOrderId,
    wfeventId,
  } = req.body;
  try {
    const fileConfig = toolsConfig.files ? toolsConfig.files : {};
    const placeHolders = await getWorkflowPlaceHolders(wfeventId);
    const workorderDetails = {
      stage,
      activity,
      service,
      du,
      customer,
      workOrderId,
      fileId,
    };
    const fileDetails = await getFileInfoDetails({
      wfEventId: wfeventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId: [],
      activitymodeltypeflow: '',
      issuemstid: '',
      wfDefId: '',
      fileTypeId: '',
      isOtherArticle: false,
      articleOrderSequence: null,
    });
    const files = await getFilesData({
      workorderDetails,
      IOFiles: fileConfig.output,
      fileDetails,
      placeHolders,
      isInputProcessing: false,
    });
    const fileTrnDetails = await getFileTrnDetails(wfeventId);
    const fileTrnData = await getFileTrnData(files, fileTrnDetails);
    res.status(200).json(fileTrnData);
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
