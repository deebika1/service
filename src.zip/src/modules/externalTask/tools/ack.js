import path from 'path';
import { query } from '../../../database/postgres.js';
import { completeExternalTaskQueue } from '../task.js';
import { _updateDBForMultipleTool } from '../index.js';
import { _getActivityDetails } from '../../task/index.js';
import {
  getWorkflowPlaceHolders,
  getFileInfoDetails,
} from '../../task/fileDetails.js';
import { getFileTrnData, getFilesData } from '../../utils/tools/io.js';
import { getFileTrnDetails } from '../../utils/tools/utils.js';
import { updateFileTRNLog } from '../updatedb.js';
import {
  _getStageInfoFromCamunda,
  _updateStageInfoToCamunda,
  // _updateActivityStageInfoToCamunda,
} from '../../bpmn/listener/create.js';
import { _localFolderCopy } from '../../utils/local/index.js';
import logger from '../../utils/logs/index.js';

export const acknowledge = async (
  wfeventId,
  toolsId,
  data,
  is_success,
  getToolsEntry,
  remarks,
  dmsType,
  isBPCorrection,
) => {
  try {
    // Refer Jira - [NWMS-7679]
    // let filteredArray2 = [];
    let filteredArray3 = [];
    const sql = `select wfeventid, taskinstanceid,actualactivitycount from public.wms_workflow_eventlog where wfeventid = $1`;
    const eventDataResponse = await query(sql, [wfeventId]);
    const { taskinstanceid, actualactivitycount } = eventDataResponse[0];
    const activityDetails = await _getActivityDetails(wfeventId);
    const {
      du,
      customer,
      stage,
      activity,
      workOrderId,
      service,
      fileId,
      toolsConfig,
      activityConfig,
    } = activityDetails;
    const config =
      toolsConfig.tools && toolsConfig.tools[toolsId]
        ? toolsConfig.tools[toolsId]
        : {};
    const fileConfig = config.files ? config.files : {};
    const placeHolders = await getWorkflowPlaceHolders(wfeventId);
    const workorderDetails = {
      stage,
      activity,
      service,
      du,
      customer,
      workOrderId,
      fileId,
    };
    const fileDetails = await getFileInfoDetails({
      wfEventId: wfeventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId: [],
      activitymodeltypeflow: '',
      issuemstid: '',
      wfDefId: '',
      fileTypeId: '',
      isOtherArticle: false,
      articleOrderSequence: null,
    });
    const files = await getFilesData({
      dmsType,
      workorderDetails,
      IOFiles: fileConfig.filter(x => x.fileFlowType.includes('OUT')),
      fileDetails,
      placeHolders,
      isInputProcessing: false,
    });
    const fileTrnDetails = await getFileTrnDetails(wfeventId);
    const fileTrnData = await getFileTrnData(files, fileTrnDetails, dmsType);
    if (fileTrnData.length) await updateFileTRNLog(fileTrnData, wfeventId);
    // await _updateDb(wfeventId, null, fileTrnData);
    let isSuccess;
    let filteredArray1 = [];
    if (Array.isArray(activityDetails.toolsId)) {
      const filteredArray = getToolsEntry.filter(
        list => list.status == 'Success',
      );
      filteredArray1 = getToolsEntry.filter(
        list => list.status == 'Success' || list.status == 'Failure',
      );
      // filteredArray2 = getToolsEntry.filter(
      //   list =>
      //     list.status == 'Success' &&
      //     (list.isfileavailable == false || list.isfileavailable == true),
      // );

      // Refer Jira - [NWMS-7679]
      // filteredArray2 = getToolsEntry.filter(
      //   list =>
      //     (list.status == 'Success' || list.status == 'Failure') &&
      //     list.isfileavailable == true,
      // );
      filteredArray3 = getToolsEntry.filter(
        list => list.isfileavailable == false || list.status == 'Failure', // Refer Jira - [NWMS-7679]
      );

      if (
        filteredArray &&
        filteredArray.length > 0 &&
        filteredArray.length == activityDetails.toolsId.length
      ) {
        isSuccess = true;
      }

      // Refer Jira - [NWMS-7679]
      // else if (
      //   filteredArray2 &&
      //   filteredArray2.length > 0 &&
      //   filteredArray2.length == activityDetails.toolsId.length
      // ) {
      //   // } else if (filteredArray2.length > 0) {
      //   isSuccess = true;
      // }
      else {
        isSuccess = false;
      }
    } else {
      isSuccess = is_success;
    }

    const activityStatusForExternalTask = isSuccess ? 'Completed' : 'Failed';
    const externalTask = getServiceToUserTaskVariables(isSuccess);
    const camundaPayload = {
      workerId: 'System',
    };

    const externalvariable = {};
    externalvariable.__isSuccess__ = externalTask.__isSuccess__;
    externalvariable.__isActivityiteration__ = {
      type: 'String',
      value: actualactivitycount,
    };

    // springer books page target file copying
    if (activityDetails.wfId == 29) {
      const copyPageTarget = fileConfig.filter(
        x => x.fileFlowType.includes('OUT') && x.aliasKey == 'pagetarget',
      );

      if (isSuccess === true && copyPageTarget.length > 0) {
        const srcPath = path.dirname(
          files.flat().filter(list => list.aliasKey == 'pagetarget')[0].path,
        );
        let destBasePath = path.join(
          activityDetails.stage.basePath,
          'page_target/',
        );
        destBasePath = destBasePath.replace(/\\/g, '/').startsWith('//')
          ? destBasePath.replace(/\\/g, '/')
          : `/${destBasePath.replace(/\\/g, '/')}`;

        let resOfFileCopy = [];

        if (dmsType == 'local') {
          resOfFileCopy = await _localFolderCopy({ srcPath, destBasePath });
          console.log(resOfFileCopy);
        }
      }
    }

    // if (
    //   activityConfig &&
    //   Object.keys(activityConfig).includes('skipActivity') &&
    //   activityConfig.skipActivity.enable &&
    //   activityConfig.skipActivity.toolId == toolsId
    // )
    if (
      activityConfig &&
      Object.keys(activityConfig).includes('skipActivity') &&
      activityConfig.skipActivity.enable
    ) {
      const getStageInfo = await _getStageInfoFromCamunda(workOrderId);
      const stageInfo = JSON.parse(getStageInfo.__stageInfo.data.value);
      const fileObj = stageInfo.files;
      if (fileObj && fileObj.length > 0) {
        fileObj.forEach(cal => {
          if (cal.id == fileId) {
            cal.isBPCorrection = isBPCorrection || false;
          }
        });
        console.log(fileObj);
        stageInfo.files = fileObj;
      }
      // let sql = `SELECT taskinstanceid FROM public.wms_workflow_eventlog where wfeventid=$1`;
      // const taskInstanceId = await query(sql, [wfeventId]);
      await _updateStageInfoToCamunda(
        stageInfo,
        getStageInfo.processInstanceId,
      );
      // if(taskInstanceId && taskInstanceId.length >0){
      //     await _updateActivityStageInfoToCamunda(fileObj, taskInstanceId[0].taskinstanceid)
      // }
      // _updateActivityStageInfoToCamunda;
      const payload = {
        type: 'Json',
        value: JSON.stringify(stageInfo),
        valueInfo: {},
      };
      externalvariable.__stageInfo__ = payload;
      if (isBPCorrection != undefined) {
        externalvariable.__isEngineSuccess__ = {
          type: 'Boolean',
          value: isBPCorrection,
        };
      }
    }
    camundaPayload.variables = externalvariable;

    if (Array.isArray(activityDetails.toolsId) && filteredArray3.length == 0) {
      if (
        filteredArray1.length == activityDetails.toolsId.length ||
        filteredArray1.length >= activityDetails.toolsId.length
      ) {
        if (
          getToolsEntry &&
          getToolsEntry.length > 0 &&
          getToolsEntry[0].activitytype == 'External Task'
        ) {
          await _updateDBForMultipleTool(
            wfeventId,
            null,
            fileTrnData,
            activityStatusForExternalTask,
            remarks,
          );
        }

        await completeExternalTaskQueue(taskinstanceid, camundaPayload);
      }
    } else if (
      filteredArray3.length > 0 &&
      getToolsEntry[0].activitytype == 'External Task'
    ) {
      await _updateDBForMultipleTool(
        wfeventId,
        null,
        fileTrnData,
        activityStatusForExternalTask,
        remarks,
      );
      await completeExternalTaskQueue(taskinstanceid, camundaPayload);
    } else {
      if (
        getToolsEntry &&
        getToolsEntry.length > 0 &&
        getToolsEntry[0].activitytype == 'External Task'
      ) {
        await _updateDBForMultipleTool(
          wfeventId,
          null,
          fileTrnData,
          activityStatusForExternalTask,
          remarks,
        );
      }
      await completeExternalTaskQueue(taskinstanceid, camundaPayload);
    }
  } catch (error) {
    logger.info(
      error?.message ? error?.message : error,
      'ackExternalTask error',
    );
  }
};

export const getServiceToUserTaskVariables = isSuccess => {
  return {
    __isSuccess__: {
      type: 'Boolean',
      value: isSuccess,
    },
  };
};
