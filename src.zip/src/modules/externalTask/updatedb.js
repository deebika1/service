import { query } from '../../database/postgres.js';

export const updateFileTRNLog = (fileTrnData, wfeventId, client) => {
  return new Promise((resolve, reject) => {
    const values = [];
    fileTrnData.forEach(fileTrn => {
      const { path, uuid, fileId } = fileTrn;
      values.push(
        `(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`,
      );
    });
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES ${values};`;
    if (client) {
      client
        .query(sql)
        .then(() => {
          resolve();
        })
        .catch(e => {
          reject(e);
        });
    } else {
      query(sql)
        .then(() => resolve())
        .catch(e => reject(e));
    }
  });
};

export const updateEventLog = (
  wfeventId,
  log,
  client,
  activityStatusForExternalTask,
  isCamundaFlow = true,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = ``;
      let values = [];
      if (!isCamundaFlow && activityStatusForExternalTask === 'Failed') {
        sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1, externaltasklog = $2, tasktype = $3, userid = $4 WHERE wfeventid = $5`;
        values = ['Unassigned', log, 'User Task', null, wfeventId];
      } else {
        sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1, externaltasklog = $2 WHERE wfeventid = $3`;
        values = [activityStatusForExternalTask, log, wfeventId];
      }
      await client.query(sql, values);
      resolve(true);
    } catch (err) {
      reject(err);
    }
  });
};

export const updateEventLogDetails = (
  wfeventId,
  client,
  activityStatusForExternalTask,
  Remarks,
) => {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp,usercomments) VALUES ($1, $2, $3,$4)`;
    client
      .query(sql, [
        wfeventId,
        activityStatusForExternalTask,
        new Date(),
        Remarks,
      ])
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};
