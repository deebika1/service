import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';

const service = new Service();

export const fetchTaskId = async (req, res) => {
  const { activityInstanceId, processInstanceId, topicName, workOrderId } =
    req.body;
  try {
    const activityId = activityInstanceId.substr(
      0,
      activityInstanceId.lastIndexOf(':'),
    );
    const camundaPayload = {
      topicName,
      processInstanceId,
      activityId,
    };
    const url = config.camnundaNative.uri.externalTask.query;
    const { data: tasks } = await service.post(
      `${config.camnundaNative.base_url}${url}`,
      camundaPayload,
    );
    if (tasks.length) {
      const task = tasks.find(
        val => activityInstanceId == val.activityInstanceId,
      );
      if (task) {
        res.send(task.id);
      } else {
        throw new Error(
          `No matching External task found for Work Order ID ${workOrderId}`,
        );
      }
    } else {
      throw new Error(
        `No External task found for Work Order ID ${workOrderId}`,
      );
    }
  } catch (err) {
    res.status(400).send(err.message ? err.message : err);
  }
};

export const lockTask = async (req, res) => {
  const { taskInstanceId, camundaPayload } = req.body;
  try {
    const url = config.camnundaNative.uri.externalTask.lock.replace(
      /{{id}}/,
      taskInstanceId,
    );
    await service.post(
      `${config.camnundaNative.base_url}${url}`,
      camundaPayload,
    );
    res.send(true);
  } catch (err) {
    res.status(400).send(err.message ? err.message : err);
  }
};

export const completeTask = async (req, res) => {
  const { taskInstanceId, camundaPayload } = req.body;
  try {
    await completeExternalTaskQueue(taskInstanceId, camundaPayload);
    console.log('success');
    res.send(true);
  } catch (err) {
    res.status(400).send(err.message ? err.message : err);
  }
};

const completeExternalTaskQueueArray = [];
const completedExternalTask = { isRunning: false };
setInterval(() => {
  if (
    completeExternalTaskQueueArray.length > 0 &&
    completedExternalTask.isRunning == false
  ) {
    ExternalTaskFromArray();
  }
}, 10000);
const pushTocompleteExternalTask = function (ele) {
  completeExternalTaskQueueArray.push(ele);
};
const guid = function () {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4();
};
// eslint-disable-next-line no-promise-executor-return
const delay = ms => new Promise(resolve => setTimeout(() => resolve(), ms));
const ExternalTaskFromArray = function () {
  if (completeExternalTaskQueueArray.length > 0) {
    completedExternalTask.isRunning = true;
    const msg = completeExternalTaskQueueArray.shift();
    completeExternalTask(msg.taskInstanceId, msg.camundaPayload)
      .then(data => {
        completedExternalTask[msg.id] = {
          id: msg.id,
          isSuccess: true,
          data,
        };
      })
      .catch(err => {
        completedExternalTask[msg.id] = {
          id: msg.id,
          isSuccess: false,
          data: err,
        };
      })
      .finally(() => {
        completedExternalTask.isRunning = false;
      });
  }
};

export const completeExternalTaskQueue = (taskInstanceId, camundaPayload) => {
  return new Promise(async (resolve, reject) => {
    const id = guid();
    pushTocompleteExternalTask({
      id,
      taskInstanceId,
      camundaPayload,
    });
    while (
      [
        ...new Set(
          Object.keys(completedExternalTask).map(o => completedExternalTask[o]),
        ),
      ].filter(x => x.id == id) == 0
    ) {
      await delay(1000);
    }
    const completedMessage = [
      ...new Set(
        Object.keys(completedExternalTask).map(o => completedExternalTask[o]),
      ),
    ].filter(x => x.id == id);
    delete completedExternalTask[id];
    if (completedMessage[0].isSuccess) {
      resolve(completedMessage[0]);
    } else {
      reject(completedMessage[0]);
    }
  });
};

export const completeExternalTask = (taskInstanceId, camundaPayload) => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.camnundaNative.uri.externalTask.complete.replace(
        /{{id}}/,
        taskInstanceId,
      );
      await service.post(
        `${config.camnundaNative.base_url}${url}`,
        camundaPayload,
      );
      resolve(true);
    } catch (e) {
      const msg = e?.message?.data?.message;

      reject(msg);
    }
  });
};
