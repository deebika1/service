import { query, transaction } from '../../database/postgres.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';

export const getAllTask = async (req, res) => {
  console.log('uiinnnn');
  const reqData = req.body;

  // itrack changes involved
  let isnonwms = false;
  const qryflow = `select flowtype from public.trn_customerflowtype_config where duid = $1 limit 1`;
  const getflowtype = await query(qryflow, [reqData.duId]);

  if (
    getflowtype &&
    getflowtype.length > 0 &&
    getflowtype[0].flowtype == 'nonwms'
  ) {
    isnonwms = true;
  } else {
    isnonwms = false;
  }

  if (reqData.userid == '') {
    res.status(400).send({ message: 'Userid should not be empty' });
  } else if (reqData.type == '') {
    res.status(400).send({ message: 'Type should not be empty' });
  } else if (reqData.pageNo == '') {
    res.status(400).send({ message: 'Page number should not be empty' });
  } else if (reqData.recordPerPage == '') {
    res.status(400).send({ message: 'Record per page should not be empty' });
  } else if (isnonwms == true) {
    let data;
    if (reqData.type == 'query') {
      data = await getQueryNonwms(reqData);
    } else {
      data = await getRecordsnonwms(reqData);
    }

    if (data.length > 0) {
      const total = data.length;
      res.status(200).json({ data, total });
    } else {
      res.status(200).json({ data: [], message: 'No data found' });
    }
    // logic here
  } else if (isnonwms == false) {
    let condition = '';
    if (
      reqData.type === 'all' ||
      reqData.type === 'myTask' ||
      reqData.type === 'despatch'
    ) {
      const { filtervalues } = reqData;
      const getNotInArray = filtervalues.filter(
        data => data.type === 'where' && data.operator !== 'IN',
      );
      const seen = {};
      const resultOfgroupBy = filtervalues.filter(entry => {
        if (entry.operator === 'IN') {
          let previous;
          if (Object.prototype.hasOwnProperty.call(seen, entry.name)) {
            previous = seen[entry.name];
            previous.value.push(entry.value);
            return false;
          }
          if (!Array.isArray(entry.value)) {
            entry.value = [entry.value];
          }
          seen[entry.name] = entry;
          return true;
        }
        return false;
      });

      const mergedArray = [].concat(getNotInArray, resultOfgroupBy);
      mergedArray.forEach((item, i) => {
        if (item.type === 'where') {
          let statusValue = '';
          if (Array.isArray(item.value)) {
            item.value.forEach((status, vi) => {
              statusValue +=
                item.value.length - 1 !== vi ? `'${status}' ,` : `'${status}'`;
            });
          }
          condition +=
            mergedArray.length - 1 !== i
              ? Array.isArray(item.value)
                ? `${item.name} ${item.operator} (${statusValue})  AND `
                : item.value === ''
                ? `${item.name} ${item.operator} AND `
                : `${item.name} ${item.operator} ${
                    item.operator === 'IN'
                      ? `('${item.value}')`
                      : `'${item.value}'`
                  } AND `
              : Array.isArray(item.value)
              ? `${item.name} ${item.operator} (${statusValue})`
              : item.value === ''
              ? `${item.name} ${item.operator} `
              : `${item.name} ${item.operator} ${
                  item.operator === 'IN'
                    ? `('${item.value}')`
                    : `'${item.value}'`
                }  `;
        }
      });

      console.log(condition, 'conditionconditioncondition111');
    } else if (reqData.type === 'filter') {
      const {
        filtervalues: { filtervalues, page, filterType, dateObjects },
      } = reqData;

      if (page === 'allTask' || page === 'myTask') {
        const output = [];

        filtervalues.forEach(item => {
          if (item.type !== 'orderby') {
            const existing = output.filter(function (v) {
              return v.name == item.name;
            });

            if (existing.length) {
              const existingIndex = output.indexOf(existing[0]);
              output[existingIndex].value = output[existingIndex].value.concat(
                item.value,
              );
            } else {
              if (typeof item.value === 'string')
                item.value = item.value ? [item.value] : [];
              output.push(item);
            }
          }
        });

        output.forEach(data => {
          data.setValue = '';
          data.value.forEach((data1, i) => {
            data.setValue += `'${data1}' ${
              data.value.length - 1 !== i ? ',' : ''
            }`;
          });
        });

        output.forEach((item, i) => {
          if (item.name !== 'duedate') {
            condition +=
              output.length - 1 !== i
                ? item.setValue == ''
                  ? `${item.name} ${item.operator} AND `
                  : `${item.name} ${item.operator} (${item.setValue}) AND `
                : item.setValue == ''
                ? `${item.name} ${item.operator} `
                : `${item.name} ${item.operator} (${item.setValue}) `;
          }
        });

        if (filterType === 'date') {
          condition += Object.keys(dateObjects).length ? 'AND' : '';
          condition += ` duedate BETWEEN '${dateObjects.startDate}' AND '${dateObjects.endDate}' `;
        }
      }
    }
    if (reqData.roleid == '1' || reqData.roleid == '9') {
      condition += ` AND (userid='${reqData.userid}' OR activitystatus IN ('Unassigned', 'Pending') )`;
    }
    let skills = '';
    if (
      reqData.type != 'query' &&
      reqData.filtervalues.fiterValueType !== 'query'
    ) {
      reqData.skillid.forEach((skill, i) => {
        skills += `'${skill}' ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
      });
      const data = await getRecords(reqData, condition, skills, res);
      if (data.length > 0) {
        const total = data.length;
        res.status(200).json({ data, total });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
      // const sqlFoTotal = `SELECT count(1) FROM public.wms_tasklist WHERE (baseduid IN (${
      //   reqData.duId
      // }) OR assignedduid IN (${reqData.duId})) ${
      //   skills ? `AND skillid IN (${skills})` : ''
      // } ${condition ? `${'AND '}${condition}` : ''}`;
      //

      // query(sqlFoTotal)
      //   .then(async totalRecords => {
      //
      //     if (totalRecords.length > 0) {
      //       const data = await getRecords(reqData, condition, skills, res);
      //       if (data.length > 0) {
      //
      //         const total = totalRecords.length;
      //         res.status(200).json({ data, total });
      //       } else {
      //         res.status(200).json({ data: [], message: 'No data found' });
      //       }
      //     } else {
      //       res.status(200).json({ data: [] });
      //     }
      //   })
      //   .catch(error => {
      //     res.status(400).send({ message: error });
      //   });
    } else {
      console.log(condition, 'conditinforquery');
      console.log(reqData, 'oosdkfsjdfkj');
      reqData.skillid.forEach((skill, i) => {
        skills += `${skill} ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
      });
      const sqlFoTotal = `SELECT * FROM public.wms_workorder_query_list where querystatus in ('Open','Re-open') and  duid in (${reqData.duId}) and (queryid in
            (select queryid from wms_query_assigned where skillid in (${skills})) or createdby='${reqData.userid}')`;
      // }')  ${condition ? `${'AND '}${condition}` : ''}`;

      console.log(sqlFoTotal, 'sql for count quereyyy');
      query(sqlFoTotal)
        .then(totalRecords => {
          console.log(totalRecords, 'recoof');
          if (totalRecords.length > 0) {
            getRecordForQuery(reqData, totalRecords.length, '', skills, res);
          } else {
            res.status(200).json({ data: [] });
          }
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    }
  }
};

export const getNewAllTask = (req, res) => {
  const { skillid, userid, roleid, duId } = req.body;

  const sql = `select * from wms_tasklist where duid='${duId}' and (userid = '${userid}' or userid is null) and roleid = ${roleid}
                and skillid in (${skillid})`;

  query(sql)
    .then(data => {
      res.status(200).json({ data, issuccess: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const getRecordForQuery = (reqData, total, condition, skills, res) => {
  const { recordPerPage, duId } = reqData;
  // const offset = (pageNo - 1) * recordPerPage;

  const numOfPages = Math.ceil(total / recordPerPage);
  const sql = `  SELECT * FROM public.wms_workorder_query_list where querystatus in ('Open','Re-open') and duid in (${duId})  and (queryid in
    (select queryid from wms_query_assigned where skillid in (${skills})) or createdby='${
    reqData.userid
  }')  ${condition ? `${'AND '}${condition}` : ''} `;
  // LIMIT ${recordPerPage ? recordPerPage : 100} OFFSET ${offset}
  console.log(sql);
  query(sql)
    .then(data => {
      res.status(200).json({ data, total, numOfPages });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const getRecords = async (reqData, condition, skills) => {
  return new Promise(async resolve => {
    const { filtervalues } = reqData;
    const arrayValues =
      reqData.type === 'filter' ? filtervalues.filtervalues : filtervalues;
    let orderBy = '';
    arrayValues.forEach(item => {
      if (item.type === 'orderby') {
        const splitOperator = item.operator.split(' ');

        orderBy =
          splitOperator &&
          `${splitOperator[0]} ${splitOperator[1]} ${item.value.toString()} ${
            splitOperator[splitOperator.length - 1]
          }`;
      }
    });
    const values = [];
    if (reqData.duId == '92') {
      if (reqData.viewName == 'All Task') {
        condition = `activitystatus NOT IN ('Completed' ,'Rejected')  AND (userid='${reqData.userid}' OR 
      activitystatus IN ('Unassigned','Pending')) `;
      } else if (reqData.viewName == 'My Task') {
        condition = `activitystatus NOT IN ('Completed' ,'Rejected')  AND (userid='${reqData.userid}') `;
      }
    }

    const includeCTE2 = reqData.duId == '95';
    const sql = `with cte as (SELECT DISTINCT ON (wms_workflow_eventlog.wfeventid)
    wms_workorder_service.baseduid,
    wms_workorder_service.assignedduid,
    wms_workorder_service.serviceid,
    wms_workorder_service.wfid,
    wms_workflow.config AS wfconfig,
    wms_workflow.wf_definitionid,
    wms_workorder.jobtype,
    wms_workorder.wotype,
    wms_mst_service.servicename,
    org_mst_deliveryunit.duname AS assignedduname,
    wms_workflow_eventlog.wfeventid,
    wms_workflow_eventlog.userid,
    wms_workflow_eventlog.skillid,
    wms_workflow_eventlog.wfdefid,
    wms_workflow_eventlog.activitystatus,
    COALESCE(wms_workflow_eventlog.updated_date,wms_workflow_eventlog.createdon) AS createddate,
    wms_workflow_eventlog.activityinstanceid,
    wms_workflow_eventlog.taskinstanceid,
    wms_workflow_eventlog.stageiterationcount,
    wms_workflow_eventlog.activityiterationcount,
    wms_workflow_eventlog.priority,
    wms_workflow_eventlog.activitycount,
    wms_workflow_eventlog.eventdata,
    wms_workflow_eventlog.parentinstanceid,
    wms_workflow_eventlog.actualactivitycount,
    wms_mst_priority.priority AS priorityname,
    wms_workorder.workorderid,
    wms_workorder.customerid,
    org_mst_customer.customername,
    wms_workorder.itemcode,
    wms_workorder.title,
    wms_workorder.printisbn,
    wms_workorder.totalchaptercount,
    wms_workflowdefinition.activityalias,
    wms_workflowdefinition.stageid,
    wms_workflowdefinition.activityid,
    wms_workflowdefinition.instancetype,
    wms_workflowdefinition.formjson,
    wms_workflowdefinition.config,
    wms_workflowdefinition.fileconfig,
    wms_workflowdefinition.itracksconfig,
    wms_workflowdefinition.toolrunningstatus,
    wms_workflowdefinition.rejectedactivitytype,
    wms_workflowdefinition.activitymodeltype,
    wms_workflowdefinition.activitymodeltypeflow,
    wms_workflowdefinition.sequence,
    wms_user.username,
    wms_workorder_incomingfiledetails.filename,
    COALESCE(wms_workorder_stage.revisedenddatetime, wms_workorder_stage.plannedenddate) AS duedate,
    pp_mst_filetype.filetype,
    wms_workorder_incomingfiledetails.mspages,
    wms_workorder_incomingfiledetails.estimatedpages,
    wms_workorder_incomingfiledetails.imagecount,
    wms_workorder_incomingfiledetails.tablecount,
    wms_workorder_incomingfiledetails.equationcount,
    wms_workorder_incomingfiledetails.newfiletype,
    wms_workorder_incomingfiledetails.runonfilesequence,
    wms_workorder_incomingfiledetails.articleordersequence,
    wms_workorder_incomingfiledetails.filetypeid,
    wms_userrole.roleid,
    wms_workorder.doinumber,
    pp_mst_journal.journalacronym,
    pp_mst_journal.pdfmerging,
    pp_mst_journal.otherdetails,
    wms_workflowdefinition.activitytype,
    dms_master.dmstype,
    wms_mst_stage.stagename,
    wms_mst_activity.activityname,
    wms_mst_screens.screenmappingpath AS screenpath,
    wms_mst_activity.isdespatchactivity,
    wms_mst_activity.iscompletiontriggeractivity,
    wms_mst_complexity.complexityid,
    wms_mst_complexity.complexity,
    wms_mst_jobnorms.jobnormsid,
    wms_mst_jobnorms.jobnormsname,
    wms_workorder.journalid,
    wms_workorder.divisionid,
    wms_workorder.subdivisionid,
    org_mst_deliveryunit.duid,
    wms_workorder.jobcardid,
    wms_workorder_incomingfiledetails.subjobid,
    wms_workorder_stage.typesetpages,
    wms_workflow_eventlog.worksheetid,
    wms_workorder_incomingfiledetails.woincomingfileid,
    wms_workorder.hardbackisbn,
    wms_workflowdefinition.resettoactivityid,
    wms_workflow_eventlog.isinstancerunning,
    wms_workorder.otherfield,
    wms_workorder.isonlineissue,
    wms_workorder.issuemstid,
    wms_workorder.ismscompleted,
    wms_workflowdefinition.pubflowconfig,
    wms_workorder.issuenumber,
    wms_workorder.volumenumber,
    ism.issuename,
    wms_workflow.iscamundaflow,
    wms_workflowdefinition.nextactivityid,
    wms_workflowdefinition.filetypeskipfornextactivity,
    wms_workorder.flowtype,
    wms_workorder_additionalinfo.pdfless,
     rej.rejfrom,
    rej.rejby,
     wwed.usercomments,
    wms_workflowdefinition.parallelactivityconfig,
    wms_workflowdefinition.parallelfiletypeskipfornextactivity,
    wms_workorder_incomingfiledetails.filesequence
FROM wms_workorder_service
JOIN wms_workflow_eventlog ON wms_workflow_eventlog.workorderid = wms_workorder_service.workorderid  and wms_workflow_eventlog.activitystatus NOT IN ('Completed' ,'Rejected')
JOIN wms_workorder ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid AND wms_workorder.isactive <> false
LEFT JOIN pp_mst_issue_master AS ism ON ism.issuemstid = wms_workorder.issuemstid
LEFT JOIN wms_user ON wms_user.userid::text = wms_workflow_eventlog.userid::text
JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
JOIN wms_workorder_stage ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid
                           AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid
                           AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid
                           AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder_service.assignedduid
                           AND (org_mst_deliveryunit.duid = wms_user.duid OR wms_user.duid IS NULL)
JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workorder_service.serviceid
JOIN wms_workflow ON wms_workflow.wfid = wms_workorder_service.wfid
JOIN org_mst_customer ON org_mst_customer.customerid = wms_workorder.customerid
LEFT JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
LEFT JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
LEFT JOIN wms_mst_screens ON wms_mst_screens.screenid = wms_workflowdefinition.screenid
LEFT JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
LEFT JOIN wms_mst_priority ON wms_mst_priority.priorityid = wms_workflow_eventlog.priority
LEFT JOIN pp_mst_filetype ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
LEFT JOIN wms_userrole ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
LEFT JOIN pp_mst_journal ON pp_mst_journal.journalid = wms_workorder.journalid
LEFT JOIN wms_mst_jobnorms ON wms_mst_jobnorms.jobnormsid = wms_workorder_service.jobnormsid
LEFT JOIN wms_mst_complexity ON wms_mst_complexity.complexityid = wms_workorder_service.complexityid
LEFT JOIN wms_workorder_additionalinfo ON wms_workorder_additionalinfo.workorderid = wms_workorder.workorderid
LEFT JOIN dms_master ON dms_master.dmsid = wms_workorder.dmsid 
LEFT JOIN (
    SELECT wfeventid, MAX(wfeventdetailid) AS latest_detail_id
    FROM wms_workflow_eventlog_details
    GROUP BY wfeventid
) latest_wwed ON latest_wwed.wfeventid = wms_workflow_eventlog.wfeventid
LEFT JOIN wms_workflow_eventlog_details wwed ON wwed.wfeventid = latest_wwed.wfeventid
                                         AND wwed.wfeventdetailid = latest_wwed.latest_detail_id    
LEFT JOIN LATERAL (
    SELECT rejby, rejfrom
    FROM public.get_rejected_workflow_events(wms_workorder.workorderid::int)
    WHERE wms_workorder.customerid = 8
) AS rej ON true    
      WHERE (wms_workorder_service.baseduid IN (${
        reqData.duId
      }) OR wms_workorder_service.assignedduid IN (${reqData.duId}))  ${
      skills ? `AND wms_workflow_eventlog.skillid IN (${skills})` : ''
    })
        ${
          includeCTE2
            ? `
          , cte2 AS (
            SELECT 
              ROW_NUMBER() OVER (PARTITION BY articleid, stage, activity, woid ORDER BY id DESC) AS frno, 
              id,
              articleid,
              isactive AS prblmtskstatus, 
              woid, 
              stage,
              activity
            FROM trn_problemtask 
            WHERE woid IN (SELECT workorderid FROM cte)
          )
          `
            : ''
        }
          SELECT cte.* ${includeCTE2 ? ', cte2.prblmtskstatus' : ''}
          FROM cte
          ${
            includeCTE2
              ? `
          LEFT JOIN cte2 ON cte2.woid = cte.workorderid 
              AND cte2.stage = cte.stagename 
              AND cte2.activity = cte.activityalias 
              AND cte2.frno = 1
          `
              : ''
          }

${
  condition ? `${'where '}${condition} AND duid = ${reqData.duId}` : ''
} ${orderBy}`;

    const data = await query(sql, values);
    // updated for fileconfig restructure
    data.forEach(item => {
      item.fileconfig = ReStructureFileConfig(item.fileconfig);
    });
    resolve(data);
  });
};

export const assigneeList = (req, res) => {
  const reqData = req.body;
  const sql = `SELECT DISTINCT ON (wms_user.userid) wms_user.userid as value, CONCAT(wms_user.username, ' (', wms_user.userid, ')') as label FROM public.wms_user 
    JOIN wms_userskill ON wms_userskill.userid = wms_user.userid 
    JOIN wms_userrole ON wms_userrole.userid = wms_user.userid 
    WHERE duid=${reqData.duId} AND wms_userskill.skillid IN (${reqData.skillid}) AND wms_userrole.roleid = 3 AND wms_userrole.isactive = true AND wms_userskill.isactive = true `;

  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const saveView = async (req, res) => {
  const {
    userid,
    entityId,
    viewname,
    viewtype,
    filtervalues,
    columnfields,
    screenId,
  } = req.body;
  try {
    await transaction(async client => {
      let sql = `INSERT INTO public.wms_mst_view_config(
            userid, entityid, viewname, viewtype, filtervalues, columnfields, screenId)
            VALUES ($1, $2, $3, $4, $5, $6, $7) returning viewid`;
      const {
        rows: [data],
      } = await client.query(sql, [
        userid,
        entityId,
        viewname,
        viewtype,
        JSON.stringify(filtervalues),
        JSON.stringify(columnfields),
        screenId,
      ]);
      sql = `INSERT INTO public.wms_viewconfig_permissions(
                 viewid, roleid, skillid)
                VALUES ($1, $2, $3);`;
      await client.query(sql, [data.viewid, null, null]);
      res.status(200).json({ message: 'View has been saved successfully' });
    });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const deleteView = async (req, res) => {
  const { viewid } = req.body;
  try {
    await transaction(async client => {
      let sql = `DELETE FROM wms_viewconfig_permissions WHERE viewid = $1`;
      await client.query(sql, [viewid]);
      sql = `DELETE FROM wms_mst_view_config WHERE viewid = $1`;
      await client.query(sql, [viewid]);
      res.status(200).json({ message: 'View deleted successfully' });
    });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const getFilteredList = (req, res) => {
  const reqData = req.body;
  let condition = '';
  if (
    reqData.type === 'all' ||
    reqData.type === 'myTask' ||
    reqData.type === 'despatch' ||
    reqData.type === 'workorder'
  ) {
    const { filtervalues } = reqData;

    const getNotInArray = filtervalues.filter(
      data => data.type === 'where' && data.operator !== 'IN',
    );
    const seen = {};
    const resultOfgroupBy = filtervalues.filter(entry => {
      if (entry.operator === 'IN') {
        let previous;
        if (Object.prototype.hasOwnProperty.call(seen, entry.name)) {
          previous = seen[entry.name];
          previous.value.push(entry.value);
          return false;
        }
        if (!Array.isArray(entry.value)) {
          entry.value = [entry.value];
        }
        seen[entry.name] = entry;
        return true;
      }
      return false;
    });

    const mergedArray = [].concat(getNotInArray, resultOfgroupBy);
    mergedArray.forEach((item, i) => {
      if (item.type === 'where') {
        let statusValue = '';
        if (Array.isArray(item.value)) {
          item.value.forEach((status, vi) => {
            statusValue +=
              item.value.length - 1 !== vi ? `'${status}' ,` : `'${status}'`;
          });
        }
        condition +=
          mergedArray.length - 1 !== i
            ? Array.isArray(item.value)
              ? `${item.name} ${item.operator} (${statusValue})  AND `
              : item.value === ''
              ? `${item.name} ${item.operator} AND `
              : `${item.name} ${item.operator} ${
                  item.operator === 'IN'
                    ? `('${item.value}')`
                    : `'${item.value}'`
                } AND `
            : Array.isArray(item.value)
            ? `${item.name} ${item.operator} (${statusValue})`
            : item.value === ''
            ? `${item.name} ${item.operator} `
            : `${item.name} ${item.operator} ${
                item.operator === 'IN' ? `('${item.value}')` : `'${item.value}'`
              }  `;
      }
    });
  }

  const condition1 = `LOWER(${
    reqData.columnName
  }) like '%${reqData.text.toLowerCase()}%'`;
  let skills = '';

  let sql = '';
  if (reqData.type !== 'query') {
    reqData.skillid.forEach((skill, i) => {
      skills += `'${skill}' ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
    });
    sql = `SELECT DISTINCT ${
      reqData.columnName
    } FROM public.wms_tasklist WHERE ${condition1} AND (baseduid IN (${
      reqData.duId
    }) OR assignedduid IN (${reqData.duId})) AND skillid IN (${skills})  ${
      condition ? `${'AND '}${condition}` : ''
    } ORDER BY ${reqData.columnName} ASC`;
  } else {
    reqData.skillid.forEach((skill, i) => {
      skills += `${skill} ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
    });
    sql = `SELECT DISTINCT ${reqData.columnName} FROM public.wms_workorder_query_list where querystatus in ('Open','Re-open') and duid in (${reqData.duId}) and (queryid in
        (select queryid from wms_query_assigned where skillid in (${skills})) or createdby='${reqData.userid}') and ${condition1}`;
  }
  console.log(sql);
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const test1 = (req, res) => {
  const getData = req.body;
  let condition = '';
  getData.filterObj.forEach((item, i) => {
    condition +=
      getData.filterObj.length - 1 !== i
        ? `${item.name} = '${item.value}' AND `
        : `${item.name} = '${item.value}'`;
  });

  const sql = `SELECT * FROM public.wms_tasklist WHERE ${condition}`;

  query(sql)
    .then(data => {
      // updated for fileconfig restructure
      data.forEach(item => {
        item.fileconfig = ReStructureFileConfig(item.fileconfig);
      });
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getPriorityList = (req, res) => {
  // const reqData = req.body;

  const sql = `SELECT priorityid as value, priority as label FROM wms_mst_priority`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const getRecordsnonwms = async reqData => {
  return new Promise(async resolve => {
    try {
      let joincondition = '';
      let wherecondition = '';
      let activitystatuscondition = '';
      let activitynamecondition = '';
      let subjobclaimedcondition = '';
      let iscustomerdespatch = '';

      if (reqData.viewName === 'All Task') {
        // condition = `activitystatus NOT IN ('Completed' ,'Rejected')`;
        joincondition = ' LEFT ';
        wherecondition = `and coalesce (fcte.activityclaimedusers,'')  != '${reqData.userid}'`;
        activitystatuscondition = ` AND wms_workflow_eventlog.activitystatus NOT IN ('Completed' ,'Rejected') `;

        // subjobclaimedcondition = ` AND scu.userid != '${reqData.userid}'`;
      } else if (reqData.viewName === 'My Task') {
        // condition = `activitystatus NOT IN ('Completed' ,'Rejected') AND subev.assigneduserid = '${reqData.userid}'`;
        if (
          reqData.roleid == '1' ||
          reqData.roleid == '9' ||
          reqData.roleid == '47'
        ) {
          joincondition = ' LEFT ';
          // wherecondition = '';
          activitystatuscondition = ` AND wms_workflow_eventlog.activitystatus NOT IN ('Completed' ,'Rejected') `;

          // subjobclaimedcondition = ` AND coalesce (scu.userid,'') = coalesce (scu.userid,'') `;
          iscustomerdespatch = ` AND coalesce((wms_workflowdefinition.itracksconfig->>'isCustomer')::boolean,false) = true `;
        } else {
          subjobclaimedcondition = ` AND coalesce (scu.userid,'') =  '${reqData.userid}' `;
          activitystatuscondition = ` AND wms_workflow_eventlog.activitystatus NOT IN ('Completed' ,'Rejected') `;
        }
      } else if (reqData.type == 'all' && reqData.viewName === 'Un Assigned') {
        joincondition = ' LEFT ';
        //  wherecondition = ` coalesce(fcte.activityclaimedusers,'')  = coalesce(fcte.activityclaimedusers,'')  `;
        activitystatuscondition = ` AND wms_workflow_eventlog.activitystatus IN ('Unassigned' ,'Pending') `;

        activitynamecondition = ` AND wms_mst_activity.activityname NOT IN ('Despatch' ,'Wait for Author Feedback' ,'Collation') `;
        // subjobclaimedcondition = ` AND coalesce (scu.userid,'') = coalesce (scu.userid,'') `;
      } else if (reqData.type == 'all' && reqData.viewName === 'Assigned') {
        joincondition = ' LEFT ';
        // wherecondition = ` coalesce(fcte.activityclaimedusers,'') = coalesce(fcte.activityclaimedusers,'') `;
        activitystatuscondition = ` AND wms_workflow_eventlog.activitystatus IN ('Work in progress' ,'YTS' ,'Hold') `;

        activitynamecondition = ` AND wms_mst_activity.activityname NOT IN ('Despatch' ,'Wait for Author Feedback' ,'Collation') `;
        // subjobclaimedcondition = ` AND coalesce (scu.userid,'') = coalesce (scu.userid,'') `;
      } else if (reqData.type == 'all' && reqData.viewName === 'Completed') {
        joincondition = ' LEFT ';
        // wherecondition = ` coalesce(fcte.activityclaimedusers,'') = coalesce(fcte.activityclaimedusers,'') `;
        activitystatuscondition = ` AND wms_workflow_eventlog.activitystatus IN ('Completed') `;

        // activitynamecondition = ` AND activityname NOT IN ('Despatch' ,'Wait for Author Feedback' ,'Collation') `;
        // subjobclaimedcondition = ` AND coalesce (scu.userid,'') = coalesce (scu.userid,'') `;
      }
      //  const orderBy = `ORDER BY wfeventid, createddate,priority ASC`;
      const values = [];

      const sql = `with maincte as (
        SELECT            
          wms_workorder.workorderid,
          wms_workorder.itemcode,
          wms_workorder.title,
          wms_workorder.customerid,
          org_mst_customer.customername,
          wms_workorder.duid as baseduid,
          wms_workorder.duid as assignedduid,
          1 as serviceid,
          wms_mst_stage.stagename,
          wms_workorder_stage.status ,
          wms_workflowdefinition.stageid,
          wms_mst_activity.activityname,
          wms_workflowdefinition.activityid,
          wms_workflowdefinition.activityalias,
          wms_workorder.wfid,
          wms_workflow.config AS wfconfig,
          wms_workflow.wf_definitionid,
          wms_workorder.jobtype,
          wms_workorder.wotype,
          'Typesetting' as servicename,
          org_mst_deliveryunit.duname AS assignedduname,
          wms_workflow_eventlog.wfeventid,
          wms_workflow_eventlog.userid,
          wms_workflow_eventlog.skillid,
          wms_workflow_eventlog.wfdefid,
          wms_workflow_eventlog.activitystatus,
          wms_workflow_eventlog.createdon as createddate,
          wms_workflow_eventlog.activityinstanceid,
          wms_workflow_eventlog.taskinstanceid,
          wms_workflow_eventlog.stageiterationcount,
          wms_workflow_eventlog.activityiterationcount,
          wms_workflow_eventlog.priority,
          wms_workflow_eventlog.activitycount,
          wms_workflow_eventlog.eventdata,
          wms_workflow_eventlog.parentinstanceid,
          wms_workflow_eventlog.actualactivitycount,
          wms_mst_priority.priority AS priorityname,  
          wms_workorder.printisbn,
          wms_workorder.totalchaptercount,  
          wms_workflowdefinition.instancetype,
          wms_workflowdefinition.formjson,
          wms_workflowdefinition.config,
          wms_workflowdefinition.fileconfig,
          wms_workflowdefinition.itracksconfig,
          wms_workflowdefinition.toolrunningstatus,
          wms_workflowdefinition.rejectedactivitytype,
          wms_workflowdefinition.activitymodeltype,
          wms_workflowdefinition.activitymodeltypeflow,
          wms_workflowdefinition.sequence,
          wms_user.username,
          wms_workorder_incomingfiledetails.filename,
          coalesce(wms_workorder_stage.revisedenddatetime, wms_workorder_stage.plannedenddate) AS duedate,
          to_char(coalesce(wms_workorder_stage.revisedenddatetime, wms_workorder_stage.plannedenddate) , 'yyyy-mm-dd HH24:mi:ss') AS itrackduedate,
          pp_mst_filetype.filetype,
          wms_workorder_incomingfiledetails.mspages,
          wms_workorder_incomingfiledetails.estimatedpages,
          wms_workorder_incomingfiledetails.imagecount,
          wms_workorder_incomingfiledetails.tablecount,
          wms_workorder_incomingfiledetails.equationcount,
          wms_workorder_incomingfiledetails.newfiletype,
          wms_workorder_incomingfiledetails.runonfilesequence,
          wms_workorder_incomingfiledetails.articleordersequence,
          wms_workorder_incomingfiledetails.filetypeid,
          wms_userrole.roleid,
          wms_workorder.doinumber,
          coalesce(pp_mst_journal.journalacronym, wms_workorder.itemcode) as journalacronym ,
          pp_mst_journal.pdfmerging,
          wms_workflowdefinition.activitytype,
          dms_master.dmstype,  
          wms_mst_screens.screenmappingpath AS screenpath,
          wms_mst_activity.isdespatchactivity,
          wms_mst_activity.iscompletiontriggeractivity,
          wms_mst_complexity.complexityid,
          wms_mst_complexity.complexity,
          0 as jobnormsid,
          '' as jobnormsname,
          wms_workorder.journalid,
          wms_workorder.divisionid,
          wms_workorder.subdivisionid,
          org_mst_deliveryunit.duid,
          wms_workorder.jobcardid,
          wms_workorder_incomingfiledetails.subjobid,
          wms_workorder_stage.typesetpages,
          wms_workflow_eventlog.worksheetid,
          wms_workorder_incomingfiledetails.woincomingfileid,
          wms_workorder.hardbackisbn,
          wms_workflowdefinition.resettoactivityid,
          wms_workflow_eventlog.isinstancerunning,
          wms_workorder.otherfield,
          wms_workorder.isonlineissue,
          wms_workorder.issuemstid,
          wms_workorder.ismscompleted,
          wms_workflowdefinition.pubflowconfig,
          wms_workorder.issuenumber,
          wms_workorder.volumenumber,
          wms_workorder.flowtype,
          wms_workorder.composingsoftwareid,
          '' as issuename
        FROM wms_workorder
          JOIN wms_workflow_eventlog ON wms_workflow_eventlog.workorderid = wms_workorder.workorderid
          LEFT JOIN wms_user ON wms_user.userid::text = wms_workflow_eventlog.userid::text
          JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
          JOIN wms_workorder_stage ON wms_workorder_stage.workorderid = wms_workorder.workorderid 
          AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid 
          AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid 
          AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
          JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder.duid      
          JOIN wms_workflow ON wms_workflow.wfid = wms_workorder.wfid
          JOIN org_mst_customer ON org_mst_customer.customerid = wms_workorder.customerid
          LEFT JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
          LEFT JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
          LEFT JOIN wms_mst_screens ON wms_mst_screens.screenid = wms_workflowdefinition.screenid
          LEFT JOIN wms_workorder_incoming AS inc on inc.woid = wms_workorder.workorderid and inc.stageid = wms_workorder_stage.wfstageid
          LEFT JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = inc.woincomingid
          LEFT JOIN wms_mst_priority ON wms_mst_priority.priorityid = wms_workflow_eventlog.priority
          LEFT JOIN pp_mst_filetype ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
          LEFT JOIN wms_userrole ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
          LEFT JOIN pp_mst_journal ON pp_mst_journal.journalid = wms_workorder.journalid
          LEFT JOIN wms_mst_complexity ON wms_mst_complexity.complexityid = wms_workorder.complexityid
          LEFT JOIN dms_master ON dms_master.dmsid = wms_workorder.dmsid      
          WHERE
          wms_workorder.isactive <> false  
          AND wms_workorder_stage.status NOT IN ('Completed' ,'Rejected')
          ${activitystatuscondition}
          ${activitynamecondition}
          ${iscustomerdespatch}
          AND wms_workorder.duid IN (${reqData.duId})
          ${
            reqData.skillid &&
            reqData.roleid != '1' &&
            reqData.roleid != '2' &&
            reqData.roleid != '47'
              ? `AND wms_workflow_eventlog.skillid IN (${reqData.skillid})`
              : ''
          } )
          , subjobcte as (
            SELECT  
            maincte.workorderid, maincte.status, coalesce(subjd.subjobstatus,'') as subjobstatus , 
            maincte.stageid,subjd.activityid,--subjd.val ,
            maincte.stageiterationcount,maincte.filename   
            FROM maincte
            LEFT JOIN (
              SELECT --SUM(CASE WHEN coalesce(subj.status,'') != 'Completed' THEN  ELSE 0 END) AS val, 
         subj.workorderid,
         subj.stageid, subj.activityid 
         ,subj.stageiterationcount,subjobname ,subj.subjobid 
         ,COALESCE(subj.status,'') AS subjobstatus
        FROM subjob_eventlog_details subj WHERE subj.workorderid IN (
        SELECT workorderid FROM maincte)
        GROUP BY workorderid,stageid,activityid,stageiterationcount ,subjobname,subj.status,subj.subjobid 
            ) AS subjd ON subjd.workorderid = maincte.workorderid
            and maincte.stageid = subjd.stageid
            and subjd.stageiterationcount = maincte.stageiterationcount
            and case when coalesce (subjd.activityid,0) = 0 then 1 else subjd.activityid end = 
              case when coalesce (maincte.activityid,0) = 0 then 1 else maincte.activityid end
            and (maincte.filename = subjd.subjobname or subjd.subjobid = 0)
            order by workorderid ,maincte.stageid
          ) , statusresult as (
         SELECT 
          scu.userid AS activityclaimedusers , 
          sj.subjobstatus,
          mc.*
      FROM maincte as mc
      LEFT JOIN subjobcte AS sj ON mc.workorderid = sj.workorderid 
      AND sj.stageid= mc.stageid  AND sj.filename = mc.filename
      --and sj.subjobstatus != 'Completed'
      --AND mc.activityid = sj.activityid 
      and case when coalesce (mc.activityid , 0 ) = 0 then 1 else mc.activityid end = 
			   case when coalesce (sj.activityid ,0) = 0 then 1 else sj.activityid end
      AND mc.stageiterationcount = sj.stageiterationcount and sj.filename = mc.filename           
            ${joincondition} join subjob_claimed_user AS scu ON scu.workorderid  = mc.workorderid  
                  AND scu.stageid = sj.stageid
                  AND scu.activityid =  sj.activityid ${subjobclaimedcondition}
      AND scu.stageiterationcount = mc.stageiterationcount
      ORDER BY wfeventid, createddate, priority asc
                ) , mainresult as (
          select  
          row_number () OVER (
          PARTITION BY fcte.workorderid, fcte.stageid, fcte.activityid , fcte.stageiterationcount
          ORDER BY fcte.workorderid, fcte.stageid, fcte.activityid , fcte.stageiterationcount) AS rno,
          fcte.* 
          from statusresult as fcte
          ${
            wherecondition == ''
              ? `where coalesce(subjobstatus,'') != 'Completed'`
              : `where coalesce(subjobstatus,'') != 'Completed'  ${wherecondition}`
          }
        ) 
          select 
          mr.activityclaimedusers,mr.subjobstatus,mr.workorderid,mr.itemcode,
          mr.itemcode as filename,mr.filename as chaptername, mr.title,
          mr.customerid,mr.customername,mr.baseduid,mr.assignedduid,mr.serviceid,mr.stagename,
          mr.status,mr.stageid,mr.activityname,mr.activityid,mr.activityalias,mr.wfid,mr.wfconfig,
          mr.wf_definitionid,mr.jobtype,mr.wotype,mr.servicename,mr.assignedduname,mr.wfeventid,
          mr.userid,mr.skillid,mr.wfdefid,mr.activitystatus,mr.createddate,mr.activityinstanceid,
          mr.taskinstanceid,mr.stageiterationcount,mr.activityiterationcount,mr.priority,
          mr.activitycount,mr.eventdata,mr.parentinstanceid,mr.actualactivitycount,
          mr.priorityname,mr.printisbn,mr.totalchaptercount,mr.instancetype,mr.formjson,
          mr.config,mr.fileconfig,mr.itracksconfig,mr.toolrunningstatus,mr.rejectedactivitytype,
          mr.activitymodeltype,mr.activitymodeltypeflow,mr."sequence",mr.username, 
          mr.duedate,mr.itrackduedate,mr.filetype,mr.mspages,mr.estimatedpages,mr.imagecount,
          mr.tablecount,mr.equationcount,mr.newfiletype,mr.runonfilesequence,
          mr.articleordersequence,mr.filetypeid,mr.roleid,mr.doinumber,mr.journalacronym,
          mr.pdfmerging,mr.activitytype,mr.dmstype,mr.screenpath,mr.isdespatchactivity,
          mr.iscompletiontriggeractivity,mr.complexityid,mr.complexity,mr.jobnormsid,
          mr.jobnormsname,mr.journalid,mr.divisionid,mr.subdivisionid,mr.duid,mr.jobcardid,
          mr.subjobid,mr.typesetpages,mr.worksheetid,mr.woincomingfileid,mr.hardbackisbn,
          mr.resettoactivityid,mr.isinstancerunning,mr.otherfield,mr.isonlineissue,mr.issuemstid,
          mr.ismscompleted,mr.pubflowconfig,mr.issuenumber,mr.volumenumber,mr.flowtype,
          mr.composingsoftwareid,mr.issuename
          from mainresult as mr where rno = 1
          order by mr.workorderid , mr.stageid , mr.activityid, mr.stageiterationcount 
          `;
      //
      // ${condition ? `${'WHERE '}${condition} AND` : 'WHERE'}
      // ${orderBy}

      const data = await query(sql, values);
      resolve(data);
    } catch (error) {
      resolve([{}]);
    }
  });
};

const getQueryNonwms = async reqData => {
  return new Promise(async resolve => {
    try {
      const qryscript = `  SELECT querytracker.queryid,
        querytracker.queryid::character varying(10) AS querysid,
        to_char(querytracker.createdon::date::timestamp with time zone, 'dd-MM-yyyy'::text) AS raisedon,
        querytracker.createdon,
        querytracker.createdby,
        users.username,
        COALESCE(querytracker.filename, w.itemcode)::character varying(250) AS filename,
        querytracker.workorderid,
        activity.activityname,
        concat(activity.activityname, ' (', querytracker.activityiterationcount, ')') AS activity,
        querytracker.activityid,
        concat(users.username, ' (', querytracker.createdby, ')') AS raisedby,
        querytracker.classificationid,
        queryclass.classificationname AS classification,
        querytracker.serviceid,
        service.servicename AS service,
        querytracker.stageid,
        concat(stage.stagename, ' (', querytracker.stageiterationcount, ')') AS stage,
        stage.stagename,
        querytracker.querystatusid,
        querystatus.status AS querystatus,
        eventlog.activitystatus AS taskstatus,
        querytracker.duid,
        querytracker.stageiterationcount,
        array_to_string(ARRAY( SELECT skill.skillname
              FROM wms_query_assigned assigned
                LEFT JOIN wms_mst_skill skill ON skill.skillid = assigned.skillid
              WHERE assigned.queryid = querytracker.queryid), ','::text) AS assignedto,
        date_part('day'::text, CURRENT_TIMESTAMP::timestamp without time zone - querytracker.createdon::timestamp without time zone)::character varying(10) AS assignedsince
      FROM wms_query querytracker
        LEFT JOIN wms_mst_activity activity ON activity.activityid = querytracker.activityid
        LEFT JOIN wms_mst_stage stage ON stage.stageid = querytracker.stageid
        LEFT JOIN wms_mst_query_classification queryclass ON queryclass.queryclassificationid = querytracker.classificationid
        LEFT JOIN wms_mst_query_status querystatus ON querystatus.querystatusid = querytracker.querystatusid
        LEFT JOIN wms_user users ON users.userid::text = querytracker.createdby::text
        LEFT JOIN wms_mst_service service ON service.serviceid = querytracker.serviceid
        LEFT JOIN wms_workflow_eventlog eventlog ON eventlog.wfeventid = querytracker.wfeventid
        LEFT JOIN wms_workorder w ON w.workorderid = querytracker.workorderid
      where  querystatus.status in ('Open','Re-open') and  querytracker.duid in (${reqData.duId}) and (querytracker.queryid in
            (select queryid from wms_query_assigned where skillid in (${reqData.skillid})) or querytracker.createdby = '${reqData.userid}')
      ORDER BY querytracker.queryid;`;

      console.log(qryscript, 'qryscript');
      const data = await query(qryscript);
      resolve(data);
      console.log(data);
    } catch (e) {
      console.log(e);
      resolve([{}]);
    }
  });
};
