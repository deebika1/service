/* eslint-disable */
import { basename, extname, dirname, resolve } from 'path';
import { query } from '../../database/postgres.js';
import { getFileValidationStatus } from '../utils/fileValidation/validate.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import { _getIncomingFileType } from '../utils/fileValidation/index.js';
import { getFormattedName } from '../utils/fileValidation/utils.js';
import logger from '../../modules/utils/logs/index.js';
import { getPreviousActivityRemarks } from './tools/index.js';

export const getFileDetails = async (req, res) => {
  const {
    wfEventId,
    workOrderId,
    du,
    customer,
    service,
    stage,
    activity,
    validationFileConfig,
    placeHolders,
    typesId,
    eventData,
    mandatorySaveFile,
    issuemstid,
  } = req.body;
  try {
    const filesInfo = await getFileInfoDetails({
      wfEventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId,
      activitymodeltypeflow:
        req.body && req.body.activitymodeltypeflow
          ? req.body.activitymodeltypeflow
          : '',
      issuemstid: issuemstid,
      wfDefId: req.body && req.body.wfDefid ? req.body.wfDefid : '',
      fileTypeId: req.body && req.body.fileTypeId ? req.body.fileTypeId : '',
      isOtherArticle:
        req.body && req.body.isOtherArticle ? req.body.isOtherArticle : false,
      articleOrderSequence: req.body.articleOrderSequence
        ? req.body.articleOrderSequence
        : null,
    });

    let filteredOtherArticleId = [];
    let incomingDetails = [];
    if (req.body.isOtherArticle) {
      incomingDetails = await _getIncomingFileType(workOrderId);
      console.log(incomingDetails, 'incomingDetailsh');
      incomingDetails = incomingDetails.filter(
        list => list.articletype == 'Other Article',
      );
      incomingDetails.map(list =>
        filteredOtherArticleId.push(parseInt(list.filetypeid)),
      );
      filteredOtherArticleId = [...new Set(filteredOtherArticleId)];
    }
    const dataFiles = filteredOtherArticleId;
    for (let j = 0; j < dataFiles.length; j++) {
      let id = dataFiles[j];
      var key = Object.keys(validationFileConfig).includes('83');
      if (key) {
        let value = validationFileConfig['83'].files;
        for (var k = 0; k < value.length; k++) {
          let dataValue = value[k];
          let filetype = [...dataValue.fileTypes, ...filteredOtherArticleId];
          dataValue['fileTypes'] = filetype;
        }
        validationFileConfig[id] = { files: value };
      }
    }
    let filesData = await fetchValidationDetails(
      filesInfo,
      validationFileConfig,
      placeHolders,
      eventData,
      mandatorySaveFile,
      workOrderId,
    );
    const isFileSynced = await getFileSyncStatus(wfEventId);
    console.log('filesData', filesData);
    filesData = await _changeMandatoryFiles(filesData, workOrderId);
    console.log('uncheckSave', filesData);
    res.status(200).json({ ...filesData, isFileSynced });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getFileDetailsNew = async (req, res) => {
  const getdata = req.body;
  console.log(getdata, 'hjkh');
  try {
    const sql = `SELECT inc.*,incf.*,flt.*,ptp.pitstopprofile as pitstopprofilename 
        from wms_workorder_incoming as inc 
        join wms_workorder_incomingfiledetails as incf on inc.woincomingid=incf.woincomingid 
        join pp_mst_filetype as flt on  incf.filetypeid = flt.filetypeid 
        left join wms_mst_pitstopprofile as ptp on ptp.pitstopprofileid=incf.pitstopprofile
        where woid=${getdata.workorderid} and flt.filetypeid !=1 order by incf.filesequence`;
    const eventData = await query(sql);
    res.status(200).json(eventData);
  } catch (error) {
    global.log(error, 'file details');
    res.status(400).send({ message: error });
  }
};

export const getProblemTask = async (req, res) => {
  const getdata = req.body;
  console.log(getdata, 'ProblemTask');
  try {
    const sql = `SELECT problem_task FROM ProblemTasks WHERE
     '${getdata.stagename}' = ANY(stages) `;
    const eventData = await query(sql);
    res.status(200).json(eventData);
  } catch (error) {
    global.log(error, 'getProblemTask');
    res.status(400).send({ message: error });
  }
};

export const getElsevierWF = async (req, res) => {
  const getdata = req.body;
  console.log(getdata, 'elsevier work flow');
  try {
    const sql = `SELECT wf.wfname FROM wms_workflow wf JOIN wms_workorder wo ON wf.wfid = wo.wfid WHERE wo.workorderid = ${getdata.woid}`;
    const eventData = await query(sql);
    res.status(200).json(eventData);
  } catch (error) {
    global.log(error, 'elsevier work flow');
    res.status(400).send({ message: error });
  }
};

export const getStandardQuery = async (req, res) => {
  const getdata = req.body;
  console.log(getdata, 'getStandardQuery');
  try {
    const sql = `SELECT standard_queries,description FROM standarqueries WHERE
     '${getdata.stagename}' = ANY(stages) `;
    const eventData = await query(sql);
    res.status(200).json(eventData);
  } catch (error) {
    global.log(error, 'getProblemTask');
    res.status(400).send({ message: error });
  }
};

export const updateDataPT = async (req, res) => {
  const getdata = req.body;
  console.log(getdata, 'updateData');
  try {
    const sql = `SELECT standard_queries FROM standarqueries WHERE
     '${getdata.stagename}' = ANY(stages) `;
    const eventData = await query(sql);
    res.status(200).json(eventData);
  } catch (error) {
    global.log(error, 'getProblemTask');
    res.status(400).send({ message: error });
  }
};

export const setPIIPlaceHolders = async (req, res) => {
  const { workorderId, woImcomingFileId } = req.body;
  try {
    const sql = `select woincomingfileid,filename,piinumber,* from wms_workorder_incoming as incoming
    join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
    where incoming.woid = ${workorderId} and woincomingfileid = ${woImcomingFileId}`;
    const result = await query(sql, []);
    res.send(result);
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const insertCorrectionDetails = async (req, res) => {
  try {
    const { userid, stage, activity, woid, stageIterationCount } = req.body;

    if (!userid || !stage || !activity || !woid || !stageIterationCount) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const sql = `
          INSERT INTO user_correction_activity_log (userid, updatedtime, stage, activity, woid, stageIterationCount)
          VALUES ($1, NOW(), $2, $3, $4, $5 )
          RETURNING *;
      `;

    const values = [userid, stage, activity, woid, stageIterationCount];

    const result = await query(sql, values);

    if (result && result.length > 0) {
      return res.status(201).json({
        message: 'Correction details inserted successfully',
        data: result[0],
      });
    } else {
      return res
        .status(400)
        .json({ error: 'Failed to insert correction details' });
    }
  } catch (error) {
    console.error('Error inserting correction details:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};

export const fetchCorrection = async (req, res) => {
  try {
    const { workorderId, choiceTogetCorrection, stageId, wfId, sequence } =
      req.body; // Get workorderId from request body

    if (!workorderId) {
      return res
        .status(400)
        .json({ message: 'Missing workorderId in request body' });
    }

    let result = [];

    if (choiceTogetCorrection === 29) {
      const sql = `SELECT payload
        FROM iauthor_dispatch_trns
        WHERE guid = (
          select guid
          FROM public.iauthor_transactions
          WHERE workorderid = $1 AND stageid = 122 
          ORDER by 1
          DESC limit 1
        )
        ORDER BY dispatchtrnsid DESC
        LIMIT 1`;

      // const sql = `
      //     SELECT ad.payload
      //     FROM public.wms_workorder wo
      //     JOIN iauthor_transactions ia ON wo.workorderid = ia.workorderid
      //     JOIN iauthor_dispatch_trns ad ON ad.guid = ia.guid
      //     WHERE wo.workorderid = $1
      //     ORDER BY ad.dispatchtrnsid DESC
      //     LIMIT 1
      // `;

      const queryResult = await query(sql, [workorderId]);
      result = queryResult;
    } else {
      const sql = `
        SELECT correction_payload as payload
        FROM iauthor_dispatch_trns 
        WHERE guid = (
            SELECT guid 
            FROM public.iauthor_transactions
            WHERE workorderid = $1 AND stageid = 122
            ORDER BY 1 DESC
            LIMIT 1
        )
        ORDER BY dispatchtrnsid DESC
        LIMIT 1
    `;
      const queryResult = await query(sql, [workorderId]);
      result = queryResult;
    }

    if (result.length === 0) {
      return res
        .status(404)
        .json({ message: 'No data found for the given workorderId' });
    }

    const data = await getPreviousActivityRemarks({
      workorderId,
      stageId,
      wfId,
      sequence,
    });

    res.status(200).json({ ...result[0], remarks: data }); // Send the fetched payload
  } catch (error) {
    console.error('Error fetching correction data:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

export const getPlaceHolders = async (req, res) => {
  const { wfEventId, workOrderId, woIncomingFileId, instanceType } = req.body;
  try {
    const awaits = [];
    awaits.push(getWorkflowPlaceHolders(wfEventId));
    awaits.push(getLinkingFileTypePlaceHolders(workOrderId));
    awaits.push(
      getChapterFileTypePlaceHolders(
        workOrderId,
        woIncomingFileId,
        instanceType,
      ),
    );
    awaits.push(getIndexFileTypePlaceHolders(workOrderId));
    awaits.push(getPrelimsFileTypePlaceHolders(workOrderId));
    const placeholderData = await Promise.all(awaits);
    let placeHolders1 = placeholderData[0];
    const placeHolders2 = placeholderData[1];
    const placeHolders3 = placeholderData[2];
    const placeHolders4 = placeholderData[3];
    const placeHolders5 = placeholderData[4];
    if (
      placeHolders2 &&
      Object.keys(placeHolders2).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        LinkingTypeFileName: placeHolders2.filename,
      };
    }
    if (
      placeHolders3 &&
      Object.keys(placeHolders3).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        ChapterTypeFileName: placeHolders3.filename,
      };
    }
    if (
      placeHolders4 &&
      Object.keys(placeHolders4).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        IndexTypeFileName: placeHolders4.filename,
      };
    }
    if (
      placeHolders5 &&
      Object.keys(placeHolders5).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        PrelimsTypeFileName: placeHolders5.filename,
      };
    }
    if (woIncomingFileId != null) {
      const sql2 = `select woincomingfileid,filename,* from wms_workorder_incoming as incoming
    join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
    where indetails.woincomingfileid = $1`;
      const incominglist = await query(sql2, [woIncomingFileId]);
      let tocList = incominglist.filter(list => list.filetypeid == 17);
      let isTocFile = tocList.length > 0 ? 'Yes' : 'No';
      placeHolders1 = {
        ...placeHolders1,
        TocFile: isTocFile,
      };
    }
    res.send(placeHolders1);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getWorkflowPlaceHolders = async wfEventId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM public.wms_wfevent_details where wfEventId = $1`;
      const eventData = await query(sql, [wfEventId]);
      let {
        workorderid,
        printisbn,
        doinumber,
        journalname,
        journalacronym,
        stageid,
        stageiterationcount,
        activityiterationcount,
        issuenumber,
        eisbn,
        volumenumber,
        itemcode,
        smartmetadata,
        watermark,
        countrycode,
        pmemail,
        uom,
        customerid,
        hardbackisbn,
        wfid,
        onlinepdf,
        print,
        additionalpdf,
        pii,
        articleno,
        journaltype,
        stagename,
        frontpii,
        backpii,
        printissn,
        manuscriptzipname,
        instancetype,
        actualactivitycount,
        indexvalue,
        mycopyisbn,
        mycopy,
        activityname,
        duid,
        filename,
        metafilename,
        bookisbn,
        onlineisbn,
        activityid,
        book2,
        book2isbn,
      } = eventData[0];
      let {
        coverprofile,
        referenceprofile,
        pdfa2bprofile,
        onlineprofile,
        pitstopprofile,
        printprofile,
      } = eventData[0];
      const WoTypesql = `select wo.wotype,wf.wfname from wms_workorder wo 
      left join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid 
      join wms_workflow wf ON woservice.wfid = wf.wfid where wo.workorderid= ${workorderid} order by 1`;
      const woTypeResult = await query(WoTypesql);
      if (woTypeResult.length === 0) {
        throw new Error(`No work order found for id ${workorderid}`);
      }
      const woType = woTypeResult[0].wotype;
      const wfName = woTypeResult[0].wfname;
      const myCopyValue = mycopy?.toLowerCase();
      // if (woType == 'Book') {
      const profileData = await getProfileData(wfEventId, woType, wfName); //profiles from New optimised table

      ({
        coverprofile,
        referenceprofile,
        pdfa2bprofile,
        onlineprofile,
        pitstopprofile,
        printprofile,
        mycopy,
      } = profileData[0]);
      const isColorProfile =
        woType == 'Book'
          ? await getProfileTypeForBooks(workorderid)
          : await getProfileType(workorderid);
      const bookfilename = await getBookFileName(workorderid);
      const chapterid = await getChapterId(workorderid);

      const zipFileName = await getZipFileName(workorderid);
      const bookworkOrderId = await getBookWorkOrderId(itemcode);
      const configSql = `SELECT wf.config FROM wms_workflow_eventlog we join wms_workflowdefinition wf ON we.wfdefid = wf.wfdefid  where wfeventid = ${wfEventId}`;
      const configResult = await query(configSql);

      const extractStageNumber = stagename.match(/-?\d+\.?\d*/)
        ? stagename.match(/-?\d+\.?\d*/)[0]
        : '';
      const isbn =
        customerid == '1'
          ? hardbackisbn
          : customerid == '6'
          ? doinumber
          : printisbn;

      const PitstopProfileSelector = () => {
        const isOnline = journaltype === 'online';
        const defaultProfile = isOnline
          ? onlineprofile || ''
          : printprofile || '';

        switch (wfid) {
          case '25':
          case '48': //Elseveir Books
            return onlineprofile || '';

          case '29':
            if (configResult.length > 0) {
              const activityType = configResult[0]?.config?.activityType;
              let isBW = isColorProfile ? 'BW' : 'CMYK';
              if (activityType == 'Chapter') {
                if (isBW === 'BW') {
                  isBW = `${isBW}_For_Chapter`;
                } else {
                  isBW = `${isBW}_For_Chapters`;
                }
              }
              printprofile = `SPR\\Springer\\${isBW}`;
              //To handle different profile for 600 stage and 650 stage email on Tue 25-02-2025 10:31 and spot requirement not clear by mohan
              if (stageid == 110 || stageid == 31) {
                onlineprofile =
                  'SPR\\Springer\\Online_1_4_Version_WithWatermark';
                mycopy = 'SPR\\Springer\\MYCOPY_With_Watermark';
                if (
                  activityid == 415 ||
                  activityid == 416 ||
                  activityid == 565 ||
                  activityid == 564
                )
                  printprofile = printprofile + '_WithWatermark';
              } else if (stageid == 111 || stageid == 97) {
                onlineprofile = 'SPR\\Springer\\Online_1_4_Version';
                mycopy = 'SPR\\Springer\\MYCOPY';
              }
            }
            return onlineprofile || '';

          case '34':
            const profileType =
              instancetype === 'Multiple' ? 'ARTICLE' : 'ISSUE';
            const colorType = isColorProfile ? 'COLOR' : 'BW';
            printprofile = `SPR_JOURNAL\\${profileType}\\${colorType}`;
            return isOnline ? printprofile || '' : onlineprofile || '';

          case '26':
          case '27':
          case '28':
          case '31':
          case '30':
          case '39':
          case '37':
          case '41':
            return isOnline ? onlineprofile || '' : printprofile || '';

          case '32':
            return isOnline ? printprofile || '' : onlineprofile || '';

          default:
            return defaultProfile;
        }
      };

      const FiletypeNamebyJnlType = () => {
        switch (wfid) {
          case '25':
            return journaltype == 'print and online' ? '_Print' : '';
          case '28':
            return journaltype == 'print and online' ? '_Print' : '';
          default:
            return journaltype == 'print and online' ? '_Print' : '';
        }
      };
      const sql1 = `select * from public.wms_workorder_stage  where workorderid = ${workorderid} and wfstageid = ${stageid} and stageiterationcount = ${stageiterationcount}`;
      const typeSetDetails = await query(sql1);
      console.log(typeSetDetails);
      const { typesetpages } = typeSetDetails.length ? typeSetDetails[0] : {};

      const sql2 = `select woincomingfileid,filename,* from wms_workorder_incoming as incoming
      join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
      where incoming.woid = $1`;
      const articletypelist = await query(sql2, [workorderid]);
      const sql3 = `select woincomingfileid from wms_workflow_eventlog where wfeventid = ${wfEventId}`;
      const incomingDetails = await query(sql3);
      console.log(incomingDetails);
      const { woincomingfileid } = incomingDetails[0];
      console.log(sql3);
      const overAllArticleList = [];
      articletypelist.forEach(list => {
        overAllArticleList.push({
          woincomingid: list.woincomingfileid,
          woincomingfileid: list.woincomingfileid,
          FileTypeName: list.filename,
          articletype: list.articletype,
          piinumber: list.piinumber,
          runonfilesequence: list.runonfilesequence,
          filesequence: list.filesequence,
          issue_type: list.issue_type,
          FileTypeId: list.filetypeid ? list.filetypeid : null,
        });
      });

      // //newCode addedfor manuscript(Anand)
      // if (woincomingfileid) {
      //   const msValue = `select newfilename from public.wms_workorder_incomingfiledetails where woincomingfileid =${woincomingfileid} order by 1`;
      //   const manuScript = await query(msValue);
      //   if (manuScript[0].newfilename?.length > 0)
      //     manuscriptzipname = manuScript[0].newfilename;
      // }
      // //newCode addedfor manuscript(Anand)
      const placeHolders = {
        // ISBN: customerid == '1' ? hardbackisbn : printisbn,
        // for tools=> only isbn value is used. so make this place holder changes
        ISBN: isbn,
        EISBN: eisbn || '',
        DOI: doinumber,
        WOID: workorderid,
        JournalName: journalname,
        JournalAcronym: journalacronym,
        JournalAcronymSub: journalacronym?.toLowerCase(),
        CountryCode: countrycode,
        PMEmail: pmemail,
        PageCount: uom,
        JournalVolumeNo: volumenumber,
        JournalIssueNo: issuenumber,
        StageIteration: stageiterationcount,
        ActivityIteration: activityiterationcount,
        BookCode: itemcode,
        // PitstopProfile: wfid == 25 ? onlineprofile || '' : pitstopprofile || '',
        PitstopProfile: PitstopProfileSelector(),
        WatermarkProfile: watermark || '',
        SmartmetadataProfile: smartmetadata || '',
        OnlinePdf: onlinepdf || '',
        Print: print || '',
        AdditionalPdf: additionalpdf || '',
        PII: pii || '',
        OnlineProfile: onlineprofile || '',
        PrintProfile: printprofile || '',
        MycopyProfile: mycopy || '',
        articleno: articleno || '',
        graphicFileName: (isbn && isbn.substring(7, isbn.length - 1)) || '',
        pagecount: typesetpages || '',
        extractStageNumber,
        ReferenceProfile: referenceprofile,
        Pdfa2bProfile: pdfa2bprofile,
        JnlTypeFileName: FiletypeNamebyJnlType(),
        articletype: '',
        FrontPII: frontpii || '',
        BackPII: backpii || '',
        PrintIssn: printissn || '',
        ArticleTypeList: overAllArticleList || [],
        CoverProfile: coverprofile || [],
        IssueJournalType: journaltype == 'online' ? 'Online' : 'Print_BW',
        ManuscriptZipName: manuscriptzipname,
        woincomingfileid,
        Activityiterationcount: actualactivitycount,
        BookFileName: bookfilename ? bookfilename.bookfilename : '',
        ChapterId: chapterid ? chapterid.chapterid : '',
        BookZipFileName: zipFileName ? zipFileName.zipFileName : '',

        bookworkOrderId: bookworkOrderId ? bookworkOrderId.bookworkorderid : '',
        indexRequired: indexvalue ? indexvalue : false,
        MyCopyISBN: mycopyisbn,
        MyCopyValue: myCopyValue,
        bookcode: itemcode,
        filename: filename,
        foldername: itemcode,
        stagecode: stagename,
        activitycode: activityname,
        duid: duid,
        customerid: customerid,
        workorderId: workorderid,
        // FileTypeName: itemcode,
        MetaFileName: metafilename,
        PrintISBN: bookisbn,
        OnlineISBN: onlineisbn,
        SetterName:
          journalacronym && pii ? `${journalacronym}${pii.slice(-8, -1)}` : '',
        Book2ISBN: book2isbn,
        Book2Value: book2?.toLowerCase(),
        ChapterType: itemcode.includes('Part') ? 'PartFrontmatter' : 'Chapter',
      };
      // added graphics image upload  isbn validation
      resolve(placeHolders);
    } catch (e) {
      logger.info(e?.message ? e?.message : e);
      reject(e.message ? e.message : e);
    }
  });
};

const getProfileData = async (wfEventId, woType, wfName) => {
  return new Promise(async (resolve, reject) => {
    try {
      let profileSql;
      if (woType == 'Book') {
        if (wfName == 'Springer_Books') {
          profileSql = `select
          boid,
          bookid,
          wfid,
          stageid,
          activityid,
          p_id,
          profileid,
          workorderid,
          wfeventid,
          profilevalue,
          profilename,
          sum(onlineprofileid ::int) as onlineprofileid,
          sum(printprofileid  ::int) as printprofileid,
          sum(coverprofileid ::int) as coverprofileid,
          sum(mycopyprofileid  ::int)as mycopyprofileid
        from (
          -- First select online block
          select
            bo.id as boid,
            bo.bookid,
            ws.wfid,
            stg.stageid,
            act.activityid,
            pitmap.p_id,
            pitdet.profileid,
            wo.workorderid,
            ev.wfeventid,
            pitdet.profilevalue,
            mstpit.profilename,
            bo.onlineprofileid as onlineprofileid,
            null as printprofileid,
            null as coverprofileid,
            null as mycopyprofileid
          from
            wms_workorder as wo
          join wms_workflow_eventlog ev on
            ev.workorderid = wo.workorderid
          join wms_workorder_service as ws on
            ws.workorderid = wo.workorderid
            and ws.serviceid = ev.serviceid
          left join wms_book_master as bo on
            bo.id = wo.bookid
          join org_mst_deliveryunit as du on
            du.duid = ws.assignedduid
          join org_mst_customer on
            org_mst_customer.customerid = wo.customerid
          join wms_workflowdefinition as wfd on
            wfd.wfdefid = ev.wfdefid
          join wms_mst_stage as stg on
            stg.stageid = wfd.stageid
          join wms_mst_activity as act on
            act.activityid = wfd.activityid
          left join trn_pitstopprofilemap as pitmap on
            pitmap.wfid = ws.wfid
            and pitmap.stageid = stg.stageid
            and pitmap.activityid = act.activityid
            and pitmap.duid = du.duid
            and pitmap.isactive = true
              and pitmap.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap.p_id and profileid = 4)
          left join trn_pitstopprofilemap as pitmap1 on
            pitmap1.wfid = ws.wfid
            and pitmap1.stageid = stg.stageid
            and pitmap1.duid = du.duid
            and pitmap1.isactive = true and pitmap1.activityid  is null
            and pitmap1.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap1.p_id and profileid = 4)
          left join trn_pitstopprofiledetail as pitdet on
            pitdet.id = coalesce(coalesce(pitmap.p_id, pitmap1.p_id), bo.onlineprofileid::bigint)
            and pitdet.isactive = true and pitdet.profileid = 4
          left join mst_pitstopprofile as mstpit on
            mstpit.profileid = pitdet.profileid
          where
            ev.wfeventid = $1
          union all
          -- Second select print block 
          select
            bo.id as boid,
            bo.bookid,
            ws.wfid,
            stg.stageid,
            act.activityid,
            pitmap.p_id,
            pitdet.profileid,
            wo.workorderid,
            ev.wfeventid,
            pitdet.profilevalue,
            mstpit.profilename,
            null as onlineprofileid,
            bo.printprofileid as printprofileid,
            null as coverprofileid,
            null as mycopyprofileid
          from
            wms_workorder as wo
          join wms_workflow_eventlog ev on
            ev.workorderid = wo.workorderid
          join wms_workorder_service as ws on
            ws.workorderid = wo.workorderid
            and ws.serviceid = ev.serviceid
          left join wms_book_master as bo on
            bo.id = wo.bookid
          join org_mst_deliveryunit as du on
            du.duid = ws.assignedduid
          join org_mst_customer on
            org_mst_customer.customerid = wo.customerid
          join wms_workflowdefinition as wfd on
            wfd.wfdefid = ev.wfdefid
          join wms_mst_stage as stg on
            stg.stageid = wfd.stageid
          join wms_mst_activity as act on
            act.activityid = wfd.activityid
          left join trn_pitstopprofilemap as pitmap on
            pitmap.wfid = ws.wfid
            and pitmap.stageid = stg.stageid
            and pitmap.activityid = act.activityid
            and pitmap.duid = du.duid
            and pitmap.isactive = true
            and pitmap.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap.p_id and profileid = 5)
          left join trn_pitstopprofilemap as pitmap1 on
            pitmap1.wfid = ws.wfid and pitmap1.activityid  is null
            and pitmap1.stageid = stg.stageid
            and pitmap1.duid = du.duid
            and pitmap1.isactive = true
            and pitmap1.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap1.p_id and profileid = 5)
          left join trn_pitstopprofiledetail as pitdet on
            pitdet.id = coalesce(coalesce(pitmap.p_id, pitmap1.p_id), bo.printprofileid::bigint)
            and pitdet.isactive = true and pitdet.profileid = 5
          left join mst_pitstopprofile as mstpit on
            mstpit.profileid = pitdet.profileid
          where
            ev.wfeventid = $1
          union all
          -- Third select cover block
          select
            bo.id as boid,
            bo.bookid,
            ws.wfid,
            stg.stageid,
            act.activityid,
            pitmap.p_id,
            pitdet.profileid,
            wo.workorderid,
            ev.wfeventid,
            pitdet.profilevalue,
            mstpit.profilename,
            null as onlineprofileid,
            null as printprofileid,
            bo.coverprofileid as coverprofileid,
            null as mycopyprofileid
          from
            wms_workorder as wo
          join wms_workflow_eventlog ev on
            ev.workorderid = wo.workorderid
          join wms_workorder_service as ws on
            ws.workorderid = wo.workorderid
            and ws.serviceid = ev.serviceid
          left join wms_book_master as bo on
            bo.id = wo.bookid
          join org_mst_deliveryunit as du on
            du.duid = ws.assignedduid
          join org_mst_customer on
            org_mst_customer.customerid = wo.customerid
          join wms_workflowdefinition as wfd on
            wfd.wfdefid = ev.wfdefid
          join wms_mst_stage as stg on
            stg.stageid = wfd.stageid
          join wms_mst_activity as act on
            act.activityid = wfd.activityid
          left join trn_pitstopprofilemap as pitmap on
            pitmap.wfid = ws.wfid
            and pitmap.stageid = stg.stageid
            and pitmap.activityid = act.activityid
            and pitmap.duid = du.duid
            and pitmap.isactive = true
            and pitmap.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap.p_id and profileid = 2)
          left join trn_pitstopprofilemap as pitmap1 on
            pitmap1.wfid = ws.wfid and pitmap1.activityid  is null
            and pitmap1.stageid = stg.stageid
            and pitmap1.duid = du.duid
            and pitmap1.isactive = true
            and pitmap1.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap1.p_id and profileid = 2)
          left join trn_pitstopprofiledetail as pitdet on
            pitdet.id = coalesce(coalesce(pitmap.p_id, pitmap1.p_id), bo.coverprofileid::bigint)
            and pitdet.isactive = true and pitdet.profileid = 2
          left join mst_pitstopprofile as mstpit on
            mstpit.profileid = pitdet.profileid
          where
            ev.wfeventid = $1
          union all
          -- Fourth select mycopy block
          select
            bo.id as boid,
            bo.bookid,
            ws.wfid,
            stg.stageid,
            act.activityid,
            pitmap.p_id,
            pitdet.profileid,
            wo.workorderid,
            ev.wfeventid,
            pitdet.profilevalue,
            mstpit.profilename,
            null as onlineprofileid,
            null as printprofileid,
            null as coverprofileid,
            bo.mycopyprofileid as mycopyprofileid
          from
            wms_workorder as wo
          join wms_workflow_eventlog ev on
            ev.workorderid = wo.workorderid
          join wms_workorder_service as ws on
            ws.workorderid = wo.workorderid
            and ws.serviceid = ev.serviceid
          left join wms_book_master as bo on
            bo.id = wo.bookid
          join org_mst_deliveryunit as du on
            du.duid = ws.assignedduid
          join org_mst_customer on
            org_mst_customer.customerid = wo.customerid
          join wms_workflowdefinition as wfd on
            wfd.wfdefid = ev.wfdefid
          join wms_mst_stage as stg on
            stg.stageid = wfd.stageid
          join wms_mst_activity as act on
            act.activityid = wfd.activityid
          left join trn_pitstopprofilemap as pitmap on
            pitmap.wfid = ws.wfid
            and pitmap.stageid = stg.stageid
            and pitmap.activityid = act.activityid
            and pitmap.duid = du.duid
            and pitmap.isactive = true
            and pitmap.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap.p_id and profileid = 7)
          left join trn_pitstopprofilemap as pitmap1 on
            pitmap1.wfid = ws.wfid and pitmap1.activityid  is null
            and pitmap1.stageid = stg.stageid
            and pitmap1.duid = du.duid
            and pitmap1.isactive = true
            and pitmap1.p_id in (select id from  trn_pitstopprofiledetail
                   where id  =  pitmap1.p_id and profileid = 7)
          left join trn_pitstopprofiledetail as pitdet on
            pitdet.id = coalesce(coalesce(pitmap.p_id, pitmap1.p_id), bo.mycopyprofileid::bigint)
            and pitdet.isactive = true and pitdet.profileid = 7
          left join mst_pitstopprofile as mstpit on
            mstpit.profileid = pitdet.profileid
          where
            ev.wfeventid = $1
            
        ) as unified_query
        group by
          boid,
          bookid,
          wfid,
          stageid,
          activityid,
          p_id,
          profileid,
          workorderid,
          wfeventid,
          profilevalue,
          profilename`;
        } else {
          profileSql = `SELECT
                      woid,
                      wfid,
                      stageid,
                      activityid,
                      p_id,
                      profileid,
                      wfeventid,
                      profilevalue,
                      profilename,
                      SUM(onlinepdfid::int) AS onlinepdfid,
                      SUM(printid::int) AS printid,
                      SUM(coverid::int) AS coverid
                  FROM (
                      -- First select online block
                      SELECT
                          bo.workorderid AS woid,
                          ws.wfid,
                          stg.stageid,
                          act.activityid,
                          pitmap.p_id,
                          pitdet.profileid,
                          wo.workorderid,
                          ev.wfeventid,
                          pitdet.profilevalue,
                          mstpit.profilename,
                          bo.onlinepdfid AS onlinepdfid,
                          NULL::int AS printid,   -- Explicitly cast NULL to integer
                          NULL::int AS coverid    -- Explicitly cast NULL to integer
                      FROM
                          wms_workorder AS wo
                      JOIN wms_workflow_eventlog ev ON ev.workorderid = wo.workorderid
                      JOIN wms_workorder_service AS ws ON ws.workorderid = wo.workorderid AND ws.serviceid = ev.serviceid
                      LEFT JOIN wms_workorder_additionalinfo AS bo ON bo.workorderid = wo.workorderid
                      JOIN org_mst_deliveryunit AS du ON du.duid = ws.assignedduid
                      JOIN org_mst_customer ON org_mst_customer.customerid = wo.customerid
                      JOIN wms_workflowdefinition AS wfd ON wfd.wfdefid = ev.wfdefid
                      JOIN wms_mst_stage AS stg ON stg.stageid = wfd.stageid
                      JOIN wms_mst_activity AS act ON act.activityid = wfd.activityid
                      LEFT JOIN trn_pitstopprofilemap AS pitmap ON pitmap.wfid = ws.wfid AND pitmap.stageid = stg.stageid
                        AND pitmap.activityid = act.activityid AND pitmap.duid = du.duid AND pitmap.isactive = TRUE
                        AND pitmap.p_id IN (SELECT id FROM trn_pitstopprofiledetail WHERE id = pitmap.p_id AND profileid = 4)
                      LEFT JOIN trn_pitstopprofilemap AS pitmap1 ON pitmap1.wfid = ws.wfid AND pitmap1.stageid = stg.stageid
                        AND pitmap1.duid = du.duid AND pitmap1.isactive = TRUE AND pitmap1.activityid IS NULL
                        AND pitmap1.p_id IN (SELECT id FROM trn_pitstopprofiledetail WHERE id = pitmap1.p_id AND profileid = 4)
                      LEFT JOIN trn_pitstopprofiledetail AS pitdet ON pitdet.id = COALESCE(COALESCE(pitmap.p_id, pitmap1.p_id), bo.onlinepdfid::bigint)
                        AND pitdet.isactive = TRUE AND pitdet.profileid = 4
                      LEFT JOIN mst_pitstopprofile AS mstpit ON mstpit.profileid = pitdet.profileid
                      WHERE ev.wfeventid = $1

                      UNION ALL

                      -- Second select print block 
                      SELECT
                          bo.workorderid AS woid,
                          ws.wfid,
                          stg.stageid,
                          act.activityid,
                          pitmap.p_id,
                          pitdet.profileid,
                          wo.workorderid,
                          ev.wfeventid,
                          pitdet.profilevalue,
                          mstpit.profilename,
                          NULL::int AS onlinepdfid,   -- Explicitly cast NULL to integer
                          bo.printid AS printid,
                          NULL::int AS coverid        -- Explicitly cast NULL to integer
                      FROM
                          wms_workorder AS wo
                      JOIN wms_workflow_eventlog ev ON ev.workorderid = wo.workorderid
                      JOIN wms_workorder_service AS ws ON ws.workorderid = wo.workorderid AND ws.serviceid = ev.serviceid
                      LEFT JOIN wms_workorder_additionalinfo AS bo ON bo.workorderid = wo.workorderid
                      JOIN org_mst_deliveryunit AS du ON du.duid = ws.assignedduid
                      JOIN org_mst_customer ON org_mst_customer.customerid = wo.customerid
                      JOIN wms_workflowdefinition AS wfd ON wfd.wfdefid = ev.wfdefid
                      JOIN wms_mst_stage AS stg ON stg.stageid = wfd.stageid
                      JOIN wms_mst_activity AS act ON act.activityid = wfd.activityid
                      LEFT JOIN trn_pitstopprofilemap AS pitmap ON pitmap.wfid = ws.wfid AND pitmap.stageid = stg.stageid
                        AND pitmap.activityid = act.activityid AND pitmap.duid = du.duid AND pitmap.isactive = TRUE
                        AND pitmap.p_id IN (SELECT id FROM trn_pitstopprofiledetail WHERE id = pitmap.p_id AND profileid = 5)
                      LEFT JOIN trn_pitstopprofilemap AS pitmap1 ON pitmap1.wfid = ws.wfid AND pitmap1.activityid IS NULL
                        AND pitmap1.stageid = stg.stageid AND pitmap1.duid = du.duid AND pitmap1.isactive = TRUE
                        AND pitmap1.p_id IN (SELECT id FROM trn_pitstopprofiledetail WHERE id = pitmap1.p_id AND profileid = 5)
                      LEFT JOIN trn_pitstopprofiledetail AS pitdet ON pitdet.id = COALESCE(COALESCE(pitmap.p_id, pitmap1.p_id), bo.printid::bigint)
                        AND pitdet.isactive = TRUE AND pitdet.profileid = 5
                      LEFT JOIN mst_pitstopprofile AS mstpit ON mstpit.profileid = pitdet.profileid
                      WHERE ev.wfeventid = $1

                      UNION ALL

                      -- Third select cover block
                      SELECT
                          bo.workorderid AS woid,
                          ws.wfid,
                          stg.stageid,
                          act.activityid,
                          pitmap.p_id,
                          pitdet.profileid,
                          wo.workorderid,
                          ev.wfeventid,
                          pitdet.profilevalue,
                          mstpit.profilename,
                          NULL::int AS onlinepdfid,   -- Explicitly cast NULL to integer
                          NULL::int AS printid,       -- Explicitly cast NULL to integer
                          bo.coverid AS coverid       -- No cast needed since coverid is already integer
                      FROM
                          wms_workorder AS wo
                      JOIN wms_workflow_eventlog ev ON ev.workorderid = wo.workorderid
                      JOIN wms_workorder_service AS ws ON ws.workorderid = wo.workorderid AND ws.serviceid = ev.serviceid
                      LEFT JOIN wms_workorder_additionalinfo AS bo ON bo.workorderid = wo.workorderid
                      JOIN org_mst_deliveryunit AS du ON du.duid = ws.assignedduid
                      JOIN org_mst_customer ON org_mst_customer.customerid = wo.customerid
                      JOIN wms_workflowdefinition AS wfd ON wfd.wfdefid = ev.wfdefid
                      JOIN wms_mst_stage AS stg ON stg.stageid = wfd.stageid
                      JOIN wms_mst_activity AS act ON act.activityid = wfd.activityid
                      LEFT JOIN trn_pitstopprofilemap AS pitmap ON pitmap.wfid = ws.wfid AND pitmap.stageid = stg.stageid
                        AND pitmap.activityid = act.activityid AND pitmap.duid = du.duid AND pitmap.isactive = TRUE
                        AND pitmap.p_id IN (SELECT id FROM trn_pitstopprofiledetail WHERE id = pitmap.p_id AND profileid = 2)
                      LEFT JOIN trn_pitstopprofilemap AS pitmap1 ON pitmap1.wfid = ws.wfid AND pitmap1.stageid = stg.stageid
                        AND pitmap1.duid = du.duid AND pitmap1.isactive = TRUE AND pitmap1.activityid IS NULL
                        AND pitmap1.p_id IN (SELECT id FROM trn_pitstopprofiledetail WHERE id = pitmap1.p_id AND profileid = 2)
                      LEFT JOIN trn_pitstopprofiledetail AS pitdet ON pitdet.id = COALESCE(COALESCE(pitmap.p_id, pitmap1.p_id), bo.coverid::int)
                        AND pitdet.isactive = TRUE AND pitdet.profileid = 2
                      LEFT JOIN mst_pitstopprofile AS mstpit ON mstpit.profileid = pitdet.profileid
                      WHERE ev.wfeventid = $1
                  ) AS unified_query
                  GROUP BY
                      wfid,
                      stageid,
                      activityid,
                      p_id,
                      profileid,
                      woid,
                      wfeventid,
                      profilevalue,
                      profilename;`;
        }
      } else {
        profileSql = `with cte as(
          SELECT 
           jo.journalid, ws.wfid ,stg.stageid ,act.activityid , pitmap.p_id , pitdet.profileid ,  wo.workorderid, ev.wfeventid
            ,pitdet.profilevalue, mstpit.profilename      
            FROM wms_workorder as wo
            JOIN wms_workflow_eventlog ev ON ev.workorderid= wo.workorderid 
            JOIN wms_workorder_service AS ws ON ws.workorderid = wo.workorderid AND ws.serviceid = ev.serviceid
            JOIN pp_mst_journal AS jo ON jo.journalid = wo.journalid
            JOIN org_mst_deliveryunit AS du ON du.duid = ws.assignedduid
            JOIN org_mst_customer ON org_mst_customer.customerid = wo.customerid 
            JOIN wms_workflowdefinition AS wfd ON wfd.wfdefid = ev.wfdefid
            JOIN wms_mst_stage AS stg ON stg.stageid = wfd.stageid
            JOIN wms_mst_activity AS act ON act.activityid = wfd.activityid
            LEFT JOIN trn_pitstopprofilemap AS pitmap ON pitmap.wfid = ws.wfid  
                AND pitmap.stageid =  stg.stageid 
                AND pitmap.activityid = act.activityid  
                AND pitmap.duid = du.duid AND pitmap.isactive = true 
            LEFT JOIN trn_pitstopprofiledetail AS pitdet ON pitdet.id = pitmap.p_id AND pitdet.isactive = true
            LEFT JOIN mst_pitstopprofile AS mstpit ON mstpit.profileid  = pitdet.profileid
         WHERE ev.wfeventid = $1), res2 as(	 
         select mpit.profileid as sprofileid,mpit.profilename as sprofilename, 
         res.journalid,res.wfid,res.stageid,res.stageid,
         res.activityid,res.p_id,res.profileid,res.workorderid,res.wfeventid,
         res.profilevalue,res.profilename
       
         from mst_pitstopprofile as mpit
         LEFT JOIN cte AS res ON res.profileid = mpit.profileid), res3 as(
         SELECT 
           wfds.stageid AS stgid, 
           wfds.activityid AS actid, 
           wos.workorderid AS woid,
           wserv.wfid AS wflowid,
           dus.duid AS assduid,
           wos.journalid as subjournalid,
            res2.* 
         FROM res2
         JOIN wms_workflow_eventlog AS evs ON evs.wfeventid = $1
         JOIN wms_workflowdefinition AS wfds ON wfds.wfdefid = evs.wfdefid
         JOIN wms_workorder AS wos ON wos.workorderid = evs.workorderid 
         JOIN wms_workorder_service AS wserv ON wserv.workorderid = wos.workorderid AND wserv.serviceid = evs.serviceid
         JOIN org_mst_deliveryunit AS dus ON dus.duid = wserv.assignedduid order by journalid)
         , res4 as (		 
         SELECT 
         res3.stgid as stageid , res3.actid as activityid, res3.woid as workorderid, 
         res3.wflowid as wflowid, res3.assduid as duid, res3.subjournalid as journalid,
         res3.sprofileid as profileid, res3.wfeventid, res3.sprofilename as profilename,
         res3.profilevalue as activityprofilevalue,
         spfd.profilevalue as stageprofilevalue,
         stgprof.profilename as stageprofilename
         FROM res3
         LEFT JOIN trn_pitstopprofilemap AS pmap ON pmap.wfid = res3.wflowid
                  AND pmap.stageid = res3.stgid AND COALESCE(pmap.activityid,0) = 0        
                  AND pmap.duid = res3.assduid AND pmap.isactive = true  
         LEFT JOIN trn_pitstopprofiledetail as spfd on spfd.id = pmap.p_id
           LEFT JOIN mst_pitstopprofile AS stgprof ON stgprof.profileid  = spfd.profileid
         ), res5 as (
         SELECT 
          res4.stageid, res4.activityid, res4.workorderid
         ,res4.wflowid, res4.duid, res4.journalid
         ,res4.profileid, res4.wfeventid, res4.profilename
         ,res4.activityprofilevalue, res4.stageprofilename, res4.stageprofilevalue
         ,pitdet1.profilevalue as j_printprofile
         ,mp1.profilename as printprofilename
         ,pitdet2.profilevalue as j_onlineprofile
         ,mp2.profilename as onlineprofilename
         ,pitdet3.profilevalue as j_refprofile
         ,mp3.profilename as refprofilename
         ,pitdet4.profilevalue as j_pdfprofile
         ,mp4.profilename as pdfprofilename
         ,pitdet5.profilevalue as j_coverprofile 
         ,mp5.profilename as coverprofilename 
         FROM res4 
         LEFT JOIN pp_mst_journal AS jprint ON jprint.journalid = res4.journalid
         LEFT JOIN trn_pitstopprofiledetail AS pitdet1 ON pitdet1.id = jprint.printprofileid AND pitdet1.isactive = true
         LEFT JOIN mst_pitstopprofile AS mp1 on mp1.profileid = pitdet1.profileid
         LEFT JOIN pp_mst_journal AS jonline ON jonline.journalid = res4.journalid
         LEFT JOIN trn_pitstopprofiledetail AS pitdet2 ON pitdet2.id = jonline.onlineprofileid AND pitdet2.isactive = true
         LEFT JOIN mst_pitstopprofile AS mp2 on mp2.profileid = pitdet2.profileid
         LEFT JOIN pp_mst_journal AS jref ON jref.journalid = res4.journalid
         LEFT JOIN trn_pitstopprofiledetail AS pitdet3 ON pitdet3.id = jref.referenceprofileid AND pitdet3.isactive = true
         LEFT JOIN mst_pitstopprofile AS mp3 on mp3.profileid = pitdet3.profileid
         LEFT JOIN pp_mst_journal AS jpdf ON jpdf.journalid = res4.journalid
         LEFT JOIN trn_pitstopprofiledetail AS pitdet4 ON pitdet4.id = jpdf.pdfa2bprofileid AND pitdet4.isactive = true
         LEFT JOIN mst_pitstopprofile AS mp4 on mp4.profileid = pitdet4.profileid
         LEFT JOIN pp_mst_journal AS jcov ON jcov.journalid = res4.journalid
         LEFT JOIN trn_pitstopprofiledetail AS pitdet5 ON pitdet5.id = jcov.coverprofileid AND pitdet5.isactive = true
         LEFT JOIN mst_pitstopprofile AS mp5 on mp5.profileid = pitdet5.profileid
        )
        select res5.stageid,res5.activityid,res5.workorderid,res5.wflowid,res5.duid,res5.journalid,
        res5.profileid,res5.profilename,
        case   
        when res5.activityprofilevalue is null and res5.profilename = 'coverprofile' then
          case  when res5.stageprofilevalue is not null and res5.stageprofilename = 'coverprofile' then 
            res5.stageprofilevalue else case when coverprofilename = 'coverprofile' then j_coverprofile else '' end end 
        when res5.activityprofilevalue is null and res5.profilename = 'referenceprofile' then
          case  when res5.stageprofilevalue is not null and res5.stageprofilename = 'referenceprofile' then 
            res5.stageprofilevalue else case when refprofilename = 'referenceprofile' then j_refprofile else '' end end 
        when res5.activityprofilevalue is null and res5.profilename = 'pdfprofile' then
          case  when res5.stageprofilevalue is not null and res5.stageprofilename = 'pdfprofile' then 
            res5.stageprofilevalue else case when pdfprofilename = 'pdfprofile' then j_pdfprofile else '' end end 
        when res5.activityprofilevalue is null and res5.profilename = 'onlineprofile' then
          case  when res5.stageprofilevalue is not null and res5.stageprofilename = 'onlineprofile' then 
            res5.stageprofilevalue else case when onlineprofilename = 'onlineprofile' then j_onlineprofile else '' end end 
        when res5.activityprofilevalue is null and res5.profilename = 'printprofile' then
          case when res5.stageprofilevalue is not null and res5.stageprofilename = 'printprofile' then 
            res5.stageprofilevalue else case when printprofilename = 'printprofile' then j_printprofile else '' end end 
        when res5.profilename = 'pitStop' then
           null 
        else
        res5.activityprofilevalue
        end as profilevalue,	
        res5.activityprofilevalue,res5.stageprofilename,res5.stageprofilevalue,
        res5.j_printprofile,res5.j_onlineprofile,res5.j_refprofile,res5.j_pdfprofile,res5.j_coverprofile	
        from res5`;
      }

      const profileData = await query(profileSql, [wfEventId]);
      let profileArr = [{}];
      if (profileData.length > 0) {
        const profileMap = {
          pdfprofile: 'pdfa2bprofile',
          onlineprofile: 'onlineprofile',
          printprofile: 'printprofile',
          coverprofile: 'coverprofile',
          referenceprofile: 'referenceprofile',
          mycopy: 'mycopy',
        };
        for (let i = 0; i < profileData.length; i++) {
          const profileName = profileData[i].profilename;
          const profileValue = profileData[i].profilevalue;

          if (profileMap.hasOwnProperty(profileName)) {
            profileArr[0][profileMap[profileName]] = profileValue;
          }
        }
      }

      resolve(profileArr);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const getProfileType = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select otherfield->>'ColorInPrint'as profiletype from wms_workorder where workorderid = $1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const getProfileTypeForBooks = async workOrderId => {
  try {
    const sql = `SELECT bookid FROM wms_workorder WHERE workorderid = $1`;
    const eventData = await query(sql, [workOrderId]);

    if (eventData.length === 0) {
      throw new Error('No book found for the given work order ID');
    }

    const bookId = eventData[0].bookid;
    const isbwSql = `SELECT isbw FROM wms_book_master WHERE id = $1 AND isactive = true`;
    const isbwData = await query(isbwSql, [bookId]);

    return isbwData.length > 0 ? isbwData[0].isbw : false;
  } catch (e) {
    throw new Error(e.message ? e.message : e);
  }
};

export const getChapterId = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select otherfield->>'ChapterId'as ChapterId from wms_workorder where workorderid = $1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
// Springer books revised proof stage enable value
export const updateIsRevisesValue = async (req, res) => {
  try {
    console.log(req.body);

    const { workorderId, isRevisesVal } = req.body;

    const sql = `UPDATE wms_workorder
                   SET otherfield = CASE WHEN otherfield is null THEN
                                '{"isrevises": "${isRevisesVal}"}'::jsonb
                          ELSE
                                jsonb_set(otherfield::jsonb, '{isrevises}', '"${isRevisesVal}"', true)
                        END
                   WHERE workorderid = ${workorderId}`;

    const result = await query(sql);
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

// Springer books revised proof stage reason
export const updateIsRevisesReason = async (req, res) => {
  try {
    console.log(req.body);

    const { workorderId, revisionRequestReason } = req.body;

    const sql = `UPDATE wms_workorder
                   SET otherfield = CASE WHEN otherfield is null THEN
                      '{"revisionRequestReason": "${revisionRequestReason}"}'::jsonb
                          ELSE
                            jsonb_set(otherfield::jsonb, '{revisionRequestReason}', '"${revisionRequestReason}"', true)
                        END
                   WHERE workorderid = ${workorderId}`;

    const result = await query(sql);
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

// Springer books revised proof stage enable value
export const getIsRevisesValue = async (req, res) => {
  try {
    console.log(req.body);

    const { workorderId } = req.body;

    const sql = `select otherfield->>'isrevises' as isrevises, otherfield->>'revisionRequestReason' as revisionRequestReason from wms_workorder where workorderid = ${workorderId}`;

    const result = await query(sql);
    res.status(200).json(result);
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const getBookFileName = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select otherfield->>'BookFileName'as BookFileName from wms_workorder where workorderid = $1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getZipFileName = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select otherfield->>'zipFileName'as ZipFileName from wms_workorder where workorderid = $1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const getBookWorkOrderId = async itemcode => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select * from wms_book_workorder_details where filename = '${itemcode}'`;
      const eventData = await query(sql, []);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getLinkingFileTypePlaceHolders = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 11 and incoming.woid =$1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getChapterFileTypePlaceHolders = async (
  workOrderId,
  woIncomingFileId,
  instanceType,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      let eventData;
      let sql;
      if (instanceType === 'multiple') {
        sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 2 and incoming.woid =$1 and incomingfiledetails.woincomingfileid = $2`;
        eventData = await query(sql, [workOrderId, woIncomingFileId]);
      } else {
        sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 2 and incoming.woid =$1`;
        eventData = await query(sql, [workOrderId]);
      }
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getIndexFileTypePlaceHolders = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 3 and incoming.woid =$1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getPrelimsFileTypePlaceHolders = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 13 and incoming.woid =$1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getPlaceHolderFields = () => {
  return [
    { label: 'ISBN', value: ';ISBN;' },
    { label: 'DOI', value: ';DOI;' },
    { label: 'JournalName', value: ';JournalName;' },
    { label: 'JournalAcronym', value: ';JournalAcronym;' },
    { label: 'JournalVolumeNo', value: ';JournalVolumeNo;' },
    { label: 'StageIteration', value: ';StageIteration;' },
    { label: 'ActivityIteration', value: ';ActivityIteration;' },
    { label: 'BookCode', value: ';BookCode;' },
    { label: 'PitstopProfile', value: ';PitstopProfile;' },
    { label: 'WatermarkProfile', value: ';WatermarkProfile;' },
    { label: 'SmartmetadataProfile', value: ';SmartmetadataProfile;' },
  ];
};

export const updateFileSyncStatus = async (req, res) => {
  const { wfEventId, status } = req.body;
  try {
    const sql = `UPDATE wms_workflow_eventlog SET isfilesynced = $1 WHERE wfeventid = $2`;
    await query(sql, [status, wfEventId]);
    res.send({ message: 'updated file sync status' });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const lockFileSyncStatus = async (req, res) => {
  const { wfEventId, LocalFileNames } = req.body;
  try {
    const sql = `select * from public.wms_workflowactivitytrn_file_map where isactive=true and wfeventid=${wfEventId}`;
    const ExistingFiles = await query(sql);
    const ListToLock = [];
    ExistingFiles.forEach(x => {
      let toLock = true;
      LocalFileNames.forEach(y => {
        if (x.repofilepath.endsWith(y)) {
          toLock = false;
        }
      });
      if (toLock) {
        ListToLock.push(x);
      }
    });
    const awt = [];
    ListToLock.forEach(x => {
      awt.push(lockFileInFileMap(x));
    });
    await Promise.all(awt);
    res.send({ message: 'lockFileSyncStatus updated.' });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getFileSyncStatus = async wfEventId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT isfilesynced FROM public.wms_workflow_eventlog WHERE wfeventid=$1`;
      const eventlogData = await query(sql, [wfEventId]);
      resolve(eventlogData.length ? eventlogData[0].isfilesynced : false);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getFileInfoDetails = ({
  wfEventId,
  workOrderId,
  du,
  customer,
  service,
  stage,
  activity,
  typesId = [],
  activitymodeltypeflow = '',
  issuemstid = '',
  wfDefId = '',
  fileTypeId = '',
  isOtherArticle = false,
  articleOrderSequence = null,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      let filesData = [];
      let filteredFilesInfoFiles;
      let filteredFiles = [];
      let singleBookRunOn = true;

      let sql = `SELECT * FROM public.wms_task_files WHERE wfeventid=${wfEventId}  ORDER BY filesequence`;
      if (activitymodeltypeflow && activitymodeltypeflow == 'Batch') {
        const data = {
          issuemstid,
          wfDefId,
          workorderid: workOrderId,
        };
        const info = await _getIssueWorkorderInfo(data);
        const wfeventids = [];
        info.forEach(list => {
          wfeventids.push(list.wfeventid);
        });
        // wfeventids = wfeventids.join(',');

        const FileInfoSql = `SELECT * FROM public.wms_filemovementconfig where flowto=${wfDefId}`;
        filteredFilesInfoFiles = await query(FileInfoSql);

        sql = `SELECT * FROM public.wms_task_files WHERE wfeventid = ANY(ARRAY[${wfeventids}]) ORDER BY filesequence`;
      } else if (
        activitymodeltypeflow &&
        activitymodeltypeflow == 'Partial' &&
        fileTypeId != '' &&
        isOtherArticle &&
        articleOrderSequence != null
      ) {
        const data = {
          workOrderId,
          wfDefId,
          fileTypeId,
          articleOrderSequence,
        };
        const info = await _getPartialNonArticleDetailsWithArticleOrderSequence(
          data,
        );
        const wfeventids = [];
        let filetypeIds = [];
        info.forEach(list => {
          wfeventids.push(list.wfeventid);
          filetypeIds.push(list.filetypeid);
        });
        // wfeventids = wfeventids.join(',');
        filetypeIds = [...new Set(filetypeIds)];

        const FileInfoSql = `SELECT * FROM public.wms_filemovementconfig where flowto=${wfDefId}`;
        filteredFilesInfoFiles = await query(FileInfoSql);

        let filteredNonArticleList = filteredFilesInfoFiles.filter(
          list => list.destfiletypeid == '83',
        );
        if (filteredNonArticleList && filteredNonArticleList.length) {
          for (var i = 0; i < filetypeIds.length; i++) {
            let datafiles = filetypeIds[i];
            filteredNonArticleList.map(sublist => {
              sublist.srcfiletypeid = datafiles;
              sublist.destfiletypeid = datafiles;
            });
          }
        }
        filteredFilesInfoFiles = [
          ...filteredFilesInfoFiles,
          ...filteredNonArticleList,
        ];

        if (info.length > 1) {
          sql = `SELECT * FROM public.wms_task_files WHERE wfeventid = ANY(ARRAY[${wfeventids}])  ORDER BY filesequence`;
        } else {
          sql = `SELECT * FROM public.wms_task_files WHERE wfeventid=${wfEventId}  ORDER BY filesequence`;
          singleBookRunOn = false;
        }
      } else if (
        activitymodeltypeflow &&
        activitymodeltypeflow == 'Partial' &&
        fileTypeId != '' &&
        isOtherArticle
      ) {
        const data = {
          workOrderId,
          wfDefId,
          fileTypeId,
        };
        const info = await _getPartialNonArticleDetails(data);
        const wfeventids = [];
        let filetypeIds = [];
        info.forEach(list => {
          wfeventids.push(list.wfeventid);
          filetypeIds.push(list.filetypeid);
        });
        // wfeventids = wfeventids.join(',');
        filetypeIds = [...new Set(filetypeIds)];

        const FileInfoSql = `SELECT * FROM public.wms_filemovementconfig where flowto=${wfDefId}`;
        filteredFilesInfoFiles = await query(FileInfoSql);

        let filteredNonArticleList = filteredFilesInfoFiles.filter(
          list => list.destfiletypeid == '83',
        );
        if (filteredNonArticleList && filteredNonArticleList.length) {
          for (var i = 0; i < filetypeIds.length; i++) {
            let datafiles = filetypeIds[i];
            filteredNonArticleList.map(sublist => {
              sublist.srcfiletypeid = datafiles;
              sublist.destfiletypeid = datafiles;
            });
          }
        }
        filteredFilesInfoFiles = [
          ...filteredFilesInfoFiles,
          ...filteredNonArticleList,
        ];

        sql = `SELECT * FROM public.wms_task_files WHERE wfeventid = ANY(ARRAY[${wfeventids}])  ORDER BY filesequence`;
      }
      let files = await query(sql);

      if (
        activitymodeltypeflow &&
        activitymodeltypeflow == 'Partial' &&
        fileTypeId != '' &&
        isOtherArticle &&
        articleOrderSequence != null &&
        singleBookRunOn
      ) {
        filteredFiles = files.filter(list => {
          return (filteredFilesInfoFiles || []).some(sublist => {
            return sublist.destfiletypeid === list.filetypeid;
          });
        });
      } else if (
        activitymodeltypeflow &&
        activitymodeltypeflow == 'Partial' &&
        fileTypeId != '' &&
        isOtherArticle
      ) {
        filteredFiles = files.filter(list => {
          return (filteredFilesInfoFiles || []).some(sublist => {
            return sublist.destfiletypeid === list.filetypeid;
          });
        });
      }
      console.log(filteredFiles, 'filteredFilesfilteredFiles');
      files = filteredFiles && filteredFiles.length > 0 ? filteredFiles : files;
      filesData = await fetchFileDetails({
        du,
        customer,
        service,
        stage,
        activity,
        filesData,
        files,
      });
      if (typesId.length)
        filesData = await fetchExistingFileTyeDetails({
          workOrderId,
          du,
          customer,
          service,
          stage,
          activity,
          typesId,
          filesData,
        });
      resolve(filesData);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

const fetchFileDetails = async ({
  du,
  customer,
  service,
  stage,
  activity,
  filesData,
  files,
}) => {
  const filesMapping = {};
  const foldersMapping = {};
  let totalMsPagesCount = 0;
  const awaits = [];
  files.forEach(file => awaits.push(fileDetailsSub(file)));
  await Promise.all(awaits);
  filesData = filesData.map(file => {
    return {
      ...file,
      files: filesMapping[file.key] || [],
      folders: foldersMapping[file.key].folders || [],
      ischeckedout: filesMapping[file.key].some(
        fmap => fmap.ischeckedout === true,
      ),
    };
  });
  return filesData;

  async function fileDetailsSub(file) {
    const reportFolderName = `${dirname(file.path)}/`;
    const reportFileName = basename(file.path);
    const ext = extname(reportFileName);
    const { ischeckedout, wfeventid } = file;
    const workOrderId = file.workorderid;
    const key = file.allowsubfiletype
      ? `${file.filetype}_${file.woincomingfileid}`
      : file.filetype;
    const pageRange = file.newfilename;
    const pitstopProfile = file.pitstopprofile;
    const pitstopProfilePath = file.pitstopprofilepath;
    const basePath = await getFolderStructure({
      type: file.allowsubfiletype
        ? 'wo_activity_file_subtype'
        : 'wo_activity_filetype',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      fileType: {
        name: file.filetype,
        id: file.filetypeid,
        fileId: file.woincomingfileid,
      },
    });
    const activityBasePath = await getFolderStructure({
      type: 'wo_activity_iteration',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
    });
    const folderRelativePath = reportFolderName.replace(basePath, '');
    const isFolder = !!folderRelativePath;
    const folderName = isFolder ? folderRelativePath.split('/')[0] : '';
    totalMsPagesCount += parseInt(file.mspages ? file.mspages : 0);
    if (!filesMapping[key]) {
      filesData.push({
        singlepdfmerge: file.singlepdfmerge,
        newfiletype: file.newfiletype,
        type: file.filetype,
        typeId: file.filetypeid,
        isFolder,
        basePath,
        activityBasePath,
        name: file.filename,
        selected: false,
        key,
        filesequence: file.filesequence,
        runonfilesequence: file.runonfilesequence,
        incomingFileId: file.woincomingfileid,
        allowSubFileType: file.allowsubfiletype,
        mspages: file.mspages,
        totalMsPages: totalMsPagesCount,
        pageRange,
        pitstopProfile,
        pitstopProfilePath,
        imagecount: file.imagecount,
        wfeventid,
      });
      filesMapping[key] = [];
      foldersMapping[key] = { folders: [] };
    }
    if (isFolder) {
      if (!foldersMapping[key][folderName]) {
        foldersMapping[key][folderName] = true;
        foldersMapping[key].folders.push({
          folderName,
          basePath,
          key,
          type: file.filetype,
          typeId: file.filetypeid,
          singlepdfmerge: file.singlepdfmerge,
          newfiletype: file.newfiletype,
        });
      }
    }
    filesMapping[key].push({
      ...file,
      isFolder,
      folderName,
      folderRelativePath,
      name: reportFileName,
      type: file.filetype,
      typeId: file.filetypeid,
      singlepdfmerge: file.singlepdfmerge,
      newfiletype: file.newfiletype,
      key,
      ext,
      folder: reportFolderName,
      ischeckedout,
    });
    return true;
  }
};

export const _getIssueWorkorderInfo = async item => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = '';
      let condition = ` where `;
      if (item.wfDefId) {
        condition += `evl.wfdefid in (${item.wfDefId})`;
      }
      if (item.issuemstid) {
        condition += ` and wo.issuemstid =${item.issuemstid}`;
      }
      if (item.workorderid) {
        condition += ` and wo.workorderid = ${item.workorderid}`;
      }
      if (item.runonFileSequence) {
        condition += ` and woincom.runonfilesequence = ${item.runonFileSequence}`;
      }
      sql = `select evl.taskinstanceid,evl.wfeventid,evl.woincomingfileid,woincom.filetypeid,wo.workorderid,wo.itemcode, woincom.filename, woincom.filesequence, woincom.runonfilesequence
            from wms_workorder wo 
            join wms_workflow_eventlog evl on wo.workorderid = evl.workorderid 
            join wms_workorder_incomingfiledetails as woincom on woincom.woincomingfileid= evl.woincomingfileid
             ${condition}`;

      // where evl.wfdefid in (${item.wfDefId}) and wo.issuemstid =${item.issuemstid}`;
      // sql = `select wo.workorderid,wo.itemcode,incomdetails.woincomingfileid from  wms_workorder as wo join
      //   wms_workorder_incoming as incom on wo.workorderid = incom.woid
      //   join wms_workorder_incomingfiledetails as incomdetails on incomdetails.woincomingid =incom.woincomingid
      //   ${condition}`;

      const issueInfo = await query(sql);
      resolve(issueInfo);
    } catch (error) {
      reject(error);
    }
  });
};

export const _getPartialNonArticleDetails = async item => {
  return new Promise(async (resolve, reject) => {
    try {
      const sqlBatch = `select eventlog.taskinstanceid,eventlog.wfeventid,eventlog.userid,wo.wotype,wo.workorderid,eventlog.wfdefid,filetypes.filetypeid,filetypes.filetype 
      from wms_workflow_eventlog as eventlog
      join wms_workorder_incomingfiledetails as woinc on woinc.woincomingfileid = eventlog.woincomingfileid
      join  wms_workorder as wo on wo.workorderid = eventlog.workorderid
      join pp_mst_filetype as filetypes on filetypes.filetypeid = woinc.filetypeid
      where eventlog.wfdefid in (${item.wfDefId}) and woinc.filetypeid = ${item.fileTypeId} and  eventlog.workorderid =${item.workOrderId} and filetypes.articletype = 'Other Article'`;
      const resIssueInfo = await query(sqlBatch);
      resolve(resIssueInfo);
    } catch (e) {
      reject(e);
    }
  });
};

export const _getPartialNonArticleDetailsWithArticleOrderSequence =
  async item => {
    return new Promise(async (resolve, reject) => {
      try {
        const sqlBatch = `select eventlog.taskinstanceid,eventlog.wfeventid,eventlog.userid,wo.wotype,wo.workorderid,eventlog.wfdefid,filetypes.filetypeid,filetypes.filetype 
      from wms_workflow_eventlog as eventlog
      join wms_workorder_incomingfiledetails as woinc on woinc.woincomingfileid = eventlog.woincomingfileid
      join  wms_workorder as wo on wo.workorderid = eventlog.workorderid
      join pp_mst_filetype as filetypes on filetypes.filetypeid = woinc.filetypeid
      where eventlog.wfdefid in (${item.wfDefId})  and woinc.articleordersequence = ${item.articleOrderSequence} and woinc.filetypeid = ${item.fileTypeId} and  eventlog.workorderid =${item.workOrderId} and filetypes.articletype = 'Other Article'`;
        const resIssueInfo = await query(sqlBatch);
        resolve(resIssueInfo);
      } catch (e) {
        reject(e);
      }
    });
  };

export const _getNonArticleList = async item => {
  return new Promise(async (resolve, reject) => {
    try {
      const sqlBatch = ` 
      select inco.woincomingfileid,inco.filename,filetype.filetypeid,filetype.filetype from wms_workorder_incoming  as wo
      join  wms_workorder_incomingfiledetails as inco on inco.woincomingid = wo.woincomingid
      join pp_mst_filetype as filetype on filetype.filetypeid = inco.filetypeid
      where wo.woid= ${item.workOrderId} and filetype.articletype = 'Other Article'`;
      const resIssueInfo = await query(sqlBatch);
      resolve(resIssueInfo);
    } catch (e) {
      reject(e);
    }
  });
};

export const fetchExistingFileTyeDetails = async ({
  workOrderId,
  du,
  customer,
  service,
  stage,
  activity,
  typesId,
  filesData,
}) => {
  const incomingFileId = filesData.map(fd => fd.incomingFileId);
  const sql = `SELECT pp_mst_filetype.filetype, pp_mst_filetype.filetypeid, pp_mst_filetype.allowsubfiletype,
    wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.woincomingfileid, 
	wms_workorder_incomingfiledetails.filesequence, wms_workorder_incomingfiledetails.mspages, 
	wms_workorder_incomingfiledetails.newfilename, wms_workorder_incomingfiledetails.pitstopprofile, wms_mst_pitstopprofile.pitstopprofile as pitstopprofilepath
    FROM wms_workorder_incomingfiledetails
    join wms_workorder_incoming on wms_workorder_incoming.woincomingid=wms_workorder_incomingfiledetails.woincomingid
	left join wms_mst_pitstopprofile on wms_mst_pitstopprofile.pitstopprofileid = wms_workorder_incomingfiledetails.pitstopprofile
    join pp_mst_filetype on wms_workorder_incomingfiledetails.filetypeid=pp_mst_filetype.filetypeid
    where wms_workorder_incoming.woid= $1 and Not(wms_workorder_incomingfiledetails.woincomingfileid = any($2)) and pp_mst_filetype.filetypeid = any($3)`;
  const existingFileTypes = await query(sql, [
    workOrderId,
    incomingFileId,
    typesId,
  ]);
  const awt = [];
  existingFileTypes.forEach(existingFileType => {
    awt.push(existingFileTypeFunction(existingFileType));
  });
  await Promise.all(awt);
  async function existingFileTypeFunction(existingFileType) {
    const key = existingFileType.allowsubfiletype
      ? `${existingFileType.filetype}_${existingFileType.woincomingfileid}`
      : existingFileType.filetype;
    const basePath = await getFolderStructure({
      type: existingFileType.allowsubfiletype
        ? 'wo_activity_file_subtype'
        : 'wo_activity_filetype',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      fileType: {
        name: existingFileType.filetype,
        id: existingFileType.filetypeid,
        fileId: existingFileType.woincomingfileid,
      },
    });
    const activityBasePath = await getFolderStructure({
      type: 'wo_activity_iteration',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
    });
    const fileData = {
      type: existingFileType.filetype,
      typeId: existingFileType.filetypeid,
      isFolder: false,
      basePath,
      activityBasePath,
      name: existingFileType.filename,
      selected: false,
      key,
      filesequence: existingFileType.filesequence,
      incomingFileId: existingFileType.woincomingfileid,
      allowSubFileType: existingFileType.allowsubfiletype,
      mspages: existingFileType.mspages,
      totalMsPages: 0,
      files: [],
      folders: [],
      ischeckedout: false,
      pageRange: existingFileType.newfilename,
      pitstopProfile: existingFileType.pitstopprofile,
      pitstopProfilePath: existingFileType.pitstopprofilepath,
    };
    filesData.push(fileData);
  }
  return filesData;
};

export const fetchValidationDetails = async (
  filesInfo,
  validationFileConfig,
  placeHolders,
  eventData,
  mandatorySaveFile,
  workOrderId,
) => {
  const {
    backupFiles,
    missedFiles,
    requiredFiles,
    globPatternFiles,
    readOnlyFiles,
    overwriteFiles,
    lwfFiles,
    UOMFile,
  } = await getFileValidation(
    filesInfo,
    validationFileConfig,
    placeHolders,
    eventData,
    mandatorySaveFile,
    workOrderId,
  );
  let UOMDetails = {};
  const missedFileTypeInfo = {};
  const fileTypes = [];
  filesInfo = filesInfo.map(fileInfo => {
    if (!fileTypes.includes(fileInfo.typeId)) fileTypes.push(fileInfo.typeId);
    const files = fileInfo.files.map(file => {
      const isUOM = isUOMFile(fileInfo.key, file.path, UOMFile);
      if (isUOM) {
        UOMDetails = file;
      }
      return {
        ...file,
        isReadOnly: isReadOnlyFile(fileInfo.key, file.path, readOnlyFiles),
        overwrite: isOverwriteFile(fileInfo.key, file.path, overwriteFiles),
        lwfDetails: getLWFDetails(fileInfo.key, file.path, lwfFiles),
        isUOM,
      };
    });
    const folders = fileInfo.folders.map(folderInfo => {
      const readWriteFiles = files.filter(
        file =>
          file.isFolder &&
          file.folderName == folderInfo.folderName &&
          !file.isReadOnly,
      );
      return { ...folderInfo, isReadOnly: readWriteFiles.length === 0 };
    });
    return {
      ...fileInfo,
      files,
      folders,
      globPatternFiles: getGlobPatternFiles(fileInfo.key, globPatternFiles),
      missedFiles: getMissedValidationFiles(fileInfo.key, missedFiles),
      requiredFiles: getRequiredValidationFiles(fileInfo.key, requiredFiles),
    };
  });
  missedFiles.forEach(file => {
    if (!file.key) {
      if (!missedFileTypeInfo[file.typeId]) {
        missedFileTypeInfo[file.typeId] = [file];
      } else {
        missedFileTypeInfo[file.typeId].push(file);
      }
    }
  });

  if (Object.keys(UOMDetails).length == 0 && Object.keys(UOMFile).length != 0) {
    UOMFile.ext = extname(UOMFile.name);
    UOMDetails = UOMFile;
  }

  const filesAdditionalInfo = {
    missedFileTypeInfo,
    UOMDetails,
    missedFiles,
    requiredFiles,
    readOnlyFiles,
    overwriteFiles,
    UOMFile,
    fileTypes,
    backupFiles,
  };
  filesInfo.sort((a, b) => {
    return a.filesequence - b.filesequence;
  });
  filesInfo.forEach(ele => {
    ele.files.forEach(element => {
      if (
        element.lwfDetails != undefined &&
        element.lwfDetails.isSoftwareOpen == true
      )
        element.isSoftwareOpen = true;
    });
  });
  return { filesInfo, filesAdditionalInfo };
};

const getFileValidation = (
  filesInfo,
  validationFileConfig,
  placeHolders,
  eventData,
  mandatorySaveFile,
  workOrderId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (Object.keys(validationFileConfig).length) {
        const fileDetails = filesInfo.map(fileInfo => {
          return {
            name: fileInfo.name,
            key: fileInfo.key,
            basePath: fileInfo.basePath,
            placeHolders: {
              FileTypeName: fileInfo.name,
              PageRange: fileInfo.pageRange,
              JnlTypeFileTypeName: fileInfo.name + placeHolders.JnlTypeFileName,
              ChapterNumber: fileInfo.name.includes('_Chapter')
                ? fileInfo.name.replace('_Chapter', '')
                : fileInfo.name,
            },
            typeId: fileInfo.typeId,
            files: fileInfo.files,
          };
        });
        const fileValidationStatus = await getFileValidationStatus(
          validationFileConfig,
          fileDetails,
          placeHolders,
          eventData,
          mandatorySaveFile,
          workOrderId,
        );
        resolve(fileValidationStatus);
      } else {
        resolve({
          missedFiles: [],
          requiredFiles: [],
          readOnlyFiles: [],
          overwriteFiles: [],
          globPatternFiles: [],
          lwfFiles: [],
          UOMFile: {},
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};

const isReadOnlyFile = (key, path, readOnlyFiles) => {
  const index = readOnlyFiles.findIndex(ro => ro.key == key && ro.path == path);
  return index !== -1;
};

const isOverwriteFile = (key, path, overwriteFiles) => {
  const index = overwriteFiles.findIndex(
    ro => ro.key == key && ro.path == path,
  );
  return index !== -1;
};

const getLWFDetails = (key, path, files) => {
  const fileData = files.find(ro => ro.key == key && ro.path == path);
  return fileData || { name: '', src: '', dest: '', isRoot: false };
};

const isUOMFile = (key, path, UOMFile) => {
  return UOMFile.key == key && UOMFile.path == path;
};

const getMissedValidationFiles = (key, missedFiles) => {
  return missedFiles.filter(fs => fs.key == key);
};

const getRequiredValidationFiles = (key, requiredFiles) => {
  return requiredFiles.filter(fs => fs.key == key);
};

const getGlobPatternFiles = (key, globPatternFiles) => {
  return globPatternFiles.filter(fs => fs.key == key);
};
async function lockFileInFileMap(x) {
  return new Promise(async (resolve, reject) => {
    try {
      // await lockDocument(x.repofileuuid)
      const locksql = `update public.wms_workflowactivitytrn_file_map set isactive = false where actfilemapid = ${x.actfilemapid}`;
      await query(locksql);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
}

// export const _changeMandatoryFiles = async (filesData, workOrderId) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const sql = `select jn.newsletter,wo.workorderid,wo.customerid from wms_workorder as wo
//       join pp_mst_journal as jn on jn.journalid = wo.journalid
//       where wo.workorderid = ${workOrderId}`;
//       const JournalDetails = await query(sql);
//       console.log('JournalDetails', JournalDetails);
//       if (JournalDetails.length > 0) {
//         const { newsletter, customerid } = JournalDetails[0];

//         if (newsletter === true) {
//           filesData.filesAdditionalInfo.missedFiles.forEach(list => {
//             if (list.conditionalTags && list.conditionalTags.enable == true) {
//               list.isMandatory = false;
//             }
//           });
//         } else if (newsletter === false && customerid === '13') {
//           filesData.filesAdditionalInfo.requiredFiles.forEach(list => {
//             if (list.conditionalTags && list.conditionalTags.enable) {
//               list.isMandatory = false;
//               console.log('requiredFiles', list.isMandatory);
//             }
//           });

//           filesData.filesAdditionalInfo.missedFiles.forEach(list => {
//             if (list.conditionalTags && list.conditionalTags.enable) {
//               list.isMandatory = false;
//               console.log('missedfiles', list.isMandatory);
//             }
//           });
//         }
//         resolve(filesData);
//       } else {
//         resolve(filesData);
//       }
//       // resolve(filesData);
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

export const _changeMandatoryFiles = async (filesData, workOrderId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select jn.newsletter,wo.workorderid,wo.customerid,jn.otherdetails,jn.isiauthor from wms_workorder as wo
      join pp_mst_journal as jn on jn.journalid = wo.journalid
      where wo.workorderid = ${workOrderId}`;
      const JournalDetails = await query(sql);
      console.log('JournalDetails', JournalDetails);
      if (JournalDetails.length > 0) {
        const { newsletter, customerid } = JournalDetails[0];

        if (newsletter === true) {
          filesData.filesAdditionalInfo.missedFiles.forEach(list => {
            if (list.conditionalTags && list.conditionalTags.enable == true) {
              list.isMandatory = false;
            }
          });
        } else if (
          newsletter === false &&
          customerid === '13' &&
          (JournalDetails[0].otherdetails.isPapAEnable == false ||
            JournalDetails[0].otherdetails == null)
        ) {
          filesData.filesAdditionalInfo.requiredFiles.forEach(list => {
            if (list.conditionalTags && list.conditionalTags.enable) {
              list.isMandatory = false;
              console.log('requiredFiles', list.isMandatory);
            }
          });

          filesData.filesAdditionalInfo.missedFiles.forEach(list => {
            if (list.conditionalTags && list.conditionalTags.enable) {
              list.isMandatory = false;
              console.log('missedfiles', list.isMandatory);
            }
          });
        } else if (
          newsletter === false &&
          customerid === '13' &&
          JournalDetails[0].otherdetails.isPapAEnable == false
        ) {
          filesData.filesAdditionalInfo.requiredFiles.forEach(list => {
            if (list.skippapFiles && list.skippapFiles == 'isPapAEnable') {
              list.isMandatory = false;
              console.log('requiredFiles', list.isMandatory);
            }
          });
          filesData.filesAdditionalInfo.missedFiles.forEach(list => {
            if (list.skippapFiles && list.skippapFiles == 'isPapAEnable') {
              list.isMandatory = false;
              console.log('missedfiles', list.isMandatory);
            }
          });
        }
        resolve(filesData);
      } else {
        resolve(filesData);
      }
      // resolve(filesData);
    } catch (error) {
      reject(error);
    }
  });
};

export const getConitionalTagsForNewConfig = async (req, res) => {
  const { fileConfig, journalType } = req.body;
  try {
    const fileConfigs = fileConfig.files.length > 0 ? fileConfig.files : [];
    let message = '';
    for (let i = 0; i < fileConfigs.length; i++) {
      const __fileDetails = fileConfigs[i];
      const enableCustomFiles =
        !!Object.keys(__fileDetails).includes('conditionalTags');
      if (enableCustomFiles && __fileDetails.conditionalTags.enable) {
        if (journalType == 'Print') {
          __fileDetails.mandatoryCheck.save = true;
          message = __fileDetails.conditionalTags.status.valid;
        } else {
          message = __fileDetails.conditionalTags.status.invalid;
        }
      }
    }
    res.send({ status: 200, message, data: fileConfigs });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const getConitionalTags = async (req, res) => {
  const { fileConfig, workOrderId } = req.body;
  try {
    const { message, fileConfigs } = _getConitionalTags(
      fileConfig,
      workOrderId,
    );
    res.send({ status: 200, message, data: fileConfigs });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const _getConitionalTags = async (
  fileConfig,
  workOrderId,
  placeHolders,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select jn.journaltype, wo.workorderid 
                   from wms_workorder as wo
                   join pp_mst_journal as jn on jn.journalid = wo.journalid
                   where wo.workorderid = ${workOrderId}`;
      const JournalDetails = await query(sql);
      const journalType =
        JournalDetails.length > 0 ? JournalDetails[0].journaltype : '';

      const booksql = `select * from wms_workorder as wo
                       join wms_book_master as bookmaster on bookmaster.id = wo.bookid
                       where workorderid = ${workOrderId}`;
      const BookMasterDetails = await query(booksql);
      const myCopy =
        BookMasterDetails.length > 0
          ? BookMasterDetails[0].mycopy?.toLowerCase()
          : '';
      const book2 =
        BookMasterDetails.length > 0
          ? BookMasterDetails[0].book2?.toLowerCase()
          : '';
      const tocFile = 'Yes';

      const sql1 = `select jn.journaltype, wo.workorderid, jn.otherdetails, ws.wfstageid 
                    from wms_workorder as wo
                    join pp_mst_journal as jn on jn.journalid = wo.journalid
                    left join wms_workorder_stage ws on ws.workorderid = wo.workorderid
                    where wo.workorderid = ${workOrderId} and ws.wfstageid = 22`;
      const inputData = await query(sql1);

      let isPapAEnable = false;
      if (
        inputData.length > 0 &&
        inputData[0].otherdetails !== null &&
        typeof inputData[0].otherdetails === 'object' &&
        inputData[0].otherdetails.isPapAEnable === false &&
        inputData[0].wfstageid == 22
      ) {
        isPapAEnable = true;
      }

      const fileConfigs = fileConfig.length > 0 ? fileConfig : [];
      let message = '';
      for (let i = 0; i < fileConfigs.length; i++) {
        const __fileDetails = fileConfigs[i];

        if (isPapAEnable && __fileDetails.skippapFiles === 'isPapAEnable') {
          if (
            __fileDetails.mandatoryCheck &&
            'save' in __fileDetails.mandatoryCheck
          ) {
            __fileDetails.mandatoryCheck.save = false;
          }
          continue; // Skip further processing for this file
        }

        const enableCustomFiles =
          !!Object.keys(__fileDetails).includes('conditionalTags');
        if (enableCustomFiles && __fileDetails.conditionalTags.enable) {
          const name = __fileDetails.conditionalTags.key;

          const formattedName = getFormattedName(name, placeHolders);

          if (
            journalType == formattedName ||
            (myCopy == 'yes' && name?.toLowerCase().includes('mycopy')) ||
            (book2 == 'yes' && name?.toLowerCase().includes('book2')) ||
            formattedName == tocFile
          ) {
            if (
              __fileDetails.mandatoryCheck &&
              Object.keys(__fileDetails.mandatoryCheck).includes('save')
            ) {
              __fileDetails.mandatoryCheck.save = true;
              message = __fileDetails.conditionalTags.status.valid;
            }
            if (
              __fileDetails.mandatoryCheck &&
              Object.keys(__fileDetails.mandatoryCheck).includes('reject') &&
              __fileDetails.mandatoryCheck.reject
            ) {
              __fileDetails.mandatoryCheck.reject = true;
              message = __fileDetails.conditionalTags.status.valid;
            }
          } else if (
            (__fileDetails.mandatoryCheck &&
              Object.keys(__fileDetails.mandatoryCheck).includes('save')) ||
            (__fileDetails.mandatoryCheck &&
              Object.keys(__fileDetails.mandatoryCheck).includes('reject'))
          ) {
            __fileDetails.mandatoryCheck.save = false;
            if (
              __fileDetails.mandatoryCheck &&
              Object.keys(__fileDetails.mandatoryCheck).includes('reject')
            ) {
              __fileDetails.mandatoryCheck.reject = false;
            }
            message = __fileDetails.conditionalTags.status.invalid;
          }
        }
      }
      resolve({ message, data: fileConfigs });
    } catch (e) {
      reject(e);
    }
  });
};
