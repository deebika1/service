/* eslint-disable */
import { basename, extname, dirname, join } from 'path';
import fs, { createReadStream } from 'fs';
import { fileURLToPath } from 'url';
import FormData from 'form-data';
import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { query } from '../../database/postgres.js';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import {
  getFileSeq,
  updateStageSequence,
  _getStageInfoFromCamunda,
  _updateStageInfoToCamunda,
  _updateActivityStageInfoToCamunda,
  getdmsType,
} from '../bpmn/listener/create.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';
import {
  fetchValidationDetails,
  getFileInfoDetails,
  getWorkflowPlaceHolders,
} from './fileDetails.js';
import { getFormattedName } from '../utils/fileValidation/utils.js';
import {
  generateFileSeqDetails,
  checkout,
} from '../utils/custom/filegeneration.js';
import { addSubJob, checkItracksExits, subJobAudit } from '../iTracks/index.js';

import { _isFileExist } from '../utils/okm/index.js';

import { checkInFiles } from '../woi/additionalInfo.js';
import { getFolderPath, getFolderStructure } from '../utils/wmsFolder/index.js';
import { _getWoDetailsForFTP } from '../woi/index.js';
import { _retreiveLocalFiles } from '../utils/local/index.js';
import { _listAllFiles } from '../utils/azure/index.js';

const service = new Service();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const fileTypeList = async (req, res) => {
  const { configFileType } = req.body;
  const { journalId } = req.body;
  let sql = `SELECT filetypeid as value, filetype as label,allowsubfiletype FROM pp_mst_filetype `;
  if (configFileType && configFileType.length > 0) {
    sql += 'where filetypeid in (';
    configFileType.forEach(data => {
      sql += `${data},`;
    });
    sql += '0)';
  } else if (journalId) {
    const journalSql = `select * from pp_mst_journal_nonart_types where journalid=${journalId}`;
    await query(journalSql).then(journalData => {
      sql += 'where filetypeid in (';
      journalData.forEach(jd => {
        sql += `${jd.filetypeid},`;
      });
      sql += '10)';
    });
  } else {
    sql += `WHERE pp_mst_filetype.category IN ('${req.body.categoryType}')`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const checkFileTypeStatus = (req, res) => {
  const { value, woid } = req.body;
  const name = value ? value.trim() : '';
  let sql = '';
  sql = `SELECT woincomingfileid,filename,pp_mst_filetype.filetype,allowsubfiletype FROM public.wms_workorder_incoming 
   JOIN public.wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
                   JOIN public.pp_mst_filetype ON pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
   WHERE wms_workorder_incoming.woid =${woid}   and LOWER(filename :: text) = '${name.toLowerCase()}'`;
  console.log(sql, 'check avail');
  query(sql)
    .then(data => {
      if (data.length) {
        res.status(200).json({ status: false, message: 'Already exist' });
      } else {
        res.status(200).json({ status: true, message: 'Available' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const getInstructionDetails = async (checklistId, stageId) => {
  let condition = '';
  if (stageId !== null) {
    condition += `AND stageId=${stageId}`;
  }
  return new Promise(async resolve => {
    let sql = `select * from wms_mst_checklistinstruction where checklistid=${checklistId} ${condition} and isactive=1 order by checklistinstructionid `;
    console.log(sql, 'sql');
    await query(sql)
      .then(async instructions => {
        console.log(instructions, 'instructions');
        if (instructions.length) {
          const tempInstructions = [];
          await Promise.all(
            instructions.map(async instruction => {
              sql = `select * from wms_mst_checklistinstruction_answer where checklistinstructionid=${instruction.checklistinstructionid} order by checklistinstructionanswerid`;
              console.log(sql, 'sql');
              await query(sql).then(answers => {
                console.log(answers, 'answers');
                instruction.answers = answers;
                tempInstructions.push(instruction);
              });
            }),
          );
          console.log(tempInstructions, 'tempInstructions');
          resolve(tempInstructions);
        } else {
          resolve([]);
        }
      })
      .catch(() => {
        resolve([]);
      });
  });
};

export const getChecklist = async (req, res) => {
  const { wfId, stageId, skillId, duId, customerId, workorderId, activityid } =
    req.body;
  let sql = `SELECT DISTINCT checklist.activityid, checklist.stageid, checklist.checklisttypeid, checklist.customerid, checklist.duid, checklist.wfid, 
       workorder.workorderid, checklist.subdivisionid, checklist.divisionid, checklist.checklistid
FROM wms_mst_checklist checklist 
JOIN wms_workorder workorder 
  ON workorder.subdivisionid = checklist.subdivisionid 
  AND workorder.divisionid = checklist.divisionid 
WHERE checklist.customerid = ${customerId ? customerId : null} 
  AND checklist.duid = ${duId ? duId : null} 
  AND checklist.wfid = ${wfId ? wfId : null} 
  AND checklist.checklisttypeid = 2 
  AND workorder.workorderid = ${workorderId ? workorderId : null} 
  AND checklist.isactive = 1 
  AND checklist.activityid = ${activityid ? activityid : null} 
  AND checklist.stageid = ${stageId ? stageId : null};
`;
  await query(sql)
    .then(async checklist => {
      if (checklist.length) {
        checklist[0].instructions = await getInstructionDetails(
          checklist[0].checklistid,
          stageId,
        );
        res.status(200).send({ data: checklist, status: true });
      } else {
        sql = `SELECT DISTINCT checklist.activityid, checklist.stageid, checklist.checklisttypeid, checklist.checklistid
FROM wms_mst_checklist checklist
WHERE checklist.activityid = ${activityid ? activityid : null} 
  AND checklist.stageid = ${stageId ? stageId : null} 
  AND checklist.checklisttypeid = 1 
  AND checklist.isactive = 1;
`;
        await query(sql)
          .then(async checklist1 => {
            if (checklist1.length) {
              checklist1[0].instructions = await getInstructionDetails(
                checklist1[0].checklistid,
                null,
              );
              res.status(200).send({ data: checklist1, status: true });
            } else {
              res.status(200).send({ data: [], status: true });
            }
          })
          .catch(error => {
            res.status(400).send({ data: [], status: false, message: error });
          });
      }
    })
    .catch(error => {
      res.status(400).send({ data: [], status: false, message: error });
    });
};

export const getviewProofing = (req, res) => {
  const { type, bookcode } = req.body;
  let sql1 = '';
  if (type == 'Collation') {
    sql1 = `select pc_url from wms_mst_pcvalidationftp_resp where articlename='${bookcode}' and isactive=true order by signalid desc limit 1`;
  } else {
    sql1 = `select pc_url from wms_mst_pcvalidationftp_resp where articlename='${bookcode}' and pc_submitted_by='Proof Collator' and isactive=true order by signalid desc limit 1`;
  }
  console.log(sql1, 'sqlforToolOption');
  query(sql1)
    .then(response => {
      const newRes = response && response.length > 0 ? response[0].pc_url : '';
      res.status(200).json({ data: newRes, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const checktoolLinkStatus = async (req, res) => {
  const {
    output,
    workorderid,
    isparentlink,
    stageid,
    serviceid,
    stageiterationcount,
    toolid,
  } = req.body;

  const sql = `SELECT COUNT(*) FROM wms_toolsoutput_details where workorderid =${workorderid}`;
  await query(sql)
    .then(async getCount => {
      const sql1 = `UPDATE wms_toolsoutput_details SET serviceid= '${serviceid}',output ='${output}',stageid= '${stageid}',stageiterationcount ='${stageiterationcount}',
    toolid='${toolid}' WHERE workorderid = ${workorderid} RETURNING output`;
      const sql2 = `Insert into wms_toolsoutput_details(workorderid,serviceid,stageid,stageiterationcount,toolid,output) values (${workorderid},${serviceid},
      ${stageid},${stageiterationcount},${toolid},${output}) RETURNING output`;
      const sql3 = getCount.length > 0 && isparentlink ? sql1 : sql2;
      query(sql3)
        .then(data => {
          res.status(200).json({ data, status: true });
        })
        .catch(() => {
          res
            .status(400)
            .send({ status: false, message: 'Getting iNet link failed.' });
        });
    })
    .catch(() => {
      res.status(400).send({
        data: [],
        status: false,
        message: 'Getting iNet link failed.',
      });
    });
};

export const getjournalid = (req, res) => {
  const { journalid } = req.body;
  const sql = `select proofingtype from pp_mst_journal  where journalid='${journalid}' `;
  // let sql = `select checklist from wms_workflow_eventlog where wfeventid=2571`
  query(sql)
    .then(response => {
      res.status(200).json({ data: response[0].proofingtype, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getHistory = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.type === 'allTask') {
    sql = `SELECT wms_workflow_eventlog_details.userid,
        (select min(wed1.timestamp) as enddate from wms_workflow_eventlog_details as wed1  
               WHERE wed1.wfeventid=$1 and wed1.operationtype = 'Work in progress' ) as starttime,
        wms_mst_stage.stagename||'('||stageiterationcount||')'  as stagename,  
        wms_mst_activity.activityname||'('||wms_workflow_eventlog_details.actualactivitycount||')' as activityname,
        (select max(timestamp) from(											
                select * from(											
                       SELECT
							timestamp, 
							operationtype,
							LEAD(operationtype,1) OVER (
							ORDER BY timestamp
							) next_operation
	
						FROM wms_workflow_eventlog_details   
               			WHERE wfeventid=$1)as m
			     order by timestamp desc limit 1)s
			     where operationtype!='Work in progress') as endtime,
        ( SELECT sum(tt)
	         from (
	               SELECT wfeventid,operationtype,tt
	                    from (
		                    select  
                              wfeventid,
		                      operationtype,
                              lead(timestamp) over (order by timestamp)-timestamp as tt                        
                            from wms_workflow_eventlog_details where wfeventid=$1
	                    ) as w 
                   where wfeventid=$1 and operationtype='Work in progress'
			) as total
    having bool_and(tt is not null)
		)as timetaken ,		
         wms_workflow_eventlog.wfeventid from wms_workflow_eventlog
         JOIN wms_workflowdefinition ON wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid 
         JOIN wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid
         JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
         JOIN wms_workflow_eventlog_details on wms_workflow_eventlog_details.wfeventid=wms_workflow_eventlog.wfeventid
         where  wms_workflow_eventlog.wfeventid=$1
         order  by wms_workflow_eventlog_details.timestamp limit 1
            `;
  } else if (reqData.type === 'task') {
    sql = `SELECT wed.wfeventid, wed.operationtype, wed.timestamp as timestamp, wed.userid, us.username FROM public.wms_workflow_eventlog_details as wed
        JOIN public.wms_user as us ON us.userid = wed.userid
        WHERE wed.wfeventid=$1`;
  } else if (reqData.type === 'file') {
    sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map WHERE wfeventid=$1`;
  }

  query(sql, [reqData.wfEventId])
    .then(response => {
      if (reqData.type === 'allTask') {
        response.forEach(d => {
          d.timetaken =
            d.timetaken != null
              ? `${
                  d.timetaken.hours != undefined
                    ? d.timetaken.hours.length == 1
                      ? `0${d.timetaken.hours}`
                      : d.timetaken.minutes
                    : '00'
                }:${
                  d.timetaken.minutes != undefined
                    ? d.timetaken.minutes.length == 1
                      ? `0${d.timetaken.minutes}`
                      : d.timetaken.minutes
                    : '00'
                }:${
                  d.timetaken.seconds != undefined
                    ? d.timetaken.seconds.length == 1
                      ? `0${d.timetaken.seconds}`
                      : d.timetaken.seconds
                    : '00'
                }`
              : '';
        });
      }
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getpathforFileSequence = async woId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `Select wo.itemcode,wst.wfstageid,st.stagename,wst.stageiterationcount,wo.customerid,cu.customername from wms_workorder as wo 
  left join wms_workorder_stage as wst on wst.workorderid=wo.workorderid 
  left join wms_mst_stage as st on st.stageid=wst.wfstageid
  left join org_mst_customer as cu on cu.customerid=wo.customerid
  where wo.workorderid ='${woId}' order by wst.sequence limit 1 `;
      await query(sql)
        .then(async response => {
          var folderPath = await _getWoDetailsForFTP({
            customer: response[0].customername,
            stage: response[0].stagename,
            jobname: response[0].itemcode,
            stageiterationcount: response[0].stageiterationcount,
          });
          resolve({
            folderPath,
            customer: response[0].customerid,
            status: true,
          });
        })
        .catch(error => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

export const saveUploadFile = (req, res) => {
  const reqData = req.body;

  if (!('path' in reqData)) {
    res.status(400).send({ message: 'File path key should not be empty' });
  } else if (reqData.path == '') {
    res.status(400).send({ message: 'File path should not be empty' });
  } else if (reqData.uuid == '') {
    res.status(400).send({ message: 'Uuid should not be empty' });
  } else {
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded)
        VALUES('${reqData.wfEventId}', '${reqData.uuid}', '${reqData.path}', null, true, false)`;
    query(sql)
      .then(() => {
        res.status(200).json({ message: 'File uploaded successfully' });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};

export const fileRead = (req, res) => {
  // const reqData = req.body;
  // var file = fs.createReadStream('upload/sample.pdf','binary');
  // var stat = fs.statSync('upload/sample.pdf');
  // res.setHeader('Content-Length', stat.size);
  // res.setHeader('Content-Type', 'application/pdf');
  // res.setHeader('Content-Disposition', 'attachment; filename=quote.pdf');
  // file.pipe(res);

  const data = fs.readFileSync('upload/sample.pdf');
  res.contentType('application/pdf');
  res.send(data);
};

export const updateOrderNo = async (req, res) => {
  try {
    const { jobId, woId, files, custId } = req.body;

    if (files.length > 0) {
      const queries = [];
      files.forEach(file => {
        let sqlForUpdate = '';
        const toSet = [];
        if (file.pitstopProfile)
          toSet.push(`pitstopprofile=${file.pitstopProfile}`);
        if (file.filesequence) toSet.push(`filesequence=${file.filesequence}`);
        if (file.newfiletype) toSet.push(`newfiletype=${file.newfiletype}`);
        if (file.singlepdfmerge)
          toSet.push(`singlepdfmerge=${file.singlepdfmerge}`);
        sqlForUpdate = `UPDATE public.wms_workorder_incomingfiledetails SET ${toSet.join(
          ',',
        )} WHERE woincomingfileid=${file.woincomingfileid}`;
        queries.push(query(sqlForUpdate, []));
      });
      await Promise.all(queries);
      const result = await updatefileSequenceXML(req.body, jobId, woId);
      const fileSequenceDetails = await getFileSeq(woId);
      if (custId !== '13') {
        await updateStageSequence(woId, fileSequenceDetails, null);
      }
      res.status(200).json({
        data: 'Files has been reordered',
        uuid: result.uuid,
        name: result.name,
        path: result.path,
      });
    } else {
      throw new Error('No Files to Reorder');
    }
  } catch (err) {
    res.status(400).send({ message: err.message });
  }
};

export const updateOrderNoFromIncoming = async (req, res) => {
  try {
    const { jobId, woId, files, custId } = req.body;

    if (files.length > 0) {
      const queries = [];
      files.forEach(file => {
        let sqlForUpdate = '';
        const toSet = [];
        if (file.filesequence) toSet.push(`filesequence=${file.filesequence}`);
        sqlForUpdate = `UPDATE public.wms_workorder_incomingfiledetails SET ${toSet.join(
          ',',
        )} WHERE woincomingfileid=${file.woincomingfileid}`;
        queries.push(query(sqlForUpdate, []));
      });
      await Promise.all(queries);
      const result = await updatefileSequenceXML(req.body, jobId, woId);
      const fileSequenceDetails = await getFileSeq(woId);
      if (custId !== '13') {
        await updateStageSequence(woId, fileSequenceDetails, null);
      }
      res.status(200).json({
        data: 'Files has been reordered',
        uuid: result.uuid,
        name: result.name,
        path: result.path,
      });
    } else {
      throw new Error('No Files to Reorder');
    }
  } catch (err) {
    res.status(400).send({ message: err.message });
  }
};

export const updatefileSequenceXML_Old = async request => {
  return new Promise(async resolve => {
    let sql = `select definition.fileconfig,* from wms_workflow_eventlog eventlog join 
    wms_workflowdefinition definition on eventlog.wfdefid=definition.wfdefid where wfeventid=${request.wfeventid}`;
    let workorderid = '';
    await query(sql, []).then(async data => {
      if (data.length) {
        // updated for fileconfig restructure
        data[0].fileconfig = ReStructureFileConfig(data[0].fileconfig);
        const fileConfigKeys = Object.keys(data[0].fileconfig.fileTypes);
        let filename = '';
        let updatefile = false;
        workorderid = data[0].workorderid;
        for (let i = 0; i < fileConfigKeys.length; i++) {
          const { files } = data[0].fileconfig.fileTypes[fileConfigKeys[i]];
          for (let j = 0; j < files.length; j++) {
            if (files[j].custom && files[j].custom.generate_filesequence) {
              console.log('file yuvaraj', files[j]);
              filename = files[j].name;
              updatefile = true;
              break;
            }
          }
        }
        if (updatefile) {
          console.log(
            getFormattedName(
              filename,
              await getWorkflowPlaceHolders(request.wfeventid),
            ),
          );
          sql = `SELECT * FROM public.wms_task_files where wfeventid=${request.wfeventid}`;
          await query(sql, []).then(async taskfiles => {
            console.log(taskfiles);
            if (taskfiles.length) {
              for (let i = 0; i < taskfiles.length; i++) {
                const reportFolderName = `${dirname(taskfiles[i].path)}/`;
                const reportFileName = basename(taskfiles[i].path);
                const ext = extname(reportFileName);
                if (
                  reportFileName ===
                  getFormattedName(
                    filename,
                    await getWorkflowPlaceHolders(request.wfeventid),
                  )
                ) {
                  console.log(reportFolderName, reportFileName, ext);
                  const payload = {
                    reportFolderName,
                    reportFileName,
                    wfeventid: request.wfeventid,
                    workorderid,
                    uuid: taskfiles[i].uuid,
                  };
                  await generateFileSeqDetails(payload);
                }
              }
            }
          });
        }
      }
      resolve(data);
    });
  });
};

export const getFileSequence = async woId => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `select  DISTINCT ON (inf.woincomingfileid) inf.woincomingfileid,
       jn.journalname,sg.stagename,wo.itemcode,inf.woincomingid,inf.filename,
       inf.typesetpage,inc.issuestartpage,st.sequence,pg.totalpage,pg.startpage,
       pg.endpage from wms_workorder as wo
        left join pp_mst_journal as jn on jn.journalid=wo.journalid
        left join wms_workorder_stage as st on st.workorderid=wo.workorderid
        left join wms_mst_stage as sg on sg.stageid=st.wfstageid
        left join wms_issue_workorder as iwo on iwo.issueworkorderid=wo.workorderid
        left join wms_workorder_incoming as inc on inc.woId = iwo.issueworkorderid
        left join wms_workorder_incomingfiledetails as inf on inf.woincomingid  = inc.woincomingid
       left join wms_workorder_pginfodetails as pg on pg.itemcode = inf.filename
        where wo.workorderid='${woId}'order by inf.woincomingfileid,st.sequence asc`;
      await query(sql)
        .then(async response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

export const getFileSeqTemplate = async details => {
  return new Promise(async (resolve, reject) => {
    try {
      let files = await getFileSequence(details.woId);
      let template =
        `<?xml version = '1.0'?>\r\n<Book>\r\n` +
        `<journalname>${files[0].journalname}</journalname>` +
        `\r\n` +
        `<stagename>${files[0].stagename}</stagename>` +
        `\r\n` +
        `<issuestartpage>${files[0].issuestartpage}</issuestartpage>`;

      const pitstopoptions = details.pitstopoption;

      if (details) {
        details.files.forEach(async detail => {
          const filename = detail.filename ? detail.filename : '';
          const filesequence = detail.filesequence ? detail.filesequence : '';
          const filetype = detail.filetype ? detail.filetype : '';
          if (details.custId == '13') {
            let validFile = files.find(i => i.filename.includes(filename));
            if (validFile) {
              template +=
                `${'<File>\r\n<FileName>'}${filename}</FileName>` +
                `\r\n` +
                `<SeqId>${filesequence}</SeqId>` +
                `\r\n` +
                `<startpages>${validFile.startpage}</startpages>` +
                `\r\n` +
                `<endpages>${validFile.endpage}</endpages>` +
                `\r\n` +
                `<totalpages>${validFile.totalpage}</totalpages>` +
                `\r\n` +
                `<Type>${filetype}</Type>` +
                `\r\n` +
                `</File>` +
                `\r\n`;
            } else {
              template +=
                `${'<File>\r\n<FileName>'}${filename}</FileName>` +
                `\r\n` +
                `<SeqId>${filesequence}</SeqId>` +
                `\r\n` +
                +`<Type>${filetype}</Type>` +
                `\r\n` +
                `</File>` +
                `\r\n`;
              console.log(template);
            }
          } else {
            template +=
              `${'<File>\r\n<FileName>'}${filename}</FileName>` +
              `\r\n` +
              `<SeqId>${filesequence}</SeqId>` +
              `\r\n` +
              `<Type>${filetype}</Type>` +
              `\r\n` +
              `<Pitstop>${
                pitstopoptions[detail.pitstopProfile - 1].label
              }</Pitstop>` +
              `\r\n` +
              `</File>` +
              `\r\n`;
          }
        });

        template += '</Book>';
        console.log('template', template);
        resolve(template);
      }
    } catch (err) {
      reject({
        status: false,
        message: err.response ? err.response : err.message,
      });
    }
  });
};

export const writeFileSequenceNumber = (
  filepath,
  name,
  getFileSequence,
  woId,
) => {
  //jobname, stage, customer, stageiterationcount
  // eslint-disable-next-line no-lone-blocks
  {
    return new Promise(async (resolve, reject) => {
      try {
        let okmPath = '';
        const dmsType = await getdmsType(woId);
        const srcPath = join(filepath, `${name}_SequenceNumber.xml`);
        let { folderPath, customer } = await getpathforFileSequence(woId);
        if (customer !== '13') {
          const okmpathh = { type: 'okm_common' };
          okmPath = await getFolderStructure(okmpathh, []);
        } else {
          okmPath = folderPath;
        }

        fs.writeFileSync(srcPath, `${getFileSequence}`);
        const fileName = basename(srcPath);

        let uuid;
        switch (dmsType) {
          case 'azure':
            const formData = new FormData();
            formData.append('content', createReadStream(srcPath));
            formData.append('docPath', `${okmPath}${name}_SequenceNumber.xml`);
            const headers = {
              'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
            };
            await service.post(
              `${config.blob_rest.base_url}${config.blob_rest.uri.upload}`,
              formData,
              headers,
            );
            uuid = 'azure';
            break;
          case 'local':
            const formData1 = new FormData();
            formData1.append('content', createReadStream(srcPath));
            formData1.append('docPath', `${okmPath}${name}_SequenceNumber.xml`);
            const headers1 = {
              'Content-Type': `multipart/form-data; boundary=${formData1._boundary}`,
            };
            await service.post(
              `${config.local_rest.base_url}${config.local_rest.uri.localupload}`,
              formData1,
              headers1,
            );
            uuid = 'local';
            break;
          default:
            const isTargetDetails = await _isFileExist(
              `${okmPath}${name}_SequenceNumber.xml`,
            );
            if (isTargetDetails.isExist) {
              uuid = isTargetDetails.uuid;
              await checkout(isTargetDetails.uuid);
              await checkInFiles(srcPath, isTargetDetails.uuid);
            } else {
              const formData2 = new FormData();
              formData2.append('content', createReadStream(srcPath));
              formData2.append('docPath', okmPath);
              const header = {
                'Content-Type': `multipart/form-data; boundary=${formData2._boundary}`,
              };
              const response = await upload(
                `${config.okm_rest.baseUrl}${config.okm_rest.document.upload}`,
                formData2,
                header,
              );
              uuid = response.data.uuid;
            }
            break;
        }
        resolve({
          uuid,
          name,
          path: `${okmPath}${name}_SequenceNumber.xml`,
        });
      } catch (e) {
        reject(e);
      }
    });
  }
};

const deleteFileNew = async fileurl1 => {
  return new Promise(async (resolve, reject) => {
    try {
      const fileurl = fileurl1.replace(/\\/g, '/');
      await fs.unlink(fileurl, err => {
        console.log('new', err, fileurl);
      });
      resolve('true');
    } catch (err) {
      reject({
        status: false,
        message: err.response ? err.response : err.message,
      });
    }
  });
};

export const updatefileSequenceXML = (request, jobId, woId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const getFileSeq1 = await getFileSeqTemplate(request);
      const name = `${jobId}`;
      const filepath = join(__dirname, '../../../uploads').replace(/\\/g, '/');
      let newData = {};
      // if (request.type == 'fileReorder') {
      newData = await writeFileSequenceNumber(
        filepath,
        name,
        getFileSeq1,
        woId,
      );
      // }

      // need to be hanlded
      //   let workorderid = ''
      //   let condition = ''
      //   let wfEventid = []
      //   request.wfeventid.map((item, i) => {
      //     wfEventid.push(item.wfeventid)
      //     condition += request.wfeventid.length - 1 !== i ?
      //       `wfeventid = '${item.wfeventid}' OR `
      //       : `wfeventid = '${item.wfeventid}'`;
      //   });

      //   let sql = `select definition.fileconfig,* from wms_workflow_eventlog eventlog join
      // wms_workflowdefinition definition on eventlog.wfdefid=definition.wfdefid ${condition ? 'where ' + condition : ''}`
      //   let data = await query(sql, [])
      //   if (data.length) {
      //     let fileConfigKeys = Object.keys(data[0].fileconfig.fileTypes);
      //     let filename = ""
      //     let updatefile = false
      //     workorderid = data[0].workorderid
      //     for (let i = 0; i < fileConfigKeys.length; i++) {
      //       let files = data[0].fileconfig.fileTypes[fileConfigKeys[i]].files
      //       for (let j = 0; j < files.length; j++) {
      //         if (files[j].custom && files[j].custom.generate_filesequence) {
      //           filename = files[j].name
      //           updatefile = true
      //           break;
      //         }
      //       }
      //     }
      //     if (updatefile) {
      //       sql = `SELECT * FROM public.wms_task_files ${condition ? 'where ' + condition : ''}`
      //       let taskfiles = await query(sql, []);
      //       if (taskfiles.length) {
      //         for (let i = 0; i < taskfiles.length; i++) {
      //           const reportFolderName = dirname(taskfiles[i].path) + '/';
      //           const reportFileName = basename(taskfiles[i].path);
      //           const ext = extname(reportFileName);
      //           if (reportFileName === getFormattedName(filename, await getWorkflowPlaceHolders(wfEventid[0]))) {
      //             let payload = {
      //               reportFolderName, reportFileName,
      //               wfeventid: wfEventid, workorderid,
      //               uuid: taskfiles[i].uuid
      //             }
      //             await generateFileSeqDetails(payload)
      //           }
      //         }
      //       }
      //     }
      //   }

      if (fs.existsSync(join(filepath, `${jobId}_SequenceNumber.xml`))) {
        await deleteFileNew(join(filepath, `${jobId}_SequenceNumber.xml`));
      }
      resolve({ uuid: newData.uuid, path: newData.path, name: newData.name });
    } catch (e) {
      reject(e);
    }
  });
};

const upload = (url, reqData, additionalHeaders = {}) => {
  return new Promise((resolve, reject) => {
    axios({
      method: 'POST',
      url,
      data: reqData,
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      maxRedirects: 0,
      headers: {
        'Access-Control-Allow-Origin': true,
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...additionalHeaders,
      },
    })
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        const message = err.response?.data?.message
          ? err.response.data.message
          : err.response?.data
          ? err.response.data
          : err.message;
        reject({ status: false, message, additionalInfo: { url } });
      });
  });
};

export const getFilesStatus_checking = (req, res) => {
  // recent update added error handling wms_workflow_eventlog.activitystatus
  const reqData = req.body;

  const sqlData = `select distinct on( activityname,aliasstagename,woincomingfileid)
  * 
  from (	 
    select
     
    wms_mst_activity.activityname,wf.activityalias,
      wms_mst_stage.stagename||'('||wms_workflow_eventlog.stageiterationcount||')' as aliasStageName,
      wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
      stageiterationcount,wms_workflow_eventlog.activityiterationcount,case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
      'Hold','Pending','Created','Claimed') then wms_workflow_eventlog.activitystatus else 'Default'
      end as  activitystatus, wms_workflowactivitytrn_file_map.woincomingfileid,wms_workorder.itemcode,
      wms_workorder.workorderid, wms_workorder_incomingfiledetails.filename,wms_workflow_eventlog.wfeventid,wms_mst_service.serviceid, wms_mst_service.servicename 
   FROM wms_workflow_eventlog
     JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
     JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid
     JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid       
     JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid
     JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
     JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
     JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
   JOIN (SELECT ev.activityiterationcount ,ev.stageiterationcount as stgitercount,  wft1.woincomingfileid,wf1.activityid,wf1.stageid
     FROM public.wms_workflow_eventlog ev
         join wms_workflowdefinition  wf1 on wf1.wfdefid = ev.wfdefid
         JOIN wms_workflowactivitytrn_file_map wft1 ON ev.wfeventid = wft1.wfeventid
         JOIN wms_workorder_incomingfiledetails wdti1 ON wft1.woincomingfileid = wdti1.woincomingfileid
         WHERE ev.workorderid = $1) AS sti ON 
    sti.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid AND  sti.activityid=wf.activityid AND sti.stageid=wf.stageid
   AND wms_workflow_eventlog.activityiterationcount = sti.activityiterationcount
     WHERE  wms_workorder.workorderid=$1   
   order by wms_workorder_incomingfiledetails.filesequence  
    )as table3`;

  const sqlStageActivity = `select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
        left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
        left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
        left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
        where wms_workflow.wfid in 
        (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
        wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where workorderid=$1 and lock=false )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
         and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1`;
  // and wms_workflowdefinition.activitytype != 'External Task' order by wms_workflowdefinition.sequence) as table1`;
  //
  console.log(sqlData, 'sqlData');

  query(sqlData, [reqData.id])
    .then(response => {
      console.log(response, 'response1');
      console.log(sqlStageActivity, 'sqlStageActivity sql');

      query(sqlStageActivity, [reqData.id])
        .then(stageActivityRes => {
          console.log(stageActivityRes, 'stageActivityRes');

          res
            .status(200)
            .json({ data: response, stageActivity: stageActivityRes });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFilesStatus = async (req, res) => {
  // recent update added error handling wms_workflow_eventlog.activitystatus
  const reqData = req.body;
  let sqlStageActivity = '';
  let sqlData = '';
  let workflowCheck = false;
  let customerid = 0;

  if (reqData.id) {
    const sqlgetcust = `select customerid from wms_workorder where workorderid = $1`;
    query(sqlgetcust, [reqData.id]).then(response => {
      customerid = response.customerid;
    });
    if (reqData.wfid) {
      const res1 = await query(
        `select iscamundaflow from wms_workflow where wfid = ${reqData.wfid}`,
      );
      workflowCheck = res1?.[0]?.iscamundaflow;
    } else {
      const res2 =
        await query(`select iscamundaflow from wms_workorder_service join wms_workorder on wms_workorder_service.workorderid = wms_workorder.workorderid
    join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
    where wms_workorder.workorderid = ${reqData.id}`);
      workflowCheck = res2?.[0]?.iscamundaflow;
    }

    if (customerid == 8) {
      sqlData = `with cte as (select wms_mst_activity.activityname,wf.activityalias,
        wms_mst_stage.stagename||'('||stageiterationcount||')' as aliasStageName,
        wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
        stageiterationcount,activityiterationcount,wms_workflow_eventlog.actualactivitycount,
        case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
        'Hold','Pending','Created','Claimed') then wms_workflow_eventlog.activitystatus else 'Default'end as  activitystatus, 
        wms_workflowactivitytrn_file_map.woincomingfileid,
        wms_workorder.itemcode,
        wms_workflow_eventlog.wfdefid,
        wms_workorder.workorderid, 
        wms_workorder_incomingfiledetails.filename,
        wms_workflow_eventlog.wfeventid,
        wms_mst_service.serviceid, 
        wms_mst_service.servicename,
        row_number() over(partition by 
        wms_workorder_incomingfiledetails.woincomingfileid,
        wms_mst_activity.activityid,
        wms_workflow_eventlog.stageiterationcount,
        wms_mst_stage.stageid,
        wf.wfdefid
        order by stageiterationcount desc,actualactivitycount desc) as rowcount
    FROM wms_workflow_eventlog  
    JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
    JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid 
    JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
    JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
    JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
    JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
    JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
    where  wms_workorder.workorderid in (select w.workorderid from public.wms_workorder_incoming a
    inner join public.wms_workorder_incomingfiledetails b on b.woincomingid=a.woincomingid 
    inner join wms_workorder_list w on LOWER(w.itemcode)=LOWER(b.filename)
    where a.woid=$1 and b.piinumber <> 'null'
    and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    union 
    SELECT workorderid  FROM wms_workorder_list where workorderid=$1)
    order by wms_workorder_incomingfiledetails.filesequence) 
    
    select * from cte where rowcount =1 and
    stagename in ('Issue Creation','Issue Revises','Elds','Revised Elds','Graphics')
    and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    
    union all
    
    select * from cte where rowcount =1 and
    stagename in ('Incoming Inspection','Pre Editing','Copy Editing','XML Conversion'
    ,'First Proof','Collation','Revises','First View','Graphics','AMO')
    and not exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    `;

      sqlStageActivity = `;with cte as (
        select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
                left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
                left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
                left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
                where wms_workflow.wfid in 
                (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
                wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where workorderid in ((select w.workorderid from public.wms_workorder_incoming a
                  inner join public.wms_workorder_incomingfiledetails b on b.woincomingid=a.woincomingid 
                  inner join wms_workorder_list w on LOWER(w.itemcode)=LOWER(b.filename)
                  where a.woid=$1 and b.piinumber <> 'null'
                  union 
                  SELECT workorderid  FROM wms_workorder_list where workorderid=$1)) and lock=false )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
                 and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1
          )
          
          select * from cte where 
             stagename in ('Issue Creation','Issue Revises','Elds','Revised Elds','Graphics')
            and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
            
            union all
            
            select * from cte where
             stagename in ('Incoming Inspection','Pre Editing','Copy Editing','XML Conversion'
        ,'First Proof','Collation','Revises','First View','Graphics','AMO')
            and not exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
            `;
      // and wms_workflowdefinition.activitytype != 'External Task' order by wms_workflowdefinition.sequence) as table1`;
      //
      console.log(sqlData, 'sqlData');
    } else {
      if (workflowCheck) {
        sqlData = `;with cte as (select wms_mst_activity.activityname,wf.activityalias,
          wms_mst_stage.stagename||'('|| wms_workflow_eventlog.stageiterationcount||')' as aliasStageName,
          wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
          wms_workflow_eventlog.stageiterationcount,activityiterationcount,wms_workflow_eventlog.actualactivitycount,
          case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
          'Hold','Pending','Created','Claimed') then wms_workflow_eventlog.activitystatus else 'Default'end as  activitystatus, 
          wms_workflowactivitytrn_file_map.woincomingfileid,
          wms_workorder.itemcode,
          wms_workflow_eventlog.wfdefid,
          wms_workorder.workorderid, 
          wms_workorder_incomingfiledetails.filename,
          wms_workflow_eventlog.wfeventid,
          wms_mst_service.serviceid, 
          wms_mst_service.servicename,
          row_number() over(partition by 
          wms_workorder_incomingfiledetails.woincomingfileid,
          wms_mst_activity.activityid,
          wms_workflow_eventlog.stageiterationcount,
          wms_mst_stage.stageid,
          wf.wfdefid
          order by wms_workflow_eventlog.stageiterationcount desc,actualactivitycount desc) as rowcount
    FROM wms_workflow_eventlog  
    JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
    JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid 
    JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
    JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
    JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
    JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
    JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
    where  wms_workorder.workorderid=$1
    order by wms_workorder_incomingfiledetails.filesequence) select * from cte where rowcount =1`;
      } else {
        sqlData = `;with cte as (select wms_mst_activity.activityname,wf.activityalias,
        wms_mst_stage.stagename||'('||wms_workflow_eventlog.stageiterationcount||')' as aliasStageName,
        wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
        wms_workflow_eventlog.stageiterationcount,activityiterationcount,wms_workflow_eventlog.actualactivitycount,
        case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
        'Hold','Pending','Created','Claimed') then wms_workflow_eventlog.activitystatus else 'Default'end as  activitystatus,
        wms_workorder_incomingfiledetails.woincomingfileid,
        wms_workorder.itemcode,
        wms_workflow_eventlog.wfdefid,
        wms_workorder.workorderid,
        wms_workorder_incomingfiledetails.filename,
        wms_workflow_eventlog.wfeventid,
        wms_mst_service.serviceid,
        wms_mst_service.servicename,
        row_number() over(partition by
        wms_workorder_incomingfiledetails.woincomingfileid,
        wms_mst_activity.activityid,
        wms_workflow_eventlog.stageiterationcount,
        wms_mst_stage.stageid,
        wf.wfdefid
        order by wms_workflow_eventlog.stageiterationcount desc,actualactivitycount desc) as rowcount
  from wms_workorder_incoming  
  join wms_workorder  on  wms_workorder_incoming.woid = wms_workorder.workorderid
  join wms_workorder_incomingfiledetails on wms_workorder_incoming.woincomingid = wms_workorder_incomingfiledetails.woincomingid
  join wms_workflow_eventlog on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
   and wms_workflow_eventlog.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid
  JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid
  JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
  JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
  JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
  where  wms_workorder_incoming.woid=$1
  order by wms_workorder_incomingfiledetails.filesequence) select * from cte where rowcount =1

`;
      }
      sqlStageActivity = `select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
  left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
  left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
  left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
  where wms_workflow.wfid in 
  (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
  wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where workorderid=$1 and lock=false )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
   and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1`;
      console.log(sqlData, 'sqlData');
    }

    query(sqlData, [reqData.id])
      .then(response => {
        query(sqlStageActivity, [reqData.id])
          .then(stageActivityRes => {
            res
              .status(200)
              .json({ data: response, stageActivity: stageActivityRes });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res
      .status(400)
      .send({ message: 'Required payload is missing (workorder id)' });
  }
};

export const getProcessAdherence = (req, res) => {
  const { wfEventId } = req.body;
  const sql = `select checklist from wms_workflow_eventlog where wfeventid=${wfEventId}`;
  // let sql = `select checklist from wms_workflow_eventlog where wfeventid=2571`
  query(sql)
    .then(response => {
      res.status(200).json({ data: response, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getToolsStatusDetails = (req, res) => {
  const { wfeventId } = req.body;
  const sql = `SELECT pmt.toolname,wta.status ,wta.remarks
FROM wms_tools_api wta
JOIN (
    SELECT toolid, MAX(apiid) AS max_apiid
    FROM wms_tools_api
    WHERE wfeventid = ${wfeventId}
    GROUP BY toolid
) latest
ON wta.apiid = latest.max_apiid AND wta.toolid = latest.toolid
join pp_mst_tool pmt on pmt.toolid =latest.toolid
WHERE wta.wfeventid =${wfeventId}`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getFileStatus = (req, res) => {
  const {
    stage,
    activity,
    customer,
    du,
    workOrderId,
    woincomingfileid,
    wfeventid,
    service: service1,
  } = req.body.file;

  let sqlData = `WITH CTE AS (
    SELECT
        wfeventdetailid,
        actualactivitycount,
        ROW_NUMBER() OVER (PARTITION BY actualactivitycount,userid ORDER BY timestamp DESC) AS rn
    FROM
        wms_workflow_eventlog_details
    WHERE
        wfeventid =  ${wfeventid}
        AND operationtype NOT IN ('Claimed', 'Hold', 'Unassigned')
),
latest_events AS (
    SELECT
        wfeventdetailid,
        wfeventid,
        actualactivitycount,
        timestamp,
        operationtype
    FROM
        wms_workflow_eventlog_details
    WHERE
        wfeventid =  ${wfeventid}
        AND operationtype NOT IN ('Claimed', 'Created', 'Hold', 'Unassigned')
    ORDER BY
        actualactivitycount DESC,
        timestamp DESC
)
SELECT
    users.username || ' (' || dc.userid || ')' AS userid,
    wms_workflowdefinition.activitytype,
    CASE
        WHEN dc.operationtype IN ('Completed', 'Pending', 'Rejected')
            AND wms_workflowdefinition.activitytype <> 'External Task' THEN
            (
                SELECT to_char(timestamp + interval '5 hours 30 minutes', 'DD-MM-YYYY HH:MI:SS AM')
                FROM latest_events AS le
                WHERE le.wfeventid = dc.wfeventid
                    AND le.actualactivitycount = dc.actualactivitycount
                    AND le.operationtype NOT IN ('Claimed', 'Created', 'Hold', 'Unassigned')
                    AND le.timestamp < dc.timestamp
                ORDER BY timestamp DESC
                LIMIT 1
            )
                  WHEN dc.operationtype IN ('Created')
            AND wms_workflowdefinition.activitytype = 'External Task' THEN
            (
                SELECT to_char(timestamp + interval '5 hours 30 minutes', 'DD-MM-YYYY HH:MI:SS AM')
                FROM wms_workflow_eventlog_details AS le
                WHERE le.wfeventid = dc.wfeventid
                AND le.actualactivitycount = dc.actualactivitycount
                    AND le.operationtype NOT IN ('Claimed', 'Hold', 'Unassigned')
                    AND le.timestamp <= dc.timestamp
                ORDER BY timestamp ASC
                LIMIT 1
            )
        WHEN wms_workflowdefinition.activitytype = 'External Task' THEN
            (
                SELECT to_char(timestamp + interval '5 hours 30 minutes', 'DD-MM-YYYY HH:MI:SS AM')
                FROM latest_events AS le
                WHERE le.wfeventid = dc.wfeventid
                    AND le.operationtype NOT IN ('Claimed', 'Hold', 'Unassigned')
                    AND le.timestamp < dc.timestamp
                ORDER BY timestamp DESC
                LIMIT 1
            )
        WHEN dc.operationtype = 'Cancelled' THEN
            (
                SELECT to_char(timestamp + interval '5 hours 30 minutes', 'DD-MM-YYYY HH:MI:SS AM')
                FROM latest_events AS le
                WHERE le.wfeventid = dc.wfeventid
                    AND le.actualactivitycount = dc.actualactivitycount
                    AND le.operationtype NOT IN ('Claimed', 'Created', 'Hold', 'Unassigned')
                    AND le.timestamp < dc.timestamp
                ORDER BY timestamp DESC
                LIMIT 1
            )
        ELSE to_char(dc.timestamp + interval '5 hours 30 minutes', 'DD-MM-YYYY HH:MI:SS AM')
    END AS starttime,
    to_char(dc.timestamp + interval '5 hours 30 minutes', 'DD-MM-YYYY HH:MI:SS AM') AS endtime,
    age(
        dc.timestamp,
        CASE
        WHEN dc.operationtype IN ('Completed', 'Pending', 'Rejected')
            AND wms_workflowdefinition.activitytype <> 'External Task' THEN
            (
                SELECT timestamp
                FROM latest_events AS le
                WHERE le.wfeventid = dc.wfeventid
                    AND le.actualactivitycount = dc.actualactivitycount
                    AND le.operationtype NOT IN ('Claimed', 'Created', 'Hold', 'Unassigned')
                    AND le.timestamp < dc.timestamp
                ORDER BY timestamp DESC
                LIMIT 1
            )
                	 WHEN dc.operationtype IN ('Created')
            AND wms_workflowdefinition.activitytype = 'External Task' THEN
            (
                SELECT timestamp
                FROM wms_workflow_eventlog_details AS le
                WHERE le.wfeventid = dc.wfeventid
                AND le.actualactivitycount = dc.actualactivitycount
                    AND le.operationtype NOT IN ('Claimed', 'Hold', 'Unassigned')
                    AND le.timestamp <= dc.timestamp
                ORDER BY timestamp ASC
                LIMIT 1
            )
        WHEN wms_workflowdefinition.activitytype = 'External Task' THEN
            (
                SELECT timestamp
                FROM latest_events AS le
                WHERE le.wfeventid = dc.wfeventid
                    AND le.operationtype NOT IN ('Claimed', 'Hold', 'Unassigned')
                    AND le.timestamp < dc.timestamp
                ORDER BY timestamp DESC
                LIMIT 1
            )
        WHEN dc.operationtype = 'Cancelled' THEN
            (
                SELECT timestamp
                FROM latest_events AS le
                WHERE le.wfeventid = dc.wfeventid
                    AND le.actualactivitycount = dc.actualactivitycount
                    AND le.operationtype NOT IN ('Claimed', 'Created', 'Hold', 'Unassigned')
                    AND le.timestamp < dc.timestamp
                ORDER BY timestamp DESC
                LIMIT 1
            )
        ELSE dc.timestamp
    END 
    ) AS timetaken,
    dc.operationtype,
    dc.actualactivitycount,
    dc.wfeventid,
    dc.usercomments,
    wms_mst_service.serviceid,
    dc.wfeventid,
    wms_mst_service.servicename,
    wms_workorder_incomingfiledetails.filename,
    wms_workflow_eventlog.activitystatus,
    wms_mst_stage.stagename || '(' || stageiterationcount || ')' AS stagename,
    CASE
        WHEN wms_workflowdefinition.activitytype = 'External Task' THEN '{"SYSTEM_NAME":"WMS Engine"}'
        ELSE dc.systeminfo
    END AS systeminfo,
    CASE
        WHEN dc.actualactivitycount IS NULL THEN wms_mst_activity.activityname
        ELSE wms_mst_activity.activityname || '(' || dc.actualactivitycount || ')'
    END AS activityname,
    current_stage.result,current_stage.current_stage
FROM
    wms_workflow_eventlog_details dc
JOIN wms_workflow_eventlog ON dc.wfeventid = wms_workflow_eventlog.wfeventid
JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = ${woincomingfileid}
JOIN wms_workflowdefinition ON wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid
JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
LEFT JOIN wms_user AS users ON users.userid = dc.userid
left join (WITH wfstage AS (
    SELECT wfstageid ,stageiterationcount,s.stagename
    FROM wms_workorder_stage
    join wms_mst_stage s on wms_workorder_stage.wfstageid = s.stageid
    WHERE workorderid = ${workOrderId} 
      AND updatedon IS NOT NULL
      and wms_workorder_stage.wfstageid <> 10
      AND status IN ('In Process', 'Completed') 
     ORDER BY stageiterationcount desc,"sequence" desc limit 1
),
stage AS (
    SELECT stageid ,e.stageiterationcount
    FROM wms_workflowdefinition ww
    JOIN wms_workflow_eventlog e ON e.wfdefid = ww.wfdefid
    WHERE e.wfeventid = ${wfeventid} 
)
SELECT 
    CASE 
        WHEN stage.stageid = wfstage.wfstageid and stage.stageiterationcount = wfstage.stageiterationcount THEN true
       when stage.stageid = 10 then true
        ELSE false
    END AS result , wfstage.stagename || '(' || wfstage.stageiterationcount || ')' as current_stage
FROM wfstage, stage) as current_stage  on 1 = 1
WHERE
    dc.wfeventid =  ${wfeventid}
    AND dc.operationtype NOT IN ('Claimed',  'Hold', 'Unassigned')
    AND dc.wfeventdetailid IN (
        SELECT wfeventdetailid
        FROM CTE
        WHERE rn = 1 OR operationtype IN ('Cancelled', 'Pending')
    )
ORDER BY timestamp DESC
`;

  query(sqlData, [])
    .then(async response => {
      const filesInfo = await getFileInfoDetails({
        stage,
        activity,
        customer,
        du,
        workOrderId,
        service: service1,
        woincomingfileid,
        wfEventId: wfeventid,
        activitymodeltypeflow: '',
        issuemstid: '',
        wfDefId: '',
        fileTypeId: '',
        isOtherArticle: false,
        articleOrderSequence: null,
      });
      const tempFilesInfo = [];
      filesInfo.forEach(fIn => {
        if (fIn.incomingFileId === woincomingfileid) {
          tempFilesInfo.push(fIn);
        }
      });
      const placeholder = await getWorkflowPlaceHolders(wfeventid);
      sqlData = `select fileconfig from wms_workflowdefinition wfd join wms_workflow_eventlog wel on wfd.wfdefid=wel.wfdefid where wfeventid=${wfeventid}`;
      await query(sqlData, [])
        .then(async fileResponse => {
          // updated for fileconfig restructure
          const fileconfig = fileResponse.length
            ? ReStructureFileConfig(fileResponse[0].fileconfig)
            : {};
          const validationFileConfig =
            fileconfig && fileconfig.fileTypes ? fileconfig.fileTypes : {};
          const eventData = {};
          const mandatorySaveFile = {};
          const filesData = await fetchValidationDetails(
            tempFilesInfo,
            validationFileConfig,
            placeholder,
            eventData,
            mandatorySaveFile,
            workOrderId,
          );
          const dmsType = await getdmsType(workOrderId);
          const files = [];
          if (filesData.filesInfo && filesData.filesInfo.length) {
            filesData.filesInfo[0].files.forEach(fr => {
              // if (!fr.isReadOnly) {
              fr.dmstype = dmsType;
              files.push(fr);
              // }
            });
          }
          let filesList = [];

          // SQL query to get file paths based on dmsid and customer/du details
          let sqlData = `
          WITH parentpath AS (
            SELECT 
              CASE 
                WHEN wmc.dmsid = 3 THEN localserverpath  
                WHEN wmc.dmsid = 4 THEN cloudfilereceivedpath  
                ELSE localserverpath 
              END AS path, 
               d.dmstype AS dmstype
            FROM 
              wms_mst_customerconfigdetails wmc
            JOIN 
              dms_master d ON d.dmsid = wmc.dmsid
            WHERE 
              wmc.customerid = $1
              AND wmc.duid = $2
          ),
          child AS (
            SELECT
              pmj.journalacronym || '/' || ww.itemcode || '/' || 
              REPLACE($3, ' ', '_') || '/' || 
              REPLACE($4, ' ', '_') || '/' || 
              ww.itemcode AS concatenated_value
            FROM 
              wms_workorder ww
            JOIN 
              pp_mst_journal pmj ON pmj.journalid = ww.journalid
            WHERE 
              ww.workorderid = $5
            UNION ALL
                SELECT
              ww.itemcode || '/' || 
              REPLACE($3, ' ', '_') || '/' || 
              REPLACE($4, ' ', '_') || '/' || 
              ww.itemcode AS concatenated_value
            FROM 
              wms_workorder ww
            WHERE 
              ww.workorderid =  $5  and ww.journalid is null
          )
          SELECT 
            REPLACE(parentpath.path || '/' || child.concatenated_value, '/;JournalAcronym;', '') AS path,
            parentpath.dmstype AS dmstype
          FROM 
            parentpath, child;
          `;

          const queryParams = [
            customer.id,
            du.id,
            stage.name,
            activity.name,
            workOrderId,
          ];

          await query(sqlData, queryParams)
            .then(async pathResponse => {
              const data = pathResponse[0];

              data.dmsType = data.dmstype; // Ensure dmsType is assigned for consistent use

              switch (data.dmsType) {
                case 'azure':
                  filesList = await _listAllFiles(data.path);
                  filesList = filesList.map(list => ({
                    ...list,
                    dmstype: 'azure',
                    filename: list.path.split('/').pop(),
                    size: list.size,
                  }));
                  break;

                case 'local':
                  filesList = await _retreiveLocalFiles(data.path);
                  filesList = filesList.map(list => ({
                    ...list,
                    dmstype: 'local',
                    filename: list.path.split('/').pop(),
                    size: list.size,
                  }));
                  break;

                default:
                  filesList.push({
                    path: data.path,
                    uuid: 'azure',
                    fileId: 'default',
                  });
                  break;
              }
            })
            .catch(error => {
              console.error('Error retrieving file paths:', error);
            });

          const workflowCheck = await query(
            ` select w.iscamundaflow  from wms_workflow w 
          join wms_workflowdefinition d on d.wfid = w.wfid 
          join wms_workflow_eventlog e on e.wfdefid  = d.wfdefid
          where e.wfeventid  = ${wfeventid} limit 1`,
          );

          sqlData = `select checklist from wms_workflow_eventlog where wfeventid=${wfeventid}`;
          await query(sqlData, []).then(async checklist => {
            res.status(200).json({
              data: response,
              files,
              checklist,
              iscamundaflow: workflowCheck?.[0]?.iscamundaflow,
              filesList,
            });
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// export const constGetStageAndActivityName = (req, res) => {
//
//     let sqlData = `select distinct wms_mst_activity.activityname, wms_mst_stage.stagename from wms_workflow_eventlog
//     JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
//     JOIN wms_workflowdefinition ON wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid
//     JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
//     JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid
//     JOIN wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid
//     JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
//     where wms_workorder.itemcode='CUP0003'`;
//     query(sqlData, []).then((response) => {
//
//         res.status(200).json({ data: response })
//     }).catch((error) => {
//         res.status(400).send({ message: error });
//     });
// }
export const isDownloadAndUploadFile = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.actfilemapid > 0) {
    sql = `UPDATE wms_workflowactivitytrn_file_map SET isdownloaded =$1,ischeckedout=$3  WHERE actfilemapid = $2 `;

    query(sql, [
      reqData.isdownloaded,
      reqData.actfilemapid,
      reqData.ischeckedout,
    ])
      .then(() => {
        res.status(200).json({
          data: `Files has been  ${
            reqData.isdownloaded ? 'Downloaded' : 'Uploaded'
          } successfully`,
        });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'No Files to Downloaded/Uploaded' });
  }
};

export const isFileCheckout = (req, res) => {
  const reqData = req.body;
  const url = `${config.openKM.uri.ischeckout}/${reqData.repofileuuid}`;

  const headers = {};
  service
    .get(`${config.openKM.base_url}${url}`, {}, headers)
    .then(response => {
      res.status(200).json({ data: response.data });
    })
    .catch(err => {
      res.status(400).send({ message: err });
    });
};

export const isFileExists = (req, res) => {
  const reqData = req.body;
  const url = `${config.openKM.uri.ischeckout}/${reqData.repofileuuid}`;

  const headers = {};
  service
    .get(`${config.openKM.base_url}${url}`, {}, headers)
    .then(response => {
      res.status(200).json({ data: response.data });
    })
    .catch(err => {
      res.status(400).send({ message: err });
    });
};

export const newDocumentFileupload = (req, res) => {
  const reqData = req.body;

  if (reqData.repofileuuid) {
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded,woincomingfileid)
        VALUES('${reqData.wfeventid}', '${reqData.repofileuuid}', '${reqData.repofilepath}', null, true, false,${reqData.woincomingfileid})`;

    query(sql)
      .then(() => {
        res.status(200).json({ message: 'File uploaded successfully' });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'No Files to Uploaded' });
  }
};

export const newFileType = async (req, res) => {
  const {
    woid,
    serviceid,
    stageid,
    updatedby,
    filetypeid,
    filename,
    wfeventid,
    uuid,
    filepath,
    duedate,
    filesequence,
    isSubjob,
    iscamundaflow,
  } = req.body;

  let dueDate = duedate ? `${duedate}` : null;
  // check the iTracks call
  const { status } = await checkItracksExits(req, res);

  const checkCount = `select a.woincomingfileid,a.woincomingid,a.filename,a.filepath,a.fileuuid,a.imagecount,a.filetypeid,a.istriggered 
  from public.wms_workorder_incomingfiledetails a
  join wms_workorder_incoming b on b.woincomingid = a.woincomingid
  where b.woid =${woid}  and filename = '${filename}' and a.filetypeid !=1
  order by a.woincomingfileid desc`;
  const fileInfo = await query(checkCount);
  if (!fileInfo.length) {
    if (isSubjob && status) {
      // call iTracks API
      const jobArray = [req.body];

      const subJobRes = await addSubJob(jobArray, req.body, false, true);
      const { status: status1, message } = subJobRes;

      if (status1) {
        const sql = `INSERT INTO public.wms_workorder_incoming(
      woid, serviceid, stageid, receiptdatetime, duedate, updatedby, batchno, updatedon)
     VALUES ( ${woid}, ${serviceid}, ${stageid}, null, null, '${updatedby}', null, current_timestamp) returning *;`;
        query(sql)
          .then(response => {
            const incomingFilesSql = `INSERT INTO public.wms_workorder_incomingfiledetails(
          woincomingid, filetypeid, filename, filepath, fileuuid, duedate, mspages, estimatedpages, imagecount, tablecount, equationcount, batchno, filesequence, isactive)
         VALUES ( ${response[0].woincomingid}, '${filetypeid}', '${filename}', '${filepath}',' ${uuid}', '${dueDate}', null, null, null, null, null, null, ${filesequence}, null) returning *;`;

            query(incomingFilesSql).then(IncomingResponse => {
              if (iscamundaflow) {
                const txnIncmoingsql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
                  wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded, woincomingfileid,ischeckedout)
                 VALUES ( ${wfeventid}, '${uuid}', '${filepath}', null, true, false ,${IncomingResponse[0].woincomingfileid},false);`;
                query(txnIncmoingsql).then(async () => {
                  // update subjobid in db
                  const auditRes = await subJobAudit(message, [
                    IncomingResponse[0].woincomingfileid,
                  ]);

                  // // await getStageinfo update
                  // let camundaUpdate = await updtageStageinfo(woid,IncomingResponse[0].woincomingfileid)

                  if (auditRes.status) {
                    res.status(200).json({
                      message: 'New File type Added successfully',
                      data: IncomingResponse[0].woincomingfileid,
                    });
                  } else {
                    res.status(400).send({ message: auditRes.message });
                  }
                });
              } else {
                res.status(200).json({
                  message: 'New File type Added successfully',
                  data: IncomingResponse[0].woincomingfileid,
                });
              }
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(400).send({ message });
      }
    } else {
      const sql = `INSERT INTO public.wms_workorder_incoming(
      woid, serviceid, stageid, receiptdatetime, duedate, updatedby, batchno, updatedon)
     VALUES ( ${woid}, ${serviceid}, ${stageid}, null, null, '${updatedby}', null, current_timestamp) returning *;`;
      query(sql)
        .then(response => {
          const incomingFilesSql = `INSERT INTO public.wms_workorder_incomingfiledetails(
          woincomingid, filetypeid, filename, filepath, fileuuid, duedate, mspages, estimatedpages, imagecount, tablecount, equationcount, batchno, filesequence, isactive)
         VALUES ( ${response[0].woincomingid}, '${filetypeid}','${filename}','${filepath}','${uuid}','${dueDate}',null,null,null,null,null,null,${filesequence},null) returning *;`;

          query(incomingFilesSql).then(async IncomingResponse => {
            if (iscamundaflow) {
              const txnIncmoingsql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
             wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded, woincomingfileid,ischeckedout)
            VALUES ( ${wfeventid}, '${uuid}', '${filepath}', null, true, false ,${IncomingResponse[0].woincomingfileid},false);`;
              // get stage info update
              // let camundaUpdate = await updtageStageinfo(woid,IncomingResponse[0].woincomingfileid)
              query(txnIncmoingsql).then(() => {
                res.status(200).json({
                  message: 'New File type Added successfully',
                  data: IncomingResponse[0].woincomingfileid,
                });
              });
            } else {
              res.status(200).json({
                message: 'New File type Added successfully',
                data: IncomingResponse[0].woincomingfileid,
              });
            }
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    }
  } else {
    res.status(400).send({ message: 'Filename already exist' });
  }
};

export const updtageStageinfo = async (woid, id) => {
  return new Promise(async (resolve, reject) => {
    try {
      let processInstanceId = '';
      let taskInstanceId = '';
      // .......GETTING PROCESS INSTANCEID.......//
      const sql1 = `select distinct eventdata->>'processInstanceId' as processinstanceid,taskinstanceid from wms_workflow_eventlog where workorderid = $1`;
      await query(sql1, [woid]).then(async response => {
        if (response && response.length) {
          processInstanceId = response[0].processinstanceid;
          taskInstanceId = response[0].taskinstanceid;
        }
      });

      // get stage info
      const getCamundaStageInfo = await _getStageInfoFromCamunda(woid);

      let testobj = [];
      testobj = JSON.parse(getCamundaStageInfo.__stageInfo.data.value);

      const object = {
        id,
        isGraphic: false,
      };

      testobj.files.push(object);
      testobj.totalChapters = testobj.files.length;

      getCamundaStageInfo.__stageInfo.data.value = JSON.stringify(testobj);

      // update stage info
      const updateCamundaStageInfo = await _updateStageInfoToCamunda(
        JSON.parse(getCamundaStageInfo.__stageInfo.data.value),
        processInstanceId,
      );

      // update taskinstanceid
      const updateTaskInstanceInfo = await _updateActivityStageInfoToCamunda(
        JSON.parse(getCamundaStageInfo.__stageInfo.data.value),
        taskInstanceId,
      );

      if (updateCamundaStageInfo) {
        resolve(true);
      } else {
        reject('Camunda update failed');
      }
    } catch (error) {
      reject(error);
      console.log(error, 'update stage info');
    }
  });
};

export const updateFileE2EEnableTrn = async (req, res) => {
  const {
    wfdefid,
    workorderid,
    userid,
    skillId,
    stageiterationcount,
    serviceid,
    activityCount,
    activityiterationcount,
    actualactivitycount,
  } = req.body;

  let sql = `SELECT wms_workorder_incomingfiledetails.woincomingfileid FROM wms_workorder_incoming
  JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
  WHERE  wms_workorder_incoming.woid = ${workorderid}`;
  let woincomingfileId = await query(sql);

  //insert eventlog
  let insertSql = `insert into wms_workflow_eventlog(workorderid,wfdefid,userid,activitystatus,skillid,stageiterationcount,
  activityiterationcount,woincomingfileid,serviceid,isfilesynced,activitycount,
 actualactivitycount) values(${workorderid},${wfdefid},'${userid}','Completed',${skillId},${stageiterationcount},
 ${activityiterationcount},${woincomingfileId[0].woincomingfileid},${serviceid},true,${activityCount},${actualactivitycount}) RETURNING wfeventid`;

  let event = await query(insertSql);

  //insert eventlog details

  let insertEventlog = `insert into wms_workflow_eventlog_details(wfeventid, operationtype) values(${event[0].wfeventid},'Created')`;
  await query(insertEventlog);
  console.log(insertSql, sql, 'testtttttt');

  //insert workflow activity trn
  let trnEntry = `INSERT INTO wms_workflowactivitytrn_file_map(
  wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
  VALUES (${event[0].wfeventid},'local','sample.tsx', true,false, ${woincomingfileId[0].woincomingfileid})`;

  await query(trnEntry);

  let updateEventlog = `update wms_workflow_eventlog set activitystatus ='Completed'
    where workorderid=${workorderid}`;

  query(updateEventlog)
    .then(() => {
      res.status(200).json({
        message: 'New File type updated successfully',
        data: woincomingfileId[0].woincomingfileid,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const newFileTypeUpdate = (req, res) => {
  const { uuid, filepath, woincomingfileid, iscamundaflow } = req.body;
  console.log(req.body, 'reqData for newFileType  update');
  const incomingFilesSql = `UPDATE public.wms_workorder_incomingfiledetails SET filepath='${filepath}', fileuuid='${uuid}' WHERE woincomingfileid=${woincomingfileid} RETURNING woincomingfileid  `;
  console.log('sql==> incomingFilesSql update', incomingFilesSql);
  query(incomingFilesSql)
    .then(IncomingResponse => {
      if (iscamundaflow) {
        const txnIncmoingsql = `UPDATE public.wms_workflowactivitytrn_file_map SET repofilepath='${filepath}', repofileuuid='${uuid}' WHERE woincomingfileid=${woincomingfileid}  `;
        console.log('sql txnIncmoingsql ==> update', txnIncmoingsql);
        query(txnIncmoingsql)
          .then(() => {
            res.status(200).json({
              message: 'New File type updated successfully',
              data: IncomingResponse[0].woincomingfileid,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({
          message: 'New File type updated successfully',
          data: IncomingResponse[0].woincomingfileid,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getViewHistory = (req, res) => {
  const reqData = req.body;

  let sql = '';
  let eventID = 0;
  let wfData = [];
  const result = [];
  let operationData = [];
  let fileData = [];
  sql = `SELECT  wms_workflow_eventlog.wfeventid,wms_workflow_eventlog_details.operationtype,wms_workflow_eventlog_details.timestamp, CONCAT(wms.stagename, '(', wms_workflow_eventlog.stageiterationcount, ')')
    as stagename, CONCAT(wma.activityname, '(', wms_workflow_eventlog.activityiterationcount, ')')
    as activityname, wms_workorder_incomingfiledetails.filename, pp_mst_filetype.filetype,wms_workorder_incomingfiledetails.filepath,wms_workflow_eventlog_details.userid,wms_user.username
     FROM wms_workflow_eventlog as wms_workflow_eventlog
     JOIN wms_workflow_eventlog_details as wms_workflow_eventlog_details  ON wms_workflow_eventlog_details.wfeventid = wms_workflow_eventlog.wfeventid
    left JOIN public.wms_user as wms_user ON wms_user.userid = wms_workflow_eventlog_details.userid
    JOIN wms_workflowdefinition as wms_workflowdefinition
        ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
    JOIN wms_mst_stage as wms
        ON wms.stageid = wms_workflowdefinition.stageid
    JOIN wms_mst_activity as wma
         ON wma.activityid = wms_workflowdefinition.activityid
    LEFT JOIN wms_workorder_incomingfiledetails as wms_workorder_incomingfiledetails
        ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
    LEFT JOIN pp_mst_filetype
        ON pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
   WHERE wms_workflow_eventlog.workorderid = ${reqData.wfOrderId} AND wms_workflow_eventlog.serviceid = ${reqData.serviceId}
   ORDER BY wfeventid ASC
   `;

  let history = {};
  query(sql)
    .then(response => {
      wfData = response;

      response.forEach(d => {
        if (d.wfeventid != eventID) {
          eventID = d.wfeventid;
          wfData.forEach(x => {
            if (x.wfeventid == eventID) {
              operationData.push({
                operation: x.operationtype,
                timestamp: x.timestamp,
                userid: x.userid,
                user: x.username,
              });
              // fileData.push({
              //     "filename": x.filename,
              //     "filepath": x.filepath,
              //     "filetype": x.filetype
              // })
            }
          });
          history = {
            wfeventid: d.wfeventid,
            stagename: d.stagename,
            activityname: d.activityname,
            starttime:
              operationData.filter(x => x.operation == 'Created').length > 0
                ? operationData.filter(x => x.operation == 'Created')[0]
                    .timestamp
                : '',
            endtime:
              operationData.filter(x => x.operation == 'Completed').length > 0
                ? operationData.filter(x => x.operation == 'Completed')[0]
                    .timestamp
                : '',
            operations: operationData.sort(function (a, b) {
              return a.timestamp - b.timestamp;
            }),
            files: fileData,
            filename: d.filename,
            filetype: d.filetype,
          };
          history.timetaken = calculateTime(history.operations);
          result.push(history);
          operationData = [];
          fileData = [];
        }
      });

      res.status(200).json({ data: result });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
const calculateTime = operations => {
  let totaltime = 0;
  let wiptime = 0;
  let isWip = false;
  operations.forEach(val => {
    if (val.operation == 'Work in progress') {
      isWip = true;
      wiptime = val.timestamp;
    } else if (isWip) {
      isWip = false;
      totaltime += val.timestamp - wiptime;
    }
  });
  if (isWip) {
    totaltime += new Date().getTime() - wiptime;
  }
  const timemin = totaltime / (60 * 1000);

  const hours = Math.floor(timemin / 60);
  const minutes = timemin % 60;

  return `${hours}:${minutes.toFixed(0)}`;
};
export const getAuditAndFile = (req, res) => {
  const reqData = req.body;

  const sql = `SELECT  * from  wms_task_files
            WHERE  wms_task_files.wfeventid = ${reqData.wfeventID}
            ORDER BY wfeventid ASC`;

  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateAuditHistory = async (req, res) => {
  const {
    files,
    woId,
    serviceId,
    stageId,
    activityId,
    activityIterationCount,
    stageIterationCount,
    updatedBy,
    wfeventId,
  } = req.body;
  console.log(req.body, 'bodddyyyyyupdateeeeee');
  let status = true;
  let fileReorderAuditId = '';
  const defaultSql = `SELECT * FROM public.wms_task_filereorder_audit where workorderid =${woId} ORDER BY filereorderauditid ASC`;
  await query(defaultSql)
    .then(async response => {
      console.log(response, 'responnnsnsns111');
      if (response.length) {
        fileReorderAuditId = response[0].filereorderauditid;
      } else {
        const sql = `INSERT INTO public.wms_task_filereorder_audit(wfeventid,workorderid, serviceid, stageid, activityid, stageiterationcount, activityiterationcount)
                  VALUES (${wfeventId || null}, ${woId}, ${serviceId}, ${
          stageId || null
        }, ${activityId || null}, ${stageIterationCount || null}, ${
          activityIterationCount || null
        }) RETURNING filereorderauditid`;
        console.log(sql, 'customermap11');
        await query(sql)
          .then(async fileReorderResponse => {
            fileReorderAuditId = fileReorderResponse[0].filereorderauditid;
            console.log(fileReorderResponse, 'responseiddd1111');
          })
          .catch(() => {
            status = false;
          });
      }
    })
    .catch(() => {
      status = false;
    });
  if (status == true && fileReorderAuditId) {
    const auditSql = `INSERT INTO public.wms_task_filereorder_audit_history(filereorderauditid, updatedby, updatedon,files) VALUES ($1, $2, $3,$4)`;
    console.log(auditSql, 'auditSq11111111111l');
    await query(auditSql, [fileReorderAuditId, updatedBy, new Date(), files])
      .then(async ResponseAuditSql => {
        console.log(ResponseAuditSql, 'ResponseAuditSql');
        res.status(200).json({ data: ResponseAuditSql });
      })
      .catch(() => {
        status = false;
      });
  } else {
    res.status(400).send({ message: 'Failed to get the filereorderauditid' });
  }
};

export const getEventIdForWo = async (req, res) => {
  const { WoId } = req.body;
  try {
    const sql = `SELECT wfeventid FROM wms_workflow_eventlog WHERE workorderid = $1 AND activitystatus NOT IN ('Completed', 'Rejected', 'Reset')`;

    query(sql, [WoId])
      .then(response => {
        res.status(200).json({ data: response });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (e) {
    console.log(e, 'error occurred while getting eventid');
    res.status(500).send({ message: 'Internal server error' });
  }
};

export const getLastInstanceActivity = (req, res) => {
  const { wfDefId, woId, fileTypeId } = req.body;
  let sql = `select count(*) from wms_workflow_eventlog as eventlog
  left join  wms_workorder_incomingfiledetails  as incomingdetails on incomingdetails.woincomingfileid = eventlog.woincomingfileid
 where eventlog.workorderid = ${woId} and eventlog.wfdefid = ${wfDefId} and incomingdetails.filetypeid = ${fileTypeId}`;
  console.log(sql, 'sql for latest acitivity');
  query(sql)
    .then(result => {
      console.log(result, 'res for latest actiivty');
      if (result[0].count > 0) {
        const Obj = {};
        Obj.type = 'indexpresent';
        Obj.count = result[0].count;
        res.status(200).json({ data: Obj });
      } else {
        sql = `select count(*) from wms_workflow_eventlog as eventlog
          where eventlog.workorderid = ${woId} and eventlog.wfdefid = ${wfDefId} and (eventlog.activitystatus = 'Completed' or eventlog.activitystatus = 'Rejected' or eventlog.activitystatus = 'Reset')`;

        query(sql, [])
          .then(data => {
            const Obj = {};
            Obj.type = 'indexnotpresent';
            Obj.count = data[0].count;

            res.status(200).json({ data: Obj });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      }
    })
    .catch(error => {
      console.log(error, 'error for latest activity');
      res.status(400).send({ message: error });
    });
};

// user event history capture
export const captureUserEvent = async (req, res) => {
  try {
    await _captureUserEvent(req, req.body);
    res.status(200).json({ data: 'success' });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const _captureUserEvent = async (req, data) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sysInfo = req.headers.systemdetail
        ? JSON.parse(req.headers.systemdetail)
        : {};
      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...sysInfo,
      };

      const { wfeventId, userId, userid } = data;
      const actionType = data.actionType.toUpperCase();
      let sql = `SELECT * from public.wms_workorder_activity_audit WHERE wfeventid = $1 and actiontype = $2`;

      const existData = await query(sql, [wfeventId, actionType]);
      if (existData.length) {
        const { activityauditid } = existData[0];
        sql = `UPDATE public.wms_workorder_activity_audit SET updatedon = $1 WHERE activityauditid = $2`;

        await query(sql, [new Date(), activityauditid]);
      } else {
        sql = `INSERT INTO public.wms_workorder_activity_audit(wfeventid, actiontype, createdon, updatedby, systeminfo)
        VALUES ($1, $2, $3, $4, $5)`;

        await query(sql, [
          wfeventId,
          actionType,
          new Date(),
          userId || userid,
          systemInfo,
        ]);
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const _prepubWorkflowUpdate = async req => {
  return new Promise(async (resolve, reject) => {
    try {
      const pubInfo = await getPubflowInfo(req);
      console.log(pubInfo, 'pubInfo');
      if (
        (pubInfo &&
          pubInfo.pubflowconfig &&
          pubInfo.pubflowconfig.isPubflow &&
          pubInfo.publicationtype == 'Online') ||
        (pubInfo &&
          pubInfo.pubflowconfig &&
          pubInfo.pubflowconfig.isPubflow &&
          pubInfo.publicationtype == 'Journal' &&
          pubInfo.ismscompleted)
      ) {
        const endpoint = config.pubflow.uri.pubupdate;
        const baseUrl = config.pubflow.switch_url;
        const url = `${baseUrl}${endpoint}`;

        const payload = await getPubflowPayload(pubInfo);
        const response = await axios.post(url, payload);
        resolve({ status: true, message: response });
      } else {
        resolve({ status: true });
      }
    } catch (error) {
      reject(error);
      console.log(error, 'error');
    }
  });
};

export const getPubflowPayload = async pubInfo => {
  return new Promise((resolve, reject) => {
    try {
      let payload;
      if (pubInfo.publicationtype == 'Online') {
        let articlecode = '';
        if (pubInfo.itemcode.includes(pubInfo.issuenumber)) {
          articlecode = pubInfo.itemcode.split(pubInfo.issuenumber)[1];
        }
        payload = {
          PublicationType: 'Online',
          PublicationID: pubInfo.publicationid,
          ActivityName: pubInfo.pflowactivityname,
          UserID: 'klipm@integra.co.in',
          API_KEY: process.env.Publication_API_KEY,
          Batch: `KLO-${pubInfo.journalacronym}_${pubInfo.volumenumber}_${pubInfo.issuenumber}_${articlecode}`,
        };

        // Batch: 'KLO-EUCL_21_02_01',  batch example
      } else {
        payload = {
          PublicationType: 'Journal',
          PublicationID: pubInfo.publicationid,
          ActivityName: pubInfo.pflowactivityname,
          Issue: pubInfo.issuenumber,
          Volume: pubInfo.volumenumber,
          CMNote: '',
          UserID: 'klipm@integra.co.in',
          API_KEY: process.env.Publication_API_KEY,
          Batch: `${pubInfo.volumenumber}-${pubInfo.issuenumber}`,
        };
      }
      resolve(payload);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPubflowInfo = async req => {
  return new Promise(async (resolve, reject) => {
    try {
      req.body.workorderId = req.body.workorderId || req.body.woId;
      req.body.isonlineissue = req.body.isonlineissue || false;
      const sql = `SELECT workorder.itemcode,workorder.workorderid, workorder.issuenumber,workorder.volumenumber,workorder.issuemstid,
    workorder.isonlineissue,workorder.ismscompleted,definition.pubflowconfig,
    publicationinfo.publicationid,publicationinfo.publicationtype,pubflowact.pflowactivityname,journal.journalacronym
     from wms_workorder as workorder
     join wms_workorder_service as service on service.workorderid =workorder.workorderid
     JOIN pp_mst_journal  as journal ON journal.journalid = workorder.journalid
     join pp_mst_journal_publication as publicationinfo on publicationinfo.journalid = journal.journalid
      join wms_workflowdefinition as definition on definition.wfid = service.wfid
     join pubflow_mst_activity_map as pubflowmap on pubflowmap.wfid = service.wfid
     join pubflow_mst_activity as pubflowact on pubflowact.pubflowactivityid = pubflowmap.pubflowactivityid
     where workorder.workorderid=${req.body.workorderId} and definition.activityid =${req.body.activityId} 
     and definition.stageid=${req.body.stageId} and ((${req.body.isonlineissue} = true AND publicationinfo.publicationtype = 'Online')
     OR (${req.body.isonlineissue} = false AND publicationinfo.publicationtype = 'Journal'))`;
      console.log(sql, 'pubsql');
      const result = await query(sql);
      resolve(result[0]);
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

export const updateTypeSetPages = async (req, res) => {
  try {
    const { woincomingfileid, typesetpage } = req.body;
    const sql = `UPDATE public.wms_workorder_incomingfiledetails SET uomvalue=${typesetpage}, typesetpage=${typesetpage}
    WHERE woincomingfileid=${woincomingfileid}`;
    await query(sql);
    res.status(200).json({ data: 'Successfully updated typeset page' });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};
export const updateRunOnFileSequence = async (req, res) => {
  try {
    const { valuesOfArray, workorderid, filetype, userid } = req.body;
    valuesOfArray.map(async list => {
      const sql = `UPDATE public.wms_workorder_incomingfiledetails SET runonfilesequence=${list.runonfilesequence}
      WHERE woincomingfileid=${list.woincomingfileid}`;
      await query(sql);
    });

    const auditSql = `INSERT INTO public.wms_audit_runonmerginghistory( filetype,workorderid, userid, createdon, isactive) 
  VALUES ('${filetype}','${workorderid}','${userid}',current_timestamp,true) RETURNING *`;

    await query(auditSql);
    res
      .status(200)
      .json({ data: 'Successfully updated Other File Type Sequence' });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const getWOTypeSetPageList = async (req, res) => {
  try {
    const { workorderId } = req.body;
    const sql = `select filename, typesetpage, woincomingfileid from public.wms_workorder_incoming
    join public.wms_workorder_incomingfiledetails on  wms_workorder_incomingfiledetails.woincomingid=wms_workorder_incoming.woincomingid
    where woid=${workorderId}`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const getMultiFilesStatusReport = async (req, res) => {
  // recent update added error handling wms_workflow_eventlog.activitystatus
  const reqData = req.body;
  let sqlStageActivity = '';
  let sqlData = '';
  let workflowCheck = false;
  let customerid = 0;
  let wfId = reqData.wfid;

  const sqlgetcust = `select customerid from wms_workorder where workorderid = $1`;
  query(sqlgetcust, [reqData.id]).then(response => {
    customerid = response.customerid;
  });
  if (wfId) {
    const res1 = await query(
      `select iscamundaflow from wms_workflow where wfid = ${wfId}`,
    );
    workflowCheck = res1?.[0]?.iscamundaflow;
  } else {
    const res2 =
      await query(`select iscamundaflow,wfid from wms_workorder_service join wms_workorder on wms_workorder_service.workorderid = wms_workorder.workorderid
    join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
    where wms_workorder.workorderid = ${reqData.id}`);
    workflowCheck = res2?.[0]?.iscamundaflow;
    wfId = res2?.[0]?.wfid;
  }

  let whereClause = ``;
  let workorderIds = ``;
  let condition = ``;

  if (reqData.multiWorkorders && reqData.multiWorkorders.length > 0) {
    if (reqData.multiWorkorders.filter(list => list.id == '').length == 0) {
      workorderIds = reqData.multiWorkorders.map(p => p.id);
      whereClause =
        workorderIds.length > 0
          ? `WHERE wms_workorder.workorderid IN (${workorderIds.join(',')})`
          : ``;
      if (workorderIds) {
        condition = `and workorderid IN (${workorderIds.join(',')})`;
      }
    } else {
      whereClause = `WHERE wf.wfid = ${wfId} and  wms_workorder.isactive = true`;
    }
  }

  if (customerid == 8) {
    sqlData = `with cte as (select wms_mst_activity.activityname,wf.activityalias,
        wms_mst_stage.stagename||'('||stageiterationcount||')' as aliasStageName,
        wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
        stageiterationcount,activityiterationcount,wms_workflow_eventlog.actualactivitycount,
        case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
        'Hold','Pending','Created','Claimed', 'NA') then wms_workflow_eventlog.activitystatus else 'Default'end as  activitystatus, 
        wms_workflowactivitytrn_file_map.woincomingfileid,
        wms_workorder.itemcode,
        wms_workflow_eventlog.wfdefid,
        wms_workorder.workorderid, 
        wms_workorder_incomingfiledetails.filename,
        wms_workflow_eventlog.wfeventid,
        wms_mst_service.serviceid, 
        wms_mst_service.servicename,
        row_number() over(partition by 
        wms_workorder_incomingfiledetails.woincomingfileid,
        wms_mst_activity.activityid,
        wms_workflow_eventlog.stageiterationcount,
        wms_mst_stage.stageid,
        wf.wfdefid
        order by stageiterationcount desc,actualactivitycount desc) as rowcount
    FROM wms_workflow_eventlog  
    JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
    JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid 
    JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
    JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
    JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
    JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
    JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
    where  wms_workorder.workorderid in (select w.workorderid from public.wms_workorder_incoming a
    inner join public.wms_workorder_incomingfiledetails b on b.woincomingid=a.woincomingid 
    inner join wms_workorder_list w on LOWER(w.itemcode)=LOWER(b.filename)
    where a.woid=$1 and b.piinumber <> 'null'
    and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    union 
    SELECT workorderid  FROM wms_workorder_list where workorderid=$1)
    order by wms_workorder_incomingfiledetails.filesequence) 
    
    select * from cte where rowcount =1 and
    stagename in ('Issue Creation','Issue Revises','Elds','Revised Elds','Graphics')
    and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    
    union all
    
    select * from cte where rowcount =1 and
    stagename in ('Incoming Inspection','Pre Editing','Copy Editing','XML Conversion'
    ,'First Proof','Collation','Revises','First View','Graphics','AMO')
    and not exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    `;

    sqlStageActivity = `;with cte as (
        select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
                left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
                left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
                left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
                where wms_workflow.wfid in 
                (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
                wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where workorderid in ((select w.workorderid from public.wms_workorder_incoming a
                  inner join public.wms_workorder_incomingfiledetails b on b.woincomingid=a.woincomingid 
                  inner join wms_workorder_list w on LOWER(w.itemcode)=LOWER(b.filename)
                  where a.woid=$1 and b.piinumber <> 'null'
                  union 
                  SELECT workorderid  FROM wms_workorder_list where workorderid=$1)) and lock=false )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
                 and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1
          )
          
          select * from cte where 
             stagename in ('Issue Creation','Issue Revises','Elds','Revised Elds','Graphics')
            and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
            
            union all
            
            select * from cte where
             stagename in ('Incoming Inspection','Pre Editing','Copy Editing','XML Conversion'
        ,'First Proof','Collation','Revises','First View','Graphics','AMO')
            and not exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
            `;
    // and wms_workflowdefinition.activitytype != 'External Task' order by wms_workflowdefinition.sequence) as table1`;
    //
    console.log(sqlData, 'sqlData');
  } else {
    if (workflowCheck) {
      sqlData = `;with cte as (select wms_mst_activity.activityname,wf.activityalias,
          wms_mst_stage.stagename||'('||stageiterationcount||')' as aliasStageName,
          wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
          stageiterationcount,activityiterationcount,wms_workflow_eventlog.actualactivitycount,
          case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
          'Hold','Pending','Created','Claimed', 'NA') then wms_workflow_eventlog.activitystatus else 'Default'end as  activitystatus, 
          wms_workflowactivitytrn_file_map.woincomingfileid,
          wms_workorder.itemcode,
          wms_workflow_eventlog.wfdefid,
          wms_workorder.workorderid, 
          wms_workorder_incomingfiledetails.filename,
          wms_workflow_eventlog.wfeventid,
          wms_mst_service.serviceid, 
          wms_mst_service.servicename,
          row_number() over(partition by 
          wms_workorder_incomingfiledetails.woincomingfileid,
          wms_mst_activity.activityid,
          wms_workflow_eventlog.stageiterationcount,
          wms_mst_stage.stageid,
          wf.wfdefid
          order by stageiterationcount desc,actualactivitycount desc) as rowcount
    FROM wms_workflow_eventlog  
    JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
    JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid and wf.lock = false
    JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
    JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
    JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid and wms_mst_activity.isactive = true
    JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid and wms_mst_activity.isactive = true
    JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
    ${whereClause}
    order by wms_workorder_incomingfiledetails.filesequence) select * from cte where rowcount =1`;
    } else {
      sqlData = `WITH cte AS (
        SELECT 
            wms_mst_activity.activityname,
            wf.activityalias,
            wms_mst_stage.stagename || '(' || wms_workflow_eventlog.stageiterationcount || ')' AS aliasStageName,
            wms_mst_stage.stagename,
            wms_mst_stage.stageid,
            wms_mst_activity.activityid,
            wms_workflow_eventlog.stageiterationcount,
            wms_workflow_eventlog.activityiterationcount,
            wms_workflow_eventlog.actualactivitycount,
            CASE 
                WHEN wms_workflow_eventlog.activitystatus IN (
                    'Completed', 'Work in progress', 'YTS', 'Reset', 'Failed', 
                    'Rejected', 'Unassigned', 'Hold', 'Pending', 'Created', 'Claimed', 'NA'
                ) THEN wms_workflow_eventlog.activitystatus 
                ELSE 'Default' 
            END AS activitystatus, 
            wms_workorder_incomingfiledetails.woincomingfileid,
            wms_workorder.itemcode,
            wms_workflow_eventlog.wfdefid,
            wms_workorder.workorderid, 
            wms_workorder_incomingfiledetails.filename,
            wms_workflow_eventlog.wfeventid,
            wms_mst_service.serviceid, 
            wms_mst_service.servicename,
            ROW_NUMBER() OVER(
                PARTITION BY 
                    wms_workorder_incomingfiledetails.filename,
                    wms_workorder.itemcode,
                    wms_workorder_incomingfiledetails.woincomingfileid,
                    wms_mst_activity.activityid,
                    wms_workflow_eventlog.stageiterationcount,
                    wms_mst_stage.stageid,
                    wf.wfdefid
                ORDER BY 
                    wms_workorder.createdon DESC
            ) AS rowcount,
            wf.wfid
        FROM 
            wms_workflow_eventlog  
        JOIN 
            wms_workorder 
            ON wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
        JOIN 
            wms_workflowdefinition wf 
            ON wms_workflow_eventlog.wfdefid = wf.wfdefid AND wf.lock = false
        JOIN 
            wms_mst_activity 
            ON wms_mst_activity.activityid = wf.activityid AND wms_mst_activity.isactive = true
        JOIN 
            wms_mst_stage 
            ON wms_mst_stage.stageid = wf.stageid AND wms_mst_stage.isactive = true
        JOIN 
            wms_mst_service 
            ON wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
        JOIN 
            wms_workorder_incoming 
            ON wms_workorder_incoming.woid = wms_workorder.workorderid
        JOIN 
            wms_workorder_incomingfiledetails 
            ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
        WHERE 
            wf.wfid = ${wfId}
            ${whereClause ? `AND ${whereClause.replace(/^WHERE\s/i, '')}` : ''}
        ORDER BY 
            wms_workorder_incomingfiledetails.filesequence
      )
      SELECT * 
      FROM cte 
      WHERE rowcount = 1;
      `;
    }
    sqlStageActivity = `select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
  left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
  left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
  left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
  where wms_workflow.wfid in 
  (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
  wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where  lock=false and wfid =${wfId}  ${condition} )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
   and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1`;
    console.log(sqlData, 'sqlData');
  }

  query(sqlData)
    .then(response => {
      const filteredResponse = response.filter(
        item => item.activitystatus !== 'NA',
      );
      query(sqlStageActivity)
        .then(stageActivityRes => {
          res.status(200).json({
            data: filteredResponse,
            stageActivity: stageActivityRes,
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getCustomerConfig = async (req, res) => {
  try {
    const { duId, customerId } = req.body;
    const sql = `select * from wms_mst_customerconfigdetails where duid=${duId} and customerid=${customerId}`;
    const response = await query(sql);
    res.status(200).json({ data: response.length ? response[0] : '' });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};
