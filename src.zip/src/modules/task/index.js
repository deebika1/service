import { basename, extname, dirname } from 'path';
import { query } from '../../database/postgres.js';
import { _copyFile, _createFolder, _getUuid } from '../utils/okm/index.js';
import * as azureHelper from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import { getdmsType } from '../bpmn/listener/create.js';
import { getWorkflowPlaceHolders } from './fileDetails.js';
import { getFormattedName } from '../utils/fileValidation/utils.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';

export const getActivityDetails = async (req, res) => {
  const { wfEventId } = req.body;
  try {
    const activityDetails = await _getActivityDetails(wfEventId);
    res.send(activityDetails);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};
export const getEventDetails = async (req, res) => {
  const {
    woId,
    wfDefId,
    stageIterationCount,
    activityIterationCount,
    wfEventId,
    basepath,
  } = req.body;
  try {
    const fileSeqDetails = await getFileSeq(wfEventId);
    const dmsType = await getdmsType(woId);
    const destUuid = '';
    switch (dmsType) {
      case 'azure':
        break;
      default:
        await _createFolder(`${basepath}page_target`).then(async uuid => {
          console.log('base path folder uuis', uuid);
        });
        break;
    }
    if (fileSeqDetails[0].filesequence !== '1') {
      const eventDetails = await _getEventDetails(
        woId,
        wfDefId,
        stageIterationCount,
        activityIterationCount,
        +fileSeqDetails[0].filesequence - 1,
      );
      const data = [];
      eventDetails.forEach((ele, i) => {
        if (extname(ele.repofilepath) === '.ent')
          data.push({
            src: ele.repofileuuid,
            srcPath: ele.repofilepath,
            dest: destUuid,
            destBasePath: `${basepath}book_1/page_target/`,
            name: basename(eventDetails[i].repofilepath),
          });
      });
      res.send([]);
    } else {
      res.send([]);
    }
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};
export const prelims3dCopy = async (req, res) => {
  const { woId, wfDefId, destUuid, basepath } = req.body;
  try {
    console.log('yuvaraj', req.body);
    const dmsType = await getdmsType(woId);
    const sql1 = `SELECT activityiterationcount,stageiterationcount FROM public.wms_workflow_eventlog where workorderid=${woId} and wfdefid=${wfDefId} order by wfeventid desc limit  1`;
    const result = await query(sql1, []);

    if (result.length) {
      const sql = `SELECT max(stageiterationcount) as stageiterationcount,max(activityiterationcount) as activitycount,repofilepath,repofileuuid FROM public.wms_workflow_eventlog eventlog
        join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid 
        join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=tfm.woincomingfileid
        where workorderid=${woId} and wfdefid=${wfDefId} and stageiterationcount=${result[0].stageiterationcount} and activityiterationcount=${result[0].activityiterationcount} and filetypeid = 13 group by repofilepath,repofileuuid`;
      await query(sql, [])
        .then(async details => {
          let cdata = '';
          for (let i = 0; i < details.length; i++) {
            const name = basename(details[i].repofilepath);
            const ext = extname(name);
            if (ext === '.3d') {
              console.log(
                details[i].repofilepath,
                'Particular .3dd file details',
              );
              switch (dmsType) {
                case 'azure':
                  cdata = await azureHelper._copyFile({
                    srcPath: details[i].repofilepath,
                    name,
                    destBasePath: basepath,
                  });
                  break;
                case 'local':
                  cdata = await localHelper._localcopyFile({
                    srcPath: details[i].repofilepath,
                    name,
                    destBasePath: basepath,
                  });
                  break;
                default:
                  cdata = await _copyFile({
                    src: details[i].repofileuuid,
                    dest: destUuid,
                    destBasePath: basepath,
                    name,
                  });
                  break;
              }
            }
          }
          console.log(cdata, 'cdataee');
          res.send({ path: cdata.path, uuid: cdata.uuid });
        })
        .catch(e => {
          res.status(400).send({ message: e.message ? e.message : e });
        });
    }
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const correctionFirstChapterEntFileCopy = async (
  woId,
  completionTriggerWfDefId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `SELECT activityiterationcount,stageiterationcount FROM public.wms_workflow_eventlog where workorderid=${woId} and wfdefid=${completionTriggerWfDefId} order by wfeventid desc limit  1`;
      const result = await query(sql1, []);

      if (result.length) {
        const sql = `SELECT max(stageiterationcount) as stageiterationcount,max(activityiterationcount) as activitycount,repofilepath,repofileuuid FROM public.wms_workflow_eventlog eventlog
        join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid 
        join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=tfm.woincomingfileid
        where workorderid=${woId} and wfdefid=${completionTriggerWfDefId} and stageiterationcount=${result[0].stageiterationcount} and activitycount=${result[0].activityiterationcount}  group by repofilepath,repofileuuid`;
        await query(sql, [])
          .then(async details => {
            resolve(details);
          })
          .catch(e => {
            reject(e);
          });
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const correctionRemainigChapterEntFileCopy = async (woId, wfDefId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `SELECT eventlog.activityiterationcount,eventlog.stageiterationcount,eventlog.wfeventid,* 
                    FROM public.wms_workflow_eventlog  as eventlog
                    JOIN wms_workflow_eventlog_details as eventlogdetails on eventlogdetails.wfeventid = eventlog.wfeventid
                    where eventlog.workorderid=${woId}  and eventlog.wfdefid=${wfDefId} and eventlog.activitystatus ='Completed' AND 
                    eventlogdetails.operationtype = 'Completed' 
                    order by timestamp desc limit 1`;
      const result = await query(sql1, []);

      if (result.length) {
        const sql = `SELECT max(stageiterationcount) as stageiterationcount,max(activityiterationcount) as activitycount,repofilepath,repofileuuid FROM public.wms_workflow_eventlog eventlog
        join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid 
        join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=tfm.woincomingfileid
        where workorderid=${woId} and wfdefid=${wfDefId} and tfm.wfeventid =${result[0].wfeventid} and stageiterationcount=${result[0].stageiterationcount} and activityiterationcount=${result[0].activityiterationcount}  group by repofilepath,repofileuuid`;
        await query(sql, [])
          .then(async details => {
            resolve(details);
          })
          .catch(e => {
            reject(e);
          });
      } else {
        resolve();
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const preEditingLinkingDocxCopy = async (req, res) => {
  const { woId, wfDefId, destUuid, basepath, filename } = req.body;
  try {
    const dmsType = await getdmsType(woId);
    console.log('prediting typescript liking copy', req.body);
    const preEventDetails = await _preEditingLinkingDocxCopy(
      woId,
      wfDefId,
      '0',
      '212',
    );
    let cdata = '';
    for (let i = 0; i < preEventDetails.length; i++) {
      const name = basename(preEventDetails[i].repofilepath);
      const ext = extname(name);
      if (ext === '.docx') {
        console.log(
          preEventDetails[i].repofilepath,
          'Particular .docx file details',
        );
        try {
          switch (dmsType) {
            case 'azure':
              cdata = await azureHelper._copyFile({
                srcPath: preEventDetails[i].repofilepath,
                name: filename,
                destBasePath: basepath,
              });
              break;
            case 'local':
              cdata = await localHelper._localcopyFile({
                srcPath: preEventDetails[i].repofilepath,
                name: filename,
                destBasePath: basepath,
              });
              break;
            default:
              cdata = await _copyFile({
                src: preEventDetails[i].repofileuuid,
                dest: destUuid,
                destBasePath: basepath,
                name: filename,
              });
              break;
          }
        } catch (er) {
          console.log(er, 'error in linkingprediting copy');
        }
      }
    }
    console.log(cdata, 'cdataee');
    res.send({ path: cdata.path, uuid: cdata.uuid });
  } catch (e) {
    console.log('error in linking file');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const copyPreEditingDocxCopy = async (req, res) => {
  const { woId, wfDefId, destUuid, basepath, filename, service } = req.body;
  try {
    const dmsType = await getdmsType(woId);
    console.log('copy prediting docxx', req.body);
    const sql = `select * from (SELECT wms_workflow_eventlog.*, wms_workflowdefinition.stageid, wms_workflowdefinition.activityid FROM public.wms_workflow_eventlog
            join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
                                   join wms_workflow_eventlog_details on wms_workflow_eventlog_details.wfeventid = wms_workflow_eventlog.wfeventid
            where workorderid = ${woId} and serviceid =${service} and wms_workflow_eventlog.wfdefid = ${wfDefId} and  (wms_workflow_eventlog_details.operationtype = 'Completed' or wms_workflow_eventlog_details.operationtype = 'Rejected' or wms_workflow_eventlog_details.operationtype = 'Failed' or wms_workflow_eventlog_details.operationtype = 'Reset')  and  (activitystatus = 'Completed' or activitystatus = 'Rejectecd' or activitystatus = 'Failed' or activitystatus = 'Reset' )
                            order by  wms_workflow_eventlog_details.timestamp  desc limit 1) as hell
                    join wms_workflowactivitytrn_file_map as filetrn on filetrn.woincomingfileid = hell.woincomingfileid
                where  (filetrn.repofilepath like '%bib.docx%' or filetrn.repofilepath like '%rfa.docx%' ) order by actfilemapid desc limit 1	`;
    await query(sql, [])
      .then(async incomingDetails => {
        console.log(sql, 'sql for copy docx');
        let cdata = '';
        for (let i = 0; i < incomingDetails.length; i++) {
          const name = basename(incomingDetails[i].repofilepath);
          const ext = extname(name);
          if (ext === '.docx') {
            console.log(
              incomingDetails[i].repofilepath,
              'Particular preEditing .docx file details',
            );
            try {
              switch (dmsType) {
                case 'azure':
                  cdata = await azureHelper._copyFile({
                    srcPath: incomingDetails[i].repofilepath,
                    name: filename,
                    destBasePath: basepath,
                  });
                  break;
                case 'local':
                  cdata = await localHelper._localcopyFile({
                    srcPath: incomingDetails[i].repofilepath,
                    name: filename,
                    destBasePath: basepath,
                  });
                  break;
                default:
                  cdata = await _copyFile({
                    src: incomingDetails[i].repofileuuid,
                    dest: destUuid,
                    destBasePath: basepath,
                    name: filename,
                  });
                  break;
              }
            } catch (er) {
              console.log(er, 'error in preEditing copy');
            }
          }
        }
        console.log(cdata, 'cdataee');
        res.send({ path: cdata.path, uuid: cdata.uuid });
      })
      .catch(e => {
        console.log(e, 'eerrror');
        res.status(400).send({ message: e.message ? e.message : e });
      });
  } catch (e) {
    console.log('error in preediting file');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const _preEditingLinkingDocxCopy = async (
  woId,
  wfDefId,
  wordIdInsertionWfDefid,
  incWfDefid,
  dmsType,
) => {
  let result = [];
  let preEventDetails3 = [];
  let preEventDetails2 = [];
  const sql = `SELECT max(stageiterationcount) as stageiterationcount,max(activityiterationcount) as activitycount,repofilepath,repofileuuid FROM public.wms_workflow_eventlog eventlog
    join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid 
    join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=tfm.woincomingfileid
    where workorderid=${woId} and wfdefid=${wfDefId} and filetypeid = 11 group by repofilepath,repofileuuid`;
  const preEventDetails = await query(sql, []);
  if (preEventDetails.length == 0) {
    const sql1 = `SELECT max(stageiterationcount) as stageiterationcount,max(activityiterationcount) as activitycount,repofilepath,repofileuuid FROM public.wms_workflow_eventlog eventlog
    join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid 
    join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=tfm.woincomingfileid
    where workorderid=${woId} and wfdefid=${wordIdInsertionWfDefid} and filetypeid = 11 group by repofilepath,repofileuuid`;
    preEventDetails2 = await query(sql1, []);
  }
  if (preEventDetails.length == 0 && preEventDetails2.length == 0) {
    const sql2 = `SELECT max(stageiterationcount) as stageiterationcount,max(activityiterationcount) as activitycount,repofilepath,repofileuuid FROM public.wms_workflow_eventlog eventlog
        join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid 
        join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=tfm.woincomingfileid
        where workorderid=${woId} and wfdefid=${incWfDefid} and filetypeid = 11 group by repofilepath,repofileuuid`;
    preEventDetails3 = await query(sql2, []);
  }
  result =
    preEventDetails.length > 0
      ? preEventDetails
      : preEventDetails2.length > 0
      ? preEventDetails2
      : preEventDetails3;
  switch (dmsType) {
    case 'azure':
      result.map(async list => {
        list.repofileuuid = 'azure';
      });
      break;
    default:
      result.map(async list => {
        list.repofileuuid = await _getUuid(list.repofilepath);
      });
      break;
  }
  console.log(result, 'okkk');
  return result;
};

export const _preEditingLinkingDocxForSecondSquenceCopy_old2 = async (
  woId,
  wfDefId,
) => {
  let condition = '';
  let secondChapterFileDetails = [];
  const uniqueIncomingList = [];
  let uniqueIncomingIdList = [];
  const sql = `SELECT * FROM public.wms_workflow_eventlog eventlog
    join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid 
    join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=tfm.woincomingfileid
    where workorderid=${woId} and wfdefid = ${wfDefId} and activitystatus = 'Completed'`;
  await query(sql, [])
    .then(async eventDetails => {
      eventDetails.forEach(item => {
        uniqueIncomingList.push(item.woincomingfileid);
        console.log(item, 'item for preEdit');
      });
      uniqueIncomingIdList = [...new Set(uniqueIncomingList)];
      uniqueIncomingIdList.forEach((list, i) => {
        condition +=
          uniqueIncomingIdList.length - 1 !== i
            ? `filetrn.woincomingfileid = '${list}' OR `
            : `filetrn.woincomingfileid = '${list}'`;
      });
      const sql2 = `select filetrn.repofileuuid,filetrn.repofilepath from wms_workflowactivitytrn_file_map as filetrn
          join wms_workorder_incomingfiledetails  as incomingdetails on filetrn. woincomingfileid = incomingdetails.woincomingfileid
           where  filetrn.repofilepath like '%bib%' ${
             condition ? `${'and ('}${condition})` : ''
           }  order by incomingdetails.filesequence desc limit 1`;
      await query(sql2, [])
        .then(async incomingDetails => {
          secondChapterFileDetails = incomingDetails;
        })
        .catch(er => {
          console.log(er, 'for file reorder');
        });
    })
    .catch(e => {
      console.log(e, 'error for preEditing');
    });
  return secondChapterFileDetails;
};

export const _preEditingLinkingDocxForSecondSquenceCopy = async (
  woId,
  serviceId,
  wfDefId,
  dmsType,
) => {
  // let sql = `select * from (SELECT wms_workflow_eventlog.*, wms_workflowdefinition.stageid, wms_workflowdefinition.activityid FROM public.wms_workflow_eventlog
  //     join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
  // 		   				join wms_workflow_eventlog_details on wms_workflow_eventlog_details.wfeventid = wms_workflow_eventlog.wfeventid
  //     where workorderid = ${woId} and serviceid =${serviceId} and wms_workflow_eventlog.wfdefid = ${wfDefId} and  (wms_workflow_eventlog_details.operationtype = 'Completed' or wms_workflow_eventlog_details.operationtype = 'Rejected' or wms_workflow_eventlog_details.operationtype = 'Failed')  and  (activitystatus = 'Completed' or activitystatus = 'Rejectecd' or activitystatus = 'Failed' )
  //                     order by  wms_workflow_eventlog_details.timestamp  desc limit 1) as hell
  //             join wms_workflowactivitytrn_file_map as filetrn on filetrn.woincomingfileid = hell.woincomingfileid
  //         where  (filetrn.repofilepath like '%bib.docx%' or filetrn.repofilepath like '%rfa.docx%' ) order by actfilemapid desc limit 1`
  const sql = `select * from (SELECT wms_workflow_eventlog.*, wms_workflowdefinition.stageid, wms_workflowdefinition.activityid FROM public.wms_workflow_eventlog
    join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
    join wms_workflow_eventlog_details on wms_workflow_eventlog_details.wfeventid = wms_workflow_eventlog.wfeventid
    where workorderid = ${woId} and serviceid =${serviceId} and wms_workflow_eventlog.wfdefid = ${wfDefId} and  (wms_workflow_eventlog_details.operationtype = 'Completed' or wms_workflow_eventlog_details.operationtype = 'Rejected' or wms_workflow_eventlog_details.operationtype = 'Failed' or wms_workflow_eventlog_details.operationtype = 'Reset')  and  (activitystatus = 'Completed' or activitystatus = 'Rejectecd' or activitystatus = 'Failed' or activitystatus = 'Reset' )
    order by  wms_workflow_eventlog_details.timestamp  desc limit 1) as hell
    join wms_workflowactivitytrn_file_map as filetrn
    on filetrn.woincomingfileid = hell.woincomingfileid 
    where (filetrn.repofilepath like '%bib.docx%' or filetrn.repofilepath like '%rfa.docx%' ) 
    and (select count (*) from  unnest (string_to_array(filetrn.repofilepath, '/'))) <= 14
     order by actfilemapid desc limit 1`;
  const preEventDetails = await query(sql, []);
  switch (dmsType) {
    case 'azure':
      preEventDetails.map(async list => {
        list.repofileuuid = 'azure';
      });
      break;

    default:
      preEventDetails.map(async list => {
        list.repofileuuid = await _getUuid(list.repofilepath);
      });
      break;
  }
  console.log(preEventDetails, 'preEventDetails');
  return preEventDetails;
};

export const fileTxnUpdate = async (wfEventId, uuid, path, incomingfileid) => {
  let sql = `select * from wms_workflowactivitytrn_file_map where wfeventid=${wfEventId} and repofilepath = '${path}'`;
  const count = await query(sql, []);

  if (count.length == 0) {
    sql = `INSERT INTO wms_workflowactivitytrn_file_map(
        wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded,woincomingfileid)
        VALUES ($1, $2, $3,true, false,$4)`;
    await query(sql, [wfEventId, uuid, path, incomingfileid]);
  } else {
    sql = `update wms_workflowactivitytrn_file_map set repofileuuid = '${uuid}' where wfeventid=${wfEventId} and repofilepath = '${path}'`;
    await query(sql, []);
  }
  return true;
};

export const getFileSeqByPriority = async (req, res) => {
  const {
    woId,
    wfDefId,
    stageIterationCount,
    activityIterationCount,
    wfEventId,
  } = req.body;
  let sql = `SELECT filesequence FROM public.wms_workflow_eventlog eventlog join 
    wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=eventlog.woincomingfileid where wfeventid=${wfEventId}`;
  const fileSeq = await query(sql, []);
  sql = `SELECT * FROM public.wms_workflow_eventlog eventlog join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=eventlog.woincomingfileid where
    workorderid=${woId} and wfdefid=${wfDefId} and stageiterationcount=${stageIterationCount} and activityiterationcount=${activityIterationCount} and (activitystatus != 'Completed' and activitystatus != 'Rejected' and activitystatus != 'Reset' ) and filesequence < ${fileSeq[0].filesequence}  order by filesequence asc`;
  console.log(sql, 'sdfsdf');
  const fileSeqPriorityDetails = await query(sql, []);
  if (!fileSeqPriorityDetails.length) {
    res.send({ data: true });
  } else {
    res.send({ data: false, fileName: fileSeqPriorityDetails[0].filename });
  }
};
export const getGraphicStageActivityDetails = async (req, res) => {
  const { activityName, wfdefid } = req.body;
  // let sql = `select activityid,activityname from wms_mst_activity where lower(activityname) like '${activityName}' `
  const sql = `select act.activityid,act.activityname,wf.activitytype from wms_mst_activity  as act
    join wms_workflowdefinition as wf on wf.activityid = act.activityid
    where lower(act.activityname) like '${activityName}' or wf.wfdefid = ${wfdefid} `;
  let sourceActivityName = await query(sql, []);
  let sourceActivityFailedName = [];
  console.log(sourceActivityName, 'sourceActivityName');
  if (
    sourceActivityName &&
    sourceActivityName.length > 0 &&
    sourceActivityName[0].activitytype == 'External Task'
  ) {
    const activityNewName = `${activityName}_f`;
    const sql1 = `select act.activityid,act.activityname,wf.activitytype from wms_mst_activity  as act
        join wms_workflowdefinition as wf on wf.activityid = act.activityid
        where lower(act.activityname) like '${activityNewName}' `;
    sourceActivityFailedName = await query(sql1, []);
  }
  if (
    sourceActivityName &&
    sourceActivityName.length > 0 &&
    sourceActivityName[0].activitytype == 'External Task'
  ) {
    const result = [];
    sourceActivityName = [...sourceActivityName, ...sourceActivityFailedName];
    sourceActivityName.forEach(list => {
      result.push({
        activityId: list.activityid,
        activityName: list.activityname,
        stageId: 10,
        stageName: 'Graphics',
        activityType: list.activitytype,
      });
    });
    res.send(result);
  } else if (
    sourceActivityName &&
    sourceActivityName.length > 0 &&
    sourceActivityName[0].activitytype == 'User Task'
  ) {
    res.send({
      activityId: sourceActivityName[0].activityid,
      activityName: sourceActivityName[0].activityname,
      stageId: 10,
      stageName: 'Graphics',
      activityType: sourceActivityName[0].activitytype,
    });
  } else {
    res.send({});
  }
};

export const getBibFileDetails = async (woId, wfDefId) => {
  const sql = `SELECT * FROM public.wms_workflow_eventlog eventlog 
   where workorderid=${woId} and  wfdefid =${wfDefId} and (activitystatus = 'Completed' or activitystatus = 'Rejected' or activitystatus = 'Reset') ORDER BY wfeventid ASC`;
  const bibFileDetails = await query(sql, []);
  return bibFileDetails;
};

export const getEntFileDetails = async (
  woId,
  wfDefId,
  activityIterationCount,
  stageIterationCount,
) => {
  const sql = `SELECT * FROM public.wms_workflow_eventlog eventlog 
   where workorderid=${woId} and  wfdefid =${wfDefId} and stageiterationcount = ${stageIterationCount} and activityiterationcount =${activityIterationCount} and (activitystatus = 'Completed' or activitystatus = 'Rejected' or activitystatus = 'Reset') ORDER BY wfeventid ASC`;
  const entFileDetails = await query(sql, []);
  return entFileDetails;
};

export const getSrcFileDetails1 = async (woId, wfDefId) => {
  const sql = `SELECT * FROM public.wms_workflow_eventlog eventlog 
   where workorderid=${woId} and  wfdefid =${wfDefId} and (activitystatus = 'Completed' or activitystatus = 'Rejected' or activitystatus = 'Reset') ORDER BY wfeventid ASC`;
  const entFileDetails = await query(sql, []);
  return entFileDetails;
};

// latest changes for batchpagination aand batchpagination_f activity
export const getSrcFileDetails = async (woId, wfDefId, instanceType) => {
  let srcFileDetails = [];
  let sql = '';
  let condition = '';
  let condition2 = '';
  condition2 +=
    instanceType == 'Single'
      ? `join wms_workflowactivitytrn_file_map as filetrn on filetrn.wfeventid = hell.wfeventid
        where  (filetrn.repofilepath like '%page_target%')order by actfilemapid desc`
      : ` join wms_workflowactivitytrn_file_map as filetrn on filetrn.woincomingfileid = hell.woincomingfileid
        where  (filetrn.repofilepath like '%page_target%')order by actfilemapid desc`;
  if (Array.isArray(wfDefId)) {
    wfDefId.forEach((list, i) => {
      condition +=
        wfDefId.length - 1 !== i
          ? `eventlog.wfdefid =  ${list} OR `
          : ` eventlog.wfdefid =  ${list}`;
    });

    // sql = `SELECT eventlog.stageiterationcount,eventlog.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname FROM public.wms_workflow_eventlog as eventlog
    // join wms_workflowdefinition as wf on wf.wfdefid = eventlog.wfdefid
    // join wms_mst_stage as stage on stage.stageid = wf.stageid
    // join wms_mst_activity as activity on activity.activityid = wf.activityid
    // where workorderid = ${woId}  ${condition ? 'and ' + '( ' + condition + ' )' : ''} order by wfeventid desc`;
    //

    sql = `select hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname,wf.instancetype, wf.activitytype from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            JOIN wms_workflow_eventlog_details as eventlogdetails on eventlogdetails.wfeventid = eventlog.wfeventid
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId}  ${
      condition ? `${'and ( '}${condition} )` : ''
    } and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or activitystatus = 'Reset' ) order by eventlogdetails.wfeventdetailid desc limit 1) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            ${condition2 || ''}`;

    srcFileDetails = await query(sql, []);
  } else {
    //  sql = `SELECT eventlog.stageiterationcount,eventlog.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname FROM public.wms_workflow_eventlog as eventlog
    // join wms_workflowdefinition as wf on wf.wfdefid = eventlog.wfdefid
    // join wms_mst_stage as stage on stage.stageid = wf.stageid
    // join wms_mst_activity as activity on activity.activityid = wf.activityid
    // where workorderid = ${woId} and eventlog.wfdefid=${wfDefId} order by wfeventid desc limit 1`;

    sql = `select hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname,wf.instancetype, wf.activitytype  from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId} and eventlog.wfdefid=${wfDefId}  and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or activitystatus = 'Reset' ) order by eventlog.wfeventid desc limit 1) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            ${condition2 || ''}`;
    srcFileDetails = await query(sql, []);
  }

  if (!srcFileDetails.length) {
    sql = `select hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname, wf.instancetype, wf.activitytype  from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId} ${
      condition && Array.isArray(wfDefId)
        ? `${'and ( '}${condition} )`
        : ` and eventlog.wfdefid= ${wfDefId}`
    }  and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or  activitystatus = 'Reset') order by eventlog.wfeventid desc limit 1) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            join wms_workflowactivitytrn_file_map as filetrn on filetrn.wfeventid = hell.wfeventid
        where  (filetrn.repofilepath like '%page_target%')order by actfilemapid desc`;

    srcFileDetails = await query(sql, []);
  }
  return srcFileDetails;
};

export const getSrcFileDetailsForServiceTask = async (
  woId,
  wfDefId,
  instanceType,
) => {
  let srcFileDetails = [];
  let sql = '';
  let condition = '';
  let condition2 = '';
  condition2 +=
    instanceType == 'Single'
      ? `join wms_workflowactivitytrn_file_map as filetrn on filetrn.wfeventid = hell.wfeventid
        where  (filetrn.repofilepath like '%page_target%')`
      : ` join wms_workflowactivitytrn_file_map as filetrn on filetrn.woincomingfileid = hell.woincomingfileid
        where  (filetrn.repofilepath like '%page_target%')`;
  if (Array.isArray(wfDefId)) {
    wfDefId.forEach((list, i) => {
      condition +=
        wfDefId.length - 1 !== i
          ? `eventlog.wfdefid =  ${list} OR `
          : ` eventlog.wfdefid =  ${list}`;
    });

    // sql = `SELECT eventlog.stageiterationcount,eventlog.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname FROM public.wms_workflow_eventlog as eventlog
    // join wms_workflowdefinition as wf on wf.wfdefid = eventlog.wfdefid
    // join wms_mst_stage as stage on stage.stageid = wf.stageid
    // join wms_mst_activity as activity on activity.activityid = wf.activityid
    // where workorderid = ${woId}  ${condition ? 'and ' + '( ' + condition + ' )' : ''} order by wfeventid desc`;
    //

    sql = `select DISTINCT wf.activityid as activityids, hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            JOIN wms_workflow_eventlog_details as eventlogdetails on eventlogdetails.wfeventid = eventlog.wfeventid
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId}  ${
      condition ? `${'and ( '}${condition} )` : ''
    } and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or activitystatus = 'Reset' ) order by eventlogdetails.wfeventdetailid desc) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            ${condition2 || ''}`;

    srcFileDetails = await query(sql, []);
  } else {
    //  sql = `SELECT eventlog.stageiterationcount,eventlog.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname FROM public.wms_workflow_eventlog as eventlog
    // join wms_workflowdefinition as wf on wf.wfdefid = eventlog.wfdefid
    // join wms_mst_stage as stage on stage.stageid = wf.stageid
    // join wms_mst_activity as activity on activity.activityid = wf.activityid
    // where workorderid = ${woId} and eventlog.wfdefid=${wfDefId} order by wfeventid desc limit 1`;

    sql = `select DISTINCT wf.activityid as activityids  hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId} and eventlog.wfdefid=${wfDefId}  and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or activitystatus = 'Reset' ) order by eventlog.wfeventid desc ) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            ${condition2 || ''}`;
    srcFileDetails = await query(sql, []);
  }

  if (!srcFileDetails.length) {
    sql = `select DISTINCT wf.activityid as activityids ,hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId} ${
      condition && Array.isArray(wfDefId)
        ? `${'and ( '}${condition} )`
        : ` and eventlog.wfdefid= ${wfDefId}`
    }  and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or  activitystatus = 'Reset') order by eventlog.wfeventid desc ) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            join wms_workflowactivitytrn_file_map as filetrn on filetrn.wfeventid = hell.wfeventid
        where  (filetrn.repofilepath like '%page_target%')`;

    srcFileDetails = await query(sql, []);
  }
  return srcFileDetails;
};

export const getSrcInternalFile = async (
  woId,
  wfDefId,
  srcFileExt,
  instanceType,
) => {
  let srcFileDetails = [];
  let sql = '';
  let condition = '';
  let condtion3 = '';
  let condition2 = '';
  condition2 +=
    instanceType == 'Single'
      ? `join wms_workflowactivitytrn_file_map as filetrn on filetrn.wfeventid = hell.wfeventid`
      : ` join wms_workflowactivitytrn_file_map as filetrn on filetrn.woincomingfileid = hell.woincomingfileid`;
  if (Array.isArray(srcFileExt)) {
    srcFileExt.forEach((list, i) => {
      condtion3 +=
        srcFileExt.length - 1 !== i
          ? `filetrn.repofilepath like '%${list}' OR `
          : ` filetrn.repofilepath like '%${list}'`;
    });
  } else {
    condtion3 = ` filetrn.repofilepath like '%${srcFileExt}'`;
  }
  if (Array.isArray(wfDefId)) {
    wfDefId.forEach((list, i) => {
      condition +=
        wfDefId.length - 1 !== i
          ? `eventlog.wfdefid =  ${list} OR `
          : ` eventlog.wfdefid =  ${list}`;
    });

    sql = `select hell.wfeventid,hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname,filetrn.repofilepath,filetrn.repofileuuid from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId}  ${
      condition ? `${'and ( '}${condition} )` : ''
    } and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or activitystatus = 'Reset' ) order by eventlog.wfeventid desc) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            ${condition2 || ''} ${
      condtion3 ? `${'where ( '}${condtion3} )` : ''
    } order by  hell.wfeventid desc`;

    srcFileDetails = await query(sql, []);
  } else {
    sql = `select hell.wfeventid, hell.stageiterationcount,hell.activityiterationcount, wf.stageid,wf.activityid, stage.stagename,activity.activityname,filetrn.repofilepath,filetrn.repofileuuid from (SELECT eventlog.woincomingfileid, incomingdetails.filesequence,eventlog.wfeventid,eventlog.wfdefid,eventlog.activityiterationcount,eventlog.stageiterationcount FROM public.wms_workflow_eventlog eventlog
            left join wms_workorder_incomingfiledetails  as incomingdetails on  eventlog.woincomingfileid = incomingdetails.woincomingfileid
            where workorderid = ${woId} and eventlog.wfdefid=${wfDefId}  and (activitystatus = 'Completed' or  activitystatus = 'Rejected' or activitystatus = 'Reset' ) order by eventlog.wfeventid desc) as hell
            join wms_workflowdefinition as wf on wf.wfdefid = hell.wfdefid
            join wms_mst_stage as stage on stage.stageid = wf.stageid
            join wms_mst_activity as activity on activity.activityid = wf.activityid
            ${condtion3 || ''} order by  hell.wfeventid desc`;
    srcFileDetails = await query(sql, []);
  }

  return srcFileDetails;
};

export const getFileSeq = async wfEventId => {
  const sql = `SELECT * FROM public.wms_workflow_eventlog eventlog join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=eventlog.woincomingfileid where
    wfeventid=${wfEventId} ORDER BY filesequence ASC`;
  const fileSeqDetails = await query(sql, []);
  return fileSeqDetails;
};
export const _getEventDetails = async (
  woId,
  wfDefId,
  stageIterationCount,
  activityIterationCount,
) => {
  const sql = `SELECT * FROM public.wms_workflow_eventlog eventlog 
    join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=eventlog.woincomingfileid 
    join wms_workflowactivitytrn_file_map tfm on tfm.wfeventid=eventlog.wfeventid where
    workorderid=${woId} and wfdefid=${wfDefId} and stageiterationcount=${stageIterationCount} and
    activityiterationcount=${activityIterationCount} and (activitystatus='Completed' or activitystatus='Rejected' or activitystatus='Reset' )`;
  const eventData = await query(sql, []);
  return eventData;
};

export const _getActivityDetails = async wfEventId => {
  const sql = `SELECT * FROM public.wms_wfevent_details where wfEventId = $1`;
  const eventData = await query(sql, [wfEventId]);
  const {
    workorderid,
    serviceid,
    servicename,
    customerid,
    customername,
    duid,
    duname,
    wfdefid,
    stageid,
    stagename,
    stageiterationcount,
    activityid,
    activityname,
    activityiterationcount,
    activitycount,
    woincomingfileid,
    config,
    fileconfig,
    toolsconfig,
    softwareconfig,
    filetype,
    filetypeid,
    allowsubfiletype,
    wfid,
    pmemail,
    pmname,
    itemcode,
    instancetype,
    wotype,
    dmstype,
    activitytype,
    actualactivitycount,
    issuemstid,
    isonlineissue,
    ismscompleted,
    activitymodeltypeflow,
    pubflowconfig,
    articleordersequence,
    newsletter,
    iscamundaflow,
    activityalias,
    runonfilesequence,
  } = eventData[0];
  const wfConfig = config || {};
  return {
    wfDefId: wfdefid,
    wfId: wfid,
    du: { name: duname, id: duid },
    customer: { name: customername, id: customerid },
    workOrderId: workorderid,
    service: { name: servicename, id: serviceid },
    stage: {
      name: stagename,
      id: stageid,
      iteration: stageiterationcount,
      basePath: await getFolderStructure({
        type: 'wo_stage_iteration',
        du: { name: duname, id: duid },
        customer: { name: customername, id: customerid },
        workOrderId: workorderid,
        service: { name: servicename, id: serviceid },
        stage: { name: stagename, id: stageid, iteration: stageiterationcount },
        activity: {
          name: activityname,
          id: activityid,
          iteration: activityiterationcount,
        },
      }),
    },
    activity: {
      name: activityname,
      id: activityid,
      iteration: activityiterationcount,
      count: activitycount,
      actualactivitycount: actualactivitycount || activitycount,
      activityalias,
    },
    fileId: woincomingfileid,
    fileTypeName: filetype,
    fileTypeId: filetypeid,
    allowSubFileType: allowsubfiletype,
    softwareId: wfConfig.softwareId ? wfConfig.softwareId : [],
    toolsId: wfConfig.toolsId ? wfConfig.toolsId : [],
    fileConfig: ReStructureFileConfig(fileconfig) || {},
    softwareConfig: softwareconfig || {},
    toolsConfig: toolsconfig || {},
    activityConfig: config || {},
    basePath: await getFolderStructure({
      type: 'wo_activity_iteration',
      du: { name: duname, id: duid },
      customer: { name: customername, id: customerid },
      workOrderId: workorderid,
      service: { name: servicename, id: serviceid },
      stage: { name: stagename, id: stageid, iteration: stageiterationcount },
      activity: {
        name: activityname,
        id: activityid,
        iteration: activityiterationcount,
      },
    }),
    pmEmail: pmemail,
    pmName: pmname,
    itemCode: itemcode,
    instanceType: instancetype,
    wotype,
    dmsType: dmstype || null,
    activityType: activitytype,
    issuemstid,
    isonlineissue,
    ismscompleted,
    activitymodeltypeflow,
    pubflowconfig,
    articleOrderSequence: articleordersequence,
    newsletter,
    iscamundaflow,
    runonfilesequence,
  };
};

export const getUserOpenTask = (req, res) => {
  res.status(200).json({ data: true });

  // const { userid, roleid } = req.body;
  // const sysInfo = req.headers.systemdetail
  //   ? JSON.parse(req.headers.systemdetail)
  //   : {};
  // let sql = ``;
  // if (roleid == 1 || roleid == 9) {
  //   sql = `SELECT wms_tasklist.*,
  //   CASE
  //       WHEN wms_workflow_eventlog_details.systeminfo != '[object Object]' THEN wms_workflow_eventlog_details.systeminfo::JSON->> 'SYSTEM_NAME'
  //         ELSE 'WEB USER'
  //       END as systemname
  //   FROM wms_tasklist
  //   JOIN wms_workflow_eventlog_details ON wms_workflow_eventlog_details.wfeventid = wms_tasklist.wfeventid
  //   WHERE lower(wms_tasklist.userid)='${userid.toLowerCase()}' AND activitystatus = 'Work in progress' AND
  //   activityalias in ('Despatch', 'Wait for Author Feedback', 'Collation','PM Review')
  //   ORDER BY wms_workflow_eventlog_details.wfeventdetailid DESC LIMIT 1`;
  // } else {
  //   sql = `SELECT wms_tasklist.*,filename,itemcode,activityname,stagename,
  //   CASE
  //   WHEN wms_workflow_eventlog_details.systeminfo != '[object Object]' THEN wms_workflow_eventlog_details.systeminfo::JSON->> 'SYSTEM_NAME'
  //     ELSE 'WEB USER'
  //   END as systemname
  //   FROM wms_tasklist
  //   JOIN wms_workflow_eventlog_details ON wms_workflow_eventlog_details.wfeventid = wms_tasklist.wfeventid
  //   WHERE lower(wms_tasklist.userid)='${userid.toLowerCase()}' AND activitystatus = 'Work in progress'
  //   ORDER BY wms_workflow_eventlog_details.wfeventdetailid DESC LIMIT 1`;
  // }
  //
  // query(sql)
  //   .then(response => {
  //     if (response.length > 0) {
  //       // updated for fileconfig restructure
  //       response.forEach(item => {
  //         item.fileconfig = ReStructureFileConfig(item.fileconfig);
  //       });
  //       if (
  //         response[0].systemname.toLowerCase() ==
  //         sysInfo.SYSTEM_NAME.toLowerCase()
  //       ) {
  //         res.status(200).json({ data: response });
  //       } else {
  //         res.status(200).json({ data: [] });
  //       }
  //     } else {
  //       query(
  //         `select landingpage from public.trn_landingpage where user_roleid = ${roleid} and isactive = true`,
  //       ).then(qryresponse => {
  //         res
  //           .status(200)
  //           .json({ data: qryresponse.length > 0 ? qryresponse : [] });
  //       });
  //     }
  //   })
  //   .catch(error => {
  //     res.status(400).send({ message: error });
  //   });
};

export const copyLinkingDocxFilesForAllChapters = async (req, res) => {
  const {
    woId,
    wfDefId,
    srcWfDefId,
    duname,
    duid,
    customername,
    customerid,
    servicename,
    serviceid,
    stagename,
    stageid,
    stageiterationcount,
    activityname,
    activityid,
    activityiterationcount,
    fileTypeName,
    fileTypeId,
    fileIncomingId,
    allowSubFileType,
    incWfDefid,
    wordIdInsertionWfDefid,
  } = req.body;
  const out = [];
  try {
    const dmsType = await getdmsType(woId);
    const bibFileDetails = await getBibFileDetails(woId, wfDefId);
    if (bibFileDetails && bibFileDetails.length == 0) {
      const basePath = await getFolderStructure({
        type: allowSubFileType
          ? 'wo_activity_file_subtype'
          : 'wo_activity_filetype',
        du: { name: duname, id: duid },
        customer: { name: customername, id: customerid },
        workOrderId: woId,
        service: { name: servicename, id: serviceid },
        stage: { name: stagename, id: stageid, iteration: stageiterationcount },
        activity: {
          name: activityname,
          id: activityid,
          iteration: activityiterationcount,
        },
        fileType: {
          name: fileTypeName,
          id: fileTypeId,
          fileId: fileIncomingId,
        },
      });
      const eventDetails = await _preEditingLinkingDocxCopy(
        woId,
        srcWfDefId,
        wordIdInsertionWfDefid,
        incWfDefid,
        dmsType,
      );
      let destUuid = '';
      switch (dmsType) {
        case 'azure':
          destUuid = 'azure';
          break;
        default:
          destUuid = await _createFolder(basePath);
          break;
      }
      for (let i = 0; i < eventDetails.length; i++) {
        const name = basename(eventDetails[i].repofilepath);
        const ext = extname(name);
        if (ext === '.docx') {
          console.log('docx file==========>', name, ext);
          try {
            if (eventDetails.length > 0) {
              out.push({
                src: eventDetails[i].repofileuuid,
                srcPath: eventDetails[i].repofilepath,
                dest: destUuid,
                destBasePath: basePath,
                name,
              });
            }
          } catch (error) {
            console.log('error', error);
          }
        }
      }
    } else {
      const basePath2 = await getFolderStructure({
        type: allowSubFileType
          ? 'wo_activity_file_subtype'
          : 'wo_activity_filetype',
        du: { name: duname, id: duid },
        customer: { name: customername, id: customerid },
        workOrderId: woId,
        service: { name: servicename, id: serviceid },
        stage: { name: stagename, id: stageid, iteration: stageiterationcount },
        activity: {
          name: activityname,
          id: activityid,
          iteration: activityiterationcount,
        },
        fileType: {
          name: fileTypeName,
          id: fileTypeId,
          fileId: fileIncomingId,
        },
      });
      const eventDetails2 = await _preEditingLinkingDocxForSecondSquenceCopy(
        woId,
        serviceid,
        wfDefId,
        dmsType,
      );
      let destUuid = '';
      switch (dmsType) {
        case 'azure':
          destUuid = 'azure';
          break;
        default:
          destUuid = await _createFolder(basePath2);
          break;
      }
      for (let i = 0; i < eventDetails2.length; i++) {
        const name = basename(eventDetails2[i].repofilepath);
        const ext = extname(name);
        if (ext === '.docx') {
          console.log('docx file==========>', name, ext);
          try {
            if (eventDetails2.length > 0) {
              out.push({
                src: eventDetails2[i].repofileuuid,
                srcPath: eventDetails2[i].repofilepath,
                dest: destUuid,
                destBasePath: basePath2,
                name,
              });
            }
          } catch (error) {
            console.log('error', error);
          }
        }
      }
    }
    res.send(out);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const copyEntFileForAllChapter = async (req, res) => {
  const {
    woId,
    wfDefId,
    completionTriggerWfDefId,
    basePath,
    stageIterationCount,
    activityIterationCount,
  } = req.body;
  const out = [];
  try {
    const dmsType = await getdmsType(woId);
    // const filteredBookTypeDetails = incomingDetails.filter(
    //   list => list.filetypeid == '1',
    // );
    const entFileDetails = await getEntFileDetails(
      woId,
      wfDefId,
      activityIterationCount,
      stageIterationCount,
    );
    if (entFileDetails && entFileDetails.length == 0) {
      const eventDetails = await correctionFirstChapterEntFileCopy(
        woId,
        completionTriggerWfDefId,
      );
      console.log(eventDetails, 'eventDetails');
      let destUuid = '';
      switch (dmsType) {
        case 'azure':
          destUuid = 'azure';
          break;
        default:
          destUuid = await _createFolder(`${basePath}book_${1}/page_target/`);
          break;
      }
      const destPath = `${basePath}book_${1}/page_target/`;
      for (let i = 0; i < eventDetails.length; i++) {
        const name = basename(eventDetails[i].repofilepath);
        const ext = extname(name);
        if (ext === '.ent') {
          console.log('docx file==========>', name, ext);
          let srcRepoFileId = '';
          switch (dmsType) {
            case 'azure':
              srcRepoFileId = 'azure';
              break;
            default:
              srcRepoFileId = await _getUuid(eventDetails[i].repofilepath);
              break;
          }
          out.push({
            src: srcRepoFileId,
            srcPath: eventDetails[i].repofilepath,
            dest: destUuid,
            destBasePath: destPath,
            name,
          });
        }
      }
    } else {
      const eventDetails2 = await correctionRemainigChapterEntFileCopy(
        woId,
        wfDefId,
      );
      if (eventDetails2.length > 0) {
        let destUuid = '';
        switch (dmsType) {
          case 'azure':
            destUuid = 'azure';
            break;
          default:
            destUuid = await _createFolder(`${basePath}book_${1}/page_target/`);
            break;
        }
        const destPath = `${basePath}book_${1}/page_target/`;
        for (let i = 0; i < eventDetails2.length; i++) {
          const name = basename(eventDetails2[i].repofilepath);
          const ext = extname(name);
          if (ext === '.ent') {
            let srcRepoFileId = '';
            switch (dmsType) {
              case 'azure':
                srcRepoFileId = 'azure';
                break;
              default:
                srcRepoFileId = await _getUuid(eventDetails2[i].repofilepath);
                break;
            }
            out.push({
              src: srcRepoFileId,
              srcPath: eventDetails2[i].repofilepath,
              dest: destUuid,
              destBasePath: destPath,
              name,
            });
          }
        }
      }
    }
    res.send(out);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const jobInfoDetailsUpdate = async (req, res) => {
  const { wfEventId, uuid, path, fileIncomingId } = req.body;
  try {
    await fileTxnUpdate(wfEventId, uuid, path, fileIncomingId);
    res.send(true);
  } catch (e) {
    console.log(e, 'error for update jobinfo details');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const TemplateDetailsUpdate = async (req, res) => {
  const { wfEventId, uuid, path, fileIncomingId } = req.body;
  try {
    const sql = `select count (1) from wms_workflowactivitytrn_file_map where wfeventid=${wfEventId} and repofilepath = '${path}'`;

    query(sql)
      .then(async response => {
        if (response[0].count == 0) {
          await fileTxnUpdate(wfEventId, uuid, path, fileIncomingId);
        } else {
          const uniqueName = dirname(path);
          console.log(uniqueName, 'dsfsd');
          const sql1 = `select * from  wms_workflowactivitytrn_file_map  WHERE wfeventid = ${wfEventId} and repofilepath like '%${uniqueName}%'`;
          query(sql1)
            .then(async resp => {
              if (resp && resp.length > 0) {
                const sql3 = `Update  wms_workflowactivitytrn_file_map SET repofilepath = '${path}', repofileuuid = '${uuid}' WHERE actfilemapid = ${resp[0].actfilemapid}`;
                console.log(sql3, 'sfsdfs');
                query(sql3)
                  .then(() => {})
                  .catch(error => {
                    res.status(400).send({ message: error });
                  });
              }
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        }
        res.status(200).send(true);
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (e) {
    console.log(e, 'error for update jobinfo details');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const TemplateDetailsDelete = async (req, res) => {
  const { fileName, wfEventId } = req.body;

  try {
    const fileNames =
      fileName && fileName.length > 0 ? fileName.split('.') : '';
    if (fileNames && fileNames.length > 0) {
      const sql = `DELETE FROM wms_workflowactivitytrn_file_map WHERE wfeventid =${wfEventId} AND repofilepath like '%${fileNames[0]}%'`;

      query(sql)
        .then(response => {
          res.status(200).json({ data: response });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    } else {
      res.status(200).json({ data: [] });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const graphicsTrnUpdate = async (req, res) => {
  const {
    woId,
    srcPathDetails,
    wfEventId,
    duname,
    duid,
    customername,
    customerid,
    servicename,
    serviceid,
    stagename,
    stageid,
    stageiterationcount,
    activityname,
    activityid,
    activityiterationcount,
    fileTypeName,
    fileTypeId,
    fileIncomingId,
    allowSubFileType,
    fileterdDetailsName,
    incomingFileDetails,
    instanceType,
    graphicFieldType,
    basePathComman,
    woType,
  } = req.body;
  try {
    if (incomingFileDetails && incomingFileDetails.length > 0) {
      incomingFileDetails.forEach(list => {
        if (Object.keys(list).includes('fileid')) {
          list.woincomingfileid = list.fileid ? list.fileid : '';
        }
      });
    }
    const placeHolders = await getWorkflowPlaceHolders(wfEventId);
    // to be handled book workflow
    placeHolders.FileTypeName =
      placeHolders.ArticleTypeList.length == 1
        ? placeHolders.ArticleTypeList[0].FileTypeName
        : null;
    const formattedFileName =
      srcPathDetails &&
      srcPathDetails.length > 0 &&
      srcPathDetails[0].folderName
        ? getFormattedName(srcPathDetails[0].folderName, placeHolders)
        : '';
    const datatosend = [];
    const singleFileTypeDetails =
      woType == 'Journal' && incomingFileDetails.length > 0
        ? incomingFileDetails[0]
        : incomingFileDetails.filter(list => list.filetypeid == '1');
    if (fileIncomingId != null) {
      let basePath = await getFolderStructure({
        type: allowSubFileType
          ? 'wo_activity_file_subtype'
          : 'wo_activity_filetype',
        du: { name: duname, id: duid },
        customer: { name: customername, id: customerid },
        workOrderId: woId,
        service: { name: servicename, id: serviceid },
        stage: { name: stagename, id: stageid, iteration: stageiterationcount },
        activity: {
          name: activityname,
          id: activityid,
          iteration: activityiterationcount,
        },
        fileType:
          instanceType == 'Single' &&
          singleFileTypeDetails &&
          singleFileTypeDetails.length > 0
            ? {
                name: singleFileTypeDetails[0].filetype,
                id: singleFileTypeDetails[0].filetypeid,
                fileId: singleFileTypeDetails[0].woincomingfileid,
              }
            : { name: fileTypeName, id: fileTypeId, fileId: fileIncomingId },
      });
      const figureTextPath =
        woType == 'Journal'
          ? basePathComman
          : woType == 'Book'
          ? basePath
          : `${basePathComman}book_${1}/`;
      const _basePath = basePath;
      if (instanceType == 'Single') {
        basePath =
          customerid == 10 || customerid == 13
            ? _basePath
            : graphicFieldType === 'graphicText'
            ? figureTextPath
            : srcPathDetails &&
              srcPathDetails.length > 0 &&
              srcPathDetails[0].folderName &&
              formattedFileName
            ? `${basePath + formattedFileName}/`
            : `${basePath}IMAGES/`;
      } else {
        basePath =
          customerid == 10 || customerid == 13
            ? _basePath
            : graphicFieldType === 'graphicText'
            ? figureTextPath
            : fileterdDetailsName &&
              fileterdDetailsName.length > 0 &&
              fileterdDetailsName[0].filename
            ? `${basePath + fileterdDetailsName[0].filename}/`
            : basePath;
      }
      datatosend.push({
        copyData: srcPathDetails,
        wfEventId,
        basePath: _basePath,
        destBasePath: basePath,
        relativePath: basePath.replace(_basePath, ''),
        incomingfileid:
          (instanceType == 'Single' || graphicFieldType === 'graphicText') &&
          woType == 'Journal' &&
          singleFileTypeDetails &&
          singleFileTypeDetails.length > 0
            ? singleFileTypeDetails[0].woincomingfileid
            : fileIncomingId,
      });
    } else {
      for (let j = 0; j < incomingFileDetails.length; j++) {
        if (
          incomingFileDetails[j].filetypeid != '1' &&
          incomingFileDetails[j].filetypeid != '15'
        ) {
          let basePath = await getFolderStructure({
            type: allowSubFileType
              ? 'wo_activity_file_subtype'
              : 'wo_activity_filetype',
            du: { name: duname, id: duid },
            customer: { name: customername, id: customerid },
            workOrderId: woId,
            service: { name: servicename, id: serviceid },
            stage: {
              name: stagename,
              id: stageid,
              iteration: stageiterationcount,
            },
            activity: {
              name: activityname,
              id: activityid,
              iteration: activityiterationcount,
            },
            fileType:
              instanceType == 'Single' &&
              singleFileTypeDetails &&
              singleFileTypeDetails.length > 0
                ? {
                    name: singleFileTypeDetails[0].filetype,
                    id: singleFileTypeDetails[0].filetypeid,
                    fileId: singleFileTypeDetails[0].woincomingfileid,
                  }
                : {
                    name: incomingFileDetails[j].filetype,
                    id: incomingFileDetails[j].filetypeid,
                    fileId: incomingFileDetails[j].woincomingfileid,
                  },
          });
          const figureTextPath =
            woType == 'Journal'
              ? basePathComman
              : `${basePathComman}book_${1}/`;
          const _basePath = basePath;
          if (instanceType == 'Single') {
            basePath =
              customerid == 10
                ? _basePath
                : graphicFieldType === 'graphicText'
                ? figureTextPath
                : srcPathDetails &&
                  srcPathDetails.length > 0 &&
                  srcPathDetails[0].folderName &&
                  formattedFileName
                ? `${basePath + formattedFileName}/`
                : `${basePath}IMAGES/`;
          } else {
            basePath =
              customerid == 10
                ? _basePath
                : graphicFieldType === 'graphicText'
                ? figureTextPath
                : fileterdDetailsName &&
                  fileterdDetailsName.length > 0 &&
                  fileterdDetailsName[0].filename
                ? `${basePath + fileterdDetailsName[0].filename}/`
                : basePath;
          }
          const CopyData = [];
          if (srcPathDetails.length > 0) {
            CopyData.push(...srcPathDetails);
          }
          const icFileId =
            (instanceType == 'Single' || graphicFieldType === 'graphicText') &&
            singleFileTypeDetails &&
            singleFileTypeDetails.length > 0
              ? singleFileTypeDetails[0].woincomingfileid
              : incomingFileDetails[j].woincomingfileid;
          if (
            datatosend.filter(
              x => x.incomingfileid == icFileId && x.destBasePath == basePath,
            ).length == 0
          ) {
            datatosend.push({
              copyData: srcPathDetails,
              wfEventId,
              destBasePath: basePath,
              basePath: _basePath,
              relativePath: basePath.replace(_basePath, ''),
              incomingfileid: icFileId,
            });
          }
        }
      }
    }
    res.status(200).json(datatosend);
  } catch (e) {
    res.status(400).json({ data: e });
    console.log('errordd', e);
  }
};

export const trnactivtyEntry = async (req, res) => {
  const dataToEnter = req.body;
  try {
    const val = [];
    if (Array.isArray(dataToEnter) && dataToEnter.length > 0) {
      dataToEnter.forEach(x => {
        val.push(
          `(${x.wfEventId},'${x.uuid}','${x.path}',true,false,${x.incomingfileid})`,
        );
      });
    }
    const sql = `	INSERT INTO wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded,woincomingfileid)
            VALUES ${val}`;
    if (val.length > 0) {
      await query(sql, [])
        .then(async () => {})
        .catch(e => {
          throw new Error(e.message);
        });
    }
    res.status(200).json({ data: 'updated File details.' });
  } catch (error) {
    console.log('errordd', error);
    res.status(400).json({ data: error });
  }
};

export const getGraphicIterationDetail = (req, res) => {
  let sql = '';
  const { woId, activityId, stageId, needOnlyCompleted } = req.body;
  if (needOnlyCompleted) {
    sql = `select * from wms_workflow_eventlog as eventlog
        join wms_workflowdefinition as wfd on wfd.wfdefid = eventlog.wfdefid
        where eventlog.workorderid = ${woId} and wfd.stageid =${stageId} and wfd.activityid = ${activityId}  and activitystatus ='Completed'order by wfeventid desc limit  1`;
  } else {
    sql = `select * from wms_workflow_eventlog as eventlog
        join wms_workflowdefinition as wfd on wfd.wfdefid = eventlog.wfdefid
        where eventlog.workorderid = ${woId} and wfd.stageid =${stageId} and wfd.activityid = ${activityId} order by wfeventid desc`;
  }

  query(sql)
    .then(response => {
      // updated for fileconfig restructure
      response.forEach(item => {
        item.fileconfig = ReStructureFileConfig(item.fileconfig);
      });
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getChapterWoIdDetails = (req, res) => {
  let sql = '';
  let { fileName } = req.body;
  if (fileName.includes('Frontmatter')) {
    fileName = fileName.replace('BookFrontmatter', 'FM1_Chapter');
  }
  if (fileName.includes('Backmatter')) {
    fileName = fileName.replace('BookBackmatter', 'BM2_Chapter');
  }
  sql = `select bookwo.workorderid, incomfile.woincomingfileid, incomfile.filename, incomfile.filetypeid, filetype.filetype
            from wms_book_workorder_details as bookwo
            join wms_workorder_incoming as incom on incom.woid = bookwo.workorderid
            join wms_workorder_incomingfiledetails as incomfile on incomfile.woincomingid = incom.woincomingid
            join pp_mst_filetype as filetype on incomfile.filetypeid = filetype.filetypeid
            where bookwo.filename = '${fileName}' order by bookwo.file_sequence asc`;
  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getCopyEditingLevel = (req, res) => {
  const { workorderid } = req.body;
  const sql = `select
	case when package.file = 'ST' then 1 when  package.file = 'ES' then 2 else  wo.celevelid end as celevelid,
	jo.isiauthor,
	jo.journaltype,
	package.file
from
	public.wms_workorder as wo
left join pp_mst_journal as jo on
	wo.journalid = jo.journalid
left join (
	select
		distinct substring(fawc.ftpfilename
	from
		'_([A-Za-z0-9]+)\.zip') as file,
		ww.workorderid
	from
		ftp_audit_wo_creation fawc
	join wms_workorder ww on
		ww.itemcode = fawc.articlename
	where
		ww.workorderid = ${workorderid}
	order by
		1 desc
	limit 1) as package on
	package.workorderid = wo.workorderid
where
	wo.workorderid = ${workorderid}`;
  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const setIssueStartPage = (req, res) => {
  const { workorderid, issuestartpage } = req.body;
  //  const sql= `UPDATE wms_workorder_incomingfiledetails wif SET issuestartpage = ${issuestartpage} WHERE wif.woincomingid IN (
  //     SELECT woi.woincomingid FROM wms_workorder_incoming woi WHERE woi.woid = ${workorderid})`;
  const sql = `UPDATE wms_workorder_incoming wif SET issuestartpage = ${issuestartpage} WHERE wif.woid = ${workorderid}`;

  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const isDirectFirstProof = (req, res) => {
  const { workorderid } = req.body;
  const sql = `SELECT wo.otherfield,jo.isnlp,wo.iscoveravailable,wo.isadvertavailable, wo.ceddetails,jo.isiauthor,jo.celevelid FROM public.wms_workorder as wo
    left join pp_mst_journal as jo on wo.journalid=jo.journalid where  workorderid= ${workorderid} `;
  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const copyPageTargetForUserTask = async (req, res) => {
  // const out = [];
  const {
    woId,
    // wfDefId,
    // wfEventId,
    srcWfDefId,
    // basePath,
    duname,
    duid,
    customername,
    customerid,
    servicename,
    serviceid,
    // incomingDetails,
    instanceType,
  } = req.body;
  try {
    // const filteredBookTypeDetails = incomingDetails.filter((list) => list.filetypeid == '1')
    // const srcFileDetails1 = await getSrcFileDetails1(woId, wfDefId);
    // if ((srcFileDetails1.length === 0 && instanceType == 'Multiple') || (instanceType == 'Single')) {
    if (instanceType == 'Multiple' || instanceType == 'Single') {
      const srcFileDetails = await getSrcFileDetails(
        woId,
        srcWfDefId,
        instanceType,
      );
      if (srcFileDetails && srcFileDetails.length > 0) {
        const src = !!(
          srcFileDetails[0].instancetype == 'Multiple' &&
          srcFileDetails[0].activitytype == 'External Task'
        );
        if (src == false) {
          const sourceBasePath = await getFolderStructure({
            type: 'wo_activity_iteration',
            du: { name: duname, id: duid },
            customer: { name: customername, id: customerid },
            workOrderId: woId,
            service: { name: servicename, id: serviceid },
            stage: {
              name: srcFileDetails[0].stagename,
              id: srcFileDetails[0].stageid,
              iteration: srcFileDetails[0].stageiterationcount,
            },
            activity: {
              name: srcFileDetails[0].activityname,
              id: srcFileDetails[0].activityid,
              iteration: srcFileDetails[0].activityiterationcount,
            },
          });
          const sourceBasePathWithoutItration = [
            ...[...sourceBasePath]
              .reverse()
              .join('')
              .replace(`/${srcFileDetails[0].activityiterationcount}/`, ''),
          ]
            .reverse()
            .join('');
          const CheckPaths = [];
          for (
            let index = srcFileDetails[0].activityiterationcount;
            index > 0;
            index--
          ) {
            CheckPaths.push(
              `${sourceBasePathWithoutItration}/${index}/book_${1}/page_target/`,
            );
          }
          res.send(CheckPaths);
        } else if (src == true) {
          copyPageTargetForServiceTask(req, res);
        } else {
          res.send([]);
        }
      } else {
        res.send([]);
      }
    }
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const copyPageTargetForServiceTask = async (req, res) => {
  // const out = [];
  const {
    woId,
    // wfDefId,
    // wfEventId,
    srcWfDefId,
    // basePath,
    duname,
    duid,
    customername,
    customerid,
    servicename,
    serviceid,
    // incomingDetails,
    instanceType,
  } = req.body;
  try {
    // const filteredBookTypeDetails = incomingDetails.filter((list) => list.filetypeid == '1')
    // const srcFileDetails1 = await getSrcFileDetails1(woId, wfDefId);
    // if ((srcFileDetails1.length === 0 && instanceType == 'Multiple') || (instanceType == 'Single')) {
    if (instanceType == 'Multiple' || instanceType == 'Single') {
      const srcFileDetails = await getSrcFileDetailsForServiceTask(
        woId,
        srcWfDefId,
        instanceType,
      );
      const CheckPaths = [];
      if (srcFileDetails && srcFileDetails.length > 0) {
        for (let h = 0; h < srcFileDetails.length; h++) {
          const src = srcFileDetails[h];
          const sourceBasePath = await getFolderStructure({
            type: 'wo_activity_iteration',
            du: { name: duname, id: duid },
            customer: { name: customername, id: customerid },
            workOrderId: woId,
            service: { name: servicename, id: serviceid },
            stage: {
              name: src.stagename,
              id: src.stageid,
              iteration: src.stageiterationcount,
            },
            activity: {
              name: src.activityname,
              id: src.activityid,
              iteration: src.activityiterationcount,
            },
          });
          const sourceBasePathWithoutItration = [
            ...[...sourceBasePath]
              .reverse()
              .join('')
              .replace(`/${src.activityiterationcount}/`, ''),
          ]
            .reverse()
            .join('');
          for (let index = src.activityiterationcount; index > 0; index--) {
            CheckPaths.push(
              `${sourceBasePathWithoutItration}/${index}/book_${1}/page_target/`,
            );
          }
        }

        res.send(CheckPaths);
      } else {
        res.send([]);
      }
    } else {
      res.send([]);
    }
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const internalShippingFile = async (req, res) => {
  const out = [];
  const {
    woId,
    // wfDefId,
    // wfEventId,
    srcWfDefId,
    basePath,
    // duname,
    // duid,
    // customername,
    // customerid,
    // servicename,
    // serviceid,
    instanceType,
    srcFileExt,
    dmsType,
  } = req.body;
  try {
    const srcFileDetails = await getSrcInternalFile(
      woId,
      srcWfDefId,
      srcFileExt,
      instanceType,
    );
    if (srcFileDetails && srcFileDetails.length > 0) {
      // const sourceBasePath = await getFolderStructure({
      //   type: 'wo_activity_iteration',
      //   du: { name: duname, id: duid },
      //   customer: { name: customername, id: customerid },
      //   workOrderId: woId,
      //   service: { name: servicename, id: serviceid },
      //   stage: {
      //     name: srcFileDetails[0].stagename,
      //     id: srcFileDetails[0].stageid,
      //     iteration: srcFileDetails[0].stageiterationcount,
      //   },
      //   activity: {
      //     name: srcFileDetails[0].activityname,
      //     id: srcFileDetails[0].activityid,
      //     iteration: srcFileDetails[0].activityiterationcount,
      //   },
      // });
      const fileToPush = [];
      srcFileDetails.forEach(list => {
        if (
          fileToPush.filter(
            sublist =>
              basename(sublist.repofilepath) == basename(list.repofilepath),
          ).length == 0
        ) {
          fileToPush.push(list);
        }
      });
      console.log(fileToPush, 'fileToPush');
      for (let i = 0; i < srcFileDetails.length; i++) {
        const name = basename(srcFileDetails[i].repofilepath);
        let srcRepoFileId = '';
        let destUuid = '';
        switch (dmsType) {
          case 'azure':
            srcRepoFileId = 'azure';
            destUuid = 'azure';

            break;
          default:
            srcRepoFileId = await _getUuid(srcFileDetails[i].repofilepath);
            destUuid = await _createFolder(basePath);
            break;
        }
        out.push({
          src: srcRepoFileId,
          srcPath: srcFileDetails[i].repofilepath,
          dest: destUuid,
          destBasePath: basePath,
          name,
        });
      }
      res.send(out);
    } else {
      res.send([]);
    }
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

//
export const taskHistoryDelete = async (req, res) => {
  const { wfEventId } = req.body;
  try {
    let sql = `DELETE FROM wms_task_report_view WHERE wfeventid =${wfEventId}`;

    let response = await query(sql);
    sql = `DELETE FROM wms_backup_files WHERE wfeventid =${wfEventId}`;

    response = await query(sql);
    sql = `DELETE FROM wms_tools_api_audit WHERE wfeventid =${wfEventId}`;

    response = await query(sql);
    sql = `DELETE FROM wms_tools_api WHERE wfeventid =${wfEventId}`;

    response = await query(sql);
    sql = `DELETE FROM wms_workflowactivitytrn_file_map WHERE wfeventid =${wfEventId}`;

    response = await query(sql);
    sql = `DELETE FROM wms_workflow_eventlog_details WHERE wfeventid =${wfEventId}`;

    response = await query(sql);
    sql = `UPDATE public.wms_workflow_eventlog SET activitystatus='Failed' WHERE wfeventid =${wfEventId}`;

    response = await query(sql);

    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getAllWorkflowConfig = async (req, res) => {
  try {
    const { wfdefid } = req.body;
    const sql = `SELECT wfdefid,wfid,stageid,activityid,formjson,config,
                  fileconfig,toolsconfig,itracksconfig,softwareconfig,financialconfig
                  FROM public.wms_workflowdefinition where wfdefid = $1`;
    const data = await query(sql, [wfdefid]);
    const response = data[0] ? data[0] : {};
    res.status(200).json({ data: response });
  } catch (e) {
    res.status(400).json({ data: {} });
  }
};

export const checkPBTaskaccess = async (req, res) => {
  try {
    const { customerid, duid, wfid, userid } = req.body;
    const sql = `select * from  public.mst_user_access where customerid = ${customerid} and duid =${duid} and wfid =${wfid} and operation ='ProblemTask' and userid = '${userid}' and isactive = true`;
    const data = await query(sql);
    const response = data[0] ? data[0] : {};
    res.status(200).json({ data: response });
  } catch (e) {
    res.status(400).json({ data: {} });
  }
};
