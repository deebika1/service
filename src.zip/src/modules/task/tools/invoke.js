/* eslint-disable */

import { Service } from '../../../httpClient/index.js';
import {
  _createAPIRequestId,
  _updateAPIRequestId,
  _buildApiConfig,
  _completeAPIRequestId,
  _updatePitstopProfile,
} from '../../utils/tools/api.js';
import { getFileTrnDetails } from '../../utils/tools/utils.js';
import { getFilesData, getFileTrnData } from '../../utils/tools/io.js';
import {
  formattedApiConfig,
  isNullorUndefined,
  formattedProfileConfig,
} from '../../utils/tools/index.js';
import { getFileInfoDetails } from '../fileDetails.js';
import { updateFileTRNLog } from './index.js';
import { startPolling } from './ack.js';
import { query } from '../../../database/postgres.js';
import { getdmsType } from '../../bpmn/listener/create.js';
import { _getIncomingFileType } from '../../utils/fileValidation/index.js';
import {
  getNewCopyBasePath,
  replacePlaceholders,
  _getFormattedGraphicPath,
} from '../../custom-uri/utils.js';
import { tools } from '../../../constants.js';
import { sendToFTPOUTQueue } from '../../../mq/index.js';
import {
  introMailPreSendCheck,
  sendS50IntroMail,
} from '../../../customers/springerBooks/controller/index.js';

const service = new Service();

export const invokeTools = async (req, res) => {
  const {
    workorderDetails,
    toolId,
    wfeventId,
    config,
    apiConfig,
    isAsync,
    placeHolders,
    userId,
    workorderId,
    jobId,
    stageName,
    activityName,
    toolsCustom,
    sId,
    customerId,
    customerName,
    woIncomingFileId,
    tooloutputid,
    iAuthor,
    newFileType,
    dmsType,
    isUICall,
    onSave,
    activityId,
    wfDefid,
    actualActivityCount,
    instanceType,
    pdfMerging,
    JournalAcronym,
    isOtherArticle,
    volumenumber,
    issuenumber,
    issuemstid,
    activitymodeltypeflow,
    isToolArray,
    articleOrderSequence,
    iscamundaflow,
    duId,
    isCorrection,
  } = req.body;
  let apiId;
  let onsave;
  let filteredOtherArticleId = [];
  try {
    apiId = await _createAPIRequestId({
      wfeventId,
      toolsId: toolId,
      isForegroundService: true,
      userId,
      actualActivityCount,
    });
    let filteredFiles = [];
    let files = '';
    let incomingDetails = [];
    let updatedApiConfig = {};
    if (!iscamundaflow) {
      incomingDetails = placeHolders.ArticleTypeList;
      let fileType = config.files.filter(a => a.name.includes('filename'));
      if (activitymodeltypeflow == 'Batch' && fileType?.length > 0) {
        let filesArray = [];
        const fileTypesInArray1 = new Set(
          config.files.flatMap(item => item.fileTypes),
        );
        const matchingFileTypes = placeHolders.ArticleTypeList.filter(item =>
          fileTypesInArray1.has(parseInt(item.FileTypeId)),
        );
        matchingFileTypes.forEach(newItem => {
          config.files.forEach(baseItem => {
            const newName = baseItem.name.replace(
              ';filename;',
              newItem.FileTypeName,
            );
            const newObject = {
              ...baseItem,
              name: newName, // Set the new name
              fileId: newItem.woincomingid,
            };
            filesArray.push(newObject);
          });
        });
        config.files = filesArray;
      } else {
        config.files.filter(async a => {
          a.name = await replacePlaceholders(a.name, placeHolders);
        });
      }

      placeHolders.stagecode = workorderDetails.stage?.name.replace(' ', '_');
      placeHolders.activitycode = workorderDetails.activity?.name.replace(
        ' ',
        '_',
      );

      ///////////////////

      files = {
        in: [],
        out: [],
      };
      const activityBasePath = await getNewCopyBasePath(placeHolders);
      let inFiles = config.files.filter(
        file =>
          (file.fileFlowType || []).filter(x => x.toLocaleLowerCase() === 'in')
            .length > 0,
      );
      let outFiles = config.files.filter(
        file =>
          (file.fileFlowType || []).filter(x => x.toLocaleLowerCase() === 'out')
            .length > 0,
      );

      for (const list of inFiles) {
        const name = await replacePlaceholders(list.name, placeHolders);
        let updateProfile = '';
        if (list.pitstopPath && list.pitstopPath != null) {
          updateProfile = await replacePlaceholders(
            list.pitstopPath,
            placeHolders,
          );
        }
        // const updateProfile = await replacePlaceholders(list.pitstopPath, placeHolders);

        if (!list?.isServerPath) {
          if (list?.isArray) {
            const multipleInFiles = [
              {
                actualPath: activityBasePath,
                aliasKey: list.aliasKey,
                path: `${activityBasePath}tool/${toolId}/In/${name}`,
                fileId: list.fileId,
                fileName: name,
                fileType: 'Chapter',
                pitstopPath: updateProfile || '',
              },
            ];
            files.in.push(multipleInFiles);
          } else {
            files.in.push({
              actualPath: activityBasePath,
              aliasKey: list.aliasKey,
              path: `${activityBasePath}tool/${toolId}/In/${name}`,
              fileId: list.fileId,
              fileName: name,
              fileType: 'Chapter',
              pitstopPath: updateProfile || '',
            });
          }
        } else {
          const data = {
            duid: workorderDetails.du.id,
            customerid: customerId,
            isServerPath: '',
          };
          const graphicPath = await _getFormattedGraphicPath(
            data,
            placeHolders,
            'genaral',
          );
          files.in.push({
            actualPath: graphicPath,
            aliasKey: list.aliasKey,
            path: graphicPath,
            fileId: woIncomingFileId,
            fileName: name,
            fileType: 'Chapter',
          });
        }
      }

      for (const list of outFiles) {
        const name = await replacePlaceholders(list.name, placeHolders);
        if (list?.isArray) {
          const multipleOutFiles = [
            {
              actualPath: activityBasePath,
              aliasKey: list.aliasKey,
              path: `${activityBasePath}tool/${toolId}/Out/${name}`,
              fileId: woIncomingFileId,
              fileName: name,
              fileType: 'Chapter',
            },
          ];

          files.out.push(multipleOutFiles);
        } else {
          files.out.push({
            actualPath: activityBasePath,
            aliasKey: list.aliasKey,
            path: `${activityBasePath}tool/${toolId}/Out/${name}`,
            fileId: woIncomingFileId,
            fileName: name,
            fileType: 'Chapter',
          });
        }
      }
    } else {
      // with camunda
      let incomingDetails1 = [];
      incomingDetails = await _getIncomingFileType(workorderId);
      console.log(incomingDetails, 'incomingDetailsh');
      incomingDetails = incomingDetails.filter(
        list => list.articletype == 'Article',
      );
      incomingDetails1 = incomingDetails.filter(
        list =>
          list.woincomingfileid == woIncomingFileId && list.filetypeid == 4,
      );
      if (isOtherArticle) {
        let incomingDetails = await _getIncomingFileType(workorderId);
        console.log(incomingDetails, 'incomingDetailsh');
        incomingDetails = incomingDetails.filter(
          list => list.articletype == 'Other Article',
        );
        filteredOtherArticleId = incomingDetails.map(list =>
          parseInt(list.filetypeid),
        );
        incomingDetails1 = incomingDetails.filter(
          list =>
            list.articletype == 'Other Article' &&
            list.woincomingfileid == woIncomingFileId,
        );

        filteredOtherArticleId = new Set(filteredOtherArticleId);
      }
      const data = config.files;
      for (let j = 0; j < data.length; j++) {
        const file = data[j];
        let { fileTypes } = file;
        if (fileTypes.includes(83)) {
          fileTypes = [...fileTypes, ...filteredOtherArticleId];
          file.fileTypes = fileTypes;
        }
      }

      incomingDetails = incomingDetails.map(list => list.woincomingfileid);

      if (iscamundaflow) {
        files = await getIOData(
          config,
          workorderDetails,
          wfeventId,
          placeHolders,
          isOtherArticle,
          issuemstid,
          activitymodeltypeflow,
          wfDefid,
          isToolArray,
          articleOrderSequence,
        );
        // skip toc file for article and other article types
        if (
          incomingDetails1.length > 0 &&
          config.toolsCustom &&
          Object.keys(config.toolsCustom).length > 0 &&
          Object.keys(config.toolsCustom).includes('skipFileType') &&
          config.toolsCustom.skipFileType
        ) {
          filteredFiles = {
            in: files.in.filter(
              item => item.fileType !== config.toolsCustom.skipFileType,
            ),
            out: files.out.filter(
              item => item.fileType !== config.toolsCustom.skipFileType,
            ),
          };
          files = filteredFiles;
        }
        if (customerId == '12' && placeHolders?.duid == '11') {
          const excludeByKeyword = keyword => ({
            in: files.in.filter(item => !item?.path?.includes(keyword)),
            out: files.out.filter(item => !item?.path?.includes(keyword)),
          });

          if (placeHolders?.MyCopyValue?.toLowerCase() === 'no') {
            files = excludeByKeyword('_MyCopy');
          }

          if (placeHolders?.Book2Value?.toLowerCase() === 'no') {
            files = excludeByKeyword('_Book2');
          }
        }
        if (isUICall === true) {
          Object.keys(files.in).forEach(ele => {
            if (Array.isArray(files.in[ele])) {
              files.in[ele].forEach(el => {
                el.path = el.path.replace(
                  el.actualPath,
                  `${el.actualPath}tool/${toolId}/In/`,
                );
              });
            } else {
              files.in[ele].path = files.in[ele].path.replace(
                files.in[ele].actualPath,
                `${files.in[ele].actualPath}tool/${toolId}/In/`,
              );
            }
          });
          Object.keys(files.out).forEach(ele => {
            if (Array.isArray(files.out[ele])) {
              files.out[ele].forEach(el => {
                el.path = el.path.replace(
                  el.actualPath,
                  `${el.actualPath}tool/${toolId}/Out/`,
                );
              });
            } else {
              files.out[ele].path = files.out[ele].path.replace(
                files.out[ele].actualPath,
                `${files.out[ele].actualPath}tool/${toolId}/Out/`,
              );
            }
          });
        }
      } else {
      }
    }

    // additionalinfo sending in tools
    let additionalInfo = {};

    const toolsPlaceHolder = config.placeHolder ? config.placeHolder : {};
    const combinedPlaceHolders = { ...placeHolders, ...toolsPlaceHolder };

    if (!iscamundaflow) {
      additionalInfo = config?.params || [];
    } else {
      // need to be removed after without camunda moved
      const sql = `select ((a.toolsconfig ::jsonb ->> 'tools') ::jsonb ->> '${toolId}')::jsonb ->> 'params' as additionalinfo
      from wms_workflowdefinition a join public.wms_workflow_eventlog b on a.wfdefid=b.wfdefid
      where a.activityid=${workorderDetails.activity.id}
      and a.stageid=${workorderDetails.stage.id} and b.wfeventid=${wfeventId}`;
      additionalInfo = await query(sql);
      if (additionalInfo.length > 0) {
        additionalInfo =
          additionalInfo[0].additionalinfo == null ||
          additionalInfo[0].additionalinfo == ''
            ? {}
            : JSON.parse(additionalInfo[0].additionalinfo);
        if (
          Object.prototype.toString.call(additionalInfo[0]) == '[object Object]'
        ) {
          const updatedprofileConfig = formattedProfileConfig(
            additionalInfo[0],
            combinedPlaceHolders,
          );
        }
      }
    }

    updatedApiConfig = formattedApiConfig(apiConfig, combinedPlaceHolders);

    const iwms = {
      additionalInfo,
      id: apiId,
      env: process.env.MODE_VAL,
      userId,
      woId: workorderId,
      wfEventId: wfeventId,
      woName: jobId,
      stage: stageName,
      stageId: workorderDetails.stage.id,
      activity: activityName,
      serviceId: workorderDetails.service.id,
      stageIteration: workorderDetails.activity.iteration,
      toolsCustom: toolsCustom || {},
      sId,
      custId: customerId,
      custName: customerName,
      tooloutputid,
      woIncomingFileId:
        woIncomingFileId != null && woIncomingFileId.length > 0
          ? woIncomingFileId
          : incomingDetails,
      iAuthor: iAuthor || null,
      newFileType: newFileType || null,
      dmsType: dmsType || null,
      isUICall,
      onSave,
      activityId,
      wfDefid,
      actualActivityCount,
      instanceType,
      pdfMerging,
      JournalAcronym,
      isIssue: !!stageName.toLowerCase().includes('issue'),
      volumeNumber: volumenumber,
      issueNumber: issuenumber,
      iscamundaflow,
      duId,
      isCorrection: isCorrection || '',
    };
    const inputParams = await _buildApiConfig(iwms, files, updatedApiConfig);
    await _updateAPIRequestId({ apiId, inputParams });
    try {
      if (tools.introMail.id === toolId) {
        await introMailPreSendCheck(inputParams);
      }
      let toolsResponse = await service.invokeService(inputParams);
      if ([tools.eProofStopSignal.id].includes(toolId)) {
        await sendToFTPOUTQueue(toolsResponse?.data?.payload);
      } else if (tools.introMail.id === toolId) {
        toolsResponse = await sendS50IntroMail(toolsResponse?.data?.payload);
      }
      const pitstopPath = toolsResponse?.data?.pitstopPath;
      if (pitstopPath) {
        await _updatePitstopProfile({ apiId, pitstopPath });
      }
      // if (
      //   onSave == true &&
      //   Object.keys(toolsResponse.data).length > 0 &&
      //   Object.keys(toolsResponse.data.data).length > 0 &&
      //   toolsResponse.data.is_success == false &&
      //   toolsResponse.data.data.onSave == false
      // ) {
      //   res.status(200).json(toolsResponse);
      //
      // } else {

      if (!isAsync) {
        await processResponse(
          config,
          workorderDetails,
          wfeventId,
          placeHolders,
        );
        const remarks =
          !isNullorUndefined(toolsResponse.data.data) &&
          (Object.prototype.toString.call(toolsResponse.data.data) ==
            '[object String]' ||
            Object.prototype.toString.call(toolsResponse.data.data) ==
              '[object Boolean]')
            ? toolsResponse.data.data
            : !isNullorUndefined(toolsResponse.data.message) &&
              (Object.prototype.toString.call(toolsResponse.data.message) ==
                '[object String]' ||
                Object.prototype.toString.call(toolsResponse.data.message) ==
                  '[object Boolean]')
            ? toolsResponse.data.message
            : toolsResponse.data.data ||
              toolsResponse.data.message ||
              'Remarks missing';
        _completeAPIRequestId({
          apiId,
          onSave,
          status: 'Success',
          remarks: remarks.toString(),
          response: toolsResponse.data || {},
          sId,
          tooloutputid,
          isFileAvailable: true,
          actualActivityCount,
        });
      }
      if (isAsync && toolsCustom.validate) {
        console.log('START  POLLING');
        onsave = await startPolling(apiId, wfeventId, files, 200);
        console.log(onsave);
        if (onsave === false) throw new Error('On save validation failed');
      }
      // res.status(200).json(toolsResponse);
      if (onsave === true) {
        res
          .status(200)
          .json({ message: 'On Save Validation Completed', toolsResponse });
      } else {
        res.status(200).json(toolsResponse);
      }
      // }
    } catch (err) {
      const errorMsg =
        err?.message?.data?.data &&
        (Object.prototype.toString.call(err.message.data.data) ==
          '[object String]' ||
          Object.prototype.toString.call(err.message.data.data) ==
            '[object Boolean]')
          ? err.message.data.data
          : err?.message?.data?.message &&
            (Object.prototype.toString.call(err.message.data.message) ==
              '[object String]' ||
              Object.prototype.toString.call(err.message.data.message) ==
                '[object Boolean]')
          ? err.message.data.message
          : err?.message?.data?.data ||
            err?.message?.data?.message ||
            err.message ||
            err;

      _completeAPIRequestId({
        apiId,
        onSave,
        status: 'Failure',
        remarks: errorMsg.toString(),
        response: err?.message?.data || {},
        sId,
        tooloutputid,
        isFileAvailable: false,
        actualActivityCount,
      });
      res.status(400).send({ message: errorMsg });
    }
  } catch (err) {
    const errorMsg = err.message ? err.message : err;

    if (apiId)
      _completeAPIRequestId({
        apiId,
        status: 'Failure',
        remarks: errorMsg.toString(),
        response: {},
        sId,
        tooloutputid,
        isFileAvailable: false,
        actualActivityCount,
      });
    res.status(400).send({ message: errorMsg });
  }
};

const getIOData = async (
  config,
  workorderDetails,
  wfeventId,
  placeHolders,
  isOtherArticle,
  issuemstid,
  activitymodeltypeflow,
  wfDefid,
  isToolArray,
  articleOrderSequence,
) => {
  const fileConfig = config.files ? config.files : {};
  const {
    stage,
    activity,
    service: ser,
    du,
    customer,
    workOrderId,
  } = workorderDetails;
  const fileDetails = await getFileInfoDetails({
    wfEventId: wfeventId,
    workOrderId,
    du,
    customer,
    service: ser,
    stage,
    activity,
    typesId: [],
    activitymodeltypeflow,
    issuemstid,
    wfDefId: wfDefid,
    fileTypeId: '',
    isOtherArticle,
    articleOrderSequence,
  });
  let input;
  const batchInArray = [];
  if (
    activitymodeltypeflow &&
    activitymodeltypeflow == 'Batch' &&
    isToolArray
  ) {
    for (let i = 0; i < fileDetails.length; i++) {
      workorderDetails.fileId = fileDetails[i].incomingFileId;
      workorderDetails.workOrderId = fileDetails[i].files[0].workorderid;
      batchInArray.push(
        await getFilesData({
          workorderDetails,
          IOFiles:
            fileConfig?.filter(x => (x.fileFlowType || []).includes('IN')) ||
            [],
          fileDetails,
          placeHolders,
          isOtherArticle,
        }),
      );
    }
  } else {
    input = await getFilesData({
      workorderDetails,
      IOFiles:
        fileConfig?.filter(x => (x.fileFlowType || []).includes('IN')) || [],
      fileDetails,
      placeHolders,
      isOtherArticle,
    });
  }
  if (
    activitymodeltypeflow &&
    activitymodeltypeflow == 'Batch' &&
    isToolArray
  ) {
    input = batchInArray.map(arr => arr[0]);
    let uniqueFilenames = {};
    input.forEach(obj => {
      let filename = obj.filename;
      if (!uniqueFilenames.hasOwnProperty(filename)) {
        uniqueFilenames[filename] = obj;
      }
    });
    // input = Object.values(uniqueFilenames);
  }
  const output = await getFilesData({
    workorderDetails,
    IOFiles:
      fileConfig?.filter(x => (x.fileFlowType || []).includes('OUT')) || [],
    fileDetails,
    placeHolders,
    isOtherArticle,
  });
  return {
    in: Object.keys(input).map(key => input?.[key]),
    out: Object.keys(output).map(key => output?.[key]),
  };
};

const processResponse = async (
  config,
  workorderDetails,
  wfeventId,
  placeHolders,
) => {
  const fileConfig = config.files ? config.files : {};
  const dmsType = await getdmsType(workorderDetails.workOrderId);
  const {
    stage,
    activity,
    service: ser,
    du,
    customer,
    workOrderId,
  } = workorderDetails;
  const fileDetails = await getFileInfoDetails({
    wfEventId: wfeventId,
    workOrderId,
    du,
    customer,
    service: ser,
    stage,
    activity,
    typesId: [],
    activitymodeltypeflow: '',
    issuemstid: '',
    wfDefId: '',
    fileTypeId: '',
    isOtherArticle: false,
    articleOrderSequence: null,
  });
  const files = await getFilesData({
    workorderDetails,
    IOFiles: fileConfig.output,
    fileDetails,
    placeHolders,
    isInputProcessing: false,
    isOtherArticle: false,
  });
  const fileTrnDetails = await getFileTrnDetails(wfeventId);
  const fileTrnData = await getFileTrnData(files, fileTrnDetails, dmsType);
  if (fileTrnData.length) await updateFileTRNLog(fileTrnData, wfeventId);
};
