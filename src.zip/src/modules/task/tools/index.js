/* eslint-disable no-throw-literal */
import { fileURLToPath } from 'url';
import { join, parse } from 'path';
import fs from 'fs';
import ExcelJS from 'exceljs';
import moment from 'moment';
import { query, transaction } from '../../../database/postgres.js';
import { getBasicToolsData } from '../../utils/tools/index.js';
import { _upload } from '../../utils/azure/index.js';
import { invokeFileUploadToFTP } from '../../filetransferkit/index.js';
import { makeDir, removeFolder } from '../../utils/custom/io.js';
import { mailTriggerForPM } from '../../woi/index.js';
import { mailTriggerForKLI } from '../action/workflow/save.js';
import logger from '../../utils/logs/index.js';
import { validateExcel } from '../../../customers/springerBooks/helpers/validation.js';
import {
  ElsUpdateRevisedData,
  ElsUpdStageAutoTat,
  ElsInsertUpdPckgReq,
  ElsUpdPckgReqpbTask,
  ElsUpdStageTatAudit,
  ElsUpdStageTat,
} from '../../woi/elsevierhelper.js';
import { _sendCampusSignal } from '../../woi/woAutocreation.js';

const __filename = fileURLToPath(import.meta.url);
export const getToolsDetails = async (req, res) => {
  const { wfDefId, toolsId } = req.body;
  try {
    const toolsDetails = [];
    const toolsData = await getBasicToolsData(toolsId);
    const toolsConfig = await getToolsConfig(wfDefId);
    toolsData.sort(function (a, b) {
      return (
        toolsId.indexOf(parseInt(a.toolid)) -
        toolsId.indexOf(parseInt(b.toolid))
      );
    });
    for (let i = 0; i < toolsData.length; i++) {
      if (toolsData[i].toolstatus) {
        const id = parseInt(toolsData[i].toolid);
        const config =
          toolsConfig.tools && toolsConfig.tools[id]
            ? toolsConfig.tools[id]
            : {};
        const name = config.aliasName
          ? config.aliasName
          : toolsData[i].toolname;
        const type = parseInt(toolsData[i].tooltypeid);
        const syncFiles = !(config.isSync == false);
        const apiConfig = toolsData[i].apiconfig ? toolsData[i].apiconfig : {};
        const isAsync = !!toolsData[i].isasync;
        const tooloutputid = parseInt(toolsData[i].tooloutputid);
        toolsDetails.push({
          id,
          name,
          config,
          apiConfig,
          isAsync,
          syncFiles,
          type,
          tooloutputid,
        });
      }
    }
    res.status(200).json(toolsDetails);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const onsaveGetToolsDetails = async (req, res) => {
  const { wfDefId, toolsId } = req.body;
  try {
    const toolsDetails = [];
    const toolsData = await getBasicToolsData(toolsId);
    const toolsConfig = await getToolsConfig(wfDefId);
    toolsData.sort(function (a, b) {
      return (
        toolsId.indexOf(parseInt(a.toolid)) -
        toolsId.indexOf(parseInt(b.toolid))
      );
    });
    for (let i = 0; i < toolsData.length; i++) {
      const id = parseInt(toolsData[i].toolid);
      const config =
        toolsConfig.tools && toolsConfig.tools[id] ? toolsConfig.tools[id] : {};
      const name = config.aliasName ? config.aliasName : toolsData[i].toolname;
      const type = parseInt(toolsData[i].tooltypeid);
      const syncFiles = !(config.isSync == false);
      const apiConfig = toolsData[i].apiconfig ? toolsData[i].apiconfig : {};
      const isAsync = !!toolsData[i].isasync;
      const tooloutputid = parseInt(toolsData[i].tooloutputid);
      const toolvalidation = toolsData[i].toolvalidation || '';
      toolsDetails.push({
        id,
        name,
        config,
        apiConfig,
        isAsync,
        syncFiles,
        type,
        tooloutputid,
        toolvalidation,
      });
    }
    res.status(200).json(toolsDetails);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

const getToolsConfig = async wfDefId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT toolsconfig FROM public.wms_workflowdefinition where wfdefid = $1`;
      const data = await query(sql, [wfDefId]);
      const config = data[0].toolsconfig ? data[0].toolsconfig : {};
      resolve(config);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const updateFileTRNLog = (fileTrnData, wfeventId) => {
  return new Promise((resolve, reject) => {
    const values = [];
    fileTrnData.forEach(fileTrn => {
      const { path, uuid, fileId } = fileTrn;
      values.push(
        `(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`,
      );
    });
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES ${values};`;
    query(sql)
      .then(() => {
        resolve();
      })
      .catch(e => {
        logger.info(
          'ackForegroundTask updateFileTRNLog',
          e?.message ? e?.message : e,
        );
        reject(e);
      });
  });
};

export const getToolsRunningStatus = async (req, res) => {
  const { wfeventId } = req.body;
  const sql = `select * from (select row_number() over(Partition by toolid order by apiid desc ) as rno,toolid,apiid,status from public.wms_tools_api 
        where wfeventid=${wfeventId}) results where rno =1 and status in ('InProgress')`;

  const response = await query(sql);
  if (response.length) {
    res.status(200).send({ message: false });
  } else {
    const sqlQuery = `UPDATE public.wms_tools_api SET status = 'Failure', remarks = 'Latest Output has been generated for that tool'
                WHERE wfeventid = ${wfeventId} and status='InProgress'`;
    await query(sqlQuery);
    res.status(200).send({ message: true });
  }
};

export const getxmlValidationFrNewsLetter = async (req, res) => {
  try {
    const { woid } = req.body;
    const sql = `SELECT b.newsletter
    FROM wms_workorder a
    JOIN pp_mst_journal b ON b.journalid = a.journalid
    WHERE a.workorderid = ${woid}`;

    const data = await query(sql);
    res.status(200).json({
      data,
      status: true,
    });
  } catch (error) {
    console.error('Error writing file:', error);
    res.status(500).send({ message: false });
  }
};
export const getFileSequenceSprBooks = async (req, res) => {
  try {
    // const data = req.body;
    const { workorderId } = req.body;
    let result = '';
    if (workorderId) {
      const sql = `select * from wms_book_workorder_details where bookworkorderid = ${workorderId} order by file_sequence`;
      result = await query(sql);
    }
    res.status(200).send({ data: result || [], status: true });
  } catch (error) {
    console.error('Error writing file:', error);
    res.status(500).send({ message: false, status: false });
  }
};
export const updateFileSequenceSprBooks = async (req, res) => {
  try {
    const data = req.body;
    data.map(async row => {
      const sql = `update wms_book_workorder_details SET file_sequence=${row.fid} where filename='${row.filename}'`;
      await query(sql);
    });
    res.status(200).send({ message: true });
  } catch (error) {
    console.error('Error updateFileSequenceSprBooks:', error);
    res.status(500).send({ message: false });
  }
};
export const addFileSequenceSprBooks = async (req, res) => {
  try {
    let { file } = req.body;
    const { woId } = req.body;
    let sql = `select 1 from wms_book_workorder_details wbwd where bookworkorderid= ${woId}`;
    const isExists = await query(sql);
    if (isExists.length) {
      sql = `DELETE FROM wms_book_workorder_details  WHERE bookworkorderid = ${woId}`;
      await query(sql);
    }
    const regex = new RegExp(`[${'~$'}]`);
    file = file.filter(item => !regex.test(item));

    for (let i = 0; file.length > i; i++) {
      sql = `INSERT INTO wms_book_workorder_details (bookworkorderid, isactive,filename,file_sequence) VALUES (${woId},true, '${
        file[i]
      }',${i + 1})`;
      await query(sql);
    }
    // });
    res.status(200).send({ message: true });
  } catch (error) {
    console.error('Error updateFileSequenceSprBooks:', error);
    res.status(500).send({ message: false });
  }
};
export const skipSuccessTool = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { toolId, activityIteration, wfeventId, workOrderId } = req.body;
      const sql = `select count(1) from wms_tools_api_list where  toolid  = ${toolId}  and workorderid =${workOrderId} and actualactivitycount = ${activityIteration} and wfeventid = ${wfeventId} AND status = 'Success'`;
      await query(sql)
        .then(async data => {
          res.status(200).json({
            status: data[0].count == 0,
          });
        })
        .catch(err => {
          res.status(400).send({
            data: [],
            status: false,
            message: `The completed tool's log checking function failed with ${
              err?.message ? err.message : err
            }`,
          });
        });
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const notesToACS = async (req, res) => {
  try {
    const jsonobj = req.body;
    if (jsonobj.note === undefined || jsonobj.note === 'undefined') {
      jsonobj.note = '';
    }
    if (jsonobj.statusValue == 'toget') {
      const sql = `select Note from NotesTOACSlog
  where workorderId=${jsonobj.workorderId} and stageId = ${jsonobj.stageId} order by createddate desc`;

      await query(sql)
        .then(async data => {
          res.status(200).json({
            data,
            status: true,
          });
        })
        .catch(() => {
          res.status(400).send({
            data: [],
            status: false,
            message: 'ACS notes failure',
          });
        });
    } else if (jsonobj.statusValue == 'toinclude') {
      const sql = `select Note from NotesTOACSlog
  where workorderId=${jsonobj.workorderId} and activityId=${jsonobj.activityId} and activityiterationcount= ${jsonobj.actualActivityCount} and stageId = ${jsonobj.stageId} and stageIterationCount = ${jsonobj.stageIterationCount}`;

      const response = await query(sql);
      if (response.length > 0) {
        const sqlQuery = `UPDATE NotesTOACSlog SET note = '${jsonobj.note}', createdby = '${jsonobj.userId}', createddate = current_timestamp, activityiterationcount = '${jsonobj.actualActivityCount}'
                WHERE workorderId = ${jsonobj.workorderId} and activityId= ${jsonobj.activityId} and activityiterationcount= ${jsonobj.actualActivityCount} and stageId = ${jsonobj.stageId} and stageIterationCount = ${jsonobj.stageIterationCount}`;
        await query(sqlQuery);

        res.status(200).send({ message: true });
      } else {
        const sqlQuery = `insert into public.NotesTOACSlog(workorderId,stageId,activityId,stageIterationCount,customerId,note, activityiterationcount, createdby, wfeventid)
     values(${jsonobj.workorderId},${jsonobj.stageId},${jsonobj.activityId},${jsonobj.stageIterationCount}, '${jsonobj.customerId}' ,'${jsonobj.note}', ${jsonobj.actualActivityCount}, '${jsonobj.userId}', ${jsonobj.wfeventId} )`;
        await query(sqlQuery);
        res.status(200).send({ message: true });
      }
    }
  } catch (error) {
    console.error('Error writing file:', error);
    res.status(500).send({ message: false });
  }
};
export const DNPACS = async (req, res) => {
  try {
    const jsonobj = req.body;

    if (jsonobj.statusValue == 'toget') {
      const sql = `WITH dnp AS (
    SELECT unnest(t.donotpublish) AS filename, true AS checked
   from (
    select donotpublish FROM acs_donotpublish_details
    WHERE workorderid = ${jsonobj.workorderId} and stageId = ${jsonobj.stageId}
    ORDER BY updated_time DESC
    LIMIT 1) as t
),
master AS (
    SELECT DISTINCT regexp_replace(repofilepath, '.*/', '') AS filename
    FROM wms_workflowactivitytrn_file_map wwfm
    JOIN wms_workflow_eventlog e ON wwfm.wfeventid = e.wfeventid
    WHERE e.workorderid = ${jsonobj.workorderId} 
    AND (
        regexp_replace(repofilepath, '.*/', '') ~ '_si_'
        OR regexp_replace(repofilepath, '.*/', '') ~ '_weo_'
    )
)
SELECT
    master.filename AS label,
    CASE
        WHEN master.filename = ANY (ARRAY(SELECT filename FROM dnp)) THEN true
        ELSE false
    END AS checked
FROM master order by  CASE
        WHEN master.filename = ANY (ARRAY(SELECT filename FROM dnp)) THEN true
        ELSE false
    END <> true ,  master.filename;`;

      await query(sql)
        .then(async data => {
          res.status(200).json({
            data,
            status: true,
          });
        })
        .catch(() => {
          res.status(400).send({
            data: [],
            status: false,
            message: 'ACS DNP failure',
          });
        });
    } else if (jsonobj.statusValue == 'toinclude') {
      const sql = `select donotpublish from acs_donotpublish_details
  where workorderId=${jsonobj.workorderId}
  and stageId=${jsonobj.stageId}  
  and stageIterationCount=${jsonobj.stageIterationCount}
    and activityId=${jsonobj.activityId} and activityiterationcount= ${jsonobj.actualActivityCount}`;

      const response = await query(sql);
      const v_donotpublish = `{"${jsonobj.selectedCheckboxes.join('","')}"}`;
      if (response.length > 0) {
        const sqlQuery = `
        UPDATE acs_donotpublish_details
        SET donotpublish = '${v_donotpublish}',
            updated_by = '${jsonobj.userid}',
            updated_time = current_timestamp,
            activityiterationcount = ${jsonobj.actualActivityCount},
            created_time = current_timestamp,
            created_by = created_by


       WHERE workorderId = ${jsonobj.workorderId}
         AND stageId = ${jsonobj.stageId}
         AND stageIterationCount = ${jsonobj.stageIterationCount}
        AND activityId = ${jsonobj.activityId} AND activityiterationcount = ${jsonobj.actualActivityCount} AND stageId = ${jsonobj.stageId} AND stageIterationCount = ${jsonobj.stageIterationCount};
        `;
        await query(sqlQuery);

        res.status(200).send({ message: true });
      } else {
        const sqlQuery = `insert into public.acs_donotpublish_details(workorderId,stageId,activityId,stageIterationCount,customerId,donotpublish,
    created_by, updated_time,activityiterationcount, wfeventid)
     values(${jsonobj.workorderId},${jsonobj.stageId},${jsonobj.activityId},${jsonobj.stageIterationCount}, '${jsonobj.customerId}' , '${v_donotpublish}','${jsonobj.userid}', current_timestamp,${jsonobj.actualActivityCount}, ${jsonobj.wfeventId})`;
        await query(sqlQuery);
        res.status(200).send({ message: true });
      }
    }
  } catch (error) {
    console.error('Error writing file:', error);
    res.status(500).send({ message: false });
  }
};

export const fileWriteLocal = async (req, res) => {
  try {
    const jsonobj = req.body;

    const filePath = jsonobj.workingFolder;
    const { errorMessage } = jsonobj;
    try {
      await fs.writeFile(filePath, errorMessage, err => {
        if (err) {
          console.error('Error writing file:', err);
          return;
        }
        console.log('Data written to file successfully.');
      });
      console.log('Data appended to file successfully.');

      const sql2 = `insert into acs_errorhandling_audit(workorderid,stageid,message,islock) values(${jsonobj.workOrderId},${jsonobj.stageId},'${jsonobj.errorMessage}','Y')`;
      await query(sql2);

      res.status(200).send({ message: true });
    } catch (err) {
      console.error('Error appending data to file:', err);
      res.status(200).send({ message: false });
    }
  } catch (error) {
    console.error('Error writing file:', error);
    res.status(500).send({ message: false });
  }
};

// get elsevier stage name
export const getElsevierCustomerStageName = async (req, res) => {
  try {
    const { stageValue } = req.body;

    try {
      const sql = `select customer_stage_name from elsevier_mst_stage where wms_stagename ='${stageValue}'`;

      const responsePB = await query(sql);
      res.status(200).send({ data: responsePB });
    } catch (err) {
      console.error('Error in problem task data:', err);
      res.status(200).send({ message: false });
    }
  } catch (error) {
    console.error('Error getting problem task data:', error);
    res.status(500).send({ message: false });
  }
};

export const addpbData = async (req, res) => {
  try {
    const {
      journalid,
      articleid,
      stage,
      activity,
      signal_description,
      xmldata,
      isactive,
      createdby,
      woid,
      stage_iteration,
      activity_iteration,
      problemgroup,
      zipPath,
      fileList,
    } = req.body;

    try {
      const sql = `select journalid as journalid,articleid as articleid,stage as stage,activity as activity,
      signal_description as signaldescription, xmldata as xmldata from trn_problemtask where isactive = 'true' 
      and articleid ='${articleid}' and stage ='${stage}'  and activity ='${activity}' order by id desc limit 1`;

      const responsePB = await query(sql);
      let sql2 = '';
      let sqlResp = '';
      // if (responsePB.length > 0) {
      //   sql2 = `update public.trn_problemtask set signal_description = '${signal_description}',xmldata = '${xmldata}'
      //   where articleid = '${articleid}' and stage = '${stage}' and activity ='${activity}' and isactive = true`;
      //   sqlResp = await query(sql2);
      // } else {

      if (responsePB.length == 0) {
        let zip_path = null;
        let file_list = null;

        if (fileList?.length > 0) {
          zip_path = zipPath;
          file_list = JSON.stringify(fileList);
        }
        sql2 = `insert into trn_problemtask(journalid,articleid,stage,activity,signal_description,xmldata,isactive,createddate,createdby,woid,stage_iteration,activity_iteration,problemgroup, zip_path, file_list) 
        values('${journalid}','${articleid}','${stage}','${activity}','${signal_description}','${xmldata}','${isactive}',current_timestamp,
        '${createdby}',${woid},${stage_iteration},'${activity_iteration}','${problemgroup}','${zip_path}','${file_list}') RETURNING id`;
        sqlResp = await query(sql2);

        const accessSql = ` SELECT userid FROM mst_user_access where userid = '${createdby}' and isactive = 'true'`;
        const accessResponse = await query(accessSql);
        let remarks = '';
        if (accessResponse.length > 0) {
          remarks = 'Waiting in customer que';
        } else {
          remarks = 'Waiting in Internal que';
        }

        const logSql = `insert into trn_problemtask_log(pb_id,createdby,createddate,status,remarks) 
        values('${sqlResp[0].id}','${createdby}',current_timestamp,'Raised','${remarks}')`;
        const logResp = await query(logSql);
        console.log(logResp);
        res.status(200).send({ message: true });
      } else {
        res.status(200).send({
          message: false,
          respMessage: 'A problem task has already been raised.',
        });
      }
      console.log(sqlResp);
      // await query(sql2);
      // res.status(200).send({ message: true });
    } catch (err) {
      console.error('Error in problem task data:', err);
      res.status(200).send({ message: false });
    }
  } catch (error) {
    console.error('Error getting problem task data:', error);
    res.status(500).send({ message: false });
  }
};

export const getpbData = async (req, res) => {
  try {
    const { articleid, stage, activity } = req.body;

    const sql = `select journalid as journalid,articleid as articleid,stage as stage,activity as activity,
      signal_description as signaldescription, xmldata as xmldata from trn_problemtask where isactive = 'true' 
      and articleid ='${articleid}' and stage ='${stage}'  and activity ='${activity}' order by id desc limit 1`;

    const responsePB = await query(sql);

    res.status(200).send({ data: responsePB });
  } catch (error) {
    console.error('Error getting problem task data:', error);
    res.status(500).send({ message: false });
  }
};

export const fetchguId = async (req, res) => {
  const { workorderId, stageId, stageIterationCount, customerId, activityId } =
    req.body;
  const iAuth = {};
  let iauthorAcctivityId = 0;
  iauthorAcctivityId =
    activityId == '163'
      ? 107
      : activityId == '130'
      ? 35
      : activityId == '137'
      ? 36
      : activityId == '399' && customerId == '10'
      ? 107
      : activityId == '399'
      ? 118
      : 0;
  return new Promise(async (resolve, reject) => {
    try {
      if (customerId == '15') {
        const sql = `SELECT pp.journalid,pp.journalacronym,wo.workorderid,
 wos.wfstageid,tr.duid,tr.customerid,tr.workorderid AS iauthwoid,
 tr.stageid as iauthstageid, tr.guid , wos.stageiterationcount,
 wos.wfstageid,
 CASE WHEN wos.wfstageid=72 THEN c.sequencedetails ELSE f.sequencedetails
 end as sequencedetails  
 FROM wms_workorder wo
 JOIN pp_mst_journal pp on pp.journalid = wo.journalid
 JOIN wms_workorder_stage wos on wos.workorderid = wo.workorderid
 JOIN wms_mst_stage st on st.stageid = wos.wfstageid
 JOIN iauthor_transactions tr on tr.workorderid = wo.workorderid and  tr.stageid = wos.wfstageid
 JOIN iauthor_workflow c on  c.iauthworkflowid = pp.iauthworkconversionflowid   
JOIN iauthor_workflow f on f.iauthworkflowid = pp.iauthworkflowid 
 WHERE wo.workorderid = ${workorderId} AND wfstageid = ${stageId} 
 AND wos.stageiterationcount=${stageIterationCount} `;

        console.log(sql);
        const data = await query(sql);
        console.log(data);
        let errMsg = '';
        if (data.length <= 0) {
          errMsg =
            'This tool execution is not applicable for Revises iterations.';
          res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
        }
        if (Object.keys(data[0].sequencedetails.length > 0)) {
          for (const [key, value] of Object.entries(
            data[0].sequencedetails.activities,
          )) {
            console.log(key);
            if (value.ActivityID == iauthorAcctivityId) {
              iAuth.roleid = value.RoleID;
              iAuth.activityid = value.ActivityID;
            }
          }
        }
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      } else if (customerId == '10') {
        const sql = ` SELECT pp.journalid,pp.journalacronym,wo.workorderid,
 wos.wfstageid,tr.duid,tr.customerid,tr.workorderid AS iauthwoid,
 tr.stageid as iauthstageid, tr.guid , wos.stageiterationcount,
 wos.wfstageid, f.sequencedetails  
 FROM wms_workorder wo
 JOIN pp_mst_journal pp on pp.journalid = wo.journalid
 JOIN wms_workorder_stage wos on wos.workorderid = wo.workorderid
 JOIN wms_mst_stage st on st.stageid = wos.wfstageid
 JOIN iauthor_transactions tr on tr.workorderid = wo.workorderid and  tr.stageid = wos.wfstageid
 JOIN iauthor_workflow f on f.iauthworkflowid = pp.iauthworkflowid 
 WHERE wo.workorderid = ${workorderId} AND wfstageid = ${stageId} 
 AND wos.stageiterationcount=${stageIterationCount}`;

        console.log(sql);
        const data = await query(sql);
        console.log(data);
        let errMsg = '';
        if (data.length <= 0) {
          errMsg =
            'This tool execution is not applicable for Revises iterations.';
          res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
        }
        if (Object.keys(data[0].sequencedetails.length > 0)) {
          for (const [key, value] of Object.entries(
            data[0].sequencedetails.activities,
          )) {
            console.log(key);
            if (value.ActivityID == iauthorAcctivityId) {
              iAuth.roleid = value.RoleID;
              iAuth.activityid = value.ActivityID;
            }
          }
        }
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      } else if (customerId == '14') {
        const sql = `select d.guid, case when e.wfstageid in (92,99, 122, 123, 124) then  c.sequencedetails else f.sequencedetails end as sequencedetails ,b.iauthworkconversionflowid from wms_workorder as a
        join pp_mst_journal as b  on b.journalid = a.journalid
       
        join wms_workorder_stage as e on e.workorderid = a.workorderid
       
        left join iauthor_workflow c on  c.iauthworkflowid = b.iauthworkflowid  
        left join iauthor_workflow f on  f.iauthworkflowid = b.iauthworkconversionflowid
        join iauthor_transactions as d on d.workorderid = a.workorderid or d.stageiterationcount =  e.triggeredstageitrationfromid
        where a.workorderid = ${workorderId}
        and b.isiauthor=true  
        and (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
        e.stageiterationcount=${stageIterationCount} order by d.iauthourtrnsid desc limit 1`;
        console.log(sql);
        const data = await query(sql);
        console.log(data);
        let errMsg = '';
        if (data.length <= 0) {
          errMsg =
            'This tool execution is not applicable for Revises iterations.';
          res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
        }
        if (Object.keys(data[0].sequencedetails.length > 0)) {
          for (const [key, value] of Object.entries(
            data[0].sequencedetails.activities,
          )) {
            console.log(key);
            // if (value.ActivityID == iauthorAcctivityId) {
            //   iAuth.roleid = value.RoleID;
            //   iAuth.activityid = value.ActivityID;
            // }
            if (value.iwmsActivityId == activityId) {
              iAuth.roleid = value.RoleID;
              iAuth.activityid = value.ActivityID;
            }
          }
        }
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      } else if (customerId == '11') {
        const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid
            join wms_workorder_stage as e on e.workorderid = a.workorderid
            join iauthor_transactions as d on d.workorderid = a.workorderid and e.triggeredstagefromid = d.stageid and d.stageiterationcount =  e.triggeredstageitrationfromid
            where a.workorderid = ${workorderId} and b.isiauthor=true  and
           
            e.stageiterationcount=${stageIterationCount} order by e.wostageid desc limit 1`;
        // cmd line from where condtion
        // (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
        console.log(sql);
        const data = await query(sql);
        console.log(data);
        let errMsg = '';
        if (data.length <= 0) {
          errMsg =
            'This tool execution is not applicable for Revises iterations.';
          res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
        }
        if (Object.keys(data[0].sequencedetails.length > 0)) {
          for (const [key, value] of Object.entries(
            data[0].sequencedetails.activities,
          )) {
            console.log(key);
            if (value.contactrole == 'SPM') {
              iAuth.roleid = value.RoleID;
              iAuth.activityid = value.ActivityID;
            }
          }
        }
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      } else if (customerId != '9') {
        const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid
            join wms_workorder_stage as e on e.workorderid = a.workorderid
            join iauthor_transactions as d on d.workorderid = a.workorderid and e.triggeredstagefromid = d.stageid and d.stageiterationcount =  e.triggeredstageitrationfromid
            where a.workorderid = ${workorderId} and b.isiauthor=true  and
            (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
            e.stageiterationcount=${stageIterationCount} order by e.wostageid desc limit 1`;
        console.log(sql);
        const data = await query(sql);
        console.log(data);
        let errMsg = '';
        if (data.length <= 0) {
          errMsg =
            'This tool execution is not applicable for Revises iterations.';
          res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
        }
        if (Object.keys(data[0].sequencedetails.length > 0)) {
          for (const [key, value] of Object.entries(
            data[0].sequencedetails.activities,
          )) {
            console.log(key);
            if (value.contactrole == 'SPM') {
              iAuth.roleid = value.RoleID;
              iAuth.activityid = value.ActivityID;
            }
          }
        }
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      } else if (customerId == '9') {
        const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid
        join wms_workorder_stage as e on e.workorderid = a.workorderid
        join iauthor_transactions as d on d.workorderid = a.workorderid
        where a.workorderid =${workorderId} and b.isiauthor=true  order by d.iauthourtrnsid desc  limit 1`;
        console.log(sql);
        const data = await query(sql);
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      }
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

// export const fetchguId = async (req, res) => {
//   const {
//     workorderId,
//     stageId,
//     stageIterationCount,
//     customerId,
//     activityId,
//     duid,
//     iscamundaflow,
//     stageIteration,
//     woincomingfileid,
//     serviceid,
//   } = req.body;
//   const iAuth = {};
//   let errMsg = '';
//   if (iscamundaflow) {
//     let iauthorAcctivityId = 0;
//     iauthorAcctivityId =
//       activityId == '163'
//         ? 107
//         : activityId == '130'
//         ? 35
//         : activityId == '137'
//         ? 36
//         : activityId == '399'
//         ? 118
//         : 0;

//     return new Promise(async (resolve, reject) => {
//       try {
//         if (customerId == '15') {
//           const sql = `select  d.guid,
// 		  case when e.wfstageid=24 then
// 		  f.sequencedetails
// 		  else  c.sequencedetails
// end as sequencedetails ,
// b.iauthworkconversionflowid  from wms_workorder as a
//           join pp_mst_journal as b  on b.journalid = a.journalid
//           join wms_workorder_stage as e on e.workorderid = a.workorderid
//           left join iauthor_workflow c on  c.iauthworkflowid = b.iauthworkconversionflowid
//           left join iauthor_workflow f on  f.iauthworkflowid = b.iauthworkflowid
// 		    join iauthor_transactions  d on d.workorderid = e.workorderid and d.stageid = e.wfstageid
// 			  where a.workorderid = ${workorderId}
// 			   and b.isiauthor=true
// 			      and (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid
// 		from  wms_workorder_stage as st where st.workorderid=${workorderId}
// 		and st.wfstageid= ${stageId} order by st.wostageid desc limit 1)) and
//           e.stageiterationcount=1 order by e.wostageid desc limit 1`;
//           console.log(sql);
//           const data = await query(sql);
//           console.log(data);

//           if (data.length <= 0) {
//             errMsg =
//               'This tool execution is not applicable for Revises iterations.';
//             res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
//           }
//           if (Object.keys(data[0].sequencedetails.length > 0)) {
//             for (const [key, value] of Object.entries(
//               data[0].sequencedetails.activities,
//             )) {
//               console.log(key);
//               if (value.ActivityID == iauthorAcctivityId) {
//                 iAuth.roleid = value.RoleID;
//                 iAuth.activityid = value.ActivityID;
//               }
//             }
//           }
//           console.log(data[0].guid, iAuth, 'JI');
//           res.status(200).send({ guid: data[0].guid, iAuth });
//         } else if (customerId == '14') {
//           const sql = `select d.guid, case when e.wfstageid in (92,99) then  c.sequencedetails else f.sequencedetails end as sequencedetails ,b.iauthworkconversionflowid from wms_workorder as a
//           join pp_mst_journal as b  on b.journalid = a.journalid

//           join wms_workorder_stage as e on e.workorderid = a.workorderid

//           left join iauthor_workflow c on  c.iauthworkflowid = b.iauthworkflowid
//           left join iauthor_workflow f on  f.iauthworkflowid = b.iauthworkconversionflowid
//           join iauthor_transactions as d on d.workorderid = a.workorderid or d.stageiterationcount =  e.triggeredstageitrationfromid
//           where a.workorderid = ${workorderId}
//           and b.isiauthor=true
//           and (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
//           e.stageiterationcount=${stageIterationCount} order by d.iauthourtrnsid desc limit 1`;
//           console.log(sql);
//           const data = await query(sql);
//           console.log(data);
//           if (data.length <= 0) {
//             errMsg =
//               'This tool execution is not applicable for Revises iterations.';
//             res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
//           }
//           if (Object.keys(data[0].sequencedetails.length > 0)) {
//             for (const [key, value] of Object.entries(
//               data[0].sequencedetails.activities,
//             )) {
//               console.log(key);
//               // if (value.ActivityID == iauthorAcctivityId) {
//               //   iAuth.roleid = value.RoleID;
//               //   iAuth.activityid = value.ActivityID;
//               // }
//               if (value.iwmsActivityId == activityId) {
//                 iAuth.roleid = value.RoleID;
//                 iAuth.activityid = value.ActivityID;
//               }
//             }
//           }
//           console.log(data[0].guid, iAuth, 'JI');
//           res.status(200).send({ guid: data[0].guid, iAuth });
//         } else if (customerId == '11') {
//           const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid
//               join wms_workorder_stage as e on e.workorderid = a.workorderid
//               join iauthor_transactions as d on d.workorderid = a.workorderid and e.triggeredstagefromid = d.stageid and d.stageiterationcount =  e.triggeredstageitrationfromid
//               where a.workorderid = ${workorderId} and b.isiauthor=true  and

//               e.stageiterationcount=${stageIterationCount} order by e.wostageid desc limit 1`;
//           // cmd line from where condtion
//           // (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
//           console.log(sql);
//           const data = await query(sql);
//           console.log(data);
//           if (data.length <= 0) {
//             errMsg =
//               'This tool execution is not applicable for Revises iterations.';
//             res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
//           }
//           if (Object.keys(data[0].sequencedetails.length > 0)) {
//             for (const [key, value] of Object.entries(
//               data[0].sequencedetails.activities,
//             )) {
//               console.log(key);
//               if (value.contactrole == 'SPM') {
//                 iAuth.roleid = value.RoleID;
//                 iAuth.activityid = value.ActivityID;
//               }
//             }
//           }
//           console.log(data[0].guid, iAuth, 'JI');
//           res.status(200).send({ guid: data[0].guid, iAuth });
//         } else if (customerId != '9') {
//           const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid
//               join wms_workorder_stage as e on e.workorderid = a.workorderid
//               join iauthor_transactions as d on d.workorderid = a.workorderid and e.triggeredstagefromid = d.stageid and d.stageiterationcount =  e.triggeredstageitrationfromid
//               where a.workorderid = ${workorderId} and b.isiauthor=true  and
//               (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
//               e.stageiterationcount=${stageIterationCount} order by e.wostageid desc limit 1`;
//           console.log(sql);
//           const data = await query(sql);
//           console.log(data);
//           if (data.length <= 0) {
//             errMsg =
//               'This tool execution is not applicable for Revises iterations.';
//             res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
//           }
//           if (Object.keys(data[0].sequencedetails.length > 0)) {
//             for (const [key, value] of Object.entries(
//               data[0].sequencedetails.activities,
//             )) {
//               console.log(key);
//               if (value.contactrole == 'SPM') {
//                 iAuth.roleid = value.RoleID;
//                 iAuth.activityid = value.ActivityID;
//               }
//             }
//           }
//           console.log(data[0].guid, iAuth, 'JI');
//           res.status(200).send({ guid: data[0].guid, iAuth });
//         } else if (customerId == '9') {
//           const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid
//           join wms_workorder_stage as e on e.workorderid = a.workorderid
//           join iauthor_transactions as d on d.workorderid = a.workorderid
//           where a.workorderid =${workorderId} and b.isiauthor=true  order by d.iauthourtrnsid desc  limit 1`;
//           console.log(sql);
//           const data = await query(sql);
//           console.log(data[0].guid, iAuth, 'JI');
//           res.status(200).send({ guid: data[0].guid, iAuth });
//         }
//       } catch (e) {
//         reject(e.message ? e.message : e);
//       }
//     });
//   }
//   return new Promise(async (resolve, reject) => {
//     try {
//       let wfId = '';
//       let journalId = '';
//       const sql1 = `SELECT wfid, journalid from public.wms_workorder WHERE workorderid = ${req.body.workorderId}`;
//       const wfIdResult = await query(sql1);
//       wfId = wfIdResult[0].wfid;
//       journalId = wfIdResult[0].journalid;
//       if (wfIdResult.length <= 0) {
//         errMsg = 'This tool execution Failed';
//         res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
//       }
//       const sql2 = `SELECT sequencedetails FROM public.iauthor_new_workflow WHERE customerid = ${customerId} and stageid = ${stageId} and duid = ${duid} and  wfid = ${wfId} and journalid = ${journalId}`;
//       const data = await query(sql2);
//       if (data.length <= 0) {
//         errMsg = 'This tool execution Failed';
//         res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
//       }
//       if (Object.keys(data[0].sequencedetails.length > 0)) {
//         for (const activity of data[0].sequencedetails.activities) {
//           if (activity.iwmsActivityId == activityId) {
//             iAuth.roleid = activity.RoleID;
//             iAuth.activityid = activity.ActivityID;
//           }
//         }
//       }

//       const sql3 = `SELECT guid FROM public.iauthor_transactions where workorderid = ${workorderId} and stageid = ${stageId} and stageiterationcount = ${stageIteration} and woincomingfileid = ${woincomingfileid}
//       and customerid = ${customerId} and duid = ${duid} and serviceid = ${serviceid}`;
//       const data2 = await query(sql3);
//       if (data2.length <= 0) {
//         errMsg = 'This tool execution Failed';
//         res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
//       }
//       const guid = data2[0]?.guid ?? 0;
//       res.status(200).send({ guid, iAuth });
//     } catch (e) {
//       reject(e.message ? e.message : e);
//     }
//   });
// };

export const checkGraphicEnabled = async (req, res) => {
  const { workorderId, wfeventId, woincomingFileId, taskType } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      let condition = '';
      let sql = '';
      if (taskType == 'Multiple') {
        condition = `eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0 and incomingfile.woincomingfileid = ${woincomingFileId}`;
        // condition = `eventlog.wfeventid = ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.isgraphicrequired = true and incomingfile.woincomingfileid =${woincomingFileId} `
        sql = `select  incomingfile.woincomingfileid,incomingfile.filename,incomingfile.imagecount,eventlog.wfdefid,workflow.config,incomingfile.woincomingfileid from wms_workorder_incoming as incoming
                join wms_workorder_incomingfiledetails as incomingfile on incomingfile.woincomingid =incoming.woincomingid
                join  wms_workflow_eventlog as eventlog on eventlog.workorderid = incoming.woid
                join wms_workflowdefinition as workflow on workflow.wfdefid = eventlog.wfdefid
                ${condition ? `where ${condition}` : ''}`;
      } else {
        condition = `eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0`;
        // condition = `eventlog.wfeventid = ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.isgraphicrequired = true`
        sql = `select  incomingfile.woincomingfileid from wms_workorder_incoming as incoming
                join wms_workorder_incomingfiledetails as incomingfile on incomingfile.woincomingid =incoming.woincomingid
                join  wms_workflow_eventlog as eventlog on eventlog.workorderid = incoming.woid
                join wms_workflowdefinition as workflow on workflow.wfdefid = eventlog.wfdefid 
                where eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0`;
      }
      console.log(sql);
      const reponse2 = await query(sql);
      console.log(reponse2, 'reponse2');
      res.status(200).send(reponse2);
    } catch (e) {
      reject(e);
    }
  });
};

function appendUnderscoreBeforeFirstNumber(inputString) {
  const match = inputString.match(/\d/);
  if (match) {
    // Insert an underscore before the first numeric character
    const { index } = match;
    const modifiedString = `${inputString.slice(0, index)}_${inputString.slice(
      index,
    )}`;
    return modifiedString;
  }
  return inputString;
}
export const exportcollationreport = async (req, res) => {
  const {
    workorder,
    stage,
    excelfilename,
    stageid,
    customerid,
    duid,
    basePath,
    isEmail,
    attachFiles,
    wfeventId,
  } = req.body;

  let blobPath = '';
  let mailAuditPayload = '';

  if (isEmail) {
    mailAuditPayload = {
      mailData: {
        subject: 'Mail trigger for pm with attachment',
        workorderId: workorder,
        serviceId: 1,
        stageId: stageid,
        stageIterationCount: req?.body?.stageiterationcount,
        wfDefId: req?.body?.wfDefId,
        mailType: 'PM mail trigger',
        wfeventId,
      },
      errorMsg: null,
      status: 'Process Started',
    };
  }
  try {
    // const sql = `select journalacronym as "mnemonic",doinumber as "doinumber",typesetpages as "number of pages",title,'' as"copy to copyed",'' as "copy to typesetter"
    //       ,firsrproofreceived as "first proof rec'd", collationenabled as "for correction",
    //       pmreviewcompleted1 as "revised proof",revisesreceived2 as "for correction v1",pmreviewcompleted2 as "revised proof1",revisesreceived3 as "for correction v2",pmreviewcompleted3 as "revised proof2"
    //       from getcollation_report('${workorder}','${stage}')`;
    const sql = `select journalacronym as "mnemonic",doi,typesetpages as "number of pages",title,'' as"copy to copyed",'' as "copy to typesetter",
    to_char(iauthorlinkcreated, 'DD-MM-YYYY') as "first proof rec'd",
    to_char(collationenabled, 'DD-MM-YYYY') as "for correction",
    to_char(pmreviewcompleted1, 'DD-MM-YYYY') as "revised proof",
    to_char(revisesreceived2, 'DD-MM-YYYY') as "for correction v1",
    to_char(pmreviewcompleted2, 'DD-MM-YYYY')  as "revised proof 1",
    to_char(revisesreceived3, 'DD-MM-YYYY') as "for correction v2",
    to_char(pmreviewcompleted3, 'DD-MM-YYYY') as "revised proof 2",
    to_char(firstview, 'DD-MM-YYYY') as "firstview",
    to_char(revisedfirstview1, 'DD-MM-YYYY') as "revised firstview1",
    to_char(revisedfirstview2, 'DD-MM-YYYY') as "revised firstview2",
    to_char(revisedfirstview3, 'DD-MM-YYYY') as "revised firstview3"  
             from getcollation_report_new('${workorder}','${stage}')`;

    console.log(sql, 'getcollationreport');
    const report = await query(sql);
    let checkStatus = true;
    if (stageid != 1 && !isEmail) {
      const sql3 = `select * from wms_ftp_audit where stageid=1 and workorderid=${workorder}`;
      const count = await query(sql3);
      checkStatus = count.length > 0;
    }

    if (checkStatus) {
      const validationFtp = `select * from wms_ftp_audit where wfeventid =${wfeventId} and status = 'Success'`;
      const validationCount = await query(validationFtp);
      if (validationCount && validationCount.length == 0) {
        // to read the xlsx file from selected path
        let outputFilePath = join(__filename, '../../../../../');

        outputFilePath = join(outputFilePath, 'upload/cupJournals.xlsx');

        let tempFilePath = join(__filename, '../../../../../');

        const temp1 = `${tempFilePath}upload/temps`;
        await makeDir(temp1);
        const temp2 = `${tempFilePath}upload/temps/${workorder}`;
        await removeFolder(temp2);
        await makeDir(temp2);

        tempFilePath = join(
          tempFilePath,
          `upload/temps/${workorder}/cupJournals.xlsx`,
        );
        await copyXlsxFile(outputFilePath, tempFilePath);

        const cells = [
          'A2',
          'B2',
          'C2',
          'D2',
          'E2',
          'F2',
          'G2',
          'H2',
          'I2',
          'J2',
          'K2',
          'L2',
          'M2',
        ];
        const cells1 = [
          'A1',
          'B1',
          'C1',
          'D1',
          'E1',
          'F1',
          'G1',
          'H1',
          'I1',
          'J1',
          'K1',
          'L1',
          'M1',
        ];

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(tempFilePath);
        const worksheet = workbook.getWorksheet('Sheet1'); // Replace 'Sheet1' with the actual sheet name
        for (let i = 0; i < cells.length; i++) {
          const cell = worksheet.getCell(cells[i]);
          const cell1 = worksheet.getCell(cells1[i]);
          // cell.value = Number.isNaN(report[0][cell1])
          //   ? report[0][cell1]
          //   : +report[0][cell1];
          cell.value =
            typeof report[0][cell1] === 'number'
              ? +report[0][cell1]
              : report[0][cell1];
        }
        const xlFilenameForUpload =
          appendUnderscoreBeforeFirstNumber(excelfilename);
        // Save the changes
        await workbook.xlsx.writeFile(tempFilePath);
        const fileDetails = {
          tempFilePath,
          name: xlFilenameForUpload,
        };

        const uploadRes = await _upload(fileDetails, basePath);
        console.log('Kaniiiiii', uploadRes);
        blobPath = uploadRes.fullPath;

        // const sql2 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Success', current_timestamp,${wfeventId},'${uploadRes.fullPath}')`;
        // const reponse2 = await query(sql2);
        // console.log(reponse2, 'reponse2');
        const srcInfo = {
          path: `${tempFilePath}`,
        };
        const targetInfo = {
          filename: `${report[0].doi}.xlsx`,
        };

        const checkValidExcel = await validateExcel(tempFilePath);
        if (!checkValidExcel.isValid) {
          throw checkValidExcel;
        }

        targetInfo.tempFileName = `${parse(targetInfo.filename).name}.io`;
        const ftpRes = await invokeFileUploadToFTP(
          'cup_ftp_fileUpload',
          srcInfo,
          targetInfo,
        );

        if (ftpRes && ftpRes.isSuccess) {
          // To send customer campus signal start
          let isSuccessSignal = true;
          let differentTypesetPage;

          if (isEmail) {
            const pageCompare = `WITH actual_row AS (
    SELECT COALESCE(typesetpages, 0) AS typesetpages,
           wfstageid,
           stageiterationcount
    FROM wms_workorder_stage
    WHERE workorderid = ${workorder} AND wfstageid = 2 AND stageiterationcount = 2
),
first_try AS (
    SELECT COALESCE(typesetpages, 0) AS typesetpages,
           wfstageid,
           stageiterationcount
    FROM wms_workorder_stage
    WHERE workorderid = ${workorder} AND wfstageid = 2 AND stageiterationcount = 1
),
second_try AS (
    SELECT COALESCE(typesetpages, 0) AS typesetpages,
           wfstageid,
           stageiterationcount
    FROM wms_workorder_stage
    WHERE workorderid = ${workorder} AND wfstageid = 1
      AND stageiterationcount = (
          SELECT MAX(stageiterationcount)
          FROM wms_workorder_stage
          WHERE workorderid = ${workorder} AND wfstageid = 1
      )
),
fallback AS (
    SELECT * FROM first_try
    UNION ALL
    SELECT * FROM second_try
    WHERE NOT EXISTS (SELECT 1 FROM first_try)
),
comparison AS (
    SELECT
        a.typesetpages,
        CASE
            WHEN f.typesetpages = a.typesetpages
            THEN FALSE
            ELSE TRUE
        END AS is_different
    FROM fallback f
    LEFT JOIN actual_row a ON TRUE
)
SELECT * FROM comparison;`;

            const pageCompareRes = await query(pageCompare);
            if (
              pageCompareRes &&
              pageCompareRes.length > 0 &&
              pageCompareRes?.[0]?.is_different
            ) {
              isSuccessSignal = true;
              differentTypesetPage = pageCompareRes?.[0]?.typesetpages;
            } else {
              isSuccessSignal = false;
            }
          }

          if (isSuccessSignal) {
            const campusQuery = `SELECT wms_mst_stage.stagename,pp_mst_journal.journalid,pp_mst_journal.otherdetails ->> 'isSignal' AS iscampustrigger,
wms_workflow_eventlog.stageiterationcount,wms_workflow_eventlog.wfdefid
FROM wms_workorder 
JOIN pp_mst_journal ON wms_workorder.journalid = pp_mst_journal.journalid 
JOIN wms_workflow_eventlog on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
JOIN wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid and issignal = true
JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
where wfeventid = ${wfeventId}`;

            const response = await query(campusQuery);

            if (
              response &&
              response.length > 0 &&
              response[0].iscampustrigger === 'true'
            ) {
              // Trigger Campus Signal
              const payload = {
                workorderId: workorder,
                stageName: response[0].stagename,
                stageIteration: response[0].stageiterationcount,
                payloadType: 'dynamicPayload',
                flowType: 'activity',
                differentTypesetPage,
                differentTypesetPageCount: isEmail,
                isRound: response[0].stagename != 'First Proof',
                isPagecount: response[0].stagename == 'First Proof',
              };
              const campRes = await _sendCampusSignal(payload);
              console.log(campRes, 'campRes');
            }
          }
          // To send customer campus signal end
          const sql2 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,remarks,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Success', 'File Uploaded Successfully' ,current_timestamp,${wfeventId},'${blobPath}')`;
          const reponse2 = await query(sql2);
          console.log(reponse2, 'reponse2');

          if (isEmail) {
            const fileArray = [];

            attachFiles.forEach(list => {
              fileArray.push(
                join(list.dest, list.srcName).split('\\').join('/'),
              );
            });

            mailAuditPayload.status = 'mailTriggerForPM function call started!';
            await pmRevieewEmailAudit(mailAuditPayload);

            await mailTriggerForPM(req.body, fileArray, mailAuditPayload);
          }
        } else {
          await removeFolder(temp2);
          throw ftpRes;
        }
        await removeFolder(temp2);
      } else if (isEmail) {
        mailAuditPayload.status =
          'Ftp already upload mail trigger process started';
        mailAuditPayload.mailData.template = attachFiles;

        await pmRevieewEmailAudit(mailAuditPayload);
        const fileArray = [];
        attachFiles.forEach(list => {
          fileArray.push(join(list.dest, list.srcName).split('\\').join('/'));
        });

        await mailTriggerForPM(req.body, fileArray, mailAuditPayload);

        mailAuditPayload.status =
          'Ftp already upload mail trigger process completed';
        await pmRevieewEmailAudit(mailAuditPayload);
      }
      res.status(200).send(report);
    } else {
      res.status(400).send({
        message:
          'xlsx file not upload in ftp due to firstproof stage not uploaded xlsx',
      });
    }
  } catch (e) {
    const message = e.message ? e.message : e;
    const sql3 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,remarks,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Failed','${message}', current_timestamp,${wfeventId},'${blobPath}')`;
    await query(sql3);

    // res.status(400).send(e.message ? e.message : e);
    res.status(400).send(message);
  }
};
export const isWordCount = async (req, res) => {
  const { workorder, tagValues } = req.body;

  try {
    let itrackcustomerid = 0;
    let wordcountperpage = 1.0;
    let customershortname = '';
    let conversionfactor = 0.0;
    let retstatus = false;
    let retdata;
    // const checksql = `Select woincomingid from public.wms_workorder_incoming where woid=${workorder}`;

    const checksql = `select  cus.itrack_customerid ,cus.customershortname, wi.woincomingid , jr.conversionfactor
        from public.wms_workorder_incoming as wi
        join wms_workorder as wo on wo.workorderid = wi.woid  
        join org_mst_customer cus on cus.customerid = wo.customerid
        join public.pp_mst_journal as jr on jr.journalid = wo.journalid
        where woid=${workorder}`;
    await query(checksql).then(async getCount => {
      if (getCount[0].woincomingid > 0) {
        const woincomingid = +getCount[0].woincomingid
          ? +getCount[0].woincomingid
          : {};

        itrackcustomerid = +getCount[0].itrack_customerid
          ? +getCount[0].itrack_customerid
          : 0;

        customershortname = getCount[0].customershortname
          ? getCount[0].customershortname
          : '';

        conversionfactor = +getCount[0].conversionfactor
          ? +getCount[0].conversionfactor
          : 1.0;

        const updatesql = `update public.wms_workorder_incomingfiledetails set wordcount = ${tagValues.totwordcount},referencecount = ${tagValues.refcount}, tablecount = ${tagValues.tables}, imagecount=${tagValues.figures},equationcount = ${tagValues.equations} where woincomingid = ${woincomingid}	`;

        await query(updatesql).then(async data => {
          retdata = data;
          retstatus = true;
        });

        try {
          if (customershortname == 'ACS') {
            const getstandardpage = `SELECT wordcount_per_page::numeric(5,2) wordcount_per_page  FROM public.mst_standardpage_measure where customerid = ${itrackcustomerid}`;

            const respage = await query(getstandardpage);
            if (respage != undefined && respage.length > 0) {
              wordcountperpage = respage[0].wordcount_per_page
                ? +respage[0].wordcount_per_page
                : 1;
            }

            const qrypageupdate = `update wms_workorder_incomingfiledetails set 
            estimatedpages = round(round(wordcount/ ${wordcountperpage}) * ${conversionfactor})  , 
            typesetpage = round(round(wordcount/ ${wordcountperpage}) * ${conversionfactor}) ,
            mspages =  round(wordcount/ ${wordcountperpage})            
            where woincomingid = ${woincomingid}`;

            await query(qrypageupdate);
          }
        } catch (error) {
          console.log(error, 'update espage');
        }
      }
      res.status(200).json({
        data: retdata,
        status: retstatus,
      });
    });
  } catch (error) {
    console.log(error);
    res.status(400).send('Error in word count file, please check');
  }
};

export const onSaveMailTrigger = async (req, res) => {
  try {
    const data = {
      articlename: req.body.articlename,
      workorderId: req.body.workorder,
      customerid: req.body.customerid,
      journalid: req.body.journalid,
      stageId: req.body.stageid,
      isAttachment: true,
      journalName: req.body.journalAcronym,
      issueName: req.body.issueName,
      flowtype: 'isjournalflow',
      attachFiles: req.body.attachFiles,
    };
    await mailTriggerForKLI(data);
    res.status(200).send('Mail trigged successfully');
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send(error);
  }
};

export const copyXlsxFile = async (outputFilePath, tempFilePath) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Read the content of the source file synchronously
      const data = await fs.readFileSync(outputFilePath);

      // Write the content to the destination file synchronously
      await fs.writeFileSync(tempFilePath, data);

      resolve();
    } catch (err) {
      reject(err);
    }
  });
};

export const pmRevieewEmailAudit = payload => {
  return new Promise(resolve => {
    try {
      const { mailData, errorMsg = null, status = null } = payload;
      const {
        subject = null,
        workorderId = null,
        serviceId = null,
        stageId = null,
        stageIterationCount = null,
        wfDefId = null,
        mailType = null,
      } = mailData;
      // console.log('yuvarajmlmlml', mailData.template.toString().replace(/'/g, '#$'))
      const tempMailData = mailData?.template
        ? mailData?.template.toString().replace(/'/g, '#$')
        : {};
      mailData.template = tempMailData;
      const wfeventid =
        mailData && mailData.wfeventId ? mailData.wfeventId : null;

      let sql = `INSERT INTO public.wms_email_audit(workorderid, serviceid, stageid, stageiterationcount, wfdefid, "timestamp", status,wfeventid) 
     VALUES (${workorderId},${serviceId},${stageId},${stageIterationCount},${wfDefId},current_timestamp,'${status}',${wfeventid}) RETURNING *`;

      query(sql, [])
        .then(data => {
          const { emailauditid } = data[0];

          sql = `INSERT INTO public.wms_email_audit_history( emailauditid, mailtype, paylod, errorlog, "timestamp", status, subject)
           VALUES ( ${emailauditid},'${mailType}','${JSON.stringify(
            mailData,
          )}','${errorMsg}', current_timestamp,'${status}', '${subject}');`;
          query(sql, [])
            .then(() => {
              resolve(true);
            })
            .catch(() => {
              resolve(false);
            });
        })
        .catch(() => {
          resolve(false);
        });
    } catch (error) {
      resolve(false);
    }
  });
};

export const getIsUpdatedPackageReqController = async (req, res) => {
  try {
    const data = await getIsUpdatedPackageReqService(req.body);
    let result;
    if (
      data.length > 0 &&
      (data[0]?.receivedon > data[0]?.claimedon || req.body.type == 'Claim')
    ) {
      result = {
        updPkgId: data[0]?.updPkgId,
        isUpdPkgReceived: true,
        UpdPkgReceivedon: moment(data[0]?.receivedon)
          .add(5, 'hours')
          .add(30, 'minutes')
          .format('DD-MM-YYYY hh:mm A'),
      };
    } else {
      result = {
        updPkgId: 0,
        isUpdPkgReceived: false,
      };
    }
    res.status(200).send({ status: true, data: result });
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};

export const getIsUpdatedPackageReqService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        workorderId,
        stageId,
        stageIterationCount,
        activityId,
        wfeventId,
      } = payload;

      const sql = `WITH latest_wwed AS (
                      SELECT wfeventid, MAX(wfeventdetailid) AS latest_detail_id
                      FROM wms_workflow_eventlog_details
                      GROUP BY wfeventid
                    )
                    SELECT tu.id AS "updPkgId", tu.createdon AS receivedon, wwed.timestamp AS claimedon
                    FROM trn_updatedrequest tu
                    JOIN latest_wwed ON latest_wwed.wfeventid = $1
                    JOIN wms_workflow_eventlog_details wwed
                        ON wwed.wfeventid = latest_wwed.wfeventid
                        AND wwed.wfeventdetailid = latest_wwed.latest_detail_id
                    WHERE tu.isactive = TRUE
                      AND tu.workorderid = $2
                      AND tu.stageid = $3
                      AND tu.stageiterationcount = $4
                      AND (tu.activityid IS NULL OR $5 <> ANY(tu.activityid))
                    ORDER BY tu.id DESC
                    LIMIT 1;`;

      const data = await query(sql, [
        wfeventId,
        workorderId,
        stageId,
        stageIterationCount,
        activityId,
      ]);

      resolve(data);
    } catch (e) {
      reject(e); // Reject the promise with the error
    }
  });
};

export const ElsUpdReqController = async (req, res) => {
  const { stageInfo, revisedTat, revisedData } = req.body;
  const { workorderId, relatedstageinfo } = stageInfo;
  try {
    await transaction(async client => {
      await ElsUpdPckgReqpbTask(client, workorderId, relatedstageinfo);

      await ElsInsertUpdPckgReq(client, workorderId, relatedstageinfo);

      if (revisedTat) {
        await ElsUpdStageTatAudit(client, workorderId, revisedTat);
        if (revisedTat.isAutoTat) {
          await ElsUpdStageAutoTat(client, workorderId, revisedTat);
        } else {
          await ElsUpdStageTat(client, workorderId, revisedTat);
        }
      }
      if (revisedData)
        await ElsUpdateRevisedData(client, workorderId, revisedData);
    });

    return res.status(200).json({ status: true });
  } catch (e) {
    return res.status(400).json({ status: false, message: e.message || e });
  }
};

export const getPreviousActivityRemarksController = async (req, res) => {
  try {
    const data = await getPreviousActivityRemarks(req.body);
    res.status(200).send(data);
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};

export const getPreviousActivityRemarks = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wfId, stageId, sequence, workorderId } = payload;
      const sql = `SELECT wwed.usercomments FROM wms_workflowdefinition ww
                  JOIN wms_workflow_eventlog wwe ON ww.wfdefid = wwe.wfdefid
                  JOIN wms_workflow_eventlog_details wwed ON wwe.wfeventid = wwed.wfeventid
                  WHERE 
                    ww.wfid = $1 AND ww.stageid = $2 AND ww."sequence" < $3 AND wwe.workorderid = $4
                    AND wwed.operationtype = 'Completed' AND wwed.usercomments IS NOT NULL
                  ORDER BY ww.wfdefid DESC, wwed.wfeventdetailid DESC LIMIT 1;`;

      const data = await query(sql, [wfId, stageId, sequence, workorderId]);
      resolve(data.length ? data[0].usercomments : false);
    } catch (e) {
      reject(e); // Reject the promise with the error
    }
  });
};

export const getBaseCustomerPathQuery = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId } = payload;

      let sql;
      if (duId) {
        sql = `select * from  public.wms_mst_customerconfigdetails where duid = ${duId}`;
      } else {
        sql = `select * from  public.wms_mst_customerconfigdetails`;
      }
      const data = await query(sql);
      resolve(data);
    } catch (e) {
      reject(e); // Reject the promise with the error
    }
  });
};

export const getXmlReportsUrl = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderid, duId, journalAcronym } = payload;
      if (!workorderid) {
        resolve(false);
        // return []; // Return an empty array if workorderid is missing
      }

      const sqlOne = `SELECT wms.stageid, wms.stagename, wmcd.localserverpath AS basepath  
    FROM  wms_workorder_stage wws
    JOIN wms_mst_stage wms ON wws.wfstageid = wms.stageid
    LEFT JOIN public.wms_mst_customerconfigdetails wmcd ON wmcd.duid = ${duId}
    WHERE wws.workorderid = ${workorderid} AND wws.wfstageid != 10 AND wws.status = 'In Process' 
    ORDER BY wws.wostageid DESC;`;

      let data = await query(sqlOne);
      if (data.length === 0) {
        const sqlTwo = `SELECT wms.stageid, wms.stagename, wmcd.localserverpath AS basepath
  FROM wms_workorder_stage wws
  JOIN wms_mst_stage wms ON wws.wfstageid = wms.stageid
  LEFT JOIN public.wms_mst_customerconfigdetails wmcd ON wmcd.duid = ${duId}
  WHERE wws.workorderid = ${workorderid} AND wws.wfstageid != 10 AND wws.status = 'Completed'
  ORDER BY wws.wostageid DESC;`;

        data = await query(sqlTwo);
      }

      if (data.length) {
        data[0].basepath = data[0].basepath.replace(
          ';JournalAcronym;',
          journalAcronym,
        ); // Assign instead of push(
      }
      resolve(data.length ? data : false);
      // return data.length ? data : [];
    } catch (error) {
      reject(error);
    }
  });
};

export const getBaseCustomerPath = async (req, res) => {
  try {
    const data = await getBaseCustomerPathQuery(req.body);
    let result;
    if (data.length > 0) {
      result = data;
    } else {
      result = [];
    }
    res.status(200).send({ status: true, data: result });
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};

export const getXmlReportURl = async (req, res) => {
  try {
    const data = await getXmlReportsUrl(req.body);
    let result;
    if (data.length > 0) {
      result = data;
    } else {
      result = [];
    }
    res.status(200).send({ status: true, data: result });
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};
