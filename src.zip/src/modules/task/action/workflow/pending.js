// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { validateFiles } from './utils/validation.js';
import { config } from '../../../../config/restApi.js';
import { transaction, query } from '../../../../database/postgres.js';
import { Service } from '../../../../httpClient/index.js';
import { emitAction, actions } from '../../../activityListener/index.js';
import { getWorkflowConfig, createReportView } from '../../../common/index.js';

import {
  checkItracksExits,
  logisticEntryUpdate,
  getiTracksStageId,
  getiTracksActivityId,
  getSubjobIds,
  logisticEntryUpdateJournal,
  checkitrackIntegration,
  logisticEntryDelete,
} from '../../../iTracks/index.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { postProcess, preProcess } from './index.js';
import {
  _getIssueWorkorderInfo,
  _getPartialNonArticleDetails,
} from '../../fileDetails.js';

const service = new Service();
export const pendingPreProcess = async (req, res, action) => {
  const { userid, wfeventId } = req.body;
  // capture user event
  const payload = {
    userId: userid,
    wfeventId,
    actionType: 'Pending',
  };
  preProcess(req, payload);

  const response = { status: true, message: '' };
  await validateFiles(req, res, action)
    .then(() => {
      // res.send('validated pending action');
      response.status = true;
      response.message = 'Validated pending action';
    })
    .catch(e => {
      res.status(400).send(e);
    });
  res.status(200).send(response);
};

export const pendingProcess = async (req, res) => {
  const {
    userid,
    wfeventId,
    woType,
    workorderId,
    activitymodeltypeflow,
    isOtherArticle,
    iscamundaflow,
    runonFileSequence,
  } = req.body;

  const responseArray = [];
  let overAllFiles = [];
  let batchInfo = [];
  const awts = [];
  // check iTracks API call
  const isItracksAPI = await checkItracksExits(req, res, true);
  console.log(isItracksAPI, 'isItracksAPI');
  const { status, isProduction, isCustomer } = isItracksAPI;
  if (
    activitymodeltypeflow &&
    activitymodeltypeflow == 'Partial' &&
    isOtherArticle
  ) {
    const data = {
      workOrderId: workorderId,
      wfDefId: req.body.wfdefid,
      fileTypeId: req.body.fileTypeId,
    };
    overAllFiles = await _getPartialNonArticleDetails(data);
  }
  if (activitymodeltypeflow && activitymodeltypeflow == 'Batch') {
    const issuePayload = {
      issuemstid: req.body.issuemstid,
      wfDefId: req.body.wfdefid,
      workorderid: req.body.workorderId,
    };
    batchInfo = await _getIssueWorkorderInfo(issuePayload);
    overAllFiles = iscamundaflow
      ? batchInfo.filter(list => list.taskinstanceid !== null)
      : batchInfo;
  } else if (runonFileSequence) {
    const issuePayload = {
      issuemstid: req.body.issuemstid,
      wfDefId: req.body.wfdefid,
      workorderid: workorderId,
      runonFileSequence,
    };
    batchInfo = await _getIssueWorkorderInfo(issuePayload);
    overAllFiles = batchInfo;
  } else {
    overAllFiles = [req.body];
  }

  for (let k = 0; k < overAllFiles.length; k++) {
    const value = overAllFiles[k];
    req.body.workorderId = value.workorderid || req.body.workorderId;
    req.body.taskInstanceId = value.taskinstanceid || req.body.taskInstanceId;
    req.body.wfeventId = value.wfeventid || req.body.wfeventId;
    req.body.activityLength = overAllFiles.length;
    req.body.loopIndex = k;
    if (status) {
      const iStageId = await getiTracksStageId(req.body);
      const iActivityId = await getiTracksActivityId(req.body);
      if (woType === 'Book') {
        const iSubjobIds = await getSubjobIds(req.body);
        console.log(iSubjobIds, 'iSubjobIds');

        if (iStageId && iActivityId && iSubjobIds.length) {
          req.body.iStageId = iStageId;
          req.body.iActivityId = iActivityId;
          req.body.subjobArray = iSubjobIds;
          const isEntryUpdate = await logisticEntryUpdate(
            req.body,
            isProduction,
            isCustomer,
            1,
            'pending',
          );
          const { status: st, Result } = isEntryUpdate;
          console.log(isEntryUpdate, 'isEntryUpdate');
          if (st) {
            unClaimTask(req)
              .then(response => {
                emitAction(actions.wfUnClaimed);
                responseArray.push(response);
                // res.send(response);
                // capture user event
                const payload = {
                  userId: userid,
                  wfeventId,
                  actionType: 'Pending',
                };
                postProcess(req, payload);
              })
              .catch(e => {
                res.status(400).send(e);
              });
            // new itrack productivity calculation
            await checkitrackIntegration(req.body, 'wms');
          } else {
            res.status(400).send({ message: Result });
          }
        } else {
          res.status(400).send({
            status: false,
            message:
              'iTracks stageid / activityid / subjobid not fount in iWMS',
          });
        }
      } else if (iStageId && iActivityId) {
        req.body.iStageId = iStageId;
        req.body.iActivityId = iActivityId;
        let isEntryUpdate;
        if (req.body.quantity > 0) {
          isEntryUpdate = await logisticEntryUpdateJournal(
            req.body,
            isProduction,
            isCustomer,
            1,
            'pending',
          );
        } else {
          isEntryUpdate = await logisticEntryDelete(req.body);
        }
        const { status: st, Result } = isEntryUpdate;
        console.log(isEntryUpdate, 'isEntryUpdate');
        if (st) {
          unClaimTask(req)
            .then(response => {
              emitAction(actions.wfUnClaimed);
              responseArray.push(response);
              // res.send(response);
              // capture user event
              const payload = {
                userId: userid,
                wfeventId,
                actionType: 'Pending',
              };
              postProcess(req, payload);
            })
            .catch(e => {
              res.status(400).send(e);
            });
          await checkitrackIntegration(req.body, 'wms');
        } else {
          res.status(400).send({ message: Result });
        }
      } else {
        res.status(400).send({
          status: false,
          message: 'iTracks stageid / activityid / subjobid not fount in iWMS',
        });
      }
    } else {
      console.log('pending without iTracks API');
      unClaimTask(req)
        .then(response => {
          emitAction(actions.wfUnClaimed);
          responseArray.push(response);
          // res.send(response);
          // capture user event
          const payload = {
            userId: userid,
            wfeventId,
            actionType: 'Pending',
          };
          postProcess(req, payload);
        })
        .catch(e => {
          res.status(400).send(e);
        });
      await checkitrackIntegration(req.body, 'wms');
    }
  }
  await Promise.all(awts);
  res.status(200).send({ message: responseArray });
};

const unClaimTask = req => {
  const {
    du,
    wfeventId,
    userId,
    taskInstanceId,
    uomid,
    noOfPages,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
    stageId,
    wfId,
    activityCount,
    comments,
    actualActivityCount,
    iscamundaflow,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.camnunda.uri.unClaim;
      const data = { id: taskInstanceId, assignee: userId };

      await transaction(async client => {
        // entry for report
        let sql = `SELECT timestamp FROM wms_workflow_eventlog_details WHERE wfeventid =$1 AND userid=$2
                AND (operationtype =$3 OR operationtype =$4 OR operationtype =$5) ORDER BY wfeventdetailid DESC LIMIT 1`;
        const { rows } = await client.query(sql, [
          wfeventId,
          userId,
          'Work in progress',
          'Hold',
          'Pending',
        ]);

        if (rows.length > 0) {
          const payload = {
            duId: du,
            userId,
            wfeventId,
            timestamp: rows[0].timestamp,
            uomValue: noOfPages || 0,
          };

          await createReportView(client, payload);
        }
        // event log
        sql = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2, isfilesynced =$3, activitycount =$4 WHERE wfeventid = $5 RETURNING wfeventid `;
        await client.query(sql, [
          null,
          'Pending',
          false,
          parseInt(activityCount) + 1,
          wfeventId,
        ]);
        // event log details
        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid,uomid, uomvalue, usercomments, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9);`;
        await client.query(sql, [
          wfeventId,
          'Pending',
          new Date(),
          userId,
          uomid,
          noOfPages || 0,
          comments,
          systemInfo,
          actualActivityCount,
        ]);
        if (iscamundaflow) {
          await service.post(`${config.camnunda.base_url}${url}`, data);
        }
        // mail trigger
        const payload = {
          duId: du,
          entityId,
          workorderId,
          serviceId,
          wfdefid,
          stageName,
          iteration: iterationCount,
          stageDuedate,
          stageId,
          wfId,
        };
        await getWorkflowConfig(payload, 'pending');

        resolve('Task has been unclaimed successfully');
      });
    } catch (e) {
      if (e.message.data.data) {
        // This is used to check camunda error msg and This is wrong. need to get proper error msg from camunda layer.

        reject(e.message.data.data);
      } else {
        reject(e.message ? e.message : e);
      }
    }
  });
};

export const getUomHistory = (req, res) => {
  const { wfeventId } = req.body;
  const pendingSql = `SELECT * FROM public.wms_workflow_eventlog_details as eventlog  JOIN public.wms_user as username ON eventlog.userid=username.userid WHERE (eventlog.operationtype='Pending' or eventlog.operationtype='Hold') AND eventlog.wfeventid =${wfeventId} and eventlog.uomvalue is not null and eventlog.uomvalue is not null and eventlog.actualactivitycount = (SELECT MAX(actualactivitycount) FROM public.wms_workflow_eventlog_details where wfeventid =${wfeventId}) ORDER BY wfeventdetailid`;
  const holdAndPendingSql = `SELECT * FROM public.wms_workflow_eventlog_details as eventlog JOIN public.wms_user as username ON eventlog.userid=username.userid WHERE eventlog.operationtype in ('Pending','Hold') AND eventlog.wfeventid =${wfeventId} and eventlog.uomvalue is not null and eventlog.uomvalue is not null and eventlog.actualactivitycount = (SELECT MAX(actualactivitycount) FROM public.wms_workflow_eventlog_details where wfeventid =${wfeventId}) ORDER BY wfeventdetailid`;
  query(pendingSql)
    .then(pendingRes => {
      query(holdAndPendingSql)
        .then(pendingHoldRes => {
          res
            .status(200)
            .json({ data: pendingRes, pendingHoldData: pendingHoldRes });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updatesStatusValueInToolsApi = async (req, res) => {
  const { wfeventId } = req.body;
  try {
    const pendingSql = `Update wms_tools_api set isactive = false where wfeventid in (SELECT wfeventid FROM public.wms_tools_api where wfeventid=${wfeventId}) `;
    const pendingRes = await query(pendingSql);
    res.status(200).send({ message: 'updated successfully', res: pendingRes });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const _pendingPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _pendingPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};
