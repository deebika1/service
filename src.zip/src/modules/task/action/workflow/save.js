/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
// import moment from 'moment';
import { transaction, query } from '../../../../database/postgres.js';
import {
  validateFiles,
  validateToolsRunningStatus,
  validateOpenQuery,
  postSaveValidation,
  validateFtpUpload,
  validateMandatoryTool,
  isACSErrorHandledFile,
  isElsevierProblemTaskFile,
} from './utils/validation.js';
import { postProcess, preProcess } from './index.js';
import { emitAction, actions } from '../../../activityListener/index.js';
import {
  getRejectedVariables,
  getBWStageVariables,
} from '../../../utils/wfTrigger/variables.js';
import { completeTask } from './utils/completeTask.js';

import {
  getWorkflowConfig,
  pkgDepositTrigger,
  createReportView,
  calculateEstimatedPage,
} from '../../../common/index.js';
import {
  checkItracksExits,
  logisticEntryUpdate,
  getiTracksStageId,
  getiTracksActivityId,
  getSubjobIds,
  logisticEntryUpdateJournal,
  taskDespatch,
  taskDespatchJournal,
  getiTracksDuId,
  getiTracksCustomerId,
  checkitrackIntegration,
} from '../../../iTracks/index.js';
import { ActConfigDetails } from '../../../configuration/index.js';
import { getdmsType } from '../../../bpmn/listener/create.js';
import { _captureUserEvent, _prepubWorkflowUpdate } from '../../taskDetails.js';
import { _triggerWOStageWf } from '../../../woi/stage.js';
import {
  _getIssueWorkorderInfo,
  _getPartialNonArticleDetails,
  _getPartialNonArticleDetailsWithArticleOrderSequence,
} from '../../fileDetails.js';
import { tocFileEnableE2E } from '../../../woi/graphicArt.js';
import { _download } from '../../../utils/azure/index.js';
import { _localdownload } from '../../../utils/local/index.js';
import { setOrdInflowService } from '../../../../salesPMO/service/index.js';
import {
  invoiceIntegrationService,
  ubrIntegrationService,
} from '../../../../odoo/service/index.js';
import { ReStructureFileConfig } from '../../../utils/fileValidation/validate.js';
// import { setOrdInflowService } from  '../salesPMO/service/index.js';
import {
  _triggerWithoutCamundaWorkflow,
  _stageCompleteUpdate,
} from '../../../woi/workflowTrigger.js';
import { stage600FileEntry } from '../../../../customers/springerBooks/controller/index.js';
import logger from '../../../utils/logs/index.js';
import { _sendCampusSignal } from '../../../woi/woAutocreation.js';
import { latexGraphicsCopy } from '../../../utils/filecopy/index.js';

export const savePreProcess = async (req, res, action) => {
  let response = { status: true, message: '' };
  const {
    toolRunningStatus,
    activityName,
    userId,
    wfeventId,
    postActivity,
    filesInfo,
    woIncomingFileId,
    workorderId,
    toolIds,
    MandatoryToolIds,
  } = req.body;
  // capture user event
  const payload = {
    userId,
    wfeventId,
    actionType: 'Save',
  };
  preProcess(req, payload);
  try {
    // checking this activity have post save validation
    let isGraphic = false;
    if (postActivity.length && woIncomingFileId) {
      const sql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingfileid = ${woIncomingFileId}`;
      const checkImageCount = await query(sql);
      if (checkImageCount.length > 0 && checkImageCount[0].imagecount > 0) {
        isGraphic = true;
      }
    } else if (postActivity.length && !woIncomingFileId) {
      const sql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingid = (select woincomingid from wms_workorder_incoming where woid = ${workorderId}) and filetypeid != 1`;
      const checkImageCount = await query(sql);
      if (checkImageCount.length) {
        checkImageCount.forEach(item => {
          if (item.imagecount > 0) {
            isGraphic = true;
          }
        });
      }
    }

    if (isGraphic) {
      const postSaveValidRes = await postSaveValidation(req.body);
    }
    // checking for tools running status
    if (toolRunningStatus) {
      const result = await validateToolsRunningStatus(req);
      response = result;
    }
    // Checking open quaries
    if (activityName == 'Despatch') {
      const result = await validateOpenQuery(req, res);
      response = result;
    }

    //
    await isACSErrorHandledFile(req);
    await isElsevierProblemTaskFile(req);
    await validateFiles(req, res, action);
    await validateMandatoryTool(wfeventId, MandatoryToolIds);

    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const _savePreProcess = async (req, payload) => {
  await _captureUserEvent(req, payload);
};
export const _savePostProcess = async (req, payload) => {
  await _captureUserEvent(req, payload);
  await _prepubWorkflowUpdate(req);
  // await need to handle prepub
};

export const saveProcess = async (req, res) => {
  const {
    userid,
    wfeventId,
    workorderId,
    woType,
    duId,
    // eslint-disable-next-line no-unused-vars
    customerId,
    wfId,
    activityId,
    stageId,
    filesInfo,
    camundaVariable,
    toolIds,
    isIssueTrigger,
    onsaveToolIds,
    issuemstid,
    wfdefid,
    iscamundaflow,
    MandatoryToolIds,
    runonFileSequence,
    isUpdPkgReceived = false,
    updPkgId,
    currentActivityRemarks = false,
    qualityRemarks = false,
    stageIterationCount,
    actualActivityCount,
    isLatexGraphicsCopy = false,
  } = req.body;
  try {
    req.body.actionType = 'Save';
    // FTP upload check
    await validateFtpUpload(wfeventId, toolIds, onsaveToolIds);
    // vaithi - need to include validation
    // await isACSErrorHandledFile(workorderId,stageId);

    req.body.dmsType = await getdmsType(workorderId);
    const isItracksAPI = await checkItracksExits(req, res, true);
    console.log(isItracksAPI, 'isItracksAPI');
    req.body.isEngineReassign = camundaVariable?.__isEnableEngine__?.value;

    if (activityId === '22' && stageId === '5' && duId === '5') {
      const pkgFileInfo = filesInfo
        .pop()
        .files.filter(fname => fname.path.includes('.zip'));
      const wfdata = {
        body: {
          workflowID: wfId,
          stageID: stageId,
          activityID: activityId,
        },
      };
      const wfDefInfo = await ActConfigDetails(wfdata);
      const wfDefconfigInfo = wfDefInfo.data[0];
      console.log(wfDefconfigInfo, 'wfDefconfigInfo');
      //  if(activityId === '22' && stageId === '5' && duId === '5'){
      if (
        pkgFileInfo.length > 0 &&
        wfDefconfigInfo.config &&
        wfDefconfigInfo.config.isApiDespatch
      ) {
        const sendPkgtoApi = await pkgDepositTrigger(pkgFileInfo[0], req.body);
        console.log(sendPkgtoApi, 'sendPkgtoApi');
      }
    }
    // eslint-disable-next-line prefer-const
    let { status, isProduction, isCustomer } = isItracksAPI;
    const responseValue = [];
    let overAllFiles = [];
    let batchInfo = [];
    const awts = [];
    let singleBookRunOn = true;

    if (
      req.body.activitymodeltypeflow &&
      req.body.activitymodeltypeflow == 'Batch'
    ) {
      const issuePayload = {
        issuemstid,
        wfDefId: wfdefid,
        workorderid: workorderId,
      };
      batchInfo = await _getIssueWorkorderInfo(issuePayload);
      overAllFiles = batchInfo;
      if (iscamundaflow) {
        overAllFiles = batchInfo.filter(list => list.taskinstanceid !== null);
      }
      req.body.isNewFileTrigger = false;
    } else if (
      req.body.activitymodeltypeflow &&
      req.body.activitymodeltypeflow == 'Partial' &&
      req.body.isOtherArticle &&
      req.body.articleOrderSequence != null
    ) {
      const data = {
        workOrderId: workorderId,
        wfDefId: req.body.wfdefid,
        fileTypeId: req.body.fileTypeId,
        articleOrderSequence: req.body.articleOrderSequence,
      };
      overAllFiles = await _getPartialNonArticleDetailsWithArticleOrderSequence(
        data,
      );
      if (overAllFiles.length < 1) {
        singleBookRunOn = false;
      }
      req.body.isNewFileTrigger = false;
    } else if (
      req.body.activitymodeltypeflow &&
      req.body.activitymodeltypeflow == 'Partial' &&
      req.body.isOtherArticle
    ) {
      const data = {
        workOrderId: workorderId,
        wfDefId: req.body.wfdefid,
        fileTypeId: req.body.fileTypeId,
      };
      overAllFiles = await _getPartialNonArticleDetails(data);
      req.body.isNewFileTrigger = false;
    } else if (runonFileSequence) {
      const issuePayload = {
        issuemstid,
        wfDefId: wfdefid,
        workorderid: workorderId,
        runonFileSequence,
      };
      batchInfo = await _getIssueWorkorderInfo(issuePayload);
      overAllFiles = batchInfo;
    } else {
      overAllFiles = [req.body];
    }
    for (let k = 0; k < overAllFiles.length; k++) {
      const value = overAllFiles[k];
      req.body.workorderId = value.workorderid || req.body.workorderId;
      req.body.taskInstanceId = value.taskinstanceid || req.body.taskInstanceId;
      req.body.wfeventId = value.wfeventid || req.body.wfeventId;
      req.body.activityLength = overAllFiles.length;
      req.body.loopIndex = k;
      if (status) {
        const iStageId = await getiTracksStageId(req.body);
        const iActivityId = await getiTracksActivityId(req.body);

        if (woType === 'Book') {
          const iSubjobIds = await getSubjobIds(req.body);
          console.log(iSubjobIds, 'iSubjobIds');

          if (iStageId && iActivityId && iSubjobIds.length) {
            req.body.iStageId = iStageId;
            req.body.iActivityId = iActivityId;
            req.body.subjobArray = iSubjobIds;
            const isEntryUpdate = await logisticEntryUpdate(
              req.body,
              isProduction,
              isCustomer,
              1,
              'save',
            );
            const { status: stat, Result } = isEntryUpdate;
            console.log(isEntryUpdate, 'isEntryUpdate');
            console.log(stat, 'status');
            console.log(Result, 'Result');
            // if (stat) {
            // need to handle save the loop
            awts.push(
              await completeCamundaTask(req, res)
                .then(async response => {
                  emitAction(actions.wfSaved);

                  responseValue.push(response);
                  // res.status(200).send({ message: response });
                  // capture user event
                  const payload = {
                    userId: userid,
                    wfeventId,
                    actionType: 'Save',
                  };
                  postProcess(req, payload);
                })
                .catch(e => {
                  res.status(400).send({ message: e });
                }),
            );
            // new itrack productivity integration
            await checkitrackIntegration(req.body, 'wms');
            // } else {
            //   res.status(400).send({ message: Result });
            // }
          } else {
            res.status(400).send({
              status: false,
              message:
                'iTracks stageid / activityid / subjobid not fount in iWMS',
            });
          }
        } else {
          console.log('inside journal logistic update');

          if (iStageId && iActivityId) {
            req.body.iStageId = iStageId;
            req.body.iActivityId = iActivityId;
            const isEntryUpdate = await logisticEntryUpdateJournal(
              req.body,
              isProduction,
              isCustomer,
              1,
              'save',
            );
            const { status: stat, Result } = isEntryUpdate;
            console.log(isEntryUpdate, 'isEntryUpdate');
            if (stat) {
              awts.push(
                completeCamundaTask(req, res)
                  .then(async response => {
                    emitAction(actions.wfSaved);
                    responseValue.push(response);

                    // res.status(200).send({ message: response });
                    // capture user event
                    const payload = {
                      userId: userid,
                      wfeventId,
                      actionType: 'Save',
                    };
                    postProcess(req, payload);
                  })
                  .catch(e => {
                    res.status(400).send({ message: e });
                  }),
              );
              // new itrack productivity calculation
              await checkitrackIntegration(req.body, 'wms');
            } else {
              res.status(400).send({ message: Result });
            }
          } else {
            res.status(400).send({
              status: false,
              message: 'iTracks stageid / activityid not fount in iWMS',
            });
          }
        }
      } else {
        if (req.body.isEngineReassign) {
        } else {
          const isTrigger = await iTracksDistapchCall(req, res);
        }
        awts.push(
          await completeCamundaTask(req, res)
            .then(async response => {
              emitAction(actions.wfSaved);
              responseValue.push(response);

              // res.status(200).send({ message: response, iTracksSuccess: false });
              // capture user event
              const payload = {
                userId: userid,
                wfeventId,
                actionType: 'Save',
              };
              postProcess(req, payload);
            })
            .catch(e => {
              res.status(400).send({ message: e, iTracksSuccess: false });
            }),
        );
        // new itrack productivity calculation
        await checkitrackIntegration(req.body, 'wms');
      }
    }
    await Promise.all(awts);
    // need to be handled skip toc file for kli
    if (req.body.isTOCTrigger && req.body.wfId == 32) {
      const tocInfo = batchInfo.filter(list => list.taskinstanceid == null);
      const payload = {
        wfId: req.body.wfId,
        workorderid: tocInfo[0].workorderid,
        instancecode: req.body.instancecode,
        instancetype: req.body.instancetype,
      };
      await tocFileEnableE2E(payload);
    }
    if (isLatexGraphicsCopy) {
      await latexGraphicsCopy({ duId, customerId, wfeventId });
    }
    if (isUpdPkgReceived) {
      const sql = `UPDATE public.trn_updatedrequest set activityid = array_append(activityid, $1), updatedon=current_timestamp, updatedby=$2 WHERE id=$3;`;
      await query(sql, [activityId, userid, updPkgId]);
    }
    if (currentActivityRemarks) {
      const sql = `UPDATE public.wms_workflow_eventlog_details
                  SET usercomments = $1
                  WHERE wfeventdetailid = (
                        SELECT wfeventdetailid
                        FROM public.wms_workflow_eventlog_details
                        WHERE operationtype = 'Completed'
                          AND wfeventid = $2
                        ORDER BY wfeventdetailid DESC
                        LIMIT 1
                    );`;
      await query(sql, [currentActivityRemarks, wfeventId]);
    }
    if (qualityRemarks) {
      const sql = `INSERT INTO public.trn_quality_remarks (workorderid, stageid, stageiterationcount, activityid, activityiterationcount, remarks, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7);`;
      await query(sql, [
        workorderId,
        stageId,
        stageIterationCount,
        activityId,
        actualActivityCount,
        qualityRemarks,
        userid,
      ]);
    }
    res.status(200).send({ message: responseValue, iTracksSuccess: false });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const reassignTaskComplete = async (req, res) => {
  await completeCamundaTask(req, res)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      res.status(400).send(e.message ? e.message : e);
    });
};
export const updateWorkOrderStatus = async (req, res) => {
  try {
    const { woId, wfDefid, wfeventid, stageId, serviceId } = req.body;

    let sql = `UPDATE wms_workflow_eventlog SET activitystatus = $1 ,remark = $4 WHERE workorderid = $2 AND wfdefid = $3`;
    await query(sql, [
      'Completed',
      woId,
      wfDefid,
      'Cannot Finish request sent to customer.',
    ]);

    sql = `UPDATE wms_workflow_eventlog_details SET operationtype = $1 WHERE wfeventid = $2`;
    await query(sql, ['Completed', wfeventid]);

    sql = `UPDATE wms_workorder_stage SET status = $1 WHERE workorderid =  $2 and wfstageid= $3`;
    await query(sql, ['Completed', woId, stageId]);

    sql = `UPDATE wms_workorder_service SET status = $1 WHERE workorderid =  $2 and serviceid= $3`;
    await query(sql, ['Completed', woId, serviceId]);

    sql = `UPDATE wms_workorder SET status = $1 WHERE workorderid = $2`;
    await query(sql, ['Completed', woId]);

    res.status(200).send({
      message: 'Cannot Finish request has been sent to customer.',
      isSuccess: true,
    });
  } catch (err) {
    console.error('Error in updateWorkOrderStatus:', err);
    res.status(400).send({
      message: 'Error updating status for Cannot Finish request.',
      error: err.message,
    });
  }
};
export const ftpCompleteTask = async (req, res) => {
  const { itemcode } = req.body;
  const sql = `select * from wms_workorder as wo
  join wms_workorder_service as service on service.workorderid = wo.workorderid
  join wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid
  join wms_mst_stage as stage on stage.stageid = wostage.wfstageid
  where wo.itemcode = '${itemcode}' and wostage.status = 'In Process' and wostage.wfstageid != 10
  `;
  const getWorkorder = await query(sql);
  if (getWorkorder.length > 0) {
    req.body.du = getWorkorder[0].assignedduid;
    req.body.workorderId = getWorkorder[0].workorderid;

    const sql1 = `SELECT * FROM public.wms_workflow_eventlog  as eventlog
    join wms_workflowdefinition as wf on wf.wfdefid  = eventlog.wfdefid
    where eventlog.workorderid = ${getWorkorder[0].workorderid} and eventlog.wfdefid in (1449,1553,1435,1420,1265) and eventlog.activitystatus = 'Unassigned'
    order by 1 desc`;
    const getEventDetails = await query(sql1);
    if (getEventDetails.length > 0) {
      req.body.userId = 'IS8224';
      req.body.wfeventId = getEventDetails[0].wfeventid;
      req.body.taskInstanceId = getEventDetails[0].taskinstanceid;
      req.body.uomId = '';
      req.body.noOfPages = 0;
      req.body.isRejectHandlingTask = '';
      req.body.stageName = getWorkorder[0].stagename;
      req.body.stageDuedate = '';
      req.body.entityId = '';
      req.body.serviceId = '';
      req.body.wfdefid = getEventDetails[0].wfdefid;
      req.body.iterationCount = getEventDetails[0].activityiterationcount;
      req.body.stageId = getWorkorder[0].stageid;
      req.body.wfId = getEventDetails[0].wfid;
      req.body.activityAlias = getEventDetails[0].activityalias;
      req.body.checklist = [];
      req.body.camundaVariable = {};
      req.body.taskType = getEventDetails[0].activitytype;
      req.body.incomingFileId = getEventDetails[0].woincomingfileid;
      req.body.isNewFileTrigger = false;
      req.body.actualActivityCount = getEventDetails[0].actualactivitycount;
      req.body.actionType = 'Save';
      req.body.isEngineReassign = false;
      req.body.issuemstid = '';
      req.body.customerId = getWorkorder[0].customerid;
      req.body.activityId = getEventDetails[0].activityid;
      req.body.fc_orderinflow = '';
      req.body.fc_unbilledrevenue = '';
      req.body.fc_invoice = '';
      req.body.autocomplete = true;
      req.body.iscamundaflow = true;
      await completeCamundaTask(req, res)
        .then(() => {
          res.status(200).send(true);
        })
        .catch(e => {
          res.status(400).send(e.message ? e.message : e);
        });
    } else {
      res.status(200).send({ data: 'No Data Found!' });
    }
  } else {
    res.status(200).send({ data: 'No Data Found!' });
  }
};
export const completeCamundaTask = (req, res) => {
  const {
    du,
    wfeventId,
    userId,
    taskInstanceId,
    uomId,
    noOfPages,
    isRejectHandlingTask,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
    stageId,
    wfId,
    activityAlias,
    checklist,
    camundaVariable,
    taskType,
    incomingFileId,
    isNewFileTrigger,
    actualActivityCount,
    actionType,
    isEngineReassign,
    issuemstid,
    customerId,
    activityId,
    fc_orderinflow,
    fc_unbilledrevenue,
    fc_invoice,
    fc_ubrcalctype,
    iscamundaflow,
    stageIterationCount,
    woIncomingFileId,
    // fc_oifcalctype,
    // fc_ubrcalctype,
    // fc_invoicecalctype,
    activitymodeltypeflow,
    activityLength,
    loopIndex,
    filetypeskipfornextactivity,
    pdfless,
    parallelStageConfig,
    indexcorrectionid,
    parallelFileTypeSkipForNextActivity,
    fileTypeId,
    otherfield,
    isCmapusSignal,
  } = req.body;
  let { nextactivityid } = req.body;
  let { parallelActivityConfig } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      // let isNewFileTrigger = (wfId == '18' && stageId == '1' && activityId == '1') ? true : false;
      let msg = 'Task has been completed successfully';
      let stage = {};
      const files = [];
      console.log(isNewFileTrigger, 'isNewFileTrigger');
      let oldArrayFiles = [];

      if (isNewFileTrigger) {
        stage = {
          type: stageName.toLowerCase().replace(/ /g, '_'),
          iteration: iterationCount,
        };
        const sql = `SELECT woincomingfileid,filename,pp_mst_filetype.filetype,allowsubfiletype FROM public.wms_workorder_incoming 
                JOIN public.wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
                JOIN public.pp_mst_filetype ON pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
                WHERE wms_workorder_incoming.woid = ${workorderId}`;
        const getFiles = await query(sql);
        getFiles.forEach(item => {
          if (item.allowsubfiletype) {
            files.push({
              id: item.woincomingfileid,
              name: item.filename,
              type: item.filetype,
            });
          }
        });
      }
      const sql1 = `SELECT * FROM public.wms_workflow_eventlog where workorderid = ${workorderId} and wfdefid=778`;
      oldArrayFiles = await query(sql1);

      camundaVariable.__isEnableForFirstIteration__ = {
        value: !(oldArrayFiles.length > 0),
        type: 'Boolean',
      };
      // springer books - stage 200 - enable qc activity only for first time - wo creation isEnableFirstTime set to true
      if (
        req.body.config &&
        Object.keys(req.body.config).includes('skipAfterFirstActivity') &&
        req.body.config.skipAfterFirstActivity
      ) {
        const isEnable = req.body.config.skipAfterFirstActivity == activityId;
        camundaVariable.__isEnableFirstTime__ = {
          value: !isEnable,
          type: 'Boolean',
        };
      }
      camundaVariable.__isActivityiteration__ = {
        value: actualActivityCount,
        type: 'String',
      };
      const payload = {
        taskId: `${taskInstanceId}`,
        variables: isRejectHandlingTask
          ? { ...camundaVariable, ...getRejectedVariables(false) }
          : isNewFileTrigger
          ? { ...camundaVariable, ...getBWStageVariables(stage, files) }
          : camundaVariable,
      };

      console.log(payload, 'payload payload');
      await transaction(async client => {
        const tempObj = {
          checklist: checklist.length ? checklist[0].instructions : [],
        };
        console.log(JSON.stringify(tempObj), 'dfdfd');
        let sql = `UPDATE wms_workflow_eventlog SET userid=coalesce($4, userid), activitystatus =$1,checklist=$3 WHERE wfeventid = $2 `;
        await client.query(sql, [
          'Completed',
          wfeventId,
          `${JSON.stringify(tempObj)}`,
          userId,
        ]);
        // entry for report
        sql = `SELECT timestamp FROM wms_workflow_eventlog_details WHERE wfeventid =$1 AND userid=$2
                AND (operationtype =$3 OR operationtype =$4 OR operationtype =$5) ORDER BY wfeventdetailid DESC LIMIT 1`;
        const { rows } = await client.query(sql, [
          wfeventId,
          userId,
          'Work in progress',
          'Hold',
          'Pending',
        ]);

        if (rows.length > 0) {
          const data = {
            duId: du,
            userId,
            wfeventId,
            timestamp: rows[0].timestamp,
            uomValue: noOfPages,
            activityAlias,
          };

          await createReportView(client, data);
        }

        if (taskType === 'Multiple') {
          if (incomingFileId) {
            sql = `UPDATE wms_workorder_incomingfiledetails set uomvalue= ${noOfPages} WHERE woincomingfileid IN (${incomingFileId})`;
            console.log(sql, 'sql for uom update');
            await client.query(sql);
          }
        } else if (noOfPages) {
          sql = `UPDATE wms_workorder set uom= ${noOfPages} WHERE workorderid = ${workorderId}`;
          console.log(sql, 'sql for uom update on WO');
          await client.query(sql);
        }
        // to be check with team
        // if (
        //   Object.keys(req.body).includes('autocomplete') &&
        //   !req.body.autocomplete
        // ) {
        if (!req.body?.autocomplete) {
          const systemInfo = {
            systemIP: requestIp.getClientIp(req),
            publicIP:
              req.headers['x-forwarded-for'] || req.connection.remoteAddress,
            ...JSON.parse(req.headers.systemdetail),
          };
          sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid,uomid,uomvalue, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`;
          await client.query(sql, [
            wfeventId,
            'Completed',
            new Date(),
            userId,
            uomId,
            noOfPages,
            systemInfo,
            actualActivityCount,
          ]);
        }
        if (
          du == '92' &&
          (stageId == '24' || stageId == '10') &&
          activityAlias.toLowerCase() == 'despatch'
        ) {
          sql = `update public.wms_workorder_stage set enddatetime = $1 ,status = $2 where workorderid = $3 and wfstageid = $4 and stageiterationcount = $5;`;
          await client.query(sql, [
            new Date(),
            'Completed',
            workorderId,
            +stageId,
            iterationCount,
          ]);
        }
      });
      let _nextActivityType = '';
      if (iscamundaflow) {
        logger.info('--complete camunda Task process Started--', payload);
        await completeTask(payload);
      } else if (nextactivityid) {
        // Below for next activity trigger without camunda flow

        // specific for elsevier journals cas flow supplimentary flow
        // if (wfId == 43 && stageId == 92 && activityId == 403) {
        //   if (
        //     otherfield?.suppliment !== undefined &&
        //     otherfield.suppliment == 0
        //   ) {
        //     nextactivityid = '192';
        //   }
        // }
        // specific for elsevier journals cas flow rerouted flow
        if (wfId == 43 && stageId == 102 && activityId == 1) {
          if (
            otherfield?.is_re_routed !== undefined &&
            otherfield?.is_re_routed == 'no'
          ) {
            nextactivityid = '445';
          }
        }
        let isTriggerNext = true;
        let fileId = woIncomingFileId;
        if (activitymodeltypeflow === 'Batch') {
          isTriggerNext = activityLength - 1 == loopIndex;
          fileId = null;
        } else {
          const { status, nextActivityType } =
            await checkAllSigngleActivityCompleted(
              workorderId,
              wfdefid,
              nextactivityid,
              wfId,
              filetypeskipfornextactivity,
              stageId,
              fileTypeId,
            );
          isTriggerNext = status;
          fileId = nextActivityType === 'Batch' ? null : woIncomingFileId;
        }
        if (isTriggerNext) {
          const startPayload = {
            wfId,
            workorderId,
            stageId,
            stageIteration: stageIterationCount,
            serviceId,
            actionFlow: 'next',
            currentActivityId: activityId,
            activityId: nextactivityid,
            woIncomingFileId: fileId,
            filetypeSkip: filetypeskipfornextactivity,
            pdfless,
            indexcorrectionid,
          };
          await _triggerWithoutCamundaWorkflow(startPayload);
        }

        if (parallelActivityConfig && parallelActivityConfig.length) {
          // Below for parallel next activity trigger without camunda flow

          //Elsevier Checking Supplementary skip logic if supplement is <= 0 For Assessent
          if (wfId == 43 && stageId == 123 && activityId == 561) {
            if (otherfield?.suppliment <= 0) {
              parallelActivityConfig = [];
            }
          }
          const promises = parallelActivityConfig.map(
            async parallelactivityid => {
              let isTriggerNext = true;
              let fileId = woIncomingFileId;

              if (activitymodeltypeflow === 'Batch') {
                isTriggerNext = activityLength - 1 === loopIndex;
                fileId = null;
              } else {
                const { status, nextActivityType } =
                  await checkAllSigngleActivityCompleted(
                    workorderId,
                    wfdefid,
                    parallelactivityid,
                    wfId,
                    parallelFileTypeSkipForNextActivity,
                    stageId,
                    fileTypeId,
                  );

                isTriggerNext = status;
                fileId = nextActivityType === 'Batch' ? null : woIncomingFileId;
              }

              if (isTriggerNext) {
                const startPayload = {
                  wfId,
                  workorderId,
                  stageId,
                  stageIteration: stageIterationCount,
                  serviceId,
                  actionFlow: 'next',
                  currentActivityId: activityId,
                  activityId: parallelactivityid,
                  woIncomingFileId: fileId,
                  filetypeSkip: parallelFileTypeSkipForNextActivity,
                  pdfless,
                  indexcorrectionid,
                };
                await _triggerWithoutCamundaWorkflow(startPayload);
              }
            },
          );
          await Promise.all(promises);
        }
      } else if (!iscamundaflow && !nextactivityid) {
        // status update for stage in last activity of the stage
        await _stageCompleteUpdate({ workorderId, stageId, wfId, activityId });
      }

      let triggerRes = true;
      if (
        req.body.isIssueTrigger == undefined ||
        req.body.isIssueTrigger == null ||
        req.body.isIssueTrigger == false
      ) {
        if (iscamundaflow) {
          triggerRes = await triggerMailAndNextStage(
            req,
            res,
            actionType,
            isEngineReassign,
          );
        } else {
          let isTriggerNext = true;
          let fileId = woIncomingFileId;
          if (activitymodeltypeflow === 'Batch') {
            isTriggerNext = activityLength - 1 == loopIndex;
            fileId = null;
          } else {
            isTriggerNext = true;
          }
          if (isTriggerNext) {
            triggerRes = await triggerMailAndNextStage(
              req,
              res,
              actionType,
              isEngineReassign,
            );
          }
        }
      }
      if (!triggerRes) {
        msg =
          'Task has been completed successfully, but mail / next stage trigger failed, Please contact admin';
      }
      // parallel stage enable
      if (wfId == 48 && pdfless != 'undefined' && pdfless != 'null') {
        if (
          parallelStageConfig &&
          parallelStageConfig.length > 0 &&
          parseInt(pdfless) == 0
        ) {
          const { status, nextActivityType } =
            await checkAllSigngleActivityCompleted(
              workorderId,
              wfdefid,
              nextactivityid,
              wfId,
              filetypeskipfornextactivity,
              stageId,
            );

          let fileId = nextActivityType === 'Batch' ? null : woIncomingFileId;
          const Payload = {
            wfId,
            workorderId,
            stageId,
            serviceId,
            parallelStageConfig,
            woIncomingFileId: fileId,
            actionFlow: 'trigger',
            currentActivityId: activityId,
            activityId: null,
          };
          const result = await paralleStageConfigEnable(Payload);
        }
      } else if (wfId == 43) {
        if (parallelStageConfig && parallelStageConfig.length > 0) {
          // specific for elsevier journals cas flow supplimentery flow
          if (stageId == 102) {
            nextactivityid = 555;
            if (
              otherfield?.suppliment !== undefined &&
              otherfield.suppliment == 0
            ) {
              nextactivityid = null;
            }
          }
          if (nextactivityid) {
            const { status, nextActivityType } =
              await checkAllSigngleActivityCompleted(
                workorderId,
                wfdefid,
                nextactivityid,
                wfId,
                filetypeskipfornextactivity,
                stageId,
              );

            let fileId = nextActivityType === 'Batch' ? null : woIncomingFileId;
            const Payload = {
              wfId,
              workorderId,
              stageId,
              serviceId,
              parallelStageConfig,
              woIncomingFileId: fileId,
              actionFlow: 'next',
              currentActivityId: activityId,
              activityId: nextactivityid,
            };
            const result = await paralleStageConfigEnable(Payload);
          }
        }
      }

      /// / New-iTrack financial process
      try {
        /// / New-iTrack financial process
        if (fc_orderinflow != undefined && fc_orderinflow == true) {
          await setOrdInflowService(req.body);
        }
        if (fc_unbilledrevenue != undefined && fc_unbilledrevenue == true) {
          if (
            fc_ubrcalctype.toLowerCase() == 'initial' ||
            fc_ubrcalctype.toLowerCase() == 'both'
          ) {
            req.body.servicetype = 'initialstagearticle';
            await ubrIntegrationService(req.body);
          }
          if (
            fc_ubrcalctype.toLowerCase() == 'dispatch' ||
            fc_ubrcalctype.toLowerCase() == 'both'
          ) {
            req.body.servicetype = 'dispatchstagearticle';
            await ubrIntegrationService(req.body);
          }
          // await ubrIntegrationService(req.body);
        }
        if (fc_invoice != undefined && fc_invoice == true) {
          await invoiceIntegrationService(req.body);
        }
      } catch (e) {
        console.log('error', e);
      }

      //To send cup journals campus acknowledgement signal start
      if (wfId == 25) {
        let isValidSignal = isCmapusSignal;
        if (stageName == 'Incoming Inspection' && isCmapusSignal) {
          const caseCheck = `select otherdetails ::json ->>'suplimentary' as suplimentary  from wms_workorder_incomingfiledetails
where woincomingfileid =${incomingFileId}`;
          let dataCase = await query(caseCheck);
          isValidSignal =
            dataCase &&
            dataCase.length > 0 &&
            dataCase?.[0]?.suplimentary == 'false'
              ? true
              : false;
        }
        if (isValidSignal) {
          const campusQuery = `SELECT wms_mst_stage.stagename,pp_mst_journal.journalid,pp_mst_journal.otherdetails ->> 'isSignal' AS iscampustrigger,
      wms_workflow_eventlog.stageiterationcount,wms_workflow_eventlog.wfdefid
      FROM wms_workorder 
      JOIN pp_mst_journal ON wms_workorder.journalid = pp_mst_journal.journalid 
      JOIN wms_workflow_eventlog on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
      JOIN wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid and issignal = true
      JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
      where wfeventid = ${wfeventId}`;

          let flowType;

          if (stageName === 'Revises' && activityAlias === 'PM Review') {
            flowType = 'static';
          } else if (
            stageName === 'Revises' &&
            activityAlias === 'FQA Cross Checking'
          ) {
            flowType = 'meta';
          } else {
            flowType = 'activity';
          }

          const response = await query(campusQuery);
          if (
            response &&
            response.length > 0 &&
            response[0].iscampustrigger === 'true'
          ) {
            // Trigger Campus Signal
            const signalPayload = {
              workorderId: workorderId,
              stageName: response[0].stagename,
              stageIteration: response[0].stageiterationcount,
              payloadType: 'dynamicPayload',
              flowType: flowType,
              isPagecount: false,
              isRound: false,
            };
            const campRes = await _sendCampusSignal(signalPayload);
            console.log(campRes, 'campRes');
          } else {
            logger.info('--Campus signal skipped due to response not found --');
          }
        }
      }
      //To send campus acknowledgement signal end

      resolve(msg);
    } catch (e) {
      if (e?.message?.data?.data) {
        // This is used to checkThis is wrong. need to get proper error msg from camunda layer
        reject(e.message.data.data);
      }
    }
  });
};

export const triggerMailAndNextStage = async (
  req,
  res,
  actionType,
  isEngineReassign,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        du,
        workorderId,
        stageDuedate,
        entityId,
        serviceId,
        wfdefid,
        iterationCount,
        stageId,
        stageName,
        wfId,
        wfeventId,
        customerId,
        activityId,
        journalacronym,
        issuename,
        jobId,
        userid,
      } = req.body;
      if (actionType == 'Save') {
        // mail trigger
        const data = {
          duId: du,
          entityId,
          workorderId,
          serviceId,
          wfdefid,
          stageName,
          iteration: iterationCount,
          stageDuedate,
          stageId,
          wfId,
          wfeventId,
          journalName: journalacronym || '',
          issueName: issuename || '',
          lstArticle: jobId,
          userName: userid,
        };
        const mailStatus = await getWorkflowConfig(data, 'save');

        // call for next stage transfer check and trigger
        if (isEngineReassign) {
          console.log(
            'next stage transfer not trigger - engine reassign',
            wfeventId,
          );
        } else {
          let nextStageTransfer = '';
          // to be handled from config - check for copyediting dispatch trigger for WKH specific
          if (customerId == '13' && stageId == '24' && activityId == '137') {
            const variables = await getCamundaVariableWithValue(workorderId);
            const checkCopyEditingDispatch =
              variables.__isCopyEditingDespatchNeeded__;
            if (!checkCopyEditingDispatch) {
              nextStageTransfer = await _nextStageTransferCheckTrigger(
                req,
                res,
              );
            }
          } else {
            nextStageTransfer = await _nextStageTransferCheckTrigger(req, res);
          }
          // estimated page update
          await calculateEstimatedPage(stageId, workorderId);
        }
      }
      resolve(true);
    } catch (e) {
      resolve(false);
    }
  });
};

const getCamundaVariableWithValue = workerId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select eventdata->'variables' as variables from wms_workflow_eventlog where workorderid = ${workerId}
      order by wfeventid desc limit 1`;
      const result = await query(sql);
      resolve(result.length ? result[0].variables : {});
    } catch (e) {
      reject(e);
    }
  });
};

export const _nextStageTransferCheckTrigger = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    try {
      let {
        actionType,
        workorderId,
        serviceId,
        stageId,
        stageIterationCount,
        activityId,
        pmUserId,
        iscamundaflow,
        activityName,
        activitymodeltypeflow,
        indexcorrectionid,
      } = req.body;

      const addeddate = new Date();

      addeddate.setHours(addeddate.getHours() + 5);
      addeddate.setMinutes(addeddate.getMinutes() + 30);

      const todaydatetime = convertDateFormat(addeddate);

      // get the task details
      let sql = `select wfid,duid,customerid,workorderid,itemcode,serviceid,servicename,wotype,stageid,stagename,stageiterationcount,activityid,wfeventid, 
      actualactivitycount, duedate, enableautostagetrnsf, activitystatus, instancetype, jobcardid, userid,otherdetails,config
      from wms_tasklist where workorderid=$1 and stageid=$2 and activityid=$3 and stageiterationcount=$4 and updated_date is not null order by updated_date desc limit 1`;
      const taskInfo = await query(sql, [
        workorderId,
        stageId,
        activityId,
        stageIterationCount,
      ]);

      const {
        activitystatus,
        wfid: wfId,
        duid: duId,
        customerid: customerId,
        servicename: serviceName,
        stagename: stageName,
        wotype: woType,
        wfeventid: wfeventId,
        duedate,
        actualactivitycount: actualActivityCount,
        instancetype: taskType,
        jobcardid: jobCardId,
        userid: userId,
        itemcode: jobId,
        otherdetails,
        config,
      } = taskInfo.length ? taskInfo[0] : {};

      let enableautostagetrnsf = taskInfo.length
        ? taskInfo?.[0]?.enableautostagetrnsf
        : false;
      if (
        otherdetails &&
        otherdetails?.isSkipPAP &&
        config?.actions?.workflow?.save?.capture?.isSkipPAP
      ) {
        enableautostagetrnsf = true;
      }

      if (enableautostagetrnsf && activitystatus === 'Completed') {
        const iPayload = {
          stageId,
          wfId,
          stageIterationCount,
          activityId,
          actualActivityCount,
          customerId,
          duId,
          wfeventId,
          wfeventid: wfeventId,
          workorderId,
          taskType,
          jobCardId,
          userId: userId || pmUserId || 'System',
          userid: userId || pmUserId || 'System',
          jobId,
        };
        req.body = { ...req.body, ...iPayload };
        // itracks dispatch - trigger only from engine activity
        if (actionType === 'Save') {
        } else {
          await iTracksDistapchCall(req, res);
        }
        // get the files info
        sql = `select * from wms_workorder_incomingfiledetails where woincomingid in (select woincomingid from wms_workorder_incoming where woid=$1)`;
        let getFilesInfo = await query(sql, [workorderId]);

        let filesInfo = getFilesInfo.length ? getFilesInfo : [];

        // fetch workorder details
        sql = `
              select
              itemcode,
              isonlineissue,
              wotype,
              wms_workorder_service.wfid,
              isiauthor,
              case
              WHEN fawc.package <> 'ST' AND  wms_workorder.celevelid >1 then true
              else false
              end as iscopyeditingworkflow,
              otherfield ,
              pp_mst_journal.newsletter as isnewsletter ,CASE 
              WHEN fawc.package = 'PR' THEN (otherdetails ->> 'istranche') 
              ELSE false ::TEXT 
              END AS istranche,
              pp_mst_journal.cereview as cereview,
              otherfield ->>'isrevises' as isrevises,
              wms_book_master.workflow as workflow,fawc.package,
              CASE 
        WHEN (pp_mst_journal.otherdetails ->> 'isPapAEnable') IS NOT NULL 
        THEN (pp_mst_journal.otherdetails ->> 'isPapAEnable')::BOOLEAN::TEXT 
        ELSE 'false' 
    END AS ispapAenable
              from
              wms_workorder
              join wms_workorder_service on
              wms_workorder_service.workorderid = wms_workorder.workorderid
              left join pp_mst_journal on
              pp_mst_journal.journalid = wms_workorder.journalid
              left join wms_book_master on
              wms_workorder.bookid = wms_book_master.id
              left join lateral (
              select 
              get_ftp_filename (wms_workorder.workorderid::int) as package
              ) as fawc on
              true
              where
              wms_workorder.workorderid = $1`;
        // to be deleted
        // changed for springer journal ce level value to take from workorder.

        // sql = `select itemcode, wotype, wms_workorder_service.wfid, isiauthor,
        // case when wms_workorder.customerid = 10 then
        // case when wms_workorder.celevelid  >1  then true else false  end
        // when wms_workorder.customerid != 10 then
        // case when pp_mst_journal.celevelid  >1  then true else false end
        // end as iscopyeditingworkflow
        // from wms_workorder
        //         join wms_workorder_service on wms_workorder_service.workorderid = wms_workorder.workorderid
        //         join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
        //         where wms_workorder.workorderid=$1`;
        const workOrderDetails = await query(sql, [workorderId]);
        const {
          wotype,
          itemcode,
          wfid,
          isiauthor,
          iscopyeditingworkflow,
          otherfield,
          isonlineissue,
          isnewsletter,
          istranche,
          cereview,
          isrevises,
          workflow,
          ispapaenable,
        } = workOrderDetails[0];

        let flowType = ['isgeneral'];
        if (isiauthor) {
          flowType.push('isiauthor');
        }
        if (iscopyeditingworkflow) {
          flowType.push('iscopyeditingworkflow');
        }
        // WKH specific
        if (
          iscopyeditingworkflow &&
          isnewsletter &&
          wfId == 31 &&
          stageId == 24
        ) {
          flowType = [];
        }
        if (wfId == 31 && ispapaenable == 'true') {
          flowType.push('ispapaenable');
        }
        if (istranche == 'true' && wfId == 25 && stageId == 23) {
          flowType = [];
        }
        if (iscopyeditingworkflow && cereview && wfId == 31 && stageId == 24) {
          flowType = [];
        }
        if (!isonlineissue) {
          // flowType= [];
          flowType.push('issuejournalflow');
        }
        if (
          otherfield &&
          Object.keys(otherfield).includes('papworkflow') &&
          otherfield.papworkflow
        ) {
          flowType.push('ispapworkflow');
        }
        // springer books Direct 600 stage enabling
        let isDirect600 = false;
        const getFiles = [];
        if (
          workflow &&
          workflow?.toLowerCase().includes('mono') &&
          wotype === 'Book'
        ) {
          sql = `select count(wodet2.workorderid) as totalchaptercount, count(eventlog.workorderid) as completedcount
          from wms_book_workorder_details as wodet1
          left join wms_book_workorder_details as wodet2 on wodet2.bookworkorderid = wodet1.bookworkorderid
          left join wms_workflow_eventlog as eventlog on eventlog.workorderid = wodet2.workorderid
          and activitystatus = 'Completed' and
          wfdefid = (select wfdefid from wms_workflowdefinition where wfid = $1 and stageid = $2 and activityid = $3)
          where wodet1.workorderid = $4`;
          const result = await query(sql, [
            wfid,
            stageId,
            activityId,
            workorderId,
          ]);

          if (result[0]?.totalchaptercount === result[0]?.completedcount) {
            sql = `select itemcode,workorderid from public.wms_workorder where workorderid =
            (select bookworkorderid from wms_book_workorder_details where workorderid=$1)`;
            const bookcode = await query(sql, [workorderId]);
            req.body = {
              itemCode: bookcode[0].itemcode,
              isDirect600: true,
              fileCount: result[0]?.totalchaptercount,
            };
            await stage600FileEntry(req, res);
            flowType = ['isdirect600'];
            sql = `select incoming.filetypeid,woincomingfileid,filename,filetypes.filetype,incoming.mspages,incoming.estimatedpages,
                    bookmst.mycopy, bookmst.index, bookmst.cover
                    from wms_workorder_incomingfiledetails as incoming
                    join pp_mst_filetype as filetypes on filetypes.filetypeid = incoming.filetypeid
                    left join wms_book_master as bookmst on bookmst.bookid = incoming.filename
                    where woincomingid in (select woincomingid from wms_workorder_incoming where woid=$1)`;
            getFilesInfo = await query(sql, [bookcode[0].workorderid]);
            if (getFilesInfo.length > 0) {
              getFilesInfo.forEach(ele => {
                getFiles.push({
                  id: ele.woincomingfileid,
                  type: ele.filetype,
                  filetypeid: ele.filetypeid,
                  name: ele.filename,
                  isChecked: true,
                  mspages: ele.mspages,
                  estimatedpages: ele.estimatedpages,
                  isMyCopy: ele.mycopy == 'Yes',
                  isIndex: !!ele.index,
                  isCover: ele.cover == 'Yes',
                });
              });
            }
            workorderId = bookcode[0].workorderid;
            isDirect600 = true;
          } else {
            flowType = [];
          }
        } else if (
          workflow &&
          !workflow?.toLowerCase().includes('mono') &&
          wotype === 'Book'
        ) {
          flowType = [];
        }
        // springer book revised proof stage enabling
        if (isrevises == 'true' && wotype === 'Book') {
          flowType = ['isrevisedproof'];
        } else if (isrevises == 'false' && wotype === 'Book') {
          flowType = [];
        }
        const flows = flowType.join("','");
        // fetch next stage details
        sql = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
        join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
        join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
        and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
        where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
        and iterationcount=$3 and flowtype   in ('${flows}')
        group by nextstageid, stagename order by min(sequence)`;
        let nextStageDetails = await query(sql, [
          wfid,
          stageId,
          stageIterationCount,
        ]);
        if (!nextStageDetails.length) {
          sql = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
          join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
          join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
          and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
          join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
          where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
          and iterationcount=$3 and flowtype   in ('${flows}')
          group by nextstageid, stagename order by min(sequence)`;
          nextStageDetails = await query(sql, [
            wfid,
            stageId,
            stageIterationCount - 1,
          ]);
        }
        console.log('workOrderDetails[0]', workOrderDetails[0]);
        if (
          workOrderDetails[0].ispapaenable == 'true' &&
          workOrderDetails[0].wfid == '31' &&
          nextStageDetails[0].nextstageid == 33
        ) {
          for (let i = 0; i < nextStageDetails.length; i++) {
            const { nextstageid, nextstagename } = nextStageDetails.length
              ? nextStageDetails[i]
              : {};

            if (nextstageid) {
              sql = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;
              const targetStageInfo = await query(sql, [
                workorderId,
                nextstageid,
              ]);
              const { sequence, plannedstartdate, plannedenddate } =
                targetStageInfo[0];
              const workFlow = `SELECT * FROM public.wms_workflow where wfid = $1`;
              const workFlowDetails = await query(workFlow, [wfId]);
              const { wfcategory } = workFlowDetails[0];

              const currentDate = convertDateFormat(
                plannedstartdate || todaydatetime,
              );
              const targetDate = convertDateFormat(
                plannedenddate || todaydatetime,
              );

              const category = wfcategory;
              const nextStageIteration = targetStageInfo.filter(
                item => item.status === 'Completed',
              );

              const targetStage = {
                iteration: nextStageIteration.length + 1,
                id: nextstageid,
                name: nextstagename,
                plannedStart: currentDate,
                plannedEnd: targetDate,
                sequence,
                receiptdate: todaydatetime,
              };
              const currentStage = {
                iteration: stageIterationCount,
                id: stageId,
                name: stageName,
              };
              const selectedFiles = filesInfo.filter(item => item.typeid !== 1);
              let files = selectedFiles.map(item => {
                return { id: item.woincomingfileid };
              });
              if (isDirect600) {
                files = getFiles;
              }
              req.body = {
                userId: 'System',
                wfId,
                duId,
                customerId,
                woId: workorderId,
                woType: woType || wotype,
                serviceId,
                serviceName,
                stageId: targetStage.id,
                jobcardId: null,
                jobId: itemcode,
                wfeventId,
                activityId,
                currentStage,
                targetStage,
                files,
                category,
                valuesOfArray: selectedFiles,
                duedate,
                type: 'next',
                entityId: '8',
                wfdefid: req.body.wfdefid,
                workorderId: workorderId,
                nextactivityid: req.body.nextactivityid,
                filetypeskipfornextactivity:
                  req.body.filetypeskipfornextactivity,
                woIncomingFileId: req.body.woIncomingFileId,
              };

              if (req.body.isE2E === undefined) {
                req.body.isAutoStageTrigger = true;
              } else if (req.body.isE2E) {
                req.body.isAutoStageTrigger = undefined;
              }
              if (iscamundaflow == false) {
                const {
                  workorderId,
                  wfdefid,
                  nextactivityid,
                  wfId,
                  filetypeskipfornextactivity,
                  woIncomingFileId,
                } = req.body;

                const checkStatus = `select * from wms_workorder_stage where workorderid =${workorderId} and wfstageid = ${nextstageid} and status='In Process'`;
                const checkStatusResult = await query(checkStatus);

                let skipAlreadyStageEntry =
                  checkStatusResult && checkStatusResult.length > 0
                    ? true
                    : false;

                let fileId =
                  activitymodeltypeflow === 'Batch' ? null : woIncomingFileId;
                const startPayload = {
                  actionFlow: 'trigger',
                  wfId,
                  workorderId,
                  serviceId,
                  stageId: nextstageid,
                  stageIteration: nextStageIteration.length + 1,
                  currentActivityId: activityId,
                  currentStage,
                  currentActivity: {
                    id: activityId,
                    name: activityName,
                  },
                  targetStage,
                  woIncomingFileId: fileId,
                  filetypeSkip: filetypeskipfornextactivity,
                  skipAlreadyStageEntry,
                  indexcorrectionid,
                };
                await _triggerWithoutCamundaWorkflow(startPayload);
              } else {
                await _triggerWOStageWf(req, res);
                sql = `UPDATE public.wms_workorder_stage SET status=$1, enddatetime=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
                await query(sql, [
                  'Completed',
                  todaydatetime,
                  workorderId,
                  serviceId,
                  stageId,
                  stageIterationCount,
                ]);
              }
              resolve(true);
            } else {
              resolve(true);
            }
          }
        } else {
          const { nextstageid, nextstagename } = nextStageDetails.length
            ? nextStageDetails[0]
            : {};

          if (nextstageid) {
            // fetch the target stage iteration count
            sql = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;
            const targetStageInfo = await query(sql, [
              workorderId,
              nextstageid,
            ]);
            const { sequence, plannedstartdate, plannedenddate } =
              targetStageInfo[0];
            // fetch the TAT details for the stage
            // const duDates = `SELECT * FROM public.org_mst_du_duedates where customerid = $1 and duid = $2 and stageid = $3`;
            // const duDatesDetails = await query(duDates, [
            //   customerId,
            //   duId,
            //   nextstageid,
            // ]);
            // const { dueduration } = duDatesDetails[0];
            // fetch the workflow details
            const workFlow = `SELECT * FROM public.wms_workflow where wfid = $1`;
            const workFlowDetails = await query(workFlow, [wfId]);
            const { wfcategory } = workFlowDetails[0];

            // const currentDate = moment(new Date()).format('YYYY-MM-DD');
            // const targetDate = moment(new Date())
            //   .add(dueduration, 'days')
            //   .format('YYYY-MM-DD');

            // const currentDate = moment(plannedstartdate || new Date()).format(
            //   'YYYY-MM-DD HH:mm:ss',
            // );
            // const targetDate = moment(plannedenddate || new Date()).format(
            //   'YYYY-MM-DD HH:mm:ss',
            // );

            const currentDate = convertDateFormat(
              plannedstartdate || todaydatetime,
            );
            const targetDate = convertDateFormat(
              plannedenddate || todaydatetime,
            );

            const category = wfcategory;
            const nextStageIteration = targetStageInfo.filter(
              item => item.status === 'Completed',
            );

            const targetStage = {
              iteration: nextStageIteration.length + 1,
              id: nextstageid,
              name: nextstagename,
              plannedStart: currentDate,
              plannedEnd: targetDate,
              sequence,
              receiptdate: todaydatetime,
            };
            const currentStage = {
              iteration: stageIterationCount,
              id: stageId,
              name: stageName,
            };
            const selectedFiles = filesInfo.filter(item => item.typeid !== 1);
            let files = selectedFiles.map(item => {
              return { id: item.woincomingfileid };
            });
            if (isDirect600) {
              files = getFiles;
            }
            req.body = {
              userId: 'System',
              wfId,
              duId,
              customerId,
              woId: workorderId,
              woType: woType || wotype,
              serviceId,
              serviceName,
              stageId: targetStage.id,
              jobcardId: null,
              jobId: itemcode,
              wfeventId,
              activityId,
              currentStage,
              targetStage,
              files,
              category,
              valuesOfArray: selectedFiles,
              duedate,
              type: 'next',
              entityId: '8',
              wfdefid: req.body.wfdefid,
              workorderId: workorderId,
              nextactivityid: req.body.nextactivityid,
              filetypeskipfornextactivity: req.body.filetypeskipfornextactivity,
              woIncomingFileId: req.body.woIncomingFileId,
            };

            if (req.body.isE2E === undefined) {
              req.body.isAutoStageTrigger = true;
            } else if (req.body.isE2E) {
              req.body.isAutoStageTrigger = undefined;
            }
            if (iscamundaflow == false) {
              const {
                workorderId,
                wfdefid,
                nextactivityid,
                wfId,
                filetypeskipfornextactivity,
                woIncomingFileId,
              } = req.body;

              // const { status, nextActivityType } = await getStageActivtyType(nextstageid);
              const checkStatus = `select * from wms_workorder_stage where workorderid =${workorderId} and wfstageid = ${nextstageid} and status='In Process'`;
              const checkStatusResult = await query(checkStatus);

              let skipAlreadyStageEntry =
                checkStatusResult && checkStatusResult.length > 0
                  ? true
                  : false;

              let fileId =
                activitymodeltypeflow === 'Batch' ? null : woIncomingFileId;

              // // let nextStageIterationCount = 0;
              // if (activitymodeltypeflow === 'Batch') {
              //   // nextStageIterationCount = nextStageIteration.length + 1;
              //   const sql = `select actualactivitycount from wms_workflow_eventlog
              //   join wms_workflowdefinition on wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
              //   where workorderid=1914 and woincomingfileid=6131 and stageid=24`
              // }

              const startPayload = {
                actionFlow: 'trigger',
                wfId,
                workorderId,
                serviceId,
                stageId: nextstageid,
                stageIteration: nextStageIteration.length + 1,
                currentActivityId: activityId,
                currentStage,
                currentActivity: {
                  id: activityId,
                  name: activityName,
                },
                targetStage,
                woIncomingFileId: fileId,
                filetypeSkip: filetypeskipfornextactivity,
                skipAlreadyStageEntry,
                indexcorrectionid,
              };
              await _triggerWithoutCamundaWorkflow(startPayload);
            } else {
              await _triggerWOStageWf(req, res);
              // stage sttatus update
              // sql = `UPDATE public.wms_workorder_stage SET status=$1, enddate=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
              sql = `UPDATE public.wms_workorder_stage SET status=$1, enddatetime=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
              await query(sql, [
                'Completed',
                todaydatetime,
                workorderId,
                serviceId,
                stageId,
                stageIterationCount,
              ]);
            }
            resolve(true);
          } else {
            resolve(true);
          }
        }
      } else {
        resolve(true);
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const _nextIssueStageTransferCheckTrigger = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        actionType,
        workorderId,
        serviceId,
        stageId,
        stageIterationCount,
        activityId,
        pmUserId,
        IssuemstId,
        ismscompleted,
        flowtype,
      } = req.body;

      await mailTriggerForKLI(req.body);

      const addeddate = new Date();

      addeddate.setHours(addeddate.getHours() + 5);
      addeddate.setMinutes(addeddate.getMinutes() + 30);

      const todaydatetime = convertDateFormat(addeddate);

      // get the task details
      let sql = `select wfid,duid,customerid,workorderid,itemcode,serviceid,servicename,wotype,stageid,stagename,stageiterationcount,activityid,wfeventid, 
      actualactivitycount, duedate, enableautostagetrnsf, activitystatus, instancetype, jobcardid, userid
      from wms_tasklist where workorderid=$1 and stageid=$2 and activityid=$3 and stageiterationcount=$4 order by actualactivitycount desc limit 1`;
      const taskInfo = await query(sql, [
        workorderId,
        stageId,
        activityId,
        stageIterationCount,
      ]);

      const {
        enableautostagetrnsf,
        activitystatus,
        wfid: wfId,
        duid: duId,
        customerid: customerId,
        servicename: serviceName,
        stagename: stageName,
        wotype: woType,
        wfeventid: wfeventId,
        duedate,
        actualactivitycount: actualActivityCount,
        instancetype: taskType,
        jobcardid: jobCardId,
        userid: userId,
        itemcode: jobId,
      } = taskInfo.length ? taskInfo[0] : {};

      //
      //
      const iPayload = {
        stageId,
        wfId,
        stageIterationCount,
        activityId,
        actualActivityCount,
        customerId,
        duId,
        wfeventId,
        wfeventid: wfeventId,
        workorderId,
        taskType,
        jobCardId,
        userId: userId || pmUserId || 'System',
        userid: userId || pmUserId || 'System',
        jobId,
      };
      req.body = { ...req.body, ...iPayload };
      // itracks dispatch - trigger only from engine activity
      if (actionType === 'Save') {
      } else {
        await iTracksDistapchCall(req, res);
      }
      // get the files info
      sql = `select * from wms_workorder_incomingfiledetails where woincomingid in (select woincomingid from wms_workorder_incoming where woid=$1)`;
      const getFilesInfo = await query(sql, [workorderId]);

      const filesInfo = getFilesInfo.length ? getFilesInfo : [];

      // fetch workorder details
      sql = `select itemcode,isonlineissue,wotype, wms_workorder_service.wfid, isiauthor, case when wms_workorder.celevelid  >1  then true else false end as iscopyeditingworkflow,otherfield from wms_workorder
        join wms_workorder_service on wms_workorder_service.workorderid = wms_workorder.workorderid
        join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
        where wms_workorder.workorderid=$1`;
      // to be deleted
      // changed for springer journal ce level value to take from workorder.

      // sql = `select itemcode, wotype, wms_workorder_service.wfid, isiauthor,
      // case when wms_workorder.customerid = 10 then
      // case when wms_workorder.celevelid  >1  then true else false  end
      // when wms_workorder.customerid != 10 then
      // case when pp_mst_journal.celevelid  >1  then true else false end
      // end as iscopyeditingworkflow
      // from wms_workorder
      //         join wms_workorder_service on wms_workorder_service.workorderid = wms_workorder.workorderid
      //         join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
      //         where wms_workorder.workorderid=$1`;
      const workOrderDetails = await query(sql, [workorderId]);
      const {
        wotype,
        itemcode,
        wfid,
        isiauthor,
        iscopyeditingworkflow,
        otherfield,
        isonlineissue,
      } = workOrderDetails[0];
      let flowType = ['isgeneral'];
      if (isiauthor) {
        flowType.push('isiauthor');
      }
      if (iscopyeditingworkflow) {
        flowType.push('iscopyeditingworkflow');
      }
      if (!isonlineissue) {
        flowType = [];
        flowType.push('issuejournalflow');
      }
      if (
        otherfield &&
        Object.keys(otherfield).includes('papworkflow') &&
        otherfield.papworkflow
      ) {
        flowType.push('ispapworkflow');
      }
      if (
        flowtype != undefined &&
        flowtype != null &&
        (flowtype == 'eldsflow' ||
          flowtype == 'issuerevisesflow' ||
          flowtype == 'coverrevisesflow')
      ) {
        flowType = [];
        flowType.push(`${flowtype}`);
      }
      const flows = flowType.join("','");
      // fetch next stage details
      sql = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
        join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
        join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
        and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
        where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
        and iterationcount=$3 and flowtype   in ('${flows}')
        group by nextstageid, stagename order by min(sequence)`;
      let nextStageDetails = await query(sql, [
        wfid,
        stageId,
        stageIterationCount,
      ]);
      if (!nextStageDetails.length) {
        sql = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
          join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
          join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
          and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
          join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
          where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
          and iterationcount=$3 and flowtype   in ('${flows}')
          group by nextstageid, stagename order by min(sequence)`;
        nextStageDetails = await query(sql, [
          wfid,
          stageId,
          stageIterationCount - 1,
        ]);
      }
      const { nextstageid, nextstagename } = nextStageDetails[0];
      // fetch the target stage iteration count
      sql = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;
      const targetStageInfo = await query(sql, [workorderId, nextstageid]);
      const { sequence, plannedstartdate, plannedenddate } = targetStageInfo[0];
      // fetch the TAT details for the stage
      // const duDates = `SELECT * FROM public.org_mst_du_duedates where customerid = $1 and duid = $2 and stageid = $3`;
      // const duDatesDetails = await query(duDates, [
      //   customerId,
      //   duId,
      //   nextstageid,
      // ]);
      // const { dueduration } = duDatesDetails[0];
      // fetch the workflow details
      const workFlow = `SELECT * FROM public.wms_workflow where wfid = $1`;
      const workFlowDetails = await query(workFlow, [wfId]);
      const { wfcategory } = workFlowDetails[0];

      // const currentDate = moment(new Date()).format('YYYY-MM-DD');
      // const targetDate = moment(new Date())
      //   .add(dueduration, 'days')
      //   .format('YYYY-MM-DD');

      // const currentDate = moment(plannedstartdate || new Date()).format(
      //   'YYYY-MM-DD HH:mm:ss',
      // );
      // const targetDate = moment(plannedenddate || new Date()).format(
      //   'YYYY-MM-DD HH:mm:ss',
      // );

      const currentDate = convertDateFormat(plannedstartdate || new Date());
      const targetDate = convertDateFormat(plannedenddate || new Date());

      const category = wfcategory;
      const nextStageIteration = targetStageInfo.filter(
        item => item.status === 'Completed',
      );

      const targetStage = {
        iteration: nextStageIteration.length + 1,
        id: nextstageid,
        name: nextstagename,
        plannedStart: currentDate,
        plannedEnd: targetDate,
        sequence,
        receiptdate: null,
      };
      const currentStage = {
        iteration: stageIterationCount,
        id: stageId,
        name: stageName,
      };
      const selectedFiles = filesInfo.filter(item => item.typeid !== 1);
      const files = selectedFiles.map(item => {
        return { id: item.woincomingfileid };
      });
      req.body = {
        userId: 'System',
        wfId,
        duId,
        customerId,
        woId: workorderId,
        woType: woType || wotype,
        serviceId,
        serviceName,
        stageId: targetStage.id,
        jobcardId: null,
        jobId: itemcode,
        wfeventId,
        activityId,
        currentStage,
        targetStage,
        files,
        category,
        valuesOfArray: selectedFiles,
        duedate,
        type: 'next',
        entityId: '8',
        ismscompleted,
        isonlineissue,
      };
      req.body.isAutoStageTrigger = !(
        IssuemstId != null && IssuemstId != undefined
      );
      await _triggerWOStageWf(req, res);
      // stage sttatus update
      // sql = `UPDATE public.wms_workorder_stage SET status=$1, enddate=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
      sql = `UPDATE public.wms_workorder_stage SET status=$1, enddatetime=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;

      await query(sql, [
        'Completed',
        todaydatetime,
        workorderId,
        serviceId,
        stageId,
        stageIterationCount,
      ]);

      resolve(true);

      // else {
      //   resolve(true);
      // }
    } catch (e) {
      reject(e);
    }
  });
};

// This function used to sent mail KLI
export const mailTriggerForKLI = async reqData => {
  const {
    articlename,
    workorderId,
    customerid = 70,
    stageId,
    isAttachment,
    journalName,
    issueName,
    journalid,
    flowtype,
  } = reqData;

  return new Promise(async (resolve, reject) => {
    try {
      let toMailArray = [];
      let cmName = '';
      let resForConfig;
      // const payload = {
      //   entityId: 8,
      //   customerId: customerid,
      //   serviceId: 1,
      //   workorderId: workorder,
      //   wfeventId,
      // };

      // if (mailInfo[0].count == 0) {
      //  const resForConfig = await getNotificationConfig(payload, mailAction);

      if (flowtype == 'isjournalflow') {
        const notify = `select * from e2e_notification_config where stageid=${stageId} and type='${flowtype}'
        and customerid=${customerid} and journalid =${journalid}`;

        resForConfig = await query(notify);
        if (resForConfig.length == 0) {
          const generalMailtrigger = `select * from e2e_notification_config where stageid=${stageId} and type='${flowtype}'
          and customerid=${customerid}`;
          resForConfig = await query(generalMailtrigger);
        }
      } else {
        const generalMailtrigger = `select * from e2e_notification_config where stageid=${stageId} and type='${flowtype}'
        and customerid=${customerid}`;
        resForConfig = await query(generalMailtrigger);
      }

      if (
        resForConfig &&
        resForConfig.length > 0 &&
        resForConfig[0].emailconfig
      ) {
        //   const sql = `select  getjournalemailidPM(${journalid})`;
        //   const tomailList = await query(sql);

        //   const sql2 = `select journal.journalemail, journal.journalacronym,journalcont.name,journalcont.email from pp_mst_journal as journal
        // join pp_mst_journal_contacts as journalcont on journalcont.journalid = journal.journalid
        // where journal.journalid = ${journalid}   and journalcont.designation :: bigint= 13`;

        // const journalInfo = await query(sql2);
        // journalInfo.forEach(list => {
        //   toMailArray.push(list.email);
        // });
        //
        // toMailArray.push(tomailList[0].getjournalemailidpm);
        const sql = `
        select roles.roleacronym, journal.journalemail, journal.journalacronym,journalcont.name,journalcont.email from pp_mst_journal as journal
              join pp_mst_journal_contacts as journalcont on journalcont.journalid = journal.journalid
            join wms_role as roles on roles.roleid= journalcont.designation :: bigint
              where journal.journalid =${journalid}`;
        console.log('sql', sql);
        const tomailList = await query(sql);
        console.log(tomailList, 'tomailList');
        tomailList.forEach(list => {
          resForConfig[0].emailconfig.to.forEach((sublist, i) => {
            if (list.roleacronym == sublist) {
              resForConfig[0].emailconfig.to[i] = list.email;
              cmName = list.name;
            }
          });
        });

        tomailList.forEach(list => {
          resForConfig[0].emailconfig.bcc.forEach((sublist, i) => {
            if (list.roleacronym == sublist) {
              resForConfig[0].emailconfig.bcc[i] = list.email;
            }
          });
        });

        tomailList.forEach(list => {
          resForConfig[0].emailconfig.cc.forEach((sublist, i) => {
            if (list.roleacronym == sublist) {
              resForConfig[0].emailconfig.cc[i] = list.email;
              cmName = list.name;
            }
          });
        });
        if (resForConfig.length > 0) {
          resForConfig[0].type = 'mail';
          const { type, emailconfig } = resForConfig[0];
          if (type === 'mail') {
            const outFiles = [];
            const fileNames = [];
            if (isAttachment) {
              if (reqData.attachFiles.length > 0) {
                for (let i = 0; i < reqData.attachFiles.length; i++) {
                  const { fullPath, srcName } = reqData.attachFiles[i];
                  const out = await _localdownload(fullPath);
                  if (out.path != '') {
                    outFiles.push(out);
                    fileNames.push(srcName);
                  }
                }
              }
            }

            toMailArray = `;${resForConfig[0].emailconfig.to
              .toString()
              .split(',')
              .join(';')};`;

            resForConfig[0].emailconfig.to = '';
            const data = {
              actionType: type,
              ...emailconfig,
              lstArticle: articlename,
              cmName,
              subMessage: '',
              toMail: toMailArray,
              jobId: articlename,
              iteration: 1,
              stageId,
              journalName,
              issueName,
              Getdate: '07-04-2024',
              userName: 'IS9111',
              issueRecDate: '07-04-2024',
              iTrackStageId: stageId,
              issueDueDate: '07-04-2024',
              outFiles: outFiles.length > 0 ? outFiles : '',
              fileNames: fileNames.length > 0 ? fileNames : '',
            };

            // if (outFiles.length > 0 && filePath.length > 0) {
            emitAction(data);
            // } else {
            //   reject(
            //     'Attached File Missing Please contact WMS Administrator',
            //   );
            // }
            // else {
            //   reject('Mail Not Found Please contact WMS Administrator');
            // }

            resolve('success');
          }
        } else {
          resolve('Failed sending email- mail template not mapped');
        }
      } else {
        reject('Journal Id Not Mapped,Please Contact WMS Administrator');
      }
      // }
      // else {
      //   resolve('Alreay mail triggered!');
      // }
    } catch (error) {
      reject(`'Failed sending email' ${error}`);
    }
  });
};

export const iTracksDistapchCall = (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { woType, duId, customerId } = req.body;
    try {
      let isTrigger = true;
      let isProduction = false;
      let isCustomer = false;
      if (
        Object.keys(req.body).includes('ftpCustomerDespatchCall') &&
        req.body.ftpCustomerDespatchCall
      ) {
        isCustomer = req.body.ftpCustomerDespatchCall;
      } else {
        const isItracksAPI = await checkItracksExits(req, res, true);
        isProduction = isItracksAPI.isProduction
          ? isItracksAPI.isProduction
          : false;
        isCustomer = isItracksAPI.isCustomer ? isItracksAPI.isCustomer : false;
      }
      if (isProduction || isCustomer) {
        let iSubjobIds = [];
        const iStageId = await getiTracksStageId(req.body);
        const iActivityId = await getiTracksActivityId(req.body);
        if (woType === 'Book') {
          iSubjobIds = await getSubjobIds(req.body);
          console.log(iSubjobIds, 'iSubjobIds');
          req.body.iStageId = iStageId;
          req.body.iActivityId = iActivityId;
          req.body.subjobArray = iSubjobIds;
          if (isProduction && isCustomer) {
            const prodDespatch = await taskDespatch(req.body, 'production');
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              // customer dispatch
              const custDespatch = await taskDespatch(req.body, 'customer');
              const { status: isCust, Result: isCustRes } = custDespatch;
              if (isCust) {
                isTrigger = isCust;
                resolve(isTrigger);
              } else {
                reject(isCustRes);
              }
            } else {
              reject(Result);
            }
          } else if (isProduction) {
            const prodDespatch = await taskDespatch(req.body, 'production');
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              isTrigger = isProd;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else if (isCustomer) {
            const custDespatch = await taskDespatch(req.body, 'customer');
            const { status: isCust, Result } = custDespatch;
            if (isCust) {
              isTrigger = isCust;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else {
            isTrigger = true;
            resolve(isTrigger);
          }
        } else {
          req.body.iStageId = iStageId;
          req.body.isProduction = isProduction;
          req.body.isCustomer = isCustomer;
          const iDuId = await getiTracksDuId(duId);
          const iCustomerId = await getiTracksCustomerId(customerId);
          if (isProduction && isCustomer) {
            const prodDespatch = await taskDespatchJournal(
              { ...req.body, iDuId, iCustomerId },
              'production',
            );
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              // customer dispatch
              const custDespatch = await taskDespatchJournal(
                { ...req.body, iDuId, iCustomerId },
                'customer',
              );
              const { status: isCust, Result: isCustRes } = custDespatch;
              if (isCust) {
                isTrigger = isCust;
                resolve(isTrigger);
              } else {
                reject(isCustRes);
              }
            } else {
              reject(Result);
            }
          } else if (isProduction) {
            const prodDespatch = await taskDespatchJournal(
              { ...req.body, iDuId, iCustomerId },
              'production',
            );
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              isTrigger = isProd;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else if (isCustomer) {
            const custDespatch = await taskDespatchJournal(
              { ...req.body, iDuId, iCustomerId },
              'customer',
            );
            const { status: isCust, Result } = custDespatch;
            if (isCust) {
              isTrigger = isCust;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else {
            isTrigger = true;
            resolve(isTrigger);
          }
        }
      } else {
        isTrigger = true;
        resolve(isTrigger);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const iTracksDispatchEngineCall = async (req, res) => {
  try {
    const { itemcode, ftpCustomerDespatchCall } = req.body;
    const sql = `select  wo.workorderid,wo.wotype,wo.customerid, wo.itemcode, wfsub.wfeventid,wfsub.stageiterationcount, wfsub.activityiterationcount,wfsub.wfdefid,wfsub.userid,wfsub.actualactivitycount,wo.divisionid,wo.subdivisionid,wo.countryid,customer.custorgmapid,du.duid,wo.jobcardid
    ,wf.instancetype,wf.activityid,wf.stageid,wf.wfid,incoming.typesetpage from wms_workorder as wo 
    join(select * from wms_workflow_eventlog as eventlog where eventlog.activitystatus = 'Completed') as wfsub 
    on wfsub.workorderid = wo.workorderid
    join org_mst_customer_orgmap as customer on customer.customerid = wo.customerid and customer.divisionid = wo.divisionid and customer.subdivisionid = wo.subdivisionid and customer.countryid = wo.countryid
    join org_mst_customerorg_du_map as du on du.custorgmapid = customer.custorgmapid
    join wms_workflowdefinition as wf on wf.wfdefid = wfsub.wfdefid
    join(
    SELECT subjobid, filetypeid, filename, woincomingfileid, wms_workorder_incoming.woid,wms_workorder_incomingfiledetails.duedate, estimatedpages, mspages, uomvalue, typesetpage FROM public.wms_workorder_incoming
                JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
               ) as incoming on  incoming.woid=wfsub.workorderid
    where itemcode = '${itemcode}' order by wfsub.wfeventid desc limit 1`;
    const details = await query(sql);
    if (details.length > 0) {
      const {
        workorderid,
        wotype,
        customerid,
        wfeventid,
        stageiterationcount,
        userid,
        actualactivitycount,
        duid,
        jobcardid,
        instancetype,
        activityid,
        stageid,
        wfid,
        typesetpage,
      } = details[0];
      req.body.woType = wotype;
      req.body.duId = duid;
      req.body.customerId = customerid;
      req.body.stageId = stageid;
      req.body.wfId = wfid;
      req.body.stageIterationCount = stageiterationcount;
      req.body.activityId = activityid;
      req.body.actualActivityCount = actualactivitycount;
      req.body.wfeventId = wfeventid;
      req.body.wfeventid = wfeventid;
      req.body.workorderId = workorderid;
      req.body.taskType = instancetype;
      req.body.jobCardId = jobcardid;
      req.body.userId = userid;
      req.body.jobId = itemcode;
      req.body.quantity = typesetpage;
      req.body.userid = userid;
      req.body.ftpCustomerDespatchCall = ftpCustomerDespatchCall;
    }
    await iTracksDistapchCall(req, res);
    res.status(200).send({ message: 'itracks dispatch call' });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const nextStageTriggerAuto = async (req, res) => {
  try {
    const { workorderId } = req.body;
    const sql = `select userid from wms_workorder_contacts where workorderid=${workorderId} and contactrole='PM'`;
    const getUserId = await query(sql);
    req.body.pmUserId = getUserId.length ? getUserId[0].userid : null;
    await _nextStageTransferCheckTrigger(req, res);
    res
      .status(200)
      .send({ message: 'Next stage trigger successfully from engine' });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export function convertDateFormat(inputDate) {
  // Parse the input date using a JavaScript Date object
  const parsedDate = new Date(inputDate);

  if (Number.isNaN(parsedDate)) {
    return 'Invalid Date'; // Handle invalid date input
  }

  // Format the date into 'YYYY-MM-DD HH:mm:ss' using the Date methods
  const year = parsedDate.getFullYear();
  const month = (parsedDate.getMonth() + 1).toString().padStart(2, '0');
  const day = parsedDate.getDate().toString().padStart(2, '0');
  const hours = parsedDate.getHours().toString().padStart(2, '0');
  const minutes = parsedDate.getMinutes().toString().padStart(2, '0');
  const seconds = parsedDate.getSeconds().toString().padStart(2, '0');

  // Create the formatted date string
  const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  return formattedDate;
}
// checking all single activity completed
export const checkAllSigngleActivityCompleted = (
  workorderId,
  wfdefid,
  nextactivityid,
  wfId,
  filetypeskipfornextactivity,
  stageId,
  fileTypeId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      let response = { status: true, nextActivityType: '' };
      let sql = `select activityalias,activitymodeltypeflow from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${nextactivityid}`;
      const activityTypeInfo = await query(sql);
      if (activityTypeInfo.length) {
        if (activityTypeInfo[0].activitymodeltypeflow === 'Batch') {
          // if (
          //   filetypeskipfornextactivity &&
          //   !filetypeskipfornextactivity.includes(fileTypeId)
          // ) {
          const skipFiles =
            filetypeskipfornextactivity && filetypeskipfornextactivity.length
              ? filetypeskipfornextactivity.filter(skp => skp != fileTypeId)
              : [];
          const skipId = skipFiles.length ? skipFiles.join(',') : null;
          sql = `select wfeventid, woincomingfileid from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid=${wfdefid} and activitystatus='Completed' 
        and woincomingfileid in (
        select woincomingfileid from wms_workorder_incomingfiledetails where woincomingid in (select woincomingid from public.wms_workorder_incoming where woid = ${workorderId}) ${
            skipId ? ` and filetypeid not in (${skipId})` : ``
          }
        ) `;
          const eventLogRes = await query(sql);
          if (eventLogRes.length) {
            sql = `select filename, woincomingfileid from wms_workorder_incomingfiledetails where woincomingid in (select woincomingid from public.wms_workorder_incoming where woid = ${workorderId}) ${
              skipId ? ` and filetypeid not in (${skipId})` : ``
            } `;
            // sql = `select wfeventid from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid=${wfdefid}`;
            const totalFiles = await query(sql);
            const lengthCheck = totalFiles.length == eventLogRes.length;
            response = { status: lengthCheck, nextActivityType: 'Batch' };
          } else {
            response = { status: false, nextActivityType: 'Batch' };
          }
          // } else {
          //   response = { status: false, nextActivityType: 'Batch' };
          // }
        } else {
          if (
            filetypeskipfornextactivity &&
            !filetypeskipfornextactivity.includes(fileTypeId)
          ) {
            response = { status: true, nextActivityType: 'Single' };
          } else if (!filetypeskipfornextactivity) {
            response = { status: true, nextActivityType: 'Single' };
          } else {
            response = { status: false, nextActivityType: 'Single' };
          }
        }
      } else {
      }
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};

export const paralleStageConfigEnable = async payload => {
  const {
    wfId,
    workorderId,
    serviceId,
    parallelStageConfig,
    woIncomingFileId,
    actionFlow,
    currentActivityId,
    activityId,
  } = payload;

  const apiCalls = parallelStageConfig.map(id => {
    return new Promise(async (resolve, reject) => {
      try {
        const sql = `select * from wms_workorder_stage
              join wms_mst_stage on wms_mst_stage.stageid = wms_workorder_stage.wfstageid
              where wfstageid in (${id}) and workorderid =${workorderId}`;

        const nextStageDetails = await query(sql);

        const stageIteration = nextStageDetails.filter(
          item => item.status === 'Completed',
        );

        const startPayload = {
          actionFlow,
          wfId,
          workorderId,
          serviceId,
          stageId: id,
          stageIteration: stageIteration.length + 1,
          currentActivityId,
          woIncomingFileId,
          activityId,
          skipAlreadyStageEntry: true,
        };
        await _triggerWithoutCamundaWorkflow(startPayload);
        resolve(true);
      } catch (error) {
        reject(error);
      }
    });
  });

  await Promise.all(apiCalls);
};

const getStageActivtyType = stageId => {
  return new Promise(async (resolve, reject) => {
    try {
      let response = { status: true, nextActivityType: '' };
      let sql = `select activityalias,activitymodeltypeflow from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} order by sequence asc limit 1`;
      const activityTypeInfo = await query(sql);
      if (activityTypeInfo.length) {
        response.nextActivityType = activityTypeInfo[0].activitymodeltypeflow;
      }
      resolve(response);
    } catch (e) {
      reject(e);
    }
  });
};
