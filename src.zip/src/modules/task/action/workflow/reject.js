// eslint-disable-next-line import/no-unresolved
import * as requestIp from 'request-ip';
import { emitAction, actions } from '../../../activityListener/index.js';
import { query, transaction } from '../../../../database/postgres.js';
import {
  getRejectedVariables,
  getBWStageVariables,
} from '../../../utils/wfTrigger/variables.js';
import { completeTask } from './utils/completeTask.js';
import { getWorkflowConfig, createReportView } from '../../../common/index.js';
import {
  checkItracksExits,
  logisticEntryUpdate,
  getiTracksStageId,
  getiTracksActivityId,
  getSubjobIds,
  logisticEntryUpdateJournal,
} from '../../../iTracks/index.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { postProcess, preProcess } from './index.js';
import {
  _getIssueWorkorderInfo,
  _getPartialNonArticleDetails,
} from '../../fileDetails.js';
import { tocFileEnableE2E } from '../../../woi/graphicArt.js';
// This function will get the defect category list
export const defectCategoryList = (req, res) => {
  const sql = `SELECT defectcategoryid as value, defectcategory as label FROM public.wms_mst_defectcategory`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const rejectProcess = async (req, res) => {
  // check iTracks API call
  const { woType, userid, wfeventId, workorderId } = req.body;
  try {
    // capture user event

    let isBatch = false;
    const responseValue = [];
    let overAllFiles = [];
    let matchedArray = [];
    const unSelectedRejectFiles = [];
    const awts = [];
    const isItracksAPI = await checkItracksExits(req, res, true);
    console.log(isItracksAPI, 'isItracksAPI');
    const { status, isProduction, isCustomer } = isItracksAPI;
    let isResponse = true;
    if (
      req.body.activitymodeltypeflow &&
      req.body.activitymodeltypeflow == 'Partial' &&
      req.body.isOtherArticle
    ) {
      const data = {
        workOrderId: workorderId,
        wfDefId: req.body.wfdefid,
        fileTypeId: req.body.fileTypeId,
      };
      overAllFiles = await _getPartialNonArticleDetails(data);
      isBatch = true;
    }

    if (
      req.body.activitymodeltypeflow &&
      req.body.activitymodeltypeflow == 'Batch'
    ) {
      const issuePayload = {
        issuemstid: req.body.issuemstid,
        wfDefId: req.body.wfdefid,
        workorderid: workorderId,
      };
      matchedArray = await _getIssueWorkorderInfo(issuePayload);
      if (req.body.rejectedFileInfo.length > 0) {
        req.body.rejectedFileInfo.forEach(list1 => {
          if (list1.selected === true) {
            const matchingObj = matchedArray.find(
              list2 => list2.woincomingfileid === list1.incomingFileId,
            );
            if (matchingObj) {
              overAllFiles.push(matchingObj);
            }
          } else {
            const matchingObj = matchedArray.find(
              list2 => list2.woincomingfileid === list1.incomingFileId,
            );
            if (matchingObj) {
              unSelectedRejectFiles.push(matchingObj);
            }
          }
        });
      }

      isBatch = true;
    }

    if (isBatch) {
      for (let k = 0; k < overAllFiles.length; k++) {
        const value = overAllFiles[k];
        req.body.workorderId = value.workorderid || workorderId;
        req.body.taskInstanceId = value.taskinstanceid;
        req.body.wfeventId = value.wfeventid || wfeventId;
        const payload = {
          userId: userid,
          wfeventId: req.body.wfeventId,
          actionType: 'Reject',
        };
        preProcess(req, payload);
        // check iTracks API call
        if (status) {
          const iStageId = await getiTracksStageId(req.body);
          const iActivityId = await getiTracksActivityId(req.body);

          if (woType === 'Book') {
            const iSubjobIds = await getSubjobIds(req.body);
            console.log(iSubjobIds, 'iSubjobIds');

            if (iStageId && iActivityId && iSubjobIds.length) {
              req.body.iStageId = iStageId;
              req.body.iActivityId = iActivityId;
              req.body.subjobArray = iSubjobIds;
              const isEntryUpdate = await logisticEntryUpdate(
                req.body,
                isProduction,
                isCustomer,
                1,
                'reject',
              );
              const { status: stat, Result } = isEntryUpdate;
              console.log(isEntryUpdate, 'isEntryUpdate');
              if (stat) {
                awts.push(
                  await rejectCamundaTask(req)
                    .then(response => {
                      emitAction(actions.wfRejected);
                      responseValue.push(response);
                      // res.send(response);
                      postProcess(req, {
                        userId: userid,
                        wfeventId: req.body.wfeventId,
                        actionType: 'Reject',
                      });
                    })
                    .catch(e => {
                      res.status(400).send(e);
                    }),
                );
              } else {
                isResponse = false;
                res.status(400).send({ message: Result });
                break;
              }
            } else {
              isResponse = false;
              res.status(400).send({
                status: false,
                message:
                  'iTracks stageid / activityid / subjobid not fount in iWMS',
              });

              break;
            }
          } else {
            console.log('inside journal logistic update');

            if (iStageId && iActivityId) {
              req.body.iStageId = iStageId;
              req.body.iActivityId = iActivityId;
              const isEntryUpdate = await logisticEntryUpdateJournal(
                req.body,
                isProduction,
                isCustomer,
                1,
                'reject',
              );
              const { status: stat, Result } = isEntryUpdate;
              console.log(isEntryUpdate, 'isEntryUpdate');
              if (stat) {
                awts.push(
                  await rejectCamundaTask(req)
                    .then(response => {
                      emitAction(actions.wfRejected);
                      responseValue.push(response);
                      // res.send(response);
                    })
                    .catch(e => {
                      res.status(400).send(e);
                    }),
                );
              } else {
                isResponse = false;
                res.status(400).send({ message: Result });
                break;
              }
            } else {
              isResponse = false;
              res.status(400).send({
                status: false,
                message: 'iTracks stageid / activityid not fount in iWMS',
              });
              break;
            }
          }
        } else {
          awts.push(
            await rejectCamundaTask(req)
              .then(response => {
                emitAction(actions.wfRejected);
                responseValue.push(response);

                // res.send(response);
              })
              .catch(e => {
                res.status(400).send(e);
              }),
          );
        }
      }
      if (isResponse) {
        await Promise.all(awts);
        // need handle ismulti reject for kli
        if (req.body.isMultiProcess && req.body.wfId == 32) {
          for (let i = 0; i < unSelectedRejectFiles.length; i++) {
            const { workorderid, wfeventid } = unSelectedRejectFiles[i];
            if (
              req.body.pubflowconfig &&
              req.body.pubflowconfig.savePart &&
              req.body.pubflowconfig.savePart.isTOCTrigger
            ) {
              const enablePayload = {
                wfId: req.body.wfId,
                workorderid,
                instancecode: req.body.pubflowconfig.savePart.instancecode,
                instancetype: req.body.pubflowconfig.savePart.instancetype,
              };
              await tocFileEnableE2E(enablePayload);
            }
            if (
              req.body.pubflowconfig &&
              req.body.pubflowconfig.rejectPart &&
              req.body.pubflowconfig.rejectPart.isRejectTrigger
            ) {
              const rejectPayload = {
                wfId: req.body.wfId,
                workorderid,
                instancecode: req.body.pubflowconfig.rejectPart.instancecode,
                instancetype: req.body.pubflowconfig.rejectPart.instancetype,
              };
              await tocFileEnableE2E(rejectPayload);
              const sql1 = `UPDATE wms_workflow_eventlog SET activitystatus ='Rejected' WHERE wfeventid = ${wfeventid}`;
              await query(sql1);
            }
          }
        }
        res.send(responseValue);
      }
    } else {
      const payload = {
        userId: userid,
        wfeventId,
        actionType: 'Reject',
      };
      preProcess(req, payload);
      // check iTracks API call
      if (status) {
        const iStageId = await getiTracksStageId(req.body);
        const iActivityId = await getiTracksActivityId(req.body);

        if (woType === 'Book') {
          const iSubjobIds = await getSubjobIds(req.body);
          console.log(iSubjobIds, 'iSubjobIds');

          if (iStageId && iActivityId && iSubjobIds.length) {
            req.body.iStageId = iStageId;
            req.body.iActivityId = iActivityId;
            req.body.subjobArray = iSubjobIds;
            const isEntryUpdate = await logisticEntryUpdate(
              req.body,
              isProduction,
              isCustomer,
              1,
              'reject',
            );
            const { status: stat, Result } = isEntryUpdate;
            console.log(isEntryUpdate, 'isEntryUpdate');
            if (stat) {
              rejectCamundaTask(req)
                .then(response => {
                  emitAction(actions.wfRejected);
                  res.send(response);
                  postProcess(req, {
                    userId: userid,
                    wfeventId: req.body.wfeventId,
                    actionType: 'Reject',
                  });
                })
                .catch(e => {
                  res.status(400).send(e);
                });
            } else {
              res.status(400).send({ message: Result });
            }
          } else {
            res.status(400).send({
              status: false,
              message:
                'iTracks stageid / activityid / subjobid not fount in iWMS',
            });
          }
        } else {
          console.log('inside journal logistic update');

          if (iStageId && iActivityId) {
            req.body.iStageId = iStageId;
            req.body.iActivityId = iActivityId;
            const isEntryUpdate = await logisticEntryUpdateJournal(
              req.body,
              isProduction,
              isCustomer,
              1,
              'reject',
            );
            const { status: stat, Result } = isEntryUpdate;
            console.log(isEntryUpdate, 'isEntryUpdate');
            if (stat) {
              rejectCamundaTask(req)
                .then(response => {
                  emitAction(actions.wfRejected);
                  res.send(response);
                })
                .catch(e => {
                  res.status(400).send(e);
                });
            } else {
              res.status(400).send({ message: Result });
            }
          } else {
            res.status(400).send({
              status: false,
              message: 'iTracks stageid / activityid not fount in iWMS',
            });
          }
        }
      } else {
        rejectCamundaTask(req)
          .then(response => {
            emitAction(actions.wfRejected);
            res.send(response);
          })
          .catch(e => {
            res.status(400).send(e);
          });
      }
    }
  } catch (e) {
    res.status(400).send({ message: e });
  }
};
// this function will insert the rejected data, complete camunda task, and update eventlogs
export const rejectCamundaTask = req => {
  const {
    du,
    wfeventId,
    taskInstanceId,
    userId,
    defectArray,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    activityId,
    wfdefid,
    iterationCount,
    uomvalue,
    stageId,
    wfId,
    camundaVariable,
    rejectedFileInfo,
    isRejectUom,
    taskType,
    woType,
    rejectedActivityType,
    actualActivityCount,
    jobType,
    iscamundaflow,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      console.log(
        du,
        wfeventId,
        taskInstanceId,
        userId,
        defectArray,
        workorderId,
        'bnbnn',
      );
      const val = [];
      rejectedFileInfo.forEach(mItem => {
        mItem.defectFormArray.forEach(sItem => {
          val.push(
            `(${mItem.wfEventId},${sItem.category},${sItem.count}, ${
              mItem.incomingFileId || null
            })`,
          );
        });
      });
      if (
        req.body.config &&
        Object.keys(req.body.config).includes('skipAfterFirstActivity') &&
        req.body.config.skipAfterFirstActivity
      ) {
        const isEnable = req.body.config.skipAfterFirstActivity == activityId;
        camundaVariable.__isEnableFirstTime__ = {
          value: !isEnable,
          type: 'Boolean',
        };
      }
      let stage = {};
      stage = {
        type: stageName.toLowerCase().replace(/ /g, '_'),
        iteration: iterationCount,
      };
      const rejectFiles = [];
      rejectedFileInfo.forEach(item => {
        rejectFiles.push({
          id: item.incomingFileId,
          name: item.fileName,
          type: item.type,
          isRejected: item.selected,
        });
      });
      if (
        taskType === 'Multiple' &&
        rejectedActivityType &&
        rejectedActivityType != null &&
        rejectedActivityType === 'Multiple'
      ) {
        stage = {
          type: stageName.toLowerCase().replace(/ /g, '_'),
          iteration: iterationCount,
        };
        const sql = `SELECT woincomingfileid,filename,pp_mst_filetype.filetype,allowsubfiletype FROM public.wms_workorder_incoming 
                JOIN public.wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
                JOIN public.pp_mst_filetype ON pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
                WHERE wms_workorder_incoming.woid = ${workorderId}`;
        const getFiles = await query(sql);
        getFiles.forEach(item => {
          const fileteredIndex = rejectFiles.findIndex(
            list => list.id == item.woincomingfileid,
          );
          if (fileteredIndex == -1) {
            rejectFiles.push({
              id: item.woincomingfileid,
              name: item.filename,
              type: item.filetype,
              isRejected: false,
            });
          }
        });
      }

      await transaction(async client => {
        if (val.length > 0) {
          const sql1 = `INSERT INTO public.wms_workflow_eventlog_defects(wfeventid, defectcategoryid, defectcount, woincomingfileid) VALUES ${val}`;
          await client.query(sql1);
        }
        const sql2 = `UPDATE wms_workflow_eventlog SET activitystatus =$1 WHERE wfeventid = $2 `;
        await client.query(sql2, ['Rejected', wfeventId]);
        // entry for report
        const sql3 = `SELECT timestamp FROM wms_workflow_eventlog_details WHERE wfeventid =$1 AND userid=$2
                AND (operationtype =$3 OR operationtype =$4 OR operationtype =$5) ORDER BY wfeventdetailid DESC LIMIT 1`;
        const { rows } = await client.query(sql3, [
          wfeventId,
          userId,
          'Work in progress',
          'Hold',
          'Pending',
        ]);

        if (rows.length > 0) {
          const data = {
            duId: du,
            userId,
            wfeventId,
            timestamp: rows[0].timestamp,
            uomValue: uomvalue || 0,
          };

          await createReportView(client, data);
        }

        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        const sql4 = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid,uomvalue, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6, $7)`;
        await client.query(sql4, [
          wfeventId,
          'Rejected',
          new Date(),
          userId,
          uomvalue,
          systemInfo,
          actualActivityCount,
        ]);
      });
      if (iscamundaflow) {
        // do not change the payload without discussing with team
        const payload = {
          taskId: `${taskInstanceId}`,
          variables:
            woType === 'Journal' && jobType === '2'
              ? {
                  ...camundaVariable,
                  ...getRejectedVariables(true),
                  ...getBWStageVariables(stage, rejectFiles),
                }
              : woType === 'Journal'
              ? { ...camundaVariable, ...getRejectedVariables(true) }
              : !isRejectUom ||
                taskType === 'Multiple' ||
                rejectedActivityType === 'Batch'
              ? { ...camundaVariable, ...getRejectedVariables(true) }
              : {
                  ...camundaVariable,
                  ...getRejectedVariables(true),
                  ...getBWStageVariables(stage, rejectFiles),
                },
        };

        console.log(payload);
        await completeTask(payload);
      } else {
        // need to implement here without camunda flow
        // Query to get the wfdefid
        const sql = `
  SELECT wfdefid 
  FROM wms_workflowdefinition 
  WHERE activityid = (
    SELECT rejectactivity 
    FROM wms_workflowdefinition 
    WHERE wfid = $1 AND wfdefid = $2
  ) 
  AND wfid = $1 AND stageid = $3`;

        const result = await query(sql, [wfId, wfdefid, stageId]);

        // Check if result is found
        if (result.length > 0) {
          const destWfdefid = result[0].wfdefid;

          // Update the workflow event log
          const actCount = Number(actualActivityCount) + 1;
          let sql1 = `
    UPDATE wms_workflow_eventlog
    SET activitystatus = $1, activityiterationcount = $2, userid = $3, actualactivitycount=$4
    WHERE wfdefid = $5 AND workorderid = $6 RETURNING wfeventid`;

          const eventRes = await query(sql1, [
            'Unassigned',
            actCount,
            null,
            actCount,
            destWfdefid,
            workorderId,
          ]);

          if (eventRes.length) {
            sql1 = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, actualactivitycount) VALUES ($1, $2, current_timestamp, $3, $4)`;
            await query(sql1, [
              eventRes[0].wfeventid,
              'Created',
              'System',
              actCount,
            ]);
          }
        } else {
          throw new Error(
            'Reject activity not mapped, please contact the IWMS administrator',
          );
        }
      }
      const data = {
        duId: du,
        entityId,
        workorderId,
        serviceId,
        wfdefid,
        stageDuedate,
        stageName,
        iteration: iterationCount,
        stageId,
        wfId,
        wfeventId,
      };
      await getWorkflowConfig(data, 'reject');

      resolve('Task has been rejected successfully');
    } catch (e) {
      if (e?.message?.data?.message) {
        // This is used to checkThis is wrong. need to get proper error msg from camunda layer
        reject(e.message.data.message);
      } else {
        reject(e.message ? e.message : e);
      }
    }
  });
};

export const _rejectPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _rejectPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};
