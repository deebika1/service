import {
  savePreProcess,
  saveProcess,
  _savePostProcess,
  _savePreProcess,
} from './save.js';
import {
  holdPreProcess,
  holdProcess,
  _holdPostProcess,
  _holdPreProcess,
} from './hold.js';
import {
  cancelPreProcess,
  cancelProcess,
  _cancelPostProcess,
  _cancelPreProcess,
} from './cancel.js';
import {
  pendingPreProcess,
  pendingProcess,
  _pendingPostProcess,
  _pendingPreProcess,
} from './pending.js';
import {
  rejectProcess,
  _rejectPostProcess,
  _rejectPreProcess,
} from './reject.js';
import { resetProcess } from './reset.js';

export const preProcess = (req, payload) => {
  const { actionType } = payload;
  switch (actionType) {
    case 'Save':
      _savePreProcess(req, payload);
      break;
    case 'Pending':
      _pendingPreProcess(req, payload);
      break;
    case 'Hold':
      _holdPreProcess(req, payload);
      break;
    case 'Cancel':
      _cancelPreProcess(req, payload);
      break;
    case 'Reject':
      _rejectPreProcess(req, payload);
      break;
    default:
      break;
  }
};

export const process = (req, res) => {
  const { type } = req.params;
  switch (type) {
    case 'Save':
      saveProcess(req, res);
      break;
    case 'Pending':
      pendingProcess(req, res);
      break;
    case 'Hold':
      holdProcess(req, res);
      break;
    case 'Cancel':
      cancelProcess(req, res);
      break;
    case 'Reject':
      rejectProcess(req, res);
      break;
    case 'Reset':
      resetProcess(req, res);
      break;

    case 'savePre':
      savePreProcess(req, res, 'Save');
      break;
    case 'pendingPre':
      pendingPreProcess(req, res, 'Pending');
      break;
    case 'holdPre':
      holdPreProcess(req, res, 'Hold');
      break;
    case 'cancelPre':
      cancelPreProcess(req, res, 'Cancel');
      break;

    default:
      break;
  }
};

export const postProcess = (req, payload) => {
  const { actionType } = payload;
  switch (actionType) {
    case 'Save':
      _savePostProcess(req, payload);
      break;
    case 'Reject':
      _rejectPostProcess(req, payload);
      break;
    case 'Cancel':
      _cancelPostProcess(req, payload);
      break;
    case 'Pending':
      _pendingPostProcess(req, payload);
      break;
    case 'Hold':
      _holdPostProcess(req, payload);
      break;
    default:
      break;
  }
};
