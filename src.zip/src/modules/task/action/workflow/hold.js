// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { transaction } from '../../../../database/postgres.js';
import { validateFiles } from './utils/validation.js';
import { emitAction, actions } from '../../../activityListener/index.js';
import { getWorkflowConfig, createReportView } from '../../../common/index.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { postProcess, preProcess } from './index.js';

export const holdPreProcess = (req, res, action) => {
  const { userid, wfeventId } = req.body;
  // capture user event
  const payload = {
    userId: userid,
    wfeventId,
    actionType: 'Hold',
  };
  preProcess(req, payload);
  validateFiles(req, res, action).then(() => {
    res.send('validated save action points');
  });
};

export const holdProcess = async (req, res) => {
  const { userid, wfeventId } = req.body;

  onHold(req)
    .then(response => {
      emitAction(actions.wfHold);
      res.send(response);
      // capture user event
      const payload = {
        userId: userid,
        wfeventId,
        actionType: 'Hold',
      };
      postProcess(req, payload);
    })
    .catch(e => {
      res.status(400).send(e);
    });
  // // check iTracks API call
  // let isItracksAPI = await checkItracksExits(req, res, true);
  // console.log(isItracksAPI, 'isItracksAPI');
  // let { status } = isItracksAPI;
  // if (status) {
  //     let isEntryCancel = await logisticEntryDelete(req.body);
  //     let { status, Result } = isEntryCancel;
  //     console.log(isEntryCancel, 'isEntryCancel on Hold');
  //     if (status) {
  //         onHold(req).then((response) => {
  //             emitAction(actions.wfHold);
  //             res.send(response);
  //         }).catch(e => {
  //             res.status(400).send(e);
  //         });
  //     } else {
  //         res.status(400).send({ message: Result });
  //     }

  // } else {
  //     console.log('without entry hold')
  //     onHold(req).then((response) => {
  //         emitAction(actions.wfHold);
  //         res.send(response);
  //     }).catch(e => {
  //         res.status(400).send(e);
  //     });
  // }
};

export const onHold = req => {
  const {
    du,
    wfeventId,
    userId,
    uomid,
    noOfPages,
    comments,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
    stageId,
    wfId,
    activityCount,
    actualActivityCount,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(async client => {
        let sql = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2, isfilesynced =$3, activitycount =$4 WHERE wfeventid = $5`;
        await client.query(sql, [
          userId,
          'Hold',
          false,
          parseInt(activityCount) + 1,
          wfeventId,
        ]);
        // entry for report
        sql = `SELECT timestamp FROM wms_workflow_eventlog_details WHERE wfeventid =$1 AND userid=$2
                AND (operationtype =$3 OR operationtype =$4 OR operationtype =$5) ORDER BY wfeventdetailid DESC LIMIT 1`;
        const { rows } = await client.query(sql, [
          wfeventId,
          userId,
          'Work in progress',
          'Hold',
          'Pending',
        ]);

        if (rows.length > 0) {
          const data = {
            duId: du,
            userId,
            wfeventId,
            timestamp: rows[0].timestamp,
            uomValue: noOfPages,
          };

          await createReportView(client, data);
        }
        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid,uomid,uomvalue,usercomments, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`;
        await client.query(sql, [
          wfeventId,
          'Hold',
          new Date(),
          userId,
          uomid,
          noOfPages,
          comments,
          systemInfo,
          actualActivityCount,
        ]);

        // mail trigger
        const payload = {
          duId: du,
          entityId,
          workorderId,
          serviceId,
          wfdefid,
          stageName,
          iteration: iterationCount,
          stageDuedate,
          stageId,
          wfId,
        };
        await getWorkflowConfig(payload, 'hold');
        resolve('Task has been Holded for a while!');
      });
    } catch (e) {
      if (e?.message?.data?.message) {
        // This is used to checkThis is wrong. need to get proper error msg from camunda layer
        reject(e.message.data.message);
      } else {
        reject(e.message ? e.message : e);
      }
    }
  });
};

export const _holdPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _holdPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};
