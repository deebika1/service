/* eslint-disable */
import { query } from '../../../../../database/postgres.js';

export const validateFiles = req => {
  return new Promise((resolve, reject) => {
    const reqData = req.body;
    const sqlForStatus = `SELECT activitystatus FROM wms_tasklist WHERE activitystatus='Work in progress' AND wfeventid = ${reqData.wfeventId}`;
    const statusRes = query(sqlForStatus);
    if (statusRes.length) {
      const sql = `SELECT 1 FROM wms_tasklist 
      WHERE userid = '${reqData.userid}' AND wfeventid = ${reqData.wfeventId}  AND baseduid = ${reqData.du} AND skillid IN(${reqData.skillid})`;

      query(sql)
        .then(response => {
          if (response.length) {
            resolve('Validated');
          } else {
            reject('Invalid');
          }
        })
        .catch(() => {
          reject('Invalid');
        });
    } else {
      resolve('Validated');
    }
  });
};

export const validateToolsRunningStatus = req => {
  const { wfeventId } = req.body;
  return new Promise((resolve, reject) => {
    const sql = `select * from (select row_number() over(Partition by toolid order by apiid desc ) as rno,toolid,apiid,status from public.wms_tools_api 
        where wfeventid=${wfeventId}) results where rno =1 and status in ('InProgress')`;

    query(sql)
      .then(response => {
        if (response.length) {
          reject({
            status: false,
            message: 'Tools Running Status not yet Completed',
          });
        } else {
          // resolve({ status: true, message: 'Tools Running Status Completed' });
          const sqlQuery = `UPDATE public.wms_tools_api SET status = 'Failure', remarks = 'Latest Output has been generated for that tool'
                WHERE wfeventid = ${wfeventId} and status='InProgress'`;
          query(sqlQuery)
            .then(res => {
              if (res) {
                // resolve();
                resolve({
                  status: true,
                  message: 'Tools Running Status Completed',
                });
              }
            })
            .catch(error => {
              console.log(error);
            });
        }
      })
      .catch(error => {
        console.log(error);
      });
  });
};

export const validateOpenQuery = req => {
  const { workorderId } = req.body;
  return new Promise((resolve, reject) => {
    const sql = `select * from public.wms_workorder_query_list where  workorderid=${workorderId} and querystatus in ('Open','Re-opened')`;

    query(sql)
      .then(response => {
        if (response.length) {
          reject({
            status: false,
            message: 'Please resolve open queries to perform dispatch',
          });
        } else {
          resolve({ status: true, message: 'Queries not available' });
        }
      })
      .catch(error => {
        console.log(error);
      });
  });
};

export const validateUserTask = (req, res) => {
  const reqData = req.body;

  const skills = [];
  reqData.skillid.forEach(item => {
    skills.push(parseInt(item));
  });
  const sql = `SELECT 1 FROM wms_tasklist 
    WHERE userid = $1 AND baseduid = $2 AND skillid IN(${skills})`;

  query(sql, [reqData.userid, reqData.du])
    .then(() => {
      res.status(200).send({ message: 'Success', success: true });
    })
    .catch(() => {
      res
        .status(400)
        .send({ message: 'Invalid task plaese contact TL', success: false });
    });
};

export const postSaveValidation = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, postActivity, wfId, woIncomingFileId } = req;
      const postActivityString = postActivity.join(',');
      let sql;
      sql = `select activitystatus from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid in (${postActivityString}) and woincomingfileid = ${woIncomingFileId} and activitystatus='Completed'`;

      const postActivityRes = await query(sql);
      if (postActivityRes.length) {
        resolve();
      } else {
        sql = `select activityalias from wms_workflowdefinition where wfid=${wfId} and wfdefid in (${postActivityString})`;
        const postActivityName = await query(sql);
        const postActivityNameString = postActivityName
          .map(item => item.activityalias)
          .join(',');
        reject(
          `Please complete the pre-activities ( ${postActivityNameString} ) to perform this action`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const batchIssueClaimValidation = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { preActivity, issuemstid, workorderId } = req;
      const preActivityString = preActivity.join(',');
      let sql = ``;
      if (issuemstid) {
        sql = `select wo.itemcode
       from wms_workorder wo 
       join wms_workflow_eventlog evl on wo.workorderid = evl.workorderid 
       where evl.wfdefid in (${preActivityString}) and wo.issuemstid = ${issuemstid}
       and evl.activitystatus != 'Completed'`;
      } else {
        sql = `select wo.itemcode
        from wms_workorder wo 
        join wms_workflow_eventlog evl on wo.workorderid = evl.workorderid 
        where evl.wfdefid in (${preActivityString}) and evl.workorderid = ${workorderId}
        and evl.activitystatus != 'Completed'`;
      }

      const preActivityRes = await query(sql);
      if (preActivityRes.length > 0) {
        const preActivityNameString = preActivityRes
          .map(item => item.itemcode)
          .join(',');
        reject(
          `Please complete the pre-activities ( ${preActivityNameString} ) to perform this action`,
        );
      } else {
        resolve();
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const PartialFileSequenceUpdate = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        workorderId,
        fileTypeId,
        woIncomingFileId,
        articleOrderSequence,
      } = req;
      let sql = '';
      if (articleOrderSequence != null) {
        sql = `select woincomingfileid,filename,piinumber,* from wms_workorder_incoming as incoming
        join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
        where incoming.woid = ${workorderId} and  indetails.filetypeid = ${fileTypeId} and indetails.articleordersequence = ${articleOrderSequence}`;
      } else {
        sql = `select woincomingfileid,filename,piinumber,* from wms_workorder_incoming as incoming
        join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
        where incoming.woid = ${workorderId} and  indetails.filetypeid = ${fileTypeId}`;
      }

      const runonSequence = await query(sql);
      const filtredSequence = runonSequence.filter(
        list => list.runonfilesequence != null,
      );
      if (filtredSequence && filtredSequence.length > 0) {
        let claim = false;
        let file = '';
        const data2 = filtredSequence.filter(
          list => list.runonfilesequence == '1',
        );
        file = data2[0].filename;
        for (let i = 0; i < filtredSequence.length; i++) {
          const data = filtredSequence[i];
          if (
            data.runonfilesequence == '1' &&
            woIncomingFileId == data.woincomingfileid
          ) {
            claim = true;
          }
        }
        if (claim) {
          resolve();
        } else {
          reject(`Please claim the Primary Article : ${file}`);
        }
      } else {
        reject(`Please update File Sequence for Other File Type Article`);
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const preClaimValidation = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, preActivity, wfId, woIncomingFileId } = req;
      const preActivityString = preActivity.join(',');
      const isCheck = true; // eslint-disable-line no-unused-vars
      /* eslint-disable no-shadow */
      const sql = `select stageid from wms_workflowdefinition where wfdefid in (${preActivityString})`;
      const getPreactivityStage = await query(sql);
      const isGraphicInfo = getPreactivityStage.length
        ? getPreactivityStage.find(st => st.stageid == 10)
        : {};
      if (isGraphicInfo && Object.keys(isGraphicInfo).length) {
        let isGraphic = false;
        if (preActivity.length && woIncomingFileId) {
          const preActWosql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingfileid = ${woIncomingFileId}`;
          const checkImageCount = await query(preActWosql);
          if (checkImageCount.length > 0 && checkImageCount[0].imagecount > 0) {
            isGraphic = true; // eslint-disable-line no-unused-vars
          } else {
            // need to be remove wfdefid from preActivity array - No Image count
            const rmvGraphicWfdefid = isGraphicInfo.wfdefid;
            const index = preActivity.indexOf(rmvGraphicWfdefid);
            if (index !== -1) {
              preActivity.splice(index, 1);
            }
          }
        } else if (preActivity.length && !woIncomingFileId) {
          const preActsql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingid = (select woincomingid from wms_workorder_incoming where woid = ${workorderId}) and filetypeid != 1`;
          const checkImageCount = await query(preActsql);
          if (checkImageCount.length) {
            checkImageCount.forEach(item => {
              if (item.imagecount > 0) {
                isGraphic = true;
              } else {
                // need to be remove wfdefid from preActivity array - No Image count
                const rmvGraphicWfdefid = isGraphicInfo.wfdefid;
                const index = preActivity.indexOf(rmvGraphicWfdefid);
                if (index !== -1) {
                  preActivity.splice(index, 1);
                }
              }
            });
          }
        }
      }
      let isValid = true;
      if (preActivity.length) {
        let sql;
        let postActivityRes;
        const preActivityString = preActivity.join(',');

        if (woIncomingFileId != null && wfId != '29') {
          sql = `select activitystatus, wfdefid from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid in (${preActivityString}) and woincomingfileid = ${woIncomingFileId}`;
          postActivityRes = await query(sql);
          if (postActivityRes.length) {
            const getLengthOfCreated = postActivityRes.filter(res =>
              preActivity.includes(res.wfdefid),
            );
            isValid =
              postActivityRes.filter(prA => prA.activitystatus == 'Completed')
                .length == getLengthOfCreated.length;
          } else {
            isValid = true;
          }
        } else {
          sql = `select activitystatus, wfdefid from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid in (${preActivityString})`;
          postActivityRes = await query(sql);
          if (postActivityRes.length) {
            const getLengthOfCreated = postActivityRes.filter(res =>
              preActivity.includes(res.wfdefid),
            );
            isValid =
              postActivityRes.filter(prA => prA.activitystatus == 'Completed')
                .length == getLengthOfCreated.length;
          } else {
            isValid = true;
          }
        }
        if (isValid) {
          resolve();
        } else {
          const preActivityString = preActivity.join(',');
          sql = `select activityalias from wms_workflowdefinition where wfid=${wfId} and wfdefid in (select wfdefid from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid in (${preActivityString}) and activitystatus !='Completed')`;
          const preActivityName = await query(sql);
          const preActivityNameString = preActivityName
            .map(item => item.activityalias)
            .join(',');
          reject(
            `Please complete the pre-activities ( ${preActivityNameString} ) to perform this action`,
          );
        }
      } else {
        resolve();
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const bookMasterValidation = woId => {
  return new Promise(async (resolve, reject) => {
    try {
      const workorderResult = await query(
        'SELECT itemcode FROM public.wms_workorder WHERE workorderid = $1',
        [woId],
      );

      if (workorderResult.length === 0) {
        return resolve('No workorder found');
      }

      const itemcode = workorderResult[0].itemcode;

      const bookMasterResult = await query(
        'SELECT id FROM public.wms_book_master WHERE bookid = $1',
        [itemcode],
      );

      if (bookMasterResult.length === 0) {
        return reject('Book Master Entry Not Found');
      }

      const bookmasterid = bookMasterResult[0].id;

      const contactResult = await query(
        'SELECT contactname, contactemail FROM public.book_master_contacts WHERE bookmasterid = $1 AND roleid = 1',
        [bookmasterid],
      );

      const hasContact =
        contactResult.length > 0 &&
        contactResult[0].contactname &&
        contactResult[0].contactemail;

      if (hasContact) {
        resolve();
      } else {
        reject('Missing contact PM name or PM email in Book Master');
      }
    } catch (e) {
      console.error('Validation Error:', e);
      reject('Disabled');
    }
  });
};
// validate ftp upload done or not
export const validateFtpUpload = (wfeventId, toolIds, onsaveToolIds) => {
  return new Promise(async (resolve, reject) => {
    try {
      const validTool = !!toolIds;
      const validOnSave = !!onsaveToolIds;
      if (validTool || validOnSave) {
        if (
          onsaveToolIds &&
          (onsaveToolIds.includes(425) || onsaveToolIds.includes(384))
        ) {
          const sql = `select status from wms_tools_api where wfeventid=${wfeventId} and status='Success' and toolid=425 order by apiid desc`;
          const response = await query(sql);
          if (response.length > 0) {
            resolve(response);
          } else {
            reject('FTP upload not done, Please check the FTP upload status');
          }
        } else if (onsaveToolIds && onsaveToolIds.includes('413')) {
          const iterationQuery = `select MAX(actualactivitycount) As iterationCount from  public.wms_workflow_eventlog_details where wfeventid = ${wfeventId}`;
          const iterationData = await query(iterationQuery);

          if (iterationData.length > 0) {
            const iterationVal = iterationData[0].iterationcount.toString();
            const sql = `SELECT actualactivitycount, status
           FROM wms_tools_api
           WHERE wfeventid = ${wfeventId}
             AND actualactivitycount = ${iterationVal}
             AND status = 'Success'
             AND remarks <> 'skipped'
             AND toolid = 413
           ORDER BY apiid DESC;
           `;
            const response = await query(sql);
            if (response.length > 0) {
              resolve(response);
            } else {
              reject('FTP upload not done, Please check the FTP upload status');
            }
          }
        } else if (toolIds && toolIds.includes(346)) {
          const sql = `select status from wms_tools_api where wfeventid=${wfeventId} and status='Success' and toolid=346 order by apiid desc`;
          const response = await query(sql);
          if (response.length > 0) {
            resolve(response);
          } else {
            reject('FTP upload not done, Please check the FTP upload status');
          }
        } else {
          resolve('FTP upload not required');
        }
      } else {
        reject(
          'Please take the new exe from iTools as part of the new build release.',
        );
      }
    } catch (e) {
      reject('FTP upload not done, Please check the FTP upload status');
    }
  });
};
//AI Chnages by Co-Pilot
export const validateMandatoryTool = async (
  wfeventId,
  MandatoryToolIds = [],
) => {
  if (!MandatoryToolIds.length) return Promise.resolve();
  try {
    for (let i = 0; i < MandatoryToolIds.length; i++) {
      const toolId = MandatoryToolIds[i];
      const sql = `
      SELECT 
        CASE WHEN status = 'Success' THEN 'Success' ELSE 'Failure' END AS status,
        toolid, toolname
      FROM wms_tools_api_list
      WHERE wfeventid = ${wfeventId} AND toolid = ${toolId}
      ORDER BY apiid DESC
      LIMIT 1
      `;
      const response = await query(sql);
      if (!response.length) {
        return Promise.reject(
          `Mandatory tool with ID ${toolId} not found for this event.`,
        );
      }
      if (response[0].status !== 'Success') {
        return Promise.reject(
          `${response[0]?.toolname} did not succeed. Please check.`,
        );
      }
    }
    return Promise.resolve();
  } catch (e) {
    return Promise.reject(`Error in validateMandatoryTool: ${e.message || e}`);
  }
};
export const isACSErrorHandledFile = workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select Workorderid from public.acs_errorhandling_audit where workorderid=${workorderId.body.workorderId} and stageid = ${workorderId.body.stageId}`;
      const response = await query(sql);
      if (response.length > 0) {
        let transcode;
        if (workorderId.body.stageId == '72') {
          transcode = 100;
        } else if (workorderId.body.stageId == '10') {
          transcode = 140;
        } else if (workorderId.body.stageId == '24') {
          transcode = 840;
        }
        const sql2 = `SELECT  mscno FROM  public.acs_mst_notificationdetails where mscno = (SELECT itemcode FROM wms_workorder where workorderid = ${workorderId.body.workorderId} and transcode= ${transcode})`;
        const response2 = await query(sql2);
        if (response2.length > 1) {
          resolve(response2);
        } else {
          reject('Updated package not recevied yet.');
        }
      } else {
        resolve('Error Handling not required.');
      }
      //  select Workorderid from  wms_acs_errorhandling_audit where workorderid = ${workorderid} and stageid = ${stageId}
    } catch (e) {
      reject('Error Handling failure');
    }
  });
};

export const isElsevierProblemTaskFile = workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      //  const sql = `select Workorderid from public.acs_errorhandling_audit where workorderid=${workorderId.body.workorderId} and stageid = ${workorderId.body.stageId}`;
      const sql = `select * from wms_workorder wo join trn_problemtask pb on wo.itemcode = pb.articleid
	where wo.workorderid = ${workorderId.body.workorderId} and pb.isactive = true`;

      const response = await query(sql);
      if (response.length > 0) {
        // resolve(true);
        reject('The article is in the Problem Task queue.');
      } else {
        // reject('File is in Problem Task que.');
        resolve(true);
      }
      //  select Workorderid from  wms_acs_errorhandling_audit where workorderid = ${workorderid} and stageid = ${stageId}
    } catch (e) {
      reject('Error in Problem task');
    }
  });
};

export const subTypeClaimValidation = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, fileTypeId, wfDefId, sequenceClaimValidation } = req;

      const sql1 = `select woincomingfileid,filetypeid from public.wms_workorder_incoming as incoming join
      public.wms_workorder_incomingfiledetails as incomingdetails on 
      incoming.woincomingid = incomingdetails.woincomingid
      where incoming.woid = ${workorderId}`;

      const data = await query(sql1);
      if (
        data &&
        data.length > 0 &&
        sequenceClaimValidation.includes(fileTypeId)
      ) {
        const result = data.filter(
          aItem =>
            !sequenceClaimValidation.includes(aItem.filetypeid.toString()),
        );
        let woincomingfileIds = ``;

        woincomingfileIds = result.map(p => p.woincomingfileid);
        const sql2 = `select woincomingfileid from wms_workflow_eventlog where workorderid = ${workorderId} and wfdefid = ${wfDefId} and 
           woincomingfileid IN (${woincomingfileIds.join(
             ',',
           )}) and activitystatus !='Completed'`;

        const validate = await query(sql2);
        if (validate.length > 0) {
          woincomingfileIds = validate.map(p => p.woincomingfileid);
          const sql3 = `select filename from wms_workorder_incomingfiledetails where woincomingfileid IN (${woincomingfileIds.join(
            ',',
          )})`;

          const preFileName = await query(sql3);
          const preActivityNameString = preFileName
            .map(item => item.filename)
            .join(',');
          reject(
            `Please complete the pre-tasks ( ${preActivityNameString} ) to perform this action`,
          );
        } else {
          resolve(true);
        }
      } else {
        resolve(true);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const isPrimaryRunOnValidation = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const getRunonData = await isPrimaryRunOnCheck(req);
      const { isprimary, primary } = getRunonData.length ? getRunonData[0] : {};

      if (isprimary) {
        resolve(true);
      } else {
        reject(
          `The task claimed is not a primary RunOn. Please claim the primary RunOn ${primary}.`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const isPrimaryRunOnCheck = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, runonFileSequence, fileSequence } = req;

      const sql = `with cte as (
        select filename, filesequence from wms_workorder_incomingfiledetails 
          where woincomingid in 
            (select woincomingid from wms_workorder_incoming where woid = ${workorderId}) 
          and runonfilesequence = ${runonFileSequence} 
          order by filesequence 
          limit 1
      )select filename as primary, case when filesequence = ${fileSequence} then true else false end as isprimary from cte;`;
      const getRunonData = await query(sql);
      resolve(getRunonData);
    } catch (e) {
      reject(e);
    }
  });
};
