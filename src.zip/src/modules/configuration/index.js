import * as requestIp from 'request-ip';
import { transaction, query } from '../../database/postgres.js';
import { getsftpConfig } from '../filetransferkit/index.js';
import { _upload } from '../utils/azure/index.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';

export const getftpConfig = async (req, res) => {
  try {
    const { key } = req.query;
    const out = await getsftpConfig(key);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getauditForXmlReader = async (req, res) => {
  try {
    const sql = `select * from public.ftp_audit_wo_creation 
                  where isactive = true 
                  and duname = '${req.query.duname}'
                  and createdon::date BETWEEN current_date - interval '2 day' AND current_date`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const auditForXmlReader = async (req, res) => {
  try {
    let { auditid } = req.body;
    const {
      inputjson,
      remark,
      issuccess,
      duname,
      stagename,
      articlename,
      ftpfilename,
      journalname,
      ftpfilepath,
      stageiterationcount,
      tempPath,
      statusid,
    } = req.body;
    let uploadpath = '';
    if (req.files && req.files.zip) {
      const out = await _upload(req.files.zip, tempPath);
      uploadpath = out.fullPath;
    }
    let sql = '';
    if (auditid === undefined) {
      sql = `INSERT INTO public.ftp_audit_wo_creation(
      inputjson, duname, stagename, articlename, ftpfilename, ftpfilepath, remark, issuccess,uploadpath,journalcode, stageiterationcount, statusid)
     VALUES ('${inputjson}','${duname}','${stagename}','${articlename}','${ftpfilename}','${ftpfilepath}','${remark}',${issuccess},'${uploadpath}','${journalname}',${stageiterationcount},${statusid}) RETURNING auditid`;
    } else {
      sql = `update public.ftp_audit_wo_creation set remark = '${remark}', issuccess = ${issuccess}, statusid = ${statusid} where auditid = ${auditid} RETURNING auditid`;
    }
    auditid = await query(sql);
    res.status(200).send(auditid[0].auditid);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// added by vaithi for acs ftp audit report
export const acsftpaudit = async (req, res) => {
  try {
    const { action } = req.body;
    const {
      remark,
      issuccess,
      duname,
      stagename,
      articlename,
      ftpfilename,
      journalcode,
      stageiterationcount,
      statusid,
    } = req.body;

    let sql = '';
    if (action == 'insert') {
      sql = `INSERT INTO public.ftp_audit_wo_creation(
      duname, stagename, articlename, ftpfilename, remark, issuccess,journalcode, stageiterationcount, statusid)
     VALUES ('${duname}','${stagename}','${articlename}','${ftpfilename}','${remark}',${issuccess},'${journalcode}',${stageiterationcount},${statusid})RETURNING auditid`;
    } else if (action == 'get') {
      sql = `select auditid from ftp_audit_wo_creation where ftpfilename ='${ftpfilename}' order by 1 desc`;
    }
    const auditid = await query(sql);
    res.status(200).send(auditid[0].auditid);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// to get the details for activity configuration
export const ActivityConfigDetails = (req, res) => {
  const reqData = req.body;

  console.log(reqData, 'stagereqData');
  let sql = '';
  if (reqData.type == 'stage') {
    sql = `SELECT   DISTINCT stage.stageid as value , stage.stagename as label  FROM wms_workflowdefinition as workflow 
        left JOIN public.wms_mst_stage as stage ON workflow.stageid=stage.stageid
          where wfid=${reqData.workflowID}`;
  } else if (reqData.type == 'all') {
    sql = `SELECT * FROM wms_workflowdefinition as  workflow
        left JOIN public.wms_mst_skill as skill ON workflow.skillid=skill.skillid 
        where wfid=${reqData.workflowID} AND stageid=${reqData.stageID} AND activityid=${reqData.activityID} `;
  } else if (reqData.type == 'stageForActivity') {
    sql = `SELECT  DISTINCT activity.activityid as value , activity.activityname as label  FROM wms_workflowdefinition as workflow
        left JOIN public.wms_mst_activity as activity ON workflow.activityid=activity.activityid
        where wfid=${reqData.workflowID} AND stageid=${reqData.stageID}`;
  }

  query(sql)
    .then(response => {
      // updated for fileconfig restructure
      response.forEach(item => {
        item.fileconfig = ReStructureFileConfig(item.fileconfig);
      });

      console.log('resforstage', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateForActConfig = (req, res) => {
  const reqData = req.body;
  global.log(reqData, 'reqDataforUpdate');
  console.log(reqData, 'reqDataforUpdate');
  const updatedData = JSON.stringify(reqData.update);
  const toolconficData = JSON.stringify(reqData.toolsConfig);
  // const toolData= JSON.stringify(reqData.toolsconfig.toolsConficUpdate)
  // console.log("toolData",toolData)
  global.log(toolconficData, 'toolconficData');
  console.log(toolconficData, 'toolconficData');
  const sql = `UPDATE public.wms_workflowdefinition
	SET   config =$1,toolsconfig =$2
	WHERE wfid =${reqData.workflowID} and stageid =${reqData.stageID} and activityid=${reqData.activityID}`;
  query(sql, [updatedData, toolconficData])
    .then(response => {
      res.status(200).json({
        data: response,
        message: `Data Updated Sucessfully for this workflowId ${reqData.workflowID} for stageid ${reqData.stageID} and activityid ${reqData.activityID} `,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// software config module start
export const softwareDetails = (req, res) => {
  const sql = `SELECT appname as label, appid as value, * FROM public.wms_mst_software WHERE isactive=true ORDER BY appid ASC`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const softwareIOList = async (req, res) => {
  try {
    const { wfId, stageId, activityId } = req.body;
    const sql = `select softwareconfig from public.wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// adding tools I/O details
export const softwareIOAdd = async (req, res) => {
  try {
    await transaction(async client => {
      const {
        wfId,
        stageId,
        activityId,
        formData,
        type,
        form,
        softwareId,
        userId,
      } = req.body;
      let sql = '';
      const softwareconfigVal = formData
        ? `'${JSON.stringify(formData)}'`
        : null;

      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...JSON.parse(req.headers.systemdetail),
      };
      // insert autit log
      sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
        wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
        ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('toolsconfig', toolsconfig) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}
      )::JSON as sourcedata, '${userId}' as updatedby, current_timestamp, '${type}', '${JSON.stringify(
        systemInfo,
      )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
      await client.query(sql);
      // get the config from wms_workflowdefinition table
      sql = `SELECT config FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
      const { rows } = await client.query(sql);
      const { config } = rows[0];
      // update the config
      const updatedConfig = { ...config, softwareId };
      if (Object.keys(updatedConfig).length) {
        // replace the single quote with double quote
        if (
          'actions' in updatedConfig &&
          'workflow' in updatedConfig.actions &&
          Object.keys(updatedConfig.actions.workflow).length
        ) {
          Object.keys(updatedConfig.actions.workflow).forEach(keyName => {
            if (
              'emailConfig' in
                updatedConfig.actions.workflow[keyName].capture &&
              updatedConfig.actions.workflow[keyName].capture.emailConfig
                .template
            ) {
              updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template = updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template.replace(/'/g, "''");
            }
          });
        }
      }

      sql = `UPDATE public.wms_workflowdefinition
        SET config='${JSON.stringify(updatedConfig)}', 
        softwareconfig=${softwareconfigVal}
        WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
      await client.query(sql);
      let msg = '';
      if (type === 'Add') {
        msg = `Workflow activity ${form} config added sucessfully`;
      } else if (type === 'Update') {
        msg = `Workflow activity ${form} config updated sucessfully`;
      } else if (type === 'Delete') {
        msg = `Workflow activity ${form} config deleted sucessfully`;
      }
      res.status(200).json({
        message: msg,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const ActConfigDetails = async req => {
  return new Promise((resolve, reject) => {
    const reqData = req.body;

    console.log(reqData, 'reqDatafortool');
    const sql = `select * from wms_workflowdefinition
        WHERE wfid =${reqData.workflowID} and stageid =${reqData.stageID} and activityid=${reqData.activityID}`;
    query(sql)
      .then(response => {
        // updated for fileconfig restructure
        response.forEach(item => {
          item.fileconfig = ReStructureFileConfig(item.fileconfig);
        });
        resolve({ data: response });
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};
// tools config module start
export const ToolsConfigDetails = (req, res) => {
  ActConfigDetails.then(response => {
    res.status(200).json({ data: response });
  }).catch(error => {
    res.status(400).send({ message: error });
  });
};

export const toolDetails = (req, res) => {
  const sql = `SELECT tooldescription as label, toolid as value FROM public.pp_mst_tool WHERE toolstatus=true ORDER BY toolid ASC`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// get the tool I/O details
export const toolIOList = async (req, res) => {
  try {
    const { wfId, stageId, activityId } = req.body;
    const sql = `select toolsconfig, wfdefid from public.wms_workflowdefinition where wfid=${wfId} 
    and stageid=${stageId} and activityid=${activityId}`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
// get the tool params suggestions
export const toolParamsSuggestions = (req, res) => {
  const sql = `SELECT toolparamsugges as label, toolparamsugges as value, description FROM public.pp_mst_tool_param_suggestions WHERE isactive=true ORDER BY toolparamsuggesid ASC`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// adding tools I/O details
export const toolsIOAdd = async (req, res) => {
  try {
    await transaction(async client => {
      const {
        wfId,
        stageId,
        activityId,
        formData,
        type,
        form,
        toolsId,
        userId,
        onSaveToolsId,
      } = req.body;
      let sql = '';
      const toolsconfigVal = formData ? `'${JSON.stringify(formData)}'` : null;
      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...JSON.parse(req.headers.systemdetail),
      };
      // insert autit log
      sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
        wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
        ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('toolsconfig', toolsconfig) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}
      )::JSON as sourcedata, '${userId}' as updatedby, current_timestamp, '${type}', '${JSON.stringify(
        systemInfo,
      )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
      await client.query(sql);
      // get the config from wms_workflowdefinition table
      sql = `SELECT config FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
      const { rows } = await client.query(sql);
      const { config } = rows[0];
      // update the config
      const updatedConfig = {
        ...config,
        toolsId: [...toolsId],
        onSaveToolsId: [...onSaveToolsId],
      };
      // if (toolType === 'activity') {
      //   updatedConfig = { ...config, toolsId: [...toolsId] };
      // } else if (toolType === 'onSave') {
      //   updatedConfig = {
      //     ...config,
      //     onSaveToolsId: [...onSaveToolsId],
      //   };
      // } else if (toolType === 'both') {
      //   updatedConfig = {
      //     ...config,
      //     toolsId: [...toolsId],
      //     onSaveToolsId: [...onSaveToolsId],
      //   };
      // }
      if (Object.keys(updatedConfig).length) {
        // replace the single quote with double quote
        if (
          'actions' in updatedConfig &&
          'workflow' in updatedConfig.actions &&
          Object.keys(updatedConfig.actions.workflow).length
        ) {
          Object.keys(updatedConfig.actions.workflow).forEach(keyName => {
            if (
              'emailConfig' in
                updatedConfig.actions.workflow[keyName].capture &&
              updatedConfig.actions.workflow[keyName].capture.emailConfig
                .template
            ) {
              updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template = updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template.replace(/'/g, "''");
            }
          });
        }

        const configVal = `'${JSON.stringify(updatedConfig)}'`;

        sql = `UPDATE public.wms_workflowdefinition
        SET config=${configVal}, 
        toolsconfig=${toolsconfigVal}
        WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
        await client.query(sql);
      }

      let msg = '';
      if (type === 'Add') {
        msg = `Workflow activity ${form} config added sucessfully`;
      } else if (type === 'Update') {
        msg = `Workflow activity ${form} config updated sucessfully`;
      } else if (type === 'Delete') {
        msg = `Workflow activity ${form} config deleted sucessfully`;
      }
      res.status(200).json({
        message: msg,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const OptionList = async (req, res) => {
  const { type, wfId, stageId, activityId } = req.body;
  let sql = '';
  if (type === 'allStages') {
    sql = `SELECT stageid as value, stagename as label from wms_mst_stage
        ORDER BY stageid ASC `;
  } else if (type === 'wfStageFilter') {
    sql = `SELECT stageid as value, stagename as label from wms_mst_stage where stageid in (select stageid from public.wms_workflowdefinition where wfid=${wfId})
        ORDER BY stageid ASC `;
  } else if (type === 'activity') {
    sql = `SELECT activityid as value , activityname as label FROM wms_mst_activity
         WHERE activityid NOT IN (select activityid from public.wms_workflowdefinition where wfid=${wfId}) ORDER BY activityid ASC`;
  } else if (type === 'wfActivityFilter') {
    sql = `SELECT activityid as value , activityname as label FROM wms_mst_activity
         WHERE activityid NOT IN (select activityid from public.wms_workflowdefinition where wfid=${wfId}) ORDER BY activityid ASC`;
  } else if (type === 'skill') {
    sql = `SELECT skillid as value , skillname as label FROM public.wms_mst_skill ORDER BY skillid ASC `;
  } else if (type === 'wfFiletypeFilter') {
    // need to update
    sql = `SELECT fileconfig FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
    const filetypeDtl = await query(sql);
    let fileTypes = [];
    for (const fileConfig of filetypeDtl) {
      fileConfig.files.forEach(x => {
        fileTypes = [...new Set([...fileTypes, ...(x.fileTypes || [])])];
      });
    }
    sql = `SELECT filetype as label, filetypeid as value  FROM public.pp_mst_filetype where filetypeid NOT IN (
                    ${fileTypes.join(',')}
                )
                ORDER BY filetypeid ASC`;
  } else if (type === 'wfFiletype') {
    //   sql = `SELECT filetype as label, filetypeid as value  FROM public.pp_mst_filetype where filetypeid NOT IN (
    //     SELECT json_object_keys(fileconfig::json -> 'fileTypes')::bigint
    //     as filtetypeid FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}
    // )
    // ORDER BY filetypeid ASC`;
    sql = `select wfcategory from wms_workflow where wfid=${wfId}`;
    const category = await query(sql);
    let condition = ` `;
    if (category.length) {
      const value =
        category[0].wfcategory == 'Bookwise'
          ? 'Book'
          : category[0].wfcategory == 'Issuewise'
          ? 'Issue'
          : '';
      if (value) {
        condition = ` where category = '${value}' `;
      }
    }
    sql = `SELECT filetype as label, filetypeid as value  FROM public.pp_mst_filetype ${condition} `;
  } else if (type === 'flowType') {
    sql = `SELECT flowtype as value , flowtype as label FROM public.pp_mst_flowtype where isactive=true`;
  } else if (type === 'wfFileExtention') {
    sql = `SELECT fileextention as value , fileextention as label FROM pp_mst_fileextention WHERE isactive=true`;
    // sql = `with cte as (
    //   SELECT DISTINCT ON (label)
    //           CASE
    //               WHEN position('.' IN reverse(source)) > 0
    //               THEN reverse(substring(reverse(source) FROM 1 FOR position('.' IN reverse(source))-1 ))
    //               ELSE ''
    //           END AS label,
    //         CASE
    //               WHEN position('.' IN reverse(source)) > 0
    //               THEN reverse(substring(reverse(source) FROM 1 FOR position('.' IN reverse(source))-1 ))
    //               ELSE ''
    //           END AS value
    //       FROM wms_filemovementconfig) select label, value from cte where value !=''`;
  } else if (type === 'getCustomTagList') {
    sql = `SELECT custom as value, custom as label, description FROM public.pp_mst_custom_tags`;
  } else if (type === 'wfCategoryList') {
    sql = `select categorycode as value,categoryname as label from pp_mst_category pmc where pmc.isactive = true`;
  } else if (type === 'graphicfileformat') {
    sql = `select graphicformat as value,graphicformat as label from pp_mst_graphicfileformat`;
  } else if (type === 'zipfilenames') {
    sql = `select filename as value, filename as label from wms_zip_filenames`;
  } else if (type === 'zipextensions') {
    sql = `select extension as value, extension as label from wms_zip_extensions`;
  } else if (type === 'emailtemplate') {
    sql = `select notificationid as value, templatename as label from wms_notifications where templatename is not null`;
  } else if (type === 'customers') {
    sql = `select customerid as value, customername as label from org_mst_customer`;
  } else if (type === 'du') {
    sql = `SELECT duid as value , duname as label FROM public.org_mst_deliveryunit ORDER BY duid ASC`;
  }

  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWFStageDetails = (req, res) => {
  const { type, stageId, wfId } = req.body;
  let sql = '';
  if (type === 'wfStages') {
    sql = `select t1.*, (
      select JSON_AGG(t2.*) from wms_workflow_nextstage_map as t2 where t2.wfstageconfigid= t1.wfstageconfigid) as nextstageconfig 
      from wms_workflow_stageconfig as t1 where wfid=${wfId} and stageid=${stageId}`;
  } else if (type === 'allWFStages') {
    sql = `select  STRING_TO_ARRAY('', '') as activity,
      min(ww.sequence) seq ,st.stageid, st.stagename
      from wms_workflowdefinition ww
      join wms_mst_stage as st on st.stageid = ww.stageid
      where ww.wfid=${wfId} group by st.stageid, st.stagename order by seq asc`;
  }

  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWFActivityDetails = async (req, res) => {
  const { type, wfId, stageId, activityId } = req.body;
  let sql = '';
  if (type === 'allWFActivity') {
    sql = `SELECT concat(stagename, ' -> ', activityalias) as label, wfdefid as value,wms_workflowdefinition.stageid,wms_workflowdefinition.activityid FROM wms_workflowdefinition
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
        WHERE wfid=${wfId} ORDER BY sequence ASC`;
  } else if (type === 'WFStageActivity') {
    sql = `SELECT * FROM wms_workflowdefinition 
        JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
        WHERE wfid=${wfId} AND stageid=${stageId} and lock = false ORDER BY sequence ASC`;
  } else if (type === 'wfActivity') {
    sql = ` SELECT * FROM wms_workflowdefinition  WHERE wfid=${wfId} AND stageid=${stageId} and activityid=${activityId} `;
    // sql = ` SELECT * FROM wms_workflowdefinition as ws
    //     LEFT JOIN wms_mst_activity as act on act.activityid = ws.activityid
    //     JOIN (SELECT wfid, json_build_object('value',act.activityid,'label',act.activityname) as skillid
    //     FROM wms_workflowdefinition as ws
    //     LEFT JOIN wms_mst_activity as act on act.activityid = ws.activityid
    //     WHERE wfid=${wfId} AND ws.stageid=${stageId} and ws.activityid=${activityId}
    //     group by ws.wfid, act.activityid) AS sub ON sub.wfid = ws.wfid
    //     WHERE ws.wfid=${wfId} AND ws.stageid=${stageId} and ws.activityid=${activityId}`;
  }

  query(sql)
    .then(async response => {
      console.log(response, type, 'response');
      if (type == 'wfActivity') {
        if (
          response &&
          response.lenght > 0 &&
          response[0].fileconfig.files > 0 &&
          response[0].fileconfig.files
        ) {
          for (let i = 0; i < response[0].fileconfig.files.length; i++) {
            const { copydetail } = response[0].fileconfig.files[i];
            console.log(copydetail, 'copydetail');
            if (copydetail && copydetail.length > 0) {
              const sql1 = `select deftable.wfdefid ,deftable.activityid,acttable.activityname,deftable.stageid,stagetable.stagename  
          from wms_workflowdefinition as deftable join
                  wms_mst_activity as acttable on acttable.activityid = deftable.activityid
                  join wms_mst_stage as stagetable on stagetable.stageid= deftable.stageid
                 -- where stageid =23 and activityid =129 and wfid =25 
            join (select stage,activity from (SELECT 
            (json_data->>'stage')::int AS stage,
            (json_data->>'activity')::int AS activity
          FROM 
            (SELECT jsonb_array_elements('${JSON.stringify(
              copydetail,
            )}'::jsonb) AS json_data) AS subquery) as res1) as subqry on subqry.stage = deftable.stageid and deftable.activityid = subqry.activity 
            where deftable.wfid =${wfId} `;

              const data = await query(sql1);
              console.log(data, 'data');
              const resWfdefids = [];
              data.forEach(list => {
                resWfdefids.push(list.wfdefid);
              });
              response[0].fileconfig.files[i].customwfdefid = resWfdefids;
            }
          }
        }
      }

      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will add / update wf stage details
export const saveWFStage = async (req, res) => {
  try {
    const { type, wfId, stageId, stageForm, userId } = req.body;

    await transaction(async client => {
      let sql = `INSERT INTO public.wms_workflow_stageconfig_audit(wfid, stageid, iterationcount, stageconfig, nextstageconfig, updatedby, updatedon)
      select wfid, stageid, iterationcount,
        (select JSON_AGG(t3.*) from wms_workflow_stageconfig as t3 where t3.wfstageconfigid= t1.wfstageconfigid) as stageconfig
        , (select JSON_AGG(t2.*) from wms_workflow_nextstage_map as t2 where t2.wfstageconfigid= t1.wfstageconfigid) as nextstageconfig,
          '${userId}' as updatedby, now() as updatedon
            from wms_workflow_stageconfig as t1 where wfid=${wfId} and stageid=${stageId} `;
      await client.query(sql);
      sql = `DELETE FROM public.wms_workflow_nextstage_map WHERE wfstageconfigid IN (SELECT wfstageconfigid FROM public.wms_workflow_stageconfig WHERE wfid=${wfId} AND stageid=${stageId})`;
      await client.query(sql);
      sql = `DELETE FROM public.wms_workflow_stageconfig WHERE wfid=${wfId} AND stageid=${stageId} RETURNING wfstageconfigid;`;
      await client.query(sql);
      for (let i = 0; i < stageForm.length; i++) {
        const wfConfigId = await insertWfStageConfig(
          client,
          wfId,
          stageId,
          stageForm[i],
        );
        if (stageForm[i].nextStageConfig.length) {
          for (let j = 0; j < stageForm[i].nextStageConfig.length; j++) {
            await insertWfNextStageConfig(
              client,
              wfConfigId,
              stageForm[i].nextStageConfig[j],
            );
          }
        }
      }
    });

    res.status(200).json({
      message: `Wokflow stage configuration ${
        type === 'add' ? 'added' : 'updated'
      } sucessfully`,
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

const insertWfStageConfig = async (client, wfId, stageId, item) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `INSERT INTO public.wms_workflow_stageconfig(wfid, stageid, isiteration, iterationcount, enableisbnupdate, aliasname)
      VALUES (${wfId}, ${stageId}, ${item.isIteration}, ${item.iterationCount}, ${item.enableISBN}, '${item.stageAliasName}') RETURNING wfstageconfigid;`;
      const { rows } = await client.query(sql);
      const { wfstageconfigid } = rows[0];
      resolve(wfstageconfigid);
    } catch (error) {
      reject(error);
    }
  });
};

const insertWfNextStageConfig = async (client, wfstageconfigid, item) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `INSERT INTO public.wms_workflow_nextstage_map(wfstageconfigid, nextstageid, submittype, flowtype)
      VALUES (${wfstageconfigid}, ${item.nextStages}, 3, '${item.flowType}') RETURNING nextstagemapid;`;
      const { rows } = await client.query(sql);
      const { nextstagemapid } = rows[0];
      resolve(nextstagemapid);
    } catch (error) {
      reject(error);
    }
  });
};

export const saveWFActivity = async (req, res) => {
  try {
    const {
      form,
      type,
      action,
      formData,
      wfId,
      stageId,
      activityId,
      wfdefId,
      userId,
    } = req.body;

    await transaction(async client => {
      let sql = '';
      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...JSON.parse(req.headers.systemdetail),
      };

      if (form === 'general') {
        sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
          wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
          ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('wfid', wfid, 'stageid', stageid,'activityid', activityid, 'sequence',sequence, 'activitytype',activitytype, 'instancetype',instancetype, 'skillid',skillid, 'config',config, 'activityalias',activityalias, 'itracksconfig',itracksconfig,
        'lock',lock, 'toolrunningstatus',toolrunningstatus, 'enablefilestatusreport',enablefilestatusreport, 'enableautostagetrnsf' ,enableautostagetrnsf) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} and lock = false)::JSON as sourcedata
        , '${userId}' as updatedby, current_timestamp, '${action}',
        '${JSON.stringify(
          systemInfo,
        )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} and lock = false)`;
        await client.query(sql);
        const {
          wfdefid,
          wfid,
          stageid,
          activityid,
          activitytype,
          instancetype,
          skillid,
          config,
          activityalias,
          itracksconfig,
          enablefilestatusreport,
          enableautostagetrnsf,
          isactive,
        } = formData;

        // extract the values from the array of objects
        if (config.preActivity.length) {
          config.preActivity = config.preActivity.map(item => item.value);
        }
        if (config.postActivity.length) {
          config.postActivity = config.postActivity.map(item => item.value);
        }
        if (config.newFileTypes.length) {
          config.newFileTypes = config.newFileTypes.map(item => item.value);
        }
        if (config.newFileTypesExt.length) {
          config.newFileTypesExt = config.newFileTypesExt.map(
            item => item.value,
          );
        }
        if (config.graphicFileFormat.length) {
          config.graphicFileFormat = config.graphicFileFormat.map(
            item => item.value,
          );
        }
        if (config.fileCombination.length) {
          config.fileCombination = config.fileCombination.map(
            item => item.value,
          );
        }
        if (config.allowedFileExtension.length) {
          config.allowedFileExtension = config.allowedFileExtension.map(
            item => item.value,
          );
        }
        if (config.skipFileExtension.length) {
          config.skipFileExtension = config.skipFileExtension.map(
            item => item.value,
          );
        }
        if (config.skipFiles.length) {
          config.skipFiles = config.skipFiles.map(item => item.value);
        }
        // replace the single quote with double quote
        if (
          'actions' in config &&
          'workflow' in config.actions &&
          Object.keys(config.actions.workflow).length
        ) {
          Object.keys(config.actions.workflow).forEach(keyName => {
            if (
              'emailConfig' in config.actions.workflow[keyName].capture &&
              config.actions.workflow[keyName].capture.emailConfig.template
            ) {
              config.actions.workflow[keyName].capture.emailConfig.template =
                config.actions.workflow[
                  keyName
                ].capture.emailConfig.template.replace(/'/g, "''");
            }
          });
        }

        const configVal = config ? `'${JSON.stringify(config)}'` : null;
        const itracksconfigVal = itracksconfig
          ? `'${JSON.stringify(itracksconfig)}'`
          : null;
        // eslint-disable-next-line no-unneeded-ternary
        const lock = isactive === 'true' || isactive === true ? false : true;
        sql = `
          UPDATE public.wms_workflowdefinition
          SET wfid=${wfid}, stageid=${stageid}, activityid=${activityid}, activitytype='${activitytype}', instancetype='${instancetype}',
          skillid=${skillid}, config=${configVal}, activityalias='${activityalias}', 
          lock=${lock},
          itracksconfig=${itracksconfigVal}, enablefilestatusreport=${enablefilestatusreport}, enableautostagetrnsf=${enableautostagetrnsf}
          WHERE wfdefid=${wfdefid}`;
      } else if (form === 'file') {
        sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
          wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
          ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('fileconfig', fileconfig) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}
        )::JSON as sourcedata, '${userId}' as updatedby, current_timestamp, '${action}', '${JSON.stringify(
          systemInfo,
        )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
        await client.query(sql);
        const fileconfigVal = formData ? `'${JSON.stringify(formData)}'` : null;
        sql = ` UPDATE public.wms_workflowdefinition SET fileconfig=${fileconfigVal} WHERE wfId=${wfId} AND wfdefid=${wfdefId}`;
      } else if (form === 'filetransfer') {
        const {
          flowFrom,
          file,
          fromActivity,
          copyWithNewName,
          copyFromCommonPath,
          fromFileType,
          toFileType,
          isIncomingSrc,
          isTemplateSrc,
          filePriority,
          toActivity,
          fmconfigid,
        } = formData;
        const flowFromAct =
          flowFrom && flowFrom.length ? flowFrom.join(',') : '';

        if (type === 'Update') {
          sql = `UPDATE public.wms_filemovementconfig
          SET flowfrom='{${flowFromAct}}', flowto=${toActivity}, filesrcactivity=${fromActivity}, source='${file}', destination='${copyWithNewName}', commonfolderpath='${copyFromCommonPath}', srcfiletypeid=${fromFileType}, destfiletypeid=${toFileType}, 
          isincomingsrc=${isIncomingSrc}, istemplatesrc=${isTemplateSrc}
          WHERE fmconfigid=${fmconfigid}`;
        } else {
          sql = `INSERT INTO public.wms_filemovementconfig(
            flowfrom, flowto, filesrcactivity, source, destination, commonfolderpath, srcfiletypeid, destfiletypeid, isincomingsrc, istemplatesrc, filepriority)
          VALUES ('{${flowFromAct}}', ${toActivity}, 
          ${fromActivity || null}, 
          '${file}', '${copyWithNewName}', '${copyFromCommonPath}',
          ${fromFileType || null},
          ${toFileType || null},
          ${isIncomingSrc},${isTemplateSrc},${filePriority});`;
        }
        await client.query(sql);

        const sqlINF = `SELECT MAX(array_length(flowfrom, 1)) AS max_length, flowfrom
        FROM wms_filemovementconfig
        WHERE flowto = ${toActivity}
        GROUP BY flowfrom ORDER BY max_length DESC LIMIT 1`;

        const {
          rows: [{ flowfrom: fFrom }],
        } = await client.query(sqlINF);

        const inFlow = fFrom ? fFrom.join(',') : '';
        sql = `UPDATE public.wms_workflowdefinition
        SET incomingflows='{${inFlow}}' WHERE wfdefid=${toActivity} `;
      } else if (form === 'reject') {
        sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
          wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
          ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('fileconfig', fileconfig) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}
        )::JSON as sourcedata, '${userId}' as updatedby, current_timestamp, '${action}', '${JSON.stringify(
          systemInfo,
        )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
        await client.query(sql);
        const rejectconfigVal = formData
          ? `'${JSON.stringify(formData)}'`
          : null;
        sql = ` UPDATE public.wms_workflowdefinition SET rejectconfig=${rejectconfigVal} WHERE wfId=${wfId} AND wfdefid=${wfdefId}`;
      }

      await client.query(sql);
      let msg = '';
      if (form === 'general') {
        msg = 'Workflow activity general info updated sucessfully';
      } else if (form === 'file') {
        if (type === 'Add') {
          msg = 'Workflow activity file I/O config added sucessfully';
        } else if (type === 'Update') {
          msg = 'Workflow activity file I/O config updated sucessfully';
        } else if (type === 'Delete') {
          msg = 'Workflow activity file I/O config deleted sucessfully';
        }
      } else if (form === 'filetransfer') {
        if (type === 'Update') {
          msg = 'Workflow activity file transfer config updated sucessfully';
        } else {
          msg = 'Workflow activity file transfer config added sucessfully';
        }
      } else if (form === 'reject') {
        if (type === 'Update') {
          msg = 'Workflow activity reject config updated sucessfully';
        } else {
          msg = 'Workflow activity reject config added sucessfully';
        }
      }
      res.status(200).json({
        message: msg,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const saveWFActivityOld = async (req, res) => {
  const {
    type,
    wfdefid,
    wfid,
    stageid,
    activityid,
    activitytype,
    instancetype,
    formjson,
    skillid,
    config,
    fileconfig,
    activityalias,
    incomingflows,
    toolsconfig,
    itracksconfig,
    softwareconfig,
    toolrunningstatus,
    rejectedactivitytype,
    activitymodeltype,
    activitymodeltypeflow,
    enablefilestatusreport,
    resettoactivityid,
  } = req.body;

  const formjsonVal = formjson ? `'${JSON.stringify(formjson)}'` : null;
  const configVal = config ? `'${JSON.stringify(config)}'` : null;
  const fileconfigVal = fileconfig ? `'${JSON.stringify(fileconfig)}'` : null;
  const incomingflowsVal = incomingflows
    ? `'${JSON.stringify(incomingflows)}'`
    : null;
  const toolsconfigVal = toolsconfig
    ? `'${JSON.stringify(toolsconfig)}'`
    : null;
  const itracksconfigVal = itracksconfig
    ? `'${JSON.stringify(itracksconfig)}'`
    : null;
  const softwareconfigVal = softwareconfig
    ? `'${JSON.stringify(softwareconfig)}'`
    : null;
  const skillidVal = skillid ? skillid.value : null;

  try {
    await transaction(async client => {
      let sql = '';
      if (type === 'add') {
        sql = `SELECT sequence FROM wms_workflowdefinition WHERE wfid =${wfid} AND stageid=${stageid} `;
        const { rows } = await client.query(sql);

        const seq = rows.length + 1;
        sql = `INSERT INTO public.wms_workflowdefinition(
                        wfid, stageid, activityid, sequence, activitytype, instancetype, formjson, skillid, config, fileconfig, activityalias, incomingflows, toolsconfig, itracksconfig, softwareconfig, lock, toolrunningstatus, rejectedactivitytype, activitymodeltype, activitymodeltypeflow, enablefilestatusreport, resettoactivityid)
                VALUES (${wfid}, ${stageid}, ${activityid}, ${seq}, '${activitytype}', '${instancetype}', 
                ${formjsonVal}, ${skillidVal}, ${configVal},${fileconfigVal}, '${activityalias}',
                ${incomingflowsVal}, ${toolsconfigVal}, ${itracksconfigVal}, ${softwareconfigVal}, false, 
                ${toolrunningstatus}, '${rejectedactivitytype}', '${activitymodeltype}', '${activitymodeltypeflow}', ${enablefilestatusreport}, '${resettoactivityid}')`;
      } else {
        sql = `
                UPDATE public.wms_workflowdefinition
                SET wfid=${wfid}, stageid=${stageid}, activityid=${activityid}, activitytype='${activitytype}', instancetype='${instancetype}',
                formjson=${formjsonVal}, skillid=${skillidVal}, config=${configVal}, fileconfig=${fileconfigVal}, activityalias='${activityalias}', 
                incomingflows=${incomingflowsVal}, toolsconfig=${toolsconfigVal}, itracksconfig=${itracksconfigVal},
                softwareconfig=${softwareconfigVal}, toolrunningstatus=${toolrunningstatus}, rejectedactivitytype='${rejectedactivitytype}',
                activitymodeltype='${activitymodeltype}', activitymodeltypeflow='${activitymodeltypeflow}', enablefilestatusreport=${enablefilestatusreport},
                resettoactivityid='${resettoactivityid}'
                WHERE wfdefid=${wfdefid}`;
      }

      await client.query(sql);
      res.status(200).json({
        message: `Workflow activity ${
          type === 'add' ? 'added' : 'updated'
        } sucessfully`,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getFilenameSuggestions = async (req, res) => {
  try {
    const { value, type } = req.body;
    let condition = ``;
    if (type === 'Search' && value) {
      condition = `WHERE source LIKE '${value}%'`;
    } else {
      condition = `WHERE source !=''`;
    }
    const sql = `SELECT distinct on (source) source as label, source as value FROM wms_filemovementconfig ${
      condition || ''
    } `;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getExistingFiles = async (req, res) => {
  try {
    const { wfId, stageId, activityId } = req.body;
    const sql = `select (fileconfig ->> 'files')::json as existingfiles, wfdefid,(rejectconfig ->> 'files')::json as rejectfiles from public.wms_workflowdefinition where wfid=${wfId} 
    and stageid=${stageId} and activityid=${activityId}`;
    const response = await query(sql);

    if (
      response &&
      response.length > 0 &&
      response[0].existingfiles &&
      response[0].existingfiles.length > 0
    ) {
      for (let i = 0; i < response[0].existingfiles.length; i++) {
        const { copydetail } = response[0].existingfiles[i];
        console.log(copydetail, 'copydetail');
        if (copydetail && copydetail.length > 0) {
          const sql1 = `SELECT deftable.wfdefid, deftable.activityid, acttable.activityname, deftable.stageid, stagetable.stagename  
                        FROM wms_workflowdefinition AS deftable
                        JOIN wms_mst_activity AS acttable ON acttable.activityid = deftable.activityid
                        JOIN wms_mst_stage AS stagetable ON stagetable.stageid = deftable.stageid
                        JOIN (SELECT stage, activity FROM (
                              SELECT (json_data->>'stage')::int AS stage, (json_data->>'activity')::int AS activity
                              FROM (SELECT jsonb_array_elements('${JSON.stringify(
                                copydetail,
                              )}'::jsonb) AS json_data) AS subquery
                              ) AS res1) AS subqry 
                        ON subqry.stage = deftable.stageid AND deftable.activityid = subqry.activity 
                        WHERE deftable.wfid = ${wfId}`;

          const data = await query(sql1);
          console.log(data, 'data');
          const resWfdefids = [];
          data.forEach(list => {
            resWfdefids.push(list.wfdefid);
          });
          response[0].existingfiles[i].customwfdefid = resWfdefids;
        }
      }
    } else {
      console.error('existingfiles is null or undefined');
    }

    res
      .status(200)
      .json({ data: response.length ? response[0].existingfiles : [] });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getRejectFiles = async (req, res) => {
  try {
    const { wfId, stageId, activityId } = req.body;
    const sql = `select (rejectconfig ->> 'files')::json as rejectfiles,wfdefid from public.wms_workflowdefinition where wfid=${wfId} 
    and stageid=${stageId} and activityid=${activityId}`;
    const response = await query(sql);
    if (response[0].rejectfiles != null && response[0].rejectfiles.length > 0) {
      for (let i = 0; i < response[0].rejectfiles.length; i++) {
        const { fromDetail, toDetail } = response[0].rejectfiles[i];
        if (fromDetail && toDetail.length > 0) {
          const sql1 = `select deftable.wfdefid ,deftable.activityid,acttable.activityname,deftable.stageid,stagetable.stagename  
    from wms_workflowdefinition as deftable join
            wms_mst_activity as acttable on acttable.activityid = deftable.activityid
            join wms_mst_stage as stagetable on stagetable.stageid= deftable.stageid
      join (select stage,activity from (SELECT 
      (json_data->>'stage')::int AS stage,
      (json_data->>'activity')::int AS activity
    FROM 
      (SELECT jsonb_array_elements('${JSON.stringify(
        fromDetail,
      )}'::jsonb) AS json_data) AS subquery) as res1) as subqry on subqry.stage = deftable.stageid and deftable.activityid = subqry.activity 
      where deftable.wfid =${wfId} `;

          const sql2 = `select deftable.wfdefid ,deftable.activityid,acttable.activityname,deftable.stageid,stagetable.stagename  
      from wms_workflowdefinition as deftable join
              wms_mst_activity as acttable on acttable.activityid = deftable.activityid
              join wms_mst_stage as stagetable on stagetable.stageid= deftable.stageid
        join (select stage,activity from (SELECT 
        (json_data->>'stage')::int AS stage,
        (json_data->>'activity')::int AS activity
      FROM 
        (SELECT jsonb_array_elements('${JSON.stringify(
          toDetail,
        )}'::jsonb) AS json_data) AS subquery) as res1) as subqry on subqry.stage = deftable.stageid and deftable.activityid = subqry.activity 
        where deftable.wfid =${wfId}`;

          const data = await query(sql1);
          const data2 = await query(sql2);
          console.log(data, 'data');
          const fromWfdefids = [];
          data.forEach(list => {
            fromWfdefids.push(list.wfdefid);
          });

          console.log(data, 'data');
          const toWfdefids = [];
          data2.forEach(list => {
            toWfdefids.push(list.wfdefid);
          });
          response[0].rejectfiles[i].fromwfdefid = fromWfdefids;
          response[0].rejectfiles[i].toWfdefids = toWfdefids;
        }
      }
    }

    res.status(200).json({
      data:
        response.length && response[0].rejectfiles != null
          ? response[0].rejectfiles
          : [],
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getFileTransferList = async (req, res) => {
  try {
    const { wfdefId } = req.body;
    const sql = `SELECT * FROM public.wms_filemovementconfig WHERE flowto=${wfdefId}`;
    //   const sql = `select
    //   (SELECT coalesce(string_agg(activityalias, ', '), 'NA')  AS flowfromname
    //   FROM wms_workflowdefinition WHERE wfdefid in ( SELECT unnest(flowfrom::bigint[]) as id
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT  activityalias AS flowtoname
    //   FROM wms_workflowdefinition WHERE wfdefid in ( SELECT flowto
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT  activityalias AS fromactivityname
    //   FROM wms_workflowdefinition WHERE wfdefid in ( SELECT filesrcactivity
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT string_agg(filetype, ', ') AS fromfiletypename from public.pp_mst_filetype WHERE filetypeid in (SELECT srcfiletypeid
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT string_agg(filetype, ', ') AS tofiletypename from public.pp_mst_filetype WHERE filetypeid in (SELECT destfiletypeid
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    // *
    // from public.wms_filemovementconfig where flowto in (${wfdefId})`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getWfFilename = async (req, res) => {
  // eslint-disable-next-line no-unused-vars
  const { type, wfId, stageId } = req.body;
  let sql = '';

  sql = `with cte as (
      SELECT (fileconfig->> 'files')::JSON as files FROM wms_workflowdefinition where stageid=${stageId}
    ) 
    select files from cte where files is not null
    `;

  query(sql)
    .then(response => {
      const wfFileName = [];
      if (response.length) {
        response[0].files.forEach(item => {
          wfFileName.push({ label: item.name, value: item.name });
        });
      }
      res.status(200).json({ data: wfFileName });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const deleteFileTransferList = async (req, res) => {
  try {
    const { userId, id, action, form, wfId, stageId, activityId } = req.body;
    const systemInfo = {
      systemIP: requestIp.getClientIp(req),
      publicIP: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
      ...JSON.parse(req.headers.systemdetail),
    };

    let sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
      wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
  ( select wfid, stageid,activityid, '${form}' as formtype,
   (select json_build_object('fmconfigid', fmconfigid, 'flowfrom', flowfrom, 'flowto', flowto, 'filesrcactivity', filesrcactivity, 'source', source, 'destination', destination, 'commonfolderpath', commonfolderpath, 'srcfiletypeid', srcfiletypeid, 'destfiletypeid', destfiletypeid, 'isincomingsrc', isincomingsrc, 'istemplatesrc',istemplatesrc, 'filepriority', filepriority) from wms_filemovementconfig where fmconfigid = ${id}
    )::JSON as sourcedata, 
   '${userId}' as updatedby, current_timestamp, '${action}', '${JSON.stringify(
      systemInfo,
    )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
    await query(sql);
    sql = `DELETE FROM public.wms_filemovementconfig WHERE fmconfigid=${id}`;
    const response = await query(sql);
    res.status(200).json({
      data: response,
      message: 'File movement configuration deleted successfully',
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getUserMapDU = (req, res) => {
  const { userid } = req.body;
  const sql = `SELECT * FROM public.org_mst_deliveryunit WHERE duid = ANY (SELECT unnest(mappedduid) FROM wms_user where userid = '${userid}' )`;
  console.log('sqlllll', sql);
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateUserMapDU = (req, res) => {
  const { selectDUid, userid } = req.body;
  const sql = `UPDATE wms_user SET mappedduid = ARRAY[${selectDUid}]::integer[] WHERE userid = '${userid}'`;
  console.log('sqlllll', sql);
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Successfully updated the Mapping DU for the user' });
    })
    .catch(error => {
      res.status(400).send({
        message: `Failed to mapped the DU for the user. => ${error}`,
      });
    });
};

export const getAllMasterStages = (req, res) => {
  const { wfid } = req.body;
  // WHERE wfid = ${wfid}
  const sql = `SELECT stageid,stagename,stagedescription,isactive
      FROM wms_mst_stage
      WHERE stageid NOT IN (
        SELECT DISTINCT(stageid)
        FROM public.wms_mst_workflowstageorder where wfid=${wfid} and islock=false
      ) and isactive=true order by stagename`;

  query(sql)
    .then(response => {
      //
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageOrder = (req, res) => {
  const { wfid } = req.body;
  const sql = `SELECT stageorder.stageid,stage.stagename,sequence, 
      islock FROM public.wms_mst_workflowstageorder AS stageorder JOIN wms_mst_stage AS stage ON 
      stageorder.stageid = stage.stageid WHERE stageorder.wfid = ${wfid} AND stageorder.islock = false order by stageorder.sequence asc`;

  query(sql)
    .then(response => {
      //
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const getStageOrderwithoutlock = async wfid => {
  return new Promise(async (resolve, reject) => {
    const sql = `SELECT stageorder.stageid,stage.stagename,sequence, 
      islock FROM public.wms_mst_workflowstageorder AS stageorder JOIN wms_mst_stage AS stage ON 
      stageorder.stageid = stage.stageid WHERE stageorder.wfid = ${wfid}`;
    await query(sql)
      .then(response => {
        resolve(response);
      })
      .catch(error => {
        console.log(error);
        reject([]);
      });
  });
};

export const saveStageOrder = async (req, res) => {
  const { wfid } = req.query;
  const data = req.body;

  let sql = '';
  const copyOfData = await getStageOrderwithoutlock(wfid);

  if (copyOfData != undefined) {
    const dataToBeInserted = [];
    const sequenceToBeUpdated = [];
    const nameKey = 'stageid';
    data.forEach(newItem => {
      const result = copyOfData.filter(
        oldItem => oldItem[nameKey] == newItem[nameKey],
      );
      if (result == undefined || result.length <= 0) {
        dataToBeInserted.push(newItem);
      } else if (
        (result[0][nameKey] == newItem[nameKey] &&
          result[0].sequence != newItem.sequence) ||
        (result[0][nameKey] == newItem[nameKey] && result[0].islock == true)
      ) {
        sequenceToBeUpdated.push(newItem);
      }
    });
    const dataToBeLocked = [];
    copyOfData.forEach(item => {
      const result = data.filter(oldItem => oldItem[nameKey] == item[nameKey]);
      if (result == undefined || result.length <= 0) dataToBeLocked.push(item);
    });
    if (dataToBeLocked.length > 0) {
      let updateLockQuery = `
      UPDATE wms_mst_workflowstageorder
      SET islock = true 
      WHERE wfid=${wfid} and stageid IN (${dataToBeLocked
        .map(item => `'${item.stageid}'`)
        .join(', ')});
    `;
      sql += updateLockQuery;

      // Lock all the activity from the locked stage
      updateLockQuery = `
      UPDATE wms_workflowdefinition
      SET lock = true 
      WHERE wfid=${wfid} and stageid IN (${dataToBeLocked
        .map(item => `'${item.stageid}'`)
        .join(', ')});
    `;
      sql += updateLockQuery;
    }

    if (sequenceToBeUpdated.length > 0) {
      let updateSequenceQuery = `
      UPDATE wms_mst_workflowstageorder
      SET islock='false', sequence = CASE
        ${sequenceToBeUpdated
          .map(
            item => `WHEN stageid = '${item.stageid}' THEN '${item.sequence}'`,
          )
          .join(' ')}
        ELSE sequence
      END
      WHERE wfid=${wfid} and stageid IN (${sequenceToBeUpdated
        .map(item => `'${item.stageid}'`)
        .join(', ')});
    `;
      sql += updateSequenceQuery;

      // Unlock all the activity from the Unlocked stage
      updateSequenceQuery = `
      UPDATE wms_workflowdefinition
      SET lock=false
      WHERE wfid=${wfid} and stageid IN (${sequenceToBeUpdated
        .map(item => `'${item.stageid}'`)
        .join(', ')});
    `;
      sql += updateSequenceQuery;
    }

    if (dataToBeInserted.length > 0) {
      const insertQuery = `
      INSERT INTO wms_mst_workflowstageorder (wfid, stageid, sequence, islock)
      VALUES ${dataToBeInserted
        .map(
          item =>
            `('${wfid}', '${item.stageid}', '${item.sequence}', '${
              item.islock ? item.islock : false
            }')`,
        )
        .join(', ')};
    `;
      sql += insertQuery;
    }

    if (!sql) {
      res
        .status(400)
        .json({ message: 'No update or insert operation specified.' });
      return;
    }

    sql = `BEGIN; ${sql} COMMIT;`;
  }
  try {
    const response = await query(sql, []);

    const sql2 = `DO $$
    DECLARE
        cr1 RECORD;
    BEGIN
        FOR cr1 IN
            SELECT ROW_NUMBER() OVER (ORDER BY o."sequence", d."sequence") AS row_number, d.wfdefid, d.wfid,d."sequence"
            FROM wms_workflowdefinition d
            JOIN wms_mst_workflowstageorder o
              ON d.wfid = o.wfid
              AND d.stageid = o.stageid
            WHERE d.wfid = ${wfid}
              AND d.lock = FALSE  AND o.islock = FALSE
            ORDER BY o."sequence", d."sequence"
        LOOP
            UPDATE wms_workflowdefinition
            SET "sequence" = cr1.row_number
            WHERE wfdefid = cr1.wfdefid
              AND wfid = cr1.wfid
              AND lock = FALSE;
        END LOOP;
    END $$;`;
    await query(sql2);

    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const getAllMasterActivities = (req, res) => {
  const { stageid } = req.body;
  const { wfid } = req.body;
  // WHERE stageid = ${stageid}
  const sql = `SELECT * FROM wms_mst_activity
  WHERE activityid not IN (SELECT DISTINCT(activityid) FROM public.wms_workflowdefinition where wfid=${wfid} and stageid=${stageid} and lock=false) and isactive=true`;

  query(sql)
    .then(response => {
      //
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageSpecificActivities = (req, res) => {
  const { wfid, stageid } = req.body;
  const sql = `
    SELECT 
      actdet.activityid,
      actdet.activityname,
      wfd.sequence,
      wfd.parallel_activities,
      wfd.next_activities,
      wfd.reject_activities,
      wfd.reject_labels,
      wfd.next_labels,
      wfd.wfdefid,
      wfd.wfid,
      wfd.stageid
    FROM wms_mst_activity AS actdet  
    JOIN wms_workflowdefinition as wfd 
      ON actdet.activityid = wfd.activityid
    WHERE actdet.isactive = true 
      AND wfd.wfid = $1 
      AND wfd.stageid = $2 
      AND wfd.lock = false 
    ORDER BY sequence ASC`;

  query(sql, [wfid, stageid])
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageSpecificMultiActivities = (req, res) => {
  try {
    const { wfid, stageid } = req.body;

    const sql = `
      SELECT 
        actdet.activityid,
        actdet.activityname,
        wfd.sequence,
        wfd.parallel_activities,
        wfd.next_activities,
        wfd.reject_activities,
        wfd.reject_labels,
        wfd.next_labels,
        wfd.wfdefid,
        wfd.wfid,
        wfd.stageid 
      FROM wms_mst_activity AS actdet  
      JOIN wms_workflowdefinition as wfd 
        ON actdet.activityid = wfd.activityid
      WHERE actdet.isactive = true 
        AND wfd.wfid = $1 
        AND wfd.stageid = $2 
        AND wfd.lock = false 
      ORDER BY sequence ASC`;

    query(sql, [wfid, stageid])
      .then(response => {
        const formattedResponse = [
          {
            activitymapping: response.map(row => ({
              ...row,
              parallel_activities: row.parallel_activities || [],
              next_activities: row.next_activities || [],
              reject_activities: row.reject_activities || [],
              reject_labels: row.reject_labels || {},
              next_labels: row.next_labels || {},
            })),
          },
        ];
        res.status(200).json({ data: formattedResponse });
      })
      .catch(error => {
        res.status(400).send({ message: error.message });
      });
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
};

const getStageSpecificActivitieswithoutlock = async (wfid, stageid) => {
  return new Promise(async (resolve, reject) => {
    const sql = `SELECT actdet.activityid,actdet.activityname,wfd.sequence,wfd.lock FROM wms_mst_activity AS actdet  
  join wms_workflowdefinition as wfd on  actdet.activityid =wfd.activityid
  where actdet.isactive=true and wfd.wfid=${wfid} and wfd.stageid=${stageid}`;
    await query(sql)
      .then(response => {
        resolve(response);
      })
      .catch(error => {
        console.log(error);
        reject([]);
      });
  });
};

export const saveActivityOrder = async (req, res) => {
  const { wfid, stageid } = req.query;
  const data = req.body;

  let sql = '';

  const copyOfData = await getStageSpecificActivitieswithoutlock(wfid, stageid);
  if (copyOfData != undefined) {
    const dataToBeInserted = [];
    const sequenceToBeUpdated = [];
    const nameKey = 'activityid';
    data.forEach(newItem => {
      const result = copyOfData.filter(
        oldItem => oldItem[nameKey] == newItem[nameKey],
      );
      if (result == undefined || result.length <= 0) {
        dataToBeInserted.push(newItem);
      } else if (
        (result[0][nameKey] == newItem[nameKey] &&
          result[0].sequence != newItem.sequence) ||
        (result[0][nameKey] == newItem[nameKey] && result[0].lock == true)
      ) {
        sequenceToBeUpdated.push(newItem);
      }
    });
    const dataToBeLocked = [];
    copyOfData.forEach(item => {
      const result = data.filter(oldItem => oldItem[nameKey] == item[nameKey]);
      if (result == undefined || result.length <= 0) dataToBeLocked.push(item);
    });
    if (dataToBeLocked.length > 0) {
      const updateLockQuery = `
      UPDATE wms_workflowdefinition
      SET lock = true 
      WHERE wfid=${wfid} and stageid=${stageid} and activityid IN (${dataToBeLocked
        .map(item => `'${item.activityid}'`)
        .join(', ')});
    `;
      sql += updateLockQuery;
    }

    if (sequenceToBeUpdated.length > 0) {
      const updateSequenceQuery = `
      UPDATE wms_workflowdefinition
      SET lock=false, sequence = CASE
        ${sequenceToBeUpdated
          .map(
            item =>
              `WHEN activityid = '${item.activityid}' THEN '${item.sequence}'`,
          )
          .join(' ')}
        ELSE sequence
      END
      WHERE wfid=${wfid} and stageid=${stageid} and activityid IN (${sequenceToBeUpdated
        .map(item => `'${item.activityid}'`)
        .join(', ')});
    `;
      sql += updateSequenceQuery;
    }

    if (dataToBeInserted.length > 0) {
      const insertQuery = `
      INSERT INTO wms_workflowdefinition (wfid, stageid, activityid, sequence, lock, activitytype, instancetype, activityalias, enablefilestatusreport)
      VALUES ${dataToBeInserted
        .map(
          item =>
            `('${wfid}', '${stageid}', '${item.activityid}', '${item.sequence}', 'false','User Task','Single','${item.activityname}',true)`,
        )
        .join(', ')};
    `;
      sql += insertQuery;
    }

    if (!sql) {
      res.status(400).json({
        message: 'No update or insert operation specified.',
      });
      return;
    }

    sql = `BEGIN; ${sql} COMMIT;`;

    try {
      const response = await query(sql, []);

      const sql2 = `DO $$
      DECLARE
          cr1 RECORD;
      BEGIN
          FOR cr1 IN
              SELECT ROW_NUMBER() OVER (ORDER BY o."sequence", d."sequence") AS row_number, d.wfdefid, d.wfid,d."sequence"
              FROM wms_workflowdefinition d
              JOIN wms_mst_workflowstageorder o
                ON d.wfid = o.wfid
                AND d.stageid = o.stageid
              WHERE d.wfid = ${wfid}
                AND d.lock = FALSE  AND o.islock = FALSE
              ORDER BY o."sequence", d."sequence"
          LOOP
              UPDATE wms_workflowdefinition
              SET "sequence" = cr1.row_number
              WHERE wfdefid = cr1.wfdefid
                AND wfid = cr1.wfid
                AND lock = FALSE;
          END LOOP;
      END $$;`;
      await query(sql2);

      res.status(200).json({
        data: response,
      });
    } catch (error) {
      res.status(400).send({
        message: error.message,
      });
    }
  }
};

export async function saveActivityMapping(req, res) {
  try {
    const data = req.body;
    let sql = '';

    if (data.length > 0) {
      const updateQuery = `
        UPDATE wms_workflowdefinition
        SET 
          parallel_activities = CASE
            ${data
              .map(
                item =>
                  `WHEN wfdefid = '${item.wfdefid}' THEN ${
                    item.parallel?.length > 0
                      ? `ARRAY[${item.parallel.map(id => `'${id}'`).join(',')}]`
                      : 'NULL'
                  }`,
              )
              .join(' ')}
            ELSE parallel_activities
          END,
          next_activities = CASE
            ${data
              .map(
                item =>
                  `WHEN wfdefid = '${item.wfdefid}' THEN ${
                    item.next?.length > 0
                      ? `ARRAY[${item.next.map(id => `'${id}'`).join(',')}]`
                      : 'NULL'
                  }`,
              )
              .join(' ')}
            ELSE next_activities
          END,
          reject_activities = CASE
            ${data
              .map(
                item =>
                  `WHEN wfdefid = '${item.wfdefid}' THEN ${
                    item.reject?.length > 0
                      ? `ARRAY[${item.reject.map(id => `'${id}'`).join(',')}]`
                      : 'NULL'
                  }`,
              )
              .join(' ')}
            ELSE reject_activities
          END,
          reject_labels = CASE
            ${data
              .map(
                item =>
                  `WHEN wfdefid = '${item.wfdefid}' THEN ${
                    item.rejectLabels
                      ? `'${JSON.stringify(item.rejectLabels)}'::jsonb`
                      : 'NULL'
                  }`,
              )
              .join(' ')}
            ELSE reject_labels
          END,
          next_labels = CASE
            ${data
              .map(
                item =>
                  `WHEN wfdefid = '${item.wfdefid}' THEN ${
                    item.nextLabels
                      ? `'${JSON.stringify(item.nextLabels)}'::jsonb`
                      : 'NULL'
                  }`,
              )
              .join(' ')}
            ELSE next_labels
          END
        WHERE wfdefid in (${data.map(item => `'${item.wfdefid}'`).join(', ')})`;

      sql = updateQuery;
    }

    if (!sql) {
      return res
        .status(400)
        .json({ message: 'No update or insert operation specified.' });
    }

    const response = await query(sql, []);
    return res.status(200).json({
      data: response,
      message: 'Activity mapping updated successfully',
    });
  } catch (error) {
    console.error('Error in saveActivityMapping:', error);
    return res.status(400).json({
      message: error.message || 'Failed to update activity mapping',
    });
  }
}

export const getActivityMapping = async (req, res) => {
  const { wfid, stageid } = req.body;

  const sql = `SELECT * FROM public.wms_mst_workflowactivitymapping WHERE wfid=${wfid} AND stageid=${stageid}`;

  try {
    const response = await query(sql);

    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};
