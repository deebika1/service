import { query } from '../../database/postgres.js';

export const getWorkflowLists = (req, res) => {
  // const { pageNo } = req.body;
  // const { recordPerPage } = req.body;
  // const offset = (pageNo - 1) * recordPerPage;
  const countRow = `SELECT count(*) FROM public.wms_workflow`;
  query(countRow)
    .then(count => {
      query(`SELECT * FROM public.wms_workflow order by wfname`)
        .then(data => {
          res.status(200).json({ data, total: count[0].count });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getAllStageList = (req, res) => {
  // const { wfId } = req.body;

  const sql = `Select stagename, stageid from public.wms_mst_stage order by stagename`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getIncomingFlowList = (req, res) => {
  const { wfId, stageId } = req.body;

  const sql = `SELECT DISTINCT w.activityalias,a.activityid,w.wfdefid 
    FROM wms_workflowdefinition w
    JOIN public.wms_mst_stage s ON w.stageid = s.stageid join
   public.wms_mst_activity a ON  w.activityid = a.activityid
    WHERE w.wfid = ${wfId} and w.stageid = ${stageId}`;
  query(sql)
    .then(data => {
      if (data.length > 0) {
        res.status(200).json({ data });
      } else {
        res.status(200).json({ data: {}, message: 'NA' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getSequenceList = (req, res) => {
  const { wfId, stageId, activityId } = req.body;

  const sql = `SELECT DISTINCT w.activityalias,w.sequence
    FROM wms_workflowdefinition w
    JOIN public.wms_mst_stage s ON w.stageid = s.stageid join
   public.wms_mst_activity a ON  w.activityid = a.activityid
    WHERE w.wfid = ${wfId} and w.stageid = ${stageId} and w.activityid = ${activityId}`;
  query(sql)
    .then(data => {
      if (data.length > 0) {
        res.status(200).json({ data });
      } else {
        res.status(200).json({ data: [] });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const addWfdefEntries = async (req, res) => {
  const {
    workflowId,
    stageId,
    activityId,
    sequenceId,
    activityName,
    incomingFlowsId,
  } = req.body;
  let finalSequenceId = sequenceId;
  if (sequenceId == null) {
    const sql = `select sequence from wms_workflowdefinition where wfid = ${workflowId}  and stageid = ${stageId} order by sequence desc limit 1 `;
    await query(sql)
      .then(data => {
        if (data.length > 0) {
          finalSequenceId = parseInt(data[0].sequence) + 1;
        } else {
          finalSequenceId = 1;
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    const sql = `select sequence from wms_workflowdefinition where wfid = ${workflowId}  and stageid = ${stageId} order by sequence desc limit 1 `;
    await query(sql)
      .then(data => {
        if (data.length > 0) {
          finalSequenceId = parseInt(data[0].sequence) + 1;
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }

  const sql = `INSERT INTO wms_workflowdefinition( wfid, stageid, activityid, sequence, activityalias, incomingflows) VALUES (${workflowId}, ${stageId}, ${activityId}, ${finalSequenceId}, '${activityName.label}', '${incomingFlowsId}')Returning wfdefid`;
  await query(sql)
    .then(data => {
      if (data.length > 0) {
        res.status(200).json({ data });
      } else {
        res.status(200).json({ data: [] });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWfDefDetails = async (req, res) => {
  const { wfId, stageId } = req.body;

  const sql = `
  SELECT(SELECT STRING_AGG (a.activityname,',')
FROM wms_workflowdefinition wfd 
left join public.wms_mst_activity a on a.activityid = wfd.activityid
where wfd.wfdefid in ( select unnest(wfd.incomingflows) 
FROM wms_workflowdefinition wfd  where wfd.wfdefid=w.wfdefid))as incomingflows, w.wfdefid, wf.wfname,wf.wfid, s.stagename,w.stageid, w.activityalias,w.activityid, w.incomingflows as incomingflowsid ,w.sequence
      FROM wms_workflowdefinition w
     JOIN public.wms_mst_stage s ON w.stageid = s.stageid  join
     public.wms_mst_activity a ON  w.activityid = a.activityid
      join public.wms_workflow wf ON  w.wfid= wf.wfid
      WHERE w.wfid = ${wfId}  and w.stageid = ${stageId} order by w.sequence`;
  await query(sql)
    .then(data => {
      if (data.length > 0) {
        res.status(200).json({ data });
      } else {
        res.status(200).json({ data: {} });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateWfDefTable = async (req, res) => {
  const { wfdefid, wfId, stageId, incomingFlowsId } = req.body;

  const sql = `
  UPDATE wms_workflowdefinition
  SET incomingflows = '${incomingFlowsId}'
  WHERE wfdefid = ${wfdefid} and wfid = ${wfId} and stageid = ${stageId} ;
 `;
  await query(sql)
    .then(data => {
      if (data.length > 0) {
        res.status(200).json({ data });
      } else {
        res.status(200).json({ data: {} });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const deleteWfDefTable = (req, res) => {
  const { wfdefid, wfId, stageId } = req.body;

  const sql = `delete from  wms_workflowdefinition where  wfdefid = ${wfdefid} and wfid = ${wfId} and stageid = ${stageId}`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
