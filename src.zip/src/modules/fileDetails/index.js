/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import pdfjsLib from 'pdfjs-dist/legacy/build/pdf.js';
import axios from 'axios';
// import PDFJSWorker from 'pdfjs-dist/legacy/build/pdf.worker.entry.js'
import getDocumentProperties from 'custom-office-document-properties';
import fs from 'fs';
import { join } from 'path';
import { config } from '../../config/restApi.js';
import { query } from '../../database/postgres.js';
import { Service } from '../../httpClient/index.js';
import { getdmsType } from '../bpmn/listener/create.js';
import * as azureHelper from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';
import { stage } from '../../constants.js';

const service = new Service();
// To save the page details savePageDetails
export const saveQuantity = async (req, res) => {
  try {
    const {
      savetype,
      wotype,
      workorderId,
      stageId,
      iterationCount,
      typesetcount,
      mscount,
      estimatedcout,
      imagecount,
      wordcountwithreference,
      wordcountwithoutreference,
      subjobname,
    } = req.body;

    if (savetype == 'typeset') {
      await saveTypesetPage({
        workorderId,
        stageId,
        iterationCount,
        typesetcount,
      });
    } else if (savetype == 'incoming') {
      await saveIncoming({
        wotype,
        workorderId,
        subjobname,
        mscount,
        estimatedcout,
        imagecount,
        wordcountwithreference,
        wordcountwithoutreference,
      });
    } else if (savetype == 'imageupload') {
      await saveImageCount({
        workorderId,
        stageId,
        iterationCount,
      });
    } else {
      res.status(200).send(true);

      return;
    }
    res.status(200).send(true);
  } catch (error) {
    res.status(400).send({ ErrorMessage: error });
  }
};

export const getTotalPageNum = async (req, res) => {
  try {
    const {
      isTypeset,
      workorderId,
      stageId,
      iterationCount,
      path,
      woIncomingFileId,
    } = req.body;
    const dmsType = await getdmsType(workorderId);
    let file = {};
    switch (dmsType) {
      case 'azure':
        const out = await azureHelper._download(path);
        file = out.data.path;
        break;
      case 'local':
        const out1 = await localHelper._localdownload(path);
        file = out1.data.path;
        break;
      default:
        file =
          config.openKM.base_url + config.openKM.uri.viewFile + req.body.fileId;
        break;
    }

    const { fileId } = req.body;
    const fileType = req.body.type;
    if (fileType.toLowerCase() === 'pdf') {
      console.log(file, 'fileelel');
      const loadingTask = pdfjsLib.getDocument(file);
      let count = 0;
      loadingTask.promise
        .then(async pdf => {
          count = pdf.numPages;
          if (count) {
            // to be deleted
            // if (isTypeset)
            //   await addTypesetPage({
            //     workorderId,
            //     stageId,
            //     iterationCount,
            //     count,
            //     woIncomingFileId,
            //   });
            res.status(200).send({ count });
          } else {
            throw new Error('Page count not found');
          }
        })
        .catch(e => {
          res.status(400).send({ ErrorMessage: e.message ? e.message : e });
        });
    } else if (fileType.toLowerCase() === 'word') {
      await getcount(file)
        .then(async data => {
          let pageCount = 0;
          pageCount = data && (data > 240 ? Math.ceil(data / 240) : 1);

          if (pageCount) {
            if (isTypeset)
              await addTypesetPage({
                workorderId,
                stageId,
                iterationCount,
                count: pageCount,
                woIncomingFileId,
              });
            res.status(200).send({ count: pageCount });
          } else {
            throw new Error('Word count not found');
          }
        })
        .catch(e => {
          res.status(400).send({ ErrorMessage: e.message ? e.message : e });
        });
    } else if (fileType.toLowerCase() === 'xml') {
      await getFileSize(fileId, path, dmsType)
        .then(async fileSize => {
          if (fileSize) {
            // to be deleted
            // if (isTypeset)
            //   await addTypesetPage({
            //     workorderId,
            //     stageId,
            //     iterationCount,
            //     count: fileSize,
            //     woIncomingFileId,
            //   });
            res.status(200).send({ count: fileSize });
          } else {
            throw new Error('File size not found');
          }
        })
        .catch(e => {
          res.status(400).send({ ErrorMessage: e.message ? e.message : e });
        });
    }
  } catch (error) {
    res.status(400).send({ ErrorMessage: error });
  }
};
export const updatePgNumFromPginfo = async (req, res) => {
  try {
    const { workorderId, stageId, iterationCount, count, woIncomingFileId } =
      req.body;
    console.log('inside typeset');
    await addTypesetPage({
      workorderId,
      stageId,
      iterationCount,
      count,
      woIncomingFileId,
    });
    res.status(200).send({ count, issuccess: true });
  } catch (e) {
    res.status(400).send({ ErrorMessage: e, issuccess: false });
  }
};

export const getcount = path => {
  console.log('Starting getcount for:', path);

  return new Promise(async (resolve, reject) => {
    const ts = Date.now();
    const uniquefileName = `${random() + Math.floor(ts / 1000)}.docx`;
    const tempFileUploadPath = 'tempFolder/';
    const filePath = `${tempFileUploadPath}${uniquefileName}`;

    try {
      if (!fs.existsSync(tempFileUploadPath)) {
        fs.mkdirSync(tempFileUploadPath);
      }

      const downloaded = await downloadFile(path, filePath);

      if (!downloaded) {
        throw new Error('Download failed, file not saved.');
      }

      getDocumentProperties.fromFilePath(filePath, (err, value) => {
        fs.unlink(filePath, unlinkErr => {
          if (unlinkErr) {
            console.warn('Temporary file cleanup failed:', unlinkErr.message);
          }
        });

        if (err) {
          console.error('Error reading document properties:', err.message);
          return reject(err);
        }

        resolve(value ? value.words : value);
      });
    } catch (error) {
      console.error(
        'getcount failed for path:',
        path,
        '| Error:',
        error.message,
      );
      reject(error);
    }
  });
};

export const getFileSize = async (uuid, file, dmsType) => {
  console.log(uuid, 'uuidforfile');
  return new Promise(async (resolve, reject) => {
    try {
      let result = 0;
      let fileObj;
      switch (dmsType) {
        case 'azure':
          fileObj = await service.get(
            `${config.blob_rest.base_url}${config.blob_rest.uri.getProperties}?docId=${file}`,
            {},
            {},
          );
          result = fileObj.data.contentLength;
          break;
        case 'local':
          fileObj = await service.get(
            `${config.local_rest.base_url}${config.local_rest.uri.getlocalProperties}?docId=${file}`,
            {},
            {},
          );
          result = fileObj.data.contentLength;
          break;
        default:
          const headers = {
            Authorization: `Basic ${process.env.OKM_AUTH}`,
          };
          fileObj = await service.get(
            `${
              config.openKM.base_url + config.openKM.uri.getFileDetails
            }?fileId=${uuid}`,
            {},
            headers,
          );
          console.log(fileObj.data.actualVersion.size, 'fileSize');
          result = fileObj.data.actualVersion.size
            ? parseInt(fileObj.data.actualVersion.size)
            : 0;
          break;
      }
      const fileInKb = result / 1000;
      const fileInPage = fileInKb > 6.92 ? Math.ceil(fileInKb / 6.92) : 1;
      console.log(fileInKb, fileInPage, 'sizeparammerteres');
      resolve(fileInPage);
    } catch (error) {
      console.log(error, 'error for file size');
      reject(error);
    }
  });
};
const random = (length = 8) => {
  return Math.random().toString(16).substr(2, length);
};
export async function downloadFile(fileUrl, outputLocationPath) {
  if (!fileUrl || fileUrl.includes('undefined')) {
    throw new Error(`Invalid file URL: ${fileUrl}`);
  }

  const writer = fs.createWriteStream(outputLocationPath);

  try {
    const response = await axios({
      method: 'get',
      url: fileUrl,
      responseType: 'stream',
    });

    return new Promise((resolve, reject) => {
      response.data.pipe(writer);
      let error = null;

      writer.on('error', err => {
        error = err;
        writer.close();
        reject(err);
      });

      writer.on('close', () => {
        if (!error) {
          resolve(true);
        }
      });
    });
  } catch (err) {
    console.error(`Download failed from URL: ${fileUrl}`, err.message);
    throw err;
  }
}
// To save the typeset page alone do not write anything
const saveTypesetPage = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, stageId, iterationCount, typesetcount } = payload;
      const sql = `UPDATE public.wms_workorder_stage SET typesetpages=${typesetcount}
            WHERE workorderid=${workorderId} AND wfstageid = ${stageId} AND stageiterationcount = ${iterationCount} `;
      await query(sql);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
const saveImageCount = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, stageId, iterationCount } = payload;
      const imagecount = await getimagecount(workorderId);
      const sql = `UPDATE public.wms_workorder_stage SET typesetpages=${imagecount.count}
            WHERE workorderid=${workorderId} AND wfstageid = ${stageId} AND stageiterationcount = ${iterationCount} `;
      await query(sql);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const getimagecount = async workorderId => {
  try {
    const qry = `with cte as (select row_number() over(partition by imagename order by actimgid desc ) as rno,
      imagename,operationtype from wms_imageupload_actions_audit  where workorderid = $1 
      and stageid = 10 and operationtype in ('Uploaded','Replaced') 
      order by imagename ,rno)  

      SELECT count(0) as imagecount FROM  cte 
      WHERE rno = 1 AND operationtype IN ('Uploaded','Replaced')`;

    const result = await query(qry, [workorderId]);
    return { status: true, count: result[0].imagecount };
  } catch (e) {
    return { status: false, count: 0 };
  }
};

// To save the typeset page alone do not write anything
const saveIncoming = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        wotype,
        workorderId,
        mscount,
        imagecount,
        wordcountwithreference,
        wordcountwithoutreference,
      } = payload;

      const convqry = `SELECT  conversionfactor   ,workorderid FROM public.pp_mst_journal jj
      join wms_workorder wo on wo.journalid = jj.journalid
      WHERE wo.workorderid = $1`;

      const getresult = await query(convqry, [workorderId]);

      const getConversionFactor = getresult.length
        ? getresult[0].conversionfactor
        : null;

      const estimatedcount = getConversionFactor
        ? mscount * getConversionFactor
        : 0;

      const updates = [];
      // estimatedpages,mspages,imagecount,typesetpage, referenceount,wordcount
      if (mscount && mscount !== 0) updates.push(`mspages = ${mscount}`);
      if (estimatedcount && estimatedcount !== 0)
        updates.push(`estimatedpages = ${estimatedcount}`);
      if (imagecount && imagecount !== 0)
        updates.push(`imagecount = ${imagecount}`);
      if (wordcountwithreference && wordcountwithreference !== 0)
        updates.push(`wordcountwithreference = ${wordcountwithreference}`);
      if (wordcountwithoutreference && wordcountwithoutreference !== 0)
        updates.push(
          `wordcountwithoutreference = ${wordcountwithoutreference}`,
        );

      if (updates.length > 0) {
        if (wotype.toLowerCase() == 'journal') {
          //      const sql = `
          // UPDATE need to write
          // SET ${updates.join(', ')}
          // WHERE workorderid = ${workorderId}`;

          const updateqry = `with cte as ( select inf.woincomingfileid, inf.woincomingid from wms_workorder_incoming as inc
      join wms_workorder_incomingfiledetails as inf on inf.woincomingid = inc.woincomingid 
      where inc.woid = $1
      )
      update wms_workorder_incomingfiledetails set 
       ${updates.join(', ')}
      from cte 
      where cte.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid`;

          await query(updateqry, [workorderId]);
        }
      }
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

// this function will add the typeset page of corresponding stage
const addTypesetPage = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, stageId, iterationCount, count, woIncomingFileId } =
        payload;
      let sql = `UPDATE public.wms_workorder_stage SET typesetpages=${count}
            WHERE workorderid=${workorderId} AND wfstageid = ${stageId} AND stageiterationcount = ${iterationCount} `;

      await query(sql);
      sql = `UPDATE public.wms_workorder_incomingfiledetails SET typesetpage=${count}
            WHERE woincomingfileid=${woIncomingFileId}`;

      await query(sql);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const readFileInfo = async (req, res) => {
  try {
    const sql = `select distinct on (filename,wms_workorder.workorderid) wms_workorder.workorderid,itemcode,filename,repofilepath,wms_workflowactivitytrn_file_map.woincomingfileid from public.wms_workorder
        join wms_workorder_incoming on wms_workorder_incoming.woid = wms_workorder.workorderid
        join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
        join wms_workflowactivitytrn_file_map on wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid
        join wms_workflow_eventlog on wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
        where wotype ='Book' and wfdefid=237 and wms_workorder.isactive=true and repofilepath like '%.pag'  order by filename, wms_workorder.workorderid asc limit 1
        `;
    console.log(sql, 'sql for typeset page on stage');
    const files = await query(sql);
    const fileContainer = [];
    for (let i = 0; i < files.length; i++) {
      fs.readdirSync(files[i].repofilepath).forEach(async File => {
        let TotalPagNum;
        if (File.includes('.pag')) {
          const fileContent = fs.readFileSync(
            join(files[i].repofilepath, File),
            { encoding: 'utf8' },
          );
          const regex = /(?<=<total>).*?(?=<\/total>)/gm;
          let m;
          // eslint-disable-next-line no-cond-assign
          while ((m = regex.exec(fileContent)) !== null) {
            // This is necessary to avoid infinite loops with zero-width matches
            if (m.index === regex.lastIndex) {
              regex.lastIndex++;
            } // The result can be accessed through the `m`-variable.
            m.forEach((match, groupIndex) => {
              console.log(`Found match, group ${groupIndex}: ${match}`);
              TotalPagNum = match;
            });
          }
        }

        fileContainer.push({ job: files[i].itemcode, total: TotalPagNum });
      });
    }
    res.status(200).send(fileContainer);
  } catch (error) {
    res.status(400).send(error);
  }
};

export const fetchLatestState = async fileName => {
  const sql = `
          WITH WorkOrder AS (
            SELECT workorderid, customerid 
            FROM wms_workorder 
            WHERE itemcode = $1
        ),
        CompletedWorkflow AS (
            SELECT wwe.workorderid, wf.stageid, wwe.stageiterationcount
            FROM wms_workflow_eventlog wwe
            JOIN wms_workflowdefinition wf 
                ON wf.wfdefid = wwe.wfdefid
            WHERE wwe.wfdefid IN (
                SELECT wfdefid
                FROM wms_workflow_eventlog 
                WHERE workorderid = (SELECT workorderid FROM WorkOrder)
                GROUP BY wfdefid
                HAVING COUNT(*) = COUNT(CASE WHEN activitystatus = 'Completed' THEN 1 END)
            ) 
            AND wwe.workorderid = (SELECT workorderid FROM WorkOrder)
            AND wf.stageid <> 10
            AND wwe.updated_date IS NOT NULL  
            ORDER BY wwe.updated_date DESC
            LIMIT 1
        )
        SELECT work_order_id, stageid, stagename, stageiterationcount, incoming_id 
        FROM (
            -- Case when customer ID is 13
            SELECT 
                cw.workorderid AS work_order_id,
                cw.stageid, 
                st.stagename, 
                cw.stageiterationcount, 
                wwi.woincomingfileid AS incoming_id
            FROM CompletedWorkflow cw
            JOIN wms_mst_stage st 
                ON cw.stageid = st.stageid
            JOIN wms_workorder_incoming iwo 
                ON cw.workorderid = iwo.woid
            JOIN wms_workorder_incomingfiledetails wwi 
                ON wwi.woincomingid = iwo.woincomingid
            WHERE (SELECT customerid FROM WorkOrder) = 13

            UNION ALL

            -- Case when customer ID is NOT 13
            SELECT 
                wo.workorderid AS work_order_id,
                LatestWorkOrderStage.wfstageid AS stageid,
                st.stagename, 
                LatestWorkOrderStage.stageiterationcount,
                wwi.woincomingfileid AS incoming_id
            FROM wms_workorder AS wo
            JOIN wms_workorder_incoming AS iwo 
                ON wo.workorderid = iwo.woid
            JOIN wms_mst_stage AS st 
                ON st.stageid = (
                    SELECT wfstageid
                    FROM wms_workorder_stage
                    WHERE workorderid = wo.workorderid 
                        AND status = 'Completed' 
                        AND wfstageid != 10
                    ORDER BY sequence DESC
                    LIMIT 1
                )
            JOIN wms_workorder_stage AS LatestWorkOrderStage
                ON wo.workorderid = LatestWorkOrderStage.workorderid
                AND LatestWorkOrderStage.wfstageid = st.stageid
                AND LatestWorkOrderStage.status = 'Completed'
                AND LatestWorkOrderStage.wfstageid != 10
            JOIN wms_workorder_incomingfiledetails AS wwi 
                ON wwi.woincomingid = iwo.woincomingid
            WHERE wo.itemcode = $1 
            AND (SELECT customerid FROM WorkOrder) <> 13
            LIMIT 1
        ) AS FinalResult;
`;

  try {
    const result = await query(sql, [fileName]);

    if (!result || result.length === 0) {
      return null;
    }

    return {
      workOrderId: result[0]?.work_order_id,
      incomingId: result[0]?.incoming_id,
      stageName: `${result[0]?.stagename} ${result[0]?.stageiterationcount}`,
      stageId: result[0]?.stageid,
      iterationcount: result[0]?.stageiterationcount,
    };
  } catch (error) {
    console.error('Error fetching latest state:', error);
    throw new Error('Failed to fetch the latest state for the file.');
  }
};

export const fetchLatestStageAndFilesService = async fileName => {
  try {
    if (!fileName) {
      throw new Error('File name is required.');
    }

    const latestStageData = await fetchLatestState(fileName);

    if (!latestStageData) {
      return { error: 'No stage found for the given file.' };
    }

    const { workOrderId, stageName, iterationcount, stageId, incomingId } =
      latestStageData;

    const basePath = `/okm:root/prodrepository/cup_journals_7/cup_journals_8/${workOrderId}/typesetting_1/`;
    let path = null;
    let pgInfoPath = null;

    const revisesIteration = await query(
      `select stageiterationcount from wms_workorder_stage where workorderid = ${workOrderId} and wfstageid = 2 order by stageiterationcount desc limit 1`,
    );

    if (stageId == stage.firstProof.id) {
      path = `${basePath}first_proof_1/${iterationcount}/correction_4/1/article_4/${incomingId}`;
    } else if (stageId == stage.revises.id) {
      path = `${basePath}revises_2/${iterationcount}/correction_4/1/article_4/${incomingId}`;
    } else if (stageId == stage.firstView.id) {
      // path = `${basePath}first_view_12/${iterationcount}/package_creation_30/1/article_4/${incomingId}`;
      // pgInfoPath = `${basePath}revises_2/${revisesIteration[0]?.stageiterationcount}/correction_4/1/article_4/${incomingId}`;
      // As per Request Neelakandan Changes Has been done
      const baseIterationResult = await query(
        `SELECT COALESCE(MAX(stageiterationcount), 1) AS revisesmaxiteration 
         FROM wms_workorder_stage 
         WHERE workorderid = $1 AND wfstageid = 2`,
        [workOrderId],
      );

      const maxIteration = baseIterationResult?.[0]?.revisesmaxiteration || 1;

      path = `${basePath}revises_2/${maxIteration}/correction_4/1/article_4/${incomingId}`;
    } else if (stageId == stage.revisedFirstView.id) {
      const finalPdfCreationCheck =
        await query(`select ww.activityalias,ww.activityid from wms_workflow_eventlog wwe
                                            join wms_workflowdefinition ww on ww.wfdefid = wwe.wfdefid  
                                            where wwe.workorderid  = ${workOrderId}
                                            and ww.stageid = ${stage.revisedFirstView.id}
                                            and wwe.activitystatus = 'Completed' and ww.activityid = 147`);
      if (finalPdfCreationCheck.length) {
        path = `${basePath}revised_first_view_32/${iterationcount}/final_pdf_creation_147/1/article_4/${incomingId}`;
      } else {
        path = `${basePath}revised_first_view_32/${iterationcount}/online_qc_27/1/article_4/${incomingId}`;
      }
      pgInfoPath = `${basePath}revises_2/${revisesIteration[0]?.stageiterationcount}/correction_4/1/article_4/${incomingId}`;
    }

    let filesList = [];

    try {
      const allFiles = await azureHelper._listAllFilePath(path);

      filesList = await Promise.all(
        allFiles
          .filter(file => file.path.match(/\.(xml|tex|pdf|pginfo)$/i))
          .map(async file => ({
            downloadPath: file.downloadPath,
            path: file.path,
          })),
      );

      if (pgInfoPath && pgInfoPath.length) {
        const pgInfoFilesFromRevises = await azureHelper._listAllFilePath(
          pgInfoPath,
        );

        const processPgInfoFile = pgInfoFiles => {
          if (!pgInfoFiles.length) return;

          const pgInfoFile = pgInfoFiles.find(file =>
            file.path.endsWith('.pginfo'),
          );

          if (!pgInfoFile) return;

          let pgInfoExists = false;
          filesList = filesList.map(file => {
            if (file.path.endsWith('.pginfo')) {
              pgInfoExists = true;
              return pgInfoFile;
            }
            return file;
          });

          if (!pgInfoExists) {
            filesList.push(pgInfoFile);
          }
        };

        if (pgInfoFilesFromRevises.length) {
          processPgInfoFile(pgInfoFilesFromRevises);
        } else {
          const firstProofIteration = await query(
            `SELECT stageiterationcount FROM wms_workorder_stage WHERE workorderid = ${workOrderId} AND wfstageid = ${stage.firstProof.id} ORDER BY stageiterationcount DESC LIMIT 1`,
          );

          const pgInfoFilesFromFirstProof = await azureHelper._listAllFilePath(
            `${basePath}first_proof_1/${firstProofIteration[0]?.stageiterationcount}/correction_4/1/article_4/${incomingId}`,
          );

          processPgInfoFile(pgInfoFilesFromFirstProof);
        }
      }
    } catch (error) {
      console.error('Error fetching files from Azure Blob:', error);
      return { error: 'Failed to retrieve files from Azure Blob Storage.' };
    }

    return {
      workOrderId,
      stageName,
      iterationcount,
      files: filesList,
    };
  } catch (error) {
    console.error('Error in fetchLatestStageAndFilesService:', error);
    return { error: 'Internal Server Error' };
  }
};

export const fetchLatestStageAndFilesCUPService = async fileName => {
  try {
    if (!fileName) {
      throw new Error('File name is required.');
    }

    const sql = `
      WITH WorkOrder AS (
          SELECT workorderid
          FROM wms_workorder
          WHERE itemcode = $1
      ),
      CompletedStage2 AS (
          SELECT 
              workorderid,
              stageiterationcount
          FROM wms_workorder_stage
          WHERE workorderid = (SELECT workorderid FROM WorkOrder)
            AND wfstageid = 2
            AND status = 'Completed'
          ORDER BY stageiterationcount DESC
          LIMIT 1
      ),
      IncomingDetails AS (
          SELECT 
              iwo.woid AS workorderid,
              wwi.woincomingfileid AS incomingid
          FROM wms_workorder_incoming iwo
          JOIN wms_workorder_incomingfiledetails wwi
              ON wwi.woincomingid = iwo.woincomingid
          WHERE iwo.woid = (SELECT workorderid FROM WorkOrder)
      )
      SELECT 
          cs2.workorderid,
          cs2.stageiterationcount,
          id.incomingid,
          TRUE AS stage2_completed
      FROM CompletedStage2 cs2
      JOIN IncomingDetails id
          ON cs2.workorderid = id.workorderid;
    `;

    const latestStageData = await query(sql, [fileName]);
    if (!latestStageData.length) {
      return { error: 'Revises is not completed for the given file.' };
    }

    const { workorderid: workOrderId, incomingid: incomingId } =
      latestStageData[0];

    const basePath = `/okm:root/prodrepository/cup_journals_7/cup_journals_8/${workOrderId}/typesetting_1/`;
    let path = null;
    let imagePath = null;

    const revisesIteration = await query(
      `SELECT stageiterationcount FROM wms_workorder_stage 
       WHERE workorderid = $1 AND wfstageid = 2 
       ORDER BY stageiterationcount DESC LIMIT 1`,
      [workOrderId],
    );

    const iteration = revisesIteration[0]?.stageiterationcount;
    path = `${basePath}revises_2/${iteration}/completion_trigger__21/1/article_4/${incomingId}`;
    imagePath = `${basePath}revises_2/${iteration}/online_qc_27/1/article_4/${incomingId}`;

    let filesList = [];

    try {
      const allFiles = await azureHelper._listAllFilePath(path);
      const imageFiles = await azureHelper._listAllFilePath(imagePath);

      const docFiles = await Promise.all(
        allFiles
          .filter(file => file.path.match(/\.(xml|pdf)$/i))
          .map(async file => ({
            downloadPath: file.downloadPath,
            path: file.path,
          })),
      );

      // const imageFileList = await Promise.all(
      //   imageFiles
      //     .filter(file =>
      //       file.path.match(/\.(tif|tiff|png|gif|giff|jpg|jpeg)$/i),
      //     )
      //     .map(async file => ({
      //       downloadPath: file.downloadPath,
      //       path: file.path,
      //     })),
      // );

      filesList = [...docFiles, ...imageFiles];
    } catch (error) {
      console.error('Error fetching files from Azure Blob:', error);
      return { error: 'Failed to retrieve files from Azure Blob Storage.' };
    }

    return {
      workOrderId,
      files: filesList,
    };
  } catch (error) {
    console.error('Error in fetchLatestStageAndFilesCUPService:', error);
    return { error: error.message || 'Internal Server Error' };
  }
};
