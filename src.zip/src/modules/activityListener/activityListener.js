import { EventEmitter } from 'events';
import { sendToNotificationQueue } from '../../mq/index.js';

const ACTION = 'action';

class ActivityListener extends EventEmitter {
  emitAction(payload) {
    this.emit(ACTION, payload);
  }
}

const activityListener = new ActivityListener();

activityListener.on(ACTION, async payload => {
  try {
    await sendToNotificationQueue(payload);
  } catch (e) {
    console.log(e);
  }
});

export const emitAction = activityListener.emitAction.bind(activityListener);
