import moment from 'moment';
import fs from 'fs';
import pathConfig, { basename } from 'path';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import { query } from '../../database/postgres.js';
import { getPlaceHolderFields } from '../task/fileDetails.js';
import { _isFileExist } from '../utils/okm/index.js';
import { sendToTaskQueue } from '../../mq/index.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import * as azureHelper from '../utils/azure/index.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';
import { _locallistAllFiles } from '../utils/local/index.js';
import { triggerEngineProcess } from '../woi/workflowTrigger.js';
import { formConfig } from './journalConfig.js';
// Activity Module
// to get the details for master activity
const service = new Service();
export const convertdifferentFileConfig = async (inputJson, wfdefid) => {
  console.log('inn', inputJson, wfdefid);
  return new Promise(async (resolve, reject) => {
    try {
      const outputFormat = {
        files: [],
      };

      for (const fileTypeId in inputJson.fileTypes) {
        if (
          Object.prototype.hasOwnProperty.call(inputJson.fileTypes, fileTypeId)
        ) {
          const fileType = inputJson.fileTypes[fileTypeId];

          // Process files within each file type
          fileType.files.forEach(file => {
            const outputFile = {
              name: file.name,
              fileFlowType: ['IN'],
              fileTypes: [parseInt(fileTypeId)],
              mandatoryCheck: {
                save: file.mandatoryCheck
                  ? file.mandatoryCheck.save === true
                  : false,
                pending: file.mandatoryCheck
                  ? file.mandatoryCheck.pending === true
                  : false,
                cancel: file.mandatoryCheck
                  ? file.mandatoryCheck.cancel === true
                  : false,
                hold: file.mandatoryCheck
                  ? file.mandatoryCheck.hold === true
                  : false,
                reject: file.mandatoryCheck
                  ? file.mandatoryCheck.reject === true
                  : false,
              },
              isUOM: !!file.isUOM,
              softwareOpen: !!file.softwareOpen,
              overwrite: !!file.overwrite,
              backup: {
                enable: false,
                limit: '',
                duration: '',
              },
              custom: [],
            };

            // Check if mandatoryCheck is specified
            if (file.mandatoryCheck && file.mandatoryCheck.save) {
              outputFile.backup.enable = true;
              outputFile.backup.limit = 5;
              outputFile.backup.duration = 60000;
              outputFile.fileFlowType.push('OUT');
            }

            // Check if custom properties are specified
            if (file.custom) {
              outputFile.custom.push(Object.keys(file.custom)[0]);
            }

            // Add the processed file to the output format
            outputFormat.files.push(outputFile);
          });
        }
      }

      const keyToFind = 'name';

      const groupedByValue = outputFormat.files.reduce((result, obj) => {
        const value = obj[keyToFind];

        // Create an array for the value if it doesn't exist
        if (!result[value]) {
          result[value] = [];
        }

        // Push the object to the array
        result[value].push(obj);

        return result;
      }, {});
      console.log(groupedByValue, 'groupedByValue');
      const originalData = [];
      Object.entries(groupedByValue).forEach(([fileName, fileInfoArray]) => {
        console.log(`File Name: ${fileName}`);
        // Iterate over the array of objects for each file name
        fileInfoArray.forEach(fileInfo => {
          const check =
            originalData.length > 0 &&
            originalData.filter(list => list.name == fileInfo.name);
          if (check && check.length > 0) {
            const index = originalData.findIndex(
              item => item.name === check[0].name,
            );
            originalData[index].fileTypes.push(fileInfo.fileTypes[0]);
          } else {
            originalData.push(fileInfo);
          }
          console.log(' Object:', fileInfo);
        });
      });
      const newFiles = { files: originalData };
      const newFileConfig = JSON.stringify(newFiles);
      console.log(newFileConfig, 'newFileConfig');
      const sql = `update wms_workflowdefinition set fileconfig='${newFileConfig}' where wfdefid =${wfdefid}`;
      console.log(sql, 'sql');
      await query(sql);
      resolve();
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

// This part check for different filetypes like Book

export const convertdifferentFileConfigAll = async (req, res) => {
  console.log(req, res);
  const { stageid, wfid, _wfdefid } = req.body;
  console.log(stageid, wfid, 'tesss');
  try {
    let sql = ``;
    if (_wfdefid) {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and activityid !=21 and wfdefid =${_wfdefid} and fileconfig IS NOT NULL
      order by sequence `;
    } else {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and  activityid !=21 and stageid =${stageid} and fileconfig IS NOT NULL 
      order by sequence `;
    }

    console.log(sql, 'sql');
    const fileInfo = await query(sql);
    for (let i = 0; i < fileInfo.length; i++) {
      const inputPayload = fileInfo[i].fileconfig_old;
      const { wfdefid } = fileInfo[i];
      await convertdifferentFileConfig(inputPayload, wfdefid);
    }
    res
      .status(200)
      .json({ message: 'Fileconfig has been updated successfully' });
  } catch (error) {
    res.status(400).json({ message: 'Fileconfig update failed' });
    console.log(error);
  }
};

// end different filetypes

// This part only for fileconfig start
export const _convertNewFileConfig = async (inputPayload, wfdefid) => {
  console.log('inn', inputPayload, wfdefid);
  return new Promise(async (resolve, reject) => {
    try {
      // if (inputPayload.fileTypes && inputPayload.fileTypes.length > 0) {
      const type = JSON.parse(Object.keys(inputPayload.fileTypes)[0]);
      const files1 = inputPayload.fileTypes[type].files.map(file => {
        const convertedFile = {
          name: file.name,
          fileFlowType: ['IN'],
          fileTypes: [type],
          mandatoryCheck: {
            save: file.mandatoryCheck
              ? file.mandatoryCheck.save === true
              : false,
            pending: file.mandatoryCheck
              ? file.mandatoryCheck.pending === true
              : false,
            cancel: file.mandatoryCheck
              ? file.mandatoryCheck.cancel === true
              : false,
            hold: file.mandatoryCheck
              ? file.mandatoryCheck.hold === true
              : false,
            reject: file.mandatoryCheck
              ? file.mandatoryCheck.reject === true
              : false,
          },
          isUOM: !!file.isUOM,
          softwareOpen: !!file.softwareOpen,
          overwrite: !!file.overwrite,
          backup: {
            enable: false,
            limit: '',
            duration: '',
          },
          custom: [],
        };

        if (file.mandatoryCheck && file.mandatoryCheck.save) {
          convertedFile.backup.enable = true;
          convertedFile.backup.limit = 5;
          convertedFile.backup.duration = 60000;
          convertedFile.fileFlowType.push('OUT');
        }

        if (file.custom) {
          convertedFile.custom.push(Object.keys(file.custom)[0]);
        }

        return convertedFile;
      });
      const newFiles = { files: files1 };
      console.log(newFiles, 'newFiles');

      const newFileConfig = JSON.stringify(newFiles);
      console.log(newFileConfig, 'newFileConfig');
      const sql = `update wms_workflowdefinition set fileconfig='${newFileConfig}' where wfdefid =${wfdefid}`;
      console.log(sql, 'sql');
      await query(sql);
      // }
      resolve();
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

export const convertNewFileConfig = async (req, res) => {
  console.log(req, res);
  const { stageid, wfid, _wfdefid } = req.body;
  console.log(stageid, wfid, 'tesss');
  try {
    let sql = ``;
    if (_wfdefid) {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and activityid !=21 and wfdefid =${_wfdefid} and fileconfig IS NOT NULL
      order by sequence `;
    } else {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and  activityid !=21 and stageid =${stageid} and fileconfig IS NOT NULL 
      order by sequence `;
    }

    console.log(sql, 'sql');
    const fileInfo = await query(sql);
    for (let i = 0; i < fileInfo.length; i++) {
      const inputPayload = fileInfo[i].fileconfig_old;
      const { wfdefid } = fileInfo[i];
      await _convertNewFileConfig(inputPayload, wfdefid);
    }
    res
      .status(200)
      .json({ message: 'Fileconfig has been updated successfully' });
  } catch (error) {
    res.status(400).json({ message: 'Fileconfig update failed' });
    console.log(error);
  }
};

// This part only for config start
export const converNewConfig = async (req, res) => {
  console.log(req, res);
  const { stageid, wfid, _wfdefid } = req.body;
  console.log(stageid, wfid, 'tesss');
  try {
    let sql = ``;
    if (_wfdefid) {
      sql = `select  config_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and  activityid !=21 and wfdefid =${_wfdefid} and config IS NOT NULL order by sequence `;
    } else {
      sql = `select  config_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and  activityid !=21 and config IS NOT NULL
      order by sequence `;
    }

    console.log(sql, 'sql');
    const confInfo = await query(sql);
    const response = [];
    for (let i = 0; i < confInfo.length; i++) {
      const inputPayload = confInfo[i].config_old;
      const { wfdefid } = confInfo[i];
      const res1 = await _convertNewConfig(inputPayload, wfdefid);
      response.push(res1);
    }
    res
      .status(200)
      .json({ message: `Config has been updated successfully ${response}` });
  } catch (error) {
    res.status(400).json({ message: 'Config update failed' });
    console.log(error);
  }
};

export const _convertNewConfig = async (originalData, wfdefid) => {
  console.log('inn', originalData, wfdefid);
  return new Promise(async (resolve, reject) => {
    try {
      if (originalData.actions && originalData.actions.workflow) {
        const convertedData = {
          displayName: originalData.displayName,
          os: originalData.os,
          isTypesetPage: originalData.isTypesetPage,
          fileType: 'Batch',
          actions: {
            workflow: {
              save: originalData.actions.workflow.save,
              reject: originalData.actions.workflow.reject,
              hold: originalData.actions.workflow.hold,
              cancel: originalData.actions.workflow.cancel,
              pending: originalData.actions.workflow.pending,
            },
          },
          softwareId: originalData.softwareId,
          toolsId: originalData.toolsId,
          type: originalData.type,
          postActivity: originalData.postActivity,
          preActivity: [],
          onSaveToolsId: [],
          newFileTypes: [],
          newFileTypesExt: [],
          graphicFileFormat: [],
          fileCombination: [],
          allowedFileExtension: [],
          skipFileExtension: [],
        };
        console.log(convertedData, 'convertedData');

        const newConfig = JSON.stringify(convertedData);
        console.log(newConfig, 'newFileConfig');
        const sql = `update wms_workflowdefinition set config='${newConfig}' where wfdefid =${wfdefid}`;
        console.log(sql, 'sql');
        await query(sql);
        resolve();
      } else {
        resolve(`${wfdefid} config is different`);
      }
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

// config end

// This part only for toolconfig start

export const convertNewToolConfig = async (req, res) => {
  console.log(req, res);

  const { stageid, wfid, _wfdefid } = req.body;
  try {
    let sql = '';
    if (_wfdefid) {
      sql = `select  toolsconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and  activityid !=21 and stageid =${stageid} and wfdefid =${_wfdefid}
      and toolsconfig IS NOT NULL order by sequence `;
    } else {
      sql = `select  toolsconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and  activityid !=21
      and toolsconfig IS NOT NULL order by sequence `;
    }

    console.log(sql, 'sql');
    const toolsInfo = await query(sql);
    for (let i = 0; i < toolsInfo.length; i++) {
      const inputPayload = toolsInfo[i].toolsconfig_old;
      const { wfdefid } = toolsInfo[i];
      await _convertNewToolConfig(inputPayload, wfdefid);
    }

    res
      .status(200)
      .json({ message: 'Toolconfig has been updated successfully' });
  } catch (error) {
    console.log(error);
    res.status(400).json({ message: 'Toolconfig update failed' });
  }
};
export const _convertNewToolConfig = async (originalData, wfdefid) => {
  console.log(originalData, 'originalData');

  return new Promise(async (resolve, reject) => {
    try {
      const convertedData = {
        tools: {},
      };
      console.log(convertedData, 'convertedData');

      for (const toolId of Object.keys(originalData.tools)) {
        console.log(toolId);

        const originalTool = originalData.tools[toolId];
        const convertedTool = {
          isToolClick: !!originalTool.isToolClick,
          params:
            originalTool && originalTool.params ? originalTool.params : '',
          files: [],
        };

        console.log(convertedTool, 'convertedTool');

        Object.keys(originalTool.files.input).forEach(inputFileName => {
          const inputFile = originalTool.files.input[inputFileName];
          const params1 =
            inputFile &&
            'params' in inputFile &&
            inputFile.params &&
            inputFile.params.length
              ? inputFile.params
              : '';
          convertedTool.params =
            convertedTool &&
            'params' in convertedTool &&
            convertedTool.params &&
            convertedTool.params.length
              ? convertedTool.params
              : '';

          const fileName =
            inputFile.src && inputFile.src.name
              ? inputFile.src.name
              : inputFile.name;
          const aliasName = fileName.includes('_')
            ? fileName.match(/_([^\.]+)/)[1]
            : '';
          const inputFileType =
            inputFile.src && inputFile.src.typeId
              ? inputFile.src.typeId
              : inputFile.typeId;
          // convertedTool.params.push(
          convertedTool.params =
            convertedTool &&
            'params' in convertedTool &&
            convertedTool.params &&
            convertedTool.params.length
              ? convertedTool.params
              : params1;
          // );
          // console.log(check, 'check');
          convertedTool.files.push({
            // params: params1,
            name: fileName,
            fileTypes: Array.isArray(inputFileType)
              ? inputFileType
              : [inputFileType],
            fileFlowType: ['IN'],
            aliasKey: aliasName,
          });
        });
        Object.entries(originalTool.files.output).forEach(
          ([fileName, fileInfoArray]) => {
            console.log(`File Name: ${fileName}`);
            // Iterate over the array of objects for each file name
            // fileInfoArray.forEach(fileInfo => {
            const check =
              convertedTool.files.length > 0 &&
              convertedTool.files.filter(
                list => list.name == fileInfoArray.name,
              );
            if (check && check.length > 0) {
              const index = convertedTool.files.findIndex(
                item => item.name === check[0].name,
              );
              convertedTool.files[index].fileFlowType.push('OUT');
              convertedTool.files[index].fileopen = true;
            } else {
              // originalData.push(fileInfo);
              console.log(fileInfoArray, 'fileInfoArray');
              const aliasName = fileInfoArray.name.includes('_')
                ? fileInfoArray.name.match(/_([^\.]+)/)[1]
                : '';
              const parameter =
                fileInfoArray && fileInfoArray.params
                  ? fileInfoArray.params
                  : [];

              convertedTool.params =
                convertedTool &&
                'params' in convertedTool &&
                convertedTool.params &&
                convertedTool.params.length
                  ? convertedTool.params
                  : '';

              convertedTool.params =
                convertedTool &&
                'params' in convertedTool &&
                convertedTool.params.length
                  ? convertedTool.params
                  : parameter;
              // console.log(parameter1, 'parameter1');
              // convertedTool.params.pushparameter;
              convertedTool.files.push({
                name: fileInfoArray.name,
                fileTypes: Array.isArray(fileInfoArray.typeId)
                  ? fileInfoArray.typeId
                  : [fileInfoArray.typeId],
                fileFlowType: ['OUT'],
                aliasKey: aliasName,
                fileopen: fileInfoArray.fileopen || false,
              });
            }
            // });
          },
        );

        // Object.keys(originalTool.files.output).forEach(outputFileName => {
        //   const outputFile = originalTool.files.output[outputFileName];
        //   const outputFileType = outputFile.typeId;
        //   const aliasName = outputFile.name.includes('_')
        //     ? outputFile.name.match(/_([^\.]+)/)[1]
        //     : '';
        //   convertedTool.files.push({
        //     name: outputFile.name,
        //     fileTypes: Array.isArray(outputFileType)
        //       ? outputFileType
        //       : [outputFileType],
        //     fileFlowType: ['OUT'],
        //     aliasKey: aliasName,
        //     fileopen: outputFile.fileopen || false,
        //   });
        // });

        convertedData.tools[toolId] = convertedTool;
      }
      console.log(convertedData, 'convertedData');
      const fileData = JSON.stringify(convertedData);
      console.log(fileData, 'fileData');
      const sql = `update wms_workflowdefinition set toolsconfig='${fileData}' where wfdefid =${wfdefid}`;
      console.log(sql, 'sql');
      await query(sql);
      resolve();
    } catch (error) {
      console.log(error);
      reject(error);
    }
  });
};

// This part only for toolconfig end

// convertNewToolConfig({
//   tools: {
//     284: {
//       isToolClick: true,
//       isFileOpen: true,
//       files: {
//         input: {
//           xml: {
//             name: ';FileTypeName;.xml',
//             typeId: 4,
//           },
//           figure: {
//             name: 'Figure.txt',
//             typeId: 4,
//             isSync: false,
//           },
//           bookDetails: {
//             name: 'BookDetails.xml',
//             typeId: 4,
//             isSync: false,
//           },
//           xml_export: {
//             name: 'xml_export_;articleno;_*.xml',
//             typeId: 4,
//             isSync: false,
//           },
//           po_Pdf: {
//             name: ';FileTypeName;_po_*.pdf',
//             typeId: 4,
//             isSync: false,
//           },
//         },
//         output: {
//           pdf: {
//             name: ';FileTypeName;.pdf',
//             typeId: [4],
//             fileopen: true,
//           },
//           aux: {
//             name: ';FileTypeName;.aux',
//             typeId: [4],
//           },
//           tex: {
//             name: ';FileTypeName;.tex',
//             typeId: [4],
//           },
//           xml: {
//             name: ';FileTypeName;.xml',
//             typeId: [4],
//             cancelFile: true,
//           },
//           reportLog: {
//             name: 'Report.log',
//             typeId: [4],
//           },
//         },
//       },
//     },
//     264: {
//       isToolClick: true,
//       params: [],
//       files: {
//         input: [
//           {
//             params: [';__FILE__;'],
//             src: {
//               name: ';FileTypeName;.xml',
//               typeId: [4],
//             },
//             dest: '',
//           },
//         ],
//         output: [],
//         outputFileValidation: [
//           {
//             name: ';FileTypeName;_err.htm',
//             type: 'Single',
//             typeId: [
//               {
//                 id: 4,
//                 isRequired: true,
//               },
//             ],
//           },
//         ],
//       },
//     },
//   },
// });

export const getActivityMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_mst_activity order by 1 desc`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.wms_mst_activity order by activityname`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in activity master
export const createActivity = (req, res) => {
  const reqData = req.body;
  const status = reqData.status == '1';

  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.wms_mst_activity(activityname,activitydescription, isactive) 
        VALUES ('${reqData.activityName}', '${reqData.activitydescription}',${status})`;
  } else {
    sql = `UPDATE public.wms_mst_activity
        SET activityname='${reqData.activityName}',activitydescription= '${reqData.activitydescription}' ,isactive=${status}
        WHERE activityid =${reqData.id}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Activity  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from activity master
export const deleteActivity = (req, res) => {
  const reqData = req.body;

  const sql = `DELETE FROM public.wms_mst_activity WHERE activityid =${reqData.activityId}`;

  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Activity has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Stage module
// get the details for stage master

export const getStageMasterList = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });

    sql = `SELECT COUNT(*) FROM public.wms_mst_stage ${
      condition ? `WHERE${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM public.wms_mst_stage ${
      condition ? `WHERE${condition}` : condition
    }`;
  }

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `SELECT * FROM public.wms_mst_stage ${
          condition ? `WHERE${condition}` : condition
        } order by stagename `;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in activity master
export const createStage = (req, res) => {
  const reqData = req.body;
  const status = reqData.status == '1';

  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.wms_mst_stage(stagename,stagedescription, isactive) 
        VALUES ('${reqData.stageName}','${reqData.stageDesc}' ,${status})`;
  } else {
    sql = `UPDATE public.wms_mst_stage
        SET stagename='${reqData.stageName}', stagedescription = '${reqData.stageDesc}', isactive=${status}
        WHERE stageid =${reqData.id}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Stage  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from stage master
export const deleteStage = (req, res) => {
  const reqData = req.body;

  const sql = `DELETE FROM public.wms_mst_stage WHERE stageid =${reqData.stageId}`;

  query(sql)
    .then(() => {
      res.status(200).json({ message: 'Stage has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// SubDivision Module
// get the details for  Subdivision master
export const getSubDivisionMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.org_mst_subdivision`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.org_mst_subdivision order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in division master
export const createSubDivision = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.org_mst_subdivision(subdivision) 
        VALUES ('${reqData.SubDivisionName}')`;
  } else {
    sql = `UPDATE public.org_mst_subdivision
        SET subdivision='${reqData.SubDivisionName}'
        WHERE subdivisionid =${reqData.id}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Division  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to delete a row from SubDivision master
export const deleteSubDivision = (req, res) => {
  const reqData = req.body;

  const sql = `DELETE FROM public.org_mst_subdivision WHERE subdivisionid =${reqData.subDivisionId}`;

  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'SubDivison has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// divison module
// get the details for  division master
export const getDivisionMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.org_mst_division `;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.org_mst_division order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in division master
export const createDivision = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.org_mst_division(division) 
        VALUES ('${reqData.divisionName}')`;
  } else {
    sql = `UPDATE public.org_mst_division
        SET division='${reqData.divisionName}'
        WHERE divisionid =${reqData.id}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Division  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to delete a row from Division master
export const deleteDivision = (req, res) => {
  const reqData = req.body;

  const sql = `DELETE FROM public.org_mst_division WHERE divisionid =${reqData.divisionId}`;

  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Divison has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Location Module
// to get the details for master Location
export const getLocationMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.geo_mst_country`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.geo_mst_country order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in location master
export const createLocation = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.geo_mst_country(countryname) 
        VALUES ('${reqData.locationName}')`;
  } else {
    sql = `UPDATE public.geo_mst_country
        SET countryname='${reqData.locationName}'
        WHERE countryid =${reqData.id}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Location  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from location master
export const deleteLocation = (req, res) => {
  const reqData = req.body;

  const sql = `DELETE FROM public.geo_mst_country WHERE countryid =${reqData.locationId}`;

  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Location has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Color Module
// to get the details for master color
export const getColorMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.pp_mst_color`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.pp_mst_color order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in color master
export const createColor = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.pp_mst_color(color) 
        VALUES ('${reqData.colorName}')`;
  } else {
    sql = `UPDATE public.pp_mst_color
        SET color='${reqData.colorName}'
        WHERE colorid =${reqData.id}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Color  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from color master
export const deleteColor = (req, res) => {
  const reqData = req.body;

  const sql = `DELETE FROM public.pp_mst_color WHERE colorid =${reqData.colorId}`;

  query(sql)
    .then(() => {
      res.status(200).json({ message: 'Color has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Software Module
// to get the details for master Software
export const getSoftwareMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.pp_mst_composingsoftware`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.pp_mst_composingsoftware order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in software master
export const createSoftware = (req, res) => {
  const reqData = req.body;
  const status = reqData.status == '1';

  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO  public.pp_mst_composingsoftware(softwarename, isactive) 
        VALUES ('${reqData.softwareName}',${status})`;
  } else {
    sql = `UPDATE  public.pp_mst_composingsoftware
        SET softwarename='${reqData.softwareName}', isactive=${status}
        WHERE softwareid =${reqData.id}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Software  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to delete a row from software master
export const deleteSoftware = (req, res) => {
  const reqData = req.body;

  const sql = `DELETE FROM  public.pp_mst_composingsoftware WHERE softwareid =${reqData.softwareId}`;

  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Software has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const userList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_user as users
        LEFT JOIN  geo_mst_country as country ON users.countryid = country.countryid
        LEFT JOIN  org_mst_deliveryunit as du ON users.duid = du.duid`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT users.userid, users.username, users.userpassword, users.useractive, users.useremail, users.duid, du.duname, users.designation, users.countryid, country.countryname, users.useraddress, users.userphone, users.usertype
            FROM public.wms_user as users
             LEFT JOIN  geo_mst_country as country ON users.countryid = country.countryid
             LEFT JOIN  org_mst_deliveryunit as du ON users.duid = du.duid
           order by username`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const OptionList = (req, res) => {
  const reqData = req.body;
  let sql = '';

  if (reqData.type == 'country') {
    sql = `SELECT countryid as value , countryname as label FROM public.geo_mst_country ORDER BY countryid ASC `;
  } else if (reqData.type == 'du') {
    sql = `SELECT duid as value , duname as label FROM public.org_mst_deliveryunit ORDER BY duid ASC `;
  } else if (reqData.type == 'role') {
    sql = `SELECT roleid as value , rolename as label FROM public.wms_role ORDER BY roleid ASC `;
  } else if (reqData.type == 'skill') {
    sql = `SELECT skillid as value , skillname as label FROM public.wms_mst_skill ORDER BY skillid ASC `;
  } else if (reqData.type == 'skilllevel') {
    sql = `SELECT skilllevelid as value , skilllevel as label FROM public.wms_mst_skilllevel ORDER BY skilllevelid ASC `;
  } else if (reqData.type == 'certlevel') {
    sql = `SELECT certlevelid as value , certlevel as label FROM public.wms_mst_certificationlevel ORDER BY certlevelid ASC `;
  } else if (reqData.type == 'software') {
    sql = `SELECT softwareid as value , softwarename as label FROM public.pp_mst_composingsoftware ORDER BY softwareid ASC `;
  } else if (reqData.type == 'bandlevel') {
    sql = `SELECT bandlevelid as value , bandlevel as label FROM public.mst_bandlevel ORDER BY bandlevelid ASC `;
  } else if (reqData.type == 'appraisaltype') {
    sql = `SELECT empapp_id as value , appraisaltype as label FROM iaspire.mst_emp_appraisal ORDER BY empapp_id ASC`;
  } else if (reqData.type == 'pbtype') {
    sql = `SELECT categoryid as value , app_type as label FROM iaspire.mst_appraisaltype ORDER BY categoryid ASC`;
  } else if (reqData.type == 'userlist') {
    sql = `SELECT userid as value , username as label FROM public.wms_user ORDER BY userid ASC `;
  }
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const userRoleList = (req, res) => {
  const reqData = req.body;

  let sql = '';
  let condition;
  if (reqData.type == 'role') {
    if (reqData.userid == null) {
      sql = `select  null as userroleid, null as userid, null as roleid, null as effectivedate, null as isactive, null as isdefault from wms_userrole limit 1`;
    } else {
      condition = `wms_userrole.userid='${reqData.userid}'`;
      // sql = `SELECT wms_userrole.userid, wms_userrole.userroleid ,wms_userrole.effectivedate,wms_userrole.roleid, wms_userrole.isdefault,wms_role.rolename,wms_role.isactive FROM public.wms_userrole left join wms_role on wms_userrole.roleid=wms_role.roleid WHERE ${condition}`;
      // sql = `SELECT * FROM public.wms_userrole WHERE ${condition}`
      sql = `SELECT distinct on (roleid) userroleid, userid, roleid, effectivedate, isactive, isdefault FROM public.wms_userrole WHERE ${condition}`;
    }
  } else if (reqData.type == 'skill') {
    if (reqData.userid == null) {
      sql = `SELECT null as userid, null as username, null as userpassword, null as useractive, null as useremail, null as duid, null as designation, null as countryid, null as useraddress, null as userphone, null as usertype, null as issuperuser, null as mappedduid FROM public.wms_user limit 1`;
    } else {
      condition = `wms_userskill.userid='${reqData.userid}'`;
      // sql = `SELECT * FROM public.wms_userskill WHERE ${condition}`
      sql = `SELECT distinct on (skillid) userskillid,userid, skillid,isactive, effectivefrom, skillelvelid, composingswid, certlevelid
        FROM public.wms_userskill  WHERE ${condition}`;
    }
  } else if (reqData.type == 'user') {
    if (reqData.userid == null) {
      sql = `SELECT null as userid, null as username, null as userpassword, null as useractive, null as useremail, null as duid, null as designation, null as countryid, null as useraddress, null as userphone, null as usertype, null as issuperuser, null as mappedduid FROM public.wms_user limit 1`;
    } else {
      condition = `wms_user.userid='${reqData.userid}'`;
      // sql = `SELECT * FROM public.wms_user WHERE ${condition}`;
      sql = `
      SELECT l2.userid AS l2, l3.userid AS l3, wms_user.*
      FROM public.wms_user
      LEFT JOIN public.wms_user AS l2 ON wms_user.reportingto = l2.userid
      LEFT JOIN public.wms_user AS l3 ON l2.reportingto = l3.userid
      WHERE ${condition}
    `;
    }
  }

  query(sql)
    .then(response => {
      if (reqData.type == 'skill') {
        const skillData = response;
        if (response.length > 0 && reqData.userid != null) {
          const skillId = response.map(data => data.skillid);
          sql = `SELECT * FROM public.wms_tasklist WHERE wms_tasklist.userid = '${reqData.userid}' AND wms_tasklist.skillid  IN (${skillId})`;

          query(sql)
            .then(resp => {
              // updated for fileconfig restructure
              resp.forEach(item => {
                item.fileconfig = ReStructureFileConfig(item.fileconfig);
              });
              res.status(200).json({
                data: {
                  skill: skillData,
                  taskList: resp,
                },
              });
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        } else
          res.status(200).json({
            data: {
              skill: skillData,
              taskList: [],
            },
          });
      } else res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in user list master
export const createUser = (req, res) => {
  const reqData = req.body.data.info;

  /** ***********Create Object then convert to json and pass to dbfunction as json parameter*************** */

  const roleobjarray = req.body.data.role.map(item => {
    const conObj = {};
    conObj.userroleid = item.userroleid;
    conObj.userid = item.userid;
    conObj.roleid = item.roleid;
    conObj.effectivedate = item.effectivedate;
    conObj.isactive = item.isactive;
    conObj.isdefault = item.isdefault;

    return conObj;
  });

  const skillobjarray = req.body.data.skill.map(item => {
    const skillObj = {};
    skillObj.userskillid = item.userskillid;
    skillObj.userid = item.userid;
    skillObj.skillid = item.skillid;
    skillObj.isactive = item.isactive;
    skillObj.effectivefrom = item.effectivefrom;
    skillObj.skillelvelid = item.skillelvelid;
    skillObj.composingswid = item.composingswid;
    skillObj.certlevelid = item.certlevelid;
    return skillObj;
  });

  const jroles = JSON.stringify(roleobjarray);
  const jskill = JSON.stringify(skillobjarray);

  const checkUser = `select * from public.wms_user where userid = '${reqData.userid}'`;
  let checkUserLen;

  query(checkUser).then(async response => {
    console.log(response);
    checkUserLen = response.length;

    let sql = '';
    if (!checkUserLen) {
      sql = `INSERT INTO public.wms_user(duid,useractive,useraddress,useremail,userphone,userid,username,designation) 
        VALUES (${reqData.duid},${reqData.useractive},'${reqData.useraddress}','${reqData.useremail}',${reqData.userphone},'${reqData.userid}','${reqData.username}','${reqData.designation}')`;
    } else {
      // sql = `UPDATE public.wms_user
      //   SET duid='${reqData.duid}' , useractive=${reqData.useractive} , useraddress='${reqData.useraddress}' , useremail='${reqData.useremail}' , userphone='${reqData.userphone}'
      //   WHERE userid ='${reqData.userid}'`;

      sql = `
      UPDATE public.wms_user
      SET
        useractive=${reqData.useractive},
        useremail='${reqData.useremail}',
        duid='${reqData.duid}',
        ${
          reqData.designationid
            ? `designationid='${reqData.designationid}',`
            : ''
        }
        countryid='${reqData.countryid}',
        useraddress='${reqData.useraddress}',
        ${reqData.userphone ? `userphone='${reqData.userphone}',` : ''}
        reportingto='${reqData.reportingto}',
        ${reqData.doj ? `doj='${reqData.doj}',` : ''}
        ${
          reqData.relievingdate
            ? `relievingdate='${reqData.relievingdate}',`
            : ''
        }
        ${reqData.bandlevelid ? `bandlevelid=${reqData.bandlevelid},` : ''}
        ${reqData.categoryid ? `categoryid='${reqData.categoryid}',` : ''}
        ${reqData.duhead ? `duhead='${reqData.duhead}',` : ''}
        ${
          reqData.functionalhead
            ? `functionalhead='${reqData.functionalhead}',`
            : ''
        }
        ${reqData.gender ? `gender='${reqData.gender}',` : ''}
        username='${reqData.username}'
        WHERE wms_user.userid ='${reqData.userid}';
    `;
    }

    query(sql)
      .then(async () => {
        // await createRole(jroles)
        // await createSkill(jskill)
        /** **********User and Skill will create in db function call in loop manner *************** */
        const usql = `select * from userroleskillmap('${jroles}','${jskill}')`;
        console.log(usql, 'roleandskillqry');
        query(usql)
          .then(resp => {
            console.log(resp);
            if (resp) {
              if (resp.length > 0) {
                if (resp[0].id == 'done') {
                  res
                    .status(200)
                    .json({ message: 'User information added successfully' });
                } else {
                  res
                    .status(400)
                    .json({ message: 'User information not added' });
                }
              }
            }
          })
          .catch(err => {
            res.status(400).json({ message: err });
          });

        /** ***************************************************************
         *   old coding - not in use...
         *   same process moved to db function         
         * ***************************************************************
        if (req.body.data.role.length > 0) req.body.data.role.map(data => {
            const reqData = data;
            userrolemap
            
            
            if (reqData.userroleid === "") {
                sql = `INSERT INTO public.wms_userrole(userid, roleid, effectivedate, isactive , isdefault) 
                VALUES ('${reqData.userid}', '${reqData.roleid}', '${reqData.effectivedate}', ${reqData.isactive}, ${reqData.isdefault})`;
            } else {
                sql = `UPDATE public.wms_userrole
                SET isactive=${reqData.isactive} , roleid='${reqData.roleid}'
                WHERE userroleid ='${reqData.userroleid}'`;
            }
            
            query(sql).then((response) => {
                // res.status(200).json({ message: `User Role has been ${reqData.userroleid ? 'updated' : 'added'} successfully` });

                if (req.body.data.skill.length > 0) req.body.data.skill.map(data => {
                    const reqData = data;
                    
                    let sql = '';
                    if (reqData.userskillid === "") {
                        sql = `INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid) 
                        VALUES ('${reqData.userid}','${reqData.skillid}',${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid})`;
                    }
                    else {
                        sql = `UPDATE public.wms_userskill
                        SET skillid='${reqData.skillid}', isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
                        WHERE userskillid ='${reqData.userskillid}'`;
                    }
                    
                    query(sql).then((response) => {
                        res.status(200).json({ message: `User information has been ${reqData.userskillid ? 'updated' : 'added'} successfully` });
                    }).catch((error) => {
                        res.status(400).send({ message: error });
                    });
                })
                else res.status(200).json({ message: `User information has been ${reqData.userroleid ? 'updated' : 'added'} successfully` });


            }).catch((error) => {
                res.status(400).send({ message: error });
            });
        })

        else {
            if (req.body.data.skill.length > 0) req.body.data.skill.map(data => {
                const reqData = data;
                
                let sql = '';
                if (reqData.userskillid === "") {
                    sql = ` if not exists (select * from wms_userskill where userid = '${reqData.userid}' and skillid = '${reqData.skillid}' and isactive = ${reqData.isactive}) then
                    INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid) 
                    VALUES ('${reqData.userid}','${reqData.skillid}',${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid})
                    end if;
                    `;
                }
                else {
                    sql = `UPDATE public.wms_userskill
                    SET skillid='${reqData.skillid}', isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
                    WHERE userskillid ='${reqData.userskillid}'`;
                }
                
                query(sql).then((response) => {
                    res.status(200).json({ message: `User information has been ${reqData.userskillid ? 'updated' : 'added'} successfully` });
                }).catch((error) => {
                    res.status(400).send({ message: error });
                });
            })
            else res.status(200).json({ message: `User information has been ${reqData.userroleid ? 'updated' : 'added'} successfully` });
        } */
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  });
};

export const createRole = async (req, res) => {
  try {
    const awaits = [];
    if (req.body.type === 'role') {
      req.body.data.forEach(data => {
        const reqData = data;

        let sql = '';
        if (reqData.userroleid === '') {
          sql = `INSERT INTO public.wms_userrole(userid, roleid, effectivedate, isactive , isdefault) 
                VALUES ('${req.body.userid}', '${reqData.roleid}', '${reqData.effectivedate}', ${reqData.isactive}, ${reqData.isdefault}) RETURNING userroleid`;
        } else {
          sql = `UPDATE public.wms_userrole
                SET isactive=${reqData.isactive} , roleid='${reqData.roleid}'
                WHERE userroleid ='${reqData.userroleid}' RETURNING userroleid`;
        }
        awaits.push(query(sql));
      });
    }
    await Promise.all(awaits);
    res
      .status(200)
      .json({ message: `User Role has been updated successfully`, data: {} });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const createSkill = async (req, res) => {
  try {
    const awaits = [];
    req.body.data.forEach(data => {
      const reqData = data;

      console.log(reqData.userskillid, 'reqData.userskillid');
      let sql;
      if (reqData.userskillid == '') {
        sql = `INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid) 
                VALUES ('${req.body.userList.userid}',${reqData.skillid},${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid})`;
      } else {
        sql = `UPDATE public.wms_userskill
                SET skillid=${reqData.skillid}, isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
                WHERE userskillid =${reqData.userskillid}`;
      }
      console.log(sql, 'ifblock');
      awaits.push(query(sql));
    });
    await Promise.all(awaits);
    res
      .status(200)
      .json({ message: `User Skill has been updated successfully`, data: {} });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};
// export const createSkill = (req, res) => {
//     req.body.data.map(data => {
//         const reqData = data;
//
//         let sql = '';
//         if (reqData.userskillid === "") {
//             sql = `INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid)
//                 VALUES ('${req.body.userList.userid}','${reqData.skillid}',${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid}) RETURNING userskillid`;
//         }
//         else {
//             sql = `UPDATE public.wms_userskill
//                 SET skillid='${reqData.skillid}', isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
//                 WHERE userskillid ='${reqData.userskillid}' RETURNING userskillid`;
//         }
//
//         query(sql).then((response) => {
//             res.status(200).json({ message: `User Skill has been ${reqData.userskillid ? 'updated' : 'added'} successfully`, data: response });
//         }).catch((error) => {
//             res.status(400).send({ message: error });
//         });
//     })
// }
// export const createSkill = async (req, res) => {
//     try {
//         let awaits = [];
//         req.body.data.map(data => {
//             const reqData = data;
//
//             console.log(reqData.userskillid, 'reqData.userskillid');
//                 let sql = `
//                 DO $$ begin
//                     if((select count(1) from public.wms_userskill where  userid = '${req.body.userList.userid}' and skillid = ${reqData.skillid}) > 0 ) then
//                         UPDATE public.wms_userskill
//                         SET skillid=${reqData.skillid}, isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
//                         WHERE userskillid =${reqData.userskillid};
//                     else
//                         INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid)
//                         VALUES ('${req.body.userList.userid}',${reqData.skillid},${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid}) ;
//                     end if;
//                 end $$;
//                 `;
//                 console.log(sql,'ifblock');
//                 awaits.push(query(sql));
//         });
//         await Promise.all(awaits)
//         res.status(200).json({ message: `User Skill has been updated successfully` , data: {}});
//     } catch (error) {
//         res.status(400).send({ message: error.message });
//     }
// }

export const deleteSkill = (req, res) => {
  const reqData = req.body;

  let sql = '';
  if (reqData.type == 'skill') {
    sql = `DELETE FROM  public.wms_userskill WHERE userskillid =${reqData.userSkillId}`;
  } else if (reqData.type == 'role') {
    sql = `DELETE FROM  public.wms_userrole WHERE userroleid =${reqData.userRoleId}`;
  }

  query(sql)
    .then(() => {
      res.status(200).json({ message: 'Skill has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getLibraryTempList = (req, res) => {
  let sql = '';
  sql = `select count(distinct (templatename)) 
        FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
        join public.org_mst_deliveryunit as du on du.duid =t.duid
        join public.org_mst_customer as cus on cus.customerid =t.customerid  
        join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
        where isdelete=false`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = ` select * from 
    (SELECT distinct on (t.templatename) du.duname,cus.customername, tt.libraryname, sw.softwarename, sw.softwareid,t.templatename,t.templateid,
     t.composingswid,t.duid,t.customerid,t.uploadedby,t.uploadeddate,t.templateuuid,t.templatefilepath,t.isdelete,t.templatetypeid,t.filename,concat(us.username , ' (', us.userid, ')') as username,case when t.isactive = TRUE then 1 else 0 end as isactive
    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
          join public.org_mst_deliveryunit as du on du.duid =t.duid
          join public.org_mst_customer as cus on cus.customerid =t.customerid   
         join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid  
          join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
           where isdelete=false) as tempp order by tempp.uploadeddate desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getSeparateTempList = (req, res) => {
  const reqData = req.body;
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
        join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
       where t.templatename='${reqData.templatename}' and isdelete=false`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT 
            *,concat(us.username , ' (', us.userid, ')') as username,case when t.isactive = TRUE then 1 else 0 end as isactive
             FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
                join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
               where t.templatename='${reqData.templatename}' and isdelete=false order by t.isactive desc ,t.uploadeddate desc`;

        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// templete repository
export const getTemplateList = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  // let sql = '';
  // let condition = '';
  // if (reqData.type === 'filter') {
  //   offset = 0;
  //   reqData.filter.forEach((item, i) => {
  //     condition +=
  //       reqData.filter.length - 1 !== i
  //         ? ` LOWER(${
  //             item.name
  //           }::text) LIKE '%${item.value.toLowerCase()}%' AND `
  //         : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
  //   });
  //
  //   sql = `SELECT COUNT(*) FROM wms_mst_composingsw_templates ${
  //     condition ? `WHERE${condition}` : condition
  //   }`;
  // } else {
  // sql = `SELECT COUNT(*) FROM wms_mst_composingsw_templates`;

  let newcondition = '';
  // const tempcondition = '';
  if (reqData.newdata == 'true') {
    newcondition = ' where res.rno = 1  ';
  } else {
    newcondition = ` where res.templatename = '${reqData.templatename}' `;
  }
  //   else {
  //    condition = 'sdfdfdf and'
  //     condition = `and t.templatename = ${reqData.templatename}`
  // }

  let newCount = '';
  newCount = `select count(0) as totalcount from (
        select row_number() Over(partition by t.templatename order by t.templateid desc) as rno,
        *
        from wms_mst_composingsw_templates t
        join public.wms_user as us on us.userid=t.uploadedby
        join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid
        join public.org_mst_deliveryunit as du on du.duid =t.duid
        join public.org_mst_customer as cus on cus.customerid =t.customerid
        join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid
        where isdelete=false
        ) res where res.rno = 1`;

  query(newCount)
    .then(getCount => {
      if (getCount[0].totalcount > 0) {
        // const numOfPages = Math.ceil(
        //   getCount[0].totalcount / reqData.recordPerPage,
        // );
        // const sql1 = `SELECT

        //     *,concat(us.username , ' (', us.userid, ')') as username,case when t.isactive = TRUE then 1 else 0 end as isactive
        //     FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
        //     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid
        //     where isdelete=false ${
        //       condition ? `and${condition}` : condition
        //     } order by t.isactive desc ,t.uploadeddate desc LIMIT ${recordPerPage} OFFSET ${offset}`;

        const sqlQuery = `select * from( 
                SELECT
                row_number() Over(partition by t.templatename order by t.templateid desc) as rno,
                *,
                concat(us.username , ' (', us.userid, ')') as username,
                case when t.isactive = TRUE then 1 else 0 end as isactive
                FROM public.wms_mst_composingsw_templates as t 
                join public.wms_user as us on us.userid=t.uploadedby 
                join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid 
                join public.org_mst_deliveryunit as du on du.duid =t.duid
                join public.org_mst_customer as cus on cus.customerid =t.customerid
                join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
                where isdelete=false  order by t.isactive desc ,t.uploadeddate desc 
                ) res ${newcondition} order by res.templateid desc`;

        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to be deleted
export const getDULists = (req, res) => {
  const result = {
    DUlist: [],
    SWlist: [],
    LBlist: [],
    CustomerList: [],
    templateDetails: [],
  };
  const { pageNo } = req.body;
  const { recordPerPage } = req.body;
  let offset = (pageNo - 1) * recordPerPage;
  let countRow = '';
  let condition = '';
  if (req.body.type === 'filter') {
    offset = 0;
    req.body.filter.forEach((item, i) => {
      condition +=
        req.body.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });

    countRow = `SELECT count(*)
        FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
         join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid where isdelete=false  ${
           condition ? `and${condition}` : condition
         }`;
  } else {
    countRow = `SELECT count(*)
    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid where isdelete=false `;
  }
  query(`SELECT duid as value, duname as label FROM org_mst_deliveryunit`)
    .then(data => {
      result.DUlist = data;
      query(
        `SELECT softwareid as value, softwarename as label FROM pp_mst_composingsoftware where isactive=true`,
      )
        .then(val => {
          result.SWlist = val;
          query(
            `SELECT templatetypeid as value, libraryname as label FROM public.wms_mst_template_type where isactive=true`,
          )
            .then(out => {
              result.LBlist = out;
              query(
                `SELECT customerid as value, customername as label FROM public.org_mst_customer`,
              )
                .then(rest => {
                  rest.CustomerList = rest;
                  query(countRow)
                    .then(count => {
                      query(`SELECT t.templateid,t.templatename,sw.softwarename,tt.libraryname,concat(us.username , ' (', us.userid, ')') as username,t.uploadeddate,t.templateuuid,t.templatefilepath,case when t.isactive = TRUE then 1 else 0 end as isactive
                    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
                     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid where isdelete=false ${
                       condition ? `and${condition}` : condition
                     } order by t.isactive desc ,t.uploadeddate desc LIMIT ${recordPerPage} OFFSET ${offset}`)
                        .then(value => {
                          rest.templateDetails = value;
                          rest
                            .status(200)
                            .json({ data: rest, total: count[0].count });
                        })
                        .catch(error => {
                          rest.status(400).send({ message: error });
                        });
                    })
                    .catch(error => {
                      rest.status(400).send({ message: error });
                    });
                })
                .catch(error => {
                  res.status(400).send({ message: error });
                });
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// for Template details
export const addTemplateDetails = (req, res) => {
  const templateDetails = req.body;

  const sqlFortemplate = `INSERT INTO public.wms_mst_composingsw_templates(templatename, composingswid, duid, customerid, uploadedby, uploadeddate,isactive, templateuuid,templatefilepath,isdelete,templatetypeid,filename)
            VALUES('${templateDetails.templatename}', ${templateDetails.composingswid}, ${templateDetails.duid}, ${templateDetails.customerid},'${templateDetails.rolename}',CURRENT_DATE,true,'${templateDetails.templateuuid}','${templateDetails.templatefilepath}',false, ${templateDetails.templatetypeid},'${templateDetails.templatename}') returning templateid;`;
  console.log(sqlFortemplate, 'queries');
  query(sqlFortemplate)
    .then(resForCreate => {
      query(`INSERT INTO public.wms_mst_composingsw_templates_auditlog(templateid,changelog)
        VALUES(${resForCreate[0].templateid}, '${JSON.stringify(
        templateDetails.log,
      )}')`)
        .then(() => {
          res.status(200).json({ data: resForCreate });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to update the template
export const updateTemplateStatus = (req, res) => {
  const updatetemplateDetails = req.body;
  query(
    `update public.wms_mst_composingsw_templates set isactive=${
      updatetemplateDetails.isactive != 0
    } where templateid=${updatetemplateDetails.id}`,
  )
    .then(() => {
      res.status(200).json({ data: updatetemplateDetails });
      query(`INSERT INTO public.wms_mst_composingsw_templates_auditlog(templateid,changelog)
        VALUES(${updatetemplateDetails.id}, '${JSON.stringify(
        updatetemplateDetails.log,
      )}')`)
        .then(resp => {
          resp.status(200).json({ data: resp });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete the template
// export const deleteTemplate1 = (req, res) => {
//     let { templateuuid, templateid, templatename } = req.body;
//     const headers = {};
//     const url = config.openKM.uri.delete;
//     service.delete(`${config.openKM.base_url}${url}/${templateuuid}`, {}, headers).then(async (response) => {
//         // query(`INSERT INTO public.wms_mst_composingsw_templates_auditlog(templateid,changelog)
//         // VALUES(${deletetemplateDetails.id}, '${JSON.stringify(deletetemplateDetails.log)}')`).then((data) => {
//         query(`update public.wms_mst_composingsw_templates set isdelete=true where templateid=${templateid}`).then((data) => {
//             res.status(200).json({ data: data });
//         }).catch((error) => {
//             res.status(400).send({ message: error });
//         });
//         // }).catch((error) => {
//         //     res.status(400).send({ message: error });
//         // })
//     }).catch((error) => {
//         res.status(400).send({ message: error });
//     })

// }

// to delete the template
const _delete = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.delete;
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docId=${pth}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};
export const deleteTemplate = (req, res) => {
  const { templatename } = req.body;

  const sqlFortemplate = `select templateid,templateuuid,templatename,templatefilepath from wms_mst_composingsw_templates WHERE templatename='${templatename}'`;
  console.log(sqlFortemplate, 'sqlFortemplate');

  query(sqlFortemplate)
    .then(resForCreate => {
      if (resForCreate) {
        const resobj = resForCreate;
        resobj.forEach(element => {
          const fullPath = element.templatefilepath + element.templatename;
          _delete(fullPath)
            .then(async () => {
              query(
                `update public.wms_mst_composingsw_templates set isdelete=true where templateid=${element.templateid}`,
              )
                .then(data => {
                  res.status(200).json({ data });
                })
                .catch(error => {
                  res.status(400).send({ message: error });
                });
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWorkorderWithNameLike = async (req, res) => {
  try {
    const out =
      await query(`select distinct a.workorderid, a.itemcode from wms_workorder a join 
    wms_workorder_service b on a.workorderid=b.workorderid where b.baseduid=${req.body.duid}
    and itemcode ILIKE '%${req.body.name}%'
    order by a.workorderid`);
    res.status(200).json(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getAccessRightsBlobFiles = async (req, res) => {
  try {
    const sql = `select isupload,duid ,* from wms_blobfiles_accessrights where userid='${req.body.userid}' and duid=${req.body.duid}`;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getJournalOptionList = async (req, res) => {
  try {
    const { customerId } = req.body;
    const sql = `SELECT DISTINCT
        journalid as value, journalacronym as label 
      FROM org_mst_customerorg_du_map as custmermap
      JOIN pp_mst_journal as journal ON journal.custorgmapid = custmermap.custorgmapid
      JOIN org_mst_customer_orgmap ON org_mst_customer_orgmap.custorgmapid = custmermap.custorgmapid
      WHERE org_mst_customer_orgmap.customerid = $1`;
    const result = await query(sql, [customerId]);
    res.status(200).send({ data: result });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getJournalBaseWOList = async (req, res) => {
  try {
    const sql = `select workorderid as value, itemcode as label  from  wms_workorder as workorder join 
    pp_mst_journal as journal on workorder.journalid = journal.journalid
     where workorder.journalid = ${req.body.journalId}`;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getWoChapters = async (req, res) => {
  try {
    const sql = `select woincomingfileid as value, filename as label
    from public.wms_workorder_incomingfiledetails a
    join wms_workorder_incoming b on b.woincomingid = a.woincomingid
    where b.woid =   ${req.body.workorderid} and a.filetypeid !=1
    order by a.woincomingfileid desc
   `;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const deleteFilePathTrn = async (req, res) => {
  try {
    const { value } = req.body;
    for (let i = 0; i < value.length; i++) {
      const repofilepath = `/okm:root/prodrepository/${value[i].path}/${value[i].name}`;
      const sql = `DELETE FROM wms_workflowactivitytrn_file_map WHERE repofilepath ='${repofilepath}'`;
      await query(sql);
    }
    res.status(200).send({ data: 'Deleted successfully!' });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({ message: error });
  }
};

// tools Upload Actions
export const blobFilesActionsAudit = async (req, res) => {
  console.log(req.body, 'neww', res);
  try {
    const { files, actionType, props, systemInfo, userid } = req.body;
    console.log(props, 'props');
    const val = [];
    files.forEach(list => {
      val.push(
        `('${
          list.name ? list.name : list.data.name
        }', '${userid}', '${systemInfo}', '${
          list.path ? list.path : list.data.path
        }', '${actionType}', ${props.profile.duId} )`,
      );
    });

    const sql2 = `INSERT INTO wms_blobfiles_actions_audit(filename,userid,systeminfo,actionpath,actiontype
      ,duid) values ${val}`;

    await query(sql2);
    res.status(200).json({
      status: true,
      data: 'audit table inserted successfully',
    });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({ message: error, status: false });
  }
};

export const getBlobFileDetailsForPath = async (req, res) => {
  try {
    let pth =
      req.body && req.body.path
        ? req.body.path.toLowerCase().replace(/ /g, '_')
        : undefined;

    if (pth == undefined) {
      const type =
        req.body.woincomingfileid != 0 && req.body.woincomingfileid != undefined
          ? 'wo_activity_file_subtype'
          : 'wo_activity_iteration';
      const input = {
        type,
        du: { name: req.body.assignedduname, id: req.body.duid },
        customer: { name: req.body.customername, id: req.body.customerid },
        workOrderId: req.body.workorderid,
        service: { name: req.body.servicename, id: req.body.serviceid },
        stage: {
          name: req.body.stagename,
          id: req.body.stageid,
          iteration: req.body.stageiterationcount,
        },
        activity: {
          name: req.body.activityname,
          id: req.body.activityid,
          iteration: req.body.activityiterationcount,
        },
        fileType: {
          name: req.body.filetype,
          id: req.body.filetypeid,
          fileId: req.body.woincomingfileid,
        },
      };
      pth = await getFolderStructure(input);
    }
    let originalPath = pth;
    if (!req.body.fileExplore || req.body.fileExplore == undefined) {
      originalPath = pth.substring(0, pth.length - 1);
    } else {
      originalPath = req.body.setpath;
    }
    const out = await azureHelper.listCurrentDirectory(originalPath);
    res.status(200).json(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const listContents = inputPath => {
  return new Promise((resolve, reject) => {
    fs.readdir(inputPath, { withFileTypes: true }, (err, items) => {
      if (err) {
        reject(err);
        return;
      }
      const result = items.map(item => {
        const fullPath = pathConfig.join(inputPath, item.name);
        return {
          name: item.name,
          path: fullPath,
          isFolder: item.isDirectory(),
          isFile: item.isFile(),
        };
      });

      resolve(result);
    });
  });
};

export const listFolderContents = async (req, res) => {
  const { customerid, duId, journalacronym, wokLabel, inputPath } = req.body;

  try {
    let currentPath = inputPath;

    if (!currentPath) {
      const sql = `select * from public.wms_mst_customerconfigdetails where duid=${duId} and customerid =${customerid}`;
      const data = await query(sql);
      currentPath = data[0]?.localserverpath
        ? `${data[0]?.localserverpath.replace(
            ';JournalAcronym;',
            journalacronym,
          )}/`
        : '';
      currentPath = `${currentPath}${wokLabel}/`;
    }

    const listFiles = await _locallistAllFiles(currentPath);
    const files = [];
    console.log(files, 'files');
    const commonPath = currentPath;

    // Sets to track unique folders and files
    const seenFolderPaths = new Set();
    const seenFileNames = new Set();

    if (listFiles && listFiles.length > 0) {
      listFiles.forEach(item => {
        const remainingPath = item.path.replace(commonPath, '');

        if (remainingPath.length > 1) {
          const folderPath = `${
            commonPath + (remainingPath.split('/')?.[0] || '')
          }/`;
          const folderName = remainingPath.split('/')?.[0];

          if (!seenFolderPaths.has(folderPath)) {
            seenFolderPaths.add(folderPath);
            files.push({
              name: folderName,
              path: folderPath,
              isFolder: true,
              isFile: false,
            });
          }
        } else {
          const baseName = basename(item.path);

          if (!seenFileNames.has(baseName)) {
            seenFileNames.add(baseName);
            files.push({
              name: baseName,
              path: item.path,
              isFolder: false,
              isFile: true,
            });
          }
        }
      });
    }

    const StageInfo = files.map(file => {
      const hasFileExtension = /\.[^/\\]+$/.test(file.name);
      return {
        path: file.path,
        name: file.name,
        isFolder: !hasFileExtension,
        stagename: file.name,
        stageid: file.name,
        children: !hasFileExtension ? [] : undefined,
      };
    });

    const uniqueFileDtls = files
      .filter(file => !file.isFolder)
      .map(file => ({
        woincomingfileid: file.name,
        filename: file.name,
        newfiletype: null,
        filetypeid: null,
        filetype: null,
        name: file.name,
      }));

    res.status(200).json({ StageInfo, uniqueFileDtls, currentPath });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

// export const listFolderContents = async (req, res) => {
//   const { customerid, duId, journalacronym, wokLabel, inputPath } = req.body;

//   try {
//     let currentPath = inputPath;

//     if (!currentPath) {
//       const sql = `select * from public.wms_mst_customerconfigdetails where duid=${duId} and customerid =${customerid}`;
//       const data = await query(sql);
//       currentPath = data[0]?.localserverpath
//         ? `${data[0]?.localserverpath.replace(
//             ';JournalAcronym;',
//             journalacronym,
//           )}/`
//         : '';
//       currentPath = `${currentPath}${wokLabel}/`;
//     }

//     const listFiles = await _locallistAllFiles(currentPath);
//     let files = [];

//     if (listFiles && listFiles.length > 0) {
//       files = listFiles.map(list => ({
//         name: pathConfig.basename(list.path), // Get just the filename
//         path: list.path,
//         isFolder: list.isFolder,
//         isFile: list.isFile,
//       }));
//     }

//     const StageInfo = files.map(file => ({
//       path: file.path,
//       name: file.name,
//       isFolder: file.isFolder,
//       stagename: file.name,
//       stageid: file.name,
//       children: file.isFolder ? [] : undefined,
//     }));

//     const uniqueFileDtls = files
//       .filter(file => !file.isFolder)
//       .map(file => ({
//         woincomingfileid: file.name,
//         filename: file.name,
//         newfiletype: pathConfig.extname(file.name).slice(1), // Get file extension without dot
//         filetypeid: null,
//         filetype: pathConfig.extname(file.name).slice(1),
//         name: file.name,
//       }));

//     res.status(200).json({
//       StageInfo,
//       uniqueFileDtls,
//       currentPath,
//     });
//   } catch (error) {
//     res.status(400).send({ message: error.message });
//   }
// };

export const getCustomerData = async (req, res) => {
  try {
    const { customerId } = req.body;
    const sql = `SELECT customerid, localserverpath, customername
               FROM customer_server_paths
               WHERE customerid = $1`;
    const result = await query(sql, [customerId]);
    // result path
    const files = await _locallistAllFiles();
    console.log(files, 'files');

    res.status(200).send({ data: result });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getFileDetailsforWorkorder = async (req, res) => {
  try {
    let condition;
    if (req.body.type == 'book') {
      condition = `workorderid=${req.body.workorderid} and (woincomingfileid =${req.body.woincomingfileid} or woincomingfileid is null)`;
    } else {
      condition = `workorderid=${req.body.workorderid}`;
    }

    const sql = `;with cte as (select 
      row_number() over(partition by itemcode,stagename,stageiterationcount,activityalias,filename order by stageiterationcount,activityiterationcount desc ) as rno,
      filetype,filetypeid,newfiletype,duid,assignedduname,customerid,customername,
      COALESCE(woincomingfileid,0) as woincomingfileid,workorderid,wfeventid, 
      filename, itemcode, servicename,stageid,stagename,
      serviceid, activityalias, activityname, activityid, stageiterationcount, 
      activityiterationcount 
      from wms_tasklist 
      where ${condition} ) select 
      filetype,filetypeid,newfiletype,duid,assignedduname,customerid,customername,
      COALESCE(woincomingfileid,0) as woincomingfileid,workorderid,wfeventid, 
      filename,COALESCE(filename,activityiterationcount::varchar) as name, itemcode, servicename,stageid,stagename,
      serviceid,servicename,activityalias, activityname, activityid, stageiterationcount, 
      activityiterationcount 
      from cte where rno=1
      order by stageid`;
    const sqlResult = await query(sql);
    const StageName = [
      ...new Set(
        sqlResult.flatMap(d => `${d.stagename}(${d.stageiterationcount})`),
      ),
    ];
    const out = { StageName: [] };
    const getstagepath = stg => {
      return `prodrepository/${stg.assignedduname}_${stg.duid}/${stg.customername}_${stg.customerid}/${req.body.workorderid}/${stg.servicename}_${stg.serviceid}/${stg.stagename}_${stg.stageid}/${stg.stageiterationcount}`;
    };
    const getactivitypath = aty => {
      const stagepath = getstagepath(aty);
      return `${stagepath}/${aty.activityname}_${aty.activityid}/${aty.activityiterationcount}`;
    };
    const uniqueFileDtls = Array.from([
      ...new Set(
        sqlResult
          .map(d => ({
            woincomingfileid: d.woincomingfileid,
            filename: d.filename,
            newfiletype: d.newfiletype,
            filetypeid: d.filetypeid,
            filetype: d.filetype,
            name: d.name || d.activityiterationcount,
          }))
          .map(JSON.stringify),
      ),
    ])
      .map(JSON.parse)
      .filter(x => x.woincomingfileid != 0);
    StageName.forEach(stg => {
      out.StageName.push({
        path: getstagepath(
          sqlResult.filter(
            x => `${x.stagename}(${x.stageiterationcount})` == stg,
          )[0],
        ),
        name: stg,
        isFolder: true,
        id: sqlResult.filter(
          x => `${x.stagename}(${x.stageiterationcount})` == stg,
        )[0].stageid,
        stagename: stg,
        stageid: sqlResult.filter(
          x => `${x.stagename}(${x.stageiterationcount})` == stg,
        )[0].stageid,
        children: Array.from([
          ...new Set(
            sqlResult
              .filter(x => `${x.stagename}(${x.stageiterationcount})` == stg)
              .map(d => ({
                path: getactivitypath(d),
                name: d.activityalias,
                id: d.activityid,
                activityname: d.activityname,
                activityid: d.activityid,
                isFolder: true,
                children: sqlResult
                  .filter(
                    x =>
                      x.activityid == d.activityid &&
                      `${x.stagename}(${x.stageiterationcount})` == stg,
                  )
                  .map(x => {
                    x.children = [];
                    x.isFolder = true;
                    return x;
                  }),
              }))
              .map(JSON.stringify),
          ),
        ]).map(JSON.parse),
      });
    });
    // out.StageName.forEach(async list => {
    //   // const fstat = await fsPromises.stat(list.path);
    //   if (list.name.includes('.')) {
    //     list.isFolder = false;
    //   } else {
    //     list.isFolder = true;
    //   }
    // });

    // out.StageName.forEach(async list => {
    //   if (list.children) {
    //     list.children.forEach(async list1 => {
    //       try {
    //         if (list1.name.includes('.')) {
    //           list1.isFolder = false;
    //         } else {
    //           list1.isFolder = true;
    //         }
    //       } catch (error) {
    //         console.error(`Error: ${error}`);
    //       }
    //     });
    //   }
    // });

    res.status(200).json({ StageInfo: out.StageName, uniqueFileDtls });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getMasterOptionLists = (req, res) => {
  const getData = req.body;
  let sql = ``;
  console.log('Datas', getData);
  if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value ,org_mst_customer.customername as label , org_mst_customer.customershortname as custname
        FROM public.org_mst_customer`;
  } else if (getData.type === 'division') {
    sql = `SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label
         FROM public.org_mst_division`;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label 
        FROM  org_mst_subdivision`;
  } else if (getData.type === 'country') {
    sql = `SELECT DISTINCT ON (geo_mst_country.countryid)geo_mst_country.countryid as value, geo_mst_country.countryname as label 
        FROM geo_mst_country`;
  } else if (getData.type === 'projectmanager') {
    sql = `select users.userid as value, concat(users.username , ' (', users.userid, ')')as label from wms_user as users
        join wms_userrole as roles on roles.userid = users.userid where roles.roleid =1 and users.duid = ${getData.duId} and useractive = true and isactive = true`;
  } else if (getData.type === 'supplierprojectmanager') {
    sql = `select users.userid as value, concat(users.username , ' (', users.userid, ')')as label from wms_user as users
        join wms_userrole as roles on roles.userid = users.userid where roles.roleid = 9 and users.duid = ${getData.duId} and useractive = true and isactive = true`;
  } else if (getData.type === 'softwares') {
    sql = `SELECT softwareid as value, softwarename as label FROM public.pp_mst_composingsoftware WHERE isactive = true`;
  } else if (getData.type === 'colours') {
    sql = `SELECT colorid as value, color as label FROM public.pp_mst_color`;
  } else if (getData.type === 'languages') {
    sql = `SELECT languageid as value, languagename as label FROM public.wms_mst_language`;
  } else if (getData.type === 'celevel') {
    sql = `SELECT celevelid as value, celevel as label FROM public.pp_mst_copyeditinglevel`;
  } else if (getData.type === 'indexType') {
    sql = `SELECT indextypeid as value, indextype as label FROM public.pp_mst_indextype`;
  } else if (getData.type === 'templatefile') {
    sql = `SELECT templateid as value,templatename as label FROM public.wms_mst_composingsw_templates where duId= ${getData.duId} and composingswid=${getData.composingSwId} and isactive = true and isdelete = false`;
  } else if (getData.type === 'iauthorworkflow') {
    sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
        where duid=${getData.duId} and isactive = true and stageid=1 ORDER BY iauthormstworkflowid ASC`;
  } else if (getData.type === 'articletype') {
    sql = `   select distinct on (inco.filetypeid) inco.filetypeid as value,filetype.filetype as  label from  wms_workorder_incoming as woi
    join wms_workorder_incomingfiledetails as inco on inco.woincomingid = woi.woincomingid
       join pp_mst_filetype as filetype on filetype.filetypeid = inco.filetypeid
    where woi.woid =${getData.workorderid} and filetype.articletype ='Other Article'`;
  } else if (getData.type === 'iauthorworkflowforbookreview') {
    sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
    where duid=${getData.duId} and isactive = true and stageid=1 ORDER BY iauthormstworkflowid ASC`;
  } else if (getData.type === 'copyeditingworkflow') {
    sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
        where isactive = true and duid=${getData.duId} and stageid=13 ORDER BY iauthormstworkflowid  ASC`;
  } else if (getData.type === 'textcolumn') {
    sql = `SELECT textcolumnid as value, textcolumn as label FROM public.wms_mst_textcolumn ORDER BY textcolumnid ASC`;
  } else if (getData.type === 'printprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='printprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'onlineprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='onlineprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'referenceprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='referenceprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'pdfprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='pdfprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'category') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='onlineprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'coverprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='coverprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'stage') {
    sql = `select wfstageid as value, stage.stagename as label from wms_workorder_stage as wo
    join wms_mst_stage as stage on stage.stageid = wo.wfstageid
    where workorderid = ${getData.workorderid}  and  isactive = true ORDER BY stageid ASC  `;
  } else if (getData.type === 'selectedstage') {
    sql = `select wfstageid as value, stage.stagename as label from wms_workorder_stage as wo
    join wms_mst_stage as stage on stage.stageid = wo.wfstageid
    where workorderid = ${getData.workorderid}  and  isactive = true ORDER BY stageid ASC  `;
  } else if (getData.type === 'journalacronym') {
    sql = `SELECT distinct on (journalid) journalid  as value, journalacronym as label FROM public.pp_mst_journal 
    left join org_mst_customer_orgmap as custorg on custorg.customerid = ${getData.customer}
    ORDER BY journalid ASC  `;
  } else if (getData.type === 'bookcode') {
    sql = `SELECT workorderid as value, itemcode as label FROM public.wms_workorder
    where isactive = true and journalid =${getData.journalacronym} and jobtype = '2' ORDER BY workorderid ASC  `;
  } else if (getData.type === 'client') {
    sql = `select duname as label, duname as value, duid as id from org_mst_deliveryunit`;
  } else if (getData.type === 'activecustomer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value ,org_mst_customer.customername as label , org_mst_customer.customershortname as custname
        FROM public.org_mst_customer where isactive = true`;
  } else if (getData.type === 'journal') {
    sql = `select journalacronym as label,journalacronym as value,journalid as id
    from pp_mst_journal as journal join org_mst_customerorg_du_map as custojournal on
	journal.custorgmapid = custojournal.custorgmapid
	where journal.isactive =1 and custojournal.duid =${getData.duId} order by journalid desc`;
  } else if (getData.type === 'workorder') {
    const conditions = [];
    if (getData.duId) {
      conditions.push(`duid = ${getData.duId}`);
    }
    if (getData.journalId) {
      conditions.push(`journalid = ${getData.journalId}`);
    }
    if (getData.volume) {
      const [volumeNumber, issueNumber] = getData.volume
        .split('(')
        .map(part => part.replace(/\D/g, '').trim());

      if (volumeNumber) {
        conditions.push(`volumenumber = '${volumeNumber}'`);
      }

      if (issueNumber) {
        conditions.push(`issuenumber = '${issueNumber}'`);
      }
    }

    conditions.push('wms_workorder.isactive = true');

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    sql = `
      SELECT workorderid as id, itemcode as label, itemcode as value, journalid, wfid
      FROM wms_workorder
      ${whereClause}
      ORDER BY workorderid DESC
    `;
  } else if (getData.type === 'filestatusworkorder') {
    const conditions = [];
    if (getData.duId) {
      conditions.push(`duid = ${getData.duId}`);
    }
    if (getData.journalId) {
      conditions.push(`journalid = ${getData.journalId}`);
    }
    if (getData.volume) {
      const [volumeNumber, issueNumber] = getData.volume
        .split('(')
        .map(part => part.replace(/\D/g, '').trim());

      if (volumeNumber) {
        conditions.push(`volumenumber = '${volumeNumber}'`);
      }

      if (issueNumber) {
        conditions.push(`issuenumber = '${issueNumber}'`);
      }
    }

    // conditions.push('wms_workorder.isactive = true');

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    sql = `
      SELECT workorderid as id,customername, customerid, itemcode as label, itemcode as value, journalid, wfid
      FROM wms_workorder_list
      ${whereClause}
      ORDER BY workorderid DESC
    `;
  } else if (getData.type === 'volume') {
    sql = `
    SELECT DISTINCT
      CASE
        WHEN COALESCE(wo.volumenumber, '') = '' OR COALESCE(wo.issuenumber, '') = ''
        THEN concat(j.journalacronym, '_0(0)')
        ELSE concat(j.journalacronym, '_', wo.volumenumber, '(', wo.issuenumber, ')')
      END as label,
      CASE
        WHEN COALESCE(wo.volumenumber, '') = '' OR COALESCE(wo.issuenumber, '') = ''
        THEN concat(j.journalacronym, '_0(0)')
        ELSE concat(j.journalacronym, '_', wo.volumenumber, '(', wo.issuenumber, ')')
      END as value
    FROM pp_mst_journal j
    LEFT JOIN wms_workorder wo ON j.journalid = wo.journalid
    WHERE j.journalid = ${getData.journalId}
    `;
  } else {
    sql = `SELECT coverprofileid as value, coverprofile as label FROM public.wms_mst_coverprofile where duid=${getData.duId} and isactive = true ORDER BY coverprofileid ASC`;
  }
  //  else {
  //   sql = `SELECT coverprofileid as value, coverprofile as label FROM public.wms_mst_coverprofile where duid=${getData.duId} and isactive = true ORDER BY coverprofileid ASC`;
  // }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJournalMasterOptionLists = (req, res) => {
  const getData = req.body;
  let sql = ``;
  console.log('Datas', getData);
  if (getData.type === 'customer') {
    //   sql = `SELECT DISTINCT ON (cu.customerid)
    //   cu.customerid AS value,
    //   cu.customername AS label,
    //   cu.customershortname AS custname
    // FROM wms_workflow wo
    // JOIN org_mst_customer cu ON wo.customerid = cu.customerid
    // WHERE wo.wfcategory = 'Articlewise'
    // AND cu.isactive = 'true'
    // ORDER BY cu.customerid;`;
    sql = `SELECT DISTINCT ON (cu.customerid) 
    cu.customerid AS value, 
    cu.customername AS label, 
    cu.customershortname AS custname
FROM wms_workflow wo
JOIN org_mst_customer cu ON wo.customerid = cu.customerid
WHERE wo.wfcategory = 'Articlewise' 
  AND cu.isactive = 'true'
  AND cu.customerid IN (
      SELECT customerid 
      FROM public.org_mst_customer_orgmap 
      WHERE custorgmapid IN (
          SELECT custorgmapid 
          FROM public.org_mst_customerorg_du_map 
          WHERE duid = ${getData.duId}
      )
  )
ORDER BY cu.customerid;`;
  } else if (getData.type === 'division') {
    sql = `SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label
         FROM public.org_mst_division`;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label 
        FROM  org_mst_subdivision`;
  } else if (getData.type === 'country') {
    sql = `SELECT DISTINCT ON (geo_mst_country.countryid)geo_mst_country.countryid as value, geo_mst_country.countryname as label 
        FROM geo_mst_country`;
  } else if (getData.type === 'projectmanager') {
    sql = `select users.userid as value, concat(users.username , ' (', users.userid, ')')as label from wms_user as users
        join wms_userrole as roles on roles.userid = users.userid where roles.roleid =1 and users.duid = ${getData.duId} and useractive = true and isactive = true`;
  } else if (getData.type === 'supplierprojectmanager') {
    sql = `select users.userid as value, concat(users.username , ' (', users.userid, ')')as label from wms_user as users
        join wms_userrole as roles on roles.userid = users.userid where roles.roleid = 9 and users.duid = ${getData.duId} and useractive = true and isactive = true`;
  } else if (getData.type === 'softwares') {
    sql = `SELECT softwareid as value, softwarename as label FROM public.pp_mst_composingsoftware WHERE isactive = true`;
  } else if (getData.type === 'colours') {
    sql = `SELECT colorid as value, color as label FROM public.pp_mst_color`;
  } else if (getData.type === 'languages') {
    sql = `SELECT languageid as value, languagename as label FROM public.wms_mst_language`;
  } else if (getData.type === 'celevel') {
    sql = `SELECT celevelid as value, celevel as label FROM public.pp_mst_copyeditinglevel`;
  } else if (getData.type === 'indexType') {
    sql = `SELECT indextypeid as value, indextype as label FROM public.pp_mst_indextype`;
  } else if (getData.type === 'templatefile') {
    sql = `SELECT templateid as value,templatename as label FROM publiwms_mst_composingsw_templatesc. where duId= ${getData.duId} and composingswid=${getData.composingSwId} and isactive = true and isdelete = false`;
  } else if (getData.type === 'iauthorworkflow') {
    sql = `select  iauthorworkflowid as value, iauthorworkflow as label from public.iauthor_new_workflow where duid =${getData.duId}`;
    // sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
    //     where duid=${getData.duId} and isactive = true and stageid=1 ORDER BY iauthormstworkflowid ASC`;
  } else if (getData.type === 'articletype') {
    sql = `   select distinct on (inco.filetypeid) inco.filetypeid as value,filetype.filetype as  label from  wms_workorder_incoming as woi
    join wms_workorder_incomingfiledetails as inco on inco.woincomingid = woi.woincomingid
       join pp_mst_filetype as filetype on filetype.filetypeid = inco.filetypeid
    where woi.woid =${getData.workorderid} and filetype.articletype ='Other Article'`;
  } else if (getData.type === 'iauthorworkflowforbookreview') {
    sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
    where duid=${getData.duId} and isactive = true and stageid=1 and iauthworkflowid in (90,91) 
ORDER BY iauthormstworkflowid ASC`;
  } else if (getData.type === 'copyeditingworkflow') {
    sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
        where isactive = true and duid=${getData.duId} and stageid=13 ORDER BY iauthormstworkflowid  ASC`;
  } else if (getData.type === 'textcolumn') {
    sql = `SELECT textcolumnid as value, textcolumn as label FROM public.wms_mst_textcolumn ORDER BY textcolumnid ASC`;
  } else if (getData.type === 'printprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='printprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
    // sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
    //       join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
    //       where wmd.fieldname = 'printprofile' and wtd.duid = ${getData.duId}`;
  } else if (getData.type === 'onlineprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='onlineprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
    // sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
    //       join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
    //       where wmd.fieldname = 'onlineprofile' and wtd.duid = ${getData.duId}`;
  } else if (getData.type === 'referenceprofile') {
    sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
          join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
          where wmd.fieldname = 'referenceprofile' and wtd.duid = ${getData.duId}`;
  } else if (getData.type === 'proofcreationtypeid') {
    sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
          join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
          where wmd.fieldname = 'proofcreationtype' and wtd.duid = ${getData.duId}`;
  } else if (getData.type === 'interfacecodeid') {
    sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
          join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
          where wmd.fieldname = 'interfacecode' and wtd.duid = ${getData.duId}`;
  } else if (getData.type === 'dataadministratorcodeid') {
    sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
where wmd.fieldname = 'dataadministratorcode' and wtd.duid = ${getData.duId}`;
  } else if (getData.type === 'status') {
    sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
where wmd.fieldname = 'status' and wtd.duid = ${getData.duId}`;
  } else if (getData.type === 'priorityid') {
    sql = `SELECT priorityid AS value, priority AS label FROM wms_mst_priority;`;
    // sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    // where tmst.profilename='journalpriority' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'typesetmodalid') {
    sql = `select wtd.id as value, wtd.value as label  from wms_mst_dropdown wmd
    join wms_trn_dropdown wtd on wtd.dropid = wmd.dropid
    where wmd.fieldname = 'typesetmodal' and wtd.duid = ${getData.duId}`;
    // sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    // where tmst.profilename='typesetmodalid' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'pdfprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='pdfprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'category') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='onlineprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'coverprofile') {
    sql = `select ttrn.id as value,  ttrn.profilevalue as label from mst_pitstopprofile as tmst left join trn_pitstopprofiledetail as ttrn on tmst.profileid=ttrn.profileid
    where tmst.profilename='coverprofile' and duid=${getData.duId} ORDER BY 1 ASC`;
  } else if (getData.type === 'stage') {
    sql = `select wfstageid as value, stage.stagename as label from wms_workorder_stage as wo
    join wms_mst_stage as stage on stage.stageid = wo.wfstageid
    where workorderid = ${getData.workorderid}  and  isactive = true ORDER BY stageid ASC  `;
  } else if (getData.type === 'selectedstage') {
    sql = `select wfstageid as value, stage.stagename as label from wms_workorder_stage as wo
    join wms_mst_stage as stage on stage.stageid = wo.wfstageid
    where workorderid = ${getData.workorderid}  and  isactive = true ORDER BY stageid ASC  `;
  } else if (getData.type === 'journalacronym') {
    sql = `SELECT distinct on (journalid) journalid  as value, journalacronym as label FROM public.pp_mst_journal 
    left join org_mst_customer_orgmap as custorg on custorg.customerid = ${getData.customer}
    ORDER BY journalid ASC  `;
  } else if (getData.type === 'bookcode') {
    sql = `SELECT workorderid as value, itemcode as label FROM public.wms_workorder
    where isactive = true and journalid =${getData.journalacronym} and jobtype = '2' ORDER BY workorderid ASC  `;
  } else if (getData.type === 'client') {
    sql = `select duname as label, duname as value, duid as id from org_mst_deliveryunit`;
  } else if (getData.type === 'activecustomer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value ,org_mst_customer.customername as label , org_mst_customer.customershortname as custname
        FROM public.org_mst_customer where isactive = true`;
  } else if (getData.type === 'journal') {
    sql = `select journalacronym as label,journalacronym as value,journalid as id
    from pp_mst_journal as journal join org_mst_customerorg_du_map as custojournal on
	journal.custorgmapid = custojournal.custorgmapid
	where journal.isactive =1 and custojournal.duid =${getData.duId} order by journalid desc`;
  } else if (getData.type === 'workorder') {
    const conditions = [];
    if (getData.duId) {
      conditions.push(`duid = ${getData.duId}`);
    }
    if (getData.journalId) {
      conditions.push(`journalid = ${getData.journalId}`);
    }
    if (getData.volume) {
      const [volumeNumber, issueNumber] = getData.volume
        .split('(')
        .map(part => part.replace(/\D/g, '').trim());

      if (volumeNumber) {
        conditions.push(`volumenumber = '${volumeNumber}'`);
      }

      if (issueNumber) {
        conditions.push(`issuenumber = '${issueNumber}'`);
      }
    }

    conditions.push('wms_workorder.isactive = true');

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    sql = `
      SELECT workorderid as id, itemcode as label, itemcode as value, journalid, wfid
      FROM wms_workorder
      ${whereClause}
      ORDER BY workorderid DESC
    `;
  } else if (getData.type === 'volume') {
    sql = `
    SELECT DISTINCT
      CASE
        WHEN COALESCE(wo.volumenumber, '') = '' OR COALESCE(wo.issuenumber, '') = ''
        THEN concat(j.journalacronym, '_0(0)')
        ELSE concat(j.journalacronym, '_', wo.volumenumber, '(', wo.issuenumber, ')')
      END as label,
      CASE
        WHEN COALESCE(wo.volumenumber, '') = '' OR COALESCE(wo.issuenumber, '') = ''
        THEN concat(j.journalacronym, '_0(0)')
        ELSE concat(j.journalacronym, '_', wo.volumenumber, '(', wo.issuenumber, ')')
      END as value
    FROM pp_mst_journal j
    LEFT JOIN wms_workorder wo ON j.journalid = wo.journalid
    WHERE j.journalid = ${getData.journalId}
    `;
  } else {
    sql = `SELECT coverprofileid as value, coverprofile as label FROM public.wms_mst_coverprofile where duid=${getData.duId} and isactive = true ORDER BY coverprofileid ASC`;
  }
  //  else {
  //   sql = `SELECT coverprofileid as value, coverprofile as label FROM public.wms_mst_coverprofile where duid=${getData.duId} and isactive = true ORDER BY coverprofileid ASC`;
  // }

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getNlpOptionLists = (req, res) => {
  const getData = req.body;
  let sql = ``;
  console.log('Datas', getData);
  if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value ,org_mst_customer.customername as label , org_mst_customer.customershortname as custname
        FROM public.org_mst_customer`;
  } else if (getData.type === 'division') {
    sql = `SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label
         FROM public.org_mst_division`;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label
        FROM  org_mst_subdivision`;
  } else if (getData.type === 'country') {
    sql = `SELECT DISTINCT ON (geo_mst_country.countryid)geo_mst_country.countryid as value, geo_mst_country.countryname as label
        FROM geo_mst_country`;
  } else if (getData.type === 'languages') {
    sql = `SELECT languageid as value, languagename as label FROM public.wms_mst_language`;
  } else if (getData.type === 'emailDropdown') {
    sql = `SELECT notificationid as id, action as value , action as label FROM wms_notifications where customerid = ${getData.customer} `;
  } else if (getData.type === 'activity') {
    sql = `SELECT activityalias AS label, activityid AS value 
    FROM wms_workflowdefinition 
    WHERE wfid = ${req.body.wfid} 
    AND stageid = ${req.body.stageId} 
    AND activityid != 21 
    ORDER BY sequence;`;
  } else if (getData.type === 'scoreAactivity') {
    sql = `SELECT activityid as value,activityalias as label
    from wms_workflowdefinition 
    WHERE wfid = ${req.body.wfid} AND stageid = ${req.body.stageId} order by sequence;`;
  } else if (getData.type === 'scoreBactivity') {
    sql = `SELECT activityid as value,activityalias as label
    from wms_workflowdefinition 
    WHERE wfid = ${req.body.wfid} AND stageid = ${req.body.stageId} order by sequence;`;
  } else if (getData.type === 'scoreCactivity') {
    sql = `SELECT activityid as value,activityalias as label
    from wms_workflowdefinition 
    WHERE wfid = ${req.body.wfid} AND stageid = ${req.body.stageId} order by sequence;`;
  } else if (getData.type === 'stage') {
    sql = `   SELECT  
        wwd.stageid AS value,
        ws.stagename AS label,
        min(wwd.sequence) as minseq
      FROM wms_workflowdefinition wwd
      JOIN wms_mst_stage ws ON wwd.stageid = ws.stageid
      WHERE wwd.wfid = ${req.body.wfid}
      GROUP BY wwd.stageid, ws.stagename
      ORDER BY minseq;`;
  } else if (getData.type === 'selectedstage') {
    sql = `select wfstageid as value, stage.stagename as label from wms_workorder_stage as wo
    join wms_mst_stage as stage on stage.stageid = wo.wfstageid
    where workorderid = ${getData.workorderid}  and  isactive = true ORDER BY stageid ASC  `;
  } else if (getData.type === 'journalacronym') {
    sql = `SELECT distinct on (journalid) journalid  as value, journalacronym as label FROM public.pp_mst_journal
    left join org_mst_customer_orgmap as custorg on custorg.customerid = ${getData.customer}
    ORDER BY journalid ASC  `;
  } else if (getData.type === 'client') {
    sql = `select duname as label, duname as value, duid as id from org_mst_deliveryunit`;
  } else if (getData.type === 'activecustomer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value ,org_mst_customer.customername as label , org_mst_customer.customershortname as custname
        FROM public.org_mst_customer where isactive = true`;
  } else if (getData.type === 'journal') {
    sql = `select journalacronym as label,journalacronym as value,journalid as id
    from pp_mst_journal as journal join org_mst_customerorg_du_map as custojournal on
journal.custorgmapid = custojournal.custorgmapid
where journal.isactive = 1 and custojournal.duid =${getData.duId} order by journalid desc`;
  } else if (getData.type === 'workflow') {
    sql = `SELECT wfid as value , wfname as label FROM wms_workflow where customerid = ${getData.customer}  `;
  } else {
    sql = `SELECT coverprofileid as value, coverprofile as label FROM public.wms_mst_coverprofile where duid=${getData.duId} and isactive = true ORDER BY coverprofileid ASC`;
  }
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// export const createJournalMaster = (req) => {
//     const {customerId,divisionId,subDivisionId, countryId, journalStatus,ceLevel,JournalAcronym,colour,custShortName,software,
//         journalName,language, onlineIssn,printIssn,projectManager,supplierProjectManager,tat,templateFile,pageHeight,pageWidth} = req.body;
//     return new Promise(async (resolve, reject) => {
//         try {
//             await transaction(async (client) => {
//                 let sql = `INSERT INTO public.org_mst_customer_orgmap(customerid, divisionid, subdivisionid, countryid, isactive) VALUES (${customerId}, ${divisionId}, ${subDivisionId}, ${countryId}, ${journalStatus}) RETURNING custorgmapid`;
//                 console.log(sql,"sqllll11")
//                 const eventResult = await client.query(sql)
//                 console.log(sql,"sqllll")
//                 console.log(eventResult,"eventResult")
//                 sql = `INSERT INTO public.pp_mst_journal(
//                     custorgmapid, journalname, journalacronym, colorid, turnaroundtime, softwareid, languageid, celevelid, templateid, printissn, trimesizewidth, trimesizewidthuom, trimesizeheight, trimesizeheightuom, pmid, supplierpmid, onlineissn)
//                    VALUES (${eventResult.rows[0].custorgmapid}, '${journalName}', '${JournalAcronym}', ${colour}, ${tat}, ${software}, ${language}, ${ceLevel}, ${templateFile}, '${printIssn}', ${pageWidth}, '0', ${pageHeight}, '0', '${projectManager}', '${supplierProjectManager}',' ${onlineIssn}') RETURNING journalid`;
//                   console.log(sql,"sqlforsecnd")
//                    await client.query(sql);
//                 resolve('Journal Created Successfully');
//             });
//         } catch (e) {
//             if (e?.message?.data?.message) { //This is used to checkThis is wrong. need to get proper error msg from camunda layer
//                 reject(e.message.data.message);
//             } else {
//                 reject(e.message ? e.message : e);
//             }
//         }
//     });
// }

// export const createJournalMaster = async (req, res) => {
//   const {
//     customerId,
//     divisionId,
//     subDivisionId,
//     countryId,
//     journalStatus,
//     ceLevel,
//     JournalAcronym,
//     colour,
//     software,
//     journalName,
//     language,
//     onlineIssn,
//     printIssn,
//     projectManager,
//     supplierProjectManager,
//     articleTat,
//     issueTat,
//     issueCount,
//     budgetedCount,
//     proofingType,
//     accessArticle,
//     templateFile,
//     pageHeight,
//     pageWidth,
//     productionList,
//     duId,
//     pageHeightUnit,
//     pageWidthUnit,
//     nonArticle,
//     isIAuthorRequired,
//     iAuthorWorkflow,
//     ce,
//     amo,
//     textColumn,
//     onlineProfile,
//     printProfile,
//     tatList,
//     templateFormat,
//     isNLPRequired,
//     isFirstproofRequired,
//     copyEditingWorkflow,
//     category,
//     journalType,
//     referenceProfile,
//     pdfProfile,
//     runon,
//     runontype,
//     cover,
//     advert,
//     blankpagelogic,
//     coverProfile,
//     onShoreCE,
//   } = req.body;
//   const runontypeJSON = JSON.stringify(runontype);
//   console.log('runontypeJSON', runontypeJSON);
//   console.log(req.body, 'boddyyyyyyyyyy');
//   const isAccessArticle = accessArticle == true ? 1 : 0;
//   let custId;
//   let status = true;
//   const defaultSql = `select custorgmapid from public.org_mst_customer_orgmap where customerid = ${customerId}  and  divisionid = ${divisionId} and  subdivisionid = ${subDivisionId}  and countryid = ${countryId}`;
//   await query(defaultSql)
//     .then(async response => {
//       console.log(response, 'responnnsnsns');
//       custId = response;
//       if (response.length) {
//         custId = response[0].custorgmapid;
//       } else {
//         const sql = `INSERT INTO public.org_mst_customer_orgmap(customerid, divisionid, subdivisionid, countryid) VALUES (${customerId}, ${divisionId}, ${subDivisionId}, ${countryId}) RETURNING custorgmapid`;
//         console.log(sql, 'customermap');
//         await query(sql).then(async resp => {
//           custId = resp[0].custorgmapid;
//           const createDu = `INSERT INTO public.org_mst_customerorg_du_map(custorgmapid, duid)
//                VALUES ( ${custId}, ${duId}) RETURNING custorgmapid`;
//           console.log(createDu, 'createduuu');
//           await query(createDu)
//             .then(async responsedu => {
//               console.log(responsedu, 'duduud');
//             })
//             .catch(() => {
//               status = false;
//             })
//             .catch(() => {
//               status = false;
//             });
//         });
//       }
//     })
//     .catch(() => {
//       status = false;
//     });
//   if (status == true) {
//     const createJournal = `INSERT INTO public.pp_mst_journal(
//             custorgmapid, journalname, journalacronym, colorid, softwareid, languageid, celevelid, templateid, printissn, trimesizewidth, trimesizewidthuom, trimesizeheight, trimesizeheightuom, pmid, supplierpmid, onlineissn,articletat, issuetat, totalissuecount, budgetedcount, isopenaccessarticle,isactive,proofingtype,isiauthor,iauthworkflowid,textcolumnid,ceid,amoid,printprofileid,onlineprofileid,templateformat,isnlp,isfirstproof,category,copyeditingworkflow,journaltype,referenceprofileid,pdfa2bprofileid,runon,runontype,cover,advert,blankpagelogic,coverprofileid,onshorece)
//            VALUES (${custId}, '${journalName}', '${JournalAcronym}', ${
//       colour || null
//     }, ${software || null}, ${language || null}, ${ceLevel || null}, ${
//       templateFile || null
//     }, '${printIssn || ''}', ${pageWidth || null}, '${
//       pageWidthUnit || null
//     }', ${pageHeight || null}, '${pageHeightUnit || null}', '${
//       projectManager || null
//     }', '${supplierProjectManager || null}','${onlineIssn || null}', ${
//       articleTat || null
//     }, ${issueTat || null}, ${issueCount || null}, ${budgetedCount || null}, ${
//       isAccessArticle.toString().length > 0 ? isAccessArticle : null
//     },${journalStatus.toString().length > 0 ? journalStatus : null}, '${
//       proofingType || null
//     }',${isIAuthorRequired.toString().length > 0 ? isIAuthorRequired : null},${
//       iAuthorWorkflow && isIAuthorRequired == true ? iAuthorWorkflow : null
//     },
//            ${textColumn || null},${ce || null},${amo || null},${
//       printProfile || null
//     },${onlineProfile || null},
//            '${templateFormat || null}',${isNLPRequired || null},${
//       isFirstproofRequired || null
//     },${category || null},${copyEditingWorkflow || null},'${
//       journalType || null
//     }',${referenceProfile || null},${pdfProfile || null},
//     ${runon !== null ? runon : false},'${
//       runontype && runon == true ? runontypeJSON : null
//     }',${cover !== null ? cover : false},${advert !== null ? advert : false},${
//       blankpagelogic || null
//     },${coverProfile || null},${onShoreCE || null}) RETURNING journalid`;
//     console.log(createJournal, 'createJournal');
//     await query(createJournal)
//       .then(async data => {
//         console.log(data, 'resultforcreatejournal');
//         nonArticle.map(async nonarticleid => {
//           const createNonArticle = `INSERT INTO public.pp_mst_journal_nonart_types(
//                     journalid, filetypeid)
//                    VALUES ( ${data[0].journalid}, ${nonarticleid})`;
//           await query(createNonArticle).then(async datanonartical => {
//             console.log(datanonartical, 'datanonartical');
//           });
//         });
//         let isPrimary;
//         const val = [];
//         productionList.forEach(list => {
//           isPrimary = list.editiorPrimary ? 1 : 0;
//           val.push(
//             `(${data[0].journalid}, '${list.editiorName}', '${list.editiorEmail}', null, '${list.editiorPhone}', null, '${list.prodStatus}', ${isPrimary})`,
//           );
//         });

//         // add tat info save
//         if (tatList) {
//           tatList.forEach(list => {
//             list.customerid = customerId;
//             list.journalid = data[0].journalid;
//             list.isactive = list.isactive != false;
//           });

//           const jsonparam = JSON.stringify(tatList);
//           console.log(jsonparam, tatList, 'tatlisttttttt');
//           const createTatInfo = `select * from insertjournalduedays('${jsonparam}')`;
//           await query(createTatInfo);
//         }

//         const createJournalConatacts = `INSERT INTO public.pp_mst_journal_contacts(
//                         journalid, name, email, address, phone1, phone2, designation, isprimary)
//                        VALUES ${val} RETURNING journalconid`;
//         console.log(createJournalConatacts, 'createJournalConatacts');
//         await query(createJournalConatacts).then(async datacontacts => {
//           console.log(datacontacts, 'datacontacts');
//           res.status(200).json({
//             journalid: data[0].journalid,
//           });
//         });
//       })
//       .catch(error => {
//         res.status(400).send({ message: error });
//       })
//       .catch(error => {
//         res.status(400).send({ message: error });
//       })
//       .catch(error => {
//         res.status(400).send({ message: error });
//       });
//   } else {
//     res.status(400).send({ message: 'Failed to get the custorgmapid' });
//   }
// };

// This code will work for CUP_Journals
export const createJournalMaster = async (req, res) => {
  const {
    customerId,
    divisionId,
    subDivisionId,
    countryId,
    journalName,
    JournalAcronym,
    colour,
    language,
    software,
    ceLevel,
    templateFile,
    printIssn,
    onlineIssn,
    pageWidth,
    pageWidthUnit,
    pageHeight,
    pageHeightUnit,
    totalissue,
    budgetedCount,
    templateFormat,
    textColumn,
    onlineProfile,
    printProfile,
    isIAuthorRequired,
    iAuthorWorkflow,
    amo,
    accessArticle,
    cover,
    runon,
    runontype,
    blankpagelogic,
    journalType,

    articletat,
    issuetat,
    category,
    copyeditingworkflow,
    isnlp,
    referenceprofile,
    pdfprofile,

    nonArticle,
    journalStatus,
    projectManager,
    supplierProjectManager,
    productionList,
    tatList,
    duId,
    modeltype,
    embargo,
    jcDate,
    ispreproof,
    journal_cetype,
    articletype,
    iauthorworkflowforbookreview,
  } = req.body;

  const runontypeJSON = JSON.stringify(runontype);
  const isAccessArticle = accessArticle === true ? 1 : 0;

  let custId;
  let status = true;

  const defaultSql = `select custorgmapid from public.org_mst_customer_orgmap where customerid = ${customerId}  and  divisionid = ${divisionId} and  subdivisionid = ${subDivisionId}  and countryid = ${countryId}`;

  await query(defaultSql)
    .then(async response => {
      if (response.length) {
        custId = response[0].custorgmapid;
      } else {
        const sql = `INSERT INTO public.org_mst_customer_orgmap(customerid, divisionid, subdivisionid, countryid) VALUES (${customerId}, ${divisionId}, ${subDivisionId}, ${countryId}) RETURNING custorgmapid`;
        await query(sql)
          .then(async resp => {
            custId = resp[0].custorgmapid;
            const createDu = `INSERT INTO public.org_mst_customerorg_du_map(custorgmapid, duid)
                    VALUES ( ${custId}, ${duId}) RETURNING custorgmapid`;

            await query(createDu)
              .then(async responsedu => {
                console.log(responsedu, 'duduud');
              })
              .catch(() => {
                status = false;
              });
          })
          .catch(() => {
            status = false;
          });
      }
    })
    .catch(() => {
      status = false;
    });

  if (status) {
    const createJournal = `INSERT INTO public.pp_mst_journal(
      custorgmapid,
      journalname,
      journalacronym,
      colorid,
      languageid,
      softwareid,
      celevelid,
      templateid,
      printissn,
      onlineissn,

      trimesizewidth,
      trimesizewidthuom,
      trimesizeheight,
      trimesizeheightuom,
      totalissuecount,
      budgetedcount,
      templateformat,
      textcolumnid,
      onlineprofileid,
      printprofileid,

      isiauthor,
      iauthworkflowid,
      iauthorreviewworkflow,
      amoid,
      isopenaccessarticle,
      isactive,
      articletat,
      issuetat,
      category,
      copyeditingworkflow,
      isnlp,

      referenceprofileid,
      pdfa2bprofileid,
      cover,
      runon,
      runontype,
      blankpagelogic,
      journaltype,
      pmid,
      supplierpmid,
    modeltype,
    isembargo,
embargodate  ,
ispreproof  ,
journal_cetype,
articletype,
iauthorreviewworkflow
    )
    VALUES (
      ${custId},
      '${journalName}', 
      '${JournalAcronym}', 
      ${colour || null}, 
      ${language || null}, 
      ${software || null}, 
      ${ceLevel || null}, 
      ${templateFile || null}, 
      '${printIssn || ''}',
      '${onlineIssn || null}',

      ${pageWidth || null}, 
      '${pageWidthUnit || null}', 
      ${pageHeight || null}, 
      '${pageHeightUnit || null}',
      ${totalissue || null},
      ${budgetedCount || null}, 
      '${templateFormat || null}',
      ${textColumn || null},
      ${onlineProfile || null},
      ${printProfile || null},

      ${
        (isIAuthorRequired && isIAuthorRequired.toString().length) > 0
          ? isIAuthorRequired
          : null
      }, 
      ${iAuthorWorkflow && isIAuthorRequired == true ? iAuthorWorkflow : null},
      ${
        iauthorworkflowforbookreview && isIAuthorRequired == true
          ? iauthorworkflowforbookreview
          : null
      },
      ${amo || null}, 
      ${isAccessArticle || null},
      ${journalStatus || null},
      ${articletat || null},
      ${issuetat || null},
      ${category || null},
      ${copyeditingworkflow || null},
      ${isnlp !== null ? isnlp : false},

      ${referenceprofile || null},
      ${pdfprofile || null},
      ${cover !== null ? cover : false},
      ${runon !== null ? runon : false},
      '${runontype && runon == true ? runontypeJSON : null}',
      ${blankpagelogic || null}, 
      '${articletype || null}',
      '${journalType || null}',
      '${projectManager || null}',
      '${supplierProjectManager || null}',
      '${modeltype || null}',
       '${embargo || false}',
     '${jcDate}', '${ispreproof || false}',
      '${journal_cetype || ''}'
    ) RETURNING journalid`;
    console.log('createJournal', createJournal);
    await query(createJournal)
      .then(async data => {
        nonArticle.map(async nonarticleid => {
          const createNonArticle = `INSERT INTO public.pp_mst_journal_nonart_types( journalid, filetypeid) VALUES ( ${data[0].journalid}, ${nonarticleid})`;
          await query(createNonArticle).then(async datanonartical => {
            console.log('datanonartical', datanonartical);
          });
        });

        let isPrimary;
        const baseJournalConId = await query(
          'select max(journalconid) as max_id from pp_mst_journal_contacts',
        );
        let currentJournalConId = baseJournalConId[0].max_id || 0;

        const contactPromises = productionList.map(async list => {
          isPrimary = list.editiorPrimary ? 1 : 0;
          currentJournalConId++;
          return `(${currentJournalConId}, ${data[0].journalid}, '${list.editiorName}', '${list.editiorEmail}', null, '${list.editiorPhone}', null, '${list.prodStatus}', ${isPrimary} )`;
        });
        const contacts = await Promise.all(contactPromises);

        const createJournalConatacts = `INSERT INTO public.pp_mst_journal_contacts(
          journalconid, journalid, name, email, address, phone1, phone2, designation, isprimary)
          VALUES ${contacts.join(',')} RETURNING journalconid`;

        await query(createJournalConatacts).then(async _datacontacts => {
          console.log(_datacontacts, 'data contacts');
          res.status(200).json({
            journalid: data[0].journalid,
          });
        });

        if (tatList) {
          tatList.forEach(list => {
            list.customerid = customerId;
            list.journalid = data[0].journalid;
            list.isactive = list.isactive != false;
          });

          const jsonparam = JSON.stringify(tatList);
          const createTatInfo = `select * from insertjournalduedays('${jsonparam}')`;
          await query(createTatInfo);
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'Failed to get the custorgmapid' });
  }
};

export const getJournalMasterConfig = async (req, res) => {
  try {
    const { value, label } = req.body;

    if (!value) {
      return res
        .status(400)
        .json({ message: "Missing 'value' in request body" });
    }

    // Fetch the journal config data
    const journalConfigData = formConfig.find(item => item.id === value);
    const defaultConfig = formConfig.find(item => item.id === '0');

    // Use defaultConfig if journalConfigData is not found
    const data = journalConfigData || defaultConfig;

    if (!data) {
      return res.status(404).json({ message: 'No configuration found' });
    }

    // Create a copy to avoid modifying original data
    const updatedData = JSON.parse(JSON.stringify(data));

    // Find and update the customer name field if it exists
    const customerNameField = updatedData.customerInfo?.find(
      item => item.fieldName === 'customer',
    );
    if (customerNameField) {
      customerNameField.value = value || '';
    }

    const customeShortNameField = updatedData.customerInfo?.find(
      item => item.fieldName === 'customershortname',
    );
    if (customeShortNameField) {
      customeShortNameField.value = label || '';
    }
    return res.status(200).json({ data: updatedData });
  } catch (error) {
    console.error('Error fetching journal master config:', error);
    return res
      .status(500)
      .json({ message: error.message || 'An internal server error occurred' });
  }
};

export const createNewJournalMaster = async (req, res) => {
  const { customerId, accessArticle, runontype } = req.body;

  const {
    customerInfo,
    journalInfo,
    tatInfo,
    otherInfo,
    contactInfo,
    journalContact,
  } = req.body;
  // const trimSizeObj = journalInfo
  // .filter(item => item.fieldName === "trimesize") // Correctly filter based on `fieldName`
  // .flatMap(item => item.subForm || []) // Flatten subForm arrays safely
  // .map(subItem => ({ [subItem.fieldName]: subItem.value }));
  const trimForm = journalInfo
    .filter(item => item.fieldName === 'trimesize')
    .flatMap(item => item.subForm || []) // Flatten subForm arrays safely
    .reduce(
      (acc, subItem) => ({
        ...acc,
        [subItem.fieldName]: subItem.value?.toString().replace(/\s+/g, ''),
      }),
      {},
    ); // Convert to a single object

  const trimSizeObj = [trimForm];
  const combinedInfoData = {
    customerId: req.body.customerId,
    duId: req.body.duid,
    ...customerInfo.reduce((acc, item) => {
      acc[item.fieldName] = item.value;
      return acc;
    }, {}),
    ...journalInfo.reduce((acc, item) => {
      acc[item.fieldName] = item.value;
      return acc;
    }, {}),
    ...otherInfo.reduce((acc, item) => {
      acc[item.fieldName] = item.value;
      return acc;
    }, {}),
    ...contactInfo.reduce((acc, item) => {
      acc[item.fieldName] = item.value;
      return acc;
    }, {}),
    tatInfo: tatInfo.map(group =>
      Object.fromEntries(
        group.map(({ fieldName, value }) => [fieldName, value]),
      ),
    ),
    journalContact: journalContact.map(group =>
      Object.fromEntries(
        group.map(({ fieldName, value }) => [fieldName, value]),
      ),
    ),
    trimForm: trimSizeObj.length > 0 ? trimSizeObj : [],
  };

  const nonArticle = combinedInfoData?.nonarticle.map(item => item.value);

  const runontypeJSON = JSON.stringify(runontype);
  const isAccessArticle = accessArticle === true ? 1 : 0;

  let custId;
  let status = true;

  const defaultSql = `select custorgmapid from public.org_mst_customer_orgmap where customerid = ${combinedInfoData.customer}  and  divisionid = ${combinedInfoData.division} and  subdivisionid = ${combinedInfoData.subdivision}  and countryid = ${combinedInfoData.country} and isactive = 1`;

  await query(defaultSql)
    .then(async response => {
      if (response.length) {
        custId = response[0].custorgmapid;
      } else {
        const sql = `INSERT INTO public.org_mst_customer_orgmap(customerid, divisionid, subdivisionid, countryid) VALUES (${combinedInfoData.customer}, ${combinedInfoData.division}, ${combinedInfoData.subdivision}, ${combinedInfoData.country}) RETURNING custorgmapid`;
        await query(sql)
          .then(async resp => {
            custId = resp[0].custorgmapid;
            const createDu = `INSERT INTO public.org_mst_customerorg_du_map(custorgmapid, duid)
                    VALUES ( ${custId}, ${combinedInfoData.duId}) RETURNING custorgmapid`;

            await query(createDu)
              .then(async responsedu => {
                console.log(responsedu, 'duduud');
              })
              .catch(() => {
                status = false;
              });
          })
          .catch(() => {
            status = false;
          });
      }
    })
    .catch(() => {
      status = false;
    });

  // journalpriority
  // proofcreationtypes
  // interfacecode,
  // dataadministratorcode

  if (status) {
    const createJournal = `INSERT INTO public.pp_mst_journal(
      custorgmapid,
      journalname,
      journalacronym,
      colorid,
      softwareid,
      languageid,
      celevelid,
      templateid,
      printissn,
      trimesizewidth,
      trimesizewidthuom,
      trimesizeheight,
      trimesizeheightuom,
      pmid,
      supplierpmid,
      onlineissn,
      articletat,
      issuetat,
      totalissuecount,
      budgetedcount,
      isactive,
      proofingtype,
      textcolumnid,
      ceid,
      amoid,
      printprofileid,
      onlineprofileid,
      templateformat,
      journalemail,
      isnlp,
      isfirstproof,
      category,
      copyeditingworkflow,
      journaltype,
      referenceprofileid,
      pdfa2bprofileid,
      runon,
      runontype,

      cover,
      advert,
      blankpagelogic,
      coverprofileid,
      pdfmerging,
      papworkflow,
      modeltype,
      newsletter,
      islicenserequired,
      otherdetails,
      duid,
      conversionfactor,
      cereview,
      iauthworkconversionflowid,
      isembargo,
      embargodate,
      ispreproof,
      revisedtopap,
      pdfjournalpublication,
      journal_cetype,
      priorityid,
      jouupdatedby,
      jouupdatedon,
      isipubeditnewflow,
      ispdfless,
      articletype,
      iauthorreviewworkflow,
      proofcreationtypeid,
      interfacecodeid,
      dataadministratorcodeid,
      isopenaccessarticle,
      typesetmodalid
    ) 
    VALUES (
      ${custId},
      '${combinedInfoData.journalname || null}', 
      '${combinedInfoData.acronym || null}', 
      ${combinedInfoData.colours || null}, 
      ${combinedInfoData.softwares || null}, 
      ${combinedInfoData.languages || null}, 
      ${combinedInfoData.celevel || null}, 
      ${combinedInfoData.templateid || null}, 
      '${combinedInfoData.printissn || ''}',
      ${combinedInfoData?.trimForm[0]?.pagewidth || 0}, 
     ' ${combinedInfoData?.trimForm[0]?.pagewidthunit || 'in'}', 
      ${combinedInfoData?.trimForm[0]?.pageheight || 0}, 
      '${combinedInfoData?.trimForm[0]?.pageheightunit || 'in'}',
      '${combinedInfoData.projectmanager || ''}',
      '${combinedInfoData.supplierprojectmanager || ''}',
      '${combinedInfoData.onlineissn || null}',
      ${combinedInfoData.articletat || null},
      ${combinedInfoData.issuetat || null},
      ${combinedInfoData.totalissue || null},     
      ${combinedInfoData.budgeted || null}, 
      ${Number(combinedInfoData.status) || 1},   
      ${combinedInfoData.proofingtype || null},
      ${combinedInfoData.textcolumn || null},
      ${combinedInfoData.ceid || null},
      ${combinedInfoData.amoid || null}, 
      '${combinedInfoData.printprofile || null}',
      '${combinedInfoData.onlineprofile || null}',
      '${combinedInfoData.templateformat || null}',
      '${combinedInfoData.journalemail || ''}',
      ${combinedInfoData.isnlp !== undefined ? combinedInfoData.isnlp : false},
      ${combinedInfoData.isfirstproof || false},
      ${combinedInfoData.category || null},
      ${combinedInfoData.copyeditingworkflow || null},
      '${combinedInfoData.journalType || null}',
      ${combinedInfoData.referenceprofile || null},
      ${combinedInfoData.pdfprofile || null},
      ${combinedInfoData.runon !== undefined ? combinedInfoData.runon : false},
      ${
        combinedInfoData.runontype && combinedInfoData.runon
          ? `'${runontypeJSON}'`
          : null
      },
      ${combinedInfoData.cover !== undefined ? combinedInfoData.cover : false},
      ${
        combinedInfoData.advert !== undefined ? combinedInfoData.advert : false
      },
      ${combinedInfoData.blankpagelogic || null}, 
      ${combinedInfoData.coverprofileid || null}, 
      ${
        combinedInfoData.pdfmerging !== undefined
          ? combinedInfoData.pdfmerging
          : false
      },
      ${
        combinedInfoData.papworkflow !== undefined
          ? combinedInfoData.papworkflow
          : false
      },
      ${combinedInfoData.modeltype || null}, 
      ${
        combinedInfoData.newsletter !== undefined
          ? combinedInfoData.newsletter
          : false
      },
      ${
        combinedInfoData.islicenserequired !== undefined
          ? combinedInfoData.islicenserequired
          : false
      },
      ${combinedInfoData.otherdetails || null}, 
      ${combinedInfoData.duId || null}, 
      ${combinedInfoData.conversionfactor || null},
      ${
        combinedInfoData.cereview !== undefined
          ? combinedInfoData.cereview
          : false
      }, 
      ${combinedInfoData.iauthworkconversionflowid || null},
      ${
        combinedInfoData.isembargo !== undefined
          ? combinedInfoData.isembargo
          : false
      },
      ${combinedInfoData.embargodate || null},
      ${
        combinedInfoData.ispreproof !== undefined
          ? combinedInfoData.ispreproof
          : false
      },
      ${
        combinedInfoData.revisedtopap !== undefined
          ? combinedInfoData.revisedtopap
          : false
      },
      ${
        combinedInfoData.pdfjournalpublication !== undefined
          ? combinedInfoData.pdfjournalpublication
          : false
      },
      ${combinedInfoData.journal_cetype || null},
      ${combinedInfoData.priorityid || null},
      ${combinedInfoData.jouupdatedby || null},
      ${combinedInfoData.jouupdatedon || null},
      ${combinedInfoData.isipubeditnewflow || null},
      ${
        combinedInfoData.ispdfless !== undefined
          ? combinedInfoData.ispdfless
          : false
      },
      ${combinedInfoData.articletype || null},
      ${combinedInfoData.iauthorreviewworkflow || null},
      ${combinedInfoData.proofcreationtypeid || null}, 
      ${combinedInfoData.interfacecodeid || null}, 
      ${combinedInfoData.dataadministratorcodeid || null},
      ${isAccessArticle || null},
      ${combinedInfoData.typesetmodalid || null}
      
    ) RETURNING journalid;`;
    // isiauthor,
    // iauthworkflowid,
    // ${combinedInfoData.isiauthor ? combinedInfoData.isiauthor : false},
    // ${
    //   combinedInfoData.iauthorworkflow && combinedInfoData.isiauthor
    //     ? combinedInfoData.iauthorworkflow
    //     : null
    // },

    console.log('createJournal', createJournal);
    await query(createJournal)
      // eslint-disable-next-line consistent-return
      .then(async data => {
        // nonArticle.map(async nonarticleid => {
        //   const createNonArticle = `INSERT INTO public.pp_mst_journal_nonart_types( journalid, filetypeid) VALUES ( ${data[0].journalid}, ${nonarticleid})`;
        //   await query(createNonArticle).then(async datanonartical => {
        //     console.log('datanonartical', datanonartical);
        //   });
        // });
        if (!data || data.length === 0) {
          return res.status(400).send({
            message: 'Journal creation failed, no journal ID returned.',
          });
        }

        const promises = nonArticle.map(nonarticleid =>
          query(`INSERT INTO public.pp_mst_journal_nonart_types(journalid, filetypeid) 
                 VALUES (${data[0].journalid}, ${nonarticleid})`),
        );

        const results = await Promise.all(promises);
        console.log('All non-articles inserted:', results);

        let isprimary;
        const baseJournalConId = await query(
          'select max(journalconid) as max_id from pp_mst_journal_contacts',
        );
        let currentJournalConId = baseJournalConId[0].max_id || 0;

        const contactPromises = combinedInfoData?.journalContact.map(list => {
          isprimary = list.isprimary ? 1 : 0;
          currentJournalConId++;

          // Properly handle null values
          const name = list.name
            ? `'${list.name.replace(/'/g, "''")}'`
            : 'NULL';
          const email = list.email
            ? `'${list.email.replace(/'/g, "''")}'`
            : 'NULL';
          const phone = list.phone
            ? `'${list.phone.replace(/'/g, "''")}'`
            : 'NULL';
          const designation = list.designation
            ? `'${list.designation.replace(/'/g, "''")}'`
            : 'NULL';

          return `(${currentJournalConId}, ${data[0].journalid}, ${name}, ${email}, NULL, ${phone}, NULL, ${designation}, ${isprimary})`;
        });

        const contacts = contactPromises.join(',');

        if (contacts) {
          const createJournalContacts = `
            INSERT INTO public.pp_mst_journal_contacts(
              journalconid, journalid, name, email, address, phone1, phone2, designation, isprimary
            ) VALUES ${contacts} RETURNING journalconid
          `;

          await query(createJournalContacts)
            .then(_datacontacts => {
              console.log(_datacontacts, 'data contacts');
              res.status(200).json({ journalid: data[0].journalid });
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        }

        if (combinedInfoData.tatInfo && combinedInfoData.tatInfo.length > 0) {
          const safeString = value =>
            value ? `'${value.replace(/'/g, "''")}'` : 'NULL';

          const tatConfig = combinedInfoData.tatInfo.map(list => {
            list.customerid = customerId;
            list.journalid = data[0].journalid;
            list.isactive = true;
            list.duid = combinedInfoData?.duId || null;

            // Properly handle null values
            const duid = list.duid ? `'${list.duid}'` : 'NULL';
            const stageid = safeString(list.stage);
            const articleduedays = safeString(list.articleduedays);
            const issueduedays = safeString(list.issueduedays);
            const stageiterationcount = safeString(list.stageiterationcount);
            const uomtype = safeString(list.uomtype);

            return `(${data[0].journalid}, ${customerId}, ${duid}, ${stageid}, ${articleduedays}, ${issueduedays}, ${list.isactive}, ${stageiterationcount}, ${uomtype})`;
          });

          const dueConfig = tatConfig.join(',');

          const createTATinfo = `
            INSERT INTO public.org_mst_journal_dueconfig(
              journalid, customerid, duid, stageid, articleduedays, issueduedays, isactive, stageiterationcount, uomtype
            ) VALUES ${dueConfig} RETURNING journalid;
          `;

          try {
            const createTatFrm = await query(createTATinfo);
            console.log('createTatFrm@@33', createTatFrm);
          } catch (error) {
            console.error('Error inserting data:', error);
          }
        }
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'Failed to get the custorgmapid' });
  }
};
export const updateNewJournalMaster = async (req, res) => {
  try {
    const {
      customerInfo,
      journalInfo,
      tatInfo,
      otherInfo,
      contactInfo,
      journalContact,
    } = req.body;
    const trimForm = journalInfo
      .filter(item => item.fieldName === 'trimesize')
      .flatMap(item => item.subForm || []) // Flatten subForm arrays safely
      .reduce(
        (acc, subItem) => ({ ...acc, [subItem.fieldName]: subItem.value }),
        {},
      ); // Convert to a single object

    const trimSizeObj = [trimForm];
    const combinedInfoData = {
      customerId: req.body.customerId,
      duId: req.body.duid,
      journalId: req.body.journalId,
      ...customerInfo.reduce((acc, item) => {
        acc[item.fieldName] = item.value;
        return acc;
      }, {}),
      ...journalInfo.reduce((acc, item) => {
        acc[item.fieldName] = item.value;
        return acc;
      }, {}),
      ...otherInfo.reduce((acc, item) => {
        acc[item.fieldName] = item.value;
        return acc;
      }, {}),
      ...contactInfo.reduce((acc, item) => {
        acc[item.fieldName] = item.value;
        return acc;
      }, {}),
      tatInfo: tatInfo.map(group =>
        Object.fromEntries(
          group.map(({ fieldName, value }) => [fieldName, value]),
        ),
      ),
      journalContact: journalContact.map(group =>
        Object.fromEntries(
          group.map(({ fieldName, value }) => [fieldName, value]),
        ),
      ),
      trimForm: trimSizeObj.length > 0 ? trimSizeObj : [],
    };
    console.log('combinedInfoData@222', combinedInfoData);
    const { updatedBy = '' } = req.body;

    const runontypeJSON =
      JSON.stringify(
        req.body && req.body.custList && req.body.custList.runontype,
      ) || null;

    const updateJournal = `
    UPDATE public.pp_mst_journal
    SET
      colorid=${combinedInfoData.colours ? combinedInfoData.colours : null},
      softwareid=${
        combinedInfoData.softwares ? combinedInfoData.softwares : null
      },
      languageid=${
        combinedInfoData.languages ? combinedInfoData.languages : null
      },
      celevelid=${combinedInfoData.celevel ? combinedInfoData.celevel : null},
      templateid=${
        combinedInfoData.templatefile ? combinedInfoData.templatefile : null
      },
      printissn='${
        combinedInfoData.printissn ? combinedInfoData.printissn : ''
      }',
      trimesizewidth=${
        combinedInfoData?.trimForm[0]?.pagewidth
          ? combinedInfoData?.trimForm[0]?.pagewidth
          : null
      },
      trimesizewidthuom='${
        combinedInfoData?.trimForm[0]?.pagewidthunit
          ? combinedInfoData?.trimForm[0]?.pagewidthunit
          : null
      }',
      trimesizeheight=${
        combinedInfoData?.trimForm[0]?.pageheight
          ? combinedInfoData?.trimForm[0]?.pageheight
          : null
      },
      trimesizeheightuom='${
        combinedInfoData?.trimForm[0]?.pageheightunit
          ? combinedInfoData?.trimForm[0]?.pageheightunit
          : null
      }',
      pmid='${
        combinedInfoData.projectmanager ? combinedInfoData.projectmanager : ''
      }',
      supplierpmid='${
        combinedInfoData.supplierprojectmanager
          ? combinedInfoData.supplierprojectmanager
          : ''
      }',
      onlineissn='${
        combinedInfoData.onlineissn ? combinedInfoData.onlineissn : null
      }',
      totalissuecount=${
        combinedInfoData.totalissue ? combinedInfoData.totalissue : null
      },
      budgetedcount=${
        combinedInfoData.budgeted ? combinedInfoData.budgeted : null
      },
      isopenaccessarticle=${
        combinedInfoData.openarticle &&
        combinedInfoData.openarticle.toString().length > 0
          ? combinedInfoData.openarticle
          : null
      },
      isactive=${
        combinedInfoData.status && combinedInfoData.status.toString().length > 0
          ? combinedInfoData.status
          : null
      },
      runon=${
        combinedInfoData.runon && combinedInfoData.runon
          ? combinedInfoData.runon
          : false
      },
      runontype='${
        combinedInfoData.runontype && combinedInfoData.runontype
          ? runontypeJSON
          : null
      }',
      articletype='${
        combinedInfoData.articletype && combinedInfoData.articletype
          ? combinedInfoData.articletype
          : null
      }',
      cover=${
        combinedInfoData.cover && combinedInfoData.cover
          ? combinedInfoData.cover
          : false
      },
      textcolumnid=${
        combinedInfoData.textcolumn ? combinedInfoData.textcolumn : null
      },
      amoid=${combinedInfoData.amo ? combinedInfoData.amo : null},
      printprofileid=${
        combinedInfoData.printprofile ? combinedInfoData.printprofile : null
      },
      onlineprofileid=${
        combinedInfoData.onlineprofile ? combinedInfoData.onlineprofile : null
      },
      templateformat='${
        combinedInfoData.templateformat ? combinedInfoData.templateformat : null
      }',
      journaltype='${
        combinedInfoData.journaltype ? combinedInfoData.journaltype : null
      }',

      articletat=${
        combinedInfoData.articletat ? combinedInfoData.articletat : null
      },
      issuetat=${combinedInfoData.issuetat ? combinedInfoData.issuetat : null},
      category='${
        combinedInfoData.category ? combinedInfoData.category : null
      }',
      copyeditingworkflow=${
        combinedInfoData.copyeditingworkflow
          ? combinedInfoData.copyeditingworkflow
          : null
      },
      isnlp=${combinedInfoData.isnlp ? combinedInfoData.isnlp : false},
      referenceprofileid=${
        combinedInfoData.referenceprofile
          ? combinedInfoData.referenceprofile
          : null
      },
      pdfa2bprofileid=${
        combinedInfoData.pdfprofile ? combinedInfoData.pdfprofile : null
      },
      isembargo = '${combinedInfoData.embargo || false}',
      embargodate = ${
        combinedInfoData.jcDate ? `'${combinedInfoData.jcDate}'` : null
      },
       ispreproof=${
         combinedInfoData.ispreproof ? combinedInfoData.ispreproof : false
       }  ,
       journal_cetype = '${
         combinedInfoData.journal_cetype
           ? combinedInfoData.journal_cetype
           : null
       }',
       jouupdatedby = '${updatedBy}',
       iauthorreviewworkflow=${
         combinedInfoData.iauthorworkflowforbookreview &&
         combinedInfoData.isiauthor == true
           ? combinedInfoData.iauthorworkflowforbookreview
           : null
       },
       priorityid = ${
         combinedInfoData.priorityid ? combinedInfoData.priorityid : null
       },
      proofcreationtypeid = ${combinedInfoData.proofcreationtypeid || null}, 
      interfacecodeid = ${combinedInfoData.interfacecodeid || null}, 
      dataadministratorcodeid =${
        combinedInfoData.dataadministratorcodeid || null
      },
      typesetmodalid=${combinedInfoData.typesetmodalid || null},
       jouupdatedon = CURRENT_TIMESTAMP
    WHERE 
      journalid=${combinedInfoData.journalId}`;
    // isiauthor=${combinedInfoData.isiauthor},
    // iauthworkflowid=${
    //   combinedInfoData.iauthorworkflow && combinedInfoData.isiauthor == true
    //     ? Number(combinedInfoData.iauthorworkflow)
    //     : null
    // },
    console.log('updateJournal@@3', updateJournal);
    await query(updateJournal);
    if (combinedInfoData.nonarticle) {
      console.log('updateJournal', updateJournal);
      const deleteNonArticle = `DELETE FROM public.pp_mst_journal_nonart_types WHERE journalid=${combinedInfoData.journalId}`;
      await query(deleteNonArticle);
      const promises = combinedInfoData.nonarticle.map(nonarticleid =>
        query(`INSERT INTO public.pp_mst_journal_nonart_types(journalid, filetypeid) 
                 VALUES (${combinedInfoData.journalId}, ${nonarticleid.value})`),
      );
      const results = await Promise.all(promises);
      console.log('All non-articles inserted:', results);
    }

    if (combinedInfoData.journalContact) {
      const deleteProd = `DELETE FROM public.pp_mst_journal_contacts WHERE journalid=${combinedInfoData.journalId};`;
      const baseJournalConId = await query(
        'select max(journalconid) as max_id from pp_mst_journal_contacts',
      );
      let currentJournalConId = baseJournalConId[0].max_id || 0;
      // Execute the delete query first
      await query(deleteProd);

      const contactPromises = combinedInfoData?.journalContact.map(list => {
        const isprimary = list.isprimary ? 1 : 0;
        currentJournalConId++;

        // Properly handle null values
        const name = list.name ? `'${list.name.replace(/'/g, "''")}'` : 'NULL';
        const email = list.email
          ? `'${list.email.replace(/'/g, "''")}'`
          : 'NULL';
        const phone = list.phone
          ? `'${list.phone.replace(/'/g, "''")}'`
          : 'NULL';
        const designation = list.designation
          ? `'${list.designation.replace(/'/g, "''")}'`
          : 'NULL';

        return `(${currentJournalConId}, ${combinedInfoData.journalId}, ${name}, ${email}, NULL, ${phone}, NULL, ${designation}, ${isprimary})`;
      });

      const contacts = contactPromises.join(',');

      if (contacts) {
        const createJournalContacts = `
            INSERT INTO public.pp_mst_journal_contacts(
              journalconid, journalid, name, email, address, phone1, phone2, designation, isprimary
            ) VALUES ${contacts} RETURNING journalconid;
          `;

        // Execute the insert query
        const createJournalContact = await query(createJournalContacts);
        console.log('All contacts inserted:', createJournalContact);
      }
    }

    if (combinedInfoData.tatInfo && combinedInfoData.tatInfo.length > 0) {
      try {
        const getJournaldetailsQuery = `SELECT * FROM public.pp_mst_journal WHERE journalid=${combinedInfoData.journalId};`;
        const getJournaldetails = await query(getJournaldetailsQuery);
        console.log('getJournaldetails:', getJournaldetails);

        if (!getJournaldetails.length) {
          throw new Error(
            `Journal details not found for journalId: ${combinedInfoData.journalId}`,
          );
        }

        const getcustomerdetailsQuery = `SELECT * FROM public.org_mst_customer_orgmap WHERE custorgmapid=${getJournaldetails[0].custorgmapid};`;
        const getCustomerDetails = await query(getcustomerdetailsQuery);
        console.log('getCustomerDetails:', getCustomerDetails);

        if (!getCustomerDetails.length) {
          throw new Error(
            `Customer details not found for custorgmapid: ${getJournaldetails[0].custorgmapid}`,
          );
        }

        const deleteTAT = `DELETE FROM public.org_mst_journal_dueconfig WHERE journalid=${combinedInfoData.journalId};`;
        await query(deleteTAT);

        const safeString = value =>
          typeof value === 'string'
            ? `'${value.replace(/'/g, "''")}'`
            : value !== null && value !== undefined
            ? value
            : 'NULL';

        const contactPromises = combinedInfoData.tatInfo.map(list => {
          const isactive = true;
          const duid = combinedInfoData.duId
            ? `'${combinedInfoData.duId}'`
            : 'NULL';
          const stageid = safeString(list.stage);
          const articleduedays = safeString(list.articleduedays);
          const issueduedays = safeString(list.issueduedays);
          const stageiterationcount = safeString(list.stageiterationcount);
          const uomtype = safeString(list.uomtype);

          return `(${combinedInfoData.journalId}, ${getCustomerDetails[0].customerid}, ${duid}, ${stageid}, ${articleduedays}, ${issueduedays}, ${isactive}, ${stageiterationcount}, ${uomtype})`;
        });

        const contacts = contactPromises.join(',');

        if (contacts) {
          const createTATinfo = `
              INSERT INTO public.org_mst_journal_dueconfig(
                journalid, customerid, duid, stageid, articleduedays, issueduedays, isactive, stageiterationcount, uomtype
              ) VALUES ${contacts} RETURNING journalid;
            `;

          const createTatFrm = await query(createTATinfo);
          console.log('TAT info inserted:', createTatFrm);
        }
      } catch (error) {
        console.error('Error processing TAT info:', error);
      }
    }

    res
      .status(200)
      .json({ success: true, message: 'Journal updated successfully.' });
  } catch (error) {
    console.error('Error updating journal:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message,
    });
  }
};

export const journalFile = async (req, res) => {
  const { journalid, path, repofileuuid } = req.body;
  const sql = `INSERT INTO public.pp_mst_journal_instructions(journalid, repofilepath, repofileuuid)
       VALUES ( ${journalid}, '${path}', '${repofileuuid}')`;
  console.log(sql, 'insertingfile');
  await query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to get the details for master activity
export const getJournalList = (req, res) => {
  const reqData = req.body;
  let sql = '';
  sql = `SELECT COUNT(*) FROM wms_detail_journal WHERE duid = ${reqData.duId} `;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM wms_detail_journal WHERE duid = ${reqData.duId}  ORDER BY status DESC`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// export const getJournalListByID = async (req, res) => {
//   const reqData = req.body;
//   const sqlQuery = `SELECT * FROM wms_detail_journal WHERE journalid = ${reqData.journalId}`;
//   console.log(sqlQuery, 'sqlforquerryy');

//   await query(sqlQuery)
//     .then(dataArray => {
//       if (dataArray.length > 0) {
//         const journalConfigData = formConfig.find((item) => item.custname === dataArray[0].customername);
//         if (journalConfigData.customerInfo && dataArray.length > 0) {
//           const data = dataArray[0]; // Accessing the first element
//           journalConfigData.customerInfo = journalConfigData.customerInfo.map((item) => {
//             if (data.hasOwnProperty(item.fieldName)) {
//               const newvaue = {...item, value: data[item.fieldName] }
//               return newvaue ;
//             }
//             return item;
//           });
//         }
//         console.log("latest@333journalConfigData", journalConfigData)
//         res.status(200).json({ data:journalConfigData });
//       } else {
//         res.status(200).json({ data: [], message: 'No data found' });
//       }
//     })
//     .catch(error => {
//       res.status(400).send({ message: error });
//     });
// };
export const getJournalListByID = async (req, res) => {
  try {
    const reqData = req.body;

    // Using parameterized query to prevent SQL injection
    const sqlQuery = `SELECT * FROM wms_detail_journal WHERE journalid = ${reqData.journalId}`;
    const dataArray = await query(sqlQuery);

    if (dataArray.length === 0) {
      return res.status(200).json({
        data: [],
        message: 'No data found',
      });
    }

    const queryResult = dataArray[0];
    const journalConfigData = formConfig.find(
      item => item.custname === queryResult.customername,
    );

    if (!journalConfigData) {
      return res.status(404).json({
        message: 'Journal configuration not found',
      });
    }
    const updatedConfig = JSON.parse(JSON.stringify(journalConfigData));

    if (reqData.isUpdate) {
      if (Array.isArray(updatedConfig.customerInfo)) {
        updatedConfig.customerInfo = updatedConfig.customerInfo.map(item => ({
          ...item,
          disabled: true,
        }));
      }
      if (Array.isArray(updatedConfig.journalInfo)) {
        updatedConfig.journalInfo = updatedConfig.journalInfo.map(item => ({
          ...item,
          disabled: ['journalname', 'acronym'].includes(item.fieldName)
            ? true
            : item.disabled,
        }));
      }
    }

    console.log('Updated journal config:', updatedConfig);

    return res.status(200).json({
      data: updatedConfig,
    });
  } catch (error) {
    console.error('Error in getJournalListByID:', error);
    return res.status(500).json({
      message: 'Internal server error',
      error: error.message,
    });
  }
};

// export const updateJournalMaster = async (req, res) => {
//   const { custList, prodList, tatList } = req.body;
//   console.log(req.body, 'bodyforupdate');
//   // let updateCustomer = `UPDATE public.org_mst_customer_orgmap
//   // SET  isactive=${custList.status}
//   // WHERE custorgmapid=${custList.custorgmapid}`;
//   // console.log(updateCustomer, "updateCustomer")
//   // await query(updateCustomer).then(async (response) => {
//   const runontypeJSON = JSON.stringify(req.body.custList.runontype);
//   console.log('runontypeJSON', runontypeJSON);
//   const updateJournal = `UPDATE public.pp_mst_journal
// 	SET  colorid=${custList.colours ? custList.colours : null}, softwareid=${
//     custList.softwares ? custList.softwares : null
//   }, languageid=${custList.languages ? custList.languages : null}, celevelid=${
//     custList.celevel ? custList.celevel : null
//   }, templateid=${
//     custList.templatefile ? custList.templatefile : null
//   }, printissn='${
//     custList.printissn ? custList.printissn : ''
//   }', trimesizewidth=${
//     custList.pagewidth ? custList.pagewidth : null
//   }, trimesizewidthuom='${
//     custList.pagewidthunit ? custList.pagewidthunit : null
//   }', trimesizeheight=${
//     custList.pageheight ? custList.pageheight : null
//   }, trimesizeheightuom='${
//     custList.pageheightunit ? custList.pageheightunit : null
//   }',
//      pmid='${
//        custList.projectmanager ? custList.projectmanager : null
//      }', supplierpmid='${
//     custList.supplierprojectmanager ? custList.supplierprojectmanager : null
//   }',
//      onlineissn='${
//        custList.onlineissn ? custList.onlineissn : null
//      }',articletat=${
//     custList.articletat ? custList.articletat : null
//   }, issuetat=${custList.issuetat ? custList.issuetat : null},
//      totalissuecount=${
//        custList.totalissue ? custList.totalissue : null
//      }, budgetedcount=${
//     custList.budgeted ? custList.budgeted : null
//   }, isopenaccessarticle=${
//     custList.openarticle && custList.openarticle.toString().length > 0
//       ? custList.openarticle
//       : null
//   }, isactive =${
//     custList.status.toString().length > 0 ? custList.status : null
//   }, proofingtype ='${custList.proofingtype ? custList.proofingtype : null}',
//       isiauthor = ${
//         custList.isiauthor && custList.isiauthor.toString().length > 0
//           ? custList.isiauthor
//           : null
//       },iauthworkflowid =${
//     custList.iauthorworkflow && custList.isiauthor == true
//       ? custList.iauthorworkflow
//       : null
//   },
// runon = ${custList.runon && custList.runon ? custList.runon : false},
// runontype = '${
//     custList.runontype && custList.runontype ? runontypeJSON : null
//   }',
//   cover = ${custList.cover && custList.cover ? custList.cover : false},
//   advert = ${custList.advert && custList.advert ? custList.advert : false},
//   blankpagelogic = ${
//     custList.blankpagelogic && custList.blankpagelogic
//       ? custList.blankpagelogic
//       : null
//   },
// textcolumnid = ${custList.textcolumn ? custList.textcolumn : null},ceid =${
//     custList.ce ? custList.ce : null
//   },amoid =${custList.amo ? custList.amo : null},printprofileid =${
//     custList.printprofile ? custList.printprofile : null
//   },
//       onlineprofileid =${
//         custList.onlineprofile ? custList.onlineprofile : null
//       } ,templateformat='${
//     custList.templateformat ? custList.templateformat : null
//   }',isnlp = ${
//     custList.isnlp && custList.isnlp.toString().length > 0
//       ? custList.isnlp
//       : null
//   },
//       isfirstproof = ${
//         custList.isfirstproof && custList.isfirstproof.toString().length > 0
//           ? custList.isfirstproof
//           : null
//       },category=${
//     custList.category ? custList.category : null
//   },copyeditingworkflow= ${
//     custList.copyeditingworkflow ? custList.copyeditingworkflow : null
//   }, journaltype = '${custList.journaltype ? custList.journaltype : null}',
//   referenceprofileid =${
//     custList.referenceprofile ? custList.referenceprofile : null
//   },
//   pdfa2bprofileid =${custList.pdfprofile ? custList.pdfprofile : null},
//   coverprofileid =${custList.coverprofile ? custList.coverprofile : null}
// 	WHERE journalid=${custList.journalid}`;
//   console.log(updateJournal, 'sqlforfirst');
//   await query(updateJournal)
//     .then(async response => {
//       console.log(response, 'respsosofn');
//       const deleteNonArticle = `DELETE FROM public.pp_mst_journal_nonart_types
//        where journalid=${custList.journalid}`;
//       console.log(deleteNonArticle, 'deleteNonArticle');
//       await query(deleteNonArticle)
//         .then(async deletenonartical => {
//           console.log(deletenonartical, 'deletenonarticaldeletenonartical');
//           custList.nonArticle.map(async nonarticleid => {
//             const createNonArticle = `INSERT INTO public.pp_mst_journal_nonart_types(
//                 journalid, filetypeid)
//                VALUES ( ${custList.journalid}, ${nonarticleid})`;
//             console.log(createNonArticle, 'createNonArticle');
//             await query(createNonArticle).then(async () => {});
//           });
//           const deleteProd = `DELETE FROM public.pp_mst_journal_contacts WHERE journalid=${custList.journalid};`;
//           await query(deleteProd).then(async () => {
//             let isPrimary;
//             const val = [];
//             const tempProdList = [];
//             prodList.forEach(list => {
//               if (list != null) {
//                 tempProdList.push(list);
//               }
//             });
//             console.log(tempProdList, 'tempProdList');
//             tempProdList.forEach(list => {
//               console.log(list, 'listforprod', list.editiorPrimary);
//               isPrimary = list.editiorPrimary == true ? 1 : 0;
//               val.push(
//                 `(${custList.journalid}, '${list.editiorName}', '${list.editiorEmail}', null, '${list.editiorPhone}', null, '${list.prodStatus}', ${isPrimary})`,
//               );
//             });
//             const updateProd = `INSERT INTO public.pp_mst_journal_contacts(
//                                 journalid, name, email, address, phone1, phone2, designation, isprimary)
//                                VALUES ${val} RETURNING journalconid`;
//             console.log(updateProd, 'updateProdupdateProd');
//             await query(updateProd).then(async responsedu => {
//               console.log(responsedu, 'resoponsefordu');
//             });
//             // added tat delete info also
//             if (tatList) {
//               tatList.forEach(list => {
//                 list.customerid = custList.customer;
//                 list.journalid = custList.journalid;
//                 list.isactive = list.isactive != false;
//               });
//               const jsonparam = JSON.stringify(tatList);
//               const createTatInfo = `select * from insertjournalduedays('${jsonparam}')`;
//               await query(createTatInfo);
//             }
//           });
//           res.status(200).json({
//             data: 'Updated Successfully',
//           });
//         })
//         .catch(error => {
//           console.log(error, 'er1');
//           res.status(400).send({ message: error });
//         });
//     })
//     .catch(error => {
//       console.log(error, 'er2');
//       res.status(400).send({ message: error });
//     })

//     .catch(error => {
//       console.log(error, 'er3');
//       res.status(400).send({ message: error });
//     })
//     .catch(error => {
//       console.log(error, 'er4');
//       res.status(400).send({ message: error });
//     });
// };

// This code will work for CUP_Journals
export const updateJournalMaster = async (req, res) => {
  console.log('Update query payload', req.body);

  const { custList, prodList, tatList, updatedBy = '' } = req.body;

  const runontypeJSON =
    JSON.stringify(
      req.body && req.body.custList && req.body.custList.runontype,
    ) || null;

  const updateJournal = `
    UPDATE public.pp_mst_journal
    SET
      colorid=${custList.colours ? custList.colours : null},
      softwareid=${custList.softwares ? custList.softwares : null},
      languageid=${custList.languages ? custList.languages : null},
      celevelid=${custList.celevel ? custList.celevel : null},
      templateid=${custList.templatefile ? custList.templatefile : null},
      printissn='${custList.printissn ? custList.printissn : ''}',
      trimesizewidth=${custList.pagewidth ? custList.pagewidth : null},
      trimesizewidthuom='${
        custList.pagewidthunit ? custList.pagewidthunit : null
      }',
      trimesizeheight=${custList.pageheight ? custList.pageheight : null},
      trimesizeheightuom='${
        custList.pageheightunit ? custList.pageheightunit : null
      }',
      pmid='${custList.projectmanager ? custList.projectmanager : null}',
      supplierpmid='${
        custList.supplierprojectmanager ? custList.supplierprojectmanager : null
      }',
      onlineissn='${custList.onlineissn ? custList.onlineissn : null}',
      totalissuecount=${custList.totalissue ? custList.totalissue : null},
      budgetedcount=${custList.budgeted ? custList.budgeted : null},
      isopenaccessarticle=${
        custList.openarticle && custList.openarticle.toString().length > 0
          ? custList.openarticle
          : null
      },
      isactive=${
        custList.status && custList.status.toString().length > 0
          ? custList.status
          : null
      },
      isiauthor=${
        custList.isiauthor && custList.isiauthor.toString().length > 0
          ? custList.isiauthor
          : null
      },
      iauthworkflowid=${
        custList.iauthorworkflow && custList.isiauthor == true
          ? custList.iauthorworkflow
          : null
      },
      runon=${custList.runon && custList.runon ? custList.runon : false},
      runontype='${
        custList.runontype && custList.runontype ? runontypeJSON : null
      }',
      articletype='${
        custList.articletype && custList.articletype
          ? custList.articletype
          : null
      }',
      cover=${custList.cover && custList.cover ? custList.cover : false},
      textcolumnid=${custList.textcolumn ? custList.textcolumn : null},
      amoid=${custList.amo ? custList.amo : null},
      printprofileid=${custList.printprofile ? custList.printprofile : null},
      onlineprofileid=${custList.onlineprofile ? custList.onlineprofile : null},
      templateformat='${
        custList.templateformat ? custList.templateformat : null
      }',
      journaltype='${custList.journaltype ? custList.journaltype : null}',

      articletat=${custList.articletat ? custList.articletat : null},
      issuetat=${custList.issuetat ? custList.issuetat : null},
      category='${custList.category ? custList.category : null}',
      copyeditingworkflow=${
        custList.copyeditingworkflow ? custList.copyeditingworkflow : null
      },
      isnlp=${custList.isnlp ? custList.isnlp : false},
      referenceprofileid=${
        custList.referenceprofile ? custList.referenceprofile : null
      },
      pdfa2bprofileid=${custList.pdfprofile ? custList.pdfprofile : null},
      isembargo = '${custList.embargo || false}',
          embargodate = ${custList.jcDate ? `'${custList.jcDate}'` : null},
       ispreproof=${custList.ispreproof ? custList.ispreproof : false}  ,
       journal_cetype = '${
         custList.journal_cetype ? custList.journal_cetype : null
       }',
       jouupdatedby = '${updatedBy}',
       iauthorreviewworkflow=${
         custList.iauthorworkflowforbookreview && custList.isiauthor == true
           ? custList.iauthorworkflowforbookreview
           : null
       },
       jouupdatedon = CURRENT_TIMESTAMP
    WHERE 
      journalid=${custList.journalid}`;

  console.log('updateJournal', updateJournal);
  await query(updateJournal)
    .then(async _response => {
      console.log(_response, 'Update Response');
      const deleteNonArticle = `DELETE FROM public.pp_mst_journal_nonart_types WHERE journalid=${custList.journalid}`;

      await query(deleteNonArticle)
        .then(async _deletenonartical => {
          console.log(_deletenonartical, 'deletenonartical');
          custList.nonArticle.map(async nonarticleid => {
            const createNonArticle = `INSERT INTO public.pp_mst_journal_nonart_types(journalid, filetypeid) VALUES (${custList.journalid}, ${nonarticleid})`;
            await query(createNonArticle).then(async () => {});
          });

          const deleteProd = `DELETE FROM public.pp_mst_journal_contacts WHERE journalid=${custList.journalid};`;

          await query(deleteProd).then(async () => {
            let isPrimary;
            const val = [];
            const tempProdList = [];
            prodList.forEach(list => {
              if (list != null) {
                tempProdList.push(list);
              }
            });
            const baseJournalConId = await query(
              'select max(journalconid) as max_id from pp_mst_journal_contacts',
            );
            let currentJournalConId = baseJournalConId[0].max_id || 0;
            tempProdList.forEach(list => {
              isPrimary = list.editiorPrimary == true ? 1 : 0;
              currentJournalConId++;
              val.push(
                `(${currentJournalConId}, ${custList.journalid}, '${list.editiorName}', '${list.editiorEmail}', null, '${list.editiorPhone}', null, '${list.prodStatus}', ${isPrimary})`,
              );
            });

            const updateProd = `INSERT INTO public.pp_mst_journal_contacts(journalconid, journalid, name, email, address, phone1, phone2, designation, isprimary) VALUES ${val.join(
              ',',
            )} RETURNING journalconid`;

            await query(updateProd).then(async responsedu => {
              console.log('Response DU', responsedu);
            });

            if (tatList) {
              tatList.forEach(list => {
                list.customerid = custList.customer;
                list.journalid = custList.journalid;
                list.isactive = list.isactive != false;
              });
              const jsonparam = JSON.stringify(tatList);
              const createTatInfo = `select * from insertjournalduedays('${jsonparam}')`;
              await query(createTatInfo);
            }
          });

          res.status(200).json({
            data: 'Updated Successfully',
          });
        })
        .catch(error => {
          console.log(error, 'er1');
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      console.log(error, 'er2');
      res.status(400).send({ message: error });
    })
    .catch(error => {
      console.log(error, 'er3');
      res.status(400).send({ message: error });
    })
    .catch(error => {
      console.log(error, 'er4');
      res.status(400).send({ message: error });
    });
};

export const nonArticleList = (req, res) => {
  const { journalId } = req.body;
  const sql = `select nonart.filetypeid as value ,filetype.filetype as label from pp_mst_journal_nonart_types as nonart 
    join pp_mst_journal as journal on journal.journalid = nonart.journalid 
    join pp_mst_filetype as filetype on filetype.filetypeid = nonart.filetypeid
    where nonart.journalid = ${journalId}`;
  console.log(sql, 'nonarctiiilll');
  query(sql)
    .then(response => {
      console.log(response, 'ikkdsfkss');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getjournalduedays = (req, res) => {
  const { journalId, customerId } = req.body;
  const sql = `select * from getjournalduedays(${customerId},${journalId})`;
  console.log(sql, req.body, 'due');
  query(sql)
    .then(response => {
      console.log(response, 'ikkdsfkss');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJournalInstruction = (req, res) => {
  const { journalId, type, journalinstructionid } = req.body;
  let sql = '';
  if (type == 'list') {
    sql = ` SELECT 
    journalinstruction.journalinstructionid,journalinstruction.repofilepath,journalinstruction.repofileuuid
   FROM  pp_mst_journal journal 
   JOIN pp_mst_journal_instructions journalinstruction ON journalinstruction.journalid = journal.journalid
    where journal.journalid = ${journalId}`;
    console.log(sql, 'insertingfile');
  } else if (type == 'delete') {
    sql = `DELETE FROM public.pp_mst_journal_instructions WHERE journalinstructionid =${journalinstructionid}`;
  }
  console.log(sql, 'deletingfileeee');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJournalContact = (req, res) => {
  const { journalId } = req.body;
  const sql = ` SELECT  journalcontact.journalconid,journalcontact.name,journalcontact.email,journalcontact.phone1, journalcontact.designation,journalcontact.isprimary
   FROM  pp_mst_journal as journal 
   JOIN pp_mst_journal_contacts as journalcontact ON journalcontact.journalid = journal.journalid
    where journal.journalid = ${journalId} order by journalcontact.journalconid asc`;
  console.log(sql, 'gettingcontact');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getJournalAcroymn = (req, res) => {
  const { customerId, divsionId, subDivisionId, countryId, journalAcroymn } =
    req.body;
  const sql = `SELECT journal.journalacronym FROM public.org_mst_customer_orgmap  as custorg
    left join pp_mst_journal as journal on journal.custorgmapid = custorg.custorgmapid
    where custorg.customerid =${customerId || ''}  and custorg.divisionid =${
    divsionId || null
  } and custorg.subdivisionid =${
    subDivisionId || null
  } and custorg.countryid = ${
    countryId || null
  } and journal.journalacronym = '${journalAcroymn}'
    ORDER BY journal.journalid ASC `;
  console.log(sql, 'journalacronym');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeee');
      res.status(200).json({
        data: response.length,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Master tool and software start
// Get Master Option List or tool

export const getToolsCommonOptions = (req, res) => {
  const sql = `SELECT org_mst_deliveryunit.duid as value, org_mst_deliveryunit.duname as label FROM org_mst_deliveryunit order by value`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getDeliverUnitList = (req, res) => {
  const sql = `select duid as value, duname as label from  public.org_mst_deliveryunit where isactive=true order by value`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getcustomerconfigdetails = (req, res) => {
  const { customerId, type, value } = req.body;
  // const sql = `SELECT a.duid, a.duname, b.id,b.cloudserverpath,b.localserverpath,b.isspcopylocal,b.cloudfilereceivedpath,b.localfilereceivedpath,b.isrpcopylocal,b.servertoolpath,b.localtoolspath,b.cloudgraphicfilepath,b.localgraphicfilepath,b.isgpcopylocal,b.localworkingfolder,b.islock,b.createdon,b.duid as existingduid FROM org_mst_deliveryunit a left join wms_mst_customerconfigdetails b on a.duid=b.duid where a.duid=${customerId}`;
  let sql = `select * from wms_mst_customerconfigdetails  where customerid=${customerId} and islock=false`;
  query(sql)
    .then(data => {
      if (type === 'insert') {
        if (data.length > 0) {
          sql = `UPDATE public.wms_mst_customerconfigdetails
         SET cloudserverpath='${value.cloudserverpath}', localserverpath='${value.localserverpath}'
         , isspcopylocal=${value.isspcopylocal}, cloudfilereceivedpath='${value.cloudfilereceivedpath}'
         , localfilereceivedpath='${value.localfilereceivedpath}', isrpcopylocal=${value.isrpcopylocal}, servertoolpath='${value.servertoolpath}', localtoolspath='${value.localtoolspath}', istplocal=${value.istplocal}, cloudgraphicfilepath='${value.cloudgraphicfilepath}'
         , localgraphicfilepath='${value.localgraphicfilepath}', isgpcopylocal='${value.isgpcopylocal}'
         , localworkingfolder='${value.localworkingfolder}' WHERE customerid='${customerId}'`;
        } else {
          sql = `INSERT INTO public.wms_mst_customerconfigdetails(
          customerid, cloudserverpath, localserverpath, isspcopylocal, cloudfilereceivedpath
          , localfilereceivedpath, isrpcopylocal, servertoolpath, localtoolspath,istplocal, cloudgraphicfilepath
          , localgraphicfilepath, isgpcopylocal, localworkingfolder, islock, createdon)
         VALUES ('${customerId}', '${value.cloudserverpath}', '${value.localserverpath}', ${value.isspcopylocal}, '${value.cloudfilereceivedpath}', '${value.localfilereceivedpath}', ${value.isrpcopylocal}, '${value.servertoolpath}', '${value.localtoolspath}',${value.istplocal}, '${value.cloudgraphicfilepath}', '${value.localgraphicfilepath}', ${value.isgpcopylocal}, '${value.localworkingfolder}', false, CURRENT_TIMESTAMP)`;
        }
        query(sql)
          .then(data1 => {
            res.status(200).json({ data1, status: true });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(200).json({
          data,
          status: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({
        message: error,
        status: false,
        data: [],
      });
    });
};

export const getToolMasterOptions = (req, res) => {
  const getData = req.body;
  let sql = '';
  if (getData.type === 'toolmode') {
    sql = `	select toolmodeid as value,toolmode as label from pp_mst_toolmode`;
  } else if (getData.type === 'tooltype') {
    sql = `	select tooltypeid as value,tooltype as label from pp_mst_tooltype`;
  } else if (getData.type === 'toolsoutput') {
    sql = `SELECT tooloutputid as value,name as label  FROM public.pp_mst_tool_output ORDER BY tooloutputid ASC `;
  }
  console.log(sql, 'sqlforToolOption');
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const createnewTool = (req, res) => {
  const getData = req.body;

  console.log(getData, 'getData');
  console.log(getData.exevalue, 'exevalue');
  const checkSql = `select count(1) from pp_mst_tool where customerid=${getData.customername} and toolname='${getData.name}'`;
  query(checkSql)
    .then(checkData => {
      console.log('chckdata', checkData);
      if (!+checkData[0].count > 0) {
        const sql = `INSERT INTO public.pp_mst_tool(
            toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid)
           VALUES ('${getData.name}','${getData.description}', ${
          getData.tooltype
        }, ${getData.toolmode}, ${getData.status}, true,'${JSON.stringify(
          getData.payload,
        )}',${getData.toolsexecutiontype != '0'},${getData.toolsoutput},${
          getData.customername
        }) returning toolid;`;
        console.log(sql, 'sqlforTool');
        query(sql)
          .then(data => {
            // insertin customer
            res.status(200).json({
              data,
              message: 'tool inserted successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(400).send({
          data: 'Tool is already registered for selected customer',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const multipleInstance = payload => {
  return new Promise((resolve, reject) => {
    try {
      const { duId, woId, customerId, serviceId, currentStage, files } =
        payload;
      console.log(payload, 'payload');

      const val = [];
      const selectedFiles =
        customerId == 1 ? files.filter(list => list.isChecked) : files;
      selectedFiles.forEach(list => {
        val.push(`(${duId},'${woId}','${customerId}','${serviceId}',
                '${currentStage.id}', '${currentStage.iteration}',${list.id})`);
      });
      if (val != '' && val != undefined) {
        console.log(val, 'values for users');
        const sql = `INSERT INTO public.wms_workflow_stagetrn_file(duid, workorderid,customerid, serviceid, stageid, stageiterationcount, woincomingfileid)
             VALUES ${val} RETURNING stagetrnfileid`;

        query(sql)
          .then(data => {
            if (data.length) {
              resolve(true);
            }
          })
          .catch(error => {
            reject(error);
          });
      } else {
        resolve(true);
      }
    } catch (e) {
      console.log(e, 'mutlitple instance errro');
      reject(e);
    }
  });
};

export const deletemultipleInstanceTwo = (req, res) => {
  const getData = req.body;
  console.log(getData, 'getData');
  const checkSql = `DELETE FROM public.wms_workflow_stagetrn_file WHERE workorderid =${getData.workorderid} and customerid =${getData.customerid} and  serviceid =${getData.serviceid} and stageid =${getData.stageid} and stageiterationcount =${getData.stageiterationcount}`;
  console.log(checkSql, 'something');
  query(checkSql)
    .then(data => {
      console.log(data, 'FFFFFFFFFF');
      res.status(200).json({ data, message: 'Deleted', status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const createToolMaster = async (req, res) => {
  const {
    customername,
    name,
    description,
    tooltype,
    toolmode,
    status,
    payload,
    toolsexecutiontype,
    toolsoutput,
  } = req.body;

  const checkSql = `select count(1) from pp_mst_tool where customerid=${customername} and toolname='${name}'`;

  query(checkSql)
    .then(checkData => {
      const dataCount = +checkData[0].count;

      if (!dataCount > 0) {
        const sql = `INSERT INTO public.pp_mst_tool(
          toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid)
         VALUES ('${name}','${description}', ${tooltype}, ${toolmode}, ${status}, true,'${JSON.stringify(
          payload || {},
        )}',${
          toolsexecutiontype != '0'
        },${toolsoutput},${customername}) returning toolid;`;
        console.log(sql, 'sqlforTool');

        query(sql)
          .then(data => {
            res.status(200).json({
              data,
              message: 'tool inserted successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(400).send({
          data: 'Tool is already registered for selected customer',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

// export const createToolMaster = async (req, res) => {
//   if (req.body.tooltype == 2) {
//     createnewTool(req, res);
//   } else {
//     try {
//       const getData = JSON.parse(JSON.stringify(req.body));

//       const newCustomer =
//         getData.customername == 2
//           ? 'WKI'
//           : getData.customername == 3
//           ? 'Hodder'
//           : getData.customername == 4
//           ? 'SDU'
//           : getData.customername == 7
//           ? 'T&FPublisher'
//           : getData.customername == 1
//           ? 'CUP'
//           : getData.customername == 5
//           ? 'HodderEducation'
//           : getData.customername == 6
//           ? 'EmeraldPublishing'
//           : '';

//       const turl = 'http://172.18.5.46:8000/api/common/addUpdateTool';
//       const reqData = {
//         toolName: getData.name,
//         toolType: getData.toolsexecutiontype == '0' ? 'sync' : 'async',
//         processType: 'object',
//         customer: newCustomer,

//         toolId: 0,
//         isLock: 'n',
//       };

//       const options = {
//         method: 'POST',
//         httpAgent: new http.Agent({ keepAlive: true }),
//         headers: {
//           'Access-Control-Allow-Origin': true,
//           'Content-Type': 'application/json',
//           Accept: 'application/json',
//         },
//         data: reqData,
//         url: turl,
//       };
//       callAddTool(options, getData).then(result => {
//         if (result) {
//           res.status(200).send(result);
//         }
//         // console.log("res",res)
//       });
//     } catch (err) {
//       console.log(err, 'createtool');
//     }
//   }
// };

// const callAddTool = async (options, getData) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       console.log('reinn');

//       axios(options).then(async response => {
//         console.log('reas', response);
//         const datanew = response.data;

//         if (datanew.is_success) {
//           const output = await createToolMaster1(getData, datanew);
//           resolve(output);
//           // console.log("res",output)
//         }
//       });
//     } catch (err) {
//       console.log('callAddTool', err);
//       reject({
//         status: false,
//         message: err.response ? err.response : err.message,
//       });
//     }
//   });
// };

// export const createToolMaster1 = async (getData, datanew, res) => {
//   return new Promise(async resolve => {
//     const toolrefid = String(datanew.data);
//     const customer = String(getData.customername);

//     const checkSql = `select count(1) from pp_mst_tool where customerid=${customer} and toolname='${getData.name}'`;
//     query(checkSql)
//       .then(checkData => {
//         console.log('chckdata', checkData);
//         if (!+checkData[0].count > 0) {
//           const sql = `INSERT INTO public.pp_mst_tool(
//             toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid,toolrefid)
//            VALUES ('${getData.name}','${getData.description}', ${
//             getData.tooltype
//           }, ${getData.toolmode}, ${getData.status}, true,'${JSON.stringify(
//             getData.payload,
//           )}',${getData.toolsexecutiontype != '0'},${
//             getData.toolsoutput
//           },${customer},${toolrefid}) returning toolid;`;
//           console.log(sql, 'sqlforTool');
//           query(sql)
//             .then(data => {
//               // insertin customer
//               resolve({
//                 data,
//                 message: 'tool inserted successfully',
//                 status: true,
//               });
//             })
//             .catch(error => {
//               res.status(400).send({ message: error, status: false, data: [] });
//             });
//         } else {
//           resolve({
//             data: 'Tool is already registered for selected customer',
//             status: false,
//           });
//         }
//       })
//       .catch(error => {
//         return { message: error, status: false, data: [] };
//       });
//   });
// };

export const createComposingSoftwareMaster = (req, res) => {
  const getData = req.body;
  console.log(getData, 'getData');
  const checkSql = `select count(1) from wms_mst_software where customerid=${getData.customername} and appname='${getData.name}'`;
  query(checkSql)
    .then(checkData => {
      console.log('chckdata', checkData);
      if (!+checkData[0].count > 0) {
        const sql = `INSERT INTO public.wms_mst_software(
                appname, apptype, appurlpath, appdescription, isactive, version, owner, displayname, appicon, customerid)
           VALUES ('${getData.name}','${getData.fileParameter}','${getData.softwareParameter}','${getData.description}','${getData.status}', null,null, '${getData.displayname}', '${getData.appicon}',${getData.customername}) returning appid;`;
        console.log(sql, 'sqlforSoft');
        query(sql)
          .then(data => {
            // insertin customer
            res.status(200).json({
              data,
              message: 'Software inserted successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(400).send({
          data: 'Software is already registered for selected customer',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const getToolMaster = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      console.log(reqData.filter, 'filterrrrrrrr');
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%'`;
    });

    console.log(condition, 'connnnnnnnnnnnnnnnnn');
  }
  sql = `select count(1) from pp_mst_tool where 1=1 ${
    condition ? `AND${condition}` : condition
  } `;
  console.log(sql, 'getToolMaster');
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        // sql = `select * from wms_tools_software_table where 1=1 ${
        //   condition ? `AND${condition}` : condition
        // } ORDER BY toolid DESC`;
        sql = `select a.toolid, a.toolname,a.tooldescription,a.toolstatus,a.istoolverified,a.payload,a.toolmodeid,a.tooloutputid
          ,a.isasync,a.toolrefid,a.isword,e.duname,b.toolmode,c.tooltype,d.name,a.tooltypeid,a.customerid from pp_mst_tool a
          join pp_mst_toolmode b on b.toolmodeid=a.toolmodeid
          join pp_mst_tooltype c on c.tooltypeid=a.tooltypeid
          join pp_mst_tool_output d on d.tooloutputid=a.tooloutputid
          left join org_mst_deliveryunit e on a.customerid=e.duid order by a.toolname`;
        query(sql)
          .then(getToolData => {
            res.status(200).json({
              data: {
                data: getToolData,
              },
              Success: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, Success: false, data: [] });
          });
      } else {
        res.status(200).json({
          data: { data: [] },
          message: 'No data found',
          Success: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, Success: false, data: [] });
    });
};
export const getSoftwareMaster = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      console.log(reqData.filter, 'filterrrrrrrr');
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%'`;
    });

    console.log(condition, 'connnnnnnnnnnnnnnnnn');
  }

  // sql = `select * from wms_tools_software_table where 1=1 ${
  //   condition ? `AND${condition}` : condition
  // } ORDER BY toolid DESC`;
  sql = `select a.appid,a.appname,a.apptype,a.appurlpath,a.appdescription,a.isactive,a.version
          ,a.owner,a.displayname,a.appicon,a.customerid,a.softrefid,a.softtypeid,e.duname from wms_mst_software a
          left join org_mst_deliveryunit e on a.customerid=e.duid order by a.appname`;
  query(sql)
    .then(getToolData => {
      if (getToolData.length > 0) {
        res.status(200).json({
          data: {
            data: getToolData,
          },
          Success: true,
        });
      } else {
        res.status(200).json({
          data: { data: [] },
          message: 'No data found',
          Success: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, Success: false, data: [] });
    });
};
export const deletenewTool = (req, res) => {
  const getData = req.body;

  console.log(getData, 'getDataaaaaaa');

  let sql = `DELETE FROM pp_mst_tool WHERE toolid=${getData.toolId};`;
  if (getData.tooltype != 'tool') {
    sql = `DELETE FROM wms_mst_software WHERE appid=${getData.toolId};`;
  }
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Tool deleted sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const deleteToolMaster = (req, res) => {
  deletenewTool(req, res);
};

// export const createDeleteMaster1 = (req, res) => {
//     let getData = req.body

//     console.log(getData, 'getDataaaaaaa')

//     let sql = `DELETE FROM pp_mst_tool WHERE toolid=${getData.toolId};`
//     query(sql).then((data) => {
//         res.status(200).json({ data: data, message: "Tool deleted sucessfully", status: true });
//     }).catch((error) => {
//         res.status(400).send({ message: error, status: false, );data: [] }
//      });
//     }

export const createDeleteMaster1 = getData => {
  return new Promise(async resolve => {
    const sql = `DELETE FROM pp_mst_tool WHERE toolid=${getData.toolId};`;
    query(sql)
      .then(data => {
        resolve({
          data,
          message: 'Tool deleted sucessfully',
          status: true,
        });
      })
      .catch(error => {
        resolve({ message: error, status: false, data: [] });
      });
  }).catch(err => {
    console.log(err, 'errr');
  });
};

// export const createToolMaster1 = async (getData, datanew, res) => {
//     return new Promise(async (resolve, reject) => {

//         let toolrefid = String(datanew.data);
//         let customer = String(getData.customername);

//         let checkSql = `select count(1) from pp_mst_tool where customerid=${customer} and toolname='${getData.name}'`
//         query(checkSql).then((checkData) => {
//             console.log("chckdata", checkData)
//             if (! +checkData[0].count > 0) {
//                 let sql = `INSERT INTO public.pp_mst_tool(
//             toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid,toolrefid)
//            VALUES ('${getData.name}','${getData.description}', ${getData.tooltype}, ${getData.toolmode}, ${getData.status}, true,'${JSON.stringify(getData.payload)}',${getData.toolsexecutiontype == '0' ? false : true},${getData.toolsoutput},${customer},${toolrefid}) returning toolid;`
//                 console.log(sql, "sqlforTool")
//                 query(sql).then((data) => {
//                     //insertin customer
//                     resolve({ data: data, message: "tool inserted successfully", status: true }
//                     )
//                 }).catch((error) => {
//                     res.status(400).send({ message: error, status: false, data: [] });
//                 });
//             } else {
//                 resolve({ data: "Tool is already registered for selected customer", status: false })
//             }
//         }).catch((error) => {
//             return { message: error, status: false, data: [] };
//         });
//     })
// }

export const deleteSoftwareMaster = (req, res) => {
  const getData = req.body;

  console.log(getData, 'Dataaaaaaa software');

  const sql = `DELETE FROM wms_mst_software WHERE appid=${getData.appId};`;
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Software deleted sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const stageActivityDetails = (req, res) => {
  const reqData = req.body;
  console.log('reqqq', reqData);

  let sql = '';

  sql = `select a.activityname,b.stagename,c.config from wms_workflowdefinition c join wms_mst_activity a ON a.activityid=c.activityid
    join wms_mst_stage b ON  b.stageid= c.stageid and C.wfid =${parseInt(
      reqData.wfid,
    )}`;

  query(sql, [])
    .then(response => {
      const toolsDetails = [];
      for (let i = 0; i < response.length; i++) {
        const toolsIdArr =
          response[i].config &&
          response[i].config.toolsId &&
          response[i].config.toolsId instanceof Array
            ? response[i].config.toolsId
            : [];
        console.log('toolsIdArr', toolsIdArr);
        if (
          toolsIdArr.length > 0 &&
          toolsIdArr.includes(parseInt(reqData.toolsId))
        ) {
          toolsDetails.push({
            activity: response[i].activityname,
            stage: response[i].stagename,
          });
        }
      }
      console.log('toolsDetails', toolsDetails);
      res.status(200).json({ data: toolsDetails });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const wipActivityDetails = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
  }

  sql = `select count(0) from getwipenginestatus(${parseInt(
    reqData.wfid,
  )},${parseInt(reqData.activitystatus)}) ${
    condition ? `WHERE${condition}` : condition
  }`;

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `select * from getwipenginestatus(${parseInt(
          reqData.wfid,
        )},${parseInt(reqData.activitystatus)}) ${
          condition ? `WHERE${condition}` : condition
        } LIMIT ${recordPerPage} OFFSET ${offset}`;

        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const retriggerActivity = async (req, res) => {
  let fileid = '';
  const {
    workorderid,
    wfdefid,
    woincomingfileid,
    stageiterationcount,
    activityiterationcount,
    // wfeventid,
  } = req.body;
  try {
    // let fileid = woincomingfileid == null? 0 : woincomingfileid;
    const sql1 = `Select instancetype from wms_workflowdefinition where wfdefid=${wfdefid}`;
    const instancetype = await query(sql1);
    if (instancetype[0].instancetype == 'Single') {
      fileid = 0;
    } else {
      const sql2 = `Select filetypeid from public.wms_workorder_incomingfiledetails where woincomingfileid in (${woincomingfileid})`;
      const chapter = await query(sql2);
      fileid = chapter[0].filetypeid == 1 ? 0 : woincomingfileid;
    }
    const sql = ` Select * from retriggeractivity ( $1 ,$2 , $3 ,$4,$5)`;
    const eventdata = await query(sql, [
      workorderid,
      wfdefid,
      fileid,
      stageiterationcount,
      activityiterationcount,
    ]);
    if (
      eventdata &&
      eventdata.length > 0 &&
      eventdata[0].retriggeractivity != null
    ) {
      await sendToTaskQueue(eventdata[0].retriggeractivity);
    }
    res.status(200).send('Data triggered sucessfully');
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const workorderlock = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });

    sql = `SELECT COUNT(*) FROM wms_workorder ${
      condition ? `WHERE${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM wms_workorder ${
      condition ? `WHERE${condition}` : condition
    }`;
  }

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `SELECT * FROM wms_workorder ${
          condition ? `WHERE${condition}` : condition
        }  ORDER BY 1 DESC LIMIT ${recordPerPage} OFFSET ${offset}`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const softstageActivityDetails = (req, res) => {
  const reqData = req.body;
  console.log('reqqq', reqData);

  let sql = '';

  sql = `select a.activityname,b.stagename,c.config from wms_workflowdefinition c join wms_mst_activity a ON a.activityid=c.activityid
    join wms_mst_stage b ON  b.stageid= c.stageid and C.wfid =${parseInt(
      reqData.wfid,
    )}`;

  query(sql, [])
    .then(response => {
      const softwareDetails = [];
      for (let i = 0; i < response.length; i++) {
        const softwareIdArr =
          response[i].config &&
          response[i].config.softwareId &&
          response[i].config.softwareId instanceof Array
            ? response[i].config.softwareId
            : [];
        console.log('softwareIdArr', softwareIdArr);
        if (
          softwareIdArr.length > 0 &&
          softwareIdArr.includes(parseInt(reqData.softId))
        ) {
          softwareDetails.push({
            activity: response[i].activityname,
            stage: response[i].stagename,
          });
        }
      }
      console.log('toolsDetails', softwareDetails);
      res.status(200).json({ data: softwareDetails });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWfidOptions = (req, res) => {
  const sql = `select wfid as id,wfname as text from wms_workflow`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getToolidOptions = (req, res) => {
  const sql = `select toolid as id,toolname as text from pp_mst_tool where toolstatus=true`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getSoftwareidOptions = (req, res) => {
  const sql = `select appid as id,appname as text from wms_mst_software where isactive=true`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getToolById = (req, res) => {
  const { toolId } = req.body;
  console.log(toolId, 'tooliddd');
  const sql = `select toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, 
    tooloutputid,customerid from pp_mst_tool where toolid =${toolId}`;
  console.log(sql, 'journalacronym');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeee');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getSoftwareById = (req, res) => {
  const { appId } = req.body;
  console.log(appId, 'appp');
  const sql = `select apptype,appurlpath,appicon,displayname,isactive from wms_mst_software where appid=${appId}`;
  console.log(sql, 'softtttt');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeeesoft');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getLocalToolsPath = (req, res) => {
  const { duId } = req.body;
  const sql = `select * from public.wms_mst_customerconfigdetails where duid=${duId}`;

  query(sql)
    .then(response => {
      res.status(200).json({
        data: response[0],
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updatenewTool = (req, res) => {
  const getData = req.body;

  console.log(getData, 'getDataaaaaaaup');

  const sql = `UPDATE pp_mst_tool SET   
    toolname='${getData.name}', tooldescription='${
    getData.description
  }', toolmodeid='${getData.toolmode}', toolstatus=${
    getData.status
  }, tooltypeid = ${getData.tooltype},
    payload='${JSON.stringify(
      getData.payload,
    )}',istoolverified=${true}, isasync =${
    getData.toolsexecutiontype != '0'
  }, tooloutputid =${getData.toolsoutput}
    WHERE toolid=${getData.toolId};`;

  console.log(sql, 'sqltool');

  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Tool updated sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const updateToolById = async (req, res) => {
  const {
    name,
    description,
    toolmode,
    status,
    tooltype,
    payload,
    toolsexecutiontype,
    toolsoutput,
    toolId,
  } = req.body;

  const payloadString = payload ? JSON.stringify(payload) : null;

  const sql = `UPDATE pp_mst_tool SET   
    toolname='${name}', tooldescription='${description}', toolmodeid='${toolmode}', toolstatus=${status}, tooltypeid = ${tooltype},
    payload='${payloadString}', istoolverified=${true}, isasync=${
    toolsexecutiontype != '0'
  }, tooloutputid=${toolsoutput}
    WHERE toolid=${toolId};`;

  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Tool updated successfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const updateToolById1 = (getData, res) => {
  return new Promise(async resolve => {
    const sql = `UPDATE pp_mst_tool SET   
        toolname='${getData.name}', tooldescription='${
      getData.description
    }', toolmodeid='${getData.toolmode}', toolstatus=${
      getData.status
    }, tooltypeid = ${getData.tooltype},
        payload='${JSON.stringify(
          getData.payload,
        )}',istoolverified=${true}, isasync =${
      getData.toolsexecutiontype != '0'
    }, tooloutputid =${getData.toolsoutput}
        WHERE toolid=${getData.toolId};`;

    console.log(sql, 'sqltool');

    query(sql)
      .then(data => {
        resolve({
          data,
          message: 'Tool updated sucessfully',
          status: true,
        });
      })
      .catch(error => {
        res.status(400).send({ message: error, status: false, data: [] });
      });
  });
};

export const updateSoftwareById = (req, res) => {
  const {
    name,
    fileParameter,
    softwareParameter,
    description,
    displayname,
    appicon,
    customername,
    appId,
    status,
  } = req.body;

  const sql = `UPDATE wms_mst_software SET   
    appname='${name}', apptype='${fileParameter}', appurlpath='${softwareParameter}',appdescription='${description}',displayname = '${displayname}', isactive = '${status}',
    appicon ='${appicon}', customerid =${customername}
    WHERE appid=${appId};`;

  console.log(sql, 'sqltool');

  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Software updated sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getToolstPlaceholderField = (req, res) => {
  const fields = getPlaceHolderFields();
  res.send(fields);
};

// Configuration ftp start

export const getFtpList = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });

    sql = `SELECT COUNT(*) FROM wms_ft_transaction_table ${
      condition ? `WHERE${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM wms_ft_transaction_table ${
      condition ? `WHERE${condition}` : condition
    }`;
  }

  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `SELECT * FROM wms_ft_transaction_table ${
          condition ? `WHERE${condition}` : condition
        }  ORDER BY trid DESC LIMIT ${recordPerPage} OFFSET ${offset}`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Configuration ftp end

// Library Report Start
export const getTemplateById = (req, res) => {
  const { id } = req.body;

  const sql = `SELECT cus.customername,cus.customerid,tem.templatetypeid,tem.isactive,tem.libraryname,du.duname,du.duid,t.templateid,t.templatename,sw.softwarename,sw.softwareid,tt.libraryname,concat(us.username , ' (', us.userid, ')') as username,t.uploadeddate,t.templateuuid,t.templatefilepath,case when t.isactive = TRUE then 1 else 0 end as isactive	
    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby	
     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid	
	 join public.org_mst_deliveryunit as du on du.duid = t.duid 	
	 join public.wms_mst_template_type as tem on tem.templatetypeid = t.templatetypeid	
	 join public.org_mst_customer as cus on cus.customerid =t.composingswid where templateid=${id}`;
  console.log(sql, 'journalacronym');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeee');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const addTempDetails = (req, res) => {
  const { path, uuid, datas, type } = req.body;
  const status = datas.status == '1';

  if (type == 'add') {
    const sql = `INSERT INTO public.wms_mst_composingsw_templates(templatename, composingswid, duid, customerid, uploadedby, uploadeddate,isactive, templateuuid,templatefilepath,isdelete,templatetypeid,filename)
            VALUES('${datas.templatename}', ${datas.softwareId}, ${datas.duID}, ${datas.customerId},'${datas.profile}',CURRENT_DATE,'${status}',
            '${uuid}','${path}',false, ${datas.libraryId},'${datas.uploadingFileName}') returning templateid;`;
    console.log(sql, 'newwww');
    query(sql)
      .then(data => {
        res.status(200).json({
          data,
          message: 'Template Uploaded Successfully',
          status: true,
        });
      })
      .catch(error => {
        console.log(error, 'eeeee');
        res.status(400).send({ message: error, status: false, data: [] });
      });
  } else {
    const sql1 = `UPDATE public.wms_mst_composingsw_templates SET  isactive='${status}'
         WHERE templateid='${datas.templateid}'`;
    query(sql1)
      .then(data => {
        const sql2 = `INSERT INTO public.wms_mst_composingsw_templates(templatename, composingswid, duid, customerid, uploadedby, uploadeddate,isactive, templateuuid,templatefilepath,isdelete,templatetypeid,filename)
            VALUES('${datas.templatename}', ${datas.softwareId}, ${datas.duID}, ${datas.customerId},'${datas.profile}',CURRENT_DATE,'${status}',
            '${uuid}','${path}',false, ${datas.libraryId},'${datas.uploadingFileName}') returning templateid;`;

        query(sql2)
          .then(response => {
            console.log(response, 'responseeeee');
            res.status(200).json({
              data,
              message: 'Template Updated Successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        console.log(error, 'eeeee');
        res.status(400).send({ message: error, status: false, data: [] });
      });
  }
};

export const getFileInfo = async (req, res) => {
  const { path } = req.body;
  try {
    const fileExistDetails = await _isFileExist(path);

    res.send(fileExistDetails);
  } catch (err) {
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const getTemplateCommonOptions = (req, res) => {
  const getData = req.body;
  let sql = '';
  if (getData.type === 'du') {
    sql = `	select duid as value,duname as label from org_mst_deliveryunit`;
  } else if (getData.type === 'customername') {
    sql = `	select customerid as value,customername as label from org_mst_customer`;
  } else if (getData.type === 'library') {
    sql = `select templatetypeid as value,libraryname as label from wms_mst_template_type `;
  } else if (getData.type === 'software') {
    sql = `select softwareid as value,softwarename as label from pp_mst_composingsoftware `;
  }
  console.log(sql, 'sqlforToolOption');
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
// Library Report End

export const checkJobNormCombination = (req, res) => {
  const {
    customer,
    division,
    du,
    service: ser,
    subdivision,
    workflow,
    softwares,
    inputfiletype,
  } = req.body;
  const sql = `select count(1) from public.wms_mst_jobnorms where divisionid=${division} 
    and subdivisionid=${subdivision} and duid=${du} and customerid=${customer} and serviceid=${ser} and wfid=${workflow} and softwareid=${softwares} and filetypeid=${inputfiletype}`;
  console.log('sql', sql);
  query(sql)
    .then(normCount => {
      console.log('normCount', normCount);
      if (+normCount[0].count === 0) {
        res.status(200).json({
          data: 'Combination is not present',
          status: true,
        });
      } else {
        res.status(200).json({
          data: 'Job Norms is already mapped for this combination',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const createNormMaster = (req, res) => {
  const {
    category,
    customer,
    division,
    du,
    inputfiletype,
    normname,
    service: ser,
    softwares,
    subdivision,
    workflow,
    createdBy,
    getData,
    stageiterationpercent,
    activityiterationpercent,
    duration,
    effectiveDate,
  } = req.body;
  let sql = `select count(1) from public.wms_mst_jobnorms where divisionid=${division} and subdivisionid=${subdivision} 
    and duid=${du} and customerid=${customer} and serviceid=${ser} and wfid=${workflow}  and softwareid=${softwares} and filetypeid=${inputfiletype}`;
  query(sql)
    .then(normCount => {
      if (+normCount[0].count === 0) {
        sql = `INSERT INTO public.wms_mst_jobnorms(
         jobnormsname, divisionid, subdivisionid, customerid, duid, softwareid, categoryid, 
        filetypeid, serviceid, wfid,
        createdby, createdon, updatedby, updatedon,stageiterationpercent,activityiterationpercent,duration,effectivedate)
        VALUES ('${normname}', ${division},  ${subdivision},  ${customer}, ${du}, ${softwares}, ${category},
         ${inputfiletype}, ${ser}, ${workflow}, '${createdBy}', current_timestamp, '${createdBy}', current_timestamp,${
          stageiterationpercent || null
        },${
          activityiterationpercent || null
        },'${duration}','${effectiveDate}') RETURNING *;`;
        console.log(sql, 'Inserting Norm Master');
        query(sql)
          .then(response => {
            const val = [];
            getData.forEach(data => {
              val.push(
                `(${response[0].jobnormsid},${data.service},${data.stage},${
                  data.activity
                },${data.complexity},${data.quantity ? data.quantity : null},${
                  data.unit ? data.unit : null
                },${data.skill},${data.skillvalue ? data.skillvalue : null})`,
              );
            });
            sql = `	INSERT INTO public.wms_mst_jobnorms_details_map(
            jobnormsid, serviceid,
           stageid, activityid, complexityid, quantity, uomid, skilllevelid, skillquantity)
           VALUES ${val}`;
            console.log(sql, 'Inserting Norm Detail');
            query(sql)
              .then(resp => {
                res.status(200).json({
                  data: resp,
                  status: true,
                });
              })
              .catch(error => {
                res
                  .status(400)
                  .send({ message: error, status: false, data: [] });
              });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(200).json({
          data: 'Job Norms is already mapped for this combination',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getNormMaster = (req, res) => {
  let sql = '';
  sql = `select count(1) from (select division.division as division,
        subdivision.subdivision as subdivision,
        du.duname as du,
        cust.customername as customer,
        software.softwarename as software,
        category.category as category,
        workflow.wfname as workflow,
        filetype.filetypename as inputfiletype,
        jobnorms.* from wms_mst_jobnorms jobnorms 
        join org_mst_division  division on division.divisionid = jobnorms.divisionid
        join org_mst_subdivision subdivision on subdivision.subdivisionid=jobnorms.subdivisionid
        join org_mst_deliveryunit du on du.duid=jobnorms.duid
        join org_mst_customer cust on cust.customerid=jobnorms.customerid
        join pp_mst_composingsoftware software on software.softwareid=jobnorms.softwareid
        join pp_mst_wocategory  category on category.categoryid=jobnorms.categoryid
        join wms_workflow workflow on workflow.wfid=jobnorms.wfid
        join pp_mst_inputfiletype filetype on filetype.filetypeid=jobnorms.filetypeid
        )as table1 where 1=1`;
  console.log(sql, 'getNormMaster');
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        sql = `select * from (select division.division as division,
                subdivision.subdivision as subdivision,
                du.duname as du,
                cust.customername as customer,
                software.softwarename as software,
                category.category as category,
                workflow.wfname as workflow,
                filetype.filetypename as inputfiletype,
                jobnorms.* from wms_mst_jobnorms jobnorms 
                join org_mst_division  division on division.divisionid = jobnorms.divisionid
                join org_mst_subdivision subdivision on subdivision.subdivisionid=jobnorms.subdivisionid
                join org_mst_deliveryunit du on du.duid=jobnorms.duid
                join org_mst_customer cust on cust.customerid=jobnorms.customerid
                join pp_mst_composingsoftware software on software.softwareid=jobnorms.softwareid
                join pp_mst_wocategory  category on category.categoryid=jobnorms.categoryid
                join wms_workflow workflow on workflow.wfid=jobnorms.wfid
                join pp_mst_inputfiletype filetype on filetype.filetypeid=jobnorms.filetypeid
                ) as table1 where 1=1  ORDER BY jobnormsid DESC`;
        query(sql)
          .then(getNormData => {
            res.status(200).json({
              data: {
                data: getNormData,
              },
              Success: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, Success: false, data: [] });
          });
      } else {
        res.status(200).json({
          data: { data: [] },
          message: 'No data found',
          Success: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, Success: false, data: [] });
    });
};
export const updateNorms = (req, res) => {
  const {
    category,
    customer,
    division,
    du,
    inputfiletype,
    normname,
    service: ser,
    softwares,
    subdivision,
    workflow,
    createdBy,
    getData,
    normId,
    stageiterationpercent,
    activityiterationpercent,
    duration,
    effectiveDate,
  } = req.body;
  let sql = `UPDATE public.wms_mst_jobnorms
	SET  jobnormsname='${normname}', divisionid=${division}, subdivisionid=${subdivision}, customerid=${customer}, 
	duid=${du}, softwareid=${softwares}, categoryid=${category}, filetypeid=${inputfiletype}, serviceid=${ser}, wfid=${workflow},
	 updatedby='${createdBy}',stageiterationpercent=${stageiterationpercent},activityiterationpercent=${activityiterationpercent},duration='${duration}',effectivedate='${effectiveDate}', updatedon=current_timestamp
	WHERE jobnormsid=${normId};`;
  query(sql)
    .then(() => {
      sql = `DELETE FROM public.wms_mst_jobnorms_details_map WHERE jobnormsid=${normId}`;
      query(sql)
        .then(() => {
          const val = [];
          getData.forEach(data => {
            val.push(
              `(${normId},${data.service},${data.stage},${data.activity},${
                data.complexity
              },${data.quantity ? data.quantity : null},${
                data.unit ? data.unit : null
              },${data.skill},${data.skillvalue ? data.skillvalue : null})`,
            );
          });
          sql = `INSERT INTO public.wms_mst_jobnorms_details_map(
        jobnormsid, serviceid,
       stageid, activityid, complexityid, quantity, uomid, skilllevelid, skillquantity)
       VALUES ${val}`;
          console.log(sql, 'Inserting Norm Detail');
          query(sql)
            .then(response => {
              res.status(200).json({ data: response, status: true });
            })
            .catch(error => {
              res.status(400).send({ message: error, status: false, data: [] });
            });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const getNormById = async (req, res) => {
  const reqData = req.body;
  let sql = `select division.division as division,subdivision.subdivision as subdivision,du.duname as du,cust.customername as customer,software.softwarename as software,
    category.category as category,workflow.wfname as workflow,filetype.filetypename as inputfilename,jobnorms.* from wms_mst_jobnorms jobnorms join org_mst_division  division on division.divisionid = jobnorms.divisionid join org_mst_subdivision subdivision on subdivision.subdivisionid=jobnorms.subdivisionid
    join org_mst_deliveryunit du on du.duid=jobnorms.duid join org_mst_customer cust on cust.customerid=jobnorms.customerid join pp_mst_composingsoftware software on software.softwareid=jobnorms.softwareid join pp_mst_wocategory  category on category.categoryid=jobnorms.categoryid
    join wms_workflow workflow on workflow.wfid=jobnorms.wfid join pp_mst_inputfiletype filetype on 
    filetype.filetypeid=jobnorms.filetypeid where jobnorms.jobnormsid=${reqData.normsId}`;
  console.log(sql, 'get Norm From ID');
  await query(sql)
    .then(async response => {
      sql = `select distinct on(complexity.complexityid,details.skilllevelid) complexity.complexityid,details.skilllevelid,complexity.complexity,skill.skilllevel
        from wms_mst_jobnorms_details_map details 
        join wms_mst_complexity complexity on details.complexityid=complexity.complexityid
        join wms_mst_skilllevel skill on skill.skilllevelid=details.skilllevelid
        where jobnormsid=${reqData.normsId}`;
      await query(sql).then(async complexSkill => {
        console.log(complexSkill);
        let complex = complexSkill.map(compSk => {
          return {
            label: compSk.complexity,
            value: compSk.complexityid,
          };
        });
        complex = Array.from(new Set(complex.map(JSON.stringify))).map(
          JSON.parse,
        );
        let skill = complexSkill.map(compSk => {
          return {
            label: compSk.skilllevel,
            value: compSk.skilllevelid,
          };
        });
        skill = Array.from(new Set(skill.map(JSON.stringify))).map(JSON.parse);
        sql = `	select * from wms_mst_jobnorms_details_map where jobnormsid=${reqData.normsId} order by jobnormsdetailid`;
        await query(sql)
          .then(async detail => {
            res.status(200).json({
              data: {
                normsData: response[0],
                complexity: complex,
                skill,
                detailData: detail,
              },
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const deleteNormMaster = async (req, res) => {
  const reqData = req.body;
  let sql = `DELETE FROM public.wms_mst_jobnorms_details_map WHERE jobnormsid=${reqData.normsId}`;
  await query(sql)
    .then(async () => {
      sql = `DELETE FROM public.wms_mst_jobnorms WHERE jobnormsid=${reqData.normsId}`;
      await query(sql)
        .then(async response => {
          res.status(200).send({ status: true, data: response });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getNotificationsOptionList = (req, res) => {
  const getData = req.body;
  let sql = ``;
  if (getData.type === 'du') {
    sql = `SELECT duid as value, duname as label from org_mst_deliveryunit`;
  } else if (getData.type === 'division') {
    sql = `
            SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label FROM org_mst_customer_orgmap  
            JOIN org_mst_division ON org_mst_customer_orgmap.divisionid = org_mst_division.divisionid
			JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE duid = ${getData.duId} `;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap  
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} AND duid = ${getData.duId}`;
  } else if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label,org_mst_customer_orgmap.custorgmapid FROM org_mst_customer_orgmap  
            JOIN org_mst_customer ON org_mst_customer_orgmap.customerid = org_mst_customer.customerid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} AND duid = ${getData.duId} AND org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId}`;
  } else if (getData.type === 'service') {
    sql = `SELECT  DISTINCT ON (service.serviceid)  service.serviceid as value, service.servicename as label FROM public.org_mst_customer_orgmap as custmap
                JOIN public.org_mst_customerorg_service_map as custservice ON custservice.custorgmapid = custmap.custorgmapid
                JOIN public.wms_mst_service as service ON service.serviceid = custservice.serviceid
                JOIN org_mst_customerorg_du_map as dumap ON dumap.custorgmapid = custmap.custorgmapid 
                WHERE  custmap.customerid=${getData.customerId} AND custmap.divisionid=${getData.divisionId} 
                AND custmap.subdivisionid=${getData.subDivisionId} AND dumap.duid = ${getData.duId}  `;
  } else if (getData.type === 'workflow') {
    sql = `SELECT DISTINCT ON(workflow.wfid) workflow.wfid as value, workflow.wfname as label, def.wfid
            FROM public.wms_workflow as workflow
            left join wms_workflowdefinition as def on def.wfid = workflow.wfid
            WHERE workflow.isactive = true AND  workflow.customerid = ${getData.customerId}
            ORDER BY workflow.wfid ASC`;
  } else if (getData.type === 'journal') {
    sql = `SELECT DISTINCT ON(journal.journalid) journal.journalid as value, journal.journalacronym as label FROM pp_mst_journal as journal
    WHERE journal.custorgmapid = ${getData.customerOrgId}
    ORDER BY journal.journalid ASC`;
  }
  console.log(sql, 'sql for optionsj');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getChecklistOptionList = (req, res) => {
  const getData = req.body;
  let sql = ``;
  if (getData.type === 'du') {
    sql = `SELECT DISTINCT ON (org_mst_deliveryunit.duid) org_mst_deliveryunit.duid as value, 
		org_mst_deliveryunit.duname as label FROM org_mst_customer_orgmap 
			JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
			 JOIN org_mst_deliveryunit ON org_mst_customerorg_du_map.duid = org_mst_deliveryunit.duid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} and
            org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId}  
            and  org_mst_deliveryunit.isactive=true order by org_mst_deliveryunit.duid`;
  } else if (getData.type === 'division') {
    sql = `
        SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value,org_mst_division.division as label
        from org_mst_division
        WHERE org_mst_division.isactive=true order by org_mst_division.divisionid`;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap  
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId}  and org_mst_subdivision.isactive=true`;
  } else if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label,org_mst_customer_orgmap.custorgmapid as custorgid FROM org_mst_customer_orgmap  
            JOIN org_mst_customer ON org_mst_customer_orgmap.customerid = org_mst_customer.customerid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId}  AND 
            org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId} and org_mst_customerorg_du_map.duid=${getData.duId}  and org_mst_customer.isactive=true`;
  } else if (getData.type === 'workflow') {
    sql = `SELECT workflow.wfid AS value, workflow.wfname AS label
      FROM public.wms_workflow AS workflow
      WHERE workflow.isactive = true
        AND workflow.customerid =${getData.customerId}
      UNION
      SELECT workflow.wfid AS value, workflow.wfname AS label
      FROM public.wms_workflow AS workflow
      JOIN public.wms_config_customertabinfomapping AS wcc
        ON workflow.wfid = ANY(wcc.workflowid)  -- Compare wfid with each element in the workflowid array
      WHERE workflow.isactive = true
        AND wcc.customerid =${getData.customerId}
        AND wcc.duid = ${getData.duId}
        AND wcc.verticalid = ${getData.subDivisionId}
        AND ${getData.divisionId} = ANY(wcc.divisionid)
      ORDER BY value ASC;`;
  } else if (getData.type === 'checklisttype') {
    sql = `SELECT checklisttypeid as value, checklisttype as lable FROM public.wms_mst_checklisttype
        where isactive = 1 ORDER BY checklisttypeid ASC  `;
  } else if (
    getData.type === 'genericskill' ||
    getData.type == 'customerskill'
  ) {
    sql = `SELECT skillid as value , skillname as label FROM public.wms_mst_skill
        ORDER BY skillid ASC `;
  } else if (getData.type === 'stage') {
    sql = `SELECT DISTINCT ON(stage.stageid) stage.stageid as value, stage.stagename as label FROM public.wms_workflowdefinition as def
        left join wms_mst_stage as stage on stage.stageid = def.stageid
        where def.wfid = ${getData.workflowId}
        ORDER BY stage.stageid ASC  `;
  } else if (getData.type === 'customeractivity') {
    sql = `SELECT act.activityname AS label, act.activityid AS value FROM  public.wms_workflowdefinition wf JOIN public.wms_mst_stage st ON wf.stageid = st.stageid JOIN public.wms_mst_activity act ON wf.activityid = act.activityid WHERE wf.stageid = ${
      getData.stage ? getData.stage : null
    } and wf.wfid = ${getData.workflowId ? getData.workflowId : null}`;
  } else if (getData.type == 'genericstage') {
    sql = `SELECT DISTINCT ON(st.stageid) st.stagename AS label, st.stageid AS value FROM  public.wms_workflowdefinition wf JOIN public.wms_mst_skill sk ON wf.skillid = sk.skillid JOIN public.wms_mst_stage st ON wf.stageid = st.stageid WHERE wf.skillid = ${
      getData.skillid ? getData.skillid : null
    }`;
  } else if (getData.type === 'genericactivity') {
    sql = `SELECT act.activityname AS label, act.activityid AS value FROM  public.wms_workflowdefinition wf JOIN public.wms_mst_stage st ON wf.stageid = st.stageid JOIN public.wms_mst_activity act ON wf.activityid = act.activityid WHERE wf.stageid = ${
      getData.stage ? getData.stage : null
    }`;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const createCheckListMaster = async (req, res) => {
  const {
    checkListName,
    checkListType,
    workflowId,
    skillId,
    status,
    instructionList,
    divisionId,
    subDivisionId,
    customerId,
    duId,
    ischecklist,
    activityid,
    stageid,
  } = req.body;
  console.log(req.body, 'boddyyyyyyyyyy');
  const sql = `INSERT INTO public.wms_mst_checklist(
        checklistname, checklisttypeid, divisionid, subdivisionid, customerid, duid, wfid, skillid, isactive,ischecklist, activityid, stageid)
                 VALUES ('${checkListName}',${checkListType || null}, ${
    divisionId || null
  }, ${subDivisionId || null}, ${customerId || null} ,${duId || null}, ${
    workflowId || null
  }, ${skillId || null}, ${status},${ischecklist}, ${activityid || null}, ${
    stageid || null
  }) RETURNING checklistid`;
  console.log(sql, 'customermap');
  await query(sql)
    .then(async response => {
      const val = [];
      instructionList.forEach(list => {
        val.push(
          `(${response[0].checklistid}, '${list.instructions}', ${
            list.mandatory
          },${list.stage ? list.stage : null}, ${list.status})`,
        );
      });
      const insertInstruction = `INSERT INTO public.wms_mst_checklistinstruction(
                checklistid, checklistinstruction, mandatory, stageid, isactive)
                       VALUES ${val} RETURNING checklistinstructionid`;
      console.log(insertInstruction, 'insertInstruction');
      await query(insertInstruction).then(async dataInstruction => {
        console.log(dataInstruction, 'dataInstruction');
        const valAnswer = [];
        instructionList.forEach((data, i) => {
          data.answers.forEach(list => {
            valAnswer.push(
              `(${dataInstruction[i].checklistinstructionid}, '${list.answer}')`,
            );
          });
        });

        const insertAnswer = `INSERT INTO public.wms_mst_checklistinstruction_answer(
                checklistinstructionid, answer)
                VALUES ${valAnswer}`;
        console.log(insertAnswer, 'insertAnswer');
        await query(insertAnswer).then(async dataAnswer => {
          console.log(dataAnswer, 'dataAnswer');
          res.status(200).json({
            data: dataAnswer,
            status: true,
          });
        });
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const getCheckListMaster = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM wms_master_checklist`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM wms_master_checklist ORDER BY status DESC`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      } else {
        res
          .status(200)
          .json({ data: [], message: 'No data found', status: true });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const getPrePopulateInstruction = (req, res) => {
  const { checkListId, checkListTypeId } = req.body;
  const sql = `SELECT instruction.checklistinstructionid,instruction.checklistid,instruction.checklistinstruction,instruction.mandatory,instruction.stageid,instruction.isactive FROM wms_mst_checklist as checklist
    left join wms_mst_checklistinstruction as instruction on instruction.checklistid = checklist.checklistid
    where instruction.checklistid = ${checkListId} and checklist.checklisttypeid = ${
    checkListTypeId || null
  }
    ORDER BY checklistinstructionid ASC `;
  console.log(sql, 'gettinginstruction');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

// Email Reader start

export const getEmailReader = (req, res) => {
  const sql = `select * from wms_mst_emailreader where isactive=true  order by sequence`;

  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

// File sequence filename details
export const getFilenameDetails = (req, res) => {
  const { woid } = req.body;

  const sql = `select ft.filetype,ifd.filename,ifd.filesequence,ifd.woincomingfileid from wms_workorder_incoming incoming 
    join wms_workorder_incomingfiledetails ifd on incoming.woincomingid=ifd.woincomingid
     join pp_mst_filetype ft on ft.filetypeid=ifd.filetypeid
    where incoming.woid=${woid} and ft.filetypeid NOT IN (1, 15) order by ifd.filesequence`;

  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const insertupdateEmailReader = (req, res) => {
  const reqData = JSON.stringify(req.body);
  const sql = `select * from  insert_emailreadertran('${reqData}')`;

  console.log(sql, 'insertingfile');
  query(sql)
    .then(response => {
      res
        .status(200)
        .json({ issuccess: true, data: response[0].insert_emailreadertran });
    })
    .catch(error => {
      res.status(400).json({ issuccess: false, message: error });
    });
};
export const insertlogForFileInjection = (req, res) => {
  const reqData = JSON.stringify(req.body);
  const sql = `select * from  insert_fileinflowlog('${reqData}')`;

  console.log(sql, 'insertingfile');
  query(sql)
    .then(response => {
      res
        .status(200)
        .json({ issuccess: true, data: response[0].insert_fileinflowlog });
    })
    .catch(error => {
      res.status(400).json({ issuccess: false, message: error });
    });
};
export const getInFlowlogDetails = (req, res) => {
  const jsonData = req.query;
  const sql = `select a.inflowid,a.customername,a.journalcode,a.stagename,a.articlename,a.packagefilename,
  a.filesize,b.status,a.remarks,a.isretriggered,c.modename,a.retriggercount,a.stageiterationcount,
  a.issuccess,TO_CHAR(a.createddate,'dd-Mon-YYYY HH:MI:SS') as createddate
  from public.wms_trnfileinflow_details a
  join public.wms_mst_statuscode b on a.statusid=b.statusid
  join public.wms_mst_inflowmode c on c.modeid=a.modeid
  where a.createddate between '${moment(jsonData.startDate).format(
    'YYYY-MM-DD',
  )}' 
  and '${moment(jsonData.endDate).format(
    'YYYY-MM-DD 23:59:59',
  )}' order by a.inflowid desc`;
  query(sql)
    .then(response => {
      res.status(200).send({ issuccess: true, data: response });
    })
    .catch(error => {
      res.status(400).send({ issuccess: false, message: error });
    });
};

// Email Reader end

export const getPrePopulateInstructionAnswers = (req, res) => {
  const { checkListId } = req.body;
  const sql = `SELECT answers.answer,answers.checklistinstructionanswerid, instruction.checklistinstructionid FROM public.wms_mst_checklistinstruction_answer as answers
    left join wms_mst_checklistinstruction as instruction on instruction.checklistinstructionid = answers.checklistinstructionid
    where checklistid = ${checkListId}
    ORDER BY checklistinstructionanswerid ASC  `;
  console.log(sql, 'gettinginstruction');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const updateCheckListMaster = async (req, res) => {
  const { checkResultArray, instructionList } = req.body;
  console.log(req.body, 'request body');
  let sql = '';
  const checklisttypeid =
    checkResultArray.checklisttype == 'customerspecific' ? 2 : 1;
  sql = `UPDATE public.wms_mst_checklist SET checklistname='${
    checkResultArray.checklistname
  }', checklisttypeid=${checklisttypeid || null}, divisionid=${
    checkResultArray.division ? checkResultArray.division : null
  },subdivisionid=${
    checkResultArray.subdivision ? checkResultArray.subdivision : null
  },customerid=${
    checkResultArray.customer ? checkResultArray.customer : null
  },duid=${checkResultArray.du ? checkResultArray.du : null}, wfid=${
    checkResultArray.wfid ? checkResultArray.wfid : null
  },skillid=${
    checkResultArray.genericskill
      ? checkResultArray.genericskill
      : checkResultArray.customerskill
  }, isactive=${checkResultArray.status}, stageid=${
    checkResultArray.stage &&
    checkResultArray.checklisttype == 'customerspecific'
      ? checkResultArray.stage
        ? checkResultArray.stage
        : null
      : checkResultArray.genericstage
  }, activityid=${
    checkResultArray.customeractivity &&
    checkResultArray.checklisttype == 'customerspecific'
      ? checkResultArray.customeractivity
      : checkResultArray.genericactivity
  }
  WHERE checklistid= ${checkResultArray.checklistid}`;
  console.log(sql, 'checklist updation');
  await query(sql)
    .then(async () => {
      sql = `delete from wms_mst_checklistinstruction_answer where checklistinstructionid in 
        (select checklistinstructionid from wms_mst_checklistinstruction where checklistid= ${checkResultArray.checklistid})`;
      await query(sql)
        .then(async () => {
          sql = `delete from wms_mst_checklistinstruction where checklistid= ${checkResultArray.checklistid}`;
          await query(sql)
            .then(async () => {
              const val = [];
              instructionList.forEach(list => {
                val.push(
                  `(${checkResultArray.checklistid}, '${list.instructions}', ${
                    list.mandatory
                  },${list.stage ? list.stage : null}, ${list.status})`,
                );
              });
              sql = `INSERT INTO public.wms_mst_checklistinstruction(checklistid, checklistinstruction, mandatory, stageid, isactive)
                                           VALUES ${val} RETURNING checklistinstructionid`;
              console.log(sql, 'insertInstruction');
              await query(sql)
                .then(async insertInsertion => {
                  const valAnswer = [];
                  instructionList.forEach((data, i) => {
                    data.answers.forEach(list => {
                      valAnswer.push(
                        `(${insertInsertion[i].checklistinstructionid}, '${list.answer}')`,
                      );
                    });
                  });
                  sql = `INSERT INTO public.wms_mst_checklistinstruction_answer(checklistinstructionid, answer)
                                            VALUES ${valAnswer}`;
                  console.log(sql, 'insertAnswer');
                  await query(sql)
                    .then(async insertInsertionAnswer => {
                      res
                        .status(200)
                        .json({ data: insertInsertionAnswer, status: true });
                    })
                    .catch(error => {
                      res
                        .status(400)
                        .send({ message: error, status: false, data: [] });
                    });
                })
                .catch(error => {
                  res
                    .status(400)
                    .send({ message: error, status: false, data: [] });
                });
            })
            .catch(error => {
              res.status(400).send({ message: error, status: false, data: [] });
            });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const deleteCheckListMaster = (req, res) => {
  const getData = req.body;

  const selectsql = `select checklistinstructionid FROM public.wms_mst_checklistinstruction WHERE checklistid=${getData.checkListId}`;
  console.log(selectsql, 'sql');
  query(selectsql).then(data => {
    console.log(data, 'data');
    // const val = [];
    if (data.length > 0) {
      data.forEach(list => {
        const deleteAns = `DELETE FROM public.wms_mst_checklistinstruction_answer WHERE checklistinstructionid=${list.checklistinstructionid}`;
        console.log(deleteAns, 'deleteAns');
        query(deleteAns)
          .then(() => {
            const deleteInst = `DELETE FROM public.wms_mst_checklistinstruction WHERE checklistid=${getData.checkListId}`;
            console.log(deleteInst, 'deleteInst');
            query(deleteInst).then(() => {
              const deleteChecklist = `DELETE FROM public.wms_mst_checklist WHERE checklistid=${getData.checkListId}`;
              console.log(deleteChecklist, 'deleteChecklist');
              query(deleteChecklist).then(() => {});
              res.status(200).json({
                data,
                message: 'Checklist deleted sucessfully',
                status: true,
              });
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      });
    } else {
      const deleteChecklist = `DELETE FROM public.wms_mst_checklist WHERE checklistid=${getData.checkListId}`;
      console.log(deleteChecklist, 'deleteChecklist');
      query(deleteChecklist)
        .then(() => {
          res.status(200).json({
            data,
            message: 'Checklist deleted sucessfully',
            status: true,
          });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    }
  });
};

export const getBookMasterFieldsConfig = async (req, res) => {
  const { duId } = req.body;
  try {
    const sql = ` select * from wms_mst_book_fields as bookfields 
      join wms_mst_book_fields_map as fieldsmap on bookfields.fieldid = fieldsmap.fieldid
      where fieldsmap.duid = ${duId} and  bookfields.isactive = true and fieldsmap.isactive = true
      order by fieldsmap.fieldsequence`;
    const fieldsArray = await query(sql);

    res.status(200).json({
      data: fieldsArray,
      message: 'sucess',
      status: true,
    });
  } catch (error) {
    res.status(400).json({
      data: [],
      message: 'failed',
      status: false,
    });
  }
};

export const checkSkillAvaliablity = async (req, res) => {
  const {
    type,
    skillId,
    divisionId,
    subDivisionId,
    duId,
    customerId,
    workflowId,
    typeId,
    checklistName,
  } = req.body;
  let sql = '';
  if (type == 'generic') {
    sql = `SELECT count(1) FROM public.wms_mst_checklist as checklist
        where checklist.skillid =${skillId} and checklist.checklisttypeid = ${typeId} `;
  } else if (type == 'customerspecific') {
    sql = `SELECT count(1) FROM public.wms_mst_checklist  as checklist
        where checklist.customerid = ${customerId} and checklist.divisionid = ${divisionId} and checklist.subdivisionid =${subDivisionId} and checklist.duid= ${duId} and checklist.skillid = ${skillId} and checklist.checklisttypeid = ${typeId} and checklist.wfid= ${workflowId}`;
  } else if (type == 'genericInstruction') {
    sql = `SELECT instruction.checklistinstructionid,instruction.checklistinstruction,instruction.mandatory,instruction.stageid,
        instruction.isactive,checklist.checklisttypeid FROM public.wms_mst_checklist as checklist
        left join wms_mst_checklistinstruction as instruction on instruction.checklistid = checklist.checklistid
        where checklist.checklisttypeid = ${typeId} and checklist.skillid = ${skillId}
        ORDER BY instruction.checklistinstructionid ASC `;
  } else if (type == 'checklistname') {
    sql = `SELECT count(*) FROM public.wms_mst_checklist as checklist where checklist.checklistname ='${checklistName}'`;
  }

  console.log(sql, 'gettinginstruction');
  await query(sql)
    .then(response => {
      const result = [];
      let tempAns = [];
      let temp = {};
      console.log(response, 'instruction response');
      if (type == 'genericInstruction') {
        if (type == 'genericInstruction') {
          let insertans = '';
          if (response && response.length) {
            response.map(async (list, index) => {
              console.log(list, index, 'listttt');
              insertans = `SELECT * FROM public.wms_mst_checklistinstruction_answer where checklistinstructionid = ${list.checklistinstructionid}
                                    ORDER BY checklistinstructionanswerid ASC `;
              await query(insertans).then(responseAns => {
                console.log(responseAns, 'responseAnsresponseAns');
                if (responseAns.length > 1) {
                  console.log(responseAns, 'answer');
                  responseAns.forEach(ans => {
                    tempAns.push({
                      answer: ans.answer,
                      checklistinstructionid: ans.checklistinstructionid,
                    });
                  });
                } else {
                  tempAns.push({
                    answer: responseAns[0].answer,
                    checklistinstructionid:
                      responseAns[0].checklistinstructionid,
                  });
                }
              });
              temp.answers = tempAns;
              temp.instructions = list.checklistinstruction;
              temp.checklistinstructionid = list.checklistinstructionid;
              temp.mandatory = list.mandatory;
              temp.status = list.isactive;
              temp.stageid = list.stageid;
              temp.checklisttypeid = list.checklisttypeid;
              result.push(temp);
              tempAns = [];
              temp = {};
              console.log(result, 'result for lk');
              if (index == response.length - 1) {
                res.status(200).json({
                  data: result,
                  status: true,
                });
              }
            });
          } else {
            res.status(200).json({
              data: [],
              status: true,
            });
          }
        } else {
          res.status(200).json({ data: [], status: true });
        }
      } else if (type == 'checklistname') {
        res.status(200).json({ data: response[0].count, status: true });
      } else {
        res.status(200).json({ data: response, status: true });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const bookmasterUpdate = async (req, res) => {
  const { inputjson, id } = req.body;
  console.log(inputjson, 'inputjson');
  const jsonObject = JSON.parse(inputjson);
  const status = false;
  let l_message = '';
  try {
    const updateQuery = `update public.wms_book_master set 
      bookid = $1 , booktitle  = $2, onlinefirst  = $3, language  = $4,
      workflow  = $5 , mspages  = $6 , fmpages = $7 , bookpages = $8 , 
      billingpages  = $9, proofingdate = $10 ,layout = $11 , vertical = $12 , complexity = $13 ,
      projectmanagement = $14 , index = $15 , seriesnumber = $16 , referencestyle = $17 , 
      location = $18 , inputtype = $19 , paginationapplication = $20 ,accesability = $21 , 
      schedule = $22 , bookhistory = $23 , fasttrack  = $24, bookproofing = $25 , revisedproof = $26 ,
      fixedpublicationdate = $27 , numberoffigures = $28 , cover = $29 , celevelid = $30 ,
      mycopy = $31 , specialinstructions = $32 , bookisbn = $33 , compcopy = $34 ,
      ordered  = $35, ordereddate  = $36, reorderdate = $37, coverpages = $38, 
      onlineprofileid = $39 ,printprofileid = $40,trimsize = $41,indextype = $42, publisherimprintname = $43,
      lot = $44, loc = $45, lof = $46 
      where id = ${id}`;

    const values = [
      jsonObject.bookid,
      jsonObject.booktitle,
      jsonObject.onlinefirst,
      jsonObject.language,
      jsonObject.workflow,
      jsonObject.mspages,
      jsonObject.fmpages,
      jsonObject.bookpages,
      jsonObject.billingpages,
      jsonObject.proofingdate,
      jsonObject.layout,
      jsonObject.vertical,
      jsonObject.complexity,
      jsonObject.projectmanagement,
      jsonObject.index,
      jsonObject.seriesnumber,
      jsonObject.referencestyle,
      jsonObject.location,
      jsonObject.inputtype,
      jsonObject.paginationapplication,
      jsonObject.accesability,
      jsonObject.schedule,
      jsonObject.bookhistory,
      jsonObject.fasttrack,
      jsonObject.bookproofing,
      jsonObject.revisedproof,
      jsonObject.fixedpublicationdate,
      jsonObject.numberoffigures,
      jsonObject.cover,
      jsonObject.celevel,
      jsonObject.mycopy,
      jsonObject.specialinstructions,
      jsonObject.bookisbn,
      jsonObject.compcopy,
      jsonObject.ordered,
      jsonObject.ordereddate,
      jsonObject.reorderdate,
      jsonObject.coverpages,
      jsonObject.onlineprofile,
      jsonObject.printprofile,
      jsonObject.trimsize,
      jsonObject.indextype,
      jsonObject.imprintname,
      jsonObject.lot,
      jsonObject.loc,
      jsonObject.lof,
    ];

    const result = await query(updateQuery, values);

    if (result) {
      l_message = 'Saved';
    } else {
      l_message = 'failed';
    }

    const qrydelete = `delete from book_master_contacts where bookmasterid = ${id}`;
    await query(qrydelete);

    const qrycontact = `
    INSERT INTO book_master_contacts (bookmasterid, contactname, contactemail, roleid, familyname)
    VALUES 
    (${id}, '${jsonObject.pename}', '${jsonObject.peemailid}', 6, NULL),
    (${id}, '${jsonObject.projectmanager}', '${jsonObject.pmemailid}', 1, NULL),
    (${id}, '${jsonObject.correspondingauthorname}', '${jsonObject.correspondingauthoremail}', 7, '${jsonObject.correspondingauthorfamilyname}'),
    (${id}, '${jsonObject.correspondingeditorname}', '${jsonObject.correspondingeditoremail}', 12, '${jsonObject.correspondingeditorfamilyname}')
    `;

    await query(qrycontact);

    res.status(200).json({
      message: l_message,
      status,
    });
  } catch (error) {
    res.status(400).json({
      message: 'failed',
      status,
    });
  }
};

export const bookmasterInsert = async (req, res) => {
  const { inputjson } = req.body;

  // ,isauto,duId
  console.log(inputjson, 'inputjson');

  const jsonObject = JSON.parse(inputjson);
  let status = false;
  let l_message = '';

  try {
    const sql = `select count(*) as count from wms_book_master where lower(bookid) = lower('${jsonObject.bookid}') and isactive=true`;

    const result1 = await query(sql);

    if (result1 && result1.length && result1[0].count == 0) {
      const insertQuery = `INSERT INTO public.wms_book_master (
      bookid, booktitle, onlinefirst, language, workflow, mspages, fmpages, bookpages, billingpages, proofingdate,
      layout, vertical, complexity, projectmanagement, index, seriesnumber, referencestyle, location, inputtype, paginationapplication,
      accesability, schedule, bookhistory, fasttrack, bookproofing, revisedproof, fixedpublicationdate, numberoffigures, cover, celevelid,
      mycopy, specialinstructions, bookisbn, compcopy, ordered, ordereddate, reorderdate,coverpages,onlineprofileid,printprofileid,mycopyisbn,
      trimsize,indextype,publisherimprintname,book2,book2isbn
    ) VALUES (
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 
      $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, 
      $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, 
      $31, $32, $33, $34, $35, $36, $37, $38, $39, $40,
      $41,$42,$43,$44,$45,$46
    ) returning id`;

      const values = [
        jsonObject.bookid ?? null,
        jsonObject.booktitle ?? null,
        jsonObject.onlinefirst ?? null,
        jsonObject.language ?? null,
        jsonObject.workflow ?? null,
        jsonObject.mspages ?? null,
        jsonObject.fmpages ?? null,
        jsonObject.bookpages ?? null,
        jsonObject.billingpages ?? null,
        jsonObject.proofingdate ?? null,
        jsonObject.layout ?? null,
        jsonObject.vertical ?? null,
        jsonObject.complexity ?? null,
        jsonObject.projectmanagement ?? null,
        jsonObject.index ?? null,
        jsonObject.seriesnumber ?? null,
        jsonObject.referencestyle ?? null,
        jsonObject.location ?? null,
        jsonObject.inputtype ?? null,
        jsonObject.paginationapplication ?? null,
        jsonObject.accesability ?? null,
        jsonObject.schedule ?? null,
        jsonObject.bookhistory ?? null,
        jsonObject.fasttrack ?? null,
        jsonObject.bookproofing ?? null,
        jsonObject.revisedproof ?? null,
        jsonObject.fixedpublicationdate ?? null,
        jsonObject.numberoffigures ?? null,
        jsonObject.cover ?? null,
        jsonObject.celevel ?? null,
        jsonObject.mycopy ?? null,
        jsonObject.specialinstructions ?? null,
        jsonObject.bookisbn ?? null,
        jsonObject.compcopy ?? null,
        jsonObject.ordererd ?? null,
        jsonObject.ordereddate ?? null,
        jsonObject.reorderdate ?? null,
        jsonObject.coverpages ?? null,
        jsonObject.onlineprofileid ?? null,
        jsonObject.printprofileid ?? null,
        jsonObject.mycopyisbn ?? null,
        jsonObject.trimsize ?? null,
        jsonObject.indextype ?? null,
        jsonObject.publisherimprintname ?? null,
        jsonObject.book2 ?? null,
        jsonObject.book2isbn ?? null,
      ];

      let resultid = 0;

      const result = await query(insertQuery, values);
      if (result?.length == 1) {
        l_message = 'Saved';
        resultid = result[0].id;
        status = true;
      } else {
        l_message = 'Failed';
      }
      const qrycontact = `insert into book_master_contacts (bookmasterid,contactname,contactemail,roleid,familyname) 
          select ${resultid},'${jsonObject.pename}','${jsonObject.peemailid}',6,'' 
          union select ${resultid},'${jsonObject.projectmanager}','${jsonObject.pmemailid}',1,''
          union select ${resultid},'${jsonObject.correspondingauthorname}','${jsonObject.correspondingauthoremail}',7,'${jsonObject.correspondingauthorfamilyname}'
          union select ${resultid},'${jsonObject.correspondingeditorname}','${jsonObject.correspondingeditoremail}',12,'${jsonObject.correspondingeditorfamilyname}'
          union select ${resultid},'${jsonObject.responsibleeditorname}','${jsonObject.responsibleeditoremail}',53,'${jsonObject.responsibleeditorfamilyname}'
          `;
      await query(qrycontact);
    } else {
      l_message = 'Entry already exist';
      status = true;
    }

    res.status(200).json({
      message: l_message,
      status,
    });
  } catch (error) {
    res.status(400).json({
      message: 'failed',
      status,
    });
  }
};

export const getbookMasterRecords = async (req, res) => {
  try {
    const sql = `select 
    row_number() over(order by id) as serial, id, bookid, booktitle ,language, workflow, createddate, 'action' as action
    from wms_book_master where isactive = true order by id desc`;
    const rdata = await query(sql);
    res.status(200).json({ data: rdata });
  } catch (e) {
    console.log(e, 'e');
  }
};

export const getbookdetailforid = async (req, res) => {
  const { id } = req.body;
  try {
    // let sqwl = `select * from wms_book_master where isactive = true and id = ${id}`;

    const sql = `SELECT bm.id, bm.bookid, bm.booktitle, bm.onlinefirst,
      bm.workflow,bm.coverpages, bm.mspages, bm.fmpages, bm.bookpages, bm.billingpages, bm.proofingdate, bm.layout, 
	    bm.vertical, bm.complexity, bm.projectmanagement, bm.indextype, bm.seriesnumber,
      bm.referencestyle, bm.location, bm.inputtype, bm.paginationapplication,
      bm.accesability, bm.schedule, bm.bookhistory, bm.fasttrack, bm.bookproofing,
      bm.revisedproof, bm.fixedpublicationdate, bm.numberoffigures,
      bm.cover, bm.celevelid, bm.mycopy, bm.specialinstructions, bm.bookisbn, bm.compcopy,
	    bm.ordered, bm.ordereddate, bm.reorderdate, bm.status ,bm.onlineprofileid as onlineprofile, bm.printprofileid as printprofile,bm.publisherimprintname as imprintname,
      bm.lot, bm.loc, bm.lof
      ,(select contactname from book_master_contacts where bookmasterid = bm.id and roleid = 1) as projectmanager
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 1)  as pmemailid
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 6) as pename
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 6) as peemailid
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 7) as correspondingauthorname
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 7) as correspondingauthoremail
      ,(select familyname from book_master_contacts where bookmasterid = bm.id  and roleid = 7) as correspondingauthorfamilyname
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 12) as correspondingeditorname
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 12) as correspondingeditoremail
      ,(select familyname from book_master_contacts where bookmasterid = bm.id  and roleid = 12) as correspondingeditorfamilyname
	    ,(select contactname from book_master_contacts where bookmasterid = bm.id  and roleid = 53) as responsibleeditorname
	    ,(select contactemail from book_master_contacts where bookmasterid = bm.id  and roleid = 53) as responsibleeditoremail
	    ,(select familyname from book_master_contacts where bookmasterid = bm.id  and roleid = 53) as responsibleeditorfamilyname
      ,bm.trimsize,
      (select COALESCE((select languagename from public.wms_mst_language as a join wms_book_master b on a.languagecode = b.language where b.id = ${id}), bm.language)) as language
      FROM wms_book_master as bm where bm.id = ${id}`;

    console.log(sql, 'getbookdetailforid');
    const rdata = await query(sql);

    res.status(200).json({ data: rdata, message: 'success' });
  } catch (e) {
    console.log(e, 'catchgetbookdetailforid');
    res.status(200).json({ data: {}, message: 'failure' });
  }
};

// SubDivision Module
// get the details for  Subdivision master
export const getMasterMenu = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_uimenu`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT ROW_NUMBER() OVER (ORDER BY m1.menuid desc) AS sno,  
        m1.menuid,
        m1.menuname,
        m1.menudescription,          
        COALESCE(m1.menuicon, '-') AS menuicon,
        COALESCE(m1.parentmenuid, null) AS parentmenuid,
        COALESCE(m2.menuname, '-') AS parent_menuname,
        'action' AS action
        FROM public.wms_uimenu m1
        LEFT JOIN 
        public.wms_uimenu m2 ON m1.parentmenuid = m2.menuid order by menuid desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getScreenMaster = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_mst_screens`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT ROW_NUMBER() OVER (ORDER BY scr.screenid desc) AS sno,  
        scr.screenid,
        scr.screenname,
        scr.screendescription,
        scr.screenmappingpath,
        COALESCE(scr.menuid, null) AS menuid,
        COALESCE(mu.menuname, '-') AS menuname,
        COALESCE(scr.duid, null) AS duid,
        'action' AS action
        FROM public.wms_mst_screens scr
        LEFT JOIN 
          public.wms_uimenu mu ON mu.menuid = scr.menuid order by screenid desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getEntityMaster = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM wms_mst_entity`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT ROW_NUMBER() OVER (ORDER BY entityid desc) AS sno, *, 'action' AS action from  wms_mst_entity order by entityid desc`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getScreenmappingMaster = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM wms_screen_entity_map`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT
        ROW_NUMBER() OVER (ORDER BY se.semapid desc) AS sno,
        se.entityid,
        e.entityname,
        se.screenid,
        sr.screenname,
        se.semapid,
        'action' AS action
    FROM public.wms_screen_entity_map se
    JOIN public.wms_mst_entity e ON se.entityid = e.entityid
    JOIN public.wms_mst_screens sr ON se.screenid = sr.screenid order by se.semapid desc;`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getRoleMappingMaster = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM wms_entity_permission`;
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT
        ROW_NUMBER() OVER (ORDER BY pm.entitypermid desc) AS sno,
        pm.entitypermid,
        pm.entityid,
        e.entityname,
        pm.roleid,
        r.rolename,
        pm.entitypermid,
        'action' AS action
    FROM public.wms_entity_permission pm
    JOIN public.wms_mst_entity e ON pm.entityid = e.entityid
    JOIN public.wms_role r ON pm.roleid = r.roleid order by pm.entitypermid desc;`;
        query(sqlQuery)
          .then(data => {
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getDropdownMaster = async (req, res) => {
  try {
    const tblname = req.params.menuname.toUpperCase();
    const out = await getMasterService(tblname);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getMasterService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(get_master_drop_down(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// eslint-disable-next-line consistent-return
export const createChapterMaster = async (req, res) => {
  try {
    const jsonObject = req.body;
    const selSql = `SELECT id,bookid FROM wms_book_master WHERE bookid = '${jsonObject.bookid}' and isactive = true`;
    const selResult = await query(selSql);
    jsonObject.bookid = selResult[0]?.id;
    if (!jsonObject.bookid) {
      return res.status(400).send({ message: 'Book ID not found' });
    }
    const values = [
      jsonObject.bookid ?? null,
      jsonObject.chapterdoi ?? null,
      jsonObject.eproofing ?? null,
      jsonObject.history ?? null,
      jsonObject.isactive ?? null,
      jsonObject.mspages ?? null,
      jsonObject.numberoffigures ?? null,
      jsonObject.proofpages ?? null,
      jsonObject.revisedproof ?? null,
      jsonObject.scheduledate ?? null,
      jsonObject.sourcezipfileid ?? null,
      jsonObject.schedule ?? null,
      jsonObject.chapteruniqueid ?? null,
      jsonObject.chaptersequencenumber ?? null,
      jsonObject.chapteritemcode ?? null,
      jsonObject.chapterid ?? null,
      jsonObject.created_by ?? null,
      jsonObject.authoremail ?? null,
      jsonObject.authorname ?? null,
      jsonObject.chaptertitle ?? null,
    ];

    const selChapter = `SELECT chaptermasterid FROM springer.ice_mstchapter WHERE chapteritemcode = '${jsonObject.chapteritemcode}' and isactive = true`;
    const selChapterResult = await query(selChapter);
    if (selChapterResult.length > 0) {
      return res
        .status(200)
        .send({ isSuccess: true, message: 'Chapter Item Code already exists' });
    }
    const sql = `INSERT INTO springer.ice_mstchapter(
        bookid, chapterdoi, eproofing, history, isactive, mspages, numberoffigures, proofpages, revisedproof, 
        scheduledate, sourcezipfileid, schedule, chapteruniqueid, chaptersequencenumber,chapteritemcode,chapterid,
        created_by,authoremail,authorname,chaptertitle)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10
               ,$11, $12, $13, $14,$15,$16,$17,$18,$19,$20) returning chaptermasterid`;
    const result = await query(sql, values);
    return res.status(200).send({
      isSuccess: true,
      result,
      message: 'Chapter Master Created Successfully',
    });
  } catch (error) {
    res.status(400).send({ isSuccess: false, error, message: error?.message });
  }
};

export const getChapterMaster = async (req, res) => {
  try {
    const { bookId } = req.body;
    const result = await query(
      `SELECT * FROM springer.ice_mstchapter WHERE bookid = ${bookId}`,
    );
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateChapterMaster = async (req, res) => {
  try {
    const {
      authoruserid,
      bookseriesid,
      chapterdoi,
      chaptermasterid,
      eproofing,
      history,
      isactive,
      mspages,
      numberoffigures,
      proofpages,
      revisedproof,
      scheduledate,
      sourcezipfileid,
      schedule,
      chapteruniqueid,
      chaptersequencenumber,
      authoremail,
      authorname,
    } = req.body;

    const sql = `
      UPDATE springer.ice_mstchapter 
      SET 
        scheduledate = ${scheduledate ? `'${scheduledate}'` : null}, 
        mspages = ${mspages !== null ? `'${mspages}'` : null}, 
        proofpages = ${proofpages !== null ? `'${proofpages}'` : null}, 
        schedule = ${schedule ? `'${schedule}'` : null}, 
        history = ${history ? `'${history}'` : null}, 
        eproofing = ${eproofing ? `'${eproofing}'` : null}, 
        revisedproof = ${revisedproof ? `'${revisedproof}'` : null}, 
        chapteruniqueid = ${chapteruniqueid !== null ? chapteruniqueid : null}, 
        chapterdoi = ${chapterdoi ? `'${chapterdoi}'` : null}, 
        chaptersequencenumber = ${
          chaptersequencenumber !== null ? chaptersequencenumber : null
        }, 
        bookseriesid = ${bookseriesid !== null ? bookseriesid : null}, 
        authoruserid = ${authoruserid !== null ? authoruserid : null}, 
        sourcezipfileid = ${sourcezipfileid !== null ? sourcezipfileid : null}, 
        isactive = ${isactive !== null ? isactive : null}, 
        numberoffigures = ${numberoffigures !== null ? numberoffigures : null},
        authoremail = ${authoremail !== null ? `'${authoremail}'` : null},
        authorname = ${authorname !== null ? `'${authorname}'` : null}
      WHERE chaptermasterid = ${chaptermasterid};
    `;
    const result = await query(sql);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export function get_master_drop_down(getdata) {
  let script = '';
  switch (getdata) {
    case 'MENU':
      script =
        'select menuname as label,menuid as value from public.wms_uimenu';
      break;
    case 'SCREEN':
      script =
        'select screenname as label,screenid as value from public.wms_mst_screens';
      break;
    case 'ROLE':
      script = 'select rolename as label,roleid as value from public.wms_role';
      break;
    case 'ENTITY':
      script =
        'select entityname as label,entityid as value from public.wms_mst_entity';
      break;
    case 'DU':
      script =
        'SELECT duid as value , duname as label FROM public.org_mst_deliveryunit ORDER BY duid ASC ';
      break;
    default:
      throw new Error('Invalid Param');
  }
  return script;
}

export const addMenuMaster = (req, res) => {
  const reqData = req.body;
  const menuid =
    'SELECT menuid FROM public.wms_uimenu ORDER BY menuid DESC LIMIT 1';
  query(menuid)
    .then(getCount => {
      const menuId = parseInt(getCount[0].menuid) + 1;
      const menuiconValue = reqData.menuicon ? `'${reqData.menuicon}'` : null;
      const parentmenuid = reqData.parentmenuid
        ? parseInt(reqData.parentmenuid.value)
        : null;
      if (getCount != 0) {
        const sql = `INSERT INTO public.wms_uimenu (menuid, menuname, menudescription,menuicon, parentmenuid, isactive)
            VALUES( ${menuId},'${reqData.menuname}','${reqData.menudescription}',${menuiconValue},${parentmenuid}, true) RETURNING menuid`;
        query(sql)
          .then(data => {
            res.status(200).json({
              data,
              message: `New Menu added successfully`,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const addScreenMaster = (req, res) => {
  const reqData = req.body;
  const menuid =
    'SELECT screenid FROM public.wms_mst_screens order by screenid DESC LIMIT 1;';
  query(menuid)
    .then(getCount => {
      const screenid = parseInt(getCount[0].screenid) + 1;
      const menuidValue =
        reqData.menuid == '' || reqData.menuid == null
          ? null
          : parseInt(reqData.menuid?.value);
      const duvalue =
        reqData.duid == null || reqData.duid == [] ? null : `'${reqData.duid}'`;
      if (getCount != 0) {
        const sql = `INSERT INTO public.wms_mst_screens (screenid, screenname, screendescription, screenmappingpath, menuid, duid)
        VALUES( ${screenid} ,'${reqData.screenname}','${reqData.screendescription}','${reqData.screenpath}',${menuidValue}, ${duvalue}) RETURNING screenid`;
        query(sql)
          .then(data => {
            res.status(200).json({
              data,
              message: `New Screen added successfully`,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      }
    })

    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const addEntityMaster = (req, res) => {
  const reqData = req.body;
  const menuid =
    'SELECT entityid FROM public.wms_mst_entity order by entityid DESC LIMIT 1;';
  query(menuid)
    .then(getCount => {
      const entityid = parseInt(getCount[0].entityid) + 1;
      if (getCount != 0) {
        const sql = `INSERT INTO public.wms_mst_entity (entityid, entityname, entitydescription, isactive)
        VALUES( ${entityid} ,'${reqData.entityname}','${reqData.entitydescription}', true) RETURNING entityid`;
        query(sql)
          .then(data => {
            res.status(200).json({
              data,
              message: `New Entity added successfully`,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      }
    })

    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const addScreenMapping = (req, res) => {
  const reqData = req.body;
  const menuid =
    'SELECT semapid FROM public.wms_screen_entity_map order by semapid DESC LIMIT 1;';
  query(menuid)
    .then(getCount => {
      const semapid = parseInt(getCount[0].semapid) + 1;
      if (getCount != 0) {
        const sql = `INSERT INTO public.wms_screen_entity_map (semapid, screenid, entityid)
        VALUES( ${semapid},${parseInt(reqData.screenname.value)},${parseInt(
          reqData.entityname.value,
        )}) RETURNING semapid`;
        query(sql)
          .then(data => {
            res.status(200).json({
              data,
              message: `New Entity and Screen Mapped successfully`,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      }
    })

    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const addRoleMapping = (req, res) => {
  const reqData = req.body;
  const menuid =
    'SELECT entitypermid FROM public.wms_entity_permission order by entitypermid DESC LIMIT 1;';
  query(menuid)
    .then(getCount => {
      const entitypermid = parseInt(getCount[0].entitypermid) + 1;
      if (getCount != 0) {
        const sql = `INSERT INTO public.wms_entity_permission (entitypermid, entityid, roleid)
        VALUES( ${entitypermid}, ${parseInt(
          reqData.entityname.value,
        )}, ${parseInt(reqData.role.value)} ) RETURNING entitypermid`;
        query(sql)
          .then(data => {
            res.status(200).json({
              data,
              message: `Entity and Role Mapped successfully`,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      }
    })

    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateMenuMaster = (req, res) => {
  const reqData = req.body;
  const menuiconValue =
    reqData.menuicon != '-' && reqData.menuicon != null
      ? `'${reqData.menuicon}'`
      : null;
  const parentmenuid =
    reqData.parentmenuid.value != null
      ? parseInt(reqData.parentmenuid.value)
      : null;
  const sql = `update public.wms_uimenu set menuname = '${reqData.menuname}', 
  menudescription = '${reqData.menudescription}', 
  menuicon = ${menuiconValue}, 
  parentmenuid = ${parentmenuid} 
  where menuid = ${parseInt(reqData.menuid)} RETURNING menuid`;
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: `Menu updated successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const updateScreenMaster = (req, res) => {
  const reqData = req.body;
  const menuidValue =
    reqData.menuid == '' || reqData.menuid == null
      ? null
      : parseInt(reqData.menuid?.value);
  const sql = `update public.wms_mst_screens set screenname = '${
    reqData.screenname
  }', screendescription = '${
    reqData.screendescription
  }', screenmappingpath = '${
    reqData.screenpath
  }', menuid = ${menuidValue}, duid = '${
    reqData.duid
  }' where screenid = ${parseInt(reqData.screenid)} RETURNING screenid`;
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: `Screen updated successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const updateEntityMaster = (req, res) => {
  const reqData = req.body;
  const sql = `update public.wms_mst_entity set entityname = '${
    reqData.entityname
  }', entitydescription = '${
    reqData.entitydescription
  }' where entityid = ${parseInt(reqData.entityid)} RETURNING entityid`;
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: `Entity updated successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const updateScreenMapping = (req, res) => {
  const reqData = req.body;
  const sql = `update public.wms_screen_entity_map set screenid = ${parseInt(
    reqData.screenname.value,
  )}, entityid = ${parseInt(
    reqData.entityname.value,
  )} where semapid = ${parseInt(reqData.semapid)} RETURNING semapid`;
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: `Menu updated successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const getBookFields = (req, res) => {
  const { customerid } = req.body;
  const sql = `
    SELECT 
      f.fieldid, 
      f.type, 
      f.label, 
      f.placeholder, 
      f.minlength, 
      f.maxlength, 
      f.pattern, 
      f.name, 
      f.isactive, 
      fm.mandatory, 
      fm.disabled, 
      fm.fieldsequence, 
      fm.defaultvalue, 
      fm.iseditdisabled,
      fm."group"
    FROM 
      public.ialt_mst_book_fields f 
    INNER JOIN 
      public.ialt_mst_book_fields_map fm 
    ON 
      f.fieldid = fm.fieldid 
    WHERE 
      fm.isactive = true
      ${customerid ? 'AND fm.customerid = $1' : ''}
    ORDER BY 
      fm.fieldsequence;
  `;

  const queryParams = customerid ? [customerid] : [];

  query(sql, queryParams)
    .then(data => {
      res.status(200).json({
        data,
        message: `Fields fetched successfully ${
          customerid ? `for customerid ${customerid}` : 'for all customers'
        }`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error.message, status: false });
    });
};

export const updateBookField = (req, res) => {
  const {
    fieldid,
    type,
    label,
    placeholder,
    minlength,
    maxlength,
    pattern,
    name,
    isactive,
  } = req.body;

  if (!fieldid) {
    return res
      .status(400)
      .json({ message: 'Field ID is required', status: false });
  }

  const sql = `
    UPDATE public.ialt_mst_book_fields
    SET 
      type = COALESCE($1, type),
      label = COALESCE($2, label),
      placeholder = COALESCE($3, placeholder),
      minlength = CASE WHEN $4 = '' THEN NULL ELSE COALESCE($4::bigint, minlength) END,
      maxlength = CASE WHEN $5 = '' THEN NULL ELSE COALESCE($5::bigint, maxlength) END,
      pattern = COALESCE($6, pattern),
      name = COALESCE($7, name),
      isactive = COALESCE($8, isactive)
    WHERE 
      fieldid = $9
    RETURNING *;
  `;

  const queryParams = [
    type,
    label,
    placeholder,
    minlength,
    maxlength,
    pattern,
    name,
    isactive,
    fieldid,
  ];

  return query(sql, queryParams)
    .then(data => {
      if (data.length > 0) {
        res.status(200).json({
          data: data[0],
          message: 'Field updated successfully',
          status: true,
        });
      } else {
        res.status(404).json({ message: 'Field not found', status: false });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error.message, status: false });
    });
};

export const getAllBookFields = (req, res) => {
  const sql = `
    SELECT 
      fieldid, 
      type, 
      label, 
      placeholder, 
      minlength, 
      maxlength, 
      pattern, 
      name, 
      isactive
    FROM 
      public.ialt_mst_book_fields
    WHERE 
      isactive = true
    ORDER BY 
      fieldid;
  `;

  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'All fields fetched successfully',
      });
    })
    .catch(error => {
      res.status(400).send({ message: error.message, status: false });
    });
};

export const updateBookFieldForCustomer = (req, res) => {
  const {
    fieldid,
    customerid,
    mandatory,
    disabled,
    fieldsequence,
    defaultvalue,
    iseditdisabled,
  } = req.body;

  if (!fieldid || !customerid) {
    return res.status(400).json({
      message: 'Field ID and Customer ID are required',
      status: false,
    });
  }

  const sql = `
    UPDATE public.ialt_mst_book_fields_map
    SET 
      mandatory = COALESCE($1, mandatory),
      disabled = COALESCE($2, disabled),
      fieldsequence = COALESCE($3, fieldsequence),
      defaultvalue = COALESCE($4, defaultvalue),
      iseditdisabled = COALESCE($5, iseditdisabled)
    WHERE 
      fieldid = $6 AND customerid = $7
    RETURNING *;
  `;

  const queryParams = [
    mandatory,
    disabled,
    fieldsequence,
    defaultvalue,
    iseditdisabled,
    fieldid,
    customerid,
  ];

  return query(sql, queryParams)
    .then(data => {
      if (data.length > 0) {
        res.status(200).json({
          data: data[0],
          message: 'Field updated successfully for the specified customer',
          status: true,
        });
      } else {
        res.status(404).json({
          message: 'Field not found for the specified customer',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error.message, status: false });
    });
};

export const deleteBookField = (req, res) => {
  const { fieldid } = req.body;

  const sql = `
    UPDATE public.ialt_mst_book_fields
    SET isactive = false
    WHERE fieldid = $1;
  `;
  query(sql, [fieldid])
    .then(() => {
      res.status(200).json({
        message: 'Field deleted successfully',
      });
    })
    .catch(error => {
      res.status(400).send({ message: error.message, status: false });
    });
};

export const deleteMappedBookField = (req, res) => {
  const { fieldid, customerid } = req.body;

  const sql = `
    UPDATE public.ialt_mst_book_fields_map
    SET isactive = false
    WHERE fieldid = $1 AND customerid = $2;
  `;

  query(sql, [fieldid, customerid])
    .then(() => {
      res.status(200).json({
        message: 'Field deleted successfully',
        status: 200,
      });
    })
    .catch(error => {
      res.status(400).json({
        message: error.message,
        status: 400,
      });
    });
};

export const updateFields = payload => {
  return new Promise(async (resolve, reject) => {
    const { fields, customerid } = payload;
    try {
      for (const [index, field] of fields.entries()) {
        const checkSql = `SELECT * FROM ialt_mst_book_fields_map WHERE fieldid = $1 AND customerid = $2`;
        const checkParams = [field.fieldid, customerid];

        const existingRows = await query(checkSql, checkParams);

        let sql;
        let params;
        if (existingRows && existingRows.length > 0) {
          sql = `UPDATE public.ialt_mst_book_fields_map
                 SET fieldsequence = $1, "group" = $2, mandatory = $3
                 WHERE fieldid = $4 AND customerid = $5`;
          params = [
            index + 1,
            field.group,
            field.mandatory,
            field.fieldid,
            customerid,
          ];
        } else {
          sql = `INSERT INTO public.ialt_mst_book_fields_map
                       (duid, fieldid, customerid, mandatory, disabled, isactive, defaultvalue, iseditdisabled, fieldsequence, "group")
                       VALUES
                       ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`;
          params = [
            field.duid || null,
            field.fieldid,
            customerid,
            field.mandatory || false,
            field.disabled || false,
            field.isactive || true,
            field.defaultvalue || null,
            field.iseditdisabled || false,
            index + 1,
            field.group,
          ];
        }
        await query(sql, params);
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const saveFieldOrder = async (req, res) => {
  try {
    const payload = req.body;
    await updateFields(payload);

    res.status(200).json({ message: 'Order and fields saved successfully' });
  } catch (error) {
    res.status(400).send({ message: error.message, status: false });
  }

  // const { fields, customerid } = req.body;
  // if (!fields.every(field => field.fieldid)) {
  //   return res
  //     .status(400)
  //     .send({ message: 'Invalid fields data', status: false });
  // }
  // let sql = 'BEGIN;';
  // ${field.duid || 'NULL'}, ${
  //   field.fieldid
  // }, ${customerid}, ${index + 1}, ${field.mandatory || false}, ${
  //   field.disabled || false
  // }, ${field.isactive || true}, ${
  //   field.defaultvalue ? `'${field.defaultvalue}'` : 'NULL'
  // }, ${field.iseditdisabled || false});
  //  const values = [];
  //  let sql1=``
  // fields.forEach((field, index) => {
  //     const sql = `select * from ialt_mst_book_fields_map where fieldid = field.fieldid`
  //      const count = await query(sql);
  //      if(count && count.length > 0){
  //      sql1 = `INSERT INTO public.ialt_mst_book_fields_map
  //       (duid, fieldid, customerid,  mandatory, disabled, isactive, defaultvalue, iseditdisabled,fieldsequence)
  //     VALUES
  //       ( ${field.duid || 'NULL'}, ${
  //       field.fieldid
  //     }, ${customerid},  ${field.mandatory || false}, ${
  //       field.disabled || false
  //     }, ${field.isactive || true}, ${
  //       field.defaultvalue ? `'${field.defaultvalue}'` : 'NULL'
  //     }, ${field.iseditdisabled || false}, ${index + 1} );
  //     `;
  //      }else{
  //       sql1 = `
  //       UPDATE public.ialt_mst_book_fields_map
  //       SET fieldsequence = ${index + 1}
  //       WHERE fieldid = ${field.fieldid} AND customerid = ${customerid};
  //     `;
  //      }
  //      await query(sql1)
  // });
  // fields.forEach((field, index) => {
  //   if (field.isNew) {
  //     // Retrieve current max fieldmapid and insert new field
  //     sql += `
  //     WITH max_id AS (
  //       SELECT COALESCE(MAX(fieldmapid), 0) AS max_id
  //       FROM public.ialt_mst_book_fields_map
  //       WHERE customerid = ${customerid}
  //     )
  // INSERT INTO public.ialt_mst_book_fields_map
  //   (fieldmapid, duid, fieldid, customerid, fieldsequence, mandatory, disabled, isactive, defaultvalue, iseditdisabled)
  // VALUES
  //   ((SELECT max_id + 1 FROM max_id), ${field.duid || 'NULL'}, ${
  //   field.fieldid
  // }, ${customerid}, ${index + 1}, ${field.mandatory || false}, ${
  //   field.disabled || false
  // }, ${field.isactive || true}, ${
  //   field.defaultvalue ? `'${field.defaultvalue}'` : 'NULL'
  // }, ${field.iseditdisabled || false});
  // `;
  //   } else {
  //     // Update the sequence of existing fields
  // sql += `
  //   UPDATE public.ialt_mst_book_fields_map
  //   SET fieldsequence = ${index + 1}
  //   WHERE fieldid = ${field.fieldid} AND customerid = ${customerid};
  // `;
  //   }
  // });
  // sql += 'COMMIT;';
  // return query(sql)
  //   .then(() => {
  //     res.status(200).json({ message: 'Order and fields saved successfully' });
  //   })
  //   .catch(error => {
  //     res.status(400).send({ message: error.message, status: false });
  //   });
};

export const addBookField = (req, res) => {
  const { type, label, placeholder, minlength, maxlength, pattern, name } =
    req.body;

  // Convert input values to appropriate types, handle empty strings
  const intMinLength = minlength ? parseInt(minlength, 10) : null;
  const intMaxLength = maxlength ? parseInt(maxlength, 10) : null;
  // Prepare SQL and parameters
  const sql = `
INSERT INTO public.ialt_mst_book_fields (
 type, label, placeholder, minlength, maxlength, pattern, name, isactive
)
VALUES ( $1, $2, $3, $4, $5, $6, $7, $8)
RETURNING fieldid;
  `;

  // Ensure no undefined values in params
  const params = [
    type || null,
    label || null,
    placeholder || null,
    intMinLength !== null ? intMinLength : null,
    intMaxLength !== null ? intMaxLength : null,
    pattern || null,
    name || null,
    true, // Assuming you want to set 'isactive' to true
  ];

  console.log('Executing SQL:', sql);
  console.log('Parameters:', params);

  // Execute the query and handle the result
  return query(sql, params)
    .then(result => {
      console.log('Query result:', result);

      const rows = result || [];
      if (rows.length === 0) {
        console.error('No rows returned from query. Result:', result);
        throw new Error('No rows returned from query');
      }

      const fieldId = rows[0]?.fieldid;
      if (!fieldId) {
        console.error('Failed to retrieve field ID. Rows:', rows);
        throw new Error('Failed to retrieve field ID');
      }

      res
        .status(200)
        .json({ message: 'Field added successfully', status: true, fieldId });
    })
    .catch(error => {
      console.error('Error adding field:', error);
      res.status(400).json({ message: error.message, status: false });
    });
};

export const updateRoleMapping = (req, res) => {
  const reqData = req.body;
  const sql = `update public.wms_entity_permission set roleid = ${parseInt(
    reqData.role.value,
  )}, entityid = ${parseInt(
    reqData.entityname.value,
  )} where entitypermid = ${parseInt(
    reqData.entitypermid,
  )} RETURNING entitypermid`;
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: `Menu updated successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const getActiveCustomers = async (req, res) => {
  try {
    const customers = await query(
      `SELECT DISTINCT org_mst_customer.customername, org_mst_customer.customerid,
wms_workflow.iscamundaflow FROM org_mst_customer
JOIN wms_workflow ON org_mst_customer.customerid = wms_workflow.customerid
WHERE org_mst_customer.isactive = true`,
    );
    res.json(customers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getJournals = async (req, res) => {
  try {
    const journals = await query(
      `
      SELECT jm.journalid, jm.journalacronym 
      FROM pp_mst_journal jm
      JOIN public.org_mst_customer_orgmap AS org ON jm.custorgmapid = org.custorgmapid AND org.isactive = 1
      WHERE org.customerid = $1 AND jm.isactive = 1
    `,
      [req.params.customerId],
    );
    res.json(journals);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getStages = async (req, res) => {
  try {
    const stages = await query(
      `
      SELECT  
        wwd.stageid AS value,
        ws.stagename AS label,
        min(wwd.sequence) as minseq
      FROM wms_workflowdefinition wwd
      JOIN wms_mst_stage ws ON wwd.stageid = ws.stageid
      WHERE wwd.wfid = $1
      GROUP BY wwd.stageid, ws.stagename
      ORDER BY minseq
      `,
      [req.params.wfid],
    );
    res.json(stages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getVolumes = async (req, res) => {
  try {
    const volumes = await query(
      `
      SELECT journalacronym || '_0(0)' AS volume
      FROM pp_mst_journal 
      WHERE journalid = $1
      UNION
      SELECT jm.journalacronym || '_' || issuenumber || '(' || volumenumber || ')' AS volume
      FROM wms_workorder wo 
      JOIN wms_workorder_stage AS stg ON stg.workorderid = wo.workorderid AND stg.status != 'YTS'
      JOIN pp_mst_journal AS jm ON jm.journalid = wo.journalid
      WHERE wo.customerid = $2 AND 
            wo.journalid = $1 AND 
            stg.wfstageid = $3 AND
            wo.issuenumber != '' AND
            wo.volumenumber != ''
    `,
      [req.params.journalId, req.params.customerId, req.params.stageId],
    );
    res.json(volumes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getActivities = async (req, res) => {
  try {
    const activities = await query(
      `
      SELECT activityid,activityalias 
      from wms_workflowdefinition 
      WHERE wfid = $1 AND stageid = $2 order by sequence
    `,
      [req.params.wfid, req.params.stageId],
    );
    res.json(activities);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getWorkorders = async (req, res) => {
  const { customerId, journalId } = req.query;
  try {
    let condition = ``;
    if (customerId) {
      condition += ` AND customerid = ${customerId}`;
    }
    if (journalId) {
      condition += ` AND journalid = ${journalId}`;
    }

    const sql = `select itemcode, wo.workorderid,wos.wfid from wms_workorder as wo join wms_workorder_service as wos on wo.workorderid = wos.workorderid where wo.isactive = true ${condition} order by wo.workorderid asc`;
    const workorders = await query(sql);

    res.json(workorders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getActiveCustomersList = async (req, res) => {
  try {
    const customers = await query(
      `SELECT DISTINCT 
    org_mst_customer.customername, 
    org_mst_customer.customerid 
      FROM 
          org_mst_customer
      JOIN 
          wms_workflow 
      ON 
          org_mst_customer.customerid = wms_workflow.customerid
      WHERE 
          org_mst_customer.isactive = true
      ORDER BY 
          org_mst_customer.customername ASC;
`,
    );
    res.json(customers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
export const getProductionTableData = async (req, res) => {
  try {
    const { workorderId, stageid, activityid } = req.body;
    const queryText = `
    SELECT
      cust.customername,
      jm.journalacronym AS book,
      wo.itemcode AS filename,
      wo.workorderid,
      wfd.activityalias AS activityname,
      st.stagename || ' ' || ev.stageiterationcount::text as stagename,
      ev.stageiterationcount,
      wfd.wfdefid,
      ev.activitystatus,
      ev.userid,  
      ev.wfeventid,
      TO_CHAR((SELECT MAX(timestamp) AS timestamp FROM wms_workflow_eventlog_details WHERE wfeventid = ev.wfeventid)::timestamp, 'yyyy-mm-dd hh24:mi:ss') AS updatedtime,
      ev.woincomingfileid,
      wos.wfid,
      wfd.activitytype,
      wfd.stageid,
      wfd.activityid,
      incomingdetails.filetypeid as fileId,
      CASE 
      WHEN incomingdetails.imagecount= 0 THEN false ELSE true END as isGraphic,
      ev.activityiterationcount,
      ev.actualactivitycount,
      wo.itemcode,
      wo.title,
      du.duid,
      du.duname,
      cust.customerid,
      jm.journalacronym,
	    wfd.config as defconfig,
	    wfd.nextactivityid,
	    wfd.fileconfig,
	    wf.config,
       st.stagename as stage

	
      FROM wms_workorder AS wo  
      JOIN wms_workorder_service AS wos ON wos.workorderid = wo.workorderid
      JOIN wms_workflowdefinition AS wfd ON wfd.wfid = wos.wfid AND wfd.stageid = $2 AND wfd.activityid = COALESCE($3, wfd.activityid)
      JOIN public.wms_workflow_eventlog AS ev ON ev.workorderid = wo.workorderid AND wfd.wfdefid = ev.wfdefid
      JOIN public.org_mst_customer AS cust ON cust.customerid = wo.customerid
      LEFT JOIN pp_mst_journal AS jm ON jm.journalid = wo.journalid
      JOIN wms_mst_stage AS st ON st.stageid = wfd.stageid
      JOIN wms_workorder_incomingfiledetails as incomingdetails on incomingdetails.woincomingfileid = ev.woincomingfileid
	    JOIN wms_workflow as wf on wf.wfid = wos.wfid
      JOIN public.org_mst_deliveryunit as du on du.duid = wos.baseduid
      
      WHERE wo.workorderid = $1
      GROUP BY
      cust.customername,
      jm.journalacronym,
      wo.itemcode,
      wfd.activityalias,
      st.stagename,
      wfd.wfdefid,
      ev.activitystatus,
      ev.userid,
      ev.wfeventid,
      ev.stageiterationcount,
      wos.wfid,
	    du.duid,
      wo.workorderid,
	    cust.customerid,
		  wf.wfid,
      incomingdetails.woincomingfileid ORDER BY ev.wfeventid asc
    `;

    const tableData = await query(queryText, [
      workorderId,
      stageid,
      activityid,
    ]);

    res.json(tableData);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const {
      newStatus,
      wfeventid,
      activitytype,
      wfid,
      // activity,
      workorderid,
      wfdefid,
      duid,
      duname,
      customerid,
      customername,
      stageid,
      stage,
      stageiterationcount,
      title,
      itemcode,
      activityname,
      activityid,
      activityiterationcount,
      // actualiterationcount,
      woincomingfileid,
      journalacronym,
      isgraphic,
      fileid,
      actualactivitycount,
      defconfig,
      fileconfig,
      category,
      nextactivityid,
      config: configData,
    } = req.body;

    const updateQuery = `
      UPDATE public.wms_workflow_eventlog
      SET activitystatus = $1
      WHERE wfeventid = $2
      RETURNING *;
    `;
    const result = await query(updateQuery, [newStatus, wfeventid]);

    if (
      (activitytype == 'External Task' && newStatus === 'Unassigned') ||
      newStatus === 'Work in progress'
    ) {
      const payload = {
        wfId: wfid,
        workorderId: workorderid,
        stageId: stageid,
        stageIteration: stageiterationcount,
        // topicName: activity,
        // isCamundaFlow: false,
        type: activitytype,
        journalAcronym: journalacronym,
        wfdefId: wfdefid,
        fileId: woincomingfileid,
        wfeventId: wfeventid,
        customer: { name: customername, id: customerid },
        du: { name: duname, id: duid },
        job: { name: title, id: itemcode },
        stage: { name: stage, id: stageid, iteration: stageiterationcount },
        activity: {
          name: activityname,
          id: activityid,
          iteration: activityiterationcount,
          activityAlias: activityname,
          actualIteration: actualactivitycount,
        },
        serviceId: '1',
        actionFlow: 'next',
        currentActivityId: '403',
        activityId: activityid,
        woIncomingFileId: woincomingfileid,
        filetypeSkip: null,
        pdfless: null,
        indexcorrectionid: undefined,
        service: {
          name: 'Typesetting',
          id: '1',
        },
        date: {
          // need to put current date
          plannedStart: new Date().toISOString(),
          plannedEnd: new Date().toISOString(),
          orderMail: new Date().toISOString(),
        },
        skillId: '1',
        wf: {
          defId: wfdefid,
          incomingFlows: [],
          defConfig: defconfig,
          configData,
          fileConfig: fileconfig,
          instanceType: 'Single',
          category,
          eventId: wfeventid,
          wfId: wfid,
          activityModelTypeFlow: null,
        },
        nextActivityId: nextactivityid,
        topicName: null,
        isCTActivity: false,
        isDespatchActivity: false,
        // woType need to take from the db
        woType: 'Journal',
        isDirectFirstProof: false,
        logoid: 2,
        activityType: activitytype,
        isBookCompleted: true,
        assignedby: null,
        pubconfig: [],
        IssuemstId: [],
        ismscompleted: [],
        filesInfo: [],
        fileuuid: 'local',
        fileTypeId: fileid,
        isGraphic: isgraphic,
        dmsType: 'local',
      };
      await triggerEngineProcess(payload);
      console.log('<<<payload>>>', payload);
    }

    if (result.length > 0) {
      res
        .status(200)
        .json({ success: true, message: 'Status updated successfully' });
    } else {
      res.status(404).json({ success: false, message: 'Record not found' });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating status',
      error: error.message,
    });
  }
};

export const logDynamicJobConfigAudit = async (req, res) => {
  try {
    const {
      workorderid,
      stageid,
      activityid,
      laststatus,
      currentstatus,
      systeminfo,
      userid,
      customerid,
      duid,
    } = req.body;

    const sql = `
      INSERT INTO public.wms_dynamic_jobconfig_audit
      (workorderid, stageid, activityid, laststatus, currentstatus, systeminfo, userid, updatedon, customerid, duid)
      VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP, $8, $9)
      RETURNING jobconfigid;
    `;

    const values = [
      workorderid,
      stageid,
      activityid,
      laststatus,
      currentstatus,
      systeminfo,
      userid,
      customerid,
      duid,
    ];

    const result = await query(sql, values);

    res.status(200).json({
      message: 'Activity logged successfully',
      jobconfigid: result[0].jobconfigid,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: 'Error logging activity', error: error.message });
  }
};

export const getNLPMasterData = async (req, res) => {
  try {
    const sql = `SELECT DISTINCT  omd.duname, omc.customername,omc.customerid,wml.languageid,
    wof.wfname,wof.wfid,lv.configid,pmj.journalname,pmj.journalid,omd.duid, wml.languagename, lv.languagevariant, lv.isapicheck,lv.isactive ,lv.created_by
FROM public.mst_language_variant AS lv
LEFT JOIN org_mst_customer AS omc ON lv.customerid = omc.customerid
LEFT JOIN pp_mst_journal AS pmj ON lv.journalid = pmj.journalid
LEFT JOIN wms_mst_language AS wml ON lv.languageid = wml.languageid
LEFT JOIN wms_workflow AS wof ON lv.wfid = wof.wfid
LEFT JOIN public.org_mst_deliveryunit AS omd ON lv.duid = omd.duid order by lv.configid desc`;

    const data = await query(sql);
    console.log(data);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const saveLanguageVariant = async (req, res) => {
  try {
    const {
      type,
      customer,
      workflow,
      languages,
      languageVariant,
      apicheck,
      nlpstatus,
      createdBy,
      configid,
    } = req.body;

    let sql;
    let values;

    if (type === 'create') {
      sql = `
              INSERT INTO public.mst_language_variant (customerid, wfid, languageid, languagevariant, isapicheck, isactive, created_by)
              VALUES ($1, $2, $3, $4, $5, $6, $7)
              RETURNING *;
          `;
      values = [
        customer,
        workflow,
        languages,
        languageVariant,
        apicheck || false,
        nlpstatus || false,
        createdBy,
      ];
    } else if (type === 'update') {
      sql = `
              UPDATE public.mst_language_variant
              SET wfid = $2, languageid = $3, languagevariant = $4, isapicheck = $5, isactive = $6, created_by = $7
              WHERE customerid = $1 and configid = $8
              RETURNING *;
          `;
      values = [
        customer,
        workflow,
        languages,
        languageVariant,
        apicheck || false,
        nlpstatus || false,
        createdBy,
        configid,
      ];
    } else {
      res.status(400).json({ error: 'Invalid type specified' });
    }

    const data = await query(sql, values);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const deleteLanguageVariant = async (req, res) => {
  const { configid } = req.body;
  try {
    const sql1 = `SELECT count(*) AS count FROM mst_language_variant WHERE configid = ${configid}`;
    const checkCount = await query(sql1);

    if (checkCount && checkCount[0].count > 0) {
      const sql = `DELETE FROM mst_language_variant WHERE configid = ${configid}`;
      await query(sql);
      res.status(200).json({ success: true });
    } else {
      res.status(404).json({
        success: false,
        message: 'No records found with the given configid',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'An error occurred',
      error: error.message,
    });
  }
};

export const getNLPScoreData = async (req, res) => {
  try {
    const sql = `SELECT DISTINCT omc.customername,omc.customerid,omd.duname,omd.duid,wo.itemcode,wo.workorderid,ml.languagename,ml.languageid,wno.action as email,wno.notificationid,
    wof.wfname,wof.wfid,ms.stagename,ms.stageid,ma.activityname,ma.activityid,ns.nlpscoreid,
ams.stagename as scoreAstagename,ams.stageid as scoreAstageid,
ama.activityname as scoreAactivityname,ama.activityid as scoreAactivityid,
bms.stagename as scoreBstagename,bms.stageid as scoreBstageid,
bma.activityname as scoreBactivityname,bma.activityid as scoreBactivityid,
cms.stagename as scoreCstagename,cms.stageid as scoreCstageid,
cma.activityname as scoreCactivityname,cma.activityid as scoreCactivityid,
ns.is_score_check as isscorecheck,ns.is_file as isfile,ns.file_details,ns.supporting_files,
ns.isactive,ns.email_check as isemailcheck FROM mst_nlpscore AS ns
LEFT JOIN org_mst_customer AS omc ON ns.customerid = omc.customerid
LEFT JOIN wms_workorder AS wo ON ns.workorderid = wo.workorderid
LEFT JOIN wms_mst_stage AS ms ON ns.stageid = ms.stageid
LEFT JOIN wms_mst_activity AS ma ON ns.activityid = ma.activityid 
LEFT JOIN wms_mst_language AS ml ON ns.languageid = ml.languageid
LEFT JOIN wms_mst_stage AS ams ON ns.score_a_stage_id = ams.stageid
LEFT JOIN wms_mst_activity AS ama ON ns.score_a_activity_id = ama.activityid
LEFT JOIN wms_mst_stage AS bms ON ns.score_b_stage_id = bms.stageid
LEFT JOIN wms_mst_activity AS bma ON ns.score_b_activity_id = bma.activityid
LEFT JOIN wms_mst_stage AS cms ON ns.score_c_stage_id = cms.stageid
LEFT JOIN wms_mst_activity AS cma ON ns.score_c_activity_id = cma.activityid
LEFT JOIN wms_notifications AS wno ON ns.email_type = wno.notificationid
LEFT JOIN wms_workflow AS wof ON ns.wfid = wof.wfid
LEFT JOIN public.org_mst_deliveryunit AS omd ON ns.duid = omd.duid order by ns.nlpscoreid desc `;

    const data = await query(sql);
    console.log(data);

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const saveNlpScoreWiseActivity = async (req, res) => {
  try {
    const {
      type,
      customer,
      workflow,
      languages,
      stage,
      activity,
      scoreAstage,
      scoreAactivity,
      scoreBstage,
      scoreBactivity,
      scoreCstage,
      scoreCactivity,
      ScoreCheck,
      EmailCheck,
      EmailType,
      file,
      nlpstatus,
      createdBy,
      nlpscoreid,
    } = req.body;
    let sql;
    let values;
    if (type === 'create') {
      sql = `
              INSERT INTO public.mst_nlpscore (customerid,wfid,languageid,stageid,activityid,score_a_stage_id,
              score_a_activity_id,score_b_stage_id,score_b_activity_id,score_c_stage_id,score_c_activity_id,
              is_score_check,email_check,email_type,is_file,isactive, created_by)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8 ,$9, $10, $11, $12, $13, $14, $15, $16,$17)
              RETURNING *;
          `;
      values = [
        customer,
        workflow,
        languages,
        stage,
        activity,
        scoreAstage || null,
        scoreAactivity || null,
        scoreBstage || null,
        scoreBactivity || null,
        scoreCstage || null,
        scoreCactivity || null,
        ScoreCheck || false,
        EmailCheck || false,
        EmailType || null,
        file || false,
        nlpstatus || false,
        createdBy,
      ];
    } else if (type === 'update') {
      sql = `
              UPDATE public.mst_nlpscore
              SET wfid = $2,languageid = $3,stageid = $4,activityid = $5,score_a_stage_id = $6,score_a_activity_id = $7,
              score_b_stage_id = $8, score_b_activity_id = $9, score_c_stage_id = $10, score_c_activity_id = $11, is_score_check = $12,email_check = $13,
              email_type = $14, is_file = $15, isactive = $16, created_by = $17
              WHERE customerid = $1 and nlpscoreid = $18
              RETURNING *;
          `;
      values = [
        customer,
        workflow,
        languages,
        stage,
        activity,
        scoreAstage || null,
        scoreAactivity || null,
        scoreBstage || null,
        scoreBactivity || null,
        scoreCstage || null,
        scoreCactivity || null,
        ScoreCheck || false,
        EmailCheck || false,
        EmailType || null,
        file || false,
        nlpstatus || false,
        createdBy,
        nlpscoreid,
      ];
    } else {
      res.status(400).json({ error: 'Invalid type specified' });
    }

    const data = await query(sql, values);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const deleteNlpScoreWiseActivity = async (req, res) => {
  const { nlpscoreid } = req.body;
  try {
    const sql1 = `SELECT count(*) AS count FROM mst_nlpscore WHERE nlpscoreid = ${nlpscoreid}`;
    const checkCount = await query(sql1);

    if (checkCount && checkCount[0].count > 0) {
      const sql = `DELETE FROM mst_nlpscore WHERE nlpscoreid = ${nlpscoreid}`;
      await query(sql);
      res.status(200).json({ success: true });
    } else {
      res.status(404).json({
        success: false,
        message: 'No records found with the given nlpscoreid',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'An error occurred',
      error: error.message,
    });
  }
};

// Email Template Controller
export const getFromFieldValues = async (req, res) => {
  try {
    const result = await fromFieldDropdownService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getToFieldValues = async (req, res) => {
  try {
    const result = await toFieldDropdownService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCcFieldValues = async (req, res) => {
  try {
    const result = await ccFieldDropdownService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getBccFieldValues = async (req, res) => {
  try {
    const result = await bccFieldDropdownService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const editEmailTemplateController = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await editEmailTemplateService(id);
    if (result) {
      res.status(200).send(result);
    } else {
      res.status(404).send({ message: 'Email template not found' });
    }
  } catch (error) {
    res.status(500).send({ error, message: error?.message });
  }
};

export const getAllEmailTemplateController = async (req, res) => {
  try {
    const result = await getAllEmailTemplatesService();
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const createEmailTemplateController = async (req, res) => {
  try {
    const templateData = req.body;
    const result = await createEmailTemplateService(templateData);
    res.status(201).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateEmailTemplateController = async (req, res) => {
  try {
    const templateData = req.body;
    const { id } = req.params;
    const result = await updateEmailTemplateService(id, templateData);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Email Template Service

export const fromFieldDropdownService = async () => {
  return getEmailFieldValues(fromFieldScript());
};

export const toFieldDropdownService = async () => {
  return getEmailFieldValues(toFieldScript());
};

export const ccFieldDropdownService = async () => {
  return getEmailFieldValues(ccFieldScript());
};

export const bccFieldDropdownService = async () => {
  return getEmailFieldValues(bccFieldScript());
};

const getEmailFieldValues = async script => {
  try {
    const result = await query(script);
    const placeholdersResult = await query(emailPlaceholdersScript());

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    const extractEmailIds = emailData => {
      let emails = [];
      if (typeof emailData === 'string') {
        try {
          const parsedData = JSON.parse(emailData);
          if (Array.isArray(parsedData)) {
            emails = parsedData;
          } else {
            emails.push(parsedData);
          }
        } catch {
          emails.push(emailData);
        }
      } else if (Array.isArray(emailData)) {
        emails = emailData;
      } else {
        emails.push(emailData);
      }
      return emails;
    };

    const allEmails = result.flatMap(row => extractEmailIds(row.email_field));
    const validEmails = allEmails.filter(email => emailRegex.test(email));
    const placeholders = placeholdersResult.map(row => row.emailplaceholder);
    const combinedEmails = [...placeholders, ...validEmails];

    return {
      combinedEmails,
    };
  } catch (error) {
    console.error('Error in getEmailFieldValues:', error);
    throw new Error('Error while fetching email addresses');
  }
};

export const editEmailTemplateService = async id => {
  try {
    const script = editEmailTemplateScript();
    const values = [id];
    const result = await query(script, values);
    return result[0];
  } catch (error) {
    console.error('Error in getEmailTemplateService:', error);
    throw new Error('Error while fetching email template');
  }
};

export const getAllEmailTemplatesService = async () => {
  try {
    const data = {
      content: 'XXXX',
    };
    const script = getAllEmailTemplates();
    const resForConfig = await query(script);

    if (resForConfig && resForConfig.length > 0) {
      const result = resForConfig
        .map(item => {
          if (item.notificationconfig && item.notificationconfig.template) {
            const replacedTemplate = item.notificationconfig.template
              .replace(/<%= data.reportingToName %>/g, data.content)
              .replace(/<%= data.quarter %>/g, data.content)
              .replace(/<%= data.month %>/g, data.content)
              .replace(/<%= data.year %>/g, data.content)
              .replace(/<%= data.Date %>/g, data.content);
            item.notificationconfig.template = replacedTemplate;
            return item;
          }
          return null;
        })
        .filter(item => item !== null);
      return result;
    }
    return [];
  } catch (error) {
    console.error('Error in getAllEmailTemplatesService:', error);
    return [];
  }
};

export const createEmailTemplateService = async templateData => {
  try {
    const {
      entityid,
      action,
      notificationconfig,
      type,
      isactive,
      templatename,
      templatedescription,
    } = templateData;

    const script = createEmailTemplateScript();
    const values = [
      entityid,
      action,
      notificationconfig,
      type,
      isactive,
      templatename,
      templatedescription,
    ];

    const result = await query(script, values);
    return result;
  } catch (error) {
    throw new Error('Error while creating email template');
  }
};

export const updateEmailTemplateService = async (id, templateData) => {
  try {
    const {
      entityid,
      action,
      notificationconfig,
      type,
      isactive,
      templatename,
      templatedescription,
    } = templateData;

    const script = updateEmailTemplateScript();

    const values = [
      entityid,
      action,
      notificationconfig,
      type,
      isactive,
      templatename,
      templatedescription,
      id,
    ];

    const result = await query(script, values);
    return result;
  } catch (error) {
    console.error('Error in updateEmailTemplateService:', error);
    throw new Error('Error while Updating email template');
  }
};

// Email Template Scripts

export const fromFieldScript = () => `
  SELECT DISTINCT (notificationconfig->>'from') AS email_field
  FROM wms_notifications
  WHERE notificationconfig->>'from' IS NOT NULL;
`;

export const toFieldScript = () => `
  SELECT DISTINCT (notificationconfig->>'to') AS email_field
  FROM wms_notifications
  WHERE notificationconfig->>'to' IS NOT NULL;
`;

export const ccFieldScript = () => `
  SELECT DISTINCT (notificationconfig->>'cc') AS email_field
  FROM wms_notifications
  WHERE notificationconfig->>'cc' IS NOT NULL;
`;

export const bccFieldScript = () => `
  SELECT DISTINCT (notificationconfig->>'bcc') AS email_field
  FROM wms_notifications
  WHERE notificationconfig->>'bcc' IS NOT NULL;
`;

export const emailPlaceholdersScript = () => `
  SELECT emailplaceholder
  FROM wms_mst_emailplaceholders
  WHERE emailplaceholder IS NOT NULL;
`;

export const editEmailTemplateScript = () => {
  const script = `
    SELECT * FROM wms_notifications
    WHERE notificationid = \$1;
  `;
  return script;
};

export const getAllEmailTemplates = () => {
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY notificationid) AS serial,* FROM wms_notifications 
  WHERE isactive = TRUE;`;
  return script;
};

export const createEmailTemplateScript = () => {
  const script = `
    INSERT INTO wms_notifications (
      entityid,
      action,
      notificationconfig,
      type,
      isactive,
      templatename,
      templatedescription
    ) VALUES (
      \$1, -- entityid
      \$2, -- action
      \$3, -- notificationconfig
      \$4, -- type
      \$5, -- isactive
      \$6, -- templatename
      \$7  -- templatedescription
    ) RETURNING *;
  `;
  return script;
};

export const updateEmailTemplateScript = () => {
  const script = `
    UPDATE wms_notifications SET
      entityid = \$1,
      action = \$2,
      notificationconfig = \$3,
      type = \$4,
      isactive = \$5,
      templatename = \$6,
      templatedescription = \$7
    WHERE notificationid = \$8
    RETURNING *;
  `;
  return script;
};

// issue filetype master
export const getFileTypeMst = (req, res) => {
  const sql = `select pmf.filetypeid, pmf.filetype, pmfd.detailid as subfiletypeid, pmfd.description as subfiletype from pp_mst_filetype pmf 
               left join pp_mst_filetype_details pmfd on pmfd.filetypeid = pmf.filetypeid 
               where pmf.category = '${req.params.category}'`;

  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};
