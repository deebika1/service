/* eslint-disable class-methods-use-this */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import axios from 'axios';
import crypto from 'crypto';
import { config } from '../config/restApi.js';
import { fileTypeFromBuffer } from 'file-type';
import mime from 'mime-types';
import { v4 as uuidv4 } from 'uuid';
import { isValidiTracksUrl } from '../helper/validator.js';
export class Service {
  // eslint-disable-next-line no-useless-constructor, no-empty-function
  constructor() {}

  post(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'POST',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({
            status: true,
            data: response.data,
            statusCode: response.status,
          });
        })
        .catch(err => {
          console.log(err, 'errr post method');
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  uploadPost(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'POST',
        url,
        data: reqData,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
          'Access-Control-Allow-Origin': true,
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          console.log(err, 'errr post method');
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  put(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'PUT',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  get(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'GET',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  delete(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'DELETE',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  invokeService(conf) {
    return new Promise((resolve, reject) => {
      axios(conf)
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          reject({
            status: false,
            message:
              err.response && err.response.data && err.response.data.message
                ? err.response.data.message
                : err.response.statusText
                ? err.response.statusText
                : err.message,
          });
        });
    });
  }

  upload(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'POST',
        url,
        data: reqData,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        maxRedirects: 0,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve(response.data);
        })
        .catch(err => {
          const message = err.response?.data?.message
            ? err.response.data.message
            : err.response?.data
            ? err.response.data
            : err.message;
          reject({ status: false, message, additionalInfo: { url } });
        });
    });
  }

  // iTracks post
  iPost(url, reqData, additionalHeaders = {}) {
    return new Promise(async (resolve, reject) => {
      try {
        const gerUrl = await axios.get(config.iTracks.switch_url).catch(() => {
          reject({
            status: false,
            message: 'Unable to reach the ipswitch server.',
          });
        });

        if (!gerUrl?.data || !isValidiTracksUrl(gerUrl.data)) {
          reject({
            status: false,
            message: 'Unable to fetch the iTracks URL (ipswitch).',
          });
        }
        console.log(gerUrl.data, 'gerUrl');
        console.log(
          `https://${gerUrl.data}/${config.iTracks.service_url}`,
          'constructed url',
        );

        await axios({
          method: 'POST',
          url: `https://${gerUrl.data}/${config.iTracks.service_url}`,
          data: reqData,
          headers: {
            'Access-Control-Allow-Origin': true,
            'Content-Type': 'application/json',
            Accept: 'application/json',
            ...additionalHeaders,
          },
          timeout: 150000,
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(err => {
            console.log(err, 'errr');
            reject({
              status: false,
              message: err.response ? err.response : err.message,
            });
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }

  // e2e api call post method

  e2ePost(url, reqData, additionalHeaders = {}) {
    return new Promise(async (resolve, reject) => {
      try {
        axios({
          method: 'POST',
          url,
          data: reqData,
          headers: {
            'Access-Control-Allow-Origin': true,
            'Content-Type': 'application/json',
            Accept: 'application/json',
            ...additionalHeaders,
          },
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(err => {
            console.log(err, 'errr');
            reject({
              status: false,
              message: err.response ? err.response : err.message,
            });
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }

  //Els PbTask

  pbTaskPost(url, reqData, additionalHeaders = {}) {
    return new Promise(async (resolve, reject) => {
      try {
        axios({
          method: 'POST',
          url,
          data: reqData,
          headers: {
            Authorization: `Bearer ${config.iftp.iftp_token}`,
            'Content-Type': 'application/json',
          },
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(err => {
            console.log(err, 'errr');
            reject({
              status: false,
              message: err.response ? err.response : err.message,
            });
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }

  // iAlt module
  ialtPost(
    url,
    reqData,
    additionalHeaders = {},
    dbusername = '',
    dbpassword = '',
  ) {
    return new Promise(async (resolve, reject) => {
      try {
        axios({
          method: 'POST',
          url,
          data: reqData,
          headers: {
            'Access-Control-Allow-Origin': true,
            'Content-type': 'application/ld+json',
            ...additionalHeaders,
          },
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(async err => {
            if (err.response && err.response.status === 401) {
              const authHeaderDigest = await this.getauthHeaderDigest(
                url,
                'POST',
                err,
                dbusername,
                dbpassword,
              );
              console.log(authHeaderDigest, 'authHeaderDigest');
              axios({
                method: 'POST',
                url,
                data: reqData,
                headers: {
                  'Access-Control-Allow-Origin': true,
                  'Content-type': 'application/ld+json',
                  Authorization: authHeaderDigest,
                },
              })
                .then(response2 => {
                  resolve(response2);
                })
                .catch(error => {
                  reject({
                    status: false,
                    message: error.response ? error.response : error.message,
                  });
                });
            } else {
              reject({
                status: false,
                message: err.response ? err.response : err.message,
              });
            }
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }

  ialtGet(url, additionalHeaders = {}) {
    return new Promise(async (resolve, reject) => {
      try {
        axios({
          method: 'GET',
          url,
          headers: {
            'Access-Control-Allow-Origin': true,
            'Content-type': 'application/ld+json',
            ...additionalHeaders,
          },
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(async err => {
            if (err.response && err.response.status === 401) {
              const authHeaderDigest = await this.getauthHeaderDigest(
                url,
                'GET',
                err,
              );
              axios({
                method: 'GET',
                url,
                headers: {
                  'Access-Control-Allow-Origin': true,
                  'Content-type': 'application/ld+json',
                  Authorization: authHeaderDigest,
                  ...additionalHeaders,
                },
              })
                .then(response2 => {
                  resolve(response2.data);
                })
                .catch(error => {
                  reject({
                    status: false,
                    message: error.response ? error.response : error.message,
                  });
                });
            } else {
              reject({
                status: false,
                message: err.response ? err.response : err.message,
              });
            }
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }
  ialtGetWithBlob(url, additionalHeaders = {}, fileName = '') {
    return new Promise(async (resolve, reject) => {
      try {
        axios({
          method: 'GET',
          url,
          headers: {
            'Access-Control-Allow-Origin': true,
            'Content-type': 'application/ld+json',
            ...additionalHeaders,
          },
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(async err => {
            if (err.response && err.response.status === 401) {
              const authHeaderDigest = await this.getauthHeaderDigest(
                url,
                'GET',
                err,
              );
              return axios({
                method: 'GET',
                url,
                responseType: 'arraybuffer', // Get response as a buffer
                headers: {
                  'Access-Control-Allow-Origin': '*',
                  'Content-Type': 'application/ld+json',
                  Authorization: authHeaderDigest,
                },
              })
                .then(async response => {
                  let filename = '';
                  const type = await fileTypeFromBuffer(response.data);
                  let extension = type ? type.ext : 'bin';
                  let contentType = type ? type.mime : '';
                  if (fileName && fileName.includes('.')) {
                    filename = `${fileName}`;
                  } else {
                    const match = url.match(/\/egi\/([A-Za-z0-9]+)\?/);
                    if (!fileName) {
                      if (match && match[1]) {
                        filename = `${match[1]}.${extension}`;
                      } else {
                        filename = `${uuidv4()}.${extension}`;
                      }
                    } else {
                      filename = `${fileName}.${extension}`;
                    }
                  }

                  resolve({ data: response.data, filename, contentType });
                })
                .catch(error => {
                  console.error('Error fetching file:', error);
                  throw error;
                });
            } else {
              reject({
                status: false,
                message: err.response ? err.response : err.message,
              });
            }
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }

  async getauthHeaderDigest(
    url,
    method,
    error,
    dbusername = '',
    dbpassword = '',
  ) {
    const username = dbusername ? dbusername : process.env.ELSEVIER_USERNAME;
    const password = dbpassword ? dbpassword : process.env.ELSEVIER_PASSWORD;

    // Parse the WWW-Authenticate header for digest info
    const authHeader = error.response.headers['www-authenticate'];
    const realm = /realm="([^"]+)"/.exec(authHeader)[1];
    const nonce = /nonce="([^"]+)"/.exec(authHeader)[1];
    const qop = /qop="([^"]+)"/.exec(authHeader)[1];
    // const algorithm = /algorithm="([^"]+)"/.exec(authHeader)[1];
    const cnonce = crypto.randomBytes(16).toString('hex'); // Generate a random cnonce
    const nc = '00000001'; // Nonce count
    const uri = '/upload?promote=false'; //new URL(url).pathname;

    // Generate HA1
    const HA1 = crypto
      .createHash('md5')
      .update(`${username}:${realm}:${password}`)
      .digest('hex');

    // Generate HA2
    const HA2 = crypto
      .createHash('md5')
      .update(`${method}:${uri}`)
      .digest('hex');

    // Generate response
    const responseDigest = crypto
      .createHash('md5')
      .update(`${HA1}:${nonce}:${nc}:${cnonce}:${qop}:${HA2}`)
      .digest('hex');

    // Construct Authorization header
    const authHeaderDigest = `Digest username="${username}", realm="${realm}", nonce="${nonce}", uri="/upload?promote=false", qop=${qop}, nc=00000001, cnonce="${cnonce}", response="${responseDigest}", algorithm="MD5"`;
    console.log(authHeaderDigest, 'authHeaderDigest');
    return authHeaderDigest;
  }

  journalGetWithBlob(url, additionalHeaders = {}, fileName = '') {
    return new Promise(async (resolve, reject) => {
      try {
        axios({
          method: 'GET',
          url,
          headers: {
            'Access-Control-Allow-Origin': true,
            'Content-type': 'application/ld+json',
            ...additionalHeaders,
          },
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(async err => {
            if (err.response && err.response.status === 401) {
              const authHeaderDigest = await this.journalGetauthHeaderDigest(
                url,
                'GET',
                err,
              );
              return axios({
                method: 'GET',
                url,
                responseType: 'arraybuffer', // Get response as a buffer
                headers: {
                  'Access-Control-Allow-Origin': '*',
                  'Content-Type': 'application/ld+json',
                  Authorization: authHeaderDigest,
                },
              })
                .then(async response => {
                  let filename = '';
                  const type = await fileTypeFromBuffer(response.data);
                  let extension = type ? type.ext : 'bin';
                  let contentType = type ? type.mime : '';
                  if (fileName && fileName.includes('.')) {
                    filename = `${fileName}`;
                  } else {
                    const match = url.match(/\/egi\/([A-Za-z0-9]+)\?/);
                    if (!fileName) {
                      if (match && match[1]) {
                        filename = `${match[1]}.${extension}`;
                      } else {
                        filename = `${uuidv4()}.${extension}`;
                      }
                    } else {
                      filename = `${fileName}.${extension}`;
                    }
                  }

                  resolve({ data: response.data, filename, contentType });
                })
                .catch(error => {
                  console.error('Error fetching file:', error);
                  throw error;
                });
            } else {
              reject({
                status: false,
                message: err.response ? err.response : err.message,
              });
            }
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }

  async journalGetauthHeaderDigest(
    url,
    method,
    error,
    dbusername = '',
    dbpassword = '',
  ) {
    const username = dbusername
      ? dbusername
      : process.env.ELSEVIER_USERNAME_JOURNAL;
    const password = dbpassword
      ? dbpassword
      : process.env.ELSEVIER_PASSWORD_JOURNAL;

    // Parse the WWW-Authenticate header for digest info
    const authHeader = error.response.headers['www-authenticate'];
    const realm = /realm="([^"]+)"/.exec(authHeader)[1];
    const nonce = /nonce="([^"]+)"/.exec(authHeader)[1];
    const qop = /qop="([^"]+)"/.exec(authHeader)[1];
    // const algorithm = /algorithm="([^"]+)"/.exec(authHeader)[1];
    const cnonce = crypto.randomBytes(16).toString('hex'); // Generate a random cnonce
    const nc = '00000001'; // Nonce count
    const uri = '/upload?promote=false'; //new URL(url).pathname;

    // Generate HA1
    const HA1 = crypto
      .createHash('md5')
      .update(`${username}:${realm}:${password}`)
      .digest('hex');

    // Generate HA2
    const HA2 = crypto
      .createHash('md5')
      .update(`${method}:${uri}`)
      .digest('hex');

    // Generate response
    const responseDigest = crypto
      .createHash('md5')
      .update(`${HA1}:${nonce}:${nc}:${cnonce}:${qop}:${HA2}`)
      .digest('hex');

    // Construct Authorization header
    const authHeaderDigest = `Digest username="${username}", realm="${realm}", nonce="${nonce}", uri="/upload?promote=false", qop=${qop}, nc=00000001, cnonce="${cnonce}", response="${responseDigest}", algorithm="MD5"`;

    return authHeaderDigest;
  }
}
