import qs from 'qs';
import FormData from 'form-data';

const getQueryParams = queryList => {
  const queryObj = {};
  queryList.forEach(query => {
    queryObj[query.key] = query.value;
  });
  return qs.stringify(queryObj);
};

const getURLEncodedFormData = formList => {
  const formObj = {};
  formList.forEach(form => {
    formObj[form.key] = form.value;
  });
  return qs.stringify(formObj);
};

const getFormData = formList => {
  const data = new FormData();
  formList.forEach(form => {
    data.append(form.key, form.value);
  });
  return data;
};

const getFormattedQueryURL = (url, input) => {
  const { query } = input;
  const params = query && query.length ? getQueryParams(query) : '';
  return `${url || ''}${params ? `?${params}` : ''}`;
};

const getBasicAuth = auth => {
  const authHeader = {};
  if (auth.details && auth.details.username && auth.details.password) {
    const authCred = Buffer.from(
      `${auth.details.username}:${auth.details.password}`,
    ).toString('base64');
    authHeader.Authorization = `Basic ${authCred}`;
  } else {
    console.log(`Mandatory fields missing (basic auth)`);
  }
  return authHeader;
};

const getBearerAuth = auth => {
  const authHeader = {};
  if (auth.details && auth.details.token) {
    authHeader.Authorization = `Bearer ${auth.details.token}`;
  } else {
    console.log(`Mandatory fields missing (bearer auth)`);
  }
  return authHeader;
};

const poulateAuthFields = (auth, config) => {
  let authHeader = {};
  switch (auth.type) {
    case 'basic':
      authHeader = getBasicAuth(auth);
      break;
    case 'bearer':
      authHeader = getBearerAuth(auth);
      break;
    default:
      console.log(`No matching type found (${auth.type})`);
  }
  config.headers = { ...config.headers, ...authHeader };
};

const getHeaders = headerList => {
  const headerObj = {};
  headerList.forEach(header => {
    headerObj[header.key] = header.value;
  });
  return headerObj;
};

const populateInputData = (input, config) => {
  const { formData, urlEncodedFormData, rawData } = input;
  if (rawData) {
    config.data = rawData;
  } else if (urlEncodedFormData && urlEncodedFormData.length) {
    const header = { 'Content-Type': 'application/x-www-form-urlencoded' };
    config.data = getURLEncodedFormData(urlEncodedFormData);
    config.headers = { ...config.headers, ...header };
  } else if (formData && formData.length) {
    config.data = getFormData(formData);
    config.headers = { ...config.headers, ...config.data.getHeaders() };
  } else {
    config.data = {};
    console.log(`No matching input fields found`);
  }
};

export const buildConfig = httpConfig => {
  const { url, method, auth, headers, input } = httpConfig;
  const config = {};
  config.url = input ? getFormattedQueryURL(url, input) : url || '';
  config.method = method || 'post';
  config.headers = headers && headers.length ? getHeaders(headers) : {};
  if (auth) poulateAuthFields(auth, config);
  if (input) populateInputData(input, config);
  return config;
};
