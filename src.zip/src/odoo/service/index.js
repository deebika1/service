import axios from 'axios';
import FormData from 'form-data';
import mime from 'mime-types';
import { query } from '../../database/postgres.js';
import {
  createInvoiceQueueDetails,
  createJobData,
  createServiceDetails,
  preparejson,
} from '../helpers/payloadCreation.js';
import { cupBussinessLogic } from '../customerLogics/cupLogic.js';
import {
  getUBRFailureReportSrcipt,
  getInvoiceOdooReportScript,
} from '../datalayer/report.js';
import { generateOdooInvoicePayload } from '../helpers/invoiceForOdoo.js';
import { odooEndPoints } from '../helpers/odooApiEndpoints.js';
import {
  approveRFIScript,
  getOdooPayloadScript,
  getRFIFilePathScript,
  getRFIStatusScript,
  // insertRFIAttachmentsScript,
  rejectRFIScript,
  updateOdooAttachmentDataScript,
  // updateRFIAttachmentsScript,
} from '../../salesPMO/datalayer/rfiScripts.js';
import { RejectionWorkflowMailService } from '../../salesPMO/service/rfiServices.js';
import { lockUnlockWorkorderService } from '../../salesPMO/service/index.js';
import { _download } from '../../modules/utils/azure/index.js';
// import { InvoiceRootSchema } from '../helpers/validation.js';

export function safeStringify(obj) {
  const seen = new WeakSet();
  return JSON.stringify(obj, (key, value) => {
    if (typeof value === 'object' && value !== null) {
      if (seen.has(value)) {
        return; // Circular reference found, discard key
      }
      seen.add(value);
    }
    // eslint-disable-next-line consistent-return
    return value;
  });
}

export const welcome = () => {
  return new Promise((resolve, reject) => {
    try {
      resolve('odoo welcomeController');
    } catch (error) {
      reject(error);
    }
  });
};

export const invoiceIntegrationService = input => {
  return new Promise(async (resolve, reject) => {
    try {
      const { journalId, workorderId, stageId } = input;

      // Insert if the record doesn't exist
      const iqry = `
        INSERT INTO salespmo.trn_rfi_jobs (journalid, workorderid, stageid)
        SELECT $1, $2, $3
        WHERE NOT EXISTS (
          SELECT 1 FROM salespmo.trn_rfi_jobs WHERE workorderid = $2 AND stageid = $3
        )
        RETURNING rfijobid;
      `;

      const insdata = await query(iqry, [journalId, workorderId, stageId]);

      if (insdata.length > 0) {
        resolve({ status: true, msg: 'success' });
      } else {
        resolve({ status: true, msg: 'Duplicate entry in invoice table' });
      }
    } catch (error) {
      reject({ status: false, msg: error.message });
    }
  });
};

export const authenticateOddoService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const authPayload = odooEndPoints.server.getAuthPayload();
      const authUrl =
        odooEndPoints.server.getOdooUrl() + odooEndPoints.auth.authenticate;
      const response = await axios.post(authUrl, authPayload);
      const cookies = response.headers['set-cookie'];
      const sessionCookie = cookies[0].split(';')[0];
      resolve(sessionCookie);
    } catch (error) {
      reject(error);
    }
  });
};

export const odooApiIntegrationService = async (
  path,
  payload,
  contentType = 'application/javascript',
) => {
  return new Promise(async (resolve, reject) => {
    try {
      let resstatus = false;
      const response = await authenticateOddoService();
      // timeout: odooEndPoints.server.timeOut,
      const dataResponse = await axios({
        method: 'POST',
        url: odooEndPoints.server.getOdooUrl() + path,
        data: payload,
        headers: {
          'Content-Type': contentType,
          Cookie: response,
        },
      });
      if (dataResponse.data.status == 'success') {
        resstatus = true;
      }
      resolve({
        data: dataResponse.data,
        status: resstatus,
        message: dataResponse.data.message,
      });
    } catch (error) {
      const msg = error?.response?.data || error?.message;
      const data = error?.response?.data || '';
      reject({ data, status: false, message: msg });
    }
  });
};

export const odooFileSendService = async formData => {
  return new Promise(async (resolve, reject) => {
    try {
      const path = odooEndPoints.api.invoiceAttachment;
      const authCookies = await authenticateOddoService();
      // 1.get rfi id
      const response = await axios.post(
        `${odooEndPoints.server.getOdooUrl() + path}`,
        formData,
        {
          headers: {
            ...formData.getHeaders(),
            // 'Content-Type': 'multipart/form-data',
            Cookie: authCookies,
          },
          maxContentLength: Infinity, // Optionally set this to prevent limits on Axios side
          maxBodyLength: Infinity,
        },
      );
      resolve(response?.data);
    } catch (error) {
      reject(error);
    }
  });
};

const insertlog = async (workorderid, stageid, type) => {
  try {
    const result = await query(
      `insert into salespmo.log_oodointegration(workorderid,stageid,integrationtype)
                values ($1,$2,$3) returning logid`,
      [workorderid, stageid, type],
    );
    const insertedId = +result[0].logid;
    return insertedId;
  } catch (e) {
    return 0;
  }
};

const updatelog = async (
  logid,
  jsonparam,
  oodoresult,
  returnmessage,
  issuccess,
) => {
  return new Promise(async resolve => {
    try {
      await query(
        `update salespmo.log_oodointegration set 
        apiinput = $2,
        responseresult = $3,
        remarks = $4,
        issuccess = $5
        where logid = $1`,
        [logid, jsonparam, oodoresult, returnmessage, issuccess],
      );
      resolve('updated');
    } catch (e) {
      console.log(e.message);
      resolve('failed');
    }
  });
};

export const ubrIntegrationService = async inputobj => {
  const {
    workorderId,
    stageId,
    servicetype,
    woId,
    subjobname,
    subJobId,
    woType = 'journal',
  } = inputobj;

  const wrkid = workorderId || woId;
  let logid;
  let jsonobj;
  let jsonparam = '';
  let returnmessage = '';
  let issuccess = false;
  let oodoresult = '';

  try {
    logid = await insertlog(wrkid, stageId, servicetype);

    // Prepare JSON object based on service type
    jsonobj = await preparejson(
      wrkid,
      stageId,
      servicetype,
      subjobname,
      subJobId,
      woType,
    );

    returnmessage = jsonobj.msg;

    if (jsonobj.msg === 'success') {
      jsonparam = jsonobj.data;

      // Call external API service
      const salesOrderUrl = odooEndPoints.api.saleOrder;
      const returnobj = await odooApiIntegrationService(
        salesOrderUrl,
        jsonparam,
      );

      if (returnobj) {
        returnmessage = returnobj.message;
        issuccess = returnobj.status;
        oodoresult = returnobj;
      }
    }
  } catch (error) {
    returnmessage = error.message;
    issuccess = false;
  }

  // Log final results in finally-equivalent block
  await updatelog(
    logid,
    jsonparam,
    JSON.stringify(oodoresult),
    returnmessage,
    issuccess,
  );

  // Return outside of try/catch/finally
  return { status: issuccess, message: returnmessage };
};

export const updateWoJournalCurrency = async workorderId => {
  try {
    const qry = `WITH ctedata AS 
              (
                SELECT DISTINCT currencyid FROM salespmo.trn_journal_rate WHERE journalid in (
                  SELECT journalid FROM wms_workorder WHERE workorderid = $1 AND currencyid is NULL
                ) LIMIT 1
              )                              
              UPDATE wms_workorder SET currencyid = ce.currencyid 
              FROM ctedata as ce
              WHERE workorderid = $1`;
    await query(qry, [workorderId]);

    return 'success';
  } catch (e) {
    console.log(e);
    return 'failed';
  }
};

export const odooPayloadCreateService = async () => {
  try {
    // handle Business logic here
    await cupBussinessLogic();
    const serviceDetails = await createServiceDetails(
      'Typesetting',
      '240200100.JO.SOLD0.INF1.03501.TYPESETTING',
      'Pages',
      '0.5',
    );
    const jobData = await createJobData(
      ('SOLD_A_1909306',
      '1909306',
      'Finals',
      'Simple',
      'fpm |comp|ce  |T2  |T1  |13  |rg  |pm  |T3 ',
      serviceDetails),
    );
    const invoice = await createInvoiceQueueDetails(
      'TandF',
      'Taylor and Francis',
      'Journal',
      'SOLD',
      'SOLD-Scandinavian Journal of the Old Testament',
      'UK',
      '2021-05-12 00:00:00.000',
      'Shelley Barry',
      'USD',
      'SOLD_35(01)',
      '35',
      '01',
      jobData,
    );
    return invoice;
  } catch (error) {
    return error;
  }
};

export const invoiceQueueStatusService = async input => {
  const resultobj = {
    success: false,
    message: '',
    id: 0,
  };
  const {
    JobCode,
    RFIid,
    Status,
    Reason,
    ActionedBy = 'ODOO',
  } = input.InvoiceStatus[0];
  let quelogid = null;

  try {
    // Log the payload data before any other logic
    // Insert log into salespmo.log_oodoinvoiceque
    const iqry = `
      INSERT INTO salespmo.log_oodoinvoiceque 
      (invoiceid, jobcode, remarks, status, payload) 
      VALUES ($1, $2, $3, $4, $5) 
      RETURNING quelogid`;

    const resdata = await query(iqry, [
      RFIid,
      JobCode,
      Reason,
      Status,
      JSON.stringify(input),
    ]);
    quelogid = resdata[0]?.quelogid;

    // Check if input.InvoiceStatus exists and has elements
    if (!input?.InvoiceStatus?.length) {
      throw new Error('Invalid or missing InvoiceStatus data');
    }
    // Check if reecgted reason exists and has elements
    if (Status === 'Rejected' && (Reason == undefined || Reason == '')) {
      throw new Error('Invalid or missing reject_reason data');
    }
    // Validate required fields
    if (!JobCode || !RFIid || !Status) {
      throw new Error('Missing required fields: JobCode, RFIid, or Status');
    }

    if (RFIid && RFIid?.includes('TandF')) {
      resultobj.success = true;
      resultobj.message = 'The queue status has been successfully retrieved.';
      return resultobj;
    }
    // Fetch RFI ID from the database to check if it exists
    const checkRFIQuery = `SELECT invoiceid FROM salespmo.trn_rfidetails WHERE invoiceid = $1`;
    const rfiCheckResult = await query(checkRFIQuery, [RFIid]);

    if (!rfiCheckResult || rfiCheckResult.length === 0) {
      throw new Error(`RFI ID ${RFIid} does not exist in the database.`);
    }

    // Determine the status code based on the Status value
    const statuscode = Status === 'Accepted' ? 'COMP' : 'REJ';

    // Fetch RFI status script
    const qrystat = getRFIStatusScript();
    const statresult = await query(qrystat, [statuscode]);

    if (!statresult || statresult.length === 0) {
      throw new Error('Failed to fetch RFI status');
    }

    // Choose the appropriate script based on Status
    const script =
      Status === 'Accepted' ? approveRFIScript() : rejectRFIScript();

    if (!resdata || resdata.length === 0) {
      throw new Error('Failed to insert log into queue');
    }

    // Update the remarks on the log table using the log ID if the RFI ID is valid
    const updateLogQuery = `
      UPDATE salespmo.log_oodoinvoiceque 
      SET remarks = $1 
      WHERE quelogid = $2`;

    await query(updateLogQuery, [Reason || 'No remarks provided', quelogid]);
    const values = [RFIid, statresult[0]?.rfistatusid, ActionedBy];
    if (Status == 'Rejected') values.push(Reason);

    // Execute the main script (either approval or rejection based on Status)
    const result = await query(script, values);
    if (Status == 'Rejected') {
      RejectionWorkflowMailService(RFIid, 'Odoo', 'rejection_workflow', 70);
    }
    if (result) {
      resultobj.success = true;
      resultobj.message = 'The queue status has been successfully retrieved.';
      resultobj.id = quelogid;
      return resultobj;
    }

    throw new Error('Failed to execute script');
  } catch (error) {
    // Handle errors with detailed messages
    // In case of an error, update the remarks field in the log with the error message
    if (quelogid) {
      const errorRemarks = `Error: ${
        error.message || 'An unexpected error occurred'
      }`;
      try {
        const updateErrorLogQuery = `
          UPDATE salespmo.log_oodoinvoiceque 
          SET remarks = $1 
          WHERE quelogid = $2`;

        await query(updateErrorLogQuery, [errorRemarks, quelogid]);
      } catch (updateError) {
        console.error('Failed to update error remarks:', updateError);
      }
    }
    resultobj.message = error.message || 'An unexpected error occurred';
    console.error(error); // Log the error details for debugging
    throw resultobj; // Reject the promise with the error result
  }
};

export const invoiceDetailsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // If the payload is valid, extract necessary details
      const getDetails = item => {
        return (
          Object.values(item).find(
            value => Array.isArray(value) && value.length > 0,
          )?.[0] || null
        );
      };
      const data = getDetails(payload);

      // Extract necessary data from the invoiceDetails
      const { RFIid, Customer, DeliveryUnit, InvoiceType, JobCode, InvoiceNo } =
        data;

      // Construct the insert script to log invoice data
      const insertScript = `
        INSERT INTO salespmo.log_odoo_invoice_reply
        (rfid, customer, delivery_unit, invoice_type, bookcode, payload, is_valid, remarks, invoiceno)
        VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9) 
        RETURNING odooinvoicelogid;
      `;

      // Insert the invoice data into the database
      await query(insertScript, [
        RFIid || null,
        Customer || null,
        DeliveryUnit || null,
        InvoiceType || null,
        JobCode || null,
        JSON.stringify(payload), // Store entire details as JSON
        true, // Default to invalid until validation
        '', // Empty remarks until validation
        InvoiceNo,
      ]);

      // Retrieve the `odooinvoicelogid` from the result
      // const { odooinvoicelogid } = result[0];

      // Validate the payload first before proceeding with any database operations
      // const { error } = InvoiceRootSchema.validate(payload);
      // if (error || !invoiceDetails) {
      //   const updateScript = `
      //     UPDATE salespmo.log_odoo_invoice_reply
      //     SET is_valid=$2, remarks=$3
      //     WHERE odooinvoicelogid= $1;
      //   `;
      //   await query(updateScript, [
      //     odooinvoicelogid,
      //     false,
      //     error.details[0]?.message || 'Invalid payload',
      //   ]);

      //   // Reject with an error message
      //   reject({
      //     status: 'error',
      //     message: error.details[0]?.message || 'Invalid payload',
      //     details: error.details[0]?.message,
      //   });
      // } else {
      //   await insert_orderinflowBilling(odooinvoicelogid, JobCode);
      //   if (InvoiceType.toLowerCase() == 'final') {
      //     const isFullyInvoice = `SELECT * FROM salespmo.trn_rfidetails WHERE invoiceid = $1;`;
      //     const invoiceData = await query(isFullyInvoice, [RFIid]);
      //     if (invoiceData[0]?.isfullinvoice) {
      //       const LockJobPayload = {
      //         workorderData: {
      //           workorderid: invoiceData[0]?.workorderid,
      //           itemcode: invoiceData[0]?.itemcode,
      //           islock: 'Unlock',
      //         },
      //         reason: 'The job is fully Billed',
      //         createdBy: 'IS9971',
      //       };
      //       await lockUnlockWorkorderService(LockJobPayload);
      //     }
      //   }
      // }
      if (InvoiceType.toLowerCase() == 'final') {
        const isFullyInvoice = `SELECT * FROM salespmo.trn_rfidetails WHERE invoiceid = $1;`;
        const invoiceData = await query(isFullyInvoice, [RFIid]);
        if (invoiceData[0]?.isfullinvoice) {
          const LockJobPayload = {
            workorderData: {
              workorderid: invoiceData[0]?.workorderid,
              itemcode: invoiceData[0]?.itemcode,
              islock: 'Unlock',
            },
            reason: 'The job is fully Billed',
            createdBy: 'ODOO',
          };
          await lockUnlockWorkorderService(LockJobPayload);
        }
      }

      // If the validation is successful, resolve with a success message
      resolve({
        status: 'success',
        message: 'The invoice details have been successfully logged.',
      });
    } catch (err) {
      // Catch unexpected errors and reject with the error message
      reject({
        status: 'error',
        message: `An error occurred: ${err.message}`,
      });
    }
  });
};

export const insert_orderinflowBilling = async (odooinvoicelogid, JobCode) => {
  try {
    const qry = `
        WITH wodata AS (
        SELECT
          wo.workorderid,oir.bookcode,  
        osr.serviceid AS service_id, 
        sv.servicename AS service_name ,
        MAX(inflow_stageid) AS inflowstageid,
        SUM(COALESCE(osr.actualinflowvalue,0)) AS sumofordervalue,
        SUM(COALESCE(billingvalue,0)) AS sumofbillingvalue
        FROM wms_workorder AS wo
        JOIN salespmo.trn_ord_inflow_report AS oir ON oir.workorderid = wo.workorderid AND oir.isactive = true
        JOIN salespmo.trn_ord_inflow_stagewise_report AS osr ON osr.ord_inflowid = oir.ord_inflowid AND osr.isactive = true
        JOIN public.wms_mst_service AS sv ON sv.serviceid = osr.serviceid
        WHERE bookcode = $2
        GROUP BY wo.workorderid, oir.bookcode, osr.serviceid, sv.servicename
        ORDER BY wo.workorderid, service_id
      ), 
      servicedata as (
        SELECT 
        DISTINCT
        rfid 
      ,bookcode 
      ,(details->>'Amount')::integer as billingamount
      ,case when details->>'Service' = 'Copy-editing' THEN 'Copy Editing' END as service_name
      ,details->>'Currency' as currency
      ,details->>'Billabledu' as billabledu
      FROM salespmo.log_odoo_invoice_reply ,
      jsonb_array_elements(payload ->'Service' ) as details
      WHERE odooinvoicelogid = $1 and bookcode  = $2
      ORDER BY rfid,bookcode,service_name
      )
      , calcdata AS  (	
      SELECT
      '('|| sumofbillingvalue :: text || '+' || billingamount :: text ||')-'|| sumofordervalue::text|| ' (SUM OF PREVIOUS BILL VALUE - BILLING VALUE)-sumofordervalue ' as newremarks,
      ((sumofbillingvalue + billingamount) - sumofordervalue)::numeric(10,2) AS finalvalue,
      inflowstageid,
      wo.workorderid,wo.bookcode, wo.service_id ,
      wo.service_name ,wo.inflowstageid, 
      wo.sumofordervalue, wo.sumofbillingvalue,
        
      sv.rfid, sv.bookcode, sv.billingamount, 
      sv.service_name, sv.currency, sv.billabledu ,
        
      tsr.ord_inflowid, tsr.serviceid ,tsr.servicename ,tsr.stageid, 
      tsr.stagename, tsr.category,   tsr.billableduid,
      tsr.billableduname, 
      tsr.transferremarks, tsr.isactive,tsr.actualinflowvalue,tsr.inflowtype ,
      tsr.billingvalue 
      FROM wodata AS wo
      JOIN servicedata AS sv ON wo.bookcode = sv.bookcode
      JOIN salespmo.trn_ord_inflow_stagewise_report AS tsr ON tsr.inflow_stageid = wo.inflowstageid
      AND sv.service_name = wo.service_name
      )
      INSERT INTO salespmo.trn_ord_inflow_stagewise_report (
      ord_inflowid, serviceid , servicename , stageid, 
      stagename, billableduid,
      billableduname, 
      transferremarks, isactive,
      actualinflowvalue, inflowtype,
      billingvalue)

      SELECT 
      cd.ord_inflowid, cd.serviceid, cd.servicename, cd.stageid, 
      cd.stagename, cd.billableduid,
      cd.billableduname, cd.newremarks, true , cd.finalvalue :: NUMERIC(18,2), 
      'Invoice' AS inflowtype ,
      cd.billingamount :: NUMERIC(18,2)
      FROM calcdata cd;
      `;

    await query(qry, [odooinvoicelogid, JobCode]);

    console.log(JobCode);
  } catch (e) {
    console.log(e);
  }
};

export const getUBRFailureReportService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, startDate, endDate, searchText } = payload;
      const script = getUBRFailureReportSrcipt();
      const result = await query(script, [
        duid,
        startDate,
        endDate,
        searchText,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertOdooInvoiceLogService = async (invoiceId, payload) => {
  try {
    const result = await query(
      `INSERT INTO salespmo.log_invoice_oodointegration(invoiceid, payload) VALUES($1, $2) returning invoicelogid;`,
      [invoiceId, payload],
    );
    const insertedId = +result[0].invoicelogid;
    return insertedId;
  } catch (e) {
    return 0;
  }
};

export const updateOdooInvoiceLogService = async (
  logid,
  response,
  remarks,
  issuccess,
) => {
  return new Promise(async resolve => {
    try {
      await query(
        `UPDATE salespmo.log_invoice_oodointegration
        SET response=$2, remarks=$3, issuccess=$4, updatedon=current_timestamp
        WHERE invoicelogid=$1;`,
        [logid, response, remarks, issuccess],
      );
      resolve('updated');
    } catch (e) {
      console.log(e.message);
      resolve('failed');
    }
  });
};
export const insertOdooFileLogService = async (invoiceId, payload) => {
  try {
    const result = await query(
      `INSERT INTO salespmo.log_rfiattachments_odoo(rfiid, payload) VALUES($1, $2) returning logid;`,
      [invoiceId, payload],
    );
    const insertedId = +result[0].logid;
    return insertedId;
  } catch (e) {
    return 0;
  }
};

const updateOdooRfiFileLogService = async (
  logid,
  response,
  remarks,
  issuccess,
) => {
  return new Promise(async resolve => {
    try {
      await query(
        `UPDATE salespmo.log_rfiattachments_odoo
        SET response=$2, remarks=$3, issuccess=$4, updated_on=current_timestamp
        WHERE logid=$1;`,
        [logid, response, remarks, issuccess],
      );
      resolve('updated');
    } catch (e) {
      console.log(e.message);
      resolve('failed');
    }
  });
};

export const sendInvoiceToOdooService = async (invoiceId, payload) => {
  return new Promise(async (resolve, reject) => {
    let message = '';
    let issuccess = false;
    let odooresult = null;
    let logid;

    try {
      const returnobj = generateOdooInvoicePayload(invoiceId, payload);
      const invoiceUrl = odooEndPoints.api.invoiceInsert;

      // Insert initial log for the Odoo invoice
      logid = await insertOdooInvoiceLogService(
        invoiceId,
        JSON.stringify(returnobj),
      );

      // Call the Odoo API integration service
      const result = await odooApiIntegrationService(invoiceUrl, returnobj);

      if (result != undefined) {
        message = result.message;
        issuccess = result.status;
        odooresult = result;
      }
      // Resolve promise with final status and message
      resolve({ status: issuccess, message });
    } catch (error) {
      console.error('odooApiIntegrationService error:', error);
      odooresult = error || '';
      message = error.message || 'Error during Odoo API call';
      reject({ status: issuccess, message });
    } finally {
      try {
        // Update the log after the API call
        await updateOdooInvoiceLogService(
          logid,
          safeStringify(odooresult),
          message,
          issuccess,
        );
      } catch (logError) {
        console.error('Log update failed:', logError);
        message += ` | Log update error: ${logError.message}`;
      }
    }
  });
};

export const sendInvoicePayloadToOdooService = async invoiceId => {
  let message = '';
  let issuccess = false;
  let odooresult = null;
  let logid;

  try {
    // Retrieve data for invoice and files
    const payloadDetails = await query(getOdooPayloadScript(), [invoiceId]);

    // Prepare Odoo payload
    const odooPayload = {
      jobdetails: payloadDetails[0]?.jobdetails,
      invoicedetails: payloadDetails[0]?.invoicedetails,
      pricedetails: payloadDetails[0]?.pricedetails,
    };
    const returnobj = generateOdooInvoicePayload(invoiceId, odooPayload);
    // returnobj.InvoiceQueueDetails.files = fileUrls;
    // Insert log for the Odoo invoice
    logid = await insertOdooInvoiceLogService(
      invoiceId,
      JSON.stringify(returnobj),
    );

    // Call the Odoo API
    const result = await odooApiIntegrationService(
      odooEndPoints.api.invoiceInsert,
      returnobj,
    );
    // let fileStatus;
    // const uploadFiles = await downloadAndSendToOdooService(invoiceId);
    await downloadAndSendToOdooService(invoiceId);
    if (result) {
      message = result.message;
      issuccess = result.status;
      odooresult = result;
    }
    // Resolve the promise with the result
    return { status: issuccess, message };
  } catch (error) {
    // Error handling with improved logging
    console.error('Error in sendInvoicePayloadToOdooService:', error);
    message = error.message || 'Error during Odoo API call';
    odooresult = error;
    return { status: false, message };
  } finally {
    // Update the log after the process, ensuring any errors are logged
    try {
      if (logid) {
        await updateOdooInvoiceLogService(
          logid,
          safeStringify(odooresult),
          message,
          issuccess,
        );
      }
    } catch (logError) {
      console.error('Log update failed:', logError);
      message += ` | Log update error: ${logError.message}`;
    }
  }
};

export const getInvoiceOdooReportService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, startDate, endDate, searchText } = payload;
      const script = getInvoiceOdooReportScript();
      const result = await query(script, [
        duid,
        startDate,
        endDate,
        searchText,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export async function downloadAndSendToOdooService(rfiId) {
  let fileUrls;
  let logid;
  let message;
  let odooresult;
  let issuccess;
  let filesDetails;
  try {
    filesDetails = await query(getRFIFilePathScript(), [rfiId]);
    // Handle files asynchronously
    fileUrls =
      filesDetails.length > 0
        ? await Promise.all(filesDetails.map(file => _download(file?.url)))
        : [];
  } catch (err) {
    console.error('Error fetching file URLs:', err);
    return;
  }

  // 1. Create formData to send the files to the next API
  const formData = new FormData();
  formData.append('rfi_id', rfiId); // Assuming 'rfi_id' is a required parameter

  // 2. Download files in parallel using Promise.all
  const downloadPromises = fileUrls.map(async (file, i) => {
    try {
      // Download the file from blob storage
      const fileResponse = await axios.get(file.data.path, {
        responseType: 'arraybuffer',
      });
      const fileBuffer = fileResponse.data;

      // Retrieve file metadata
      const cleanPath = file.data.path.split('?')[0];
      const fileName = cleanPath.split('/').pop(); // Extract filename from the URL
      const decodedFileName = decodeURIComponent(decodeURIComponent(fileName));
      const fileMimeType = mime.lookup(fileName) || 'application/octet-stream'; // Dynamically get mime type
      const fileSize = fileBuffer.length;

      // Create a log entry for this file (can include more metadata if necessary)
      const fileLog = {
        attachmentid: filesDetails[i]?.rfi_attachmentid,
        filename: decodedFileName,
        filesize: fileSize,
        mimeType: fileMimeType,
      };

      // Append the file data to formData
      formData.append('file_data', fileBuffer, {
        filename: decodedFileName,
        contentType: fileMimeType,
      });
      return fileLog;
    } catch (error) {
      console.error(`Error downloading file from ${file.data.path}:`, error);
      message = error.message || 'Error during Odoo API call';
      odooresult = error;
      return null;
      // Optionally, you can log the failed download or continue processing
    }
  });

  try {
    // Wait for all files to be downloaded
    const fileLogs = await Promise.all(downloadPromises);
    // Filter out any null values (in case of failed downloads)
    const successfulLogs = fileLogs.filter(log => log !== null);

    issuccess = true;
    // insert log before sending to odoo
    logid = await insertOdooFileLogService(
      rfiId,
      JSON.stringify(successfulLogs),
    );
    // 3. Upload all files to Odoo in a single request
    odooresult = await odooFileSendService(formData);
    // Create an array of promises
    const updatePromises = odooresult?.attachment_details.map(log => {
      const values = [
        log.RFIid,
        log.file_name,
        log.res_id,
        log.attachment_id,
        log.public_url,
      ];
      return query(updateOdooAttachmentDataScript(), values); // Return the promise for each query
    });
    // Wait for all update promises to be completed
    await Promise.all(updatePromises);
    // return fileDetails;
  } catch (error) {
    issuccess = false;
    odooresult = error;
    console.error('Error uploading files to Odoo:', error);
    throw error; // Rethrow or handle the error as needed
  } finally {
    // Update the log after the process, ensuring any errors are logged
    try {
      if (logid) {
        await updateOdooRfiFileLogService(
          logid,
          safeStringify(odooresult),
          message,
          issuccess,
        );
      }
    } catch (logError) {
      console.error('Log update failed:', logError);
      message += ` | Log update error: ${logError.message}`;
    }
  }
}
