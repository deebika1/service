function generateServiceDetails(inputJson) {
  // Define the expected output fields and map them to corresponding input fields
  const outputFields = {
    Service: 'Service',
    Category: 'Category',
    Description: 'Invoice Description',
    ItemNumber: 'Item Number',
    BillableDU: 'Billable DU',
    ItemCode: 'Code',
    SACCode: 'SAC Code',
    GeneralLedgerAccount: 'General Ledger Account',
    LineItemNo: 'Line ItemNo',
    Uom: 'UOM',
    Rate: 'Rate',
    NoOfUnits: 'Units',
    AcceptedManuscriptDelivery: 'Accepted Manuscript Delivery',
    UploadDate: 'Upload Date',
    Remarks: 'Remarks',
    ArticleType: 'Article Type',
    DOINumber: 'DOI Number',
    CurrentState: 'Current State',
    WBSEntity: 'WBS Entity',
    PrevBilledPages: 'prevbilledpages',
  };

  // Initialize an empty array for ServiceDetails output
  const serviceDetails = [];

  // Iterate over each set of service details in the input JSON
  inputJson.forEach(serviceGroup => {
    const serviceDetail = {};

    // Initialize serviceDetail object with empty strings for all expected fields
    Object.keys(outputFields).forEach(field => {
      serviceDetail[field] = null;
    });

    // Iterate through each item in the service group
    serviceGroup.forEach(item => {
      const label = item.labelname;
      const value = item.value == '' ? null : item.value;

      // Map the value from input to the corresponding field in the output
      Object.keys(outputFields).forEach(outputField => {
        if (label === outputFields[outputField]) {
          serviceDetail[outputField] = value;
        }
      });
    });
    // if (serviceDetail.UploadDate == '') serviceDetail.UploadDate = null;

    // Add the constructed service detail to the final array
    serviceDetails.push(serviceDetail);
  });

  return serviceDetails;
}

export function generateJobData(jobJson, serviceDetailsJson) {
  // Prepare the JobData template
  const jobDetailsFields = {
    JobCode: 'itemcode',
    ManuscriptNumber: 'Manuscript Number',
    Stage: 'Stage',
    CopyEditingService: 'Copy Editing Service',
    CopyEditingLevel: 'Copy Editing Level',
    Complexity: 'Complexity',
    ProjectManagementCategory: 'Project Management Category',
  };

  // Helper function to map fields using the invoiceFields
  const mapFields = job => {
    const mappedJob = {};
    for (const [outputField, inputField] of Object.entries(jobDetailsFields)) {
      // mappedJob[outputField] = inputField ? job[inputField] ?? null : null;
      const value = job[inputField];

      // If value is undefined or empty string, set it to null, otherwise set the value
      mappedJob[outputField] = value == '' || value == null ? null : value;
    }
    mappedJob.ServiceDetails = generateServiceDetails(serviceDetailsJson); // Assuming generateJobData() is defined elsewhere
    return mappedJob;
  };
  // Map the input job JSON to the expected output format
  const jobData = jobJson.map(mapFields);
  return jobData;
}

export function generateOdooInvoicePayload(rfiId, invoiceJson) {
  // Prepare the JobData template
  const invoiceFields = {
    DeliveryUnit: 'duname',
    Customer: 'nameofcustomer',
    Email: 'email',
    Vertical: 'verticalname',
    JournalShortName: 'journalacronym',
    JournalNumber: 'journalacronym',
    JournalCode: 'journalacronym',
    JournalName: 'journalname',
    Country: 'ist_code',
    CountryOfOrigin: 'countryoforigin',
    JobReceivedDate: 'jobreceivedate',
    KindAttention: 'kindattention',
    PurchaseOrderNo: 'purchaseno',
    PurchaseOrderDate: 'purchaseorderdate',
    DespatchDate: 'despatchdate',
    Project: 'project',
    Title: 'title',
    Author: 'Author',
    ISBNNo: 'isbnno',
    ProjectNo: 'projectno',
    Currency: 'currency',
    GreatPlainsProject: 'greatplainsproject',
    EditorialPages: 'editorialpages',
    Vol_Issue: 'vol/isseno',
    VolNo: 'volumenumber',
    IssueNo: 'issuenumber',
    AnalyticalCode: 'code',
    CountryOfRegion: 'destination',
    IsArticle: 'isarticle',
    IsFinal: 'isfinal',
    // InActive: 'no',
  };
  const {
    jobdetails,
    invoicedetails,
    pricedetails,
    // uploads
  } = invoiceJson;

  const mapFields = job => {
    const mappedJob = {
      RFIid: rfiId,
      InActive: 'no',
    };
    for (const [outputField, inputField] of Object.entries(invoiceFields)) {
      mappedJob[outputField] = inputField ? job[inputField] ?? null : null;
    }
    invoicedetails.forEach(item => {
      // Iterate through each item in the invoicedetails group
      const label = item.labelname.toLowerCase().trim().replace(/\s+/g, '');
      const value = item.value == '' ? null : item.value;
      // Map the value from input to the corresponding field in the output
      Object.keys(invoiceFields).forEach(outputField => {
        if (label === invoiceFields[outputField]) {
          mappedJob[outputField] = value == '' ? mappedJob[outputField] : value;
        }
      });
    });
    mappedJob.JobData = [];
    pricedetails.forEach(element => {
      mappedJob.JobData.push({
        JobCode: element.JobCode,
        ManuscriptNumber: element.ManuscriptNumber || '-',
        Stage: element.Stage || '-',
        CopyEditingService: element.CopyEditingService || 'no',
        CopyEditingLevel: element.CopyEditingLevel || 'no',
        Complexity: element.Complexity || '-',
        ServiceDetails: generateServiceDetails(element.service),
      });
    });
    return mappedJob;
  };
  // Map the input job JSON to the expected output format
  // const jobData = jobdetails.map(mapFields);
  const jobData = mapFields(jobdetails[0]);
  // jobData.uploads = [...uploads];
  const invoiceQueue = {
    InvoiceQueueDetails: [jobData],
  };
  return invoiceQueue;
}
