export const odooEndPoints = {
  server: {
    host: process.env.ODOO_HOST,
    port: process.env.ODOO_PORT,
    protocol: process.env.ODOO_PROTOCOL,
    basePath: process.env.ODOO_BASE_PATH || '',
    timeOut: parseInt(process.env.ODOO_SERVER_TIMEOUT || 180000),
    getAuthPayload: () => {
      return {
        jsonrpc: process.env.ODOO_AUTH_PROTOCOL_VERSION,
        params: {
          login: process.env.ODOO_USER,
          password: process.env.ODOO_PWD,
          db: process.env.ODOO_DB,
        },
      };
    },
    getOdooUrl: () =>
      `${process.env.ODOO_PROTOCOL}://${process.env.ODOO_BASE_PATH}`,
  },
  auth: {
    authenticate: '/web/session/authenticate',
  },
  api: {
    saleOrder: '/api/sale_order_details',
    invoiceInsert: '/api/invoice_details',
    invoiceAttachment: '/api/attachment',
  },
};
