import Joi from 'joi';

export const searchforfeedbackSchema = Joi.object({
  bookcode: Joi.string().allow('').required(),
  jobcardcode: Joi.number().allow(null).required(),
  jobtitle: Joi.string().allow('').required(),
  fromdate: Joi.date().allow(null).required(),
  todate: Joi.date().allow(null).required(),
  divisions: Joi.number().allow(null).required(),
  customers: Joi.number().allow(null).required(),
  companyid: Joi.number().allow(null).required(),
  searchby: Joi.string().allow('').required(),
  isbn: Joi.string().allow('').required(),
  jobcardid: Joi.number().allow(null).required(),
});

// Define the schema for the InvoiceStatus array item
const invoiceStatusSchema = Joi.object({
  Customer: Joi.string().optional(),
  DeliveryUnit: Joi.string().optional(),
  JobCode: Joi.string().required(),
  RFIid: Joi.string().required(),
  Status: Joi.string().valid('Accepted', 'Rejected').required(),
  reject_reason: Joi.string().when('Status', {
    is: 'Rejected',
    then: Joi.required(), // reject_reason is required only if Status is 'Rejected'
    otherwise: Joi.optional(),
  }),
});

// Define the main schema for the whole payload
export const invoiceMainSchema = Joi.object({
  InvoiceStatus: Joi.array().items(invoiceStatusSchema).required(), // InvoiceStatus must be an array and contain valid items
});

export const invoiceDetailsSchema = Joi.object({
  InvoiceDetails: Joi.array()
    .items(
      Joi.object({
        Customer: Joi.string().allow(''),
        DeliveryUnit: Joi.string().allow(''),
        RFIid: Joi.string().required(),
        InvoiceType: Joi.string().valid('Partial', 'Final').required(),
        // InvoicedDate: Joi.string().required().pattern(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/),
        JobCode: Joi.string().allow(''),
        InvoiceNo: Joi.string().required(),
        InvoicedBy: Joi.string().required(),
        InvoicedDate: Joi.string().required(),
        Service: Joi.array().items(
          Joi.object({
            Service: Joi.string().required(),
            Currency: Joi.string().allow(''),
            Billabledu: Joi.string().allow(''),
            Amount: Joi.number().required(),
          }),
        ),
      }),
    )
    .required(),
});

// Define the schema for the `Service` array
const serviceSchema = Joi.array().items(
  Joi.object({
    Amount: Joi.number().required(),
    Service: Joi.string().required(),
    Currency: Joi.string().valid('USD').required(),
    Billabledu: Joi.string().required(),
  }).required(),
);

// Define the schema for `PartialInvoiceDetails`
const partialInvoiceDetailsSchema = Joi.array().items(
  Joi.object({
    RFIid: Joi.string().required(),
    JobCode: Joi.string().required(),
    Service: serviceSchema.required(), // Use the service schema for the Service array
    Customer: Joi.string().required(),
    InvoiceNo: Joi.string().required(),
    InvoicedBy: Joi.string().required(),
    InvoiceType: Joi.string().valid('Partial').required(), // You can specify other valid invoice types if necessary
    DeliveryUnit: Joi.string().required(),
    InvoicedDate: Joi.date().iso().required(), // ISO 8601 date format
  }).required(),
);

// Define the root schema for the payload
export const PartialInvoiceSchema = Joi.object({
  PartialInvoiceDetails: partialInvoiceDetailsSchema.required(),
});

// Define the schema for the `Service` array
const finalServiceSchema = Joi.array().items(
  Joi.object({
    Amount: Joi.number().required(),
    Service: Joi.string().required(),
    Currency: Joi.string().valid('USD').required(),
    Billabledu: Joi.string().required(),
  }).required(),
);

// Define the schema for the `InvoiceDetails` array
const finalInvoiceDetailsSchema = Joi.array().items(
  Joi.object({
    JobCode: Joi.string().required(),
    Service: finalServiceSchema.required(), // Use the service schema for the Service array
  }).required(),
);

// Define the schema for `FinalInvoiceDetails`
const finalInvoiceDetailsRootSchema = Joi.array().items(
  Joi.object({
    RFIid: Joi.string().required(),
    Customer: Joi.string().required(),
    InvoiceNo: Joi.string().required(),
    InvoicedBy: Joi.string().required(),
    InvoiceType: Joi.string().valid('Final').required(),
    DeliveryUnit: Joi.string().required(),
    InvoicedDate: Joi.date().iso().required(),
    InvoiceDetails: finalInvoiceDetailsSchema.required(), // InvoiceDetails is an array of objects
  }).required(),
);

export const InvoiceRootSchema = Joi.object({
  // Validate if the object contains either `PartialInvoiceDetails` or `FinalInvoiceDetails`
  PartialInvoiceDetails: partialInvoiceDetailsSchema.optional(),
  FinalInvoiceDetails: finalInvoiceDetailsRootSchema.optional(),
}).or('PartialInvoiceDetails', 'FinalInvoiceDetails');
