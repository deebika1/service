import { query } from '../../database/postgres.js';

// export const preparejson_old = async (workorderId, stageId, type) => {
//   return new Promise(async resolve => {
//     let returnjson = '';
//     try {
//       let duId;
//       let jobId;
//       let jobtitle;
//       let duname;
//       let jobcreatedon;
//       let createdmonth;
//       let customerId;
//       let customername;
//       let countryid;
//       let countryname;
//       let divisionid;
//       let divisionname;
//       let verticalid;
//       let verticalname;
//       let vertical;
//       let celevel;
//       let journalId;
//       let imagecount;
//       let typesetpage;
//       let estimatedpages;
//       let mspages;
//       let tablecount;
//       let equationcount;
//       let wordcount;
//       let currency;
//       let journalacronym;
//       let eisbn;
//       let stagename;
//       let currentdate;

//       const sql = `SELECT
//           wo.workorderid , wo.itemcode ,wo.title, itrdu.duId , itrdu.duname,
//           itrcust.customerid , itrcust.customername,
//           di.divisionid , di.division , co.countryid , co.countryname ,
//           itrdu.duId as baseduid , mser.serviceid , mser.servicename,
//           TO_CHAR(wo.createdon + INTERVAL '5 hours 30 minutes','YYYY-MM-DD HH24:MI:SS.MS') as jobcreatedon,
//           TO_CHAR(wo.createdon + INTERVAL '5 hours 30 minutes','YYYY-MM-DD HH24:MI:SS.MS') AS createdmonth,
//           subd.subdivisionid as verticalid,
//           subd.subdivision as verticalname,
//           subd.verticalcode , wo.journalid,
//           jm.journalacronym,
//           mcopy.displayname as celevel,
//           wo.celevelid ,
//           wo.eisbn
//           FROM wms_workorder AS wo
//           JOIN public.org_mst_customer as cu ON cu.customerid = wo.customerid
//           JOIN public.org_mst_division as di ON di.divisionid = wo.divisionid
//           JOIN public.geo_mst_country as co ON co.countryid = wo.countryid
//           JOIN public.org_mst_customer_orgmap as cog ON cog.divisionid = wo.divisionid AND
//           cog.customerid = wo.customerid  AND cog.subdivisionid = wo.subdivisionid
//           AND cog.countryid = wo.countryid
//           JOIN public.org_mst_subdivision as subd ON subd.subdivisionid = wo.subdivisionid
//           JOIN public.org_mst_customerorg_du_map as cdu on cdu.custorgmapid = cog.custorgmapid
//           JOIN public.org_mst_deliveryunit as du on du.duid = cdu.duid
//           JOIN public.org_mst_customerorg_service_map as ser on ser.custorgmapid = cog.custorgmapid
//           JOIN public.wms_mst_service as mser on mser.serviceid = ser.serviceid
//           JOIN public.mst_deliveryunit as itrdu on itrdu.duid = du.itrackduid
//           join public.mst_customer as itrcust on itrcust.customerid = cu.itrack_customerid
//           join public.pp_mst_copyeditinglevel as mcopy on mcopy.celevelid = wo.celevelid
//           left join public.pp_mst_journal as jm on jm.journalid = wo.journalid
//           WHERE wo.workorderid = ${workorderId}`;

//       const qresult = await query(sql);

//       if (qresult && qresult.length > 0) {
//         duId = qresult[0].duid;
//         jobId = qresult[0].itemcode;
//         duname = qresult[0].duname;
//         jobcreatedon = qresult[0].jobcreatedon;
//         createdmonth = qresult[0].createdmonth;
//         customerId = qresult[0].customerid;
//         customername = qresult[0].customername;
//         countryid = qresult[0].countryid;
//         countryname = qresult[0].countryname;
//         divisionid = qresult[0].divisionid;
//         divisionname = qresult[0].division;
//         verticalid = qresult[0].verticalid;
//         verticalname = qresult[0].verticalname;
//         vertical = qresult[0].verticalcode;
//         celevel = qresult[0].celevel;
//         journalId = qresult[0].journalid;
//         journalacronym = qresult[0].journalacronym;
//         jobtitle = qresult[0].title;
//         eisbn = qresult[0].eisbn;
//       }

//       console.log(duId);
//       console.log(createdmonth);
//       console.log(customerId);
//       console.log(countryid);
//       console.log(divisionid);
//       console.log(verticalid);
//       console.log(vertical);
//       console.log(celevel);
//       console.log(journalacronym);
//       console.log(tablecount);
//       console.log(equationcount);
//       console.log(wordcount);

//       const incomingsql = `SELECT inf.mspages,
//           coalesce(estimatedpages,0) as estimatedpages,
//           coalesce(typesetpage,0) as typesetpage,
//           coalesce(imagecount,0) as imagecount,
//           coalesce(tablecount,0) as tablecount,
//           coalesce(equationcount,0) as equationcount,
//           coalesce(wordcount,0) as wordcount,
//           referencecount FROM wms_workorder AS wo
//           JOIN wms_workorder_incoming AS inc ON inc.woid = wo.workorderid
//           JOIN wms_workorder_incomingfiledetails AS inf ON inf.woincomingid = inc.woincomingid
//           WHERE wo.workorderid = $1  ORDER BY 1 DESC`;
//       const incomingdetail = await query(incomingsql, [workorderId]);

//       if (incomingdetail != undefined && incomingdetail.length) {
//         imagecount = +incomingdetail[0].imagecount;
//         typesetpage = +incomingdetail[0].typesetpage;
//         estimatedpages = +incomingdetail[0].estimatedpages;
//         mspages = +incomingdetail[0].mspages;
//         tablecount = +incomingdetail[0].tablecount;
//         equationcount = +incomingdetail[0].equationcount;
//         wordcount = +incomingdetail[0].wordcount;
//       }

//       const wostagedetail = await query(
//         `select stg.stagename,
//            to_char(now()+INTERVAL '330 MINUTES','YYYY-MM-DD HH:MI:SS.MS') as currentdate
//            ,ws.*
//            from wms_workorder_stage as ws
//            JOIN wms_mst_stage stg on stg.stageid = ws.wfstageid
//            where ws.workorderid = $1 and ws.wfstageid = $2`,
//         [workorderId, stageId],
//       );
//       if (wostagedetail != undefined && wostagedetail.length > 0) {
//         typesetpage = +wostagedetail[0].typesetpages;
//         stagename = wostagedetail[0].stagename;
//         currentdate = wostagedetail[0].currentdate;
//       }

//       const sqlcur = `SELECT cur.currencycode FROM salespmo.trn_journal_rate AS jr
//             JOIN public.mst_currencymst AS cur ON cur.currencyid = jr.currencyid
//             WHERE journalid = ${journalId} LIMIT 1`;
//       const getcurrency = await query(sqlcur);

//       if (getcurrency != undefined && getcurrency.length > 0) {
//         currency = getcurrency[0].currencycode;
//       }
//       let rest;

//       if (type == 'jobcardcreation') {
//         const jobobj = {
//           DeliveryUnit: duname,
//           Customer: customername,
//           BookCode: jobId,
//           Vertical: verticalname,
//           Division: divisionname || 'N/A', // Default to 'N/A' if divisionname is empty or undefined
//           KeyAccountManager: 'kam', // Assuming you want 'kam' as a string
//           JobCardNo: 'JobCardNo',
//           JobTitle: jobtitle,
//           IsbnNo: eisbn,
//           Country: countryname,
//           BookType: '', // Empty string as in your example
//           ReceiptDate: jobcreatedon,
//           CreatedDate: jobcreatedon,
//           ClientManager: '', // Empty string as in your example
//           ProjectManager: '', // Empty string as in your example
//           jobcardid: workorderId,
//           Currency: currency,
//         };
//         const jobDetails = {
//           JobDetails: [jobobj],
//         };
//         // console.log(JSON.stringify(jobDetails, null, 2));
//         rest = JSON.stringify(jobDetails, null, 2);
//       } else if (type == 'servicecreation') {
//         rest = await getarticleratejson(
//           journalId,
//           duname,
//           customername,
//           jobId,
//           currency,
//         );
//       } else if (type == 'initialstagearticle') {
//         const jobobj = {
//           DeliveryUnit: duname,
//           Customer: customername,
//           BookCode: jobId,
//           createdDate: jobcreatedon,
//           SubJob: [
//             {
//               Chapter: jobId,
//               Stage: stagename,
//               EstimatedPage: estimatedpages,
//               MsPage: mspages,
//               NoOfImages: imagecount,
//               SubJobId: 0,
//             },
//           ],
//         };
//         const structuredObj = {
//           StageDetails: [jobobj],
//         };
//         // console.log(JSON.stringify(structuredObj, null, 2));
//         rest = JSON.stringify(structuredObj, null, 2);
//       } else if (type == 'dispatchstagearticle') {
//         const desobj = {
//           DeliveryUnit: duname,
//           Customer: customername,
//           BookCode: jobId,
//           SubJob: [
//             {
//               Chapter: jobId,
//               Stage: stagename,
//               TypeSetPage: typesetpage,
//               DispatchedDate: currentdate,
//               SubJobId: 0,
//             },
//           ],
//         };
//         const structuredObj = {
//           StageDispatchedDetails: [desobj],
//         };
//         rest = JSON.stringify(structuredObj, null, 2);
//       }
//       if (rest) {
//         returnjson = rest;
//       }
//       resolve({ data: returnjson, msg: 'success' });
//     } catch (exeption) {
//       resolve({ data: returnjson, msg: exeption.message });
//     }
//   });
// };

// const getarticleratejson_old = async (
//   journalid,
//   DeliveryUnit,
//   customer,
//   bookcode,
//   currency,
// ) => {
//   let returnjson = '';
//   return new Promise(async resolve => {
//     try {
//       const sql = `SELECT json_build_object(
//               'ServiceDetails', json_agg(
//                   json_build_object(
//                       'DeliveryUnit', '${DeliveryUnit}',
//                       'Customer', '${customer}',
//                       'BookCode', '${bookcode}',
//                       'Currency', '${currency}',
//                       'RateDetails', (
//                           SELECT json_agg(row_to_json(t))
//                           FROM (
//                               SELECT
//                                   um.uom as "Uom",
//                                   ser.servicename as "Service",
//                                   value as "Rate"
//                               FROM salespmo.trn_journal_rate AS jr
//                               JOIN public.wms_mst_service AS ser
//                                   ON ser.serviceid = jr.serviceid AND ser.isactive = true
//                               JOIN public.wms_mst_uom AS um
//                                   ON um.uomid = jr.uomid AND um.isactive = 1
//                               WHERE jr.journalid = ${journalid} AND jr.isactive = true
//                           ) t
//                       )
//                   )
//               )
//           ) as json_result;`;

//       const rateconfig = await query(sql);
//       if (rateconfig != undefined && rateconfig.length) {
//         if (rateconfig[0].json_result.ServiceDetails != undefined) {
//           returnjson = JSON.stringify(rateconfig[0].json_result);
//         }
//       }
//       resolve(returnjson);
//     } catch (error) {
//       resolve('');
//     }
//   });
// };

export const preparejson = async (
  workorderId,
  stageId,
  type,
  subjobname,
  subjobId,
  woType = 'journal',
) => {
  try {
    let stageDetails;
    const workOrderDetails = await getWorkOrderDetails(workorderId, woType);
    const incomingDetails = await getIncomingDetails(workorderId);
    if (stageId !== null && stageId !== 0) {
      stageDetails = await getStageDetails(workorderId, stageId);
    }
    // const currency =
    //   workOrderDetails[0]?.vertical.toUpperCase() == 'J' ||
    //   workOrderDetails?.vertical.toUpperCase() == 'J'
    //     ? await getCurrencyCode_Journal(
    //         workOrderDetails?.journalId || workOrderDetails?.journalid,
    //       )
    //     : await getCurrencyCode_Job(workorderId);

    const currency =
      workOrderDetails[0]?.currencycode || workOrderDetails?.currencycode;
    let returnjson = '';

    switch (type) {
      case 'jobcardcreation':
        returnjson = createJobCardJson(workOrderDetails);
        break;
      case 'servicecreation':
        if (
          workOrderDetails[0]?.vertical.toUpperCase() == 'J' ||
          workOrderDetails?.vertical.toUpperCase() == 'J'
        ) {
          returnjson = await getArticleRateJson(
            workOrderDetails.journalId || workOrderDetails.journalid,
            workOrderDetails.duname,
            workOrderDetails.customername,
            workOrderDetails.jobId || workOrderDetails.jobid,
            currency,
            workOrderDetails?.jobtitle || workOrderDetails?.jobTitle,
            workOrderDetails?.celevelid || workOrderDetails?.celevel,
          );
        } else {
          returnjson = await getjobRateJson(
            workorderId,
            workOrderDetails.duname,
            workOrderDetails.customername,
            workOrderDetails.jobId || workOrderDetails.jobid,
            currency,
          );
        }
        break;
      case 'initialstagearticle':
        returnjson = createInitialStageArticleJson(
          workOrderDetails,
          incomingDetails,
          stageDetails,
          subjobname,
          subjobId,
        );
        break;
      case 'dispatchstagearticle':
        returnjson = createDispatchStageArticleJson(
          workOrderDetails,
          incomingDetails,
          stageDetails,
          subjobname,
          subjobId,
        );
        break;
      default:
        throw new Error('Invalid service type');
    }

    return { data: returnjson, msg: 'success' };
  } catch (error) {
    return { data: '', msg: error.message };
  }
};

// Helper functions:
const getWorkOrderDetails = async (workorderId, woType) => {
  let sql = '';
  if (woType.toLowerCase() == 'journal') {
    sql = `SELECT
      wo.workorderid, wo.itemcode AS "jobId", wo.title AS jobtitle, itrdu.duname, 
      itrcust.customerid, itrcust.customername, di.divisionid, di.division AS divisionname, 
      co.countryid, co.countryname, co.ist_code  , subd.subdivisionid AS verticalid, 
      subd.subdivision AS verticalname, subd.verticalcode AS vertical, wo.journalid, 
      jm.journalacronym, mcopy.displayname AS celevel, wo.eisbn,
      TO_CHAR(wo.createdon + INTERVAL '5 hours 30 minutes','YYYY-MM-DD HH24:MI:SS.MS') AS jobcreatedon,
      ( select kus.username from salespmo.trn_kamcustomerrel tkm
        join  wms_user as kus on tkm.kamempcode = kus.userid
        where tkm.duid = du.itrackduid
        and tkm.customerid = cu.itrack_customerid 
        and tkm.countryid =  wo.countryid and 
        tkm.divisionid = wo.divisionid  limit 1  
      ) as kamname,
       COALESCE((SELECT contactname FROM wms_workorder_contacts WHERE workorderid = wo.workorderid AND contactrole = 'PM'  LIMIT 1),'') AS projectmanager,
	     COALESCE((SELECT contactname FROM org_mst_customerorg_contact omcc WHERE custorgmapid = jm.custorgmapid AND contactroleid = 'CM' LIMIT 1),'') AS clientmanager,
       wo.currencyid,
       cur.currencycode
    FROM wms_workorder AS wo
    JOIN public.org_mst_customer AS cu ON cu.customerid = wo.customerid  
    JOIN public.org_mst_division AS di ON di.divisionid = wo.divisionid  
    JOIN public.geo_mst_country AS co ON co.countryid = wo.countryid
    JOIN public.org_mst_customer_orgmap AS cog ON cog.divisionid = wo.divisionid 
      AND cog.customerid = wo.customerid AND cog.subdivisionid = wo.subdivisionid
      AND cog.countryid = wo.countryid
    JOIN public.org_mst_subdivision AS subd ON subd.subdivisionid = wo.subdivisionid
    JOIN public.org_mst_customerorg_du_map AS cdu ON cdu.custorgmapid = cog.custorgmapid
    JOIN public.org_mst_deliveryunit AS du ON du.duid = cdu.duid
    LEFT JOIN public.org_mst_customerorg_service_map AS ser ON ser.custorgmapid = cog.custorgmapid
    LEFT JOIN public.wms_mst_service AS mser ON mser.serviceid = ser.serviceid  
    JOIN public.mst_deliveryunit AS itrdu ON itrdu.duid = du.itrackduid
    JOIN public.mst_customer AS itrcust ON itrcust.customerid = cu.itrack_customerid
    LEFT JOIN public.pp_mst_copyeditinglevel AS mcopy ON mcopy.celevelid = wo.celevelid
    LEFT JOIN public.pp_mst_journal AS jm ON jm.journalid = wo.journalid
    JOIN public.mst_currencymst AS cur ON cur.currencyid = wo.currencyid
    WHERE wo.workorderid = ${workorderId}`;
  } else {
    sql = `SELECT
      wo.workorderid, wo.itemcode AS "jobId", wo.title AS jobtitle, itrdu.duname, 
      itrcust.customerid, itrcust.customername, di.divisionid, di.division AS divisionname, 
      co.countryid, co.countryname, co.ist_code  , subd.subdivisionid AS verticalid, 
      subd.subdivision AS verticalname, subd.verticalcode AS vertical, wo.journalid, 
      jm.journalacronym, mcopy.displayname AS celevel, wo.eisbn,
      TO_CHAR(wo.createdon + INTERVAL '5 hours 30 minutes','YYYY-MM-DD HH24:MI:SS.MS') AS jobcreatedon,
      ( select kus.username from salespmo.trn_kamcustomerrel tkm
        join  wms_user as kus on tkm.kamempcode = kus.userid
        where tkm.duid = du.itrackduid
        and tkm.customerid = cu.itrack_customerid 
        and tkm.countryid =  wo.countryid and 
        tkm.divisionid = wo.divisionid  limit 1  
      ) as kamname,
       COALESCE((SELECT contactname FROM wms_workorder_contacts WHERE workorderid = wo.workorderid AND contactrole = 'PM' LIMIT 1),'') AS projectmanager,
	     COALESCE((SELECT contactname FROM wms_workorder_contacts WHERE workorderid = wo.workorderid AND contactrole = 'PMTL' LIMIT 1),'') AS clientmanager,
       wo.currencyid,
       cur.currencycode
    FROM wms_workorder AS wo
    JOIN public.org_mst_customer AS cu ON cu.customerid = wo.customerid  
    JOIN public.org_mst_deliveryunit AS du ON du.duid = wo.duid
    JOIN public.mst_customer AS itrcust ON itrcust.customerid = cu.itrack_customerid
    JOIN public.mst_deliveryunit AS itrdu ON itrdu.duid = du.itrackduid
    JOIN public.org_mst_division AS di ON di.divisionid = wo.divisionid  
    JOIN public.geo_mst_country AS co ON co.countryid = wo.countryid
    JOIN public.org_mst_subdivision AS subd ON subd.subdivisionid = wo.subdivisionid
    LEFT JOIN public.pp_mst_copyeditinglevel AS mcopy ON mcopy.celevelid = wo.celevelid
    LEFT JOIN public.pp_mst_journal AS jm ON jm.journalid = wo.journalid
    JOIN public.mst_currencymst AS cur ON cur.currencyid = wo.currencyid
    WHERE wo.workorderid = ${workorderId}`;
  }

  const result = await query(sql);
  if (!result || result.length === 0)
    throw new Error('Work order related datas missing');

  return result[0];
};

const getIncomingDetails = async workorderId => {
  const sql = `SELECT  sum(coalesce(inf.mspages,0)) as mspages, sum(coalesce(estimatedpages, 0)) AS estimatedpages, 
      sum(coalesce(typesetpage, 0)) AS typesetpage, sum(coalesce(imagecount, 0)) AS imagecount, 
      sum(coalesce(tablecount, 0)) AS tablecount, sum(coalesce(equationcount, 0)) AS equationcount, 
      sum(coalesce(wordcount, 0)) AS wordcount
    FROM wms_workorder AS wo
    LEFT JOIN wms_workorder_incoming AS inc ON inc.woid = wo.workorderid  
    LEFT JOIN wms_workorder_incomingfiledetails AS inf ON inf.woincomingid = inc.woincomingid
    WHERE wo.workorderid = $1 ORDER BY 1 DESC`;

  const result = await query(sql, [workorderId]);
  if (!result || result.length === 0)
    throw new Error('Incoming details not found');

  return result[0];
};

const getStageDetails = async (workorderId, stageId) => {
  const sql = `SELECT stg.stagename, 
      TO_CHAR(NOW() + INTERVAL '330 MINUTES', 'YYYY-MM-DD HH:MI:SS.MS') AS currentdate, ws.typesetpages
    FROM wms_workorder_stage AS ws
    JOIN wms_mst_stage stg ON stg.stageid = ws.wfstageid
    WHERE ws.workorderid = $1 AND ws.wfstageid = $2`;

  const result = await query(sql, [workorderId, stageId]);
  if (!result || result.length === 0)
    throw new Error('Stage details not found');

  return result[0];
};

// const getCurrencyCode_Journal = async journalId => {
//   const sql = `SELECT cur.currencycode
//     FROM salespmo.trn_journal_rate AS jr
//     JOIN public.mst_currencymst AS cur ON cur.currencyid = jr.currencyid
//     WHERE journalid = ${journalId} LIMIT 1`;

//   const result = await query(sql);
//   if (!result || result.length === 0) throw new Error('Currency not found');

//   return result[0].currencycode;
// };

// const getCurrencyCode_Job = async workorderId => {
//   const sql = `SELECT cur.currencycode
//     FROM salespmo.trn_job_rate AS jr
//     JOIN public.mst_currencymst AS cur ON cur.currencyid = jr.currencyid
//     WHERE workorderid = ${workorderId} LIMIT 1`;

//   const result = await query(sql);
//   if (!result || result.length === 0) throw new Error('Currency not found');

//   return result[0].currencycode;
// };
// JSON creation functions:

const createJobCardJson = details => {
  return JSON.stringify(
    {
      JobDetails: [
        {
          DeliveryUnit: details.duname,
          Customer: details.customername,
          BookCode: details.jobId || details.jobid,
          Vertical: details.verticalname,
          Division: details.divisionname || 'N/A',
          KeyAccountManager: details.kamname || null,
          JobCardNo: details.workorderid,
          JobTitle: details.jobtitle,
          IsbnNo: details.eisbn,
          Country: details.ist_code,
          BookType: '',
          ReceiptDate: details.jobcreatedon,
          CreatedDate: details.jobcreatedon,
          ClientManager: details.clientmanager,
          ProjectManager: details.projectmanager,
          jobcardid: details.workorderId || details.workorderid,
          Currency: details.currencycode,
        },
      ],
    },
    null,
    2,
  );
};

const createInitialStageArticleJson = (
  details,
  incomingDetails,
  stageDetails,
  subjobname,
  subjobid,
) => {
  if (details.customername.toLowerCase() == 'american chemical society') {
    return JSON.stringify(
      {
        StageDetails: [
          {
            DeliveryUnit: details.duname,
            Customer: details.customername,
            BookCode: details.jobId,
            createdDate: details.jobcreatedon,
            SubJob: [
              {
                Chapter: subjobname || details.jobId,
                Stage: stageDetails.stagename,
                EstimatedPage:
                  stageDetails.stagename.toLowerCase() == 'graphics'
                    ? +incomingDetails.imagecount
                    : +incomingDetails.estimatedpages,
                MsPage: +incomingDetails.mspages,
                NoOfImages: +incomingDetails.imagecount,
                SubJobId: +subjobid || 0,
              },
            ],
          },
        ],
      },
      null,
      2,
    );
  }
  return JSON.stringify(
    {
      StageDetails: [
        {
          DeliveryUnit: details.duname,
          Customer: details.customername,
          BookCode: details.jobId,
          createdDate: details.jobcreatedon,
          SubJob: [
            {
              Chapter: subjobname || details.jobId,
              Stage: stageDetails.stagename,
              EstimatedPage: +incomingDetails.estimatedpages,
              MsPage: +incomingDetails.mspages,
              NoOfImages: +incomingDetails.imagecount,
              SubJobId: +subjobid || 0,
            },
          ],
        },
      ],
    },
    null,
    2,
  );
};

const createDispatchStageArticleJson = (
  details,
  incomingDetails,
  stageDetails,
  subjobname,
  subjobid,
) => {
  if (details.customername.toLowerCase() == 'american chemical society') {
    const jsondata = {
      StageDispatchedDetails: [
        {
          DeliveryUnit: details.duname,
          Customer: details.customername,
          BookCode: details.jobId,
          SubJob: [
            {
              Chapter: subjobname || details.jobId,
              Stage: stageDetails.stagename,
              TypeSetPage:
                stageDetails.stagename.toLowerCase() == 'graphics'
                  ? +incomingDetails.imagecount
                  : +incomingDetails.estimatedpages,
              DispatchedDate: stageDetails.currentdate,
              SubJobId: +subjobid || 0,
            },
          ],
        },
      ],
    };
    return JSON.stringify(jsondata, null, 2);
  }

  const jsondata = {
    StageDispatchedDetails: [
      {
        DeliveryUnit: details.duname,
        Customer: details.customername,
        BookCode: details.jobId,
        SubJob: [
          {
            Chapter: subjobname || details.jobId,
            Stage: stageDetails.stagename,
            TypeSetPage: +stageDetails.typesetpages,
            DispatchedDate: stageDetails.currentdate,
            SubJobId: +subjobid || 0,
          },
        ],
      },
    ],
  };
  return JSON.stringify(jsondata, null, 2);
};

const getArticleRateJson = async (
  journalId,
  duname,
  customername,
  jobId,
  currency,
  jobTitle,
  celevel,
) => {
  const rateSql = `
    SELECT json_build_object(
      'ServiceDetails', json_agg(
        json_build_object(
          'DeliveryUnit', '${duname}',
          'Customer', '${customername}',
          'BookCode', '${jobId}',
          'Job Title', '${jobTitle}',
          'Currency', '${currency}',
          'RateData', (
           SELECT json_agg(row_to_json(t))
            FROM (
              SELECT um.uom AS "Uom", ser.servicename AS "Service", jr.value::text AS "Rate"
                FROM salespmo.trn_journal_rate AS jr
                JOIN public.wms_mst_service AS ser
                ON ser.serviceid = jr.serviceid AND ser.isactive = true
                JOIN public.wms_mst_uom AS um
                ON um.uomid = jr.uomid AND um.isactive = 1
                WHERE
                  jr.journalid = ${journalId}
                  AND jr.isactive = true
                  AND (
                  (ser.servicename = 'Copy Editing' AND jr.category = '${celevel}')
                  OR (ser.servicename != 'Copy Editing'))
            ) t
          )
        )
      )
    ) as json_result`;

  const result = await query(rateSql);
  if (!result || result.length === 0)
    throw new Error('Article rate details not found');

  return JSON.stringify(result[0].json_result);
};

const getjobRateJson = async (
  workorderId,
  duname,
  customername,
  jobId,
  currency,
) => {
  const rateSql = `
    SELECT json_build_object(
      'ServiceDetails', json_agg(
        json_build_object(
          'DeliveryUnit', '${duname}',
          'Customer', '${customername}',
          'BookCode', '${jobId}',
          'Currency', '${currency}',
          'RateData', (
            SELECT json_agg(row_to_json(t))
            FROM (
              SELECT um.uom as "Uom", ser.servicename as "Service", jr.value :: text as "Rate"
              FROM salespmo.trn_job_rate AS jr
              JOIN public.wms_mst_service AS ser ON ser.serviceid = jr.serviceid AND ser.isactive = true
              JOIN public.wms_mst_uom AS um ON um.uomid = jr.uomid AND um.isactive = 1
              WHERE jr.workorderid = ${workorderId} AND jr.isactive = true
            ) t
          )
        )
      )
    ) as json_result`;

  const result = await query(rateSql);
  if (!result || result.length === 0)
    throw new Error('Article rate details not found');

  return JSON.stringify(result[0].json_result);
};

export async function createInvoiceQueueDetails({
  deliveryUnit,
  customer,
  vertical,
  journalShortName,
  journalName,
  country,
  jobReceivedDate,
  kindAttention,
  currency,
  volIssue,
  volNo,
  issueNo,
  jobDataArray,
  purchaseOrderNo = '',
  purchaseOrderDate = null,
  project = '',
  title = '',
  author = '',
  isbnNo = '',
  projectNo = '',
  greatPlainsProject = '',
  editorialPages = '',
  analyticalCode = '',
  countryOfRegion = '',
  isArticle = 'no',
  isFinal = 'yes',
}) {
  return {
    InvoiceQueueDetails: [
      {
        DeliveryUnit: deliveryUnit || null,
        Customer: customer || null,
        Vertical: vertical || null,
        JournalShortName: journalShortName || null,
        JournalName: journalName || null,
        Country: country || null,
        JobReceivedDate: jobReceivedDate || null,
        KindAttention: kindAttention || null,
        PurchaseOrderNo: purchaseOrderNo || '',
        PurchaseOrderDate: purchaseOrderDate || 'As Agreed',
        Project: project || '',
        Title: title || '',
        Author: author || '',
        ISBNNo: isbnNo || '',
        ProjectNo: projectNo || '',
        Currency: currency || null,
        GreatPlainsProject: greatPlainsProject || '',
        EditorialPages: editorialPages || '',
        Vol_Issue: volIssue || null,
        VolNo: volNo || null,
        IssueNo: issueNo || null,
        AnalyticalCode: analyticalCode || '',
        CountryofRegion: countryOfRegion || '',
        IsArticle: isArticle || 'no',
        IsFinal: isFinal || 'yes',
        JobData: jobDataArray || [],
      },
    ],
  };
}

export async function createJobData({
  jobCode = null,
  manuscriptNumber = null,
  stage = null,
  complexity = null,
  projectManagementCategory = null,
  serviceDetailsArray = [],
}) {
  return {
    JobCode: jobCode || null,
    ManuscriptNumber: manuscriptNumber || null,
    Stage: stage || null,
    CopyEditingService: 'No',
    CopyEditingLevel: '',
    Complexity: complexity || null,
    ProjectManagementCategory: projectManagementCategory || null,
    ServiceDetails: serviceDetailsArray || [],
  };
}

export async function createServiceDetails({
  service = null,
  category = '',
  description = null,
  itemNumber = '',
  billableDU = '',
  itemCode = '',
  sacCode = '',
  generalLedgerAccount = '',
  lineItemNo = '',
  uom = null,
  rate = null,
  noOfUnits = '',
}) {
  return {
    Service: service || null,
    category,
    Description: description || null,
    ItemNumber: itemNumber,
    BillableDU: billableDU,
    ItemCode: itemCode,
    SACCode: sacCode,
    GeneralLedgerAccount: generalLedgerAccount,
    LineItemNo: lineItemNo,
    Uom: uom || null,
    Rate: rate || null,
    NoOfUnits: noOfUnits,
  };
}
