export const cupBussinessLogic = () => {};

export const cupCustomerPayload = () => {};
