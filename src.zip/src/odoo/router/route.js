import express from 'express';
import swaggerUi from 'swagger-ui-express';
import { readFileSync } from 'fs';
import {
  odooApiIntegrationsController,
  oodoIntegrationController,
  ubrIntegrationApiTestController,
  invoiceQueueStatusController,
  invoiceDetailsController,
  getUBRFailureReportController,
  getInvoiceOdooReportController,
  sendInvoiceController,
  sendFileToOdooRfiIDController,
} from '../controller/index.js';

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}

const odooRouter = express.Router();
swaggerDocs(odooRouter);
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };
// router.use('/api/odoo', handler(odooRoutes));
odooRouter.post('/testapi', handler(oodoIntegrationController));
odooRouter.post('/testubr', handler(ubrIntegrationApiTestController));
odooRouter.post('/testodoopayload', handler(odooApiIntegrationsController));
odooRouter.post('/sendinvoice', handler(sendInvoiceController));
odooRouter.post('/sendfile', handler(sendFileToOdooRfiIDController));
odooRouter.post('/testinvoice', handler(sendInvoiceController));
odooRouter.post('/invoicequeuestatus', handler(invoiceQueueStatusController));
odooRouter.post('/invoicedetails', handler(invoiceDetailsController));
odooRouter.post('/ubrfailurereport', handler(getUBRFailureReportController));

odooRouter.post(
  '/invoicefailurereport',
  handler(getInvoiceOdooReportController),
);
export default odooRouter;
