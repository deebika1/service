import {
  invoiceIntegrationService,
  odooApiIntegrationService,
  odooPayloadCreateService,
  ubrIntegrationService,
  invoiceQueueStatusService,
  invoiceDetailsService,
  getUBRFailureReportService,
  getInvoiceOdooReportService,
  downloadAndSendToOdooService,
  sendInvoicePayloadToOdooService,
} from '../service/index.js';

// odoo Integration startFF
export const oodoIntegrationController = async (req, res) => {
  const { invoicetype, url } = req.body;
  try {
    await odooApiIntegrationService(url, invoicetype);
    res.status(200).send({ success: true });
  } catch (error) {
    res.status(200).send({ success: true });
  }
};

export const invoiceIntegrationController = async (req, res) => {
  try {
    const payload = req.body;
    await invoiceIntegrationService(payload);
    res.status(200).send({ success: true });
  } catch (error) {
    res.status(400).send({ success: true });
  }
};

export const odooApiIntegrationsController = async (req, res) => {
  const input = req.payload;
  try {
    const returnresult = await odooPayloadCreateService(input);
    res
      .status(200)
      .send({ status: returnresult.success, message: returnresult.status });
  } catch (error) {
    res.status(400).send({ success: false, message: error });
  }
};

export const ubrIntegrationApiTestController = async (req, res) => {
  const {
    workorderId,
    stageId,
    servicetype,
    woId,
    woType,
    subjobname,
    subJobId,
  } = req.body;
  const inputobj = {
    workorderId,
    stageId,
    servicetype,
    woId,
    woType,
    subjobname,
    subJobId,
  };

  // ,woType , subjobname, subJobId

  try {
    const returnresult = await ubrIntegrationService(inputobj);
    res
      .status(200)
      .send({ status: returnresult.success, message: returnresult.status });
  } catch (error) {
    res.status(400).send({ success: false, message: error });
  }
};

export const inflowIntegrationController = async (req, res) => {
  const { calculationtype } = req.body;
  try {
    console.log(calculationtype);
    res.status(200).send({ success: true });
  } catch (error) {
    res.status(400).send({ success: true });
  }
};

export const invoiceQueueStatusController = async (req, res) => {
  try {
    const returnresult = await invoiceQueueStatusService(req.body);
    res.status(200).send(returnresult);
  } catch (error) {
    //
    res.status(400).send(error);
  }
};

export const invoiceDetailsController = async (req, res) => {
  try {
    const returnresult = await invoiceDetailsService(req.body);
    res
      .status(200)
      .send({ status: returnresult.status, message: returnresult.message });
  } catch (error) {
    res.status(400).send(error);
  }
};

export const getUBRFailureReportController = async (req, res) => {
  try {
    const returnresult = await getUBRFailureReportService(req.body);
    res.status(200).send(returnresult);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const sendInvoiceController = async (req, res) => {
  try {
    const { invoiceid } = req.body;
    const returnresult = await sendInvoicePayloadToOdooService(invoiceid);
    res.status(200).send(returnresult);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const sendFileToOdooRfiIDController = async (req, res) => {
  try {
    const { invoiceid } = req.body;
    const returnresult = await downloadAndSendToOdooService(invoiceid);
    res.status(200).send(returnresult);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getInvoiceOdooReportController = async (req, res) => {
  try {
    const returnresult = await getInvoiceOdooReportService(req.body);
    res.status(200).send(returnresult);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
