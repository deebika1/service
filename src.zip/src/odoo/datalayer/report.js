export const getUBRFailureReportSrcipt = () => {
  // lockjob
  const script = `select
            lo.logid,
            lo.workorderid,
            ww.itemcode ,
            omd.duname ,
            mc.customername ,
            lo.integrationtype ,
            lo.remarks ,
             to_char(lo.createdon,'yyyy-mm-dd hh24:mi:ss') as createdon
        from salespmo.log_oodointegration lo
        join wms_workorder ww on ww.workorderid = lo.workorderid
        join wms_mst_stage wms on wms.stageid = lo.stageid
        join public.org_mst_customer_orgmap as corg on
            corg.customerid = ww.customerid
            and corg.countryid = ww.countryid
            and corg.divisionid = ww.divisionid
            and corg.subdivisionid = ww.subdivisionid
            and corg.isactive = 1
        join public.org_mst_customerorg_du_map as cdumap on	cdumap.custorgmapid = corg.custorgmapid	 
        left join public.mst_deliveryunit omd on omd.duid = cdumap.duid and omd.isactive = true
        left join public.org_mst_customer omc on omc.customerid = ww.customerid	and omc.isactive = true
        left join public.mst_customer mc on mc.customerid = omc.itrack_customerid and mc.isactive = true
        where
            cdumap.duid != $1
            and lo.issuccess <> true
            and coalesce (ww.workorderid,0) != 0
            and coalesce(ww.islock,false) = false
            and lo.createdon ::date  between $2::date and $3 ::date 
            and (
                ww.itemcode ~* $4 OR
                omd.duname  ~* $4 OR
                mc.customername ~* $4 OR  
                lo.integrationtype ~* $4 OR
                lo.remarks  ~* $4 
            )
        order by 1`;
  return script;
};
// lockjob
export const getInvoiceOdooReportScript = () => {
  const script = `select corg.custorgmapid, cdumap.duid ,omd.duname,
	ww.itemcode ,pmj.journalacronym 
	,mc.customername ,mr.status  
	,lio.invoiceid ,lio.payload 
	,lio.response ,lio.remarks 
	,lio.issuccess , to_char(lio.createdon ,'yyyy-mm-dd hh24:mi:ss')as createdon
from salespmo.log_invoice_oodointegration lio 
left join salespmo.trn_rfidetails tr on tr.invoiceid  = lio.invoiceid 
left join wms_workorder ww on ww.workorderid  = tr.workorderid  and coalesce(ww.islock,false) = false
left join pp_mst_journal pmj  on pmj.journalid  = ww.journalid 
left join salespmo.mst_rfistatus mr on mr.rfistatusid  = tr.rfistatusid and mr.isactive  = true
left join public.org_mst_customer_orgmap as corg on
            corg.customerid = ww.customerid
            and corg.countryid = ww.countryid
            and corg.divisionid = ww.divisionid
            and corg.subdivisionid = ww.subdivisionid
            and corg.isactive = 1
left join public.org_mst_customerorg_du_map as cdumap on cdumap.custorgmapid = corg.custorgmapid
left join public.org_mst_deliveryunit ormd on ormd.duid = cdumap.duid and ormd.isactive  = true
left join public.mst_deliveryunit omd on omd.duid = ormd.itrackduid  and omd.isactive = true
left join public.org_mst_customer omc on omc.customerid = ww.customerid	and omc.isactive = true
left join public.mst_customer mc on mc.customerid = omc.itrack_customerid and mc.isactive = true
where  
 cdumap.duid != $1
 and coalesce(ww.workorderid,0) != 0
 
 and lio.createdon ::date between $2::date and $3::date 
 and (ww.itemcode ~* $4 OR
      omd.duname  ~* $4 OR 
      lio.remarks  ~* $4)`;

  return script;
};
