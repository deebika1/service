import jsv from 'json-validator';

export const validator = (reqData, userSchema) => {
  let response = {};
  jsv.validate(reqData, userSchema, (err, messages, test, test1) => {
    if (err) {
      throw err;
    }
    if (Object.keys(messages).length) {
      response = { status: false, message: test1[0] };
    } else {
      response = { status: true, message: [] };
    }
  });

  return response;
};

export const isValidiTracksUrl = url => {
  // Regular expression to check if the string is a valid URL
  const regex = /^[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+\.co\.in$/;
  return regex.test(url);
};
