import express from 'express';
import externalServiceRouter from '../../externalServices/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const externalserviceRoutes = express.Router();

externalserviceRoutes.use('/', handler(externalServiceRouter));

export default externalserviceRoutes;
