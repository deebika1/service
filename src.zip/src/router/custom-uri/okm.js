import express from 'express';
import { updateStatus } from '../../modules/custom-uri/okm.js';

import {
  getFileDetails,
  getToolDetail,
  updateFileTRNLog,
  updateNewFileName,
  updateNewFileNameFromTools,
  UpdateManuscriptzipnameforElseJNL,
  getFileSequence,
  getFileSequenceTemplate,
  getBaseServerPath,
  getFmFileSequenceElsBook,
  getFileSequenceIssueE2E,
  getIssueWorkorderInfo,
  getRevisedFileInfoE2E,
  acsErrorContent,
  getFormattedGraphicPath,
  extractFileConfig,
  getS3UploadDetails,
  uploadS3Payload,
  engineFileCopy,
  insertTrnFiles,
  getLatestStgActy,
} from '../../modules/custom-uri/utils.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/okm/updateStatus', handler(updateStatus));
router.post('/getToolDetail', handler(getToolDetail));
router.post('/getFileDetails', handler(getFileDetails));
router.post('/acscontentwrite', handler(acsErrorContent));
router.post('/updateFileTRNLog', handler(updateFileTRNLog));
router.post('/updateNewFileName', handler(updateNewFileName));
router.post('/updateNewFileNameFromTools', handler(updateNewFileNameFromTools));
router.post(
  '/UpdateManuscriptzipnameforElseJNL',
  handler(UpdateManuscriptzipnameforElseJNL),
);
router.post('/getFileSequence', handler(getFileSequence));
router.post('/getFileSequenceTemplate', handler(getFileSequenceTemplate));
router.post('/getBaseServerPath', handler(getBaseServerPath));
router.post('/getFmFileSequenceElsBook', handler(getFmFileSequenceElsBook));
router.post('/getFileSequenceIssueE2E', handler(getFileSequenceIssueE2E));
router.post('/getIssueWorkorderInfo', handler(getIssueWorkorderInfo));
router.post('/getRevisedFileInfoE2E', handler(getRevisedFileInfoE2E));
router.post('/getFormattedGraphicPath', handler(getFormattedGraphicPath));
router.post('/extractFileConfig', handler(extractFileConfig));
router.post('/getS3UploadDetails', handler(getS3UploadDetails));
router.post('/uploadS3Payload', handler(uploadS3Payload));
router.post('/engineFileCopy', handler(engineFileCopy));

// From electron app insert and update trancesection table bulk insert
router.post('/insertTrnFiles', handler(insertTrnFiles));
router.post('/getlateststgacty', handler(getLatestStgActy));

export default router;
