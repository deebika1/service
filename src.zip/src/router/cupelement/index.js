import express from 'express';

import cupElementRouter from '../../cupelement/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const cupelementRoutes = express.Router();

cupelementRoutes.use('/', handler(cupElementRouter));

export default cupelementRoutes;
