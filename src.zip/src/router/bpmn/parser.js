import express from 'express';
import multer from 'multer';
import { parseBPMN, saveBPMN } from '../../modules/bpmn/parser/index.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();
const bpmnUpload = multer({ dest: 'uploads/' }).single('bpmn');

router.post('/parse', handler(bpmnUpload), handler(parseBPMN));
router.post('/save', handler(saveBPMN));

export default router;
