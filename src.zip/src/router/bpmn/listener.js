import express from 'express';
import {
  getLatestActivityDetails,
  getWfDetails,
  getFileMovementConfig,
  getLatestWorkedActivityDetails,
  getWoEventLogDetails,
  createDb,
  entrytofileTrnDetails,
  updateDb,
  updateDbError,
  updateDbRemark,
  updateAsUnassigned,
  getIncomingFileDetails,
  getPreviousEventLogDetail,
  getBookDetails,
  getFileSeqDetails,
  getBookDetailsForCupJournals,
  getBookDetailsForOupJournals,
  externalTaskPayload,
  fetchPayloadForAricleOrderSequence,
  resetFileDetails,
  getStageInfoFromCamunda,
  updateStageInfoToCamunda,
  updateStageInfoForSequence,
  blobStorageDetails,
  getFileNameForPii,
  updateVariableValueToCamunda,
  updateOtherfieldForWorkorder,
  getBookDetailsForWKHIssueAPI,
  getBookMasterDetails,
} from '../../modules/bpmn/listener/create.js';
import { getIoppJournalDetails } from '../../modules/utils/custom/ioppjournaldetails.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();

router.post('/getLatestActivityDetails', handler(getLatestActivityDetails));
router.post(
  '/getLatestWorkedActivityDetails',
  handler(getLatestWorkedActivityDetails),
);
router.post('/getWfDetails', handler(getWfDetails));
router.post('/getWoEventLogDetails', handler(getWoEventLogDetails));
router.post('/getPreviousEventLogDetail', handler(getPreviousEventLogDetail));
router.post('/getFileMovementConfig', handler(getFileMovementConfig));
router.post('/getIncomingFileDetails', handler(getIncomingFileDetails));
router.post(
  '/updateOtherfieldForWorkorder',
  handler(updateOtherfieldForWorkorder),
);

router.post('/createDb', handler(createDb));
router.post('/entrytofileTrnDetails', handler(entrytofileTrnDetails));
router.post('/updateDb', handler(updateDb));
router.post('/updateAsUnassigned', handler(updateAsUnassigned));
router.post('/updateDbError', handler(updateDbError));
router.post('/updateDbRemark', handler(updateDbRemark));
router.post('/getBookDetails', handler(getBookDetails));
router.post('/getJournalDetails', handler(getIoppJournalDetails));
router.post('/getFileSeqDetails', handler(getFileSeqDetails));
router.post(
  '/getBookDetailsForCupJournals',
  handler(getBookDetailsForCupJournals),
);
router.post(
  '/getBookDetailsForOupJournals',
  handler(getBookDetailsForOupJournals),
);
router.post('/externalTaskPayload', handler(externalTaskPayload));
router.post('/resetFileDetails', handler(resetFileDetails));
router.post('/getStageInfoFromCamunda', handler(getStageInfoFromCamunda));
router.post('/updateStageInfoToCamunda', handler(updateStageInfoToCamunda));
router.post('/updateStageInfoForSequence', handler(updateStageInfoForSequence));
router.post('/blobStorageDetails', handler(blobStorageDetails));
router.post(
  '/fetchPayloadForAricleOrderSequence',
  handler(fetchPayloadForAricleOrderSequence),
);
router.post('/getFileNameForPii', handler(getFileNameForPii));

router.post(
  '/updateVariableValueToCamunda',
  handler(updateVariableValueToCamunda),
);
router.post(
  '/getBookDetailsForWKHIssueAPI',
  handler(getBookDetailsForWKHIssueAPI),
);
router.post('/getBookMasterDetails', handler(getBookMasterDetails));

export default router;
