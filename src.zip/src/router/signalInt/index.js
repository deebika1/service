import express from 'express';

import signalRouter from '../../signalIntegration/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const signalRoutes = express.Router();

signalRoutes.use('/', handler(signalRouter));

export default signalRoutes;
