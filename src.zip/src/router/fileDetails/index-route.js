import express from 'express';
import {
  saveQuantity,
  getTotalPageNum,
  updatePgNumFromPginfo,
  readFileInfo,
} from '../../modules/fileDetails/index.js';
import { uploadFileCreateAndUpdate } from '../../modules/utils/okm/index.js';

import {
  fileUpload,
  fileDelete,
  fileDownload,
  DeleteFilesInBlobFolder,
  localFileGetDownload,
  _downloadBlobFiles,
  _ftpUploadStatusCheck,
  getToolListPath,
} from '../../modules/utils/azure/index.js';

import { filesContainer } from '../../modules/filecontainer/index.js';
import {
  getFileLatestState,
  latestStageAndFiles,
  latestStageAndFilesCUP,
} from './fileDetailsController.js';

import {
  localfileUpload,
  localfileDownload,
  localfileDelete,
} from '../../modules/utils/local/index.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();
router.post('/savePageDetails', handler(saveQuantity));
router.post('/getPageCount', handler(getTotalPageNum));
router.post('/updatePgNumFromPginfo', handler(updatePgNumFromPginfo));
router.post('/uploadFileCreateAndUpdate', handler(uploadFileCreateAndUpdate));
router.post('/fileUpload', handler(fileUpload));
router.post('/fileDelete', handler(fileDelete));
router.post('/fileDownload', handler(fileDownload));
router.post('/localFileGetDownload', handler(localFileGetDownload));
router.post('/readFileInfo', handler(readFileInfo));
router.post('/filedonwloadLocal', handler(localfileDownload));
router.post('/localfileDownload', handler(localfileDownload));
router.post('/DeleteFilesInBlobFolder', handler(DeleteFilesInBlobFolder));
router.post('/filesContainer', handler(filesContainer));
router.post('/_downloadBlobFiles', handler(_downloadBlobFiles));
router.post('/ftpUploadStatusCheck', handler(_ftpUploadStatusCheck));
router.post('/getToolListPath', handler(getToolListPath));
// router.get('/getcount', getcount);
router.post('/localfileUpload', handler(localfileUpload));
router.post('/localfileDelete', handler(localfileDelete));
router.get('/latestStage/:fileName', handler(getFileLatestState));
router.get('/latestStageAndFiles/:fileName', handler(latestStageAndFiles));
router.get(
  '/latestStageAndFilesCUP/:fileName',
  handler(latestStageAndFilesCUP),
);

export default router;
