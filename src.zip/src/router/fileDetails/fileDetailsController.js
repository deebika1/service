/* eslint-disable consistent-return */
import {
  fetchLatestState,
  fetchLatestStageAndFilesService,
  fetchLatestStageAndFilesCUPService,
} from '../../modules/fileDetails/index.js';

// eslint-disable-next-line consistent-return
export const getFileLatestState = async (req, res) => {
  try {
    const { fileName } = req.params;

    if (!fileName) {
      console.warn('Missing fileName in request params');
      return res.status(400).json({ message: 'File name is required.' });
    }

    const latestState = await fetchLatestState(fileName);

    if (!latestState) {
      console.info('No stage found for file:', fileName);
      return res
        .status(404)
        .json({ message: 'No stage found for the given file.' });
    }

    console.info('Latest state fetched successfully for file:', fileName);
    return res.status(200).json(latestState);
  } catch (error) {
    console.error('Error in getFileLatestState:', error);
    return res
      .status(500)
      .json({ message: 'Internal Server Error', error: error.message });
  }
};

export const latestStageAndFiles = async (req, res) => {
  try {
    const { fileName } = req.params;

    if (!fileName) {
      console.warn('Missing fileName in request params');
      return res.status(400).json({ message: 'File name is required.' });
    }

    const response = await fetchLatestStageAndFilesService(fileName);

    if (response.error) {
      return res.status(400).json({ message: response.error });
    }

    res.status(200).json(response);
  } catch (error) {
    console.error('Error in latestStageAndFiles:', error);
    res
      .status(500)
      .json({ message: 'Internal Server Error', error: error.message });
  }
};

export const latestStageAndFilesCUP = async (req, res) => {
  try {
    const { fileName } = req.params;

    if (!fileName) {
      console.warn('Missing fileName in request params');
      return res.status(400).json({ message: 'File name is required.' });
    }

    const response = await fetchLatestStageAndFilesCUPService(fileName);

    if (response.error) {
      return res.status(400).json({ message: response.error });
    }

    res.status(200).json(response);
  } catch (error) {
    console.error('Error in latestStageAndFiles:', error);
    res
      .status(500)
      .json({ message: 'Internal Server Error', error: error.message });
  }
};
