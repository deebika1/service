import express from 'express';
import {
  getftpConfig,
  auditForXmlReader,
  acsftpaudit,
  getauditForXmlReader,
  ActivityConfigDetails,
  updateForActConfig,
  softwareDetails,
  toolDetails,
  OptionList,
  ToolsConfigDetails,
  saveWFStage,
  getWFStageDetails,
  getWFActivityDetails,
  saveWFActivity,
  getFilenameSuggestions,
  getExistingFiles,
  getRejectFiles,
  getFileTransferList,
  getWfFilename,
  deleteFileTransferList,
  toolIOList,
  toolsIOAdd,
  getUserMapDU,
  updateUserMapDU,
  softwareIOList,
  softwareIOAdd,
  toolParamsSuggestions,
  getAllMasterStages,
  getStageOrder,
  saveStageOrder,
  getAllMasterActivities,
  getStageSpecificActivities,
  getStageSpecificMultiActivities,
  saveActivityOrder,
  saveActivityMapping,
  getActivityMapping,
} from '../../modules/configuration/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/ActivityConfigDetails', handler(ActivityConfigDetails));
router.get('/getftpConfig', handler(getftpConfig));
router.post('/auditForXmlReader', handler(auditForXmlReader));
router.post('/acsftpaudit', handler(acsftpaudit));
router.get('/getauditForXmlReader', handler(getauditForXmlReader));
router.post('/updateForActConfig', handler(updateForActConfig));
router.post('/toolDetails', handler(toolDetails));
router.post('/OptionList', handler(OptionList));
router.post('/ToolsConfigDetails', handler(ToolsConfigDetails));
router.post('/getUserMapDU', handler(getUserMapDU));
router.post('/updateUserMapDU', handler(updateUserMapDU));
// router.post('/toolstageDetails',toolstageDetails)
router.post('/toolIOList', handler(toolIOList));
router.post('/toolsIOAdd', handler(toolsIOAdd));
router.post('/toolParamsSuggestions', handler(toolParamsSuggestions));

router.post('/softwareDetails', handler(softwareDetails));
router.post('/softwareIOList', handler(softwareIOList));
router.post('/softwareIOAdd', handler(softwareIOAdd));

router.post('/saveWFStage', handler(saveWFStage));
router.post('/getWFStageDetails', handler(getWFStageDetails));
router.post('/getWFActivityDetails', handler(getWFActivityDetails));
router.post('/saveWFActivity', handler(saveWFActivity));
router.post('/getFilenameSuggestions', handler(getFilenameSuggestions));
router.post('/getExistingFiles', handler(getExistingFiles));
router.post('/getRejectFiles', handler(getRejectFiles));
router.post('/getFileTransferList', handler(getFileTransferList));
router.post('/getWfFilename', handler(getWfFilename));
router.post('/deleteFileTransferList', handler(deleteFileTransferList));

router.post('/getAllMasterStages', handler(getAllMasterStages));
router.post('/getStageOrder', handler(getStageOrder));
router.post('/saveStageOrder', handler(saveStageOrder));
router.post('/getAllMasterActivities', handler(getAllMasterActivities));
router.post('/getStageSpecificActivities', handler(getStageSpecificActivities));
router.post(
  '/getStageSpecificMultiActivities',
  handler(getStageSpecificMultiActivities),
);
router.post('/saveActivityOrder', handler(saveActivityOrder));

router.post('/getActivityMapping', handler(getActivityMapping));
router.post('/saveActivityMapping', handler(saveActivityMapping));
export default router;
