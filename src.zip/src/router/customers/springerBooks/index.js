import express from 'express';

import sprBooksRouter from '../../../customers/springerBooks/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const sprBooksRoutes = express.Router();

sprBooksRoutes.use('/', handler(sprBooksRouter));

export default sprBooksRoutes;
