import express from 'express';
import { emailTrigger } from '../../modules/aduit/email/index.js';
import { trackitTrigger } from '../../modules/aduit/trackit/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/emailTrigger', handler(emailTrigger));
router.post('/trackitTrigger', handler(trackitTrigger));

export default router;
