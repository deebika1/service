import express from 'express';
import authRouter from './auth-router.js';
import taskListRoute from './wms/task-route.js';
import reportRoute from './report/report-route.js';
import customUri from './custom-uri/okm.js';
import workOrderCreation from './wms/woi-route.js';
import BPMN from './bpmn/index.js';
import externalTask from './externalTask/index.js';
import utils from './utils/index.js';
import Master from './master/master-route.js';
import configuration from './configuration/config-route.js';
import Common from './wms/common-route.js';
import wfl from './workflow/route.js';
import fileDetails from './fileDetails/index-route.js';
import uom from './uom/uom-list.js';
import aduit from './aduit/index.js';
import toolRunningStatus from './toolsRunningStatus/tools-running-status.js';
import dllRoute from './iTracks/index.js';
import Notification from './notification/index.js';
import newItrackRouter from './new-iTracks/index.js';
import iAspireRoutes from './iAspire/index.js';
import salesPMORoutes from './salesPmo/index.js';
import odooRoutes from './odoo/index.js';
import cupelementRoutes from './cupelement/index.js';
import iAltRoutes from './iAlt/index.js';
import customersetupRoutes from './customerSetup/index.js';
import signalRoutes from './signalInt/index.js';
import dispatchRoutes from './dispatch/index.js';
import sprBooksRoutes from './customers/springerBooks/index.js';
import cupAuthorUploadRoutes from '../cupAuthorUpload/index.js';
import externalserviceRoutes from './externalServices/index.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };

const router = express.Router();

router.use('/auth', handler(authRouter));
router.use('/api/task', handler(taskListRoute));
router.use('/api/custom-uri', handler(customUri));
router.use('/api/woi', handler(workOrderCreation));
router.use('/api/utils', handler(utils));
router.use('/api/bpmn', handler(BPMN));
router.use('/api/externalTask', handler(externalTask));
router.use('/api/master', handler(Master));
router.use('/api/common', handler(Common));
router.use('/api/fileDetails', handler(fileDetails));
router.use('/api/config', handler(configuration));
router.use('/api/workflow', handler(wfl));
router.use('/api/uom', handler(uom));
router.use('/api/report', handler(reportRoute));
router.use('/api/aduit', handler(aduit));
router.use('/tools/status', handler(toolRunningStatus));
router.use('/api/notification', handler(Notification));

//
router.use('/api/dll', handler(dllRoute));
router.use('/api/itrack', handler(newItrackRouter));
router.use('/api/iaspire', handler(iAspireRoutes));
router.use('/api/salespmo', handler(salesPMORoutes));
router.use('/api/odoo', handler(odooRoutes));
router.use('/api/cupelement', handler(cupelementRoutes));
router.use('/api/customersetup', handler(customersetupRoutes));

router.use('/api/ialt', handler(iAltRoutes));
router.use('/api/signal', handler(signalRoutes));
router.use('/api/dispatch', handler(dispatchRoutes));
router.use('/api/sprbooks', handler(sprBooksRoutes));
router.use('/api/cupauthor', handler(cupAuthorUploadRoutes));
router.use('/api/externalservice', handler(externalserviceRoutes));
export default router;
