import express from 'express';
import {
  getDynamicColumns,
  emailAudit,
  triggerTrackItAPI,
  updateEstimatedValue,
  triggerMailWithAction,
  commontriggerMailWithAction,
} from '../../modules/common/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/getDynamicColumns', handler(getDynamicColumns));
router.post('/emailAudit', handler(emailAudit));
router.post('/triggerTrackItAPI', handler(triggerTrackItAPI));
router.post('/calculateestimatedvalue', handler(updateEstimatedValue));
router.post('/triggerMailWithAction', handler(triggerMailWithAction));
router.post(
  '/commontriggerMailWithAction',
  handler(commontriggerMailWithAction),
);

// API for Camunda Performence Test
// router.post('/CamundaAPI',CamundaAPI)

export default router;
