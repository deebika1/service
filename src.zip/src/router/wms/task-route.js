import express from 'express';
import {
  getAllTask,
  getNewAllTask,
  assigneeList,
  saveView,
  deleteView,
  getFilteredList,
  getPriorityList,
} from '../../modules/task/list.js';
import {
  getHistory,
  saveUploadFile,
  fileRead,
  updateOrderNo,
  updateOrderNoFromIncoming,
  getFilesStatus,
  getFileStatus,
  getProcessAdherence,
  isDownloadAndUploadFile,
  isFileCheckout,
  newDocumentFileupload,
  newFileType,
  fileTypeList,
  checkFileTypeStatus,
  getViewHistory,
  getChecklist,
  getjournalid,
  getviewProofing,
  checktoolLinkStatus,
  updateAuditHistory,
  newFileTypeUpdate,
  updateFileE2EEnableTrn,
  getEventIdForWo,
  getLastInstanceActivity,
  captureUserEvent,
  updateTypeSetPages,
  getWOTypeSetPageList,
  updateRunOnFileSequence,
  getMultiFilesStatusReport,
  getCustomerConfig,
  getToolsStatusDetails,
} from '../../modules/task/taskDetails.js';
import {
  getFileDetails,
  getPlaceHolders,
  fetchCorrection,
  insertCorrectionDetails,
  updateFileSyncStatus,
  getFileDetailsNew,
  getProblemTask,
  getElsevierWF,
  updateDataPT,
  getStandardQuery,
  lockFileSyncStatus,
  setPIIPlaceHolders,
  getConitionalTags,
  updateIsRevisesValue,
  getIsRevisesValue,
  updateIsRevisesReason,
} from '../../modules/task/fileDetails.js';
import {
  preProcess as wfPreProcess,
  process as wfProcess,
} from '../../modules/task/action/workflow/index.js';
import { process as generalProcess } from '../../modules/task/action/general/index.js';
import { defectCategoryList } from '../../modules/task/action/workflow/reject.js';
import {
  getUomHistory,
  updatesStatusValueInToolsApi,
} from '../../modules/task/action/workflow/pending.js';
import { validateUserTask } from '../../modules/task/action/workflow/utils/validation.js';
import {
  getActivityDetails,
  getEventDetails,
  prelims3dCopy,
  getFileSeqByPriority,
  preEditingLinkingDocxCopy,
  copyPreEditingDocxCopy,
  getUserOpenTask,
  copyLinkingDocxFilesForAllChapters,
  jobInfoDetailsUpdate,
  TemplateDetailsUpdate,
  TemplateDetailsDelete,
  trnactivtyEntry,
  getGraphicStageActivityDetails,
  graphicsTrnUpdate,
  getGraphicIterationDetail,
  getCopyEditingLevel,
  setIssueStartPage,
  isDirectFirstProof,
  copyEntFileForAllChapter,
  copyPageTargetForUserTask,
  internalShippingFile,
  copyPageTargetForServiceTask,
  getAllWorkflowConfig,
  checkPBTaskaccess,
  getChapterWoIdDetails,
} from '../../modules/task/index.js';
import {
  getToolsDetails,
  onsaveGetToolsDetails,
  fetchguId,
  fileWriteLocal,
  addpbData,
  getpbData,
  notesToACS,
  DNPACS,
  checkGraphicEnabled,
  exportcollationreport,
  isWordCount,
  onSaveMailTrigger,
  getToolsRunningStatus,
  getFileSequenceSprBooks,
  getxmlValidationFrNewsLetter,
  updateFileSequenceSprBooks,
  addFileSequenceSprBooks,
  getIsUpdatedPackageReqController,
  ElsUpdReqController,
  getPreviousActivityRemarksController,
  getElsevierCustomerStageName,
  getXmlReportURl,
  getBaseCustomerPath,
  skipSuccessTool,
} from '../../modules/task/tools/index.js';
import { invokeTools } from '../../modules/task/tools/invoke.js';
import {
  getToolStatus,
  getToolRunningStatus,
} from '../../modules/task/tools/status.js';
import { getJobInfoDetails } from '../../modules/utils/custom/jobinfoxml.js';
import {
  iTracksReset,
  mailTriggerForiTracks,
} from '../../modules/iTracks/index.js';
import {
  resetModification,
  checkAllTaskCompletionReset,
  resetModificationWithoutCamunda,
  getUnActiveSupplimentary,
} from '../../modules/task/action/workflow/reset.js';
import { getIoppJournalDetails } from '../../modules/utils/custom/ioppjournaldetails.js';
import {
  reassignTaskComplete,
  completeCamundaTask,
  ftpCompleteTask,
  nextStageTriggerAuto,
  iTracksDispatchEngineCall,
  updateWorkOrderStatus,
} from '../../modules/task/action/workflow/save.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();
router.post('/saveView', handler(saveView));
router.post('/deleteView', handler(deleteView));
router.post('/getFilteredList', handler(getFilteredList));
router.post('/getTaskList', handler(getAllTask));
router.post('/getNewTaskList', handler(getNewAllTask));
router.post('/getFileDetails', handler(getFileDetails));
router.post('/getFileDetailsNew', handler(getFileDetailsNew));
router.post('/getProblemTask', handler(getProblemTask));
router.post('/getElsevierWF', handler(getElsevierWF));
router.post('/updateDataPT', handler(updateDataPT));
router.post('/getStandardQuery', handler(getStandardQuery));
router.post('/getActivityDetails', handler(getActivityDetails));
router.post('/prelims3dCopy', handler(prelims3dCopy));
router.post('/preEditingLinkingDocxCopy', handler(preEditingLinkingDocxCopy));
router.post('/copyPreEditingDocxCopy', handler(copyPreEditingDocxCopy));
router.post('/getFileSeqByPriority', handler(getFileSeqByPriority));
router.post(
  '/getGraphicStageActivityDetails',
  handler(getGraphicStageActivityDetails),
);
router.post('/TemplateDetailsDelete', handler(TemplateDetailsDelete));
router.post('/getEventDetails', handler(getEventDetails));
router.post(
  '/copyLinkingDocxFilesForAllChapters',
  handler(copyLinkingDocxFilesForAllChapters),
);
router.post('/jobInfoDetailsUpdate', handler(jobInfoDetailsUpdate));
router.post('/TemplateDetailsUpdate', handler(TemplateDetailsUpdate));
router.post('/iTracksDispatchEngineCall', handler(iTracksDispatchEngineCall));
router.post('/updateFileSyncStatus', handler(updateFileSyncStatus));
router.post('/lockFileSyncStatus', handler(lockFileSyncStatus));
router.post('/getPlaceHolders', handler(getPlaceHolders));
router.post('/fetchCorrection', handler(fetchCorrection));
router.post('/insertCorrectionDetails', handler(insertCorrectionDetails));
router.post('/getConitionalTags', handler(getConitionalTags));
router.post('/assigneeList', handler(assigneeList));
router.post('/completeTasks', handler(reassignTaskComplete));
router.post('/completeCamundaTask', handler(completeCamundaTask));
router.post('/ftpCompleteTask', handler(ftpCompleteTask));
router.post('/getHistory', handler(getHistory));
router.post('/getViewHistory', handler(getViewHistory));
router.post('/getPriorityList', handler(getPriorityList));
router.post('/getJobInfoDetails', handler(getJobInfoDetails));
router.post('/graphicsTrnUpdate', handler(graphicsTrnUpdate));
router.post('/trnactivtyEntry', handler(trnactivtyEntry));
router.post('/getGraphicIterationDetail', handler(getGraphicIterationDetail));
router.post('/getCopyEditingLevel', handler(getCopyEditingLevel));
router.post('/setIssueStartPage', handler(setIssueStartPage));
router.post('/isDirectFirstProof', handler(isDirectFirstProof));
router.post('/copyEntFileForAllChapter', handler(copyEntFileForAllChapter));
router.post('/copyPageTarget', handler(copyPageTargetForUserTask));
router.post('/setPIIPlaceHolders', handler(setPIIPlaceHolders));
router.post('/setIsRevisesValue', handler(updateIsRevisesValue)); // Springer books revised proof stage enable value
router.post('/getIsRevisesValue', handler(getIsRevisesValue));
router.post('/setIsRevisesReason', handler(updateIsRevisesReason));
router.post(
  '/copyPageTargetForServiceTask',
  handler(copyPageTargetForServiceTask),
);
router.post('/internalShippingFile', handler(internalShippingFile));
router.post('/getIoppJournalDetails', handler(getIoppJournalDetails));
router.post('/getChapterWoIdDetails', handler(getChapterWoIdDetails));

// view task info
router.post('/action/workflow/preprocess/:type', handler(wfPreProcess));
router.post('/action/workflow/process/:type', handler(wfProcess));
router.post('/action/general/process/:type', handler(generalProcess));
router.post('/saveUploadFile', handler(saveUploadFile));
router.get('/defectCategoryList', handler(defectCategoryList));
router.post('/fileTypeList', handler(fileTypeList));
router.post('/checkFileTypeStatus', handler(checkFileTypeStatus));
router.post('/getLastInstanceActivity', handler(getLastInstanceActivity));
router.post('/getChecklist', handler(getChecklist));
router.post('/getviewProofing', handler(getviewProofing));
router.post('/getjournalid', handler(getjournalid));
// router.post('/getviewProofingEntity',getviewProofingEntity)
router.post('/checktoolLinkStatus', handler(checktoolLinkStatus));
router.post('/getUomHistory', handler(getUomHistory));
router.post(
  '/updatesStatusValueInToolsApi',
  handler(updatesStatusValueInToolsApi),
);
router.post('/newDocumentFileupload', handler(newDocumentFileupload));
router.post('/newFileType', handler(newFileType));
router.post('/newFileTypeUpdate', handler(newFileTypeUpdate));
router.post('/updateFileE2EEnableTrn', handler(updateFileE2EEnableTrn));
router.post('/resetModification', handler(resetModification));
router.post(
  '/resetModificationWithoutCamunda',
  handler(resetModificationWithoutCamunda),
);
router.post(
  '/checkAllTaskCompletionReset',
  handler(checkAllTaskCompletionReset),
);
router.post('/getUnActiveSupplimentary', handler(getUnActiveSupplimentary));

router.get('/fileRead', handler(fileRead));
router.post('/isFileCheckout', handler(isFileCheckout));

router.post('/reorderFile', handler(updateOrderNo));
router.post('/reorderFileFromIncoming', handler(updateOrderNoFromIncoming));
router.post('/updateAuditHistory', handler(updateAuditHistory));
router.post('/getEventIdForWo', handler(getEventIdForWo));
router.post('/isDownloadAndUploadFile', handler(isDownloadAndUploadFile));

router.post('/getFilesStatus', handler(getFilesStatus));
router.post('/getProcessAdherence', handler(getProcessAdherence));
router.post('/getToolsStatusDetails', handler(getToolsStatusDetails));
router.post('/getFileStatus', handler(getFileStatus));

router.post('/validateUserTask', handler(validateUserTask));

// Task Tools
router.post('/getToolsDetails', handler(getToolsDetails));
router.post('/getToolStatus', handler(getToolStatus));
router.post('/invokeTools', handler(invokeTools));
router.post('/completeWorkorder', handler(updateWorkOrderStatus));
router.post('/onsaveGetToolsDetails', handler(onsaveGetToolsDetails));
router.post('/fetchguId', handler(fetchguId));
router.post('/acsworkingpath', handler(fileWriteLocal));
router.post('/addpbData', handler(addpbData));
router.post('/getpbData', handler(getpbData));
router.post(
  '/getElsevierCustomerStageName',
  handler(getElsevierCustomerStageName),
);
router.post('/notestoacs', handler(notesToACS));
router.post('/dnpacs', handler(DNPACS));
router.post('/getFileSequence', handler(getFileSequenceSprBooks));
router.post('/getworkflowType', handler(getxmlValidationFrNewsLetter));

router.post('/updateFileSequence', handler(updateFileSequenceSprBooks));
router.post('/addFileSequence', handler(addFileSequenceSprBooks));
router.post('/skipSuccessTool', handler(skipSuccessTool));
// router.post('/doNotPublishACS', handler(doNotPublishACS));
router.post('/checkGraphicEnabled', handler(checkGraphicEnabled));
router.post('/uploadxltoFTP', handler(exportcollationreport));
router.post('/isWordCount', handler(isWordCount));
router.post('/onSaveMailTrigger', handler(onSaveMailTrigger));

router.post('/getUserOpenTask', handler(getUserOpenTask));
router.post('/productionReset', handler(iTracksReset));
router.post('/getToolsRunningStatus', handler(getToolsRunningStatus));

router.post('/captureUserEvent', handler(captureUserEvent));

router.post('/updateTypeSetPages', handler(updateTypeSetPages));
router.post('/updateRunOnFileSequence', handler(updateRunOnFileSequence));
router.post('/getWOTypeSetPageList', handler(getWOTypeSetPageList));
router.post('/nextStageTriggerAuto', handler(nextStageTriggerAuto));
router.post('/mailTriggerForiTracks', handler(mailTriggerForiTracks));
router.post('/iTracksDispatchEngineCall', handler(iTracksDispatchEngineCall));
router.post('/getAllWorkflowConfig', handler(getAllWorkflowConfig));
router.post('/checkPBTaskaccess', handler(checkPBTaskaccess));
router.post('/getMultiFilesStatusReport', handler(getMultiFilesStatusReport));

router.post('/getCustomerConfig', handler(getCustomerConfig));
router.post('/getToolRunningStatus', handler(getToolRunningStatus));
router.post(
  '/getIsUpdatedPackageReq',
  handler(getIsUpdatedPackageReqController),
);
router.post('/elsUpdReq', handler(ElsUpdReqController));
router.post(
  '/getPreviousActivityRemarks',
  handler(getPreviousActivityRemarksController),
);
router.post('/getXmlReportUrl', handler(getXmlReportURl));
router.post('/getBasePath', handler(getBaseCustomerPath));

export default router;
