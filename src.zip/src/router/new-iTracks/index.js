import express from 'express';

import iQualityRouter from '../../iquality/router/route.js';
import iProductivityRouter from '../../iProductivity/router/route.js';
import iAspireRouter from '../../iAspire/router/route.js';
import menuScreenRouter from '../../masterScreenMap/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const newItrackRouter = express.Router();

newItrackRouter.use('/iquality', handler(iQualityRouter));
newItrackRouter.use('/iproductivity', handler(iProductivityRouter));
newItrackRouter.use('/iaspire', handler(iAspireRouter));
newItrackRouter.use('/masterScreenmap', handler(menuScreenRouter));

export default newItrackRouter;
