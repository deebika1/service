import express from 'express';
import {
  getWIPReport,
  getWIPReportTwo,
  getWipNonWms,
  getWIPDetailedReport,
  getProductivityReport,
  getReportOptionLists,
  getQualityReport,
  getQualityReportOptionLists,
  getMonitoringReport,
  getMonitoringReportOptionList,
  getWIPWorkorderReport,
  getWIPChapterReport,
  exportWOReport,
  insertWipStageNotes,
  activityTrackList,
  getdownloadmanuscript,
  getactivitystartend,
  getdownloadmanuscriptfile,
  getManuscriptStatus,
  getStageCreatedCount,
  getToolsMasterAccessRightsReport,
  getToolsMasterAccessRights,
  getToolsListServerPath,
  getUsersByCustomer,
  getUsersByDeliveryUnit,
  postToolsMasterAccessRights,
  addNewTool,
  getWipEngineActivityReport,
  getAuditReport,
  getCompletedWorkOrders,
  getFTPAuditReport,
  getFTPDownloadReportSpringer,
  getDownloadUploadManuscriptReport,
  getJobsheetHistoryforSpringer,
  getDespatchFailureReport,
  ftpjobretrigger,
  getFilepathforSpringer,
  getOverallJobHistory,
  getFTPDownloadReportACS,
  getPBTaskData,
  getElsBasePath,
  getCopyeditingQueACS,
  getFilepathforACS,
  getAcknowledgementReportACS,
  getSwiftXMLReport,
  getLicenseChaserReport,
  testFunction,
  getFTPReport,
  getTATWKH,
  getnotefromcustomerACS,
  getMonthwiseDelivery,
  getEngineFailure,
  getXMLtrackerReportACS,
  getFTPFailure,
  updateFTPFailure,
  getCAMSAcknowledge,
  insertCAMSAcknowledge,
  getnotefromVendorReport,
  doNotPublishReport,
  GetShiftWiseInflowReport,
  GetShiftWiseInOutReportMaster,
  GetShiftWiseOutflowReport,
  GetOutflowPivotReport,
  getOverallFileStatusReport,
  getOverallFileOptionLists,
  getCampusSignalAuditReport,
  convertFilesReport,
} from '../../modules/report/wip/index.js';
import {
  getJobSummaryReport,
  stageListForCustomer,
  activityListForStage,
  getUserList,
} from '../../modules/report/jobSummary/index.js';
import { graphicImageDelete } from '../../modules/report/graphicImageDelete/index.js';
import { toolsWIPReport } from '../../modules/report/toolsWIP/index.js';
import { GetQualityRemarks } from '../../modules/report/other/index.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();

router.post('/getWIPReport', handler(getWIPReport));
router.post('/getWIPReportTwo', handler(getWIPReportTwo));
router.post('/getWipReportNonWms', handler(getWipNonWms));
router.post('/testFunction', handler(testFunction));
router.post('/getStageCreatedCount', handler(getStageCreatedCount));
router.post('/getDespatchFailureReport', handler(getDespatchFailureReport));
router.post('/getWipEngineActivityReport', handler(getWipEngineActivityReport));
router.post('/getAuditReport', handler(getAuditReport));
router.post('/getCompletedWorkOrders', handler(getCompletedWorkOrders));
router.post('/getFTPAuditReport', handler(getFTPAuditReport));
router.post(
  '/getFTPDownloadReportSpringer',
  handler(getFTPDownloadReportSpringer),
);
router.post(
  '/getDownloadUploadManuscriptReport',
  handler(getDownloadUploadManuscriptReport),
);
router.post(
  '/getJobsheetHistoryforSpringer',
  handler(getJobsheetHistoryforSpringer),
);
router.post('/getFilepathforSpringer', handler(getFilepathforSpringer));
router.post(
  '/getToolsMasterAccessRightsReport',
  handler(getToolsMasterAccessRightsReport),
);
router.post('/getToolsMasterAccessRights', handler(getToolsMasterAccessRights));
router.post('/getToolsListServerPath', handler(getToolsListServerPath));
router.post('/getUsersByCustomer', handler(getUsersByCustomer));
router.post('/getUsersByDeliveryUnit', handler(getUsersByDeliveryUnit));
router.post(
  '/postToolsMasterAccessRights',
  handler(postToolsMasterAccessRights),
);
router.post('/addNewTool', handler(addNewTool));
router.post('/getWIPDetailedReport', handler(getWIPDetailedReport));
router.post('/getProductivityReport', handler(getProductivityReport));
router.post('/getReportOptionLists', handler(getReportOptionLists));
router.post('/getQualityReport', handler(getQualityReport));
router.post(
  '/getQualityReportOptionLists',
  handler(getQualityReportOptionLists),
);
router.post('/getMonitoringReport', handler(getMonitoringReport));
router.post(
  '/getMonitoringReportOptionList',
  handler(getMonitoringReportOptionList),
);
router.post('/getWIPWorkorderReport', handler(getWIPWorkorderReport));
router.post('/getWIPChapterReport', handler(getWIPChapterReport));
router.post('/exportWOReport', handler(exportWOReport));
router.post('/insertWipStageNotes', handler(insertWipStageNotes));
router.post('/activityTrackList', handler(activityTrackList));
router.post('/getdownloadmanuscript', handler(getdownloadmanuscript));
router.post('/getdownloadmanuscriptfile', handler(getdownloadmanuscriptfile));
router.post('/getswiftxmlreport', handler(getSwiftXMLReport));
router.post('/getlicensechaserreport', handler(getLicenseChaserReport));
router.post('/getManuscriptStatus', handler(getManuscriptStatus));
router.post('/getactivitystartend', handler(getactivitystartend));
router.post('/ftpjobretrigger', handler(ftpjobretrigger));
router.post('/getJobSummaryReport', handler(getJobSummaryReport));
router.post('/stageListForCustomer', handler(stageListForCustomer));
router.post('/activityListForStage', handler(activityListForStage));
router.post('/getUserList', handler(getUserList));
router.post('/graphicImageDelete', handler(graphicImageDelete));
router.post('/toolsWIPReport', handler(toolsWIPReport));
router.post('/getOverallJobHistory', handler(getOverallJobHistory));
router.post('/getFTPDownloadReportACS', handler(getFTPDownloadReportACS));
router.post('/getPBTaskData', handler(getPBTaskData));
router.post('/getElsBasePath', handler(getElsBasePath));
router.post('/getFilepathforACS', handler(getFilepathforACS));
router.post('/getCopyeditingQueACS', handler(getCopyeditingQueACS));
router.post(
  '/getAcknowledgementReportACS',
  handler(getAcknowledgementReportACS),
);
router.post('/getFTPReport', handler(getFTPReport));
router.post('/gettat', handler(getTATWKH));
router.post('/getnotefromcustomerACS', handler(getnotefromcustomerACS));
router.post('/getnotefromVendorReport', handler(getnotefromVendorReport));
router.post('/getshiftwiseinflowreport', handler(GetShiftWiseInflowReport));
router.post(
  '/getshiftwiseinoutreportmaster',
  handler(GetShiftWiseInOutReportMaster),
);
router.post('/getshiftwiseoutflowreport', handler(GetShiftWiseOutflowReport));
router.post('/getoutflowpivotreport', handler(GetOutflowPivotReport));
router.post('/getqualityremarks', handler(GetQualityRemarks));

router.post('/doNotPublishReport', handler(doNotPublishReport));
router.post('/convertFilesReport', handler(convertFilesReport));
router.post('/getOverallFileStatusReport', handler(getOverallFileStatusReport));
router.post('/getOverallFileOptionLists', handler(getOverallFileOptionLists));

router.post('/getDeliveryReport', handler(getMonthwiseDelivery));
router.post('/getEngineFailure', handler(getEngineFailure));
router.post('/getFTPFailure', handler(getFTPFailure));
router.post('/updateFTPFailure', handler(updateFTPFailure));

// For ACS Ready XML Tracker Report
router.post('/getXMLtrackerReportACS', handler(getXMLtrackerReportACS));

// Cams acknowledgement report
router.post('/getCAMSAcknowledge', handler(getCAMSAcknowledge));
router.post('/insertCAMSAcknowledge', handler(insertCAMSAcknowledge));
router.post('/getCampusSignalAuditReport', handler(getCampusSignalAuditReport));

export default router;
