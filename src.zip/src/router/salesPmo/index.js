import express from 'express';
import salesPMORouter from '../../salesPMO/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const salesPMORoutes = express.Router();

salesPMORoutes.use('/', handler(salesPMORouter));

export default salesPMORoutes;
