import express from 'express';
import odooRouter from '../../odoo/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const odooRoutes = express.Router();

odooRoutes.use('/', handler(odooRouter));

export default odooRoutes;
