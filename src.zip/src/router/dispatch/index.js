import express from 'express';
import {
  dispatchFromIauthor,
  updateDispatchFromIauthor,
} from '../../modules/dispatch/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };

router.post('/dispatchFromIauthor', handler(dispatchFromIauthor));
router.post('/updateDispatchFromIauthor', handler(updateDispatchFromIauthor));

export default router;
