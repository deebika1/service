import express from 'express';
import {
  iTracksCall,
  logisticEntryUpdateRetrigger,
  stageRetrigger,
  create_CoverArticle,
} from '../../modules/iTracks/index.js';
import { taskHistoryDelete } from '../../modules/task/index.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();

router.post('/woCreation', handler(iTracksCall));
router.post('/taskHistoryDelete', handler(taskHistoryDelete));
router.post(
  '/logisticEntryUpdateRetrigger',
  handler(logisticEntryUpdateRetrigger),
);
router.post('/stageRetrigger', handler(stageRetrigger));

router.post('/createCoverArticle', handler(create_CoverArticle));

export default router;
