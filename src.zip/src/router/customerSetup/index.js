import express from 'express';

import CustSetupRouter from '../../customerSetup/router/route.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const customersetupRoutes = express.Router();

customersetupRoutes.use('/', handler(CustSetupRouter));

export default customersetupRoutes;
