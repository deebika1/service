import dotenv from 'dotenv';
// import { initializeLogger } from './modules/utils/logs/index.js/index.js';

dotenv.config({ path: `env/${process.env.MODE}.env` });
// await initializeLogger();
