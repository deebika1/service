import express from 'express';

import {
  altextGenerationJobController,
  journalJobProcessController,
  updateXMLPreviewController,
  ialtFailedAcknowledgeService,
  srcFileDownloadFromPiiController,
  checkVTWSignalReceivedController,
  getJournalSignalAuditController,
  getJournalSignalHistoryController,
} from '../controller/index.js';

const signalRouter = express.Router();
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

signalRouter.post(
  '/altextGenerationJobProcess',
  handler(altextGenerationJobController),
);

signalRouter.post('/journalJobProcess', handler(journalJobProcessController));
signalRouter.post('/updateXMLPreview', handler(updateXMLPreviewController));
signalRouter.post(
  '/wmsFailedAcknowledge',
  handler(ialtFailedAcknowledgeService),
);
signalRouter.post(
  '/srcFileDownloadFromPii',
  handler(srcFileDownloadFromPiiController),
);

signalRouter.get(
  '/checkVTWSignalReceived/:pii/:servicetype/:jobflowtype',
  handler(checkVTWSignalReceivedController),
);

signalRouter.post(
  '/getJournalSignalAudit',
  handler(getJournalSignalAuditController),
);

signalRouter.post(
  '/getJournalSignalHistory',
  handler(getJournalSignalHistoryController),
);

export default signalRouter;
