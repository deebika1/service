/* eslint-disable prefer-const */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
// import axios from 'axios';
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import moment from 'moment';
import { _triggerIaltWorkflowController } from '../../iAlt/controller/index.js';
import {
  workorderCreation,
  woServiceCreation,
  woStageCreation,
  addIncoming,
} from '../../iAlt/datalayer/index.js';
import { query, transaction } from '../../database/postgres.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import {
  fileCopyForElsevierJournal,
  wmsWorkflowTrigger,
  _saveChapter,
} from '../../modules/woi/incoming.js';
// import { ialtFailedAcknowledgeService } from './elseVier/altTextJobProcess.js';
import { creation } from '../../modules/woi/autoArticleWoContainer.js';
import { convertDateFormat } from '../../iAlt/service/index.js';

const service = new Service();

const jobTypeObj = {
  1: 'Article',
  2: 'Issue',
  3: 'Non Article',
};

export const iAltAutoJobCreationService = payload => {
  return new Promise(async (resole, reject) => {
    const { jobFlowType, signalAuditId } = payload;
    try {
      const logHisPayload = {
        signalAuditId,
        request: payload,
      };
      if (!jobFlowType && !signalAuditId) {
        const msg =
          'Required filed "Job Type | signalAuditId " is missing from the payload';
        logHisPayload.response = msg;
        logHisPayload.status = 'Failed';
        logHisPayload.message = msg;
        logHisPayload.processStatusId = 16;
        await ialtSignalLogHistory(logHisPayload);
        throw new Error(msg);
      }
      if (jobFlowType === 'ialt') {
        await altTextJobCreation(payload);
      } else {
        await altArticleJobCreation(payload);
      }

      resole({ status: true, message: 'Job creation successfull!' });
    } catch (err) {
      reject(err);
    }
  });
};
const altTextJobCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    let jobCreationPayload = { ...payload };
    try {
      let logHisPayload = {
        signalAuditId,
        request: payload,
        response: 'Job creation process has started',
        message: 'Job creation process has started',
        status: 'Success',
        processStatusId: 6,
      };
      await ialtSignalLogHistory(logHisPayload);

      await validatePayload(payload);

      jobCreationPayload = await readMetadata(jobCreationPayload);
      jobCreationPayload = await constructPayloadForBookCreation(
        jobCreationPayload,
      );
      jobCreationPayload = await constructPayloadForIaltWOCreation(
        jobCreationPayload,
      );
      // const filesRes = await getSourceFileResponse(jobCreationPayload);
      // jobCreationPayload = { ...jobCreationPayload, ...filesRes };
      const bookInfo = await bookCreationProcess(jobCreationPayload);

      jobCreationPayload = { ...jobCreationPayload, ...bookInfo };
      await getAutoJobSourceFilesUpdateQueue(jobCreationPayload);

      // to be removed due auto job queue implementation
      // if (jobCreationPayload.chapterInfo.files.length) {
      //   await incomingCreationProcess(jobCreationPayload);
      //   //  await workflowTriggerProcess(jobCreationPayload);
      // } else {
      //   const msg = `Auto extraction failed due to vector images. Manual processing required.`;
      //   logHisPayload = {
      //     signalAuditId,
      //     request: jobCreationPayload,
      //     response: msg,
      //     message: msg,
      //     status: 'Success',
      //     processStatusId: 29,
      //   };
      //   await ialtSignalLogHistory(logHisPayload);
      // }

      const msg = `Job creation process completed`;
      logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 12,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ status: true, message: msg });
    } catch (err) {
      const msg = `Job creation process failed`;
      const logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Failed',
        processStatusId: 21,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
const validatePayload = payload => {
  return new Promise((resolve, reject) => {
    try {
      const { jobFlowType, signalAuditId, title, stageName, dms, metaData } =
        payload;
      if (
        !jobFlowType &&
        !signalAuditId &&
        Object.keys(dms).length &&
        metaData &&
        title &&
        stageName
      ) {
        throw new Error('Required filed is missing from the payload');
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
export const readMetadata = item => {
  return new Promise((resolve, reject) => {
    try {
      const payload = {
        ...item,
      };
      // delete payload.metaData; //no need metaData above metaData info present
      resolve(payload);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};

// construct iAlt book payload
export const constructPayloadForBookCreation = data => {
  return new Promise((resolve, reject) => {
    try {
      const payload = {
        ...data,
        bookInfo: {
          ...data.bookInfo,
          duId: data.duId,
          customerId: data.customerId,
          country: '1',
          authorName: '',
          // edition: Math.floor(1000 + Math.random() * 9000),
          edition: 1,
          chapterCount: '1',
          startDate: moment().format('YYYY-MM-DD hh:mm:ss'),
          endDate: data.bookInfo.dueDate,
          instruction: '',
          customerType: 'Higher Education',
          piiNumber: data.piiNumber,
        },
      };
      resolve(payload);
    } catch (error) {
      reject(error);
    }
  });
};
// construct iAlt chaptercreation payload

export const constructPayloadForIaltWOCreation = data => {
  return new Promise((resolve, reject) => {
    try {
      const payload = {
        ...data,
        chapterInfo: {
          ...data.chapterInfo,
          wfId: data.wfId,
          customerId: data.customerId,
          woType: data.jobFlowType,
          duId: data.duId,
          serviceId: data.serviceId,
          stageId: data.stageId,
          stageIteration: data.stageIteration,
          bookId: data.bookId,
          imageCount: 0,
          complexityId: 1,
          piiNumber: data.piiNumber,
        },
      };
      resolve(payload);
    } catch (error) {
      reject(error);
    }
  });
};

// ialt signal log
export const ialtSignalLogService = (data, action) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        jobFlowTypeId,
        serviceCallType,
        piiNumber,
        response,
        ackMsgInfo,
        signalAuditId,
        duId,
        customerId,
        updateType,
        status,
        message,
        processStatusId,
      } = data;
      let sql = ``;
      if (action == 'Insert') {
        sql = `INSERT INTO wms_mst_signal_audit(
	      jobflowtypeid, servicecalltype, duid, customerid, pii, signalinfo, status, receiveddate)
	      VALUES (${jobFlowTypeId}, '${serviceCallType}', ${duId}, ${customerId}, '${piiNumber}', '${JSON.stringify(
          ackMsgInfo,
        )}', 'In Progress', CURRENT_TIMESTAMP) RETURNING signalauditid`;
      } else if (updateType === 'acknowledged') {
        sql = `UPDATE wms_mst_signal_audit SET acknowledgeddate=CURRENT_TIMESTAMP WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
      } else if (updateType === 'completed') {
        sql = `UPDATE wms_mst_signal_audit SET status='Completed', completeddate=CURRENT_TIMESTAMP WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
      } else if (updateType === 'failed') {
        sql = `UPDATE wms_mst_signal_audit SET status='Failed', faileddate=CURRENT_TIMESTAMP WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
      } else if (updateType === 'inprogress') {
        sql = `UPDATE wms_mst_signal_audit SET status='In Progress' WHERE signalauditid=${signalAuditId} RETURNING signalauditid`;
      }
      const result = await query(sql);
      const auditId = result[0].signalauditid;
      if (action == 'Insert') {
        const payload = {
          signalAuditId: auditId,
          request: {},
          response,
          processStatusId,
          status,
          message,
        };
        await ialtSignalLogHistory(payload);
      }
      resolve({
        status: true,
        data: auditId,
        message:
          action == 'Insert'
            ? 'Log inserted successfully'
            : 'Log updated successfully',
      });
    } catch (error) {
      reject({ status: false, message: error.message ? error.message : error });
    }
  });
};
export const ialtSignalLogHistory = data => {
  return new Promise(async (resolve, reject) => {
    let sql = ``;
    try {
      const {
        status,
        message,
        processStatusId,
        signalAuditId,
        request,
        response,
      } = data;
      sql = `INSERT INTO wms_mst_signal_audit_trns(signalauditid, processstatusid, request, response, createdon, message, status)
      VALUES (${signalAuditId}, ${processStatusId},'${
        JSON.stringify(request) || null
      }','${
        JSON.stringify(response) || null
      }', CURRENT_TIMESTAMP, '${message}', '${status}' ) RETURNING signalaudittrnsid`;
      await query(sql);
      resolve({ status: true, message: 'Log trns inserted successfully' });
    } catch (error) {
      reject({ status: false, message: error.message ? error.message : error });
    }
  });
};

// get incoming files extracted pdf and images response from ialt team
export const getSourceFileResponse = payload => {
  return new Promise(async (resolve, reject) => {
    let logHisPayload = {};
    const { signalAuditId, originalFiles } = payload;
    try {
      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: 'Source file upload to iAlt has started',
        message: 'Source file upload to iAlt has started',
        status: 'Success',
        processStatusId: 7,
      };
      //await ialtSignalLogHistory(logHisPayload);

      let egiFiles = [];
      let referenceFiles = [];

      if (originalFiles && originalFiles.length > 0) {
        // Filter for isegiFile: true and get pathWithSAS
        egiFiles = originalFiles
          .filter(item => item.isegiFile)
          .map(item => item.pathWithSAS);

        // Filter for isegiFile: false and get pathWithSAS
        referenceFiles = originalFiles
          .filter(item => !item.isegiFile)
          .map(item => item.pathWithSAS);
      }

      const payloadArray = {
        files: egiFiles && egiFiles.length > 0 ? egiFiles : referenceFiles,
        ReferenceFile: referenceFiles,
      };

      const url = config.iAlt.base_url + config.iAlt.uri.ialtFileUploadFromBlob;
      const result = await service.post(url, payloadArray);
      const filteredData = Array.isArray(result?.data)
        ? result.data.filter(file => file?.imageurl)
        : [];
      // let result = {};
      // result.data = [
      //   {
      //     short_description: '',
      //     long_description: '',
      //     short_descriptionedit: '',
      //     long_descriptionedit: '',
      //     caption: '',
      //     assettype: 'image',
      //     page_no: '',
      //     image_number: '',
      //     image_chapter: '',
      //     short_description_accuracy: '100%',
      //     long_description_accuracy: '100%',
      //     notes: '',
      //     isActive: true,
      //     revision: 0,
      //     _id: '669617bb54f1ab04d7107529',
      //     imagename: 'ee952b7c-798b-4e80-9022-7f89a89e7799/page_1_image_0.png',
      //     imageurl:
      //       'https://integraproductsasa.blob.core.windows.net/alt/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_0.png',
      //     thumbnailurl:
      //       'https://integraproductsasa.blob.core.windows.net/alt/dev/upload/thumbnail/ee952b7c-798b-4e80-9022-7f89a89e7799_2024-07-16_06-47-43/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_0.png',
      //     originalType: 'image/png',
      //     fileType: 'image/png',
      //     size: '65.88 KB',
      //     service: '',
      //     project_id: '',
      //     client_id: '',
      //     apiStatus: '0',
      //     updatedBy: '',
      //     updatedOn: '2024-07-16T06:48:27.000Z',
      //     __v: 0,
      //   },
      //   // {
      //   //   short_description: '',
      //   //   long_description: '',
      //   //   short_descriptionedit: '',
      //   //   long_descriptionedit: '',
      //   //   caption: '',
      //   //   assettype: 'pdf',
      //   //   page_no: '',
      //   //   image_number: '',
      //   //   image_chapter: '',
      //   //   short_description_accuracy: '100%',
      //   //   long_description_accuracy: '100%',
      //   //   notes: '',
      //   //   isActive: true,
      //   //   revision: 0,
      //   //   _id: '669617bb54f1ab04d710752a',
      //   //   imagename: 'ee952b7c-798b-4e80-9022-7f89a89e7799/page_1_image_1.png',
      //   //   imageurl:
      //   //     'https://integraproductsasa.blob.core.windows.net/alt/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_1.png',
      //   //   thumbnailurl:
      //   //     'https://integraproductsasa.blob.core.windows.net/alt/dev/upload/thumbnail/ee952b7c-798b-4e80-9022-7f89a89e7799_2024-07-16_06-47-43/test/upload/extractimagefrompdf/output_folder_ee952b7c-798b-4e80-9022-7f89a89e7799.pdf_2024-07-16_06-47-43_page_1_image_1.png',
      //   //   originalType: 'image/png',
      //   //   fileType: 'image/png',
      //   //   size: '238.33 KB',
      //   //   service: '',
      //   //   project_id: '',
      //   //   client_id: '',
      //   //   apiStatus: '0',
      //   //   updatedBy: '',
      //   //   updatedOn: '2024-07-16T06:48:27.000Z',
      //   //   __v: 0,
      //   // },
      // ];

      if (filteredData.length) {
        filteredData.forEach((list, i) => {
          list.filesequence = i + 1;
          list.filetypeid = 85;
          list.complexityid = 1;
          list.caption = list.caption.replace(/(')/g, '$1$1');
        });
      }
      payload.chapterInfo.files = filteredData;
      payload.chapterInfo.imageCount = filteredData.length;
      payload.chapterInfo.complexityId = 1;

      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: payload.chapterInfo.files,
        message: 'Source file upload to iAlt has been completed',
        status: 'Success',
        processStatusId: 8,
      };
      //  await ialtSignalLogHistory(logHisPayload);

      resolve(payload);
    } catch (error) {
      let resError;
      if (typeof error === 'object' && error !== null) {
        resError =
          error.message?.data?.message ??
          error.message ??
          'Source file upload to iAlt has failed';
      } else {
        resError = 'Source file upload to iAlt has failed';
      }
      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: resError,
        message: 'Source file upload to iAlt has failed',
        status: 'Failed',
        processStatusId: 17,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject({ status: false, message: resError });
    }
  });
};
// book , chapter, service and stage creation process
export const bookCreationProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      // book creation process
      const { bookId } = await ialtAutoBookCreate(payload.bookInfo);
      payload.chapterInfo.bookId = bookId;
      payload.bookId = bookId;
      // chapter creation process
      const { data } = await workorderCreation(payload.chapterInfo);
      payload.chapterInfo.workorderId = data.workorderid;
      payload.workorderId = data.workorderid;
      // service creation process
      await woServiceCreation(payload.chapterInfo);
      // stage creation process
      await woStageCreation(payload.chapterInfo);
      const msg =
        'Book chapter, service, or stage has been created successfully';
      // const logHisPayload = {
      //   signalAuditId,
      //   request: payload,
      //   response: msg,
      //   message: msg,
      //   status: 'Success',
      //   processStatusId: 9,
      // };
      //  await ialtSignalLogHistory(logHisPayload);
      resolve(payload);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message
          ? err.message
          : 'Book, chapter, service, or stage creation failed',
        message: 'Book, chapter, service, or stage creation failed',
        status: 'Success',
        processStatusId: 18,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
export const incomingCreationProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      // incoming creation process
      await addIncoming(payload.chapterInfo);
      const msg = 'Incoming creation process has been completed';
      // const logHisPayload = {
      //   signalAuditId,
      //   request: payload,
      //   response: msg,
      //   message: msg,
      //   status: 'Success',
      //   processStatusId: 10,
      // };
      //   await ialtSignalLogHistory(logHisPayload);
      resolve({ status: true, message: msg });
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message
          ? err.message
          : 'Incoming creation process failed',
        message: 'Incoming creation process failed',
        status: 'Failed',
        processStatusId: 19,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
export const workflowTriggerProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      payload.chapterInfo.assetType = 'image';
      payload.chapterInfo.isSignalTrigger = true;
      payload.chapterInfo.actionType = 'trigger';
      const { status } = await _triggerIaltWorkflowController(
        payload.chapterInfo,
      );
      let msg = 'Workflow not triggered, waiting for pdf extraction review';
      if (status) {
        // msg = 'Workflow triggered successfully';
        // const logHisPayload = {
        //   signalAuditId,
        //   request: payload,
        //   response: msg,
        //   message: msg,
        //   status: 'Success',
        //   processStatusId: 11,
        // };
        // await ialtSignalLogHistory(logHisPayload);
      } else {
        const logHisPayload = {
          signalAuditId,
          request: payload,
          response: msg,
          message: msg,
          status: 'Success',
          processStatusId: 30,
        };
        await ialtSignalLogHistory(logHisPayload);
      }
      resolve({ status: true, message: msg });
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message ? err.message : 'Workflow trigger failed',
        message: 'Workflow trigger failed',
        status: 'Failed',
        processStatusId: 20,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};

// create book ialt auto workorder creation
export const ialtAutoBookCreate = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        title,
        isbn,
        country,
        authorName,
        edition,
        duId,
        userId,
        customerId,
        chapterCount,
        endDate,
        customerType,
        instruction,
        piiNumber,
      } = payload;
      let bookId = '';
      let sql = `select bookid from ialt_books where isbn ='${isbn}' and isactive =true`;
      const checkExits = await query(sql);

      const startDueDate = await query(`SELECT * FROM 
      add_hours_exclude_weekends_and_holidays
    (CURRENT_TIMESTAMP::timestamp(0),48 ::integer)`);

      let formattedStartDate = await convertDateFormat(
        startDueDate?.[0]?.add_hours_exclude_weekends_and_holidays,
      );

      if (!checkExits.length) {
        const sql = `INSERT INTO ialt_books (
          bookname, countryname, authorname, editorname, duid, chaptercount, customerid, 
          receiveddate, isactive, isbn, filetype, assetuploaded, createdby, instruction, 
          startdate, piinumber
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP, true, $8, $9, true, $10, $11, CURRENT_TIMESTAMP, $12
        ) RETURNING bookid`;

        const values = [
          title,
          country,
          authorName,
          edition,
          duId,
          chapterCount,
          customerId,
          isbn,
          customerType,
          userId,
          instruction,
          piiNumber,
        ];

        const response = await query(sql, values);

        bookId = response.length ? response[0].bookid : null;

        const sql2 = `UPDATE ialt_books SET startdate ='${formattedStartDate}'  WHERE bookid = ${bookId}
        RETURNING bookid;`;
        await query(sql2);
      } else {
        bookId = checkExits.length ? checkExits[0].bookid : null;
        const sql1 = `select count(*) from wms_workorder where bookid =${bookId}`;
        const countRes = await query(sql1);
        const count = parseInt(countRes?.[0]?.count, 10) || 0; // Default to 0 if count is not available
        const sql2 = `UPDATE ialt_books SET chaptercount = ${
          count + 1
        } WHERE bookid = ${bookId}`;
        await query(sql2);
      }
      resolve({ bookId });
    } catch (error) {
      reject({ status: false, message: error.message ? error.message : error });
    }
  });
};

// ialt article job creation
const altArticleJobCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    let jobCreationPayload = { ...payload };
    try {
      let logHisPayload = {
        signalAuditId,
        request: payload,
        response: 'Job creation process has started',
        message: 'Job creation process has started',
        status: 'Success',
        processStatusId: 6,
      };
      await ialtSignalLogHistory(logHisPayload);

      await validatePayload(payload);
      // await checkWOExists(payload);

      jobCreationPayload = await readMetadata(jobCreationPayload);
      jobCreationPayload = await constructPayloadForArticleWOCreation(
        jobCreationPayload,
      );
      const woResponse = await artilceWoCreationProcess(jobCreationPayload);
      const { workorderId } = woResponse;
      jobCreationPayload.workorderId = workorderId;
      await articleAutoIncomingCreationProcess(jobCreationPayload);
      await workflowTriggerProcess(jobCreationPayload);

      const msg = `Job creation process completed`;
      logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 12,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ status: true, message: msg });
    } catch (err) {
      const msg = `Job creation process failed`;
      const logHisPayload = {
        signalAuditId,
        request: jobCreationPayload,
        response: msg,
        message: msg,
        status: 'Failed',
        processStatusId: 21,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// construct payload for article workorder creation
const constructPayloadForArticleWOCreation = async item => {
  return new Promise(async (resolve, reject) => {
    const { jobFlowType, customerName, jobType } = item;
    try {
      // get journal information from customer and journal acronym
      const journalDetail = await getCustomerJournalDetail(item);
      if (journalDetail) {
        // change string to integer from journalDetails array
        journalDetail.customer = parseInt(journalDetail.customer);
        journalDetail.division = parseInt(journalDetail.division);
        journalDetail.subDivision = parseInt(journalDetail.subDivision);
        journalDetail.country = parseInt(journalDetail.country);
        journalDetail.duId = parseInt(journalDetail.duId);
        journalDetail.colours = parseInt(journalDetail.colours);
        journalDetail.softwares = parseInt(journalDetail.softwares);
        journalDetail.languages = parseInt(journalDetail.languages);
        journalDetail.CELevel = parseInt(journalDetail.CELevel);
        journalDetail.journalId = parseInt(journalDetail.journalId);
        journalDetail.custOrgMapId = parseInt(journalDetail.custOrgMapId);
        journalDetail.services = journalDetail.serviceId;
        journalDetail.custPrimaryContact = journalDetail.primaryContact;
        journalDetail.custSecondaryContact = journalDetail.secondaryContact;
        journalDetail.kamName = journalDetail.KAMContact;
        journalDetail.clientManager = journalDetail.CMContact;
        // create payload for workorder creation
        const jobTypeId = Object.keys(jobTypeObj).find(
          key => jobTypeObj[key] === jobType,
        );
        const sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE duid=$1 and customerid=$2`;
        const dmsInfo = await query(sql, [
          journalDetail.duId,
          journalDetail.customer,
        ]);
        const { dmsid } = dmsInfo.length ? dmsInfo[0] : '';
        if (dmsid) {
          const payload = {
            ...item,
            ...journalDetail,
            woType: jobFlowType,
            customerId: journalDetail.customer,
            userId: item.createdBy,
            doiNumber: item.title,
            jobId: item.name,
            jobTitle: item.title,
            jobTypeId,
            jobTypeName: jobTypeObj[jobType],
            externalUsers: journalDetail.editorDetails,
            noOfChapters: 1,
            pageWidth: journalDetail.trimesizewidth,
            pageWidthUnit: journalDetail.trimesizewidthuom,
            pageHeight: journalDetail.trimesizeheight,
            pageHeightUnit: journalDetail.trimesizeheightuom,
            dmsId: dmsid,
          };
          resolve(payload);
        } else {
          throw new Error(
            `DMS type not mapping for the customer ${customerName}`,
          );
        }
      } else {
        throw new Error(
          `Journal details not found for the customer ${customerName}`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};
// ialt article workorder creation process
const artilceWoCreationProcess = async payload => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId } = payload;
    try {
      let result = {};
      await transaction(async client => {
        result = await creation(payload, client);
      });
      const { data } = result;
      const msg =
        'Book chapter, service, or stage has been created successfully';
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: msg,
        message: msg,
        status: 'Success',
        processStatusId: 9,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve({ workorderId: data.workorderid, status: true, message: msg });
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: payload,
        response: err.message
          ? err.message
          : 'Book, chapter, service, or stage creation failed',
        message: 'Book, chapter, service, or stage creation failed',
        status: 'Success',
        processStatusId: 18,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// Auto incoming creation from API trigger based customer
export const articleAutoIncomingCreationProcess = async req => {
  return new Promise(async (resolve, reject) => {
    const { workorderId } = req.body;
    let payload = req.body;
    try {
      const incomingPayload = await constructIncomingPayload(payload);
      const { files, containerType, jobType, fileType } = incomingPayload;

      let sql = `select wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,stage.stageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid, wo.isonlineissue,
            wo.duid, wo.wfid
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid 
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId} order by wostageid limit 1`;
      // and updatedon is not null
      const woDetails = await query(sql);
      if (woDetails.length) {
        // files.forEach(async fi => {
        //   sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        //   const fileTypeRes = await query(sql);
        //   fi.filetypeid = fileTypeRes[0].filetypeid;
        //   fi.filetype = fileTypeRes[0].filetype;
        // });
        sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        const fileTypeRes = await query(sql);
        files[0].filetypeid = fileTypeRes[0].filetypeid;
        files[0].filetype = fileTypeRes[0].filetype;

        const workflow = {
          name: woDetails[0].wfname,
          id: woDetails[0].wfname_bpmnid,
          category: woDetails[0].wfcategory,
          enableListener: woDetails[0].wfconfig
            ? !!woDetails[0].wfconfig.enableListener
            : false,
          incoming: {
            fileTypes:
              woDetails[0].wfconfig &&
              woDetails[0].wfconfig.incoming &&
              woDetails[0].wfconfig.incoming.fileTypes
                ? woDetails[0].wfconfig.incoming.fileTypes
                : [],
          },
        };
        const serviceInfo = {
          id: woDetails[0].serviceid,
          name: woDetails[0].servicename,
        };
        woDetails[0].workflow = workflow;
        woDetails[0].service = serviceInfo;
        payload = {
          woid: workorderId,
          service: {
            id: woDetails[0].serviceid,
            name: woDetails[0].servicename,
          },
          stageid: woDetails[0].wfstageid,
          receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
          duedate: new Date(woDetails[0].plannedenddate).toISOString(),
          updatedby: woDetails[0].updatedby,
          batchno: 0,
          valuesOfArray: files,
          totalArticleCount: 1,
          totalNonArticleCount: 0,
          totalCount: 0,
          totalChapterCount: null,
          fileNameISBN: '',
        };
        const response = await _saveChapter({ body: payload }, { res: {} });

        const fileCopyPayload = {
          resData: response.data,
          woDetails: woDetails[0],
          files,
          containerType,
          jobTypeName: jobTypeObj[jobType],
        };
        await fileCopyForElsevierJournal(fileCopyPayload);

        for (let k = 0; k < files.length; k++) {
          const filteredObj = response.data.find(
            sublist => sublist.filename == files[k].filename,
          );
          files[k].woincomingfileid = files[k].woincomingfileid
            ? files[k].woincomingfileid
            : filteredObj.woincomingfileid;
        }
        await wmsWorkflowTrigger({ woDetails: woDetails[0], files });
        resolve({
          message: `Auto incoming success for ${workorderId}`,
          data: {
            stageId: woDetails[0].wfstageid,
            stageName: woDetails[0].stagename,
            iteration: 1,
          },
          status: true,
        });
      } else {
        reject({
          message: `Auto incoming failed due to wokflow details not found for ${workorderId}`,
        });
      }
    } catch (e) {
      reject({
        message: e.message
          ? e.message
          : `Auto incoming failed for ${workorderId}`,
        status: false,
      });
    }
  });
};
// create incoming payload for auto incoming creation
export const constructIncomingPayload = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const file = [
        {
          filetypeid: '',
          filetype: '',
          jobType: payload.jobType,
          filename: payload.fileName,
          extention: payload.extention,
          filepath: payload.sourcePath ? payload.sourcePath : null,
          fileuuid: '',
          duedate: payload.dueDate,
          mspages: payload.msPages,
          imagecount: 1,
          estimatedpages: 0,
          tablecount: 0,
          equationcount: 0,
          boxcount: 0,
          wordcount: 0,
          referencecount: 0,
          filesequence: 1,
        },
      ];
      const incomingPayload = {
        workorderId: payload.workorderId,
        containerType: payload.containerType,
        files: file,
        jobType: payload.jobType,
        fileType: payload.fileType,
      };
      resolve(incomingPayload);
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};

// get journal details from customer and journal acronym
const getCustomerJournalDetail = data => {
  const { customerName, journalAcronym } = data;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `select a.colorid::bigint as colours ,a.softwareid::bigint  as softwares ,a.languageid::bigint as languages ,a.celevelid::bigint as  "CELevel",a.printissn as "printISSN" ,
        b.divisionid::bigint as division ,b.subdivisionid::bigint as "subDivision",b.countryid::bigint as country ,b.customerid::bigint as  customer,d.duid as "duId",
        a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
        a.journalid as "journalId"
        from pp_mst_journal a
              JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
              JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
              JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid
              JOIN org_mst_customer e on e.customerid=b.customerid
              where a.isactive = 1 AND b.isactive = 1
              AND (LOWER(e.customername) = LOWER('${customerName}')
              or  LOWER(e.customershortname) = LOWER('${customerName}')
              )
              AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;
      const journalRes = await query(sql);
      if (journalRes.length) {
        sql = `select * from org_mst_customerorg_contact where custorgmapid=${journalRes[0].custOrgMapId}`;
        const journalContactRes = await query(sql);
        sql = ` select * from pp_mst_journal as journal join pp_mst_journal_contacts as journalcontact on
          journalcontact.journalid=journal.journalid where journal.journalacronym = '${journalAcronym}'`;
        const journalOtherContactRes = await query(sql);

        const journalInfo = journalRes[0];
        journalContactRes.forEach(list => {
          if (list.isprimary && list.contacttype === 'Customer') {
            journalInfo.primaryContact = list.custorgconmapid;
          } else if (!list.isprimary && list.contacttype === 'Customer') {
            journalInfo.secondaryContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'KAM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.KAMContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'CM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.CMContact = list.custorgconmapid;
          }
        });
        if (journalOtherContactRes.length) {
          const ecInfo = journalOtherContactRes.filter(
            list => list.designation == 10,
          );
          journalInfo.editorDetails = ecInfo.map(item => {
            return {
              name: item.name,
              role: '10',
              email: item.email,
              roleAcronym: 'EC',
            };
          });
        }

        resolve(journalInfo);
      } else {
        reject({
          message: `Journal details not found for the customer ${customerName} `,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const isSignalExist = async (piiNumber, servicecalltype) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT signalauditid FROM wms_mst_signal_audit WHERE pii ='${piiNumber}' and servicecalltype = '${servicecalltype}'`;
      const response = await query(sql);
      resolve(response.length > 1 ? true : false);
    } catch (e) {
      reject(e);
    }
  });
};

export const getSignalAuidtInfo = piiNumber => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM wms_mst_signal_audit WHERE pii ='${piiNumber}' order by signalauditid asc `;
      const response = await query(sql);
      if (response.length) {
        resolve(response[0]);
      } else {
        resolve(false);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const checkChapterExists = (data, signalAckPayload) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { chapterName, isbn } = data;
      const { piiNumber } = signalAckPayload;
      // const { signalAuditId } = signalAckPayload;
      const sql = `
      SELECT ialt_books.bookname, wms_workorder.itemcode
      FROM wms_workorder
      JOIN ialt_books ON ialt_books.bookid = wms_workorder.bookid
      WHERE ialt_books.isbn = $1
        AND wms_workorder.itemcode = $2
        AND wms_workorder.isactive = true
        AND ialt_books.isactive = true
    `;

      const values = [isbn, chapterName];

      const result = await query(sql, values);

      if (result.length) {
        // const logHisPayload = {
        //   signalAuditId,
        //   request: data,
        //   response: `Chapter (${chapterName}) already exists for the title - ${isbn}`,
        //   message: 'Chapter already exists for the title',
        //   status: 'Success',
        //   processStatusId: 28,
        // };
        // await ialtSignalLogHistory(logHisPayload);
        // await ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
        resolve({
          status: false,
          message: `Chapter (${chapterName}) already exists for the title - ${isbn}`,
        });
      } else {
        resolve({ status: true, message: 'Chapter info not exists' });
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getAutoJobSourceFilesUpdateQueue = payload => {
  return new Promise(async (resolve, reject) => {
    let logHisPayload = {};
    const { signalAuditId, originalFiles } = payload;
    try {
      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: 'Source file upload to iAlt has started',
        message: 'Source file upload to iAlt has started',
        status: 'Success',
        processStatusId: 7,
      };
      //await ialtSignalLogHistory(logHisPayload);

      let egiFiles = [];
      let referenceFiles = [];

      if (originalFiles && originalFiles.length > 0) {
        // Filter for isegiFile: true and get pathWithSAS
        egiFiles = originalFiles
          .filter(item => item.isegiFile)
          .map(item => item.pathWithSAS);

        // Filter for isegiFile: false and get pathWithSAS
        referenceFiles = originalFiles
          .filter(item => !item.isegiFile)
          .map(item => item.pathWithSAS);
      }
      payload.chapterInfo.clientid = 14;
      payload.chapterInfo.client = 'Elsevier';
      const payloadArray = {
        ...payload.chapterInfo,
        files: egiFiles && egiFiles.length > 0 ? egiFiles : referenceFiles,
        ReferenceFile: referenceFiles,
      };
      const url =
        config.iAlt.base_url + config.iAlt.uri.ialtUploadFilesQueueSchedular;

      //  const url = `http://BCPINT-L043:3000/v1/ialtimage/uploadFilesforExtractionQueueSchedular`;
      const result = await service.post(url, [payloadArray]);
      resolve(result);
    } catch (error) {
      let resError;
      if (typeof error === 'object' && error !== null) {
        resError =
          error.message?.data?.message ??
          error.message ??
          'Source file upload to iAlt has failed';
      } else {
        resError = 'Source file upload to iAlt has failed';
      }
      logHisPayload = {
        signalAuditId,
        request: originalFiles,
        response: resError,
        message: 'Source file upload to iAlt has failed',
        status: 'Failed',
        processStatusId: 17,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject({ status: false, message: resError });
    }
  });
};

export const getJournalSignalAuditService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, filterObj } = payload;
      let condition = `Where audit.isactive = true`;
      for (const key in filterObj) {
        if (
          // eslint-disable-next-line no-prototype-builtins
          filterObj.hasOwnProperty(key) &&
          (filterObj[key] == null || filterObj[key] == '')
        ) {
          delete filterObj[key];
        }
      }
      let arrayFilter = Object.keys(filterObj);

      if (arrayFilter.length) {
        arrayFilter.forEach((key, index) => {
          if (filterObj[key]) {
            condition += ` ${
              index == 0 ? ' AND' : ''
            } ${key} = ${`'${filterObj[key]}'`}  ${
              arrayFilter.length - 1 != index ? 'AND' : ''
            } `;
          }
        });
      }
      if (searchText) {
        condition += ` AND audit.pii ILIKE '%${searchText.toLowerCase()}%'`;
      }
      // payload.status = status;
      payload.condition = condition;
      const response = await _getJournalSignalAuditService(
        payload,
        searchText.toLowerCase(),
      );
      resolve({ response });
    } catch (error) {
      reject(error);
    }
  });
};
export const _getJournalSignalAuditService = async (payload, searchText) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { isServerSide } = payload;
      let { condition } = payload;
      if (!isServerSide) {
      } else {
        const { pageNo, recordPerPage, type } = payload;
        let offset = (pageNo - 1) * recordPerPage;

        let sql = `select * from wms_mst_signal_audit as audit join
        wms_mst_jobflowtype as flowtype on audit.jobflowtypeid = flowtype.jobflowtypeid
         ${condition ? `${condition}` : condition}`;

        const getResCount = await query(sql);
        if (getResCount.length > 0) {
          const numOfPages = Math.ceil(getResCount.length / recordPerPage);
          const paginationQuery = `LIMIT ${recordPerPage} OFFSET ${
            searchText ? 0 : offset
          }`;

          const sql = `
            SELECT 
              audit.signalauditid,
              audit.pii,
              audit.status,
              TO_CHAR(audit.receiveddate, 'DD-MM-YYYY HH:MI AM') AS receiveddate,
              TO_CHAR(audit.acknowledgeddate, 'DD-MM-YYYY HH:MI AM') AS acknowledgeddate,
              TO_CHAR(audit.completeddate, 'DD-MM-YYYY HH:MI AM') AS completeddate,
              TO_CHAR(audit.faileddate, 'DD-MM-YYYY HH:MI AM') AS faileddate,
              audit.servicecalltype,
              COALESCE(workorder.itemcode, 'WO Not Yet Created') as itemcode
            FROM wms_mst_signal_audit AS audit
            JOIN wms_mst_jobflowtype AS flowtype 
              ON audit.jobflowtypeid = flowtype.jobflowtypeid  
            Left JOIN wms_workorder AS workorder 
              ON workorder.otherfield->>'pii' = audit.pii
              ${condition}
              ORDER BY audit.signalauditid DESC 
              ${paginationQuery};
              `;

          const response = await query(sql);

          resolve({
            status: true,
            data: response,
            total: getResCount.length,
            numOfPages,
          });
        } else {
          resolve({
            status: true,
            data: [],
            total: 0,
            numOfPages: 0,
            message: 'No data found',
          });
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const getJournalSignalHistoryService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { signalauditid } = payload;
      const sql = `select * from wms_mst_signal_audit_trns where signalauditid=${signalauditid}
      order by signalaudittrnsid desc`;
      const response = await query(sql);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};
