/* eslint-disable no-unreachable */
/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
import AWS from 'aws-sdk';
// import  { fs } from 'fs';
import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  unlinkSync,
  rm,
  rmSync,
  writeFile,
  unlink,
  createWriteStream,
  writeFileSync,
  promises as fspromise,
} from 'fs';
import path from 'path';
import https from 'https';
import { randomUUID } from 'crypto';
import moment from 'moment';
// eslint-disable-next-line import/no-extraneous-dependencies
import AdmZip from 'adm-zip';
// eslint-disable-next-line import/no-extraneous-dependencies
import soap from 'soap';
import xml2js from 'xml2js';
// eslint-disable-next-line import/no-extraneous-dependencies
import { DOMParser, XMLSerializer } from 'xmldom';
import axios from 'axios';
import { query } from '../../../database/postgres.js';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import {
  ialtSignalLogService,
  ialtSignalLogHistory,
  iAltAutoJobCreationService,
  checkChapterExists,
  isSignalExist,
} from '../index.js';
import { emitAction } from '../../../modules/activityListener/index.js';
import {
  getNotificationTemplate,
  _triggerMailWithAction,
} from '../../../modules/common/index.js';
import {
  _uploads3File,
  _download,
} from '../../../modules/utils/azure/index.js';
import { getFolderStructureForIalt } from '../../../modules/utils/wmsFolder/index.js';
import {
  _localFolderCopy,
  _localZIPCopyWithExtract,
} from '../../../modules/utils/local/index.js';
import logger from '../../../modules/utils/logs/index.js';

const __dirname = path.resolve();
const service = new Service();

// Configure the AWS SDK with your credentials and region
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

const s3 = new AWS.S3();
const sqs = new AWS.SQS({ apiVersion: '2012-11-05' });
const bucketName = process.env.AWS_ELSEVIER_BUCKET_NAME;
const folderPath = 'contributors/158184564625';
const queueURL = process.env.SQS_QUEUE_URL;

export const journalJobService = async data => {
  let errorPii = 'Pii';
  return new Promise(async (resolve, reject) => {
    let jobPayload = {};
    const generalInfo = {
      customerId: 14,
      customerName: 'Elsevier',
      // journalAcronym: 'INTCPC',
      duId: 95,
      wfId: 43,
      jobFlowType: 'Journal',
      jobFlowTypeId: 1,
    };
    try {
      if (!Object.keys(data).length) {
        throw new Error('Job received without payload');
      }
      const jobInfo = await readJobData(data);
      errorPii = jobInfo?.piiNumber;
      const isOldSignal = await isSignalExist(
        jobInfo?.piiNumber,
        jobInfo?.serviceCallType,
      );
      if (isOldSignal) {
        resolve(true);
        return;
      }
      // initial log entry
      let logPayload = {
        ...generalInfo,
        ...jobInfo,
        response: data,
        message: 'Job request received',
        status: 'Success',
        processStatusId: 1,
      };
      const { data: signalAuditId } = await ialtSignalLogService(
        logPayload,
        'Insert',
      );
      jobPayload = {
        ...jobPayload,
        signalAuditId,
        ...generalInfo,
        ...jobInfo,
      };
      try {
        const signalAckPayload = {
          signalAuditId,
          piiNumber: jobInfo.piiNumber,
          ackMsgInfo: jobInfo.ackMsgInfo,
        };
        await ialtJobReceivedAcknowledgeService(signalAckPayload);
        if (
          jobInfo.serviceCallType === 'LaTeX' ||
          jobInfo.serviceCallType === 'rerouted'
        ) {
          logger.info('before get meta data api call');
          // get the metadata info
          const result = await getMetaData(signalAckPayload);
          logger.info('after get meta data api call');
          const bookInfo = await readMetadata(result);

          jobPayload = {
            ...jobPayload,
            signalAuditId,
            ...generalInfo,
            ...jobInfo,
            bookInfo,
          };
          logger.info('before download api call');
          // download source files
          const assetDownloadRes = await downloadAssetFile(
            bookInfo.assetInfo,
            signalAckPayload,
          );
          logger.info('after download api call');
          // Specify the path where you want to save the ZIP file
          const tempFolder = `tempFolder/CAS-FLOW/${jobInfo.piiNumber}/`;
          // const tempFolder = path.join(__dirname, 'tempFolder/CAS-FLOW/');

          await downloadFileFromBuffer(assetDownloadRes, tempFolder);

          const xmlString = await findAndReadXmlFile(tempFolder);
          logger.info(xmlString, 'xmlString');
          logger.info('before updatexml preview api call');

          await _updateXMLPreviewService(
            xmlString,
            'preview',
            signalAuditId,
            bookInfo.journalAcronym,
            jobPayload.customerId,
            jobPayload.piiNumber,
          );
          logger.info('after updatexml preview api call');

          let wmsFolder = '02_WMS_dev';
          if (process.env.MODE === 'test') {
            wmsFolder = '02_WMS_test';
          } else if (process.env.MODE === 'uat') {
            wmsFolder = '02_WMS_uat';
          } else if (process.env.MODE === 'live') {
            wmsFolder = '02_WMS';
          }
          const sourceInfo = assetDownloadRes.find(item =>
            item.filename.includes('.zip'),
          );
          // const tempFolder = path.join(__dirname, 'tempFolder/CAS-FLOW/');
          // Specify the path where you want to save the ZIP file
          const destPath = `//integrafs2/ElsJournals/${wmsFolder}/${bookInfo.journalAcronym}/CAS-FLOW/${jobPayload.piiNumber}/${sourceInfo.filename}`;

          logger.info('_localZIPCopyWithExtract Starts.');
          const resOfFileCopy = await _localZIPCopyWithExtract({
            sourceInfo,
            destPath,
            unZipTypes: ['.xml'],
          });
          logger.info('_localZIPCopyWithExtract End.');

          // temprorary - need to be removed
          rmSync(tempFolder, { recursive: true, force: true });
          // await _ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
          const mailPayload = {
            action: 'elsevier_vtw_to_iwms_success',
            woTypeId: jobPayload.jobFlowTypeId,
            customerId: jobPayload.customerId,
            journalAcronym: bookInfo.journalAcronym,
            piiNumber: jobPayload.piiNumber,
          };
          await sendMail(mailPayload);
          resolve(true);
        } else {
          await _ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
          // const mailPayload = {
          //   action: 'elsevier_vtw_queue_failure',
          //   customerId: jobPayload.customerId,
          //   subj: `Elsevier Journal | VTW Signal process failure - ${jobPayload.piiNumber}`,
          //   content: `We Cannot Finish request - Invalid Service call type ${jobInfo.serviceCallType}.`,
          // };
          // await sendMail(mailPayload);
          reject({
            status: false,
            message: `We Cannot Finish request - Invalid Service call type ${jobInfo.serviceCallType}.`,
          });
        }
      } catch (err) {
        logPayload = {
          signalAuditId,
          response: err.message || err,
          updateType: 'failed',
        };
        await ialtSignalLogService(logPayload, 'Update');
        throw new Error(err.message || err);
      }
    } catch (err) {
      // const mailPayload = {
      //   action: 'auto_create_failure',
      //   woTypeId: jobPayload.jobFlowTypeId,
      //   customerId: jobPayload.customerId,
      //   to: [],
      //   title: jobPayload?.bookInfo?.title
      //     ? jobPayload.bookInfo.title
      //     : 'Failed in initial process',
      //   stageName: jobPayload?.bookInfo?.stage ? jobPayload.bookInfo.stage : '',
      //   message: err.message ? err.message : err,
      // };
      // await sendMail(mailPayload);
      reject({
        status: false,
        message: `${errorPii} - ${
          err.message ? err.message : JSON.stringify(err)
        }`,
      });
    } finally {
      /* empty */
    }
  });
};
// Function to send a message to SQS
export const sendMessageToSQSService = async messageBody => {
  try {
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: '',

      // QueueUrl: `${queueURL}/${process.env.SQS_QUEUE_NAME}`,
    };
    const data = await sqs.sendMessage(params).promise();
  } catch (err) {
    logger.info('Error sending message', err);
  }
};
export const listInBucketsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const data = await s3
        .listObjectsV2({
          Bucket: payload.bucketName,
          Prefix: payload.folderPath,
        })
        .promise();
      resolve(data.Contents);
      // to get all buckets
      // s3.listBuckets((err, data) => {
      //   if (err) {
      //
      //   } else {
      //
      //   }
      // });
    } catch (err) {
      logger.info('Error listing objects in bucket:', err);
      reject(err); // Throw error for caller to handle
    }
  });
};
// Function to delete a message from the SQS queue
const deleteMessage = async receiptHandle => {
  const params = {
    QueueUrl: queueURL,
    ReceiptHandle: receiptHandle,
  };

  try {
    // await sqs.deleteMessage(params).promise();
  } catch (err) {
    logger.info('Error deleting message:', err);
  }
};
export const uploadFileToS3Service = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      filePath,
      signalAuditInfo: { signalauditid: signalAuditId, signalinfo: ackMsgInfo },
    } = payload;
    let params = {};
    try {
      // Download the file from the provided folder URL
      const url = new URL(filePath);
      const fileName = path.basename(url.pathname);
      const tempFilePath = `tempFolder/${fileName}`; // Temporary download path
      try {
        await downloadFileFromUrl(filePath, tempFilePath);
        // Read content from the file
        const fileContent = readFileSync(tempFilePath);
        // Setting up S3 upload parameters
        params = {
          Bucket: `${bucketName}`,
          Key: `${folderPath}/${fileName}`,
          Body: fileContent,
          ACL: 'bucket-owner-full-control',
        };
        // Uploading files to the bucket
        const data = await s3.upload(params).promise();

        const logHisPayload = {
          signalAuditId,
          request: params,
          response: data,
          message: 'Final output has been uploaded successfully',
          status: 'Success',
          processStatusId: 22,
        };
        await ialtSignalLogHistory(logHisPayload);
        resolve(data);
      } catch (err) {
        const logHisPayload = {
          signalAuditId,
          updateType: 'failed',
          request: params,
          response: err.message ? err.message : err,
          message: 'Final output upload has failed',
          status: 'Failed',
          processStatusId: 23,
        };
        await ialtSignalLogService(logHisPayload, 'Update');
        await ialtSignalLogHistory(logHisPayload);
        const ackPaylod = {
          signalAuditId,
          ackMsgInfo,
        };
        await _ialtFailedAcknowledgeService(ackPaylod, 'Failed');
        reject(err); // Throw error for caller to handle
      } finally {
        unlinkSync(tempFilePath); // Clean up temporary file
      }
    } catch (err) {
      reject(err);
    }
  });
};
const downloadFileFromUrl = (fileUrl, destPath) => {
  return new Promise((resolve, reject) => {
    const file = createWriteStream(destPath);

    https
      .get(fileUrl, response => {
        response.pipe(file);
        file.on('finish', () => {
          file.close(resolve); // close() is async, resolve after close completes.
        });
      })
      .on('error', err => {
        unlink(destPath, () => reject(err)); // Delete the file async. (But we don't check the result)
      });
  });
};
export const altTextUploadNotification = (data, signalAuditInfo) => {
  return new Promise(async (resolve, reject) => {
    const { Location, ETag, piiNumber, key } = data;
    const { signalauditid: signalAuditId, signalinfo: ackMsgInfo } =
      signalAuditInfo;

    let payload = {};
    try {
      const assetVersion = ETag.replace(/^"|"$/g, '');
      const fileName = path.basename(Location);
      payload = {
        '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
        '@type': 'bam:ContentObjects',
        'bam:hasContentObjects': [
          {
            '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
            '@type': 'bam:Metadata',
            '@id': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
            'dct:language': 'en',
            'ecm:identifier': `pii:${piiNumber}`,
            'dct:title': 'Como articular la cooperación en red',
            'prism:aggregationType': [
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3',
            ],
            'dct:type':
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3.1',
            'bam:hasAssetMetadata': [
              {
                '@id': `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                '@type': 'bam:AssetMetadata',
                'dct:isFormatOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'dct:format':
                  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'bam:assetType': 'ALTERNATE-TEXT',
                'bam:assetVersion': `${assetVersion}`,
                'prism:byteCount': 2619,
                'bam:mode': 'private',
                'bam:filename': `${fileName}`,
                'bam:multiPart': false,
              },
            ],
            'bam:hasGeneration': [
              {
                '@type': 'bam:Generation',
                'bam:isGenerationOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'bam:hasAsset': [
                  `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                ],
                'bam:classificationLevel': 'public',
                'bam:stage': 'uncorrected_proof',
                'bam:hasGeneration': [],
              },
            ],
          },
        ],
      };
      const url = `${config.iAlt.else_vier.base_url}/${config.iAlt.else_vier.uri.upload}`;
      const result = await service.ialtPost(url, payload);

      const logHisPayload = {
        signalAuditId,
        updateType: 'completed',
        request: payload,
        response: result.data,
        message: 'Final output upload acknowledgment has been set successfully',
        status: 'Success',
        processStatusId: 25,
      };
      await ialtSignalLogHistory(logHisPayload);
      await ialtSignalLogService(logHisPayload, 'Update');

      resolve(result);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        updateType: 'failed',
        request: payload,
        response: err.message ? err.message : err,
        message: 'Final output upload acknowledgment has failed',
        status: 'Failed',
        processStatusId: 26,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);

      const ackPaylod = {
        signalAuditId,
        ackMsgInfo,
      };
      await _ialtFailedAcknowledgeService(ackPaylod, 'Failed');
      reject('Alt text upload notification sending failed');
    }
  });
};

const getMetaData = signalAckPayload => {
  return new Promise(async (resolve, reject) => {
    const { piiNumber, signalAuditId, ackMsgInfo } = signalAckPayload;
    const url = `${config.iAlt.else_vier.base_url}/metadata/pii/${piiNumber}`;
    try {
      const result = await service.ialtGet(url);
      if (Object.keys(result).length) {
        const logHisPayload = {
          signalAuditId,
          request: url,
          response: result,
          message: 'Metadata fetching request successful',
          status: 'Success',
          processStatusId: 3,
        };
        await ialtSignalLogHistory(logHisPayload);
        resolve(result);
      } else {
        logger.info('Metadata info not found');
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: url,
        response: err.message?.data || err,
        message: 'Metadata fetching request failed',
        status: 'Failed',
        processStatusId: 3,
      };
      await ialtSignalLogHistory(logHisPayload);

      // await _ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
      reject(err.message ? err.message : err);
    }
  });
};
export const readJobData = jobData => {
  return new Promise((resolve, reject) => {
    try {
      const serviceCallType = path.basename(jobData['msg:service']['svc:type']);
      const piiNumber = path.basename(jobData['msg:service']['svc:about']);
      // const chpData = jobData['msg:service']['svc:params'][0];
      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);
      const ackMsgInfo = {
        messageSMSId: path.basename(jobData['@id']),
        serviceSMSId: path.basename(jobData['msg:service']['@id']),
        serviceAboutUrl: jobData['msg:service']['svc:about'],
      };

      // const chapterInfo = {
      //   name: `${chpData.chapterPit} ${chpData.chapterNumber}`,
      //   title: chpData.chapterTitle,
      //   startDate: moment().format('YYYY-MM-DD hh:mm:ss'),
      //   endDate: moment(futureDate).format('YYYY-MM-DD hh:mm:ss'),
      //   userId: 'System',
      // };
      resolve({ serviceCallType, piiNumber, ackMsgInfo });
    } catch (error) {
      logger.info('Error parsing JSON:', error);
      reject(error);
    }
  });
};
export const readMetadata = result => {
  return new Promise((resolve, reject) => {
    try {
      const jobInfo = {};
      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);
      const allStageSourceInfo = result['bam:hasGeneration'];
      let stageSourceInfo = [];
      stageSourceInfo = result['bam:hasGeneration'].filter(
        item => item['bam:stage'] === 'accepted_manuscript',
      );
      const getMaxVerison = stageSourceInfo.reduce(
        (max, row) =>
          row['bam:generation'] > max['bam:generation'] ? row : max,
        stageSourceInfo[0],
      );
      const assetInfo = getMaxVerison['bam:hasAsset'];
      jobInfo.receivedStage = getMaxVerison['bam:stage'];
      jobInfo.title = result['prism:publicationName'];
      jobInfo.isbn = result['prism:isbn']
        ? result['prism:isbn'].replace(/-/g, '')
        : null;
      jobInfo.assetInfo = assetInfo;
      jobInfo.dueDate = moment(futureDate).format('YYYY-MM-DD hh:mm:ss');
      jobInfo.userId = 'System';
      jobInfo.journalAcronym = result['bam:jid'];

      resolve(jobInfo);
    } catch (error) {
      logger.info('Error parsing JSON:', error);
      reject(error);
    }
  });
};
// download asset file from client
const downloadAssetFile = (assetInfo, signalAckPayload) => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId, ackMsgInfo } = signalAckPayload;
    try {
      const assetPromises = assetInfo.map(async item => {
        const assetUrl = item;
        const {
          data: sourceContent,
          filename,
          contentType,
        } = await service.journalGetWithBlob(assetUrl);
        return { sourceContent, filename, contentType };
      });
      const assetDownloadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: JSON.stringify({}),
        message: 'Source file downloaded successfully',
        status: 'Success',
        processStatusId: 4,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(assetDownloadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: err.message ? err.message : 'Source file downloaded failed',
        message: 'Source file downloaded failed',
        status: 'Failed',
        processStatusId: 4,
      };
      await ialtSignalLogHistory(logHisPayload);

      // await _ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
      reject(err);
    }
  });
};
// get du, customer info
const getGeneralInfo = payload => {
  return new Promise(async (resolve, reject) => {
    const { duId, customerId, receivedStage, stageId } = payload;
    try {
      let sql = `select duid, duname from org_mst_deliveryunit where duid=${duId} and isactive=true`;
      const duInfo = await query(sql);
      sql = `select customerid, customername from org_mst_customer where customerid=${customerId} and isactive=true`;
      const custInfo = await query(sql);
      sql = `select stageid, stagename from wms_mst_stage where stageid=${stageId}`;
      // sql = `select stageid, stagename from wms_mst_stage where stageid = (select stageid from wms_mst_service_calltype
      // join wms_mst_service_calltype_map on wms_mst_service_calltype_map.servicecallmapid=wms_mst_service_calltype.servicecaltypeid
      // where servicecalltype='${receivedStage}' and wms_mst_service_calltype.isactive=true and wms_mst_service_calltype_map.isactive=true) and isactive=true`;
      const stageInfo = await query(sql);
      sql = ` SELECT dms_master.dmsid, dms_master.dmstype FROM wms_mst_customerconfigdetails 
      JOIN dms_master ON dms_master.dmsid = wms_mst_customerconfigdetails.dmsid
      WHERE customerid=${customerId} and dms_master.isactive`;

      const dmsInfo = await query(sql);
      if (
        duInfo.length &&
        custInfo.length &&
        stageInfo.length &&
        dmsInfo.length
      ) {
        resolve({
          ...payload,
          du: { id: duInfo[0].duid, name: duInfo[0].duname },
          customer: {
            id: custInfo[0].customerid,
            name: custInfo[0].customername,
          },
          stage: { id: stageInfo[0].stageid, name: stageInfo[0].stagename },
          dms: { id: dmsInfo[0].dmsid, name: dmsInfo[0].dmstype },
        });
      } else {
        throw new Error('Du | Customer | Stage info not found');
      }
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};
// asset upload process
const assetUploadProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      assetDownloadRes,
      signalAuditId,
      du,
      customer,
      stage,
      bookName,
      chapterName,
    } = payload;
    try {
      const folderPathData = {
        type: 'ialt_book_chapter_stage',
        duName: du.name,
        customerName: customer.name,
        bookName,
        chapterName,
        stageName: stage.name,
      };
      const pathToStore = await getFolderStructureForIalt(folderPathData);
      const assets = assetDownloadRes.filter(item => item.contentType);
      const assetPromises = assets.map(async item => {
        const docPath = `${pathToStore}${item.filename}`;
        const { fullPath } = await _uploads3File(
          docPath,
          item.sourceContent,
          item.contentType,
        );
        let sasPath = {};
        if (fullPath.includes('.pdf')) {
          const { data } = await _download(fullPath);
          sasPath = data;
        }
        return {
          allPath: fullPath,
          pathWithSAS: sasPath.path ? sasPath.path : '',
        };
      });
      const assetUploadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(payload),
        response: JSON.stringify(assetUploadRes),
        message: 'Source file uploaded to blob successfully',
        status: 'Success',
        processStatusId: 5,
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(assetUploadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(payload),
        response: err.message
          ? err.message
          : 'Source file upload to blob failed',
        message: 'Source file upload to blob failed',
        status: 'Failed',
        processStatusId: 5,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// job received acknowledgement to client
export const ialtJobReceivedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      const tokenRes = await service.post(url, data);
      const { auth_token } = tokenRes.data;
      const formattedDate = moment().utc().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      const uniqueId = randomUUID();
      data = {
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/LoginAndCreateProof/LaTeX/${uniqueId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/ArticleSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/ProcessManager/JournalProduction',
        'msg:event': {
          '@id':
            'http://vtw.elsevier.com/event/id/LoginAndCreateProof/LaTeX/feef8da9-de35-4bff-9b23-5c702c86f0aa',
          '@type': 'msg:EventNotification',
          'evt:time': formattedDate,
          'evt:type':
            'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      const result = await service.post(url, data, headers);
      const logHisPayload = {
        signalAuditId,
        updateType: 'acknowledged',
        request: data,
        response: result,
        message: 'Job received acknowledgment sent successfully',
        status: 'Success',
        processStatusId: 2,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Job received acknowledgement sent failed',
        message: 'Job received acknowledgement sent failed',
        status: 'Failed',
        processStatusId: 2,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// failed acknowledgement to client
export const _ialtFailedAcknowledgeService = (payload, status) => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      const tokenRes = await service.post(url, data);
      const { auth_token } = tokenRes.data;
      const formattedDate = moment().utc().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      const uniqueId = randomUUID();
      data = {
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/LoginAndCreateProof/LaTeX/${uniqueId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/ArticleSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/ProcessManager/JournalProduction',
        'msg:event': {
          '@id':
            'http://vtw.elsevier.com/event/id/LoginAndCreateProof/LaTeX/feef9da9-de35-4bff-9b23-5c702c86f0aa',
          '@type': 'msg:EventNotification',
          'evt:time': formattedDate,
          'evt:type': `http://vtw.elsevier.com/data/voc/Events/${status}`,
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      const result = await service.post(url, data, headers);
      const logHisPayload = {
        signalAuditId,
        updateType: 'failed',
        request: data,
        response: result,
        message: 'Job failure acknowledgment sent successfully',
        status: 'Success',
        processStatusId: 15,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Sent failed',
        message: 'Job failure acknowledgment sent failed',
        status: 'Failed',
        processStatusId: 24,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// job completed acknowledgement to client
export const ialtJobCompletedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
      queueUrl,
    } = payload;
    const formattedDate = moment().utc().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    const uniqueId = randomUUID();
    const messageBody = {
      '@timestamp': formattedDate,
      '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
      '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${uniqueId}`,
      '@type': 'msg:Message',
      'msg:format': 'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
      'msg:type':
        'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
      'msg:from':
        'http://vtw.elsevier.com/data/voc/Contributors/MPS/BookSupplier',
      'msg:to':
        'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
      'msg:event': {
        '@id':
          'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-1008-4e52-9b8a-c75f8c6c7742',
        '@type': 'msg:EventNotification',
        'evt:time': formattedDate,
        'evt:type':
          'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
        'evt:about': `${serviceAboutUrl}`,
        'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
      },
    };
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: queueUrl,
    };
    try {
      const data = await sqs.sendMessage(params).promise();
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent successfully',
        status: 'Job received acknowledgment sent successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent failed',
        status: 'Job received acknowledgement sent failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        action,
        to,
        customerId,
        message,
        title,
        stageName,
        woTypeId,
        content,
        subj,
        journalAcronym,
        piiNumber,
      } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        woTypeId,
        customerId,
      };
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        stageName,
        subMessage: message,
        toMail: toMailArray,
        content,
        subj,
        journalAcronym,
        piiNumber,
      };
      await emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};
// get dms info
const getDmsInfo = customerId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE customerid=$1`;
      const dmsInfo = await query(sql, [customerId]);
      const { dmsid } = dmsInfo[0];
      resolve(dmsid);
    } catch (err) {
      reject('DMS info not found for the customer');
    }
  });
};

// download and extracted temp folder
const downloadFileFromBuffer = (data, tempFolder) => {
  return new Promise(async (resolve, reject) => {
    try {
      const fileInfo = data.find(item => item.filename.includes('.zip'));
      logger.info(fileInfo, 'fileInfo');
      if (fileInfo && Object.keys(fileInfo).length) {
        const fileName = fileInfo.filename;
        // Replace this with your actual buffer data
        const zipBuffer = Buffer.from(fileInfo.sourceContent, 'binary');
        if (!existsSync(tempFolder)) {
          // Create the directory if it doesn't exist
          mkdirSync(tempFolder, { recursive: true });
        }
        // writeFileSync will cause event blocking
        writeFile(tempFolder + fileName, zipBuffer, err1 => {
          if (err1) throw err1;
          const zip = new AdmZip(tempFolder + fileName);
          const zipEntries = zip.getEntries();
          const filteredEntries = zipEntries.filter(
            entry => path.extname(entry.entryName) === '.xml',
          );
          filteredEntries.forEach(entry => {
            const entryPath = path.join(tempFolder, entry.entryName);
            if (entry.isDirectory) {
              mkdirSync(entryPath, { recursive: true });
            } else {
              zip.extractEntryTo(entry, tempFolder, true, true);
            }
          });

          resolve('File downloaded and extracted successfully.');
        });
      } else {
        logger.info('Zip file was not availabe in the source');
        throw new Error('Zip file was not availabe in the source');
      }
    } catch (error) {
      logger.info(error, 'error file download');
      reject('File download to temp folder failed.');
    }
  });
};
// find and get the order xml
const findAndReadXmlFile = folder => {
  return new Promise(async (resolve, reject) => {
    try {
      // const tempFolder = path.join(__dirname, 'tempFolder/CAS-FLOW');

      // Read all files in the specified folder
      const files = readdirSync(folder);

      // Filter to find XML files
      const xmlFiles = files.filter(file => path.extname(file) === '.xml');

      if (xmlFiles.length === 0) {
        throw new Error('No XML files found in the specified folder.');
      }

      // Assuming you want to read the first XML file found
      const xmlFilePath = path.join(folder, xmlFiles[0]);

      // Read the XML file as a string
      const xmlData = readFileSync(xmlFilePath, 'utf-8');

      // Log the XML data
      logger.info(`XML File Content from ${xmlFilePath}:\n`, xmlData);

      // Return the XML data as a string
      resolve(xmlData);
    } catch (error) {
      logger.info('Error finding or reading the XML file:', error);
      reject(error);
    }
  });
};

const _updateXMLPreviewService = (
  xmlInput,
  flowtype,
  signalAuditId,
  journalAcronym,
  customerId,
  pii,
) => {
  return new Promise(async (resolve, reject) => {
    let finalRes = false;
    let payload = {};
    try {
      const sql = `SELECT wtd.value as proofcreationtype, wtd1.value as dataadministratorcode FROM pp_mst_journal pmj
                  join wms_trn_dropdown wtd on wtd.id = pmj.proofcreationtypeid
                  join wms_trn_dropdown wtd1 on wtd1.id = pmj.dataadministratorcodeid
                  join org_mst_customer_orgmap omco on omco.custorgmapid = pmj.custorgmapid
                  where pmj.journalacronym = $1 and omco.customerid = $2;`;
      const jouDetail = await query(sql, [journalAcronym, customerId]);
      if (jouDetail.length === 0) {
        throw new Error('Journal details not found.');
      }
      let configuration = {};
      if (flowtype == 'preview') {
        let updatedXmlString = '';
        // if (addNewTag) {
        // Your original XML string
        let xmlString = xmlInput;
        xmlString = xmlString.replace(/<\?xml [^>]+>\s*/gi, '');

        // Parse the XML string into a DOM object
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlString, 'text/xml');

        const elementSupp = xmlDoc.createElement('supplier-code');
        elementSupp.appendChild(
          xmlDoc.createTextNode(process.env.ELSEVIER_SUPPLIER_CODE),
        ); // default

        const targetElement = xmlDoc.getElementsByTagName('interface-code')[0];
        if (targetElement && targetElement.parentNode) {
          const parent = targetElement.parentNode;
          if (targetElement.nextSibling) {
            parent.insertBefore(elementSupp, targetElement.nextSibling);
          } else {
            parent.appendChild(elementSupp);
          }
        }
        const existingElement = xmlDoc.getElementsByTagName(
          'proof-creation-process',
        )[0];
        if (existingElement != undefined)
          existingElement.textContent = jouDetail[0].proofcreationtype; // from journal master

        // Serialize the XML document back to a string
        const serializer = new XMLSerializer();
        xmlString = serializer.serializeToString(xmlDoc);
        xmlString = xmlString.replace(
          /<\/interface-code><supplier-code>/i,
          '</interface-code>\r\n\t<supplier-code>',
        );
        xmlString = xmlString.replace(
          /<\/supplier-code><data-administrator>/i,
          '</supplier-code>\r\n\t<data-administrator>',
        );
        updatedXmlString = xmlString;
        // } else {
        //   updatedXmlString = xmlInput;
        // }

        const usernameheader = process.env.ELSEVIER_PREVIEWMD_HEADER_USERNAME;
        const passwordheader = process.env.ELSEVIER_PREVIEWMD_HEADER_PASSWORD;

        payload = await fnGenerateSopaXML(flowtype, updatedXmlString);

        configuration = {
          method: 'post',
          maxBodyLength: Infinity,
          url: process.env.ELSEVIER_PREVIEWMD_APIURL, // fetch from env
          headers: {
            'Content-Type': 'text/xml',
            username: usernameheader,
            password: passwordheader,
          },
          data: payload,
        };
      } else {
        let updatedXmlString = '';
        // if (addNewTag) {
        // Your original XML string
        let xmlString = xmlInput;
        xmlString = xmlString.replace(/<\?xml [^>]+>\s*/gi, '');

        // Parse the XML string into a DOM object
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlString, 'text/xml');

        const elementSupp = xmlDoc.createElement('supplier-code');
        elementSupp.appendChild(
          xmlDoc.createTextNode(process.env.ELSEVIER_SUPPLIER_CODE),
        ); // default

        const elementadmin = xmlDoc.createElement('data-administrator');
        elementadmin.appendChild(
          xmlDoc.createTextNode(jouDetail[0].dataadministratorcode),
        ); // from journal master

        const targetElement = xmlDoc.getElementsByTagName('interface-code')[0];
        if (targetElement && targetElement.parentNode) {
          const parent = targetElement.parentNode;
          if (targetElement.nextSibling) {
            parent.insertBefore(elementSupp, targetElement.nextSibling);
          } else {
            parent.appendChild(elementSupp);
          }
          if (elementSupp.nextSibling) {
            parent.insertBefore(elementadmin, elementSupp.nextSibling);
          } else {
            parent.appendChild(elementadmin);
          }
        }
        const existingElement = xmlDoc.getElementsByTagName(
          'proof-creation-process',
        )[0];
        if (existingElement != undefined)
          existingElement.textContent = jouDetail[0].proofcreationtype; // from journal master

        if (jouDetail[0].proofcreationtype == 'Complex Content') {
          // production type value update
          const existingDetailsTag = xmlDoc.getElementsByTagName('details')[0];
          const existingDetailsSubTag =
            existingDetailsTag.getElementsByTagName('production-type')[0];

          // Change the attribute value
          if (existingDetailsSubTag) {
            existingDetailsSubTag.setAttribute('type', 'FLP');
          }
        } else {
          throw new Error(
            'The Proof Creation Type is not classified as Complex Content.',
          );
        }
        // Serialize the XML document back to a string
        const serializer = new XMLSerializer();
        xmlString = serializer.serializeToString(xmlDoc);
        xmlString = xmlString.replace(
          /<\/interface-code><supplier-code>/i,
          '</interface-code>\r\n\t<supplier-code>',
        );
        xmlString = xmlString.replace(
          /<\/supplier-code><data-administrator>/i,
          '</supplier-code>\r\n\t<data-administrator>',
        );
        updatedXmlString = xmlString;
        // } else {
        //   updatedXmlString = xmlInput;
        // }

        const usernameheader = process.env.ELSEVIER_PREVIEWMD_HEADER_USERNAME;
        const passwordheader = process.env.ELSEVIER_PREVIEWMD_HEADER_PASSWORD;

        payload = await fnGenerateSopaXML(flowtype, updatedXmlString);

        configuration = {
          method: 'post',
          maxBodyLength: Infinity,
          url: process.env.ELSEVIER_PREVIEWMD_APIURL, // fetch from env
          headers: {
            'Content-Type': 'text/xml',
            username: usernameheader,
            password: passwordheader,
          },
          data: payload,
        };
      }

      let isNotifier = true;
      await axios
        .request(configuration)
        .then(async response => {
          finalRes = response.data;
          logger.info(JSON.stringify(response.data));
          const responseMatch = finalRes.match(
            /<art:response[^>]*type="([^"]+)"/,
          );
          const messageMatch = [
            ...finalRes.matchAll(
              /<art1:message code="([^"]+)">([^<]+)<\/art1:message>/g,
            ),
          ];
          if (
            (responseMatch[1] === 'success' && messageMatch.length > 0) ||
            responseMatch[1] === 'failure'
          ) {
            // send mail
            const msg =
              messageMatch.length > 0
                ? messageMatch
                    .map(match => `${match[1]} - ${match[2]}`)
                    .join(', ')
                : false;
            await Pmd_Cmd_notifier(
              flowtype === 'preview' ? 'PMD warning' : 'CMD failure',
              pii,
              msg,
            );
            if (responseMatch[1] === 'failure') {
              isNotifier = false;
              throw new Error(msg);
            }
          }
        })
        .catch(async error => {
          logger.info(error);
          const { response = { data: false }, message = 'Process failed' } =
            error;
          const errMsg = response.data ? response.data : message;
          if (isNotifier) {
            await Pmd_Cmd_notifier(
              flowtype === 'preview' ? 'PMD failure' : 'CMD failure',
              pii,
              errMsg,
            );
          }
          throw new Error(errMsg);
        });

      if (signalAuditId) {
        const logHisPayload = {
          signalAuditId,
          request: payload,
          response: finalRes,
          message:
            flowtype == 'preview'
              ? 'PMD updated successfully'
              : 'CMD updated successfully',
          status: 'Success',
          processStatusId: 4,
        };
        await ialtSignalLogHistory(logHisPayload);
      }
      resolve({ status: true, data: finalRes });
    } catch (err) {
      if (signalAuditId) {
        const logHisPayload = {
          signalAuditId,
          updateType: 'failed',
          request: payload,
          response: finalRes || err.message || err,
          message:
            flowtype == 'preview' ? 'PMD update failed' : 'CMD update failed',
          status: 'Failed',
          processStatusId: 4,
        };
        await ialtSignalLogService(logHisPayload, 'Update');
        await ialtSignalLogHistory(logHisPayload);

        // as instructed by transition team, should not be send the failed
        // const ackPaylod = {
        //   signalAuditId,
        //   ackMsgInfo,
        // };
        // await _ialtFailedAcknowledgeService(ackPaylod, 'Failed');
      }
      reject(err);
    }
  });
};

const fnGenerateSopaXML = (type, meta) => {
  return new Promise(async (resolve, reject) => {
    try {
      const username = process.env.ELSEVIER_PREVIEWMD_SOAP_USERNAME;
      const password = process.env.ELSEVIER_PREVIEWMD_SOAP_PASSWORD;

      const requesttype =
        type === 'preview' ? 'PreviewArticleRequest' : 'UpdateArticleRequest';
      meta = meta.replace(/(<\/?)/gi, '$1art1:');
      meta = meta.replace('<art1:eo-gateway>', '<art:eo-gateway>');
      meta = meta.replace('</art1:eo-gateway>', '</art:eo-gateway>');
      const data = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:art="http://www.elsevier.com/enterprise/messages/article/v1/ArticleEBM.xsd" xmlns:art1="http://www.elsevier.com/enterprise/objects/article/v1/ArticleEBO.xsd">
        <soapenv:Header>
          <wsse:Security soapenv:mustUnderstand="1" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
            <wsse:UsernameToken>
              <wsse:Username>${username}</wsse:Username>
              <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">${password}</wsse:Password>
            </wsse:UsernameToken>
          </wsse:Security>
        </soapenv:Header>
        <soapenv:Body>
          <art:${requesttype}>
            ${meta}
          </art:${requesttype}>
        </soapenv:Body>
      </soapenv:Envelope>`;

      resolve(data);
    } catch (err) {
      reject(err);
    }
  });
};

// const updateXMLPreview = xmlInput => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       // The URL of the WSDL
//       const url = 'https://uat.business.api.elsevier.com/cxf/articlePS?wsdl';

//       // Create a SOAP client
//       await soap.createClient(url, (err, client) => {
//         if (err) {
//           console.error('Error creating SOAP client:', err);
//           return;
//         }

//         // Log the available methods from the WSDL
//         console.log('Available methods:', client.describe());

//         // Convert the XML input to a JavaScript object
//         xml2js.parseString(xmlInput, { explicitArray: false }, (err1, result) => {
//           if (err1) {
//             console.error('Error parsing XML:', err1);
//             return;
//           }

//           const args = {
//             'eo-gateway': result['eo-gateway'],
//             targetNSAlias: 'ebm',
//             targetNamespace: 'http://www.elsevier.com/enterprise/messages/article/v1/ArticleEBM.xsd'
//           };

//           // Example of invoking a method (replace `methodName` with an actual method)
//           client.ArticlePSService.ArticlePSSoap11.PreviewArticle(args, (err2, result1) => {
//             if (err2) {
//               console.error('Error invoking method:', err2);
//               return;
//             }

//             // Process the result
//             console.log('Result 1:', result1);
//           });
//         });
//       });

//       resolve();
//     } catch (error) {
//       reject(error);
//     }
//   });
// };

export const updateXMLPreviewService = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { xmlString, flowtype, workorderId, journalAcronym, customerId } =
        data;
      let signalAuditId = null;
      let pii = null;
      if (workorderId) {
        const sql = `select signalauditid, pii from wms_mst_signal_audit where pii in (select otherfield->> 'pii' as pii from wms_workorder where workorderid=${workorderId})`;
        const signalInfo = await query(sql);
        if (signalInfo.length) {
          signalAuditId = signalInfo[0].signalauditid || null;
          pii = signalInfo[0].pii || null;
        } else {
          throw new Error('Signal information not found');
        }
      }
      const res = await _updateXMLPreviewService(
        xmlString,
        flowtype,
        signalAuditId,
        journalAcronym,
        customerId,
        pii,
      );
      resolve(res);
    } catch (err) {
      reject(err);
    }
  });
};

export const srcFileDownloadFromPii = async payload => {
  return new Promise(async (resolve, reject) => {
    let signalAuditId = '';
    try {
      // eslint-disable-next-line prefer-const
      let { pii, destPath, type = 'out' } = payload;
      if (pii) {
        pii = pii.replace(/[^a-zA-Z0-9]/g, '');

        const resData = await query(
          `SELECT signalauditid FROM public.wms_mst_signal_audit where pii = '${pii}'`,
        );
        if (resData.length) {
          signalAuditId = resData[0]?.signalauditid;
          // get the metadata info
          const result = await getMetaDataForFinalSupply({
            pii,
            signalAuditId,
          });
          const bookInfo = await readMetadata(result);

          // download source files
          const assetDownloadRes = await downloadAssetFileFinalSupply(
            bookInfo.assetInfo,
            signalAuditId,
          );
          // Specify the path where you want to save the ZIP file
          // const tempFolder = 'tempFolder/CAS-FLOW/';
          // const tempFolder = `//integrafs2/ElsJournals/tempFolder/CAS-FLOW/${pii}/`;
          if (destPath) {
            // await downloadFileFromBuffer(assetDownloadRes, destPath);
            const sourceInfo = assetDownloadRes.find(item =>
              item.filename.includes('.zip'),
            );
            destPath = `${destPath}${sourceInfo.filename}`;
            logger.info('_localZIPCopyWithExtract Starts.');
            const resOfFileCopy = await _localZIPCopyWithExtract({
              sourceInfo,
              destPath,
              type,
            });
            logger.info('_localZIPCopyWithExtract End.');
            resolve(true);
          } else {
            reject({ status: false, message: 'Destination Path not found' });
          }
        } else {
          reject({
            status: false,
            message:
              'The PII number is mismatched. Please check the requested PII.',
          });
        }

        // const srcPath = tempFolder;
        // const destBasePath = destPath;

        // const resOfFileCopy = await _localFolderCopy({ srcPath, destBasePath });
        // if(resOfFileCopy) {
        //   await rm(tempFolder, { recursive: true, force: true });
        // }
      } else {
        reject({ status: false, message: 'Pii number not found' });
      }
    } catch (err) {
      const { isLog = true } = payload;
      if (isLog) {
        const logPayload = {
          signalAuditId,
          response: err.message,
          updateType: 'failed',
        };
        await ialtSignalLogService(logPayload, 'Update');
      }
      reject({ status: false, message: err.message ? err.message : err });
    }
  });
};

export const checkVTWSignalReceived = async (pii, servicetype, jobflowtype) => {
  return new Promise(async (resolve, reject) => {
    try {
      pii = pii.replace(/[^a-zA-Z0-9]/g, '');

      const resData = await query(
        `SELECT signalauditid, receiveddate FROM public.wms_mst_signal_audit where pii = $1 and servicecalltype = $2 and jobflowtypeid = $3 order by 1 desc limit 1`,
        [pii, servicetype, jobflowtype],
      );
      if (resData.length && resData[0].signalauditid) {
        resolve({
          issuccess: true,
          receiveddate: resData[0].receiveddate,
          message: 'Signal Received.',
        });
      } else {
        resolve({
          issuccess: false,
          message: 'Signal Not found.',
        });
      }
    } catch (err) {
      reject({ status: false, message: err.message ? err.message : err });
    }
  });
};

const getMetaDataForFinalSupply = signalAckPayload => {
  return new Promise(async (resolve, reject) => {
    const { pii, signalAuditId } = signalAckPayload;
    const url = `${config.iAlt.else_vier.base_url}/metadata/pii/${pii}`;
    try {
      const result = await service.ialtGet(url);
      if (Object.keys(result).length) {
        resolve(result);
      } else {
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: url,
        response: err.message ? err.message : err,
        message: 'Metadata fetching request failed for final supply',
        status: 'Failed',
        processStatusId: 3,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err.message ? err.message : err);
    }
  });
};
// download asset file from client
const downloadAssetFileFinalSupply = (assetInfo, signalAuditId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const assetPromises = assetInfo.map(async item => {
        const assetUrl = item;
        const {
          data: sourceContent,
          filename,
          contentType,
        } = await service.journalGetWithBlob(assetUrl);
        return { sourceContent, filename, contentType };
      });
      const assetDownloadRes = await Promise.all(assetPromises);
      resolve(assetDownloadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: err.message ? err.message : 'Source file downloaded failed',
        message: 'Source file downloaded failed',
        status: 'Failed',
        processStatusId: 4,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};
// download and extracted temp folder
const downloadFileFromBufferFinalSupply = (data, tempFolder) => {
  return new Promise(async (resolve, reject) => {
    try {
      await Promise.all(
        data.map(async item => {
          const fileInfo = item;
          if (Object.keys(fileInfo).length) {
            const fileName = fileInfo.filename;
            // Replace this with your actual buffer data
            const zipBuffer = Buffer.from(fileInfo.sourceContent, 'binary');
            // rm(tempFolder, { recursive: true, force: true }, err => {
            //   if (err) throw err;

            // Check if the directory exists
            if (!existsSync(tempFolder)) {
              // Create the directory if it doesn't exist
              mkdirSync(tempFolder, { recursive: true });
            }
            writeFileSync(tempFolder + fileName, zipBuffer, err1 => {
              if (err1) throw err1;
              const zip = new AdmZip(tempFolder + fileName);
              const zipEntries = zip.getEntries();
              const filteredEntries = zipEntries.filter(
                entry => path.extname(entry.entryName) === '.xml',
              );
              filteredEntries.forEach(entry => {
                const entryPath = path.join(tempFolder, entry.entryName);
                if (entry.isDirectory) {
                  mkdirSync(entryPath, { recursive: true });
                } else if (fileInfo.filename.includes('.zip')) {
                  zip.extractEntryTo(entry, tempFolder, true, true);
                }
              });

              resolve('File downloaded and extracted successfully.');

              // try {
              //   // Load the ZIP file
              //   const zip = new AdmZip(tempFolder + fileName);
              //   const zipEntries = zip.getEntries();
              //   // Ensure ZIP file is not empty
              //   if (zipEntries.length === 0) {
              //     throw new Error('ZIP file is empty or corrupted.');
              //   }

              //   // Extract all contents
              //   zip.extractAllTo(tempFolder, true);
              //
              //   // resolve('File downloaded and extracted successfully.');
              // } catch (err2) {
              //   logger.error('Failed to extract ZIP file:', err2);
              //   reject(err2);
              // }
              // });
            });
          } else {
            throw new Error('Zip file was not availabe in the source');
          }
        }),
      );
    } catch (error) {
      reject('File download to temp folder failed.');
    }
  });
};

export const Pmd_Cmd_notifier = async (type, pii, msg) => {
  return new Promise(async (resolve, reject) => {
    const action = 'elsevier_pmd_cmd_notifier';
    const message = msg
      ? `, Find the exact response below: ${
          typeof msg === 'object' ? JSON.stringify(msg) : msg
        }`
      : ` and No message tag found in the response`;
    const data = {
      subj: `Elsevier | ${type} - ${pii}.`,
      content: `${type} response received for the PII - ${pii}${message}.`,
    };
    try {
      await _triggerMailWithAction({ data, action });
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
