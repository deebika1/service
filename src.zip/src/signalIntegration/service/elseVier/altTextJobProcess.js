/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
/* eslint-disable */
// eslint-disable-next-line import/no-extraneous-dependencies
import AWS from 'aws-sdk';
import fs from 'fs';
import path from 'path';
import https from 'https';
import moment from 'moment';
import { query } from '../../../database/postgres.js';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import {
  ialtSignalLogService,
  ialtSignalLogHistory,
  iAltAutoJobCreationService,
  checkChapterExists,
} from '../index.js';
import { emitAction } from '../../../modules/activityListener/index.js';
import { getNotificationTemplate } from '../../../modules/common/index.js';
import {
  _uploads3File,
  _download,
} from '../../../modules/utils/azure/index.js';
import { getFolderStructureForIalt } from '../../../modules/utils/wmsFolder/index.js';
import { ialtSuccessAcknowledgeService } from '../../../iAlt/service/altTextJobProcess.js';
import { processAssetInfo } from '../../../iAlt/service/index.js';
import { jobInfoDetailsUpdate } from '../../../modules/task/index.js';

const service = new Service();

// Configure the AWS SDK with your credentials and region
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

const s3 = new AWS.S3();
const sqs = new AWS.SQS({ apiVersion: '2012-11-05' });
const bucketName = process.env.AWS_ELSEVIER_BUCKET_NAME;
const folderPath = 'contributors/158184564625';
const queueURL = process.env.SQS_QUEUE_URL;

export const altextGenerationJobService = async data => {
  return new Promise(async (resolve, reject) => {
    let jobPayload = {};
    let generalInfo = {
      customerId: 14,
      duId: 94,
      wfId: 38,
      serviceId: 1,
      stageId: 54,
      stageIteration: 1,
      jobFlowType: 'ialt',
      jobFlowTypeId: 3,
      chapterInfo: {},
      bookInfo: {},
    };
    try {
      if (!Object.keys(data).length) {
        throw new Error('Job received without payload');
      }
      const jobInfo = await readJobData(data);

      // initial log entry
      let logPayload = {
        ...generalInfo,
        ...jobInfo,
        response: data,
        message: 'Job request received',
        status: 'Success',
        processStatusId: 1,
      };
      const { data: signalAuditId } = await ialtSignalLogService(
        logPayload,
        'Insert',
      );
      try {
        const signalAckPayload = {
          signalAuditId,
          piiNumber: jobInfo.piiNumber,
          ackMsgInfo: jobInfo.ackMsgInfo,
          egiFilesInfo: jobInfo?.egiFilesInfo ? jobInfo?.egiFilesInfo : {},
        };
        const checkAcknowledgeQuery = ` select * from public.wms_mst_signal_audit_trns
        where signalauditid in (
        select signalauditid from public.wms_mst_signal_audit  where pii = '${jobInfo.piiNumber}'
        ) and message = 'Job received acknowledgment sent successfully'`;

        const checkAcknowledge = await query(checkAcknowledgeQuery);
        const isAcknowledged = checkAcknowledge && checkAcknowledge.length > 0;

        if (!isAcknowledged) {
          await ialtJobReceivedAcknowledgeService(signalAckPayload);
        }
        // get the metadata info
        const result = await getMetaData(signalAckPayload);
        const bookInfo = await readMetadata(result);

        // to trigger mail for job incoming start
        const mailStartPayload = {
          action: 'auto_create_start',
          woTypeId: generalInfo?.jobFlowTypeId,
          customerId: generalInfo?.customerId,
          to: [],
          title: `${bookInfo?.title} - ${jobInfo?.chapterInfo?.name}`,
          chapterName: jobInfo?.chapterInfo?.name,
          message: `Auto job creation process started`,
        };
        if (!isAcknowledged) {
          //  await sendMail(mailStartPayload);
        }
        //  to trigger mail for job incoming end

        //get the egi metadata info
        let egiInfo = [];
        let mainFiles = [];

        if (
          jobInfo?.ackMsgInfo?.egiFilesInfo &&
          jobInfo?.ackMsgInfo?.egiFilesInfo.length > 0
        ) {
          egiInfo = await Promise.all(
            jobInfo?.ackMsgInfo?.egiFilesInfo.map(async list => {
              const payload = {
                signalAuditId,
                egiNumber: list.split('/').pop(),
              };
              return getEgiMetaData(payload);
            }),
          );
          egiInfo.flat().map(list => {
            mainFiles.push({
              path: list,
              isegiFile: true,
            });
          });

          bookInfo.assetInfo.flat().map(list => {
            const verValue = list.split('ver=').pop();
            let newArray = bookInfo.assetmeta.filter(
              item => item['bam:assetVersion'] == verValue,
            );

            let sourceTypeName = '';
            if (newArray?.[0]?.['bam:assetVersion'] !== 'STRIPIN') {
              sourceTypeName = newArray?.[0]?.['bam:filename'];
            } else {
              sourceTypeName = 'STRIPIN.zip';
            }

            // if (jobInfo?.ackMsgInfo?.sourceType == 'emss') {
            // sourceTypeName = newArray?.[0]?.['bam:filename']
            //   ? newArray?.[0]?.['bam:filename']
            //   : path.basename(newArray?.[0]?.['bam:ucsLocation'][0]);
            // } else {
            //   sourceTypeName = path.basename(
            //     newArray?.[0]?.['bam:ucsLocation'][0],
            //   )
            //     ? path.basename(newArray?.[0]?.['bam:ucsLocation'][0])
            //     : newArray?.[0]?.['bam:filename'];
            // }
            mainFiles.push({
              path: list,
              isegiFile: false,
              newFileName: sourceTypeName
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/['’]/gi, '')
                .replace(/[^a-z0-9\.]/gi, ' ')
                .replace(/\s+/gi, '_'),
            });
          });
          bookInfo.assetInfo = mainFiles;
        } else {
          bookInfo.assetInfo.flat().map(list => {
            const verValue = list.split('ver=').pop();
            let newArray = bookInfo.assetmeta.filter(
              item => item['bam:assetVersion'] == verValue,
            );

            let sourceTypeName = '';
            if (newArray?.[0]?.['bam:assetVersion'] !== 'STRIPIN') {
              sourceTypeName = newArray?.[0]?.['bam:filename'];
            } else {
              sourceTypeName = 'STRIPIN.zip';
            }

            // if (jobInfo?.ackMsgInfo?.sourceType == 'emss') {
            //   sourceTypeName = newArray?.[0]?.['bam:filename']
            //     ? newArray?.[0]?.['bam:filename']
            //     : path.basename(newArray?.[0]?.['bam:ucsLocation'][0]);
            // } else {
            //   sourceTypeName = path.basename(
            //     newArray?.[0]?.['bam:ucsLocation'][0],
            //   )
            //     ? path.basename(newArray?.[0]?.['bam:ucsLocation'][0])
            //     : newArray?.[0]?.['bam:filename'];
            // }
            mainFiles.push({
              path: list,
              isegiFile: false,
              newFileName: sourceTypeName
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/['’]/gi, '')
                .replace(/[^a-z0-9\.]/gi, ' ')
                .replace(/\s+/gi, '_'),
            });
          });
          bookInfo.assetInfo = mainFiles;
        }

        jobPayload = {
          ...jobPayload,
          signalAuditId,
          ...generalInfo,
          ...jobInfo,
          bookInfo,
        };

        const statusCheck = await checkChapterExists(
          {
            isbn: bookInfo.isbn,
            chapterName: jobInfo.chapterInfo.name,
          },
          signalAckPayload,
        );

        if (
          statusCheck &&
          !statusCheck.status &&
          generalInfo.jobFlowType === 'ialt'
        ) {
          const sql4 = `SELECT ialt_books.bookname, wms_workorder.itemcode FROM wms_workorder
          JOIN ialt_books ON ialt_books.bookid = wms_workorder.bookid
          WHERE ialt_books.isbn='${bookInfo.isbn}' AND wms_workorder.itemcode='${jobInfo.chapterInfo.name}' AND wms_workorder.otherfield->>'pii' ='${signalAckPayload.piiNumber}'
          and  wms_workorder.isactive = true and ialt_books.isactive=true`;

          const validate = await query(sql4);
          if (validate.length > 0) {
            throw new Error('Chapter already created for the pii');
          } else {
            const regex = /^(?:[0-9a-z\.]+\s?)*(?=:?)/gi;
            let subTitle = '';
            if (/^[0-9\.]+\s?/gi.test(jobInfo.chapterInfo.title))
              subTitle = jobInfo.chapterInfo.title
                .match(/^[0-9\.]+\s?/gi)?.[0]
                .trim()
                .replace(/\.$/, '');
            else subTitle = jobInfo.chapterInfo.title.match(regex)?.[0].trim();

            if (subTitle) {
              jobInfo.chapterInfo.name = `${jobInfo.chapterInfo.name.trim()} ${subTitle.trim()}`;
            }
            const sql5 = `SELECT ialt_books.bookname, wms_workorder.itemcode FROM wms_workorder
            JOIN ialt_books ON ialt_books.bookid = wms_workorder.bookid
            WHERE ialt_books.isbn='${bookInfo.isbn}' AND wms_workorder.itemcode='${jobInfo.chapterInfo.name}' AND wms_workorder.otherfield->>'pii' ='${signalAckPayload.piiNumber}'
            and  wms_workorder.isactive = true and ialt_books.isactive=true`;

            const subTitleValidate = await query(sql5);

            if (subTitleValidate.length > 0) {
              throw new Error('Chapter already created for the pii');
            }
          }
        }

        if (bookInfo.assetInfo.length > 0) {
          const response = await processAssetInfo(
            bookInfo.assetInfo,
            jobInfo?.ackMsgInfo?.sourceType,
          );
          console.log(response, 'response');
          bookInfo.assetInfo = response;
        }

        // download source files
        const assetDownloadRes = await downloadAssetFile(
          bookInfo.assetInfo,
          signalAckPayload,
        );

        // get du , customer, stage, dms info
        generalInfo = await getGeneralInfo(generalInfo);
        // upload source file to blob
        const assetUploadRes = await assetUploadProcess({
          assetDownloadRes,
          signalAuditId,
          ...generalInfo,
          bookName: bookInfo.title,
          chapterName: jobInfo.chapterInfo.name,
        });

        // const allFiles = assetUploadRes.map(item => item?.allPath);
        const allFiles = assetUploadRes
          .filter(item => item !== undefined)
          .map(item => item.allPath);

        // const originalFiles = assetUploadRes
        //   .map(item => item?.pathWithSAS, item?.isegiFile)
        //   .filter(p => p !== '')
        //   .filter(item => item !== undefined);
        const originalFiles = assetUploadRes.filter(
          item => item && item.pathWithSAS !== '',
        );

        jobPayload = {
          ...jobPayload,
          originalFiles,
          allFiles,
        };
        const response = await iAltAutoJobCreationService(jobPayload);

        const mailPayload = {
          action: 'auto_create_success',
          woTypeId: jobPayload.jobFlowTypeId,
          customerId: jobPayload.customerId,
          to: [],
          title: `${jobPayload?.bookInfo?.title} - ${jobInfo?.chapterInfo?.name}`,
          chapterName: jobPayload.chapterInfo.name,
          stageName: jobPayload?.bookInfo?.stage
            ? jobPayload.bookInfo.stage
            : '',
          message: `Auto job creation process completed`,
        };
        // await sendMail(mailPayload);
        resolve(response);
      } catch (err) {
        logPayload = {
          signalAuditId,
          response: err.message,
          updateType: 'failed',
        };
        await ialtSignalLogService(logPayload, 'Update');
        throw new Error(err.message);
      }
    } catch (err) {
      const mailPayload = {
        action: 'auto_create_failure',
        woTypeId: jobPayload.jobFlowTypeId,
        customerId: jobPayload.customerId,
        to: [],
        title:
          `${jobPayload?.bookInfo?.title} - ${jobPayload?.chapterInfo?.name}`
            ? `${jobPayload?.bookInfo?.title} - ${jobPayload?.chapterInfo?.name}`
            : 'Failed in initial process',
        chapterName: jobPayload.chapterInfo?.name,
        stageName: jobPayload?.bookInfo?.stage ? jobPayload.bookInfo.stage : '',
        message: err.message ? err.message : err,
      };
      // await sendMail(mailPayload);
      reject({ status: false, message: err.message ? err.message : err });
    } finally {
    }
  });
};
// Function to send a message to SQS
export const sendMessageToSQSService = async messageBody => {
  try {
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: '',

      // QueueUrl: `${queueURL}/${process.env.SQS_QUEUE_NAME}`,
    };
    const data = await sqs.sendMessage(params).promise();
  } catch (err) {
    console.error('Error sending message', err);
  }
};
export const listInBucketsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const data = await s3
        .listObjectsV2({
          Bucket: payload.bucketName,
          Prefix: payload.folderPath,
        })
        .promise();
      resolve(data.Contents);
      // to get all buckets
      // s3.listBuckets((err, data) => {
      //   if (err) {
      //
      //   } else {
      //
      //   }
      // });
    } catch (err) {
      console.error('Error listing objects in bucket:', err);
      reject(err); // Throw error for caller to handle
    }
  });
};
// Function to delete a message from the SQS queue
const deleteMessage = async receiptHandle => {
  const params = {
    QueueUrl: queueURL,
    ReceiptHandle: receiptHandle,
  };

  try {
    // await sqs.deleteMessage(params).promise();
  } catch (err) {
    console.error('Error deleting message:', err);
  }
};
export const uploadFileToS3Service = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      filePath,
      signalAuditInfo: { signalauditid: signalAuditId, signalinfo: ackMsgInfo },
      userid,
    } = payload;
    let params = {};
    try {
      // Download the file from the provided folder URL
      const url = new URL(filePath);
      const fileName = path.basename(url.pathname);
      const tempFilePath = `tempFolder/${fileName}`; // Temporary download path
      try {
        await downloadFileFromUrl(filePath, tempFilePath);
        // Read content from the file
        const fileContent = fs.readFileSync(tempFilePath);
        // Setting up S3 upload parameters
        params = {
          Bucket: `${bucketName}`,
          Key: `${folderPath}/${fileName}`,
          Body: fileContent,
          ACL: 'bucket-owner-full-control',
        };
        // Uploading files to the bucket
        const data = await s3.putObject(params).promise();
        data.Location = `https://${process.env.AWS_ELSEVIER_BUCKET_NAME}.s3.eu-west-1.amazonaws.com/${params.Key}`;
        data.key = params.Key;
        data.title = payload.chapterName;

        const headParams = {
          Bucket: params.Bucket,
          Key: params.Key,
        };
        const headData = await s3.headObject(headParams).promise();

        const logHisPayload = {
          signalAuditId,
          request: params,
          response: data,
          message: `Final output has been uploaded successfully ${
            userid || ''
          }`,
          status: 'Success',
          processStatusId: 22,
        };
        await ialtSignalLogHistory(logHisPayload);

        resolve(data);
      } catch (err) {
        const logHisPayload = {
          signalAuditId,
          updateType: 'failed',
          request: params,
          response: err.message ? err.message : err,
          message: 'Final output upload has failed',
          status: 'Failed',
          processStatusId: 23,
        };
        await ialtSignalLogService(logHisPayload, 'Update');
        await ialtSignalLogHistory(logHisPayload);
        const ackPaylod = {
          signalAuditId,
          ackMsgInfo,
        };
        await ialtFailedAcknowledgeService(ackPaylod, 'Failed');
        reject(err); // Throw error for caller to handle
      } finally {
        fs.unlinkSync(tempFilePath); // Clean up temporary file
      }
    } catch (err) {
      reject(err);
    }
  });
};
const downloadFileFromUrl = (fileUrl, destPath) => {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);

    https
      .get(fileUrl, response => {
        response.pipe(file);
        file.on('finish', () => {
          file.close(resolve); // close() is async, resolve after close completes.
        });
      })
      .on('error', err => {
        fs.unlink(destPath, () => reject(err)); // Delete the file async. (But we don't check the result)
      });
  });
};
export const altTextUploadNotification = (data, signalAuditInfo) => {
  return new Promise(async (resolve, reject) => {
    const { Location, ETag, piiNumber, key, title } = data;
    const { signalauditid: signalAuditId, signalinfo: ackMsgInfo } =
      signalAuditInfo;

    let payload = {};
    let resultTitle = await getMetaDataForTitle(piiNumber);
    let currentStage = '';

    try {
      currentStage = 'FINAL_OUTPUT_PREPARE_PAYLOAD';

      const assetVersion = ETag.replace(/^"|"$/g, '');
      const fileName = path.basename(Location);
      payload = {
        '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
        '@type': 'bam:ContentObjects',
        'bam:hasContentObjects': [
          {
            '@context': `${process.env.ELSEVIER_BASEURL}/metadata/context.jsonld`,
            '@type': 'bam:Metadata',
            '@id': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
            'dct:language': 'en',
            'ecm:identifier': `pii:${piiNumber}`,
            'dct:title': `${resultTitle}`,
            'prism:aggregationType': [
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3',
            ],
            'dct:type':
              'http://data.elsevier.com/vocabulary/ElsevierContentTypes/3.1',
            'bam:hasAssetMetadata': [
              {
                '@id': `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                '@type': 'bam:AssetMetadata',
                'dct:isFormatOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'dct:format':
                  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'bam:assetType': 'ALTERNATE-TEXT',
                'bam:assetVersion': `${assetVersion}`,
                'prism:byteCount': 2619,
                'bam:mode': 'private',
                'bam:filename': `${fileName}`,
                'bam:multiPart': false,
              },
            ],
            'bam:hasGeneration': [
              {
                '@type': 'bam:Generation',
                'bam:isGenerationOf': `${process.env.ELSEVIER_BASEURL}/content/pii/${piiNumber}`,
                'bam:hasAsset': [
                  `${process.env.AWS_URL}/${process.env.AWS_ELSEVIER_BUCKET_NAME}/${key}`,
                ],
                'bam:classificationLevel': 'public',
                'bam:stage': 'uncorrected_proof',
                'bam:hasGeneration': [],
              },
            ],
          },
        ],
      };
      currentStage = 'FINAL_OUTPUT_UPLOAD';

      const url = `${config.iAlt.else_vier.base_url}/${config.iAlt.else_vier.uri.upload}`;
      let result = null;

      try {
        result = await service.ialtPost(url, payload);
      } catch (error) {
        throw new Error('iAlt File upload API Failed: ' + error.message);
      }
      currentStage = 'FINAL_OUTPUT_UPLOAD_SUCCESS';

      const logHisPayload = {
        signalAuditId,
        updateType: 'completed',
        request: payload,
        response: result.data,
        message: 'Final output upload acknowledgment has been set successfully',
        status: 'Success',
        processStatusId: 25,
      };
      await ialtSignalLogHistory(logHisPayload);
      await ialtSignalLogService(logHisPayload, 'Update');

      currentStage = 'FINAL_OUTPUT_COMPLETED_ACK_PREPARE_PAYLOAD';
      const ackPaylod = {
        signalAuditId,
        ackMsgInfo,
        piiNumber: piiNumber,
      };
      await ialtSuccessAcknowledgeService(ackPaylod, 'FinishedSuccessfully');

      resolve(result);
    } catch (err) {
      await logAcknowledgementActivity({
        signalAuditId,
        stage: currentStage,
        acknowledgementtype: 'COMPLETED_ACK',
        status: 'Failed',
        pii: piiNumber,
        errorMessage: `Failed at ${currentStage} stage: ${
          err.message || 'Unknown error'
        }`,
      });

      const logHisPayload = {
        signalAuditId,
        updateType: 'failed',
        request: payload,
        response: err.message ? err.message : err,
        message: 'Final output upload acknowledgment has failed',
        status: 'Failed',
        processStatusId: 26,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);

      const ackPaylod = {
        signalAuditId,
        ackMsgInfo,
      };
      await ialtFailedAcknowledgeService(ackPaylod, 'Failed');
      reject('Alt text upload notification sending failed');
    }
  });
};

export const getMetaData = signalAckPayload => {
  return new Promise(async (resolve, reject) => {
    const { piiNumber, signalAuditId, ackMsgInfo } = signalAckPayload;
    const url = `${config.iAlt.else_vier.base_url}/metadata/pii/${piiNumber}?mode=full`;
    try {
      const result = await service.ialtGet(url);
      if (Object.keys(result).length) {
        const logHisPayload = {
          signalAuditId,
          request: url,
          response: result,
          message: 'Metadata fetching request successful',
          status: 'Success',
          processStatusId: 3,
        };
        // await ialtSignalLogHistory(logHisPayload);
        resolve(result);
      } else {
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: url,
        response: err.message ? err.message : err,
        message: 'Metadata fetching request failed',
        status: 'Failed',
        processStatusId: 3,
      };
      await ialtSignalLogHistory(logHisPayload);

      await ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
      reject(err.message ? err.message : err);
    }
  });
};
export const readJobData = jobData => {
  return new Promise((resolve, reject) => {
    try {
      const serviceCallType = path.basename(jobData['msg:service']['svc:type']);
      const piiNumber = path.basename(jobData['msg:service']['svc:about']);
      const chpData = jobData['msg:service']['svc:params'][0];
      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);
      const ackMsgInfo = {
        messageSMSId: path.basename(jobData['@id']),
        serviceSMSId: path.basename(jobData['msg:service']['@id']),
        serviceAboutUrl: jobData['msg:service']['svc:about'],
        egiFilesInfo: jobData['msg:service']['svc:resource'],
        sourceType:
          jobData['msg:service']['svc:params'].length > 1
            ? jobData['msg:service']?.['svc:params']?.[1]?.['moreDetails']?.[
                'source'
              ]
            : '',
      };

      const chapterInfo = {
        name:
          chpData.chapterNumber == '' ||
          chpData.chapterNumber == null ||
          chpData.chapterNumber == 'null'
            ? (() => {
                const match = chpData.chapterTitle.match(/^(\d+(\.\d+)?)/);
                const extractedNumber = match ? match[0] : chpData.chapterTitle;
                return `${chpData.chapterPit.trimEnd()} ${extractedNumber}`.trimEnd();
              })()
            : `${chpData.chapterPit.trimEnd()} ${
                chpData.chapterNumber
              }`.trimEnd(),

        title: chpData.chapterTitle.replace(/(')/g, '$1$1'),
        startDate: moment().format('YYYY-MM-DD hh:mm:ss'),
        endDate: moment(futureDate).format('YYYY-MM-DD hh:mm:ss'),
        userId: 'System',
      };
      resolve({ serviceCallType, piiNumber, ackMsgInfo, chapterInfo });
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};
export const readMetadata = result => {
  return new Promise((resolve, reject) => {
    try {
      const jobInfo = {};
      // tat caluculation for 48 hrs from now
      const currentDate = new Date();
      const futureDate = new Date(currentDate.getTime() + 48 * 60 * 60 * 1000);
      const allStageSourceInfo = result['bam:hasGeneration'];
      let stageSourceInfo = [];
      stageSourceInfo = result['bam:hasGeneration'].filter(
        item => item['bam:stage'] === 'accepted_manuscript',
      );
      const getMaxVerison = stageSourceInfo.reduce(
        (max, row) =>
          row['bam:generation'] > max['bam:generation'] ? row : max,
        stageSourceInfo[0],
      );
      const assetInfo = getMaxVerison['bam:hasAsset'];
      jobInfo.receivedStage = getMaxVerison['bam:stage'];
      // jobInfo.title = result['prism:publicationName'].replaceAll(' ', '_').replaceAll('–', '_');
      jobInfo.title =
        result['prism:publicationName']
          ?.replaceAll(' ', '_')
          ?.replaceAll('–', '_') || '';
      jobInfo.isbn = result['prism:isbn'].replace(/-/g, '');
      jobInfo.assetInfo = assetInfo;
      jobInfo.assetmeta = result['bam:hasAssetMetadata'];
      jobInfo.dueDate = moment(futureDate).format('YYYY-MM-DD hh:mm:ss');
      jobInfo.userId = 'System';

      resolve(jobInfo);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      reject(error);
    }
  });
};
// download asset file from client
export const downloadAssetFile = (assetInfo, signalAckPayload) => {
  return new Promise(async (resolve, reject) => {
    const { signalAuditId, ackMsgInfo } = signalAckPayload;
    try {
      const assetPromises = assetInfo.map(async item => {
        const assetUrl = item.path;
        let isegiFile = item.isegiFile;
        const fileName = item.filename;

        const {
          data: sourceContent,
          filename,
          contentType,
        } = await service.ialtGetWithBlob(assetUrl, {}, fileName);
        return { sourceContent, filename, contentType, isegiFile };
      });
      const assetDownloadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: 'Asset download successfully',
        response: 'Asset download successfully',
        message: 'Source file downloaded successfully',
        status: 'Success',
        processStatusId: 4,
      };
      // await ialtSignalLogHistory(logHisPayload);
      resolve(assetDownloadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(assetInfo),
        response: err.message ? err.message : 'Source file downloaded failed',
        message: 'Source file downloaded failed',
        status: 'Failed',
        processStatusId: 4,
      };
      await ialtSignalLogHistory(logHisPayload);

      await ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
      reject(err);
    }
  });
};
// get du, customer info
const getGeneralInfo = payload => {
  return new Promise(async (resolve, reject) => {
    const { duId, customerId, receivedStage, stageId } = payload;
    try {
      let sql = `select duid, duname from org_mst_deliveryunit where duid=${duId} and isactive=true`;
      const duInfo = await query(sql);
      sql = `select customerid, customername from org_mst_customer where customerid=${customerId} and isactive=true`;
      const custInfo = await query(sql);
      sql = `select stageid, stagename from wms_mst_stage where stageid=${stageId}`;
      // sql = `select stageid, stagename from wms_mst_stage where stageid = (select stageid from wms_mst_service_calltype
      // join wms_mst_service_calltype_map on wms_mst_service_calltype_map.servicecallmapid=wms_mst_service_calltype.servicecaltypeid
      // where servicecalltype='${receivedStage}' and wms_mst_service_calltype.isactive=true and wms_mst_service_calltype_map.isactive=true) and isactive=true`;
      const stageInfo = await query(sql);
      sql = ` SELECT dms_master.dmsid, dms_master.dmstype FROM wms_mst_customerconfigdetails 
      JOIN dms_master ON dms_master.dmsid = wms_mst_customerconfigdetails.dmsid
      WHERE customerid=${customerId} and dms_master.isactive`;

      const dmsInfo = await query(sql);
      if (
        duInfo.length &&
        custInfo.length &&
        stageInfo.length &&
        dmsInfo.length
      ) {
        resolve({
          ...payload,
          du: { id: duInfo[0].duid, name: duInfo[0].duname },
          customer: {
            id: custInfo[0].customerid,
            name: custInfo[0].customername,
          },
          stage: { id: stageInfo[0].stageid, name: stageInfo[0].stagename },
          dms: { id: dmsInfo[0].dmsid, name: dmsInfo[0].dmstype },
        });
      } else {
        throw new Error('Du | Customer | Stage info not found');
      }
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};
// asset upload process
export const assetUploadProcess = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      assetDownloadRes,
      signalAuditId,
      du,
      customer,
      stage,
      bookName,
      chapterName,
    } = payload;
    try {
      let formatBookName = bookName
        .trim()
        .replace(/['’]/gi, '')
        .replace(/[^a-zA-Z0-9]/gi, ' ')
        .replace(/\s+/gi, '_');
      const folderPathData = {
        type: 'ialt_book_chapter_stage',
        duName: du.name,
        customerName: customer.name,
        bookName: formatBookName,
        chapterName: chapterName.trim(),
        stageName: stage.name,
      };
      let pathToStore = await getFolderStructureForIalt(folderPathData);
      pathToStore = pathToStore.replaceAll(/[^a-zA-Z0-9./-]/g, '_');
      if (pathToStore.startsWith('/okm:root/'))
        pathToStore = pathToStore.replace('/okm:root/', '');
      if (pathToStore.startsWith('/okm_root/'))
        pathToStore = pathToStore.replace('/okm_root/', '');

      const assetPromises = assetDownloadRes.map(async item => {
        if (item.contentType) {
          let docPath;
          if (item?.isegiFile) {
            docPath = `${pathToStore}Images/${item.filename}`;
          } else {
            docPath = `${pathToStore}${item.filename}`;
          }
          const { fullPath } = await _uploads3File(
            docPath,
            item.sourceContent,
            item.contentType,
          );
          let sasPath = {};
          const extensions = [
            '.pdf',
            '.docx',
            '.doc',
            '.ppt',
            '.pptx',
            '.tiff',
            '.tif',
            '.eps',
            '.jpg',
            '.jpeg',
            '.webp',
            '.bmp',
            '.gif',
            '.tif',
            '.eps',
            '.ico',
            '.svg',
            '.svg+xml',
            '.png',
            '.psd',
            '.ai',
            '.xml',
          ];

          if (extensions.some(ext => fullPath.toLowerCase().includes(ext))) {
            const { data } = await _download(fullPath);
            sasPath = data;
          }
          return {
            allPath: fullPath,
            pathWithSAS: sasPath.path ? sasPath.path : '',
            isegiFile: item?.isegiFile,
          };
        }
      });
      const assetUploadRes = await Promise.all(assetPromises);

      const logHisPayload = {
        signalAuditId,
        request: 'Source file asset upload request',
        response: 'Source file asset upload successfully',
        message: 'Source file uploaded to blob successfully',
        status: 'Success',
        processStatusId: 5,
      };
      //  await ialtSignalLogHistory(logHisPayload);
      resolve(assetUploadRes);
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(payload),
        response: err.message
          ? err.message
          : 'Source file upload to blob failed',
        message: 'Source file upload to blob failed',
        status: 'Failed',
        processStatusId: 5,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(err);
    }
  });
};

export const logAcknowledgementActivity = async payload => {
  const {
    signalAuditId,
    stage,
    acknowledgementtype,
    status,
    pii,
    errorMessage = null,
  } = payload;

  try {
    const checkSql = `
    SELECT 1 FROM ialtacknowledgementlog 
    WHERE pii = $1 AND acknowledgementtype = $2
  `;
    const [existingRecord] = await query(checkSql, [pii, acknowledgementtype]);

    const params = [
      signalAuditId, // $1
      pii, // $2
      stage, // $3
      acknowledgementtype, // $4
      status, // $5
      errorMessage, // $6
      new Date(), // $7
    ];
    const sql = existingRecord
      ? `UPDATE ialtacknowledgementlog 
        SET signalauditid = $1,
            stage = $3,
            status = $5,
            error_message = $6,
            updated_at = $7
        WHERE pii = $2 AND acknowledgementtype = $4`
      : `INSERT INTO ialtacknowledgementlog 
        (signalauditid, pii, stage, acknowledgementtype, status, error_message, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7)`;

    await query(sql, params);
    return { success: true };
  } catch (err) {
    throw new Error(`Queue logging failed: ${err.message}`);
  }
};

// job received acknowledgement to client
export const ialtJobReceivedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      piiNumber,
      signalAuditId,
      isRetrigger = false,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    let currentStage = '';

    try {
      currentStage = 'TOKEN_FETCH';
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      let tokenRes = null;

      try {
        tokenRes = await service.post(url, data);
      } catch (error) {
        throw new Error('iAlt API Failed to get Token: ' + error.message);
      }

      currentStage = 'PREPARE_JOB_RECEIVED_ACK_PAYLOAD';
      const { auth_token } = tokenRes.data;
      data = {
        '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/AltTextSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
        'msg:event': {
          '@id':
            'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-1008-4e52-9b8a-c75f8c6c7742',
          '@type': 'msg:EventNotification',
          'evt:time': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
          'evt:type':
            'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      currentStage = 'SEND_JOB_RECEIVED_ACK';
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      let result = null;
      try {
        result = await service.post(url, data, headers);
      } catch (error) {
        throw new Error(
          'iAlt API Failed to sending acknowledgment: ' + error.message,
        );
      }
      currentStage = 'RECEIVED_ACK_SUCCESS';

      const logHisPayload = {
        signalAuditId,
        updateType: 'acknowledged',
        request: data,
        response: result,
        message: 'Job received acknowledgment sent successfully',
        status: 'Success',
        processStatusId: 2,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);

      const isAcklogsAvailableQuery = `SELECT id as ackid, pii, signalauditid, acknowledgementtype, status
                                        FROM ialtacknowledgementlog where status = 'Failed' and signalauditid = '${signalAuditId}' and acknowledgementtype = 'RECEIVED_ACK'`;
      const isAcklogsAvailable = await query(isAcklogsAvailableQuery);

      if (!!isAcklogsAvailable) {
        await logAcknowledgementActivity({
          signalAuditId,
          stage: currentStage,
          acknowledgementtype: 'RECEIVED_ACK',
          status: isRetrigger ? 'Retriggered' : 'Completed',
          pii: piiNumber,
          errorMessage: '',
        });
      }
      resolve(true);
    } catch (error) {
      await logAcknowledgementActivity({
        signalAuditId,
        stage: currentStage,
        acknowledgementtype: 'RECEIVED_ACK',
        status: 'Failed',
        pii: piiNumber,
        errorMessage: `Failed at ${currentStage} stage: ${
          error.message || 'Unknown error'
        }`,
      });

      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Job received acknowledgement sent failed',
        message: 'Job received acknowledgement sent failed',
        status: 'Failed',
        processStatusId: 2,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// failed acknowledgement to client
export const ialtFailedAcknowledgeService = (payload, status) => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
    } = payload;
    let data = {};
    try {
      // get the token
      data = {
        accessKey: process.env.SMS_ACCESSKEY,
        secretKey: process.env.SMS_SECRETKEY,
      };
      let url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.getSmsApiToken}`;
      const tokenRes = await service.post(url, data);
      const { auth_token } = tokenRes.data;
      data = {
        '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
        '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
        '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
        '@type': 'msg:Message',
        'msg:format':
          'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
        'msg:type':
          'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
        'msg:from':
          'http://vtw.elsevier.com/data/voc/Contributors/Integra/AltTextSupplier',
        'msg:to':
          'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
        'msg:event': {
          '@id':
            'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-5007-4e52-9b8a-c75f8c6c7742',
          '@type': 'msg:EventNotification',
          'evt:time': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
          'evt:type': `http://vtw.elsevier.com/data/voc/Events/${status}`,
          'evt:about': `${serviceAboutUrl}`,
          'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
        },
      };
      const headers = {
        Authorization: `Bearer ${auth_token}`,
      };
      url = `${config.iAlt.else_vier.sms.base_url}/${config.iAlt.else_vier.sms.uri.receiveAcknowledgement}`;
      const result = await service.post(url, data, headers);
      const logHisPayload = {
        signalAuditId,
        updateType: 'failed',
        request: data,
        response: result,
        message: 'Job failure acknowledgment sent successfully',
        status: 'Success',
        processStatusId: 15,
      };
      await ialtSignalLogService(logHisPayload, 'Update');
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: data,
        response: 'Sent failed',
        message: 'Job failure acknowledgment sent failed',
        status: 'Failed',
        processStatusId: 24,
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// job completed acknowledgement to client
export const ialtJobCompletedAcknowledgeService = payload => {
  return new Promise(async (resolve, reject) => {
    const {
      signalAuditId,
      piiNumber,
      ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
      queueUrl,
    } = payload;
    const messageBody = {
      '@timestamp': moment().format('YYYY-MM-DD hh:mm:ss.sss'),
      '@context': 'http://vtw.elsevier.com/metadata/context.jsonld',
      '@id': `http://vtw.elsevier.com/message/id/Elsevier/SMS/${messageSMSId}`,
      '@type': 'msg:Message',
      'msg:format': 'http://vtw.elsevier.com/data/voc/Formats/MessageFormat-1',
      'msg:type':
        'http://vtw.elsevier.com/data/voc/MessageTypes/EventNotification-1',
      'msg:from':
        'http://vtw.elsevier.com/data/voc/Contributors/MPS/BookSupplier',
      'msg:to':
        'http://vtw.elsevier.com/data/voc/Contributors/Elsevier/CWSBooksProduction',
      'msg:event': {
        '@id':
          'http://vtw.elsevier.com/event/id/Elsevier/SMS/3b6cdced-1008-4e52-9b8a-c75f8c6c7742',
        '@type': 'msg:EventNotification',
        'evt:time': '2024-05-29T11:07:25.777Z',
        'evt:type':
          'http://vtw.elsevier.com/data/voc/Events/ServiceCallAcknowledged',
        'evt:about': `${serviceAboutUrl}`,
        'evt:parent': `http://vtw.elsevier.com/serviceCall/id/Elsevier/SMS/${serviceSMSId}`,
      },
    };
    const params = {
      MessageBody: JSON.stringify(messageBody),
      QueueUrl: queueUrl,
    };
    try {
      const data = await sqs.sendMessage(params).promise();
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent successfully',
        status: 'Job received acknowledgment sent successfully',
      };
      await ialtSignalLogHistory(logHisPayload);
      resolve(true);
    } catch (error) {
      const logHisPayload = {
        signalAuditId,
        request: JSON.stringify(params),
        response: 'Sent failed',
        status: 'Job received acknowledgement sent failed',
      };
      await ialtSignalLogHistory(logHisPayload);
      reject(error);
    }
  });
};
// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { action, to, customerId, message, title, stageName, woTypeId } =
        data;
      let payload = {
        entityId: 2,
        actionType: action,
        customerId,
        woTypeId,
      };
      const resForConfig = await getNotificationTemplate(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: title,
        stageName,
        subMessage: message,
        toMail: toMailArray,
      };
      await emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};
// get dms info
const getDmsInfo = customerId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT dmsid FROM wms_mst_customerconfigdetails WHERE customerid=$1`;
      const dmsInfo = await query(sql, [customerId]);
      const { dmsid } = dmsInfo[0];
      resolve(dmsid);
    } catch (err) {
      reject('DMS info not found for the customer');
    }
  });
};

const getEgiMetaData = signalAckPayload => {
  return new Promise(async (resolve, reject) => {
    const { egiNumber, signalAuditId, ackMsgInfo } = signalAckPayload;
    const url = `${config.iAlt.else_vier.base_url}/metadata/egi/${egiNumber}`;
    try {
      const result = await service.ialtGet(url);
      if (Object.keys(result).length) {
        const logHisPayload = {
          signalAuditId,
          request: url,
          response: result,
          message: 'Metadata fetching request successful',
          status: 'Success',
          processStatusId: 3,
        };
        // await ialtSignalLogHistory(logHisPayload);
        const response = await readMetadata(result);
        resolve(response.assetInfo);
      } else {
        throw new Error('Metadata info not found');
      }
    } catch (err) {
      const logHisPayload = {
        signalAuditId,
        request: url,
        response: err.message ? err.message : err,
        message: 'Metadata fetching request failed',
        status: 'Failed',
        processStatusId: 3,
      };
      await ialtSignalLogHistory(logHisPayload);

      await ialtFailedAcknowledgeService(signalAckPayload, 'CannotFinish');
      reject(err.message ? err.message : err);
    }
  });
};

export const getMetaDataForTitle = async pii => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `
        SELECT * 
        FROM public.wms_mst_signal_audit_trns
        WHERE signalauditid IN (
          SELECT signalauditid 
          FROM public.wms_mst_signal_audit  
          WHERE pii IN ('${pii}')
        ) 
        AND message = 'Job request received'
      `;
      const payloadInfo = await query(sql);
      resolve(
        payloadInfo[0]?.response?.['msg:service']?.['svc:params']?.[0]
          ?.chapterTitle,
      );
    } catch (err) {
      reject(err.message ? err.message : err);
    }
  });
};
