import { altextGenerationJobService } from '../service/elseVier/altTextJobProcess.js';
import {
  journalJobService,
  updateXMLPreviewService,
  _ialtFailedAcknowledgeService,
  srcFileDownloadFromPii,
  checkVTWSignalReceived,
} from '../service/elseVier/journalJobProcess.js';
import { query } from '../../database/postgres.js';
import {
  getJournalSignalAuditService,
  getJournalSignalHistoryService,
} from '../service/index.js';

export const altextGenerationJobController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await altextGenerationJobService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const journalJobProcessController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await journalJobService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const updateXMLPreviewController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await updateXMLPreviewService(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({
      status: false,
      message: error.message ? error.message : 'Update XML API has failed',
    });
  }
};
export const ialtFailedAcknowledgeService = async (req, res) => {
  try {
    const { woId, status } = req.body;
    let sql = `SELECT REGEXP_REPLACE(otherfield->>'pii', '[^a-zA-Z0-9]', '', 'g') AS pii FROM wms_workorder WHERE
    workorderid = $1`;
    const piiInfo = await query(sql, [woId]);
    if (piiInfo.length <= 0 && piiInfo[0].pii != '') {
      res.status(400).send({
        status: false,
        message: 'pii value not found for the given workorderid.',
      });
    }
    const { pii } = piiInfo[0];
    //  const piiNumber = piiInfo[0].piinumberreplace(/[^a-zA-Z0-9]/g, '');
    sql = ` select signalinfo ::jsonb->> 'messageSMSId' as messageSMSId,
    signalinfo::jsonb->> 'serviceSMSId' AS serviceSMSId, signalinfo::jsonb->> 'serviceAboutUrl'
    AS serviceAboutUrl, signalauditid,* from public.wms_mst_signal_audit  where pii =$1`;
    const signalInfo = await query(sql, [pii]);
    if (signalInfo.length > 0) {
      const { messageSMSId, serviceSMSId, serviceAboutUrl } =
        signalInfo[0].signalinfo;
      const ackPayload = {
        signalAuditId: signalInfo[0].signalauditid,
        ackMsgInfo: { messageSMSId, serviceSMSId, serviceAboutUrl },
      };
      const response = await _ialtFailedAcknowledgeService(ackPayload, status);
      if (response) {
        res.status(200).send({
          status: true,
          message: 'Acknowledgement sent successfully',
        });
      }
    } else {
      res.status(400).send({
        status: false,
        message: 'No data found',
      });
    }
  } catch (error) {
    res.status(400).send({
      status: false,
      message: error.message
        ? error.message
        : 'ialtFailedAcknowledgeService has failed',
    });
  }
};

export const srcFileDownloadFromPiiController = async (req, res) => {
  try {
    const payload = req.body;
    const response = await srcFileDownloadFromPii(payload);
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const checkVTWSignalReceivedController = async (req, res) => {
  try {
    const { pii, servicetype, jobflowtype } = req.params;
    const response = await checkVTWSignalReceived(
      decodeURIComponent(pii),
      servicetype,
      jobflowtype,
    );
    res.status(200).json(response);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Need integrate here for loop trigger auto jobcreation retrigger

export const multipleJobsRetrigger = async () => {
  const payload = [{ pii: 'B9780443317521000040' }];

  for (let i = 0; i < payload.length; i++) {
    const pii = payload[i]?.pii;
    const sql = ` select * from public.wms_mst_signal_audit_trns
                   where signalauditid in (
                   select signalauditid from public.wms_mst_signal_audit  where pii = '${pii}'	
                   ) and message = 'Job request received'`;

    const payloadInfo = await query(sql);
    console.log(payloadInfo, 'payloadInfo');
    if (
      payloadInfo &&
      payloadInfo.length > 0 &&
      'msg:to' in payloadInfo[0].response
    ) {
      const response = await altextGenerationJobService(
        payloadInfo[0].response,
      );

      // await query(
      //   `update  wms_mst_signal_audit set isactive = false where pii ='${pii}'`,
      // );

      console.log(response, 'response');
    } else {
      console.log('invalid payload');
    }
  }
};

// multipleJobsRetrigger()

// get Journal Signal Aduit
export const getJournalSignalAuditController = async (req, res) => {
  try {
    const payload = req.body;
    let reportLists = '';
    reportLists = await getJournalSignalAuditService(payload);
    res.status(200).json(reportLists.response);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};

export const getJournalSignalHistoryController = async (req, res) => {
  try {
    const payload = req.body;
    const reportLists = await getJournalSignalHistoryService(payload);
    res.status(200).json(reportLists);
  } catch (error) {
    const errorMessage = error?.message || 'Unknown error occurred';
    res.status(400).json({ error: errorMessage });
  }
};
