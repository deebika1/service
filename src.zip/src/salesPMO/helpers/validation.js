import Joi from 'joi';

export const searchforfeedbackSchema = Joi.object({
  bookcode: Joi.string().allow('').required(),
  jobcardcode: Joi.number().allow(null).required(),
  jobtitle: Joi.string().allow('').required(),
  fromdate: Joi.date().allow(null).required(),
  todate: Joi.date().allow(null).required(),
  divisions: Joi.number().allow(null).required(),
  customers: Joi.number().allow(null).required(),
  companyid: Joi.number().allow(null).required(),
  searchby: Joi.string().allow('').required(),
  isbn: Joi.string().allow('').required(),
  jobcardid: Joi.number().allow(null).required(),
});

export const handleCustomerInsertSchema = Joi.object({
  cmEmpCode: Joi.string().allow('').required(),
  kamEmpCode: Joi.string().required(),
  kamHEmpCode: Joi.string().required(),
  customerId: Joi.number().required(),
  countryId: Joi.number().required(),
  divisionId: Joi.number().required(),
  verticalId: Joi.number().required(),
  serviceId: Joi.array().required(),
  segmentId: Joi.number().required(),
  duId: Joi.number().required(),
  entityId: Joi.number().required(),
  effectiveFrom: Joi.date().required(),
  isActive: Joi.boolean().required(),
  createdBy: Joi.string().required(),
  remarks: Joi.string().required(),
  kamcustomerrelid: Joi.number().required().allow(null),
  approvedempcode: Joi.string().required().allow(null),
  new_effective_from: Joi.date().required().allow(null),
  new_cmempcode: Joi.string().required().allow(null),
  new_kamempcode: Joi.string().required().allow(null),
  new_kamhempcode: Joi.string().required().allow(null),
});

export const insertReassignKamOrCmSchema = Joi.object({
  insertList: Joi.array().required(),
  updateList: Joi.array().required(),
  kam: Joi.string().required().allow(''),
  cm: Joi.string().required().allow(''),
  effectiveFrom: Joi.date().required(),
  reason: Joi.string().required(),
  userid: Joi.string().required(),
});

export const getChangeReqFilterSchema = Joi.object({
  status: Joi.string().valid('all', 'P', 'R', 'A').required(),
  type: Joi.string().valid('all', 'CR', 'NR').required(),
});

export const getKamDetailsSchema = Joi.object({
  rectype: Joi.string().valid('P', 'K').required(),
  relid: Joi.number().required(),
});

export const getKAMPendingHistorySchema = Joi.object({
  queueid: Joi.number().required(),
});

export const getUserMappedAndBaseDuSchema = Joi.object({
  type: Joi.string().valid('mappeddu', 'basedu').required(),
  userid: Joi.string().required(),
});
export const getRateEntryByIdSchema = Joi.object({
  vertical: Joi.string().required(),
  id: Joi.number().required(),
});

export const getProjectWiseReportDataSchema = Joi.object({
  selectedDu: Joi.array().required(),
  baseDu: Joi.number().required(),
  exchange: Joi.number().required(),
  currency: Joi.number().required(),
  from: Joi.date().required(),
  to: Joi.date().required(),
});

export const getPlanVsActualReportDataSchema = Joi.object({
  selectedDu: Joi.array().required(),
  exchange: Joi.number().required(),
  currency: Joi.number().required(),
  from: Joi.date().required(),
  to: Joi.date().required(),
});

export const getRateEntryTableDataSchema = Joi.object({
  duId: Joi.number().required().allow(null),
  customerId: Joi.number().required().allow(null),
  vertical: Joi.string().required(),
  searchText: Joi.string().required().allow(''),
  startDate: Joi.string().required().allow(null),
  endDate: Joi.string().required().allow(null),
});

const masterData = [
  'stage',
  'service',
  'du',
  'uom',
  'currency',
  'country',
  'kam',
  'cm',
  'segment',
  'entity',
  'mstcustomer',
  'spmostatus',
  'reqtype',
  'spmostatusdd',
  'currencycode',
  'exchangerate',
  'cmempcode',
  'kamempcode',
  'vertical',
];

export const getMasterSchema = Joi.object({
  table: Joi.string()
    .valid(...masterData)
    .required(),
});

export const journalRateEnryServiceDDSchema = Joi.object({
  duId: Joi.number().required().allow(null),
  customerId: Joi.number().required().allow(null),
});

export const getStageDDByserviceMappingSchema = Joi.object({
  serviceMapId: Joi.number().required().allow(null),
});

export const insertJournalRateEntrySchema = Joi.object({
  journalid: Joi.number().required(),
  journalacronym: Joi.string().required(),
  currencyid: Joi.number().required(),
  created_by: Joi.string().required(),
  data: Joi.array().required(),
});

export const insertRateEntrySchema = Joi.object({
  workorderid: Joi.number().required().allow(''),
  bookcode: Joi.string().required().allow(''),
  journalid: Joi.number().required().allow(''),
  journalacronym: Joi.string().required().allow(''),
  currencyid: Joi.number().required(),
  created_by: Joi.string().required(),
  vertical: Joi.string().required(),
  data: Joi.array().required(),
  deleteids: Joi.array().required().allow(null),
});

export const getUserMappedDuByUserIdSchema = Joi.object({
  userid: Joi.string().required(),
});

export const geCustomerByDuidSchema = Joi.object({
  duid: Joi.number().required(),
});

export const geVerticalByDuidSchema = Joi.object({
  duid: Joi.number().required(),
  customerid: Joi.number().required(),
});

export const getRateEntryDDSchema = Joi.object({
  duid: Joi.number().required(),
  customerid: Joi.number().required(),
  verticalid: Joi.number().required(),
  dd: Joi.string().required(),
});

export const getRateHistorySchema = Joi.object({
  rateid: Joi.number().required(),
  vertical: Joi.string().required(),
});
export const getRateEntryActualSchema = Joi.object({
  workorderid: Joi.number().required().allow(null),
  bookcode: Joi.string().required().allow(''),
});
export const getRateEntryAdjSchema = Joi.object({
  workorderid: Joi.number().required().allow(null),
  bookcode: Joi.string().required().allow(''),
});
export const deleteRateEntryAdjSchema = Joi.object({
  adjustmentid: Joi.number().required().allow(null),
  userid: Joi.string().required().allow(''),
});

export const inserAdjJobRateSchema = Joi.object({
  workorderid: Joi.number().required().allow(null),
  bookcode: Joi.string().required(),
  duid: Joi.number().required(),
  duidname: Joi.string().required().allow(''),
  baseduid: Joi.number().required().allow(null),
  baseduname: Joi.string().required().allow(''),
  customerid: Joi.number().required().allow(null),
  customername: Joi.string().required().allow(''),
  divisionid: Joi.number().required().allow(null),
  divisionname: Joi.string().required().allow(''),
  countryid: Joi.number().required().allow(null),
  countryname: Joi.string().required().allow(''),
  verticalid: Joi.number().required().allow(null),
  verticalname: Joi.string().required().allow(''),
  segmentid: Joi.number().required().allow(null),
  segmentname: Joi.string().required().allow(null),
  jobcreatedon: Joi.string().required().allow(''),
  service: Joi.number().required().allow(null),
  servicename: Joi.string().required().allow(''),
  ordermonth: Joi.string().required().allow(''),
  value: Joi.number().required().allow(null),
  remarks: Joi.string().required(),
  currencyid: Joi.number().required().allow(null),
  currencyname: Joi.string().required().allow(''),
  userid: Joi.string().required(),
});

export const getServiceFromKAMSchema = Joi.object({
  duid: Joi.number().required(),
  customerid: Joi.number().required(),
  verticalid: Joi.number().required(),
});

export const getRateConfigStageByWorkFlowSchema = Joi.object({
  customerid: Joi.number().required(),
});

export const insertRateEntryConfigSchema = Joi.object({
  customerInfo: Joi.object().required(),
  orderInFlow: Joi.array().required(),
  deleteItems: Joi.array().required().allow(null),
  userId: Joi.string().required(),
  notRequired: Joi.boolean().required(),
});
export const insertInvoiceDescSchema = Joi.object({
  customerInfo: Joi.object().required(),
  invoiceDescription: Joi.array().required(),
  deleteItems: Joi.array().required().allow(null),
  userId: Joi.string().required(),
  notRequired: Joi.boolean().required(),
});

export const rateConfigTableSchema = Joi.object({
  duid: Joi.number().required(),
  customerid: Joi.number().required(),
  verticalid: Joi.number().required(),
});

export const rateConfigAppendixSchema = Joi.object({
  customerInfo: Joi.object().required(),
  appendixTemplate: Joi.array().required(),
  userId: Joi.string().required(),
  id: Joi.number().required(),
});

export const rateConfigCombinationSchema = Joi.object({
  duid: Joi.number().required(),
  customerid: Joi.number().required(),
  verticalid: Joi.number().required(),
});

export const raiseRFITableSchema = Joi.object({
  customer: Joi.number().allow(null),
  status: Joi.number().allow(null),
  searchtext: Joi.string().allow(null),
  fields: Joi.array().required().allow(null),
  userid: Joi.string().required(),
  tablestatus: Joi.array().required(),
});

export const getJobdetailsSchema = Joi.object({
  woid: Joi.number().required(),
});
export const getJobDetailsByWoidStageidSchema = Joi.object({
  woid: Joi.number().required(),
  stageid: Joi.number().required(),
});

export const getRFIInvoiceFieldsSchema = Joi.object({
  duid: Joi.number().required(),
  customerid: Joi.number().required(),
  verticalid: Joi.number().required(),
});

export const createRfiSchema = Joi.object({
  invoiceid: Joi.number().required(),
  rfisavetype: Joi.string().required(),
  userid: Joi.string().required(),
  woid: Joi.number().required(),
  itemcode: Joi.string().required(),
  jobdetails: Joi.string().required(),
  invoice: Joi.string().required(),
  invoiceType: Joi.string().required(),
  price: Joi.string().required(),
  remark: Joi.string().allow(''),
  attachment: Joi.string(),
  isApprover: Joi.boolean().required(),
  uploads: Joi.any(),
});

export const invoiceDescSchema = Joi.object({
  duid: Joi.number().required(),
  customerid: Joi.number().required(),
  verticalid: Joi.number().required(),
  serviceid: Joi.number().required(),
  category: Joi.string().required(),
});

export const rateEntryRFISchema = Joi.object({
  vertical: Joi.string().required(),
  woid: Joi.number().required(),
});

export const invoiceintegration = Joi.object({
  journalId: Joi.number().optional(),
  workorderId: Joi.number().required(),
  stageId: Joi.number().required(),
});

export const getArticleDetailsSchema = Joi.object({
  woid: Joi.number().required(),
  jobtype: Joi.string().required(),
});

export const approveRejectRFISchema = Joi.object({
  invoiceid: Joi.number().required(),
  userid: Joi.string().required(),
  approved: Joi.boolean().required(),
  reason: Joi.string().required().allow(''),
});

export const getAuditSearchDDSchema = Joi.object({
  module: Joi.string().required(),
  search: Joi.string().required(),
  vertical: Joi.string().required().allow(''),
  duId: Joi.number().required(),
  customerId: Joi.number().required(),
});

export const getAuditDataSchema = Joi.object({
  module: Joi.string().required(),
  vertical: Joi.string().required().allow(''),
  search: Joi.string().required(),
});

export const journalManuscriptEditorialSchema = Joi.object({
  data: Joi.array()
    .items(
      Joi.object({
        sequence: Joi.number().required(),
        level_of_effort: Joi.number().required(),
        ManuscriptNumber: Joi.string().alphanum().required(), // ManuscriptNumber should be alphanumeric
        TechEditPageCount: Joi.number().optional(),
        BillableGraphicCount: Joi.number().optional(),
        tech_edit_cost: Joi.number().optional(),
        graphic_cost: Joi.number().optional(),
      }),
    )
    .required(), // Ensure that 'data' exists and is an array of objects
  createdBy: Joi.any().optional(), // You can leave this as optional or validate it if needed
  key: Joi.any().optional(), // Same here, optional validation
  Year: Joi.any().optional(), // Same for Year, optional if not needed
});
