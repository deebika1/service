import { query } from '../../database/postgres.js';
import { getRFIStatusIdsScript } from '../datalayer/rfiScripts.js';

let _statusIDMap = {}; // Private variable to hold the status codes and IDs

const DEFAULT_STATUS_CODES = ['INP', 'INVC', 'OF', 'INP']; // Default status codes to initialize

const RFIStatusManager = {
  // Initialize the status manager with a series of status codes
  async initializeStatusIDs(statusCodes = DEFAULT_STATUS_CODES) {
    if (!Array.isArray(statusCodes)) {
      throw new Error('Input must be an array of status codes.');
    }

    const result = await query(getRFIStatusIdsScript(statusCodes));

    // Populate the map with results from the query
    _statusIDMap = result.reduce((map, row) => {
      map[row.statuscode] = row.rfistatusid;
      return map;
    }, {});

    // console.log("RFIStatusManager initialized with status codes:", Object.keys(_statusIDMap));
  },

  // Get the status ID for a specific code
  RFIStatusID(statusCode) {
    if (!_statusIDMap[statusCode]) {
      console.trace(`Status ID for code "${statusCode}" is not initialized.`);
      throw new Error(`Status ID for code "${statusCode}" is not initialized.`);
    }
    return _statusIDMap[statusCode];
  },
};

// Self-invoking async function to preload status IDs on module load
(async () => {
  try {
    await RFIStatusManager.initializeStatusIDs();
    // console.log("RFIStatusManager preloaded with default status codes.");
  } catch (error) {
    console.error('Failed to preload RFIStatusManager:', error);
  }
})();

export const initializeStatusIDs = async statusCodes =>
  RFIStatusManager.initializeStatusIDs(statusCodes);
export const RFIStatusID = statusCode =>
  RFIStatusManager.RFIStatusID(statusCode);
