import { query, transactionWithResult } from '../../database/postgres.js';
import { odooEndPoints } from '../../odoo/helpers/odooApiEndpoints.js';
import {
  insertOdooInvoiceLogService,
  odooApiIntegrationService,
  safeStringify,
  updateOdooInvoiceLogService,
} from '../../odoo/service/index.js';
import { updateRFIDetailsTableScript } from '../datalayer/rfiScripts.js';
import { RFIStatusID } from './RFIStatusID.js';

const InvoiceQueueDetailsTemplate = {
  InvoiceQueueDetails: [
    {
      RFIid: '-',
      DeliveryUnit: 'Editorial Services – Journals',
      Customer: 'American Chemical Society',
      Email: null,
      Vertical: 'Journals',
      JournalShortName: 'sc',
      JournalCode: 'sc',
      JournalName: 'ACS Sustainable Chemistry & Engineering',
      Country: 'US',
      CountryOfOrigin: null,
      JobReceivedDate: '2024-10-24',
      KindAttention: 'Brandt, William D',
      PurchaseOrderNo: null,
      PurchaseOrderDate: '2024-11-15',
      Project: null,
      Title: 'sc4c05777',
      Author: null,
      ISBNNo: null,
      ProjectNo: null,
      Currency: 'USD',
      GreatPlainsProject: null,
      EditorialPages: null,
      //   VolIssue: null,
      Vol_Issue: null,
      VolNo: '',
      IssueNo: '',
      AnalyticalCode: null,
      CountryOfRegion: 'United State',
      IsArticle: 'yes',
      IsFinal: 'yes',
      DespatchDate: null,
      InActive: 'no',
      //   PrevBilledPages: null,
      JobData: [
        {
          JobCode: 'sc4c05777',
          ManuscriptNumber: '-',
          Stage: 'Copy Editing',
          CopyEditingService: 'yes',
          CopyEditingLevel: 'Level1',
          Complexity: 'Complex',
          ServiceDetails: [],
        },
      ],
    },
  ],
};

export const remapToInvoiceQueueDetails = (
  input,
  invoiceQueueDetailRows,
  serviceDetailRows,
  invoiceQueueDetailsTemplate = InvoiceQueueDetailsTemplate,
) => {
  const { createdBy: profileId } = input;
  const result = [];
  const RFIDetailsTablePayload = [];
  // Iterate through each entry in invoiceQueueDetailRows (Journal data)
  invoiceQueueDetailRows.forEach(journal => {
    const {
      itemcode,
      workorderid,
      journalacronym,
      journalname,
      countrycode,
      countryname,
      customername,
      verticalname,
      jobcreatedon,
      currencycode,
      celvelname,
      kindattention,
      customerdespatchdate,
    } = journal;

    const { BillableGraphicCount, TechEditPageCount, ManuscriptNumber } =
      input.data.filter(a => a.ManuscriptNumber == itemcode)[0];
    //  input.data[index];

    // console.log(`rate: graphic: ${graphic_cost}, copyEditing: ${tech_edit_cost}`);

    // Find matching services from serviceDetailRows based on workorderid and itemcode
    const serviceDetails = serviceDetailRows.filter(
      service =>
        service.workorderid === workorderid && service.itemcode === itemcode,
    );
    if (serviceDetails.length > 0) {
      // Clone the template to avoid modifying the original template
      const invoiceDetails = JSON.parse(
        JSON.stringify(invoiceQueueDetailsTemplate),
      );
      // Fill in InvoiceQueueDetails based on invoiceQueueDetailRows (journal) data
      invoiceDetails.InvoiceQueueDetails[0].Customer = customername;

      invoiceDetails.InvoiceQueueDetails[0].Vertical = verticalname;
      invoiceDetails.InvoiceQueueDetails[0].JournalShortName = journalacronym;
      invoiceDetails.InvoiceQueueDetails[0].JournalCode = journalacronym;
      invoiceDetails.InvoiceQueueDetails[0].JournalName = journalname;
      invoiceDetails.InvoiceQueueDetails[0].Country = countrycode;
      invoiceDetails.InvoiceQueueDetails[0].CountryOfRegion = countryname;
      invoiceDetails.InvoiceQueueDetails[0].JobReceivedDate = jobcreatedon;
      invoiceDetails.InvoiceQueueDetails[0].Currency = currencycode;
      invoiceDetails.InvoiceQueueDetails[0].KindAttention = kindattention;
      invoiceDetails.InvoiceQueueDetails[0].ManuscriptNumber = ManuscriptNumber;

      invoiceDetails.InvoiceQueueDetails[0].DespatchDate = customerdespatchdate;
      invoiceDetails.InvoiceQueueDetails[0].Title = itemcode;

      // Add JobData for the journal
      invoiceDetails.InvoiceQueueDetails[0].JobData[0].JobCode = itemcode;
      // console.log(`${invoiceDetails.InvoiceQueueDetails[0].JobData[0].JobCode} = ${itemcode} `);
      invoiceDetails.InvoiceQueueDetails[0].JobData[0].CopyEditingLevel =
        celvelname;

      const serviceDetailsForJournal = serviceDetails.map(service => {
        return {
          Service: service.servicename,
          Category: service.category || 'No Category', // default if category is not present
          Description: service.invoicedescription || 'No Description', // default if invoicedescription is not present
          ItemNumber: null,
          BillableDU: service.billableduname,
          ItemCode:
            service.servicename === 'Copy Editing' ? '771013' : '771014',
          SACCode: null,
          GeneralLedgerAccount: null,
          LineItemNo: null,
          Uom: service.uom,
          Rate: service.value,
          // Rate:
          //   service.servicename === 'Copy Editing'
          //     ? tech_edit_cost
          //     : graphic_cost, // If graphics processing or graphis included then use graphic_cost else tech_edit_cost
          NoOfUnits:
            service.servicename === 'Copy Editing'
              ? TechEditPageCount
              : BillableGraphicCount, // If graphics processing or graphis included then use BillableGraphicCount else TechEditPageCount
          AcceptedManuscriptDelivery: null,
          UploadDate: null,
          Remarks: null,
          ArticleType: null,
          DOINumber: null,
          CurrentState: null,
          WBSEntity: null,
          PrevBilledPages: null,
        };
      });
      // Add the service details to the JobData section
      invoiceDetails.InvoiceQueueDetails[0].JobData[0].ServiceDetails =
        serviceDetailsForJournal;
      // Push the populated invoice details into the result array
      result.push(invoiceDetails);

      //  Populate the inputs for the Insert / update of RFIDetails table
      RFIDetailsTablePayload.push({
        workorderid,
        rfistatusid: RFIStatusID('INP'),
        created_by: profileId,
        created_time: new Date(),
        approved_by: profileId,
        approved_time: new Date(),
        itemcode,
        auto_payload: result[result.length - 1],
      });
    }
    // need to confirm the itemcode and the payload has the same
  });
  return { result, RFIDetailsTablePayload };
};

export const updatePayloadWithRFid = (RFIidsAndStatuses, payload) => {
  RFIidsAndStatuses.forEach((RFIidAndStatus, index) => {
    if (payload[index].InvoiceQueueDetails[0].RFIid === '-') {
      payload[index].InvoiceQueueDetails[0].RFIid = RFIidAndStatus.rfiid;
    }
  });
};

export const udpateRFIDetailsForInvoiceQueue = async RFIDetailsTablePayload => {
  try {
    const result = await query(
      updateRFIDetailsTableScript(RFIDetailsTablePayload, RFIStatusID('INVC')),
    );
    console.log(result);
  } catch (error) {
    throw new Error(`RFI Details updation error: ${error.message}`);
  }
};

export const updateRFIDetailsTransaction = async RFIDetailsTablePayload => {
  try {
    return await transactionWithResult(async client => {
      return client.query(
        updateRFIDetailsTableScript(
          RFIDetailsTablePayload,
          RFIStatusID('INVC'),
        ),
      );
    });
  } catch (error) {
    throw new Error(`RFI Details updation error: ${error.message}`);
  }
};

// const sendAutoPayloadToODOOService = async payload => {
//   try {
//     const response = await odooApiIntegrationService(
//       odooEndPoints.api.invoiceInsert,
//       payload,
//     );
//     return {
//       RFIid: payload.InvoiceQueueDetails[0].RFIid,
//       itemCode: payload.InvoiceQueueDetails[0].JobData[0].JobCode,
//       response,
//     };
//   } catch (error) {
//     return {
//       RFIid: payload.InvoiceQueueDetails[0].RFIid,
//       itemCode: payload.InvoiceQueueDetails[0].JobData[0].JobCode,
//       error,
//     };
//   }
// };
export const sendAutoPayloadToODOOService = async payload => {
  let message = '';
  let issuccess = false;
  let odooresult = null;
  let logid;
  try {
    // Insert log for the Odoo invoice
    logid = await insertOdooInvoiceLogService(
      payload.InvoiceQueueDetails[0].RFIid,
      JSON.stringify(payload),
    );

    // Send request to Odoo API
    const response = await odooApiIntegrationService(
      odooEndPoints.api.invoiceInsert,
      payload,
    );

    // Prepare the response object to return
    odooresult = response;
    message = response.message || 'Success';
    issuccess = true;

    // Return the relevant data
    return {
      RFIid: payload.InvoiceQueueDetails[0].RFIid,
      itemCode: payload.InvoiceQueueDetails[0].JobData[0].JobCode,
      response,
    };
  } catch (error) {
    // Error handling with improved logging
    console.error('Error in sendAutoPayloadToODOOService:', error);
    message = error.message || 'Error during Odoo API call';
    odooresult = error;

    // Return error details
    return {
      RFIid: payload.InvoiceQueueDetails[0].RFIid,
      itemCode: payload.InvoiceQueueDetails[0].JobData[0].JobCode,
      error,
    };
  } finally {
    // Update the log after the process
    try {
      if (logid) {
        await updateOdooInvoiceLogService(
          logid,
          safeStringify(odooresult),
          message,
          issuccess,
        );
      }
    } catch (logError) {
      console.error('Log update failed:', logError);
      message += ` | Log update error: ${logError.message}`;
    }
  }
};

export const startAutoPayloadsODOOService = async (profileId, payloads) => {
  const ODOOResult = {
    orders: [],
  };
  const isSendingToODOO = true; // for testing purpose, will remove after issues are resolved
  if (isSendingToODOO) {
    // Set your rate limit (e.g., 200 requests per minute)
    const rateLimitPerMinute = 200;
    const delayBetweenCalls = 60000 / rateLimitPerMinute; // Delay between each call in milliseconds

    // Array to store results of all successful API calls
    for (let i = 0; i < payloads.length; i++) {
      const payload = payloads[i];
      // const { workorderid, itemcode } = payload;
      const { auto_payload, workorderid, itemcode } = payload;
      // console.log(auto_payload);
      // const result = {
      //   error: false,
      // };
      const result = await sendAutoPayloadToODOOService(auto_payload);
      // console.log(result);
      // This is the part where the communication with the front end happens... which is currently a question mark
      // emitEventByProfileId(profileId, "AutoInvoiceQueue", result);

      // Handle success, failure consitions here. use codes INVC and OF respectively.
      if (result.error) {
        // console.error(result.error);
        // console.log(result.error.status);
        payload.rfistatusid = RFIStatusID('OF');
        ODOOResult.orders.push({
          workorderid,
          itemcode,
          status: 'failed',
          reason: result.error.message,
        });
      } else {
        console.log(`${workorderid} no issues`);
        payload.rfistatusid = RFIStatusID('INP');
        ODOOResult.orders.push({
          workorderid,
          itemcode,
          status: 'success',
        });
      }
      // Add delay between API calls to respect the rate limit
      if (i < payloads.length - 1) {
        // Wait for the delay time before making the next API call
        await new Promise(resolve => {
          setTimeout(resolve, delayBetweenCalls);
        });
      }
    }
    // console.log('finalized results');
    // console.log(ODOOResult);
    await updateRFIDetailsTransaction(payloads);
  } else {
    await updateRFIDetailsTransaction(payloads);
    return payloads;
  }

  return ODOOResult;
};
