export const getServiceMst = () => {
  const script =
    'SELECT servicename FROM public.wms_mst_service WHERE isactive = true;';
  return script;
};

export const insFileBasicDetails = () => {
  const script = `INSERT INTO salespmo.customer_price_grid (filename, version, effectivefromdate, effectivetodate, 
    isactive, created_by, created_time) VALUES ($1,
    COALESCE((SELECT MAX(version) FROM salespmo.customer_price_grid), 0) + 1, $2,
    (SELECT (effectivefromdate - INTERVAL '1 day')::DATE FROM salespmo.customer_price_grid ORDER BY version DESC LIMIT 1),
    $3,$4,CURRENT_TIMESTAMP)
    RETURNING fileid;`;
  return script;
};

export const insFileItemDetails = (inputArray, fileId) => {
  const script = `WITH input_data AS (
  SELECT 
    *,
    row_number() OVER () AS input_order -- Add an order column based on the input array's order
  FROM jsonb_to_recordset('${JSON.stringify(inputArray)}') AS t(
    index_number TEXT,
    business_group TEXT,
    service_item_number TEXT,
    service_category TEXT,
    item_description TEXT,
    complexity TEXT,
    item_type TEXT,
    service_type TEXT,
    unit TEXT,
    l1_item_description TEXT,
    l2_item_description TEXT,
    unit_type TEXT
  )
),
inserted_rows AS (
  INSERT INTO salespmo.customer_price_grid_details (fileid, index_number, business_group, 
    service_item_number, service_category, item_description, complexity, item_type, service_type, unit,  
    l1_item_description, l2_item_description, unit_type, serviceid)
  SELECT 
    ${fileId},
    input_data.index_number,
    input_data.business_group,
    input_data.service_item_number,
    input_data.service_category,
    input_data.item_description,
    input_data.complexity,
    input_data.item_type,
    input_data.service_type,
    input_data.unit,
    input_data.l1_item_description,
    input_data.l2_item_description,
    input_data.unit_type,
    (SELECT serviceid FROM public.wms_mst_service WHERE servicename ILIKE 
        '%' || input_data.service_category || '%' AND isactive = true LIMIT 1)
  FROM input_data
  RETURNING *
  )
  SELECT * FROM inserted_rows;  -- Final select to return inserted rows`;
  return script;
};

export const getFileBasicDetails = () => {
  const script = `SELECT pg.fileid, pg.filename, pg.created_time AS uploadedon, 
    u.username || ' (' || pg.created_by || ')'  AS uploadedby, CONCAT('Version ', pg.version) AS version, 
    pg.effectivefromdate AS effectivefrom, pg.effectivetodate AS effectiveto, 'action' AS action 
    FROM salespmo.customer_price_grid pg
	  LEFT JOIN public.wms_user u ON u.userid = pg.created_by AND u.useractive = true
    --WHERE ($1 = '' OR filename ILIKE '%' || $1 || '%' OR version::TEXT = $1) AND isactive = true ORDER BY 1 DESC
    WHERE ($1 = '' OR filename ILIKE '%' || $1 || '%' pg.version = CAST(SUBSTRING($1 FROM '\d+') AS INT)) AND isactive = true ORDER BY 1 DESC;`;
  return script;
};

export const getLatestVersion = () => {
  const script = `SELECT COALESCE(MAX(version), 0) AS version FROM salespmo.customer_price_grid WHERE isactive = true;`;
  return script;
};

export const getFileLineItemDetails = () => {
  const script = `SELECT fd.* FROM salespmo.customer_price_grid_details fd 
    JOIN salespmo.customer_price_grid pg ON pg.fileid =  fd.fileid AND pg.filename = $2 AND pg.isactive = true
    WHERE fd.fileid = $1 AND 
    ($3 = '' OR fd.index_number ILIKE '%' || $3 || '%' OR fd.service_category ILIKE '%' || $3 || '%');`;
  return script;
};
