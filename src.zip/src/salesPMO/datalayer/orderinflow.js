export const insertOrdInflowScript = () => {
  const script = `
    WITH 
     inserted_ord_inflow AS (
      INSERT INTO salespmo.trn_ord_inflow_report(
        workorderid,
        bookcode,                
        baseduid,
        baseduname,
        customerid,
        customername,
        divisionid,
        divisionname,
        countryid,
        countryname,
        verticalid,
        verticalname,        
        segmentid,
        segmentname,
        currencyid,
        currencyname, 
        jobcreatedon,         
        flowtype, 
        isactive,
        created_by
      )
      VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, 
        $15,$16,$17, $18, true, $19)
      RETURNING ord_inflowid
    )
    INSERT INTO salespmo.trn_ord_inflow_stagewise_report(
      ord_inflowid,
      serviceid,
      servicename,
      stageid,
      stagename,
      uomid,
      uom,
      uomqty,
      rate,
      actualinflowvalue,
      transferremarks,
      isactive,
      created_by,
      ordermonth,
      category,
      inflowtype,
      billableduid
    )
    VALUES (
      (SELECT ord_inflowid FROM inserted_ord_inflow),
      $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, true, $19, current_timestamp, $30, $31,$32)
    RETURNING 'INSERTED RECORD ' ||inflow_stageid AS result;
    `;
  return script;
};

export const insertOrdInflowstageScript = () => {
  const script = `
    INSERT INTO salespmo.trn_ord_inflow_stagewise_report(
      ord_inflowid,
      serviceid,
      servicename,
      stageid,
      stagename,
      uomid,
      uom,
      uomqty,
      rate,
      actualinflowvalue,
      transferremarks,
      created_by,
      ordermonth,
      category,
      inflowtype,
      billableduid,
      billableduname,
      adjqty
    )
    VALUES (
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12,current_timestamp,$13, $14, $15, $16, $17)
    RETURNING 'INSERTED STAGE RECORD ' ||inflow_stageid AS result;
  `;
  return script;
};

export const updateOrdInflowScript = () => {
  const script = `
    UPDATE salespmo.trn_ord_inflow_stagewise_report 
    SET 
      uomqty = $2,
      rate = $3,
      actualinflowvalue = $4,
      transferremarks = $5,
      updated_by = $6,
      adjqty = $7,
      updated_time = current_timestamp
    WHERE inflow_stageid = $1
    RETURNING 'UPDATED RECORD ' || inflow_stageid AS result
  `;
  return script;
};
