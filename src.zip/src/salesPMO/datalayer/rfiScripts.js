// lockjob
export const getRFITableScript = param => {
  const script = `;with rfidata as (select
   row_number() over(
   order by ww.itemcode) as "serial",
   md.duname,
   md.duid,
   mc.customername,ww.workorderid,ww.itemcode,
   ww.journalid,
   case 
    WHEN trfi.isfullinvoice IS NULL THEN '-'      
    WHEN trfi.isfullinvoice = false THEN 'Partial'
    ELSE 'Full' 
   end as invoicetype,
   wms.stagename,
   wms.stageid,
   pmj.journalname,
   pmj.journalacronym,
   coalesce(mrs.status,'RFI-YET TO START') as status,
   mrs.rfistatusid as statusid,
   coalesce( mrs.statuscode,'YTS') as statuscode,
   coalesce( mrs.statusclass,'spmo_pending') as statusclass,
   wmv.verticalname as vertical,
   wmv.verticalid,
   trfi.invoiceid,
   trfi,isfullinvoice,
   trfi.rejected_reason,
      CASE 
    WHEN trfi.rejected_by = 'ODOO' THEN 'ODOO'
    ELSE (select username || ' ' || '(' || userid || ')' as username 
          from public.wms_user 
          where userid = trfi.rejected_by and useractive = true)
    END as rejected_by,
   to_char(trfi.rejected_time + interval '330 minutes','dd/mm/yyyy') as rejected_on,
   to_char(trfi.created_time + interval '330 minutes','dd/mm/yyyy') as createdat,
   'uom' as uom,
   'dispatchdate' as dispatchdate,    
   mc.customerid as customerid,
  (select username || ' ' || '(' || userid || ')' as username from public.wms_user where userid  = trfi.created_by and useractive = true) as createdby,
   'action' as action,
COUNT(*) FILTER (WHERE coalesce( mrs.statuscode,'YTS') in ('YTS','PEND','INP')) OVER () AS total_inp,
	COUNT(*) FILTER (WHERE coalesce( mrs.statuscode,'YTS') = 'REJ') OVER () AS total_rej,	
    COUNT(*) FILTER (WHERE coalesce( mrs.statuscode,'YTS') in ('COMP','INC')) OVER () AS total_comp
  from wms_workorder ww
  join salespmo.trn_rfi_jobs trj on   trj.workorderid = ww.workorderid
  join org_mst_customer omc on omc.customerid = ww.customerid
  left join mst_customer mc on mc.customerid = omc.itrack_customerid
  join wms_mst_stage wms on wms.stageid = trj.stageid
  left join pp_mst_journal pmj on pmj.journalid = ww.journalid
  left join salespmo.trn_rfidetails trfi on trfi.workorderid  = ww.workorderid
  left join salespmo.mst_rfistatus mrs on mrs.rfistatusid  = trfi.rfistatusid
  join public.org_mst_subdivision oms on oms.subdivisionid = ww.subdivisionid
  join  wms_mst_vertical wmv on wmv.verticalname ilike oms.subdivision
  join org_mst_customer_orgmap omco on omco.customerid = ww.customerid
        and omco.divisionid = ww.divisionid
        and omco.subdivisionid = ww.subdivisionid
        and omco.countryid = ww.countryid
        and omco.isactive = 1
  join org_mst_customerorg_du_map as cdu on cdu.custorgmapid  = omco.custorgmapid
  join public.org_mst_deliveryunit omd on omd.duid = cdu.duid
  join public.mst_deliveryunit md on md.duid  = omd.itrackduid
  where ww.isactive = true and coalesce(ww.islock,false) = false
  and cdu.duid::integer = any((select ARRAY_APPEND(COALESCE(mappedduid, ARRAY[]::INTEGER[]),duid )
  from wms_user wu where userid = $4)::integer[])
  )
  select ${param}, journalid, duid, invoiceid,createdat,createdby,isfullinvoice, rejected_reason,
  rejected_by, rejected_on, journalacronym,
  customerid,stageid,statusid,statusclass,statuscode,verticalid,
  total_inp,total_rej,total_comp
  from rfidata
  where
  (workorderid::text ilike '%' || COALESCE($1, '') || '%' OR
  itemcode ilike '%' || COALESCE($1, '') || '%' OR
  stagename ilike '%' || COALESCE($1, '') || '%' )
  and statuscode = any($5)
  and coalesce(customerid, 0) =  COALESCE($2, coalesce(customerid, 0))
  AND coalesce(statusid, 0) =  COALESCE($3, coalesce(statusid, 0));`;
  return script;
};

export const getJobDetailsByWorkorderIdScript = () => {
  const script = `SELECT  
    wo.workorderid,
    TO_CHAR(wo.createdon, 'YYYY-MM-DD') AS jobreceivedate,
    wo.itemcode,
    wo.itemcode as articleid,
    wo.journalid,
    wo.title,
    wo.volumenumber,
    wo.issuenumber,
    mdu.duname,
    itc.customername,
    itc.customername as nameofcustomer,
    div.division,
    tkam.kamempcode,
    tkam.cmempcode,
    mj.jobtype,
    mj.jobtypeid,
    pmj.journalname,
    pmj.journalacronym,
    pmj.journalacronym as journal,
    ver.verticalname,
    COALESCE(wwc.contactname, '') AS author,  -- Return '' if no author
     CASE 
        WHEN u_cm.username IS NOT NULL AND u_cm.userid IS NOT NULL 
        THEN CONCAT(u_cm.username, ' (', u_cm.userid, ')') 
        ELSE '-' 
    END AS cmuser,
    CASE 
        WHEN u_kam.username IS NOT NULL AND u_kam.userid IS NOT NULL 
        THEN CONCAT(u_kam.username, ' (', u_kam.userid, ')') 
        ELSE '-' 
    END AS kamuser,
    div.divisionid,
    itc.customerid,
    wo.countryid,
    gmc.ist_code,
    gmc.countryname as destination,
    ver.verticalid,
    mdu.duid,
    (mj.jobtype = 'Article') AS isarticle,    
    To_char(coalesce(wws.enddatetime,wws.customerdespatchdate ) , 'YYYY-MM-DD') as despatchdate,
    null as prevbilledpages
FROM wms_workorder wo
JOIN public.org_mst_customer omc ON omc.customerid = wo.customerid
JOIN public.mst_customer itc ON itc.customerid = omc.itrack_customerid
JOIN public.org_mst_subdivision oms ON oms.subdivisionid = wo.subdivisionid
JOIN public.wms_mst_vertical ver ON ver.verticaldescription = oms.verticalcode
JOIN public.geo_mst_country gmc ON gmc.countryid = wo.countryid 
JOIN public.org_mst_customer_orgmap corg ON corg.customerid = wo.customerid 
    AND corg.divisionid = wo.divisionid 
    AND corg.subdivisionid = wo.subdivisionid 
    AND corg.countryid = wo.countryid
    AND corg.isactive = 1
LEFT JOIN public.pp_mst_journal pmj ON pmj.journalid = wo.journalid 
LEFT JOIN public.wms_workorder_contacts wwc ON wwc.workorderid = wo.workorderid  AND wwc.contactrole = 'AUTHOR'
LEFT JOIN public.org_mst_customerorg_du_map cdu ON cdu.custorgmapid = corg.custorgmapid
LEFT JOIN public.org_mst_deliveryunit odu ON odu.duid = cdu.duid
LEFT JOIN public.mst_deliveryunit mdu ON mdu.duid = odu.itrackduid
LEFT JOIN org_mst_division div ON div.divisionid = wo.divisionid AND div.isactive = true
LEFT JOIN public.mst_jobtype mj ON mj.jobtypeid = CAST(wo.jobtype AS BIGINT) 
LEFT JOIN salespmo.trn_kamcustomerrel tkam ON tkam.duid = mdu.duid 
    AND tkam.customerid = itc.customerid 
    AND tkam.countryid = wo.countryid 
    AND tkam.divisionid = div.divisionid 
    AND tkam.verticalid = ver.verticalid 
    AND tkam.isactive = true
LEFT JOIN public.wms_user u_cm ON u_cm.userid = tkam.cmempcode AND u_cm.useractive = true
LEFT JOIN public.wms_user u_kam ON u_kam.userid = tkam.kamempcode AND u_kam.useractive = true
left join public.wms_workorder_stage wws on  wws.workorderid = wo.workorderid and wws.wfstageid = $2 
WHERE wo.workorderid = $1 
ORDER BY wo.workorderid;`;
  return script;
};
export const insertRFIScript = () => {
  const script = `INSERT INTO salespmo.trn_rfidetails(workorderid,invoicedetails,pricedetails,
isfullinvoice,remarks,uploadedfiles,rfistatusid,created_by, jobdetails, created_time, itemcode)
values ($1,$2,$3,$4,$5,$6,$7,$8,$9, CURRENT_TIMESTAMP, $10) returning invoiceid`;
  return script;
};

export const updateRFIScript = () => {
  const script = `
		update salespmo.trn_rfidetails set
		invoicedetails = $1
		,pricedetails = $2
		,isfullinvoice = $3
		,remarks = $4 
		,uploadedfiles = $5
		,rfistatusid = $6
		,updated_by = $7
		,updated_time = current_timestamp
		where invoiceid = $8 returning invoiceid`;
  return script;
};

export const getRFIStatusScript = () => {
  const script = `select * from salespmo.mst_rfistatus where isactive  = true and  statuscode  = $1`;
  return script;
};
export const getRFIInvoiceDataScript = () => {
  const script = `SELECT mr.statuscode, tr.invoiceid, tr.workorderid, tr.invoicedetails, tr.pricedetails, tr.jobdetails,
    tr.itemcode, tr.created_by, u.username, u.useremail
    FROM salespmo.trn_rfidetails tr
    JOIN salespmo.mst_rfistatus mr ON mr.rfistatusid = tr.rfistatusid
    LEFT JOIN public.wms_user u ON u.userid = tr.created_by
    WHERE tr.invoiceid = $1
    AND mr.statuscode = any($2);`;
  return script;
};

export const getRFIFieldScript = () => {
  const script = `
  select
	invmapid,
	fields,
from
	salespmo.invoice_fieldmapping
where
	is_active = true
	and duid = $1
	and customerid = $2
	and verticalid = $3;`;
  return script;
};
export const getInvoiceDescScript = () => {
  const script = `select
	invconfigid,
	invoicedescription
from
	salespmo.invoice_config
where
	is_active = true
	and duid = $1
	and customerid = $2
	and verticalid = $3
	and serviceid = $4
	and category = $5;
  `;
  return script;
};

export const getJournalRateEntryForRFIScript = () => {
  const script = `select ic.invoicedescription,
   tjr.journalrateid, tjr.category, tjr.uomid, tjr.currencyid, tjr.value as rate, tjr.code, tjr.billableduid,
   wms.servicename as service, sum(wws.typesetpages) as units, wmu.uom , md.duname as billabledu,
   cmst.currency_symbol as currencysymbol,cmst.currencycode, cmst.currencycode as currency
 from public.wms_workorder ww 
 join salespmo.trn_journal_rate tjr on tjr.journalid = ww.journalid 
 join public.wms_mst_service wms on wms.serviceid = tjr.serviceid 
 join public.mst_currencymst cmst on cmst.currencyid = tjr.currencyid 
 join public.wms_mst_uom wmu on wmu.uomid  = tjr.uomid 
 join public.org_mst_customer_orgmap omco on omco.customerid = ww.customerid and 
 omco.divisionid = ww.divisionid  and omco.subdivisionid = ww.subdivisionid and omco.countryid = ww.countryid 
 join public.org_mst_customerorg_du_map omcdm on omcdm.custorgmapid = omco.custorgmapid 
 join public.org_mst_deliveryunit omd on omd.duid = omcdm.duid
 join public.org_mst_customer omc on omc.customerid = ww.customerid 
 join public.mst_deliveryunit md on md.duid =  tjr.billableduid
 left join salespmo.invoice_quantity_stage iqs on iqs.customerid = omc.itrack_customerid
 and iqs.serviceid = wms.serviceid and iqs.duid = omd.itrackduid and iqs.isactive = true
 left join public.wms_workorder_stage wws on wws.serviceid = iqs.serviceid and wws.wfstageid = iqs.stageid 
 left join salespmo.invoice_config ic on ic.duid = omd.itrackduid 
 and ic.customerid = omc.itrack_customerid  
 and ic.serviceid = tjr.serviceid 
 and ic.category = tjr.category 
 and ic.is_active = true
 where tjr.isactive = true and ww.workorderid = $1
 group by 
 ic.invoicedescription,
 tjr.journalrateid, tjr.category, tjr.uomid, tjr.currencyid, tjr.value, tjr.code, tjr.billableduid,
 wms.servicename, wmu.uom , md.duname, cmst.currency_symbol,cmst.currencycode`;
  return script;
};

export const getWORateEntryForRFIScript = () => {
  const script = `select ic.invoicedescription,
   tjr.jobrateid, tjr.category, tjr.uomid, tjr.currencyid, tjr.value as rate, tjr.code, tjr.billableduid,
   wms.servicename as service, wmu.uom , md.duname as billabledu, cmst.currency_symbol as currencysymbol,cmst.currencycode
 from public.wms_workorder ww 
 join salespmo.trn_job_rate tjr on tjr.workorderid = ww.workorderid 
 join public.wms_mst_service wms on wms.serviceid = tjr.serviceid 
 join public.mst_currencymst cmst on cmst.currencyid = tjr.currencyid 
 join public.wms_mst_uom wmu on wmu.uomid  = tjr.uomid 
 join public.org_mst_customer_orgmap omco on omco.customerid = ww.customerid and 
 omco.divisionid = ww.divisionid  and omco.subdivisionid = ww.subdivisionid and omco.countryid = ww.countryid 
 join public.org_mst_customerorg_du_map omcdm on omcdm.custorgmapid = omco.custorgmapid 
 join public.org_mst_deliveryunit omd on omd.duid = omcdm.duid
 join public.org_mst_customer omc on omc.customerid = ww.customerid 
 join public.mst_deliveryunit md on md.duid =  tjr.billableduid
 left join salespmo.invoice_config ic on ic.duid = omd.itrackduid 
 and ic.customerid = omc.itrack_customerid  
 and ic.serviceid = tjr.serviceid 
 and ic.category = tjr.category 
 and ic.is_active = true
 where tjr.isactive = true and ww.workorderid = $1`;
  return script;
};

export const getRFIDetailsScript = () => {
  const script = `SELECT tr.*, 
       json_agg(
           json_build_object(
               'rfi_attachmentid', tra.rfi_attachmentid,
               'rfiid', tra.rfiid,
               'name', tra.filename,
               'size',tra.size,
               'url', tra.url,
               'created_time', tra.created_time,
               'res_id',res_id,
               'attachment_id',attachment_id,
               'odoo_url',odoo_url          
           )
       ) AS attachments
FROM salespmo.trn_rfidetails tr  
LEFT JOIN salespmo.trn_rfi_attachments tra 
    ON tra.rfiid::TEXT = tr.invoiceid::TEXT and tra.isactive = true
WHERE tr.invoiceid = $1
GROUP BY tr.invoiceid;`;
  return script;
};

export const getRFIIssueArticleDetailScript = () => {
  const script = `SELECT 
  distinct ww.workorderid,
  ww.itemcode,
  ww.title,
  ww.journalid,
  pmj.journalname,
  pmj.journalacronym,
  wmc.complexity as complexity,
  pmc.displayname as copyEditingLevel,
  '-' AS pages,
  wms.stagename AS stage,
  CASE WHEN (ws.enddatetime IS NOT null or
ws.customerdespatchdate IS NOT null ) THEN 'yes' ELSE 'no' END AS copyEditingService
FROM 
  wms_workorder ww
  LEFT JOIN wms_workorder_stage ws ON ws.workorderid = ww.workorderid AND ws.wfstageid = 
(SELECT stageid FROM wms_mst_stage WHERE stagename = 'Copy Editing' AND isactive = true)
left join wms_mst_stage wms on wms.stageid = ws.wfstageid
LEFT JOIN 
  pp_mst_journal pmj ON pmj.journalid = ww.journalid
  left join public.wms_mst_complexity wmc on wmc.complexityid = ww.complexityid 
  left join  public.pp_mst_copyeditinglevel pmc on pmc.celevelid = ww.celevelid 
INNER JOIN 
  wms_issue_workorder wiw ON wiw.articleworkorderid = ww.workorderid
WHERE 
  wiw.issueworkorderid = $1;`;
  return script;
};

export const getRFIArticleDetailScript = () => {
  const script = `SELECT
    distinct ww.workorderid,
    ww.itemcode,
    ww.title,
    ww.journalid,
    pmj.journalname,
    pmj.journalacronym,
    wmc.complexity as complexity,
    pmc.displayname as copyEditingLevel,
    '-' AS pages,
    wms.stagename AS stage,
	CASE WHEN (ws.enddatetime IS NOT null or
	ws.customerdespatchdate IS NOT null ) THEN 'yes' ELSE 'no' END AS copyEditingService
FROM
    wms_workorder ww
LEFT JOIN wms_workorder_stage ws ON ws.workorderid = ww.workorderid AND ws.wfstageid = 
(SELECT stageid FROM wms_mst_stage WHERE stagename = 'Copy Editing' AND isactive = true)
left join wms_mst_stage wms on wms.stageid = ws.wfstageid
LEFT JOIN
    pp_mst_journal pmj ON pmj.journalid = ww.journalid
    LEFT JOIN public.wms_mst_complexity wmc ON wmc.complexityid = ww.complexityid
    LEFT JOIN  public.pp_mst_copyeditinglevel pmc ON pmc.celevelid = ww.celevelid
WHERE
    ww.workorderid = $1`;
  return script;
};

export const approveRFIScript = () => {
  const script = `UPDATE salespmo.trn_rfidetails  SET
  rfistatusid=$2,
  updated_by=$3,
  updated_time=current_timestamp,
  approved_by=$3,
  approved_time=current_timestamp
  WHERE invoiceid=$1;`;
  return script;
};
export const rejectRFIScript = () => {
  const script = `UPDATE salespmo.trn_rfidetails  SET
  rfistatusid=$2,
  updated_by=$3,
  updated_time=current_timestamp,
  rejected_by=$3, 
  rejected_reason=$4,
  rejected_time=current_timestamp
  WHERE invoiceid=$1;`;
  return script;
};
export const updateRFIStatusScript = () => {
  const script = `UPDATE salespmo.trn_rfidetails SET rfistatusid = $2 WHERE invoiceid=$1;`;
  return script;
};
export const insertRFIAttachmentsScript = () => {
  const script = `INSERT INTO salespmo.trn_rfidetails_attachments
(rfi_id, file_name, file_type, file_size, upload_status, is_active)
VALUES($1, $2, $3, $4, false, true);`;
  return script;
};
export const updateRFIAttachmentsScript = () => {
  const script = `UPDATE salespmo.trn_rfidetails SET rfistatusid = $2 WHERE invoiceid=$1;`;
  return script;
};
export const insertRFIAttachmentScript = () => {
  const script = `INSERT INTO salespmo.trn_rfi_attachments
( rfiid, filename, url, isactive, created_by, created_time, size)
VALUES( $1, $2, $3, true, $4, CURRENT_TIMESTAMP, $5);`;
  return script;
};

export const getRFIFilePathScript = () => {
  const script = `SELECT rfi_attachmentid, filename, url FROM salespmo.trn_rfi_attachments WHERE rfiid =$1 and isactive = true;`;
  return script;
};

export const updateDeleteRfiAttachmentScript = () => {
  const script = `WITH updated AS (
    UPDATE salespmo.trn_rfi_attachments
    SET isactive = false, odoo_deleted = true
    WHERE rfi_attachmentid = $1
    RETURNING rfiid
)
SELECT json_agg(
           json_build_object(
               'rfi_attachmentid', tra.rfi_attachmentid,
               'rfiid', tra.rfiid,
               'isactive', tra.isactive,
               'size',tra.size,
               'name', tra.filename,
               'url', tra.url,
               'created_time', tra.created_time
           )
       ) AS attachments
FROM salespmo.trn_rfi_attachments tra
WHERE tra.isactive = true
  AND tra.rfiid = (SELECT rfiid FROM updated LIMIT 1)
  AND tra.rfi_attachmentid != $1 -- Exclude the updated attachment
GROUP BY tra.rfiid;`;
  return script;
};

export const getOdooPayloadScript = () => {
  return `SELECT invoicedetails, pricedetails, jobdetails FROM salespmo.trn_rfidetails WHERE invoiceid=$1;`;
};
export const updateOdooAttachmentDataScript = () => {
  return `UPDATE salespmo.trn_rfi_attachments SET res_id=$3, attachment_id=$4, odoo_url=$5, odoo_sent=true
  WHERE rfiid=$1 and filename=$2;`;
};

export const checkWorkOrderExitsScript = inputArray => {
  const script = `WITH jsondata AS (
  SELECT * FROM jsonb_to_recordset(
  '${JSON.stringify(inputArray)}' 
  ) AS t(
    "level_of_effort" INT,
    "ManuscriptNumber" character varying
  )
),
-- Check if itemcodes exist in wms_workorder
missing_workorder AS (
  SELECT jb."ManuscriptNumber" AS manuscript_number
  FROM jsondata AS jb
  LEFT JOIN wms_workorder wo ON wo.itemcode = jb."ManuscriptNumber"
  WHERE wo.workorderid IS NULL
),
-- Get the jobdata by matching itemcodes from jsondata and wms_workorder
jobdata AS (
  SELECT 
    jo.journalid,
    wo.workorderid,
    wo.itemcode,
    jb."ManuscriptNumber" AS manuscript_number,
    jb."level_of_effort" AS level_of_effort
  FROM wms_workorder AS wo
  JOIN pp_mst_journal jo ON wo.journalid = jo.journalid
  JOIN jsondata AS jb ON jb."ManuscriptNumber" = wo.itemcode
),
ratedata AS (
  SELECT
    tjr.journalid,
    tjr.serviceid,
    tjr.category
  FROM salespmo.trn_journal_rate tjr
)
-- Select missing itemcodes in wms_workorder (if any)
SELECT 
  mw.manuscript_number AS itemcode,
  NULL AS workorderid,
  NULL AS journalid,
  'Missing in Workorder' AS status
FROM missing_workorder mw
UNION ALL
-- Check for missing rate entries for itemcodes in trn_journal_rate
SELECT 
  job.itemcode,
  job.workorderid,
  job.journalid,
  'Missing Rate Entry' AS status
FROM jobdata AS job
LEFT JOIN ratedata AS rd 
  ON rd.journalid = job.journalid
WHERE rd.journalid IS NULL; -- No rate entry for the itemcode
`;
  return script;
};

export const checkIfAnyWOIsCompOrINPScript = inputArray => {
  const script = `SELECT  workorderid, itemcode, mr.status
FROM salespmo.trn_rfidetails AS trd
join salespmo.mst_rfistatus mr on mr.rfistatusid  = trd.rfistatusid 
WHERE EXISTS (
    SELECT 1
    FROM jsonb_array_elements('${JSON.stringify(
      inputArray,
    )}' ::jsonb) AS job_elem
    WHERE job_elem->>'ManuscriptNumber' = trd.itemcode
)
AND trd.rfistatusid IN (
    SELECT rfistatusid
    FROM salespmo.mst_rfistatus
    WHERE statuscode IN ('INP', 'COMP', 'INVC')
);`;
  return script;
};

// ACS AUtomation Payload Script
export const invoiceQueueDetailsScript = inputArray => {
  const script = `
  WITH jsondata AS (
    SELECT * 
    FROM jsonb_to_recordset(
        '${JSON.stringify(inputArray)}' 
    ) AS t(
        "level_of_effort" INT,
        "ManuscriptNumber" CHARACTER VARYING,
        "sequence" INT
    )
),
jobdata AS (
    SELECT 
        jo.journalid,
        jo.journalacronym,
        jo.journalname,
        wo.celevelid,
        wo.itemcode,
        wo.workorderid,
        mc.customerid,
        mc.customername,
        mc.customeralias,
        vert.verticalid,
        vert.verticalname,
        gmc.ist_code AS countrycode,
        TO_CHAR(wo.createdon, 'yyyy-mm-dd') AS jobcreatedon,
        gmc.countryname,
        mdel.duname,
        mdel.duid,
        pmc.displayname AS celvelname,
        jb."sequence"
    FROM wms_workorder AS wo
    JOIN pp_mst_journal jo ON wo.journalid = jo.journalid
    JOIN org_mst_customer omc ON omc.customerid = wo.customerid
    JOIN mst_customer mc ON mc.customerid = omc.itrack_customerid
    JOIN org_mst_customer_orgmap cmp ON cmp.customerid = wo.customerid
        AND cmp.divisionid = wo.divisionid
        AND cmp.subdivisionid = wo.subdivisionid
        AND cmp.countryid = wo.countryid
        AND cmp.isactive = 1
    JOIN org_mst_customerorg_du_map cdmp ON cdmp.custorgmapid = cmp.custorgmapid
    JOIN org_mst_deliveryunit del ON del.duid = cdmp.duid
    JOIN mst_deliveryunit AS mdel ON mdel.duid = del.itrackduid
    JOIN org_mst_subdivision oms ON oms.subdivisionid = wo.subdivisionid
    JOIN wms_mst_vertical vert ON vert.verticalid = oms.itrack_vertical_id
    JOIN geo_mst_country gmc ON gmc.countryid = wo.countryid
    JOIN jsondata AS jb ON jb."ManuscriptNumber" = wo.itemcode
    JOIN public.pp_mst_copyeditinglevel pmc ON pmc.levelofeffort = jb."level_of_effort"
    WHERE wo.isactive = TRUE
    ORDER BY jb."sequence"
),
wostage AS (
    SELECT 
        ws.workorderid,
        stg.stagename,
        ws.status,
        ws.productiondespatchdate,
        ws.customerdespatchdate,
        ws.enddatetime
    FROM wms_workorder_stage AS ws
    JOIN wms_mst_stage AS stg ON stg.stageid = ws.wfstageid
    WHERE ws.workorderid IN (
        SELECT workorderid 
        FROM jobdata
    ) 
    AND ws.wfstageid = 24
),
ratedata AS (
    SELECT 
        MAX(tjr.currencyid) AS currencyid,
        tjr.journalid,
        mc.currencycode,
        mc.currencytext
    FROM salespmo.trn_journal_rate tjr
    JOIN mst_currencymst mc ON mc.currencyid = tjr.currencyid
    WHERE tjr.journalid IN (
        SELECT journalid 
        FROM jobdata
    )
    GROUP BY mc.currencycode, mc.currencytext, tjr.journalid
),
fieldmap AS (
    SELECT 
        fm.customerid,
        fm.verticalid,
        jsonb_path_query(fields::jsonb, '$[*] ? (@.labelname == "Kind Attention")') AS labelename,
        jsonb_path_query(fields::jsonb, '$[*] ? (@.labelname == "Kind Attention")')::jsonb->'default_value' AS value
    FROM salespmo.invoice_fieldmapping fm
    WHERE jsonb_path_exists(fields::jsonb, '$[*] ? (@.labelname == "Kind Attention")')
)
SELECT 
    job.journalid,
    job.journalacronym,
    job.journalname,
    job.celevelid,
    job.customerid,
    job.verticalid,
    job.itemcode,
    job.workorderid,
    job.customername,
    job.customeralias,
    job.verticalname,
    job.countrycode,
    job.jobcreatedon,
    job.countryname,
    job.duname,
    job.duid,
    rt.currencycode,
    rt.currencytext,
    fm.value AS kindattention,
    job.celvelname,
    st.stagename,
    st.productiondespatchdate,
    TO_CHAR(COALESCE (st.customerdespatchdate, st.enddatetime), 'yyyy-mm-dd') AS customerdespatchdate,
    job."sequence"
FROM jobdata AS job
LEFT JOIN wostage AS st ON st.workorderid = job.workorderid
LEFT JOIN ratedata AS rt ON job.journalid = rt.journalid
LEFT JOIN fieldmap AS fm ON fm.customerid = job.customerid AND fm.verticalid = job.verticalid
ORDER BY job."sequence";
    `;
  // console.log(script);
  return script;
};

export const serviceDetailsScript = inputArray => {
  const script = `
  with jsondata as  (
SELECT * FROM jsonb_to_recordset('${JSON.stringify(inputArray)}')
AS t(
    "level_of_effort" INT,
    "ManuscriptNumber" character varying
)
)
 , jobdata AS
(
	SELECT jo.journalid , jo.journalacronym,jo.journalname,wo.celevelid
	,wo.itemcode,wo.workorderid,mc.customerid ,mc.customername ,mc.customeralias ,vert.verticalid
	,vert.verticalname ,gmc.ist_code as countrycode
	,to_char(wo.createdon ,'yyyy-mm-dd') as jobcreatedon
	,gmc.countryname
	,mdel.duname ,mdel.duid
	,pmc.displayname as celvelname
	FROM wms_workorder AS wo
	JOIN pp_mst_journal jo ON wo.journalid = jo.journalid
	JOIN org_mst_customer omc ON omc.customerid = wo.customerid
	JOIN mst_customer mc ON mc.customerid = omc.itrack_customerid
	JOIN org_mst_customer_orgmap cmp ON cmp.customerid = wo.customerid and cmp.divisionid  = wo.divisionid
	AND cmp.subdivisionid = wo.subdivisionid  AND cmp.countryid = wo.countryid and cmp.isactive = 1
	JOIN org_mst_customerorg_du_map cdmp ON cdmp.custorgmapid = cmp.custorgmapid
	join org_mst_deliveryunit del on del.duid = cdmp.duid
	join mst_deliveryunit as mdel on mdel.duid = del.itrackduid
	JOIN org_mst_subdivision oms ON oms.subdivisionid = wo.subdivisionid
	JOIN wms_mst_vertical vert ON vert.verticalid = oms.itrack_vertical_id  
	JOIN geo_mst_country gmc on gmc.countryid = wo.countryid
	JOIN jsondata as jb on jb."ManuscriptNumber" = wo.itemcode
	JOIN public.pp_mst_copyeditinglevel pmc ON pmc.levelofeffort = jb."level_of_effort"
	WHERE  wo.isactive  = true
)
 , ratedata AS ( 
SELECT  
tjr.journalrateid, ser.servicename,tjr.serviceid ,  md.duname AS billableduname,
tjr.category ,
wmu.uom , tjr.journalid ,tjr.value, COALESCE (tjr.code, '') AS code
FROM salespmo.trn_journal_rate tjr    
JOIN wms_mst_service ser ON ser.serviceid = tjr.serviceid AND ser.isactive = true  
JOIN mst_deliveryunit md ON md.duid  = tjr.billableduid 
JOIN wms_mst_uom wmu ON wmu.uomid = tjr.uomid AND wmu.isactive  = 1 
JOIN (SELECT DISTINCT journalid , celvelname FROM jobdata) AS job ON job.journalid = tjr.journalid
AND tjr.category = job.celvelname
UNION 
 SELECT  
tjr.journalrateid, ser.servicename,tjr.serviceid , md.duname AS billableduname,
tjr.category ,
wmu.uom , tjr.journalid ,tjr.value, COALESCE (tjr.code, '') AS code
FROM salespmo.trn_journal_rate tjr    
JOIN wms_mst_service ser ON ser.serviceid = tjr.serviceid AND ser.isactive = true AND ser.serviceid = 6
JOIN mst_deliveryunit md ON md.duid  = tjr.billableduid 
JOIN wms_mst_uom wmu ON wmu.uomid = tjr.uomid AND wmu.isactive  = 1 
WHERE tjr.journalid IN (SELECT DISTINCT journalid  FROM jobdata)
AND tjr.category =  'NA' 
)
SELECT job.workorderid,job.itemcode, job.journalid ,inc.invoicedescription,  
serv.servicename, inc.serviceid,  rd.billableduname
,inc.category,rd.uom ,rd.value, rd.code
FROM jobdata as job
JOIN ratedata as rd on rd.journalid = job.journalid   
and rd.category = CASE WHEN rd.serviceid = 6 THEN 'NA' ELSE job.celvelname  END 
LEFT JOIN salespmo.invoice_config AS inc ON
inc.duid = job.duid
AND inc.customerid = job.customerid
AND inc.verticalid = job.verticalid
AND inc.serviceid = rd.serviceid AND inc.category  = rd.category
AND is_active = true
LEFT JOIN wms_mst_service serv ON serv.serviceid = inc.serviceid AND serv.isactive = true
ORDER BY job.workorderid, rd.serviceid;`;
  return script;
};

export const crossCheckWorkOrderIDsScript = inputArray => {
  const script = `
    WITH jsondata AS (
    SELECT * 
    FROM jsonb_to_recordset('${JSON.stringify(inputArray)}') AS t(
        "workorderid" BIGINT,
        "itemcode" TEXT
    )
),
non_matching_ids AS (
    SELECT t.workorderid, t.itemcode
    FROM jsondata t
    WHERE NOT EXISTS (
        SELECT 1
        FROM salespmo.trn_rfi_jobs trj
        WHERE trj.workorderid = t.workorderid
    )
)
SELECT workorderid, itemcode
FROM non_matching_ids;
  `;

  return script;
};

export const getRFIStatusIdsScript = inputs => {
  const formattedInputs = inputs.map(code => `'${code}'`).join(', ');
  const script = `
    SELECT statuscode, rfistatusid
    FROM salespmo.mst_rfistatus
    WHERE statuscode IN (${formattedInputs});
  `;
  return script;
};

export const updateRFIDetailsTableScript = (inputArray, RFIStatusCode) => {
  // console.log(inputArray);
  const script = `
   WITH input_data AS (
  SELECT 
    *,
    row_number() OVER () AS input_order -- Add an order column based on the input array's order
  FROM jsonb_to_recordset('${JSON.stringify(inputArray)}') AS t(
    workorderid BIGINT,
    rfistatusid INT,
    created_by TEXT,
    created_time TIMESTAMP,
    approved_by TEXT,
    approved_time TIMESTAMP,
    itemcode TEXT,
    auto_payload JSONB
  )
),
conflicting_rows AS (
  SELECT
    trn.workorderid,
    trn.itemcode,
    input_data.input_order -- Preserve the input order for sorting
  FROM salespmo.trn_rfidetails AS trn
  JOIN input_data
    ON trn.workorderid = input_data.workorderid
  WHERE trn.rfistatusid = ${RFIStatusCode}
),
updated_rows AS (
  UPDATE salespmo.trn_rfidetails AS trn
  SET
    isfullinvoice = true,
    rfistatusid = input_data.rfistatusid,
    created_by = input_data.created_by,
    created_time = input_data.created_time,
    approved_by = input_data.approved_by,
    approved_time = input_data.approved_time,
    itemcode = input_data.itemcode,
    is_automatic = true,
    auto_payload = input_data.auto_payload
  FROM input_data
  WHERE trn.workorderid = input_data.workorderid
    AND trn.rfistatusid <> ${RFIStatusCode}
  RETURNING 
    trn.invoiceid AS rfiid, 
    trn.workorderid, 
    trn.itemcode, 
    (SELECT input_order FROM input_data WHERE input_data.workorderid = trn.workorderid) AS input_order, -- Preserve the input order
    'success' AS status
),
inserted_rows AS (
  INSERT INTO salespmo.trn_rfidetails (
    workorderid,
    isfullinvoice,
    rfistatusid,
    created_by,
    created_time,
    approved_by,
    approved_time,
    itemcode,
    is_automatic,
    auto_payload
  )
  SELECT 
    input_data.workorderid,
    true,
    input_data.rfistatusid,
    input_data.created_by,
    input_data.created_time,
    input_data.approved_by,
    input_data.approved_time,
    input_data.itemcode,
    true,
    input_data.auto_payload
  FROM input_data
  WHERE NOT EXISTS (
    SELECT 1
    FROM salespmo.trn_rfidetails AS trn
    WHERE trn.workorderid = input_data.workorderid
  )
  RETURNING 
    invoiceid AS rfiid, 
    workorderid, 
    itemcode, 
    (SELECT input_order FROM input_data WHERE input_data.workorderid = trn_rfidetails.workorderid) AS input_order, -- Preserve the input order
    'success' AS status
)
SELECT rfiid, workorderid, itemcode, 'success' AS status, input_order
FROM updated_rows
UNION ALL
SELECT rfiid, workorderid, itemcode, 'success' AS status, input_order
FROM inserted_rows
UNION ALL
SELECT NULL AS rfiid, workorderid, itemcode, 'failure' AS status, input_order
FROM conflicting_rows
ORDER BY input_order; -- Sort by the original input order

  `;
  return script;
};
