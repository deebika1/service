import { query } from '../../database/postgres.js';

export const getSegment = () => {
  const script = `  select segment_id,segment_name,is_active as isactive from salespmo.mst_segment order by 1 `;
  return script;
};
export const insertSegment = () => {
  const script = `INSERT INTO salespmo.mst_segment (segment_name, is_active,created_by) 
                  VALUES ($1, $2, $3)`;
  return script;
};

export const checkSegment = () => {
  const script = `SELECT
  CASE
      WHEN EXISTS (
          SELECT 1
          FROM salespmo.mst_segment
          WHERE trim(upper(segment_name)) = trim(upper($1))
          and ( segment_id <> $2 or $2  is null)
      )
      THEN true
      ELSE false
  END AS duplicate;`;
  return script;
};
export const checkVertical = () => {
  const script = `SELECT
  CASE
      WHEN EXISTS (
          SELECT 1
          FROM public.wms_mst_vertical
          WHERE trim(upper(verticalname)) = trim(upper($1))
          and ( verticalid <> $2 or $2  is null)
      )
      THEN true
      ELSE false
  END AS duplicate;`;
  return script;
};
export const checkService = () => {
  const script = `SELECT
  CASE
      WHEN EXISTS (
          SELECT 1
          FROM public.wms_mst_service
          WHERE trim(upper(servicename)) = trim(upper($1))
          and ( serviceid <> $2 or $2  is null)
      )
      THEN true
      ELSE false
  END AS duplicate;`;
  return script;
};

export const updateSegment = () => {
  const script = `  update salespmo.mst_segment  set segment_name = $2, is_active = $3,updated_by = $4,updated_at = current_timestamp where  segment_id = $1`;
  return script;
};
export const deleteSegment = async id => {
  const result = await query(
    `DELETE FROM salespmo.mst_segment WHERE segment_id = $1;`,
    [id],
  );
  return result;
};

export const getVertical = () => {
  const script = ` select * from public.wms_mst_vertical order by verticalid`;
  return script;
};

export const insertVertical = () => {
  const script = `INSERT INTO public.wms_mst_vertical (verticalname,verticaldescription, isactive,created_by) 
                  VALUES ($1, $2, $3,$4)`;
  return script;
};
export const updateVertical = () => {
  const script = `  update public.wms_mst_vertical set verticalname = $2, verticaldescription = $3, isactive = $4,updated_by = $5,updated_time = current_timestamp where  verticalid = $1`;
  return script;
};
export const deleteVertical = async id => {
  const result = await query(
    `DELETE FROM public.wms_mst_vertical WHERE verticalid = $1;`,
    [id],
  );
  return result;
};

export const getService = () => {
  const script = `  select serviceid,servicename,servicedesc,isactive from public.wms_mst_service  order by 1 `;
  return script;
};
export const insertService = () => {
  const script = `INSERT INTO  public.wms_mst_service (serviceid,servicename, servicedesc,isactive,created_by) 
                  VALUES ($1, $2, $3,$4,$5)`;
  return script;
};
export const updateService = () => {
  const script = ` update public.wms_mst_service  set servicename = $2, servicedesc = $3,isactive = $4,updated_by = $5,updated_time = current_timestamp where  serviceid = $1`;
  return script;
};
export const deleteService = async id => {
  const result = await query(
    `DELETE FROM public.wms_mst_service WHERE serviceid = $1;`,
    [id],
  );
  return result;
};

export const getUserMappedDuScript = type => {
  let script;
  if (type == 'mappeddu') {
    // script = ` SELECT  duid as column_id, duname as column_name
    // FROM public.mst_deliveryunit md
    // WHERE duid = ANY (
    //     SELECT unnest(itracks_mappedduid)
    //     FROM public.wms_user wu
    //     WHERE userid = $1
    // ) and isactive = true order by duname;`;
    script = ` SELECT 
      md.duid AS column_id, 
      md.duname AS column_name FROM public.mst_deliveryunit md
    WHERE 
    md.duid = ANY (
        SELECT  omd.itrackduid FROM  public.wms_user wu CROSS JOIN 
            unnest(wu.mappedduid) AS mapped_duid
        JOIN 
            public.org_mst_deliveryunit omd 
        ON 
            omd.duid = mapped_duid 
        WHERE 
            wu.userid = $1
    ) 
    AND md.isactive = true 
  ORDER BY 
    md.duname;`;
  } else if (type == 'basedu') {
    // script = `SELECT  duid as column_id, duname as column_name
    // FROM public.mst_deliveryunit md
    // WHERE duid = ANY (
    //     select itracks_duid
    //     FROM public.wms_user wu
    //     WHERE userid = $1
    // ) and isactive = true order by duname;`;
    script = `SELECT 
    md.duid AS column_id, 
    md.duname AS column_name FROM public.mst_deliveryunit md 
    WHERE 
        md.duid = ANY (
            SELECT 
                omd.itrackduid
            FROM 
                public.org_mst_deliveryunit omd
            JOIN 
                public.wms_user wu 
            ON 
                wu.duid = omd.duid
            WHERE 
                wu.userid = $1
        ) 
        AND md.isactive = true 
    ORDER BY 
        md.duname;`;
  }
  return script;
};

export function getMasterDropDownScript(table) {
  let script = '';
  switch (table) {
    case 'DU':
      script =
        'select duid AS column_id, duname AS column_name FROM public.mst_deliveryunit WHERE isactive = true ORDER BY duname';
      break;
    case 'STAGE':
      script =
        'select wms.stageid AS column_id, wms.stagename AS column_name FROM public.wms_mst_stage wms WHERE isactive = true ORDER BY stagename';
      break;
    case 'UOM':
      script =
        'SELECT uomid::bigint AS column_id, uom AS column_name FROM public.wms_mst_uom WHERE isactive = 1 ORDER BY uom;';
      break;
    case 'VERTICAL':
      script = `SELECT verticalid AS column_id, verticalname AS column_name FROM public.wms_mst_vertical 
          WHERE isactive = true`;
      break;
    case 'CURRENCY':
      script = `SELECT currencyid::bigint AS column_id, currencycode AS column_name, currency_symbol as symbol  FROM public.mst_currencymst WHERE isactive = true order by currencycode;`;
      break;
    case 'COUNTRY':
      script = `SELECT countryid::bigint AS column_id, countrycode AS column_name FROM public.geo_mst_country WHERE isactive = true order by countrycode;`;
      break;
    case 'ENTITY':
      script = `SELECT entityid::bigint AS column_id, entityname AS column_name FROM public.mst_entity wme  WHERE isactive = true order by entityname;`;
      break;
    case 'MSTCUSTOMER':
      script =
        'SELECT customerid AS column_id, customername AS column_name FROM public.mst_customer WHERE isactive = true ORDER BY customername;';
      break;
    case 'SEGMENT':
      script =
        'SELECT segment_id AS column_id, segment_name AS column_name FROM salespmo.mst_segment WHERE is_active = true ORDER BY segment_name;';
      break;
    case 'KAM':
      script = `SELECT DISTINCT ON (wu2.username)
      wu2.username || ' (' || wu2.userid || ')' AS column_name,
      wu2.userid AS column_id
  FROM
      public.wms_userrole wu
  JOIN public.wms_role wr ON
      wr.roleid = wu.roleid
  JOIN public.wms_user wu2 ON
      wu2.userid = wu.userid
  WHERE
      wr.rolename = 'Key Account Manager'
      AND wu2.useractive = true
  ORDER BY
      wu2.username;`;
      break;
    case 'CM':
      script = `SELECT DISTINCT ON (wu2.username)
      wu2.username||' ('|| wu2.userid||')' AS column_name,  wu2.userid as column_id
      FROM public.wms_userrole wu
      join public.wms_role wr on wr.roleid =  wu.roleid
      JOIN public.wms_user wu2 ON wu2.userid = wu.userid
      WHERE wr.rolename = 'PMTL' and wu2.useractive = true
      ORDER BY wu2.username;`;
      break;
    case 'SPMOSTATUS':
      script =
        'select distinct status_alias as column_name ,status_alias as column_id  from salespmo.mst_status ms where isactive = true ORDER BY status_alias';
      break;
    case 'REQTYPE':
      script =
        'select reqcode as column_id, reqname as column_name from salespmo.mst_request_type where isactive = true ORDER BY reqname';
      break;
    case 'SPMOSTATUSDD':
      script = `select status_alias as column_name , statuscode as column_id from salespmo.mst_status where isactive = true and status_alias not in ('ACTIVE') ORDER BY status_alias`;
      break;
    case 'EXCHANGERATE':
      script =
        'select exchangerateid AS column_id, exchangerate AS column_name  from public.currency_exchange_rates where isactive = true order by exchangerateid';
      break;
    case 'KAMEMPCODE':
      script = `SELECT DISTINCT ON (wu2.username)
                CONCAT(wu2.username, ' (', wu2.userid, ')') AS column_name,  wu2.userid as column_id
                FROM public.wms_userrole wu
                join public.wms_role wr on wr.roleid =  wu.roleid
                JOIN public.wms_user wu2 ON wu2.userid = wu.userid
                WHERE wr.rolename = 'Key Account Manager' and wu2.useractive = true
                ORDER BY wu2.username;`;
      break;
    case 'CMEMPCODE':
      script = `SELECT DISTINCT ON (wu2.username)
                CONCAT(wu2.username, ' (', wu2.userid, ')') AS column_name,  wu2.userid as column_id
                FROM public.wms_userrole wu
                join public.wms_role wr on wr.roleid =  wu.roleid
                JOIN public.wms_user wu2 ON wu2.userid = wu.userid
                WHERE wr.rolename = 'Client Manager' and wu2.useractive = true
                ORDER BY wu2.username;`;
      break;
    case 'SERVICE':
      script =
        'SELECT serviceid AS column_id, servicename AS column_name FROM public.wms_mst_service WHERE isactive = true ORDER BY servicename;';
      break;

    default:
      throw new Error('Invalid Param');
  }
  return script;
}

export const getRateEntryMapScreenServiceDDScript = () => {
  const script = `
  select ms.servicemapping_id as parentid, ms.serviceid AS column_id, wms.servicename AS column_name from salespmo.mst_servicemapping ms  
  join public.wms_mst_service wms  on  ms.serviceid = wms.serviceid  
  where ms.duid = $1 and ms.customerid = $2 and ms.isactive = true order by wms.servicename`;
  return script;
};

export const getStageDDByserviceMappingScript = () => {
  const script = `
  select ms2.stagemapping_id as parentid, wms.stageid   AS column_id, wms.stagename AS column_name from salespmo.mst_servicemapping ms  
  join salespmo.mst_stagemapping ms2 on ms2.servicemapping_id = $3  and ms2.isactive = true
  join public.wms_mst_stage wms on wms.stageid =  ms2.stageid and wms.isactive = true
  where ms.duid = $1 and ms.customerid = $2 and ms.isactive = true order by wms.stagename`;
  return script;
};

export const getStageDDByserviceMapIdScript = () => {
  const script = `select wms.stageid AS column_id, wms.stagename AS column_name from salespmo.mst_stagemapping ms2 
  join public.wms_mst_stage wms on wms.stageid =  ms2.stageid and wms.isactive = true  where ms2.servicemapping_id = $1  and ms2.isactive = true order by wms.stagename`;
  return script;
};

export const getUserMappedDuByUserIdScript = () => {
  const script = `SELECT 
  md.duid AS column_id, 
  md.duname AS column_name 
  FROM 
  public.mst_deliveryunit md 
  JOIN 
  (
    SELECT DISTINCT omd.itrackduid 
    FROM public.org_mst_deliveryunit omd 
    JOIN 
    (
      SELECT unnest(mappedduid) AS duid 
      FROM public.wms_user 
              WHERE userid = $1
              ) AS user_mapped 
          ON omd.duid = user_mapped.duid
        ) AS distinct_itrackduid 
      ON md.duid = distinct_itrackduid.itrackduid;`;
  return script;
};

export const getDuFromKamCustomerScript = () => {
  const script = `select
	md.duid as column_id,
	md.duname as column_name
  from
	public.mst_deliveryunit md where md.isactive = true and duid in
	(
	select distinct duid from salespmo.trn_kamcustomerrel tk where isactive = true
	)  order by md.duname;`;
  return script;
};

export const getCustomerByDuIdScript = () => {
  const script = `select
	mc.customerid as column_id,
	mc.customername as column_name
  from
	public.mst_customer mc where mc.isactive = true and customerid in (
    select 
		distinct tk.customerid 
    from  salespmo.trn_kamcustomerrel tk where tk.duid = $1
    ) order by mc.customername;`;
  return script;
};

export const getVerticalByDuCustomerIdScript = () => {
  const script = `
    select
    wmv.verticalid as column_id,
    wmv.verticalname as column_name
    from
    public.wms_mst_vertical wmv where wmv.isactive = true and wmv.verticalid in (
      select 
      distinct tk.verticalid
      from  salespmo.trn_kamcustomerrel tk where tk.duid = $1 and tk.customerid = $2
    ) order by wmv.verticalname;`;
  return script;
};

export const getServiceInKamRelScript = () => {
  const script = `select  distinct(wms.serviceid) as column_id, wms.servicename as column_name from salespmo.trn_kamcustomerrel tk
  join public.wms_mst_service wms on wms.serviceid = tk.serviceid where tk.isactive = true and tk.duid  = $1 and tk.customerid = $2 and tk.verticalid = $3
  order by wms.servicename asc`;
  return script;
};
export const getServiceByRateConfigScript = () => {
  const script = `select  distinct(wms.serviceid) as column_id, wms.servicename as column_name from salespmo.rate_entry_config rec
  join public.wms_mst_service wms  on wms.serviceid  = rec.serviceid
  where rec.is_active = true and rec.duid  = $1 and rec.customerid = $2 and rec.verticalid = $3
  order by wms.servicename asc`;
  // const script = `select  distinct(wms.serviceid) as column_id, wms.servicename as column_name from salespmo.trn_kamcustomerrel tk
  // join public.wms_mst_service wms on wms.serviceid = tk.serviceid where tk.isactive = true and tk.duid  = $1 and tk.customerid = $2 and tk.verticalid = $3
  // order by wms.servicename asc`;
  return script;
};
export const getCategoryByRateConfigScript = () => {
  const script = `select rec.serviceid, rec.category  as column_id, rec.category  as column_name from salespmo.rate_entry_config rec 
where rec.is_active = true and rec.duid  = $1 and rec.customerid = $2 and rec.verticalid = $3 
order by rec.category asc`;
  return script;
};
export const getUomByRateConfigScript = () => {
  const script = `select rec.serviceid, rec.category, wmu.uomid  as column_id, wmu.uom  as column_name from salespmo.rate_entry_config rec 
join public.wms_mst_uom wmu  on wmu.uomid = rec.uomid  
where rec.is_active = true and rec.duid  = $1 and rec.customerid = $2 and rec.verticalid = $3 
order by wmu.uom asc`;
  return script;
};

export const getStageByCustFromKAMScript = () => {
  // const script = ` SELECT DISTINCT wms.stageid as column_id, wms.stagename as column_name
  // FROM public.wms_mst_stage wms
  // JOIN public.wms_workflowdefinition ww ON wms.stageid = ww.stageid
  // JOIN public.wms_workflow wwf ON ww.wfid = wwf.wfid
  // join public.org_mst_customer omc on omc.customerid = wwf.customerid
  // WHERE omc.itrack_customerid =  $1 order by wms.stagename asc;`;
  // return script;
  const script = `SELECT DISTINCT 
    stg.stageid as column_id, 
    stg.stagename as column_name 
  FROM wms_config_customertabinfomapping as ctab
  JOIN wms_workflow as wfl 
    ON wfl.wfid = any(ctab.workflowid) AND wfl.isactive = true
  JOIN wms_workflowdefinition as wfd 
    ON wfd.wfid = wfl.wfid 
  JOIN wms_mst_stage as stg 
    ON stg.stageid = wfd.stageid AND stg.isactive = true
  JOIN org_mst_customer as cust 
    ON cust.customerid = ctab.customerid AND cust.isactive = true
  WHERE cust.itrack_customerid = $1 
  union  all 
  SELECT DISTINCT 
    wms.stageid as column_id, 
    wms.stagename as column_name 
  FROM public.wms_mst_stage wms
  where 0 = 
  (select count (1)
  FROM wms_config_customertabinfomapping as ctab
  JOIN wms_workflow as wfl 
    ON wfl.wfid = any(ctab.workflowid) AND wfl.isactive = true
  JOIN wms_workflowdefinition as wfd 
    ON wfd.wfid = wfl.wfid 
  JOIN wms_mst_stage as stg 
    ON stg.stageid = wfd.stageid AND stg.isactive = true
  JOIN org_mst_customer as cust 
    ON cust.customerid = ctab.customerid AND cust.isactive = true
  WHERE cust.itrack_customerid = $1 
  AND ctab.isactive = true) order by column_name asc`;
  return script;
};

export const getCategoryScript = () => {
  const script = `SELECT 
    category AS column_name,
    categorymaster AS column_id
  FROM (
      SELECT 
          complexity AS category, 
          'complexity' AS categorymaster 
      FROM 
          public.wms_mst_complexity 
      WHERE 
          isactive = 1
      UNION ALL
      SELECT 
          displayname AS category, 
          'copyediting' AS categorymaster 
      FROM 
          public.pp_mst_copyeditinglevel
  ) AS res
  ORDER BY 
    category;`;
  return script;
};

export const getInvoiceDescriptionScript = () => {
  const script = `select distinct invoicedescription AS column_id, invoicedescription AS column_name from salespmo.invoice_config `;
  return script;
};
