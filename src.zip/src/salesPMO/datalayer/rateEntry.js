export const getJournalRateEntryScript = () => {
  const script = `
WITH distinct_journals AS (
    SELECT 
	-- DISTINCT ON (j.journalid)
    r.journalrateid,
        j.journalid,
        j.journalacronym,
        m.custorgmapid,
        j.journalname,
        mc.customerid,
        mc.customername,
        d.duid,
        d.duname,
        j.createdon  AS job_created_on,
        r.created_time AS created_on,		 
		r.created_by , r.updated_by,
		usrcre.username as createdbyname,
		usrupd.username as updatedbyname,
        COALESCE(r.updated_time, r.created_time) AS latest_changed_on,	
        m.divisionid,
        md.division AS divisionname,
        m.countryid,
        gmc.countrycode,
        kam.contactname AS kam_contactname,
        cm.contactname AS cm_contactname,
        wmv.verticalid,
        wmv.verticalname,
        CASE WHEN r.created_time IS NOT NULL THEN 'Completed' ELSE 'Pending' END AS status,
        CASE WHEN r.created_time IS NOT NULL THEN 'completed' ELSE 'spmo_pending' END AS statusclass,
        CASE WHEN r.created_time IS NOT NULL THEN '2' ELSE '1' END AS statusid,
        cum.rate_entry_type,
        'action' AS action
    FROM public.pp_mst_journal j
    JOIN public.org_mst_customer_orgmap m ON m.custorgmapid = j.custorgmapid AND m.isactive = 1
    JOIN public.org_mst_customerorg_du_map du ON du.custorgmapid = j.custorgmapid
    JOIN public.org_mst_deliveryunit omd ON omd.duid = du.duid
    LEFT JOIN public.mst_deliveryunit d ON d.duid = omd.itrackduid
    LEFT JOIN public.org_mst_subdivision subd ON subd.subdivisionid = m.subdivisionid AND subd.isactive = true
    JOIN public.org_mst_division md ON m.divisionid = md.divisionid
    JOIN public.geo_mst_country gmc ON gmc.countryid = m.countryid
    JOIN public.org_mst_customer o ON o.customerid = m.customerid
    JOIN public.mst_customer mc ON mc.customerid = o.itrack_customerid
    LEFT JOIN public.wms_mst_vertical wmv ON wmv.verticalname = subd.subdivision
    LEFT JOIN salespmo.trn_journal_rate r ON r.journalid = j.journalid 
	LEFT JOIN wms_user as usrcre ON usrcre.userid =  r.created_by
	LEFT JOIN wms_user as usrupd ON usrupd.userid = r.updated_by
 
    LEFT JOIN (
        SELECT
            contactname,
            custorgmapid,
            MAX(custorgconmapid) AS max_custorgconmapid
        FROM public.org_mst_customerorg_contact
        WHERE contactroleid = 'KAM' AND isprimary = true  
        GROUP BY contactname, custorgmapid
    ) kam ON kam.custorgmapid = m.custorgmapid
    LEFT JOIN (
        SELECT
            contactname,
            custorgmapid,
            MAX(custorgconmapid) AS max_custorgconmapid
        FROM public.org_mst_customerorg_contact
        WHERE contactroleid = 'CM' AND isprimary = true
        GROUP BY contactname, custorgmapid
    ) cm ON cm.custorgmapid = m.custorgmapid
     LEFT JOIN public.wms_config_customertabinfomapping cum ON cum.duid = omd.duid AND cum.customerid = o.customerid
	AND md.divisionid = ANY(cum.divisionid) AND cum.verticalid = m.subdivisionid
	AND m.countryid = ANY(cum.countryid) AND cum.isactive = true
    WHERE
        omd.itrackduid = $1::bigint AND
        mc.customerid = $2::bigint  
    ORDER by j.journalid, r.journalrateid
), res2 as (SELECT  
row_number() over(partition by journalid order by journalrateid  ) as rowno_created,
*
FROM distinct_journals 

UNION
SELECT  
row_number() over(partition by journalid order by journalrateid desc  ) as rowno_updated,
*
FROM distinct_journals 
)  
,res3 as (SELECT   
rowno_created
,"journalid"
,journalrateid
,"job_created_on"
,"created_on" 
,created_by
,updated_by
,createdbyname
,updatedbyname
,LEAD(updatedbyname, 1) OVER (PARTITION BY  journalid ORDER BY journalrateid ) AS lead_updatedbyname
 
,LEAD(updated_by, 1) OVER (PARTITION BY  journalid ORDER BY journalrateid ) AS lead_updated_by 
,"latest_changed_on" 
,LEAD(latest_changed_on, 1) OVER (PARTITION BY  journalid ORDER BY journalrateid ) AS lead_latest_changed_on
,"journalacronym","custorgmapid","journalname","customerid"	
,"customername"	,"duid"	,"duname", 
"divisionid","divisionname","countryid", "countrycode"	,"kam_contactname",
"cm_contactname","verticalid","verticalname","status","statusclass","statusid","rate_entry_type","action" 
FROM res2 WHERE rowno_created = 1)
,res4 AS (
SELECT row_number() over(partition by  journalid order by journalrateid ) as min_jrateid, 
*
,(SELECT username FROM wms_user WHERE userid = COALESCE(res3.lead_updated_by, res3.updated_by, res3.created_by)) as latest_changed_by
FROM res3 
)
 
SELECT * FROM res4 WHERE min_jrateid = 1 
and ($3::text = '' OR res4.journalname ILIKE '%' || $3 || '%' OR res4.journalacronym ILIKE '%' || $3 || '%')
        AND (
            $4::text IS NULL OR $4 = '' OR $5 = '' OR
            ($4 = $5 AND res4.created_on >= $4::date AND res4.created_on < ($4::date + INTERVAL '1 day')) OR
            ($4 <> $5 AND res4.created_on >= $4::date AND res4.created_on < ($5::date + INTERVAL '1 day'))
        )
order by case 
	when latest_changed_on is null 
	then '1990-07-25 08:27:33.170'
	else latest_changed_on
end desc;
  `;
  return script;
};
export const getWorkOrderRateEntryScript = () => {
  const script = `WITH max_updated_time AS (
    SELECT workorderid, MAX(updated_time) as max_updated_time, MIN(jobrateid) as jobrateid 
    FROM salespmo.trn_job_rate  
    GROUP BY workorderid
),
min_created_time AS (
    SELECT workorderid, MIN(created_time) as min_created_time,min(jobrateid) as jobrateid 
    FROM salespmo.trn_job_rate 
    GROUP BY workorderid
)
,res_combine AS (
 
SELECT jrc.jobrateid,jrc.workorderid, jrc.created_by,jrc.created_time ,1 as modeval
FROM 
salespmo.trn_job_rate  as jrc
JOIN min_created_time AS mct ON jrc.workorderid = mct.workorderid and mct.jobrateid = jrc.jobrateid 
  UNION
SELECT
jru.jobrateid,jru.workorderid,jru.updated_by,jru.updated_time,2 as modeval
FROM salespmo.trn_job_rate AS jru
join max_updated_time AS mut ON jru.workorderid = mut.workorderid and mut.jobrateid = jru.jobrateid 
ORDER BY 2,1,4,5
)  
,jobrate_cte as (  
SELECT jobrateid,workorderid,created_by,created_time,modeval,
LEAD(created_by, 1) OVER (PARTITION BY  workorderid ORDER BY modeval ) AS updated_by,
LEAD(created_time, 1) OVER (PARTITION BY  workorderid ORDER BY modeval ) AS updated_time
FROM res_combine ORDER BY 2,1)
, distinct_job AS 
(
  SELECT	 
  ww.workorderid,
  ww.itemcode,
  ww.title,
  md.divisionid,
  md.division as divisionname,
  gmc.countryid,
  gmc.countrycode,
  gmc.countryname,
  ww.createdon + interval '5 hours 30 minutes' as job_created_on,
  mc.customerid,
  mc.customername,
  omd.duid as org_duid,
  d.duid,
  d.duname,
  pmc.celevelid,
  pmc.displayname,
  pmc.celevel,
  kam.contactname AS kam_contactname,
  cm.contactname AS cm_contactname,
  subd.subdivisionid,
  subd.subdivision,
  wmv.verticalid,
  wmv.verticalname,
  r.created_time AS created_on,
  COALESCE(r.updated_time, r.created_time) AS latest_changed_on,
  (SELECT username FROM wms_user WHERE userid = COALESCE(r.updated_by, r.created_by)) AS latest_changed_by,
  CASE WHEN r.created_time is not null then 'Completed' else 'Pending' end as status,
  case when r.created_time is not null then 'completed' else 'spmo_pending' end as statusclass,
  case when r.created_time is not null then '2' else '1' end as statusid,
  CASE WHEN ww.createdon IS NULL THEN ''
        WHEN EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - ww.createdon)) / 3600 > 48 THEN '>48'
        ELSE '<48'
  END AS status_time,
  cum.rate_entry_type,
  'action' as action
FROM public.wms_workorder ww
-- JOIN public.org_mst_customer_orgmap m ON m.divisionid = ww.divisionid
-- 	AND m.subdivisionid = ww.subdivisionid and m.countryid = ww.countryid
-- 	AND ww.customerid = m.customerid AND m.isactive = 1
-- JOIN public.org_mst_customerorg_du_map du ON du.custorgmapid = m.custorgmapid
JOIN public.org_mst_deliveryunit omd ON  ww.duid = omd.duid
LEFT JOIN public.mst_deliveryunit d ON d.duid = omd.itrackduid
LEFT JOIN public.org_mst_subdivision subd ON subd.subdivisionid = ww.subdivisionid and subd.isactive = true
LEFT JOIN public.org_mst_division md on ww.divisionid = md.divisionid
LEFT JOIN public.geo_mst_country gmc on gmc.countryid = ww.countryid
LEFT JOIN public.org_mst_customer o ON o.customerid = ww.customerid
LEFT JOIN public.mst_customer mc ON mc.customerid = o.itrack_customerid
LEFT JOIN public.wms_mst_vertical wmv ON wmv.verticalname = subd.subdivision
LEFT JOIN public.pp_mst_copyeditinglevel pmc on pmc.celevelid = ww.celevelid
LEFT JOIN jobrate_cte as r ON r.workorderid =  ww.workorderid and r.modeval = 1
left join (
select distinct  tk.username  as contactname , kam.kamempcode,kam.duid,kam.customerid ,kam.divisionid, kam.verticalid,kam.countryid
from salespmo.trn_kamcustomerrel kam   
join wms_user tk  on tk.userid  = kam.kamempcode  
) as kam on kam.duid = d.duid and kam.customerid = mc.customerid
and kam.countryid = gmc.countryid and kam.divisionid = md.divisionid and kam.verticalid = wmv.verticalid
-- 
LEFT JOIN (
      SELECT
          wwc2.contactname,
          wwc2.wocontactid,
          wwc2.workorderid,
          MAX(wocontactid) AS max_custorgconmapid
      FROM
          public.wms_workorder_contacts wwc2
      WHERE
          wwc2.contactrole = 'PMTL'
          AND wwc2.isprimary = true
      GROUP BY
         wwc2.contactname,
          wwc2.wocontactid,
          wwc2.workorderid
  ) cm ON cm.workorderid = ww.workorderid
   LEFT JOIN public.wms_config_customertabinfomapping cum ON cum.duid = ww.duid AND cum.customerid = ww.customerid
	AND ww.divisionid = ANY(cum.divisionid) AND cum.verticalid = ww.subdivisionid 
	AND ww.countryid = ANY(cum.countryid) AND cum.isactive = true
WHERE
   omd.itrackduid = $1::bigint AND
   mc.customerid = $2::bigint 
AND ($3::text = '' OR ww.workorderid::text = $3::text  OR ww.title ILIKE '%' || $3 || '%'
	OR ww.itemcode ILIKE '%' || $3 || '%')
  AND (
    ($4::text IS NULL OR $4 = '' OR $5 = '')  OR
    ($4 = $5 AND r.created_time >= $4::date AND r.created_time < ($4::date + INTERVAL '1 day')) OR
    ($4 <> $5 AND r.created_time >= $4::date AND r.created_time < ($5::date + INTERVAL '1 day'))
	)
)
SELECT 
    dj.*
FROM distinct_job dj
ORDER BY case 
	when latest_changed_on is null 
	then '1990-07-25 08:27:33.170'
	else latest_changed_on
end desc`;
  return script;
};

export const getJournalRateStageScript = () => {
  const script = `
SELECT 
j.journalrateid, 
j.journalid ,
    j.currencyid,
    c.currencycode,
    c.currency_symbol,
    j.serviceid,
    j.category, 
    s.servicename,
    j.billableduid,
    d.duid,
    d.duname,
    j.uomid,
    u.uom,
    j.value,
    j.code,
    true as disabled
FROM 
    salespmo.trn_journal_rate j
JOIN 
    public.mst_currencymst c ON c.currencyid = j.currencyid 
JOIN 
    public.wms_mst_service s ON s.serviceid = j.serviceid 
JOIN 
    public.mst_deliveryunit d ON d.duid = j.billableduid 
JOIN 
    public.wms_mst_uom u ON u.uomid = j.uomid
where j.journalid = $1 and j.isactive = true
GROUP by
j.journalrateid, 
j.journalid,
    j.category, 
    j.currencyid,
    c.currencycode,
    c.currency_symbol,
    j.serviceid,
    s.servicename,
    j.billableduid,
    d.duid,
    d.duname,
    j.uomid,
    u.uom,
    j.value; `;
  return script;
};

export const checkForJournalScript = () => {
  const script = `select * from salespmo.trn_journal_rate where 
  journalid = $1  and
  journalacronym = $2 and
  serviceid = $3 and
  category = $4 and
  currencyid = $5 and
  uomid = $6 and
  billableduid = $7 and
  isactive = true
`;
  return script;
};
export const checkForJobRateScript = () => {
  const script = `select * from salespmo.trn_job_rate
  where
  workorderid = $1  and
  bookcode = $2 and
  serviceid = $3 and
  category = $4 and
  currencyid = $5 and
  uomid = $6 and
  billableduid = $7 and
  isactive = true
`;
  return script;
};

export const insertJournalRateScript = () => {
  const script = `
    INSERT INTO salespmo.trn_journal_rate(
      journalid,
      journalacronym,
      serviceid,
      category,
      currencyid,
      uomid,
      value,
      billableduid,
      created_by,
      code
    )
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10);
  `;
  return script;
};

export const updateJournalRateScript = () => {
  const script = `
    UPDATE salespmo.trn_journal_rate
    SET
      journalacronym = $2,
      serviceid = $3,
      category = $4,
      currencyid = $5,
      uomid = $6,
      value = $7,
      billableduid = $8,
      updated_by = $9,
      code = $10,
      updated_time = CURRENT_TIMESTAMP
    WHERE
      journalrateid = $11 and journalid = $1
    RETURNING 'UPDATED JOURNAL RATE RECORD ' || journalrateid AS result;
  `;
  return script;
};

export const deleteJournalRateScript = () => {
  const script = `
    UPDATE salespmo.trn_journal_rate
    SET
      isactive = false,
      updated_by = $3,
      updated_time = CURRENT_TIMESTAMP
    WHERE
      journalrateid = ANY($2::int[]) and journalid = $1
  `;
  return script;
};

export const deleteJobRateScript = () => {
  const script = `
    UPDATE salespmo.trn_job_rate
    SET
      isactive = false,
      updated_by = $3,
      updated_time = CURRENT_TIMESTAMP
    WHERE
      jobrateid = any($2::int[]) and workorderid = $1
  `;
  return script;
};

export const insertJobRateScript = () => {
  const script = `
    INSERT INTO salespmo.trn_job_rate(
      workorderid,
      bookcode,
      serviceid,
      category,
      currencyid,
      uomid,
      value,
      billableduid,
      created_by,
      created_time, 
      code
    )
    VALUES($1,$2,$3,$4,$5, $6,$7,$8,$9,current_timestamp,$10);
  `;
  return script;
};

export const updateJobRateScript = () => {
  const script = `
    UPDATE salespmo.trn_job_rate
    SET
      bookcode = $2,
      serviceid = $3,
      category = $4,
      currencyid = $5,
      uomid = $6,
      value = $7,
      billableduid = $8,
      updated_by = $9,
      updated_time = CURRENT_TIMESTAMP,
      code = $10
    WHERE
      jobrateid = $11 and workorderid = $1 ;
  `;
  return script;
};
export const getJobRateScript = () => {
  const script = `
SELECT  
	j.jobrateid ,
	j.workorderid, 
  j.category,
    j.currencyid,
    c.currencycode,
    c.currency_symbol,
    j.serviceid,
    s.servicename,
    j.billableduid,
    d.duid,
    d.duname,
    string_agg(st.stageid::text, ',') AS stage_ids,
    string_agg(st.stagename, ',') AS stage_names,
    j.uomid,
    u.uom,
    j.value,
    j.code,
    j.uin,  -- For pearson rateentry
    j.gpc,
    j.item_desc,
    j.bookcode,
	  j.stageid AS p_stageid,
	  jst.stagename,
    j.complexity,
    j.service_type,
    j.unit_type,
    j.comments,
    j.quantity,
    j.total_value,
    true as disabled
FROM 
    salespmo.trn_job_rate j
JOIN 
    public.mst_currencymst c ON c.currencyid = j.currencyid 
JOIN 
    public.wms_mst_service s ON s.serviceid = j.serviceid 
JOIN 
    public.mst_deliveryunit d ON d.duid = j.billableduid 
left JOIN 
    (SELECT unnest(stageid) AS stage_id, stageid AS original_stage_id FROM salespmo.trn_job_rate) AS unnested_stages ON unnested_stages.original_stage_id = j.stageid
left JOIN 
    public.wms_mst_stage st ON st.stageid = unnested_stages.stage_id
LEFT JOIN -- Join changed to Left join for Pearson Rate Entry
    public.wms_mst_uom u ON u.uomid = j.uomid
LEFT JOIN -- For pearson rateentry
    public.wms_mst_stage jst ON jst.stageid = ANY(j.stageid) AND jst.isactive = true
where j.workorderid = $1 and j.isactive = true
GROUP by
j.jobrateid ,
j.workorderid, 
  j.category,
    j.currencyid,
    c.currencycode,
    c.currency_symbol,
    j.serviceid,
    s.servicename,
    j.billableduid,
    d.duid,
    d.duname,
    j.uomid,
    u.uom,
    j.value,
    j.code,
    jst.stagename; `;
  return script;
};

export const insertJobRateAdjScript = () => {
  const script = `INSERT INTO salespmo.trn_job_adjustment
(workorderid, bookcode, duid, customerid, service, ordermonth, value, remarks, currencyid, createdby)
VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)RETURNING adjustmentid;`;
  return script;
};

export const updateJobAdjRateScript = () => {
  const script = `
      UPDATE salespmo.trn_job_adjustment
      SET
        workorderid = $2,
        duid = $3
        customerId = $4,
        month = $5,
        year = $6,
        serviceid = $7,
        remarks = $8,
        value = $9,
        updated_by = $10,
        updated_time = current_timestamp
      WHERE
      adjustmentid = $1
      RETURNING 'UPDATED JOB ADJUST RATE ' || adjustmentid AS result;
    `;
  return script;
};

export const getJobRateAdjScript = () => {
  const script = `
  SELECT adjustmentid, wms.servicename, md.duname, 
    mc.currency_symbol,workorderid, bookcode, tja.duid, customerid, tja.service, tja.ordermonth,
    value, remarks, createdby, 
    createdtime + interval '5 hours 30 minutes' as createdon, updatedby, 
    updatedtime + interval '5 hours 30 minutes' as updatedon
  FROM salespmo.trn_job_adjustment tja 
  join public.wms_mst_service wms on wms.serviceid  = tja.service 
  join public.mst_deliveryunit md on md.duid = tja.duid 
  join public.mst_currencymst mc on mc.currencyid = tja.currencyid
   where (workorderid = $1 and tja.isactive = true) or (bookcode = $2 and tja.isactive = true);
  `;
  return script;
};

export const deleteJobRateAdjScript = () => {
  const script = `
  UPDATE salespmo.trn_job_adjustment
  SET  isactive=false,  updatedby=$2, updatedtime=CURRENT_TIMESTAMP
  WHERE adjustmentid=$1;
  `;
  return script;
};
export const checkActualByAdjRateScript = () => {
  const script = `
 select * FROM salespmo.trn_ord_inflow_stagewise_report
WHERE adjustmentid = $1 and (ordermonth >= date_trunc('month', current_date)
  AND ordermonth < date_trunc('month', current_date) + interval '1 month')
  `;
  return script;
};
export const deleteActualByAdjRateScript = () => {
  const script = `
 DELETE FROM salespmo.trn_ord_inflow_stagewise_report
WHERE adjustmentid = $1 and (ordermonth >= date_trunc('month', current_date)
  AND ordermonth < date_trunc('month', current_date) + interval '1 month')
  `;
  return script;
};

// rate entry actuals
export const getJobRateEntryActualsScript = () => {
  const script = `select toir.ord_inflowid,toir.currencyid,mc.currency_symbol,
        mc.currencycode , toisr.billableduid,toisr.billableduname, toisr.ordermonth,serviceid,servicename, stageid,stagename,uomid,uom,uomqty,
        rate,actualinflowvalue, toisr.adjustmentid 
      from salespmo.trn_ord_inflow_report toir 
      join salespmo.trn_ord_inflow_stagewise_report toisr  on toisr.ord_inflowid = toir.ord_inflowid
      join public.mst_currencymst mc on mc.currencyid = toir.currencyid 
      where toir.bookcode = $1  OR toir.workorderid = $2
      order by ordermonth desc`;
  return script;
};
// rate entry actuals

// rate entry History
export const getJobRateEntryHistoryScript = () => {
  const script = `select history_created_time, journalid, journalrateid , updated_by, created_by  from salespmo.trn_journal_rate_history
where  journalid = $1
 group by journalid ,journalrateid, updated_by , history_created_time, created_by
 order by history_created_time desc`;
  return script;
};

export const getJournalRateEntryHistoryScript = () => {
  const script = `select  wms.serviceid as column_id, wms.servicename as column_name from salespmo.rate_entry_config rec 
join public.wms_mst_service wms  on wms.serviceid  = rec.serviceid 
where rec.is_active = true and rec.duid  = $1 and rec.customerid = $2 and rec.verticalid = $3 
order by wms.servicename asc`;
  return script;
};
// rate entry History
export const getRateEntryMonthYearScript = () => {
  const script = `select 
TO_CHAR(current_date + interval '5 hours 30 minutes', 'Month') AS month,
TO_CHAR(current_date + interval '5 hours 30 minutes', 'YYYY') AS year, 
current_date + interval '5 hours 30 minutes' as currentdate ;`;
  return script;
};

export const insertAdjOnActualsScript = () => {
  const script = `
INSERT INTO salespmo.trn_ord_inflow_stagewise_report (
    ord_inflowid, 
    serviceid, 
    servicename, 
    actualinflowvalue,
    adjustmentid,
    ordermonth,
    billableduid,
    billableduname,
    created_by, 
    isactive,
    created_time
)
VALUES (
    $1, 
    $2, 
    $3, 
    $4, 
    $5, 
    $6,
    $7,
    $8,
    $9,
    true, 
    CURRENT_TIMESTAMP
);
  `;
  return script;
};

export const checkOrderInflowRecordScript = () => {
  const script = ` SELECT ord_inflowid FROM salespmo.trn_ord_inflow_report WHERE bookcode = $1`;
  return script;
};

export const insertOrderInflowRecordScript = () => {
  const script = ` INSERT INTO salespmo.trn_ord_inflow_report
  (workorderid, bookcode, baseduid, baseduname, customerid, customername, 
  divisionid, divisionname, countryid, countryname, verticalid, verticalname, 
  segmentid, segmentname, currencyid, currencyname, jobcreatedon, created_by, 
  flowtype, isactive, created_time)
  VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,
  'NEW', true, CURRENT_TIMESTAMP) RETURNING ord_inflowid;
  `;
  return script;
};

export const checkForAdjRateEntryScript = () => {
  const script = `select * from salespmo.trn_job_adjustment 
where isactive = true and bookcode = $1 and duid = $2 and customerid = $3 and service = $4 and 
(ordermonth >= date_trunc('month', current_date)
  AND ordermonth < date_trunc('month', current_date) + interval '1 month');`;
  return script;
};

export const insertRateEntryConfigScript = () => {
  const script = `INSERT INTO salespmo.rate_entry_config
(duid, customerid, verticalid, serviceid, category, categorymaster, uomid, oif_stageid, ubr_stageid, createdby, createdate, oi_ubr_not_required )
VALUES( $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, CURRENT_TIMESTAMP, $11);`;
  return script;
};
export const updateRateEntryConfigNotRequiredScript = () => {
  const script = `UPDATE salespmo.rate_entry_config
SET duid=$2, customerid=$3, verticalid=$4, is_active=true, updatedby=$5, updatedate=CURRENT_TIMESTAMP 
WHERE rate_entry_config_id=$1;`;
  return script;
};

export const updateRateEntryConfigScript = () => {
  const script = `UPDATE salespmo.rate_entry_config
  SET  serviceid=$2, category=$3, categorymaster=$4, uomid=$5, oif_stageid=$6, ubr_stageid=$7, updatedby=$8, updatedate=CURRENT_TIMESTAMP 
  WHERE rate_entry_config_id=$1;`;
  return script;
};

export const deleteRateEntryConfigScript = () => {
  const script = `UPDATE salespmo.rate_entry_config
    SET  is_active=false, updatedby=$2, updatedate=CURRENT_TIMESTAMP
    WHERE rate_entry_config_id = $1;`;
  return script;
};
export const checkRateEntryIfServiceExistsScript = () => {
  const script = `select rate_entry_config_id from salespmo.rate_entry_config rec where rec.duid = $1 and rec.customerid = $2 and 
rec.oi_ubr_not_required =$3 and rec.is_active = $4`;
  return script;
};

export const deleteInvoiceDescConfigScript = () => {
  const script = `UPDATE salespmo.invoice_config
SET is_active=false, updatedby=$2,  updatedate=CURRENT_TIMESTAMP
WHERE invconfigid = $1;`;
  return script;
};
export const checkInvDescIfServiceExistsScript = () => {
  const script = `select invconfigid from salespmo.invoice_config ic where ic.duid = $1 and ic.customerid = $2 and 
ic.inv_desc_not_required =$3 and ic.is_active = $4`;
  return script;
};

export const updateInvDescConfigNotRequiredScript = () => {
  const script = `UPDATE salespmo.invoice_config
SET duid=$2, customerid=$3, verticalid=$4, is_active=true, updatedby=$5, updatedate=CURRENT_TIMESTAMP 
WHERE invconfigid=$1;`;
  return script;
};

export const updateInvoiceDescScript = () => {
  const script = `UPDATE salespmo.invoice_config
SET serviceid=$2, category=$3, categorymaster=$4, invoicedescription=$5, updatedby=$6, updatedate=CURRENT_TIMESTAMP
WHERE invconfigid = $1;`;
  return script;
};

export const insertInvoiceDescScript = () => {
  const script = `INSERT INTO salespmo.invoice_config
( duid, customerid, verticalid, serviceid, category, categorymaster, invoicedescription, createdby, createdate, inv_desc_not_required)
VALUES( $1, $2, $3, $4, $5, $6, $7, $8, CURRENT_TIMESTAMP, $9);`;
  return script;
};

export const rateConfigTableScript = () => {
  const script = `;with data_rateentry as 
(
select
	distinct on
	(rec.duid,
	rec.customerid,
	rec.verticalid) rec.duid ,
	md.duname ,
	rec.customerid,
	mcu.customername ,
	rec.verticalid,
	msv.verticalname ,
	rec.createdby,
	coalesce(rec.createdate , rec.updatedate) as updatedon
from
	salespmo.rate_entry_config rec
join public.mst_customer as mcu on
	mcu.customerid = rec.customerid
join public.wms_mst_vertical as msv on
	msv.verticalid = rec.verticalid
join public.mst_deliveryunit as md on
	md.duid = rec.duid
where
	(rec.duid = coalesce($1, rec.duid))
	and (
         mcu.customername ilike '%' || coalesce($2, '') || '%'
		or msv.verticalname ilike '%' || coalesce($2, '') || '%'
        )
order by
	rec.duid,
	rec.customerid,
	rec.verticalid,
	coalesce(rec.createdate, rec.updatedate) desc
  ),
data_invoice as (
select
	distinct on
	(inv.duid,
	inv.customerid,
	inv.verticalid) inv.duid ,
	md.duname ,
	inv.customerid ,
	mcu.customername ,
	inv.verticalid,
	msv.verticalname ,
	inv.createdby,
	coalesce(inv.createdate , inv.updatedate) as updatedon
from
	salespmo.invoice_config inv
join public.mst_customer as mcu on
	mcu.customerid = inv.customerid
join public.wms_mst_vertical as msv on
	msv.verticalid = inv.verticalid
join public.mst_deliveryunit as md on
	md.duid = inv.duid
where 
	(inv.duid = coalesce($1, inv.duid))
		and (
         mcu.customername ilike '%' || coalesce($2, '') || '%'
			or msv.verticalname ilike '%' || coalesce($2, '') || '%'
        )
	order by
		inv.duid,
		inv.customerid,
		inv.verticalid,
		coalesce(inv.createdate , inv.updatedate)desc
  ) ,
data_invoicefield as (
select
	distinct on
	(inf.duid,
	inf.customerid,
	inf.verticalid) inf.duid,
	md.duname ,
	inf.customerid ,
	mcu.customername ,
	inf.verticalid,
	msv.verticalname ,
	inf.createdby,
	coalesce(inf.createdate , inf.updatedate) as updatedon
from
	salespmo.invoice_fieldmapping inf
join public.mst_customer as mcu on
	mcu.customerid = inf.customerid
join public.wms_mst_vertical as msv on
	msv.verticalid = inf.verticalid
join public.mst_deliveryunit as md on
	md.duid = inf.duid
where
	(inf.duid = coalesce($1, inf.duid))
		and (
         mcu.customername ilike '%' || coalesce($2, '') || '%'
			or msv.verticalname ilike '%' || coalesce($2, '') || '%'
        )
	order by
		inf.duid,
		inf.customerid,
		inf.verticalid,
		coalesce(inf.createdate , inf.updatedate)desc
)
select
	distinct on
	(fres.duid,
	fres.customerid,
	fres.verticalid) 
	fres.duid ,
	fres.customerid,
	fres.customername as customer ,
	fres.verticalname as vertical,
	fres.duname as du,
	fres.verticalid ,
	fres.createdby,
  to_char(fres.updatedon + interval '330 minutes','dd/mm/yyyy') as modifiedon
from
	(
	select
		*
	from
		data_rateentry d1
	where
		coalesce (d1.updatedon)::date = coalesce($3, d1.updatedon) ::date
union all
	select
		*
	from
		data_invoice as d2
	where
		coalesce (d2.updatedon)::date = coalesce($3, d2.updatedon) ::date
union all
	select
		*
	from
		data_invoicefield as d3
	where
		coalesce (d3.updatedon)::date = coalesce($3, d3.updatedon) ::date 
) as fres
order by
	fres.duid,
	fres.customerid,
	fres.verticalid ,
	fres.createdby,
	modifiedon desc`;
  return script;
};

export const getInvoicedynamicfieldScript = () => {
  const script = `select fieldmapid as id,labelname,ismandatory,fieldposition, fieldtype, placeholder,ismanual,isdisabled,ishide, default_value
  from wms_config_fields_map where isactive = true and screenname  = 'invoice' order by labelname;`;
  return script;
};

export const getInvoicefieldmappingScript = () => {
  const script = `select invmapid , fields  from salespmo.invoice_fieldmapping where duid = $1 and customerid  = $2 and verticalid = $3 and is_active  = true;`;
  return script;
};

export const insertInvoicefieldmappingScript = () => {
  const script = `INSERT INTO salespmo.invoice_fieldmapping 
      (duid, customerid, verticalid, fields, is_active, createdby, createdate) 
VALUES($1, $2, $3, $4, true, $5, CURRENT_TIMESTAMP) returning invmapid;`;
  return script;
};

export const updateInvoicefieldmappingScript = () => {
  const script = `update salespmo.invoice_fieldmapping set fields = $1 , updatedby = $2, updatedate = CURRENT_TIMESTAMP where invmapid = $3 returning invmapid;`;
  return script;
};
// lockjob
export const getOrderinflowReportScript = param => {
  const script = `;with cte AS
   (
    select 
    osr.ord_inflowid, oir.workorderid , oir.bookcode as jobid 
   ,coalesce(osr.actualinflowvalue ,0) as ordervalue
   ,osr.ordermonth ::date as orderdate, to_char(osr.ordermonth,'MON') as ordermonth, osr.serviceid
   ,osr.servicename as service, osr.stageid, osr.stagename
   ,oir.divisionid ,oir.baseduname as du, oir.customerid, oir.customername as customer
   ,oir.divisionname as division, oir.countryid, oir.countryname as country
   ,oir.verticalid, oir.verticalname as vertical
   ,oir.currencyid  ,oir.currencyname as currencycode 
   ,osr.billableduid , osr.billableduname, kam.kamempcode  
   ,wu.username as kam ,pmjc.name as projectmanager 
   ,wo.createdon as jobcreateddate
   ,wo.title
   ,osr.rate ,osr.uomqty, osr.actualinflowvalue
   ,(select max(created_time) from salespmo.trn_journal_rate tjr where journalid = wo.journalid  ) as rateentereddate
   ,osr.transferremarks 
   ,osr.adjqty
  FROM salespmo.trn_ord_inflow_report as oir
  JOIN salespmo.trn_ord_inflow_stagewise_report as osr on oir.ord_inflowid = osr.ord_inflowid 
  JOIN wms_workorder wo on wo.workorderid = oir.workorderid and coalesce(wo.islock,false) = false
  LEFT JOIN pp_mst_journal_contacts pmjc  on pmjc.journalid = wo.journalid AND pmjc.designation = '1'
  LEFT JOIN salespmo.trn_kamcustomerrel as kam on kam.customerid = oir.customerid  
												 AND kam.divisionid = oir.divisionid  
												 AND kam.verticalid = oir.verticalid  
												 AND kam.serviceid  = osr.serviceid
  LEFT JOIN wms_user wu on wu.userid = kam.kamempcode  
  
  WHERE oir.isactive = true 
    AND oir.flowtype  = 'NEW'   
    AND (oir.baseduid = COALESCE($1, oir.baseduid))
    AND (
         oir.customername ILIKE '%' || COALESCE($4, '') || '%'
         OR oir.verticalname ILIKE '%' || COALESCE($4, '') || '%'
         OR oir.bookcode ILIKE '%' || COALESCE($4, '') || '%'
        )
    AND ((osr.ordermonth  + interval '5 hours 30 minutes')::date BETWEEN COALESCE($2, osr.ordermonth )::date AND COALESCE($3, osr.ordermonth )::date)
  ORDER BY oir.workorderid , osr.ord_inflowid
    )
  SELECT ${param} 
   , sum(ordervalue) as ordervalue     
   from cte
  GROUP BY ${param};`;

  return script;
};

export const checkCombinationForRateEntry = () => {
  const script = `
  SELECT CASE
      WHEN EXISTS (
          SELECT 1 FROM salespmo.rate_entry_config rec 
          WHERE rec.duid = $1 AND rec.customerid = $2 AND rec.verticalid = $3
      ) OR EXISTS (
          SELECT 1 FROM salespmo.invoice_fieldmapping if2 
          WHERE if2.duid = $1 AND if2.customerid = $2 AND if2.verticalid = $3
      ) OR EXISTS (
          SELECT 1 FROM salespmo.invoice_config ic 
          WHERE ic.duid = $1 AND ic.customerid = $2 AND ic.verticalid = $3
      )
      THEN TRUE
      ELSE FALSE
  END AS record_exists;
  `;
  return script;
};

export const getRateEntryDataScript = () => {
  const script = `
  SELECT 
    rec.rate_entry_config_id,
    rec.serviceid,
    wms.servicename,
    rec.category,
    rec.categorymaster,
    rec.uomid,
    rec.oi_ubr_not_required,
    wmu.uom,
    -- Aggregate OI stages into an array of JSON objects
    COALESCE(
        JSON_AGG(
            DISTINCT JSONB_BUILD_OBJECT('value', wms2.stageid, 'label', wms2.stagename)
        ) FILTER (WHERE oif_stage.stageid IS NOT NULL), '[]'
    ) AS stageOI,
    -- Aggregate UBR stages into an array of JSON objects
    COALESCE(
        JSON_AGG(
            DISTINCT JSONB_BUILD_OBJECT('value', wms3.stageid, 'label', wms3.stagename)
        ) FILTER (WHERE ubr_stage.stageid IS NOT NULL), '[]'
    ) AS stageUBR
  FROM salespmo.rate_entry_config rec
  LEFT JOIN public.wms_mst_service wms ON wms.serviceid = rec.serviceid
  LEFT JOIN public.wms_mst_uom wmu ON wmu.uomid = rec.uomid
  LEFT JOIN LATERAL UNNEST(rec.oif_stageid) AS oif_stage(stageid) ON true
  LEFT JOIN public.wms_mst_stage wms2 ON wms2.stageid = oif_stage.stageid
  LEFT JOIN LATERAL UNNEST(rec.ubr_stageid) AS ubr_stage(stageid) ON true
  LEFT JOIN public.wms_mst_stage wms3 ON wms3.stageid = ubr_stage.stageid
  WHERE rec.is_active = true and duid = $1 AND customerid = $2 AND verticalid = $3
  GROUP BY rec.rate_entry_config_id, rec.serviceid, wms.servicename, rec.category, 
  rec.categorymaster, rec.uomid,rec.oi_ubr_not_required, wmu.uom;`;
  return script;
};

export const getRateConfigInvoiceDescDataScript = () => {
  const script = `select ic.invconfigid, ic.category, ic.categorymaster, ic.invoicedescription, ic.serviceid, wms.servicename, ic.inv_desc_not_required  from salespmo.invoice_config ic 
 LEFT JOIN public.wms_mst_service wms ON ic.serviceid = wms.serviceid 
 WHERE ic.is_active=true and ic.duid = $1 AND ic.customerid = $2 AND ic.verticalid = $3`;
  return script;
};

export const getRateConfigFieldScript = () => {
  const script = `select if2.*,mc.customercode, mc.customername, mc.customeralias
 from salespmo.invoice_fieldmapping if2  
 join public.mst_customer mc on mc.customerid = if2.customerid 
 WHERE if2.duid = $1 AND if2.customerid = $2 AND if2.verticalid = $3`;
  return script;
};

export const getOrderInflowFailureScript = () => {
  const script = `with logdata as (
      select
        distinct on
        (lo.workorderid) lo.workorderid , 
        wms.stageid ,
        wo.itemcode , 
        wms.stagename,
        lo.calctype,
        lo.remarks,
        lo.createdon
      from salespmo.log_orderinflow as lo
      join wms_workorder as wo on wo.workorderid = lo.workorderid
      join wms_mst_stage as wms on wms.stageid = lo.stageid
      join public.org_mst_customer_orgmap corg on
        corg.customerid = wo.customerid
        and corg.countryid = wo.countryid
        and corg.divisionid = wo.divisionid
        and corg.subdivisionid = wo.subdivisionid
      join public.org_mst_customerorg_du_map as cdum on
        cdum.custorgmapid = corg.custorgmapid
      join public.org_mst_deliveryunit omd on
        omd.duid = cdum.duid
      where
        omd.itrackduid = $1 and
        lo.createdon::date between  $2 ::date and  $3 ::date
        and (
        wo.itemcode ~* $4  or
        wms.stagename ~* $4
        )
      order by
        lo.workorderid ,
        createdon desc
      )
      , dtrecord as (
      select
        coalesce (toisr.actualinflowvalue ,0) as insvalue,
        ls.* ,
        toir.baseduid
      from logdata as ls
      left join salespmo.trn_ord_inflow_report as toir 
        on toir.workorderid = ls.workorderid
      left join salespmo.trn_ord_inflow_stagewise_report as toisr 
        on toisr.ord_inflowid = toir.ord_inflowid
        and toisr.stageid = ls.stageid
        and ls.calctype = toisr.inflowtype 
      )
      select
        insvalue, workorderid, stageid, itemcode,
        stagename, calctype, remarks, to_char (createdon,'yyyy-mm-dd hh24:mi:ss') as createdon,
        baseduid 
      from dtrecord
     ;`;
  // where insvalue = 0
  return script;
};
