export const getProjectWiseReportDataScript = payload => {
  console.log(payload);
  // const { selectedDu, baseDu, exchange, currency, from, to } = payload;

  // Start with the base script
  const script = `select bookcode,servicename from salespmo.trn_ord_inflow_report a join salespmo.trn_ord_inflow_stagewise_report b on a.ord_inflowid=b.ord_inflowid `;

  // // Initialize an array to hold the conditions
  // const conditions = [];

  // // Conditionally add to the WHERE clause based on the presence of each variable
  // if (selectedDu) {
  //   conditions.push(`selected_du = '${selectedDu}'`);
  // }

  // if (baseDu) {
  //   conditions.push(`base_du = '${baseDu}'`);
  // }

  // if (exchange) {
  //   conditions.push(`exchange = '${exchange}'`);
  // }

  // if (currency) {
  //   conditions.push(`currency = '${currency}'`);
  // }

  // if (from) {
  //   conditions.push(`date >= '${from}'`);
  // }

  // if (to) {
  //   conditions.push(`date <= '${to}'`);
  // }

  // // If there are any conditions, append them to the script
  // if (conditions.length > 0) {
  //   script += ` WHERE  ${conditions.join(' AND ')}`;
  // }

  // // Now `script` contains the complete SQL query
  // console.log(script);

  return script;
};
export const getPlanVsActualReportDataScript = () => {
  const script = ` select * from salespmo.actual_report_view `;
  return script;
};

export const getAuditModuleDDScript = () => {
  const script = `SELECT distinct(moduleid) as column_id, description as column_name
FROM salespmo.mst_audit_module where isactive = true;`;
  return script;
};

export const getAuditJournalSearchDDScript = () => {
  //   const script = `SELECT distinct journalacronym AS column_id, journalacronym AS column_name
  // FROM salespmo.trn_journal_rate tjr
  // WHERE tjr.journalacronym ILIKE '%' || $1 || '%'`;
  const script = `SELECT DISTINCT tjr.journalacronym AS column_id, tjr.journalacronym AS column_name
    FROM salespmo.trn_journal_rate tjr
    JOIN public.pp_mst_journal mj ON mj.journalid = tjr.journalid AND mj.isactive = 1
    JOIN public.org_mst_customer_orgmap cmap ON cmap.custorgmapid = mj.custorgmapid
    JOIN public.org_mst_customerorg_du_map dmap ON dmap.custorgmapid = mj.custorgmapid
    WHERE tjr.journalacronym ILIKE '%' || $1 || '%' AND dmap.duid IN ($2) AND cmap.customerid IN ($3);`;
  return script;
};
export const getAuditRateSearchDDScript = () => {
  //   const script = `SELECT distinct bookcode AS column_id, bookcode AS column_name
  // FROM salespmo.trn_job_rate tjr2
  // WHERE tjr2.bookcode ILIKE '%' || $1 || '%';`;
  const script = `SELECT DISTINCT tjr2.bookcode AS column_id, tjr2.bookcode AS column_name
    FROM salespmo.trn_job_rate tjr2
    JOIN public.wms_workorder wo ON wo.workorderid = tjr2.workorderid AND wo.isactive = true
    -- JOIN public.org_mst_deliveryunit odu ON wo.duid = odu.duid AND odu.isactive = true
    -- JOIN public.mst_deliveryunit ndu ON ndu.duid = odu.itrackduid AND ndu.isactive = true
    JOIN public.mst_deliveryunit ndu ON ndu.duid = $2 AND ndu.isactive = true
	JOIN public.org_mst_deliveryunit odu ON odu.itrackduid = ndu.duid AND odu.isactive = true
	JOIN public.org_mst_customer_orgmap cmap ON cmap.customerid = wo.customerid 
		AND cmap.divisionid = wo.divisionid AND cmap.subdivisionid = wo.subdivisionid
		AND cmap.countryid = wo.countryid AND cmap.isactive = 1
	JOIN public.org_mst_customerorg_du_map dumap ON dumap.custorgmapid = cmap.custorgmapid AND dumap.duid = odu.duid
    JOIN public.org_mst_customer ocu ON ocu.customerid = wo.customerid AND ocu.isactive = true
    JOIN public.mst_customer ncu ON ncu.customerid = ocu.itrack_customerid AND ncu.isactive = true
    WHERE tjr2.bookcode ILIKE '%' || $1 || '%' AND ncu.customerid IN ($3);`;
  return script;
};

export const getAuditInvoiceDDScript = () => {
  //   const script = `SELECT itemcode AS column_id, itemcode AS column_name
  // FROM salespmo.trn_rfidetails tr
  // WHERE tr.itemcode ILIKE '%' || $1 || '%';`;
  const script = `SELECT DISTINCT tr.itemcode AS column_id, tr.itemcode AS column_name
    FROM salespmo.trn_rfidetails tr
    JOIN public.wms_workorder wo ON wo.workorderid = tr.workorderid AND wo.isactive = true
    -- JOIN public.org_mst_deliveryunit odu ON wo.duid = odu.duid AND odu.isactive = true
    -- JOIN public.mst_deliveryunit ndu ON ndu.duid = odu.itrackduid AND ndu.isactive = true
    JOIN public.mst_deliveryunit ndu ON ndu.duid = $2 AND ndu.isactive = true
	JOIN public.org_mst_deliveryunit odu ON odu.itrackduid = ndu.duid AND odu.isactive = true
	JOIN public.org_mst_customer_orgmap cmap ON cmap.customerid = wo.customerid 
		AND cmap.divisionid = wo.divisionid AND cmap.subdivisionid = wo.subdivisionid
		AND cmap.countryid = wo.countryid AND cmap.isactive = 1
	JOIN public.org_mst_customerorg_du_map dumap ON dumap.custorgmapid = cmap.custorgmapid AND dumap.duid = odu.duid
    JOIN public.org_mst_customer ocu ON ocu.customerid = wo.customerid AND ocu.isactive = true
    JOIN public.mst_customer ncu ON ncu.customerid = ocu.itrack_customerid AND ncu.isactive = true
    WHERE tr.itemcode ILIKE '%' || $1 || '%' AND ncu.customerid IN ($3);`;
  return script;
};

export const getAuditLogJournalRateDataScript = () => {
  return `WITH filtered_audit_log AS (
    -- Pre-filter audit_log rows with necessary casting
    SELECT 
        al.*, 
        -- Cast values for billableduid-related fields
        CASE 
            WHEN al.field_name LIKE '%billableduid%' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS modified_data_cast,
        
        CASE 
            WHEN al.field_name LIKE '%billableduid%' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS original_data_cast,

        -- Pre-cast for serviceid and uomid-related fields
        CASE 
            WHEN al.field_name = 'serviceid' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS serviceid_modified,
        
        CASE 
            WHEN al.field_name = 'serviceid' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS serviceid_org,
        
        CASE 
            WHEN al.field_name = 'uomid' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS uomid_modified,
        
        CASE 
            WHEN al.field_name = 'uomid' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS uomid_org,

        -- Pre-fetch the user details (avoid repeated subqueries)
        (SELECT username || ' ' || '(' || userid || ')' 
         FROM public.wms_user 
         WHERE userid = al.modified_by AND useractive = true) AS modified_by_user,
         
        (SELECT username || ' ' || '(' || userid || ')' 
         FROM public.wms_user 
         WHERE userid = al.original_added_by AND useractive = true) AS original_added_by_user
    FROM 
        salespmo.audit_log al
)
SELECT 
    al.*, 
    -- Conditionally display modified data based on field_name
    CASE 
        WHEN al.modified_data_cast IS NOT NULL THEN mdu.duname  -- billableduid
        WHEN al.serviceid_modified IS NOT NULL THEN ms.servicename  -- serviceid
        WHEN al.uomid_modified IS NOT NULL THEN wmu.uom  -- uomid
        ELSE al.modified_data
    END AS display_modifieddata,

    -- Determine the field description based on field_name
    CASE 
        WHEN al.field_name = 'billableduid' THEN 'Billable DU' 
        WHEN al.field_name = 'serviceid' THEN 'Service' 
        WHEN al.field_name = 'uomid' THEN 'UOM' 
        WHEN al.field_name = 'value' THEN 'Rate'
        WHEN al.field_name = 'category' THEN 'Category'
        ELSE al.field_name
    END AS field,

    -- Date formatting with timezone adjustment (330 minutes)
    TO_CHAR(al.original_added_on + interval '330 minutes', 'DD/MM/YYYY HH24:MI:SS') AS original_added_date,
    TO_CHAR(al.modified_on + interval '330 minutes', 'DD/MM/YYYY HH24:MI:SS') AS modified_date,

    -- Conditionally display original data based on field_name
    CASE 
        WHEN al.original_data_cast IS NOT NULL THEN odu.duname  -- billableduid
        WHEN al.field_name = 'serviceid' THEN oms.servicename  -- serviceid
        WHEN al.field_name = 'uomid' THEN owmu.uom  -- uomid
        ELSE al.original_data
    END AS display_originaldata
FROM 
    salespmo.trn_journal_rate tjr
LEFT JOIN  
    filtered_audit_log al
    ON al.primary_key_value = tjr.journalrateid 
    AND al.table_name = 'trn_journal_rate'

-- Join with mst_deliveryunit for billableduid
LEFT JOIN 
    public.mst_deliveryunit mdu
    ON mdu.duid = al.modified_data_cast

LEFT JOIN 
    public.mst_deliveryunit odu
    ON odu.duid = al.original_data_cast

-- Join with wms_mst_service for serviceid
LEFT JOIN 
    public.wms_mst_service ms
    ON ms.serviceid = al.serviceid_modified
    AND al.field_name = 'serviceid'

LEFT JOIN 
    public.wms_mst_service oms
    ON oms.serviceid = al.serviceid_org
    AND al.field_name = 'serviceid'

-- Join with wms_mst_uom for uomid
LEFT JOIN 
    public.wms_mst_uom wmu
    ON wmu.uomid = al.uomid_modified
    AND al.field_name = 'uomid'

LEFT JOIN 
    public.wms_mst_uom owmu
    ON owmu.uomid = al.uomid_org
    AND al.field_name = 'uomid'

WHERE 
    tjr.journalacronym = $1

ORDER BY 
    al.modified_on DESC;
`;
};

export const getAuditLogJobRateDataScript = () => {
  return `WITH filtered_audit_log AS (
    -- Pre-filter audit_log rows with necessary casting
    SELECT 
        al.*, 
        -- Cast values for billableduid-related fields
        CASE 
            WHEN al.field_name LIKE '%billableduid%' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS modified_data_cast,
        
        CASE 
            WHEN al.field_name LIKE '%billableduid%' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS original_data_cast,

        -- Pre-cast for serviceid and uomid-related fields
        CASE 
            WHEN al.field_name = 'serviceid' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS serviceid_modified,
        
        CASE 
            WHEN al.field_name = 'serviceid' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS serviceid_org,
        
        CASE 
            WHEN al.field_name = 'uomid' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS uomid_modified,
        
        CASE 
            WHEN al.field_name = 'uomid' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS uomid_org,

        -- Pre-fetch the user details (avoid repeated subqueries)
        (SELECT username || ' ' || '(' || userid || ')' 
         FROM public.wms_user 
         WHERE userid = al.modified_by AND useractive = true) AS modified_by_user,
         
        (SELECT username || ' ' || '(' || userid || ')' 
         FROM public.wms_user 
         WHERE userid = al.original_added_by AND useractive = true) AS original_added_by_user
    FROM 
        salespmo.audit_log al
)
SELECT 
    al.*, 
    -- Conditionally display modified data based on field_name
    CASE 
        WHEN al.modified_data_cast IS NOT NULL THEN mdu.duname  -- billableduid
        WHEN al.serviceid_modified IS NOT NULL THEN ms.servicename  -- serviceid
        WHEN al.uomid_modified IS NOT NULL THEN wmu.uom  -- uomid
        ELSE al.modified_data
    END AS display_modifieddata,

    -- Determine the field description based on field_name
    CASE 
        WHEN al.field_name = 'billableduid' THEN 'Billable DU' 
        WHEN al.field_name = 'serviceid' THEN 'Service' 
        WHEN al.field_name = 'uomid' THEN 'UOM' 
        WHEN al.field_name = 'value' THEN 'Rate'
        WHEN al.field_name = 'category' THEN 'Category'
        ELSE al.field_name
    END AS field,

    -- Date formatting with timezone adjustment (330 minutes)
    TO_CHAR(al.original_added_on + interval '330 minutes', 'DD/MM/YYYY HH24:MI:SS') AS original_added_date,
    TO_CHAR(al.modified_on + interval '330 minutes', 'DD/MM/YYYY HH24:MI:SS') AS modified_date,

    -- Conditionally display original data based on field_name
    CASE 
        WHEN al.original_data_cast IS NOT NULL THEN odu.duname  -- billableduid
        WHEN al.field_name = 'serviceid' THEN oms.servicename  -- serviceid
        WHEN al.field_name = 'uomid' THEN owmu.uom  -- uomid
        ELSE al.original_data
    END AS display_originaldata
FROM 
    salespmo.trn_job_rate tjr
LEFT JOIN  
    filtered_audit_log al
    ON al.primary_key_value = tjr.jobrateid 
    AND al.table_name = 'trn_job_rate'

-- Join with mst_deliveryunit for billableduid
LEFT JOIN 
    public.mst_deliveryunit mdu
    ON mdu.duid = al.modified_data_cast

LEFT JOIN 
    public.mst_deliveryunit odu
    ON odu.duid = al.original_data_cast

-- Join with wms_mst_service for serviceid
LEFT JOIN 
    public.wms_mst_service ms
    ON ms.serviceid = al.serviceid_modified
    AND al.field_name = 'serviceid'

LEFT JOIN 
    public.wms_mst_service oms
    ON oms.serviceid = al.serviceid_org
    AND al.field_name = 'serviceid'

-- Join with wms_mst_uom for uomid
LEFT JOIN 
    public.wms_mst_uom wmu
    ON wmu.uomid = al.uomid_modified
    AND al.field_name = 'uomid'

LEFT JOIN 
    public.wms_mst_uom owmu
    ON owmu.uomid = al.uomid_org
    AND al.field_name = 'uomid'

WHERE 
    tjr.bookcode = $1
    AND al.audit_id IS NOT NULL  -- Skip rows without matching data in filtered_audit_log

ORDER BY 
    al.modified_on DESC;
`;
};

export const getAuditLogRfiDetailsDataScript = () => {
  return `WITH filtered_audit_log AS (
	SELECT 
        al.*, 
        -- Cast values for billableduid-related fields
        CASE 
            WHEN al.field_name LIKE '%billableduid%' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS modified_data_cast,
        
        CASE 
            WHEN al.field_name LIKE '%billableduid%' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS original_data_cast,

        -- Pre-cast for serviceid and uomid-related fields
        CASE 
            WHEN al.field_name = 'serviceid' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS serviceid_modified,
        
        CASE 
            WHEN al.field_name = 'serviceid' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS serviceid_org,
        
        CASE 
            WHEN al.field_name = 'uomid' THEN CAST(al.modified_data AS INTEGER)
            ELSE NULL
        END AS uomid_modified,
        
        CASE 
            WHEN al.field_name = 'uomid' THEN CAST(al.original_data AS INTEGER)
            ELSE NULL
        END AS uomid_org,

        -- Pre-fetch the user details (avoid repeated subqueries)
        COALESCE((SELECT username || ' ' || '(' || userid || ')' 
         FROM public.wms_user 
         WHERE userid = al.modified_by AND useractive = true),al.modified_by) AS modified_by_user,
         
        COALESCE((SELECT username || ' ' || '(' || userid || ')' 
         FROM public.wms_user 
         WHERE userid = al.original_added_by AND useractive = true),al.original_added_by) AS original_added_by_user
    FROM 
        salespmo.audit_log al
)
SELECT 
    al.*, 
    -- Conditionally display modified data based on field_name
    CASE 
        WHEN al.modified_data_cast IS NOT NULL THEN mdu.duname  -- billableduid
        WHEN al.serviceid_modified IS NOT NULL THEN ms.servicename  -- serviceid
        WHEN al.uomid_modified IS NOT NULL THEN wmu.uom  -- uomid
        ELSE al.modified_data
    END AS display_modifieddata,

    -- Determine the field description based on field_name
    CASE 
        WHEN al.field_name = 'billableduid' THEN 'Billable DU' 
        WHEN al.field_name = 'serviceid' THEN 'Service' 
        WHEN al.field_name = 'uomid' THEN 'UOM' 
        WHEN al.field_name = 'value' THEN 'Rate'
        WHEN al.field_name = 'category' THEN 'Category'
        ELSE al.field_name
    END AS field,

    -- Date formatting with timezone adjustment (330 minutes)
    TO_CHAR(al.original_added_on + interval '330 minutes', 'DD/MM/YYYY HH24:MI:SS') AS original_added_date,
    TO_CHAR(al.modified_on + interval '330 minutes', 'DD/MM/YYYY HH24:MI:SS') AS modified_date,

    -- Conditionally display original data based on field_name
    CASE 
        WHEN al.original_data_cast IS NOT NULL THEN odu.duname  -- billableduid
        WHEN al.field_name = 'serviceid' THEN oms.servicename  -- serviceid
        WHEN al.field_name = 'uomid' THEN owmu.uom  -- uomid
        ELSE al.original_data
    END AS display_originaldata
FROM 
    salespmo.trn_rfidetails tjr
LEFT JOIN  
    filtered_audit_log al
    ON al.primary_key_value = tjr.invoiceid 
    AND al.table_name = 'trn_rfidetails'

-- Join with mst_deliveryunit for billableduid
LEFT JOIN 
    public.mst_deliveryunit mdu
    ON mdu.duid = al.modified_data_cast

LEFT JOIN 
    public.mst_deliveryunit odu
    ON odu.duid = al.original_data_cast

-- Join with wms_mst_service for serviceid
LEFT JOIN 
    public.wms_mst_service ms
    ON ms.serviceid = al.serviceid_modified
    AND al.field_name = 'serviceid'

LEFT JOIN 
    public.wms_mst_service oms
    ON oms.serviceid = al.serviceid_org
    AND al.field_name = 'serviceid'

-- Join with wms_mst_uom for uomid
LEFT JOIN 
    public.wms_mst_uom wmu
    ON wmu.uomid = al.uomid_modified
    AND al.field_name = 'uomid'

LEFT JOIN 
    public.wms_mst_uom owmu
    ON owmu.uomid = al.uomid_org
    AND al.field_name = 'uomid'

WHERE 
    tjr.itemcode = $1
    AND al.audit_id IS NOT NULL  -- Skip rows without matching data in filtered_audit_log

ORDER BY 
    al.modified_on DESC;`;
};
