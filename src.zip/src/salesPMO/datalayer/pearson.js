// Price Grid
export const getServiceMst = () => {
  const script =
    'SELECT servicename FROM public.wms_mst_service WHERE isactive = true;';
  return script;
};

export const insFileBasicDetails = () => {
  const script = `INSERT INTO salespmo.customer_price_grid (filename, version, effectivefromdate, effectivetodate, 
    isactive, created_by, created_time) VALUES ($1,
    COALESCE((SELECT MAX(version) FROM salespmo.customer_price_grid), 0) + 1, $2,
    (SELECT (effectivefromdate - INTERVAL '1 day')::DATE FROM salespmo.customer_price_grid ORDER BY version DESC LIMIT 1),
    $3,$4,CURRENT_TIMESTAMP)
    RETURNING fileid;`;
  return script;
};

export const insFileItemDetails = (inputArray, fileId) => {
  const script = `WITH input_data AS (
  SELECT 
    *,
    row_number() OVER () AS input_order -- Add an order column based on the input array's order
  FROM jsonb_to_recordset('${JSON.stringify(inputArray)}') AS t(
    index_number TEXT,
    business_group TEXT,
    service_item_number TEXT,
    service_category TEXT,
    item_description TEXT,
    complexity TEXT,
    item_type TEXT,
    service_type TEXT,
    unit TEXT,
    l1_item_description TEXT,
    l2_item_description TEXT,
    unit_type TEXT
  )
),
inserted_rows AS (
  INSERT INTO salespmo.customer_price_grid_details (fileid, index_number, business_group, 
    service_item_number, service_category, item_description, complexity, item_type, service_type, unit,  
    l1_item_description, l2_item_description, unit_type, serviceid)
  SELECT 
    ${fileId},
    input_data.index_number,
    input_data.business_group,
    input_data.service_item_number,
    input_data.service_category,
    input_data.item_description,
    input_data.complexity,
    input_data.item_type,
    input_data.service_type,
    input_data.unit,
    input_data.l1_item_description,
    input_data.l2_item_description,
    input_data.unit_type,
    (SELECT serviceid FROM public.wms_mst_service WHERE servicename ILIKE 
        '%' || input_data.service_category || '%' AND isactive = true LIMIT 1)
  FROM input_data
  RETURNING *
  )
  SELECT * FROM inserted_rows;  -- Final select to return inserted rows`;
  return script;
};

export const getFileBasicDetails = () => {
  const script = `SELECT pg.fileid, pg.filename, pg.created_time AS uploadedon, 
    u.username || ' (' || pg.created_by || ')'  AS uploadedby, CONCAT('Version ', pg.version) AS version, 
    pg.effectivefromdate AS effectivefrom, pg.effectivetodate AS effectiveto, 'action' AS action 
    FROM salespmo.customer_price_grid pg
	  LEFT JOIN public.wms_user u ON u.userid = pg.created_by AND u.useractive = true
    --WHERE ($1 = '' OR filename ILIKE '%' || $1 || '%' OR version::TEXT = $1) AND isactive = true ORDER BY 1 DESC;
    WHERE ($1 = '' OR pg.filename ILIKE '%' || $1 || '%' OR pg.version::TEXT ILIKE '%' || $1 || '%'
	    OR position('version' IN lower($1)) > 0 AND pg.version::TEXT = trim(both ' ' from substring($1 from 9))
	    ) AND isactive = true ORDER BY 1 DESC;`;
  return script;
};

export const getLatestVersion = () => {
  const script = `SELECT COALESCE(MAX(version), 0) AS version FROM salespmo.customer_price_grid WHERE isactive = true;`;
  return script;
};

export const getFileLineItemDetails = () => {
  const script = `SELECT fd.* FROM salespmo.customer_price_grid_details fd 
    JOIN salespmo.customer_price_grid pg ON pg.fileid =  fd.fileid AND pg.filename = $2 AND pg.isactive = true
    WHERE fd.fileid = $1 AND 
    ($3 = '' OR fd.index_number ILIKE '%' || $3 || '%' OR fd.service_category ILIKE '%' || $3 || '%' OR fd.service_item_number ILIKE '%' || $3 || '%');`;
  return script;
};

// Rate Entry
export const checkIsIncomingAnalysisComplete = () => {
  const script = `SELECT * FROM public.wms_workorder_incoming wi 
    JOIN public.wms_workorder_incomingfiledetails wif ON wif.woincomingid = wi.woincomingid AND wif.isactive = true
    WHERE wi.woid = $1;`;
  return script;
};

export const checkIsStageCreated = () => {
  const script = `SELECT * FROM public.wms_workorder_stage WHERE workorderid = $1;`;
  return script;
};

export const getUniquePriceGridMasterData = () => {
  const query = `WITH RankedFiles AS (
    SELECT pg.fileid, ROW_NUMBER() OVER (ORDER BY pg.fileid DESC) AS rn
    FROM salespmo.customer_price_grid pg
    WHERE pg.isactive = true)
    SELECT pgd.* FROM salespmo.customer_price_grid_details pgd
    JOIN salespmo.customer_price_grid pg ON pg.fileid = pgd.fileid AND pg.isactive = true
    JOIN RankedFiles rf ON pg.fileid = rf.fileid
    WHERE rf.rn = 1 AND ($1 = '' OR pgd.index_number ilike '%' || $1 || '%')
	  AND ($2 = '' OR pgd.service_item_number ilike '%' || $2 || '%') 
    AND ($3 = '' OR  pgd.service_category::TEXT ilike '%' || $3 || '%')
    AND ($4 = '' OR pgd.item_description ilike '%' || $4 || '%')
    AND ($5 = '' OR pgd.complexity ilike '%' || $5 || '%')
    AND ($6 = '' OR pgd.service_type ilike '%' || $6 || '%')
    AND ($7 = '' OR pgd.unit_type ilike '%' || $7 || '%')
    ORDER BY pgd.index_number, pgd.service_item_number, pgd.service_category, pgd.item_description, pgd.complexity, 
    pgd.service_type, pgd.unit_type, pgd.serviceid;`;
  return query;
};

export const getUBRStagewithWorkOrderId = () => {
  const script = `SELECT ws.workorderid, ws.wfstageid AS column_id, ms.stagename AS column_name FROM 
    public.wms_workorder_stage ws
    LEFT JOIN public.wms_mst_stage ms ON ms.stageid = ws.wfstageid AND ms.isactive = true
    WHERE ws.workorderid = $1;`;
  return script;
};

export const checkForRateEntryScript = () => {
  const script = `SELECT * FROM salespmo.trn_job_rate
    WHERE
    workorderid = $1  AND
    bookcode = $2 AND
    serviceid = $3 AND
    $4 = ANY(stageid) AND
    --stageid = $4 AND
    currencyid = $5 AND
    billableduid = $6 AND
    uin = $7 AND
    gpc = $8 AND
    item_desc = $9 AND
    complexity = $10 AND
    service_type = $11 AND
    unit_type = $12 AND
    comments = $13 AND
    isactive = true`;
  return script;
};

export const insertRateEntryScript = () => {
  const script = `INSERT INTO salespmo.trn_job_rate(workorderid, bookcode, serviceid, stageid, currencyid, 
      value, billableduid, quantity, total_value, uin, gpc, item_desc, complexity, service_type, unit_type,
      comments, created_by, created_time) VALUES 
      ($1, $2, $3, ARRAY[$4]::bigint[], $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, CURRENT_TIMESTAMP);`;
  return script;
};

export const updateRateEntryScript = () => {
  const script = `
    UPDATE salespmo.trn_job_rate
    SET
      serviceid = $3,
      --stageid = array_append(stageid, $4),  -- Append the value $4 to the existing bigint[] array
      stageid = $4,
      currencyid = $5,
      value = $6,
      billableduid = $7,
      quantity = $8,
      total_value = $9,
      uin = $10,
      gpc = $11,
      item_desc = $12,
      complexity = $13,
      service_type = $14,
      unit_type = $15,
      comments = $16,
      updated_by = $17,
      updated_time = CURRENT_TIMESTAMP
    WHERE jobrateid = $18 AND workorderid = $1 AND bookcode = $2;`;
  return script;
};
