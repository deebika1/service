import { query, transaction } from '../../database/postgres.js';
// lockjob
export const getWorkOrderList = () => {
  const script = `SELECT ROW_NUMBER() OVER (ORDER BY wo.itemcode, wo.title) AS serial,
    wo.workorderid, wo.itemcode, wo.title, cdu.duid AS iwmsduid, du.duid, du.duname, 
    wo.customerid AS iwmscustomerid, c.customerid, c.customername,
    CASE WHEN (SELECT COUNT(*) FROM salespmo.trn_lockunlockjob_history WHERE workorderid = wo.itemcode) >= 1 THEN true
	  ELSE false END AS hashistory,
    CASE WHEN wo.islock is true THEN 'Lock'
	  ELSE 'Unlock' END AS islock,'action' AS action
    FROM public.wms_workorder wo
    JOIN public.org_mst_customer_orgmap cu ON cu.customerid = wo.customerid AND 
        cu.divisionid = wo.divisionid AND cu.subdivisionid = wo.subdivisionid AND 
        cu.countryid = wo.countryid AND cu.isactive = 1
    JOIN public.org_mst_customerorg_du_map cdu ON cdu.custorgmapid = cu.custorgmapid
    LEFT JOIN public.org_mst_deliveryunit odu ON odu.duid = cdu.duid AND odu.isactive = true
    LEFT JOIN public.mst_deliveryunit du ON du.duid = odu.itrackduid AND du.isactive = true
    LEFT JOIN public.org_mst_customer oc ON oc.customerid = wo.customerid AND oc.isactive = true
    LEFT JOIN public.mst_customer c ON c.customerid = oc.itrack_customerid AND c.isactive = true
    WHERE wo.isactive = true and coalesce(wo.islock,false) = false AND (wo.itemcode ILIKE '%' || $1 || '%' OR wo.title ILIKE '%' || $1 || '%')
    ORDER BY wo.itemcode, wo.title`;
  return script;
};

export const validateLockUnlockFile = async (file, createdBy) => {
  return new Promise(async (resolve, reject) => {
    try {
      let haserror = false;

      const deleteScript = delLockUnlockTempTableData();
      await query(deleteScript);
      const script = insertScriptforLockUnlockTempTable();
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            for (const element of file) {
              if (
                element.length === 3 ||
                element[0] ||
                element[0].trim() !== '' ||
                element[1] ||
                element[1].trim() !== '' ||
                element[2] ||
                element[2].trim() !== ''
              ) {
                await client.query(script, [
                  element[0],
                  element[1],
                  element[2],
                  null,
                  createdBy,
                ]);
              } else if (
                !element[0] ||
                element[0].trim() == '' ||
                !element[1] ||
                element[1].trim() == '' ||
                !element[2] ||
                element[2].trim() == ''
              ) {
                await client.query(script, [
                  element[0] || '',
                  element[1] || '',
                  element[2] || '',
                  'Fill all details',
                  createdBy,
                ]);
                haserror = true;
              }
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });

      // check duplicate records in excel
      const getScript = getTempTableData();
      const insertedData = await query(getScript);

      for (let i = 0; i < insertedData.length; i++) {
        for (let j = i + 1; j < insertedData.length; j++) {
          if (
            insertedData[i].workorderid == insertedData[j].workorderid &&
            insertedData[i].lockunlock != insertedData[j].lockunlock
          ) {
            await query(
              `UPDATE salespmo.trn_temp_lockunlockjob SET remarks = 
              CASE WHEN remarks IS NULL THEN 'Duplicate value'
              ELSE CONCAT(remarks, ',Duplicate value') END WHERE id = $1;`,
              [insertedData[j].id],
            );
            haserror = true;
          }
        }
      }

      insertedData.forEach(async item => {
        const isWorkorderExist = await query(
          `SELECT 1 FROM public.wms_workorder WHERE itemcode = '${item.workorderid}'`,
        );
        if (isWorkorderExist.length == 0) {
          await query(
            `UPDATE salespmo.trn_temp_lockunlockjob SET remarks = 
            CASE WHEN remarks IS NULL THEN 'Workorder ID does not match'
            ELSE CONCAT(remarks, ',Workorder ID does not match') END WHERE id = $1;`,
            [item.id],
          );
          haserror = true;
        }
      });

      if (haserror) {
        resolve('file has error');
      } else {
        const result = await insertPlan(insertedData, createdBy);
        if (result) {
          resolve('success');
        } else {
          resolve('file has error');
        }
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const insertPlan = async (insertedData, createdBy) => {
  try {
    let result = true;
    const updateWorkOrderIdScript = updateWorkorderID();
    const InsertHistoryScript = insertHistoryTable();

    await transaction(client => {
      return new Promise(async (tresolve, treject) => {
        try {
          for (const item of insertedData) {
            const isLockFlag = item.lockunlock.trim().toUpperCase() === 'LOCK';
            const isLock =
              item.lockunlock.trim().toUpperCase() === 'LOCK'
                ? 'Locked'
                : 'Unlocked';

            const isExistScript = checkisExist();
            const isExist = await client.query(isExistScript, [
              item.workorderid,
              isLockFlag,
            ]);
            if (!item.remarks) {
              await client.query(updateWorkOrderIdScript, [
                item.workorderid,
                isLockFlag,
              ]);
              if (isExist[0].count === 0) {
                await client.query(InsertHistoryScript, [
                  item.workorderid,
                  isLock,
                  item.reason,
                  createdBy,
                ]);
              }
            } else {
              result = false;
            }
          }
          tresolve('success');
        } catch (error) {
          treject(error);
        }
      });
    });
    return result;
  } catch (err) {
    console.log(err);
    return false;
  }
};

export const delLockUnlockTempTableData = () => {
  const script = `DELETE FROM salespmo.trn_temp_lockunlockjob;`;
  return script;
};

export const insertScriptforLockUnlockTempTable = () => {
  const script = `INSERT INTO salespmo.trn_temp_lockunlockjob(
    workorderid, lockunlock, reason, remarks, created_by, created_time)
    VALUES($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
    RETURNING id;`;
  return script;
};

export const getTempTableData = () => {
  const script = `SELECT * FROM salespmo.trn_temp_lockunlockjob ORDER BY 1;`;
  return script;
};

export const updateWorkorderID = () => {
  const script = `UPDATE public.wms_workorder SET islock = $2 WHERE itemcode = $1 AND isactive = true;`;
  return script;
};

export const insertHistoryTable = () => {
  const script = `INSERT INTO salespmo.trn_lockunlockjob_history (workorderid, islock, reason, updated_by, updated_time)
    --VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP AT TIME ZONE 'UTC' + INTERVAL '5 hours 30 minutes');
    VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP);`;
  return script;
};

export const getHistoryData = () => {
  // const script = `SELECT
  //   CONCAT((SELECT username FROM public.wms_user WHERE userid = th.updated_by), ' (', th.updated_by, ')') AS username,
  //   th.workorderid AS workorderid, th.islock AS type, th.reason AS team, th.updated_time AS created_time
  //   FROM salespmo.trn_lockunlockjob_history th
  //   WHERE th.workorderid = $1 ORDER BY updated_time DESC;`;
  const script = `SELECT 
      CASE 
        WHEN th.updated_by = 'ODOO' THEN th.updated_by 
        ELSE CONCAT((SELECT username FROM public.wms_user WHERE userid = th.updated_by), ' (', th.updated_by, ')') 
      END AS username, th.workorderid AS workorderid, th.islock AS type, th.reason AS team, 
      th.updated_time AS created_time
      FROM salespmo.trn_lockunlockjob_history th
      WHERE th.workorderid = $1 ORDER BY updated_time DESC;`;
  return script;
};

export const checkisExist = () => {
  const script = `SELECT COUNT(*) FROM public.wms_workorder WHERE itemcode = $1 AND islock = $2 AND isactive = true;`;
  return script;
};

export const updateLockJobusingId = () => {
  const script = `UPDATE public.wms_workorder SET islock = $2 WHERE workorderid = $1 AND isactive = true;`;
  return script;
};

export const getIsFullyInvoiced = () => {
  const script = `SELECT COUNT(*) FROM salespmo.trn_rfidetails WHERE workorderid = $1 AND isfullinvoice = true;`;
  return script;
};
