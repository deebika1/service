import { query } from '../../database/postgres.js';

export const insertServiceAndStageMapping = async (
  duid,
  Customerid,
  serviceid,
  stages,
  created_by,
) => {
  const serviceMappingResult = await query(
    `INSERT INTO salespmo.mst_servicemapping(
      duid,
      Customerid,
      serviceid,
      created_by
    )
    VALUES (
      $1, $2, $3, $4
    )
    RETURNING servicemapping_id;`,
    [duid, Customerid, serviceid, created_by],
  );

  const { servicemapping_id } = serviceMappingResult.rows[0];
  const stageMappingPromises = stages.map(async stage => {
    await query(
      `INSERT INTO salespmo.mst_stagemapping(
        servicemapping_id,
        StageId,
        Stageseq,
        created_by
      )
      VALUES (
        $1, $2, $3, $4, $5
      );`,
      [servicemapping_id, stage.StageId, stage.Stageseq, created_by],
    );
  });

  await Promise.all(stageMappingPromises);

  return { serviceMappingResult };
};

export const updateServiceMappingById = async (
  servicemapping_id,
  duid,
  Customerid,
  serviceid,
  updated_by,
) => {
  const result = await query(
    `UPDATE salespmo.mst_servicemapping
SET duid = $2,
    Customerid = $3,
    serviceid = $4,
    updated_by = $5,
    updated_time = current_timestamp
WHERE servicemapping_id = $1;`,
    [servicemapping_id, duid, Customerid, serviceid, updated_by],
  );
  return result;
};

export const updateStageMappingById = async (
  stagemapping_id,
  servicemapping_id,
  StageId,
  Stageseq,
  updated_by,
) => {
  const result = await query(
    `UPDATE salespmo.mst_stagemapping
     SET servicemapping_id = $2,
         StageId = $3,
         isactive = $4,
         updated_by = $5,
         updated_time = current_timestamp
     WHERE stagemapping_id = $1;`,
    [stagemapping_id, servicemapping_id, StageId, Stageseq, updated_by],
  );
  return result;
};

export const getServiceMapScript = () => {
  const script = `select 
  s.duid,
  md.duname ,
  s.customerid,
  mc.customername ,
  s.serviceid,
  wms.servicename ,
  s.servicemapping_id 
  from  salespmo.mst_servicemapping s
  join mst_customer mc on mc.customerid = s.customerid 
  join mst_deliveryunit md on md.duid = s.duid 
  join wms_mst_service wms on wms.serviceid = s.serviceid 
  where s.isactive = true order by md.duname ,mc.customername ,wms.servicename ;`;
  return script;
};

export const getStageMapScript = () => {
  const script = `select ms.stageid ,
  wms.stagename ,
  ms.stageseq ,
  ms.stagemapping_id 
from salespmo.mst_stagemapping ms 
join wms_mst_stage wms on wms.stageid = ms.stageid 
where ms.servicemapping_id = $1
and ms.isactive = true;`;
  return script;
};
