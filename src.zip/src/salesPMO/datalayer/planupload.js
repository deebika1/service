/* eslint-disable array-callback-return */
import { query, transaction } from '../../database/postgres.js';
import { get_master_drop_down } from '../../iProductivity/dataLayer/masterDropDown.js';

export const validateFile = (file, createdBy, key, Year) => {
  return new Promise(async (resolve, reject) => {
    try {
      let dataerror = false;
      let rowerror = false;
      const deleteScript = delTempTableData();
      await query(deleteScript);
      const script = insertScriptforTempTable();
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            for (const element of file) {
              await client.query(script, [
                element[0],
                element[1],
                element[2],
                element[3],
                element[4],
                element[5],
                element[6],
                element[7],
                element[8],
                element[9],
                element[10],
                element[11],
                element[12],
                element[13],
                element[14],
                element[15],
                element[16],
                element[17],
                element[18],
                element[19],
                element[20],
                element[21],
                // element[22],
                createdBy,
              ]);
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });

      // check duplicate records in excel
      const getScript = getTempTableData();
      const insertedData = await query(getScript);

      for (let i = 0; i < insertedData.length; i++) {
        for (let j = i + 1; j < insertedData.length; j++) {
          if (insertedData[i].data === insertedData[j].data) {
            await query(
              `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks = 'Duplicate Entry', errortype = 'row error'
            WHERE relid = $1;`,
              [insertedData[j].relid],
            );
            rowerror = true;
          }
        }
      }

      let entityMaster = await query(get_master_drop_down('ENTITY'));
      entityMaster = entityMaster.map(data => parseInt(data.column_id));
      let duMaster = await query(get_master_drop_down('DU'));
      duMaster = duMaster.map(data => parseInt(data.column_id));
      let customerMaster = await query(get_master_drop_down('MSTCUSTOMER'));
      customerMaster = customerMaster.map(data => parseInt(data.column_id));
      let serviceMaster = await query(get_master_drop_down('SERVICE'));
      serviceMaster = serviceMaster.map(data => parseInt(data.column_id));
      let divisionMaster = await query(get_master_drop_down('DIVISION'));
      divisionMaster = divisionMaster.map(data => parseInt(data.column_id));
      let segmentMaster = await query(get_master_drop_down('SEGMENT'));
      segmentMaster = segmentMaster.map(data => parseInt(data.column_id));
      let countryMaster = await query(get_master_drop_down('COUNTRY'));
      countryMaster = countryMaster.map(data => parseInt(data.column_id));
      let verticalMaster = await query(get_master_drop_down('VERTICAL'));
      verticalMaster = verticalMaster.map(data => parseInt(data.column_id));
      let cmMaster = await query(get_master_drop_down('CMEMPCODE'));
      cmMaster = cmMaster.map(data => data.column_id);
      let kamMaster = await query(get_master_drop_down('KAMEMPCODE'));
      kamMaster = kamMaster.map(data => data.column_id);
      // let currencycodeMaster = await query(
      //   get_master_drop_down('CURRENCYCODE'),
      // );
      // currencycodeMaster = currencycodeMaster.map(data =>
      //   parseInt(data.column_id),
      // );

      // check master data mismatch
      const entityListScript = uniqueEntityScript();
      const entityList = await query(entityListScript);
      entityList.forEach(async item => {
        if (!entityMaster.includes(parseInt(item.entityid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid Entity'
          ELSE CONCAT(remarks, ',Invalid Entity') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE entityname = $1;`,
            [item.entityname],
          );
          dataerror = true;
        }
      });
      const DUListScript = uniqueDUScript();
      const DUList = await query(DUListScript);
      DUList.forEach(async item => {
        if (!duMaster.includes(parseInt(item.duid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid DU'
          ELSE CONCAT(remarks, ',Invalid DU') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE duname = $1;`,
            [item.duname],
          );
          dataerror = true;
        }
      });
      const customerListScript = uniqueCustomerScript();
      const customerList = await query(customerListScript);
      customerList.forEach(async item => {
        if (!customerMaster.includes(parseInt(item.customerid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid Customer'
          ELSE CONCAT(remarks, ',Invalid Customer') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE customername = $1;`,
            [item.customername],
          );
          dataerror = true;
        }
      });
      const serviceListScript = uniqueServiceScript();
      const serviceList = await query(serviceListScript);
      serviceList.forEach(async item => {
        if (!serviceMaster.includes(parseInt(item.serviceid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid Service'
          ELSE CONCAT(remarks, ',Invalid Service') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE servicename = $1;`,
            [item.servicename],
          );
          dataerror = true;
        }
      });
      const divisionListScript = uniqueDivisionScript();
      const divisionList = await query(divisionListScript);
      divisionList.forEach(async item => {
        if (!divisionMaster.includes(parseInt(item.divisionid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid Division'
          ELSE CONCAT(remarks, ',Invalid Division') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE divisionname = $1;`,
            [item.divisionname],
          );
          dataerror = true;
        }
      });
      const segmentListScript = uniqueSegmentScript();
      const segmentList = await query(segmentListScript);
      segmentList.forEach(async item => {
        if (!segmentMaster.includes(parseInt(item.segmentid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid Segment'
          ELSE CONCAT(remarks, ',Invalid Segment') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE segmentname = $1;`,
            [item.segmentname],
          );
          dataerror = true;
        }
      });
      const countryListScript = uniqueCountryScript();
      const countryList = await query(countryListScript);
      countryList.forEach(async item => {
        if (!countryMaster.includes(parseInt(item.countryid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid Country'
          ELSE CONCAT(remarks, ',Invalid Country') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE countryname = $1;`,
            [item.countryname],
          );
          dataerror = true;
        }
      });
      const verticalListScript = uniqueVerticalScript();
      const verticalList = await query(verticalListScript);
      verticalList.forEach(async item => {
        if (!verticalMaster.includes(parseInt(item.verticalid))) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid Vertical'
          ELSE CONCAT(remarks, ',Invalid Vertical') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE verticalname = $1;`,
            [item.verticalname],
          );
          dataerror = true;
        }
      });
      const cmListScript = uniqueCMScript();
      const cmList = await query(cmListScript);
      cmList.forEach(async item => {
        if (!cmMaster.includes(item.cmempid)) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid cm'
          ELSE CONCAT(remarks, ',Invalid cm') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE cmname = $1;`,
            [item.cmname],
          );
          dataerror = true;
        }
      });
      const kamListScript = uniqueKAMScript();
      const kamList = await query(kamListScript);
      kamList.forEach(async item => {
        if (!kamMaster.includes(item.kamempid)) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'Invalid kam'
          ELSE CONCAT(remarks, ',Invalid kam') END, errortype =
          CASE WHEN errortype IS NULL THEN 'cell error'
          WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
          ELSE errortype END WHERE kamname = $1;`,
            [item.kamname],
          );
          dataerror = true;
        }
      });
      // const currencycodeListScript = uniqueCurrencyCodeScript();
      // const currencycodeList = await query(currencycodeListScript);
      // currencycodeList.forEach(async item => {
      //   if (!currencycodeMaster.includes(parseInt(item.currencyid))) {
      //     await query(
      //       `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
      //     CASE WHEN remarks IS NULL THEN 'Invalid currencycode'
      //     ELSE CONCAT(remarks, ',Invalid currencycode') END, errortype =
      //     CASE WHEN errortype IS NULL THEN 'cell error'
      //     WHEN errortype NOT ILIKE '%cell error%' THEN CONCAT(errortype, ',cell error')
      //     ELSE errortype END WHERE currencycode = $1;`,
      //       [item.currencycode],
      //     );
      //     dataerror = true;
      //   }
      // });

      // check Customer and CM combination
      const getcustomerKAMScript = getCustomerKAMCombinationScript();
      const customerKAMList = await query(getcustomerKAMScript);
      const queryPromises = customerKAMList.map(async item => {
        const count = await query(
          `SELECT COUNT(*) FROM salespmo.trn_kamcustomerrel WHERE customerid = $1 
        AND kamempcode = $2`,
          [item.customerid, item.userid],
        );
        if (count[0].count == 0) {
          await query(
            `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
          CASE WHEN remarks IS NULL THEN 'KAM-Customer Mismatch'
          ELSE CONCAT(remarks, ',KAM-Customer Mismatch') END, errortype =
          CASE WHEN errortype IS NULL THEN 'row error'
          WHEN errortype NOT ILIKE '%row error%' THEN CONCAT(errortype, ',row error')
          ELSE errortype END WHERE customername = $1 AND kamname = $2;`,
            [item.customername, item.kamname],
          );
          return true; // Indicate that an error occurred
        }
        return false; // Indicate that no error occurred
      });

      const results = await Promise.all(queryPromises); // Wait for all query promises to resolve
      rowerror = results.some(result => result); // Check if any error occurred

      if (dataerror || rowerror) {
        resolve('file has error');
      } else {
        const result = await insertPlan(insertedData, createdBy, key, Year);
        if (result) {
          resolve('success');
        } else {
          resolve('file has error');
        }
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const insertPlan = async (insertedData, createdBy, key, Year) => {
  try {
    const response = [];
    let result = false;
    const getTransdataScript = getExistingDataScript();

    const insertBudgetScript = insertBudgetplanUpload();
    const insertTargetScript = insertTargetplanUpload();
    for (const item of insertedData) {
      const parts = item.data.split(',');
      const relid = await query(getTransdataScript, [
        parts[0],
        parts[1],
        parts[2],
        parts[3],
        parts[4],
        parts[5],
        parts[6],
        parts[7],
        parts[8].split('(')[1].split(')')[0],
        parts[9].split('(')[1].split(')')[0],
      ]);
      if (relid.length > 0 && (!item.remarks || item.remarks !== '')) {
        item.relid = relid[0].id;
        response.push('true');
      } else if (relid.length === 0) {
        await query(
          `UPDATE salespmo.trn_temp_kamcustomerrel SET remarks =
        CASE WHEN remarks IS NULL THEN 'Combination Mismatch'
        ELSE CONCAT(remarks, ',Combination Mismatch') END, errortype =
        CASE WHEN errortype IS NULL THEN 'row error'
        WHEN errortype NOT ILIKE '%row error%' THEN CONCAT(errortype, ',row error')
        ELSE errortype END WHERE entityname = $1 AND duname = $2 AND 		
		    customername = $3 AND servicename = $4 AND divisionname = $5 AND
		    segmentname = $6 AND countryname = $7 AND verticalname = $8 AND
		    cmname = $9 AND kamname = $10;`,
          [
            parts[0],
            parts[1],
            parts[2],
            parts[3],
            parts[4],
            parts[5],
            parts[6],
            parts[7],
            parts[8],
            parts[9],
          ],
        );
        response.push('false');
      }
    }
    if (response.includes('false')) {
      result = false;
    } else {
      for (const item of insertedData) {
        // const currencyId = await query(
        //   `SELECT currencyid AS id FROM iquality.Mst_CurrencyMst WHERE currencycode = $1`,
        //   [item.currencycode],
        // );
        if (key === 'Budget') {
          const isExistScript = chechIsExistBudget();
          const isExist = await query(isExistScript, [
            item.relid,
            // currencyId[0].id,
            `${Year}-01-01`,
          ]);
          if (isExist[0].count > 0) {
            const updateScript = updateBudgetPlan();
            await query(updateScript, [
              item.relid,
              // currencyId[0].id,
              `${Year}-01-01`,
              item.aprl,
              item.may,
              item.june,
              item.july,
              item.aug,
              item.sep,
              item.oct,
              item.nov,
              item.dec,
              item.jan,
              item.feb,
              item.march,
              createdBy,
            ]);
          } else {
            await query(insertBudgetScript, [
              item.relid,
              // currencyId[0].id,
              `${Year}-01-01`,
              item.aprl,
              item.may,
              item.june,
              item.july,
              item.aug,
              item.sep,
              item.oct,
              item.nov,
              item.dec,
              item.jan,
              item.feb,
              item.march,
              true,
              createdBy,
            ]);
          }
        } else if (key === 'Target') {
          const isExistScript = chechIsExistTarget();
          const isExist = await query(isExistScript, [
            item.relid,
            // currencyId[0].id,
            `${Year}-01-01`,
          ]);
          if (isExist[0].count > 0) {
            const updateScript = updateTargetPlan();
            await query(updateScript, [
              item.relid,
              // currencyId[0].id,
              `${Year}-01-01`,
              item.aprl,
              item.may,
              item.june,
              item.july,
              item.aug,
              item.sep,
              item.oct,
              item.nov,
              item.dec,
              item.jan,
              item.feb,
              item.march,
              createdBy,
            ]);
          } else {
            await query(insertTargetScript, [
              item.relid,
              // currencyId[0].id,
              `${Year}-01-01`,
              item.aprl,
              item.may,
              item.june,
              item.july,
              item.aug,
              item.sep,
              item.oct,
              item.nov,
              item.dec,
              item.jan,
              item.feb,
              item.march,
              true,
              createdBy,
            ]);
          }
        }
      }
      result = true;
    }
    return result;
  } catch (err) {
    console.log(err);
    return false;
  }
};

export const insertScriptforTempTable = () => {
  // const script = `INSERT INTO salespmo.trn_temp_kamcustomerrel(
  //   entityname, duname, customername, servicename, divisionname, segmentname, countryname,
  //   verticalname, cmname, kamname, currencycode, aprl, may, june, july, aug, sep, oct,
  //   nov, dec, jan, feb, march, created_by, created_time)
  // VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, CURRENT_TIMESTAMP)
  // RETURNING relid;`;
  const script = `INSERT INTO salespmo.trn_temp_kamcustomerrel(
    entityname, duname, customername, servicename, divisionname, segmentname, countryname,
    verticalname, cmname, kamname, aprl, may, june, july, aug, sep, oct, 
    nov, dec, jan, feb, march, created_by, created_time)
  VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, CURRENT_TIMESTAMP)
  RETURNING relid;`;
  return script;
};

export const delTempTableData = () => {
  const script = `DELETE FROM salespmo.trn_temp_kamcustomerrel;`;
  return script;
};

export const getTempTableData = () => {
  // const script = `SELECT relid,CONCAT(entityname,',',duname,',',customername,',',servicename,
  // ',',divisionname,',',segmentname,',',countryname,',',verticalname,',',
  //  cmname,',',kamname,',',currencycode) AS data, remarks, currencycode,
  //  aprl, may, june, july, aug, sep, oct, nov, dec, jan, feb, march
  // FROM salespmo.trn_temp_kamcustomerrel order by 1;`;
  const script = `SELECT relid,CONCAT(entityname,',',duname,',',customername,',',servicename,
  ',',divisionname,',',segmentname,',',countryname,',',verticalname,',',
   cmname,',',kamname) AS data, remarks,
   aprl, may, june, july, aug, sep, oct, nov, dec, jan, feb, march
  FROM salespmo.trn_temp_kamcustomerrel order by 1;`;
  return script;
};

export const uniqueEntityScript = () => {
  const script = `SELECT DISTINCT en.entityid::bigint, k.entityname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.mst_entity en ON UPPER(TRIM(en.entityname)) = UPPER(TRIM(k.entityname));`;
  return script;
};

export const uniqueDUScript = () => {
  const script = `SELECT DISTINCT du.duid::bigint, k.duname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.mst_deliveryunit du ON UPPER(TRIM(du.duname)) = UPPER(TRIM(k.duname));`;
  return script;
};

export const uniqueCustomerScript = () => {
  const script = `SELECT DISTINCT cu.customerid::bigint, k.customername FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.mst_customer cu ON UPPER(TRIM(cu.customername)) = UPPER(TRIM(k.customername));`;
  return script;
};

export const uniqueServiceScript = () => {
  const script = `SELECT DISTINCT se.serviceid::bigint, k.servicename FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.wms_mst_service se ON UPPER(TRIM(se.servicename)) = UPPER(TRIM(k.servicename));`;
  return script;
};

export const uniqueDivisionScript = () => {
  const script = `SELECT DISTINCT di.divisionid::bigint, k.divisionname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.org_mst_division di ON UPPER(TRIM(di.division)) = UPPER(TRIM(k.divisionname));`;
  return script;
};

export const uniqueSegmentScript = () => {
  const script = `SELECT DISTINCT seg.segment_id::bigint AS segmentid, k.segmentname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN salespmo.mst_segment seg ON UPPER(TRIM(seg.segment_name)) = UPPER(TRIM(k.segmentname));`;
  return script;
};

export const uniqueCountryScript = () => {
  const script = `SELECT DISTINCT co.countryid::bigint, k.countryname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.geo_mst_country co ON UPPER(TRIM(co.countrycode)) = UPPER(TRIM(k.countryname));`;
  return script;
};

export const uniqueVerticalScript = () => {
  const script = `SELECT DISTINCT ve.verticalid::bigint, k.verticalname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.wms_mst_vertical ve ON UPPER(TRIM(ve.verticalname)) = UPPER(TRIM(k.verticalname));`;
  return script;
};

export const uniqueCMScript = () => {
  const script = `SELECT DISTINCT u.userid AS cmempid, k.cmname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.wms_user u ON UPPER(TRIM(CONCAT(u.username, ' (',u.userid,')'))) = UPPER(TRIM(k.cmname));`;
  return script;
};

export const uniqueKAMScript = () => {
  const script = `SELECT DISTINCT u.userid AS kamempid, k.kamname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.wms_user u ON UPPER(TRIM(CONCAT(u.username, ' (',u.userid,')'))) = UPPER(TRIM(k.kamname));`;
  return script;
};

export const uniqueCurrencyCodeScript = () => {
  const script = `SELECT DISTINCT cu.Currencyid::bigint, k.currencycode FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN iquality.Mst_CurrencyMst cu ON UPPER(TRIM(cu.CurrencyCode)) = UPPER(TRIM(k.currencycode));`;
  return script;
};

export const getCustomerKAMCombinationScript = () => {
  const script = `SELECT DISTINCT cu.customerid::bigint, k.customername, u.userid, k.kamname FROM salespmo.trn_temp_kamcustomerrel k
  LEFT JOIN public.mst_customer cu ON UPPER(TRIM(cu.customername)) = UPPER(TRIM(k.customername))
  LEFT JOIN public.wms_user u ON UPPER(TRIM(CONCAT(u.username, ' (',u.userid,')'))) = UPPER(TRIM(k.kamname));`;
  return script;
};

export const getExistingDataScript = () => {
  const script = `SELECT kr.kamcustomerrelid AS id
  FROM salespmo.trn_kamcustomerrel kr
  WHERE kr.isactive = true AND 
  kr.statusid = (SELECT statusid from salespmo.mst_status WHERE status_alias = 'ACTIVE' AND isactive = true) AND
  kr.entityid = (SELECT entityid from public.mst_entity WHERE entityname = $1 AND isactive = true) AND
  kr.duid = (SELECT duid from public.mst_deliveryunit WHERE duname = $2 AND isactive = true) AND
  kr.customerid = (SELECT customerid from public.mst_customer WHERE customername = $3 AND isactive = true) AND
  kr.serviceid = (SELECT serviceid from public.wms_mst_service WHERE servicename = $4 AND isactive = true) AND
  kr.divisionid = (SELECT divisionid from public.org_mst_division WHERE division = $5 AND isactive = true) AND
  kr.segmentid = (SELECT segment_id from salespmo.mst_segment WHERE segment_name = $6 AND is_active = true) AND
  kr.countryid = (SELECT countryid from public.geo_mst_country WHERE countrycode = $7 AND isactive = true) AND
  kr.verticalid = (SELECT verticalid from public.wms_mst_vertical WHERE verticalname = $8 AND isactive = true) AND
  kr.cmempcode = $9 AND kr.kamempcode = $10;`;
  return script;
};

export const insertBudgetplanUpload = () => {
  // const script = `INSERT INTO salespmo.trn_budgetplan (kamcustomerrelid, currencyid, year, april_value, may_value,
  //   june_value, july_value, august_value, september_value, october_value, november_value, december_value,
  //   january_value, february_value, march_value, isactive, created_by, created_time, updated_by, updated_time) VALUES
  //   ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,CURRENT_TIMESTAMP,$17,CURRENT_TIMESTAMP);`;
  const script = `INSERT INTO salespmo.trn_budgetplan (kamcustomerrelid, year, april_value, may_value,
  june_value, july_value, august_value, september_value, october_value, november_value, december_value,
  january_value, february_value, march_value, isactive, created_by, created_time, updated_by, updated_time) VALUES 
  ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,CURRENT_TIMESTAMP,$16,CURRENT_TIMESTAMP);`;
  return script;
};

export const insertTargetplanUpload = () => {
  // const script = `INSERT INTO salespmo.trn_targetplan (kamcustomerrelid, currencyid, year, april_value, may_value,
  //   june_value, july_value, august_value, september_value, october_value, november_value, december_value,
  //   january_value, february_value, march_value, isactive, created_by, created_time, updated_by, updated_time) VALUES
  //   ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,CURRENT_TIMESTAMP,$17,CURRENT_TIMESTAMP);`;
  const script = `INSERT INTO salespmo.trn_targetplan (kamcustomerrelid, year, april_value, may_value,
  june_value, july_value, august_value, september_value, october_value, november_value, december_value,
  january_value, february_value, march_value, isactive, created_by, created_time, updated_by, updated_time) VALUES 
  ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,CURRENT_TIMESTAMP,$16,CURRENT_TIMESTAMP);`;
  return script;
};

export const getExceptiondata = () => {
  const script = `SELECT * FROM salespmo.trn_temp_kamcustomerrel order by 1;`;
  return script;
};

export const getExchangeCurrencyandRate = () => {
  const script = `SELECT Coalesce(e.currencyid,c.currencyid) AS currencyid,c.currencycode,c.currencytext,e.year,e.exchangerate 
    FROM iquality.Mst_CurrencyMst c
    LEFT JOIN public.currency_exchange_rates e ON e.currencyid = c.currencyid AND e.isactive = true AND e.year = $1
    WHERE c.isactive = true	ORDER BY e.currencyid;`;
  return script;
};

export const checkIfExistExchangeRate = () => {
  const script = `SELECT * FROM public.currency_exchange_rates WHERE currencyid = $1 AND year = $2 AND isactive = true;`;
  return script;
};

export const InsertCurrencyExchangeRate = () => {
  const script = `INSERT INTO public.currency_exchange_rates (currencyid,year,exchangerate,isactive,created_by,created_time) 
  VALUES ($1,$2,$3,$4,$5,CURRENT_TIMESTAMP);`;
  return script;
};

export const UpdateCurrencyExchangeRate = () => {
  const script = `UPDATE public.currency_exchange_rates SET exchangerate = $1, updated_by = $2, updated_time = CURRENT_TIMESTAMP
  WHERE currencyid = $3 AND year = $4 AND isactive = true;`;
  return script;
};

export const getBudgetFinancialYear = () => {
  const script = `SELECT EXTRACT(YEAR FROM year) AS year FROM salespmo.trn_budgetplan
  UNION
  SELECT EXTRACT(YEAR FROM CURRENT_DATE);`;
  return script;
};

export const getTargetFinancialYear = () => {
  const script = `SELECT EXTRACT(YEAR FROM year) AS year FROM salespmo.trn_targetplan
  UNION
  SELECT EXTRACT(YEAR FROM CURRENT_DATE);`;
  return script;
};

export const getBudgetPlanDetails = () => {
  const script = `SELECT b.updated_by, u.username, 
    DATE_TRUNC('day', b.updated_time) AS updated_date, -- Truncate timestamp to date
    LEFT(LEFT(u.username, 1), 2) AS shortname
  --  b.updated_time, LEFT(CASE 
  --      WHEN POSITION(' ' IN u.username) = 0 THEN LEFT(u.username, 1)
  --      ELSE STRING_AGG(SUBSTRING(word, 1, 1), '') 
  --    END, 2) AS shortname
    FROM salespmo.trn_budgetplan b
    LEFT JOIN public.wms_user u ON u.userid = b.updated_by
    --  CROSS JOIN unnest(string_to_array(u.username, ' ')) AS word
    WHERE EXTRACT(YEAR FROM b.year) = $1
    GROUP BY b.updated_by, u.username, updated_date ORDER BY updated_date DESC;`;
  return script;
};

export const getTargetPlanDetails = () => {
  const script = `SELECT t.updated_by, u.username,
  DATE_TRUNC('day', t.updated_time) AS updated_date, -- Truncate timestamp to date
    LEFT(LEFT(u.username, 1), 2) AS shortname 
 --  t.updated_time, LEFT(CASE 
 --        WHEN POSITION(' ' IN u.username) = 0 THEN LEFT(u.username, 1)
 --        ELSE STRING_AGG(SUBSTRING(word, 1, 1), '') 
 --        END, 2) AS shortname
    FROM salespmo.trn_targetplan t
    LEFT JOIN public.wms_user u ON u.userid = t.updated_by
   --   CROSS JOIN unnest(string_to_array(u.username, ' ')) AS word
    WHERE EXTRACT(YEAR FROM t.year) = $1
    GROUP BY t.updated_by, u.username, updated_date ORDER BY updated_date DESC;`;
  return script;
};

export const getBudgetPlan = () => {
  const script = `SELECT * FROM salespmo.plan_budget_report_view WHERE year = $1 AND (
        (updated_by = $2 AND DATE(updated_time) = $3)
     OR (created_by = $2 AND DATE(created_time) = $3));`;
  return script;
};

export const getTargetPlan = () => {
  const script = `SELECT * FROM salespmo.plan_target_report_view WHERE year = $1 AND (
        (updated_by = $2 AND DATE(updated_time) = $3)
     OR (created_by = $2 AND DATE(created_time) = $3));`;
  return script;
};

export const checkIfYearIsExist = () => {
  const script = `SELECT 1 FROM salespmo.mst_financialyear WHERE fyear = $1;`;
  return script;
};

export const insertFYear = () => {
  const script = `INSERT INTO salespmo.mst_financialyear (fyear,isactive,created_by,created_time,updated_by,updated_time)
      VALUES ($1,$2,$3,CURRENT_TIMESTAMP,$3,CURRENT_TIMESTAMP);`;
  return script;
};

export const getFYear = () => {
  const script = `SELECT fyear AS year FROM salespmo.mst_financialyear WHERE isactive = true;`;
  return script;
};

const chechIsExistBudget = () => {
  // const script = `SELECT COUNT(*) FROM salespmo.trn_budgetplan WHERE kamcustomerrelid = $1 AND currencyid = $2 AND
  //                 year = $3 AND isactive = true`;
  const script = `SELECT COUNT(*) FROM salespmo.trn_budgetplan WHERE kamcustomerrelid = $1 AND year = $2 AND isactive = true`;
  return script;
};

const chechIsExistTarget = () => {
  const script = `SELECT COUNT(*) FROM salespmo.trn_targetplan WHERE kamcustomerrelid = $1 AND currencyid = $2 AND 
                  year = $3 AND isactive = true`;
  return script;
};

const updateBudgetPlan = () => {
  // const script = `UPDATE salespmo.trn_budgetplan SET april_value = $4, may_value = $5, june_value = $6,
  //   july_value = $7, august_value = $8, september_value = $9, october_value = $10, november_value = $11,
  //   december_value = $12, january_value = $13, february_value = $14, march_value = $15,
  //   updated_by = $16, updated_time = CURRENT_TIMESTAMP
  //   WHERE kamcustomerrelid = $1 AND currencyid = $2 AND year = $3 AND isactive = true`;
  const script = `UPDATE salespmo.trn_budgetplan SET april_value = $3, may_value = $4, june_value = $5, 
    july_value = $6, august_value = $7, september_value = $8, october_value = $9, november_value = $10,
    december_value = $11, january_value = $12, february_value = $13, march_value = $14,
    updated_by = $15, updated_time = CURRENT_TIMESTAMP
    WHERE kamcustomerrelid = $1 AND year = $2 AND isactive = true`;
  return script;
};

const updateTargetPlan = () => {
  // const script = `UPDATE salespmo.trn_targetplan SET april_value = $4, may_value = $5, june_value = $6,
  //   july_value = $7, august_value = $8, september_value = $9, october_value = $10, november_value = $11,
  //   december_value = $12, january_value = $13, february_value = $14, march_value = $15,
  //   updated_by = $16, updated_time = CURRENT_TIMESTAMP
  //   WHERE kamcustomerrelid = $1 AND currencyid = $2 AND year = $3 AND isactive = true`;
  const script = `UPDATE salespmo.trn_targetplan SET april_value = $3, may_value = $4, june_value = $5, 
    july_value = $6, august_value = $7, september_value = $8, october_value = $9, november_value = $10,
    december_value = $11, january_value = $12, february_value = $13, march_value = $14,
    updated_by = $15, updated_time = CURRENT_TIMESTAMP
    WHERE kamcustomerrelid = $1 AND year = $2 AND isactive = true`;
  return script;
};
