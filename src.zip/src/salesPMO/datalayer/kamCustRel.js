import { query } from '../../database/postgres.js';

export const insertKAMCustomerRelScript = type => {
  const script = `INSERT INTO salespmo.trn_kamcustomerrel(
    Cmempcode,
    customerId,
    countryId,
    duid,
    divisionid,
    verticalid,
    serviceid,
    KAMempcode,
    entityID,
    isactive,
    remarks,
    created_by,
    effective_from,
    segmentId,
    updated_by,
    kamheadempcode,
    statusid
)
VALUES (
    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $12, $15,
    (select ms.statusid from salespmo.mst_status ms 
      where ms.statuscode = ${
        type == 'A' ? `'V'` : `'P'`
      } and ms.isactive = true)) 
    RETURNING kamcustomerrelid;`;
  return script;
};

export const checkKAMCustomerRelScript = () => {
  const script = `SELECT 1
      FROM salespmo.trn_kamcustomerrel
      WHERE customerId = $1
        AND countryId = $2
        AND duid = $3
        AND divisionid = $4
        AND verticalid = $5
        AND serviceid = $6`;
  return script;
};

export const updateKAMCustomerRelScript = reqcode => {
  let script = '';
  if (reqcode == 'NR') {
    script = `UPDATE salespmo.trn_kamcustomerrel SET 
      statusid = (select ms.statusid from salespmo.mst_status ms where ms.statuscode = 'V' and ms.isactive = true) 
    WHERE kamcustomerrelid=$1;`;
  } else if (reqcode == 'CR') {
    script = `UPDATE salespmo.trn_kamcustomerrel
    SET 
      cmempcode=$17,
      customerid=$2,
      countryid=$3,
      duid=$4, 
      divisionid=$5,
      verticalid=$6,
      serviceid=$7,
      kamempcode=$8,
      entityid=$9,
      isactive=$10,
      remarks=$11,
      effective_from=$12,
      segmentid=$13,
      updated_by=$14,  
      statusid = (select ms.statusid from salespmo.mst_status ms where ms.statuscode = 'V' and ms.isactive = true),
      kamheadempcode=$15,
      approvedempcode=$16
      WHERE kamcustomerrelid=$1;`;
  }
  return script;
};

export const insertKAMCustomerRelPendingScript = () => {
  const script = `INSERT INTO salespmo.trn_kamcustomerrel_pendingqueue(
    Cmempcode,
    customerId,
    countryId,
    duid,
    divisionid,
    verticalid,
    serviceid,
    kamempcode,
    entityid,
    isactive,
    remarks,
    created_by,
    effective_from,
    segmentid,
    updated_by,
    statusid,
    request_type_id,
    kamcustomerrelid,
    approvedempcode,
    new_effective_from,
    new_kamempcode,
    new_cmempcode,
    kamheadempcode
  )
  VALUES(
    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $12,
    (select ms.statusid from salespmo.mst_status ms  where ms.statuscode = 'P' and ms.isactive = true),
    (SELECT request_type_id FROM salespmo.mst_request_type WHERE reqcode = 'NR' and isactive = true),
  $15, $16, $17, $18, $19, $20);`;
  return script;
};

export const insertKAMActiveRecModifyScript = () => {
  const script = `INSERT INTO salespmo.trn_kamcustomerrel_pendingqueue(
    kamcustomerrelid,
    duid,
    customerId,
    countryId,
    divisionid,
    verticalid,
    serviceid,
    Cmempcode,
    kamheadempcode,
    new_kamempcode,
    new_cmempcode,
    entityid,
    approvedempcode,
    effective_from,
    new_effective_from,
    remarks,
    created_by,
    segmentid,
    kamempcode,
    statusid,
    request_type_id,
    updated_by,
    new_kamheadempcode
  )
  VALUES(
    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19,
    (select ms.statusid from salespmo.mst_status ms where ms.statuscode = 'P' and ms.isactive = true),
    (SELECT request_type_id FROM salespmo.mst_request_type WHERE reqcode = 'CR' and isactive = true),
        $17, $20) RETURNING * ; `;
  return script;
};

export const insertKAMRelPendingQueueHistory = () => {
  const script = `INSERT INTO salespmo.trn_kamcustomerrel_pendingqueue_history
  (kamcustomerrelid, 
old_verticalid, 
new_verticalid,
old_serviceid, 
new_serviceid, 
old_kamempcode, 
new_kamempcode, 
old_cmempcode, 
new_cmempcode, 
old_kamheadempcode, 
new_kamheadempcode, 
old_new_kamempcode, 
new_new_kamempcode, 
old_new_cmempcode, 
new_new_cmempcode, 
old_approvedempcode, 
new_approvedempcode, 
old_effective_from, 
new_effective_from, 
old_new_effective_from, 
new_new_effective_from, 
old_remarks, 
new_remarks, 
old_created_by, 
new_created_by, 
old_created_time, 
new_created_time, 
old_updated_by, 
new_updated_by, 
old_updated_time, 
new_updated_time, 
old_statusid, 
new_statusid, 
old_request_type_id, 
new_request_type_id, 
old_rejection_comment, 
new_rejection_comment, 
old_change_reason, 
new_change_reason, 
change_time, 
changed_by, 
updated_remarks,
queueid)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,CURRENT_TIMESTAMP,$40,$41,$42);`;
  return script;
};

export const getKAMDetailsByIdScript = rectype => {
  let script = '';
  if (rectype == 'P') {
    script = `SELECT CRP.queueid, 'P' as rectype, CRP.kamcustomerrelid, CRP.duid, CRP.customerid, CRP.countryid, CRP.divisionid, CRP.verticalid, 
    CRP.serviceid, CRP.kamempcode, CRP.cmempcode, CRP.kamheadempcode, CRP.entityid, CRP.approvedempcode, CRP.effective_from, CRP.remarks, 
    CRP.segmentid, CRP.statusid, CRP.isactive, CRP.created_by, CRP.created_time, CRP.updated_by, CRP.updated_time, CRP.new_kamempcode, 
    CRP.new_kamheadempcode, CRP.new_cmempcode, CRP.new_effective_from, ms.statusname as status
    FROM salespmo.trn_kamcustomerrel_pendingqueue CRP 
    left join salespmo.mst_status ms on ms.statusid = CRP.statusid
    where queueid = $1; `;
  } else {
    script = `SELECT kamcustomerrelid, 'K' as rectype, duid, customerid, countryid, divisionid, verticalid, serviceid, kamempcode, cmempcode, kamheadempcode, entityid, approvedempcode, effective_from, remarks, segmentid, statusid, isactive, created_by, created_time, updated_by, updated_time
   FROM salespmo.trn_kamcustomerrel where kamcustomerrelid = $1; `;
  }
  return script;
};

export const updateKAMCustomerRelById = async (
  KamCustomerRelId,
  Cmempcode,
  customerId,
  countryId,
  divisionid,
  verticalcode,
  serviceid,
  KAMempcode,
  duid,
  entityID,
  isactive,
  updated_by,
) => {
  const result = await query(
    `UPDATE salespmo.Trn_KAMCustomerRel
     SET Cmempcode = $2,
    customerId = $3,
    countryId = $4,
    divisionid = $5,
    verticalid = $6,
    serviceid = $7,
    KAMempcode = $8,
    duid = $9,
    entityID = $10,
    isactive = $11,
    updated_by = $12,
    updated_time = current_timestamp
     WHERE KamCustomerRelId = $1; `,
    [
      KamCustomerRelId,
      Cmempcode,
      customerId,
      countryId,
      divisionid,
      verticalcode,
      serviceid,
      KAMempcode,
      duid,
      entityID,
      isactive,
      updated_by,
    ],
  );
  return result;
};

export const updateKAMPendingByIdScript = () => {
  const script = `
  UPDATE
  salespmo.trn_kamcustomerrel_pendingqueue
  SET
  kamcustomerrelid = $2,
    duid = $3,
    customerid = $4,
    countryid = $5,
    divisionid = $6,
    verticalid = $7,
    serviceid = $8,
    cmempcode = $9,
    kamheadempcode = $10,
    new_kamempcode = $11,
    new_cmempcode = $12,
    entityid = $13,
    approvedempcode = $14,
    effective_from = $15,
    new_effective_from = $16,
    remarks = $17,
    isactive = true,
    created_time = CURRENT_TIMESTAMP,
    updated_by = $18,
    updated_time = CURRENT_TIMESTAMP,
    segmentid = $19,
    kamempcode = $20,
    new_kamheadempcode = $21,
    statusid = (
      select ms.statusid from salespmo.mst_status ms where ms.statuscode = 'P' and ms.isactive = true
  ),
request_type_id = (
  SELECT request_type_id FROM salespmo.mst_request_type WHERE reqcode = 'CR' and isactive = true
  )
WHERE
queueid = $1 RETURNING *;
`;
  return script;
};

export const getKAMCustomerRel = () => {
  const script = `select  ROW_NUMBER() OVER(ORDER BY Q.customerId DESC) AS serial,
  Q.* , case when rectype = 'K' then kamcustomerrelid else queueid END as targetid from(
    select
    CR.kamcustomerrelid as kamcustomerrelid,
    null as queueid,
    CR.Cmempcode as clientmanager,
    CM.username || ' (' || CR.Cmempcode || ')' AS clientmanagername,
    CR.customerId as customerID,
    C.customername as customername,
    CR.countryId as countryId,
    CY.countrycode as countryname,
    CR.divisionid as divisionid,
    DI.division as divisionname,
    CR.effective_from as effectivefrom,
    CR.verticalid as verticalid,
    VR.verticalname as verticalname,
    CR.serviceid as serviceid,
    S.servicename as servicename,
    CR.KAMempcode as KAMcode,
    CR.kamheadempcode as kamhcode,
    KH.username || ' (' || CR.kamheadempcode|| ')' AS kamhname,
    K.username || ' (' || CR.KAMempcode || ')' AS KAMname,
    CR.duid as duid,
    D.Duname as duname,
    CR.entityID as entityID,
    e.entityname as entityname,
    CR.segmentid as segmentid,
    CR.remarks as remarks,
    ms.segment_name as segmentname,
    ms2.statusname as status,
    ms2.statuscolor as statusclass,
    ms2.statuscode as statuscode,
    'active' as requesttype,
    '2' as requesttypeid,
    'K' as rectype,
    'action' as action,
    null as updatedTime,
    false as "isSelected"
    FROM salespmo.Trn_KAMCustomerRel CR
    LEFT JOIN public.mst_customer C ON CR.customerId = C.customerId
    LEFT JOIN public.geo_mst_country CY ON CR.countryId = CY.countryId
    LEFT JOIN public.mst_deliveryunit D ON CR.duid = D.duid
    LEFT JOIN public.org_mst_division DI ON CR.divisionid = DI.divisionid
    LEFT JOIN public.wms_mst_service S ON CR.serviceid = S.serviceid
    LEFT JOIN public.wms_user CM ON CR.Cmempcode = cm.userid
    LEFT JOIN public.wms_user K ON CR.KAMempcode = K.userid
    LEFT JOIN public.wms_user KH ON CR.kamheadempcode = KH.userid
    LEFT JOIN public.mst_entity e ON CR.entityID = e.entityID
    LEFT JOIN public.wms_mst_vertical VR ON VR.verticalid = CR.verticalid
    left join salespmo.mst_segment ms on CR.segmentid = ms.segment_id 
    left join salespmo.mst_status ms2 on ms2.statusid = CR.statusid
    where CR.isactive is true and CR.statusid = (select statusid from salespmo.mst_status where statuscode = 'V')
    union all
select
CRP.kamcustomerrelid as kamcustomerrelid,
  CRP.queueid as queueid,
  CRP.Cmempcode as clientmanager,
  COALESCE( NCM.username || ' (' || CRP.new_cmempcode || ')', CM.username || ' (' || CRP.Cmempcode || ')') AS clientmanagername,
  CRP.customerId as customerID,
  C.customername as customername,
  CRP.countryId as countryId,
  CY.countrycode as countryname, 
  CRP.divisionid as divisionid,
  DI.division as divisionname,
  CRP.effective_from as effectivefrom,
  CRP.verticalid as verticalid,
  VR.verticalname as verticalname,
  CRP.serviceid as serviceid,
  S.servicename as servicename,
  CRP.KAMempcode as KAMcode,
  CRP.kamheadempcode as kamhcode,
  COALESCE( NKH.username || ' (' || CRP.kamheadempcode || ')', KH.username || ' (' || CRP.kamheadempcode|| ')') AS kamhname,
   COALESCE( NK.username || ' (' || CRP.new_kamempcode || ')', K.username || ' (' || CRP.KAMempcode || ')') AS KAMname,
  CRP.duid as duid,
  D.Duname as duname,
  CRP.entityID as entityID,
  e.entityname as entityname,
  CRP.segmentid as segmentid,
  CRP.remarks as remarks,
  ms.segment_name as segmentname,
  ms2.statusname as status,
  ms2.statuscolor as statusclass,
  ms2.statuscode as statuscode,
  rt.reqname as requesttype,
  rt.request_type_id as requesttypeid,
  'P' as rectype,
    case when statuscode = 'R' then 'action'
      else ''
    end as action,
    CRP.updated_time as updatedTime,
  false as "isSelected"
  FROM salespmo.trn_kamcustomerrel_pendingqueue CRP
  LEFT JOIN public.mst_customer C ON CRP.customerId = C.customerId
  LEFT JOIN public.geo_mst_country CY ON CRP.countryId = CY.countryId
  LEFT JOIN public.mst_deliveryunit D ON CRP.duid = D.duid
  LEFT JOIN public.org_mst_division DI ON CRP.divisionid = DI.divisionid
  LEFT JOIN public.wms_mst_service S ON CRP.serviceid = S.serviceid
  LEFT JOIN public.wms_user CM ON CRP.Cmempcode = cm.userid
  LEFT JOIN public.wms_user K ON CRP.KAMempcode = K.userid
  LEFT JOIN public.wms_user KH ON CRP.kamheadempcode = KH.userid
  LEFT JOIN public.wms_user NCM ON CRP.new_cmempcode = NCM.userid
  LEFT JOIN public.wms_user NK ON CRP.new_kamempcode = NK.userid
  LEFT JOIN public.wms_user NKH ON CRP.new_kamheadempcode = NKH.userid
  LEFT JOIN public.mst_entity e ON CRP.entityID = e.entityID
  LEFT JOIN public.wms_mst_vertical VR ON VR.verticalid = CRP.verticalid
  left join salespmo.mst_segment ms on CRP.segmentid = ms.segment_id 
  left join salespmo.mst_status ms2 on ms2.statusid = CRP.statusid
  left join salespmo.mst_request_type rt on rt.request_type_id = CRP.request_type_id
   where CRP.isactive = true and 
   CRP.statusid in (select statusid from salespmo.mst_status where statuscode in ('P', 'R')) and 
   (
        (CRP.statusid IN (
            SELECT statusid 
            FROM salespmo.mst_status 
            WHERE statuscode = 'P'
        ))
        OR
        (CRP.statusid IN (
            SELECT statusid 
            FROM salespmo.mst_status 
            WHERE statuscode = 'R'
        ) AND CRP.updated_time >= current_date - interval '30 days')
    )) 
   as Q where ($1 = '' OR Q.customername ILIKE '%' || $1 || '%' OR Q.KAMname ILIKE '%' || $1 || '%') order by Q.updatedTime
  `;
  return script;
};

export const getKAMChangeTableDataScript = filterData => {
  const { status, type } = filterData;
  let statusFilter = '';
  let typeFilter = '';
  if (status === 'ALL') {
    statusFilter = `'P', 'R','A'`;
  } else {
    statusFilter = `'${status}'`;
  }
  if (type === 'ALL') {
    typeFilter = `'CR', 'NR'`;
  } else {
    typeFilter = `'${type}'`;
  }
  const script = `
select
ROW_NUMBER() OVER(ORDER BY CRP.customerId DESC) AS serial,
  CRP.queueid as targetid,
  CRP.kamcustomerrelid as kamcustomerrelid,
  CRP.Cmempcode as clientmanager,
  CM.username as clientmanagername,
  CRP.customerId as customerID,
  C.customername as customername,
  CRP.countryId as countryId,
  CY.countryname as countryname,
  CRP.divisionid as divisionid,
  DI.division as divisionname,
  CRP.verticalid as verticalid,
  CRP.serviceid as serviceid,
  CRP.effective_from as effectiveon,
  CRP.updated_time as actionedon,
  S.servicename as servicename,
  CRP.KAMempcode as KAM,
  K.username as KAMname,
  KH.username as kamhname,
  CRP.kamheadempcode as kamhcode,
  CRP.duid as duid,
  D.Duname as duname,
  CRP.entityID as entityID,
  e.entityname as entityname,
  CRP.segmentid as segmentid,
  ms.segment_name as segmentname,
  ms2.statusname as status,
  ms2.statuscolor as statusclass,
  ms2.statuscode as statuscode,
  rt.request_type_id as changetypeid,
  rt.reqcode as reqcode,
  rt.reqname as type,
  'P' as rectype,
  'action' as action,
  false as "isSelected"
      FROM salespmo.trn_kamcustomerrel_pendingqueue CRP
      LEFT JOIN public.mst_customer C ON CRP.customerId = C.customerId
      LEFT JOIN public.geo_mst_country CY ON CRP.countryId = CY.countryId
      LEFT JOIN public.mst_deliveryunit D ON CRP.duid = D.duid
      LEFT JOIN public.org_mst_division DI ON CRP.divisionid = DI.divisionid
      LEFT JOIN public.wms_mst_service S ON CRP.serviceid = S.serviceid
      LEFT JOIN public.wms_user CM ON CRP.Cmempcode = cm.userid
      LEFT JOIN public.wms_user K ON CRP.KAMempcode = K.userid
      LEFT JOIN public.wms_user KH ON CRP.kamheadempcode = KH.userid
      LEFT JOIN public.mst_entity e ON CRP.entityID = e.entityID
      left join salespmo.mst_segment ms on CRP.segmentid = ms.segment_id 
      left join salespmo.mst_status ms2 on ms2.statusid = CRP.statusid
      left join salespmo.mst_request_type rt on rt.request_type_id = CRP.request_type_id
     where CRP.isactive = true and
CRP.statusid in (select statusid from salespmo.mst_status where statuscode in (${statusFilter}))
     and CRP.request_type_id in (select request_type_id from salespmo.mst_request_type where reqcode in (${typeFilter}))
`;
  return script;
};

export const approveOrRejectKAMChangeScript = type => {
  const script = `UPDATE salespmo.trn_kamcustomerrel_pendingqueue 
  SET
    updated_by = $3,
    updated_time = CURRENT_TIMESTAMP,
    statusid = (select statusid from salespmo.mst_status where statuscode = '${type}'),
    rejection_comment = $2
  WHERE queueid = $1 RETURNING *; `;
  return script;
};

export const updateKAMCMPendingReassignScript = () => {
  const script = `UPDATE salespmo.trn_kamcustomerrel_pendingqueue 
  SET
    kamempcode = $2,
    cmempcode = $3,
    effective_from = $4,
    remarks = $5,
    updated_by = $6,
    updated_time = CURRENT_TIMESTAMP,
    statusid = (select ms.statusid from salespmo.mst_status ms where ms.statuscode = 'P' and ms.isactive = true),
    request_type_id = (SELECT request_type_id FROM salespmo.mst_request_type WHERE reqcode = 'CR' and isactive = true)
  WHERE queueid = $1`;
  return script;
};
export const updateKAMPendingReassignScript = () => {
  const script = `UPDATE salespmo.trn_kamcustomerrel_pendingqueue 
  SET
    kamempcode = $2,
    effective_from = $3,
    remarks = $4,
    updated_by = $5,
    updated_time = CURRENT_TIMESTAMP,
    statusid = (select ms.statusid from salespmo.mst_status ms where ms.statuscode = 'P' and ms.isactive = true),
    request_type_id = (SELECT request_type_id FROM salespmo.mst_request_type WHERE reqcode = 'CR' and isactive = true)
  WHERE queueid = $1`;
  return script;
};

export const updateCMPendingReassignScript = () => {
  const script = `UPDATE salespmo.trn_kamcustomerrel_pendingqueue 
  SET
    cmempcode = $2,
    cmempcode = $3,
    remarks = $4,
    updated_by = $5,
    updated_time = CURRENT_TIMESTAMP,
    statusid = (select ms.statusid from salespmo.mst_status ms where ms.statuscode = 'P' and ms.isactive = true),
    request_type_id = (SELECT request_type_id FROM salespmo.mst_request_type WHERE reqcode = 'CR' and isactive = true)
  WHERE queueid = $1`;
  return script;
};

export const insertKAMPendingReassignScript = () => {
  const script = `
  INSERT INTO salespmo.trn_kamcustomerrel_pendingqueue (
    kamcustomerrelid,
    duid,
    customerid,
    countryid,
    divisionid,
    verticalid,
    serviceid,
    kamempcode,
    cmempcode,
    kamheadempcode,
    entityid,
    approvedempcode,
    effective_from,
    remarks,
    segmentid,
    statusid,
    created_by,
    updated_by,
    request_type_id,
    rejection_comment,
    new_effective_from,
    new_kamempcode,
    new_cmempcode,
    change_reason
  )
  SELECT 
    kamcustomerrelid, 
    duid, 
    customerid, 
    countryid, 
    divisionid, 
    verticalid, 
    serviceid, 
    kamempcode, 
    cmempcode, 
    kamheadempcode, 
    entityid, 
    approvedempcode, 
    effective_from, 
    $5, 
    segmentid, 
    (SELECT ms.statusid FROM salespmo.mst_status ms WHERE ms.statuscode = 'P' AND ms.isactive = TRUE),
    created_by, 
    $6, 
    (SELECT request_type_id FROM salespmo.mst_request_type WHERE reqcode = 'CR' AND isactive = TRUE),
    NULL,  
    $4, 
    $2, 
    $3, 
    $5
  FROM salespmo.trn_kamcustomerrel 
  WHERE kamcustomerrelid = $1 RETURNING *;`;
  return script;
};

export const getKAMPendingQueueHistoryScript = () => {
  const script = `
  SELECT
    TO_CHAR(change_time, 'DD') as date,
    STRING_AGG(DISTINCT TO_CHAR(change_time, 'Mon') || ' ' || TO_CHAR(change_time, 'YYYY'), '') as month,
    status,
    statuscolor,
    json_agg(
          jsonb_build_object(
              'remarks', remarks,
              'fromdata', fromdata,
              'todata', todata
          )
      ) as history,
      new_updated_by as changed_by,
      change_time as change_time,  
      new_new_effective_from as new_new_effective_from,
      old_effective_from as old_effective_from,
      new_rejection_comment as comment
FROM (
    SELECT
        historyid,
        CASE
            WHEN remarks = 'verticalid' THEN  'Vertical'
            WHEN remarks = 'serviceid' THEN 'Service'
            WHEN remarks = 'kamempcode' THEN 'KAM'
            WHEN remarks = 'cmempcode' THEN 'Client Manager'
            WHEN remarks = 'kamheadempcode' THEN 'KAM Head'
            WHEN remarks = 'new_kamempcode' THEN 'New KAM'
            WHEN remarks = 'new_cmempcode' THEN 'New Client Manager'
            WHEN remarks = 'statusid' THEN 'Status'
            WHEN remarks = 'request_type_id' THEN 'Request'
            WHEN remarks = 'effective_from' THEN 'Effective Date'
            WHEN remarks = 'new_effective_from' THEN 'New Effective Date'
            WHEN remarks = 'remarks' THEN 'Reason'
        END AS remarks, 
        CASE
            WHEN remarks = 'verticalid' THEN CAST((select VR.verticalname from public.wms_mst_vertical VR where VR.verticalid = old_verticalid) AS TEXT)
            WHEN remarks = 'serviceid' THEN CAST((select S.servicename from public.wms_mst_service S WHERE S.serviceid = old_serviceid) AS TEXT)
            WHEN remarks = 'kamempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = old_kamempcode )  AS TEXT)
            WHEN remarks = 'cmempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = old_cmempcode) AS TEXT)
            WHEN remarks = 'kamheadempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = old_kamheadempcode)  AS TEXT)
            WHEN remarks = 'new_kamempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = old_new_kamempcode) AS TEXT)
            WHEN remarks = 'new_cmempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = old_new_cmempcode)  AS TEXT)
            WHEN remarks = 'statusid' THEN CAST((select ms.statusname from salespmo.mst_status ms WHERE ms.statusid = old_statusid) AS TEXT)
            WHEN remarks = 'request_type_id' THEN CAST((select reqname from salespmo.mst_request_type where request_type_id = old_request_type_id) AS TEXT)
            WHEN remarks = 'effective_from' THEN CAST(old_effective_from AS TEXT)
            WHEN remarks = 'new_effective_from' THEN CAST(old_new_effective_from AS TEXT)
            WHEN remarks = 'remarks' THEN CAST(old_remarks AS TEXT)
        END AS fromdata,
         case	
            WHEN remarks = 'verticalid' THEN CAST((select VR.verticalname from public.wms_mst_vertical VR where VR.verticalid = new_verticalid)  AS TEXT)
            WHEN remarks = 'serviceid' THEN CAST((select S.servicename from public.wms_mst_service S WHERE S.serviceid = new_serviceid)  AS TEXT)
            WHEN remarks = 'kamempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = new_kamempcode ) AS TEXT)
            WHEN remarks = 'cmempcode' THEN CAST( (select CM.username from  public.wms_user CM WHERE CM.userid = new_cmempcode ) AS TEXT)
            WHEN remarks = 'kamheadempcode' THEN CAST( (select CM.username from  public.wms_user CM WHERE CM.userid = new_kamheadempcode ) AS TEXT)
            WHEN remarks = 'new_kamempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = new_new_kamempcode ) AS TEXT)
            WHEN remarks = 'new_cmempcode' THEN CAST((select CM.username from  public.wms_user CM WHERE CM.userid = new_new_cmempcode ) AS TEXT)
            WHEN remarks = 'statusid' THEN CAST((select ms.statusname from salespmo.mst_status ms WHERE ms.statusid = new_statusid) AS TEXT)
            WHEN remarks = 'request_type_id' THEN CAST((select reqname from salespmo.mst_request_type where request_type_id = new_request_type_id) AS TEXT)
            WHEN remarks = 'effective_from' THEN CAST(new_effective_from AS TEXT)
            WHEN remarks = 'new_effective_from' THEN CAST(new_new_effective_from AS TEXT)
            WHEN remarks = 'remarks' THEN CAST(new_remarks AS TEXT)
        END AS todata,
        (select CM.username || ' ' || '(' || CM.userid || ')' as new_updated_by from  public.wms_user CM WHERE CM.userid = new_updated_by),
        change_time,
        (select statusname from salespmo.mst_status ms where statusid = new_statusid) as status,
        (select statuscolor from salespmo.mst_status ms where statusid = new_statusid) as statuscolor,
        new_new_effective_from,
        old_effective_from,
        new_rejection_comment
    FROM (
        SELECT *, unnest(string_to_array(updated_remarks, ', ')) AS remarks
        FROM salespmo.trn_kamcustomerrel_pendingqueue_history
        WHERE kamcustomerrelid = $1 AND updated_remarks IS NOT NULL
    ) AS subquery
) AS final_query
GROUP BY historyid,status,statuscolor,new_updated_by,change_time,new_new_effective_from,new_rejection_comment,old_effective_from ;`;
  return script;
};
