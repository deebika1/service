export function get_master(p_name) {
  let query = '';

  switch (p_name) {
    case 'ENTITY':
      query = `SELECT entityid::bigint AS column_id, entityname AS column_name FROM public.mst_entity 
        WHERE isactive = true AND entityname ILIKE '%' || $1 || '%' order by entityname;`;
      break;
    case 'CUSTOMER':
      query = `SELECT customerid AS column_id, customername AS column_name FROM public.mst_customer 
        WHERE isactive = true AND customername ILIKE '%' || $1 || '%' ORDER BY customername;`;
      break;
    case 'SEGMENT':
      query = `SELECT segment_id AS column_id, segment_name AS column_name FROM salespmo.mst_segment 
        WHERE is_active = true AND segment_name ILIKE '%' || $1 || '%' ORDER BY segment_name;`;
      break;
    case 'DIVISION':
      query = `SELECT divisionid AS column_id, division AS column_name FROM public.org_mst_division 
        WHERE isactive = true AND division ILIKE '%' || $1 || '%' ORDER BY division;`;
      break;
    case 'DU':
      query = `select duid AS column_id, duname AS column_name FROM public.mst_deliveryunit 
        WHERE isactive = true AND duname ILIKE '%' || $1 || '%' ORDER BY duname`;
      break;
    case 'COUNTRY':
      query = `SELECT countryid::bigint AS column_id, countryname AS column_name, countrycode FROM public.geo_mst_country
        WHERE isactive = true AND countryname ILIKE '%' || $1 || '%' ORDER BY countrycode;`;
      break;
    case 'VERTICAL':
      query = `SELECT verticalid AS column_id, verticalname AS column_name FROM public.wms_mst_vertical 
        WHERE isactive = true AND verticalid <> 1 AND verticalname ILIKE '%' || $1 || '%' ORDER BY verticalname;`;
      break;
    case 'SERVICE':
      query = `SELECT serviceid AS column_id, servicename AS column_name FROM public.wms_mst_service 
        WHERE isactive = true AND servicename ILIKE '%' || $1 || '%' ORDER BY servicename;`;
      break;
    case 'CURRENCY':
      query = `SELECT Currencyid::bigint AS column_id, CurrencyText AS column_name FROM iquality.Mst_CurrencyMst 
        WHERE isactive = true AND currencytext ILIKE '%' || $1 || '%' ORDER BY CurrencyText;`;
      break;
    case 'DUMAPPING':
      query = `SELECT du.duid AS itrackduid, du.duname AS column_name, odu.duid AS iwmsduid, odu.duname AS iwmsdu
          FROM public.mst_deliveryunit du
          JOIN public.org_mst_deliveryunit odu ON odu.itrackduid = du.duid AND odu.isactive = true
          WHERE du.isactive = true AND (du.duname ILIKE '%' || $1 || '%' OR odu.duname ILIKE '%' || $1 || '%')
          ORDER BY du.duname;`;
      break;
    case 'CUSTOMERMAPPING':
      query = `SELECT cu.customerid AS itrackcustomerid, cu.customername AS column_name,
          ocu.customerid AS iwmscustomerid, ocu.customername AS iwmscustomer
          FROM public.mst_customer cu
          JOIN public.org_mst_customer ocu ON ocu.itrack_customerid = cu.customerid AND ocu.isactive = true
          WHERE cu.isactive = true AND (cu.customername ILIKE '%' || $1 || '%' OR ocu.customername ILIKE '%' || $1 || '%')
          ORDER BY cu.customername;`;
      break;
    case 'ODU':
      query = `SELECT duid AS column_id, duname AS column_name FROM public.org_mst_deliveryunit 
          WHERE isactive = true AND duname ILIKE '%' || $1 || '%' ORDER BY duname;`;
      break;
    case 'OCUSTOMER':
      query = `SELECT customerid AS column_id, customername AS column_name FROM public.org_mst_customer 
          WHERE isactive = true AND customername ILIKE '%' || $1 || '%' ORDER BY customername;`;
      break;
    default:
      throw new Error('Invalid Param');
  }

  return query;
}

export function update_master(p_name) {
  let query = '';

  switch (p_name) {
    case 'ENTITY':
      query =
        'UPDATE public.mst_entity SET entityname = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP WHERE entityid = $1 AND isactive = true';
      break;
    case 'CUSTOMER':
      query =
        'UPDATE public.mst_customer SET customername = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP WHERE customerid = $1 AND isactive = true';
      break;
    case 'SEGMENT':
      query =
        'UPDATE salespmo.mst_segment SET segment_name = $2, updated_by = $3, updated_at = CURRENT_TIMESTAMP WHERE segment_id = $1 AND is_active = true';
      break;
    case 'DIVISION':
      query =
        'UPDATE public.org_mst_division SET division = $2 WHERE divisionid = $1 AND isactive = true';
      break;
    case 'DU':
      query =
        'UPDATE public.mst_deliveryunit SET duname = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP WHERE duid = $1 AND isactive = true';
      break;
    case 'COUNTRY':
      query =
        'UPDATE public.geo_mst_country SET countryname = $2 WHERE countryid = $1 AND isactive = true';
      break;
    case 'VERTICAL':
      query =
        'UPDATE public.wms_mst_vertical SET verticalname = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP WHERE verticalid = $1 AND isactive = true';
      break;
    case 'SERVICE':
      query =
        'UPDATE public.wms_mst_service SET servicename = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP WHERE serviceid = $1 AND isactive = true';
      break;
    case 'CURRENCY':
      query =
        'UPDATE iquality.Mst_CurrencyMst SET currencytext = $2, updated_by = $3, updated_time = CURRENT_TIMESTAMP WHERE currencyid = $1 AND isactive = true';
      break;
    case 'DUMAPPING':
      query = `UPDATE public.org_mst_deliveryunit SET itrackduid = $2 WHERE duid = $1 AND isactive = true`;
      break;
    case 'CUSTOMERMAPPING':
      query = `UPDATE public.org_mst_customer SET itrack_customerid = $2 WHERE customerid = $1 AND isactive = true`;
      break;
    default:
      throw new Error('Invalid Param');
  }

  return query;
}

export function add_master(p_name) {
  let query = '';

  switch (p_name) {
    case 'ENTITY':
      query =
        'INSERT INTO public.mst_entity (entityname, isactive, created_by, created_time) VALUES ($1,$2,$3,CURRENT_TIMESTAMP);';
      break;
    case 'CUSTOMER':
      query =
        'INSERT INTO public.mst_customer (customername, customeralias, isactive, created_by, created_time) VALUES ($1,$1,$2,$3,CURRENT_TIMESTAMP)';
      break;
    case 'SEGMENT':
      query =
        'INSERT INTO salespmo.mst_segment (segment_name, is_active, created_by, created_at) VALUES ($1,$2,$3,CURRENT_TIMESTAMP)';
      break;
    case 'DIVISION':
      query =
        'INSERT INTO public.org_mst_division (division, isactive) VALUES ($1,$2)';
      break;
    case 'DU':
      query =
        'INSERT INTO public.mst_deliveryunit (duname, isactive, created_by, created_time) VALUES ($1,$2,$3,CURRENT_TIMESTAMP)';
      break;
    case 'COUNTRY':
      query =
        'INSERT INTO public.geo_mst_country (countryname, isactive) VALUES ($1,$2)';
      break;
    case 'VERTICAL':
      query =
        'INSERT INTO public.wms_mst_vertical (verticalname, isactive, created_by, created_time) VALUES ($1,$2,$3,CURRENT_TIMESTAMP)';
      break;
    case 'SERVICE':
      query = `INSERT INTO public.wms_mst_service (serviceid, servicename, isactive, created_by, created_time) VALUES 
        ((SELECT MAX(serviceid)+1 FROM public.wms_mst_service),$1,$2,$3,CURRENT_TIMESTAMP)`;
      break;
    case 'CURRENCY':
      query =
        'INSERT INTO iquality.Mst_CurrencyMst (currencytext, isactive, created_by, created_time) VALUES ($1,$2,$3,CURRENT_TIMESTAMP)';
      break;
    default:
      throw new Error('Invalid Param');
  }

  return query;
}

export function delete_master(p_name) {
  let query = '';

  switch (p_name) {
    case 'ENTITY':
      query =
        'UPDATE public.mst_entity SET isactive = false, updated_by = $2, updated_time = CURRENT_TIMESTAMP WHERE entityid = $1 AND isactive = true';
      break;
    case 'CUSTOMER':
      query =
        'UPDATE public.mst_customer SET isactive = false, updated_by = $2, updated_time = CURRENT_TIMESTAMP WHERE customerid = $1 AND isactive = true';
      break;
    case 'SEGMENT':
      query =
        'UPDATE salespmo.mst_segment SET is_active = false, updated_by = $2, updated_at = CURRENT_TIMESTAMP WHERE segment_id = $1 AND is_active = true';
      break;
    case 'DIVISION':
      query =
        'UPDATE public.org_mst_division SET isactive = false WHERE divisionid = $1 AND isactive = true';
      break;
    case 'DU':
      query =
        'UPDATE public.mst_deliveryunit SET isactive = false, updated_by = $2, updated_time = CURRENT_TIMESTAMP WHERE duid = $1 AND isactive = true';
      break;
    case 'COUNTRY':
      query =
        'UPDATE public.geo_mst_country SET isactive = false WHERE countryid = $1 AND isactive = true';
      break;
    case 'VERTICAL':
      query =
        'UPDATE public.wms_mst_vertical SET isactive = false, updated_by = $2, updated_time = CURRENT_TIMESTAMP WHERE verticalid = $1 AND isactive = true';
      break;
    case 'SERVICE':
      query =
        'UPDATE public.wms_mst_service SET isactive = false, updated_by = $2, updated_time = CURRENT_TIMESTAMP WHERE serviceid = $1 AND isactive = true';
      break;
    case 'CURRENCY':
      query =
        'UPDATE iquality.Mst_CurrencyMst SET isactive = false, updated_by = $2, updated_time = CURRENT_TIMESTAMP WHERE currencyid = $1 AND isactive = true';
      break;
    case 'DUMAPPING':
      query = `UPDATE public.org_mst_deliveryunit SET itrackduid = null WHERE duid = $1 AND isactive = true`;
      break;
    case 'CUSTOMERMAPPING':
      query = `UPDATE public.org_mst_customer SET itrack_customerid = null WHERE customerid = $1 AND isactive = true`;
      break;
    default:
      throw new Error('Invalid Param');
  }

  return query;
}
