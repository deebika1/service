import { query } from '../../database/postgres.js';

export const insertBudgetPlan = async data => {
  const results = [];
  try {
    await query('BEGIN');
    for (const recordData of data) {
      const {
        KamCustomerRelId,
        CurrencyId,
        Year,
        april_value,
        may_value,
        june_value,
        july_value,
        august_value,
        september_value,
        october_value,
        november_value,
        december_value,
        january_value,
        february_value,
        march_value,
        isactive,
        created_by,
      } = recordData;

      const result = await query(
        `INSERT INTO salespmo.Trn_budgetplan (
          KamCustomerRelId,
          CurrencyId,
          Year,
          april_value,
          may_value,
          june_value,
          july_value,
          august_value,
          september_value,
          october_value,
          november_value,
          december_value,
          january_value,
          february_value,
          march_value,
          isactive,
          created_by
        ) VALUES (
          $1, $2, $3::DATE, $4::FLOAT, $5::FLOAT, $6::FLOAT, $7::FLOAT, $8::FLOAT, $9::FLOAT, $10::FLOAT, $11::FLOAT, $12::FLOAT, $13::FLOAT, $14::FLOAT, $15::FLOAT, $16::BOOLEAN, $17, CURRENT_TIMESTAMP
        )`,
        [
          KamCustomerRelId,
          CurrencyId,
          Year,
          april_value,
          may_value,
          june_value,
          july_value,
          august_value,
          september_value,
          october_value,
          november_value,
          december_value,
          january_value,
          february_value,
          march_value,
          isactive,
          created_by,
        ],
      );
      results.push(result);
    }
    await query('COMMIT');
  } catch (error) {
    await query('ROLLBACK');
    console.error('Error inserting data:', error);
    results.push({ error: error.message });
  }

  return results;
};

export const insertTargetPlan = async data => {
  const results = [];
  try {
    await query('BEGIN');
    for (const recordData of data) {
      const {
        KamCustomerRelId,
        CurrencyId,
        Year,
        april_value,
        may_value,
        june_value,
        july_value,
        august_value,
        september_value,
        october_value,
        november_value,
        december_value,
        january_value,
        february_value,
        march_value,
        isactive,
        created_by,
      } = recordData;

      const result = await query(
        `INSERT INTO salespmo.Trn_targetplan (
          KamCustomerRelId,
          CurrencyId,
          Year,
          april_value,
          may_value,
          june_value,
          july_value,
          august_value,
          september_value,
          october_value,
          november_value,
          december_value,
          january_value,
          february_value,
          march_value,
          isactive,
          created_by
        ) VALUES (
          $1, $2, $3::DATE, $4::FLOAT, $5::FLOAT, $6::FLOAT, $7::FLOAT, $8::FLOAT, $9::FLOAT, $10::FLOAT, $11::FLOAT, $12::FLOAT, $13::FLOAT, $14::FLOAT, $15::FLOAT, $16::BOOLEAN, $17, CURRENT_TIMESTAMP
        )`,
        [
          KamCustomerRelId,
          CurrencyId,
          Year,
          april_value,
          may_value,
          june_value,
          july_value,
          august_value,
          september_value,
          october_value,
          november_value,
          december_value,
          january_value,
          february_value,
          march_value,
          isactive,
          created_by,
        ],
      );
      results.push(result);
    }
    await query('COMMIT');
  } catch (error) {
    await query('ROLLBACK');
    console.error('Error inserting data:', error);
    results.push({ error: error.message });
  }

  return results;
};

export const getPlanTemplateScript = () => {
  const script = `select
	CR.kamcustomerrelid as kamcustomerrelid,
	C.customername as customername,
	CY.countryname as countryname,
	DI.division as divisionname,
	CR.verticalcode as verticalcode,
	S.servicename as servicename,
	CR.KAMempcode as KAM,
	K.username as KAMname,
	CR.Cmempcode as clientmanager,
	CM.username as clientmanagername,
	D.Duname as duname ,
	e.entityname as entityname,
	0 as  currency,
	2023 as year,
	0 as apr_value,
	0 as may_value,
	0 as jun_value,
	0 as jul_value,
	0 as aug_value,
	0 as sep_value,
	0 as oct_value,
	0 as nov_value,
	0 as dec_value,
	0 as jan_value,
	0 as feb_value,
	0 as mar_value
from
	salespmo.Trn_KAMCustomerRel CR
left join public.org_mst_customer C on
	CR.customerId = C.customerId
left join public.geo_mst_country CY on
	CR.countryId = CY.countryId
left join public.mst_deliveryunit D on
	CR.duid = D.duid
left join public.org_mst_division DI on
	CR.divisionid = DI.divisionid
left join public.wms_mst_service S on
	CR.serviceid = S.serviceid
left join public.wms_user CM on
	CR.Cmempcode = CM.userid
left join public.wms_user K on
	CR.KAMempcode = K.userid
left join public.mst_entity e on
	CR.entityID = e.entityID`;
  return script;
};

export const InsertKAMRelPendingRequest = () => {
  const script = `select
	CR.kamcustomerrelid as kamcustomerrelid,
	C.customername as customername,
	CY.countryname as countryname,
	DI.division as divisionname,
	CR.verticalcode as verticalcode,
	S.servicename as servicename,
	CR.KAMempcode as KAM,
	K.username as KAMname,
	CR.Cmempcode as clientmanager,
	CM.username as clientmanagername,
	D.Duname as duname ,
	e.entityname as entityname,
	0 as  currency,
	2023 as year,
	0 as apr_value,
	0 as may_value,
	0 as jun_value,
	0 as jul_value,
	0 as aug_value,
	0 as sep_value,
	0 as oct_value,
	0 as nov_value,
	0 as dec_value,
	0 as jan_value,
	0 as feb_value,
	0 as mar_value
from
	salespmo.Trn_KAMCustomerRel CR
left join public.org_mst_customer C on
	CR.customerId = C.customerId
left join public.geo_mst_country CY on
	CR.countryId = CY.countryId
left join public.mst_deliveryunit D on
	CR.duid = D.duid
left join public.org_mst_division DI on
	CR.divisionid = DI.divisionid
left join public.wms_mst_service S on
	CR.serviceid = S.serviceid
left join public.wms_user CM on
	CR.Cmempcode = CM.userid
left join public.wms_user K on
	CR.KAMempcode = K.userid
left join public.mst_entity e on
	CR.entityID = e.entityID`;
  return script;
};
