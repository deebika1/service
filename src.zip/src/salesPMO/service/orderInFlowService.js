import { query } from '../../database/postgres.js';
import { setOrdInflowService } from './index.js';

export const manualOIRACS = async () => {
  let successCount = 0;
  let failureCount = 0;

  try {
    const workorderDetails = await query(`
      SELECT 
      wo.workorderid, 
      wo.itemcode,  
      cus.customershortname,  
      jr.journalacronym, 
      toir.created_by, 
      omd.division, 
      wms.stagename,
      wms.stageid
    FROM public.wms_workorder_incoming AS wi
    JOIN wms_workorder AS wo ON wo.workorderid = wi.woid  
    JOIN public.org_mst_division omd ON omd.divisionid = wo.divisionid 
    JOIN org_mst_customer cus ON cus.customerid = wo.customerid
    JOIN public.pp_mst_journal AS jr ON jr.journalid = wo.journalid
    join public.wms_mst_stage wms on wms.stageid = wi.stageid
    JOIN salespmo.trn_ord_inflow_report toir ON toir.workorderid = wo.workorderid 
    WHERE wo.itemcode IN 
    ('ab5c00810')`);
    const sleep = ms =>
      new Promise(resolve => {
        setTimeout(resolve, ms); // Just resolve the promise after the timeout
      });

    for (const workorderDetail of workorderDetails) {
      const {
        workorderid,
        journalacronym,
        division,
        created_by,
        itemcode,
        stagename,
        stageid,
      } = workorderDetail;

      console.log(
        `🔄 Processing ${
          successCount + failureCount + 1
        } :- WorkOrder ID: ${workorderid} - itemcode : ${itemcode}`,
      );

      const data = {
        workorderId: workorderid,
        journalacronym,
        divisionname: division,
        userId: created_by,
        itemcode,
        stagename,
        stageid,
      };

      const result = await updateACSEstimatePagesSerice(data);

      if (result) {
        successCount++;
        console.log(`✅ Success: WorkOrder ID ${workorderid}`);
      } else {
        failureCount++;
        console.log(`❌ Failed: WorkOrder ID ${workorderid}`);
      }
      // Delay for 500ms before processing next item
      await sleep(100);
      console.log(`Delay of 100ms`);
    }

    console.log(`\n📊 Processing Complete:`);
    console.log(`✅ Successful: ${successCount}`);
    console.log(`❌ Failed: ${failureCount}`);
  } catch (err) {
    console.error('❌ Error in manualOIRACS:', err.message, err.stack);
  }
};

export const updateACSEstimatePagesSerice = async data => {
  const {
    workorderId,
    journalacronym,
    divisionname,
    itemcode,
    stagename,
    stageid,
    userId = '',
    type = 'new',
    fc_oifcalctype = 'initial',
  } = data;

  try {
    const checksql = `
      SELECT 
        cus.itrack_customerid,
        cus.customershortname,
        wi.woincomingid,
        jr.conversionfactor
      FROM public.wms_workorder_incoming AS wi
      JOIN wms_workorder AS wo ON wo.workorderid = wi.woid  
      JOIN org_mst_customer cus ON cus.customerid = wo.customerid
      JOIN public.pp_mst_journal AS jr ON jr.journalid = wo.journalid
      WHERE woid = ${workorderId}
    `;

    const getCount = await query(checksql);

    if (!getCount.length || !getCount[0].woincomingid) {
      console.warn(
        `⚠️ No incoming workorder found for WorkOrder ID: ${workorderId}`,
      );
      return false;
    }

    const {
      woincomingid,
      itrack_customerid,
      conversionfactor: cf,
    } = getCount[0];

    const itrackcustomerid = +itrack_customerid || 0;
    const conversionfactor = +cf || 1.0;

    const getStandardPage = `
        SELECT wordcount_per_page::numeric(5,2) AS wordcount_per_page
        FROM public.mst_standardpage_measure 
        WHERE customerid = ${itrackcustomerid}
      `;

    const respage = await query(getStandardPage);

    let wordcountperpage = 1.0;
    if (respage?.length > 0) {
      wordcountperpage = +respage[0].wordcount_per_page || 1.0;
    } else {
      console.warn(
        `⚠️ No wordcount_per_page found for customer ID: ${itrackcustomerid}`,
      );
    }

    const qryPageUpdate = `
        UPDATE wms_workorder_incomingfiledetails
        SET 
          estimatedpages = ROUND(ROUND(wordcount / ${wordcountperpage}) * ${conversionfactor}),
          typesetpage = ROUND(ROUND(wordcount / ${wordcountperpage}) * ${conversionfactor}),
          mspages = ROUND(wordcount / ${wordcountperpage})
        WHERE woincomingid = ${woincomingid}
      `;

    await query(qryPageUpdate);
    console.log(
      `✅ Updated estimated pages for WorkOrder ID: ${workorderId} - itemcode : ${itemcode}`,
    );

    console.log(
      `⚙️ starting inflow service for WorkOrder ID: ${workorderId} - itemcode : ${itemcode}`,
    );
    await setOrdInflowService({
      workorderId,
      journalacronym,
      divisionname,
      userId,
      type,
      fc_oifcalctype,
      stageName: stagename,
      stageId: stageid,
    });
    console.log(
      `🎯 inflow service completed for WorkOrder ID: ${workorderId} - itemcode : ${itemcode}`,
    );
    return true;
  } catch (err) {
    console.error(
      `❌ Error in updateACSEstimatePagesSerice for WorkOrder ID ${workorderId}:`,
      err.message,
      err.stack,
    );
    return false;
  }
};
