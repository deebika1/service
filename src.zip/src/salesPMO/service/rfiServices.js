import moment from 'moment';
import { query } from '../../database/postgres.js';
import {
  odooApiIntegrationService,
  sendInvoicePayloadToOdooService,
  sendInvoiceToOdooService,
} from '../../odoo/service/index.js';
import {
  getInvoiceDescScript,
  getJobDetailsByWorkorderIdScript,
  getJournalRateEntryForRFIScript,
  getRFIFieldScript,
  getRFITableScript,
  insertRFIScript,
  getRFIStatusScript,
  updateRFIScript,
  getRFIDetailsScript,
  getWORateEntryForRFIScript,
  getRFIArticleDetailScript,
  getRFIIssueArticleDetailScript,
  approveRFIScript,
  rejectRFIScript,
  getRFIInvoiceDataScript,
  updateRFIStatusScript,
  insertRFIAttachmentsScript,
  insertRFIAttachmentScript,
  updateDeleteRfiAttachmentScript,
  invoiceQueueDetailsScript,
  serviceDetailsScript,
  crossCheckWorkOrderIDsScript,
  checkWorkOrderExitsScript,
  checkIfAnyWOIsCompOrINPScript,
} from '../datalayer/rfiScripts.js';
import {
  getEmailTemplate,
  extractEmails,
} from '../../modules/iTracks/index.js';
import { getUserDetailByUserIdScript } from '../../iAspire/datalayer/iaspireIntegration.js';
import { modifyNotificationConfigFromEmails } from '../../modules/woi/manualLogisticEntry.js';
import { emitAction } from '../../modules/activityListener/activityListener.js';
import { odooEndPoints } from '../../odoo/helpers/odooApiEndpoints.js';
import {
  remapToInvoiceQueueDetails,
  startAutoPayloadsODOOService,
  updatePayloadWithRFid,
  updateRFIDetailsTransaction,
} from '../helpers/ACSAutoHelpers.js';

export const getRaiseRFITableService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { fields, searchtext, customer, status, userid, tablestatus } =
        payload;
      const columnfield = fields.map(col => `"${col}"`).join(',');
      const tableScript = getRFITableScript(columnfield);
      const result = await query(tableScript, [
        searchtext,
        customer,
        status,
        userid,
        tablestatus,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getJobDetailsService = (woid, stageid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getJobDetailsByWorkorderIdScript();
      const result = await query(script, [woid, stageid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getInvoiceRFIFieldsService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid } = payload;
      const script = getRFIFieldScript();
      const result = await query(script, [duid, customerid, verticalid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getInvoiceDescService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid, serviceid, category } = payload;
      const script = getInvoiceDescScript();
      const result = await query(script, [
        duid,
        customerid,
        verticalid,
        serviceid,
        category,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertRFIService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        invoiceid,
        woid,
        itemcode,
        invoice,
        invoiceType,
        jobdetails,
        price,
        remark,
        attachment,
        rfisavetype,
        userid,
        isApprover,
        uploads,
      } = payload;

      let statuscode = '';
      let rfistatusid = 0;
      if (rfisavetype.toLowerCase() == 'save') {
        statuscode = 'PEND';
      }
      // if (rfisavetype.toLowerCase() == 'draft') {
      //   statuscode = 'INP';
      // }
      if (isApprover) {
        statuscode = 'INP';
      }
      let fullinvoice = false;
      if (invoiceType.toLowerCase() == 'full') {
        fullinvoice = true;
      }

      const qrystat = getRFIStatusScript();
      const statresult = await query(qrystat, [statuscode]);
      if (statresult != undefined && statresult.length > 0) {
        rfistatusid = statresult[0].rfistatusid;
      }

      if (invoiceid == 0) {
        const iscript = insertRFIScript();
        const attachScript = insertRFIAttachmentsScript();
        const insresult = await query(iscript, [
          woid,
          invoice,
          price,
          fullinvoice,
          remark,
          attachment,
          rfistatusid,
          userid,
          jobdetails,
          itemcode,
        ]);
        if (uploads.length > 0) {
          for (const { fileType, fileName, fileSize } of uploads) {
            // Assuming `insresult[0].invoiceid` is available, and `attachScript` is the query string
            await query(attachScript, [
              insresult[0].invoiceid,
              fileName,
              fileType,
              fileSize,
            ]);
          }
        }
        if (isApprover) {
          const insertedId = insresult[0].invoiceid;
          // Prepare the Odoo payload
          const odooPayload = {
            ...payload, // Spread existing properties
            jobdetails: JSON.parse(jobdetails),
            invoicedetails: JSON.parse(invoice),
            pricedetails: JSON.parse(price),
          };
          try {
            // Try sending the invoice to Odoo
            await sendInvoiceToOdooService(insertedId, odooPayload);
          } catch (err) {
            // If sending to Odoo fails, update the status in the table to a failed state
            const statusID = await query(getRFIStatusScript(), ['OF']);
            const updateStatusQuery = updateRFIStatusScript();
            await query(updateStatusQuery, [
              insertedId,
              statusID[0].rfistatusid,
            ]);
            reject(err);
          }
        }
        resolve(insresult);
      } else if (invoiceid > 0) {
        const updqry = updateRFIScript();
        const updresult = await query(updqry, [
          invoice,
          price,
          fullinvoice,
          remark,
          attachment,
          rfistatusid,
          userid,
          invoiceid,
        ]);
        if (isApprover) {
          const odooPayload = {
            ...payload, // Spread existing properties
            jobdetails: JSON.parse(jobdetails),
            invoicedetails: JSON.parse(invoice),
            pricedetails: JSON.parse(price),
          };
          try {
            // Try sending the invoice to Odoo
            await sendInvoiceToOdooService(invoiceid, odooPayload);
          } catch (err) {
            // If sending to Odoo fails, update the status in the table to a failed state
            const statusID = await query(getRFIStatusScript(), ['OF']);
            const updateStatusQuery = updateRFIStatusScript();
            await query(updateStatusQuery, [
              invoiceid,
              statusID[0].rfistatusid,
            ]);
            reject({ status: err.status, message: err.message });
          }
        }
        resolve(updresult);
      } else {
        resolve([{ invoiceid: '-1' }]);
      }
    } catch (error) {
      reject(error);
    }
  });
};

// if it is approver then the status is set to INP else it is set to PEND
export const insertOrUpdateRFIService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        invoiceid,
        woid,
        itemcode,
        invoice,
        invoiceType,
        jobdetails,
        price,
        remark,
        attachment,
        userid,
        isApprover,
      } = payload;
      const statuscode = isApprover ? 'INP' : 'PEND';
      let fullinvoice = false;
      let rfistatusid = 0;
      if (invoiceType.toLowerCase() === 'full') fullinvoice = true;
      const qrystat = getRFIStatusScript();
      const statresult = await query(qrystat, [statuscode]);
      if (statresult && statresult.length > 0) {
        rfistatusid = statresult[0].rfistatusid;
      }
      // Check if it's a new invoice (invoiceid is 0) or an update (invoiceid > 0)
      if (invoiceid === 0) {
        const iscript = insertRFIScript();
        const insresult = await query(iscript, [
          woid,
          invoice,
          price,
          fullinvoice,
          remark,
          attachment,
          rfistatusid,
          userid,
          jobdetails,
          itemcode,
        ]);
        resolve(insresult);
      } else if (invoiceid > 0) {
        const updqry = updateRFIScript();
        const updresult = await query(updqry, [
          invoice,
          price,
          fullinvoice,
          remark,
          attachment,
          rfistatusid,
          userid,
          invoiceid,
        ]);
        resolve(updresult);
      } else {
        resolve([{ invoiceid: '-1' }]);
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const insertRFIAttachmentService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // Using Promise.all to handle multiple insertions
      const insertPromises = payload.map(async item => {
        const { rfiid, filename, url, userid, size } = item;
        const script = insertRFIAttachmentScript();
        return query(script, [rfiid, filename, url, userid, size]); // Insert each record
      });
      // Wait for all insertions to complete
      const results = await Promise.all(insertPromises);
      resolve(results); // Resolve with the results of all insertions
    } catch (error) {
      reject(error); // Reject in case of any error
    }
  });
};

export const getRateEntryForRFIService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { vertical, woid } = payload;
      let script;
      if (vertical == 'Journals') {
        script = getJournalRateEntryForRFIScript();
      } else {
        script = getWORateEntryForRFIScript();
      }
      const result = await query(script, [woid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRFIDetailsService = woid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getRFIDetailsScript();
      const result = await query(script, [woid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRFIArticleDetailsService = (woid, jobtype) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script =
        jobtype.toLowerCase() == 'issue'
          ? getRFIIssueArticleDetailScript()
          : getRFIArticleDetailScript();
      const result = await query(script, [woid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const approveRejectRFIService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { invoiceid, userid, approved, reason } = payload;
      let statuscode = '';
      if (approved) {
        statuscode = 'INP';
      } else {
        statuscode = 'REJ';
      }
      const approveStatus = ['PEND', 'REJ'];
      const rejectStatus = ['PEND'];
      const qrystat = getRFIStatusScript();
      const invoiceDataScript = getRFIInvoiceDataScript();
      const script = approved ? approveRFIScript() : rejectRFIScript();

      // Step 1: Query the current RFI status
      const statresult = await query(qrystat, [statuscode]);

      // Step 2: Get the invoice data
      const invoiceData = await query(invoiceDataScript, [
        invoiceid,
        approved ? approveStatus : rejectStatus,
      ]);
      // check before approving or rejecting it is in right flow or not
      if (invoiceData.length == 0) {
        throw new Error('This RFI is already Approved/Rejected.');
      }

      // Step 3: Send the data to Odoo and wait for success response
      if (approved) {
        const sendResult = await sendInvoicePayloadToOdooService(invoiceid);
        if (!sendResult.status) {
          throw new Error('Failed to send data to Odoo.');
        }
      }

      // Step 4: After Odoo is successfully updated, update the table
      const values = [invoiceid, statresult[0].rfistatusid, userid];
      if (!approved) values.push(reason);
      const result = await query(script, values);

      // Optional: Trigger workflow mail for rejection if needed
      if (!approved) {
        RejectionWorkflowMailService(
          invoiceid,
          userid,
          'rejection_workflow',
          70,
        );
      }
      // Resolve the result after updating the table
      resolve(result);
    } catch (error) {
      // Reject with error if any step fails
      reject(error);
    }
  });
};

export const RFIIntegrationService = input => {
  return new Promise(async (resolve, reject) => {
    try {
      const { journalId, workorderId, stageId } = input;
      const iqry = `insert into salespmo.trn_rfi_jobs(journalid,workorderid,stageid)
      values ($1,$2,$3) returning rfijobid`;
      const insdata = await query(iqry, [journalId, workorderId, stageId]);

      // You can check if data was inserted correctly
      if (insdata && insdata.length > 0) {
        resolve('Data inserted successfully');
      } else {
        throw new Error('Insert operation returned no data');
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const RejectionWorkflowMailService = async (
  invoiceid,
  userId,
  mailAction,
  entityId,
) => {
  const invoiceDetails = await query(
    `SELECT mr.statuscode, tr.invoiceid, tr.workorderid, tr.invoicedetails, tr.pricedetails, tr.jobdetails,
    tr.itemcode, tr.created_by, u.username, u.useremail
    FROM salespmo.trn_rfidetails tr
    JOIN salespmo.mst_rfistatus mr ON mr.rfistatusid = tr.rfistatusid
    LEFT JOIN public.wms_user u ON u.userid = tr.created_by
    WHERE tr.invoiceid = $1;`,
    [invoiceid],
  );
  const script = getUserDetailByUserIdScript();

  const resForConfig = await getEmailTemplate(entityId, mailAction);
  const { notificationconfig } = resForConfig[0];

  const mailIDinTO = extractEmails(notificationconfig.to);
  const mailIDinCC = extractEmails(notificationconfig.cc);

  const mailTo = invoiceDetails ? [invoiceDetails[0]?.useremail] : [];
  const mailCCData =
    userId && userId.toLowerCase() !== 'odoo'
      ? await query(script, [userId])
      : [];
  const mailCC =
    mailCCData && mailCCData.length > 0 ? [mailCCData[0]?.useremail] : [];

  const updatedNotificationConfig = await modifyNotificationConfigFromEmails(
    notificationconfig,
    mailIDinTO,
    mailIDinCC,
    mailTo,
    mailCC,
  );

  const mailData = {
    ...updatedNotificationConfig,
    userName: invoiceDetails[0]?.username,
    itemCode: invoiceDetails[0]?.itemcode,
    rejectedBy: mailCCData[0]?.username || 'ODOO',
    rejectedOn: moment(new Date()).format('DD-MM-YYYY'),
  };
  emitAction(mailData);
};

export const deleteRfiAttachmentService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { rfi_attachmentid, res_id, attachment_id, rfiid } = payload;
      const odooPayload = {
        RFIid: rfiid,
        attachment_id,
        res_id,
        delete: 'yes',
      };
      const deleteUrl = odooEndPoints.api.invoiceAttachment;
      // Send the request to Odoo
      await odooApiIntegrationService(
        deleteUrl,
        odooPayload,
        'application/json',
      );
      const response = await query(updateDeleteRfiAttachmentScript(), [
        rfi_attachmentid,
      ]);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

export const ACSAutoService = input => {
  const { createdBy, data } = input;
  return new Promise(async (resolve, reject) => {
    try {
      const notExistsWorkOrders = await query(checkWorkOrderExitsScript(data));
      const ifRecordNotInCompORINP = await query(
        checkIfAnyWOIsCompOrINPScript(data),
      );
      // if any invalid work orders (jobs/itemcode) found, reject the promise
      if (notExistsWorkOrders.length > 0) {
        reject({
          message: 'Invalid workorders found',
          type: 'invalid',
          data: notExistsWorkOrders,
        });
        return;
      }
      // if any invalid work orders (jobs/itemcode) found, reject the promise
      if (ifRecordNotInCompORINP.length > 0) {
        reject({
          message: 'Workorders already in Progress or Cpmpleted',
          type: 'invalid',
          data: ifRecordNotInCompORINP,
        });
        return;
      }
      // get invoice details (job detials from itemcode)
      const invoiceQueueDetailRows = await query(
        invoiceQueueDetailsScript(data),
      );
      // if the number of rows fetched is not equal to the number of work orders, reject the promise
      if (invoiceQueueDetailRows.length !== data.length) {
        reject({
          message: 'Journal not dispatched from the respective Stages.',
          type: 'invalid',
          data: notExistsWorkOrders,
        });
        return;
      }
      // check jobs are valid for rfi (salespmo.trn_rfi_jobs intermediate table)
      const nonExistingWorkOrders = await query(
        crossCheckWorkOrderIDsScript(invoiceQueueDetailRows),
      );

      // if any invalid work orders (jobs/itemcode) found, reject the promise
      if (nonExistingWorkOrders.length > 0) {
        reject({
          message: 'Journal not dispatched from the respective Stages.',
          type: 'invalid',
          data: nonExistingWorkOrders,
        });
        return;
      }
      // get service details (using manuscript number as itemcode)
      const serviceDetailRows = await query(serviceDetailsScript(data));
      if (
        invoiceQueueDetailRows.length === 0 ||
        serviceDetailRows.length === 0
      ) {
        reject(new Error('Details not found for orders'));
        return;
      }
      // remap the data to the required format (odoo Payload Fromat)
      const { result, RFIDetailsTablePayload } = remapToInvoiceQueueDetails(
        input,
        invoiceQueueDetailRows,
        serviceDetailRows,
      );
      const RFIidsAndStatuses = await updateRFIDetailsTransaction(
        RFIDetailsTablePayload,
      );
      const updateFailures = RFIidsAndStatuses.reduce(
        (output, RFIidAndStatus) => {
          if (RFIidAndStatus.status === 'failure') {
            output.push({
              workorderid: RFIidAndStatus.rfiid,
              status: RFIidAndStatus.status,
            });
          }
          return output;
        },
        [],
      );
      if (updateFailures.length > 0) {
        // console.log(updateFailures);
        // throw error new Error('Duplicate / Previously completed Work Order Ids found');
        reject({
          message: 'Duplicate / Previously completed Work Order Ids found',
          type: 'duplicate',
          data: updateFailures,
        });
        return;
      }
      updatePayloadWithRFid(RFIidsAndStatuses, result);
      const ordersStatus = await startAutoPayloadsODOOService(
        createdBy,
        RFIDetailsTablePayload,
      );
      resolve(ordersStatus);
    } catch (error) {
      // Catching any other errors and returning the message
      reject({
        message: error.message || 'An unexpected error occurred',
        type: 'error',
        details: error,
      });
    }
  });
};
