import { query } from '../../database/postgres.js';
import { getUserMappedDuScript } from '../datalayer/master.js';
import {
  getAuditInvoiceDDScript,
  getAuditJournalSearchDDScript,
  getAuditLogJobRateDataScript,
  getAuditLogJournalRateDataScript,
  getAuditModuleDDScript,
  getAuditRateSearchDDScript,
  getPlanVsActualReportDataScript,
  getProjectWiseReportDataScript,
  getAuditLogRfiDetailsDataScript,
} from '../datalayer/reports.js';

export const getUserMappedDuService = (type, userid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getUserMappedDuScript(type);
      const result = await query(script, [userid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getProjectWiseTableDataService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getProjectWiseReportDataScript(payload);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getPlanVsActualTableDataService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      // const { selectedDu, exchange, currency, from, to } = payload;
      const script = getPlanVsActualReportDataScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAuditModuleDDService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getAuditModuleDDScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAuditSearchService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { module, vertical, search, duId, customerId } = payload;
      const script =
        module == 'Rate Entry'
          ? vertical == 'Journals'
            ? getAuditJournalSearchDDScript()
            : getAuditRateSearchDDScript()
          : getAuditInvoiceDDScript();
      const result = await query(script, [search, duId, customerId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAuditDataService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { module, vertical, search } = payload;
      const script =
        module == 'Rate Entry'
          ? vertical == 'Journals'
            ? getAuditLogJournalRateDataScript()
            : getAuditLogJobRateDataScript()
          : getAuditLogRfiDetailsDataScript(); // invoice script here;
      const result = await query(script, [search]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
