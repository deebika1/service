import { query, transaction } from '../../database/postgres.js';
import {
  updateKAMCustomerRelById,
  getKAMCustomerRel,
  insertKAMCustomerRelScript,
  insertKAMCustomerRelPendingScript,
  getKAMDetailsByIdScript,
  updateKAMPendingByIdScript,
  getKAMChangeTableDataScript,
  insertKAMActiveRecModifyScript,
  approveOrRejectKAMChangeScript,
  updateKAMCustomerRelScript,
  updateKAMPendingReassignScript,
  insertKAMPendingReassignScript,
  getKAMPendingQueueHistoryScript,
  insertKAMRelPendingQueueHistory,
  updateCMPendingReassignScript,
  updateKAMCMPendingReassignScript,
  checkKAMCustomerRelScript,
} from '../datalayer/kamCustRel.js';
import { getPlanTemplateScript } from '../datalayer/plan.js';

import {
  getJournalRateEntryScript,
  getJournalRateStageScript,
  insertJournalRateScript,
  insertJobRateScript,
  updateJournalRateScript,
  updateJobRateScript,
  getJobRateScript,
  getJobRateAdjScript,
  getWorkOrderRateEntryScript,
  getJournalRateEntryHistoryScript,
  getJobRateEntryHistoryScript,
  deleteJournalRateScript,
  deleteJobRateScript,
  getJobRateEntryActualsScript,
  getRateEntryMonthYearScript,
  insertJobRateAdjScript,
  deleteJobRateAdjScript,
  checkOrderInflowRecordScript,
  insertAdjOnActualsScript,
  insertOrderInflowRecordScript,
  checkForAdjRateEntryScript,
  deleteActualByAdjRateScript,
  checkActualByAdjRateScript,
  checkForJournalScript,
  checkForJobRateScript,
  insertRateEntryConfigScript,
  updateRateEntryConfigScript,
  deleteRateEntryConfigScript,
  deleteInvoiceDescConfigScript,
  updateInvoiceDescScript,
  insertInvoiceDescScript,
  rateConfigTableScript,
  getInvoicedynamicfieldScript,
  getInvoicefieldmappingScript,
  insertInvoicefieldmappingScript,
  updateInvoicefieldmappingScript,
  getOrderinflowReportScript,
  checkCombinationForRateEntry,
  getRateEntryDataScript,
  getRateConfigInvoiceDescDataScript,
  getRateConfigFieldScript,
  getOrderInflowFailureScript,
  checkRateEntryIfServiceExistsScript,
  updateRateEntryConfigNotRequiredScript,
  updateInvDescConfigNotRequiredScript,
  checkInvDescIfServiceExistsScript,
} from '../datalayer/rateEntry.js';

// import logger from '../../modules/utils/logs/index.js';

import {
  insertServiceAndStageMapping,
  updateServiceMappingById,
  updateStageMappingById,
  getServiceMapScript,
  getStageMapScript,
} from '../datalayer/serviceStageMapping.js';

import {
  getSegment,
  getVertical,
  insertSegment,
  updateSegment,
  deleteSegment,
  insertVertical,
  updateVertical,
  deleteVertical,
  getService,
  insertService,
  updateService,
  deleteService,
  checkSegment,
  checkVertical,
  checkService,
  getMasterDropDownScript,
  getRateEntryMapScreenServiceDDScript,
  getStageDDByserviceMapIdScript,
  getUserMappedDuByUserIdScript,
  getCustomerByDuIdScript,
  getVerticalByDuCustomerIdScript,
  getServiceByRateConfigScript,
  getUomByRateConfigScript,
  getCategoryByRateConfigScript,
  getDuFromKamCustomerScript,
  getCategoryScript,
  getStageByCustFromKAMScript,
  getInvoiceDescriptionScript,
  getServiceInKamRelScript,
} from '../datalayer/master.js';
import {
  insertOrdInflowScript,
  updateOrdInflowScript,
  insertOrdInflowstageScript,
} from '../datalayer/orderinflow.js';

import {
  validateFile,
  getExceptiondata,
  getExchangeCurrencyandRate,
  checkIfExistExchangeRate,
  InsertCurrencyExchangeRate,
  UpdateCurrencyExchangeRate,
  getBudgetFinancialYear,
  getTargetFinancialYear,
  getBudgetPlanDetails,
  getTargetPlanDetails,
  getBudgetPlan,
  getTargetPlan,
  checkIfYearIsExist,
  insertFYear,
  getFYear,
} from '../datalayer/planupload.js';

import {
  update_master,
  add_master,
  delete_master,
  get_master,
} from '../datalayer/masters.js';

import {
  getWorkOrderList,
  validateLockUnlockFile,
  getTempTableData,
  // updateWorkorderID,
  insertHistoryTable,
  getHistoryData,
  updateLockJobusingId,
  getIsFullyInvoiced,
} from '../datalayer/lockUnlock.js';
import { ubrIntegrationService } from '../../odoo/service/index.js';

export const insertKAMCustomerRelService = ({
  cmEmpCode,
  customerId,
  countryId,
  divisionId,
  verticalId,
  serviceId,
  kamEmpCode,
  kamHEmpCode,
  duId,
  entityId,
  isActive,
  remarks,
  createdBy,
  effectiveFrom,
  segmentId,
  approvedempcode,
  new_effective_from,
  new_kamempcode,
  new_cmempcode,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          let serviceData;
          try {
            let response = '';
            for (const service of serviceId) {
              serviceData = service;
              const checkRecordExists = checkKAMCustomerRelScript();
              const checkResult = await client.query(checkRecordExists, [
                customerId,
                countryId,
                duId,
                divisionId,
                verticalId,
                service,
              ]);
              if (checkResult.rows.length > 0) {
                // Combination already exists
                throw new Error(
                  `Combination already exists for service ID: ${service}`,
                );
              }
              const kamRelscript = insertKAMCustomerRelScript('N');
              const result = await client.query(kamRelscript, [
                cmEmpCode,
                customerId,
                countryId,
                duId,
                divisionId,
                verticalId,
                service,
                kamEmpCode,
                entityId,
                isActive,
                remarks,
                createdBy,
                effectiveFrom,
                segmentId,
                kamHEmpCode,
              ]);
              const kamRelId = result?.rows[0]?.kamcustomerrelid;
              const kamRelPendingScript = insertKAMCustomerRelPendingScript();
              response = await client.query(kamRelPendingScript, [
                cmEmpCode,
                customerId,
                countryId,
                duId,
                divisionId,
                verticalId,
                service,
                kamEmpCode,
                entityId,
                isActive,
                remarks,
                createdBy,
                effectiveFrom,
                segmentId,
                kamRelId,
                approvedempcode,
                new_effective_from,
                new_kamempcode,
                new_cmempcode,
                kamHEmpCode,
              ]);
            }
            tresolve({ msg: 'success', data: response });
          } catch (error) {
            treject({ msg: error.message, service: serviceData });
          }
        });
      });
      resolve({ msg: 'success' });
    } catch (error) {
      reject(error);
    }
  });
};

export const updateKAMCustomerRelByIdService = (
  KamCustomerRelId,
  Cmempcode,
  customerId,
  countryId,
  divisionid,
  verticalcode,
  serviceid,
  KAMempcode,
  duid,
  entityID,
  isactive,
  updated_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const checkRecordExists = checkKAMCustomerRelScript();
      const checkResult = await query(checkRecordExists, [
        customerId,
        countryId,
        duid,
        divisionid,
        verticalcode,
        serviceid,
      ]);
      if (checkResult.rows.length > 0) {
        // Combination already exists
        reject({
          success: false,
          message: 'Combination already exists.',
        });
      }
      const script = updateKAMCustomerRelById();
      const result = await query(script, [
        KamCustomerRelId,
        Cmempcode,
        customerId,
        countryId,
        divisionid,
        verticalcode,
        serviceid,
        KAMempcode,
        duid,
        entityID,
        isactive,
        updated_by,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

function getModifiedFields(originalRecord, payload) {
  let modified = '';
  const fields = [
    { key: 'verticalid', label: 'verticalid', newKey: 'verticalId' },
    { key: 'serviceid', label: 'serviceid', newKey: 'serviceId' },
    { key: 'kamempcode', label: 'kamempcode', newKey: 'new_kamempcode' },
    { key: 'cmempcode', label: 'cmempcode', newKey: 'new_cmempcode' },
    {
      key: 'kamheadempcode',
      label: 'kamheadempcode',
      newKey: 'new_kamhempcode',
    },
    {
      key: 'effective_from_date',
      label: 'effective_from',
      newKey: 'new_effective_from',
    },
    { key: 'remarks', label: 'remarks', newKey: 'remarks' },
  ];

  fields.forEach(({ key, label, newKey }) => {
    if (newKey && payload[newKey] != null) {
      if (originalRecord[key] != payload[newKey]) {
        modified += (modified ? ', ' : '') + label;
      }
    }
  });

  return modified;
}
export const updateKAMPendingByIdService = payload => {
  return new Promise(async (resolve, reject) => {
    await transaction(client => {
      return new Promise(async (tresolve, treject) => {
        try {
          let script = '';
          const {
            cmEmpCode,
            customerId,
            countryId,
            divisionId,
            verticalId,
            serviceId,
            kamEmpCode,
            duId,
            entityId,
            remarks,
            createdBy,
            effectiveFrom,
            segmentId,
            approvedempcode,
            new_effective_from,
            new_kamempcode,
            new_cmempcode,
            queueid,
            kamcustomerrelid,
            kamHEmpCode,
            rectype,
            new_kamhempcode,
          } = payload;
          const values = [
            queueid,
            kamcustomerrelid,
            duId,
            customerId,
            countryId,
            divisionId,
            verticalId,
            serviceId,
            cmEmpCode,
            kamHEmpCode,
            new_kamempcode,
            new_cmempcode,
            entityId,
            approvedempcode,
            effectiveFrom,
            new_effective_from,
            remarks,
            createdBy,
            segmentId,
            kamEmpCode,
            new_kamhempcode,
          ];
          // get original record from the table
          const { rows } = await client.query(
            `select *, TO_CHAR(effective_from, 'YYYY/MM/DD') AS effective_from_date  from salespmo.trn_kamcustomerrel where kamcustomerrelid = $1`,
            [kamcustomerrelid],
          );
          const originalRecord = rows[0];
          const modifiedColumns = getModifiedFields(originalRecord, payload);
          // need to updat the quote for update when active insert then update record
          // update is working need to insert record
          if (rectype === 'K') {
            script = insertKAMActiveRecModifyScript();
            values.shift();
          } else if (rectype === 'P') {
            script = updateKAMPendingByIdScript();
          }
          const insertHistoryQueue = insertKAMRelPendingQueueHistory();
          const result = await client.query(script, values);
          const pendingQueueList = result.rows[0];
          const historyValues = [
            kamcustomerrelid,
            originalRecord.verticalid,
            payload.verticalId,
            originalRecord.serviceid,
            payload.serviceId,
            originalRecord.kamempcode,
            payload.new_kamempcode,
            originalRecord.cmempcode,
            payload.new_cmempcode,
            originalRecord.kamheadempcode,
            payload.new_kamhempcode,
            originalRecord.kamempcode,
            payload.new_kamhempcode,
            originalRecord.cmempcode,
            payload.new_cmempcode,
            originalRecord.updated_by,
            payload.approvedempcode,
            originalRecord.effective_from_date,
            payload.new_effective_from,
            originalRecord.effective_from_date,
            payload.new_effective_from,
            originalRecord.remarks,
            payload.remarks,
            originalRecord.created_by,
            createdBy,
            originalRecord.created_time,
            pendingQueueList.created_time, // new_created_time,
            originalRecord.updated_by,
            createdBy,
            originalRecord.updated_time,
            pendingQueueList.updated_time, // new_updated_time,
            originalRecord.statusid,
            pendingQueueList.statusid, // new_statusid,
            pendingQueueList.request_type_id, // originalRecord old_request_type_id,
            pendingQueueList.request_type_id, // new_request_type_id,
            pendingQueueList.rejection_comment, // originalRecord old_rejection_comment,
            pendingQueueList.rejection_comment, // rejection comment
            originalRecord.remarks,
            payload.remarks,
            createdBy,
            modifiedColumns,
            pendingQueueList.queueid,
          ];
          await client.query(insertHistoryQueue, historyValues);
          tresolve(result);
          resolve(result);
        } catch (error) {
          reject(error);
          treject(error);
        }
      });
    });
  });
};

export const approveRejectKAMChangeService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            const { comment, type, queueid, reqcode, userid } = payload;
            const script = approveOrRejectKAMChangeScript(type);
            const res = await client.query(script, [queueid, comment, userid]);
            const result = res?.rows[0];
            const insertOrUpdateScript = updateKAMCustomerRelScript(reqcode);
            let values = [result.kamcustomerrelid];
            if (reqcode == 'CR') {
              const updateArr = [
                result.customerid,
                result.countryid,
                result.duid,
                result.divisionid,
                result.verticalid,
                result.serviceid,
                result.new_kamempcode == null
                  ? result.kamempcode
                  : result.new_kamempcode,
                result.entityid,
                result.isactive,
                result.remarks,
                result.new_effective_from == null
                  ? result.effective_from
                  : result.new_effective_from,
                result.segmentid,
                result.updated_by,
                result.new_kamheadempcode == null
                  ? result.kamheadempcode
                  : result.new_kamheadempcode,
                result.approvedempcode,
                result.new_cmempcode == null
                  ? result.cmempcode
                  : result.new_cmempcode,
              ];
              const arr3 = values.concat(updateArr);
              values = [...arr3];
            }
            if (type == 'A') {
              const out = await client.query(insertOrUpdateScript, values);
              tresolve({ msg: 'success', data: out });
            } else {
              tresolve({ msg: 'success', data: 'rejected' });
            }
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve({ msg: 'success' });
    } catch (error) {
      reject(error);
    }
  });
};

export const getKAMCustomerRelService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText } = payload;
      const script = getKAMCustomerRel();
      const result = await query(script, [searchText]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getKAMDetailsByIdService = (rectype, id) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getKAMDetailsByIdScript(rectype);
      const result = await query(script, [id]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getKAMRelChangeService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getKAMChangeTableDataScript(payload);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getJournalRateEntryService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duId, customerId, vertical, startDate, endDate, searchText } =
        payload;

      const script =
        vertical == 'Journals'
          ? getJournalRateEntryScript()
          : getWorkOrderRateEntryScript();
      const result = await query(script, [
        duId,
        customerId,
        searchText,
        startDate || '',
        endDate || '',
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getJournalRateStageService = journalid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getJournalRateStageScript();
      const result = await query(script, [journalid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertJournalRateService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { journalid, journalacronym, currencyid, created_by, data } =
        payload;
      const script = insertJournalRateScript();
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            for (const i of data) {
              const { service, du, rate, stage, uom } = i;
              await client.query(script, [
                journalid,
                journalacronym,
                service,
                stage,
                currencyid,
                uom,
                rate,
                du,
                created_by,
              ]);
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('RateEntry successfully inserted');
    } catch (error) {
      reject(error);
    }
  });
};

export const insertRateEntryService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        workorderid,
        bookcode,
        journalid,
        journalacronym,
        currencyid,
        created_by,
        vertical,
        data,
        deleteids,
      } = payload;

      const duplicateCheckScript =
        vertical == 'Journals'
          ? checkForJournalScript()
          : checkForJobRateScript();
      const insertScript =
        vertical == 'Journals'
          ? insertJournalRateScript()
          : insertJobRateScript();
      const updateScript =
        vertical == 'Journals'
          ? updateJournalRateScript()
          : updateJobRateScript();
      const deleteScript =
        vertical == 'Journals'
          ? deleteJournalRateScript()
          : deleteJobRateScript();

      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            if (deleteids.length > 0) {
              await client.query(deleteScript, [
                vertical == 'Journals' ? journalid : workorderid,
                deleteids,
                created_by,
              ]);
            }
            for (const i of data) {
              const { service, workedDu, rate, category, uom, id, code } = i;
              const script = id == 0 ? insertScript : updateScript;
              const values = [
                vertical == 'Journals' ? journalid : workorderid,
                vertical == 'Journals' ? journalacronym : bookcode,
                service,
                category,
                currencyid,
                uom,
                rate,
                workedDu,
                created_by,
                code,
              ];
              if (id) values.push(id);
              if (id == 0) {
                const checkValues = [
                  vertical == 'Journals' ? journalid : workorderid,
                  vertical == 'Journals' ? journalacronym : bookcode,
                  service,
                  category,
                  currencyid,
                  uom,
                  workedDu,
                ];
                const duplicateRecords = await client.query(
                  duplicateCheckScript,
                  checkValues,
                );
                if (duplicateRecords?.rows.length > 0) {
                  throw new Error('Containing Duplicate entries.');
                } else {
                  await client.query(script, values);
                }
              } else {
                await client.query(script, values);
              }
            }

            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      if (vertical !== 'Journals') {
        await ubrIntegrationService({
          workorderId: workorderid,
          stageId: null,
          servicetype: 'servicecreation',
          woId: workorderid,
          woType: 'book',
        });
      }
      resolve('RateEntry successfully inserted');
    } catch (error) {
      reject(error);
    }
  });
};

export const updateJournalRateByIdService = (
  journalrateid,
  journalid,
  serviceid,
  value,
  uomid,
  isactive,
  updated_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateJournalRateScript();
      const result = await query(script, [
        journalrateid,
        journalid,
        serviceid,
        value,
        uomid,
        isactive,
        updated_by,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getJobRateService = workorderid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getJobRateScript();
      const result = await query(script, [workorderid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getJobRateAdjService = (workorderid, duid, customerid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getJobRateAdjScript();
      const result = await query(script, [workorderid, duid, customerid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertJobRateService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderid, bookcode, currencyid, created_by, data } = payload;
      const script = insertJobRateScript();
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            for (const i of data) {
              const { service, du, rate, stage, uom } = i;
              await client.query(script, [
                workorderid,
                bookcode,
                service,
                stage,
                currencyid,
                uom,
                rate,
                du,
                created_by,
              ]);
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('RateEntry successfully inserted');
    } catch (error) {
      reject(error);
    }
  });
};

export const updateJobRateByIdService = (
  jobrateid,
  workorderid,
  bookcode,
  serviceid,
  stage,
  value,
  uomid,
  isactive,
  updated_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateJobRateScript();
      const result = await query(script, [
        jobrateid,
        workorderid,
        bookcode,
        serviceid,
        stage,
        value,
        uomid,
        isactive,
        updated_by,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getServiceMapService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getServiceMapScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getStageMapService = servicemapid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getStageMapScript();
      const result = await query(script, [servicemapid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertServiceAndStageMappingService = (
  duid,
  Customerid,
  serviceid,
  stages,
  created_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = insertServiceAndStageMapping(
        duid,
        Customerid,
        serviceid,
        stages,
        created_by,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateServiceMappingByIdService = (
  servicemapping_id,
  duid,
  Customerid,
  serviceid,
  billableduid,
  isactive,
  updated_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateServiceMappingById();
      const result = await query(script, [
        duid,
        servicemapping_id,
        duid,
        Customerid,
        serviceid,
        billableduid,
        isactive,
        updated_by,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateStageMappingByIdService = (
  stagemapping_id,
  servicemapping_id,
  StageId,
  Stageseq,
  isactive,
  updated_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = updateStageMappingById();
      const result = await query(script, [
        stagemapping_id,
        servicemapping_id,
        StageId,
        Stageseq,
        isactive,
        updated_by,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getInitialPlanTemplateDownloadService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getPlanTemplateScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertReassignKamOrCmService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { insertList, updateList, cm, kam, effectiveFrom, reason, userid } =
        payload;
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            let updatedRemarks = '';
            if (kam == '' && cm != '') {
              updatedRemarks += `${updatedRemarks ? ', ' : ''}cmempcode`;
            } else if (cm == '' && kam != '') {
              updatedRemarks += `${updatedRemarks ? ', ' : ''}kamempcode`;
            } else {
              updatedRemarks += `${
                updatedRemarks ? ', ' : ''
              }kamempcode, cmempcode`;
            }
            updatedRemarks += `${
              updatedRemarks ? ', ' : ''
            }effective_from, remarks, statusid`;
            const updateKAMCMScript = updateKAMCMPendingReassignScript();
            const updateKAMScript = updateKAMPendingReassignScript();
            const updateCMScript = updateCMPendingReassignScript();
            const insertScript = insertKAMPendingReassignScript();
            const insertHistory = insertKAMRelPendingQueueHistory();
            const old_status = await client.query(
              `select  statusid  from  salespmo.mst_status where statuscode = 'A'`,
            );
            const new_status = await client.query(
              `select  statusid  from  salespmo.mst_status where statuscode = 'P'`,
            );
            for (const i of updateList) {
              if (kam == '' && cm != '') {
                await client.query(updateCMScript, [
                  i.id,
                  cm,
                  effectiveFrom,
                  reason,
                  userid,
                ]);
              } else if (cm == '' && kam != '') {
                await client.query(updateKAMScript, [
                  i.id,
                  kam,
                  effectiveFrom,
                  reason,
                  userid,
                ]);
              } else {
                await client.query(updateKAMCMScript, [
                  i.id,
                  kam,
                  cm,
                  effectiveFrom,
                  reason,
                  userid,
                ]);
              }
            }
            for (const i of insertList) {
              const res = await client.query(insertScript, [
                i.id,
                kam == '' ? i.old_kam : kam,
                cm == '' ? i.old_cm : cm,
                effectiveFrom,
                reason,
                userid,
              ]);
              const result = res?.rows[0];
              const historyValues = [
                result.kamcustomerrelid, // kamcustomerrelid,
                result.verticalid, // old_verticalid,
                result.verticalid, // new_verticalid,
                result.serviceid, // old_serviceid,
                result.serviceid, // new_serviceid,
                result.kamempcode, // old_kamempcode,
                result.new_kamempcode, // new_kamempcode,
                result.cmempcode, // old_cmempcode,
                result.new_cmempcode, // new_cmempcode,
                result.kamheadempcode, // old_kamheadempcode,
                result.kamheadempcode, // new_kamheadempcode,
                null, // old_new_kamempcode,
                null, // new_new_kamempcode,
                null, // old_new_cmempcode,
                null, // new_new_cmempcode,
                null, // old_approvedempcode,
                null, // new_approvedempcode,
                i.old_effective_from, // old_effective_from,
                result.effective_from, // new_effective_from,
                null, // old_new_effective_from,
                null, // new_new_effective_from,
                i.old_remarks, // old_remarks,
                result.remarks, // new_remarks,
                result.created_by, // old_created_by,
                result.created_by, // new_created_by,
                result.created_time, // old_created_time,
                result.created_time, // new_created_time,
                result.updated_by, // old_updated_by,
                result.updated_by, // new_updated_by,
                result.updated_time, // old_updated_time,
                result.updated_time, // new_updated_time,
                old_status?.rows[0]?.statusid, // old_statusid,
                new_status?.rows[0]?.statusid, // new_statusid,
                result.request_type_id, // old_request_type_id,
                result.request_type_id, // new_request_type_id,
                result.rejection_comment, // old_rejection_comment,
                result.rejection_comment, // new_rejection_comment,
                result.change_reason, // old_change_reason,
                result.change_reason, // new_change_reason,
                userid, // changed_by,
                updatedRemarks, // updated_remarks,
                result.queueid, // queueid,
              ];
              await client.query(insertHistory, historyValues);
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('result');
    } catch (error) {
      reject(error);
    }
  });
};

export const getSegmentService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = '';
      sql = `SELECT COUNT(*) FROM salespmo.mst_segment`;
      const getCount = await query(sql);
      const script = getSegment();
      const result = await query(script);
      if (getCount[0].count == 0) {
        resolve({ data: [], total: getCount[0].count });
      }
      resolve({ data: result, total: getCount[0].count });
    } catch (error) {
      reject(error);
    }
  });
};

export const getVerticalService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = '';
      sql = `SELECT COUNT(*) FROM public.wms_mst_vertical`;
      const getCount = await query(sql);
      const script = getVertical();
      const result = await query(script);
      if (getCount[0].count == 0) {
        resolve({ data: [], total: getCount[0].count });
      }
      resolve({ data: result, total: getCount[0].count });
    } catch (error) {
      reject(error);
    }
  });
};

export const setSegmentService = ({ id, segmentname, status, createdBy }) => {
  return new Promise(async (resolve, reject) => {
    try {
      let script;
      let result;

      if (id === '') {
        script = insertSegment();
        result = await query(script, [segmentname, status, createdBy]);
      } else {
        script = updateSegment();
        result = await query(script, [id, segmentname, status, createdBy]);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteSegmentService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { id } = param;
      const result = await deleteSegment(id);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const setVerticalService = ({
  id,
  verticalname,
  verticalcode,
  status,
  createdBy,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      let script;
      let result;

      if (id === '') {
        script = insertVertical();
        result = await query(script, [
          verticalname,
          verticalcode,
          status,
          createdBy,
        ]);
      } else {
        script = updateVertical();
        result = await query(script, [
          id,
          verticalname,
          verticalcode,
          status,
          createdBy,
        ]);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteVerticalService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { id } = param;
      const result = await deleteVertical(id);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getServiceService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = '';
      sql = `SELECT COUNT(*) FROM public.wms_mst_service`;
      const getCount = await query(sql);
      const script = getService();
      const result = await query(script);
      if (getCount[0].count == 0) {
        resolve({ data: [], total: getCount[0].count });
      }
      resolve({ data: result, total: getCount[0].count });
    } catch (error) {
      reject(error);
    }
  });
};

export const setServiceService = ({
  id,
  servicename,
  servicedesc,
  status,
  createdBy,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      let script;
      let result;

      if (id === '') {
        script = insertService();
        const resultmaxid = await query(
          'SELECT COALESCE(MAX(serviceid), 0) + 1 AS next_serviceid FROM public.wms_mst_service',
        );
        const nextServiceId = resultmaxid[0].next_serviceid;

        result = await query(script, [
          nextServiceId,
          servicename,
          servicedesc,
          status,
          createdBy,
        ]);
      } else {
        script = updateService();
        result = await query(script, [
          id,
          servicename,
          servicedesc,
          status,
          createdBy,
        ]);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteServiceService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { id } = param;
      const result = await deleteService(id);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const checkSegmentService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { segmentName, id } = param;
      let idnew = null; // Declare idnew variable outside of the if block
      if (id === '') {
        idnew = null;
      } else {
        idnew = id;
      }
      const script = checkSegment(); // Get the SQL script
      const result = await query(script, [segmentName, idnew]); // Assuming query is a function to execute SQL queries
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const checkVerticalService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { verticalname, id } = param;
      let idnew = null;
      if (id === '') {
        idnew = null;
      } else {
        idnew = id;
      }
      const script = checkVertical();
      const result = await query(script, [verticalname, idnew]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const checkServiceService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { servicename, id } = param;
      let idnew = null;
      if (id === '') {
        idnew = null;
      } else {
        idnew = id;
      }
      const script = checkService();
      const result = await query(script, [servicename, idnew]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getKAMPendingQueueHistoryService = queueid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getKAMPendingQueueHistoryScript();
      const result = await query(script, [queueid]);
      const outputData = result.reduce((acc, curr) => {
        const { date, month, ...rest } = curr;
        // Find if the date/month combination already exists in the accumulator
        let dateGroup = acc.find(
          group => group.date === date && group.month === month,
        );
        // If not, create a new group and add it to the accumulator
        if (!dateGroup) {
          dateGroup = { date, month, record: [] };
          acc.push(dateGroup);
        }
        // Add the current record to the appropriate date/month group
        dateGroup.record.push(rest);
        return acc;
      }, []);
      resolve(outputData);
    } catch (error) {
      reject(error);
    }
  });
};

export const setOrdInflowService = async inputjson => {
  return new Promise(async resolve => {
    const {
      workorderId,
      journalacronym,
      divisionname,

      userId,
      type,
      fc_oifcalctype,
    } = inputjson;

    let {
      jobId,
      vertical,
      quantity,
      baseduname,
      duname,
      duId,
      customerId,
      journalId,
      stageId,
      baseduid,
      divisionid,
      countryid,
      verticalid,
      verticalname,
      segmentid,
      serviceid,
      servicename,
      jobcreatedon,
      customername,
      countryname,
      createdmonth,
      celevel,
      celevelid,
      billableduid,
      segmentname,
      uomId,
      stageName,
      complexityid,
      complexityname,
      // fc_orderinflow,
      // fc_unbilledrevenue,
      // fc_invoice,
      // fc_ubrcalctype,
      // fc_invoicecalctype,
    } = inputjson;
    let valid_prerequest = false;
    let local_error = '';
    try {
      quantity = quantity ?? 0;

      if (workorderId == undefined || workorderId == null || workorderId < 1) {
        throw new Error(`workorderId is not valid ${workorderId}`);
      } else if (
        type == undefined ||
        (type?.toUpperCase() != 'NEW' && type?.toUpperCase() != 'OLD')
      ) {
        throw new Error(
          `The type is not valid. (${type}), it should be either "new" or "old'`,
        );
      } else if (
        fc_oifcalctype == null ||
        fc_oifcalctype == undefined ||
        (fc_oifcalctype?.toUpperCase() !== 'INITIAL' &&
          fc_oifcalctype?.toUpperCase() !== 'DISPATCH')
      ) {
        throw new Error(
          `Calculation type ${fc_oifcalctype} , it should be either "INITIAL" or "DISPATCH"`,
        );
      }

      // else if (uomId == undefined || uomId == null || uomId == 0) {
      //   throw new Error(`Invalid Uom ${uomId}`);
      // }

      if (type === 'new') {
        const sql = `SELECT
        wo.workorderid , wo.itemcode , itrdu.duId , itrdu.duname, itrcust.customerid , itrcust.customername,
        di.divisionid , di.division , co.countryid , co.countryname,
        itrdu.duId as baseduid , mser.serviceid , mser.servicename,
        TO_CHAR(wo.createdon,'YYYY-MM-DD hh:mi:ss') as jobcreatedon, 
        TO_CHAR(wo.createdon,'YYYY-MM-DD hh:mi:ss') AS createdmonth,
        subd.subdivisionid as verticalid, 
        subd.subdivision as verticalname,
        subd.verticalcode , wo.journalid,
        mcopy.displayname as celevel,
        wo.celevelid ,
        wo.complexityid,
        wmc.complexity
        FROM wms_workorder AS wo 
        JOIN public.org_mst_customer as cu ON cu.customerid = wo.customerid  
        JOIN public.org_mst_division as di ON di.divisionid = wo.divisionid
        JOIN public.geo_mst_country as co ON co.countryid = wo.countryid
        JOIN public.org_mst_customer_orgmap as cog ON cog.divisionid = wo.divisionid AND 
        cog.customerid = wo.customerid  AND cog.subdivisionid = wo.subdivisionid
        AND cog.countryid = wo.countryid
        JOIN public.org_mst_subdivision as subd ON subd.subdivisionid = wo.subdivisionid
        JOIN public.org_mst_customerorg_du_map as cdu on cdu.custorgmapid = cog.custorgmapid and cdu.duid = CASE WHEN wo.flowtype = 'nonwms' then wo.duid else cdu.duid end
        JOIN public.org_mst_deliveryunit as du on du.duid = cdu.duid
        LEFT JOIN public.org_mst_customerorg_service_map as ser on ser.custorgmapid = cog.custorgmapid
        LEFT JOIN public.wms_mst_service as mser on mser.serviceid = ser.serviceid  
        JOIN public.mst_deliveryunit as itrdu on itrdu.duid = du.itrackduid
        join public.mst_customer as itrcust on itrcust.customerid = cu.itrack_customerid
        LEFT join public.pp_mst_copyeditinglevel as mcopy on mcopy.celevelid = wo.celevelid
        left join public.wms_mst_complexity wmc on wmc.complexityid = wo.complexityid
        WHERE wo.workorderid = ${workorderId}`;

        const qresult = await query(sql);

        if (qresult && qresult.length > 0) {
          console.log(qresult, 'qresult');
          duId = qresult[0].duid;
          jobId = qresult[0].itemcode;
          duname = qresult[0].duname;
          baseduid = qresult[0].baseduid;
          baseduname = qresult[0].duname;
          jobcreatedon = qresult[0].jobcreatedon;
          createdmonth = qresult[0].createdmonth;
          customerId = qresult[0].customerid;
          customername = qresult[0].customername;
          countryid = qresult[0].countryid;
          countryname = qresult[0].countryname;

          divisionid = qresult[0].divisionid;
          verticalid = qresult[0].verticalid;
          verticalname = qresult[0].verticalname;
          vertical = qresult[0].verticalcode;
          celevel = qresult[0].celevel;
          celevelid = qresult[0].celevelid;
          journalId = qresult[0].journalid ? qresult[0].journalid : 0;
          complexityid = qresult[0].complexityid;
          complexityname = qresult[0].complexity;
          // Hardcode due to WMS Teams not enough time to fix it hence the hardcode
          if (complexityname == null) {
            complexityname = 'No Complexity';
            complexityid = 12;
          }
          console.log(journalacronym);
          console.log(createdmonth);
          console.log(complexityid);
          segmentname = '';
          servicename = '';
        } else {
          throw new Error('workorder data not found');
        }
      } else if (type === 'old') {
        const v_duname = await query(
          `SELECT duid FROM public.mst_deliveryunit 
          WHERE duname  = $1`,
          [duname],
        );

        duId = v_duname.length > 0 ? v_duname[0].duid : null;

        const v_baseduname = await query(
          `SELECT duid FROM public.mst_deliveryunit 
          WHERE duname  = $1`,
          [baseduname],
        );

        baseduid = v_baseduname.length > 0 ? v_baseduname[0].duid : null;

        const v_Customername = await query(
          `SELECT customerid FROM public.mst_customer 
          WHERE customername  = $1`,
          [customername],
        );

        customerId =
          v_Customername.length > 0 ? v_Customername[0].customerid : null;

        const v_divisionname = await query(
          `SELECT divisionid FROM public.org_mst_division 
          WHERE division  = $1`,
          [divisionname],
        );

        divisionid =
          v_divisionname.length > 0 ? v_divisionname[0].divisionid : null;

        const v_countryname = await query(
          `SELECT countryid FROM public.geo_mst_country 
          WHERE countryname  = $1`,
          [countryname],
        );

        countryid =
          v_countryname.length > 0 ? v_countryname[0].countryid : null;

        const v_stagename = await query(
          `SELECT stageid FROM public.wms_mst_stage 
          WHERE stagename  = $1`,
          [stageName],
        );

        stageId = v_stagename.length > 0 ? v_stagename[0].stageid : null;

        const v_vertical = await query(
          `SELECT verticalid,verticalname,verticaldescription FROM public.wms_mst_vertical 
          WHERE UPPER(verticaldescription) = UPPER($1)`,
          [vertical],
        );
        verticalid = v_vertical.length > 0 ? v_vertical[0].verticalid : null;
        verticalname =
          v_vertical.length > 0 ? v_vertical[0].verticalname : null;

        const v_journalacronym = await query(
          `SELECT journalid FROM public.pp_mst_journal 
          WHERE journalacronym  = $1`,
          [journalId],
        );

        journalId =
          v_journalacronym.length > 0 ? v_journalacronym[0].journalid : null;
      }

      const checkvariable = await validateVariables({
        duId,
        jobId,
        duname,
        baseduid,
        baseduname,
        jobcreatedon,
        createdmonth,
        customerId,
        customername,
        countryid,
        countryname,
        divisionid,
        verticalid,
        verticalname,
        vertical,
        celevel,
        celevelid,
        journalId,
        stageId,
        complexityname,
      });

      valid_prerequest = checkvariable.valid;

      if (!valid_prerequest) {
        throw new Error(checkvariable.message);
      }

      const incomingsql = `SELECT 
        sum(inf.mspages) as mspages,
        sum(coalesce(inf.estimatedpages,0)) as estimatedpages,
        sum(coalesce(inf.typesetpage,0)) as typesetpage,
        sum(coalesce(inf.imagecount,0)) as imagecount,
        sum(coalesce(inf.tablecount,0)) as tablecount,
        sum(coalesce(inf.equationcount,0)) as equationcount,
        sum(coalesce(inf.wordcount,0)) as wordcount,
        sum(inf.referencecount) as  referencecount
        FROM wms_workorder AS wo
        JOIN wms_workorder_incoming AS inc ON inc.woid = wo.workorderid  
        JOIN wms_workorder_incomingfiledetails AS inf ON inf.woincomingid = inc.woincomingid
        WHERE wo.workorderid = $1  ORDER BY 1 DESC`;
      const incomingdetail = await query(incomingsql, [workorderId]);

      if (incomingdetail == undefined || incomingdetail.length == 0) {
        throw new Error(`Error on getting pages details from incoming details`);
      }

      const wostagedetail = await query(
        `select mst.stagename, ws.* from wms_workorder_stage ws
        join wms_mst_stage as  mst on mst.stageid = ws.wfstageid
        where ws.workorderid = $1 and ws.wfstageid = $2`,
        [workorderId, stageId],
      );

      if (wostagedetail == undefined || wostagedetail.length == 0) {
        throw new Error(`Error on getting stage details`);
      }
      if (wostagedetail.length > 0) {
        stageName = wostagedetail[0].stagename;
      }

      if (incomingdetail != undefined && incomingdetail.length) {
        if (fc_oifcalctype?.toUpperCase() === 'INITIAL') {
          // if (
          //   incomingdetail[0].estimatedpages == null ||
          //   incomingdetail[0].estimatedpages < 2
          // ) {
          //   throw new Error(`Estimated pages is not valid`);

          // }

          quantity = +incomingdetail[0].estimatedpages || 1;
        } else if (wostagedetail != undefined && wostagedetail.length) {
          // if (
          //   wostagedetail[0].typesetpages == null ||
          //   wostagedetail[0].typesetpages < 2
          // ) {
          //   throw new Error(`Typeset pages is not valid`);
          // }
          quantity = +wostagedetail[0].typesetpages || 1;
        }
      } else {
        throw new Error(`Incoming details not found`);
      }
      // quantity = 21;

      const rateconfig = await query(
        `select rec.serviceid, rec.uomid,wmu.uom ,rec.category, umet.metric , mse.servicename
        from salespmo.rate_entry_config as rec
        left join salespmo.metric_config as umet on rec.uomid = umet.uomid
        left join public.wms_mst_service as  mse on mse.serviceid  = rec.serviceid 
        left join wms_mst_uom as wmu on wmu.uomid = rec.uomid and wmu.isactive = 1
        where 
        rec.duid = $1 and
        rec.customerid = $2 and 
        (rec.category = $3 OR rec.category=$5 OR rec.category in ('N/A','NA')) and
        $4 = any(array[rec.oif_stageid])  and         
        rec.is_active = true`,
        [duId, customerId, celevel, stageId, complexityname],
      );

      if (rateconfig.length == 0) {
        throw new Error(`Service details not found in rate config`);
      }
      // for each service put entry to the table
      for (let i = 0; i < rateconfig.length; i++) {
        // NA
        serviceid = +rateconfig[i].serviceid;
        uomId = +rateconfig[i].uomid;
        const currentcelevel = rateconfig[i].category;
        const metrictype = rateconfig[i].metric;
        servicename = rateconfig[i].servicename;
        const uomname = rateconfig[i].uom;

        if (serviceid == undefined || serviceid == null) {
          local_error = `service detail not present in rate config duId = ${duId}, customerId = ${customerId}, celevel = ${celevel}, stageId = ${stageId}`;
          break;
        } else if (currentcelevel == undefined || currentcelevel == null) {
          local_error = `celevel detail not present in rate config duId = ${duId}, customerId = ${customerId}, celevel = ${celevel}, stageId = ${stageId}`;
          break;
        } else if (uomId == undefined || uomId == null) {
          local_error = `Uom detail not present in rate config duId = ${duId}, customerId = ${customerId}, celevel = ${celevel}, stageId = ${stageId}`;
          break;
        } else if (metrictype == undefined || metrictype == null) {
          local_error = `metric config not mapped for the uom in rate config duId = ${duId}, customerId = ${customerId}, celevel = ${celevel}, stageId = ${stageId}`;
          break;
        }

        if (fc_oifcalctype?.toUpperCase() === 'INITIAL') {
          if (uomname == 'No. of Pages') {
            if (
              incomingdetail[0].estimatedpages == null ||
              incomingdetail[0].estimatedpages < 1
            ) {
              // throw new Error(`Estimated pages is not valid`);
              local_error = `Estimated pages is not valid`;
              break;
            }
            quantity = +incomingdetail[0].estimatedpages;
          } else if (uomname == 'Word Count') {
            if (
              incomingdetail[0].wordcount == null ||
              incomingdetail[0].wordcount < 1
            ) {
              // throw new Error(`Estimated pages is not valid`);
              local_error = `wordcount pages is not valid`;
              break;
            }
            quantity = +incomingdetail[0].wordcount;
          } else if (uomname == 'MS Pages') {
            if (
              incomingdetail[0].mspages == null ||
              incomingdetail[0].mspages < 1
            ) {
              // throw new Error(`Estimated pages is not valid`);
              local_error = `MS Pages pages is not valid`;
              break;
            }
            quantity = +incomingdetail[0].mspages;
          } else if (uomname == 'Images') {
            if (incomingdetail[0].imagecount == null) {
              // throw new Error(`Estimated pages is not valid`);
              local_error = `Image count is not valid`;
              break;
            }
            quantity = +incomingdetail[0].imagecount;
          } else if (metrictype.toUpperCase() == 'QUANTITY') {
            quantity = +incomingdetail[0].estimatedpages;
          } else if (metrictype.toUpperCase() == 'RATE') {
            quantity = 1;
          }
        } else if (
          fc_oifcalctype?.toUpperCase() === 'DISPATCH' &&
          metrictype.toUpperCase() == 'RATE'
        ) {
          quantity = 1;
        }

        let precondition = true;
        const scriptrate =
          vertical == 'J'
            ? `select value , billableduid, currencyid from salespmo.trn_journal_rate
          where journalid = $1 and serviceid = $2 and category = $3  and uomid = $4
          and isactive = true`
            : `select value , billableduid, currencyid from salespmo.trn_job_rate
          where workorderid = $1 and serviceid = $2 and category = $3  and uomid = $4
          and isactive = true`;

        const jobjournalratedata = await query(scriptrate, [
          vertical == 'J' ? journalId : workorderId,
          serviceid,
          currentcelevel,
          uomId,
        ]);

        if (jobjournalratedata == undefined || jobjournalratedata.length < 1) {
          precondition = false;
          local_error = `Rate Details not present for 
            Journal/Job ${
              vertical == 'J' ? journalId : workorderId
            } , service ${serviceid},copyediting ${currentcelevel},uom ${uomId}`;
          break;
        }

        // if2
        if (precondition) {
          billableduid = +jobjournalratedata[0].billableduid;

          if (
            jobjournalratedata[0].currencyid == null ||
            jobjournalratedata[0].currencyid == undefined
          ) {
            local_error = `currency is not valid for Journal/Job = ${
              vertical == 'J' ? journalId : workorderId
            }, service = ${serviceid}, celevel = ${currentcelevel} and uom = ${uomId}`;
            break;
          }

          const p_CurrencyId = jobjournalratedata[0].currencyid;
          const p_itemrate =
            jobjournalratedata[0].value > 0 ? jobjournalratedata[0].value : 0;

          // not useing
          // const v_jobCurrencyId = await query(
          //   `SELECT  COALESCE(currencyid,0) as currencyid
          //   FROM salespmo.trn_job_rate
          //   WHERE serviceid = $1 AND $2 = ANY(stageid) AND workorderid = $3  AND uomid = $4`,
          //   [serviceid, stageId, workorderId,  uomId],
          // );
          // const p_jobCurrencyId =
          //   v_jobCurrencyId.length > 0 ? v_jobCurrencyId[0].currencyid : null;

          // const v_jobCurrencyname = await query(
          //   'SELECT currencycode FROM public.mst_currencymst WHERE currencyid = $1',
          //   [p_jobCurrencyId],
          // );

          // const p_jobCurrencyname =
          //   v_jobCurrencyname.length > 0
          //     ? v_jobCurrencyname[0].currencycode
          //     : null;

          // const v_jobrate = await query(
          //   `SELECT COALESCE(value,0) as value
          //     FROM salespmo.trn_job_rate
          //     WHERE serviceid = $1 AND $2 = ANY(stageid)  AND workorderid = $3 AND bookcode = $4 AND uomid = $5`,
          //   [serviceid, stageId, workorderId, jobId, uomId],
          // );

          // const p_jobrate = v_jobrate.length > 0 ? v_jobrate[0].value : 0;

          const v_MstCurrencyname = await query(
            'SELECT currencycode FROM public.mst_currencymst WHERE currencyid = $1',
            [p_CurrencyId],
          );
          const p_Currencyname =
            v_MstCurrencyname.length > 0
              ? v_MstCurrencyname[0].currencycode
              : null;

          const v_uom = await query(
            'select uom from  wms_mst_uom where uomid = $1',
            [uomId],
          );
          const p_uom = v_uom.length > 0 ? v_uom[0].uom : null;

          const v_segmentname = await query(
            'select segment_id from salespmo.mst_segment where segment_name  = $1 ',
            [segmentid],
          );
          segmentid =
            v_segmentname.length > 0 ? v_segmentname[0].segment_id : null;
          let v_Actualadjremarks = '';
          let v_rate = 0;
          let finalvalue = 0;
          let initialqty = 0;
          let adjustmentqty = 0;
          let v_CurrencyId = 0;
          let v_Currencyname = '';

          if (vertical === 'B' && p_itemrate === 0) {
            throw new Error('Book Rate Entry Not Found');
          } else if (vertical === 'J' && p_itemrate === 0) {
            throw new Error('Journal Rate Entry Not Found');
          }
          // else if (vertical === 'J') {
          v_rate = +p_itemrate;
          v_CurrencyId = +p_CurrencyId;
          v_Currencyname = p_Currencyname;
          // }
          // else {
          //   v_rate = +p_jobrate;
          //   v_CurrencyId = +p_jobCurrencyId;
          //   v_Currencyname = p_jobCurrencyname;
          // }
          let v_Actualvalue = 0;
          if (metrictype?.toUpperCase() == 'QUANTITY') {
            v_Actualvalue = v_rate * quantity;
            v_Actualadjremarks = `COST OF RATE * QUANTITY (${v_rate} * ${quantity}) = ${v_Actualvalue}`;
          } else {
            v_Actualvalue = v_rate;
            v_Actualadjremarks = `DIRECT COST OF RATE IS ${v_rate}`;
          }

          //  const v_Actualvalue = v_rate * quantity;
          finalvalue = v_Actualvalue;

          let insert_oineworder = '';
          let update_currentmonthorder = '';
          let insert_oinewstage = '';

          let pk_ord_inflowid = 0;
          let pk_inflow_stageid = 0;

          //* ** check main order **** */
          const v_oireport = await query(
            `select ord_inflowid,workorderid,created_time,flowtype 
            FROM salespmo.trn_ord_inflow_report r 
            where workorderid = $1 and
            bookcode = $2 and baseduid = $3 and customerid = $4 and
            divisionid = $5 and countryid = $6 and verticalid = $7 and
            currencyid = $8 and flowtype ilike $9 and isactive =  true`,
            [
              workorderId,
              jobId,
              baseduid,
              customerId,
              divisionid,
              countryid,
              verticalid,
              p_CurrencyId,
              type,
            ],
          );

          //* *** check duplicate entry in orderinflow table  ****/
          const chkduplicate = await query(
            `select toisr.*
              from salespmo.trn_ord_inflow_report oir
              join salespmo.trn_ord_inflow_stagewise_report toisr
                  on toisr.ord_inflowid = oir.ord_inflowid
              where
              oir.workorderid = $1 and
              toisr.inflowtype ilike $2 and
              toisr.stageid = $3 and
              toisr.serviceid = $4`,
            [workorderId, fc_oifcalctype, stageId, serviceid],
          );

          if (chkduplicate != undefined && chkduplicate.length > 0) {
            // local_error = `Inflow allready captured for this
            //       workorderid ${workorderId} and type ${fc_oifcalctype} and stage ${stageName} and service ${servicename}`;
            // break;
            console.log('temporary comment');
          }

          if (v_oireport != undefined && v_oireport.length > 0) {
            //* ** take primary key of main table **** */
            pk_ord_inflowid = +v_oireport[0].ord_inflowid;

            //* ** check stage wise order **** */
            const v_oistagereport = await query(
              `select inflow_stageid, inflowtype, 
              case when to_char(ordermonth,'yyyy-mm') = to_char(current_timestamp,'yyyy-mm') 
              then 'YES' else 'NO' end as iscurrentmonth 
              from salespmo.trn_ord_inflow_stagewise_report 
              where ord_inflowid = $1 and serviceid = $2
              and stageid = $3
              and upper(inflowtype) = $4`,
              [
                pk_ord_inflowid,
                serviceid,
                stageId,
                fc_oifcalctype?.toUpperCase(),
              ],
            );

            if (v_oistagereport != undefined && v_oistagereport.length) {
              //* ** take ordermonth is current month to update **** */
              update_currentmonthorder = v_oistagereport[0].iscurrentmonth;

              //* ** take primary key of stage table **** */
              pk_inflow_stageid = v_oistagereport[0].inflow_stageid;
            } else {
              insert_oinewstage = 'YES';
            }
          } else {
            insert_oineworder = 'YES';
          }

          //* ** take sum of previous rate (INITIAL AND ADJUSTED VALUE)  *****/
          if (fc_oifcalctype?.toUpperCase() === 'DISPATCH') {
            const getsum = await query(
              `select 
                 sum(actualinflowvalue) as sumrate 
                ,sum(uomqty) as initialqty
             from salespmo.trn_ord_inflow_stagewise_report 
             where ord_inflowid = $1 and serviceid = $2 
             and stageid = $3
             and upper(inflowtype) != 'DISPATCH' and isactive = true`,
              [pk_ord_inflowid, serviceid, stageId],
            );

            if (getsum != undefined && getsum.length) {
              //* ** subtract sum value to actual value **** */
              finalvalue = v_Actualvalue - +getsum[0].sumrate;
              initialqty = +getsum[0].initialqty;
              adjustmentqty = quantity - initialqty;
              v_Actualadjremarks += ` ,(ACTUAL VALUE ${v_Actualvalue} - PREVIOUS VALUE ${+getsum[0]
                .sumrate} =  ${finalvalue}) AND ADJUSTED QTY = ${adjustmentqty}`;
            }
          }

          if (update_currentmonthorder == 'YES') {
            const updateScript = updateOrdInflowScript();
            await query(updateScript, [
              pk_inflow_stageid,
              quantity,
              v_rate,
              finalvalue,
              v_Actualadjremarks,
              userId,
              adjustmentqty,
            ]);
            local_error = 'success';
            // resolve(result);
          } else if (insert_oinewstage == 'YES') {
            const stageScript = insertOrdInflowstageScript();
            await query(stageScript, [
              pk_ord_inflowid,
              serviceid,
              servicename,
              stageId,
              stageName,
              uomId,
              p_uom,
              quantity,
              v_rate,
              finalvalue,
              v_Actualadjremarks,
              userId,
              celevelid,
              fc_oifcalctype,
              billableduid,
              baseduname,
              adjustmentqty,
            ]);
            local_error = 'success';
            // resolve(result);
          } else if (insert_oineworder == 'YES') {
            const insertScript = insertOrdInflowScript();
            const flowtype = 'NEW';
            await query(insertScript, [
              workorderId,
              jobId,
              baseduid,
              baseduname,
              customerId,
              customername,
              divisionid,
              divisionname,
              countryid,
              countryname,
              verticalid,
              verticalname,
              segmentid,
              segmentname,
              v_CurrencyId,
              v_Currencyname,
              jobcreatedon,
              flowtype,
              userId,
              serviceid,
              servicename,
              stageId,
              stageName,
              uomId,
              p_uom,
              quantity,
              v_rate,
              finalvalue,
              v_Actualadjremarks,
              celevelid,
              fc_oifcalctype,
              billableduid,
            ]);

            local_error = 'success';
            // resolve(result);
          } else {
            // resolve({ message: 'order inflow not captured' });
            local_error = 'order inflow not captured';
            break;
          }
        } // end of if condition after for loop
        else {
          local_error = `Rate details not present for 
             Journal/Job ${
               vertical == 'J' ? journalId : workorderId
             } , service ${serviceid},copyediting ${currentcelevel},uom ${uomId}`;
          break;
        }
      } // end of forloop
    } catch (error) {
      local_error = error.message;
      // reject(error.message);
    } finally {
      const logresut = await logOrderinflow({
        workorderId,
        stageId,
        fc_oifcalctype,
        type,
        remark: local_error,
        issuccess: false,
      });
      console.log(logresut);
      resolve(local_error);
    }
  });
};

export const logOrderinflow = async payload => {
  const { workorderId, stageId, fc_oifcalctype, type, remark, issuccess } =
    payload;
  return new Promise(async resolve => {
    try {
      const esql = `insert into salespmo.log_orderinflow(workorderid, stageid, calctype, flowtype, remarks, issuccess)
        values($1,$2,$3,$4,$5,$6)`;

      await query(esql, [
        workorderId,
        stageId,
        fc_oifcalctype,
        type,
        remark,
        issuccess,
      ]);
      resolve('true');
    } catch (error) {
      console.log(error);
      resolve('false');
    }
  });
};

export const validateVariables = async variables => {
  const Variables = variables;
  console.log(variables);
  const missingVariables = [];

  for (const [key, value] of Object.entries(Variables)) {
    if (value === undefined || value === null || value === '') {
      missingVariables.push(key);
    }
  }

  if (missingVariables.length > 0) {
    return {
      valid: false,
      message: `The following details are mandatory: ${missingVariables.join(
        ', ',
      )}`,
    };
  }
  return {
    valid: true,
    message: 'success',
  };
};

// Plan Upload
export const planUploadService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { Exceldata, createdBy, key, Year } = payload;
      const result = validateFile(Exceldata, createdBy, key, Year);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getExceptionDataService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getExceptiondata();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSalesPMOMasterDropDownService = tblname => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getMasterDropDownScript(tblname);
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getExchangeCurrencyandRateService = year => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getExchangeCurrencyandRate(year);
      const result = await query(script, [year]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const InsorUpdExchangeRateService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { currencyList, Year, updatedBy } = payload;
      const isExistScript = checkIfExistExchangeRate();
      const InsertScript = InsertCurrencyExchangeRate();
      const updateScript = UpdateCurrencyExchangeRate();
      const queryPromises = currencyList.map(async item => {
        if (item.exchangerate) {
          const ifExist = await query(isExistScript, [
            item.currencyid,
            item.year,
          ]);
          if (ifExist.length > 0) {
            await query(updateScript, [
              item.exchangerate,
              updatedBy,
              item.currencyid,
              item.year,
            ]);
          } else {
            await query(InsertScript, [
              item.currencyid,
              Year,
              item.exchangerate,
              true,
              updatedBy,
            ]);
          }
        }
      });
      const result = await Promise.all(queryPromises);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getYearDropdownService = key => {
  return new Promise(async (resolve, reject) => {
    try {
      let script = '';
      if (key === 'Budget') {
        script = getBudgetFinancialYear();
      } else if (key === 'Target') {
        script = getTargetFinancialYear();
      }
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRateEntryMapScreenServiceDDService = (duId, customerId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getRateEntryMapScreenServiceDDScript();
      const result = await query(script, [duId, customerId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUploadedPlanDetailsService = (key, Year) => {
  return new Promise(async (resolve, reject) => {
    try {
      let script = '';
      if (key === 'Budget') {
        script = getBudgetPlanDetails();
      } else if (key === 'Target') {
        script = getTargetPlanDetails();
      }
      const result = await query(script, [Year]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getStageDDByserviceMappingService = serviceMapId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getStageDDByserviceMapIdScript();
      const result = await query(script, [serviceMapId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUploadedPlanService = (key, Year, userId, uploaded_date) => {
  return new Promise(async (resolve, reject) => {
    try {
      let script = '';
      if (key === 'Budget') {
        script = getBudgetPlan();
      } else if (key === 'Target') {
        script = getTargetPlan();
      }
      const result = await query(script, [
        Year,
        userId,
        uploaded_date.split('T')[0],
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insandGetFinancialYearService = async userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const Year = [new Date().getFullYear(), new Date().getFullYear() + 1];
      const checkScript = checkIfYearIsExist();
      for (const year of Year) {
        const isExist = await query(checkScript, [year]);
        if (isExist.length === 0) {
          const script = insertFYear();
          await query(script, [year, true, userId]);
        }
      }
      const script = getFYear();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUserMappedDuByUserIdService = userid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getUserMappedDuByUserIdScript();
      const result = await query(script, [userid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getDuFromKAMCustService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getDuFromKamCustomerScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getCustomerByDuService = duid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getCustomerByDuIdScript();
      const result = await query(script, [duid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getVericalByDuCustomerService = (duid, customerid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getVerticalByDuCustomerIdScript();
      const result = await query(script, [duid, customerid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// Masters Insert, Update, Delete START
export const getMasterService = async (param, searchText) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = get_master(param.trim().toUpperCase());
      const result = await query(script, [searchText]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const addMasterService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let result = '';
      const { param, newData, createdBy } = payload;
      const script = add_master(param.trim().toUpperCase());
      if (param == 'division' || param == 'country') {
        result = await query(script, [newData, true]);
      } else {
        result = await query(script, [newData, true, createdBy]);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateMasterService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let result = '';
      const { param, id, updatedData, updatedBy } = payload;
      const script = update_master(param.trim().toUpperCase());
      if (
        param == 'division' ||
        param == 'country' ||
        param == 'dumapping' ||
        param == 'customermapping'
      ) {
        result = await query(script, [id, updatedData]);
      } else {
        result = await query(script, [id, updatedData, updatedBy]);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteMasterService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let result = '';
      const { param, id, updatedBy } = payload;
      const script = delete_master(param.trim().toUpperCase());
      if (
        param == 'division' ||
        param == 'country' ||
        param == 'dumapping' ||
        param == 'customermapping'
      ) {
        result = await query(script, [id]);
      } else {
        result = await query(script, [id, updatedBy]);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
// Masters Insert, Update, Delete END

export const rateEntryDDService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid, dd } = payload;
      let script = '';
      if (dd == 'service') {
        script = getServiceByRateConfigScript();
      } else if (dd == 'category') {
        script = getCategoryByRateConfigScript();
      } else if (dd == 'uom') {
        script = getUomByRateConfigScript();
      }
      const result = await query(script, [duid, customerid, verticalid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRateEntryActualsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { bookcode, workorderid } = payload;
      const script = getJobRateEntryActualsScript();
      const result = await query(script, [bookcode, workorderid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRateEntryAdjService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { bookcode, workorderid } = payload;
      const script = getJobRateAdjScript();
      const result = await query(script, [workorderid, bookcode]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const deleteRateEntryAdjService = async (adjustmentid, userid) => {
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            const script = deleteJobRateAdjScript();
            const checkActualScript = checkActualByAdjRateScript();
            const deleteActualScript = deleteActualByAdjRateScript();
            await client.query(script, [adjustmentid, userid]);
            const actualResult = await client.query(checkActualScript, [
              adjustmentid,
            ]);
            if (actualResult?.rows.length > 0) {
              const result = await client.query(deleteActualScript, [
                adjustmentid,
              ]);
              tresolve(result);
            } else {
              throw new Error('Unable to Delete adjustment.');
            }
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('success');
    } catch (error) {
      reject(error);
    }
  });
};

export const getRateEntryHistoryService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { vertical, rateid } = payload;
      let script = '';
      if (vertical == 'Journals') {
        script = getJournalRateEntryHistoryScript();
      } else {
        script = getJobRateEntryHistoryScript();
      }
      const result = await query(script, [rateid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getRateEntryMonthYearService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getRateEntryMonthYearScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const insertJobRateAdjService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        workorderid,
        bookcode,
        duid,
        duidname,
        customerid,
        customername,
        baseduid,
        baseduname,
        divisionid,
        divisionname,
        countryid,
        countryname,
        verticalid,
        verticalname,
        segmentid,
        segmentname,
        currencyname,
        jobcreatedon,
        service,
        servicename,
        ordermonth,
        value,
        remarks,
        currencyid,
        userid,
      } = payload;
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            const checkAdjScript = checkForAdjRateEntryScript();
            const checkAdjResult = await client.query(checkAdjScript, [
              bookcode,
              duid,
              customerid,
              service,
            ]);
            if (checkAdjResult?.rows.length > 0) {
              throw new Error('Adjustment Already done with this combination.');
            } else {
              const insertAdjscript = insertJobRateAdjScript();
              const adjResult = await client.query(insertAdjscript, [
                workorderid,
                bookcode,
                duid,
                customerid,
                service,
                ordermonth,
                value,
                remarks,
                currencyid,
                userid,
              ]);
              const checkScript = checkOrderInflowRecordScript();
              const insertOrderInFlowScript = insertAdjOnActualsScript();
              const checkResult = await client.query(checkScript, [bookcode]);
              if (checkResult.rows.length > 0) {
                await client.query(insertOrderInFlowScript, [
                  checkResult.rows[0].ord_inflowid,
                  service,
                  servicename,
                  parseFloat(value),
                  adjResult.rows[0].adjustmentid,
                  ordermonth,
                  duid,
                  duidname,
                  userid,
                ]);
                tresolve('success');
              } else {
                const insertSalesPmoOif = insertOrderInflowRecordScript();
                const salesPmoOif = await client.query(insertSalesPmoOif, [
                  workorderid,
                  bookcode,
                  baseduid,
                  baseduname,
                  customerid,
                  customername,
                  divisionid,
                  divisionname,
                  countryid,
                  countryname,
                  verticalid,
                  verticalname,
                  segmentid,
                  segmentname,
                  currencyid,
                  currencyname,
                  jobcreatedon,
                  userid,
                ]);
                await client.query(insertOrderInFlowScript, [
                  salesPmoOif.rows[0].ord_inflowid,
                  service,
                  servicename,
                  parseFloat(value),
                  adjResult.rows[0].adjustmentid,
                  ordermonth,
                  duid,
                  duidname,
                  userid,
                ]);
                tresolve('success');
              }
            }
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('success');
    } catch (error) {
      reject(error);
    }
  });
};

// Lock/Unlock Start
export const getWorkorderListService = async searchText => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getWorkOrderList();
      const result = await query(script, [searchText]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateLockUnlockWorkorderService = async (file, createdBy) => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await validateLockUnlockFile(file, createdBy);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getExceptiondataService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getTempTableData();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const lockUnlockWorkorderService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderData, reason, createdBy } = payload;

      const updateWorkOrderIdScript = updateLockJobusingId();
      const InsertHistoryScript = insertHistoryTable();

      const isLockFlag = workorderData.islock.trim().toUpperCase() !== 'LOCK';
      const isLock =
        workorderData.islock.trim().toUpperCase() !== 'LOCK'
          ? 'Locked'
          : 'Unlocked';

      const isFullyInvoiceScript = getIsFullyInvoiced();
      const invoiceData = await query(isFullyInvoiceScript, [
        workorderData?.workorderid,
      ]);

      if (invoiceData[0]?.count > 0) {
        let result = await query(updateWorkOrderIdScript, [
          workorderData.workorderid,
          isLockFlag,
        ]);
        result = await query(InsertHistoryScript, [
          workorderData.itemcode,
          isLock,
          reason,
          createdBy,
        ]);
        resolve(result);
      } else {
        resolve('Job is not fully invoiced!');
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const getWorkorderHistoryService = async workorderID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getHistoryData();
      const result = await query(script, [workorderID]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
// Lock/Unlock End

// rateentryconfig
export const rateConfigServiceDDService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid } = payload;
      const script = getServiceInKamRelScript();
      const result = await query(script, [duid, customerid, verticalid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const rateConfigCategoryService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getCategoryScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const rateConfigCombiCheckService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid } = payload;
      const script = checkCombinationForRateEntry();
      const result = await query(script, [duid, customerid, verticalid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getInvoiceDescriptionService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getInvoiceDescriptionScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const rateConfigStageByWorkFlowService = async customerId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getStageByCustFromKAMScript();
      const result = await query(script, [customerId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertRateEntryConfigService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            const {
              customerInfo,
              orderInFlow,
              deleteItems,
              userId,
              notRequired,
            } = payload;
            const { duId, customerId, verticalId } = customerInfo;
            let script;
            const deleteScript = deleteRateEntryConfigScript();
            let values;
            if (deleteItems.length > 0) {
              deleteItems.forEach(async item => {
                await client.query(deleteScript, [item, userId]);
              });
            }
            if (notRequired) {
              const checkServicesExists = await query(
                checkRateEntryIfServiceExistsScript(),
                [duId, customerId, !notRequired, true],
              );
              const checkIfNotReqExists = await query(
                checkRateEntryIfServiceExistsScript(),
                [duId, customerId, notRequired, false],
              );
              const checkIfNotReqExistsIsActive = await query(
                checkRateEntryIfServiceExistsScript(),
                [duId, customerId, notRequired, true],
              );
              if (checkServicesExists.length > 0) {
                checkServicesExists.forEach(async item => {
                  await client.query(deleteScript, [
                    item.rate_entry_config_id,
                    userId,
                  ]);
                });
              }
              if (
                checkIfNotReqExists.length == 0 &&
                checkIfNotReqExistsIsActive.length == 0
              ) {
                script = insertRateEntryConfigScript();
                values = [
                  duId,
                  customerId,
                  verticalId,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  userId,
                  notRequired,
                ];
              } else {
                script = updateRateEntryConfigNotRequiredScript();
                values = [
                  checkIfNotReqExists[0]?.rate_entry_config_id ||
                    checkIfNotReqExistsIsActive[0]?.rate_entry_config_id,
                  duId,
                  customerId,
                  verticalId,
                  userId,
                ];
              }
              await client.query(script, values);
            } else if (!notRequired) {
              const checkIfNotReqExists = await query(
                checkRateEntryIfServiceExistsScript(),
                [duId, customerId, !notRequired, true],
              );
              if (checkIfNotReqExists.length > 0) {
                checkIfNotReqExists.forEach(async item => {
                  await client.query(deleteScript, [
                    item.rate_entry_config_id,
                    userId,
                  ]);
                });
              }
              orderInFlow.forEach(async item => {
                const {
                  id,
                  service,
                  category,
                  categoryMaster,
                  uom,
                  stageOI,
                  stageUBR,
                } = item;
                if (id !== 0) {
                  script = updateRateEntryConfigScript();
                  values = [
                    id,
                    service,
                    category,
                    categoryMaster,
                    uom,
                    stageOI,
                    stageUBR,
                    userId,
                  ];
                } else {
                  script = insertRateEntryConfigScript();
                  values = [
                    duId,
                    customerId,
                    verticalId,
                    service,
                    category,
                    categoryMaster,
                    uom,
                    stageOI,
                    stageUBR,
                    userId,
                    notRequired,
                  ];
                }
                await client.query(script, values);
              });
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve({ msg: 'success' });
    } catch (error) {
      reject(error);
    }
  });
};
export const insertInvoiceDescService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            const {
              customerInfo,
              invoiceDescription,
              deleteItems,
              userId,
              notRequired,
            } = payload;
            const { duId, customerId, verticalId } = customerInfo;
            let script;
            const deleteScript = deleteInvoiceDescConfigScript();
            let values;
            if (deleteItems.length > 0) {
              deleteItems.forEach(async item => {
                await client.query(deleteScript, [item, userId]);
              });
            }
            if (notRequired) {
              const checkServicesExists = await query(
                checkInvDescIfServiceExistsScript(),
                [duId, customerId, !notRequired, true],
              );
              const checkIfNotReqExists = await query(
                checkInvDescIfServiceExistsScript(),
                [duId, customerId, notRequired, false],
              );
              const checkIfNotReqExistsIsActive = await query(
                checkInvDescIfServiceExistsScript(),
                [duId, customerId, notRequired, true],
              );
              if (checkServicesExists.length > 0) {
                checkServicesExists.forEach(async item => {
                  await client.query(deleteScript, [item.invconfigid, userId]);
                });
              }
              if (
                checkIfNotReqExists.length == 0 &&
                checkIfNotReqExistsIsActive.length == 0
              ) {
                script = insertInvoiceDescScript();
                values = [
                  duId,
                  customerId,
                  verticalId,
                  null,
                  null,
                  null,
                  null,
                  userId,
                  notRequired,
                ];
              } else {
                script = updateInvDescConfigNotRequiredScript();
                values = [
                  checkIfNotReqExists[0]?.invconfigid ||
                    checkIfNotReqExistsIsActive[0]?.invconfigid,
                  duId,
                  customerId,
                  verticalId,
                  userId,
                ];
              }
              await client.query(script, values);
            } else if (!notRequired) {
              const checkIfNotReqExists = await query(
                checkInvDescIfServiceExistsScript(),
                [duId, customerId, !notRequired, true],
              );
              if (checkIfNotReqExists.length > 0) {
                checkIfNotReqExists.forEach(async item => {
                  await client.query(deleteScript, [item.invconfigid, userId]);
                });
              }
              invoiceDescription.forEach(async item => {
                const { id, service, category, categoryMaster, invoiceDesc } =
                  item;
                if (id !== 0) {
                  script = updateInvoiceDescScript();
                  values = [
                    id,
                    service,
                    category,
                    categoryMaster,
                    invoiceDesc,
                    userId,
                  ];
                } else {
                  script = insertInvoiceDescScript();
                  values = [
                    duId,
                    customerId,
                    verticalId,
                    service,
                    category,
                    categoryMaster,
                    invoiceDesc,
                    userId,
                    notRequired,
                  ];
                }
                await client.query(script, values);
              });
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve({ msg: 'success' });
    } catch (error) {
      reject(error);
    }
  });
};

export const getRateConfigTableService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, seachtext, modifieddate } = payload;
      const script = rateConfigTableScript();
      const result = await query(script, [duid, seachtext, modifieddate]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
// rateentryconfig

export const getInvoicedynamicfieldService = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = getInvoicedynamicfieldScript();
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getInvoicefieldmappingService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid } = payload;
      const script = getInvoicefieldmappingScript();
      const result = await query(script, [duid, customerid, verticalid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertAppendixTemplateService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            const { customerInfo, appendixTemplate, id, userId } = payload;
            const { duId, customerId, verticalId } = customerInfo;
            let script;
            let values;
            if (id !== 0) {
              script = updateInvoicefieldmappingScript();
              values = [JSON.stringify(appendixTemplate), userId, id];
            } else {
              script = insertInvoicefieldmappingScript();
              values = [
                duId,
                customerId,
                verticalId,
                JSON.stringify(appendixTemplate),
                userId,
              ];
            }
            await client.query(script, values);
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve({ msg: 'success' });
    } catch (error) {
      reject(error);
    }
  });
};

export const insertInvoicefieldmappingService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid, fields, userid } = payload;
      const jsonmappedfield =
        typeof fields == 'object' ? JSON.stringify(fields) : fields;
      const script = insertInvoicefieldmappingScript();
      const result = await query(script, [
        duid,
        customerid,
        verticalid,
        jsonmappedfield,
        userid,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateInvoicefieldmappingService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { fields, invmapid, userid } = payload;
      const jsonmappedfield =
        typeof fields == 'object' ? JSON.stringify(fields) : fields;
      const script = updateInvoicefieldmappingScript();
      const result = await query(script, [jsonmappedfield, userid, invmapid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getOrderinflowReportService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, field, startDate, endDate, searchText } = payload;

      const updatedfield = field.filter(
        item =>
          item !== 'ordervalue' && item !== 'colFilter' && item !== 'serial',
      );

      const columnfield = updatedfield.map(col => `"${col}"`).join(',');

      const script = getOrderinflowReportScript(columnfield);
      const result = await query(script, [
        duid,
        startDate,
        endDate,
        searchText,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getRateEntryDataService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid } = payload;
      const script = getRateEntryDataScript();
      const result = await query(script, [duid, customerid, verticalid]);
      const rateConfig = [];
      if (result) {
        result.forEach(row => {
          const item = {
            id: row.rate_entry_config_id,
            service: {
              value: row.serviceid,
              label: row.servicename,
            },
            category: {
              value: row.category,
              type: row.categorymaster,
              label: row.category,
            },
            stageOI: row.stageoi,
            stageUBR: row.stageubr,
            uom: {
              value: row.uomid,
              label: row.uom,
            },
          };
          rateConfig.push(item);
        });
      }
      resolve({
        rateConfig,
        notRequired: result[0]?.oi_ubr_not_required || false,
      });
    } catch (error) {
      reject(error);
    }
  });
};
export const getRateEntryInvoiceDataService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid } = payload;
      const script = getRateConfigInvoiceDescDataScript();
      const result = await query(script, [duid, customerid, verticalid]);
      const invoiceDesc = [];
      if (result) {
        result.forEach(row => {
          const item = {
            id: row.invconfigid,
            service: {
              label: row.servicename,
              value: row.serviceid,
            },
            category: {
              value: row.category,
              type: row.categorymaster,
              label: row.category,
            },
            invoiceDesc: {
              value: row.invoicedescription,
              label: row.invoicedescription,
            },
          };
          invoiceDesc.push(item);
        });
      }
      resolve({
        invoiceDesc,
        notRequired: result[0]?.inv_desc_not_required || false,
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const getRateEntryInvoiceFieldService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, customerid, verticalid } = payload;
      const script = getRateConfigFieldScript();
      const result = await query(script, [duid, customerid, verticalid]);
      // const response = await getAutomaticDataForInvoiceFields(result);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getOrderinflowFailureService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { duid, startDate, endDate, searchText } = payload;
      const script = getOrderInflowFailureScript();
      const result = await query(script, [
        duid,
        startDate,
        endDate,
        searchText,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

const getDataForCustomer = async (customer, labelName) => {
  const labelToTableMapping = {
    springer: {
      author: 'springer_tablename',
      place: 'springer_place_table',
      // Add other mappings for Springer
    },
    cupjournals: {
      author: 'cupjournals_tablename',
      place: 'cupjournals_place_table',
      // Add other mappings for CUP
    },
    weiley: {
      author: 'weiley_tablename',
      place: 'weiley_place_table',
      // Add other mappings for Weiley
    },
    acs: {
      author: '',
      place: 'aacs_place_table',
      // Add other mappings for AACS
    },
  };

  // Check if the customer exists in the mapping and has a specific label mapping
  const customerMapping = labelToTableMapping[customer.toLowerCase()];
  if (customerMapping && customerMapping[labelName.toLowerCase()]) {
    const script = customerMapping[labelName.toLowerCase()];
    const data = await query(`${script}`);
    return data;
  }
  return null; // or return default data
};

export const getAutomaticDataForInvoiceFields = async payload => {
  try {
    const { fields, customeralias } = payload;
    const invoiceFields = await Promise.all(
      fields.map(async field => {
        const labelName = field.labelname.toLowerCase().trim();
        const data = await getDataForCustomer(customeralias, labelName);

        if (data) {
          return { ...field, value: data };
        }
        return field;
      }),
    );

    return invoiceFields;
  } catch (error) {
    throw new Error(error);
  }
};
