import { query, transaction } from '../../database/postgres.js';
import {
  // Price Grid
  getServiceMst,
  insFileBasicDetails,
  insFileItemDetails,
  getFileBasicDetails,
  getLatestVersion,
  getFileLineItemDetails,
  // Rate Entry
  checkIsIncomingAnalysisComplete,
  checkIsStageCreated,
  getUniquePriceGridMasterData,
  getUBRStagewithWorkOrderId,
  checkForRateEntryScript,
  insertRateEntryScript,
  updateRateEntryScript,
} from '../datalayer/pearson.js';
import { deleteJobRateScript } from '../datalayer/rateEntry.js';
import { ubrIntegrationService } from '../../odoo/service/index.js';

// Price Grid
export const priceGridUploadService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { excelData, fileName, effectionFrom, uploadedBy } = payload;
      let hasError = false;
      let updExcelData = [];

      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            const serviceMstScript = getServiceMst();
            const serviceMst = await client.query(serviceMstScript);
            updExcelData = excelData.map(data => {
              // Check if the 'CSC Service Category' exists in serviceMst by matching 'servicename'
              if (
                !serviceMst?.rows?.some(
                  service =>
                    service.servicename === data['CSC Service Category'],
                )
              ) {
                data.remarks = 'Invalid Service';
                hasError = true;
              }
              data.index_number = data['Unique Index Number'];
              data.business_group = data['Business Group'];
              data.service_item_number =
                data['Oracle Service Item Number (GPC)'];
              data.service_category = data['CSC Service Category'];
              data.item_description = data['(Oracle) Item Description'];
              data.complexity = data['(Oracle) Complexity'];
              data.item_type = data['(Oracle) Item Type'];
              data.service_type = data['(Oracle) Service Type'];
              data.unit = data['(Oracle) Unit'];
              data.l1_item_description = data['Item Description - Level 1'];
              data.l2_item_description = data['Item Description - Level 2'];
              data.unit_type = data['Unit Type'];
              return data;
            });
            tresolve({ updExcelData });
          } catch (error) {
            treject(error);
          }
        });
      });
      if (hasError) {
        resolve({ result: 'file has error', errList: updExcelData });
      } else {
        const result = await insDetails(
          updExcelData,
          fileName,
          effectionFrom,
          uploadedBy,
        );
        if (result == 'success') {
          resolve({ result: 'success' });
        } else {
          resolve({ result: 'failed' });
        }
      }
    } catch (error) {
      reject(error);
    }
  });
};

const insDetails = async (
  updExcelData,
  fileName,
  effectionFrom,
  uploadedBy,
) => {
  try {
    const fileinsScript = insFileBasicDetails();
    const fileResponse = await query(fileinsScript, [
      fileName,
      effectionFrom,
      true,
      uploadedBy,
    ]);
    if (fileResponse) {
      const fileItemScript = insFileItemDetails(
        updExcelData,
        fileResponse[0]?.fileid,
      );
      await query(fileItemScript);
    }
    return 'success';
  } catch (error) {
    return 'error';
  }
};

export const getFileBasicDetailsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText } = payload;
      const getScript = getFileBasicDetails();
      const getLatestVersionScript = getLatestVersion();
      const result = await query(getScript, [searchText]);
      const latestVersion = await query(getLatestVersionScript);
      resolve({ result, latestVersion });
    } catch (error) {
      reject(error);
    }
  });
};

export const getFileLineItemDetailsService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { fileId, fileName, searchText } = payload;
      const getScript = getFileLineItemDetails();
      const result = await query(getScript, [fileId, fileName, searchText]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// Rate Entry
export const checkIncomingAndStageValidationService = async workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const Script1 = checkIsIncomingAnalysisComplete();
      const Script2 = checkIsStageCreated();
      const IsIncomingCompleted = await query(Script1, [workorderId]);
      const IsStageCreated = await query(Script2, [workorderId]);
      resolve({ IsIncomingCompleted, IsStageCreated });
    } catch (error) {
      reject(error);
    }
  });
};

export const getExcelMasterDataService = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        uin,
        gpc,
        servicecategory,
        itemdescription,
        complexity,
        servicetype,
        unittype,
      } = payload;
      const getScript = getUniquePriceGridMasterData();
      const result = await query(getScript, [
        uin,
        gpc,
        servicecategory,
        itemdescription,
        complexity,
        servicetype,
        unittype,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getUBRStagewithWorkOrderIdService = async workorderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const getScript = getUBRStagewithWorkOrderId();
      const result = await query(getScript, [workorderId]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertorUpdateRateEntryService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderid, bookcode, currencyid, data, deleteids, created_by } =
        payload;

      const duplicateCheckScript = checkForRateEntryScript();
      const insertScript = insertRateEntryScript();
      const updateScript = updateRateEntryScript();
      const deleteScript = deleteJobRateScript();

      await transaction(client => {
        return new Promise(async (tresolve, treject) => {
          try {
            if (deleteids.length > 0) {
              await client.query(deleteScript, [
                workorderid,
                deleteids,
                created_by,
              ]);
            }
            for (const i of data) {
              const {
                id,
                uin,
                gpc,
                servicecategory,
                itemdescription,
                ubrstage,
                du,
                complexity,
                servicetype,
                unittype,
                quantity,
                rate,
                comments,
                amount,
              } = i;
              const script = id == 0 ? insertScript : updateScript;
              const values = [
                workorderid,
                bookcode,
                servicecategory,
                ubrstage,
                currencyid,
                rate,
                du,
                quantity,
                amount,
                uin,
                gpc,
                itemdescription,
                complexity,
                servicetype,
                unittype,
                comments,
                created_by,
              ];
              if (id) values.push(id);
              if (id == 0) {
                const checkValues = [
                  workorderid,
                  bookcode,
                  servicecategory,
                  ubrstage,
                  currencyid,
                  du,
                  uin,
                  gpc,
                  itemdescription,
                  complexity,
                  servicetype,
                  unittype,
                  comments,
                ];
                const duplicateRecords = await client.query(
                  duplicateCheckScript,
                  checkValues,
                );
                if (duplicateRecords?.rows.length > 0) {
                  throw new Error('Containing Duplicate entries.');
                } else {
                  await client.query(script, values);
                  await ubrIntegrationService({
                    workorderId: workorderid,
                    stageId: ubrstage,
                    servicetype: 'servicecreation',
                    woId: workorderid,
                    woType: 'book',
                  });
                }
              } else {
                await client.query(script, values);
              }
            }
            tresolve('success');
          } catch (error) {
            treject(error);
          }
        });
      });
      resolve('RateEntry successfully inserted');
    } catch (error) {
      reject(error);
    }
  });
};
