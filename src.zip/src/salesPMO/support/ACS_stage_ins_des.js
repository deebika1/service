import axios from 'axios';
import { query } from '../../database/postgres.js';
import { odooEndPoints } from '../../odoo/helpers/odooApiEndpoints.js';
import { authenticateOddoService } from '../../odoo/service/index.js';

// let sessionCookie = null;

const authenticateOnce = async () => {
  // if (sessionCookie) return sessionCookie;
  try {
    const response = await authenticateOddoService();
    // sessionCookie = response;
    return response;
  } catch (error) {
    throw new Error('Authentication failed');
  }
};

const sendStageData = async (data, type, sessionCookie) => {
  const url = odooEndPoints.api.saleOrder;
  const payload = JSON.stringify(data, null, 2);
  const contentType = 'application/json';

  try {
    const response = await axios({
      method: 'POST',
      url: odooEndPoints.server.getOdooUrl() + url,
      data: payload,
      headers: {
        'Content-Type': contentType,
        Cookie: sessionCookie,
      },
    });

    const bookCode =
      data.StageDetails?.[0]?.BookCode ||
      data.StageDispatchedDetails?.[0]?.BookCode;

    if (response.data.status === 'success') {
      console.log(`${type} success for ${bookCode}`);
      return { success: true, message: `${type} success` };
    }
    console.error(`${type} failed for ${bookCode}: ${response.data.message}`);
    return { success: false, message: `${type} failed` };
  } catch (error) {
    const bookCode =
      data.StageDetails?.[0]?.BookCode ||
      data.StageDispatchedDetails?.[0]?.BookCode;
    console.error(`${type} error for ${bookCode}: ${error.message}`);
    return { success: false, message: `${type} error` };
  }
};

export const sendACSStageIntialDespatch = async (woid = 38940) => {
  const sessionCookie = await authenticateOnce();
  const workOrders = await query(masterDataScript(), [woid]);

  let successCount = 0;
  let failureCount = 0;
  const totalWorkOrders = workOrders.length;

  for (let i = 0; i < totalWorkOrders; i++) {
    const masterData = workOrders[i];
    try {
      const stageInitialData = {
        StageDetails: [
          {
            DeliveryUnit: masterData.duname,
            Customer: masterData.customername,
            BookCode: masterData.jobid,
            createdDate: masterData.jobcreatedon,
            SubJob: [
              {
                Chapter: masterData.jobid,
                Stage: masterData.stagename,
                EstimatedPage:
                  masterData.stagename.toLowerCase() === 'graphics'
                    ? +masterData.imagecount
                    : +masterData.estimatedpages,
                MsPage: +masterData.mspages,
                NoOfImages: +masterData.imagecount,
                SubJobId: 0,
              },
            ],
          },
        ],
      };

      const initialResponse = await sendStageData(
        stageInitialData,
        'Initial',
        sessionCookie,
      );
      if (!initialResponse.success) {
        failureCount++;
        console.log(
          `Progress: ${i + 1}/${totalWorkOrders} - Initial stage failed for ${
            masterData.jobId
          }`,
        );
      }

      const stageDispatchData = {
        StageDispatchedDetails: [
          {
            DeliveryUnit: masterData.duname,
            Customer: masterData.customername,
            BookCode: masterData.jobid,
            SubJob: [
              {
                Chapter: masterData.jobid,
                Stage: masterData.stagename,
                TypeSetPage:
                  masterData.stagename.toLowerCase() === 'graphics'
                    ? +masterData.imagecount
                    : +masterData.estimatedpages,
                DispatchedDate: masterData.currentdate,
                SubJobId: 0,
              },
            ],
          },
        ],
      };

      const dispatchResponse = await sendStageData(
        stageDispatchData,
        'Dispatch',
        sessionCookie,
      );
      if (dispatchResponse.success) {
        successCount++;
        console.log(
          `Progress: ${i + 1}/${totalWorkOrders} - Dispatch success for ${
            masterData.jobId
          }`,
        );
      } else {
        failureCount++;
        console.log(
          `Progress: ${i + 1}/${totalWorkOrders} - Dispatch stage failed for ${
            masterData.jobId
          }`,
        );
      }
    } catch (error) {
      failureCount++;
      console.error(
        `Error processing work order ${masterData.jobId}: ${error.message}`,
      );
    }

    // Log the current progress
    console.log(
      `Progress: ${
        i + 1
      }/${totalWorkOrders} - Successes: ${successCount}, Failures: ${failureCount}`,
    );
  }
  console.log(
    `Processing complete: ${successCount} successes, ${failureCount} failures`,
  );
};

const masterDataScript = () => {
  return `WITH workorder_details AS (
            SELECT
                wo.workorderid,
                wo.itemcode AS jobId,
                wo.title AS jobtitle,
                itrdu.duname,
                itrcust.customerid,
                itrcust.customername,
                di.divisionid,
                di.division AS divisionname,
                co.countryid,
                co.countryname,
                co.ist_code,
                subd.subdivisionid AS verticalid,
                subd.subdivision AS verticalname,
                subd.verticalcode AS vertical,
                wo.journalid,
                jm.journalacronym,
                mcopy.displayname AS celevel,
                wo.eisbn,
                TO_CHAR(wo.createdon + INTERVAL '5 hours 30 minutes', 'YYYY-MM-DD HH24:MI:SS.MS') AS jobcreatedon,
                (
                    SELECT kus.username
                    FROM salespmo.trn_kamcustomerrel tkm
                    JOIN wms_user AS kus ON tkm.kamempcode = kus.userid
                    WHERE tkm.duid = du.itrackduid
                      AND tkm.customerid = cu.itrack_customerid
                      AND tkm.countryid = wo.countryid
                      AND tkm.divisionid = wo.divisionid
                    LIMIT 1
                ) AS kamname,
                COALESCE((
                    SELECT contactname
                    FROM wms_workorder_contacts
                    WHERE workorderid = wo.workorderid
                      AND contactrole = 'PM'
                    LIMIT 1
                ), '') AS projectmanager,
                COALESCE((
                    SELECT contactname
                    FROM org_mst_customerorg_contact omcc
                    WHERE custorgmapid = jm.custorgmapid
                      AND contactroleid = 'CM'
                    LIMIT 1
                ), '') AS clientmanager,
                wo.currencyid,
                cur.currencycode
            FROM wms_workorder AS wo
            JOIN public.org_mst_customer AS cu ON cu.customerid = wo.customerid
            JOIN public.org_mst_division AS di ON di.divisionid = wo.divisionid
            JOIN public.geo_mst_country AS co ON co.countryid = wo.countryid
            JOIN public.org_mst_customer_orgmap AS cog ON cog.divisionid = wo.divisionid
                AND cog.customerid = wo.customerid
                AND cog.subdivisionid = wo.subdivisionid
                AND cog.countryid = wo.countryid
            JOIN public.org_mst_subdivision AS subd ON subd.subdivisionid = wo.subdivisionid
            JOIN public.org_mst_customerorg_du_map AS cdu ON cdu.custorgmapid = cog.custorgmapid
            JOIN public.org_mst_deliveryunit AS du ON du.duid = cdu.duid
            LEFT JOIN public.org_mst_customerorg_service_map AS ser ON ser.custorgmapid = cog.custorgmapid
            LEFT JOIN public.wms_mst_service AS mser ON mser.serviceid = ser.serviceid
            JOIN public.mst_deliveryunit AS itrdu ON itrdu.duid = du.itrackduid
            JOIN public.mst_customer AS itrcust ON itrcust.customerid = cu.itrack_customerid
            LEFT JOIN public.pp_mst_copyeditinglevel AS mcopy ON mcopy.celevelid = wo.celevelid
            LEFT JOIN public.pp_mst_journal AS jm ON jm.journalid = wo.journalid
            JOIN public.mst_currencymst AS cur ON cur.currencyid = wo.currencyid
            WHERE wo.workorderid = $1
        ),
        incoming_details AS (
            SELECT
                SUM(COALESCE(inf.mspages, 0)) AS mspages,
                SUM(COALESCE(inf.estimatedpages, 0)) AS estimatedpages,
                SUM(COALESCE(inf.typesetpage, 0)) AS typesetpage,
                SUM(COALESCE(inf.imagecount, 0)) AS imagecount,
                SUM(COALESCE(inf.tablecount, 0)) AS tablecount,
                SUM(COALESCE(inf.equationcount, 0)) AS equationcount,
                SUM(COALESCE(inf.wordcount, 0)) AS wordcount
            FROM wms_workorder AS wo
            LEFT JOIN wms_workorder_incoming AS inc ON inc.woid = wo.workorderid
            LEFT JOIN wms_workorder_incomingfiledetails AS inf ON inf.woincomingid = inc.woincomingid
            WHERE wo.workorderid = $1
        ),
        stage_details AS (
            SELECT
                stg.stagename,
                TO_CHAR(NOW() + INTERVAL '330 MINUTES', 'YYYY-MM-DD HH:MI:SS.MS') AS currentdate,
                ws.typesetpages
            FROM wms_workorder_stage AS ws
            JOIN wms_mst_stage stg ON stg.stageid = ws.wfstageid
            WHERE ws.workorderid = $1
              AND ws.wfstageid in (72,10)
        )
        SELECT DISTINCT
            wd.workorderid,
            wd.jobId,
            wd.jobtitle,
            wd.duname,
            wd.customerid,
            wd.customername,
            wd.divisionid,
            wd.divisionname,
            wd.countryid,
            wd.countryname,
            wd.ist_code,
            wd.verticalid,
            wd.verticalname,
            wd.vertical,
            wd.journalid,
            wd.journalacronym,
            wd.celevel,
            wd.eisbn,
            wd.jobcreatedon,
            wd.kamname,
            wd.projectmanager,
            wd.clientmanager,
            wd.currencyid,
            wd.currencycode,
            id.mspages,
            id.estimatedpages,
            id.typesetpage,
            id.imagecount,
            id.tablecount,
            id.equationcount,
            id.wordcount,
            sd.stagename,
            sd.currentdate
            --sd.typesetpages
        FROM workorder_details wd
        LEFT JOIN incoming_details id ON true
        LEFT JOIN stage_details sd ON true;`;
};
