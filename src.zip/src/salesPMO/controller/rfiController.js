import {
  getAuditDataService,
  getAuditModuleDDService,
  getAuditSearchService,
} from '../service/reportService.js';
import {
  ACSAutoService,
  approveRejectRFIService,
  deleteRfiAttachmentService,
  getInvoiceDescService,
  getInvoiceRFIFieldsService,
  getJobDetailsService,
  getRaiseRFITableService,
  getRateEntryForRFIService,
  getRFIArticleDetailsService,
  getRFIDetailsService,
  insertOrUpdateRFIService,
  insertRFIAttachmentService,
  RFIIntegrationService,
} from '../service/rfiServices.js';

export const getRFITableDataController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getRaiseRFITableService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getJobDetailsController = async (req, res) => {
  try {
    const { woid, stageid } = req.params;
    const out = await getJobDetailsService(woid, stageid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRFIInvoiceFieldsController = async (req, res) => {
  try {
    const data = req.params;
    const out = await getInvoiceRFIFieldsService(data);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getInvoiceDescController = async (req, res) => {
  try {
    const data = req.body;
    const out = await getInvoiceDescService(data);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertRFIController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertOrUpdateRFIService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertRFIFileController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertRFIAttachmentService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateEntryRFIController = async (req, res) => {
  try {
    const data = req.body;
    const out = await getRateEntryForRFIService(data);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRfiDetailsController = async (req, res) => {
  try {
    const { woid } = req.params;
    const out = await getRFIDetailsService(woid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRfiArticleDetailsController = async (req, res) => {
  try {
    const { woid, jobtype } = req.params;
    const out = await getRFIArticleDetailsService(woid, jobtype);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const approveRejectRFIController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await approveRejectRFIService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const invoiceIntegrationController = async (req, res) => {
  try {
    const data = req.body;
    const out = await RFIIntegrationService(data);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getAuditModuleDDController = async (req, res) => {
  try {
    const out = await getAuditModuleDDService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getAuditSearchDDController = async (req, res) => {
  try {
    const out = await getAuditSearchService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getAuditDataController = async (req, res) => {
  try {
    const out = await getAuditDataService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const deleteRfiAttachmentController = async (req, res) => {
  try {
    const out = await deleteRfiAttachmentService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const ACSAutoController = async (req, res) => {
  try {
    const { createdBy, data } = req.body;
    const out = await ACSAutoService({ createdBy, data });
    res.status(200).send({ status: 'ok', out });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
