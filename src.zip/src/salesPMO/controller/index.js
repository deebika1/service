import {
  insertKAMCustomerRelService,
  insertJournalRateService,
  insertJobRateService,
  insertServiceAndStageMappingService,
  updateKAMCustomerRelByIdService,
  updateJournalRateByIdService,
  updateJobRateByIdService,
  updateServiceMappingByIdService,
  updateStageMappingByIdService,
  getKAMCustomerRelService,
  getInitialPlanTemplateDownloadService,
  insertReassignKamOrCmService,
  getSegmentService,
  getVerticalService,
  setSegmentService,
  deleteSegmentService,
  setVerticalService,
  deleteVerticalService,
  getKAMRelChangeService,
  getServiceService,
  setServiceService,
  deleteServiceService,
  checkSegmentService,
  checkVerticalService,
  checkServiceService,
  getKAMDetailsByIdService,
  updateKAMPendingByIdService,
  approveRejectKAMChangeService,
  getKAMPendingQueueHistoryService,
  setOrdInflowService,
  getJournalRateEntryService,
  getJournalRateStageService,
  planUploadService,
  getExceptionDataService,
  getSalesPMOMasterDropDownService,
  getRateEntryMapScreenServiceDDService,
  getStageDDByserviceMappingService,
  getExchangeCurrencyandRateService,
  InsorUpdExchangeRateService,
  getYearDropdownService,
  getUploadedPlanDetailsService,
  getUploadedPlanService,
  getStageMapService,
  getServiceMapService,
  getJobRateService,
  getJobRateAdjService,
  insandGetFinancialYearService,
  getUserMappedDuByUserIdService,
  getCustomerByDuService,
  getVericalByDuCustomerService,
  addMasterService,
  updateMasterService,
  deleteMasterService,
  getMasterService,
  getWorkorderListService,
  insertRateEntryService,
  rateEntryDDService,
  updateLockUnlockWorkorderService,
  getExceptiondataService,
  lockUnlockWorkorderService,
  getWorkorderHistoryService,
  getRateEntryActualsService,
  getRateEntryHistoryService,
  getRateEntryMonthYearService,
  insertJobRateAdjService,
  getRateEntryAdjService,
  deleteRateEntryAdjService,
  getDuFromKAMCustService,
  rateConfigServiceDDService,
  rateConfigCategoryService,
  rateConfigStageByWorkFlowService,
  insertRateEntryConfigService,
  getInvoiceDescriptionService,
  insertInvoiceDescService,
  getRateConfigTableService,
  getInvoicedynamicfieldService,
  getInvoicefieldmappingService,
  updateInvoicefieldmappingService,
  insertAppendixTemplateService,
  getOrderinflowReportService,
  rateConfigCombiCheckService,
  getRateEntryDataService,
  getRateEntryInvoiceDataService,
  getRateEntryInvoiceFieldService,
  getOrderinflowFailureService,
} from '../service/index.js';
import {
  getPlanVsActualTableDataService,
  getProjectWiseTableDataService,
  getUserMappedDuService,
} from '../service/reportService.js';

export const insertInvoiceController = async (req, res) => {
  try {
    res.status(200).send({ message: 'connection working fine.' });
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insertKAMCustomerRelController = async (req, res) => {
  try {
    const out = await insertKAMCustomerRelService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateKAMCustomerRelByIdController = async (req, res) => {
  try {
    const out = await updateKAMCustomerRelByIdService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateKAMPendingByIdController = async (req, res) => {
  try {
    const out = await updateKAMPendingByIdService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const approveRejectKAMChangeController = async (req, res) => {
  try {
    const out = await approveRejectKAMChangeService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getKAMCustomerRelController = async (req, res) => {
  try {
    const out = await getKAMCustomerRelService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getKAMdetailsByIdController = async (req, res) => {
  try {
    const { rectype, relid } = req.params;
    const out = await getKAMDetailsByIdService(rectype, relid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getKAMRelChangeController = async (req, res) => {
  try {
    const status = req.params.status.toUpperCase();
    const type = req.params.type.toUpperCase();
    const out = await getKAMRelChangeService({ status, type });
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getKAMPendingHistoryController = async (req, res) => {
  try {
    const { queueid } = req.params;
    const out = await getKAMPendingQueueHistoryService(queueid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertJournalRateController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertJournalRateService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertRateEntryController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertRateEntryService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getMonthYearController = async (req, res) => {
  try {
    const out = await getRateEntryMonthYearService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insertJobRateAdjController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertJobRateAdjService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateJournalRateByIdController = async (req, res) => {
  try {
    const out = await updateJournalRateByIdService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertJobRateController = async (req, res) => {
  try {
    const out = await insertJobRateService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateJobRateByIdController = async (req, res) => {
  try {
    const out = await updateJobRateByIdService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertServiceAndStageMappingController = async (req, res) => {
  try {
    const out = await insertServiceAndStageMappingService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateServiceMappingByIdController = async (req, res) => {
  try {
    const out = await updateServiceMappingByIdService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateStageMappingByIdController = async (req, res) => {
  try {
    const out = await updateStageMappingByIdService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getPlanTemplateDownloadController = async (req, res) => {
  try {
    const out = await getInitialPlanTemplateDownloadService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertReassignKamOrCmController = async (req, res) => {
  try {
    const out = await insertReassignKamOrCmService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getSegmentController = async (req, res) => {
  try {
    const out = await getSegmentService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getVerticalController = async (req, res) => {
  try {
    const out = await getVerticalService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const setSegmentController = async (req, res) => {
  try {
    const out = await setSegmentService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const deleteSegmentController = async (req, res) => {
  try {
    const out = await deleteSegmentService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const setVerticalController = async (req, res) => {
  try {
    const out = await setVerticalService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const deleteVerticalController = async (req, res) => {
  try {
    const out = await deleteVerticalService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getServiceController = async (req, res) => {
  try {
    const out = await getServiceService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const setServiceController = async (req, res) => {
  try {
    const out = await setServiceService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const deleteServiceController = async (req, res) => {
  try {
    const out = await deleteServiceService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const checkSegmentController = async (req, res) => {
  try {
    const out = await checkSegmentService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const checkVerticalController = async (req, res) => {
  try {
    const out = await checkVerticalService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const checkServiceController = async (req, res) => {
  try {
    const out = await checkServiceService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUserMappedAndBaseDuController = async (req, res) => {
  try {
    const { type, userid } = req.params;
    const out = await getUserMappedDuService(type, userid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const setOrdInflowController = async (req, res) => {
  try {
    const out = await setOrdInflowService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getProjectWiseTableDataController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getProjectWiseTableDataService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRateEntryDataController = async (req, res) => {
  try {
    const { vertical, id } = req.params;
    let out = '';
    if (vertical == 'Journals') {
      out = await getJournalRateStageService(id);
    } else {
      out = await getJobRateService(id);
    }
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getPlanVsActualTableDataController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getPlanVsActualTableDataService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getJournalRateEntryController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getJournalRateEntryService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Plan Upload
export const planUploadController = async (req, res) => {
  try {
    const out = await planUploadService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getExceptionDataController = async (req, res) => {
  try {
    const out = await getExceptionDataService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getSalesPMOMasterDDController = async (req, res) => {
  try {
    const { table } = req.params;
    const out = await getSalesPMOMasterDropDownService(table.toUpperCase());
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getExchangeCurrencyandRateController = async (req, res) => {
  try {
    const { Year } = req.params;
    const out = await getExchangeCurrencyandRateService(Year);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRateEntryMapScrServiceDDController = async (req, res) => {
  try {
    const { duId, customerId } = req.params;
    const out = await getRateEntryMapScreenServiceDDService(duId, customerId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const InsorUpdExchangeRateController = async (req, res) => {
  try {
    const out = await InsorUpdExchangeRateService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getStageDDByserviceMappingController = async (req, res) => {
  try {
    const { serviceMapId } = req.params;
    const out = await getStageDDByserviceMappingService(serviceMapId);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getYearDropdownController = async (req, res) => {
  try {
    const { key } = req.params;
    const out = await getYearDropdownService(key);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUploadedPlanDetailsController = async (req, res) => {
  try {
    const { key, Year } = req.body;
    const out = await getUploadedPlanDetailsService(key, Year);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUploadedPlanController = async (req, res) => {
  try {
    const { key, Year, userId, uploaded_date } = req.body;
    const out = await getUploadedPlanService(key, Year, userId, uploaded_date);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insandGetFinancialYearController = async (req, res) => {
  try {
    const { modifiedBy } = req.body;
    const out = await insandGetFinancialYearService(modifiedBy);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// Plan Upload end

export const getServiceMapController = async (req, res) => {
  try {
    const { key, Year } = req.body;
    const out = await getServiceMapService(key, Year);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getStageMapController = async (req, res) => {
  try {
    const { key, Year } = req.body;
    const out = await getStageMapService(key, Year);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getJobRateController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getJobRateService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getJobRateAdjController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getJobRateAdjService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// RateEntry(main) DD
export const getUserMappedDuByUserIdController = async (req, res) => {
  try {
    const { userid } = req.params;
    const out = await getUserMappedDuByUserIdService(userid.toUpperCase());
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getDuFromKamCustController = async (req, res) => {
  try {
    const out = await getDuFromKAMCustService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustomerByDuController = async (req, res) => {
  try {
    const { duid } = req.params;
    const out = await getCustomerByDuService(duid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getVerticalByDuCustomerController = async (req, res) => {
  try {
    const { duid, customerid } = req.params;
    const out = await getVericalByDuCustomerService(duid, customerid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Masters START
export const getMasterController = async (req, res) => {
  try {
    const { param, searchText } = req.body;
    const out = await getMasterService(param, searchText);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const addMasterController = async (req, res) => {
  try {
    const out = await addMasterService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateMasterController = async (req, res) => {
  try {
    const out = await updateMasterService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteMasterController = async (req, res) => {
  try {
    const out = await deleteMasterService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateEntryDDController = async (req, res) => {
  try {
    const out = await rateEntryDDService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateEntryActualsController = async (req, res) => {
  try {
    const { bookcode, wororderid } = req.params;
    const out = await getRateEntryActualsService({ bookcode, wororderid });
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateEntryAdjController = async (req, res) => {
  try {
    const { bookcode, wororderid } = req.params;
    const out = await getRateEntryAdjService({ bookcode, wororderid });
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const deleteRateEntryAdjController = async (req, res) => {
  try {
    const { adjustmentid, userid } = req.params;
    const out = await deleteRateEntryAdjService(adjustmentid, userid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateEntryHistoryController = async (req, res) => {
  try {
    const { rateid, vertical } = req.params;
    const out = await getRateEntryHistoryService({ vertical, rateid });
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// Masters END

// Lock/Unlock
export const getWorkorderListController = async (req, res) => {
  try {
    const { searchText } = req.params;
    const out = await getWorkorderListService(searchText);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateLockUnlockWorkorderController = async (req, res) => {
  try {
    const { file, createdBy } = req.body;
    const out = await updateLockUnlockWorkorderService(file, createdBy);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getExceptiondataController = async (req, res) => {
  try {
    const out = await getExceptiondataService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const lockUnlockWorkorderController = async (req, res) => {
  try {
    const out = await lockUnlockWorkorderService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getWorkorderHistoryController = async (req, res) => {
  try {
    const { workorderID } = req.params;
    const out = await getWorkorderHistoryService(workorderID);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
// Lock/Unlock End

// rateConfig
export const getServiceFromKAMController = async (req, res) => {
  try {
    const { duid, customerid, verticalid } = req.params;
    const out = await rateConfigServiceDDService({
      duid,
      customerid,
      verticalid,
    });
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateConfigCategoryController = async (req, res) => {
  try {
    const out = await rateConfigCategoryService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateEntryFetchController = async (req, res) => {
  try {
    const out = await getRateEntryDataService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const rateEntryCombinationCheckController = async (req, res) => {
  try {
    const { duid, customerid, verticalid } = req.params;
    const out = await rateConfigCombiCheckService({
      duid,
      customerid,
      verticalid,
    });
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getInvoiceDescriptionController = async (req, res) => {
  try {
    const out = await getInvoiceDescriptionService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateConfigStageByWorkFlowController = async (req, res) => {
  try {
    const { customerid } = req.params;
    const out = await rateConfigStageByWorkFlowService(customerid);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insertRateEntryConfigController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertRateEntryConfigService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insertInvoiceDescController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insertInvoiceDescService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getRateConfigTableController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getRateConfigTableService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const getInvoicedynamicfieldController = async (req, res) => {
  try {
    const out = await getInvoicedynamicfieldService();
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getInvoicefieldmappingController = async (req, res) => {
  try {
    const out = await getInvoicefieldmappingService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
export const insertInvoicefieldmappingController = async (req, res) => {
  try {
    const out = await insertAppendixTemplateService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateInvoicefieldmappingController = async (req, res) => {
  try {
    const out = await updateInvoicefieldmappingService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getOrderinflowReportController = async (req, res) => {
  try {
    const out = await getOrderinflowReportService(req.body);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRateConfigInvoiceDescController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getRateEntryInvoiceDataService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getRateEntryInvoiceFieldController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getRateEntryInvoiceFieldService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getOrderinflowFailureController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getOrderinflowFailureService(payload);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
