import {
  // Price Grid
  priceGridUploadService,
  getFileBasicDetailsService,
  getFileLineItemDetailsService,
  // Rate Entry
  checkIncomingAndStageValidationService,
  getExcelMasterDataService,
  getUBRStagewithWorkOrderIdService,
  insertorUpdateRateEntryService,
} from '../service/pearsonService.js';

// Price Grid
export const priceGridUploadController = async (req, res) => {
  try {
    const result = await priceGridUploadService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFileBasicDetailsController = async (req, res) => {
  try {
    const result = await getFileBasicDetailsService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getFileLineItemDetailsController = async (req, res) => {
  try {
    const result = await getFileLineItemDetailsService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

// Rate Entry
export const checkIncomingAndStageValidationController = async (req, res) => {
  try {
    const { workorderid } = req.params;
    const result = await checkIncomingAndStageValidationService(workorderid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getExcelMasterDataController = async (req, res) => {
  try {
    const result = await getExcelMasterDataService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const getUBRStagewithWorkOrderIdController = async (req, res) => {
  try {
    const { workorderid } = req.params;
    const result = await getUBRStagewithWorkOrderIdService(workorderid);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};

export const insertorUpdateRateEntryController = async (req, res) => {
  try {
    const result = await insertorUpdateRateEntryService(req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(400).send({ error, message: error?.message });
  }
};
