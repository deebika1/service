import express from 'express';
import {
  // Price Grid
  priceGridUploadController,
  getFileBasicDetailsController,
  getFileLineItemDetailsController,
  // Rate Entry
  checkIncomingAndStageValidationController,
  getExcelMasterDataController,
  getUBRStagewithWorkOrderIdController,
  insertorUpdateRateEntryController,
} from '../controller/pearsonController.js';

const pearsonRouter = express.Router();
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

// Pearson Price Grid
pearsonRouter.post('/pricegridupload', handler(priceGridUploadController));
pearsonRouter.post('/getfiledetails', handler(getFileBasicDetailsController));
pearsonRouter.post('/getfileitems', handler(getFileLineItemDetailsController));

// Pearson Rate Entry
pearsonRouter.get(
  '/checkincomingstageisexist/:workorderid',
  handler(checkIncomingAndStageValidationController),
);
pearsonRouter.post(
  '/getmasterfromexcel',
  handler(getExcelMasterDataController),
);
pearsonRouter.get(
  '/getubrstagewithwoid/:workorderid',
  handler(getUBRStagewithWorkOrderIdController),
);
pearsonRouter.post(
  '/insorupdrateentry',
  handler(insertorUpdateRateEntryController),
);

export default pearsonRouter;
