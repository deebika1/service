import express from 'express';
import {
  validateRequestBody,
  validateRequestParams,
} from '../helpers/middleware.js';
import {
  approveRejectRFISchema,
  // createRfiSchema,
  getArticleDetailsSchema,
  getJobdetailsSchema,
  getRFIInvoiceFieldsSchema,
  invoiceDescSchema,
  raiseRFITableSchema,
  rateEntryRFISchema,
  invoiceintegration,
  journalManuscriptEditorialSchema,
  getJobDetailsByWoidStageidSchema,
} from '../helpers/validation.js';
import {
  ACSAutoController,
  approveRejectRFIController,
  deleteRfiAttachmentController,
  getInvoiceDescController,
  getJobDetailsController,
  getRateEntryRFIController,
  getRfiArticleDetailsController,
  getRfiDetailsController,
  getRFIInvoiceFieldsController,
  getRFITableDataController,
  insertRFIController,
  insertRFIFileController,
  invoiceIntegrationController,
} from '../controller/rfiController.js';

import { RejectionWorkflowMailService } from '../service/rfiServices.js';

const rfiRouter = express.Router();
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };
// getraiserfi table data
rfiRouter.post(
  '/raiserfi',
  validateRequestBody(raiseRFITableSchema),
  handler(getRFITableDataController),
);
// get job details
rfiRouter.get(
  '/jobdetails/:woid/:stageid',
  validateRequestParams(getJobDetailsByWoidStageidSchema),
  handler(getJobDetailsController),
);
// get invoice dynamic fields
rfiRouter.get(
  '/invoice/:duid/:customerid/:verticalid',
  validateRequestParams(getRFIInvoiceFieldsSchema),
  handler(getRFIInvoiceFieldsController),
);
// get invoice descriptions
rfiRouter.get(
  '/invoicedesc',
  validateRequestBody(invoiceDescSchema),
  handler(getInvoiceDescController),
);
// create rfi (invoice)
rfiRouter.post(
  '/create',
  // validateRequestBody(createRfiSchema),
  handler(insertRFIController),
);

rfiRouter.post('/rfifile', handler(insertRFIFileController));

// get rate Entry for rfi (invoice)
rfiRouter.post(
  '/rateentry',
  validateRequestBody(rateEntryRFISchema),
  handler(getRateEntryRFIController),
);
// get rif details by woid
rfiRouter.get(
  '/view/:woid',
  validateRequestParams(getJobdetailsSchema),
  handler(getRfiDetailsController),
);
// get rif Article details by woid fot issues
rfiRouter.get(
  '/article/:jobtype/:woid',
  validateRequestParams(getArticleDetailsSchema),
  handler(getRfiArticleDetailsController),
);
// approve or reject RFI
rfiRouter.post(
  '/apprej',
  validateRequestBody(approveRejectRFISchema),
  handler(approveRejectRFIController),
);

rfiRouter.post(
  '/rfiintegration',
  validateRequestBody(invoiceintegration),
  handler(invoiceIntegrationController),
);

rfiRouter.post('/rejrfimail', handler(RejectionWorkflowMailService));
rfiRouter.post('/delrfiattachment', handler(deleteRfiAttachmentController));

rfiRouter.post(
  '/ACS',
  validateRequestBody(journalManuscriptEditorialSchema),
  handler(ACSAutoController),
);

export default rfiRouter;
