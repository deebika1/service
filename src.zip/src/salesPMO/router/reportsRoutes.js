import express from 'express';
import {
  validateRequestBody,
  validateRequestParams,
} from '../helpers/middleware.js';
import {
  getOrderinflowFailureController,
  getOrderinflowReportController,
  getPlanVsActualTableDataController,
  getProjectWiseTableDataController,
  getUserMappedAndBaseDuController,
} from '../controller/index.js';
import {
  getAuditDataSchema,
  getAuditSearchDDSchema,
  getPlanVsActualReportDataSchema,
  getProjectWiseReportDataSchema,
  getUserMappedAndBaseDuSchema,
} from '../helpers/validation.js';
import {
  getAuditDataController,
  getAuditModuleDDController,
  getAuditSearchDDController,
} from '../controller/rfiController.js';

const reportsRouter = express.Router();
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };
// order in flow
reportsRouter.post(
  '/ordreinflowFailure',
  handler(getOrderinflowFailureController),
);
reportsRouter.post('/orderinflow', handler(getOrderinflowReportController));
reportsRouter.get(
  '/:type/:userid',
  validateRequestParams(getUserMappedAndBaseDuSchema),
  handler(getUserMappedAndBaseDuController),
);
// order in flow
// project wise
reportsRouter.post(
  '/project',
  validateRequestBody(getProjectWiseReportDataSchema),
  handler(getProjectWiseTableDataController),
);
// project wise
// plan vs actual
reportsRouter.post(
  '/plan',
  validateRequestBody(getPlanVsActualReportDataSchema),
  handler(getPlanVsActualTableDataController),
);
// plan vs actual
// audit log report
reportsRouter.get('/auditmodule', handler(getAuditModuleDDController));
reportsRouter.post(
  '/jobdd',
  validateRequestBody(getAuditSearchDDSchema),
  handler(getAuditSearchDDController),
);
reportsRouter.post(
  '/auditdata',
  validateRequestBody(getAuditDataSchema),
  handler(getAuditDataController),
);
// audit log report

export default reportsRouter;
