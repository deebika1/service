import express from 'express';
import swaggerUi from 'swagger-ui-express';
import { readFileSync } from 'fs';
import {
  insertKAMCustomerRelController,
  insertJournalRateController,
  insertJobRateController,
  insertServiceAndStageMappingController,
  updateKAMCustomerRelByIdController,
  updateJobRateByIdController,
  updateJournalRateByIdController,
  updateServiceMappingByIdController,
  updateStageMappingByIdController,
  getKAMCustomerRelController,
  getPlanTemplateDownloadController,
  insertInvoiceController,
  insertReassignKamOrCmController,
  getSegmentController,
  getVerticalController,
  setSegmentController,
  deleteSegmentController,
  setVerticalController,
  deleteVerticalController,
  getKAMRelChangeController,
  setServiceController,
  getServiceController,
  deleteServiceController,
  checkSegmentController,
  checkVerticalController,
  checkServiceController,
  getKAMdetailsByIdController,
  updateKAMPendingByIdController,
  approveRejectKAMChangeController,
  getKAMPendingHistoryController,
  setOrdInflowController,
  getJournalRateEntryController,
  planUploadController,
  getExceptionDataController,
  getSalesPMOMasterDDController,
  getRateEntryMapScrServiceDDController,
  getStageDDByserviceMappingController,
  getExchangeCurrencyandRateController,
  InsorUpdExchangeRateController,
  getYearDropdownController,
  getUploadedPlanDetailsController,
  getUploadedPlanController,
  getServiceMapController,
  getStageMapController,
  getJobRateController,
  getJobRateAdjController,
  insandGetFinancialYearController,
  getUserMappedDuByUserIdController,
  getCustomerByDuController,
  getVerticalByDuCustomerController,
  addMasterController,
  updateMasterController,
  deleteMasterController,
  getMasterController,
  getWorkorderListController,
  insertRateEntryController,
  getRateEntryDDController,
  updateLockUnlockWorkorderController,
  getExceptiondataController,
  lockUnlockWorkorderController,
  getWorkorderHistoryController,
  getRateEntryDataController,
  getRateEntryActualsController,
  getRateEntryHistoryController,
  getMonthYearController,
  insertJobRateAdjController,
  getRateEntryAdjController,
  deleteRateEntryAdjController,
  getDuFromKamCustController,
  getServiceFromKAMController,
  getRateConfigCategoryController,
  getRateConfigStageByWorkFlowController,
  insertRateEntryConfigController,
  getInvoiceDescriptionController,
  insertInvoiceDescController,
  getRateConfigTableController,
  getInvoicedynamicfieldController,
  getInvoicefieldmappingController,
  insertInvoicefieldmappingController,
  updateInvoicefieldmappingController,
  rateEntryCombinationCheckController,
  getRateEntryFetchController,
  getRateConfigInvoiceDescController,
  getRateEntryInvoiceFieldController,
} from '../controller/index.js';
import {
  deleteRateEntryAdjSchema,
  geCustomerByDuidSchema,
  geVerticalByDuidSchema,
  getChangeReqFilterSchema,
  getKAMPendingHistorySchema,
  getKamDetailsSchema,
  getMasterSchema,
  getRateConfigStageByWorkFlowSchema,
  getRateEntryActualSchema,
  getRateEntryAdjSchema,
  getRateEntryByIdSchema,
  getRateEntryDDSchema,
  getRateEntryTableDataSchema,
  getRateHistorySchema,
  getServiceFromKAMSchema,
  getStageDDByserviceMappingSchema,
  getUserMappedDuByUserIdSchema,
  handleCustomerInsertSchema,
  inserAdjJobRateSchema,
  insertInvoiceDescSchema,
  insertJournalRateEntrySchema,
  insertRateEntryConfigSchema,
  insertRateEntrySchema,
  insertReassignKamOrCmSchema,
  journalRateEnryServiceDDSchema,
  rateConfigAppendixSchema,
  rateConfigCombinationSchema,
  rateConfigTableSchema,
} from '../helpers/validation.js';
import {
  validateRequestBody,
  validateRequestParams,
} from '../../iquality/helpers/middleware.js';
import rfiRouter from './rfiRoutes.js';
import reportsRouter from './reportsRoutes.js';
import { _download } from '../../modules/utils/azure/index.js';
// Pearson
import pearsonRouter from './pearsonRoutes.js';

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}

const salesPMORouter = express.Router();
swaggerDocs(salesPMORouter);
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

salesPMORouter.get(
  '/masters/:table',
  validateRequestParams(getMasterSchema),
  handler(getSalesPMOMasterDDController),
);
salesPMORouter.get(
  '/service/:duId/:customerId',
  validateRequestParams(journalRateEnryServiceDDSchema),
  handler(getRateEntryMapScrServiceDDController),
);
salesPMORouter.get(
  '/stage/:serviceMapId',
  validateRequestParams(getStageDDByserviceMappingSchema),
  handler(getStageDDByserviceMappingController),
);
salesPMORouter.post('/invoices/push', handler(insertInvoiceController));

salesPMORouter.post(
  '/createkamcustrel',
  validateRequestBody(handleCustomerInsertSchema),
  handler(insertKAMCustomerRelController),
);
salesPMORouter.post(
  '/kamCustRel/update',
  handler(updateKAMCustomerRelByIdController),
);
salesPMORouter.post('/kamupdatereq', handler(updateKAMPendingByIdController));
salesPMORouter.post('/apprchange', handler(approveRejectKAMChangeController));
salesPMORouter.post('/kammaping', handler(getKAMCustomerRelController));
salesPMORouter.get(
  '/kamdetails/:rectype/:relid',
  validateRequestParams(getKamDetailsSchema),
  handler(getKAMdetailsByIdController),
);
salesPMORouter.get(
  '/changereq/:status/:type',
  validateRequestParams(getChangeReqFilterSchema),
  handler(getKAMRelChangeController),
);
salesPMORouter.get(
  '/history/:queueid',
  validateRequestParams(getKAMPendingHistorySchema),
  handler(getKAMPendingHistoryController),
);
salesPMORouter.post(
  '/journalrate/insert',
  validateRequestBody(insertJournalRateEntrySchema),
  handler(insertJournalRateController),
);
salesPMORouter.post(
  '/insertrateentry',
  validateRequestBody(insertRateEntrySchema),
  handler(insertRateEntryController),
);
salesPMORouter.post(
  '/journalrate/update',
  handler(updateJournalRateByIdController),
);
salesPMORouter.post('/jobrate/insert', handler(insertJobRateController));
salesPMORouter.post('/jobrate/update', handler(updateJobRateByIdController));
salesPMORouter.post(
  '/servicestagemapping/insert',
  handler(insertServiceAndStageMappingController),
);
salesPMORouter.post(
  '/servicestagemapping/update',
  handler(updateServiceMappingByIdController),
);
salesPMORouter.post(
  '/servicestagemapping/update',
  handler(updateStageMappingByIdController),
);
salesPMORouter.get('/plandownload', handler(getPlanTemplateDownloadController));
salesPMORouter.post(
  '/reassignkam',
  validateRequestBody(insertReassignKamOrCmSchema),
  handler(insertReassignKamOrCmController),
);
salesPMORouter.post('/getsegment', handler(getSegmentController));
salesPMORouter.post('/getvertical', handler(getVerticalController));
salesPMORouter.post('/setsegment', handler(setSegmentController));
salesPMORouter.post('/deletesegment', handler(deleteSegmentController));
salesPMORouter.post('/setvertical', handler(setVerticalController));
salesPMORouter.post('/deletevertical', handler(deleteVerticalController));
salesPMORouter.post('/getservice', handler(getServiceController));
salesPMORouter.post('/setservice', handler(setServiceController));
salesPMORouter.post('/deleteservice', handler(deleteServiceController));
salesPMORouter.post('/checksegment', handler(checkSegmentController));
salesPMORouter.post('/checkvertical', handler(checkVerticalController));
salesPMORouter.post('/checkservice', handler(checkServiceController));
salesPMORouter.post('/setorderinflow', handler(setOrdInflowController));
salesPMORouter.get(
  '/getrateentry/:vertical/:id',
  validateRequestParams(getRateEntryByIdSchema),
  handler(getRateEntryDataController),
);
salesPMORouter.post(
  '/getrateentrystage',
  validateRequestBody(getRateEntryTableDataSchema),
  handler(getJournalRateEntryController),
);
salesPMORouter.get('/monthyr', handler(getMonthYearController));
salesPMORouter.post(
  '/rateadj',
  validateRequestBody(inserAdjJobRateSchema),
  handler(insertJobRateAdjController),
);
salesPMORouter.get(
  '/adjdata/:bookcode/:workorderid',
  validateRequestParams(getRateEntryAdjSchema),
  handler(getRateEntryAdjController),
);
salesPMORouter.get(
  '/deleteadj/:adjustmentid/:userid',
  validateRequestParams(deleteRateEntryAdjSchema),
  handler(deleteRateEntryAdjController),
);

// Plan Upload
salesPMORouter.post('/planupload', handler(planUploadController));
salesPMORouter.get('/exceptiondata', handler(getExceptionDataController));
salesPMORouter.get(
  '/currencyexchangerate/:Year',
  handler(getExchangeCurrencyandRateController),
);
salesPMORouter.post(
  '/insorupdexchangerate',
  handler(InsorUpdExchangeRateController),
);
salesPMORouter.get('/getyeardropdown/:key', handler(getYearDropdownController));
salesPMORouter.post('/plandetails', handler(getUploadedPlanDetailsController));
salesPMORouter.post('/getuploadedplan', handler(getUploadedPlanController));
salesPMORouter.post(
  '/insorgetfyear',
  handler(insandGetFinancialYearController),
);
// Plan Upload end

// rateEntry Start
salesPMORouter.post('/servicemap', handler(getServiceMapController));
salesPMORouter.post('/stagemap', handler(getStageMapController));
salesPMORouter.post('/getrateentry', handler(getJobRateController));
salesPMORouter.post('/getrateadj', handler(getJobRateAdjController));
salesPMORouter.get(
  '/getuserdu/:userid',
  validateRequestParams(getUserMappedDuByUserIdSchema),
  handler(getUserMappedDuByUserIdController),
);
salesPMORouter.get('/du', handler(getDuFromKamCustController));
salesPMORouter.get(
  '/customer/:duid',
  validateRequestParams(geCustomerByDuidSchema),
  handler(getCustomerByDuController),
);
salesPMORouter.get(
  '/vertical/:duid/:customerid',
  validateRequestParams(geVerticalByDuidSchema),
  handler(getVerticalByDuCustomerController),
);
salesPMORouter.post(
  '/rateentrydd',
  validateRequestBody(getRateEntryDDSchema),
  handler(getRateEntryDDController),
);
salesPMORouter.get(
  '/actuals/:bookcode/:workorderid',
  validateRequestParams(getRateEntryActualSchema),
  handler(getRateEntryActualsController),
);
salesPMORouter.get(
  '/history/:vertical/:rateid',
  validateRequestParams(getRateHistorySchema),
  handler(getRateEntryHistoryController),
);
// rateEntry End

// Masters
salesPMORouter.post('/getmasterdata', handler(getMasterController));
salesPMORouter.post('/addmasterdata', handler(addMasterController));
salesPMORouter.post('/updatemasterdata', handler(updateMasterController));
salesPMORouter.post('/deletemasterdata', handler(deleteMasterController));

// Lock/Unlock
salesPMORouter.get(
  '/getworkorderlist/:searchText',
  handler(getWorkorderListController),
);
salesPMORouter.post(
  '/updateworkorderlist',
  handler(updateLockUnlockWorkorderController),
);
salesPMORouter.get('/getexceptiondata', handler(getExceptiondataController));
salesPMORouter.post(
  '/updateworkoderlockunlock',
  handler(lockUnlockWorkorderController),
);
salesPMORouter.get(
  '/getworkorderhistory/:workorderID',
  handler(getWorkorderHistoryController),
);

// rate entryConfigurations
salesPMORouter.get(
  '/rateconfig/service/:duid/:customerid/:verticalid',
  validateRequestParams(getServiceFromKAMSchema),
  handler(getServiceFromKAMController),
);
salesPMORouter.get(
  '/rateconfig/stage/:customerid',
  validateRequestParams(getRateConfigStageByWorkFlowSchema),
  handler(getRateConfigStageByWorkFlowController),
);
salesPMORouter.get(
  '/rateconfig/category',
  handler(getRateConfigCategoryController),
);
salesPMORouter.get(
  '/rateconfig/comb/:duid/:customerid/:verticalid',
  validateRequestParams(rateConfigCombinationSchema),
  handler(rateEntryCombinationCheckController),
);

salesPMORouter.get(
  '/rateconfig/invoice',
  handler(getInvoiceDescriptionController),
);
salesPMORouter.post(
  '/rateconfig',
  validateRequestBody(insertRateEntryConfigSchema),
  handler(insertRateEntryConfigController),
);
salesPMORouter.post(
  '/invoicedesc',
  validateRequestBody(insertInvoiceDescSchema),
  handler(insertInvoiceDescController),
);
salesPMORouter.post('/rateconfig/rate', handler(getRateEntryFetchController));
salesPMORouter.post(
  '/rateconfig/table',
  //  validateRequestBody(rateConfigTableSchema),
  handler(getRateConfigTableController),
);
// rate Entry configurations

salesPMORouter.get(
  '/rateconfig/template',
  handler(getInvoicedynamicfieldController),
);
salesPMORouter.post(
  '/invoicefieldmapping',
  handler(getInvoicefieldmappingController),
);
salesPMORouter.post(
  '/rateconfig/template/insert',
  validateRequestBody(rateConfigAppendixSchema),
  handler(insertInvoicefieldmappingController),
);
salesPMORouter.post(
  '/invoiceupdatefieldmapping',
  handler(updateInvoicefieldmappingController),
);

salesPMORouter.post(
  '/rateconfig/invoicedesc',
  handler(getRateConfigInvoiceDescController),
);
salesPMORouter.post(
  '/rateconfig/invoicefield',
  validateRequestBody(rateConfigTableSchema),
  handler(getRateEntryInvoiceFieldController),
);

// RFI
salesPMORouter.use('/rfi', rfiRouter);
// REPORTS
salesPMORouter.use('/reports', reportsRouter);
salesPMORouter.post('/uploads', async (req, res) => {
  const data = await _download(req.body.path);
  res.status(200).send(data);
});

// Pearson Price Grid
salesPMORouter.use('/pearson', pearsonRouter);

export default salesPMORouter;
