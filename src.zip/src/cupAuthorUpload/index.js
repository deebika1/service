import express from 'express';
import fs from 'fs';
import {
  BlobServiceClient,
  generateBlobSASQueryParameters,
  ContainerSASPermissions,
  StorageSharedKeyCredential,
} from '@azure/storage-blob';
import { query } from '../database/postgres.js';

const cupAuthorUploadRoute = express.Router();

const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

const errorHandler = (res, error, customMessage = 'Internal server error') => {
  console.error('Error:', error); // Log the error for debugging

  // Send a structured error response
  return res.status(500).json({
    message: customMessage,
    error: error.message || error, // Include the error message if available
  });
};

// Azure Storage Configuration
const AZURE_STORAGE_ACCOUNT_NAME = 'cupjournal';
const AZURE_STORAGE_ACCOUNT_KEY =
  'Oo/K7Qp6CISwPvxiKDqD8BjA0D9kbP5zmkwKkhZCfsDRiTphzd3HChmBE7Y4AQ0aWdVpVgmdi/ND+ASt1L4yNw==';
const CONTAINER_NAME = 'cupauhtoruploads';

// Create BlobServiceClient
const blobServiceClient = new BlobServiceClient(
  `https://${AZURE_STORAGE_ACCOUNT_NAME}.blob.core.windows.net`,
  new StorageSharedKeyCredential(
    AZURE_STORAGE_ACCOUNT_NAME,
    AZURE_STORAGE_ACCOUNT_KEY,
  ),
);

const uploadToBlob = async (req, res) => {
  try {
    if (!req.files && !req.files.file) {
      return res.status(400).send('No file uploaded.');
    }
    // In your route:
    // const file = req?.files.file;
    const { woid } = req.body;
    const uploadedFile = req.files.file; // Access the uploaded file
    const { tempFilePath, name, size } = uploadedFile;

    // Read the file from the temp path
    const fileBuffer = fs.readFileSync(tempFilePath);

    const sanitizedFileName = name.replace(/\s+/g, '_');
    const fileName = `${woid}_${sanitizedFileName}`;

    const containerClient =
      blobServiceClient.getContainerClient(CONTAINER_NAME);
    const blockBlobClient = containerClient.getBlockBlobClient(fileName);

    // Upload file to blob
    await blockBlobClient.upload(fileBuffer, size);
    // Generate the URL for the uploaded file
    const fileUrl = blockBlobClient.url;
    // Extract the relative path by removing the base URL
    const baseUrl = `https://${AZURE_STORAGE_ACCOUNT_NAME}.blob.core.windows.net`;
    const relativePath = fileUrl.replace(baseUrl, '');
    return res.status(200).send({
      message: 'File uploaded successfully.',
      fileName,
      fileUrl: relativePath,
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    return res
      .status(500)
      .send({ error: 'Failed to upload file.', message: error.message });
  }
};

const downloadFileFromBlob = async (req, res) => {
  const { blobName, expiryMinutes } = req.body;

  if (!blobName || !expiryMinutes) {
    return res
      .status(400)
      .send("Missing 'blobName' or 'expiryMinutes' query parameter.");
  }

  // Calculate a date three months from now
  const expiresOn = new Date();
  expiresOn.setMonth(expiresOn.getMonth() + 3);

  try {
    // Extract the actual blob name by removing the prefix if present
    const prefixToRemove = `/${CONTAINER_NAME}/`;
    const fileName = blobName.startsWith(prefixToRemove)
      ? blobName.slice(prefixToRemove.length)
      : blobName;

    const containerClient =
      blobServiceClient.getContainerClient(CONTAINER_NAME);
    const blobClient = containerClient.getBlobClient(fileName);

    // Ensure the blob exists
    const exists = await blobClient.exists();
    if (!exists) {
      return res.status(404).send('Blob not found.');
    }

    // Generate SAS Token
    const sasToken = generateBlobSASQueryParameters(
      {
        containerName: CONTAINER_NAME,
        fileName,
        permissions: ContainerSASPermissions.parse('r'), // Read-only permission
        startsOn: new Date(),
        // expiresOn: new Date(new Date().valueOf() + expiryMinutes * 60 * 1000), // Expiry based on input
        expiresOn, // Expiry based on input
      },
      new StorageSharedKeyCredential(
        AZURE_STORAGE_ACCOUNT_NAME,
        AZURE_STORAGE_ACCOUNT_KEY,
      ),
    ).toString();

    // Define prefix (explicitly append the prefix header URL)
    const prefixUrl = `https://${AZURE_STORAGE_ACCOUNT_NAME}.blob.core.windows.net/`;
    const downloadUrl = `${prefixUrl}${CONTAINER_NAME}/${fileName}?${sasToken}`;

    // const downloadUrl = `${blobClient.url}?${sasToken}`;
    return res.status(200).send({ downloadUrl });
  } catch (error) {
    console.error('Error generating SAS key:', error);
    return res.status(500).send({ error: 'Failed to generate SAS key.' });
  }
};

export const getCustomerMaster = async (req, res) => {
  try {
    const script = `SELECT 
          customerid AS column_id, 
          customername AS column_name 
        FROM public.mst_customer  
        WHERE isactive = true 
        ORDER BY customername;`;
    const result = await query(script);
    // If result is empty, return a 400 response with a message
    if (result && result && result.length > 0) {
      return res.send(result); // Send results as JSON
    }
    // If no data is found, return a 400 response
    return res.status(400).json({ message: 'No Customers found.' });
  } catch (error) {
    // Return a 500 response in case of an error
    console.error('Error fetching data:', error);
    return errorHandler(res, error, 'Failed to fetch journal data');
  }
};

export const getJournalMaster = async (req, res) => {
  try {
    const { customerId } = req.params; // Get customerId from route parameters
    const script = `
      SELECT 
        journalid as column_id, 
        journalacronym as column_name
      FROM public.org_mst_customer omc
      JOIN public.org_mst_customer_orgmap omco
          ON omco.customerid = omc.customerid
      JOIN public.pp_mst_journal pmj 
          ON pmj.custorgmapid = omco.custorgmapid
      WHERE omc.itrack_customerid = $1;
    `;
    // Run the query
    const result = await query(script, [customerId]);
    // Check if there are any results
    if (result && result.length > 0) {
      return res.send(result); // Send results as JSON
    }
    // If no data is found, return a 400 response
    return res
      .status(400)
      .json({ message: 'No journals found for this customer.' });
  } catch (error) {
    // Call the common error handler
    return errorHandler(res, error, 'Failed to fetch journal data');
  }
};

export const checkWorkorderIsPresent = async (req, res) => {
  try {
    const { itemcode, customerid, journalid } = req.params; // Get itemcode from route parameters
    const script = `SELECT workorderid FROM wms_workorder ww
    join public.org_mst_customer omc on omc.itrack_customerid = $1
    where ww.customerid = omc.customerid and ww.journalid  = $2  and ww.itemcode = $3 and ww.isactive = true order by 1 desc limit 1`;
    // Run the query
    const result = await query(script, [customerid, journalid, itemcode]);
    // Check if any workorder was found
    if (result && result.length > 0) {
      return res.send(result); // Return workorder details as JSON
    }
    // If no workorder is found, send a 400 response
    return res.status(400).json({ message: 'Workorder not found.' });
  } catch (error) {
    // Call the common error handler
    return errorHandler(res, error, 'Failed to check workorder');
  }
};

export const insAttachmentInfoController = async (req, res) => {
  try {
    // Destructure values from the request body
    const { customerid, journalid, workorderid, itemcode, fileurl, createdby } =
      req.body;
    const InsertLogscript = `INSERT INTO public.log_cupauthor_upload 
      (customerid,journalid,workorderid,itemcode,fileurl,createdby) VALUES ($1,$2,$3,$4,$5,$6)`;
    // // Call the service to insert attachment info
    const result = await query(InsertLogscript, [
      customerid,
      journalid,
      workorderid,
      itemcode,
      fileurl,
      createdby,
    ]);
    // Send a successful response
    return res.status(200).json(result);
  } catch (error) {
    // Use the common error handler
    return errorHandler(res, error, 'Failed to insert attachment info');
  }
};

cupAuthorUploadRoute.get('/customer', handler(getCustomerMaster));
cupAuthorUploadRoute.get('/journal/:customerId', handler(getJournalMaster));
cupAuthorUploadRoute.get(
  '/article/:customerid/:journalid/:itemcode',
  handler(checkWorkorderIsPresent),
);
cupAuthorUploadRoute.post('/logupload', handler(insAttachmentInfoController));
cupAuthorUploadRoute.post('/uploadfile', handler(uploadToBlob));
cupAuthorUploadRoute.post('/downloadblobfile', handler(downloadFileFromBlob));

export default cupAuthorUploadRoute;
