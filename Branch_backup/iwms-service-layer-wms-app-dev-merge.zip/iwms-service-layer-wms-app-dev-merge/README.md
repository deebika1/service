# WMS Server

Worflow Management System server.

## Prerequesites

* NodeJS - V14

## Steps to run the app

* Clone the repository into your work location.

* Open the terminal from the work location.

* Execute the below command to install the project dependencies.

```bash

npm i

```

* Execute the below command to launch the application.

```bash

npm start

```

> Server will be listenning at [localhost:5000](http://localhost:5000) 
