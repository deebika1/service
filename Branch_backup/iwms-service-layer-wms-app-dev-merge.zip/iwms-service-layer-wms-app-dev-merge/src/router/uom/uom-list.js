import express from 'express';
import { getUomList, updateUomList } from '../../modules/uom-list/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/getUomList', handler(getUomList));
router.post('/updateUomList', handler(updateUomList));

export default router;
