import express from 'express';
import {
  getFolderPath,
  getTemplatePath,
  getTemplateSrcDetails,
} from '../../modules/utils/wmsFolder/index.js';
import {
  getFileValidationStatus,
  isValidFile,
  getFilteredFiles,
  getToolsFileDetail,
  getIncomingFileType,
  deleteTranscationEnterisForCancel,
  getPreviousActivitiesForCancel,
  checkWipActivity,
} from '../../modules/utils/fileValidation/index.js';
import {
  checkout,
  copyFile,
  createFolder,
  getDocumentProps,
  getUuid,
  deleteFile,
  isFileExist,
  retreiveFiles,
  getRestoreVersion,
} from '../../modules/utils/okm/index.js';
import {
  createAPIRequestId,
  completeAPIRequestId,
  updateAPIRequestId,
  buildApiConfig,
  getToolsStatusForServiceTask,
} from '../../modules/utils/tools/api.js';
import {
  acknowledge,
  initialAcknowledge,
} from '../../modules/utils/tools/ack.js';
import {
  updateBackupFile,
  getBackupFileDetails,
} from '../../modules/utils/tools/backup.js';
import {
  IOPPLanguageEditUpdate,
  IOPPStatusUpdate,
} from '../../modules/customerIntegration/iopp/iopp.js';
import {
  FolderCopy,
  getToolsData,
  iAuthorLinkGeneration,
  getiAuthorActivityLink,
  iNLPScoreGeneration,
  getiAuthorActivityFiles,
  saveiNetLink,
  gettoolLink,
} from '../../modules/utils/tools/index.js';
import { fetchguId } from '../../modules/task/tools/index.js';

import { fetchXmlReaderFromSftpWatcher } from '../../modules/filetransferkit/ioopMetaReader.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/getFolderPath', handler(getFolderPath));
router.post('/getTemplateSrcDetails', handler(getTemplateSrcDetails));
router.post('/getTemplatePath', handler(getTemplatePath));
router.post('/getFileValidationStatus', handler(getFileValidationStatus));
router.post('/isValidFile', handler(isValidFile));
router.post('/getToolsFileDetail', handler(getToolsFileDetail));
router.post('/getIncomingFileType', handler(getIncomingFileType));
router.post(
  '/deleteTranscationEnterisForCancel',
  handler(deleteTranscationEnterisForCancel),
);
router.post('/getFilteredFiles', handler(getFilteredFiles));
router.post(
  '/getPreviousActivitiesForCancel',
  handler(getPreviousActivitiesForCancel),
);
router.post('/updateBackupFile', handler(updateBackupFile));
router.post('/getBackupFileDetails', handler(getBackupFileDetails));
router.post('/checkWipActivity', handler(checkWipActivity));

// OKM Utils
router.post('/okm/checkout', handler(checkout));
router.post('/okm/copyFile', handler(copyFile));
router.post('/okm/createFolder', handler(createFolder));
router.post('/okm/getDocumentProps', handler(getDocumentProps));
router.post('/okm/getUuid', handler(getUuid));
router.post('/okm/deleteFile', handler(deleteFile));
router.post('/okm/isFileExist', handler(isFileExist));
router.post('/okm/retreiveFiles', handler(retreiveFiles));
router.post('/okm/getRestoreVersion', handler(getRestoreVersion));
router.post('/okm/FolderCopy', handler(FolderCopy));

// Tools
router.post('/tools/createAPIRequestId', handler(createAPIRequestId));
router.post('/tools/completeAPIRequestId', handler(completeAPIRequestId));
router.post('/tools/iAuthorLinkGeneration', handler(iAuthorLinkGeneration));
router.post('/tools/IOPPLanguageEditUpdate', handler(IOPPLanguageEditUpdate));
router.post('/tools/IOPPStatusUpdate', handler(IOPPStatusUpdate));
router.post('/tools/iNLPScoreGeneration', handler(iNLPScoreGeneration));
router.post('/tools/getiAuthorActivityFiles', handler(getiAuthorActivityFiles));
router.post('/tools/getiAuthorActivityLink', handler(getiAuthorActivityLink));
router.post('/tools/getToolsData', handler(getToolsData));
router.post('/tools/updateAPIRequestId', handler(updateAPIRequestId));
router.post('/tools/buildApiConfig', handler(buildApiConfig));
router.post('/tools/acknowledge', handler(acknowledge));
router.post('/tools/initialAcknowledge', handler(initialAcknowledge));
router.post('/tools/fetchguId', handler(fetchguId));
router.post(
  '/tools/getToolsStatusForServiceTask',
  handler(getToolsStatusForServiceTask),
);
router.post('/tools/saveiNetLink', handler(saveiNetLink));
router.post('/tools/gettoolLink', handler(gettoolLink));

router.post(
  '/ftp/fetchXmlReaderFromSftpWatcher',
  handler(fetchXmlReaderFromSftpWatcher),
);
export default router;
