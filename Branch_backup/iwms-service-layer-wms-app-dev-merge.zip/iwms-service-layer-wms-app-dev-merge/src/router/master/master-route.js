import express from 'express';
import { invokeFtpFileUpload } from '../../modules/filetransferkit/index.js';
import { pkgUploadOpenKmToSftp } from '../../modules/filetransferkit/proofcentral.js';
import { pkgDepositTrigger } from '../../modules/common/index.js';
import { updateLogFileToDms } from '../../modules/utils/logs/logSync.js';
import { fetchXmlReaderFromSftpWatcher } from '../../modules/filetransferkit/ioopMetaReader.js';
import {
  getStageMasterList,
  getActivityMasterList,
  convertNewFileConfig,
  convertdifferentFileConfigAll,
  converNewConfig,
  convertNewToolConfig,
  getDivisionMasterList,
  getSubDivisionMasterList,
  createActivity,
  deleteActivity,
  createStage,
  deleteStage,
  createDivision,
  deleteDivision,
  createSubDivision,
  deleteSubDivision,
  getLocationMasterList,
  createLocation,
  deleteLocation,
  getColorMasterList,
  createColor,
  deleteColor,
  getSoftwareMasterList,
  createSoftware,
  deleteSoftware,
  userList,
  OptionList,
  userRoleList,
  createUser,
  createRole,
  createSkill,
  addTemplateDetails,
  updateTemplateStatus,
  deleteTemplate,
  getTemplateList,
  getLibraryTempList,
  getSeparateTempList,
  deleteSkill,
  getMasterOptionLists,
  createJournalMaster,
  journalFile,
  getJournalList,
  updateJournalMaster,
  nonArticleList,
  getjournalduedays,
  getJournalInstruction,
  getJournalContact,
  getToolMasterOptions,
  getToolsCommonOptions,
  createToolMaster,
  getToolMaster,
  getSoftwareMaster,
  deleteToolMaster,
  getToolById,
  updateToolById,
  getJournalAcroymn,
  createNormMaster,
  getNormMaster,
  getNormById,
  deleteNormMaster,
  getFileDetailsforWorkorder,
  getBlobFileDetailsForPath,
  getWorkorderWithNameLike,
  getAccessRightsBlobFiles,
  // getJournalOptionList,
  // getJournalBaseWOList,
  getWoChapters,
  updateNorms,
  checkJobNormCombination,
  getNotificationsOptionList,
  getChecklistOptionList,
  createCheckListMaster,
  getCheckListMaster,
  getPrePopulateInstructionAnswers,
  getPrePopulateInstruction,
  getEmailReader,
  getFilenameDetails,
  insertupdateEmailReader,
  updateCheckListMaster,
  getTemplateCommonOptions,
  getTemplateById,
  getFileInfo,
  addTempDetails,
  deleteCheckListMaster,
  getFtpList,
  checkSkillAvaliablity,
  createComposingSoftwareMaster,
  deleteSoftwareMaster,
  stageActivityDetails,
  softstageActivityDetails,
  wipActivityDetails,
  workorderlock,
  getWfidOptions,
  getSoftwareidOptions,
  getToolidOptions,
  getSoftwareById,
  updateSoftwareById,
  getToolstPlaceholderField,
  getLocalToolsPath,
  multipleInstance,
  deletemultipleInstanceTwo,
  retriggerActivity,
  getcustomerconfigdetails,
  getDeliverUnitList,
} from '../../modules/master/index.js';
import { generateiAuthorHtml } from '../../modules/utils/tools/index.js';
import { uploadCamsPackage } from '../../modules/filetransferkit/camsPackage.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/getStageMasterList', handler(getStageMasterList));
router.post('/getActivityMasterList', handler(getActivityMasterList));
router.post('/convertNewFileConfig', handler(convertNewFileConfig));
router.post(
  '/convertdifferentFileConfigAll',
  handler(convertdifferentFileConfigAll),
);
router.post('/converNewConfig', handler(converNewConfig));
router.post('/convertNewToolConfig', handler(convertNewToolConfig));
router.get('/updateLogFileToDms', handler(updateLogFileToDms));

router.post('/createActivity', handler(createActivity));
router.post('/deleteActivity', handler(deleteActivity));
router.post('/createStage', handler(createStage));
router.post('/deleteStage', handler(deleteStage));
router.post('/getDivisionMasterList', handler(getDivisionMasterList));
router.post('/createDivision', handler(createDivision));
router.post('/deleteDivision', handler(deleteDivision));
router.post('/getSubDivisionMasterList', handler(getSubDivisionMasterList));
router.post('/createSubDivision', handler(createSubDivision));
router.post('/deleteSubDivision', handler(deleteSubDivision));
router.post('/getLocationMasterList', handler(getLocationMasterList));
router.post('/createLocation', handler(createLocation));
router.post('/deleteLocation', handler(deleteLocation));
router.post('/getColorMasterList', handler(getColorMasterList));
router.post('/createColor', handler(createColor));
router.post('/deleteColor', handler(deleteColor));
router.post('/getSoftwareMasterList', handler(getSoftwareMasterList));
router.post('/createSoftware', handler(createSoftware));
router.post('/deleteSoftware', handler(deleteSoftware));
router.post('/userList', handler(userList));
router.post('/OptionList', handler(OptionList));
router.post('/userRoleList', handler(userRoleList));
router.post('/createUser', handler(createUser));
router.post('/createRole', handler(createRole));
router.post('/createSkill', handler(createSkill));
router.post('/getTemplateList', handler(getTemplateList));
router.post('/getLibraryTempList', handler(getLibraryTempList));
router.post('/getSeparateTempList', handler(getSeparateTempList));
router.post('/addTemplateDetails', handler(addTemplateDetails));
router.post('/updateTemplateStatus', handler(updateTemplateStatus));
router.post('/deleteTemplate', handler(deleteTemplate));
router.post('/deleteSkill', handler(deleteSkill));
router.post('/getMasterOptionLists', handler(getMasterOptionLists));
router.post('/createJournalMaster', handler(createJournalMaster));
router.post('/journalFile', handler(journalFile));
router.post('/getJournalList', handler(getJournalList));
router.post('/updateJournalMaster', handler(updateJournalMaster));
router.post('/nonArticleList', handler(nonArticleList));
router.post('/getjournalduedays', handler(getjournalduedays));
router.post('/getJournalInstruction', handler(getJournalInstruction));
router.post('/getJournalContact', handler(getJournalContact));
router.post('/getJournalAcroymn', handler(getJournalAcroymn));
router.post('/getFileDetailsforWorkorder', handler(getFileDetailsforWorkorder));
router.post('/getBlobFileDetailsForPath', handler(getBlobFileDetailsForPath));
router.post('/getWorkorderWithNameLike', handler(getWorkorderWithNameLike));
router.post('/getAccessRightsBlobFiles', handler(getAccessRightsBlobFiles));
router.post('/getWoChapters', handler(getWoChapters));

// Tool Master Start
router.post('/getToolMasterOptions', handler(getToolMasterOptions));
router.post('/getToolsCommonOptions', handler(getToolsCommonOptions));
router.post('/createToolMaster', handler(createToolMaster));
router.post(
  '/createComposingSoftwareMaster',
  handler(createComposingSoftwareMaster),
);

// customer config details
router.post('/getcustomerconfigdetails', handler(getcustomerconfigdetails));
router.post('/getDeliverUnitList', handler(getDeliverUnitList));

router.post('/multipleInstance', handler(multipleInstance));
router.post('/deletemultipleInstanceTwo', handler(deletemultipleInstanceTwo));
router.post('/getToolMaster', handler(getToolMaster));
router.post('/getSoftwareMaster', handler(getSoftwareMaster));
router.post('/deleteToolMaster', handler(deleteToolMaster));
router.post('/deleteSoftwareMaster', handler(deleteSoftwareMaster));
router.post('/getToolById', handler(getToolById));
router.post('/getSoftwareById', handler(getSoftwareById));
router.post('/updateToolById', handler(updateToolById));
router.post('/updateSoftwareById', handler(updateSoftwareById));
router.post('/getToolstPlaceholderField', handler(getToolstPlaceholderField));
router.post('/getLocalToolsPath', handler(getLocalToolsPath));
router.post('/stageActivityDetails', handler(stageActivityDetails));
router.post('/softstageActivityDetails', handler(softstageActivityDetails));
router.post('/wipActivityDetails', handler(wipActivityDetails));
router.post('/workorderlock', handler(workorderlock));
router.post('/getWfidOptions', handler(getWfidOptions));
router.post('/getToolidOptions', handler(getToolidOptions));
router.post('/getSoftwareidOptions', handler(getSoftwareidOptions));
router.post('/retriggerActivity', handler(retriggerActivity));
// Tool Master End

// Email reader start
router.post('/getEmailReader', handler(getEmailReader));
router.post('/insertupdateEmailReader', handler(insertupdateEmailReader));
router.post('/generateiAuthorHtml', handler(generateiAuthorHtml));
// Email reader End

// Configuration Ftp Start
router.post('/getFtpList', handler(getFtpList));
// Configuration Ftp End

// Library Report Start
router.post('/getTemplateById', handler(getTemplateById));
router.post('/addTempDetails', handler(addTempDetails));
router.post('/getTemplateCommonOptions', handler(getTemplateCommonOptions));
router.post('/getFileInfo', handler(getFileInfo));
// Library Report End

// Get File sequence filename details start
router.post('/getFilenameDetails', handler(getFilenameDetails));
// Get File sequence filename details end

router.post('/createNormMaster', handler(createNormMaster));
router.post('/getNormMaster', handler(getNormMaster));
router.post('/getNormById', handler(getNormById));
router.post('/deleteNormMaster', handler(deleteNormMaster));
router.post('/updateNorms', handler(updateNorms));
router.post('/checkJobNormCombination', handler(checkJobNormCombination));
router.post('/getNotificationsOptionList', handler(getNotificationsOptionList));
router.post('/getChecklistOptionList', handler(getChecklistOptionList));
router.post('/createCheckListMaster', handler(createCheckListMaster));
router.post('/getCheckListMaster', handler(getCheckListMaster));
router.post(
  '/getPrePopulateInstructionAnswers',
  handler(getPrePopulateInstructionAnswers),
);
router.post('/getPrePopulateInstruction', handler(getPrePopulateInstruction));
router.post('/updateCheckListMaster', handler(updateCheckListMaster));
router.post('/deleteCheckListMaster', handler(deleteCheckListMaster));
router.post('/checkSkillAvaliablity', handler(checkSkillAvaliablity));
router.post('/pkgUploadOpenKmToSftp', handler(pkgUploadOpenKmToSftp));
router.post('/invokeFtpFileUpload', handler(invokeFtpFileUpload));
router.post('/uploadCamsPackage', handler(uploadCamsPackage));
router.post('/pkgDepositTrigger', handler(pkgDepositTrigger));
router.post(
  '/fetchXmlReaderFromSftpWatcher',
  handler(fetchXmlReaderFromSftpWatcher),
);

export default router;
