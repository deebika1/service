import express from 'express';
import {
  getTotalPageNum,
  updatePgNumFromPginfo,
  readFileInfo,
} from '../../modules/fileDetails/index.js';
import { uploadFileCreateAndUpdate } from '../../modules/utils/okm/index.js';

import {
  fileUpload,
  fileDelete,
  fileDownload,
  localFileGetDownload,
  _downloadBlobFiles,
  getToolListPath,
} from '../../modules/utils/azure/index.js';

import { filesContainer } from '../../modules/filecontainer/index.js';

import {
  localfileUpload,
  localfileDownload,
} from '../../modules/utils/local/index.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();
router.post('/getPageCount', handler(getTotalPageNum));
router.post('/updatePgNumFromPginfo', handler(updatePgNumFromPginfo));
router.post('/uploadFileCreateAndUpdate', handler(uploadFileCreateAndUpdate));
router.post('/fileUpload', handler(fileUpload));
router.post('/fileDelete', handler(fileDelete));
router.post('/fileDownload', handler(fileDownload));
router.post('/localFileGetDownload', handler(localFileGetDownload));
router.post('/readFileInfo', handler(readFileInfo));
router.post('/filedonwloadLocal', handler(localfileDownload));
router.post('/filesContainer', handler(filesContainer));
router.post('/_downloadBlobFiles', handler(_downloadBlobFiles));
router.post('/getToolListPath', handler(getToolListPath));
// router.get('/getcount', getcount);
router.post('/localfileUpload', handler(localfileUpload));

export default router;
