import express from 'express';
import {
  getWorkflowLists,
  getAllStageList,
  getIncomingFlowList,
  getSequenceList,
  addWfdefEntries,
  getWfDefDetails,
  updateWfDefTable,
  deleteWfDefTable,
} from '../../modules/workflowList/wfl.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/getWorkflowLists', handler(getWorkflowLists));
router.post('/getAllStageList', handler(getAllStageList));
router.post('/getIncomingFlowList', handler(getIncomingFlowList));
router.post('/getSequenceList', handler(getSequenceList));
router.post('/addWfdefEntries', handler(addWfdefEntries));
router.post('/getWfDefDetails', handler(getWfDefDetails));
router.post('/updateWfDefTable', handler(updateWfDefTable));
router.post('/deleteWfDefTable', handler(deleteWfDefTable));

export default router;
