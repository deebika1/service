import express from 'express';
import {
  getWIPReport,
  getWIPReportTwo,
  getWIPDetailedReport,
  getProductivityReport,
  getReportOptionLists,
  getQualityReport,
  getQualityReportOptionLists,
  getMonitoringReport,
  getMonitoringReportOptionList,
  getWIPWorkorderReport,
  getWIPChapterReport,
  exportWOReport,
  insertWipStageNotes,
  activityTrackList,
  getdownloadmanuscript,
  getactivitystartend,
  getdownloadmanuscriptfile,
  getManuscriptStatus,
  getStageCreatedCount,
  getToolsMasterAccessRightsReport,
  getToolsMasterAccessRights,
  getToolsListServerPath,
  getUsersByCustomer,
  postToolsMasterAccessRights,
  addNewTool,
  getWipEngineActivityReport,
  getAuditReport,
  getCompletedWorkOrders,
  getFTPAuditReport,
  getFTPDownloadReportSpringer,
  getDownloadUploadManuscriptReport,
  getJobsheetHistoryforSpringer,
  getDespatchFailureReport,
  ftpjobretrigger,
  getFilepathforSpringer,
} from '../../modules/report/wip/index.js';
import {
  getJobSummaryReport,
  stageListForCustomer,
  activityListForStage,
  getUserList,
} from '../../modules/report/jobSummary/index.js';
import { graphicImageDelete } from '../../modules/report/graphicImageDelete/index.js';
import { toolsWIPReport } from '../../modules/report/toolsWIP/index.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();

router.post('/getWIPReport', handler(getWIPReport));
router.post('/getWIPReportTwo', handler(getWIPReportTwo));
router.post('/getStageCreatedCount', handler(getStageCreatedCount));
router.post('/getDespatchFailureReport', handler(getDespatchFailureReport));
router.post('/getWipEngineActivityReport', handler(getWipEngineActivityReport));
router.post('/getAuditReport', handler(getAuditReport));
router.post('/getCompletedWorkOrders', handler(getCompletedWorkOrders));
router.post('/getFTPAuditReport', handler(getFTPAuditReport));
router.post(
  '/getFTPDownloadReportSpringer',
  handler(getFTPDownloadReportSpringer),
);
router.post(
  '/getDownloadUploadManuscriptReport',
  handler(getDownloadUploadManuscriptReport),
);
router.post(
  '/getJobsheetHistoryforSpringer',
  handler(getJobsheetHistoryforSpringer),
);
router.post('/getFilepathforSpringer', handler(getFilepathforSpringer));
router.post(
  '/getToolsMasterAccessRightsReport',
  handler(getToolsMasterAccessRightsReport),
);
router.post('/getToolsMasterAccessRights', handler(getToolsMasterAccessRights));
router.post('/getToolsListServerPath', handler(getToolsListServerPath));
router.post('/getUsersByCustomer', handler(getUsersByCustomer));
router.post(
  '/postToolsMasterAccessRights',
  handler(postToolsMasterAccessRights),
);
router.post('/addNewTool', handler(addNewTool));
router.post('/getWIPDetailedReport', handler(getWIPDetailedReport));
router.post('/getProductivityReport', handler(getProductivityReport));
router.post('/getReportOptionLists', handler(getReportOptionLists));
router.post('/getQualityReport', handler(getQualityReport));
router.post(
  '/getQualityReportOptionLists',
  handler(getQualityReportOptionLists),
);
router.post('/getMonitoringReport', handler(getMonitoringReport));
router.post(
  '/getMonitoringReportOptionList',
  handler(getMonitoringReportOptionList),
);
router.post('/getWIPWorkorderReport', handler(getWIPWorkorderReport));
router.post('/getWIPChapterReport', handler(getWIPChapterReport));
router.post('/exportWOReport', handler(exportWOReport));
router.post('/insertWipStageNotes', handler(insertWipStageNotes));
router.post('/activityTrackList', handler(activityTrackList));
router.post('/getdownloadmanuscript', handler(getdownloadmanuscript));
router.post('/getdownloadmanuscriptfile', handler(getdownloadmanuscriptfile));
router.post('/getManuscriptStatus', handler(getManuscriptStatus));
router.post('/getactivitystartend', handler(getactivitystartend));
router.post('/ftpjobretrigger', handler(ftpjobretrigger));
router.post('/getJobSummaryReport', handler(getJobSummaryReport));
router.post('/stageListForCustomer', handler(stageListForCustomer));
router.post('/activityListForStage', handler(activityListForStage));
router.post('/getUserList', handler(getUserList));
router.post('/graphicImageDelete', handler(graphicImageDelete));
router.post('/toolsWIPReport', handler(toolsWIPReport));

export default router;
