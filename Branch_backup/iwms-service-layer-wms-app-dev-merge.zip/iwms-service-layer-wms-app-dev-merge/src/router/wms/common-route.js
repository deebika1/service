import express from 'express';
import {
  getDynamicColumns,
  emailAudit,
  triggerTrackItAPI,
} from '../../modules/common/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/getDynamicColumns', handler(getDynamicColumns));
router.post('/emailAudit', handler(emailAudit));
router.post('/triggerTrackItAPI', handler(triggerTrackItAPI));

// API for Camunda Performence Test
// router.post('/CamundaAPI',CamundaAPI)

export default router;
