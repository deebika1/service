import express from 'express';
import { getBaseURL } from '../../modules/mailReader/mailReader.js';
import {
  getOptionLists,
  getWOLists,
  WorkOrderCreation,
  retriggerAutoWorkorder,
  checkAvailability,
  getWoDetails,
  updateWoReport,
  getFilteredList,
  getStageListById,
  getWOServiceList,
  updateWoService,
  deleteWoService,
  readOrderDateFromEmail,
  getOverDueList,
  getExternalCustomerContacts,
  getStageOverdueCount,
  getBookComplete,
  getAdditionalInfo,
  getWOListById,
  getFilteredWorkorder,
  getWoStageActivityCompletedList,
  getWipActivityList,
  getWoDetailsForFTP,
} from '../../modules/woi/index.js';
import {
  saveChapter,
  getimcomingDetails,
  getIncomingData,
  updateChapter,
  deleteChapter,
  bookComplete,
  exportIncomingData,
  remainingChaptersCount,
  getTemplateListOptions,
  updateTemplateList,
  getSelectedTemplate,
  templateList,
  saveBookCompleted,
  getArticleIssueList,
  saveAssignedArticle,
  getAssignedArticleList,
  deleteAssignedArticle,
  copyArticleToIssue,
  getArticleStatus,
  getEnableListener,
  updateCamundaDetails,
  getWOSourceFileDetails,
  autoIncomingForIssue,
  autoIncomingForSpringer,
  autoIncomingForWKHJournals,
  insertWOSourceFileDetails,
  autoIncomingForACSJournals,
  autoIncomingForSpringerIssue,
} from '../../modules/woi/incoming.js';
import { _getFormattedName } from '../../modules/utils/fileValidation/utils.js';
import {
  insert_acs_mst_notificationdetails,
  getDownloadList_ACS,
  updateACSmetainfo,
  insert_ack_notificationdetails,
  getGraphicsList_ACS,
} from '../../modules/woi/acs.js';

import {
  getPreviousChapterPath,
  getWOStageChapters,
  getWOStageLists,
  triggerWOStageWf,
  triggerNextStagewf,
  triggerNextStagewfguid,
  triggerMultipleInstance,
  updateWoStage,
  getStageHistory,
  checkMultiInstance,
  addFileButtonValidation,
  getEventlog,
  getProcessInstance,
  getWOStageFiles,
  getWfTargetStageList,
  targeStageInfo,
} from '../../modules/woi/stage.js';

import {
  getGraphicLists,
  graphicArt,
  getGraphicAuditLists,
  addFileGraphicImage,
  fileNameUpdate,
} from '../../modules/woi/graphicArt.js';
import {
  getAdditionalOptionList,
  createAdditionalInfoList,
  updateAdditionalInfoList,
  updateBookDetailsForActivites,
  getIncomingDetailsIdList,
  BookDetailsTextForActivites,
  getWorkflowName,
} from '../../modules/woi/additionalInfo.js';
import {
  woInstructions,
  woInstructionsFiles,
  getWOI,
  edittWOI,
  deleteWOI,
  getStageList,
  triggerMessage,
} from '../../modules/woi/woInstructions.js';
import {
  getQueryBuilderOptions,
  queryInsertion,
  queryFile,
  getQueryList,
  getQueryHistory,
  postReply,
  getQueryListforDespatch,
  getLastActivityForQueryCheck,
} from '../../modules/woi/query.js';
import {
  woJobNormsMapping,
  getWOJobNormsMappedList,
  deleteWOJobnormsMap,
  getJobNormOptionList,
} from '../../modules/woi/jobNorms.js';
import {
  getWorksheetId,
  getLastFileName,
  getProofingType,
  getTrnImages,
  updateImagepathtrn,
  deleteImagepathtrn,
  graphicsImageActions,
  deleteGraphicToolImagepath,
  toolsUploadActions,
} from '../../modules/iTracks/index.js';
import {
  readWorkorderInfo,
  getWKjournals,
  getWKjournalsByFTPName,
  UpdateManuscriptzipname,
  getStageIterationCount,
  TestSendEmail,
  getWorkorderxmlData,
  insertUploadPathUid,
  getAutoemailLogdetails,
  checkFtpWatcherIdleNotification,
} from '../../modules/woi/woAutocreation.js';

import { killActiveInstance } from '../../modules/utils/wfTrigger/index.js';
import {
  insert_ftpdownloadstatus_springerbook,
  getspringerbookftpdownloaddetail,
  getftpdownloadwithfilename,
  getAllftpdownloaddata,
  springerMailForAutoCreate,
  getdownloadedfile,
  getEproofDetails,
  insertsuccesswatcherdetail,
  insert_eproof_logDetails_for_springerBooks,
  insert_eproof_outDetails_for_springerBooks,
  getWorkOrderDetailsInfoForSpringer,
  geteProof_log_xml_details,
  insertMailDetails,
  // sendMailtoeProof,
  eProofMsgUpdate,
} from '../../modules/woi/srpingerRepository.js';

import {
  sendMail,
  updateContentCheckerLogDetails,
  checkArticleOASISWorkflow,
  executeQuerySpringer,
  getCommonPathForSpringer,
  insert_eProof_ZipDetails,
  geteProofDownloadList_Springer,
  geteProofLogJobList,
  iceNotification,
  updateDispatchDetails,
  updateeProoffilestatus,
  checkSuccessLogForPreviousUploaded,
  getDispatchDetails,
  updateRetryCountInDatabase,
  getXMLTagConfigDetails,
  tableJobDetailsUpdate,
  tablePackageUpdate,
  updateLogUploadStatus,
  getLogJobList,
  updatefileuploadstatus,
  getFileUploadList_Springer,
  insert_InIOzipfilesInUpload,
  getIncommingJobList,
  updateDownloadFileStatus,
  insert_ftpFileWatcherStatus_springer,
  getConnectionParameter_Springer,
  getDownloadList_Springer,
  insertDuplicateID,
  intiatefiledownloadupdate,
} from '../../modules/woi/springerJournal.js';

import { createBookInfo } from '../../modules/woi/woBookAutocreation.js';
// import { getJournalList } from '../../modules/master/index.js';
import {
  workorderCreationFromE2EAPI,
  autoIssueWorkorderCreation,
} from '../../modules/woi/autoWorkorderCreationContainer.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };

// acs start
router.post(
  '/insert_acs_mst_notificationdetails',
  handler(insert_acs_mst_notificationdetails),
);
router.post('/getDownloadList_ACS', handler(getDownloadList_ACS));
router.post('/update_acs_metainfo', handler(updateACSmetainfo));
router.post(
  '/insert_ack_notification',
  handler(insert_ack_notificationdetails),
);
router.post('/getGraphicsList_ACS', handler(getGraphicsList_ACS));

// acs end

router.post('/woInstructions', handler(woInstructions));
router.post('/triggerMessage', handler(triggerMessage));
router.post('/woInstructionFiles', handler(woInstructionsFiles));
router.post('/getWOLists', handler(getWOLists));
router.post('/getWOListById', handler(getWOListById));
router.post('/getFilteredWorkorder', handler(getFilteredWorkorder));

router.post('/getWorkorderxmlData', handler(getWorkorderxmlData));
router.post('/readWorkorderInfo', handler(readWorkorderInfo));
router.post('/getWKjournals', handler(getWKjournals));
router.post('/getWKjournalsByFTPName', handler(getWKjournalsByFTPName));
router.post('/UpdateManuscriptzipname', handler(UpdateManuscriptzipname));
router.post('/getStageIterationCount', handler(getStageIterationCount));
router.post('/createBookInfo', handler(createBookInfo));

router.post('/TestSendEmail', handler(TestSendEmail));
router.post('/getBaseURL', handler(getBaseURL));
router.post('/insertUploadPathUid', handler(insertUploadPathUid));

router.post('/getWOI', handler(getWOI));
router.post('/deleteWOI', handler(deleteWOI));
router.post('/getStageList', handler(getStageList));
router.post('/editwoi', handler(edittWOI));
router.post('/getFilteredWoiList', handler(getFilteredList));
router.post('/getWOServiceList', handler(getWOServiceList));
router.post('/getOverDueList', handler(getOverDueList));
router.post('/getStageOverdueCount', handler(getStageOverdueCount));
router.post('/getBookComplete', handler(getBookComplete));
router.post('/getAdditionalInfo', handler(getAdditionalInfo));

router.post('/getOptionLists', handler(getOptionLists));
router.post('/getStageListById', handler(getStageListById));

// router.get('/getCustomerLists', getCustomerLists);
// router.post('/getDivisonList', getDivisonList);
// router.post('/getSubDivisonList', getSubDivisonList);
// router.post('/getLocationList', getLocationList);
// router.post('/getCustomerContactList', getCustomerContactList);

router.post('/create', handler(WorkOrderCreation));
router.post('/getWOStageLists', handler(getWOStageLists));
router.post('/getWOStageChapters', handler(getWOStageChapters));
router.post('/getWOStageFiles', handler(getWOStageFiles));
router.post('/getWoDetails', handler(getWoDetails));
router.post('/checkAvailability', handler(checkAvailability));
router.post('/saveChapter', handler(saveChapter));
router.post('/getimcomingDetails', handler(getimcomingDetails));
router.post('/getIncomingData', handler(getIncomingData));
router.post('/updateChapter', handler(updateChapter));
router.post('/deleteChapter', handler(deleteChapter));
router.post('/bookComplete', handler(bookComplete));
router.get('/exportIncomingData/:id', handler(exportIncomingData));
router.post('/updateWoReport', handler(updateWoReport));
router.post('/updateWoStage', handler(updateWoStage));
router.post('/updateWoService', handler(updateWoService));
router.post('/deleteWoService', handler(deleteWoService));
router.post('/getPreviousChapterPath', handler(getPreviousChapterPath));
router.post('/triggerWOStageWf', handler(triggerWOStageWf));
router.post('/triggerNextStagewf', handler(triggerNextStagewf));
router.post('/triggerNextStagewfguid', handler(triggerNextStagewfguid));
router.post('/triggerMultipleInstance', handler(triggerMultipleInstance));
router.post('/readOrderDateFromEmail', handler(readOrderDateFromEmail));
router.post('/graphicArt', handler(graphicArt));
router.post('/getGraphicLists', handler(getGraphicLists));
router.post('/getGraphicAuditLists', handler(getGraphicAuditLists));
router.post('/getStageHistory', handler(getStageHistory));
router.post('/checkMultiInstance', handler(checkMultiInstance));
router.post('/addFileButtonValidation', handler(addFileButtonValidation));
router.post('/getEventlog', handler(getEventlog));
router.post('/getProcessInstance', handler(getProcessInstance));
router.post('/remainingChaptersCount', handler(remainingChaptersCount));
router.post('/getTemplateListOptions', handler(getTemplateListOptions));
router.post('/updateTemplateList', handler(updateTemplateList));
router.post('/getSelectedTemplate', handler(getSelectedTemplate));
router.post('/templateList', handler(templateList));
router.post(
  '/getExternalCustomerContacts',
  handler(getExternalCustomerContacts),
);
router.post('/autoIncomingForIssue', autoIncomingForIssue);

router.post('/saveBookCompleted', handler(saveBookCompleted));
router.post('/getArticleIssueList', handler(getArticleIssueList));
router.post('/saveAssignedArticle', handler(saveAssignedArticle));
router.post('/getAssignedArticleList', handler(getAssignedArticleList));
router.post('/deleteAssignedArticle', handler(deleteAssignedArticle));
router.post('/copyArticleToIssue', handler(copyArticleToIssue));
router.post('/getArticleStatus', handler(getArticleStatus));
router.post('/getEnableListener', handler(getEnableListener));
router.post('/updateCamundaDetails', handler(updateCamundaDetails));
router.post('/targeStageInfo', handler(targeStageInfo));
router.post('/autoIncomingForSpringer', autoIncomingForSpringer);
router.post('/autoIncomingForWKHJournals', autoIncomingForWKHJournals);
router.post('/autoIncomingForACSJournals', autoIncomingForACSJournals);
router.post('/autoIncomingForSpringerIssue', autoIncomingForSpringerIssue);

router.post('/getQueryBuilderOptions', handler(getQueryBuilderOptions));
router.post('/queryInsertion', handler(queryInsertion));
router.post('/queryFile', handler(queryFile));
router.post('/getQueryList', handler(getQueryList));
router.post('/getQueryHistory', handler(getQueryHistory));
router.post('/postReply', handler(postReply));
router.post('/getQueryListforDespatch', handler(getQueryListforDespatch));
router.post(
  '/getLastActivityForQueryCheck',
  handler(getLastActivityForQueryCheck),
);

router.post('/woJobNormsMapping', handler(woJobNormsMapping));
router.post('/getWOJobNormsMappedList', handler(getWOJobNormsMappedList));
router.post('/deleteWOJobnormsMap', handler(deleteWOJobnormsMap));
router.post('/getJobNormOptionList', handler(getJobNormOptionList));

router.post('/getAdditionalOptionList', handler(getAdditionalOptionList));
router.post('/createAdditionalInfoList', handler(createAdditionalInfoList));
router.post('/updateAdditionalInfoList', handler(updateAdditionalInfoList));
router.post('/getWorksheetId', handler(getWorksheetId));
router.post('/getProofingType', handler(getProofingType));
router.post('/getTrnImages', handler(getTrnImages));
router.post('/updateImagepathtrn', handler(updateImagepathtrn));
router.post('/deleteImagepathtrn', handler(deleteImagepathtrn));
router.post('/graphicsImageActions', handler(graphicsImageActions));
router.post('/toolsUploadActions', handler(toolsUploadActions));
router.post('/deleteGraphicToolImagepath', handler(deleteGraphicToolImagepath));
router.post('/getFormattedName', handler(_getFormattedName));
router.post(
  '/updateBookDetailsForActivites',
  handler(updateBookDetailsForActivites),
);
router.post(
  '/BookDetailsTextForActivites',
  handler(BookDetailsTextForActivites),
);
router.post('/getIncomingDetailsIdList', handler(getIncomingDetailsIdList));
router.post('/getLastFileName', handler(getLastFileName));
router.post(
  '/getWoStageActivityCompletedList',
  handler(getWoStageActivityCompletedList),
);
router.post('/getWorkflowName', handler(getWorkflowName));
router.post('/getWipActivityList', handler(getWipActivityList));
router.post('/getWOSourceFileDetails', handler(getWOSourceFileDetails));
router.post('/addFileGraphicImage', handler(addFileGraphicImage));
router.post('/fileNameUpdate', handler(fileNameUpdate));
router.post('/insertWOSourceFileDetails', handler(insertWOSourceFileDetails));

router.post('/getWfTargetStageList', handler(getWfTargetStageList));

// for camunda performence test
router.post('/triggerWOStageWf', handler(triggerWOStageWf));

router.post('/killActiveInstance', handler(killActiveInstance));

router.get('/getAutoemailLogdetails', handler(getAutoemailLogdetails));
router.get('/retriggerAutoWorkorder', handler(retriggerAutoWorkorder));
router.post(
  '/insertftpdownloadstatusspringerbook',
  handler(insert_ftpdownloadstatus_springerbook),
);
router.get(
  '/getspringerbookftpdownloaddetail',
  handler(getspringerbookftpdownloaddetail),
);
router.get('/getftpdownloadwithfilename', handler(getftpdownloadwithfilename));
router.get('/getAllftpdownloaddata', handler(getAllftpdownloaddata));
router.post('/springerMailForAutoCreate', handler(springerMailForAutoCreate));
router.get('/springergetdownloadedfile', handler(getdownloadedfile));
router.post('/insertsuccesswatcherdetail', handler(insertsuccesswatcherdetail));
router.post(
  '/inserteprooflogDetailsforspringerBooks',
  handler(insert_eproof_logDetails_for_springerBooks),
);
router.post(
  '/inserteproofOutDetailsforspringerBooks',
  handler(insert_eproof_outDetails_for_springerBooks),
);
router.post(
  '/getWorkOrderDetailsInfoForSpringer',
  handler(getWorkOrderDetailsInfoForSpringer),
);
router.get('/getEproofDetails', handler(getEproofDetails));
router.post('/eProofMsgUpdate', handler(eProofMsgUpdate));
router.post('/geteProof_log_xml_details', handler(geteProof_log_xml_details));
router.post('/insertMailDetails', handler(insertMailDetails));
// router.post('/sendMailtoeProof',handler(sendMailtoeProof));

// springer
router.post(
  '/insertftpdownloadstatusspringer',
  handler(insert_ftpFileWatcherStatus_springer),
);
router.get(
  '/getConnectionParameter_Springer',
  handler(getConnectionParameter_Springer),
);

router.get('/getDownloadList_Springer', handler(getDownloadList_Springer));
router.get(
  '/geteProofDownloadList_Springer',
  handler(geteProofDownloadList_Springer),
);
router.get('/getlogJobList_Springer', handler(getLogJobList));
router.get('/geteProofLogJobList', handler(geteProofLogJobList));
router.post('/insertDuplicateID', handler(insertDuplicateID));
router.post('/intiatefiledownloadupdate', handler(intiatefiledownloadupdate));
router.post('/updateDownloadFileStatus', handler(updateDownloadFileStatus));
router.post('/updatefileuploadstatus', handler(updatefileuploadstatus));
router.post('/updateLogUploadStatus', handler(updateLogUploadStatus));
router.post('/updateeProoffilestatus', handler(updateeProoffilestatus));
router.get('/getIncommingJobList', handler(getIncommingJobList));
router.get('/getFileUploadList_Springer', handler(getFileUploadList_Springer));
router.get('/getXMLTagConfigDetails', handler(getXMLTagConfigDetails));
router.get('/getDispatchDetails', handler(getDispatchDetails));
router.get(
  '/checkSuccessLogForPreviousUploaded',
  handler(checkSuccessLogForPreviousUploaded),
);
router.post('/tablePackageUpdate', handler(tablePackageUpdate));
router.post('/tableJobDetailsUpdate', handler(tableJobDetailsUpdate));
router.post('/updateRetryCountInDatabase', handler(updateRetryCountInDatabase));
router.post('/updateDispatchDetails', handler(updateDispatchDetails));
router.post('/iceNotification', handler(iceNotification));
router.post('/sendMail', handler(sendMail));
router.post(
  '/insert_InIOzipfilesInUpload',
  handler(insert_InIOzipfilesInUpload),
);
router.post('/insert_eProof_ZipDetails', handler(insert_eProof_ZipDetails));
router.post('/getWoDetailsForFTP', handler(getWoDetailsForFTP));
router.post('/executeQuerySpringer', handler(executeQuerySpringer));
router.get('/getCommonPathForSpringer', handler(getCommonPathForSpringer));
router.get('/checkArticleOASISWorkflow', handler(checkArticleOASISWorkflow));
router.post(
  '/updateContentCheckerLogDetails',
  handler(updateContentCheckerLogDetails),
);

// router for WK-KLI
router.post(
  '/workorderCreationFromE2EAPI',
  handler(workorderCreationFromE2EAPI),
);
router.post('/autoIssueWorkorderCreation', handler(autoIssueWorkorderCreation));
router.post(
  '/checkFtpWatcherIdleNotification',
  handler(checkFtpWatcherIdleNotification),
);

export default router;
