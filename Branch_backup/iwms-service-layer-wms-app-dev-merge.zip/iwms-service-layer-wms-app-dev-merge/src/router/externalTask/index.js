import express from 'express';
import {
  updateDb,
  updateExternalTaskData,
  getExternalTaskConfig,
  updateEventDetails,
  getEventFileDeatils,
} from '../../modules/externalTask/index.js';
import {
  fetchTaskId,
  lockTask,
  completeTask,
} from '../../modules/externalTask/task.js';
import {
  getIOFilesData,
  getIOFilesTrnData,
} from '../../modules/externalTask/tools/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/updateDb', handler(updateDb));
router.post('/getExternalTaskConfig', handler(getExternalTaskConfig));
router.post('/updateEventDetails', handler(updateEventDetails));
router.post('/getEventFileDeatils', handler(getEventFileDeatils));
router.post('/updateExternalTaskData', handler(updateExternalTaskData));

router.post('/fetchTaskId', handler(fetchTaskId));
router.post('/lockTask', handler(lockTask));
router.post('/completeTask', handler(completeTask));

router.post('/tools/getIOFilesData', handler(getIOFilesData));
router.post('/tools/getIOFilesTrnData', handler(getIOFilesTrnData));

export default router;
