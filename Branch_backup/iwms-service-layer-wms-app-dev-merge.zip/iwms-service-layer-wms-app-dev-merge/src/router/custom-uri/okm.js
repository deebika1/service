import express from 'express';
import { updateStatus } from '../../modules/custom-uri/okm.js';

import {
  getFileDetails,
  getToolDetail,
  updateFileTRNLog,
  updateNewFileName,
  updateNewFileNameFromTools,
  getFileSequence,
} from '../../modules/custom-uri/utils.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/okm/updateStatus', handler(updateStatus));
router.post('/getToolDetail', handler(getToolDetail));
router.post('/getFileDetails', handler(getFileDetails));
router.post('/updateFileTRNLog', handler(updateFileTRNLog));
router.post('/updateNewFileName', handler(updateNewFileName));
router.post('/updateNewFileNameFromTools', handler(updateNewFileNameFromTools));
router.post('/getFileSequence', handler(getFileSequence));

export default router;
