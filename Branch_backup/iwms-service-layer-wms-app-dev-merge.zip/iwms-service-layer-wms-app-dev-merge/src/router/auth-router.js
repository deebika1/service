import express from 'express';
import {
  checkAuthStatus,
  authenticate,
  signOut,
  setuserDefaultDU,
} from '../auth/web/authentication.js';
import {
  getScreensInfo,
  getScreenInfo,
  getAdminUser,
  getElectronVersionDetails,
} from '../auth/web/authorization.js';
import { getAuthToken } from '../auth/service/authentication.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();

router.get('/status', handler(checkAuthStatus));
router.post('/authenticate', handler(authenticate));
router.post('/setuserdu', handler(setuserDefaultDU));
router.post('/signout', handler(signOut));
router.post('/authorization/getScreensInfo', handler(getScreensInfo));
router.post('/authorization/getScreenInfo', handler(getScreenInfo));
router.get('/get/token', handler(getAuthToken));
router.get('/get/adminuser', handler(getAdminUser));
router.get(
  '/get/getElectronVersionDetails',
  handler(getElectronVersionDetails),
);

export default router;
