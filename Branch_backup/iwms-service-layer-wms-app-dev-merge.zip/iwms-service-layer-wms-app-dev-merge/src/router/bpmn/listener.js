import express from 'express';
import {
  getLatestActivityDetails,
  getWfDetails,
  getFileMovementConfig,
  getLatestWorkedActivityDetails,
  getWoEventLogDetails,
  createDb,
  entrytofileTrnDetails,
  updateDb,
  updateDbError,
  updateDbRemark,
  updateAsUnassigned,
  getIncomingFileDetails,
  getPreviousEventLogDetail,
  getBookDetails,
  getFileSeqDetails,
  getBookDetailsForCupJournals,
  externalTaskPayload,
  resetFileDetails,
  getStageInfoFromCamunda,
  updateStageInfoToCamunda,
  updateStageInfoForSequence,
  blobStorageDetails,
  getFileNameForPii,
} from '../../modules/bpmn/listener/create.js';
import { getIoppJournalDetails } from '../../modules/utils/custom/ioppjournaldetails.js';

const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
const router = express.Router();

router.post('/getLatestActivityDetails', handler(getLatestActivityDetails));
router.post(
  '/getLatestWorkedActivityDetails',
  handler(getLatestWorkedActivityDetails),
);
router.post('/getWfDetails', handler(getWfDetails));
router.post('/getWoEventLogDetails', handler(getWoEventLogDetails));
router.post('/getPreviousEventLogDetail', handler(getPreviousEventLogDetail));
router.post('/getFileMovementConfig', handler(getFileMovementConfig));
router.post('/getIncomingFileDetails', handler(getIncomingFileDetails));
router.post('/createDb', handler(createDb));
router.post('/entrytofileTrnDetails', handler(entrytofileTrnDetails));
router.post('/updateDb', handler(updateDb));
router.post('/updateAsUnassigned', handler(updateAsUnassigned));
router.post('/updateDbError', handler(updateDbError));
router.post('/updateDbRemark', handler(updateDbRemark));
router.post('/getBookDetails', handler(getBookDetails));
router.post('/getJournalDetails', handler(getIoppJournalDetails));
router.post('/getFileSeqDetails', handler(getFileSeqDetails));
router.post(
  '/getBookDetailsForCupJournals',
  handler(getBookDetailsForCupJournals),
);
router.post('/externalTaskPayload', handler(externalTaskPayload));
router.post('/resetFileDetails', handler(resetFileDetails));
router.post('/getStageInfoFromCamunda', handler(getStageInfoFromCamunda));
router.post('/updateStageInfoToCamunda', handler(updateStageInfoToCamunda));
router.post('/updateStageInfoForSequence', handler(updateStageInfoForSequence));
router.post('/blobStorageDetails', handler(blobStorageDetails));
router.post('/externalTaskPayload', handler(externalTaskPayload));
router.post('/getFileNameForPii', handler(getFileNameForPii));

export default router;
