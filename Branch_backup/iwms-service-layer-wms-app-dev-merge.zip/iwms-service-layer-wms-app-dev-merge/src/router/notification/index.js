import express from 'express';
import {
  getNotificationOptions,
  createNotificationSender,
  getNotificationSenderList,
  deleteNotificationSenderMap,
  updateNotificationSender,
  createNotification,
  getNotificationList,
  getNotificationDetailList,
  updateNotification,
  deleteNotification,
} from '../../modules/notification/index.js';

const router = express.Router();
const handler = cb =>
  function (request, response, next) {
    Promise.resolve(cb(request, response, next)).catch(error => next(error));
  };
router.post('/getNotificationOptions', handler(getNotificationOptions));
router.post('/createNotificationSender', handler(createNotificationSender));
router.post('/getNotificationSenderList', handler(getNotificationSenderList));
router.post(
  '/deleteNotificationSenderMap',
  handler(deleteNotificationSenderMap),
);
router.post('/updateNotificationSender', handler(updateNotificationSender));
router.post('/createNotification', handler(createNotification));
router.post('/getNotificationList', handler(getNotificationList));
router.post('/getNotificationDetailList', handler(getNotificationDetailList));
router.post('/updateNotification', handler(updateNotification));
router.post('/deleteNotification', handler(deleteNotification));

export default router;
