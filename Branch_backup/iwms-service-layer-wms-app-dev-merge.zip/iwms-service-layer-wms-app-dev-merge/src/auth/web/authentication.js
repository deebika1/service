import jwt from 'jsonwebtoken';
import ActiveDirectory from 'activedirectory';
import {
  getInfo,
  validateSuperUsr,
  getuserDU,
  setuserDU,
} from './authorization.js';
// import { Service } from '../../httpClient/index.js';
import logger from '../../modules/utils/logs/index.js';

// const service = new Service();
const ad = new ActiveDirectory({
  url: process.env.LDAP_URL,
  baseDN: process.env.LDAP_BASEDN,
});

export const setuserDefaultDU = async (req, res) => {
  try {
    const usr = req.body.username.toUpperCase();
    const { duID } = req.body;
    await setuserDU(usr, duID);
    res.status(200).send(true);
  } catch (error) {
    res.status(403).send(false);
    logger.info(error);
  }
};

export const authenticate = async (req, res) => {
  const usr = req.body.username.toUpperCase();
  const pwd = req.body.password;
  const bufusr = `${usr}@${process.env.LDAP_UID_DOMAIN}`;

  try {
    const SuperUserChkResp = await validateSuperUsr(usr);
    if (SuperUserChkResp.validStatus && pwd === usr + process.env.DEFAULT_PD) {
      logger.info('out', usr + process.env.DEFAULT_PD);
      const accessToken = jwt.sign(
        { user: usr },
        process.env.OAUTH_TOKEN_SECRET,
        {},
      );
      setProfileDetails(accessToken, req, res);
    } else if (
      SuperUserChkResp.validStatus &&
      pwd != usr + process.env.DEFAULT_PD
    ) {
      ad.authenticate(bufusr, pwd, function (err, auth) {
        logger.info(auth, 'auth');
        if (auth) {
          logger.info('in');
          const accessToken = jwt.sign(
            { user: usr },
            process.env.OAUTH_TOKEN_SECRET,
            {},
          );
          setProfileDetails(accessToken, req, res);
        } else {
          res.status(200).send(false);
        }
      });
    } else {
      res.status(200).send(false);
    }
    // console.log(SuperUserChkResp, 'SuperUserChkResp');
    // const accessToken = jwt.sign({ user: usr }, process.env.OAUTH_TOKEN_SECRET, {});
    // setProfileDetails(accessToken, req, res);
  } catch (e) {
    res.status(200).send(false);
    logger.info(e, 'auth error');
  }
};

export const setProfileDetails = async (accessToken, req, res) => {
  logger.info(accessToken, 'accessTokenaccessToken');

  try {
    const profileDetails = await getProfileDetails(accessToken, req);
    const DUDetails = await getuserDU(req.body.username.toUpperCase());
    req.session.wat = accessToken;
    req.session.wp = JSON.stringify({
      roles: profileDetails.profile.roles.id,
      skills: profileDetails.profile.skills.id,
    });
    if (req.body.inDesktopEnv == 'true')
      res.status(200).send({
        id: req.session.id,
        wp: req.session.wp,
        wat: req.session.wat,
        DUDetails,
      });
    else res.status(200).send({ DUDetails });
  } catch (e) {
    res.status(403).send(false);
    logger.info(e);
  }
};
export const checkAuthStatus = async (req, res) => {
  try {
    const status = await getAuthStatus(req);
    res.send(status);
  } catch (e) {
    res.status(e.type == 'InternalServerError' ? 500 : 401).send(e);
  }
};

export const getAuthStatus = req => {
  return new Promise(async (resolve, reject) => {
    // req.session.reload();
    if (req.headers.wat) {
      req.session.wat = req.headers.wat;
      req.session.wp = req.headers.wp;
    }
    if (req.session.wat) {
      try {
        const existingProfileDetails = req.session.wp
          ? JSON.parse(req.session.wp)
          : { roles: [], skills: [] };
        const profileDetails = await getProfileDetails(req.session.wat, req);
        const currentProfileDetails = {
          roles: profileDetails.profile.roles.id,
          skills: profileDetails.profile.skills.id,
        };
        const isValidProfile = isValidRoleSkill(
          existingProfileDetails,
          currentProfileDetails,
        );
        if (!isValidProfile)
          // eslint-disable-next-line no-throw-literal
          throw {
            type: 'InvalidProfile',
            message: 'User Profile has changed',
            existingProfileDetails,
            currentProfileDetails,
          };
        resolve(profileDetails);
      } catch (e) {
        reject(e);
      }
    } else {
      resolve({
        type: 'NewSession',
        message: 'New Session',
      });
    }
  });
};

const arraysEqual = (arr1, arr2) => {
  const set1 = new Set(arr2);

  return (
    arr1.length === arr2.length && arr1.every(element => set1.has(element))
  );
};

const isValidRoleSkill = (existingProfileDetails, currentProfileDetails) => {
  const isValidRole = arraysEqual(
    existingProfileDetails.roles,
    currentProfileDetails.roles,
  );

  const isValidSkill = arraysEqual(
    existingProfileDetails.skills,
    currentProfileDetails.skills,
  );

  return isValidRole && isValidSkill;
};

const validateJwtToken = accessToken => {
  return new Promise(async (resolve, reject) => {
    try {
      const sub = jwt.verify(accessToken, process.env.OAUTH_TOKEN_SECRET);
      logger.info('--- Auth Validation Success (API) ---');
      resolve(sub);
    } catch (e) {
      const message =
        e.name == 'JsonWebTokenError'
          ? 'Access token is Invalid'
          : e.name == 'TokenExpiredError'
          ? 'Access token is expired'
          : e.message
          ? e.message
          : e;
      const type =
        e.name == 'JsonWebTokenError'
          ? 'InvalidToken'
          : e.name == 'TokenExpiredError'
          ? 'ExpiredToken'
          : 'InternalServerError';
      reject({ type, message });
    }
  });
};

// const validateIamToken = (accessToken) => {
//     return new Promise(async (resolve, reject) => {
//         try {
//             const headers = {
//                 'Authorization': `Bearer ${accessToken}`
//             };
//             try {
//                 const response = await service.get(`${authConfig.base_url}${authConfig.uri.user_info}`, {}, headers);
//                 const { sub } = response.data;
//                 resolve(sub.toUpperCase());
//             } catch (err) {
//                 reject({
//                     type: 'InvalidToken',
//                     message: 'Access token is Invalid'
//                 });
//             }
//         } catch (e) {
//             reject({
//                 type: 'InternalServerError',
//                 message: e.message ? e.message : e
//             });
//         }
//     });
// }

const getProfileDetails = (accessToken, req) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { user: sub } = await validateJwtToken(accessToken);
      try {
        const profile = await getInfo(sub);
        resolve({
          isLoggedIn: true,
          profile,
          sessionId: req.session.id,
        });
      } catch (e) {
        reject({
          type:
            e.type == 'UserNotExist' ? 'UserNotExist' : 'InternalServerError',
          message: e.message ? e.message : e,
        });
      }
    } catch (e) {
      if (e.type) {
        if (e.type == 'InvalidToken') {
          logger.info('token is expired');
          try {
            reject('Referesh token faild');
            // to be removed
            // const profileDetails = await updateRefreshToken(req);
            // resolve(profileDetails);
          } catch (err) {
            reject(err);
          }
        } else {
          reject(e);
        }
      } else {
        reject({
          type: 'InternalServerError',
          message: e.message ? e.message : e,
        });
      }
    }
  });
};

// const updateRefreshToken = req => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const authCred = Buffer.from(
//         `${process.env.OAUTH_CLIENT_ID}:${process.env.OAUTH_CLIENT_SECRET}`,
//       ).toString('base64');
//       const data = querystring.stringify({
//         grant_type: 'refresh_token',
//         refresh_token: req.session.wrt,
//       });
//       const headers = {
//         Authorization: `Basic ${authCred}`,
//         'Content-Type': 'application/x-www-form-urlencoded',
//       };
//       try {
//         const response = await service.post(
//           `${authConfig.base_url}${authConfig.uri.token}`,
//           data,
//           headers,
//         );
//         req.session.wat = response.data.access_token;
//         req.session.wrt = response.data.refresh_token;
//         req.session.wit = response.data.id_token;
//         const profileDetails = await getProfileDetails(req.session.wat, req);
//         req.session.wp = JSON.stringify({
//           roles: profileDetails.profile.roles.id,
//           skills: profileDetails.profile.skills.id,
//         });
//         logger.info('updated access token');
//         resolve(profileDetails);
//       } catch (err) {
//         logger.info(err);
//         reject({
//           type: 'InvalidToken',
//           message: 'Access token is Invalid',
//         });
//       }
//     } catch (e) {
//       reject({
//         type: 'InternalServerError',
//         message: e.message ? e.message : e,
//       });
//     }
//   });
// };

export const signOut = async (req, res) => {
  req.session.destroy(() => {
    res.send(true);
  });
};
