import jwt from 'jsonwebtoken';
import { userList, whiteListedAPI } from './config.js';
import { getAuthStatus } from '../web/authentication.js';
import logger from '../../modules/utils/logs/index.js';

export const authenticate = async (req, res, next) => {
  const { path } = req;
  if (!isWhiteListedAPI(path)) {
    if (req.headers['iwms-web-app']) {
      await verifyWebTokenStatus(req, res, next);
    } else {
      verifyAuthToken(req, res, next);
    }
  } else {
    next();
  }
};

export const getAuthToken = (req, res) => {
  const { authorization } = req.headers;
  if (authorization) {
    // eslint-disable-next-line new-cap
    const [username, password] = new Buffer.from(
      authorization.split(' ')[1],
      'base64',
    )
      .toString()
      .split(':');
    const userDetail = userList.find(
      user => user.name == username && user.password == password,
    );
    if (userDetail) {
      try {
        const option = userDetail.isSuperUser ? {} : { expiresIn: 3600 };
        const accessToken = jwt.sign(
          { user: userDetail.name },
          process.env.OAUTH_TOKEN_SECRET,
          option,
        );
        res.status(200).send({ accessToken });
      } catch (e) {
        const message = e.message ? e.message : e;
        logger.info(message, 'getAuthToken');
        res.status(500).send({ type: 'InternalServerError', message });
      }
    } else {
      res.status(401).send({
        type: 'Unauthorized',
        message: 'Authentication failed. Please check username and password',
      });
    }
  } else {
    res
      .status(401)
      .send({ type: 'Unauthorized', message: 'Basic Auth is missing' });
  }
};

export const verifyAuthToken = (req, res, next) => {
  const { authorization } = req.headers;
  logger.info('--- Auth Validation Starts (API) ---');
  if (authorization) {
    try {
      const accessToken = authorization.split(' ')[1];
      jwt.verify(accessToken, process.env.OAUTH_TOKEN_SECRET);
      logger.info('--- Auth Validation Success (API) ---');
      next();
    } catch (e) {
      const message =
        e.name == 'JsonWebTokenError'
          ? 'Access token is Invalid'
          : e.name == 'TokenExpiredError'
          ? 'Access token is expired'
          : e.message
          ? e.message
          : e;
      const type =
        e.name == 'JsonWebTokenError'
          ? 'InvalidToken'
          : e.name == 'TokenExpiredError'
          ? 'ExpiredToken'
          : 'InternalServerError';
      logger.info(message, 'verifyAuthToken');
      logger.info('--- Auth Validation Failed (API) ---');
      res
        .status(type == 'InternalServerError' ? 500 : 401)
        .send({ type, message });
    }
  } else {
    logger.info('--- Auth Validation Failed (API) ---');
    res
      .status(401)
      .send({ type: 'Unauthorized', message: 'Bearer Token is missing' });
  }
};

const verifyWebTokenStatus = async (req, res, next) => {
  try {
    logger.info('--- Auth Validation Starts (web) ---');
    const status = await getAuthStatus(req);
    logger.info('--- Auth Validation Success (web) ---');
    if (status.type == 'NewSession') {
      res.status(200).send(status);
    } else {
      next();
    }
  } catch (e) {
    logger.info(e);
    logger.info('--- Auth Validation Failed (web) ---');
    res.status(e.type == 'InternalServerError' ? 500 : 401).send(e);
  }
};

const isWhiteListedAPI = api => {
  return whiteListedAPI.some(wAPI => {
    const apiRegex = new RegExp(wAPI);
    const apiResult = api.match(apiRegex);
    return apiResult ? apiResult[0] == api : false;
  });
};
