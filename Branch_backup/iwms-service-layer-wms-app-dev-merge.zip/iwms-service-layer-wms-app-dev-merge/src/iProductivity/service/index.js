import { query } from '../../database/postgres.js';
import { copyActivityNorms } from '../dataLayer/activityCopy.js';
import {
  calculateProductivity,
  getSubJobByCustIdDuIdScript,
  getWoByCustIdDuIdScript,
  productivitySummaryReportScript,
} from '../dataLayer/productivityCalculation.js';
import { get_master_drop_down } from '../dataLayer/masterDropDown.js';

// get all master services
export const getMasterService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      // const values = [param];
      // const script = 'SELECT * FROM iproductivity.get_master_drop_down($1)';
      // const result = await query(script, values);
      const result = await query(get_master_drop_down(param));
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// get iteration count services
export const getIterationService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iproductivity.get_iteration()';
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

// dynamic columns
export const getDynamicColumnsService = filterValues => {
  return new Promise(async (resolve, reject) => {
    try {
      const { entityId, roleid, skillid, screenId, userid } = filterValues;
      let entityIdArray = '';
      if (entityId instanceof Array) {
        entityIdArray = entityId;
      } else {
        entityIdArray = [entityId];
      }
      const condition = `entityid = any($1) AND ( userid = $2 OR (roleid = $3 AND (skillid = any($4) OR skillid IS NULL))) AND screenid = $5`;
      const script = `SELECT *,filterValues as defaultFilterValues FROM public.wms_viewconfig_details WHERE ${condition} ORDER BY viewid ASC `;
      const values = [entityIdArray, userid, roleid, skillid, screenId];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSubDivbyDivIdService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM iproductivity.get_subdivwithdiv($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createCustomerMasterService = customerDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerName, customerid, divisionid, duid } = customerDetails;
      const values = [customerName, customerid, divisionid, duid];
      const script =
        'SELECT * FROM iproductivity.insert_org_mst_customer($1, $2, $3, $4)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const editCustomerMasterService = customerDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerName, customerid } = customerDetails;
      const values = [customerName, customerid];
      const validateScript =
        'SELECT 1 FROM public.org_mst_customer WHERE trim(upper(customername)) = trim(upper($1)) ';
      const result = await query(validateScript, [customerName]);
      let out;
      if (result.length == 0) {
        const script =
          'UPDATE org_mst_customer SET customername = $1 WHERE customerid = $2';
        out = await query(script, values);
        resolve(out);
      } else {
        reject('customer Name is already taken.');
      }
    } catch (error) {
      reject(error);
    }
  });
};
export const createStageMasterService = customerDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { customerName, divisionid, duid } = customerDetails;
      const values = [customerName, divisionid, duid];
      const script =
        'SELECT * FROM iproductivity.insert_org_mst_customer($1, $2, $3)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createActivityMasterService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [payload.activityName];
      const script = 'SELECT * FROM iproductivity.insert_wms_mst_activity($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateCustomerMasterService = customerData => {
  return new Promise(async (resolve, reject) => {
    try {
      // const values = [param];
      // const script = 'SELECT * FROM iproductivity.get_master_drop_down($1)';
      // const customerDataresult = await query(script, values);
      resolve(customerData);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteCustomerMasterService = customerid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [customerid];
      const script = 'SELECT * FROM iproductivity.delete_org_mst_customer($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getCustomerInfoService = duid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [duid];
      const script = 'SELECT * FROM iproductivity.GET_CUSTINFO($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getCustomerDetailsService = (duid, customerID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [customerID, duid];
      const script = 'SELECT * FROM iproductivity.get_cust_info_details($1,$2)';
      const result = await query(script, values);
      // const result = await getSimpleTableDataWithPagination(
      //   query,
      //   script,
      //   values,
      //   searchInfo,
      // );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script =
        'SELECT * FROM iproductivity.get_service_with_customer($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getWorkflowService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script =
        'SELECT * FROM iproductivity.get_workflow_with_customer($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getStageService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM iproductivity.get_stage_with_wfid($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createCustomerInfoService = customerInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        custinfoid,
        customerid,
        divisionid,
        verticalid,
        serviceid,
        stageid,
        noofiteration,
        duid,
        created_by,
      } = customerInfo;
      const script =
        'SELECT * FROM iproductivity.insert_cust_info($1,$2,$3,$4,$5,$6,$7,$8,$9);';
      const result = await query(script, [
        custinfoid,
        customerid,
        divisionid,
        verticalid,
        serviceid,
        stageid,
        noofiteration,
        duid,
        created_by,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteCustomerInfoService = (custinfoid, updatedby) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iproductivity.delete_cust_info($1, $2)';
      const values = [custinfoid, updatedby];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getCustActivityService = custinfoid => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iproductivity.get_activityinfo_bycust($1)';
      const values = [custinfoid];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getNormActidSkidService = normsDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { custinfoid, activityid, skilllevelid } = normsDetail;
      const script =
        'SELECT * FROM iproductivity.get_norms_config_details($1,$2,$3)';
      const values = [custinfoid, activityid, skilllevelid];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const copyNormsToCustService = normsDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { fromcustid, fromduid, toduid, tocustid, createdby } = normsDetail;
      const script = 'SELECT * FROM iproductivity.copy_norms($1,$2,$3,$4,$5)';
      const values = [fromcustid, fromduid, tocustid, toduid, createdby];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const copyActivityService = activityDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        custinfoid,
        fromactivityid,
        fromSkilllevelid,
        toactivityid,
        toskilllevelid,
        createdby,
        selectedItems,
      } = activityDetails;
      const result = await copyActivityNorms(
        query,
        custinfoid,
        fromactivityid,
        fromSkilllevelid,
        toactivityid,
        toskilllevelid,
        selectedItems,
        createdby,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getNormsService = custinfoid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [custinfoid];
      const script =
        'SELECT * FROM  iproductivity.get_norms_config_details($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createNormsService = normsinfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        normsid,
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
        targetsla,
        efffrom,
        createdby,
        versionid,
        remarks,
      } = normsinfo;
      const script =
        'select * from iproductivity.insert_norms_config($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)';
      const result = await query(script, [
        normsid,
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
        targetsla,
        efffrom,
        createdby,
        versionid,
        remarks,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getNormVersionHistoryService = normsinfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
      } = normsinfo;
      const script =
        'select * from iproductivity.get_norms_version_history($1,$2,$3,$4,$5,$6,$7)';
      const result = await query(script, [
        custinfoid,
        complexityid,
        activityid,
        noofiteration,
        skilllevelid,
        uomid,
        appid,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteNormsService = deleteDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const { normsid, updatedby } = deleteDetails;
      const values = [normsid, updatedby];
      const script = `SELECT * FROM iproductivity.delete_norms_config($1, $2)`;
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createManualLogisticService = manualLogistics => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        duid,
        customerid,
        divisionid,
        verticalid,
        serviceid,
        stageid,
        activityid,
        complexityid,
        iteration,
        skilllevelid,
        uomid,
        appid,
        queryraised,
        actual,
        starttime,
        endtime,
        empcode,
        bookcode,
        subjob,
        createddate,
      } = manualLogistics;

      const result = await calculateProductivity(
        query,
        duid /* p_duid */,
        customerid /* p_customerid */,
        divisionid /* p_divisionid */,
        verticalid /* p_verticalid */,
        serviceid /* p_serviceid */,
        stageid /* p_stageid */,
        activityid /* p_activityid */,
        complexityid /* p_complexityid */,
        iteration /* p_noofiteration */,
        skilllevelid /* p_skilllevelid */,
        uomid /* p_uomid */,
        appid /* p_appid */,
        queryraised /* p_isqueryraised */,
        // seccorrection /* p_seccorrection */,
        actual /* p_actualsla */,
        starttime /* p_starttime */,
        endtime /* p_endtime */,
        empcode /* p_empid */,
        bookcode /* p_bookCode */,
        subjob /* p_subjob */,
        createddate /* createddate */,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createServiceMasterService = servicename => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [servicename];
      const script = 'SELECT * FROM iproductivity.insert_wms_service($1);';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteServiceMasterService = serviceid => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [serviceid];
      const script = 'SELECT * FROM iproductivity.delete_wms_service($1);';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createMasterStageService = stagename => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [stagename];
      const script = 'select * from iproductivity.insert_wms_stage($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getWODropDownService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { column, duid, custid } = payload;
      const values = [duid, custid];
      let script;
      if (column == 'wo') {
        script = getWoByCustIdDuIdScript();
      } else {
        script = getSubJobByCustIdDuIdScript();
      }
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getProductivtySchemaService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { user, fromDate, toDate } = payload;
      const values = [user, fromDate, toDate];
      const script = productivitySummaryReportScript();
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
