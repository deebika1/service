export function get_master_drop_down(p_name) {
  let query = '';

  switch (p_name) {
    case 'IDU':
      query =
        'select duid AS column_id, duname AS column_name FROM public.mst_deliveryunit WHERE isactive = true ORDER BY duname';
      break;
    case 'DU':
      query =
        'SELECT duid AS column_id, duname AS column_name FROM public.mst_deliveryunit WHERE isactive = true ORDER BY duname;';
      break;
    case 'ODU':
      query =
        'SELECT duid AS column_id, duname AS column_name FROM public.org_mst_deliveryunit WHERE isactive = true ORDER BY duname;';
      break;
    case 'CUSTOMER':
      query =
        'SELECT customerid AS column_id, customername AS column_name FROM public.org_mst_customer WHERE isactive = true ORDER BY customername;';
      break;
    case 'SERVICE':
      query =
        'SELECT serviceid AS column_id, servicename AS column_name FROM public.wms_mst_service WHERE isactive = true ORDER BY servicename;';
      break;
    case 'STAGE':
      query =
        'SELECT stageid AS column_id, stagename AS column_name FROM public.wms_mst_stage WHERE isactive = true ORDER BY stagename;';
      break;
    case 'SHIFT':
      query =
        'SELECT shiftid::bigint AS column_id, shifthrs::VARCHAR AS column_name FROM public.wms_mst_shift WHERE isactive = true ORDER BY shifthrs;';
      break;
    case 'ACTIVITY':
      query =
        'SELECT activityid AS column_id, activityname AS column_name FROM public.wms_mst_activity WHERE isactive = true ORDER BY activityname;';
      break;
    case 'SOFTWARE':
      query =
        'SELECT appid AS column_id, appname AS column_name FROM public.wms_mst_software WHERE isactive = true ORDER BY appname;';
      break;
    case 'COMPLEXITY':
      query =
        'SELECT complexityid AS column_id, complexity AS column_name FROM public.wms_mst_complexity WHERE isactive = 1 ORDER BY complexity;';
      break;
    case 'SKILLLEVEL':
      query =
        'SELECT skilllevelid AS column_id, skilllevel AS column_name FROM public.wms_mst_skilllevel WHERE skilllevelid IN (1, 2) ORDER BY skilllevel;';
      break;
    case 'MODE':
      query =
        'SELECT modeid::bigint AS column_id, modedesc AS column_name FROM iquality.mst_qualitymode ORDER BY modedesc;';
      break;
    case 'SKILL':
      query =
        'SELECT skillid AS column_id, skillname AS column_name FROM public.wms_mst_skill ORDER BY skillname;';
      break;
    case 'DIVISION':
      query =
        'SELECT divisionid AS column_id, division AS column_name FROM public.org_mst_division WHERE isactive = true ORDER BY division;';
      break;
    case 'SUBDIVISION':
      query =
        'SELECT subdivisionid AS column_id, subdivision AS column_name FROM public.org_mst_subdivision WHERE isactive = true ORDER BY subdivision;';
      break;
    case 'UOM':
      query =
        'SELECT uomid::bigint AS column_id, uom AS column_name FROM public.wms_mst_uom WHERE isactive = 1 ORDER BY uom;';
      break;
    case 'VERTICAL':
      query =
        'SELECT verticalid AS column_id, verticalname AS column_name FROM public.wms_mst_vertical WHERE isactive = true AND verticalid <> 1 ORDER BY verticalname;';
      break;
    case 'NOC':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 1 ORDER BY ErrorDesc;';
      break;
    case 'PROCESS':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 2 ORDER BY ErrorDesc;';
      break;
    case 'BOOKPART':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 3 ORDER BY ErrorDesc;';
      break;
    case 'ELEMENT':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 4 ORDER BY ErrorDesc;';
      break;
    case 'TYPEOFEDITING':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 5 ORDER BY ErrorDesc;';
      break;
    case 'PARAMETERS':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 6 ORDER BY ErrorDesc;';
      break;
    case 'ERRORTYPE':
      query =
        'SELECT ErrorId::bigint AS column_id, ErrorDesc AS column_name FROM iquality.SvnD_ErrorMst WHERE isactive = true AND ErrorGroupId = 7 ORDER BY ErrorDesc;';
      break;
    case 'SEVERITY':
      query =
        'SELECT SeverityId::bigint AS column_id, Severity AS column_name FROM iquality.Mst_Severity WHERE isactive = true ORDER BY Severity;';
      break;
    case 'CURRENCY':
      query =
        'SELECT Currencyid::bigint AS column_id, CurrencyText AS column_name FROM iquality.Mst_CurrencyMst WHERE isactive = true ORDER BY CurrencyText;';
      break;
    case 'APPRAISALCATEGORY':
      query =
        'SELECT categoryid::bigint AS column_id, category AS column_name FROM iaspire.mst_appraisaltype WHERE isactive = true;';
      break;
    case 'DESIGNATION':
      query =
        'SELECT designationid::bigint AS column_id, designationdesc AS column_name FROM public.mst_designation WHERE isactive = true;';
      break;
    case 'BANDLEVEL':
      query =
        'SELECT bandlevelid::bigint AS column_id, bandlevel AS column_name FROM public.mst_bandlevel WHERE isactive = true;';
      break;
    default:
      throw new Error('Invalid Param');
  }

  return query;
}
