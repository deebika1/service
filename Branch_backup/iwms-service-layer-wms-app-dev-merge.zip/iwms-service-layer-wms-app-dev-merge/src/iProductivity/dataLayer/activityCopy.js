export const copyActivityNorms = (
  query,
  p_custinfoid,
  p_fromactivityid,
  p_fromskilllevelid,
  p_toactivityid,
  p_toskilllevelid,
  p_copydata,
  p_created_by,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (const vCopyElement of p_copydata) {
        const existsQuery = `
        SELECT 1
        FROM iproductivity.mst_norms_config n
        WHERE n.custinfoid = $1
        AND n.activityid = $2
        AND n.skilllevelid = $3
        AND n.normsid = $4
      `;
        const existsValues = [
          p_custinfoid,
          p_fromactivityid,
          p_fromskilllevelid,
          vCopyElement.tonormsid,
        ];

        const existsResult = await query(existsQuery, existsValues);

        if (existsResult && existsResult?.length > 0) {
          const insertQuery = `
          INSERT INTO iproductivity.mst_norms_config (
            custinfoid,
            complexityid,
            activityid,
            noofiteration,
            skilllevelid,
            uomid,
            targetsla,
            version,
            created_by,
            efffrom,
            appid
          ) SELECT
            $1,
            n.complexityid,
            $2,
            n.noofiteration,
            $3,
            n.uomid,
            $4,
            0,
            $5,
            CURRENT_DATE,
            n.appid
          FROM iproductivity.mst_norms_config n
          WHERE n.custinfoid = $6
          AND n.activityid = $7
          AND n.skilllevelid = $8
          AND n.normsid = $9
        `;

          const insertValue = [
            p_custinfoid,
            p_toactivityid,
            p_toskilllevelid,
            vCopyElement.totargetsla,
            p_created_by,
            p_custinfoid,
            p_fromactivityid,
            p_fromskilllevelid,
            vCopyElement.tonormsid,
          ];

          await query(insertQuery, insertValue);
        }
      }
      resolve(true);
    } catch (error) {
      console.error('Error:', error);
      reject(error);
    }
  });
};
