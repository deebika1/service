import { readFileSync } from 'fs';
import express from 'express';
import swaggerUi from 'swagger-ui-express';
import {
  createCustomerMasterController,
  deleteCustomerMasterController,
  deleteCustomerInfoController,
  getCustomerInfoController,
  getMasterController,
  getServiceController,
  getWorkflowController,
  getStageController,
  updateCustomerMasterController,
  getCustActivityController,
  getIterationController,
  getNormsController,
  createNormsController,
  deleteNormsController,
  createServiceMasterController,
  deleteServiceMasterController,
  createStageMasterController,
  getSubDivByDivIdController,
  getDynamicColumnController,
  getiProductivityFolderPath,
  getCustomerDetailsController,
  getNormsActidSkidController,
  copyNormsToCustController,
  getNormVersionHistoryController,
  createManaualLogisticsController,
  getDropDownForManualEntryController,
  getProductivityReportController,
  copyActivityController,
  createMstCustomerController,
  editMasterCustomerController,
} from '../controller/index.js';
import {
  validateRequestBody,
  validateRequestParams,
} from '../helpers/middleware.js';
import {
  createOrgCustomerSchema,
  deleteOrgCustomerSchema,
  getByCustomerIdSchema,
  getByWorkFlowIdSchema,
  getMasterSchema,
  createStageSchema,
  createServiceNameSchema,
  deleteByServiceIdSchema,
  createNormsInfoSchema,
  deleteNormsInfoSchema,
  deleteCustInfoSchema,
  getCustActivityInfoSchema,
  getSubDivByDivSchema,
  getNormsByHeaderSchema,
  getByCustomerIDSchema,
  getCustomersByDuidSchema,
  getNormsActidSkillidInfoSchema,
  copyNormCustSchema,
  getNormsVersionHistorySchema,
  getWoDropDownSchema,
  getProductivityReportSchema,
  copyActivitySchema,
} from '../helpers/validation.js';

const iProductivityRouter = express.Router();

const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}

// CRUD MASTERS
swaggerDocs(iProductivityRouter);
iProductivityRouter.get('/masters/iteration', handler(getIterationController));
// folder path
iProductivityRouter.get('/folderpath', handler(getiProductivityFolderPath));
iProductivityRouter.post(
  '/dynamicColumns',
  handler(getDynamicColumnController),
);
iProductivityRouter.get(
  '/masters/:tblname',
  validateRequestParams(getMasterSchema),
  handler(getMasterController),
);
iProductivityRouter.get(
  '/masters/getService/:custid',
  validateRequestParams(getByCustomerIdSchema),
  handler(getServiceController),
);
iProductivityRouter.get(
  '/masters/subdiv/:divID',
  validateRequestParams(getSubDivByDivSchema),
  handler(getSubDivByDivIdController),
);
iProductivityRouter.post(
  '/masters/createservice',
  validateRequestBody(createServiceNameSchema),
  handler(createServiceMasterController),
);
iProductivityRouter.post(
  '/masters/deleteservice/:serviceid',
  validateRequestParams(deleteByServiceIdSchema),
  handler(deleteServiceMasterController),
);
iProductivityRouter.get(
  '/masters/getWorkflow/:custid',
  validateRequestParams(getByCustomerIdSchema),
  handler(getWorkflowController),
);
iProductivityRouter.get(
  '/masters/getStage/:wfid',
  validateRequestParams(getByWorkFlowIdSchema),
  handler(getStageController),
);

iProductivityRouter.post(
  '/masters/createstage',
  validateRequestBody(createStageSchema),
  handler(createStageMasterController),
);
// CRUD ORG CUSTOMER
iProductivityRouter.post(
  '/masters/customer',
  validateRequestBody(createOrgCustomerSchema),
  handler(createCustomerMasterController),
);
iProductivityRouter.post(
  '/masters/updatecustomer',
  handler(updateCustomerMasterController),
);
iProductivityRouter.post(
  '/masters/deletecustomer',
  validateRequestParams(deleteOrgCustomerSchema),
  handler(deleteCustomerMasterController),
);
// CRUD CUSTOMER INFO
iProductivityRouter.post(
  '/get/customerinfo',
  validateRequestBody(getCustomersByDuidSchema),
  handler(getCustomerInfoController),
);
iProductivityRouter.get(
  '/customerinfo/:duid/:customerID',
  validateRequestParams(getByCustomerIDSchema),
  handler(getCustomerDetailsController),
);

iProductivityRouter.post(
  '/customerinfo',
  // validateRequestBody(createCustInfoSchema),
  handler(createCustomerMasterController),
);
iProductivityRouter.post(
  '/createcustomer',
  handler(createMstCustomerController),
);
iProductivityRouter.post(
  '/updateCustomername',
  handler(editMasterCustomerController),
);
iProductivityRouter.post(
  '/deletecustinfo',
  validateRequestBody(deleteCustInfoSchema),
  handler(deleteCustomerInfoController),
);
// CRUD NORMS
iProductivityRouter.get(
  '/norms/activity/:custinfoid',
  validateRequestParams(getCustActivityInfoSchema),
  handler(getCustActivityController),
);
iProductivityRouter.post(
  '/getnorms',
  validateRequestBody(getNormsActidSkillidInfoSchema),
  handler(getNormsActidSkidController),
);
iProductivityRouter.post(
  '/copynorm',
  validateRequestBody(copyNormCustSchema),
  handler(copyNormsToCustController),
);
iProductivityRouter.post(
  '/copyactivity',
  validateRequestBody(copyActivitySchema),
  handler(copyActivityController),
);
iProductivityRouter.get(
  '/norms/:custinfoid',
  validateRequestParams(getNormsByHeaderSchema),
  handler(getNormsController),
);
iProductivityRouter.post(
  '/norms',
  validateRequestBody(createNormsInfoSchema),
  handler(createNormsController),
);
iProductivityRouter.post(
  '/normsversion',
  validateRequestBody(getNormsVersionHistorySchema),
  handler(getNormVersionHistoryController),
);

iProductivityRouter.post(
  '/deletenorms',
  validateRequestBody(deleteNormsInfoSchema),
  handler(deleteNormsController),
);
iProductivityRouter.post(
  '/logistics',
  // validateRequestBody(logisticsFeedSchema),
  handler(createManaualLogisticsController),
);
iProductivityRouter.post(
  '/woDropDown',
  validateRequestBody(getWoDropDownSchema),
  handler(getDropDownForManualEntryController),
);
iProductivityRouter.post(
  '/report',
  validateRequestBody(getProductivityReportSchema),
  handler(getProductivityReportController),
);

export default iProductivityRouter;
