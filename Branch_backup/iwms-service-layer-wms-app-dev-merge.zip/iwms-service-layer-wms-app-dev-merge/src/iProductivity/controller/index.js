import {
  createCustomerInfoService,
  createCustomerMasterService,
  deleteCustomerMasterService,
  getCustomerInfoService,
  getMasterService,
  getService,
  getWorkflowService,
  getStageService,
  updateCustomerMasterService,
  deleteCustomerInfoService,
  getCustActivityService,
  getIterationService,
  getNormsService,
  createNormsService,
  deleteNormsService,
  createServiceMasterService,
  deleteServiceMasterService,
  createStageMasterService,
  getSubDivbyDivIdService,
  getDynamicColumnsService,
  getCustomerDetailsService,
  createActivityMasterService,
  getNormActidSkidService,
  copyNormsToCustService,
  getNormVersionHistoryService,
  createManualLogisticService,
  getWODropDownService,
  getProductivtySchemaService,
  createMasterStageService,
  copyActivityService,
  editCustomerMasterService,
} from '../service/index.js';
import logger from '../../modules/utils/logs/index.js';

export const getiProductivityFolderPath = async (req, res) => {
  try {
    res.status(200).send({ path: '/okm:root/prodrepository/iProductivity/' });
  } catch (error) {
    logger.info('getiProductivityFolderPath : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const getDynamicColumnController = async (req, res) => {
  try {
    const filterValue = req.body;
    const out = await getDynamicColumnsService(filterValue);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getMasterController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getMasterController = async (req, res) => {
  try {
    const tblname = req.params.tblname.toUpperCase();
    const out = await getMasterService(tblname);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getMasterController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getSubDivByDivIdController = async (req, res) => {
  try {
    const { divID } = req.params;
    const out = await getSubDivbyDivIdService(divID);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getSubDivByDivIdController : ', {
      error,
      message: error?.message,
    });
    res.status(400).send({ error, message: error?.message });
  }
};

export const getIterationController = async (req, res) => {
  try {
    const out = await getIterationService();
    res.status(200).send(out);
  } catch (error) {
    logger.info('getMasterController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustomerInfoController = async (req, res) => {
  try {
    const { duid } = req.body;
    const out = await getCustomerInfoService(duid);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getCustInfoController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustomerDetailsController = async (req, res) => {
  try {
    const { duid, customerID } = req.params;
    const out = await getCustomerDetailsService(duid, customerID);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getCustInfoController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createCustomerInfoController = async (req, res) => {
  try {
    await createCustomerInfoService(req.body);
    res.status(201).send('Customer Info created successfully!');
  } catch (error) {
    logger.info('createCustInfoController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteCustomerInfoController = async (req, res) => {
  try {
    const { custinfoid, updatedby } = req.body;
    const result = await deleteCustomerInfoService(custinfoid, updatedby);
    res.status(200).send(result);
  } catch (error) {
    logger.info('deleteCustomerInfoService:', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createCustomerMasterController = async (req, res) => {
  try {
    const payload = req.body;
    let stageMaster;
    if (payload.stageid == null) {
      stageMaster = await createMasterStageService(payload.stageName);
      payload.stageid = stageMaster[0]?.insert_wms_stage;
    }
    await createCustomerInfoService(payload);
    res.status(201).send('Customer Info created successfully!');
  } catch (error) {
    logger.info('createCustomerMasterController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createMstCustomerController = async (req, res) => {
  try {
    const payload = req.body;
    await createCustomerMasterService(payload);
    res.status(201).send('Customer created successfully!');
  } catch (error) {
    logger.info('createMstCustomerController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const editMasterCustomerController = async (req, res) => {
  try {
    const payload = req.body;
    await editCustomerMasterService(payload);
    res.status(201).send('Customer Updated successfully!');
  } catch (error) {
    logger.info('editMasterCustomerController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const updateCustomerMasterController = async (req, res) => {
  try {
    await updateCustomerMasterService(req.body);
    res.status(201).send('Customer Info updated successfully!');
  } catch (error) {
    logger.info('createCustInfoController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteCustomerMasterController = async (req, res) => {
  try {
    const { customerid } = req.params;
    await deleteCustomerMasterService(customerid);
    res.status(201).send('Customer Info updated successfully!');
  } catch (error) {
    logger.info('createCustInfoController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getServiceController = async (req, res) => {
  try {
    const { custid } = req.params;
    const out = await getService(custid);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getServiceController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getStageController = async (req, res) => {
  try {
    const { wfid } = req.params;
    const out = await getStageService(wfid);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getStageController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getWorkflowController = async (req, res) => {
  try {
    const { custid } = req.params;
    const out = await getWorkflowService(custid);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getWorkflowController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getCustActivityController = async (req, res) => {
  try {
    const { custinfoid } = req.params;
    const result = await getCustActivityService(custinfoid);
    res.status(200).send(result);
  } catch (error) {
    logger.info('getActivityService:', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const getNormsActidSkidController = async (req, res) => {
  try {
    const normsDetail = req.body;
    const result = await getNormActidSkidService(normsDetail);
    res.status(200).send(result);
  } catch (error) {
    logger.info('getNormsActidSkidController:', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const copyNormsToCustController = async (req, res) => {
  try {
    const normsDetail = req.body;
    const result = await copyNormsToCustService(normsDetail);
    res.status(200).send(result);
  } catch (error) {
    logger.info('copyNormsToCustController:', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const copyActivityController = async (req, res) => {
  try {
    const activityDetails = req.body;
    const result = await copyActivityService(activityDetails);
    res.status(200).send(result);
  } catch (error) {
    logger.info('copyActivityController:', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getNormsController = async (req, res) => {
  try {
    const { custinfoid } = req.params;
    const out = await getNormsService(custinfoid);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getNormsController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createNormsController = async (req, res) => {
  try {
    const payload = req.body;
    let activityMaster;
    if (payload.activityid == null) {
      activityMaster = await createActivityMasterService(payload);
      payload.activityid = activityMaster[0]?.insert_wms_mst_activity;
    }
    await createNormsService(payload);
    // try {
    //   await mailTriggerService(mailData);
    // } catch (mailError) {
    //   console.error('Mail Trigger Service Error:', mailError);
    // }
    res.status(201).send('New Norms Created Successfully!');
  } catch (error) {
    logger.info('createNormsController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getNormVersionHistoryController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getNormVersionHistoryService(payload);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getNormVersionHistoryController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteNormsController = async (req, res) => {
  try {
    const payload = req.body;
    await deleteNormsService(payload);
    res.status(200).send('Norms Deleted Successfully!');
  } catch (error) {
    logger.info('deleteNormsController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createManaualLogisticsController = async (req, res) => {
  try {
    const payload = req.body;
    await createManualLogisticService(payload);
    res.status(200).send('Norms Successfully Calculated!');
  } catch (error) {
    logger.info('createManaualLogisticsController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createServiceMasterController = async (req, res) => {
  try {
    const { servicename } = req.body;
    await createServiceMasterService(servicename);
    res.status(201).send('Service Info created successfully!');
  } catch (error) {
    logger.info('createSeviceInfoController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteServiceMasterController = async (req, res) => {
  try {
    const { serviceid } = req.params;
    await deleteServiceMasterService(serviceid);
    res.status(201).send('Service Info updated successfully!');
  } catch (error) {
    logger.info('createServiceInfoController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createStageMasterController = async (req, res) => {
  try {
    const { stagename } = req.body;
    await createStageMasterService(stagename);
    res.status(201).send('stage created successfully!');
  } catch (error) {
    logger.info('createStageMasterController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getDropDownForManualEntryController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getWODropDownService(payload);
    res.status(201).send(out);
  } catch (error) {
    logger.info('getDropDownForManualEntryController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const getProductivityReportController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getProductivtySchemaService(payload);
    res.status(201).send(out);
  } catch (error) {
    logger.info('getProductivityReportController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
