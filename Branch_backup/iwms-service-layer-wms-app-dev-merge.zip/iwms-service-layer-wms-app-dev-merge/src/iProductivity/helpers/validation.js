import Joi from 'joi';

const masterData = [
  'customer',
  'division',
  'vertical',
  'shift',
  'software',
  'du',
  'complexity',
  'skilllevel',
  'uom',
  'skill',
  'customerid',
  'activity',
  'service',
  'stage',
  'subdivision',
  'mode',
  'noc',
  'process',
  'bookpart',
  'element',
  'typeofediting',
  'parameters',
  'errortype',
  'severity',
  'currency',
  'idu',
  'odu',
  'appraisalcategory',
  'designation',
  'bandlevel',
];

export const getMasterSchema = Joi.object({
  tblname: Joi.string()
    .valid(...masterData)
    .required(),
});

export const getByCustomerIdSchema = Joi.object({
  custid: Joi.number().min(1).required(),
});
export const getByCustomerIDSchema = Joi.object({
  duid: Joi.number().min(1).required(),
  customerID: Joi.number().min(1).required(),
});

export const getSubDivByDivSchema = Joi.object({
  divID: Joi.number().min(1).required(),
});

export const getByWorkFlowIdSchema = Joi.object({
  wfid: Joi.number().min(1).required(),
});

export const getNormsByHeaderSchema = Joi.object({
  custinfoid: Joi.number().min(1).required(),
});

export const createStageSchema = Joi.object({
  p_stagename: Joi.string().min(2).max(30).required(),
});

export const deleteCustInfoSchema = Joi.object({
  custinfoid: Joi.number().min(1).required(),
  updatedby: Joi.string().alphanum().min(3).required(),
});

export const createOrgCustomerSchema = Joi.object({
  customerDetails: Joi.object({
    customername: Joi.string().min(1).max(30).required(),
    divisionid: Joi.number().min(1).required(),
    duid: Joi.number().min(1).required(),
  }).required(),
  customerInfoDetails: Joi.object({
    custinfoid: Joi.number().allow(null).required(),
    customerid: Joi.number().required(),
    divisionid: Joi.number().required(),
    verticalid: Joi.number().required(),
    serviceid: Joi.number().required(),
    stageid: Joi.number().required(),
    noofiteration: Joi.number().required(),
    duid: Joi.number().required(),
    created_by: Joi.string().required(),
  }).required(),
});

export const deleteOrgCustomerSchema = Joi.object({
  customerid: Joi.number().min(1).required(),
});

export const createCustInfoSchema = Joi.object({
  custinfoid: Joi.number().allow(null).required(),
  customerid: Joi.number().allow(null).required(),
  customerName: Joi.string().allow(null).required(),
  divisionid: Joi.number().allow(null).required(),
  verticalid: Joi.number().allow(null).required(),
  serviceid: Joi.number().allow(null).required(),
  stageName: Joi.string().allow(null).required(),
  stageid: Joi.number().allow(null).required(),
  noofiteration: Joi.number().allow(null).required(),
  duid: Joi.number().required(),
  created_by: Joi.string().allow(null).required(),
});

export const getCustomersByDuidSchema = Joi.object({
  duid: Joi.number().min(1).required(),
});

export const createServiceNameSchema = Joi.object({
  servicename: Joi.string().alphanum().min(3).max(30).required(),
});

export const deleteByServiceIdSchema = Joi.object({
  serviceid: Joi.number().min(1).required(),
});

export const createNormsInfoSchema = Joi.object({
  normsid: Joi.number().min(1).allow(null).required(),
  custinfoid: Joi.number().min(1).required(),
  complexityid: Joi.number().min(1).required(),
  activityid: Joi.number().min(1).allow(null).required(),
  activityName: Joi.string().allow(null).required(),
  noofiteration: Joi.number().required(),
  skilllevelid: Joi.number().min(1).required(),
  uomid: Joi.number().min(1).required(),
  appid: Joi.number().min(1).required(),
  targetsla: Joi.number().precision(2).min(0).required(),
  efffrom: Joi.string().required(),
  createdby: Joi.string().required(),
  versionid: Joi.number().required(),
  remarks: Joi.string().allow(null).allow(''),
});
export const getNormsVersionHistorySchema = Joi.object({
  custinfoid: Joi.number().min(1).required(),
  complexityid: Joi.number().min(1).required(),
  activityid: Joi.number().min(1).required(),
  noofiteration: Joi.number().required(),
  skilllevelid: Joi.number().min(1).required(),
  uomid: Joi.number().min(1).required(),
  appid: Joi.number().min(1).required(),
});

export const updateNormsInfoSchema = Joi.object({
  normsid: Joi.number().min(1).required(),
  custinfoid: Joi.number().min(1).required(),
  complexityid: Joi.number().min(1).required(),
  activityid: Joi.number().min(1).required(),
  noofiteration: Joi.number().min(1).required(),
  skilllevelid: Joi.number().min(1).required(),
  uomid: Joi.number().min(1).required(),
  shiftid: Joi.number().min(1).required(),
  targetsla: Joi.number().precision(2).min(1).required(),
  skillid: Joi.number().min(1).required(),
  outsrctype: Joi.boolean().required(),
  eff_from: Joi.date().required(),
  primaryflag: Joi.boolean().required(),
  updated_by: Joi.string().required(),
});

export const deleteNormsInfoSchema = Joi.object({
  normsid: Joi.number().min(1).required(),
  updatedby: Joi.string().required(),
});

export const getCustActivityInfoSchema = Joi.object({
  custinfoid: Joi.number().min(1).required(),
});
export const getNormsActidSkillidInfoSchema = Joi.object({
  custinfoid: Joi.number().min(1).required(),
  activityid: Joi.number().min(1).required(),
  skilllevelid: Joi.number().min(1).required(),
});
export const copyNormCustSchema = Joi.object({
  fromcustid: Joi.number().min(1).required(),
  fromduid: Joi.number().min(1).required(),
  toduid: Joi.number().min(1).required(),
  tocustid: Joi.number().min(1).required(),
  createdby: Joi.string().required(),
});

export const logisticsFeedSchema = Joi.object({
  empcode: Joi.string().required(),
  duid: Joi.number().min(1).required(),
  customerid: Joi.number().min(1).required(),
  bookcode: Joi.string().required(),
  subjob: Joi.string().required(),
  divisionid: Joi.number().min(1).required(),
  verticalid: Joi.number().min(1).required(),
  serviceid: Joi.number().min(1).required(),
  stageid: Joi.number().min(1).required(),
  activityid: Joi.number().min(1).required(),
  skilllevelid: Joi.number().min(1).required(),
  complexityid: Joi.number().min(1).required(),
  iteration: Joi.number().min(0).required(),
  appid: Joi.number().min(1).required(),
  starttime: Joi.string().required(),
  endtime: Joi.string().required(),
  queryraised: Joi.boolean().required(),
  uomid: Joi.number().min(1).required(),
  actual: Joi.string().required(),
  seccorrection: Joi.string(),
});

export const getWoDropDownSchema = Joi.object({
  column: Joi.string().required(),
  duid: Joi.number().min(1).required(),
  custid: Joi.number().min(1).required(),
});

export const getProductivityReportSchema = Joi.object({
  user: Joi.string().required(),
  fromDate: Joi.string().required(),
  toDate: Joi.string().required(),
});

export const copyActivitySchema = Joi.object({
  custinfoid: Joi.number().min(1).required(),
  fromactivityid: Joi.number().min(1).required(),
  fromSkilllevelid: Joi.number().min(1).required(),
  toactivityid: Joi.number().min(1).required(),
  toskilllevelid: Joi.number().min(1).required(),
  createdby: Joi.string().required(),
  selectedItems: Joi.array().items(Joi.any()),
});
