export const calculateProductivity = async (
  query,
  p_duid,
  p_customerid,
  p_divisionid,
  p_verticalid,
  p_serviceid,
  p_stageid,
  p_activityid,
  p_complexityid,
  p_noofiteration,
  p_skilllevelid,
  p_uomid,
  p_appid,
  p_isqueryraised,
  p_seccorrection,
  p_actualsla,
  p_starttime,
  p_endtime,
  p_empid,
  p_bookCode,
  p_subjob,
) => {
  let v_targetsla;
  let v_version;
  let v_custinfoid;
  let v_timetaken = 0;
  let v_productivity = 0;
  let v_defaultsla = 0.75;
  let v_iteration_targetsla;
  let v_pretimetaken;
  const v_defaulttime = 0.25;
  const v_totaltime = 450;

  // Database query to get v_targetsla, v_version, v_custinfoid
  const queryResult = await query(
    `
      SELECT COALESCE(mnc.targetsla, 0), mnc.version, c.custinfoid
      FROM iproductivity.mst_cust_info c
      LEFT JOIN iproductivity.mst_norms_config mnc ON mnc.custinfoid = c.custinfoid
      WHERE c.duid = $1
        AND c.customerid = $2
        AND c.divisionid = $3
        AND c.verticalid = $4
        AND c.serviceid = $5
        AND c.stageid = $6
        AND mnc.complexityid = $7
        AND mnc.activityid = $8
        AND mnc.noofiteration = $9
        AND mnc.skilllevelid = $10
        AND mnc.uomid = $11
        AND mnc.appid = $12
        AND (mnc.effto - CURRENT_DATE >= 1 OR mnc.effto IS NULL OR mnc.effto = CURRENT_DATE)
        AND mnc.efffrom <= CURRENT_DATE
        AND mnc.isactive = true
        AND c.isactive = true
        AND mnc.targetsla > 0;
    `,
    [
      p_duid,
      p_customerid,
      p_divisionid,
      p_verticalid,
      p_serviceid,
      p_stageid,
      p_complexityid,
      p_activityid,
      p_noofiteration,
      p_skilllevelid,
      p_uomid,
      p_appid,
    ],
  );

  if (queryResult.length > 0) {
    v_targetsla = queryResult[0].coalesce;
    v_version = queryResult[0].version;
    v_custinfoid = queryResult[0].custinfoid;
  }

  if (!v_targetsla) {
    v_targetsla = 0;
  }

  if (p_isqueryraised && p_noofiteration > 0) {
    v_defaultsla = 100;
  } else {
    v_defaultsla = 0.75;
  }

  if (p_seccorrection === 0) {
    v_productivity = (p_actualsla / v_targetsla) * 100;
  } else if (p_seccorrection > 0) {
    v_timetaken = p_seccorrection * (v_targetsla / v_totaltime);

    if (p_noofiteration === 0) {
      v_productivity =
        ((p_actualsla - p_seccorrection) / v_targetsla +
          v_defaultsla * (p_seccorrection / v_targetsla)) *
        100;
    } else if (v_targetsla === 0) {
      const script = `
        SELECT Timetaken
        FROM iproductivity.Productivity_Trans
        WHERE duid = $1
          AND customerid = $2
          AND divisionid = $3
          AND verticalid = $4
          AND serviceid  = $5
          AND stageid    = $6
          AND activityid = $7
          AND skilllevelid  = $8
          AND complexityid  = $9
          AND noofiteration = $10
          AND appid = $11
          AND uomid = $12;
      `;
      const prevTimeResult = await query(script, [
        p_duid,
        p_customerid,
        p_divisionid,
        p_verticalid,
        p_serviceid,
        p_stageid,
        p_activityid,
        p_skilllevelid,
        p_complexityid,
        p_noofiteration - 1,
        p_appid,
        p_uomid,
      ]);

      if (prevTimeResult.length > 0) {
        v_pretimetaken = prevTimeResult[0].timetaken;
      }

      v_timetaken = v_defaulttime * v_pretimetaken;
      v_iteration_targetsla = (v_totaltime / v_timetaken) * p_actualsla;
      v_productivity = (p_actualsla / v_iteration_targetsla) * 100;
    } else {
      v_timetaken *= v_defaulttime;
      v_productivity = (p_actualsla / v_targetsla) * 100;
    }
  }

  // Database query to insert into Productivity_Trans table
  await query(
    `
      INSERT INTO iproductivity.Productivity_Trans (
        custinfoid,
        empid, 
        duid, 
        customerid, 
        bookCode,
        subjob,
        divisionid, 
        verticalid, 
        serviceid, 
        stageid, 
        activityid,
        skilllevelid, 
        complexityid, 
        noofiteration, 
        appid, 
        version, 
        starttime, 
        endtime,
        isqueryraised, 
        uomid, 
        targetsla, 
        actualsla, 
        sec_correction, 
        totaltime, 
        timetaken, 
        productivity
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26
      );
    `,
    [
      v_custinfoid,
      p_empid,
      p_duid,
      p_customerid,
      p_bookCode,
      p_subjob,
      p_divisionid,
      p_verticalid,
      p_serviceid,
      p_stageid,
      p_activityid,
      p_skilllevelid,
      p_complexityid,
      p_noofiteration,
      p_appid,
      v_version,
      p_starttime,
      p_endtime,
      p_isqueryraised,
      p_uomid,
      v_iteration_targetsla > 0
        ? Math.round(v_iteration_targetsla)
        : v_targetsla,
      p_actualsla,
      p_seccorrection,
      v_totaltime,
      v_timetaken.toFixed(2),
      Math.ceil(v_productivity),
    ],
  );
};
