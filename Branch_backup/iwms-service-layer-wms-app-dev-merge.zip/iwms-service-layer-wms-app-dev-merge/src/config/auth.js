export const authConfig = {
  base_url: process.env.WSO2_BASEURL,
  uri: {
    token: '/oauth2/token',
    redirect: '/auth/redirect',
    user_info: '/oauth2/userinfo',
    logout: '/oidc/logout',
  },
};
