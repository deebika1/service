import yargs from 'yargs';

const { argv } = yargs(process.argv);

export const appConfig = {
  host: process.env.HOST,
  port: process.env.PORT,
  proxyPort: process.env.PROXY_PORT,
  protocol: process.env.PROTOCOL,
  basePath: process.env.BASE_PATH || '',
  getUrl: () =>
    `${process.env.PROTOCOL}://${process.env.HOST}:${process.env.PROXY_PORT}${
      process.env.BASE_PATH ? process.env.BASE_PATH : ''
    }`,
  client: {
    host: process.env.CLIENT_HOST,
    port: process.env.CLIENT_PORT,
    protocol: process.env.CLIENT_PROTOCOL,
    getUrl: () =>
      `${process.env.CLIENT_PROTOCOL}://${process.env.CLIENT_HOST}:${process.env.CLIENT_PORT}`,
  },
  postgres: {
    host: process.env.POSTGRES_HOST,
    port: process.env.POSTGRES_PORT,
    user: process.env.POSTGRES_USER,
    ssl: process.env.POSTGRES_SSL == 'true',
    database: process.env.POSTGRES_DB,
    password: process.env.POSTGRES_PWD,
  },
  rabbitMQ: {
    protocol: process.env.RMQ_PROTOCOL,
    username: process.env.RMQ_USER,
    password: process.env.RMQ_PWD,
    host: process.env.RMQ_HOST,
    port: process.env.RMQ_PORT,
    virtualHost: process.env.RMQ_VH,
    queues: {
      action: process.env.RMQ_NOTIFICATION_QUEUE,
    },
    getQueueMsgs: `http://${process.env.RMQ_HOST}:15672/api/queues/iwms/${process.env.RMQ_CAMUNDA_TASK_EXCHANGE}/get`,
  },
  azureSB: {
    conString: process.env.ASB_CON_STRING,
    queues: {
      action: process.env.ASB_NOTIFICATION_QUEUE,
    },
  },
  MQ: argv.MQ,
  isItracksAPI: true,
};
