export const config = {
  iAuthor: {
    base_url: () => {
      switch (process.env.MODE.toLocaleLowerCase()) {
        case 'azure':
          return 'https://ipubsuite.integra.co.in/integra/ips/';
        case 'dev':
          return 'https://dev-ipubsuite.integra.co.in/integra/ips/';
        case 'test':
          return 'https://test-ipubsuite.integra.co.in/integra/ips/';
        case 'uat':
          return 'https://demo-ipubsuite.integra.co.in/integra/ips/';
        default:
          return 'https://test-ipubsuite.integra.co.in/integra/ips/';
      }
    },
    journal: 'ijps/',
    createjob: 'v2/wms-jrnl-createjob-new',
    nlp: 'nlp-score',
    getiAuthorLink: 'wms-sendlinkactivity-iaurl',
    getCurrentiAuthorLink: 'getCurrentiAuthorLink',
    iauthorhtml: 'https://iauthor.integra.co.in/api/',
    generateiAuthorhtml: 'generate-iauthor-html',
    updateiAuthorMoved: 'ijps/update-journal-job-moved-to-wms',
    checkiAuthorStatus: 'wms-checkactivity-status',
    getiAuthorActivityFiles: 'v2/get-iactivity-files',
    clientid: 'WMS',
    apikey: '84B9A8C7-FDEA-47DC-B1CF-845FD79C4E05',
  },
  camnunda: {
    base_url: process.env.CAMUNDA_BASEURL,
    uri: {
      claimTask: 'claimtask',
      unClaim: 'unclaimtask',
      completeTask: 'commonCompleteTask',
      fileUpload: 'upload',
      startInstance: 'startinstance',
      reset: 'postModification',
    },
  },
  camnundaNative: {
    base_url: process.env.CAMUNDA_NATIVE_URL,
    uri: {
      externalTask: {
        query: 'external-task/',
        lock: 'external-task/{{id}}/lock/',
        complete: 'external-task/{{id}}/complete/',
        resetModification: 'process-instance/{{id}}/modification',
      },
      parallelReset: 'modification/execute',
      activieInstance: 'process-instance/{{id}}/activity-instances',
      getStageInfo:
        'process-instance/{{id}}/variables/__stageInfo__?deserializeValue=false',
      putStageInfo: 'process-instance/{{id}}/variables/__stageInfo__',
      putActivityStageInfo:
        'task/{{id}}/variables/__stageInfo__?deserializeValue=false',
    },
  },
  openKM: {
    base_url: process.env.OKM_BASEURL,
    base_out_url: process.env.OKM_BASEURL_OUT,
    uri: {
      delete: 'delete',
      ischeckout: 'ischeckout',
      viewFile: 'viewdocument/',
      download: 'downloaddocument/',
      getFileDetails: 'getFileDetails/',
      checkin: 'checkin',
      downloadwithCheckout: '/downloadwithCheckout',
      upload: 'upload',
    },
  },
  okmNative: {
    base_url: process.env.OKM_NATIVEURL,
    uri: {
      getUuid: 'repository/getNodeUuid/',
      retreiveFiles: 'search/find/',
      getDocumentProps: 'document/getProperties/',
      checkout: 'document/checkout/',
      checkin: 'document/checkin/',
      createFolder: 'folder/createSimple/',
      createFile: 'document/createSimple/',
      documentCopy: 'document/extendedCopy/',
      documentDelete: 'document/delete/',
      restoreVersion: 'document/restoreVersion',
      extendedCopy: 'folder/extendedCopy',
      documentChildren: 'document/getChildren',
      folderCopy: 'folder/copy/',
      folderDelete: 'folder/delete/',
      folderRename: 'folder/rename',
      lock: 'document/lock',
      folderCreate: 'folder/createMissingFolders',
      folderChildren: 'folder/getChildren',
    },
  },
  trackletApi: {
    base_url: process.env.TRACKIT_URL,
    uri: {
      trackIt: 'typesetter/article/stage/v2',
    },
  },
  pkgDepositApi: {
    base_url: process.env.EMDEPOSIT_ENDPOINT,
    uri: {
      deposit_auth: 'authentication/versions/1/tickets',
      pre_pub:
        'alfresco/versions/1/nodes/23e75e57-4f46-49eb-bf10-4c8349ce53fa/children',
      post_pub:
        'alfresco/versions/1/nodes/7796a65f-7a44-4e4e-bf23-71b1d4c735df/children',
    },
  },
  iTracks: {
    switch_url: process.env.SWITCH_URL,
    base_url: process.env.ITRACKS_URL,
    service_url: process.env.ITRACKS_SERVICE,
    uri: {
      book: {
        iendpointKey: 'test',
        createJob: 'createbookjob',
        addSubJob: 'addsubjob',
        logisticEntryInsert: 'logisticentryinsert',
        logisticEntryUpdate: 'logisticentryupdate',
        logisticEntryDelete: 'logisticentrydelete',
        canWorkActivity: 'canworkactivity',
        openEntry: 'openentry',
        productionDispatch: 'productiondispatch',
        customerDispatch: 'customerdispatch',
        productionDispatchReset: 'resetProdDespatch',
      },
      journal: {
        iendpointKey: 'test',
        iendpointKey_createJob: 'KhpyP6s0ArPT5fizZ97pAg==',
        createJob: 'CreateArticle',
        iendpointKey_addStage: 'QxxnlYvH10MlmsNfO6lG0w==',
        addStage: 'Addstage',
        iendpointKey_canWorkActivity: '3SYCo7PPJ2aWgVVreGGMjA==',
        canWorkActivity: 'IssueCanworkActivity',
        iendpointKey_logisticEntryInsert: '3SYCo7PPJ2aWgVVreGGMjA==',
        logisticEntryInsert: 'IssueLogisticEntryInsert',
        iendpointKey_logisticEntryUpdate: '3SYCo7PPJ2aWgVVreGGMjA==',
        logisticEntryUpdate: 'IssueLogisticEntryUpdate',
        productionDispatch: 'IssueProductionDispatch',
        customerDispatch: 'IssueCustomerDispatch',
        productionDispatchReset: 'issueResetProdDespatch',
        mergeIssue: 'Mergeissue',
        createIssueJob: 'Createissue',
      },
    },
  },
  okm_rest: {
    baseUrl: process.env.OKM_BASEURL,
    document: {
      upload: 'upload',
    },
  },
  blob_rest: {
    base_url: process.env.BLOB_BASEURL,
    uri: {
      upload: 'document/checkin',
      delete: 'document/delete',
      checkin: 'document/checkin',
      checkout: 'document/checkout',
      copy: 'document/extendedCopy',
      rename: 'document/rename',
      download: 'document/download',
      retreiveBlobFiles: 'document/retreiveBlobFiles',
      getProperties: 'document/getProperties',
      retreiveBlobRootList: 'document/retreiveBlobRootList',
      copyExternalBlobToBlob: 'document/copyExternalBlobToBlob',
      blobExist: '/document/isExists',
      // localupload: 'document/localcheckin',
      // localdelete: 'document/localfiledelete',
      // localcheckin: 'document/localcheckin',
      // localcheckout: 'document/localcheckout',
      // localcopy: 'document/localextendedCopy',
      // localrename: 'document/localfilerename',
      // localdownload: 'document/localdownload',
      // retreiveLocalFiles: 'document/retreivelocalFiles',
      // getlocalProperties: 'document/getlocalProperties',
      // retreiveLocalRootList: 'document/retreivelocalRootList',
    },
  },
  local_rest: {
    base_url: process.env.LOCAL_BASEURL,
    uri: {
      localupload: 'document/localcheckin',
      localdelete: 'document/localfiledelete',
      localcheckin: 'document/localcheckin',
      localcheckout: 'document/localcheckout',
      localcopy: 'document/localextendedCopy',
      localmultiplefileCopy: 'document/localmultiplefileCopy',
      localrename: 'document/localfilerename',
      localdownload: 'document/localdownload',
      retreiveLocalFiles: 'document/retreivelocalFiles',
      getlocalProperties: 'document/getlocalProperties',
      retreiveLocalRootList: 'document/retreivelocalRootList',
      copyExternalBlobToLocal: 'document/copyExternalBlobToLocal',
      copyLocalStorageToLocal: 'document/copyLocalStorageToLocal',
      localisExists: 'document/localisExists',
    },
  },
  e2e: {
    base_url: process.env.E2E_BASEURL,
    uri: {
      getIssueSequence: 'Api/getArticleSequence',
    },
  },
};
