import { query } from '../../database/postgres.js';
import {
  CreateOrUpdateuser,
  CreateOrUpdateDesigRole,
  CreateOrUpdateUserRole,
  getDuId,
  checkUserExistence,
} from '../datalayer/userUpdate.js';
import {
  insertOrUpdateAppraisalDetails,
  getIdByField,
  getQuaterDetails,
  getAppraisalType,
  getTemplateId,
} from '../datalayer/iaspireIntegration.js';

export const updateUserService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        empCode,
        empName,
        emailId,
        designationDesc,
        address1,
        phone,
        divisionDesc,
        isActive,
        l1Manager,
        category,
        bandLevel,
        doj,
        relievingDate,
        dob,
      } = info;
      const duId = await getDuId(divisionDesc);
      const designationId = await getIdByField(
        'designationdesc',
        designationDesc,
      );
      const categoryId = await getIdByField('category', category);
      const bendLevelId = await getIdByField('bandlevel', bandLevel);

      const result = await CreateOrUpdateuser(
        empCode,
        empName,
        emailId,
        designationDesc,
        designationId,
        address1,
        phone,
        duId,
        isActive,
        l1Manager,
        categoryId,
        bendLevelId,
        doj,
        relievingDate,
        dob,
      );
      if (isActive === 'true') {
        const result2 = await CreateOrUpdateDesigRole(designationDesc);
        if (result2 !== null) {
          const roleIds = result2.length >= 1 ? result2.split(',') : [result2];

          for (const roleId of roleIds) {
            await CreateOrUpdateUserRole(empCode, roleId.trim());
          }
        }

        await iaspireRoleMapping(empCode, l1Manager);

        if (
          doj != null &&
          (empCode.startsWith('IS') || empCode.startsWith('BVE'))
        ) {
          // checks the eligibility of the user for current quarter. The no of days should be grater than or equal to 15 days.
          const isEligible = await isUserEligible(doj);
          const itrackduid = await await getIdByField('duname', divisionDesc);
          if (isEligible) {
            await appraisalMapping(
              empCode,
              category,
              designationId,
              itrackduid,
              bendLevelId,
            );
          }
        }
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
const isUserEligible = async dateparam => {
  const date = new Date(dateparam);
  const quarterDetails = await getQuaterDetails(date);
  const qStartDate = new Date(quarterDetails[0]?.startdate);

  const differenceInDays = Math.floor(
    (date - qStartDate) / (1000 * 60 * 60 * 24),
  );

  return differenceInDays >= 15;
};

const iaspireRoleMapping = async (empCode, l1Manager) => {
  // Appraisee Role mapping
  const appraiseeRoleId = await getIdByField('rolename', 'Appraisee');
  await CreateOrUpdateUserRole(empCode, appraiseeRoleId.trim());

  // Appraiser Role mapping
  if (l1Manager !== null) {
    if (await checkUserExistence(l1Manager));
    {
      const appraiserRoleId = await getIdByField('rolename', 'Appraiser');
      await CreateOrUpdateUserRole(l1Manager, appraiserRoleId.trim());
    }
  }
};

const appraisalMapping = async (
  empCode,
  category,
  designationId,
  duId,
  bendLevelId,
) => {
  const currentDate = new Date();
  const quarterDetails = await getQuaterDetails(currentDate);
  const appType = await getAppraisalType(category);
  let templateId = null;
  let statusid = 1;
  if (appType.toUpperCase() === 'QPR') {
    templateId = await getTemplateId(designationId, duId, bendLevelId);
    statusid = 2;
  }
  // Inserting or updating appraisal details
  await insertOrUpdateAppraisalDetails(
    empCode,
    quarterDetails[0]?.quartercode,
    appType,
    statusid,
    templateId,
    quarterDetails[0]?.deadline,
  );
};

export const createRatingGroupService = ratingGroupDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { groupname, isactive, createdby } = ratingGroupDetail;
      const script = `INSERT INTO iaspire.mst_rating_group(
         groupname, isactive, created_by)
        VALUES ( $1, $2, $3);`;
      const result = await query(script, [groupname, isactive, createdby]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createOrUpdateRatingService = ratingDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        valueid,
        groupid,
        minvalue,
        maxvalue,
        isactive,
        createdby,
        updatedby,
      } = ratingDetail;
      let script;
      let value = [];
      if (valueid) {
        script = `UPDATE iaspire.mst_rating_value
        SET  minvalue=$3, maxvalue=$4, updated_by=$5
        WHERE valueid = $1 AND groupid = $2`;
        value = [valueid, groupid, minvalue, maxvalue, updatedby];
      } else {
        script = `INSERT INTO iaspire.mst_rating_value(
           groupid, minvalue, maxvalue, isactive, created_by)
          VALUES ($1,$2,$3,$4,$5);`;
        value = [groupid, minvalue, maxvalue, isactive, createdby];
      }
      const result = await query(script, value);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteRatingValueService = ratingDetail => {
  return new Promise(async (resolve, reject) => {
    try {
      const { valueid, groupid } = ratingDetail;
      const script = `UPDATE iaspire.mst_rating_value
      SET  isactive=false
      WHERE valueid = $1 AND groupid = $2`;
      const result = await query(script, [valueid, groupid]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
