import express from 'express';
import swaggerUi from 'swagger-ui-express';
import { readFileSync } from 'fs';
// import {
//   validateArrRequestBody,
//   validateRequestBody,
//   validateRequestParams,
// } from '../helpers/middleware.js';
import {
  createOrUpdateRatingValueController,
  createRatingGroupController,
  deleteRatingValueController,
  updateUserController,
} from '../controller/index.js';

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}

const iAspireRouter = express.Router();
swaggerDocs(iAspireRouter);
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

iAspireRouter.post('/userUpdation', handler(updateUserController));
iAspireRouter.post('/ratinggroup', handler(createRatingGroupController));
iAspireRouter.post('/deleterating', handler(deleteRatingValueController));
iAspireRouter.post(
  '/ratingvalue',
  handler(createOrUpdateRatingValueController),
);

export default iAspireRouter;
