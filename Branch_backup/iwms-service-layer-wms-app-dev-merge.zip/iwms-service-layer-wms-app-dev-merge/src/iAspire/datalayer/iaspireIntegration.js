import { query } from '../../database/postgres.js';

export const getAppraisalType = async category => {
  const appType = await query(
    'SELECT app_type FROM iaspire.mst_appraisaltype WHERE trim(upper(category)) = trim(upper($1)) AND isactive = true',
    [category],
  );
  return appType[0]?.app_type;
};

export const getQuaterDetails = async date => {
  let quarterDetails = await query(
    'SELECT * FROM iaspire.mst_quarters WHERE $1 BETWEEN startdate AND enddate',
    [date],
  );
  if (quarterDetails?.length === 0)
    quarterDetails = await query(
      'SELECT * FROM iaspire.mst_quarters WHERE isactive = true',
      [date],
    );
  return quarterDetails;
};

export const getTemplateId = async (designationId, duId, bendLevelId) => {
  const templateDetails = await query(
    `SELECT templateid FROM iaspire.trn_qpr_template WHERE duid = $1 AND designationid = $2 AND bandlevelid = $3 AND isactive = true`,
    [duId, designationId, bendLevelId],
  );
  return templateDetails[0]?.templateid;
};

// Function to check if the Appraisal record exists
const checkAppraisalRecordExists = async (empCode, quartercode) => {
  const existsResult = await query(
    `SELECT 1 FROM iaspire.trn_appraisalmapping
      WHERE trim(upper(employeecode)) = trim(upper($1)) AND quartercode = $2 AND isactive = true`,
    [empCode, quartercode],
  );
  return existsResult?.length !== 0;
};

export const insertOrUpdateAppraisalDetails = async (
  empCode,
  quartercode,
  appType,
  statusid,
  templateId,
  deadline,
) => {
  const existingRecord = await checkAppraisalRecordExists(empCode, quartercode);
  if (!existingRecord) {
    await query(
      `INSERT INTO iaspire.trn_appraisalmapping(employeecode, quartercode, appraisaltype, statusid, templateid, deadline, created_by) VALUES ($1, $2, $3, $4, $5, $6, 'iStrong')`,
      [empCode, quartercode, appType, statusid, templateId, deadline],
    );
  } else {
    await query(
      `UPDATE iaspire.trn_appraisalmapping
        SET
          appraisaltype = COALESCE($3, appraisaltype),
          statusid = $4,
          templateid = $5,
          updated_by = 'iStrong'
      WHERE trim(upper(employeecode)) = trim(upper($1)) AND trim(upper(quartercode)) = trim(upper($2))`,
      [empCode, quartercode, appType, statusid, templateId],
    );
  }
  return true;
};

// Function to fetch the ID based on the field and value
export const getIdByField = async (fieldName, fieldValue) => {
  let tableName;
  let idField;
  switch (fieldName) {
    case 'designationdesc':
      tableName = 'public.mst_designation';
      idField = 'designationid';
      break;
    case 'category':
      tableName = 'iaspire.mst_appraisaltype';
      idField = 'categoryid';
      break;
    case 'bandlevel':
      tableName = 'public.mst_bandlevel';
      idField = 'bandlevelid';
      break;
    case 'rolename':
      tableName = 'public.wms_role';
      idField = 'roleid';
      break;
    case 'duname':
      tableName = 'public.mst_deliveryunit';
      idField = 'duid';
      break;
    default:
      throw new Error('Invalid field name');
  }

  const queryResult = await query(
    `SELECT ${idField} FROM ${tableName} WHERE trim(upper(${fieldName})) = trim(upper($1)) AND isactive = true`,
    [fieldValue],
  );
  if (
    queryResult?.length === 0 &&
    (fieldName === 'designationdesc' || fieldName === 'bandlevelid')
  ) {
    await query(
      `INSERT INTO ${tableName} (${fieldName}, created_by) VALUES ($1, 'iStrong')`,
      [fieldValue],
    );
  }
  return queryResult[0]?.[idField];
};
