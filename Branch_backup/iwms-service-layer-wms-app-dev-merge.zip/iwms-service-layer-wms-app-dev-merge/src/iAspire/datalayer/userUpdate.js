import { query } from '../../database/postgres.js';

export const CreateOrUpdateuser = (
  empCode,
  empName,
  emailId,
  designationDesc,
  designationId,
  address1,
  phone,
  duId,
  isActive,
  l1Manager,
  categoryId,
  bendLevelId,
  doj,
  relievingDate,
  dob,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const userExists = await checkUserExistence(empCode);
      if (userExists) {
        // User exists, perform the update operation here
        if (process.env.MODE == 'dev' || process.env.MODE == 'test') {
          await query(
            `UPDATE public.wms_user
              SET
                username = COALESCE($2, username),
                designation = COALESCE($3, designation),
                useraddress = COALESCE($4, useraddress),
                userphone = COALESCE($5, userphone),
                useractive = COALESCE($6, useractive),
                reportingto = COALESCE($7, reportingto),
                categoryid = COALESCE($8, categoryid),
                bandlevelid = COALESCE($9, bandlevelid),
                doj = COALESCE($10, doj),
                relievingdate = COALESCE($11, relievingdate),
                dob = COALESCE($12, dob),
                designationid = COALESCE($13, designationid)
            WHERE trim(upper(userid)) = trim(upper($1))`,
            [
              empCode,
              empName,
              designationDesc,
              address1,
              phone,
              isActive,
              l1Manager,
              categoryId,
              bendLevelId,
              doj,
              relievingDate,
              dob,
              designationId,
            ],
          );
        } else {
          await query(
            `UPDATE public.wms_user
              SET
                username = COALESCE($2, username),
                useremail = COALESCE($3, useremail),
                designation = COALESCE($4, designation),
                useraddress = COALESCE($5, useraddress),
                userphone = COALESCE($6, userphone),
                useractive = COALESCE($7, useractive),
                reportingto = COALESCE($8, reportingto),
                categoryid = COALESCE($9, categoryid),
                bandlevelid = COALESCE($10, bandlevelid),
                doj = COALESCE($11, doj),
                relievingdate = COALESCE($12, relievingdate),
                dob = COALESCE($13, dob),
                designationid = COALESCE($14, designationid)
            WHERE trim(upper(userid)) = trim(upper($1))`,
            [
              empCode,
              empName,
              emailId,
              designationDesc,
              address1,
              phone,
              isActive,
              l1Manager,
              categoryId,
              bendLevelId,
              doj,
              relievingDate,
              dob,
              designationId,
            ],
          );
        }
      } else {
        // User does not exist, perform the insert operation here
        await query(
          `INSERT INTO public.wms_user(userid,username,userpassword,useractive,useremail,duid,designation,countryid,useraddress,userphone,usertype,issuperuser,mappedduid, reportingto, categoryid, bandlevelid, doj, relievingdate, dob,designationid)
          VALUES ($1,$2,NULL,$3,$4,$5,$6,1,$7,$8,NULL,FALSE,NULL,$9,$10,$11,$12,$13,$14,$15)`,
          [
            empCode,
            empName,
            isActive,
            emailId,
            duId,
            designationDesc,
            address1,
            phone,
            l1Manager,
            categoryId,
            bendLevelId,
            doj,
            relievingDate,
            dob,
            designationId,
          ],
        );
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

// Function to check if the user exists
export const checkUserExistence = async empCode => {
  const existsResult = await query(
    `SELECT 1 FROM public.wms_user WHERE trim(upper(userid)) = trim(upper($1))`,
    [empCode],
  );
  return existsResult?.length !== 0;
};

export const getDuId = divisionDesc => {
  return new Promise(async (resolve, reject) => {
    try {
      let duId = await query(
        `SELECT WmsMst.duid FROM public.mst_deliveryunit as iDUmst
        JOIN public.org_mst_deliveryunit WmsMst on iDUmst.duid = WmsMst.itrackduid 
        WHERE trim(upper(iDUmst.duname)) = trim(upper($1)) and iDUmst.isactive = true and WmsMst.isactive = true`,
        [divisionDesc],
      );

      if (duId?.length === 0 && divisionDesc !== '') {
        duId = await query(
          'SELECT duid FROM public.org_mst_deliveryunit WHERE trim(upper(duname)) = trim(upper($1))',
          [divisionDesc],
        );
        /* const itracksDuExists = await query(
          'SELECT 1 FROM public.mst_deliveryunit WHERE trim(upper(duname)) = trim(upper($1))',
          [divisionDesc],
        );
        if (itracksDuExists?.length === 0) {
          const itracksDuId = await query(
            `INSERT INTO public.mst_deliveryunit (
            duid, duname, isactive, created_by, created_time, updated_by, updated_time)
            VALUES (nextval('public.mst_deliveryunit_duid_seq'), $1, true, 'iStrong', NOW(), NULL, NULL) RETURNING duid`,
            [divisionDesc],
          );

          const wmsDuExists = await query(
            'SELECT 1 FROM public.org_mst_deliveryunit WHERE trim(upper(duname)) = trim(upper($1))',
            [divisionDesc],
          );
          if (wmsDuExists?.length === 0) {
            duId = await query(
              `INSERT INTO public.org_mst_deliveryunit(
                      duid, duname, isactive, dualias, iduid, itrackduid)
                      VALUES (nextval('public.org_mst_deliveryunit_duid_seq'), $1, true, NULL, NULL, $2) RETURNING duid`,
              [divisionDesc, itracksDuId[0]?.duid || null],
            );
          }
        } */
      }
      resolve(duId[0]?.duid);
    } catch (error) {
      reject(error);
    }
  });
};

export const CreateOrUpdateDesigRole = designationDesc => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        'SELECT 1 FROM iquality.trn_istrongDesignationRoleMapping WHERE trim(upper(designation)) = trim(upper($1))',
        [designationDesc],
      );

      let role_id;

      if (result?.length !== 0) {
        // Designation exists, select the role IDs
        const roles = await query(
          'SELECT roleId FROM iquality.trn_istrongDesignationRoleMapping WHERE trim(upper(designation)) = trim(upper($1))',
          [designationDesc],
        );

        // Combine the role IDs into a comma-separated string
        role_id = await roles.map(role => role.roleid).join(', ');
      } else {
        // Designation doesn't exist, insert a new record and return the role ID
        const roleId = await query(
          'INSERT INTO iquality.trn_istrongDesignationRoleMapping (designation, roleId) VALUES ($1, NULL) RETURNING roleId',
          [designationDesc],
        );
        role_id = roleId;
      }
      resolve(role_id);
    } catch (error) {
      reject(error);
    }
  });
};

// Function to check if the user-role relationship exists
const checkUserRoleExistence = async (empCode, roleId) => {
  const existsResult = await query(
    `SELECT 1 FROM public.wms_userrole
    WHERE trim(upper(userid)) = trim(upper($1)) AND roleid = $2`,
    [empCode, roleId],
  );
  return existsResult?.length !== 0;
};

// Function to fetch the next userroleid
const fetchNextUserRoleId = async () => {
  const userroleidResult = await query(
    `SELECT max(userroleid) + 1 as userroleid FROM public.wms_userrole`,
  );
  return userroleidResult[0]?.userroleid;
};

export const CreateOrUpdateUserRole = (empCode, roleId) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (!(await checkUserRoleExistence(empCode, roleId))) {
        const userroleId = await fetchNextUserRoleId();

        await query(
          `INSERT INTO public.wms_userrole(userroleid,userid,roleid,effectivedate,isactive,isdefault)
          VALUES ($1,$2,$3,CURRENT_DATE,TRUE,FALSE)`,
          [userroleId, empCode, roleId],
        );
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
