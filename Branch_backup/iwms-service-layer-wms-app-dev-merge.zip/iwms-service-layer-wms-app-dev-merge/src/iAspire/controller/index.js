import logger from '../../modules/utils/logs/index.js';
import {
  createOrUpdateRatingService,
  createRatingGroupService,
  deleteRatingValueService,
  updateUserService,
} from '../service/index.js';

export const updateUserController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await updateUserService(payload);
    res.status(200).send(result);
  } catch (error) {
    logger.info('Update User controller : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createRatingGroupController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createRatingGroupService(payload);
    res.status(200).send(result);
  } catch (error) {
    logger.info('reateRatingGroupController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const createOrUpdateRatingValueController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await createOrUpdateRatingService(payload);
    res.status(200).send(result);
  } catch (error) {
    logger.info('createOrUpdateRatingValueController: ', error);
    res.status(400).send({ error, message: error?.message });
  }
};

export const deleteRatingValueController = async (req, res) => {
  try {
    const payload = req.body;
    const result = await deleteRatingValueService(payload);
    res.status(200).send(result);
  } catch (error) {
    logger.info('deleteRatingValueController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
