import Joi from 'joi';

export const searchforfeedbackSchema = Joi.object({
  bookcode: Joi.string().allow('').required(),
  jobcardcode: Joi.number().allow(null).required(),
  jobtitle: Joi.string().allow('').required(),
  fromdate: Joi.date().allow(null).required(),
  todate: Joi.date().allow(null).required(),
  divisions: Joi.number().allow(null).required(),
  customers: Joi.number().allow(null).required(),
  companyid: Joi.number().allow(null).required(),
  searchby: Joi.string().allow('').required(),
  isbn: Joi.string().allow('').required(),
  jobcardid: Joi.number().allow(null).required(),
});

export const getCustomerByDuIdSchema = Joi.object({
  divid: Joi.number().min(1).required(),
});

export const bookCCASchema = Joi.object({
  feedbackdesc: Joi.string().required(),
  shortdesc: Joi.string().allow(''),
  jobCardID: Joi.number().required(),
  stageID: Joi.number().required(),
  created_by: Joi.string().alphanum().required(),
  compNo: Joi.number().required(),
  receivedFrom: Joi.string().required(),
  mode: Joi.number().required(),
  receivedDate: Joi.string().required(),
  isOnHold: Joi.boolean().required(),
  isChargeBack: Joi.boolean().required(),
  despatchedDate: Joi.date().allow(null),
  divisionId: Joi.number().required(),
  subDivisionID: Joi.number().required(),
  amount: Joi.number().allow(null),
  currencyId: Joi.number().allow(null),
  remarks: Joi.string().allow(null),
  fromDivId: Joi.number().allow(null),
  fromSubDivId: Joi.number().allow(null),
  fromSkillId: Joi.number().allow(null),
  toDivId: Joi.number().allow(null),
  toSubDivId: Joi.number().allow(null),
  toSkillId: Joi.number().allow(null),
  errId: Joi.number().allow(null),
  isErrCatFalls: Joi.boolean().required(),
  feedbacktype: Joi.string().allow(''),
  NOC_Id: Joi.number().allow(null),
  process_Id: Joi.number().allow(null),
  bookpartId: Joi.number().allow(null),
  elementId: Joi.number().allow(null),
  typeofeditingID: Joi.number().allow(null),
  parameter: Joi.string().allow(''),
  errortype: Joi.string().allow(''),
  severityID: Joi.number().allow(null),
  others: Joi.string().allow(''),
  others_remarks: Joi.string().allow(''),
  raised_by: Joi.string().allow(''),
});

export const getD1EmpDetailsSchema = Joi.object({
  searchBy: Joi.string().allow(null),
});

export const getD1TeamSchema = Joi.object({
  feedBackID: Joi.number().required().min(0),
});

const D1teamDetailsSchema = Joi.object({
  feedBackID: Joi.number().required(),
  userId: Joi.string().required(),
  ischampion: Joi.boolean().required(),
  createdBy: Joi.string().required(),
});

export const D1teamDetailsArrSchema = Joi.array().items(D1teamDetailsSchema);
export const modifyCCASchema = Joi.object({
  feedbackId: Joi.number().required(),
  feedbackdesc: Joi.string(),
  feedbackshortdesc: Joi.string().allow(''),
  updated_by: Joi.string().required().min(3),
  chargeback: Joi.boolean().required(),
  divisionId: Joi.number().required().min(1),
  subDivisionId: Joi.number().required().min(1),
  amount: Joi.number().allow(null),
  currencyId: Joi.number().allow(null),
  remarks: Joi.string().allow(''),
});
export const FeedbackIdSchema = Joi.object({
  fId: Joi.number().min(1).required(),
});

export const viewFeedbackSchema = Joi.object({
  searchData: Joi.string().allow('').required(),
  formDate: Joi.allow(null),
  toDate: Joi.allow(null),
  searchType: Joi.string().allow('').required(),
});

export const d3createSchema = Joi.object({
  payload: Joi.object({
    feedbackId: Joi.number().required(),
    intrmackCust: Joi.string().allow(''),
    intrmVerifications: Joi.string().allow(''),
    intrmSentDate: Joi.date().required(),
    intrmReceivedDate: Joi.date().required(),
    sentBy: Joi.string().allow('').required(),
    createdBy: Joi.string().required(),
    integraProb: Joi.boolean().required(),
    verification: Joi.string().allow(''),
    fromScreen: Joi.string().allow(''),
  }).required(),
  fileUrls: Joi.array().items(Joi.any()), // Modify this according to the expected schema for the array items.
});

export const createDuMappingSchema = Joi.object({
  feedbackId: Joi.number().required(),
  divisionId: Joi.number().required(),
  subDivisionTd: Joi.number().required(),
  skillId: Joi.number().allow(null),
  errserial: Joi.number().required(),
  createdBy: Joi.string().required(),
});
export const DivisionMappingIdSchema = Joi.object({
  DMId: Joi.number().min(1).required(),
});
export const getD5RouteCauseSchema = Joi.object({
  SvnDID: Joi.number().required(),
  SID: Joi.number().required(),
});
export const updateD5Schema = Joi.object({
  CauseDetID: Joi.number().required().allow(null),
  ActionId: Joi.number().required().allow(null),
  TargetDate: Joi.date().required(),
  ActualCompDate: Joi.date().required().allow(null),
  ActionDesc: Joi.string().required().allow(''),
  TypeID: Joi.number().required().min(1),
  createdBy: Joi.string().required(),
  EmpId: Joi.string().required(),
  serialId: Joi.number().required(),
  svndId: Joi.number().required(),
});
export const deleteD5Schema = Joi.object({
  CauseDetID: Joi.number().required().min(1),
  ActionID: Joi.number().required().min(1),
  TypeID: Joi.string().required().max(1),
});
export const reopenD5Schema = Joi.object({
  ActionID: Joi.number().required().min(1),
  EntryBy: Joi.string().required(),
});
export const D5HdsUpdateSchema = Joi.object({
  FeedbackId: Joi.string().required(),
  SvnDID: Joi.number().required(),
  SerialNo: Joi.number().required(),
  HdsIsRequired: Joi.boolean().required(),
  HdsRemarks: Joi.string().required().allow(''),
  createdBy: Joi.string().required(),
});

export const getD4AempDetailSchema = Joi.object({
  empType: Joi.string().allow(null),
  searchBy: Joi.string().allow(null),
});
export const getSeveritydataSchema = Joi.object({
  severityType: Joi.string().required(),
  feedBackID: Joi.string().required(),
});
export const InsertCompSeveritySchema = Joi.object({
  Feedbackid: Joi.number().required(),
  Severity: Joi.number().required(),
  SeveritycatID: Joi.number().required(),
  createdBy: Joi.string().required(),
});
export const DeleteCompSeveritySchema = Joi.object({
  Feedbackid: Joi.number().required(),
  ComplaintSeverityID: Joi.number().required(),
});
export const InsertChargeBackSchema = Joi.object({
  EmpChargeBackId: Joi.number().required().allow(null),
  ComplaintId: Joi.number().required(),
  EmpId: Joi.string().required(),
  ResourceType: Joi.string().required(),
  CurrencyType: Joi.string().required(),
  ChargeBackAmount: Joi.string().required(),
  EntryBy: Joi.string().required(),
});

export const DashboardResponsibleSchema = Joi.object({
  empID: Joi.string().required(),
  type: Joi.string().required(),
});
export const DashboardAssignedSchema = Joi.object({
  empID: Joi.string().required(),
  type: Joi.string().required(),
  module: Joi.string().required(),
});
export const DashboardComplaintTeamSchema = Joi.object({
  empID: Joi.string().required(),
  module: Joi.number().required(),
  type: Joi.string().required(),
});
export const viewToDuSchema = Joi.object({
  fID: Joi.number().required(),
});
export const removeFileByFileName = Joi.object({
  filename: Joi.string().required(),
});
export const getD1toD7FlowSchema = Joi.object({
  FID: Joi.string().required(),
  CurrentStatus: Joi.string().required(),
  SID: Joi.string().required(),
  SLID: Joi.string().required(),
});
