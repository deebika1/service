export const getSimpleTableDataWithPagination = (
  query,
  script,
  values,
  searchInfo,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      let totalData;
      let tableData;
      const { recordPerPage, pageNo } = searchInfo;
      const offset = recordPerPage * (pageNo - 1) + 1;
      const limit = pageNo * recordPerPage;
      //   const script =
      //     'select * from iquality.status_search_for_appreciation($1,$2,$3)';
      const scriptWithOffSet = `${script} where serial between ${offset} and ${limit}`;
      if (values.length > 0) {
        totalData = await query(script, values);
        tableData = await query(scriptWithOffSet, values);
      } else {
        totalData = await query(script);
        tableData = await query(scriptWithOffSet);
      }
      const total = totalData.length;
      const numOfPages = Math.ceil(total / recordPerPage);
      resolve({ result: tableData, totalresult: totalData, total, numOfPages });
    } catch (error) {
      reject(error);
    }
  });
};

export const getFeedbackIDFromFDNO = out => {
  const feedbackID = out[0].svnd_insertfeedback;
  let id = out[0].svnd_insertfeedback;
  // Match a dash followed by one or more digits, and capture the digits
  const regex = /-(\d+)-/;
  const match = feedbackID.match(regex);
  if (match && match[1]) {
    // Convert the captured string to an integer
    id = parseInt(match[1], 10);
  }
  return id;
};
