import { readFileSync } from 'fs';
import express from 'express';
import swaggerUi from 'swagger-ui-express';
import {
  validateArrRequestBody,
  validateRequestBody,
  validateRequestParams,
} from '../helpers/middleware.js';

import {
  searchforfeedbackSchema,
  getCustomerByDuIdSchema,
  getD1EmpDetailsSchema,
  D1teamDetailsArrSchema,
  getD1TeamSchema,
  modifyCCASchema,
  FeedbackIdSchema,
  d3createSchema,
  createDuMappingSchema,
  DivisionMappingIdSchema,
  getD5RouteCauseSchema,
  updateD5Schema,
  deleteD5Schema,
  reopenD5Schema,
  D5HdsUpdateSchema,
  getD4AempDetailSchema,
  getSeveritydataSchema,
  InsertCompSeveritySchema,
  DeleteCompSeveritySchema,
  InsertChargeBackSchema,
  DashboardResponsibleSchema,
  DashboardAssignedSchema,
  DashboardComplaintTeamSchema,
  viewToDuSchema,
  removeFileByFileName,
  getD1toD7FlowSchema,
} from '../helpers/validation.js';

import {
  welcomeController,
  FeedbackDUMappingController,
  viewDuMappingController,
  searchforfeedbackController,
  getDuController,
  getCustomerByDuIdController,
  getSearchOptionsController,
  getCurrencyController,
  getD1EmployeeDetailsController,
  createD1TeamController,
  getD1TeamController,
  viewFeedbackController,
  searchAppreciationPosController,
  modifyCCAController,
  getCCADetailsController,
  getOlditracks,
  createFeedbackController,
  getD2ProbDefController,
  createD2Controller,
  getD2JobCountController,
  getD2JobdetailController,
  CreateD3Controller,
  getD3DetailsController,
  errorCatRemoveController,
  getApprDetailsController,
  ApprDUMappingController,
  getApprDUDetailsController,
  getD4detailController,
  insertd4ACausesController,
  getsvnDIDController,
  D5actiondrpdwnController,
  D5rootcausedrpdwnController,
  getD5dataController,
  updateD5Controller,
  deleteD5Controller,
  reopenD5Controller,
  insertApprDUMappingController,
  updateApprDUMappingController,
  getAwardsMasterController,
  getAppreDetailsAwardsController,
  deleteApprEmpMapController,
  updateApprAwardController,
  d5HdsUpdateController,
  getD4aDetailsController,
  getD4aColumnsController,
  createD4aDetailsController,
  createD4aWhyController,
  getD4aWhyCategoryController,
  getD4AEmpDetailController,
  createD4aWhyEmpDetailController,
  getD4aWhyController,
  getD4BDetailController,
  insertD6Controller,
  getRootCauseController,
  get6dDataController,
  getDUErrorStatusController,
  getD7dataController,
  getD7DropdownDetailsController,
  createD7Controller,
  closeFeedbackController,
  getd5StatusController,
  getSeverityController,
  getSeverityDataController,
  InsertCompSeverityController,
  DeleteCompSeverityController,
  getChargeBackResourceTypeController,
  getChargeBackController,
  InsertEmpChargeBackController,
  getD4WhyEmpDetailsController,
  deleteD4BCauseDetailsController,
  mailTriggerController,
  getRpEmpTypeDDController,
  getReportDuDDController,
  getReportEmpDDController,
  getReportController,
  getiQualityFolderPath,
  getFeedbackCountController,
  getResponsibleFeedbackController,
  getResponsibleAppreciationController,
  getFBActionassignedController,
  getFBAssignedDetailsController,
  getCCANotAttachedController,
  getCompaintsTeamMemberController,
  getCompaintsTeamMemberDetController,
  getInitialSeverityDataController,
  ChargeBackAttController,
  getChargeBackAttachmentController,
  SaveLevelforD2Controller,
  getLevelforD2Controller,
  getFeedbacktypeforAppReportController,
  getAppReportController,
  getToDUController,
  removeFileFromTableController,
  getICEController,
  fetchOldiTracksController,
  createWmsUserController,
  getDUEmployeeDetailsController,
  getiAspireController,
  getD7FlowStatusController,
  getApprReportEmpDDController,
  updateAttachmentcommentControler,
  updateAccountMISController,
  getApprDropdownController,
  searchAppreciationFilterController,
  getFeedbackDropdownController,
  searchFeedbackFilterController,
  getFromDUforUserController,
  getDUFeedbackDropdownController,
  getDUDropdownforD2Controller,
  UpdateLineitemD2Controller,
} from '../controller/index.js';

const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}

const iQualityRouter = express.Router();
swaggerDocs(iQualityRouter);
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };

iQualityRouter.get('/', handler(welcomeController));
// folder path
iQualityRouter.get('/folderpath', handler(getiQualityFolderPath));
// search
iQualityRouter.post(
  '/search',
  validateRequestBody(searchforfeedbackSchema),
  handler(searchforfeedbackController),
);
// currency
iQualityRouter.get('/getcurrency', handler(getCurrencyController));

iQualityRouter.get('/du', handler(getDuController));
iQualityRouter.get(
  '/customer/:divid',
  validateRequestParams(getCustomerByDuIdSchema),
  handler(getCustomerByDuIdController),
);
iQualityRouter.get('/searchoptions', handler(getSearchOptionsController));

// CCA
iQualityRouter.post('/viewfeedback', viewFeedbackController);
// CCA & ICA & IA & CA
iQualityRouter.post('/feedback', handler(createFeedbackController));

// 7D analysis
iQualityRouter.get(
  '/d1/:searchBy',
  validateRequestParams(getD1EmpDetailsSchema),
  handler(getD1EmployeeDetailsController),
);

iQualityRouter.get(
  '/d1/team/:feedBackID',
  validateRequestParams(getD1TeamSchema),
  handler(getD1TeamController),
);

iQualityRouter.post(
  '/d1',
  validateArrRequestBody(D1teamDetailsArrSchema),
  handler(createD1TeamController),
);

iQualityRouter.post(
  '/searchApprPositive',
  handler(searchAppreciationPosController),
);
iQualityRouter.post(
  '/modifyCCA',
  validateRequestBody(modifyCCASchema),
  handler(modifyCCAController),
);
iQualityRouter.get(
  '/getccadetails/:fId',
  validateRequestParams(FeedbackIdSchema),
  handler(getCCADetailsController),
);
// access olditracks Database
iQualityRouter.post('/existing', handler(getOlditracks));
iQualityRouter.post(
  '/d3create',
  validateRequestBody(d3createSchema),
  handler(CreateD3Controller),
);
iQualityRouter.get(
  '/getd3details/:fId',
  validateRequestParams(FeedbackIdSchema),
  handler(getD3DetailsController),
);
// 7D analysis - D2 Screen
iQualityRouter.get(
  '/d2/:feedBackID',
  validateRequestParams(getD1TeamSchema),
  handler(getD2ProbDefController),
);

iQualityRouter.post('/d2/createD2', handler(createD2Controller));
iQualityRouter.get(
  '/d2/getJobcount/:feedBackID',
  validateRequestParams(getD1TeamSchema),
  handler(getD2JobCountController),
);
iQualityRouter.post('/d2/SaveEscLevel', handler(SaveLevelforD2Controller));
iQualityRouter.get(
  '/d2/getEscLevel/:feedBackID',
  handler(getLevelforD2Controller),
);
iQualityRouter.get(
  '/d2/getJobcountdetail/:feedBackID',
  validateRequestParams(getD1TeamSchema),
  handler(getD2JobdetailController),
);

iQualityRouter.post('/viewDUMapping', handler(viewDuMappingController));

iQualityRouter.post('/FeedbackDUMapping', handler(FeedbackDUMappingController));
// Appreciation
iQualityRouter.get(
  '/getApprdetails/:fId',
  validateRequestParams(FeedbackIdSchema),
  handler(getApprDetailsController),
);

iQualityRouter.post(
  '/apprInsertDUMapping',
  handler(insertApprDUMappingController),
);
iQualityRouter.post(
  '/apprUpdateDUMapping',
  handler(updateApprDUMappingController),
);
iQualityRouter.get('/getAwardEligibility', handler(getAwardsMasterController));
iQualityRouter.get(
  '/getApprAwardDetails/:fID',
  handler(getAppreDetailsAwardsController),
);
iQualityRouter.get(
  '/deleteApprEmployeeMapping/:AppAwardDuSkillRelID',
  handler(deleteApprEmpMapController),
);
iQualityRouter.post(
  '/UpdateApprApprovalValues',
  handler(updateApprAwardController),
);

// DU Mapping
iQualityRouter.post(
  '/ApprDUMapping',
  validateRequestBody(createDuMappingSchema),
  handler(ApprDUMappingController),
);
iQualityRouter.get(
  '/getApprDUdetails/:fId',
  validateRequestParams(FeedbackIdSchema),
  handler(getApprDUDetailsController),
);
iQualityRouter.post(
  '/removeDivisionMapping/:DMId',
  validateRequestParams(DivisionMappingIdSchema),
  handler(errorCatRemoveController),
);
// 7D analysis - D4 screen
iQualityRouter.get(
  '/d4/:feedBackID',
  validateRequestParams(getD1TeamSchema),
  handler(getD4detailController),
);

iQualityRouter.post('/d4/createD4', handler(insertd4ACausesController));

// 7D analysis - D5 screen
iQualityRouter.get(
  '/svndID/:feedBackID',
  validateRequestParams(getD1TeamSchema),
  handler(getsvnDIDController),
);
iQualityRouter.get('/d5/actions', handler(D5actiondrpdwnController));
iQualityRouter.get(
  '/d5/routecause/:SvnDID/:SID',
  validateRequestParams(getD5RouteCauseSchema),
  handler(D5rootcausedrpdwnController),
);
iQualityRouter.get(
  '/d5/getd5data/:SvnDID/:SID',
  validateRequestParams(getD5RouteCauseSchema),
  handler(getD5dataController),
);
iQualityRouter.post(
  '/d5/insertorupdated5',
  validateRequestBody(updateD5Schema),
  handler(updateD5Controller),
);
iQualityRouter.post(
  '/d5/deleted5',
  validateRequestBody(deleteD5Schema),
  handler(deleteD5Controller),
);
iQualityRouter.post(
  '/d5/reopend5',
  validateRequestBody(reopenD5Schema),
  handler(reopenD5Controller),
);
iQualityRouter.post(
  '/d5/hdsupdate',
  validateRequestBody(D5HdsUpdateSchema),
  handler(d5HdsUpdateController),
);

// D4 endpoints
iQualityRouter.get('/d4a/columns', handler(getD4aColumnsController));
iQualityRouter.get('/d4a/details/:FID/:SID', handler(getD4aDetailsController));
iQualityRouter.get('/d4a/category', handler(getD4aDetailsController));
iQualityRouter.post('/d4a/details', handler(createD4aDetailsController));
iQualityRouter.post('/d4a/why', handler(createD4aWhyController));
iQualityRouter.get('/d4a/why/:fId/:causeDelId', handler(getD4aWhyController));
iQualityRouter.get(
  '/d4a/why/emp/:fId/:causeDelId',
  handler(getD4WhyEmpDetailsController),
);
iQualityRouter.get('/d4a/why/category', handler(getD4aWhyCategoryController));
iQualityRouter.get(
  '/d4a/:empType/:searchBy',
  validateRequestParams(getD4AempDetailSchema),
  handler(getD4AEmpDetailController),
);
iQualityRouter.post('/d4a/why/emp', handler(createD4aWhyEmpDetailController));
iQualityRouter.get(
  '/d4b/delete/:causeDelId/:empId',
  handler(deleteD4BCauseDetailsController),
);
iQualityRouter.get('/d4b/:fId/:sId', handler(getD4BDetailController));
iQualityRouter.post('/d6/insertd6', handler(insertD6Controller));

iQualityRouter.get(
  '/getRootCause/:svndId/:dimensionCode/:isApplicale',
  handler(getRootCauseController),
);

iQualityRouter.get(
  '/get6dData/:fId/:svndId/:dimensionCode/:serialno',
  handler(get6dDataController),
);
iQualityRouter.get(
  '/getDUErrorStatus/:fId',
  validateRequestParams(FeedbackIdSchema),
  handler(getDUErrorStatusController),
);

// 7D analysis-D7 Screens
iQualityRouter.get(
  '/d7/getd7data/:SvnDID',
  // validateRequestParams(getD5RouteCauseSchema),
  handler(getD7dataController),
);
iQualityRouter.get('/d7/itemdropdown', handler(getD7DropdownDetailsController));
iQualityRouter.post('/d7/createD7', handler(createD7Controller));
iQualityRouter.post('/d7/closeFeedback', handler(closeFeedbackController));
iQualityRouter.get(
  '/getD5Status/:fId/:svdId/:serialNo',
  handler(getd5StatusController),
);

// Complaint Severity
iQualityRouter.get('/getSeverity', handler(getSeverityController));
iQualityRouter.get(
  '/getSeveritydata/:severityType/:feedBackID',
  validateRequestParams(getSeveritydataSchema),
  handler(getSeverityDataController),
);
iQualityRouter.get(
  '/getInitialSeveritydata/:fID',
  handler(getInitialSeverityDataController),
);
iQualityRouter.post(
  '/insertSeverity',
  validateRequestBody(InsertCompSeveritySchema),
  handler(InsertCompSeverityController),
);
iQualityRouter.post(
  '/deleteSeverity',
  validateRequestBody(DeleteCompSeveritySchema),
  handler(DeleteCompSeverityController),
);

// ChargeBack
iQualityRouter.get(
  '/getResourceType',
  handler(getChargeBackResourceTypeController),
);
iQualityRouter.get('/getChargeBackData/:fID', handler(getChargeBackController));
iQualityRouter.post(
  '/InsertChargeBack',
  validateRequestBody(InsertChargeBackSchema),
  handler(InsertEmpChargeBackController),
);
iQualityRouter.post('/InsertAttChargeBack', handler(ChargeBackAttController));
iQualityRouter.get(
  '/getChargeBackAttachment/:fID',
  handler(getChargeBackAttachmentController),
);
// Mail Notification
iQualityRouter.post('/mailTrigger', handler(mailTriggerController));

// Reports
iQualityRouter.get('/report/empType', handler(getRpEmpTypeDDController));
iQualityRouter.get('/report/du/:userID', handler(getReportDuDDController));
iQualityRouter.get('/report/emp/:DuId', handler(getReportEmpDDController));
iQualityRouter.post('/report', handler(getReportController));
// Dashboard
iQualityRouter.get(
  '/dashboard/getFeedbackCount/:empID',
  handler(getFeedbackCountController),
);
iQualityRouter.get(
  '/dashboard/getResponsibleFB/:empID/:type',
  validateRequestParams(DashboardResponsibleSchema),
  handler(getResponsibleFeedbackController),
);
iQualityRouter.get(
  '/dashboard/getResponsibleAppreciation/:empID/:type',
  validateRequestParams(DashboardResponsibleSchema),
  handler(getResponsibleAppreciationController),
);
iQualityRouter.get(
  '/dashboard/getFBActionassigned/:empID',
  handler(getFBActionassignedController),
);
iQualityRouter.get(
  '/dashboard/getAssignedDetails/:empID/:type/:module',
  validateRequestParams(DashboardAssignedSchema),
  handler(getFBAssignedDetailsController),
);
iQualityRouter.get(
  '/dashboard/getCCANotAttached/:empID',
  handler(getCCANotAttachedController),
);
iQualityRouter.get(
  '/dashboard/getComplaintsteamMember/:empID',
  handler(getCompaintsTeamMemberController),
);
iQualityRouter.get(
  '/dashboard/getCompaintsTeamMemberDet/:empID/:module/:type',
  validateRequestParams(DashboardComplaintTeamSchema),
  handler(getCompaintsTeamMemberDetController),
);

// iquality - Appreciation Report
iQualityRouter.get(
  '/appreport/getFeedbacktype',
  handler(getFeedbacktypeforAppReportController),
);
iQualityRouter.post(
  '/appreport/getApprReportData',
  handler(getAppReportController),
);
iQualityRouter.get(
  '/ViewToDU/:fID',
  validateRequestParams(viewToDuSchema),
  handler(getToDUController),
);
iQualityRouter.get(
  '/Apprreport/emp/:DuId',
  handler(getApprReportEmpDDController),
);

// remove file from table
iQualityRouter.post(
  '/removefile',
  validateRequestBody(removeFileByFileName),
  handler(removeFileFromTableController),
);
iQualityRouter.get('/ice', handler(getICEController));
iQualityRouter.post('/oldWMS', handler(fetchOldiTracksController));
iQualityRouter.post('/createWmsUser', handler(createWmsUserController));
iQualityRouter.post('/iaspire', handler(getiAspireController));

// Du based employee details
iQualityRouter.get(
  '/d1appreciation/:searchBy',
  validateRequestParams(getD1EmpDetailsSchema),
  handler(getDUEmployeeDetailsController),
);

// D1 to D7 Flow
iQualityRouter.get(
  '/getD1toD7Flow/:FID/:CurrentStatus/:SID/:SLID',
  validateRequestParams(getD1toD7FlowSchema),
  handler(getD7FlowStatusController),
);
iQualityRouter.post('/accountMIS', handler(updateAccountMISController));

// D2 Attachment with comment
iQualityRouter.post(
  '/d2/updateAttachComment',
  handler(updateAttachmentcommentControler),
);
iQualityRouter.post('/getApprDropdown', handler(getApprDropdownController));
iQualityRouter.post(
  '/searchAppreciationFilter',
  handler(searchAppreciationFilterController),
);
iQualityRouter.post(
  '/getFeedbackDropdown',
  handler(getFeedbackDropdownController),
);
iQualityRouter.post(
  '/searchFeedbackFilter',
  handler(searchFeedbackFilterController),
);

// get base du for FromDU and ToDU in ICA Others option
iQualityRouter.get(
  '/getFromDUforUser/:userID',
  handler(getFromDUforUserController),
);
iQualityRouter.post(
  '/getDUFeedbackDropdown',
  handler(getDUFeedbackDropdownController),
);
// get DU dropdown details for D2 screen
iQualityRouter.get('/getDUforD2/:fID', handler(getDUDropdownforD2Controller));
iQualityRouter.post('/updateLineItem', handler(UpdateLineitemD2Controller));

export default iQualityRouter;
