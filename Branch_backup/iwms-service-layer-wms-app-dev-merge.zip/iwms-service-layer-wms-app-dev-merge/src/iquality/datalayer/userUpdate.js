import { query } from '../../database/postgres.js';

export const CreateOrUpdateuser = (
  empcode_param,
  empname_param,
  emailid_param,
  DesignationDesc_param,
  address1_param,
  phone_param,
  divisiondesc_param,
  isActive,
  L1Manager,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const duid = await isDUexist(divisiondesc_param);
      const userExists = await query(
        'SELECT 1 FROM public.wms_user WHERE trim(upper(userid)) = trim(upper($1))',
        [empcode_param],
      );
      if (userExists.length !== 0) {
        // User exists, perform the update operation here
        if (process.env.MODE == 'dev' || process.env.MODE == 'test') {
          await query(
            `UPDATE public.wms_user
            SET
              username = COALESCE($2, username),
              designation = COALESCE($3, designation),
              useraddress = COALESCE($4, useraddress),
              userphone = COALESCE($5, userphone),
              useractive = COALESCE($6, useractive),
              reportingto = COALESCE($7, reportingto)
            WHERE trim(upper(userid)) = trim(upper($1))`,
            [
              empcode_param,
              empname_param,
              DesignationDesc_param,
              address1_param,
              phone_param,
              isActive,
              L1Manager,
            ],
          );
        } else {
          await query(
            `UPDATE public.wms_user
              SET
                  username = COALESCE($2, username),
                  useremail = COALESCE($3, useremail),
                  designation = COALESCE($4, designation),
                  useraddress = COALESCE($5, useraddress),
                  userphone = COALESCE($6, userphone),
                  useractive = COALESCE($7, useractive),
                  reportingto = COALESCE($8, reportingto)
             WHERE trim(upper(userid)) = trim(upper($1))`,
            [
              empcode_param,
              empname_param,
              emailid_param,
              DesignationDesc_param,
              address1_param,
              phone_param,
              isActive,
              L1Manager,
            ],
          );
        }
      } else {
        // User does not exist, perform the insert operation here
        await query(
          `INSERT INTO public.wms_user(userid,username,userpassword,useractive,useremail,duid,designation,countryid,useraddress,userphone,usertype,issuperuser,mappedduid, reportingto)
          VALUES ($1,$2,NULL,$3,$4,$5,$6,1,$7,$8,NULL,FALSE,NULL,$9)`,
          [
            empcode_param,
            empname_param,
            isActive,
            emailid_param,
            duid.length > 0 ? duid[0].duid : null,
            DesignationDesc_param,
            address1_param,
            phone_param,
            L1Manager,
          ],
        );
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

const isDUexist = divisiondesc_param => {
  return new Promise(async (resolve, reject) => {
    try {
      let vduid = await query(
        `SELECT WmsMst.duid FROM public.mst_deliveryunit as iDUmst
        JOIN public.org_mst_deliveryunit WmsMst on iDUmst.duid = WmsMst.itrackduid 
        WHERE trim(upper(iDUmst.duname)) = trim(upper($1)) and iDUmst.isactive = true and WmsMst.isactive = true`,
        [divisiondesc_param],
      );

      if (vduid.length === 0 && divisiondesc_param !== '') {
        vduid = await query(
          'SELECT duid FROM public.org_mst_deliveryunit WHERE trim(upper(duname)) = trim(upper($1))',
          [divisiondesc_param],
        );
        /* const itracksduExists = await query(
          'SELECT 1 FROM public.mst_deliveryunit WHERE trim(upper(duname)) = trim(upper($1))',
          [divisiondesc_param],
        );
        if (itracksduExists.length === 0) {
          const itracksduid = await query(
            `INSERT INTO public.mst_deliveryunit (
            duid, duname, isactive, created_by, created_time, updated_by, updated_time)
            VALUES (nextval('public.mst_deliveryunit_duid_seq'), $1, true, 'iStrong', NOW(), NULL, NULL) RETURNING duid`,
            [divisiondesc_param],
          );

          const WMSduExists = await query(
            'SELECT 1 FROM public.org_mst_deliveryunit WHERE trim(upper(duname)) = trim(upper($1))',
            [divisiondesc_param],
          );
          if (WMSduExists.length === 0) {
            vduid = await query(
              `INSERT INTO public.org_mst_deliveryunit(
                      duid, duname, isactive, dualias, iduid, itrackduid)
                      VALUES (nextval('public.org_mst_deliveryunit_duid_seq'), $1, true, NULL, NULL, $2) RETURNING duid`,
              [divisiondesc_param, itracksduid.rows[0]?.duid || null],
            );
          }
        } */
      }
      resolve(vduid);
    } catch (error) {
      reject(error);
    }
  });
};

export const CreateOrUpdateDesigRole = DesignationDesc_param => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        'SELECT 1 FROM iquality.trn_istrongDesignationRoleMapping WHERE trim(upper(designation)) = trim(upper($1))',
        [DesignationDesc_param],
      );

      let role_id;

      if (result.length !== 0) {
        // Designation exists, select the role IDs
        const roles = await query(
          'SELECT roleId FROM iquality.trn_istrongDesignationRoleMapping WHERE trim(upper(designation)) = trim(upper($1))',
          [DesignationDesc_param],
        );

        // Combine the role IDs into a comma-separated string
        role_id = await roles.map(role => role.roleid).join(', ');
      } else {
        // Designation doesn't exist, insert a new record and return the role ID
        const roleId = await query(
          'INSERT INTO iquality.trn_istrongDesignationRoleMapping (designation, roleId) VALUES ($1, NULL) RETURNING roleId',
          [DesignationDesc_param],
        );
        role_id = roleId;
      }
      resolve(role_id);
    } catch (error) {
      reject(error);
    }
  });
};

export const CreateOrUpdateUserRole = (empcode_param, roleId) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Check if the user and role id already exist
      const existsResult = await query(
        `SELECT 1 FROM public.wms_userrole
        WHERE trim(upper(userid)) = trim(upper($1)) AND roleid = $2`,
        [empcode_param, roleId],
      );

      if (existsResult.length === 0) {
        // Insert user-role record
        const userroleid = await query(
          `SELECT max(userroleid) + 1 FROM public.wms_userrole`,
        );
        await query(
          `INSERT INTO public.wms_userrole(userroleid,userid,roleid,effectivedate,isactive,isdefault)
          VALUES ($1,$2,$3,CURRENT_DATE,TRUE,FALSE)`,
          [userroleid, empcode_param, roleId],
        );
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};
