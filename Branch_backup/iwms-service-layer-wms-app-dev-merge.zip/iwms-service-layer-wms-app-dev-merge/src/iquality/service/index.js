/* eslint-disable */
import Request from 'request';
import { query } from '../../database/postgres.js';
import axios from 'axios';
import { getSimpleTableDataWithPagination } from '../helpers/common.js';
import { mailTriggerForiTracks } from '../../modules/iTracks/index.js';

export const welcome = () => {
  return new Promise((resolve, reject) => {
    try {
      resolve(' itrack quality welcomeController');
    } catch (error) {
      reject(error);
    }
  });
};

export const searchforfeedbackService = searchinfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        bookcode,
        jobcardcode,
        jobtitle,
        fromdate,
        todate,
        divisions,
        customers,
        companyid,
        searchby,
        isbn,
        jobcardid,
      } = searchinfo;
      const script =
        'select * from iquality.searchforfeedback($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)';
      const result = await query(script, [
        bookcode,
        jobcardcode,
        jobtitle,
        fromdate,
        todate,
        divisions,
        customers,
        companyid,
        searchby,
        isbn,
        jobcardid,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getDuService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iquality.SearchDivisionFromWO()';
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getCustomerByDuIdService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM iquality.SearchCustWithDiv($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSearchOptionsService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iquality.GetSearchOptions()';
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getCurrencyService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iquality.GetCurrencyList()';
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createFeedBackService = feedbackInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackdesc,
        shortdesc,
        jobCardID,
        stageID,
        created_by,
        compNo,
        receivedFrom,
        mode,
        receivedDate,
        isOnHold,
        isChargeBack,
        despatchedDate,
        divisionId,
        subDivisionID,
        amount,
        currencyId,
        remarks,
        fromDivId,
        fromSubDivId,
        fromSkillId,
        toDivId,
        toSubDivId,
        toSkillId,
        errId,
        isErrCatFalls,
        feedbacktype,
        NOC_Id,
        process_Id,
        bookpartId,
        elementId,
        typeofeditingID,
        parameter,
        errortype,
        severityID,
        others,
        others_remarks,
        raisedby,
        modeRemarks,
        feedbackdata,
      } = feedbackInfo;
      const script =
        'SELECT * FROM iquality.svnd_insertfeedback($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39);';
      const result = await query(script, [
        feedbackdesc,
        shortdesc,
        jobCardID,
        stageID,
        created_by,
        compNo,
        receivedFrom,
        mode,
        receivedDate,
        isOnHold,
        isChargeBack,
        despatchedDate,
        divisionId,
        subDivisionID,
        amount,
        currencyId,
        remarks,
        fromDivId,
        fromSubDivId,
        fromSkillId,
        toDivId,
        toSubDivId,
        toSkillId,
        errId,
        isErrCatFalls,
        feedbacktype,
        NOC_Id,
        process_Id,
        bookpartId,
        elementId,
        typeofeditingID,
        parameter,
        errortype,
        severityID,
        others,
        others_remarks,
        raisedby,
        modeRemarks,
        feedbackdata,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createOldWmsFeedBackService = feedbackInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackID,
        bookCode,
        jobTitle,
        jobCardID,
        customerID,
        customerName,
        countryID,
        countryName,
        autherID,
        autherName,
        peID,
        peName,
        fromDuID,
        fromDuName,
        createdBy,
      } = feedbackInfo;
      const script =
        'SELECT * FROM iquality.InsertSvnDTrnExistingWO($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15);';
      const result = await query(script, [
        feedbackID,
        bookCode,
        jobTitle,
        jobCardID,
        customerID,
        customerName,
        countryID,
        countryName,
        autherID,
        autherName,
        peID,
        peName,
        fromDuID,
        fromDuName,
        createdBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertFeedbackAttachment = (
  attachments,
  feedbackId,
  createdBy,
  fromScreen,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Convert JSON data to a string
      const json = JSON.stringify(attachments);
      const values = [json, feedbackId, createdBy, fromScreen];
      const script = 'SELECT * FROM iquality.insert_attachment($1,$2,$3,$4)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD1EmployeeDetailsService = searchBy => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [searchBy === 'all' ? ' ' : searchBy];
      const script = 'SELECT * FROM iquality.seach_empdetails($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD1TeamService = feedBackId => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [feedBackId];
      const script = 'SELECT * FROM iquality.get_empdetails($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertD1TeamService = D1teamDetailsArray => {
  return new Promise(async (resolve, reject) => {
    try {
      const deleteScript = 'SELECT * FROM  iquality.delete_svnd_team($1)';
      await query(deleteScript, [D1teamDetailsArray[0].feedBackID]);

      const insertPromises = D1teamDetailsArray.map(async D1teamDetails => {
        const { feedBackID, userId, ischampion, createdBy } = D1teamDetails;
        const insertScript =
          'SELECT * FROM iquality.insert_svnd_team($1,$2,$3,$4)';
        const result = await query(insertScript, [
          feedBackID,
          userId,
          ischampion,
          createdBy,
        ]);
        return result;
      });
      const results = await Promise.all(insertPromises);
      resolve(results);
    } catch (error) {
      reject(error);
    }
  });
};
export const modifyCCAService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackId,
        feedbackdesc,
        feedbackshortdesc,
        updated_by,
        chargeback,
        divisionId,
        subDivisionId,
        amount,
        currencyId,
        remarks,
      } = info;
      const script =
        'select * from iquality.modify_cca_details($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)';
      const result = await query(script, [
        feedbackId,
        feedbackdesc,
        feedbackshortdesc,
        updated_by,
        chargeback,
        divisionId,
        subDivisionId,
        amount,
        currencyId,
        remarks,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getCCAdetailsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM  iquality.get_cca_details($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const searchAppreciationPosService = searchInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchText, fromDate, toDate, createdBy } = searchInfo;
      // const offset = recordPerPage * (pageNo - 1) + 1;
      // const limit = pageNo * recordPerPage;
      const script = `select * from iquality.status_search_for_appreciation($1,$2,$3,$4)
        where ( '${searchText}' = ''  or trim(upper(feedbackno)) ilike (trim(upper('%${searchText}%'))))`;
      // const script1 = `select * from iquality.status_search_for_appreciation($1,$2,$3,$4) where serial between ${offset} and ${limit}`;
      const result = await query(script, ['', fromDate, toDate, createdBy]);
      // const result1 = await query(script1, [
      //   searchText,
      //   fromDate,
      //   toDate,
      //   createdBy,
      // // ]);
      // const total = result.length;
      // const numOfPages = Math.ceil(total / recordPerPage);
      resolve({ totalresult: result });
    } catch (error) {
      reject(error);
    }
  });
};

export const viewFeedbackService = searchedData => {
  return new Promise(async (resolve, reject) => {
    try {
      const { searchData, fromDate, toDate, searchType, createdBy } =
        searchedData;
      // const offset = recordPerPage * (pageNo - 1) + 1;
      // const limit = pageNo * recordPerPage;
      const script = `select * from  iquality.status_search_for_complaint($1,$2,$3,$4,$5)
        where ( '${searchData}' = ''  or trim(upper(feedbackno)) ilike (trim(upper('%${searchData}%'))))
        or ( '${searchData}' = ''  or trim(upper(jobid)) ilike (trim(upper('%${searchData}%'))))`;
      // const script1 = `select * from  iquality.status_search_for_complaint($1,$2,$3,$4,$5) where serial between ${offset} and ${limit}`;
      const result = await query(script, [
        '',
        fromDate,
        toDate,
        searchType,
        createdBy,
      ]);
      // const result1 = await query(script1, [
      //   searchData,
      //   fromDate,
      //   toDate,
      //   searchType,
      //   createdBy,
      // ]);
      // const total = result.length;
      // const numOfPages = Math.ceil(total / recordPerPage);
      resolve({ totalresult: result });
    } catch (error) {
      reject(error);
    }
  });
};

export const ActiveIPSwitchURL = function (serverName) {
  const ipswitch = process.env.IPSWITCH;
  return new Promise((resolve, reject) => {
    try {
      serverName = serverName === undefined ? 'iwmsfs' : serverName;
      let ipswitchURL = ipswitch.replace('<<serverName>>', serverName);
      Request.get(
        ipswitchURL,
        { strictSSL: false },
        (error, response, body) => {
          if (error) {
            console.log('error');
            reject('IPSwitchURL   ' + error);
          }
          resolve(body);
        },
      );
    } catch (error) {
      reject(error);
    }
  });
};
export const createD3Service = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackId,
        intrmackCust,
        intrmVerifications,
        intrmSentDate,
        intrmReceivedDate,
        sentBy,
        createdBy,
        integraProb,
        verification,
      } = info;
      const script =
        'select * from iquality.insert_svnd_d3($1,$2,$3,$4,$5,$6,$7,$8,$9)';
      const result = await query(script, [
        feedbackId,
        intrmackCust,
        intrmVerifications,
        intrmSentDate,
        intrmReceivedDate,
        sentBy,
        createdBy,
        integraProb,
        verification,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getD3detailsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM iquality.getd3details($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD2ProbDefService = feedBackId => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [feedBackId];
      const script = 'SELECT * FROM iquality.getd2details($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createD2Service = D2Data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackId,
        finalProb,
        isErrCatfalls,
        createdBy,
        updatedBy,
        probOccurred,
        affectedPerson,
        actionNeeded,
      } = D2Data;
      const errorCat = [],
        du_stmt = [];
      D2Data.errorCat.map(async arr => {
        errorCat.push(arr.slice(0, -2)); // Slice the array to exclude the last two elements
        du_stmt.push(arr.splice(7, 2)); // Create an array with the last two one element
      });

      const jsonArray = errorCat.map(arr => `"${JSON.stringify(arr)}"`);
      const updatedJson = `{${jsonArray.join(',')}}`;
      const jsonArraydu = du_stmt.map(([du, final]) => {
        return { du, final };
      });
      const updatedJsondu = JSON.stringify(jsonArraydu);

      const script = `select * from iquality.insert_svnd_d2($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`;
      const result = await query(script, [
        feedbackId,
        finalProb,
        isErrCatfalls,
        createdBy,
        updatedBy,
        updatedJson,
        probOccurred,
        affectedPerson,
        actionNeeded,
        updatedJsondu,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD2JobCountService = feedBackId => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [feedBackId];
      const script = 'SELECT * from iquality.getjobcount($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD2JobdetailService = feedBackId => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [feedBackId];
      const script = `SELECT* from iquality.getjobdetailsforcount($1)`;
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const viewDuMappingService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const { feedbackId, slNo } = param;
      const script =
        'select * from iquality.get_SvnD_ComplaintDUMapping($1,$2)';
      const result = await query(script, [feedbackId, slNo]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const FeedbackDUMappingService = finfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackId,
        divisionId,
        subDivisionTd,
        skillId,
        errserial,
        createdBy,
        accountedmis,
      } = finfo;
      const script =
        'SELECT * FROM Iquality.SvnD_FeedbackDUMapping($1,$2,$3,$4,$5,$6,$7);';
      const result = await query(script, [
        feedbackId,
        divisionId,
        subDivisionTd,
        skillId,
        errserial,
        createdBy,
        accountedmis,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getApprdetailsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM  iquality.getapprdetails($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD4detailService = feedBackId => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [feedBackId];
      const script = 'select * from iquality.get4ADetails($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const ApprDUMappingService = Ainfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackId,
        DivisionId,
        SubDivisionId,
        MappedJobFamily,
        MappedBy,
        Remarks,
      } = Ainfo;
      const script =
        'SELECT * FROM Iquality.insert_app_award_du_skill_rel($1,$2,$3,$4,$5,$6);';
      const result = await query(script, [
        feedbackId,
        DivisionId,
        SubDivisionId,
        MappedJobFamily,
        MappedBy,
        Remarks,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertd4ACausesService = d4Info => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log('d4Info', d4Info);
      const script = 'SELECT * FROM Iquality.SvnD_FeedbackDUMapping($1);';
      const result = await query(script, [d4Info]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getApprDUdetailsService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM  iquality.get_app_award_du_skill_rel($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getsvnDIDService = feedBackId => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT SvnDId FROM iquality.SvnD_trn_7DAnalysis WHERE feedbackid = ${feedBackId}`;
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const errorCatReomveService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'select * from iquality.Delete_DivisionMapping($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const D5actiondrpdwnService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        'select ActionTypeID,ActionTypeDesc from iquality.mst_ActionType where isactive = true order by ActionTypeID asc',
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const D5rootcausedrpdwnService = async (SvnDID, SID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [SvnDID, SID];
      const script = 'SELECT * from iquality.get_d5rootcause($1, $2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD5dataService = (SvnDID, SID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [SvnDID, SID];
      const script = 'SELECT * from iquality.getd5data($1,$2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateD5Service = D5data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        CauseDetID,
        ActionId,
        TargetDate,
        ActualCompDate,
        ActionDesc,
        TypeID,
        createdBy,
        EmpId,
        serialId,
        svndId,
      } = D5data;
      const script =
        'SELECT * from iquality.d5insertorupdate($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)';
      const result = await query(script, [
        CauseDetID,
        ActionId,
        TargetDate,
        ActualCompDate,
        ActionDesc,
        TypeID,
        createdBy,
        EmpId,
        serialId,
        svndId,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const insertD6Service = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        typeId,
        mode,
        actionId,
        targetDtae,
        actualCompleteDate,
        actionDesc1,
        actionDesc2,
        actionDesc3,
        causeDetId,
        entryBy,
        commaSeperatedIds,
        CommaSeperatedDUIds,
        serialId,
        svndId,
        fromScreen,
      } = info;
      const script =
        'select * from iquality.insert6d($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)';
      const result = await query(script, [
        typeId,
        mode,
        actionId,
        targetDtae,
        actualCompleteDate,
        actionDesc1,
        actionDesc2,
        actionDesc3,
        causeDetId,
        entryBy,
        commaSeperatedIds,
        CommaSeperatedDUIds,
        serialId,
        svndId,
        fromScreen,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteD5Service = D5data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { CauseDetID, ActionID, TypeID } = D5data;
      const script = 'SELECT * from  iquality.deleted5($1,$2,$3)';
      const result = await query(script, [CauseDetID, ActionID, TypeID]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const reopenD5Service = D5data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { ActionID, EntryBy } = D5data;
      const script = 'SELECT * from  iquality.d5_reopen($1,$2)';
      const result = await query(script, [ActionID, EntryBy]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const insertApprDUMappingService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        feedbackid,
        DivisionId,
        SubDivisionId,
        MappedJobFamily,
        MappedBy,
        MappedOn,
        Remarks,
        employeeID,
      } = param;
      const script =
        'SELECT * FROM  iquality.insert_app_award_du_skill_rel($1,$2,$3,$4,$5,$6,$7,$8)';
      const result = await query(script, [
        feedbackid,
        DivisionId,
        SubDivisionId,
        MappedJobFamily,
        MappedBy,
        MappedOn,
        Remarks,
        employeeID,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const updateApprDUMappingService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        AppAwardDuSkillRelID,
        AppreciationId,
        DivisionId,
        SubDivisionId,
        SkillID,
        MappedBy,
        Remarks,
        IsActive,
        employeeID,
      } = param;
      const script =
        'SELECT * FROM  iquality.update_app_award_du_skill_rel($1,$2,$3,$4,$5,$6,$7,$8,$9)';
      const result = await query(script, [
        AppAwardDuSkillRelID,
        AppreciationId,
        DivisionId,
        SubDivisionId,
        SkillID,
        MappedBy,
        Remarks,
        IsActive,
        employeeID,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAwardsMasterService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script =
        'SELECT * FROM iquality.RecommendStatus ORDER BY RecommendStatusid';
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getAppreDetailsAwardsService = fID => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [fID];
      const script =
        'SELECT * FROM iquality.get_award_appreciation_details($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteApprEmpMapService = AppAwardDuSkillRelID => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [AppAwardDuSkillRelID];
      const script =
        'SELECT * FROM  iquality.delete_appreciation_employee_mapping($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateApprAwardService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        AppAwardDuSkillRelID,
        awardStatusID,
        RecommendReason,
        RecommendedBy,
      } = param;
      const script =
        'SELECT * FROM  iquality.update_appreciation_approval_values($1,$2,$3,$4)';
      const result = await query(script, [
        AppAwardDuSkillRelID,
        awardStatusID,
        RecommendReason,
        RecommendedBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const d5HdsUpdateService = HdsData => {
  return new Promise(async (resolve, reject) => {
    try {
      // const { SvnDID, HdsIsRequired, HdsRemarks, createdBy } = HdsData;
      const {
        FeedbackId,
        SvnDID,
        SerialNo,
        HdsIsRequired,
        HdsRemarks,
        createdBy,
      } = HdsData;
      const script = 'SELECT * FROM iquality.d5hdsupdate($1,$2,$3,$4,$5,$6)';
      const result = await query(script, [
        FeedbackId,
        SvnDID,
        SerialNo,
        HdsIsRequired,
        HdsRemarks,
        createdBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD4aColumnsService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT * FROM iquality.SvnD_Masters WHERE itemtype = 'F'`;
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getD4aDetailsService = (FID, SID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [FID, SID];
      const script = 'select * from iquality.get4ADetails($1, $2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createD4aDetailsService = D4aDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        causeId,
        causeDesc,
        feedBackId,
        causeTypeID,
        createdBy,
        serialId,
      } = D4aDetails;
      const values = [
        causeId,
        causeDesc,
        feedBackId,
        causeTypeID,
        createdBy,
        serialId,
      ];
      const script =
        'SELECT iquality.insert_d4a_SvnD_Causes($1, $2, $3, $4, $5, $6)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const get6dDataService = (fId, svndId, dimensionCode, serialno) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iquality.getd6data($1,$2,$3,$4)';
      const values = [fId, svndId, dimensionCode, serialno];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createD4aWhyService = D4aWhys => {
  return new Promise(async (resolve, reject) => {
    try {
      const { whyId, causeDetailId, whyDesc, sequenceId, createdBy } = D4aWhys;
      const values = [whyId, causeDetailId, whyDesc, sequenceId, createdBy];
      const script =
        'SELECT * FROM iquality.insert_SvnD_Why($1, $2, $3, $4, $5)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getRootCauseService = (svndId, dimensionCode, isApplicale) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'select * from iquality.getd6dropdown($1,$2,$3)';
      const values = [svndId, dimensionCode, isApplicale];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD4AWhyService = (fId, causeDelId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [fId, causeDelId];
      const script = 'SELECT * FROM iquality.get_rootcause_analysis($1, $2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getD4AWhyEmpDetailService = (fId, causeDelId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [fId, causeDelId];
      const script =
        'SELECT * FROM iquality.get_rootcause_analysis_respemp($1, $2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getDUErrorStatusService = param => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [param];
      const script = 'SELECT * FROM  iquality.check_duerr_completed($1)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD4aWhyCategoryService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT masteritemid , masteritemdesc FROM iquality.SvnD_Masters WHERE itemtype = 'C' ORDER BY masteritemdesc`;
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getD7dataService = SvnDID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT * from iquality.get_svnd_d7(${SvnDID})`;
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD4AEmpDetailService = (searchBy, empType) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [searchBy === 'all' ? ' ' : searchBy, empType];
      const script = 'SELECT * FROM iquality.all_empdetails($1, $2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getD7DropdownDetailsService = searchBy => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `select masteritemid,masteritemdesc from iquality.SvnD_Masters where itemtype = '7'`;
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const createD4aRootCauseEmpService = D4aRootEmp => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        causeRespId,
        causeDetId,
        categoryId,
        empType,
        empId,
        createdBy,
        serialId,
        feedBackId,
      } = D4aRootEmp;

      // const values = [
      //   causeRespId,
      //   causeDetId,
      //   categoryId,
      //   empType,
      //   empId,
      //   createdBy,
      //   serialId,
      //   feedBackId,
      // ];
      let result = '';
      result = await query(
        `DELETE from iquality.SvnD_CauseResp where causedetid = ${causeDetId}`,
      );

      empId.map(async empID => {
        const script =
          'SELECT iquality.insert_SvnD_CauseResp($1, $2, $3, $4, $5, $6, $7, $8)';
        result = await query(script, [
          causeRespId,
          causeDetId,
          categoryId,
          empType,
          empID,
          createdBy,
          serialId,
          feedBackId,
        ]);
      });
      // const script =
      //   'SELECT iquality.insert_SvnD_CauseResp($1, $2, $3, $4, $5, $6, $7, $8)';
      // const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createD7Service = D7Data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { feedbackID, causeID, DetailType, createdBy, closeddate, closed } =
        D7Data;
      const script = `SELECT * from iquality.insert_svnd_d7($1,$2,$3,$4,$5,$6)`;
      const result = await query(script, [
        feedbackID,
        causeID,
        DetailType,
        createdBy,
        closeddate,
        closed,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD4BDetailService = (feedbackID, sId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [feedbackID, sId];
      const script = 'SELECT * FROM iquality.get_d4overalldetails($1, $2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const deleteD4BCauseDetailService = (causeDelId, empId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [causeDelId, empId];
      const script = 'SELECT * FROM  iquality.d4delete($1,$2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const closeFeedbackService = closeFeedbackData => {
  return new Promise(async (resolve, reject) => {
    try {
      const { feedbackID, createdBy } = closeFeedbackData;
      const script = `SELECT * from  iquality.feedback_close($1,$2)`;
      const result = await query(script, [feedbackID, createdBy]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getD5StatusService = (fId, svdId, serialNo) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [fId, svdId, serialNo];
      const script =
        'SELECT hds_is_required,hds_remarks FROM iquality.svnd_Horizontal WHERE feedbackid=$1 AND svndid=$2 AND serialno=$3';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getSeverityService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        'select severityid,severity,severitytype from iquality.mst_severity where isactive = true order by severityid asc',
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getSeverityDataService = (severityType, feedBackID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT ROW_NUMBER() OVER (ORDER BY m.MasterItemID) AS sno, m.MasterItemID, m.MasterItemDesc,
      true AS isEdit, CASE WHEN m.MasterItemID = cs.SeveritycatID THEN true ELSE false END AS isChecked 
      FROM iquality.svnd_masters m LEFT JOIN iquality.SvnD_ComplaintSeverity cs ON cs.SeveritycatID = m.MasterItemID 
      AND cs.feedbackid = ${feedBackID} WHERE m.itemtype='${severityType}'`;
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getInitialSeverityDataService = fID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT ROW_NUMBER() OVER (ORDER BY m.MasterItemID) AS sno, m.MasterItemID, m.MasterItemDesc,
      m.itemtype as itemtype, true AS isEdit, CASE WHEN m.MasterItemID = cs.SeveritycatID THEN true ELSE false END
      AS isChecked FROM iquality.svnd_masters m LEFT JOIN iquality.SvnD_ComplaintSeverity cs ON
      cs.SeveritycatID = m.MasterItemID AND cs.feedbackid = ${fID} WHERE m.itemtype in(select severitytype from
      iquality.mst_severity where isactive = true order by severityid asc)`;
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const InsertCompSeverityService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { Feedbackid, Severity, SeveritycatID, createdBy } = payload;
      const script =
        'SELECT * FROM iquality.insert_complaint_severity($1,$2,$3,$4)';
      const result = await query(script, [
        Feedbackid,
        Severity,
        SeveritycatID,
        createdBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const DeleteCompSeverityService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { Feedbackid, ComplaintSeverityID } = payload;
      const script = 'SELECT * FROM iquality.delete_complaint_severity($1,$2)';
      const result = await query(script, [Feedbackid, ComplaintSeverityID]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getChargeBackResourceTypeService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        `SELECT 'Primary' as Category UNION ALL SELECT 'Secondary' as Category`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getChargeBackService = fID => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        `SELECT * from iquality.get_chargeback_details(${fID})`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const InsertEmpChargeBackService = Payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        EmpChargeBackId,
        ComplaintId,
        EmpId,
        ResourceType,
        CurrencyType,
        ChargeBackAmount,
        EntryBy,
      } = Payload;
      const script =
        'SELECT * from iquality.insert_emp_chargeback($1,$2,$3,$4,$5,$6,$7)';
      const result = await query(script, [
        EmpChargeBackId,
        ComplaintId,
        EmpId,
        ResourceType,
        CurrencyType,
        ChargeBackAmount,
        EntryBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const mailTriggerService = sendData => {
  return new Promise(async (resolve, reject) => {
    try {
      // const endpointUrl = 'http://localhost:5000/api/task/mailTriggerForiTracks'
      const endpointUrl =
        process.env.NewWMSLink + '/api/task/mailTriggerForiTracks';
      // const response = await axios.post(endpointUrl, sendData);
      const response = await mailTriggerForiTracks(sendData);
      resolve(response);
    } catch (error) {
      reject(error);
    }
  });
};

// Reports
export const getRpEmpTypeDDService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        `SELECT
        'Internal' as  FeedbackType ,'IC'  as  FeedbackTypeid
        union all
        SELECT
        'External' as  FeedbackType ,'CC'  as  FeedbackTypeid
        union all
        SELECT
        'All' as  FeedbackType ,'All'  as  FeedbackTypeid`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getReportDuDDService = user => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        //       `select * from ((SELECT
        //         0 as duid,
        //         'All' as duname
        //     FROM public.wms_userrole ur
        //     LEFT JOIN public.wms_role wr ON ur.roleid = wr.roleid
        //     WHERE ur.USERID = '${user}' and wr.roleacronym IN ('CQH')
        //     )
        //     UNION ALL
        //     (SELECT
        //         omd.DuID,
        //         omd.duname
        //     FROM iquality.SvnD_trn_DivisionMapping svdma
        //     LEFT JOIN public.mst_deliveryunit omd ON omd.DuID = svdma.DivisionID
        //     LEFT JOIN public.wms_userrole ur ON ur.USERID = '${user}'
        //     LEFT JOIN public.wms_role wr ON ur.roleid = wr.roleid
        //     WHERE wr.roleacronym IN ('CQH')
        //     GROUP BY omd.DuID, omd.duname
        //     ORDER BY omd.duname
        //     )
        //     UNION ALL
        //     (
        //       SELECT
        //       om.duid,
        //       om.duname
        //   FROM public.wms_user WU
        //   LEFT JOIN public.wms_userrole UR ON WU.USERID = UR.USERID
        //   LEFT JOIN public.org_mst_deliveryunit omd ON omd.DuID = WU.DuID OR omd.DuID = ANY
        // (SELECT unnest(mappedduid) FROM wms_user  WHERE userid = '${user}')
        // 	  LEFT JOIN public.mst_deliveryunit om ON om.DuID = omd.itrackduid
        //   LEFT JOIN public.wms_role wr ON  UR.roleid = wr.roleid
        //   WHERE WU.USERID = '${user}' AND wr.roleacronym NOT IN ('CQH')
        //   GROUP BY WU.DuID, om.duname, om.duid
        //   ORDER BY om.duname) )as s group by s.duid,s.duname order by s.duid,s.duname`,
        `select * from ((SELECT omd.DuID, omd.duname
    FROM public.mst_deliveryunit omd LEFT JOIN public.wms_userrole ur ON ur.USERID = '${user}'
    LEFT JOIN public.wms_role wr ON ur.roleid = wr.roleid 
    WHERE wr.roleacronym IN ('CQH')
    GROUP BY omd.DuID, omd.duname
    ORDER BY omd.duname)
    UNION ALL
    (SELECT om.duid, om.duname
    FROM public.wms_user WU
    LEFT JOIN public.wms_userrole UR ON WU.USERID = UR.USERID
    LEFT JOIN public.org_mst_deliveryunit omd ON omd.DuID = WU.DuID OR omd.DuID = ANY 
    (SELECT unnest(mappedduid) FROM wms_user  WHERE userid = '${user}')
    LEFT JOIN public.mst_deliveryunit om ON om.DuID = omd.itrackduid
    LEFT JOIN public.wms_role wr ON  UR.roleid = wr.roleid 
    WHERE WU.USERID = '${user}' AND wr.roleacronym NOT IN ('CQH')
    GROUP BY WU.DuID, om.duname, om.duid ORDER BY om.duname))as s group by s.duid,s.duname 
    HAVING s.duid IS NOT NULL AND s.duname IS NOT NULL order by s.duname`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getReportEmpDDService = DuID => {
  return new Promise(async (resolve, reject) => {
    try {
      let result = '';
      if (DuID === '0') {
        result =
          //   await query(`select a.empid,a.username || '(' || a.empid || ')' AS username
          // from (select cr.empid,u.username from iquality.SvnD_CauseResp  cr
          // LEFT JOIN public.wms_user u on u.USERID = cr.empid
          // where (NULL is  null  or u.DuID in   (SELECT unnest(string_to_array(NULL, ','))::int) )
          // group by  cr.empid,u.username
          // union all
          // select fb.created_by as empid,u.username from iquality.SvnD_trn_feedbackmst  fb
          // LEFT JOIN public.wms_user u on u.USERID = fb.created_by
          // where (NULL is  null or u.DuID in  (SELECT unnest(string_to_array(NULL, ','))::int) )
          // group by  fb.created_by,u.username
          // )as a group by a.empid,a.username order by a.username`);
          await query(`select a.empid,a.username || '(' || a.empid || ')' AS username
        from (select cr.empid,u.username from iquality.SvnD_CauseResp  cr
        LEFT JOIN public.wms_user u on u.USERID = cr.empid
        where (NULL is  null  or u.DuID in   (SELECT unnest(string_to_array(NULL, ','))::int) )
        group by  cr.empid,u.username
        union all 
        select u.userid,u.username from public.wms_user u
        where (NULL is  null or u.DuID in  (SELECT unnest(string_to_array(NULL, ','))::int) )
        group by u.userid,u.username
        )as a group by a.empid,a.username order by a.username`);
      } else {
        result =
          //     await query(`select a.empid,a.username || '(' || a.empid || ')' AS username
          //     from (select cr.empid,u.username from iquality.SvnD_CauseResp  cr
          //     LEFT JOIN public.wms_user u on u.USERID = cr.empid
          //  LEFT JOIN public.org_mst_deliveryunit du on u.duid = du.DuID
          //  LEFT JOIN public.mst_deliveryunit d on d.DuID = du.itrackduid
          //     where ('${DuID}' is  null  or d.DuID in   (SELECT unnest(string_to_array('${DuID}', ','))::int) )
          //     group by  cr.empid,u.username
          //     union all
          //     select fb.created_by as empid,u.username from iquality.SvnD_trn_feedbackmst  fb
          //     LEFT JOIN public.wms_user u on u.USERID = fb.created_by
          // LEFT JOIN public.org_mst_deliveryunit du on u.duid = du.DuID
          //  LEFT JOIN public.mst_deliveryunit d on d.DuID = du.itrackduid
          //     where ('${DuID}' is  null or d.DuID in  (SELECT unnest(string_to_array('${DuID}', ','))::int) )
          //     group by  fb.created_by,u.username
          //     )as a group by a.empid,a.username order by a.username`);
          await query(`select a.userid as empid,a.username || '(' || a.userid || ')' AS username
          from (select u.userid,u.username from public.wms_user u
      LEFT JOIN public.org_mst_deliveryunit du on u.duid = du.DuID
      LEFT JOIN public.mst_deliveryunit d on d.DuID = du.itrackduid
          where ('${DuID}' is  null  or d.DuID in   (SELECT unnest(string_to_array('${DuID}', ','))::int) )
          group by  u.userid,u.username
          union all 
          select u.userid as empid,u.username from public.wms_user u
      LEFT JOIN public.org_mst_deliveryunit du on u.duid = du.DuID
      LEFT JOIN public.mst_deliveryunit d on d.DuID = du.itrackduid
          where ('${DuID}' is  null or d.DuID in  (SELECT unnest(string_to_array('${DuID}', ','))::int) )
          group by  u.userid,u.username
          )as a group by a.userid,a.username order by a.username`);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getReportService = reportQuery => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        fBType,
        emp,
        dateType,
        fromDate,
        toDate,
        du,
        recordPerPage,
        pageNo,
        notIntegraIssue,
        MIS,
        customer,
      } = reportQuery;
      const values = [
        fBType,
        emp,
        dateType,
        fromDate,
        toDate,
        du,
        notIntegraIssue,
        MIS,
        customer,
      ];
      const script =
        'SELECT * FROM iquality.get_feedback_report($1, $2, $3, $4, $5, $6, $7, $8, $9)';
      const result = getSimpleTableDataWithPagination(query, script, values, {
        recordPerPage,
        pageNo,
      });
      // const result = await query(script, values)
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getFeedbackCountService = empID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'SELECT * FROM iquality.feedbackcountbyemp($1)';
      const values = [empID];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getChargeBackAttachmentService = fID => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        `select JSON_AGG(JSON_BUILD_OBJECT('filename', ac.filename, 'fileurl', ac.fileurl))::text AS attachment_info
          from iquality.SvnD_attachment ac where ac.feedbackid = ${fID} and  ac.fromscreen = 'ChargeBack'`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getResponsibleFBService = (empID, type) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script =
        'SELECT * FROM  iquality.get_responsible_feedback_dashboard($1,$2)';
      const values = [empID, type];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getResponsibleAppreciationService = (empID, type) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script =
        'SELECT * FROM  iquality.get_responsible_appreciation_dashboard($1,$2)';
      const values = [empID, type];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getFBActionassignedService = empID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'select * from iquality.get_feedbacks_Actionassigned($1)';
      const values = [empID];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getFBAssignedDetailsService = (empID, type, module) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script =
        'SELECT * FROM iquality.get_feedbacks_Actionassigned_details($1,$2,$3)';
      const values = [empID, type, module];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getCCANotAttachedService = empID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT q.feedbacktype,q.no_of_compl from (
        SELECT feedbacktype,count(feedbackid) AS no_of_compl
        FROM iquality.SvnD_trn_feedbackmst
        WHERE (created_by=$1 AND created_time <= NOW() - INTERVAL '48 hours'
        AND (status < 3 or status = 0)) group by feedbacktype) as q where q.feedbacktype in ('CC','IC') order by q.feedbacktype`;
      const values = [empID];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getCompaintsTeamMemberService = empID => {
  return new Promise(async (resolve, reject) => {
    try {
      const script =
        'SELECT * FROM  iquality.get_feedbacks_for_teammembers($1)';
      const values = [empID];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getCompaintsTeamMemberDetService = (empID, module, type) => {
  return new Promise(async (resolve, reject) => {
    try {
      const script =
        'SELECT * FROM iquality.get_feedbacks_for_teammembers_details($1,$2,$3)';
      const values = [empID, module, type];
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD3AttachmentService = feedBackID => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        `select JSON_AGG(JSON_BUILD_OBJECT('filename', ac.filename, 'fileurl', ac.fileurl))::text AS attachment_info
        from iquality.SvnD_attachment ac where ac.feedbackid = ${feedBackID} and  ac.fromscreen = 'D3'`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const SaveLevelforD2Service = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      let script = '';
      if (payload.CheckedLevel === 1) {
        script = `UPDATE iquality.SvnD_trn_feedbackmst SET level1 = true, level2 = false, updated_by = '${payload.CreatedBy}',
        updated_time = current_timestamp WHERE feedbackid = ${payload.FeedbackID}`;
      } else if (payload.CheckedLevel === 2) {
        script = `UPDATE iquality.SvnD_trn_feedbackmst SET level1 = false, level2 = true, updated_by = '${payload.CreatedBy}',
        updated_time = current_timestamp WHERE feedbackid = ${payload.FeedbackID}`;
      }
      const result = await query(script);
      resolve({ msg: 'success' });
    } catch (error) {
      reject(error);
    }
  });
};
export const getToDUService = fID => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        // `select er.serialno,div.duname,sd.subdeliverydesc from iquality.SvnD_Trn_DivisionMapping d
        // LEFT JOIN  org_mst_deliveryunit div ON d.DivisionID = div.duid
        // LEFT JOIN  iquality.mst_subdeliveryunit sd ON sd.subdeliveryid = d.subdivisionid
        // Left join iquality.SvnD_trn_7DAnalysis svd on svd.feedbackid= d.feedbackid
        // Left Join iquality.SvnD_Analysis_ErrorCatRel er ON  er.SvnDID = svd.SvnDID and d.errcat = er.serialno
        // where d.feedbackid = ${fID} and d.mappingtype = 'A'and er.serialno is not null
        // GROUP BY div.duname,sd.subdeliverydesc,er.serialno`,
        `select div.duname,sd.subdeliverydesc from iquality.SvnD_Trn_DivisionMapping d
        LEFT JOIN  mst_deliveryunit div ON d.DivisionID = div.duid
        LEFT JOIN  iquality.mst_subdeliveryunit sd ON sd.subdeliveryid = d.subdivisionid
		    Left join iquality.SvnD_trn_7DAnalysis svd on svd.feedbackid= d.feedbackid
        where d.feedbackid = ${fID} and (d.mappingtype = 'T' or d.mappingtype = 'A')
		    GROUP BY div.duname,sd.subdeliverydesc`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getLevelforD2Service = feedBackID => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(
        `select level1, level2 from iquality.SvnD_trn_feedbackmst where feedbackid = ${feedBackID}`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getFeedbacktypeforAppReportService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const result = await query(`SELECT
      'Internal' as  FeedbackType ,'IA'  as  FeedbackTypeid
      union all
      SELECT
      'External' as  FeedbackType ,'EA'  as  FeedbackTypeid
      union all
      SELECT
      'All' as  FeedbackType ,'All'  as  FeedbackTypeid`);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getAppReportService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        fBType,
        dateType,
        fromDate,
        toDate,
        du,
        emp,
        recordPerPage,
        pageNo,
      } = payload;
      // const offset = recordPerPage * (pageNo - 1) + 1;
      // const limit = pageNo * recordPerPage;
      const values = [fBType, dateType, fromDate, toDate, du, emp];
      const script = `select * from iquality.get_Appreciation_report($1,$2,$3,$4,$5,$6)`;
      // const script1 = `select * from iquality.get_Appreciation_report($1,$2,$3,$4,$5,$6) where serial between ${offset} and ${limit}`;
      const result = await query(script, values);
      // const result1 = await query(script1, values);
      // const total = result.length;
      // const numOfPages = Math.ceil(total / recordPerPage);
      // resolve({ result: result1, totalresult: result, total, numOfPages });
      resolve({ totalresult: result });
    } catch (error) {
      reject(error);
    }
  });
};

export const removeFileTableService = filename => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [filename];
      const script = `DELETE FROM iquality.svnd_attachment WHERE filename = $1`;
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const geticetService = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = 'select * from iquality.feedback_details_for_icet()';
      const result = await query(script);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const createWmsUserService = info => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        empcode_param,
        empname_param,
        divisionid_param,
        divisiondesc_param,
        DesignationId_param,
        DesignationDesc_param,
        address1_param,
        phone_param,
        emailid_param,
      } = info;
      const script =
        'select * from iquality.createWmsUser($1,$2,$3,$4,$5,$6,$7,$8,$9)';
      const result = await query(script, [
        empcode_param,
        empname_param,
        divisionid_param,
        divisiondesc_param,
        DesignationId_param,
        DesignationDesc_param,
        address1_param,
        phone_param,
        emailid_param,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getDUEmployeeDetailsService = searchBy => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = ['', searchBy === 'all' ? ' ' : searchBy];
      const script = 'SELECT * FROM iquality.seach_empdetails($1,$2)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getiAspireService = searchinfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const { empcode, fromdate, todate } = searchinfo;
      const script =
        'SELECT * FROM iquality.get_feedbackcount_for_iaspire($1,$2,$3);';
      const result = await query(script, [empcode, fromdate, todate]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getD7FlowStatusService = (FID, CurrentStatus, SID, SLID) => {
  return new Promise(async (resolve, reject) => {
    try {
      const values = [FID, CurrentStatus, SID, SLID];
      const script = 'select * from iquality.get_status_7d($1, $2,$3,$4)';
      const result = await query(script, values);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const getApprReportEmpDDService = DuID => {
  return new Promise(async (resolve, reject) => {
    try {
      let result = '';
      if (DuID === '0') {
        result =
          await query(`select a.empid,a.username || '(' || a.empid || ')' AS username
        from (select cr.empid,u.username from iquality.SvnD_CauseResp  cr
        LEFT JOIN public.wms_user u on u.USERID = cr.empid
        where (NULL is  null  or u.DuID in   (SELECT unnest(string_to_array(NULL, ','))::int) )
        group by  cr.empid,u.username
        union all 
        select fb.created_by as empid,u.username from iquality.SvnD_trn_feedbackmst  fb
        LEFT JOIN public.wms_user u on u.USERID = fb.created_by
        where (NULL is  null or u.DuID in  (SELECT unnest(string_to_array(NULL, ','))::int) )
        group by  fb.created_by,u.username
        )as a group by a.empid,a.username order by a.username`);
      } else {
        result =
          await query(`select a.empid,a.username || '(' || a.empid || ')' AS username
        from (select cr.empid,u.username from iquality.SvnD_AppreciationEmpMapRel  cr
        LEFT JOIN public.wms_user u on u.USERID = cr.empid
        where ('${DuID}' is  null  or u.DuID in   (SELECT unnest(string_to_array('${DuID}', ','))::int) )
        group by  cr.empid,u.username
        union all 
        select fb.created_by as empid,u.username from iquality.SvnD_trn_feedbackmst  fb
        LEFT JOIN public.wms_user u on u.USERID = fb.created_by
        where ('${DuID}' is  null or u.DuID in  (SELECT unnest(string_to_array('${DuID}', ','))::int) )
        group by  fb.created_by,u.username
        )as a group by a.empid,a.username order by a.username`);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const updateAttachmentcommentService = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      payload.uploadedfiles.files.map(async data => {
        await query(`UPDATE iquality.SvnD_attachment SET filecomment = '${data.filecomment}',updated_by = '${payload?.updatedBy}',updated_time = CURRENT_TIMESTAMP WHERE 
        feedbackid = ${payload?.feedbackId} AND filename = '${data.name}' AND fileurl = '${data.fileurl}' AND fromscreen = 'D2'`);
      });
      resolve('success');
    } catch (error) {
      reject(error);
    }
  });
};
export const updateAccountMISService = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        accountedmis,
        feedbackId,
        errserial,
        //svndId,
        dumappingid,
      } = data;

      if (errserial) {
        await query(`
        UPDATE iquality.SvnD_Trn_DivisionMapping SET accountmis = ${accountedmis} WHERE feedbackid = ${feedbackId} AND errcat = ${errserial}`);
      } else {
        const result = await query(
          `select DivisionID,SubDivisionID,SkillID from iquality.SvnD_Trn_DivisionMapping where divisionmappingid = ${dumappingid}`,
        );
        await query(
          `UPDATE iquality.SvnD_Trn_DivisionMapping SET accountmis = ${accountedmis} WHERE feedbackid = ${feedbackId} AND divisionmappingid = ${dumappingid}`,
        );
        if (result.length > 0) {
          result.map(async item => {
            await query(
              `UPDATE iquality.SvnD_Trn_DivisionMapping SET accountmis = ${accountedmis} WHERE feedbackid = ${feedbackId} AND DivisionID = ${
                item.divisionid
              } AND
                SubDivisionID = ${item.subdivisionid} AND SkillID ${
                item.skillid ? ` = ${item.skillid}` : `is NULL`
              }`,
            );
          });
        }
      }
      // const divisionMapping =
      //   'UPDATE iquality.SvnD_Trn_DivisionMapping SET accountmis = $1 WHERE feedbackid = $2 AND errcat = $3';
      // //const duRel = 'UPDATE iquality.SvnD_DURel SET isaccountformis = $1 WHERE svndid = $2';

      // await query(divisionMapping, [accountedmis, feedbackId, errserial]);
      //await query(duRel, [accountedmis, svndId]);
      resolve('Tables updated successfully');
    } catch (error) {
      reject(error);
    }
  });
};

export const getApprDropdownService = searchInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const { dropdown, searchText, fromDate, toDate, createdBy } = searchInfo;
      const script = `SELECT ROW_NUMBER() OVER () AS column_id, ${dropdown}  AS column_name FROM ( SELECT DISTINCT ${dropdown} FROM iquality.status_search_for_appreciation($1,$2,$3,$4)) subquery WHERE ${dropdown} IS NOT NULL order by ${dropdown}`;
      const result = await query(script, [
        searchText,
        fromDate,
        toDate,
        createdBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

//get base du for FromDU and ToDU in ICA Others option
export const getFromDUforUserService = userID => {
  return new Promise(async (resolve, reject) => {
    try {
      const result =
        await query(`select d.duid,d.duname from public.wms_user wu LEFT JOIN 
        public.org_mst_deliveryunit du ON wu.duid=du.duid
        LEFT JOIN 
        public.mst_deliveryunit d ON d.duid=du.itrackduid
         where userid = '${userID}'
         group by  d.duid,d.duname  order by d.duname `);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const searchAppreciationFilterService = searchInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        searchText,
        fromDate,
        toDate,
        createdBy,
        // recordPerPage,
        // pageNo,
        du,
        customer,
        recommendstatus,
      } = searchInfo;
      // const offset = recordPerPage * (pageNo - 1) + 1;
      // const limit = pageNo * recordPerPage;
      const script = `select * from iquality.status_search_for_appreciation($1,$2,$3,$4) 
        where ( '${du}' = ''  or trim(upper(du)) in (trim(upper('${du}'))))
        and ( '${customer}' = '' or trim(upper(customername)) in (trim(upper('${customer}'))))
        AND case when  '1' = '${recommendstatus}' then 1 = 1 when   '' = '${recommendstatus}' then 
        trim(upper(recommendstatus)) is null else   trim(upper(recommendstatus)) = trim(upper('${recommendstatus}')) end`;
      // const script1 = `select * from iquality.status_search_for_appreciation($1,$2,$3,$4)
      // where ( '${du}' = ''  or trim(upper(du)) in (trim(upper('${du}'))))
      // and ( '${customer}' = '' or trim(upper(customername)) in (trim(upper('${customer}'))))
      // and ( '${recommendstatus}' = '' or trim(upper(recommendstatus)) in (trim(upper('${recommendstatus}')))) and
      // serial between ${offset} and ${limit}`;
      const result = await query(script, [
        searchText,
        fromDate,
        toDate,
        createdBy,
      ]);
      // const result1 = await query(script1, [
      //   searchText,
      //   fromDate,
      //   toDate,
      //   createdBy,
      // ]);
      // const total = result.length;
      // const numOfPages = Math.ceil(total / recordPerPage);
      // resolve({ result: result1, totalresult: result, total, numOfPages });
      resolve({ totalresult: result });
    } catch (error) {
      reject(error);
    }
  });
};
export const getFeedbackDropdownService = searchInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const { dropdown, searchText, fromDate, toDate, searchType, createdBy } =
        searchInfo;
      const script = `SELECT ROW_NUMBER() OVER () AS column_id, ${dropdown}  AS column_name FROM ( SELECT DISTINCT ${dropdown} FROM iquality.status_search_for_complaint($1,$2,$3,$4,$5)) subquery WHERE ${dropdown} IS NOT NULL order by ${dropdown}`;
      const result = await query(script, [
        searchText,
        fromDate,
        toDate,
        searchType,
        createdBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const searchFeedbackFilterService = searchInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        searchText,
        fromDate,
        toDate,
        searchType,
        createdBy,
        du,
        subdu,
        jobfamily,
        customer,
        status,
        stage,
        severity,
        mis,
        nip,
        raisedfeedback,
      } = searchInfo;
      // const offset = recordPerPage * (pageNo - 1) + 1;
      // const limit = pageNo * recordPerPage;
      let script;
      if (raisedfeedback == 'false' || raisedfeedback == '') {
        script = `select * from iquality.status_search_for_complaint($1,$2,$3,$4,$5) 
        where ( '${du}' = ''  or trim(upper(to_du)) in (trim(upper('${du}'))))
          AND ( '${subdu}' = '' or trim(upper(to_subdu)) in (trim(upper('${subdu}'))))
          AND ( '${jobfamily}' = '' or trim(upper(to_jobfamily)) in (trim(upper('${jobfamily}'))))
          AND ( '${customer}' = '' or trim(upper(customer)) in (trim(upper('${customer}'))))
          AND ( '${status}' = '' or trim(upper(status)) in (trim(upper('${status}'))))
          AND case when  '1' = '${severity}' then 1 = 1 when   '' = '${severity}' then 
          trim(upper(severity)) is null else   trim(upper(severity)) = trim(upper('${severity}')) end
          AND ( '${mis}' = '' or trim(upper(accountmis)) in (trim(upper('${mis}'))))
          AND ( '${nip}' = '' or trim(upper(nip)) in (trim(upper('${nip}'))))
          AND ( '${stage}' = '' or trim(upper(stage)) in (trim(upper('${stage}'))))`;
      } else {
        script = `select * from iquality.status_search_for_complaint($1,$2,$3,$4,$5) 
      where ( '${du}' = ''  or trim(upper(from_du)) in (trim(upper('${du}'))))
        AND ( '${subdu}' = '' or trim(upper(to_subdu)) in (trim(upper('${subdu}'))))
        AND ( '${jobfamily}' = '' or trim(upper(to_jobfamily)) in (trim(upper('${jobfamily}'))))
        AND ( '${customer}' = '' or trim(upper(customer)) in (trim(upper('${customer}'))))
        AND ( '${status}' = '' or trim(upper(status)) in (trim(upper('${status}'))))
        AND case when  '1' = '${severity}' then 1 = 1 when   '' = '${severity}' then 
        trim(upper(severity)) is null else   trim(upper(severity)) = trim(upper('${severity}')) end
        AND ( '${mis}' = '' or trim(upper(accountmis)) in (trim(upper('${mis}'))))
        AND ( '${nip}' = '' or trim(upper(nip)) in (trim(upper('${nip}'))))
        AND ( '${stage}' = '' or trim(upper(stage)) in (trim(upper('${stage}'))))`;
      }
      const result = await query(script, [
        searchText,
        fromDate,
        toDate,
        searchType,
        createdBy,
      ]);
      resolve({ totalresult: result });
    } catch (error) {
      reject(error);
    }
  });
};
export const getDUFeedbackDropdownService = searchInfo => {
  return new Promise(async (resolve, reject) => {
    try {
      const { dropdown, searchText, fromDate, toDate, searchType, createdBy } =
        searchInfo;
      // const script = `SELECT ROW_NUMBER() OVER () AS column_id, ${dropdown}  AS column_name FROM ( SELECT DISTINCT ${dropdown} FROM iquality.status_search_for_complaint($1,$2,$3,$4,$5)) subquery WHERE ${dropdown} IS NOT NULL order by ${dropdown}`;
      const script = `SELECT ROW_NUMBER() OVER () AS column_id, ${dropdown}  AS column_name FROM ( 
        SELECT DISTINCT from_du FROM iquality.status_search_for_complaint($1,$2,$3,$4,$5)
        union 
        SELECT DISTINCT unnest(string_to_array(to_du, ', ')) AS to_du
        FROM iquality.status_search_for_complaint($1,$2,$3,$4,$5)
        ) subquery WHERE ${dropdown} IS NOT NULL order by ${dropdown}`;
      const result = await query(script, [
        searchText,
        fromDate,
        toDate,
        searchType,
        createdBy,
      ]);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getDUDropdownforD2Service = fID => {
  return new Promise(async (resolve, reject) => {
    try {
      const result =
        //   await query(`select div.duid,div.duname from iquality.SvnD_Trn_DivisionMapping d
        // LEFT JOIN  mst_deliveryunit div ON d.DivisionID = div.duid where d.feedbackid = ${fID}
        // and (d.mappingtype = 'T' OR d.mappingtype = 'A') and d.accountmis = true
        // GROUP BY div.duid,div.duname order by div.duname`);
        await query(`select d.divisionmappingid AS duid,
      CONCAT_WS(' , ', div.duname, subdiv.subdeliverydesc, sk.skillname) AS duname
      from iquality.SvnD_Trn_DivisionMapping d LEFT JOIN mst_deliveryunit div ON d.DivisionID = div.duid 
      LEFT JOIN iquality.mst_subdeliveryunit subdiv ON d.subdivisionid = subdiv.subdeliveryid 
      LEFT JOIN public.wms_mst_skill sk ON d.skillid = sk.skillid where d.feedbackid = ${fID}
      and (d.mappingtype = 'T' OR d.mappingtype = 'A') and d.accountmis = true and d.errcat is null
      GROUP BY div.duname,subdiv.subdeliverydesc,sk.skillname,d.divisionmappingid order by div.duname`);
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const UpdateLineitemD2Service = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { fid, serialno, errCat, duid, fnlstmt, updateBy } = payload;
      let result = '';
      errCat.map(async (item, index) => {
        result =
          await query(`Update iquality.SvnD_Analysis_ErrorCatRel SET errorid = ${item},updated_by = '${updateBy}' 
          where feedbackid = ${fid} and serialno = ${serialno} and errorgroupid = ${
            index + 1
          }`);
      });
      const resultCount = await query(
        `select count(*) from iquality.svnd_errorcatdu_stmt where feedbackid = ${fid} and serialno = ${serialno}`,
      );
      const result1 = await query(
        `select DivisionID as duID,SubDivisionID as subduID,SkillID as skill from iquality.SvnD_Trn_DivisionMapping where divisionmappingid = ${duid}`,
      );
      if (resultCount[0].count > 0) {
        result =
          await query(`Update iquality.svnd_errorcatdu_stmt SET duid = ${result1[0].duid},fnl_prb_stmt = '${fnlstmt}',
        updatedby = '${updateBy}' where feedbackid = ${fid} and serialno = ${serialno}`);
      } else {
        result =
          await query(`Insert into iquality.svnd_errorcatdu_stmt (duid,fnl_prb_stmt,createdby,updatedby,feedbackid,serialno)
        values (${result1[0].duid},'${fnlstmt}','${updateBy}','${updateBy}',${fid},${serialno})`);
      }

      const resultCount1 = await query(
        `select count(*) from iquality.SvnD_Trn_DivisionMapping WHERE feedbackid = ${fid} and errcat = ${serialno} and MappingType = 'A';`,
      );
      if (resultCount1[0].count > 0) {
        result =
          await query(`UPDATE iquality.svnd_trn_divisionmapping SET divisionid = ${result1[0].duid},
        subdivisionid=${result1[0].subduid}, skillid=${result1[0].skill} where feedbackid = ${fid} and errcat=${serialno}`);
      } else {
        result =
          await query(`INSERT INTO iquality.SvnD_Trn_DivisionMapping (feedbackid,DivisionID,SubDivisionID,SkillID,
          MappingType,errcat,created_by,accountmis) VALUES (${fid},${result1[0].duid},${result1[0].subduid},
          ${result1[0].skill},'A',${serialno},'${updateBy}',true)`);
      }
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const getOrgMstDeliveryUnitService = mstDeliveryUnit => {
  return new Promise(async (resolve, reject) => {
    try {
      const script = `SELECT STRING_AGG(d.duid::text, ',') as id
      FROM public.org_mst_deliveryunit d
      LEFT JOIN public.mst_deliveryunit du ON du.duid = d.itrackduid
      WHERE du.duid = $1;`;
      const result = await query(script, [mstDeliveryUnit]);
      resolve(result[0].id);
    } catch (error) {
      reject(error);
    }
  });
};
