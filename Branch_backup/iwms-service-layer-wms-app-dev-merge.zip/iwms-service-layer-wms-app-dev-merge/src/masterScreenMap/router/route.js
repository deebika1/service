import express from 'express';
import swaggerUi from 'swagger-ui-express';
import { readFileSync } from 'fs';
import {
  validateRequestParams,
  validateRequestBody,
} from '../helpers/middleware.js';

import {
  getMasterController,
  getUserListController,
  getDUbasedlistController,
  getMenuListController,
  insDelMenuAccessController,
  getMenuDataController,
} from '../controller/index.js';
import {
  getMasterSchema,
  getUserSchema,
  getDUbasedlistSchema,
} from '../helpers/validation.js';

const menuScreenRouter = express.Router();
const handler = cb =>
  function (req, res, next) {
    Promise.resolve(cb(req, res, next)).catch(error => next(error));
  };
const loadJSON = path =>
  JSON.parse(readFileSync(new URL(path, import.meta.url)));
const swagger = loadJSON('../helpers/swagger.json');

function swaggerDocs(app) {
  // Swagger Page
  app.get('/docs', swaggerUi.serve, swaggerUi.setup(swagger));
}
swaggerDocs(menuScreenRouter);

menuScreenRouter.get(
  '/masters/:tblname',
  validateRequestParams(getMasterSchema),
  handler(getMasterController),
);
menuScreenRouter.post(
  '/userlist',
  validateRequestBody(getUserSchema),
  handler(getUserListController),
);
menuScreenRouter.post(
  '/userlistSearch',
  validateRequestBody(getDUbasedlistSchema),
  handler(getDUbasedlistController),
);
menuScreenRouter.get('/menulist', handler(getMenuListController));
menuScreenRouter.post('/insdelmenuaccess', handler(insDelMenuAccessController));
menuScreenRouter.post('/getMenuData', handler(getMenuDataController));

export default menuScreenRouter;
