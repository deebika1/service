import {
  getMasterDropDownService,
  getUserListService,
  getDUbasedlistService,
  getMenuListService,
  insDelMenuAccessService,
  getMenuDataService,
} from '../service/index.js';
import logger from '../../modules/utils/logs/index.js';

export const getMasterController = async (req, res) => {
  try {
    const tblname = req.params.tblname.toUpperCase();
    const out = await getMasterDropDownService(tblname);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getMasterController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const getUserListController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getUserListService(payload);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getUserController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const getDUbasedlistController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getDUbasedlistService(payload);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getDUbasedlistController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const getMenuListController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getMenuListService(payload);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getMenuController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const insDelMenuAccessController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await insDelMenuAccessService(payload);
    res.status(200).send(out);
  } catch (error) {
    logger.info('insDelMenuAccessController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
export const getMenuDataController = async (req, res) => {
  try {
    const payload = req.body;
    const out = await getMenuDataService(payload);
    res.status(200).send(out);
  } catch (error) {
    logger.info('getMenuDataController : ', error);
    res.status(400).send({ error, message: error?.message });
  }
};
