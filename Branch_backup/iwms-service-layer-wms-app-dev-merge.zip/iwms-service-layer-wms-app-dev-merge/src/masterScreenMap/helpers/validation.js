import Joi from 'joi';

const masterData = ['du', 'role'];

export const getMasterSchema = Joi.object({
  tblname: Joi.string()
    .valid(...masterData)
    .required(),
});
export const getUserSchema = Joi.object({
  roleId: Joi.array().required(),
  userId: Joi.string().required(),
});
export const getDUbasedlistSchema = Joi.object({
  searchtype: Joi.string().required(),
  duId: Joi.array().allow(null),
  roleId: Joi.array().allow(null),
});
