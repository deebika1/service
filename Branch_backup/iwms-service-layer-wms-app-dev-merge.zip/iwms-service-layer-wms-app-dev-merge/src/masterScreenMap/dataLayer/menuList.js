import { query } from '../../database/postgres.js';

export async function get_menu_list() {
  let result = '';

  result = await query(
    `WITH RECURSIVE all_parents AS (
        SELECT DISTINCT
            menuid AS root_menuid
        FROM
            public.wms_uimenu
        WHERE parentmenuid IS NULL AND isactive = true AND isdefault = false
    ),
    menu_hierarchy AS (
        SELECT
            menuid,
            menuname,
            menudescription,
            menuicon,
            parentmenuid,
            isactive,
            menusequence,
            jsonb_build_object('id', menuid, 'name', menuname, 'isChecked', false) AS json_data
        FROM
            public.wms_uimenu
        WHERE
            parentmenuid IN (SELECT root_menuid FROM all_parents) and isdefault = false and isactive = true
        UNION
        SELECT
            child.menuid,
            child.menuname,
            child.menudescription,
            child.menuicon,
            child.parentmenuid,
            child.isactive,
            child.menusequence,
            jsonb_build_object('id', child.menuid, 'name', child.menuname, 'isChecked', false) || parent.json_data AS json_data
        FROM
            public.wms_uimenu child
        JOIN
            menu_hierarchy parent ON child.parentmenuid = parent.menuid
		where child.isdefault = false
    )  
    SELECT
      jsonb_agg(hierarchy) AS menu_hierarchy
    FROM (
    SELECT
           ( CASE
                WHEN COUNT(menu.json_data) > 0 THEN
                    jsonb_build_object('id', root_menuid, 'isChecked', false, 'name', uimenu.menuname, 'children', jsonb_agg(json_data))
                ELSE
                    jsonb_build_object('id', root_menuid, 'isChecked', false, 'name', uimenu.menuname)
            END) AS hierarchy
    FROM
        all_parents
    JOIN
        public.wms_uimenu uimenu ON all_parents.root_menuid = uimenu.menuid
    LEFT JOIN
        menu_hierarchy AS menu ON root_menuid = menu.parentmenuid
    GROUP BY
        root_menuid, uimenu.menuname
    ) AS subquery;`,
  );
  return result[0].menu_hierarchy;
}
