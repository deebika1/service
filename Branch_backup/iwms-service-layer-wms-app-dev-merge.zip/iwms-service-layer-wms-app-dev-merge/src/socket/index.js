import * as socketIO from 'socket.io';
import logger from '../modules/utils/logs/index.js';

const sockets = {};
let io;

export const establishSocket = server => {
  io = new socketIO.Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST'],
    },
  });

  io.on('connection', socket => {
    const sessionId = socket.handshake.query.sesId;
    logger.info(`connected ${socket.id} in a session ${sessionId}`);
    sockets[sessionId] = socket;
    logger.info(Object.keys(sockets));
    socket.on('disconnect', reason => {
      delete sockets[sessionId];
      logger.info(
        `disconnected ${socket.id} due to ${reason} in a session ${sessionId}`,
      );
      logger.info(Object.keys(sockets));
    });
  });
};

export const emitEvent = (sid, name, data) => {
  logger.info(sid, 'force send start');
  const socket = sid ? sockets[sid.trim()] : null;
  if (socket && socket.connected) {
    console.log('force send');
    socket.emit(name, data);
  }
};
