import schedule from 'node-schedule';
import { transaction } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';

export const startCronJob = name => {
  // To cancel the job on a certain condition (uniqueJobName must be known)
  if (schedule.scheduledJobs[name]) {
    logger.info(name, `************** STOP: ******************`);
    const current_job = schedule.scheduledJobs[name];
    current_job.cancel();
    logger.info('stopped job new');
  } else {
    logger.info('continued job new');
  }

  const uniqueJobName = name;
  // Shedule job according to timed according to cron expression
  schedule.scheduleJob(uniqueJobName, '*/2 * * * * *', async () => {
    // Bar the foo..
    logger.info(uniqueJobName, 'listeninggggg....');
    await isTriggerCheck(name);
    // await updateWFAction(name);
  });
  // Inspect the job object (i.E.: job.name etc.)
  logger.info(`************** JOB: ******************`);
  // logger.info(job);
};

const isTriggerCheck = async wfeventId => {
  // return new Promise(async (resolve, reject) => {
  try {
    await transaction(async client => {
      const sql = `SELECT * FROMF wms_workflow_eventlog WHERE wfeventid = $1 `;
      const {
        rows: [data],
      } = await client.query(sql, [wfeventId]);
      if (data) {
        logger.info(data, 'datadatadata');
      }
      // resolve('Task status updated by cron');
    });
  } catch (e) {
    // reject('Failed! Task status updated by cron');
  }
  // });
};
// const updateWFAction = async wfeventId => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       await transaction(async client => {
//         const sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1, isfilesynced =$2 WHERE wfeventid = $3 `;
//         await client.query(sql, ['Hold', false, wfeventId]);
//         resolve('Task status updated by cron');
//       });
//     } catch (e) {
//       reject('Failed! Task status updated by cron');
//     }
//   });
// };
