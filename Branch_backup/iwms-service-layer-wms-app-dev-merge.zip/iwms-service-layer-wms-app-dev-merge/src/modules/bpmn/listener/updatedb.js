import {
  queryWOStageChapters,
  getStageCompletionStatus,
  updateServiceStatus,
} from '../../woi/stage.js';
import { query } from '../../../database/postgres.js';
import { config } from '../../../config/restApi.js';
import { Service } from '../../../httpClient/index.js';
import logger from '../../utils/logs/index.js';

const httpService = new Service();

export const createEventLog = eventLogData => {
  const {
    workOrderId,
    wfdefId,
    skillId,
    parentActivityInstance,
    activityInstanceId,
    taskInstanceId,
    stage,
    activity,
    fileId,
    service,
    payload,
  } = eventLogData;
  return new Promise((resolve, reject) => {
    if (workOrderId == null || wfdefId == null) {
      reject({
        message: `Input error workOrderId : ${workOrderId} , wfdefId : ${wfdefId}`,
      });
    } else {
      const sql = `select * from public.create_event_log($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;
      query(sql, [
        workOrderId,
        wfdefId,
        parentActivityInstance,
        activityInstanceId,
        taskInstanceId,
        stage.iteration,
        activity.iteration,
        fileId,
        service.id,
        JSON.stringify(payload),
        skillId,
        activity.actualIteration,
      ])
        .then(data => {
          resolve(data[0].wfevent_id);
        })
        .catch(e => {
          reject(e);
        });
    }
    // const sql1 = `INSERT INTO public.wms_workflow_eventlog(
    //     workorderid, wfdefid, parentinstanceid, activityinstanceid, taskinstanceid, activitystatus, stageiterationcount, activityiterationcount, woincomingfileid, serviceid, eventdata, isfilesynced, activitycount, skillid)
    //     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, ${skillId ? `'${skillId}'` : 'NULL'} ) returning wfeventid;`;
    // query(sql, [workOrderId, wfdefId, parentActivityInstance, activityInstanceId, taskInstanceId, 'Inprocess', stage.iteration, activity.iteration, fileId, service.id, payload, false, 1]).then((data) => {
  });
};

export const updateEventLog = (eventLogData, client) => {
  const { wfeventId } = eventLogData;
  return new Promise((resolve, reject) => {
    const sql = `UPDATE public.wms_workflow_eventlog SET activitystatus = $1 WHERE wfeventid = $2 `;
    client
      .query(sql, ['Unassigned', wfeventId])
      .then(() => {
        resolve(wfeventId);
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const updateEventLogDetails = (wfeventId, client) => {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp) VALUES ($1, $2, $3)`;
    client
      .query(sql, [wfeventId, 'Created', new Date()])
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const updateFileTRNLog = (fileTrnData, wfeventId, client) => {
  console.log('inside fileTRNLOG');
  return new Promise((resolve, reject) => {
    const ids = fileTrnData.map(o => o.path);
    const filtered = fileTrnData.filter(
      ({ path }, index) => !ids.includes(path, index + 1),
    );
    const values = [];
    console.log(filtered, 'filtered files');
    filtered.forEach(fileTrn => {
      const { path, uuid, fileId } = fileTrn;
      values.push({
        wfeventid: wfeventId,
        repofileuuid: uuid,
        repofilepath: path,
        isvisible: true,
        isdownloaded: false,
        woincomingfileid: fileId,
      });
    });
    const sql = `select * from public.updateworkflowtrnfilemap ('${JSON.stringify(
      values,
    )}')`;
    console.log(sql, 'sql for file path entry');
    client
      .query(sql)
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const updateStageStatus = async eventLogData => {
  const {
    category,
    wfConfig,
    workOrderId,
    service,
    stage,
    processInstanceId,
    isBookCompleted,
    wfDefConfig,
    wfeventId,
    taskInstanceId,
  } = eventLogData;
  return new Promise(async (resolve, reject) => {
    try {
      const addeddate = new Date();
      logger.info(
        addeddate,
        'new Date()--updatedb.js-- updatestagesatus -- suradha',
      );

      addeddate.setHours(addeddate.getHours() + 5);
      addeddate.setMinutes(addeddate.getMinutes() + 30);

      logger.info(
        addeddate,
        'added 530 hour--updatedb.js-- updatestagesatus -- suradha',
      );
      const todaydatetime = convertDateFormat(addeddate);

      logger.info(
        todaydatetime,
        'todaydatetime--updatedb.js-- updatestagesatus -- suradha',
      );

      const incomingFileTypes =
        wfConfig && wfConfig.incoming && wfConfig.incoming.fileTypes
          ? wfConfig.incoming.fileTypes
          : [];
      const stageDetails = await queryWOStageChapters(
        category,
        incomingFileTypes,
        stage.id,
        service.id,
        stage.iteration,
        workOrderId,
      );
      const isStageCompleted = getStageCompletionStatus(category, stageDetails);
      if (isStageCompleted) {
        // const sql = `UPDATE public.wms_workorder_stage SET status=$1, enddate=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
        const sql = `UPDATE public.wms_workorder_stage SET status=$1, enddatetime=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
        logger.info(
          'todaydatetime updatedbJS Suradha',
          workOrderId,
          '___',
          todaydatetime,
        );
        await query(sql, [
          'Completed',
          todaydatetime,
          workOrderId,
          service.id,
          stage.id,
          stage.iteration,
        ]);
        logger.info(`Stage (${stage.id}) is completed for woid ${workOrderId}`);
        if (wfDefConfig && !!wfDefConfig.completeWorkOrder) {
          let sqlQuery = `UPDATE wms_workflow_eventlog SET activitystatus =$1 WHERE wfeventid = $2`;
          await query(sqlQuery, ['Completed', wfeventId]);
          const data = {
            taskId: taskInstanceId,
          };
          sqlQuery = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp) VALUES ($1, $2, $3)`;
          await query(sqlQuery, [wfeventId, 'Completed', new Date()]);
          const url = config.camnunda.uri.completeTask;
          await httpService.post(`${config.camnunda.base_url}${url}`, data);
          await updateServiceStatus(
            workOrderId,
            service.id,
            processInstanceId,
            isBookCompleted,
          );
        }
      }
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

function convertDateFormat(inputDate) {
  // Parse the input date using a JavaScript Date object
  const parsedDate = new Date(inputDate);

  if (Number.isNaN(parsedDate)) {
    return 'Invalid Date'; // Handle invalid date input
  }

  // Format the date into 'YYYY-MM-DD HH:mm:ss' using the Date methods
  const year = parsedDate.getFullYear();
  const month = (parsedDate.getMonth() + 1).toString().padStart(2, '0');
  const day = parsedDate.getDate().toString().padStart(2, '0');
  const hours = parsedDate.getHours().toString().padStart(2, '0');
  const minutes = parsedDate.getMinutes().toString().padStart(2, '0');
  const seconds = parsedDate.getSeconds().toString().padStart(2, '0');

  // Create the formatted date string
  const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  return formattedDate;
}
