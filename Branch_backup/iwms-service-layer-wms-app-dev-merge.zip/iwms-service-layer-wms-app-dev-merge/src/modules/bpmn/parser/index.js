import { unlink } from 'fs';
import { BPMNParser } from './core/index.js';
import { startBfsTraversal } from './bfs.js';
import { startDfsTraversal } from './dfs.js';
import { saveToDb } from './save.js';
import logger from '../../utils/logs/index.js';

let workflowName = 'CUP FP 1';
export const parseBPMN = (req, res) => {
  workflowName = req.body.wfName;
  const { destination, filename } = req.file;
  const path = destination + filename;
  const parseStartTime = new Date();
  const bpmnParser = new BPMNParser(path);
  bpmnParser.on('parsed', () => {
    try {
      const parseTime = new Date().getTime() - parseStartTime.getTime();
      const traverseStartTime = new Date();
      const processDetails = bpmnParser.getProcessDetails();
      processDetails.name = workflowName || processDetails.name;
      const dfsTaskDetails = startDfsTraversal(bpmnParser);
      const bfsTaskDetails = startBfsTraversal(bpmnParser);
      const traverseTime = new Date().getTime() - traverseStartTime.getTime();
      const analysis = getAnalysisReport({
        bpmnParser,
        parseTime,
        traverseTime,
        dfsTaskDetails,
        bfsTaskDetails,
      });
      res.send({
        dfsTaskDetails,
        bfsTaskDetails,
        analysis,
        processDetails,
        xmlContent: bpmnParser.xmlContent,
      });
    } catch (e) {
      res.status(400).send(e);
      logger.info('error -- ', e);
    } finally {
      unlink(path, err => {
        logger.info(err);
      });
    }
  });

  bpmnParser.on('error', err => {
    logger.info(err);
    res.status(400).send(err);
  });
};

export const saveBPMN = (req, res) => {
  const { processDetails, taskDetails } = req.body;
  try {
    saveToDb(processDetails, taskDetails)
      .then(() => {
        res.send('Saved successfully !');
      })
      .catch(e => {
        logger.info(e);
        res.status(400).send(e);
      });
  } catch (e) {
    logger.info('error -- ', e);
    res.status(400).send(e);
  }
};

const getAnalysisReport = ({
  bpmnParser,
  parseTime,
  traverseTime,
  dfsTaskDetails,
  bfsTaskDetails,
}) => {
  const taskDetailsId = [
    ...bpmnParser.getUserTasksId(),
    ...bpmnParser.getServiceTasksId(),
  ];
  const bfsTaskDetailsId = bfsTaskDetails.map(task => task.id);
  const dfsTaskDetailsId = dfsTaskDetails.map(task => task.id);
  return {
    parseTime: `${parseTime} ms`,
    traverseTime: `${traverseTime} ms`,
    totalTime: `${parseTime + traverseTime} ms`,
    dfsTask: dfsTaskDetails.length,
    bfsTask: bfsTaskDetails.length,
    task: taskDetailsId.length,
    missedBfsTaskId: taskDetailsId
      .filter(task => !bfsTaskDetailsId.includes(task))
      .join(' ,'),
    missedDfsTaskId: taskDetailsId
      .filter(task => !dfsTaskDetailsId.includes(task))
      .join(' ,'),
  };
};

// const testBPMNParser = () => {
//   const parseStartTime = new Date();
//   const bpmnParser = new BPMNParser('./upload/test.bpmn');
//   bpmnParser.on('parsed', () => {
//     try {
//       const parseTime = new Date().getTime() - parseStartTime.getTime();
//       const traverseStartTime = new Date();
//       const processDetails = bpmnParser.getProcessDetails();
//       processDetails.name = workflowName || processDetails.name;
//       const dfsTaskDetails = startDfsTraversal(bpmnParser);
//       const bfsTaskDetails = [] || startBfsTraversal(bpmnParser);
//       const traverseTime = new Date().getTime() - traverseStartTime.getTime();
//       const analysis = getAnalysisReport({
//         bpmnParser,
//         parseTime,
//         traverseTime,
//         dfsTaskDetails,
//         bfsTaskDetails,
//       });
//       // saveToDb(processDetails, dfsTaskDetails).then(() => {
//       //     logger.info('Saved successfully !');
//       // }).catch(e => {
//       //     logger.info(e)
//       // });
//     } catch (e) {
//       logger.info('error -- ', e);
//     }
//   });

//   bpmnParser.on('error', e => {
//     logger.info('error -- ', e);
//   });
// };

// testBPMNParser();
