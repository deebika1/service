import { updateWorkflow, updateWorkflowDefinition } from './updateDb.js';
import { transaction } from '../../../database/postgres.js';

export const saveToDb = (processDetails, taskDetails) => {
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(client => {
        return new Promise(async (tResolve, tReject) => {
          try {
            for (let i = 0; i < taskDetails.length; i++) {
              await saveTaskDetail(processDetails, taskDetails[i], client);
            }
            tResolve();
          } catch (e) {
            tReject(e.message ? e.message : e);
          }
        });
      });
      resolve('saved to database');
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

const saveTaskDetail = async (processDetails, taskDetail, client) => {
  const { activityType, instanceType, sequence } = taskDetail;
  let { formData } = taskDetail;
  const wfid = await updateWorkflow({ ...processDetails, client });
  const inParams = getInputFields(taskDetail);
  formData = formData ? JSON.stringify(formData) : null;
  await updateWorkflowDefinition({
    ...inParams,
    wfid,
    activityType,
    instanceType,
    sequence,
    formData: formData || null,
    client,
  });
};

const getInputFields = taskDetail => {
  const { inputParams, type, name } = taskDetail;
  let fields = { StageId: null, ActivityId: null };
  if (type === 'userTask') {
    fields = { ...fields, SkillId: null, ScreenId: null };
  }
  inputParams.forEach(({ name: nm, value }) => {
    if (fields[nm] == null || fields[nm]) {
      fields[nm] = value;
    }
  });
  const missingFields = Object.keys(fields)
    .filter(fName => !fields[fName])
    .map(fName => fName);
  if (missingFields.length)
    throw new Error(
      `${missingFields.join(', ')} ${
        missingFields.length === 1 ? 'field is' : 'fields are'
      } missing in ${name}`,
    );
  const { StageId, ActivityId, SkillId, ScreenId } = fields;
  return {
    stageId: StageId,
    activityId: ActivityId,
    skillid: SkillId,
    screenId: ScreenId,
  };
};
