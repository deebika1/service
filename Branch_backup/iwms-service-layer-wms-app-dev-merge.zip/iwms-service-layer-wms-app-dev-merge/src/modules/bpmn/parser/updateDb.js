export const updateWorkflow = ({ name, description, id, client }) => {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO wms_workflow( wfname, wfname_bpmnid, wftype, wfdescription ,screenid) VALUES ($1, $2, $3, $4, $5) Returning wfid`;
    client
      .query(sql, [name, id, 'Master', description, 3])
      .then(data => {
        resolve(data.rows[0].wfid);
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const updateWorkflowDefinition = ({
  wfid,
  stageId,
  activityId,
  activityType,
  instanceType,
  sequence,
  skillid,
  screenId,
  formData,
  client,
}) => {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO wms_workflowdefinition( wfid, stageid, activityid, activitytype, instancetype, sequence, screenid, skillid, isrequired, formjson) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`;
    client
      .query(sql, [
        wfid,
        stageId,
        activityId,
        activityType,
        instanceType,
        sequence,
        screenId,
        skillid,
        true,
        formData,
      ])
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};
