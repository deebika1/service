import { getAttributeName } from './utils.js';

export class BPMNSearch {
  constructor(bpmParser) {
    this.nodes = {};
    this.sequences = {};
    this.bpmParser = bpmParser;
    this.populateNodes();
    this.populateSequences();
  }

  populateNodes() {
    const nodeKeys = Object.keys(this.bpmParser.processObj);
    nodeKeys.forEach(nodeKey => {
      const nodeValue = this.bpmParser.processObj[nodeKey];
      if (nodeValue instanceof Array || nodeValue instanceof Object) {
        const nodeList = nodeValue instanceof Array ? nodeValue : [nodeValue];
        const firstNode = nodeList[0];
        const isValidNode =
          firstNode[[getAttributeName('id')]] &&
          (firstNode.incoming || firstNode.outgoing);
        if (isValidNode) {
          nodeList.forEach(node => {
            const nodeId = node[getAttributeName('id')];
            const nodeName = node[getAttributeName('name')] || '';
            this.nodes[nodeId] = {
              ...node,
              getType: () => nodeKey,
              getId: () => nodeId,
              getName: () => nodeName,
            };
          });
        }
      }
    });
  }

  populateSequences() {
    const sequenceFlow = this.bpmParser.processObj.sequenceFlow || [];
    sequenceFlow.forEach(sequence => {
      this.sequences[sequence[getAttributeName('id')]] = sequence;
    });
  }

  getNodeById(nodeId) {
    const node = this.nodes[nodeId];
    if (!node) throw new Error('Node not found');
    return node;
  }

  findNextNode(node) {
    node = typeof node === 'string' ? this.nodes[node] : node;
    if (!node) throw new Error('Node not found');
    const nextnodes = [];
    if (node.outgoing) {
      const outgoingNodes =
        node.outgoing instanceof Array ? node.outgoing : [node.outgoing];
      outgoingNodes.forEach(outgoingNode => {
        const sequence = this.sequences[outgoingNode];
        const targetRefName = sequence[getAttributeName('targetRef')];
        const nextnode = this.nodes[targetRefName];
        nextnodes.push(nextnode);
      });
    }
    return nextnodes;
  }
}
