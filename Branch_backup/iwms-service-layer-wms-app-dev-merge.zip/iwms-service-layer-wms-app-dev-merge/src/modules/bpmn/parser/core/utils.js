import { xmlConfig } from './config.js';

export const getAttributeName = attrName =>
  xmlConfig.attributeNamePrefix + attrName;

export const getTextValue = () => xmlConfig.textNodeName;
