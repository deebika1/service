/* eslint-disable prefer-const */
import moment from 'moment';
import plimit from 'p-limit';
import axios from 'axios';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import { query } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';
import * as azureHelper from '../utils/azure/index.js';
import { emitAction } from '../activityListener/activityListener.js';
import { _localdelete } from '../utils/local/index.js';

const _plimit = plimit(1);

const service = new Service();

export const checkItracksExits = (req, res, workflow = false) => {
  const { customerId, duId, stageId, activityId, wfId } = req.body;
  const userid = req.body.userid || req.body.userId;
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM public.itracks_config
            WHERE duid = ${duId} AND customerid = ${customerId} AND isactive = 1 AND not ('${userid}' ilike 'BCP%' or 
            '${userid}' ilike 'INT%')`;
    query(sql)
      .then(response => {
        if (response.length && workflow) {
          const sqlQuery = `SELECT itracksconfig FROM public.wms_workflowdefinition
            WHERE wfid = ${wfId} AND stageid = ${stageId} AND activityid = ${activityId}`;
          query(sqlQuery)
            .then(wfData => {
              if (wfData.length && wfData[0].itracksconfig) {
                const { isTrigger, isProduction, isCustomer } =
                  wfData.length && wfData[0].itracksconfig;
                resolve({
                  status: isTrigger,
                  isProduction: isProduction || false,
                  isCustomer: isCustomer || false,
                });
              } else {
                resolve({
                  status: false,
                  isProduction: false,
                  isCustomer: false,
                });
              }
            })
            .catch(() => {
              resolve({ status: false });
            });
        } else {
          resolve({ status: !!response.length });
        }
      })
      .catch(() => {
        reject({ message: 'Error for itracks config details' });
      });
  });
};
export const createJob = params => {
  return new Promise(async resolve => {
    const { woType, jobType } = params;
    if (woType === 'Book') {
      try {
        const iPayload = await getBookPayload(params);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.book.iendpointKey,
          iendpointname: config.iTracks.uri.book.createJob,
        };
        logger.info(headers, 'headers for jobcard create itracks');
        logger.info(url, 'url for jobcard create itracks');

        const result = await service.iPost(url, iPayload, headers);
        logger.info(result, 'result of jobcard create itracks');
        const { status, Result } = result.data;
        resolve({ status, message: Result });
      } catch (e) {
        resolve({ status: false, message: e.message ? e.message : e });
      }
    } else {
      try {
        const iPayload = await getJournalPayload(params);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname:
            jobType == 2
              ? config.iTracks.uri.journal.createIssueJob
              : config.iTracks.uri.journal.createJob,
        };
        logger.info(headers, 'headers for jobcard create itracks');
        logger.info(iPayload, 'payload  for jobcard create itracks');

        const result = await service.iPost(url, iPayload, headers);
        logger.info(result, 'result of jobcard create itracks');
        const { status, Result } = result.data;
        resolve({ status, message: Result });
      } catch (e) {
        resolve({ status: false, message: e.message ? e.message : e });
      }

      // resolve({ status: true, message: '' });
    }
  });
};

export const create_CoverArticle = async (req, res) => {
  const { coverdata } = req.body;
  let status = false;
  let Result = '';
  try {
    let coverlist = JSON.parse(coverdata);
    // const iPayload = await getJournalPayload(params);
    for (let index = 0; index < coverlist.length; index++) {
      if (index == 0 || (index > 0 && status == true)) {
        let iPayload = coverlist[index];
        console.log(iPayload);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname: config.iTracks.uri.journal.createJob,
        };
        const result = await service.iPost(url, iPayload, headers);
        status = result.data.status;
        Result = result.data.Result;
      }
    }
    res.status(200).send({ status, message: Result });
  } catch (e) {
    res.status(400).send({ status: false, message: Result });
  }
};

const getBookPayload = params => {
  const {
    jobId,
    jobTitle,
    CELevel,
    WoHardBackISBN,
    WoOcISBN,
    country,
    customer,
    division,
    languages,
    subDivision,
    externalUsers,
    projectManager,
    duId,
    category,
    iWorkflow,
    softwares,
  } = params;

  return new Promise((resolve, reject) => {
    let sql = ` SELECT cus.customeralias,cus.customerid,div.divisionalias,div.divisionid,sub.subdivisionalias,
        sub.verticalcode,sub.subdivisionid,cou.countrycode,cou.countryid,du.duid,du.dualias,lang.languageid,
        lang.languagecode,celevel.celevel,celevel.celevelid, category.categoryalias, software.softwarename
        FROM org_mst_customer cus
        JOIN org_mst_subdivision sub ON sub.subdivisionid = ${subDivision}
        JOIN org_mst_division div ON div.divisionid = ${division}
        JOIN geo_mst_country cou ON cou.countryid = ${country}
        JOIN org_mst_deliveryunit du ON du.duid = ${duId}
        JOIN wms_mst_language lang ON lang.languageid = ${languages}
        JOIN pp_mst_copyeditinglevel celevel ON celevel.celevelid = ${CELevel}
        JOIN pp_mst_wocategory category ON category.categoryid = ${category}
        JOIN pp_mst_composingsoftware software ON software.softwareid = ${softwares}

        WHERE cus.customerid = ${customer}`;
    logger.info(sql, 'sql for params details');
    query(sql)
      .then(async data => {
        logger.info(data, 'res for params details');
        if (data.length) {
          sql = `SELECT contact.contactname, contact.contactemail, contact.contactroleid,contact.contacttype, wms_users.userid 
                    FROM org_mst_customerorg_contact as contact
                    JOIN wms_users ON wms_users.username = contact.contactname
                    WHERE custorgconmapid IN (${projectManager})`;
          logger.info(sql, 'sql for PM details');
          query(sql)
            .then(async pmData => {
              if (pmData.length) {
                logger.info(pmData, 'res PM details');

                const otherUsers = {};
                if (externalUsers && externalUsers.length) {
                  externalUsers.forEach(item => {
                    if (item.roleAcronym == 'AUTHOR') {
                      otherUsers.Author = item.name;
                      otherUsers.AuthorMailId = item.email;
                    } else if (item.roleAcronym == 'PED') {
                      otherUsers.ProductionEditor = item.name;
                    } else if (item.roleAcronym == 'PM') {
                      otherUsers.CSEEmpCode = item.userid;
                    }
                  });
                }
                logger.info(otherUsers, 'otherUsersotherUsers');
                const comapanyDetails = await getComapanyDetails();
                const { companyname } =
                  comapanyDetails.length && comapanyDetails[0];
                const {
                  dualias,
                  customeralias,
                  divisionalias,
                  verticalcode,
                  countrycode,
                  languagecode,
                  celevel,
                  categoryalias,
                  softwarename,
                } = data[0];
                let iPayload = {};
                iPayload = {
                  ...otherUsers,
                  BookCode: jobId,
                  JobTitle: jobTitle,
                  DivisionName: dualias,
                  CustomerName: customeralias,
                  // "ProductionEditor": "James W Dunn",
                  EISBN: WoOcISBN,
                  ISBN: WoHardBackISBN,
                  CompanyName: companyname,
                  CountryName: countrycode,
                  CustomerDivisionName: divisionalias,
                  CustomerSubDivisionName: 'N/A',
                  strWorkFlowName: iWorkflow,
                  LanguageName: languagecode,
                  CSEEmpCode: pmData[0].userid,
                  VerticalCode: verticalcode,
                  strCELevel: celevel,
                  CategoryName: categoryalias,
                  SoftWareName: softwarename,
                };
                logger.info(iPayload, 'req for jobcard create itracks');
                resolve(iPayload);
              } else {
                reject({ status: false, message: 'PM details not found' });
              }
            })
            .catch(() => {
              reject({ status: false, message: 'Error for PM details get' });
            });
        } else {
          reject({ status: false, message: 'Combination not found' });
        }
      })
      .catch(() => {
        reject({
          status: false,
          message: 'Error for customer combination get',
        });
      });
  });
};
const getJournalPayload = params => {
  const {
    jobType,
    doiNumber,
    jobId,
    jobTitle,
    journalAcronym,
    emailOrderDate,
    customer,
    externalUsers,
    duId,
    journalId,
    isauto,
  } = params;

  return new Promise((resolve, reject) => {
    const sql = ` SELECT cus.icustomerid,cus.customerid,du.duid,du.iduid
        FROM org_mst_customer cus
        JOIN org_mst_deliveryunit du ON du.duid = ${duId}
        WHERE cus.customerid = ${customer}`;
    query(sql)
      .then(async data => {
        if (data.length) {
          const jId = isauto ? journalId : journalAcronym;
          const jsql = `SELECT journalacronym FROM pp_mst_journal
          WHERE journalid IN (${jId})`;
          query(jsql)
            .then(async jData => {
              if (jData.length) {
                const otherUsers = {};
                if (externalUsers && externalUsers.length) {
                  externalUsers.forEach(item => {
                    if (item.roleAcronym == 'AUTHOR') {
                      otherUsers.Author = item.name;
                      otherUsers.AuthorMailId = item.email;
                    }
                  });
                }
                const { iduid, icustomerid } = data[0];

                let iPayload = {};
                iPayload = {
                  ...otherUsers,
                  JobNature: jobType == '2' ? 'I' : 'A',
                  DOI: doiNumber,
                  JournalCode: jData[0].journalacronym, // "JCOM",
                  Title: jobTitle,
                  CustomerOrderDate:
                    emailOrderDate || moment().format('YYYY-MM-DD'),
                  BookCode: jobId,
                  Manuscriptid: jobId,
                  CustomerId: icustomerid,
                  DivisionId: iduid,
                  ReceivedDate: moment().format('YYYY-MM-DD'),
                  isBillable: true,
                };
                resolve(iPayload);
              } else {
                reject({ status: false, message: 'Journal details not found' });
              }
            })
            .catch(() => {
              reject({
                status: false,
                message: 'Error for Journal details get',
              });
            });
        } else {
          reject({ status: false, message: 'Combination not found' });
        }
      })
      .catch(() => {
        reject({
          status: false,
          message: 'Error for customer combination get',
        });
      });
  });
};
const getComapanyDetails = () => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM wms_mst_company `;
    query(sql)
      .then(res => {
        resolve(res);
      })
      .catch(error => {
        reject(error);
      });
  });
};
// const createWoAudit = (payload, response, woId) => {
//   const { status, Result } = response;
//   return new Promise((resolve, reject) => {
//     if (status) {
//       const sql = `UPDATE public.wms_workorder SET jobcardid=${Result}
//             WHERE workorderid=${woId} `;
//       query(sql)
//         .then(res => {
//           logger.info(res, 'res for jobcard id update');
//         })
//         .catch(error => {
//           logger.info(error, 'error for jobcard id update');
//         });
//     }

//     const sql = `INSERT INTO public.wms_workorder_audit(workorderid, createdon, updatedon, status)
//             VALUES (${woId}, current_timestamp, current_timestamp, ${status} ) RETURNING woauditid `;
//     query(sql)
//       .then(data => {
//         if (data.length) {
//           const sql = `INSERT INTO public.wms_workorder_audit_history(woauditid, payload, status, log, timestamp)
//                 VALUES ( ${data[0].woauditid}, '${JSON.stringify(
//             payload,
//           )}', ${status}, '${Result}', current_timestamp ) RETURNING woaudithistoryid `;
//           logger.info(sql, 'sql for itracks audit history');
//           query(sql)
//             .then(auditData => {
//               logger.info(auditData, 'res for itracks audit history');
//               resolve(status);
//             })
//             .catch(error => {
//               reject(error);
//             });
//         }
//       })
//       .catch(error => {
//         reject(error);
//       });
//   });
// };
// {"status":true,"Result":928853}
// {"status":false,"Result":"CSE Employee Code should not be empty"}

export const addSubJob = async (jobArray, data, isUpdateSubjobId, isMerge) => {
  const {
    woId,
    woid,
    woType,
    wotype,
    userid,
    userId,
    receiptdate,
    jobcardId,
    jobcardid,
    targetStage,
  } = data;
  let subjobArray = await getSubjobIds({
    workorderId: woId || woid,
    taskType: 'General',
  });
  if (isMerge) {
    subjobArray = subjobArray.concat(jobArray);
  }
  logger.info(subjobArray, 'subjobArray in next stage');
  logger.info(jobArray, 'jobArray in next stage');

  return new Promise(async (resolve, reject) => {
    try {
      if (wotype === 'Book' || woType === 'Book') {
        const iStageName = await getiTracksStageName(data);
        let response = { status: false, Result: '' };

        const payload = [];
        const woincomingId = [];
        const promises = subjobArray.map(async item => {
          const iFileType = await getiTracksFileType(item.filetypeid);
          woincomingId.push(item.woincomingfileid || item.id);
          payload.push({
            jobCardId: jobcardId || jobcardid,
            subJobDesc: item.filename || item.name,
            subJobType: iFileType, // "T",
            Remark: 'test',
            stageName: iStageName, // "Finals",
            dueDate: targetStage ? targetStage.plannedEnd : item.duedate, // "2022-02-08 00:00:00.000",
            ReceiptDate: receiptdate || moment().toISOString(), // "2022-02-06 00:00:00.000",
            empcode: userid || userId, // "is4748",
            EstimatedPages: item.estimatedpages || 0, // 6,
            mspage: item.mspages || 0, // "12",
            subjobId: item.subjobid || 0,
            // newly added for subjob id
          });
        });

        await Promise.all(promises).then(async () => {
          // do something with the finalized list of albums here

          const url = config.iTracks.base_url;
          const headers = {
            iendpointkey: config.iTracks.uri.book.iendpointKey,
            iendpointname: config.iTracks.uri.book.addSubJob,
          };
          logger.info(headers, 'headers for subjob itracks');
          logger.info(payload, 'payload for subjob itracks');
          logger.info(url, 'url for subjob itracks ');
          const chunkSize = 75;
          const awt = [];
          for (let i = 0; i < payload.length; i += chunkSize) {
            const chunk = payload.slice(i, i + chunkSize);
            awt.push(_plimit(() => service.iPost(url, chunk, headers)));
          }
          const result = await Promise.all(awt);
          logger.info(result, 'result of subjob');
          const failedResult = result.filter(x => x.data.status == false);
          if (failedResult.length > 0) {
            response.status = false;
            response.message = [];
            response.Result = [];
            result.forEach(x => response.Result.push(...x.data.Result));
            failedResult.forEach(x => response.message.push(...x.data.Result));
          } else {
            response.status = true;
            response.message = [];
            response.Result = [];
            result.forEach(x => response.Result.push(...x.data.Result));
          }

          const { status, Result } = response;
          response.status = status;
          response.message = Result;
          logger.info(status, 'response for subjob');
          logger.info(isUpdateSubjobId, 'isUpdateSubjobId');
          if (!status) {
            resolve(response);
          } else if (status && isUpdateSubjobId) {
            const auditRes = await subJobAudit(Result, woincomingId);
            response = auditRes;
            logger.info(response, 'subjob audit res');
            resolve(response);
          } else if (status && !isUpdateSubjobId) {
            resolve(response);
          }
        });
      } else {
        resolve({ status: true, message: '' });
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const subJobAudit = (subjobId, woincomingfileid) => {
  logger.info(subjobId, 'subjobId');
  logger.info(woincomingfileid, 'woincomingfileid');

  return new Promise((resolve, reject) => {
    let sql = `select * from public.wms_workorder_incomingfiledetails
        WHERE woincomingfileid = ANY ($1)`;
    logger.info(sql, 'sql for filter woicomingfileid');
    query(sql, [woincomingfileid])
      .then(res => {
        logger.info(res, 'res for filter woicomingfileid');
        if (res.length) {
          const val = [];
          subjobId.forEach(rItem => {
            res.forEach(sItem => {
              if (rItem.subJobDesc === sItem.filename) {
                val.push(`(${sItem.woincomingfileid}, ${rItem.subJobID})`);
              }
            });
          });

          sql = `update wms_workorder_incomingfiledetails as wwi set
                        subjobid = wwi2.subjobid
                    from (values
                        ${val}
                    ) as wwi2(woincomingfileid, subjobid)
                    where wwi2.woincomingfileid = wwi.woincomingfileid`;

          query(sql)
            .then(() => {
              resolve({
                status: true,
                message: 'subjobid updated successfully',
              });
            })
            .catch(() => {
              reject({ status: false, message: 'Error for subjob id update' });
            });
        } else {
          reject({ status: false, message: 'Woicomingfileid not found' });
        }
      })
      .catch(() => {
        reject({ status: false, message: 'Error for filter woicomingfileid' });
      });
  });
};

export const validateTask = async (req, res) => {
  return new Promise(async resolve => {
    const isCanWork = await canWorkActivity(req.body);
    const { status } = isCanWork;
    if (status) {
      const isEntryExists = await openEntryExists(req.body);
      const { status: stat } = isEntryExists;
      if (stat) {
        resolve(stat);
      } else {
        res.status(400).send(isEntryExists);
      }
    } else {
      res.status(400).send(isCanWork);
    }
  });
};

export const canWorkActivity = data => {
  const { woType, userid, jobCardId, duId, customerId, jobId, jobType } = data;
  return new Promise(async resolve => {
    const iStageId = await getiTracksStageId(data);
    const iActivityId = await getiTracksActivityId(data);
    if (iStageId && iActivityId) {
      if (woType === 'Book') {
        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.book.iendpointKey,
          iendpointname: config.iTracks.uri.book.canWorkActivity,
        };
        const payload = {
          empId: userid,
          jobCardid: jobCardId,
          stageId: iStageId, // 2,
          activityId: iActivityId, // 5902
        };
        logger.info(headers, 'headers for can work activity itracks');
        logger.info(payload, 'payload for can work activity itracks');
        logger.info(url, 'url for itracks');

        const result = await service.iPost(url, payload, headers);
        logger.info(result.data, 'result of can work activity');
        const { status, Result } = result.data;
        resolve({
          status,
          iStageId,
          iActivityId,
          message: status
            ? Result
            : `${Result}. Please contact the iTrack Administrator`,
        });
      } else {
        const iDuId = await getiTracksDuId(duId);
        const iCustomerId = await getiTracksCustomerId(customerId);

        const url = config.iTracks.base_url;
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname: config.iTracks.uri.journal.canWorkActivity,
        };
        const payload = {
          BookCode: jobId,
          IsIssue: jobType === '2' ? 'Y' : 'N',
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          EmpCode: userid,
          StageId: iStageId,
          ActivityId: iActivityId,
        };
        logger.info(headers, 'headers for can work activity itracks');
        logger.info(payload, 'payload for can work activity itracks');

        const result = await service.iPost(url, payload, headers);
        logger.info(result.data, 'result of can work activity');
        const { status, Result } = result.data;
        resolve({
          status,
          iStageId,
          iActivityId,
          message: status
            ? Result
            : `${Result}. Please contact the iTrack Administrator`,
        });
      }
    } else {
      resolve({
        status: false,
        message: 'iTracks stageid / activityid not fount in iWMS',
      });
    }
  });
};

export const getiTracksFileType = id => {
  return new Promise((resolve, reject) => {
    const sql = `select filetypecode from pp_mst_filetype where filetypeid= ${id}`;
    query(sql)
      .then(res => {
        if (res.length) {
          resolve(res[0].filetypecode);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        reject(false);
      });
  });
};

// export const constructPayload = (jobArray, jobcardId) => {
//   return new Promise((resolve, reject) => {
//     const payload = [];
//     const woincomingId = [];
//     const promises = jobArray.map(async item => {
//       const iFileType = await getiTracksFileType(item.filetypeid);
//       woincomingId.push(item.woincomingfileid || item.id);
//       payload.push({
//         jobCardId: jobcardId,
//         subJobDesc: item.filename || item.name, // "chapter1",
//         subJobType: iFileType, // "T",
//         Remark: 'test',
//         stageName: iStageName, // "Finals",
//         dueDate: item.duedate || targetStage.plannedEnd, // "2022-02-08 00:00:00.000",
//         ReceiptDate: receiptdate || moment().format('YYYY-MM-DD hh:mm:ss'), // "2022-02-06 00:00:00.000",
//         empcode: userid || userId, // "is4748",
//         EstimatedPages: item.estimatedpages || 0, // 6,
//         mspage: item.mspages || 0, // "12"
//       });
//     });

//     Promise.all(promises).then(function () {
//       // do something with the finalized list of albums here
//     });
//   });
// };

export const getiTracksStageName = data => {
  const { stageId, wfId, stageIterationCount } = data;
  logger.info(data, 'datadatadata112');
  return new Promise((resolve, reject) => {
    const sql = `SELECT iws.istageid,iws.istagename,ism.stageid, ism.iterationcount FROM itracks_mst_stage_map as ism 
        JOIN itracks_mst_stage as iws ON ism.itracksstageid = iws.itracksstageid
        WHERE ism.wfid= ${wfId} AND ism.stageid = ${stageId} AND iws.isactive=1`;
    query(sql)
      .then(res => {
        if (res.length) {
          let iStageName = '';
          res.forEach(item => {
            if (
              item.stageid == stageId &&
              item.iterationcount == stageIterationCount
            ) {
              iStageName = item.istagename;
            }
          });
          if (!iStageName) {
            iStageName = res[res.length - 1].istagename;
          }
          resolve(iStageName);
        } else {
          reject('iTracks stage Name not found');
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};
export const getiTracksStageId = data => {
  const { stageId, wfId, stageIterationCount } = data;
  return new Promise(resolve => {
    const sql = `SELECT iws.istageid,iws.istagename,ism.stageid, ism.iterationcount FROM itracks_mst_stage_map as ism 
        JOIN itracks_mst_stage as iws ON ism.itracksstageid = iws.itracksstageid
        WHERE ism.wfid= ${wfId} AND ism.stageid = ${stageId} AND iws.isactive=1`;
    query(sql)
      .then(res => {
        if (res.length) {
          let iStageId = '';
          res.forEach(item => {
            if (
              item.stageid == stageId &&
              item.iterationcount == stageIterationCount
            ) {
              iStageId = item.istageid;
            }
          });
          if (!iStageId) {
            iStageId = res[res.length - 1].istageid;
          }
          resolve(iStageId);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        resolve(false);
      });
  });
};
export const getFileDetails = data => {
  const { woid, woId } = data;
  const workorderId = woid || woId;
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT woincomingfileid,filename,filetypeid,mspages,estimatedpages, imagecount,equationcount, tablecount , wwif.duedate FROM public.wms_workorder_incoming 
      JOIN wms_workorder_incomingfiledetails AS wwif ON wwif.woincomingid = wms_workorder_incoming.woincomingid
      WHERE woid=$1 order by coalesce ( mspages,0) desc`;
      const fileDetails = await query(sql, [workorderId]);
      resolve(fileDetails);
    } catch (error) {
      reject(error);
    }
  });
};

export const getiTracksActivityId = data => {
  const { stageId, activityId, wfId, actualActivityCount } = data;
  return new Promise((resolve, reject) => {
    const sql = `
        SELECT iwa.iactivityid,iwa.iactivityname,imam.activityid,imam.iterationcount FROM itracks_mst_activity_map as imam 
        JOIN itracks_mst_activity as iwa ON iwa.itracksactivityid = imam.itracksactivityid
        WHERE imam.wfid= ${wfId} AND imam.stageid = ${stageId} AND imam.activityid = ${activityId} AND iwa.isactive=1`;
    query(sql)
      .then(res => {
        if (res.length) {
          let iActivityId = '';
          res.forEach(item => {
            if (
              item.activityid == activityId &&
              item.iterationcount == actualActivityCount
            ) {
              iActivityId = item.iactivityid;
            }
          });
          if (!iActivityId) {
            iActivityId = res[res.length - 1].iactivityid;
          }
          resolve(iActivityId);
        } else {
          resolve(false);
        }
      })
      .catch(() => {
        reject(false);
      });
  });
};
// export const getSubjobIdsFromTrnFile = (data) => {
//     const { wfeventid, taskType, workorderId } = data;
//     return new Promise((resolve, reject) => {
//         let sql = '';
//         if (taskType == 'Single') {
//             sql = `SELECT subjobid FROM public.wms_workorder_incoming
//             JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
//             WHERE wms_workorder_incoming.woid=${workorderId} AND wms_workorder_incomingfiledetails.filetypeid=1 AND subjobid IS NOT NULL`;
//         } else {
//             sql = `SELECT  DISTINCT ON (wfeventid) subjobid FROM public.wms_workflowactivitytrn_file_map
//             JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
//             WHERE wfeventid=${wfeventid} AND wms_workorder_incomingfiledetails.subjobid IS NOT NULL`;
//         }
//         query(sql).then((res) => {
//             resolve(res);
//         }).catch((error) => {
//             reject("");
//         });
//     });
// }
export const getSubjobIds = data => {
  const { wfeventId, wfeventid, workorderId, taskType } = data;
  return new Promise((resolve, reject) => {
    let sql = '';
    if (taskType == 'General') {
      sql = `SELECT subjobid, filetypeid, filename, woincomingfileid, wms_workorder_incomingfiledetails.duedate, estimatedpages, mspages, uomvalue, typesetpage FROM public.wms_workorder_incoming
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
            WHERE wms_workorder_incoming.woid=${workorderId} AND filetypeid NOT IN (5, 15)
			`;
    } else if (taskType == 'Single') {
      sql = `SELECT subjobid, filetypeid, filename, woincomingfileid, wms_workorder_incomingfiledetails.duedate, estimatedpages, mspages, uomvalue, typesetpage FROM public.wms_workorder_incoming
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
            WHERE wms_workorder_incoming.woid=${workorderId} AND subjobid IS NOT NULL
			`;
    } else {
      // sql = `SELECT  DISTINCT ON (wfeventid) subjobid, filetypeid, uomvalue, typesetpage FROM public.wms_workflowactivitytrn_file_map
      // JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
      // WHERE wfeventid=${wfeventId || wfeventid} AND wms_workorder_incomingfiledetails.subjobid IS NOT NULL
      // `;

      sql = `SELECT  DISTINCT ON (wfeventid) subjobid, filetypeid, uomvalue, typesetpage FROM public.wms_workflow_eventlog
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
            WHERE wfeventid=${
              wfeventId || wfeventid
            } AND wms_workorder_incomingfiledetails.subjobid IS NOT NULL
            `;
    }
    logger.info(sql, 'sql for subjobid');
    // SELECT * FROM public.wms_workorder_incomingfiledetails
    // WHERE wms_workorder_incomingfiledetails.woincomingfileid IN (${incomingFileId}) AND subjobid IS NOT NUll
    query(sql)
      .then(res => {
        resolve(res);
      })
      .catch(() => {
        reject([]);
      });
  });
};

export const openEntryExists = data => {
  const { userid } = data;
  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.openEntry,
    };
    const payload = {
      empCode: userid,
    };
    logger.info(headers, 'headers for exists itracks');
    logger.info(payload, 'payload for exists itracks');

    const result = await service.iPost(url, payload, headers);
    logger.info(result.data, 'result of exists');
    const { status, Result } = result.data;
    resolve({
      status,
      message: status
        ? Result
        : `${Result} Please contact the iTrack Administrator`,
    });
  });
};

export const logisticEntryInsert = data => {
  const {
    taskType,
    userid,
    jobCardId,
    subjobArray,
    iStageId,
    iActivityId,
    startPage,
    endPage,
    wfeventid,
  } = data;

  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.logisticEntryInsert,
    };
    let response = { status: false, message: '' };
    logger.info(subjobArray, 'subjobArray subjobArray');
    // filter the subjob id based on task type
    let subjobIds = subjobArray;
    if (taskType == 'Single') {
      subjobIds = subjobArray.filter(item => item.filetypeid == 1);
    }
    await Promise.all(
      subjobIds.map(async item => {
        const payload = {
          trandate: moment().toISOString(),
          subjobid: item.subjobid,
          activityId: iActivityId,
          stageid: iStageId,
          startDate: moment().toISOString(),
          empCode: userid,
          jobCardid: jobCardId,
          startPage: startPage || 0,
          endPage: endPage || 0,
        };
        logger.info(headers, 'headers for logistic entry insert itracks');
        logger.info(payload, 'payload for logistic entry insert itracks');

        const result = await service.iPost(url, payload, headers);
        logger.info(result.data, 'result of logistic entry insert');

        const { status, Result } = result.data;
        let worksheetRes = false;
        if (status) {
          worksheetRes = await addWorksheetId(Result, wfeventid);
        } else {
          resolve({
            status,
            message: `${Result}. Please contact the iTrack Administrator`,
          });
        }

        if (worksheetRes) {
          resolve({ status, message: Result });
        } else {
          resolve({ status, message: 'Worksheet id update failed' });
        }
        response = result.data;
      }),
    );

    resolve(response);
  });
};

export const logisticEntryUpdate = (
  data,
  isProduction,
  isCustomer,
  actionId,
  action,
) => {
  const {
    taskType,
    subjobArray,
    userid,
    userId,
    jobCardId,
    iStageId,
    iActivityId,
    startPage,
    endPage,
    quantity,
    wfeventId,
    worksheetId,
  } = data;

  return new Promise(async resolve => {
    const totMins = await calculateTaskTOT(wfeventId, userId);
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.logisticEntryUpdate,
    };
    let response = { status: false, Result: '' };
    // filter the subjob id based on task type
    let subjobIds = subjobArray;
    if (taskType == 'Single') {
      subjobIds = subjobArray.filter(item => item.filetypeid == 1);
    }
    data.subjobIds = subjobIds;
    logger.info(worksheetId, 'worksheetId from UI');
    const iWorksheetId = await _getWorksheetId(wfeventId);
    logger.info(iWorksheetId, 'iWorksheetId from iTracks');
    await Promise.all(
      subjobIds.map(async item => {
        const payload = {
          worksheetid: iWorksheetId,
          finishDate: moment().toISOString(),
          totMins,
          // "quantity": taskType === 'Single' ? isBatchTaskUom ? quantity || 0 : item.uomvalue : quantity || 0,
          quantity: taskType === 'Single' ? quantity || 0 : item.uomvalue,
          statusId: actionId,
          subjobid: item.subjobid,
          activityId: iActivityId,
          remarks: 'testing',
          stageid: iStageId,
          empCode: userid || userId,
          jobCardid: jobCardId,
          startPage: startPage || 0,
          endPage: taskType === 'Single' ? endPage || 0 : item.uomvalue,
          // to be confirmed
          // "startPage": taskType === 'Single' ? isBatchTaskUom ? startPage || 0 : 1 : startPage || 0,
          // "endPage": taskType === 'Single' ? isBatchTaskUom ? endPage || 0 : item.uomvalue : endPage || 0
        };
        logger.info(headers, 'headers for logistic entry update itracks');
        logger.info(payload, 'payload for logistic entry update itracks');

        const result = await service.iPost(url, payload, headers);
        logger.info(result.data, 'result of logistic update insert');
        const { status, Result } = result.data;
        response = result.data;
        if (!status) {
          resolve({
            status,
            Result: status
              ? Result
              : `${Result}. Please contact the iTrack Administrator`,
          });
        }
      }),
    );

    if (response.status && action === 'save') {
      if (isProduction) {
        const prodDespatch = await taskDespatch(data, 'production');
        resolve(prodDespatch);
      } else if (isCustomer) {
        const custDespatch = await taskDespatch(data, 'customer');
        resolve(custDespatch);
      } else {
        resolve(response);
      }
    } else {
      resolve(response);
    }
  });
};

// export const despatchAction = (isProduction, isCustomer) => {
//   return new Promise(async resolve => {
//     try {
//       if (response.status) {
//         if (isProduction) {
//           const prodDespatch = await taskDespatch(data, 'production');
//           resolve(prodDespatch);
//         } else if (isCustomer) {
//           const custDespatch = await taskDespatch(data, 'customer');
//           resolve(custDespatch);
//         } else {
//           resolve(response);
//         }
//       } else {
//       }
//     } catch (e) {}
//   });
// };

const calculateTaskTOT = (wfeventId, userId) => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `SELECT taskreportid, totaltime, uomvalue FROM wms_task_report_view WHERE wfeventid = ${wfeventId} and userid='${userId}'`;
      logger.info(sql, 'sql for previous entry Exists');
      query(sql)
        .then(exData => {
          logger.info(exData, 'previous entry Exists');
          sql = `SELECT timestamp FROM wms_workflow_eventlog_details
                    WHERE wfeventid=${wfeventId} AND operationtype = 'Work in progress' ORDER BY wfeventdetailid DESC
                    LIMIT 1 `;

          query(sql)
            .then(res => {
              if (res.length) {
                const now = moment();
                const then = moment(res[0].timestamp).format(
                  'DD/MM/YYYY HH:mm:ss',
                );
                const ms = moment(now, 'DD/MM/YYYY HH:mm:ss').diff(
                  moment(then, 'DD/MM/YYYY HH:mm:ss'),
                );
                const d = moment.duration(ms);

                const getPreMinutes = exData.length
                  ? moment(exData[0].totaltime, 'HH:mm:ss').diff(
                      moment().startOf('day'),
                      'minutes',
                    )
                  : 0;
                const totalMinutes = d.asMinutes() + getPreMinutes;
                logger.info(getPreMinutes, 'get previous working minutes');

                logger.info(totalMinutes, 'adding total working minutes');
                resolve(totalMinutes);
              }
            })
            .catch(error => {
              reject(error);
            });
        })
        .catch(error => {
          reject(error);
        });
    } catch (e) {
      reject(e);
    }
  });
};

export const logisticEntryDelete = async data => {
  const { worksheetId, wfeventId } = data;
  logger.info(worksheetId, 'worksheetId from UI');
  const iWorksheetId = await _getWorksheetId(wfeventId);
  logger.info(iWorksheetId, 'iWorksheetId from iTracks');
  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = {
      iendpointkey: config.iTracks.uri.book.iendpointKey,
      iendpointname: config.iTracks.uri.book.logisticEntryDelete,
    };
    const payload = {
      worksheetid: iWorksheetId, // 19557403
    };
    logger.info(headers, 'headers for logistic entry delete itracks');
    logger.info(payload, 'payload for logistic entry delete itracks');
    const result = await service.iPost(url, payload, headers);
    logger.info(result.data, 'result of logistic delete insert');
    resolve(result.data);
  });
};

export const taskDespatch = (data, type) => {
  logger.info(data, 'data req');
  const { jobCardId, subjobArray, iStageId, userId } = data;
  return new Promise(async resolve => {
    const url = config.iTracks.base_url;
    const headers = { iendpointkey: config.iTracks.uri.book.iendpointKey };
    let payload = {};
    const setSubjobs = [];
    if (type === 'production') {
      subjobArray.forEach(sId => {
        setSubjobs.push({
          SubJobId: sId.subjobid,
          Quantity: sId.typesetpage,
          // to be confirmed
          // "Quantity": taskType === 'Single' ? isBatchTaskUom ? quantity || 0 : item.uomvalue : quantity || 0
        });
      });
      payload = {
        JobCardId: jobCardId,
        StageId: iStageId,
        SubJob: setSubjobs,
        EmpCode: userId,
        Finishdate: moment().format('YYYY-MM-DD hh:mm:ss'),
        PMEInstruction: 'testing',
      };
      headers.iendpointname = config.iTracks.uri.book.productionDispatch;
    } else {
      subjobArray.forEach(sId => {
        setSubjobs.push(sId.subjobid);
      });
      payload = {
        JobCardId: jobCardId,
        StageId: iStageId,
        SubJob: setSubjobs,
        EmpCode: userId,
        Finishdate: moment().format('YYYY-MM-DD hh:mm:ss'),
      };
      headers.iendpointname = config.iTracks.uri.book.customerDispatch;
    }

    logger.info(headers, 'headers for task despatch itracks');
    logger.info(payload, 'payload for task despatch itracks');

    const result = await service.iPost(url, payload, headers);
    logger.info(result, 'result of task despatch');
    resolve(result.data);
  });
};
const addWorksheetId = (worksheetId, wfeventid) => {
  return new Promise((resolve, reject) => {
    const sql = `UPDATE public.wms_workflow_eventlog SET worksheetid=${worksheetId}
        WHERE wfeventid=${wfeventid} `;
    query(sql)
      .then(() => {
        resolve(true);
      })
      .catch(() => {
        reject(false);
      });
  });
};

// const despatchAudit = (payload, response, woincomingfileid) => {
//   const { status, Result } = response;
//   return new Promise((resolve, reject) => {
//     if (status) {
//       const sql = `UPDATE public.wms_workorder_incomingfiledetails SET subjobid=${Result}
//             WHERE woincomingfileid=${woincomingfileid} `;
//       query(sql)
//         .then(res => {
//           logger.info(res, 'res for subjob id update');
//           resolve(status);
//         })
//         .catch(error => {
//           reject(error);
//         });
//     }
//   });
// };

/// get worksheet id
export const getWorksheetId = (req, res) => {
  const { wfeventId } = req.body;
  const sql = `SELECT worksheetid FROM public.wms_workflow_eventlog WHERE wfeventid = ${wfeventId}`;
  query(sql)
    .then(ressult => {
      res
        .status(200)
        .json({ data: ressult.length ? ressult[0].worksheetid : '' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const _getWorksheetId = wfeventId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT worksheetid FROM public.wms_workflow_eventlog WHERE wfeventid = ${wfeventId}`;
    query(sql)
      .then(ressult => {
        resolve(ressult.length ? ressult[0].worksheetid : '');
      })
      .catch(error => {
        reject(error);
      });
  });
};

export const productionReset = async (req, res) => {
  const { jobCardId, woType, duId, customerId, jobId } = req.body;
  try {
    const iStageId = await getiTracksStageId(req.body);
    logger.info(iStageId, 'iStageId');

    let url = '';
    let headers = '';
    let payload = {};

    if (woType === 'Book') {
      const subjobArray = await getSubjobIds(req.body);
      logger.info(subjobArray, 'subjobArray');

      const setSubjobs = [];
      subjobArray.forEach(sId => {
        setSubjobs.push(sId.subjobid);
      });
      payload = {
        jobcardid1: jobCardId,
        SubJobId: setSubjobs,
        stageId: iStageId,
      };
      url = config.iTracks.base_url;
      headers = {
        iendpointkey: config.iTracks.uri.book.iendpointKey,
        iendpointname: config.iTracks.uri.book.productionDispatchReset,
      };
    } else {
      const iDuId = await getiTracksDuId(duId);
      const iCustomerId = await getiTracksCustomerId(customerId);
      payload = {
        BookCode: jobId,
        DivisionID: iDuId,
        CustomerID: iCustomerId,
        StageId: iStageId,
      };
      url = config.iTracks.base_url;
      headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.productionDispatchReset,
      };
    }

    logger.info(headers, 'headers for production reset itracks');
    logger.info(payload, 'payload for production reset itracks');

    const result = await service.iPost(url, payload, headers);
    logger.info(result, 'result of production reset');
    if (result.status) {
      res.status(200).json({ message: 'Production reset successfully' });
    } else {
      res.status(400).json({ message: 'Production reset failed' });
    }
  } catch (error) {
    res.status(400).json({ message: error });
  }
};

export const getProofingType = (req, res) => {
  const { journalid } = req.body;
  const sql = `SELECT proofingtype FROM public.pp_mst_journal where journalid = ${journalid}`;
  query(sql)
    .then(ressult => {
      res.status(200).send(ressult);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getTrnImages = (req, res) => {
  const { wfeventid } = req.body;
  const sql = `select reverse(substr(reverse(repofilepath),0,strpos(reverse(repofilepath),'/'))),repofilepath from  public.wms_workflowactivitytrn_file_map where wfeventid =${wfeventid} and repofilepath like '%.eps'
    `;
  query(sql)
    .then(ressult => {
      res.status(200).send(ressult);
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// testing 11

// export const updateFileTRNLog = (fileTrnData, wfeventId) => {
//     return new Promise((resolve, reject) => {
//         const values = [];
//         fileTrnData.map((fileTrn) => {
//             const { path, uuid, fileId } = fileTrn;
//             values.push(`(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`);
//         });
//         const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
//             wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
//             VALUES ${values};`;
//         query(sql).then(() => {
//             resolve();
//         }).catch(e => {
//             reject(e);
//         });
//     })
// }

export const graphicsImageActions = async (req, res) => {
  const { taskDetails, actionType, systemInfo, userid } = req.body;
  try {
    let { images } = req.body;
    if (actionType == 'Deleted') {
      const newDeletePath = JSON.stringify(images);
      const sql1 = `select regexp_replace(repofilepath, '.*/', ''), * from wms_workflowactivitytrn_file_map where woincomingfileid=${
        taskDetails.woincomingfileid
      } 
        and regexp_replace(repofilepath, '.*/', '') = any (  
        (
        (select replace (replace (replace(aggval::Text,'{','{"') :: text, '}','"}')::text, ',','","')	 
        from
        (select array_agg(reverse) as aggval from
        ( select reverse from json_to_recordset
         ('${newDeletePath}')
        as x(reverse text) 
         union
        select 	 
           CASE WHEN '.pdf' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.pdf') ELSE null end as reverse
         from json_to_recordset
         ('${newDeletePath}')
        as x(reverse text) 
         union
        select 	 
           CASE WHEN '.png' = any('{${taskDetails.config.fileCombination.toString()}}') THEN REPLACE(reverse,'.eps','.png') ELSE null end as reverse
         from json_to_recordset
         ('${newDeletePath}')
        as x(reverse text) 
        ) as finalres where finalres.reverse is not null
        ) as ressub
           )::text[]))`;
      logger.info(sql1, 'deletesql');
      const response = await query(sql1);
      images = response;
      logger.info(response, 'response');
    }
    const val = [];
    images.forEach(list => {
      val.push(
        `(${taskDetails.workorderid}, '${
          list && list.reverse
            ? list.reverse
            : list.file && list.file.reverse
            ? list.file.reverse
            : list.regexp_replace
        }', ${taskDetails.stageid}, ${taskDetails.activityid}, ${
          taskDetails.wfeventid
        }, '${actionType}', '${systemInfo}', '${userid}',${
          taskDetails.customerid
        },'${
          list && list.path
            ? list.path
            : list.file && list.file.path
            ? list.file.path
            : list.repofilepath
        }' )`,
      );
    });

    const sql2 = `INSERT INTO wms_imageupload_actions_audit(workorderid,imagename,stageid,activityid,wfeventid,operationtype,
      systeminfo,userid,customerid,repofilepath) values ${val}`;
    logger.info(sql2, val, 'data');
    await query(sql2);
    res.status(200).json({
      status: true,
      data: 'audit table inserted successfully',
    });
  } catch (error) {
    logger.info(error, 'error trn actions');
    res.status(400).send({ message: error, status: false });
  }
};
export const updateImagepathtrn = async (req, res) => {
  const { taskDetails, uploadedPaths } = req.body;

  try {
    for (const list of uploadedPaths) {
      const sql = `INSERT INTO wms_workflowactivitytrn_file_map(
wfeventid, repofileuuid,repofilepath,workingfolderpath,isvisible, isdownloaded, woincomingfileid, ischeckedout, isactive)
select ${taskDetails.wfeventid}, '${list.uuid}', '${
        list.path
      }', null, ${true}, ${false}, '${
        taskDetails.woincomingfileid
      }',null,${true}
where not exists (
  select 1 from wms_workflowactivitytrn_file_map
      where wfeventid = ${taskDetails.wfeventid}
      and repofilepath = '${list.path}'
      and woincomingfileid = '${taskDetails.woincomingfileid}'
)`;
      logger.info(sql, 'createtrninsert');
      await query(sql);
    }
    res.status(200).json({
      status: true,
      data: 'Trancesection table inserted successfully',
    });
  } catch (error) {
    logger.info(error, 'error trn insert');
    res.status(400).send({ message: error, status: false });
  }
};

export const deleteImagepathtrn = async (req, res) => {
  try {
    const { deletePaths, taskDetails } = req.body;
    let condition = '';
    if (deletePaths.length > 0) {
      deletePaths.forEach((list, index) => {
        condition += `%${list}%`;
        if (index !== deletePaths.length - 1) {
          condition += '|';
        }
      });
    }
    let sql = `select * from wms_workflowactivitytrn_file_map where wfeventid=${taskDetails.wfeventid} and repofilepath SIMILAR TO '${condition}'`;
    logger.info(sql, 'deletesql');
    const response = await query(sql);
    logger.info(response, 'response');
    const awt = [];
    await deleteImagesStorage(response, taskDetails);
    await Promise.all(awt);
    sql = `DELETE from wms_workflowactivitytrn_file_map where wfeventid=${taskDetails.wfeventid} and repofilepath SIMILAR TO '${condition}'`;
    await query(sql);
    res.status(200).json({
      status: true,
      data: response,
      message: 'Transaction table deleted successfully',
    });
  } catch (error) {
    logger.info(error, 'error in blob  file delete');
    res.status(400).send({ message: error, status: false });
  }
};
export const deleteImagesStorage = async (response, taskDetails) => {
  return new Promise((resolve, reject) => {
    try {
      const awt = [];
      for (let i = 0; i < response.length; i++) {
        switch (taskDetails.dmstype) {
          case 'azure':
            awt.push(
              _plimit(() => azureHelper._delete(response[i].repofilepath)),
            );
            break;
          case 'local':
            awt.push(_plimit(() => _localdelete(response[i].repofilepath)));
            break;
          default:
            awt.push(_plimit(() => _localdelete(response[i].repofilepath)));
            break;
        }
      }
      Promise.all(awt)
        .then(() => resolve(true))
        .catch(error => reject(error));
    } catch (error) {
      reject(error);
    }
  });
};

// function deleteImagesStorage(response, taskDetails, awt) {
// for (let i = 0; i < response.length; i++) {
//   // const chunk = payload.slice(i, i + chunkSize);
//   // eslint-disable-next-line default-case
//   switch (taskDetails.dmstype) {
//     case 'azure':
//       awt.push(_plimit(() => azureHelper._delete(response[i].repofilepath)));
//       break;
//     case 'local':
//       awt.push(_plimit(() => _localdelete(response[i].repofilepath)));
//       break;
//   }
// }
// }

export const deleteGraphicToolImagepath = async (req, res) => {
  const { deletePaths, taskDetails } = req.body;
  const newDeletePath = JSON.stringify(deletePaths);

  const sql = `Delete from wms_workflowactivitytrn_file_map where woincomingfileid=${taskDetails.woincomingfileid} 
  and 
  repofilepath = any (  
  (select array_agg(repofilepath) from json_to_recordset('${newDeletePath}') as x(repofilepath text)
  )::text[] 
  )`;

  logger.info(sql, 'deletesql');
  const awt = [];
  for (let i = 0; i < deletePaths.length; i++) {
    // const chunk = payload.slice(i, i + chunkSize);
    awt.push(_plimit(() => azureHelper._delete(deletePaths[i].repofilepath)));
  }
  await Promise.all(awt);

  await query(sql)
    .then(async datastrn => {
      console.log(datastrn, 'datacontacts');
      res.status(200).json({
        status: true,
        data: 'Trancesection table deleted successfully',
      });
    })
    .catch(error => {
      logger.info(error, 'error trn insert');
      res.status(400).send({ message: error, status: false });
    });
};

export const getLastFileName = async (req, res) => {
  const { woID } = req.body;
  try {
    const lastfilename = await _getLastFileName(woID);
    res.send(lastfilename);
  } catch (e) {
    logger.info(e, 'getlastfilename');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const _getLastFileName = async woID => {
  const sql = `select a.woincomingid , a.filename , a.newfilename  from wms_workorder_incomingfiledetails as a 
     left join wms_workorder_incoming as b on a.woincomingid = b.woincomingid 
     where b.woid = $1 and newfilename is not null order by a.filesequence  desc limit 1`;
  const data = await query(sql, [woID]);
  if (data.length > 0) {
    const { woincomingid, filename, newfilename } = data[0];
    return {
      woIncomingId: woincomingid,
      fileName: filename,
      newFileName: newfilename,
    };
  }
  const array = {};
  return array;
};

// tools Upload Actions
export const toolsUploadActions = async (req, res) => {
  console.log(req.body, 'neww', res);
  try {
    const { files, actionType, props, systemInfo, userid } = req.body;
    console.log(props, 'props');
    const val = [];
    files.forEach(list => {
      val.push(
        `('${list.name}', '${userid}', '${systemInfo}', '${list.data.replace(
          /\\/g,
          '/',
        )}', '${actionType}', ${props.profile.duId} )`,
      );
    });

    const sql2 = `INSERT INTO wms_toolsupload_actions_audit(filename,userid,systeminfo,actionpath,actiontype
      ,duid) values ${val}`;
    logger.info(sql2, val, 'data');
    await query(sql2);
    res.status(200).json({
      status: true,
      data: 'audit table inserted successfully',
    });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({ message: error, status: false });
  }
};

export const iTracksCall = async (req, res) => {
  // const url = 'http://localhost:8081/api/testDll';
  // let result = await service.get(`${url}`);
  res.send(true);
};

// Journal API module

export const addSatge = data => {
  const {
    duId,
    customerId,
    // receiptdate,
    // receiptdate,
    jobId,
    wotype,
    // eslint-disable-next-line no-unused-vars
    valuesOfArray,
    // duedate,
    // duedate,
    woid,
    isrelatedstage,
    stageId,
  } = data;
  let { plannedenddate, receiptdate, duedate, woId } = data;
  woId = woid || woId;
  let { woType } = data;
  return new Promise(async (resolve, reject) => {
    try {
      let tmp_plannedenddate;
      receiptdate = receiptdate
        ? receiptdate.trim().replace('T', ' ').substring(0, 19)
        : receiptdate;
      plannedenddate = plannedenddate
        ? plannedenddate.trim().replace('T', ' ').substring(0, 19)
        : plannedenddate;
      if (typeof duedate == 'object') {
        duedate = duedate
          ? duedate.toISOString().trim().replace('T', ' ').substring(0, 19)
          : duedate;
      } else if (typeof duedate == 'string') {
        duedate = duedate
          ? duedate.trim().replace('T', ' ').substring(0, 19)
          : duedate;
      } else {
        duedate = duedate
          ? duedate.trim().replace('T', ' ').substring(0, 19)
          : duedate;
      }

      woType = woType || wotype;
      if (woType === 'Journal') {
        const iDuId = await getiTracksDuId(duId);
        const iCustomerId = await getiTracksCustomerId(customerId);
        const iStageId = await getiTracksStageId(data);
        const fileDetails = await getFileDetails(data);
        if (isrelatedstage) {
          const relatedStagedet = await getTATforStage(woId, stageId);
          if (relatedStagedet != undefined && relatedStagedet.data.length) {
            tmp_plannedenddate = relatedStagedet.data[0].plannedenddate;
            if (tmp_plannedenddate != undefined) {
              plannedenddate = tmp_plannedenddate
                .toISOString()
                .replace('T', ' ')
                .substring(0, 19);
            }
          }
        }
        logger.info(iDuId, 'iDuId');
        logger.info(iStageId, 'iStageId');
        logger.info(iCustomerId, 'iCustomerId');
        logger.info(fileDetails, 'fileDetails');
        if (iDuId && iCustomerId && iStageId && fileDetails.length) {
          const url = config.iTracks.base_url;
          const headers = {
            iendpointkey: config.iTracks.uri.journal.iendpointKey,
            iendpointname: config.iTracks.uri.journal.addStage,
          };
          const payload = {
            BookCode: jobId,
            DivisionId: iDuId,
            CustomerId: iCustomerId,
            StageId: iStageId,
            ReceiveDate:
              receiptdate ||
              moment().toISOString().replace('T', ' ').substring(0, 19),
            DueDate: plannedenddate || duedate,
            MSPage: fileDetails[0].mspages,
          };
          logger.info(headers, 'headers for itracks addstage');
          logger.info(payload, 'payload for itracks addstage');
          const result = await service.iPost(url, payload, headers);
          // const result = {status: true,data: {status: true,test:""}}
          logger.info(result.data, 'result of addstage');
          const { status, Result } = result.data;
          if (status == false) {
            const itrackloginput = {
              url: '',
              payloaddata: '',
              headers: '',
              paramdata: '',
              iduid: 0,
              icustomerid: 0,
              status: '',
              failureplace: '',
              saveaction: '',
              isproduction: '',
              iscustomer: '',
              remarks: '',
            };

            const igerUrl = await axios.get(config.iTracks.switch_url);
            let iurl = `https://${igerUrl.data}/${config.iTracks.service_url}`;

            itrackloginput.url = iurl;
            itrackloginput.payloaddata = payload;
            itrackloginput.headers = headers;
            itrackloginput.paramdata = JSON.stringify(data);
            itrackloginput.iduid = iDuId;
            itrackloginput.icustomerid = iCustomerId;
            itrackloginput.status = status;
            itrackloginput.failureplace = 'addstage';
            itrackloginput.saveaction = '';
            itrackloginput.isproduction = false;
            itrackloginput.iscustomer = false;
            itrackloginput.remarks = Result;

            await insert_itrackservicecall(itrackloginput);
          }

          resolve({
            status,
            message: status
              ? Result
              : `${Result}. Please contact the iTrack Administrator`,
          });
        } else {
          resolve({
            status: false,
            message: `iTracks duid / stageid / customerid / file info not fount in iWMS`,
          });
        }
      } else {
        logger.info('inside book WO');
        resolve({ status: true });
      }
    } catch (e) {
      logger.info(e, 'first ee');
      reject(e.message ? e.message : e);
    }
  });
};

export const getiTracksCustomerId = customerId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT icustomerid FROM org_mst_customer WHERE customerid= ${customerId} AND isactive=true`;
    query(sql)
      .then(res => {
        logger.info(res, 'res for get iTracks customerid');
        if (res.length) {
          resolve(res[0].icustomerid);
        } else {
          resolve(false);
        }
      })
      .catch(error => {
        logger.info(error, 'error for get iTracks customerid');
        reject(false);
      });
  });
};

export const getiTracksDuId = duId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT iduid FROM org_mst_deliveryunit WHERE duid= ${duId} AND isactive=true`;
    logger.info(sql, 'sql for get iTracks duid');
    query(sql)
      .then(res => {
        logger.info(res, 'res for get iTracks duid');
        if (res.length) {
          resolve(res[0].iduid);
        } else {
          resolve(false);
        }
      })
      .catch(error => {
        logger.info(error, 'error for get iTracks duid');
        reject(false);
      });
  });
};

export const logisticEntryInsertJournal = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        userid,
        iStageId,
        iActivityId,
        startPage,
        endPage,
        wfeventid,
        duId,
        customerId,
        taskType,
        jobType,
      } = data;
      let { jobId } = data;
      logger.info(data, 'datadatadata new');
      const iDuId = await getiTracksDuId(duId);
      const iCustomerId = await getiTracksCustomerId(customerId);
      if (taskType == 'Multiple' && jobType == '2') {
        jobId = await getSubIssues(data);
      }

      logger.info(jobId, 'jobIddd');
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.logisticEntryInsert,
      };
      const payload = {
        BookCode: jobId,
        DivisionID: iDuId,
        CustomerID: iCustomerId,
        trandate: moment().toISOString(),
        activityId: iActivityId,
        startDate: moment().toISOString(),
        StageId: iStageId,
        EmpCode: userid,
        startPage: startPage || 1,
        endPage: endPage || 1,
      };
      logger.info(headers, 'headers for logistic entry insert itracks');
      logger.info(payload, 'payload for logistic entry insert itracks');

      const result = await service.iPost(url, payload, headers);
      logger.info(result.data, 'result of logistic entry insert');
      const { status, Result } = result.data;
      let worksheetRes = false;
      if (status) {
        worksheetRes = await addWorksheetId(Result, wfeventid);
      } else {
        resolve({
          status,
          message: `${Result}. Please contact the iTrack Administrator`,
        });
      }
      if (worksheetRes) {
        resolve({ status, message: Result });
      } else {
        resolve({ status, message: 'Worksheet id update failed' });
      }
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const logisticEntryUpdateJournal = async (
  data,
  isProduction,
  isCustomer,
  actionId,
  action,
) => {
  const {
    duId,
    customerId,
    userid,
    iStageId,
    iActivityId,
    endPage,
    quantity,
    wfeventId,
    worksheetId,
    jobId,
  } = data;

  const itrackloginput = {
    url: '',
    payloaddata: '',
    headers: '',
    paramdata: '',
    iduid: 0,
    icustomerid: 0,
    status: '',
    failureplace: '',
    saveaction: '',
    isproduction: '',
    iscustomer: '',
    remarks: '',
  };

  logger.info(data, 'datadatadata');
  const iDuId = await getiTracksDuId(duId);
  const iCustomerId = await getiTracksCustomerId(customerId);
  return new Promise(async (resolve, reject) => {
    try {
      const totMins = await calculateTaskTOT(wfeventId, userid);
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.logisticEntryUpdate,
      };
      let response = { status: false, Result: '' };
      logger.info(worksheetId, 'worksheetId from UI');
      const iWorksheetId = await _getWorksheetId(wfeventId);
      logger.info(iWorksheetId, 'iWorksheetId from iTracks');
      const payload = {
        BookCode: jobId,
        DivisionID: iDuId,
        CustomerID: iCustomerId,
        worksheetid: iWorksheetId,
        totMins,
        quantity: quantity || 0,
        statusId: actionId,
        remarks: 'test',
        activityId: iActivityId,
        StageId: iStageId,
        EmpCode: userid,
        Finishdate: moment().toISOString(),
        startPage: endPage ? 1 : 0,
        endPage: endPage || 0,
      };
      logger.info(headers, 'headers for logistic entry update itracks');
      logger.info(payload, 'payload for logistic entry update itracks');

      const result = await service.iPost(url, payload, headers);
      logger.info(result.data, 'result of logistic update insert');
      const { status, Result } = result.data;
      response = result.data;
      if (!status) {
        itrackloginput.url = url;
        itrackloginput.payloaddata = payload;
        itrackloginput.headers = headers;
        itrackloginput.paramdata = JSON.stringify(data);
        itrackloginput.iduid = iDuId;
        itrackloginput.icustomerid = iCustomerId;
        itrackloginput.status = status;
        itrackloginput.failureplace = 'logisticEntryUpdate';
        itrackloginput.saveaction = action;
        itrackloginput.isproduction = isProduction;
        itrackloginput.iscustomer = isCustomer;
        itrackloginput.remarks = Result;

        await insert_itrackservicecall(itrackloginput);

        resolve({
          status,
          Result: status
            ? Result
            : `${Result}. Please contact the iTrack Administrator`,
        });
      }
      if (response.status && action === 'save') {
        data.isProduction = isProduction;
        data.isCustomer = isCustomer;

        if (!isProduction && !isCustomer) {
          resolve(response);
        } else if (isProduction && isCustomer) {
          const prodDespatch = await taskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
          );
          if (prodDespatch.status) {
            const custDespatch = await taskDespatchJournal(
              { ...data, iDuId, iCustomerId },
              'customer',
            );
            resolve(custDespatch);
          } else {
            resolve(prodDespatch);
          }
        } else if (isProduction && !isCustomer) {
          const prodDespatch = await taskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
          );
          resolve(prodDespatch);
        } else if (!isProduction && isCustomer) {
          const custDespatch = await taskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'customer',
          );
          resolve(custDespatch);
        }
      } else {
        resolve(response);
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const taskDespatchJournal = (data, type) => {
  logger.info(data, 'data');
  const { userid, iStageId, quantity, jobId, iDuId, iCustomerId } = data;

  const itrackloginput = {
    url: '',
    payloaddata: '',
    headers: '',
    paramdata: JSON.stringify(data),
    iduid: iDuId,
    icustomerid: iCustomerId,
    status: '',
    failureplace: '',
    saveaction: '',
    isproduction: '',
    iscustomer: '',
    remarks: '',
  };

  return new Promise(async (resolve, reject) => {
    try {
      const url = config.iTracks.base_url;
      const headers = { iendpointkey: config.iTracks.uri.book.iendpointKey };
      let payload = {};
      if (type === 'production') {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          pagecount: quantity || 0,
          Finishdate: moment().toISOString(),
          PMEInstruction: 'testing',
        };
        itrackloginput.failureplace = 'ProductionDispatch';
        headers.iendpointname = config.iTracks.uri.journal.productionDispatch;
      } else {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          Finishdate: moment().toISOString(),
        };
        itrackloginput.failureplace = 'CustomerDispatch';
        headers.iendpointname = config.iTracks.uri.journal.customerDispatch;
      }

      logger.info(headers, 'headers for task despatch itracks');
      logger.info(payload, 'payload for task despatch itracks');

      const result = await service.iPost(url, payload, headers);
      logger.info(result, 'result of task despatch - journal');
      if (result.status) {
        const { status, Result } = result.data;

        if (status == false) {
          itrackloginput.url = url;
          itrackloginput.payloaddata = payload;
          itrackloginput.headers = headers;
          itrackloginput.status = status;
          // itrackloginput.failureplace ='logisticEntryUpdate',
          itrackloginput.saveaction = 'save';
          itrackloginput.isproduction = data.isProduction;
          itrackloginput.iscustomer = data.isCustomer;
          itrackloginput.remarks = Result;

          await insert_itrackservicecall(itrackloginput);
        }
      }
      resolve(result.data);
    } catch (e) {
      reject(e);
    }
  });
};

export const mergeIssue = async (articlesArray, data) => {
  let filename = '';
  for (let i = 0; i < articlesArray.length; i++) {
    filename += `'${articlesArray[i].filename}' ${
      articlesArray.length - 1 !== i ? ',' : ''
    } `;
  }
  if (filename.length > 0) {
    const sql = `select case when wwif.filetypeid = 4 then  ww.itemcode else  wwif.filename end as itemcode from wms_workorder_incomingfiledetails as wwif
        join wms_workorder_incoming as wwi on wwi.woincomingid=wwif.woincomingid
        join wms_workorder as ww on  ww.workorderid=wwi.woid
        where replace(wwif.filename,'_Article','') IN (${filename}) 
        and case when wwif.filetypeid = 4 then ww.workorderid NOT IN (${data.woid})
        and ww.status='Completed' else true end`;
    logger.info(sql, 'sqlllllll');
    const result = await query(sql, []);

    const articles = result.map(item => {
      return item.itemcode;
    });
    return new Promise(async resolve => {
      const url = config.iTracks.base_url;
      const headers = {
        iendpointkey: config.iTracks.uri.journal.iendpointKey,
        iendpointname: config.iTracks.uri.journal.mergeIssue,
      };
      const payload = {
        Articles: articles,
        Issue: data.jobId,
      };
      logger.info(headers, 'headers for merge issue itracks');
      logger.info(payload, 'payload for merge issue itracks');
      const rest = await service.iPost(url, payload, headers);
      const { status, Result } = rest.data;
      resolve({ status, message: Result });
    });
  }
  return Promise.resolve({ status: false, message: 'No filenames provided.' });
};

const getSubIssues = data => {
  const { fileName, customerId, workorderId } = data;
  return new Promise((resolve, reject) => {
    const sql = `select ww.itemcode from wms_workorder_incomingfiledetails as wwif
    join wms_workorder_incoming as wwi on wwi.woincomingid=wwif.woincomingid
    join wms_workorder as ww on  ww.workorderid=wwi.woid
    where replace(wwif.filename,'_Article','') ='${fileName}'  and ww.customerid=${customerId}
    and case when wwif.filetypeid = 4 then
     ww.workorderid NOT IN (${workorderId})
    and ww.status='Completed' else true end`;
    logger.info(sql, 'sqlllll');
    query(sql)
      .then(res => {
        resolve(res.length ? res[0].itemcode : '');
      })
      .catch(error => {
        reject(error);
      });
  });
};

// newItracks email trigger

export const getEmailTemplate = async (entityid, action) => {
  try {
    const sql = `SELECT * from wms_notifications WHERE entityid = ${entityid} and action = '${action}'`;
    logger.info(sql, 'sql for mail');
    const resForConfig = await query(sql);
    if (resForConfig.length > 0) {
      return resForConfig;
    }
    return false;
  } catch (error) {
    return false;
  }
};

export const getDivisionGroupMailid = async (divisionid, customerid) => {
  try {
    const sql = `select mailtype, mailid from iquality.svnd_trn_divisiongroupmail where divisionid = ${divisionid} and customerid = ${customerid} and modulename = 'quality'`;
    const divGropuMailid = await query(sql);
    if (divGropuMailid.length > 0) {
      return divGropuMailid;
    }
    return [];
  } catch (error) {
    return [];
  }
};

function extractEmails(emails) {
  return emails.filter(email => email.includes('@'));
}

async function getMailCentralQuality() {
  const centralQualitySQL = `
    SELECT ud.useremail
    FROM public.wms_user_details ud
    LEFT JOIN public.wms_userrole ur ON ur.userid = ud.userid
    LEFT JOIN public.wms_role r ON r.roleid = ur.roleid
    WHERE r.roleacronym = 'CQH'
    GROUP BY ud.useremail
  `;
  const mailForCQH = await query(centralQualitySQL);
  return mailForCQH.map(emailObj => emailObj.useremail);
}

async function getMailForTo(TOGroup, RaisedToId) {
  const toSQL = `
    SELECT ud.useremail
    FROM public.wms_user_details ud
    LEFT JOIN public.wms_userrole ur ON ur.userid = ud.userid
    LEFT JOIN public.wms_role r ON r.roleid = ur.roleid
    WHERE ud.duid IN (${RaisedToId})
    AND r.roleacronym IN (${TOGroup.map(role => `'${role}'`).join(', ')})
    GROUP BY ud.useremail
  `;

  const mailForTo = await query(toSQL);
  return mailForTo.map(emailObj => emailObj.useremail);
}

async function getMailForCC(CCGroup, RaisedFrom, userid) {
  const toSQL = `
  select ud.useremail from  public.wms_user_details ud
  left join public.wms_userrole ur on ur.userid = ud.userid
  left join public.wms_role r on r.roleid = ur.roleid
  where ud.duid IN (${RaisedFrom})
  and r.roleacronym IN (${CCGroup.map(role => `'${role}'`).join(
    ', ',
  )}) group by ud.useremail
  union all
  select ud.useremail from  public.wms_user_details ud where 	 ud.userid = '${userid}'
  `;
  const mailForCC = await query(toSQL);
  return mailForCC.map(emailObj => emailObj.useremail);
}

function modifyNotificationConfigFromEmails(
  mailConfig,
  mailCentralQuality,
  mailTo,
  mailCC,
  mailIDinTO,
  mailIDinCC,
  KAMmail,
  CMmail,
  PMmail,
) {
  // Combine all email IDs
  const allEmails = [
    ...mailCentralQuality,
    ...mailTo,
    ...mailIDinTO,
    ...KAMmail,
    ...CMmail,
    ...PMmail,
  ];

  // Deduplicate and filter out null values
  mailConfig.to = [...new Set(allEmails)].filter(
    email => email && email !== 'null',
  );
  mailConfig.cc = [...new Set([...mailCC, ...mailIDinCC])].filter(
    email => email && email !== 'null',
  );

  // Remove email IDs that exist in both to and cc arrays
  mailConfig.cc = mailConfig.cc.filter(email => !mailConfig.to.includes(email));
  return mailConfig;
}

function checkAndPushKAMMailIfConditionMet(
  mailAction,
  mailConfig,
  roleToCheck,
  emailToPush,
  feedbackId,
) {
  if (
    mailAction !== 'IC' &&
    feedbackId?.split('-')[0] !== 'IA' &&
    (mailConfig.to.includes(roleToCheck) ||
      (mailConfig.cc.includes(roleToCheck) && emailToPush != null))
  ) {
    const uniqueEmails = [...new Set(emailToPush)];
    return uniqueEmails;
  }
  return [];
}
function checkAndPushMailIfConditionMet(mailConfig, roleToCheck, emailToPush) {
  if (
    mailConfig.to.includes(roleToCheck) ||
    (mailConfig.cc.includes(roleToCheck) && emailToPush != null)
  ) {
    const uniqueEmails = [...new Set(emailToPush)];
    return uniqueEmails;
  }
  return [];
}

export async function sendMail(data) {
  const endpointUrl = `${process.env.CLIENT_HOST}:${process.env.CLIENT_PORT}`;
  const {
    feedbackId,
    encryptedID,
    mailAction,
    entityid,
    BookCode,
    Raisedby,
    RaisedFrom,
    RaisedFromDU,
    RaisedTo,
    RaisedToId,
    CustomerId,
    RaisedOn,
    CustomerName,
    CustomerDivision,
    CustomerCountry,
    Description,
    userid,
    SubDu,
    JobFamily,
    BookCodekamEmail,
    BookCodeCMEmail,
    BookCodePMEmail,
    MisStatus,
  } = data;

  const resForConfig = await getEmailTemplate(entityid, mailAction);
  const { notificationconfig } = resForConfig[0];

  const mailIDinTO = extractEmails(notificationconfig.to);
  const mailIDinCC = extractEmails(notificationconfig.cc);
  const mailCentralQuality =
    notificationconfig.to.includes('CQH') ||
    notificationconfig.cc.includes('CQH')
      ? await getMailCentralQuality(notificationconfig)
      : [];

  const TOGroup = notificationconfig.to;
  const CCGroup = notificationconfig.cc;
  const mailTo =
    RaisedToId != null && RaisedToId != ''
      ? await getMailForTo(TOGroup, RaisedToId)
      : await getMailForTo(TOGroup, RaisedFrom);
  const mailCC = await getMailForCC(CCGroup, RaisedFrom, userid);
  let KAMmail = [];
  let CMmail = [];
  let PMmail = [];
  KAMmail = checkAndPushKAMMailIfConditionMet(
    mailAction,
    notificationconfig,
    'KAM',
    BookCodekamEmail,
    feedbackId,
  );
  CMmail = checkAndPushMailIfConditionMet(
    notificationconfig,
    'CM',
    BookCodeCMEmail,
  );
  PMmail = checkAndPushMailIfConditionMet(
    notificationconfig,
    'PME',
    BookCodePMEmail,
  );
  const divisionGroupMailid = await getDivisionGroupMailid(
    RaisedToId,
    CustomerId,
  );
  divisionGroupMailid.forEach(item => {
    if (item.mailtype.toLowerCase() === 'cc') {
      if (Array.isArray(item.mailid)) {
        mailCC.push(...item.mailid);
      } else {
        mailCC.push(item.mailid);
      }
    } else if (item.mailtype.toLowerCase() === 'to') {
      if (Array.isArray(item.mailid)) {
        mailTo.push(...item.mailid);
      } else {
        mailTo.push(item.mailid);
      }
    }
  });

  const updatedNotificationConfig = await modifyNotificationConfigFromEmails(
    notificationconfig,
    mailCentralQuality,
    mailTo,
    mailCC,
    mailIDinTO,
    mailIDinCC,
    KAMmail,
    CMmail,
    PMmail,
  );

  const mailData = {
    ...updatedNotificationConfig,
    feedbackId,
    BookCode,
    encryptedID,
    Raisedby,
    RaisedFrom,
    RaisedFromDU,
    RaisedTo,
    RaisedOn,
    CustomerName,
    CustomerDivision,
    CustomerCountry,
    Description,
    userid,
    SubDu,
    JobFamily,
    endpointUrl,
    MisStatus,
  };
  console.log(mailData);
  emitAction(mailData);
  return true;
}

export const mailTriggerForiTracks = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      // eslint-disable-next-line prefer-template, prettier/prettier
      const endpointUrl =
        // eslint-disable-next-line prefer-template
        process.env.CLIENT_HOST + ':' + process.env.CLIENT_PORT;
      const {
        feedbackId,
        encryptedID,
        mailAction,
        entityid,
        BookCode,
        Raisedby,
        RaisedFrom,
        RaisedTo,
        RaisedOn,
        CustomerName,
        CustomerDivision,
        CustomerCountry,
        Description,
        userid,
        SubDu,
        JobFamily,
      } = data;
      try {
        const mailTo = [];
        const mailCentralQuality = [];
        const mailCC = [];
        const mailIDinTO = [];
        const mailIDinCC = [];
        const resForConfig = await getiTracksNotificationConfig(
          entityid,
          mailAction,
        );
        const { notificationconfig } = resForConfig[0];
        // mail ID's from Central Quality
        for (const item of resForConfig[0].notificationconfig.to) {
          if (item.includes('@')) {
            const emails = item.match(/\S+@\S+\.\S+/);
            if (emails) {
              mailIDinTO.push(emails[0]);
            }
          }
        }
        for (const item of resForConfig[0].notificationconfig.cc) {
          if (item.includes('@')) {
            const emails = item.match(/\S+@\S+\.\S+/);
            if (emails) {
              mailIDinCC.push(emails[0]);
            }
          }
        }
        if (
          resForConfig[0].notificationconfig.to.length > 0 &&
          resForConfig[0].notificationconfig.to.includes('CQH')
        ) {
          const centralQuality = `select ud.useremail from  public.wms_user_details ud
          left join public.wms_userrole ur on ur.userid = ud.userid
          left join public.wms_role r on r.roleid = ur.roleid
          where  r.roleacronym = 'CQH' group by ud.useremail
          `;
          const mailForCQH = await query(centralQuality);
          if (mailForCQH.length > 0) {
            for (const emailObj of mailForCQH) {
              mailCentralQuality.push(emailObj.useremail);
            }
          }
        }

        // mail ID's from To Roles
        if (resForConfig[0].notificationconfig.to.length > 0) {
          const TOGroup =
            // eslint-disable-next-line prefer-template
            "'" + resForConfig[0].notificationconfig.to.join("', '") + "'";
          const ToQL = `select ud.useremail from  public.wms_user_details ud
          left join public.wms_userrole ur on ur.userid = ud.userid
          left join public.wms_role r on r.roleid = ur.roleid
          where ud.duid in (select udd.duid from public.wms_user_details udd
          where udd.duname = '${RaisedTo}')
          and r.roleacronym IN (${TOGroup}) group by ud.useremail
          `;
          const mailForTo = await query(ToQL);
          if (mailForTo.length > 0) {
            for (const emailObj of mailForTo) {
              mailTo.push(emailObj.useremail);
            }
          }
        }
        resForConfig[0].notificationconfig.to.length = 0;
        resForConfig[0].notificationconfig.to.push(
          ...mailCentralQuality,
          ...mailTo,
          ...mailIDinTO,
        );
        if (resForConfig[0].notificationconfig.cc.length > 0) {
          const CCGroup =
            // eslint-disable-next-line prefer-template
            "'" + resForConfig[0].notificationconfig.cc.join("', '") + "'";
          const CCTL = `select ud.useremail from  public.wms_user_details ud
          left join public.wms_userrole ur on ur.userid = ud.userid
          left join public.wms_role r on r.roleid = ur.roleid
          where ud.duid in (select udd.duid from public.wms_user_details udd
          where udd.userid = '${userid}')
          and r.roleacronym IN (${CCGroup}) group by ud.useremail
          union all
          select ud.useremail from  public.wms_user_details ud where 	 ud.userid = '${userid}'
          `;
          const mailForCC = await query(CCTL);
          if (mailForCC.length > 0) {
            resForConfig[0].notificationconfig.cc.length = 0;
            for (const emailObj of mailForCC) {
              mailCC.push(emailObj.useremail);
            }
          }
        }
        resForConfig[0].notificationconfig.cc.length = 0;
        resForConfig[0].notificationconfig.cc.push(...mailCC, ...mailIDinCC);
        const mailData = {
          ...notificationconfig,
          feedbackId,
          encryptedID,
          BookCode,
          Raisedby,
          RaisedFrom,
          RaisedTo,
          RaisedOn,
          CustomerName,
          CustomerDivision,
          CustomerCountry,
          Description,
          userid,
          SubDu,
          JobFamily,
          endpointUrl,
        };
        emitAction(mailData);
        resolve(true);
      } catch (error) {
        console.log(error, 'mail sending error');
        // res.status(400).send({ message: 'Failed sending email', error });
        reject(false);
      }
      // });
      resolve(true);
    } catch (e) {
      reject(false);
    }
  });
};

export const getiTracksNotificationConfig = (entityid, action) => {
  return new Promise(async resolve => {
    try {
      let sql = '';
      sql = `SELECT * from wms_notifications WHERE entityid= ${entityid} and action='${action}'`;
      logger.info(sql, 'sql for mail');
      query(sql).then(resForConfig => {
        if (resForConfig.length > 0) {
          resolve(resForConfig);
        } else {
          resolve(false);
        }
      });
    } catch (e) {
      resolve(false);
    }
  });
};

export const relatedStageInfo = async (wfId, customerId, stageId) => {
  return new Promise(async resolve => {
    // and wcssr.triggerrelatedstage = case when (wcssr.stageid = 2 and wcssr.customerid = 13 and (select count(1) from wms_workorder_stage where workorderid=${woId} and wfstageid=2 and status !='YTS' )>0) then false else true end
    try {
      const sql = `select  resq.wfid,resq.stageid,resq.stagename,wfsub.seq from
    (
      select wcssr.wfid,st.stageid,st.stagename FROM wms_config_splited_stage_relation wcssr 
      join wms_mst_stage st ON st.stageid = any(wcssr.relatedstage)  
      WHERE wcssr.stageid = ${stageId}  and wcssr.customerid =  ${customerId}  
      and wcssr.isactive = true
      order by wcssr.wfid , wcssr.stageid
    ) as resq
    join (select stageid, min(sequence) as seq from wms_workflowdefinition where wfid = ${wfId}  
    group by stageid   order by seq) as wfsub on wfsub.stageid =  resq.stageid
    order by wfsub.seq`;

      console.log(sql);
      await query(sql).then(data => {
        resolve({ issuccess: true, data, message: 'success' });
      });
    } catch (error) {
      resolve({ issuccess: false, message: error?.message });
    }
  });
};
export const getTATforStage = async (workorderId, stageId) => {
  return new Promise(async resolve => {
    const sql = `select plannedstartdate, plannedenddate from wms_workorder_stage where workorderid = ${workorderId} and wfstageid = ${stageId}`;
    await query(sql).then(data => {
      resolve({ issuccess: true, data, message: 'success' });
    });
  });
};

export const insert_itrackservicecall = async inputdata => {
  // try {
  const {
    url,
    payloaddata,
    headers,
    paramdata,
    iduid,
    icustomerid,
    status,
    failureplace,
    saveaction,
    isproduction,
    iscustomer,
    remarks,
  } = inputdata;
  const jsongpayload = JSON.stringify(payloaddata);
  const jsonheaders = JSON.stringify(headers);
  return new Promise(async resolve => {
    try {
      const sql = `insert into wms_servicecall_entry (url,payloaddata,headers,paramdata, iduid, icustomerid,status,failureplace,saveaction,isproduction,iscustomer,remarks)
                VALUES ('${url}','${jsongpayload}','${jsonheaders}','${paramdata}',
                        ${iduid}, ${icustomerid}, ${status},'${failureplace}','${saveaction}',
                        ${isproduction},${iscustomer},'${remarks}')`;
      await query(sql).then(data => {
        console.log(data);
        // resolve({ issuccess: true,  message: 'success' });
      });
      resolve({ issuccess: true, message: 'success' });
    } catch (error) {
      console.log(error);
      resolve({ issuccess: false, message: 'failed' });
    }
  });
};

export const stageRetrigger = async (req, res) => {
  try {
    console.log(req);
    const sql = `select replace(replace(payloaddata->>'Finishdate','T',' '),'Z',''):: timestamp AS finisheddate, servicecallid,url,payloaddata,headers,paramdata,iduid,icustomerid,status,saveaction,failureplace,
    isproduction,iscustomer,remarks,isretriggered
    from public.wms_servicecall_entry
    where coalesce(isretriggered,false) = false 
    and failureplace in ('addstage')
    order by servicecallid`;

    const getdata = await query(sql);

    if (getdata && getdata.length) {
      for (let index = 0; index < getdata.length; index++) {
        const { servicecallid, url, payloaddata } = getdata[index];
        const headers = {
          iendpointkey: config.iTracks.uri.journal.iendpointKey,
          iendpointname: config.iTracks.uri.journal.addStage,
        };
        let result = await service.iPost(url, payloaddata, headers);
        // const { status : rstatus } = result.data;

        if (result) {
          const retriggerstatus = result.status;
          const retriggerremarks = result.Result;

          const upsql = `update public.wms_servicecall_entry set 
          isretriggered = ${retriggerstatus}, retriggerremarks = '${retriggerremarks}', retriggerdate = now()
          where servicecallid = ${servicecallid}`;
          await query(upsql);
        }
      }
    }
  } catch (e) {
    console.log(e);
  } finally {
    res.status(200).send({ status: 'completed' });
  }
};

export const logisticEntryUpdateRetrigger = async (req, res) => {
  try {
    const sql = `select replace(replace(payloaddata->>'Finishdate','T',' '),'Z',''):: timestamp AS finisheddate, servicecallid,url,payloaddata,headers,paramdata,iduid,icustomerid,status,saveaction,failureplace,
                isproduction,iscustomer,remarks,isretriggered
                from public.wms_servicecall_entry
                where coalesce(isretriggered,false) = false 
                and failureplace in ('ProductionDispatch','logisticEntryUpdate','CustomerDispatch')
                order by servicecallid`;
    console.log(req);
    const getdata = await query(sql);

    if (getdata && getdata.length) {
      for (let index = 0; index < getdata.length; index++) {
        const {
          servicecallid,
          url,
          payloaddata,
          headers,
          paramdata,
          iduid,
          icustomerid,
          status,
          saveaction,
          failureplace,
          isproduction,
          iscustomer,
        } = getdata[index];
        console.log(status);
        const retstatus = await retriggerUpdateLogisticeEntry(
          url,
          payloaddata,
          headers,
          paramdata,
          iduid,
          icustomerid,
          isproduction,
          iscustomer,
          saveaction,
          failureplace,
        );

        if (retstatus) {
          const retriggerstatus = retstatus.status;
          const retriggerremarks = retstatus.Result;

          const upsql = `update public.wms_servicecall_entry set 
          isretriggered = ${retriggerstatus}, retriggerremarks = '${retriggerremarks}', retriggerdate = now()
          where servicecallid = ${servicecallid}`;
          await query(upsql);
        }
      }
    }
  } catch (error) {
    console.log(error);
  } finally {
    res.status(200).send({ status: 'completed' });
  }
};

const retriggerUpdateLogisticeEntry = async (
  url,
  payload,
  headers,
  paramdata,
  iduid,
  icustomerid,
  isProduction,
  isCustomer,
  saveaction,
  failureplace,
) => {
  return new Promise(async resolve => {
    try {
      const data = paramdata;
      const iDuId = iduid;
      const iCustomerId = icustomerid;
      const { Finishdate } = payload;
      let result = { status: true, data: { status: true, Result: '' } };
      payload.Finishdate = Finishdate.replace('T', ' ').substring(0, 19);

      if (failureplace == 'logisticEntryUpdate') {
        result = await service.iPost(url, payload, headers);
      }

      const { status } = result.data;

      console.log(status);
      data.isProduction = isProduction;
      data.isCustomer = isCustomer;

      if (status && saveaction == 'save') {
        if (isProduction && isCustomer) {
          const prodDespatch = await retriggerTaskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
            payload,
          );
          if (prodDespatch.status) {
            const custDespatch = await retriggerTaskDespatchJournal(
              { ...data, iDuId, iCustomerId },
              'customer',
              payload,
            );
            resolve(custDespatch);
          } else {
            resolve(prodDespatch);
          }
        } else if (isProduction && !isCustomer) {
          const prodDespatch = await retriggerTaskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'production',
            payload,
          );
          resolve(prodDespatch);
        } else if (!isProduction && isCustomer) {
          const custDespatch = await retriggerTaskDespatchJournal(
            { ...data, iDuId, iCustomerId },
            'customer',
            payload,
          );
          resolve(custDespatch);
        } else {
          resolve({ status: false, Result: 'no codition execute' });
        }
      } else {
        resolve(result.data);
      }
    } catch (er) {
      // console.log(er.message);
      resolve({ status: true, Result: er.message });
    }
  });
};

export const retriggerTaskDespatchJournal = async (
  data,
  type,
  parampayload,
) => {
  logger.info(data, 'data');
  const { userid, iStageId, quantity, jobId, iDuId, iCustomerId } = data;
  const { Finishdate } = parampayload;
  return new Promise(async resolve => {
    try {
      const url = config.iTracks.base_url;
      const headers = { iendpointkey: config.iTracks.uri.book.iendpointKey };
      let payload = {};
      if (type === 'production') {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          pagecount: quantity || 0,
          Finishdate:
            Finishdate.replace('T', ' ').substring(0, 19) ||
            moment().toISOString(),
          PMEInstruction: 'testing',
        };

        headers.iendpointname = config.iTracks.uri.journal.productionDispatch;
      } else {
        payload = {
          BookCode: jobId,
          DivisionID: iDuId,
          CustomerID: iCustomerId,
          StageId: iStageId,
          EmpCode: userid,
          Finishdate:
            Finishdate.replace('T', ' ').substring(0, 19) ||
            moment().toISOString(),
        };

        headers.iendpointname = config.iTracks.uri.journal.customerDispatch;
      }

      logger.info(headers, 'headers for task despatch itracks');
      logger.info(payload, 'payload for task despatch itracks');

      const result = await service.iPost(url, payload, headers);
      logger.info(result, 'result of task despatch - journal');

      resolve(result.data);
    } catch (e) {
      resolve({ status: false, Result: e.message });
      // console.log(e)
    }
  });
};
