import { query } from '../../database/postgres.js';
import {
  getFileInfoDetails,
  fetchValidationDetails,
} from '../task/fileDetails.js';
import { getBasicToolsData } from '../utils/tools/index.js';
import logger from '../utils/logs/index.js';

export const getToolDetail = async (req, res) => {
  const { toolId } = req.body;
  try {
    const toolsDetail = await getBasicToolsData(toolId);
    res.send(toolsDetail ? toolsDetail[0] : []);
  } catch (e) {
    logger.info(e, 'getToolDetail');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const getFileDetails = async (req, res) => {
  const {
    wfEventId,
    workOrderId,
    du,
    customer,
    service,
    stage,
    activity,
    softwareId,
    fileConfig,
    placeHolders,
    mandatorySaveFile,
    eventData,
  } = req.body;
  try {
    const validationFileConfig =
      fileConfig && fileConfig.fileTypes ? fileConfig.fileTypes : {};
    const typesId =
      fileConfig && fileConfig.fileTypesId ? fileConfig.fileTypesId : [];
    const softwareDetails = await getSoftwareDetails(softwareId);
    const fileTypes = await getFileTypes();
    const filesInfo = await getFileInfoDetails({
      wfEventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId,
    });
    const filesData = await fetchValidationDetails(
      filesInfo,
      validationFileConfig,
      placeHolders,
      eventData,
      mandatorySaveFile,
      workOrderId,
    );
    res.send({
      ...filesData,
      fileTypes,
      validationFileConfig,
      softwareDetails,
    });
  } catch (e) {
    logger.info(e, 'getFileDetails');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

const getSoftwareDetails = softwareId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM public.wms_mst_software where appid = any($1) and isactive = $2`;
      const softwareDetails = await query(sql, [softwareId, true]);
      resolve(softwareDetails);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

const getFileTypes = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT filetypeid, filetype FROM public.pp_mst_filetype
            ORDER BY filetypeid ASC `;
      const fileTpes = await query(sql);
      resolve(fileTpes);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

const getFileTrnQuery = type => {
  switch (type) {
    case 'insert_new_file':
      return `INSERT INTO wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES ($1, $2, $3, $4, $5, $6)`;
    case 'update_existing_file':
      return `UPDATE wms_workflowactivitytrn_file_map SET ischeckedout = $1 WHERE actfilemapid = $2`;
    case 'open_files':
      return `UPDATE wms_workflowactivitytrn_file_map SET isdownloaded = $1, workingfolderpath = $2, ischeckedout = $3 WHERE actfilemapid = $4`;
    default:
      return '';
  }
};

const getFileTrnQueryParams = (type, payload) => {
  switch (type) {
    case 'insert_new_file':
      return [
        payload.wfEventId,
        payload.uuid,
        payload.path,
        true,
        false,
        payload.fileId,
      ];
    case 'update_existing_file':
      return [false, payload.actFileMapId];
    case 'open_files':
      return [true, payload.path, payload.isCheckedOut, payload.actFileMapId];
    default:
      return [];
  }
};

export const updateFileTRNLog = (req, res) => {
  const { type, payload } = req.body;
  const sql = getFileTrnQuery(type);
  const params = getFileTrnQueryParams(type, payload);
  query(sql, params)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      logger.info(e, 'updateFileTRNLog');
      res.status(400).send(e.message ? e.message : e);
    });
};
export const updateNewFileName = (req, res) => {
  const { incomingFileId, newFileName } = req.body;
  const sql = `UPDATE public.wms_workorder_incomingfiledetails
	SET newfilename='${newFileName}'
	WHERE woincomingfileid=${incomingFileId};`;
  query(sql)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      logger.info(e, 'updateNewFileName');
      res.status(400).send(e.message ? e.message : e);
    });
};

export const updateNewFileNameFromTools = (req, res) => {
  const { incomingFileId, newFileName } = req.body;
  const sql = `UPDATE public.wms_workorder_incomingfiledetails
	SET newfilename='${newFileName}'
	WHERE woincomingfileid=${incomingFileId};`;
  query(sql)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      logger.info(e, 'updateNewFileNameFromTools error');
      res.status(200).send(false);
    });
};

export const getFileSequence = (req, res) => {
  const { woid } = req.body;
  const sql = `select woin.filename,woin.filesequence  from wms_workorder_incoming as wo
  join  wms_workorder_incomingfiledetails as woin on woin.woincomingid = wo.woincomingid
  where wo.woid = ${woid}  and woin.filetypeid != 10 order by woin.filesequence;`;
  query(sql)
    .then(response => {
      res.status(200).send({ data: response, status: true });
    })
    .catch(e => {
      logger.info(e, 'updateNewFileNameFromTools error');
      res.status(200).send(false);
    });
};
