import fs, { createReadStream } from 'fs';
import moment from 'moment';
import download from 'download';
import FormData from 'form-data';
import { query } from '../../database/postgres.js';
import { emitAction } from '../activityListener/index.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';
import logger from '../utils/logs/index.js';
import * as azureHelper from '../utils/azure/index.js';

const service = new Service();

export const getDynamicColumns = (req, res) => {
  const { entityId, roleid, skillid, screenId, userid } = req.body;
  logger.info(entityId, 'entityIdentityId');
  let entityIdArray = '';
  if (entityId instanceof Array) {
    entityIdArray = entityId;
  } else {
    entityIdArray = [entityId];
  }
  const condition = `entityid = any($1) AND ( userid = $2 OR (roleid = $3 AND (skillid = any($4) OR skillid IS NULL))) AND screenid = $5`;
  const sql = `SELECT *,filterValues as defaultFilterValues FROM public.wms_viewconfig_details WHERE ${condition} ORDER BY viewid ASC `;
  logger.info(sql, 'sql');
  query(sql, [entityIdArray, userid, roleid, skillid, screenId])
    .then(data => {
      console.log('dataaa', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJournalDetail = async data => {
  const { journalshortname, customershortname } = data;
  return new Promise(async resolve => {
    const sql = `SELECT * from public.getjournaldetail('${journalshortname}', '${customershortname}')`;
    query(sql)
      .then(response => {
        console.log(response);
        if (response && response.length) {
          if (response[0].j && response[0].j.length) {
            resolve(response[0].j);
          } else {
            resolve({ error: 'Journal data not found in new wms' });
          }
        } else {
          resolve({ error: 'Journal data not found in new wms' });
        }
      })
      .catch(() => {
        resolve({ error: 'Journal data not found in new wms' });
      });
  });
};

export const getNotificationConfig = (data, action) => {
  return new Promise(async resolve => {
    try {
      const { entityId, workorderId, serviceId, customerId, duId, wfeventId } =
        data;
      let sql = '';
      if (
        action != 'create' &&
        action != 'iterate/next' &&
        action != 'onlineproof' &&
        action != 'notify_production' &&
        action != 'auto_create_success' &&
        action != 'auto_create_failure' &&
        action != 'auto_stage_trigger_success' &&
        action != 'auto_stage_trigger_failure' &&
        action != 'save_pm' &&
        action != 'common_failure'
      ) {
        logger.info('not equal create');
        sql = `
                    SELECT wmc.isprimary ,wo.workorderid,wmc.contactid,wmc.contactname,wmc.contactemail,wmc.contactrole,wo.itemcode,oms.customername,
                    wo.totalchaptercount, wo.printisbn, wo.totalarticlecount, wo.totalnonarticlecount,
                    wo.wotype, wo.jobtype, wo.doinumber, du.duname, wmc.contacttype, wo.title, journal.journalname,journal.journalacronym,wo.doinumber,
                    wif.filename, wo.issuenumber, wo.volumenumber FROM wms_workorder as wo
                    JOIN wms_workorder_contacts wmc ON wmc.workorderid = wo.workorderid
                    JOIN org_mst_customer as oms ON oms.customerid = wo.customerid
                    JOIN wms_workflow_eventlog as wfel ON wfel.workorderid = wo.workorderid
				left JOIN wms_workorder_incomingfiledetails as wif ON wif.woincomingfileid = wfel.woincomingfileid
                    JOIN org_mst_deliveryunit as du ON du.duid = ${duId}
                    left  JOIN pp_mst_journal as journal ON journal.journalid = wo.journalid
                    WHERE wo.workorderid = ${workorderId} AND wmc.contactrole IN ('PM','SPM','AUTHOR','CO-AUTHOR','PED') AND wfel.wfeventid = ${wfeventId}
                   `;
      } else if (
        action === 'auto_create_success' ||
        action === 'auto_create_failure' ||
        action === 'auto_stage_trigger_success' ||
        action === 'save_pm' ||
        action === 'auto_stage_trigger_failure'
      ) {
        sql = `SELECT * from wms_notifications WHERE customerid= ${customerId} and action='${action}'`;
      } else if (action == 'common_failure') {
        sql = `SELECT * from wms_notifications WHERE customerid= ${customerId} and action='${action}'`;
      } else {
        sql = `SELECT wmc.isprimary ,wo.workorderid,wmc.contactid,wmc.contactname,wmc.contactemail,wmc.contactrole,wo.itemcode,oms.customername,
                    notif.notificationconfig, notif.type,wo.totalchaptercount, wo.printisbn, wo.totalarticlecount, wo.totalnonarticlecount,
                    wo.wotype, wo.jobtype, wo.doinumber, du.duname, wmc.contacttype, wo.title, journal.journalname, journal.journalacronym, wo.issuenumber, wo.volumenumber ,
                    journal.journalemail
                    FROM wms_workorder as wo
                    JOIN wms_workorder_contacts wmc ON wmc.workorderid = wo.workorderid
                    JOIN org_mst_customer as oms ON oms.customerid = wo.customerid
                    JOIN wms_notifications as notif ON notif.customerid = wo.customerid
                    LEFT JOIN pp_mst_journal as journal ON journal.journalid = wo.journalid
                    JOIN org_mst_deliveryunit as du ON du.duid = ${duId}
                    WHERE wo.workorderid = ${workorderId} AND notif.entityid = ${entityId}
                    AND wmc.contactrole IN ('PM','SPM','AUTHOR') AND notif.action = '${action}' `;
      }

      logger.info(sql, 'sql for mail');
      query(sql).then(resForConfig => {
        logger.info(resForConfig, 'resForConfig');
        if (resForConfig.length > 0 && action == 'common_failure') {
          resolve(resForConfig);
        } else if (resForConfig.length > 0) {
          sql = `SELECT servicename FROM wms_mst_service WHERE serviceid IN(${serviceId})`;
          query(sql).then(resForServices => {
            let services = '';
            if (resForServices && resForServices.length) {
              resForServices.forEach((item, i) => {
                services +=
                  resForServices.length - 1 != i
                    ? `${item.servicename}, `
                    : item.servicename;
              });
            }
            console.log(services, 'concated services');
            resForConfig.forEach(item => {
              item.services = services;
            });
            console.log(resForConfig, 'resForConfig 111');
            resolve(resForConfig);
          });
        } else {
          logger.info('get notification config empty');
          resolve(false);
        }
      });
    } catch (e) {
      logger.info('get notification config failed');
      resolve(false);
    }
  });
};

export const getWorkflowConfig = (data, action) => {
  const {
    duId,
    entityId,
    workorderId,
    serviceId,
    wfdefid,
    stageName,
    stageDuedate,
    iteration,
    stageId,
    wfeventId,
  } = data;
  return new Promise(async resolve => {
    try {
      logger.info(serviceId, 'serviceId');
      const sql = `SELECT config FROM wms_workflowdefinition WHERE wfdefid = ${wfdefid}`;
      logger.info(sql, 'sql');
      query(sql).then(async resForWfConfig => {
        logger.info(resForWfConfig, 'resForWfConfig');
        if (resForWfConfig.length > 0) {
          const getObj = resForWfConfig[0];
          console.log(
            getObj.config.actions.workflow[action].capture,
            'getObj.config.actions.workflow[action].capture',
          );
          const { email, emailConfig } =
            getObj.config.actions.workflow[action].capture;
          logger.info(email, 'emailemail11');
          if (email == true) {
            const { template, subject, from, to, cc, bcc } = emailConfig;
            logger.info(email, 'innnnnnnn');
            const payload = {
              entityId,
              workorderId,
              serviceId,
              duId,
              wfeventId,
            };
            const resForConfig = await getNotificationConfig(payload, action);
            if (resForConfig.length > 0) {
              const pmI = resForConfig.findIndex(
                val => val.contactrole === 'PM' && val.isprimary,
              );
              logger.info(pmI, 'pmI');
              const spmI = resForConfig.findIndex(
                val => val.contactrole === 'SPM' && !val.isprimary,
              );
              logger.info(spmI, 'spmI');
              const authorI = resForConfig.findIndex(
                val =>
                  val.contactrole === 'AUTHOR' &&
                  val.contacttype === 'Customer',
              );
              logger.info(authorI, 'authorI');
              const {
                workorderid,
                customername,
                duname,
                itemcode,
                services,
                totalchaptercount,
                printisbn,
                totalarticlecount,
                totalnonarticlecount,
                wotype,
                jobtype,
                title,
                journalname,
                doinumber,
                journalacronym,
                filename,
                issuenumber,
                volumenumber,
              } = resForConfig[0];
              const mailObj = {};
              if (pmI != -1) {
                console.log('inside pm');
                mailObj.toPm = resForConfig[pmI].contactemail;
              }
              if (spmI != -1) {
                console.log('inside spm');
                mailObj.toSpm = resForConfig[spmI].contactemail;
              }
              if (authorI != -1) {
                console.log('inside spm');
                mailObj.toAuthor = resForConfig[authorI].contactemail;
              }
              const fromArray = [];
              const toMailArray = [];
              const ccMailArray = [];
              const bccMailArray = [];
              if (Array.isArray(from)) {
                from.forEach(item => {
                  if (mailObj[item]) {
                    fromArray.push(mailObj[item]);
                  } else {
                    fromArray.push(item);
                  }
                });
              } else {
                fromArray.push(from);
              }

              to.forEach(item => {
                if (mailObj[item]) {
                  toMailArray.push(mailObj[item]);
                } else {
                  toMailArray.push(item);
                }
              });
              cc.forEach(item => {
                if (mailObj[item]) {
                  ccMailArray.push(mailObj[item]);
                } else {
                  ccMailArray.push(item);
                }
              });
              bcc.forEach(item => {
                if (mailObj[item]) {
                  bccMailArray.push(mailObj[item]);
                } else {
                  bccMailArray.push(item);
                }
              });
              console.log(toMailArray, 'toMailArray');
              console.log(ccMailArray, 'toMailArray');
              console.log(bccMailArray, 'toMailArray');
              const payld = {
                actionType: 'mail',
                date: moment(new Date()).format('DD-MM-YYYY'),
                workorderId: workorderid,
                noOfChapter: totalchaptercount,
                noOfArticle: totalarticlecount,
                noOfNonArticle: totalnonarticlecount,
                printIsbn: printisbn,
                woType: wotype,
                jobType: jobtype,
                service: services,
                doiNumber: doinumber,
                jobId: itemcode,
                jobName: title,
                journalAcronym: journalacronym,
                journalName: journalname,
                customerName: customername,
                duName: duname,
                pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
                spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
                spmMail:
                  authorI != -1 ? resForConfig[authorI].contactemail : '',
                authorName:
                  authorI != -1 ? resForConfig[authorI].contactname : '',
                tlName: 'TL',
                stageName,
                iteration,
                stageDuedate: moment(stageDuedate).format('DD-MM-YYYY'),
                from: fromArray,
                toMail: toMailArray,
                cc: ccMailArray,
                bcc: bccMailArray,
                subject,
                template,
                serviceId,
                stageId,
                stageIterationCount: iteration,
                wfDefId: wfdefid,
                mailType: 'workflow',
                fileName: filename,
                issueNumber: issuenumber,
                volumeNumber: volumenumber,
              };
              logger.info(payld, 'req for wf notif');
              emitAction(payld);
              resolve(true);
            } else {
              resolve(false);
            }
          } else {
            resolve(false);
          }
        } else {
          logger.info('get notification config empty');
          resolve(false);
        }
      });
    } catch (e) {
      logger.info('get notification config failed');
      resolve(false);
    }
  });
};

export const createReportView = (client, data) => {
  const { wfeventId, userId, uomValue, duId } = data;
  return new Promise(async resolve => {
    try {
      const now = new Date();
      const then = new Date(data.timestamp);
      logger.info(
        moment(data.timestamp).format('DD/MM/YYYY HH:mm:ss'),
        'res data',
      );
      const hour = moment
        .utc(
          moment(now, 'DD/MM/YYYY HH:mm:ss').diff(
            moment(then, 'DD/MM/YYYY HH:mm:ss'),
          ),
        )
        .format('HH:mm:ss');
      logger.info(hour, 'hour');
      const sql = `SELECT taskreportid, totaltime, uomvalue FROM wms_task_report_view WHERE wfeventid =$1 and userid=$2`;
      const { rows } = await client.query(sql, [wfeventId, userId]);
      logger.info(rows, 'isExists');
      if (rows.length > 0) {
        let newHour = '';
        if (rows[0].totaltime) {
          logger.info('innnn');
          const a = moment.duration(rows[0].totaltime);
          const b = moment.duration(hour);
          const c = a.add(b);
          newHour = `${c.hours()}:${c.minutes()}:${c.seconds()}`;
        }
        logger.info(newHour, 'adding prev hours');
        const totalUom = rows[0].uomvalue
          ? parseInt(rows[0].uomvalue) + parseInt(uomValue || 0)
          : parseInt(uomValue || 0);
        logger.info(totalUom, 'total of uom');
        const sqlQuery = `UPDATE public.wms_task_report_view SET uomvalue =$1, totaltime=$2 WHERE taskreportid=$3 `;
        client
          .query(sqlQuery, [totalUom, newHour, rows[0].taskreportid])
          .then(response => {
            logger.info(response, 'update the task view report');
            resolve(true);
          });
      } else {
        const uom = uomValue ? parseInt(uomValue) : 0;
        const getValueSql = `SELECT DISTINCT ON (incoming.woincomingfileid)
                    wms_user.duid,wms_user.userid,wms_user.username,eventlog.workorderid,workorder.itemcode,
                    service.servicename,stage.stagename,activity.activityname,
                    COALESCE(incoming.filename,'All Chapters') as filename,
                    skill.skillname,skilllevel.skilllevel,${uom}, '${hour}', current_timestamp,
                    eventlog.wfeventid, eventlog.stageiterationcount, eventlog.actualactivitycount, wfdef.activityalias
                    FROM wms_workorder workorder
                    JOIN wms_workflow_eventlog eventlog ON eventlog.workorderid = workorder.workorderid
                    LEFT JOIN wms_workorder_incomingfiledetails incoming ON incoming.woincomingfileid = eventlog.woincomingfileid
                    JOIN wms_workflowdefinition wfdef ON eventlog.wfdefid = wfdef.wfdefid
                    JOIN wms_mst_service service ON service.serviceid = eventlog.serviceid
                    JOIN wms_mst_stage stage ON stage.stageid = wfdef.stageid
                    JOIN wms_mst_activity activity ON activity.activityid = wfdef.activityid
                    JOIN wms_mst_skill skill ON skill.skillid = eventlog.skillid
                    JOIN wms_userskill userskill ON userskill.skillid = eventlog.skillid AND userskill.userid::text = eventlog.userid::text
                    LEFT JOIN wms_mst_skilllevel skilllevel ON skilllevel.skilllevelid = userskill.skillelvelid
                    JOIN wms_workflow_eventlog_details eventdetails ON eventdetails.wfeventid = eventlog.wfeventid
                    JOIN wms_user ON wms_user.userid = eventlog.userid
                    WHERE wms_user.duid = ${duId} AND wms_user.userid = '${userId}' AND eventlog.wfeventid = ${wfeventId}
                    `;
        logger.info(getValueSql, 'getValueSql');
        const sqlQuery = `INSERT INTO public.wms_task_report_view(duid, userid, username, workorderid,
                         itemcode, servicename, stagename, activityname, filename, skillname, skilllevel, uomvalue,
                         totaltime, updatedon, wfeventid, stageiterationcount, activityiterationcount, activityalias )
                    ${getValueSql}`;
        logger.info(sqlQuery, 'sql');
        client.query(sqlQuery).then(response => {
          logger.info(response, 'response');
          resolve(true);
        });
      }
    } catch (e) {
      logger.info(e, 'error for report view');
      resolve(false);
    }
  });
};
export const emailAudit = (req, res) => {
  // logger.info("Failure Email Audit==>", req.body)
  const { mailData, errorMsg = null, status = null } = req.body;
  const {
    subject = null,
    workorderId = null,
    serviceId = null,
    stageId = null,
    stageIterationCount = null,
    wfDefId = null,
    mailType = null,
  } = mailData;
  // console.log('yuvarajmlmlml', mailData.template.toString().replace(/'/g, '#$'))
  const tempMailData = mailData.template.toString().replace(/'/g, '#$');
  mailData.template = tempMailData;
  const wfeventid = mailData && mailData.wfeventId ? mailData.wfeventId : null;

  let sql = `INSERT INTO public.wms_email_audit(workorderid, serviceid, stageid, stageiterationcount, wfdefid, "timestamp", status,wfeventid) 
     VALUES (${workorderId},${serviceId},${stageId},${stageIterationCount},${wfDefId},current_timestamp,'${status}',${wfeventid}) RETURNING *`;
  logger.info(sql);
  query(sql, [])
    .then(data => {
      const { emailauditid } = data[0];
      logger.info('insert data', data);
      sql = `INSERT INTO public.wms_email_audit_history( emailauditid, mailtype, paylod, errorlog, "timestamp", status, subject)
           VALUES ( ${emailauditid},'${mailType}','${JSON.stringify(
        mailData,
      )}','${errorMsg}', current_timestamp,'${status}', '${subject}');`;
      query(sql, [])
        .then(rest => {
          res.status(200).json({ data: rest });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      logger.info('insert data erroir', error);
      res.status(400).send({ message: error });
    });
};

export const pkgDepositTrigger = async (reqData, wfData) => {
  return new Promise(async (resolve, reject) => {
    try {
      logger.info(reqData, 'req from client-util for pkg deposit');
      const authPaylod = {
        userId: process.env.EMDEPOSIT_USR,
        password: process.env.EMDEPOSIT_PWD,
      };
      const pkgDepositAuth = await service.post(
        `${config.pkgDepositApi.base_url}${config.pkgDepositApi.uri.deposit_auth}`,
        authPaylod,
        {},
      );
      logger.info(pkgDepositAuth, 'pkgDepositAuth');
      let authToken = '';
      if (
        pkgDepositAuth.data &&
        pkgDepositAuth.data.entry &&
        pkgDepositAuth.data.entry.id
      ) {
        authToken = Buffer.from(pkgDepositAuth.data.entry.id).toString(
          'base64',
        );
        console.log(authToken, 'api deposit_ticket');
      }
      const formData = new FormData();
      const headers = {
        Authorization: `Basic ${authToken}`,
      };
      const pkgFileuuid = reqData.uuid;
      const pkgFileName = reqData.name;
      let pkgPath;
      switch (wfData.dmsType) {
        case 'azure':
          const azureDownload = await azureHelper._download(reqData.path);
          pkgPath = azureDownload.data.path;
          break;
        default:
          pkgPath =
            config.openKM.base_url + config.openKM.uri.viewFile + pkgFileuuid;
          break;
      }
      // -----------------START UPLOAD CHECK WITH OKM---------------------//
      // let okmpathh = { "type": "okm_common" }
      // let okmPath = await getFolderStructure(okmpathh, []);
      // formData.append('content', createReadStream(`uploads/` + pkgFileName));
      // formData.append('docPath', okmPath);
      // const header = {
      //   'Content-Type': 'multipart/form-data; boundary=' + formData._boundary
      // };
      //  const response = await service.upload(`${config.openKM.base_url}${config.openKM.uri.upload}`, formData , header);
      //  console.log(response);
      // -----------------END UPLOAD CHECK WITH OKM---------------------//
      await download(pkgPath, `uploads`);
      formData.append('filedata', createReadStream(`uploads/${pkgFileName}`));
      const depositResp = await service.post(
        `${config.pkgDepositApi.base_url}${config.pkgDepositApi.uri.pre_pub}`,
        formData,
        headers,
      );
      // const depositResp = await service.post(`www.test.com/${config.pkgDepositApi.uri.pre_pub}`, formData , headers);

      console.log(depositResp, 'depositResp');
      if (depositResp) {
        const apiDepositRes = await contentDepositAPIAudit(
          depositResp,
          wfData,
          pkgFileName,
          'success',
        );
        resolve(apiDepositRes);
      } else {
        const apiDepositRes = await contentDepositAPIAudit(
          depositResp,
          wfData,
          pkgFileName,
          'failed',
        );
        resolve(apiDepositRes);
      }
      fs.unlink(`uploads/${pkgFileName}`, function (err) {
        if (err) reject(err);
        logger.info('File deleted!');
      });
    } catch (error) {
      logger.info(error, 'error for pkg upload Api before return');
      await contentDepositAPIAudit(
        {
          status: error.status,
          message: `Package upload Api failed${error.message}`,
        },
        wfData,
        reqData.name,
        'failed',
      );
      reject({
        status: error.status,
        message: `Package upload Api failed${error.message}`,
      });
    }
  });
};
export const triggerTrackItAPI = async (req, res) => {
  try {
    console.log(req.body, 'req from external-task on trackit');
    logger.info(req.body, 'req from external-task on trackit');
    const result = await getAuthAccessWorflow(req.body);
    console.log(result, 'resultforacesssstype');
    if (result) {
      res.status(200).send({ data: result });
    } else {
      res.status(400).send({ data: 'Trackit audit entry failed' });
    }
  } catch (error) {
    logger.info(error, 'error for  tractit API before return');
    res
      .status(400)
      .send({ status: error.status, message: 'Trackit API failed' });
  }
};

export const getAuthAccessWorflow = data => {
  const { doi, stage, details, source, runNumber, result, username, password } =
    data;

  const payload = {
    doi,
    stage,
    details,
    source,
    runNumber,
    result,
    dateTime: moment(new Date()).format('YYYYMMDDhhmmss'),
    username,
    password,
  };
  data.jsonData = payload;
  console.log(payload, 'req data for API');
  logger.info(payload, 'req data for API');

  return new Promise(async resolve => {
    // let username = process.env.TRACKIT_USERNAME;
    // let password = process.env.TRACKIT_PASSWORD;
    // const auth = Buffer.from(username + ":" + password).toString("base64");
    // console.log(auth, "authththh")
    // const headers = {
    //      "Authorization": `Basic ${auth}`
    // }
    const headers = {};
    logger.info(headers, 'headers-trackit');
    const url = config.trackletApi.base_url;
    logger.info(url, 'url-trackit');
    try {
      const response = await service.post(`${url}`, payload, headers);
      logger.info(response, 'response for trackit API');
      const rest = {
        status: response.status,
        statusCode: response.data && response.data.statusCode,
        message: response.data,
      };
      if (rest.statusCode == '200') {
        const trackItRes = await tractItAPIAudit(data, 'success');
        resolve(trackItRes);
      } else {
        const trackItRes = await tractItAPIAudit(data, 'failed');
        resolve(trackItRes);
      }
    } catch (error) {
      logger.info(error, 'error for trackit API');
      const trackItRes = await tractItAPIAudit(data, 'failed');
      resolve(trackItRes);
    }
  });
};

// this function will insert the tractit API audit
export const tractItAPIAudit = (data, status) => {
  const {
    jsonData,
    workorderId,
    serviceId,
    stageId,
    stageIterationCount,
    stage,
  } = data;

  logger.info(data, 'req data for trackit insert');
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO public.wms_trackit_api_audit(apiaction, workorderid, serviceid, stageid, stageiterationcount, payload, timestamp, status)
               VALUES ( '${stage}', ${workorderId}, ${serviceId}, ${stageId}, ${stageIterationCount}, '${JSON.stringify(
      jsonData,
    )}', current_timestamp, '${status}')`;
    logger.info(sql, 'sql for trackit API');
    query(sql, [])
      .then(result => {
        logger.info(result, 'res for trackit API');
        resolve(true);
      })
      .catch(error => {
        logger.info(error, 'error for insert trackit API');
        reject(false);
      });
  });
};
// this function will insert the content Deposit API audit
export const contentDepositAPIAudit = async (
  data,
  wfdata,
  filename,
  status,
) => {
  return new Promise((resolve, reject) => {
    try {
      const { workorderId, serviceId, stageId, stageIterationCount } = wfdata;
      logger.info(data, 'req data for trackit insert');
      const sql = `INSERT INTO public.wms_contentdeposit_api_audit(apiaction, workorderid,filename, serviceid, stageid, stageiterationcount, payload, timestamp, status)
               VALUES ( 'apiDeposit', ${workorderId}, '${filename}', ${serviceId}, ${stageId}, ${stageIterationCount}, '${JSON.stringify(
        data,
      )}', current_timestamp, '${status}')`;
      logger.info(sql, 'sql for trackit API');
      query(sql, [])
        .then(result => {
          logger.info(result, 'res for contentDepositAPIAudit API');
          resolve(true);
        })
        .catch(error => {
          logger.info(error, 'error for insert contentDepositAPIAudit API');
          reject(false);
        });
    } catch (err) {
      logger.info(err, 'error for insert contentDepositAPIAudit API');
    }
  });
};
// ///camunda performence testing API.
// const startInstance = async (variables, wfKey, userid) => {
//      return new Promise(async (resolve, reject) => {
//      let returnvalue;
//      try {
//           let triggerResponse;
//           let triggerUserTask;
//           let triggerExternalTask;

//           triggerResponse = await service.post(`http://172.16.200.181:8080/engine-rest/process-definition/key/${wfKey}/start`, variables);
//           console.log(triggerResponse, "sfjsdfjsd")
//           triggerUserTask = await service.get(`http://172.16.200.181:8080/engine-rest/task?processInstanceId=${triggerResponse.data.id}`);
//           triggerExternalTask = await service.get(`http://172.16.200.181:8080/engine-rest/external-task?processInstanceId=${triggerResponse.data.id}`)
//           console.log(triggerUserTask, triggerExternalTask, "triggerUserTask");
//           var BookCompleted = false
//           while ((triggerUserTask && triggerExternalTask &&  Object.keys(triggerUserTask).length > 0  && triggerUserTask.data && triggerUserTask.data.length > 0) || (Object.keys(triggerExternalTask).length > 0 && triggerExternalTask.data && triggerExternalTask.data.length > 0)) {
//                if (triggerUserTask && Object.keys(triggerUserTask).length > 0 &&  triggerUserTask.data && triggerUserTask.data.length > 0) {
//                     for (var i = 0; i < triggerUserTask.data.length; i++) {
//                          var calimResult = await claimTask(triggerUserTask.data[i].id, userid);
//                          console.log(calimResult, "calimResult");
//                          if (calimResult && Object.keys(calimResult).length > 0) {
//                               var completePayload = { taskId: triggerUserTask.data[i].id, variables: {} }
//                               var completeResponse = await completeTask(completePayload)
//                               if (completeResponse && Object.keys(completeResponse).length > 0) {
//                                    if(triggerUserTask.data[i].name == 'Completion Trigger'){
//                                         BookCompleted = true
//                                    }
//                                    triggerUserTask = await service.get(`http://172.16.200.181:8080/engine-rest/task?processInstanceId=${triggerResponse.data.id}`);
//                                    triggerExternalTask = await service.get(`http://172.16.200.181:8080/engine-rest/external-task?processInstanceId=${triggerResponse.data.id}`)

//                               }
//                          }

//                     }
//                     if(BookCompleted){
//                          triggerBatchCompletion(triggerResponse.data.id)
//                     }
//                }
//                console.log(triggerExternalTask, "triggerExternalTask")
//                if (triggerExternalTask && Object.keys(triggerExternalTask).length > 0 && triggerExternalTask.data && triggerExternalTask.data.length > 0) {
//                     for (var i = 0; i < triggerExternalTask.data.length; i++) {
//                          let lockPaylod = {
//                               topicName: triggerExternalTask.data[i].topicName,
//                               processInstanceId: triggerExternalTask.data[i].processInstanceId,
//                               activityId: triggerExternalTask.data[i].activityId,
//                               "workerId": "System"
//                          }
//                          let lockPayload2 = {
//                               "lockDuration": 36000000,
//                               "workerId": "System"
//                          }
//                          var LockResult = await LockExternalTask(triggerExternalTask.data[0].id, lockPayload2);
//                          console.log(LockResult, "LockResult");
//                          if (LockResult && Object.keys(LockResult).length > 0) {
//                               await CompleteExternalTask(triggerExternalTask.data[0].id, lockPaylod);
//                               triggerExternalTask = await service.get(`http://172.16.200.181:8080/engine-rest/external-task?processInstanceId=${triggerResponse.data.id}`)
//                               triggerUserTask = await service.get(`http://172.16.200.181:8080/engine-rest/task?processInstanceId=${triggerResponse.data.id}`);

//                          }
//                     }
//                }
//           }

//           if(('data' in triggerUserTask &&  !triggerUserTask.data.length ) && ('data' in triggerExternalTask &&  !triggerExternalTask.data.length ) ){
//                console.log("Instance Completed");
//                returnvalue ='completed';
//                resolve(returnvalue)

//           }

//      }
//      catch (e) {
//           reject(e);
//           console.log(e, 'error occured')
//      }
// })
// }
// const claimTask = async (taskInstanceId, userid) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let data = { id: taskInstanceId, userId: userid };
//                let claimData = await service.post('http://172.16.200.197:8085/claimtask', data);
//                console.log(claimData, "claimDataclaimData")
//                resolve(claimData)
//           }
//           catch (e) {
//                reject(e)
//                console.log(e, "error in claim task")
//           }
//      })

// }

// const LockExternalTask = async (taskInstanceId, lockPaylod) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let LockData = await service.post(`http://172.16.200.181:8080/engine-rest/external-task/${taskInstanceId}/lock/`, lockPaylod);
//                console.log(LockData, "LockData")
//                resolve(LockData)
//           }
//           catch (e) {
//                reject(e)
//                console.log(e, "error in claim task")
//           }
//      })

// }

// const CompleteExternalTask = async (taskInstanceId, lockPaylod) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let CompleteExternalData = await service.post(`http://172.16.200.181:8080/engine-rest/external-task/${taskInstanceId}/complete`, lockPaylod);
//                console.log(CompleteExternalData, "CompleteExternalData")
//                resolve(CompleteExternalData)
//           }
//           catch (e) {
//                reject(e)
//                console.log(e, "error in claim task")
//           }
//      })

// }

// const unclaimTask = async (taskInstanceId, userid) => {
//      try {
//           let data = { id: taskInstanceId, userId: userid };
//           await service.post('http://172.16.200.197:8085/unclaimtask', data);
//      } catch (e) {
//           console.log(e)
//      }

// }

// const completeTask = async (payload) => {
//      return new Promise(async (resolve, reject) => {
//           try {
//                let completeData = await service.post('http://172.16.200.197:8085/commonCompleteTask', payload);
//                console.log(completeData, "completedata")
//                resolve(completeData)
//           } catch (e) {
//                reject(e)
//                console.log(e, "complete task error")
//           }
//      })

// }

// export const CamundaAPI = async (req, res) => {
//      let variables = req.body.variables;

//      let promises = [];
//      let start = moment().format('hh:mm:ss');
//      console.log(start, 'start time');

//      for(var i=1; i <= 50; i++) {
//           let userid = i+1;
//           promises.push(startInstance(variables, req.body.wfKey, userid));
//      }

//      Promise.all(promises).then((result) => {
//           console.log(result, 'result');
//           let end = moment().format('hh:mm:ss');
//           console.log(end, 'end time');
//           res.status(200).json({ data: {start, end }});

//      }).catch((e) => {
//           console.log(e, 'failed');
//      });

// }

// let startInstances = await startInstance(variables, req.body.wfKey, userid);
// console.log(startInstances, "startInstancesstartInstances")
// if(startInstances == 'completed'){
//      res.status(200).json({ data: startInstances });
// }
