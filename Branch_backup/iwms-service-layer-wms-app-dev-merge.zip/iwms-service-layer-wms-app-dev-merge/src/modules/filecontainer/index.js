// import { config } from '../../config/restApi.js';
import { query } from '../../database/postgres.js';
// import { Service } from '../../httpClient/index.js';
import logger from '../utils/logs/index.js';

// this function will add the typeset page of corresponding stage
export const filesContainer = async (req, res) => {
  try {
    const { woid } = req.body;
    const sql = `select * from woi where woid='${woid}'`;
    logger.info(sql, 'sql for typeset page on stage wise');
    await query(sql);
    res.status(200).json({ message: 'success' });
  } catch (e) {
    logger.info(e);
  }
};
