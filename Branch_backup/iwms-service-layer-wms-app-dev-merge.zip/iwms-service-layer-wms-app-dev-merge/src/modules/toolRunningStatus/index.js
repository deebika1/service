import { query } from '../../database/postgres.js';

export const getToolsOptionList = (req, res) => {
  const getData = req.body;
  let sql = ``;
  if (getData.type == 'du') {
    sql = `SELECT duid as value, duname as label from org_mst_deliveryunit`;
  } else if (getData.type === 'division') {
    sql = `
            SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label FROM org_mst_customer_orgmap  
            JOIN org_mst_division ON org_mst_customer_orgmap.divisionid = org_mst_division.divisionid
			JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE duid = ${getData.duId} `;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap  
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} AND duid = ${getData.duId}`;
  } else if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label FROM org_mst_customer_orgmap  
            JOIN org_mst_customer ON org_mst_customer_orgmap.customerid = org_mst_customer.customerid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} AND duid = ${getData.duId} AND org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId}`;
  } else if (getData.type === 'service') {
    sql = `SELECT  DISTINCT ON (service.serviceid)  service.serviceid as value, service.servicename as label FROM public.org_mst_customer_orgmap as custmap
                JOIN public.org_mst_customerorg_service_map as custservice ON custservice.custorgmapid = custmap.custorgmapid
                JOIN public.wms_mst_service as service ON service.serviceid = custservice.serviceid
                JOIN org_mst_customerorg_du_map as dumap ON dumap.custorgmapid = custmap.custorgmapid 
                WHERE  custmap.customerid=${getData.customerId} AND custmap.divisionid=${getData.divisionId} 
                AND custmap.subdivisionid=${getData.subDivisionId} AND dumap.duid = ${getData.duId}  `;
  } else if (getData.type === 'workflow') {
    sql = `SELECT wfid as value, wfname as label FROM public.wms_workflow WHERE isactive = true AND  customerid = ${getData.customerId}`;
  }
  console.log(sql, 'sql for optionsj');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
