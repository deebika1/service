import { basename, extname, dirname } from 'path';
import { query } from '../../database/postgres.js';
import { getFileValidationStatus } from '../utils/fileValidation/validate.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import logger from '../utils/logs/index.js';

export const getFileDetails = async (req, res) => {
  const {
    wfEventId,
    workOrderId,
    du,
    customer,
    service,
    stage,
    activity,
    validationFileConfig,
    placeHolders,
    typesId,
    eventData,
    mandatorySaveFile,
  } = req.body;
  try {
    const filesInfo = await getFileInfoDetails({
      wfEventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId,
    });
    const filesData = await fetchValidationDetails(
      filesInfo,
      validationFileConfig,
      placeHolders,
      eventData,
      mandatorySaveFile,
      workOrderId,
    );
    const isFileSynced = await getFileSyncStatus(wfEventId);
    res.status(200).json({ ...filesData, isFileSynced });
  } catch (error) {
    logger.info(error, 'file details');
    res.status(400).send({ message: error });
  }
};

export const getFileDetailsNew = async (req, res) => {
  const getdata = req.body;
  console.log(getdata, 'hjkh');
  try {
    const sql = `SELECT inc.*,incf.*,flt.*,ptp.pitstopprofile as pitstopprofilename 
        from wms_workorder_incoming as inc 
        join wms_workorder_incomingfiledetails as incf on inc.woincomingid=incf.woincomingid 
        join pp_mst_filetype as flt on  incf.filetypeid = flt.filetypeid 
        left join wms_mst_pitstopprofile as ptp on ptp.pitstopprofileid=incf.pitstopprofile
        where woid=${getdata.workorderid} and flt.filetypeid !=1 order by filesequence`;
    const eventData = await query(sql);
    res.status(200).json(eventData);
  } catch (error) {
    global.log(error, 'file details');
    res.status(400).send({ message: error });
  }
};
export const setPIIPlaceHolders = async (req, res) => {
  const { workorderId, woImcomingFileId } = req.body;
  try {
    const sql = `select woincomingfileid,filename,piinumber,* from wms_workorder_incoming as incoming
    join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
    where incoming.woid = ${workorderId} and woincomingfileid = ${woImcomingFileId}`;
    const result = await query(sql, []);
    res.send(result);
  } catch (e) {
    logger.info('piiplaceholders', e);
    res.status(400).send({ message: e });
  }
};

export const getPlaceHolders = async (req, res) => {
  const { wfEventId, workOrderId } = req.body;
  try {
    const awaits = [];
    awaits.push(getWorkflowPlaceHolders(wfEventId));
    awaits.push(getLinkingFileTypePlaceHolders(workOrderId));
    awaits.push(getChapterFileTypePlaceHolders(workOrderId));
    awaits.push(getIndexFileTypePlaceHolders(workOrderId));
    awaits.push(getPrelimsFileTypePlaceHolders(workOrderId));
    const placeholderData = await Promise.all(awaits);
    let placeHolders1 = placeholderData[0];
    const placeHolders2 = placeholderData[1];
    const placeHolders3 = placeholderData[2];
    const placeHolders4 = placeholderData[3];
    const placeHolders5 = placeholderData[4];
    if (
      placeHolders2 &&
      Object.keys(placeHolders2).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        LinkingTypeFileName: placeHolders2.filename,
      };
    }
    if (
      placeHolders3 &&
      Object.keys(placeHolders3).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        ChapterTypeFileName: placeHolders3.filename,
      };
    }
    if (
      placeHolders4 &&
      Object.keys(placeHolders4).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        IndexTypeFileName: placeHolders4.filename,
      };
    }
    if (
      placeHolders5 &&
      Object.keys(placeHolders5).length > 0 &&
      placeHolders1 &&
      Object.keys(placeHolders1).length > 0
    ) {
      placeHolders1 = {
        ...placeHolders1,
        PrelimsTypeFileName: placeHolders5.filename,
      };
    }

    res.send(placeHolders1);
  } catch (error) {
    logger.info(error, 'getPlaceHolders');
    res.status(400).send({ message: error });
  }
};

export const getWorkflowPlaceHolders = async wfEventId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM public.wms_wfevent_details where wfEventId = $1`;
      const eventData = await query(sql, [wfEventId]);
      const {
        workorderid,
        printisbn,
        doinumber,
        journalname,
        journalacronym,
        stageid,
        stageiterationcount,
        activityiterationcount,
        issuenumber,
        volumenumber,
        itemcode,
        smartmetadata,
        watermark,
        pitstopprofile,
        countrycode,
        pmemail,
        uom,
        customerid,
        hardbackisbn,
        wfid,
        onlineprofile,
        onlinepdf,
        print,
        additionalpdf,
        pii,
        articleno,
        printprofile,
        journaltype,
        stagename,
        referenceprofile,
        pdfa2bprofile,
        frontpii,
        backpii,
        printissn,
        coverprofile,
        manuscriptzipname,
      } = eventData[0];

      const extractStageNumber = stagename.match(/-?\d+\.?\d*/)
        ? stagename.match(/-?\d+\.?\d*/)[0]
        : '';
      const isbn =
        customerid == '1'
          ? hardbackisbn
          : customerid == '6'
          ? doinumber
          : printisbn;

      const PitstopProfileSelector = () => {
        switch (wfid) {
          case '25':
            return onlineprofile || '';
          case '26':
            return journaltype == 'online'
              ? onlineprofile || ''
              : printprofile || '';
          case '27':
            return journaltype == 'online'
              ? onlineprofile || ''
              : printprofile || '';
          case '28':
            return journaltype == 'online'
              ? onlineprofile || ''
              : printprofile || '';
          case '31':
            return journaltype == 'online'
              ? onlineprofile || ''
              : printprofile || '';
            case '32':
            return journaltype == 'online'
              ?  printprofile || ''
              : onlineprofile || '';
          default:
            return pitstopprofile || '';
        }
      };
      const FiletypeNamebyJnlType = () => {
        switch (wfid) {
          case '25':
            return journaltype == 'print and online' ? '_Print' : '';
          case '28':
            return journaltype == 'print and online' ? '_Print' : '';
          default:
            return journaltype == 'print and online' ? '_Print' : '';
        }
      };
      const sql1 = `select * from public.wms_workorder_stage  where workorderid = ${workorderid} and wfstageid = ${stageid} and stageiterationcount = ${stageiterationcount}`;
      const typeSetDetails = await query(sql1);
      console.log(typeSetDetails);
      const { typesetpages } = typeSetDetails.length ? typeSetDetails[0] : {};

      const sql2 = `select woincomingfileid,filename,* from wms_workorder_incoming as incoming
      join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
      where incoming.woid = $1`;
      const articletypelist = await query(sql2, [workorderid]);

      const sql3 = `select woincomingfileid from wms_workflow_eventlog where wfeventid = ${wfEventId}`;
      const incomingDetails = await query(sql3);
      console.log(incomingDetails);
      const { woincomingfileid } = incomingDetails[0];
      console.log(sql3);
      const overAllArticleList = [];
      articletypelist.forEach(list => {
        overAllArticleList.push({
          woincomingid: list.woincomingfileid,
          FileTypeName: list.filename,
          articletype: list.articletype,
          piinumber: list.piinumber,
        });
      });
      const placeHolders = {
        // ISBN: customerid == '1' ? hardbackisbn : printisbn,
        // for tools=> only isbn value is used. so make this place holder changes
        ISBN: isbn,
        DOI: doinumber,
        WOID: workorderid,
        JournalName: journalname,
        JournalAcronym: journalacronym,
        JournalAcronymSub: journalacronym?.toLowerCase(),
        CountryCode: countrycode,
        PMEmail: pmemail,
        PageCount: uom,
        JournalVolumeNo: volumenumber,
        JournalIssueNo: issuenumber,
        StageIteration: stageiterationcount,
        ActivityIteration: activityiterationcount,
        BookCode: itemcode,
        // PitstopProfile: wfid == 25 ? onlineprofile || '' : pitstopprofile || '',
        PitstopProfile: PitstopProfileSelector(),
        WatermarkProfile: watermark || '',
        SmartmetadataProfile: smartmetadata || '',
        OnlinePdf: onlinepdf || '',
        Print: print || '',
        AdditionalPdf: additionalpdf || '',
        PII: pii || '',
        OnlineProfile: onlineprofile || '',
        PrintProfile: printprofile || '',
        articleno: articleno || '',
        graphicFileName: (isbn && isbn.substring(7, isbn.length - 1)) || '',
        pagecount: typesetpages || '',
        extractStageNumber,
        ReferenceProfile: referenceprofile,
        Pdfa2bProfile: pdfa2bprofile,
        JnlTypeFileName: FiletypeNamebyJnlType(),
        articletype: '',
        FrontPII: frontpii || '',
        BackPII: backpii || '',
        PrintIssn: printissn || '',
        ArticleTypeList: overAllArticleList || [],
        CoverProfile: coverprofile || [],
        IssueJournalType: journaltype == 'online' ? 'Online' : 'Print_BW',
        ManuscriptZipName: manuscriptzipname,
        woincomingfileid,
      };
      // added graphics image upload  isbn validation
      resolve(placeHolders);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getLinkingFileTypePlaceHolders = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 11 and incoming.woid =$1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getChapterFileTypePlaceHolders = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 2 and incoming.woid =$1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getIndexFileTypePlaceHolders = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 3 and incoming.woid =$1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getPrelimsFileTypePlaceHolders = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT incomingfiledetails.filename FROM public.wms_workorder_incoming as incoming
            join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
            where incomingfiledetails.filetypeid = 13 and incoming.woid =$1`;
      const eventData = await query(sql, [workOrderId]);
      resolve(eventData[0]);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getPlaceHolderFields = () => {
  return [
    { label: 'ISBN', value: ';ISBN;' },
    { label: 'DOI', value: ';DOI;' },
    { label: 'JournalName', value: ';JournalName;' },
    { label: 'JournalAcronym', value: ';JournalAcronym;' },
    { label: 'JournalVolumeNo', value: ';JournalVolumeNo;' },
    { label: 'StageIteration', value: ';StageIteration;' },
    { label: 'ActivityIteration', value: ';ActivityIteration;' },
    { label: 'BookCode', value: ';BookCode;' },
    { label: 'PitstopProfile', value: ';PitstopProfile;' },
    { label: 'WatermarkProfile', value: ';WatermarkProfile;' },
    { label: 'SmartmetadataProfile', value: ';SmartmetadataProfile;' },
  ];
};

export const updateFileSyncStatus = async (req, res) => {
  const { wfEventId, status } = req.body;
  try {
    const sql = `UPDATE wms_workflow_eventlog SET isfilesynced = $1 WHERE wfeventid = $2`;
    await query(sql, [status, wfEventId]);
    res.send({ message: 'updated file sync status' });
  } catch (error) {
    logger.info(error, 'getPlaceHolders');
    res.status(400).send({ message: error });
  }
};

export const lockFileSyncStatus = async (req, res) => {
  const { wfEventId, LocalFileNames } = req.body;
  try {
    const sql = `select * from public.wms_workflowactivitytrn_file_map where isactive=true and wfeventid=${wfEventId}`;
    const ExistingFiles = await query(sql);
    const ListToLock = [];
    ExistingFiles.forEach(x => {
      let toLock = true;
      LocalFileNames.forEach(y => {
        if (x.repofilepath.endsWith(y)) {
          toLock = false;
        }
      });
      if (toLock) {
        ListToLock.push(x);
      }
    });
    const awt = [];
    ListToLock.forEach(x => {
      awt.push(lockFileInFileMap(x));
    });
    await Promise.all(awt);
    res.send({ message: 'lockFileSyncStatus updated.' });
  } catch (error) {
    logger.info(error, 'lockFileSyncStatus');
    res.status(400).send({ message: error });
  }
};

export const getFileSyncStatus = async wfEventId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT isfilesynced FROM public.wms_workflow_eventlog WHERE wfeventid=$1`;
      const eventlogData = await query(sql, [wfEventId]);
      resolve(eventlogData.length ? eventlogData[0].isfilesynced : false);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getFileInfoDetails = ({
  wfEventId,
  workOrderId,
  du,
  customer,
  service,
  stage,
  activity,
  typesId = [],
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      let filesData = [];
      const sql = `SELECT * FROM public.wms_task_files WHERE wfeventid=$1  ORDER BY filesequence`;
      const files = await query(sql, [wfEventId]);
      filesData = await fetchFileDetails({
        workOrderId,
        du,
        customer,
        service,
        stage,
        activity,
        filesData,
        files,
      });
      if (typesId.length)
        filesData = await fetchExistingFileTyeDetails({
          workOrderId,
          du,
          customer,
          service,
          stage,
          activity,
          typesId,
          filesData,
        });
      resolve(filesData);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

const fetchFileDetails = async ({
  workOrderId,
  du,
  customer,
  service,
  stage,
  activity,
  filesData,
  files,
}) => {
  const filesMapping = {};
  const foldersMapping = {};
  let totalMsPagesCount = 0;
  const awaits = [];
  files.forEach(file => awaits.push(fileDetailsSub(file)));
  await Promise.all(awaits);
  filesData = filesData.map(file => {
    return {
      ...file,
      files: filesMapping[file.key] || [],
      folders: foldersMapping[file.key].folders || [],
      ischeckedout: filesMapping[file.key].some(
        fmap => fmap.ischeckedout === true,
      ),
    };
  });
  return filesData;

  async function fileDetailsSub(file) {
    const reportFolderName = `${dirname(file.path)}/`;
    const reportFileName = basename(file.path);
    const ext = extname(reportFileName);
    const { ischeckedout } = file;
    const key = file.allowsubfiletype
      ? `${file.filetype}_${file.woincomingfileid}`
      : file.filetype;
    const pageRange = file.newfilename;
    const pitstopProfile = file.pitstopprofile;
    const pitstopProfilePath = file.pitstopprofilepath;
    const basePath = await getFolderStructure({
      type: file.allowsubfiletype
        ? 'wo_activity_file_subtype'
        : 'wo_activity_filetype',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      fileType: {
        name: file.filetype,
        id: file.filetypeid,
        fileId: file.woincomingfileid,
      },
    });
    const activityBasePath = await getFolderStructure({
      type: 'wo_activity_iteration',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
    });
    const folderRelativePath = reportFolderName.replace(basePath, '');
    const isFolder = !!folderRelativePath;
    const folderName = isFolder ? folderRelativePath.split('/')[0] : '';
    totalMsPagesCount += parseInt(file.mspages ? file.mspages : 0);
    if (!filesMapping[key]) {
      filesData.push({
        singlepdfmerge: file.singlepdfmerge,
        newfiletype: file.newfiletype,
        type: file.filetype,
        typeId: file.filetypeid,
        isFolder,
        basePath,
        activityBasePath,
        name: file.filename,
        selected: false,
        key,
        filesequence: file.filesequence,
        incomingFileId: file.woincomingfileid,
        allowSubFileType: file.allowsubfiletype,
        mspages: file.mspages,
        totalMsPages: totalMsPagesCount,
        pageRange,
        pitstopProfile,
        pitstopProfilePath,
        imagecount: file.imagecount,
      });
      filesMapping[key] = [];
      foldersMapping[key] = { folders: [] };
    }
    if (isFolder) {
      if (!foldersMapping[key][folderName]) {
        foldersMapping[key][folderName] = true;
        foldersMapping[key].folders.push({
          folderName,
          basePath,
          key,
          type: file.filetype,
          typeId: file.filetypeid,
          singlepdfmerge: file.singlepdfmerge,
          newfiletype: file.newfiletype,
        });
      }
    }
    filesMapping[key].push({
      ...file,
      isFolder,
      folderName,
      folderRelativePath,
      name: reportFileName,
      type: file.filetype,
      typeId: file.filetypeid,
      singlepdfmerge: file.singlepdfmerge,
      newfiletype: file.newfiletype,
      key,
      ext,
      folder: reportFolderName,
      ischeckedout,
    });
    return true;
  }
};

export const fetchExistingFileTyeDetails = async ({
  workOrderId,
  du,
  customer,
  service,
  stage,
  activity,
  typesId,
  filesData,
}) => {
  const incomingFileId = filesData.map(fd => fd.incomingFileId);
  const sql = `SELECT pp_mst_filetype.filetype, pp_mst_filetype.filetypeid, pp_mst_filetype.allowsubfiletype,
    wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.woincomingfileid, 
	wms_workorder_incomingfiledetails.filesequence, wms_workorder_incomingfiledetails.mspages, 
	wms_workorder_incomingfiledetails.newfilename, wms_workorder_incomingfiledetails.pitstopprofile, wms_mst_pitstopprofile.pitstopprofile as pitstopprofilepath
    FROM wms_workorder_incomingfiledetails
    join wms_workorder_incoming on wms_workorder_incoming.woincomingid=wms_workorder_incomingfiledetails.woincomingid
	left join wms_mst_pitstopprofile on wms_mst_pitstopprofile.pitstopprofileid = wms_workorder_incomingfiledetails.pitstopprofile
    join pp_mst_filetype on wms_workorder_incomingfiledetails.filetypeid=pp_mst_filetype.filetypeid
    where wms_workorder_incoming.woid= $1 and Not(wms_workorder_incomingfiledetails.woincomingfileid = any($2)) and pp_mst_filetype.filetypeid = any($3)`;
  const existingFileTypes = await query(sql, [
    workOrderId,
    incomingFileId,
    typesId,
  ]);
  const awt = [];
  existingFileTypes.forEach(existingFileType => {
    awt.push(existingFileTypeFunction(existingFileType));
  });
  await Promise.all(awt);
  async function existingFileTypeFunction(existingFileType) {
    const key = existingFileType.allowsubfiletype
      ? `${existingFileType.filetype}_${existingFileType.woincomingfileid}`
      : existingFileType.filetype;
    const basePath = await getFolderStructure({
      type: existingFileType.allowsubfiletype
        ? 'wo_activity_file_subtype'
        : 'wo_activity_filetype',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      fileType: {
        name: existingFileType.filetype,
        id: existingFileType.filetypeid,
        fileId: existingFileType.woincomingfileid,
      },
    });
    const activityBasePath = await getFolderStructure({
      type: 'wo_activity_iteration',
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
    });
    const fileData = {
      type: existingFileType.filetype,
      typeId: existingFileType.filetypeid,
      isFolder: false,
      basePath,
      activityBasePath,
      name: existingFileType.filename,
      selected: false,
      key,
      filesequence: existingFileType.filesequence,
      incomingFileId: existingFileType.woincomingfileid,
      allowSubFileType: existingFileType.allowsubfiletype,
      mspages: existingFileType.mspages,
      totalMsPages: 0,
      files: [],
      folders: [],
      ischeckedout: false,
      pageRange: existingFileType.newfilename,
      pitstopProfile: existingFileType.pitstopprofile,
      pitstopProfilePath: existingFileType.pitstopprofilepath,
    };
    filesData.push(fileData);
  }
  return filesData;
};

export const fetchValidationDetails = async (
  filesInfo,
  validationFileConfig,
  placeHolders,
  eventData,
  mandatorySaveFile,
  workOrderId,
) => {
  const {
    backupFiles,
    missedFiles,
    requiredFiles,
    globPatternFiles,
    readOnlyFiles,
    overwriteFiles,
    lwfFiles,
    UOMFile,
  } = await getFileValidation(
    filesInfo,
    validationFileConfig,
    placeHolders,
    eventData,
    mandatorySaveFile,
    workOrderId,
  );
  let UOMDetails = {};
  const missedFileTypeInfo = {};
  const fileTypes = [];
  filesInfo = filesInfo.map(fileInfo => {
    if (!fileTypes.includes(fileInfo.typeId)) fileTypes.push(fileInfo.typeId);
    const files = fileInfo.files.map(file => {
      const isUOM = isUOMFile(fileInfo.key, file.path, UOMFile);
      if (isUOM) {
        UOMDetails = file;
      }
      return {
        ...file,
        isReadOnly: isReadOnlyFile(fileInfo.key, file.path, readOnlyFiles),
        overwrite: isOverwriteFile(fileInfo.key, file.path, overwriteFiles),
        lwfDetails: getLWFDetails(fileInfo.key, file.path, lwfFiles),
        isUOM,
      };
    });
    const folders = fileInfo.folders.map(folderInfo => {
      const readWriteFiles = files.filter(
        file =>
          file.isFolder &&
          file.folderName == folderInfo.folderName &&
          !file.isReadOnly,
      );
      return { ...folderInfo, isReadOnly: readWriteFiles.length === 0 };
    });
    return {
      ...fileInfo,
      files,
      folders,
      globPatternFiles: getGlobPatternFiles(fileInfo.key, globPatternFiles),
      missedFiles: getMissedValidationFiles(fileInfo.key, missedFiles),
      requiredFiles: getRequiredValidationFiles(fileInfo.key, requiredFiles),
    };
  });
  missedFiles.forEach(file => {
    if (!file.key) {
      if (!missedFileTypeInfo[file.typeId]) {
        missedFileTypeInfo[file.typeId] = [file];
      } else {
        missedFileTypeInfo[file.typeId].push(file);
      }
    }
  });

  if (Object.keys(UOMDetails).length == 0 && Object.keys(UOMFile).length != 0) {
    UOMFile.ext = extname(UOMFile.name);
    UOMDetails = UOMFile;
  }

  const filesAdditionalInfo = {
    missedFileTypeInfo,
    UOMDetails,
    missedFiles,
    requiredFiles,
    readOnlyFiles,
    overwriteFiles,
    UOMFile,
    fileTypes,
    backupFiles,
  };
  filesInfo.sort((a, b) => {
    return a.filesequence - b.filesequence;
  });
  filesInfo.forEach(ele => {
    ele.files.forEach(element => {
      if (
        element.lwfDetails != undefined &&
        element.lwfDetails.isSoftwareOpen == true
      )
        element.isSoftwareOpen = true;
    });
  });
  return { filesInfo, filesAdditionalInfo };
};

const getFileValidation = (
  filesInfo,
  validationFileConfig,
  placeHolders,
  eventData,
  mandatorySaveFile,
  workOrderId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (Object.keys(validationFileConfig).length) {
        const fileDetails = filesInfo.map(fileInfo => {
          return {
            name: fileInfo.name,
            key: fileInfo.key,
            basePath: fileInfo.basePath,
            placeHolders: {
              FileTypeName: fileInfo.name,
              PageRange: fileInfo.pageRange,
              JnlTypeFileTypeName: fileInfo.name + placeHolders.JnlTypeFileName,
            },
            typeId: fileInfo.typeId,
            files: fileInfo.files,
          };
        });
        const fileValidationStatus = await getFileValidationStatus(
          validationFileConfig,
          fileDetails,
          placeHolders,
          eventData,
          mandatorySaveFile,
          workOrderId,
        );
        resolve(fileValidationStatus);
      } else {
        resolve({
          missedFiles: [],
          requiredFiles: [],
          readOnlyFiles: [],
          overwriteFiles: [],
          globPatternFiles: [],
          lwfFiles: [],
          UOMFile: {},
        });
      }
    } catch (e) {
      logger.info(e, 'validation file error');
      reject(e);
    }
  });
};

const isReadOnlyFile = (key, path, readOnlyFiles) => {
  const index = readOnlyFiles.findIndex(ro => ro.key == key && ro.path == path);
  return index !== -1;
};

const isOverwriteFile = (key, path, overwriteFiles) => {
  const index = overwriteFiles.findIndex(
    ro => ro.key == key && ro.path == path,
  );
  return index !== -1;
};

const getLWFDetails = (key, path, files) => {
  const fileData = files.find(ro => ro.key == key && ro.path == path);
  return fileData || { name: '', src: '', dest: '', isRoot: false };
};

const isUOMFile = (key, path, UOMFile) => {
  return UOMFile.key == key && UOMFile.path == path;
};

const getMissedValidationFiles = (key, missedFiles) => {
  return missedFiles.filter(fs => fs.key == key);
};

const getRequiredValidationFiles = (key, requiredFiles) => {
  return requiredFiles.filter(fs => fs.key == key);
};

const getGlobPatternFiles = (key, globPatternFiles) => {
  return globPatternFiles.filter(fs => fs.key == key);
};
async function lockFileInFileMap(x) {
  return new Promise(async (resolve, reject) => {
    try {
      // await lockDocument(x.repofileuuid)
      const locksql = `update public.wms_workflowactivitytrn_file_map set isactive = false where actfilemapid = ${x.actfilemapid}`;
      await query(locksql);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
}
