import { basename, extname, dirname, join } from 'path';
import fs, { createReadStream } from 'fs';
import { fileURLToPath } from 'url';
import FormData from 'form-data';
import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { query } from '../../database/postgres.js';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import {
  getFileSeq,
  updateStageSequence,
  _getStageInfoFromCamunda,
  _updateStageInfoToCamunda,
  _updateActivityStageInfoToCamunda,
  getdmsType,
} from '../bpmn/listener/create.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';
import {
  fetchValidationDetails,
  getFileInfoDetails,
  getWorkflowPlaceHolders,
} from './fileDetails.js';
import { getFormattedName } from '../utils/fileValidation/utils.js';
import {
  generateFileSeqDetails,
  checkout,
} from '../utils/custom/filegeneration.js';
import logger from '../utils/logs/index.js';
import { addSubJob, checkItracksExits, subJobAudit } from '../iTracks/index.js';

import { _isFileExist } from '../utils/okm/index.js';

import { checkInFiles } from '../woi/additionalInfo.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';

const service = new Service();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const fileTypeList = async (req, res) => {
  logger.info('file type list based on config==>', req.body);
  const { configFileType } = req.body;
  const { journalId } = req.body;
  let sql = `SELECT filetypeid as value, filetype as label,allowsubfiletype FROM pp_mst_filetype `;
  if (configFileType && configFileType.length > 0) {
    sql += 'where filetypeid in (';
    configFileType.forEach(data => {
      sql += `${data},`;
    });
    sql += '0)';
  } else if (journalId) {
    const journalSql = `select * from pp_mst_journal_nonart_types where journalid=${journalId}`;
    await query(journalSql).then(journalData => {
      sql += 'where filetypeid in (';
      journalData.forEach(jd => {
        sql += `${jd.filetypeid},`;
      });
      sql += '10)';
    });
  } else {
    sql += `WHERE pp_mst_filetype.category IN ('${req.body.categoryType}')`;
  }
  logger.info(sql, 'filetype sql');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const checkFileTypeStatus = (req, res) => {
  const { value, woid } = req.body;
  const name = value ? value.trim() : '';
  let sql = '';
  sql = `SELECT woincomingfileid,filename,pp_mst_filetype.filetype,allowsubfiletype FROM public.wms_workorder_incoming 
   JOIN public.wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
                   JOIN public.pp_mst_filetype ON pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
   WHERE wms_workorder_incoming.woid =${woid}   and LOWER(filename :: text) = '${name.toLowerCase()}'`;
  console.log(sql, 'check avail');
  query(sql)
    .then(data => {
      logger.info(data, 'data');
      if (data.length) {
        res.status(200).json({ status: false, message: 'Already exist' });
      } else {
        res.status(200).json({ status: true, message: 'Available' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const getInstructionDetails = async (checklistId, stageId) => {
  let condition = '';
  if (stageId !== null) {
    condition += `AND stageId=${stageId}`;
  }
  return new Promise(async resolve => {
    let sql = `select * from wms_mst_checklistinstruction where checklistid=${checklistId} ${condition} and isactive=0 order by checklistinstructionid `;
    console.log(sql, 'sql');
    await query(sql)
      .then(async instructions => {
        console.log(instructions, 'instructions');
        if (instructions.length) {
          const tempInstructions = [];
          await Promise.all(
            instructions.map(async instruction => {
              sql = `select * from wms_mst_checklistinstruction_answer where checklistinstructionid=${instruction.checklistinstructionid} order by checklistinstructionanswerid`;
              console.log(sql, 'sql');
              await query(sql).then(answers => {
                console.log(answers, 'answers');
                instruction.answers = answers;
                tempInstructions.push(instruction);
              });
            }),
          );
          console.log(tempInstructions, 'tempInstructions');
          resolve(tempInstructions);
        } else {
          resolve([]);
        }
      })
      .catch(() => {
        resolve([]);
      });
  });
};

export const getChecklist = async (req, res) => {
  const { wfId, stageId, skillId, duId, customerId, workorderId } = req.body;
  let sql = `select * from wms_mst_checklist checklist 
  join wms_workorder workorder on workorder.subdivisionid=checklist.subdivisionid and workorder.divisionid=checklist.divisionid 
  where checklist.customerid=${customerId} and checklist.duid=${duId} and checklist.wfid=${wfId} and checklist.skillid=${skillId} and 
  checklist.checklisttypeid=2 and workorder.workorderid=${workorderId} and checklist.isactive=0`;
  await query(sql)
    .then(async checklist => {
      if (checklist.length) {
        checklist[0].instructions = await getInstructionDetails(
          checklist[0].checklistid,
          stageId,
        );
        res.status(200).send({ data: checklist, status: true });
      } else {
        sql = `select * from wms_mst_checklist checklist where skillid=${skillId} and checklisttypeid=1 and checklist.isactive=0`;
        await query(sql)
          .then(async checklist1 => {
            if (checklist1.length) {
              checklist1[0].instructions = await getInstructionDetails(
                checklist1[0].checklistid,
                null,
              );
              res.status(200).send({ data: checklist1, status: true });
            } else {
              res.status(200).send({ data: [], status: true });
            }
          })
          .catch(error => {
            res.status(400).send({ data: [], status: false, message: error });
          });
      }
    })
    .catch(error => {
      res.status(400).send({ data: [], status: false, message: error });
    });
};

export const getviewProofing = (req, res) => {
  const { type, bookcode } = req.body;
  let sql1 = '';
  if (type == 'Collation') {
    sql1 = `select pc_url from wms_mst_pcvalidationftp_resp where articlename='${bookcode}' and isactive=true order by signalid desc limit 1`;
  } else {
    sql1 = `select pc_url from wms_mst_pcvalidationftp_resp where articlename='${bookcode}' and pc_submitted_by='Proof Collator' and isactive=true order by signalid desc limit 1`;
  }
  console.log(sql1, 'sqlforToolOption');
  query(sql1)
    .then(response => {
      const newRes = response && response.length > 0 ? response[0].pc_url : '';
      res.status(200).json({ data: newRes, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const checktoolLinkStatus = async (req, res) => {
  const {
    output,
    workorderid,
    isparentlink,
    stageid,
    serviceid,
    stageiterationcount,
    toolid,
  } = req.body;

  const sql = `SELECT COUNT(*) FROM wms_toolsoutput_details where workorderid =${workorderid}`;
  await query(sql)
    .then(async getCount => {
      const sql1 = `UPDATE wms_toolsoutput_details SET serviceid= '${serviceid}',output ='${output}',stageid= '${stageid}',stageiterationcount ='${stageiterationcount}',
    toolid='${toolid}' WHERE workorderid = ${workorderid} RETURNING output`;
      const sql2 = `Insert into wms_toolsoutput_details(workorderid,serviceid,stageid,stageiterationcount,toolid,output) values (${workorderid},${serviceid},
      ${stageid},${stageiterationcount},${toolid},${output}) RETURNING output`;
      const sql3 = getCount.length > 0 && isparentlink ? sql1 : sql2;
      query(sql3)
        .then(data => {
          logger.info('stage', data);
          res.status(200).json({ data, status: true });
        })
        .catch(() => {
          res
            .status(400)
            .send({ status: false, message: 'Getting iNet link failed.' });
        });
    })
    .catch(() => {
      res.status(400).send({
        data: [],
        status: false,
        message: 'Getting iNet link failed.',
      });
    });
};

export const getjournalid = (req, res) => {
  const { journalid } = req.body;
  const sql = `select proofingtype from pp_mst_journal  where journalid='${journalid}' `;
  // let sql = `select checklist from wms_workflow_eventlog where wfeventid=2571`
  query(sql)
    .then(response => {
      res.status(200).json({ data: response[0].proofingtype, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getHistory = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.type === 'allTask') {
    sql = `SELECT wms_workflow_eventlog_details.userid,
        (select min(wed1.timestamp) as enddate from wms_workflow_eventlog_details as wed1  
               WHERE wed1.wfeventid=$1 and wed1.operationtype = 'Work in progress' ) as starttime,
        wms_mst_stage.stagename||'('||stageiterationcount||')'  as stagename,  
        wms_mst_activity.activityname||'('||wms_workflow_eventlog_details.actualactivitycount||')' as activityname,
        (select max(timestamp) from(											
                select * from(											
                       SELECT
							timestamp, 
							operationtype,
							LEAD(operationtype,1) OVER (
							ORDER BY timestamp
							) next_operation
	
						FROM wms_workflow_eventlog_details   
               			WHERE wfeventid=$1)as m
			     order by timestamp desc limit 1)s
			     where operationtype!='Work in progress') as endtime,
        ( SELECT sum(tt)
	         from (
	               SELECT wfeventid,operationtype,tt
	                    from (
		                    select  
                              wfeventid,
		                      operationtype,
                              lead(timestamp) over (order by timestamp)-timestamp as tt                        
                            from wms_workflow_eventlog_details where wfeventid=$1
	                    ) as w 
                   where wfeventid=$1 and operationtype='Work in progress'
			) as total
    having bool_and(tt is not null)
		)as timetaken ,		
         wms_workflow_eventlog.wfeventid from wms_workflow_eventlog
         JOIN wms_workflowdefinition ON wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid 
         JOIN wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid
         JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
         JOIN wms_workflow_eventlog_details on wms_workflow_eventlog_details.wfeventid=wms_workflow_eventlog.wfeventid
         where  wms_workflow_eventlog.wfeventid=$1
         order  by wms_workflow_eventlog_details.timestamp limit 1
            `;
  } else if (reqData.type === 'task') {
    sql = `SELECT wed.wfeventid, wed.operationtype, wed.timestamp as timestamp, wed.userid, us.username FROM public.wms_workflow_eventlog_details as wed
        JOIN public.wms_user as us ON us.userid = wed.userid
        WHERE wed.wfeventid=$1`;
  } else if (reqData.type === 'file') {
    sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map WHERE wfeventid=$1`;
  }

  query(sql, [reqData.wfEventId])
    .then(response => {
      logger.info(response, 'res');
      if (reqData.type === 'allTask') {
        response.forEach(d => {
          d.timetaken =
            d.timetaken != null
              ? `${
                  d.timetaken.hours != undefined
                    ? d.timetaken.hours.length == 1
                      ? `0${d.timetaken.hours}`
                      : d.timetaken.minutes
                    : '00'
                }:${
                  d.timetaken.minutes != undefined
                    ? d.timetaken.minutes.length == 1
                      ? `0${d.timetaken.minutes}`
                      : d.timetaken.minutes
                    : '00'
                }:${
                  d.timetaken.seconds != undefined
                    ? d.timetaken.seconds.length == 1
                      ? `0${d.timetaken.seconds}`
                      : d.timetaken.seconds
                    : '00'
                }`
              : '';
        });
      }
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const saveUploadFile = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData for woi');
  if (!('path' in reqData)) {
    res.status(400).send({ message: 'File path key should not be empty' });
  } else if (reqData.path == '') {
    res.status(400).send({ message: 'File path should not be empty' });
  } else if (reqData.uuid == '') {
    res.status(400).send({ message: 'Uuid should not be empty' });
  } else {
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded)
        VALUES('${reqData.wfEventId}', '${reqData.uuid}', '${reqData.path}', null, true, false)`;
    query(sql)
      .then(() => {
        res.status(200).json({ message: 'File uploaded successfully' });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};

export const fileRead = (req, res) => {
  // const reqData = req.body;
  // var file = fs.createReadStream('upload/sample.pdf','binary');
  // var stat = fs.statSync('upload/sample.pdf');
  // res.setHeader('Content-Length', stat.size);
  // res.setHeader('Content-Type', 'application/pdf');
  // res.setHeader('Content-Disposition', 'attachment; filename=quote.pdf');
  // file.pipe(res);

  const data = fs.readFileSync('upload/sample.pdf');
  res.contentType('application/pdf');
  res.send(data);
};

export const updateOrderNo = async (req, res) => {
  try {
    const { jobId, woId, files } = req.body;

    logger.info(req.body, 'reqData for reordering the file');

    if (files.length > 0) {
      const queries = [];
      files.forEach(file => {
        let sqlForUpdate = '';
        const toSet = [];
        if (file.pitstopProfile)
          toSet.push(`pitstopprofile=${file.pitstopProfile}`);
        if (file.filesequence) toSet.push(`filesequence=${file.filesequence}`);
        if (file.newfiletype) toSet.push(`newfiletype=${file.newfiletype}`);
        if (file.singlepdfmerge)
          toSet.push(`singlepdfmerge=${file.singlepdfmerge}`);
        sqlForUpdate = `UPDATE public.wms_workorder_incomingfiledetails SET ${toSet.join(
          ',',
        )} WHERE woincomingfileid=${file.woincomingfileid}`;
        queries.push(query(sqlForUpdate, []));
      });
      await Promise.all(queries);
      const result = await updatefileSequenceXML(req.body, jobId, woId);
      const fileSequenceDetails = await getFileSeq(woId);
      await updateStageSequence(woId, fileSequenceDetails, null);
      res.status(200).json({
        data: 'Files has been reordered',
        uuid: result.uuid,
        name: result.name,
        path: result.path,
      });
    } else {
      throw new Error('No Files to Reorder');
    }
  } catch (err) {
    res.status(400).send({ message: err.message });
  }
};

export const updatefileSequenceXML_Old = async request => {
  return new Promise(async resolve => {
    let sql = `select definition.fileconfig,* from wms_workflow_eventlog eventlog join 
    wms_workflowdefinition definition on eventlog.wfdefid=definition.wfdefid where wfeventid=${request.wfeventid}`;
    let workorderid = '';
    await query(sql, []).then(async data => {
      if (data.length) {
        // updated for fileconfig restructure
        data[0].fileconfig = ReStructureFileConfig(data[0].fileconfig);
        const fileConfigKeys = Object.keys(data[0].fileconfig.fileTypes);
        let filename = '';
        let updatefile = false;
        workorderid = data[0].workorderid;
        for (let i = 0; i < fileConfigKeys.length; i++) {
          const { files } = data[0].fileconfig.fileTypes[fileConfigKeys[i]];
          for (let j = 0; j < files.length; j++) {
            if (files[j].custom && files[j].custom.generate_filesequence) {
              console.log('file yuvaraj', files[j]);
              filename = files[j].name;
              updatefile = true;
              break;
            }
          }
        }
        if (updatefile) {
          console.log(
            getFormattedName(
              filename,
              await getWorkflowPlaceHolders(request.wfeventid),
            ),
          );
          sql = `SELECT * FROM public.wms_task_files where wfeventid=${request.wfeventid}`;
          await query(sql, []).then(async taskfiles => {
            console.log(taskfiles);
            if (taskfiles.length) {
              for (let i = 0; i < taskfiles.length; i++) {
                const reportFolderName = `${dirname(taskfiles[i].path)}/`;
                const reportFileName = basename(taskfiles[i].path);
                const ext = extname(reportFileName);
                if (
                  reportFileName ===
                  getFormattedName(
                    filename,
                    await getWorkflowPlaceHolders(request.wfeventid),
                  )
                ) {
                  console.log(reportFolderName, reportFileName, ext);
                  const payload = {
                    reportFolderName,
                    reportFileName,
                    wfeventid: request.wfeventid,
                    workorderid,
                    uuid: taskfiles[i].uuid,
                  };
                  await generateFileSeqDetails(payload);
                }
              }
            }
          });
        }
      }
      resolve(data);
    });
  });
};

export const getFileSeqTemplate = details => {
  let template = "<?xml version = '1.0'?>\r\n<Book>\r\n";
  const pitstopoptions = details.pitstopoption;
  if (details) {
    details.files.forEach(detail => {
      const filename = detail.filename ? detail.filename : '';
      const filesequence = detail.filesequence ? detail.filesequence : '';
      const filetype = detail.filetype ? detail.filetype : '';
      // let pitstopprofile = detail.pitstopprofile ?  detail.pitstopprofile : ""
      template +=
        `${'<File>\r\n<FileName>'}${filename}</FileName>` +
        `\r\n` +
        `<SeqId>${filesequence}</SeqId>` +
        `\r\n` +
        `<Type>${filetype}</Type>` +
        `\r\n` +
        `<Pitstop>${
          pitstopoptions[detail.pitstopProfile - 1].label
        }</Pitstop>` +
        `\r\n` +
        `</File>` +
        `\r\n`;
    });
  }
  template += '</Book>';
  console.log('template', template);
  return template;
};

export const writeFileSequenceNumber = (
  filepath,
  name,
  getFileSequence,
  woId,
) => {
  // eslint-disable-next-line no-lone-blocks
  {
    return new Promise(async (resolve, reject) => {
      try {
        const dmsType = await getdmsType(woId);
        const srcPath = join(filepath, `${name}_SequenceNumber.xml`);
        const okmpathh = { type: 'okm_common' };
        const okmPath = await getFolderStructure(okmpathh, []);
        fs.writeFileSync(srcPath, `${getFileSequence}`);
        const fileName = basename(srcPath);
        logger.info(`Upload started for ${fileName}`);
        let uuid;
        switch (dmsType) {
          case 'azure':
            const formData = new FormData();
            formData.append('content', createReadStream(srcPath));
            formData.append('docPath', `${okmPath}${name}_SequenceNumber.xml`);
            const headers = {
              'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
            };
            await service.post(
              `${config.blob_rest.base_url}${config.blob_rest.uri.upload}`,
              formData,
              headers,
            );
            uuid = 'azure';
            break;
          case 'local':
            const formData1 = new FormData();
            formData1.append('content', createReadStream(srcPath));
            formData1.append('docPath', `${okmPath}${name}_SequenceNumber.xml`);
            const headers1 = {
              'Content-Type': `multipart/form-data; boundary=${formData1._boundary}`,
            };
            await service.post(
              `${config.local_rest.base_url}${config.local_rest.uri.localupload}`,
              formData1,
              headers1,
            );
            uuid = 'local';
            break;
          default:
            const isTargetDetails = await _isFileExist(
              `${okmPath}${name}_SequenceNumber.xml`,
            );
            if (isTargetDetails.isExist) {
              uuid = isTargetDetails.uuid;
              await checkout(isTargetDetails.uuid);
              await checkInFiles(srcPath, isTargetDetails.uuid);
            } else {
              const formData2 = new FormData();
              formData2.append('content', createReadStream(srcPath));
              formData2.append('docPath', okmPath);
              const header = {
                'Content-Type': `multipart/form-data; boundary=${formData2._boundary}`,
              };
              const response = await upload(
                `${config.okm_rest.baseUrl}${config.okm_rest.document.upload}`,
                formData2,
                header,
              );
              uuid = response.data.uuid;
            }
            break;
        }
        resolve({
          uuid,
          name,
          path: `${okmPath}${name}_SequenceNumber.xml`,
        });
      } catch (e) {
        reject(e);
      }
    });
  }
};

const deleteFileNew = async fileurl1 => {
  return new Promise(async (resolve, reject) => {
    try {
      const fileurl = fileurl1.replace(/\\/g, '/');
      await fs.unlink(fileurl, err => {
        console.log('new', err, fileurl);
      });
      resolve('true');
    } catch (err) {
      reject({
        status: false,
        message: err.response ? err.response : err.message,
      });
    }
  });
};

export const updatefileSequenceXML = (request, jobId, woId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const getFileSeq1 = await getFileSeqTemplate(request);
      const name = `${jobId}`;
      const filepath = join(__dirname, '../../../uploads').replace(/\\/g, '/');
      let newData = {};
      // if (request.type == 'fileReorder') {
      newData = await writeFileSequenceNumber(
        filepath,
        name,
        getFileSeq1,
        woId,
      );
      // }

      // need to be hanlded
      //   let workorderid = ''
      //   let condition = ''
      //   let wfEventid = []
      //   request.wfeventid.map((item, i) => {
      //     wfEventid.push(item.wfeventid)
      //     condition += request.wfeventid.length - 1 !== i ?
      //       `wfeventid = '${item.wfeventid}' OR `
      //       : `wfeventid = '${item.wfeventid}'`;
      //   });

      //   let sql = `select definition.fileconfig,* from wms_workflow_eventlog eventlog join
      // wms_workflowdefinition definition on eventlog.wfdefid=definition.wfdefid ${condition ? 'where ' + condition : ''}`
      //   let data = await query(sql, [])
      //   if (data.length) {
      //     let fileConfigKeys = Object.keys(data[0].fileconfig.fileTypes);
      //     logger.info("fileConfigKeys", fileConfigKeys)
      //     let filename = ""
      //     let updatefile = false
      //     workorderid = data[0].workorderid
      //     for (let i = 0; i < fileConfigKeys.length; i++) {
      //       let files = data[0].fileconfig.fileTypes[fileConfigKeys[i]].files
      //       for (let j = 0; j < files.length; j++) {
      //         if (files[j].custom && files[j].custom.generate_filesequence) {
      //           filename = files[j].name
      //           updatefile = true
      //           break;
      //         }
      //       }
      //     }
      //     if (updatefile) {
      //       sql = `SELECT * FROM public.wms_task_files ${condition ? 'where ' + condition : ''}`
      //       let taskfiles = await query(sql, []);
      //       if (taskfiles.length) {
      //         for (let i = 0; i < taskfiles.length; i++) {
      //           const reportFolderName = dirname(taskfiles[i].path) + '/';
      //           const reportFileName = basename(taskfiles[i].path);
      //           const ext = extname(reportFileName);
      //           if (reportFileName === getFormattedName(filename, await getWorkflowPlaceHolders(wfEventid[0]))) {
      //             let payload = {
      //               reportFolderName, reportFileName,
      //               wfeventid: wfEventid, workorderid,
      //               uuid: taskfiles[i].uuid
      //             }
      //             await generateFileSeqDetails(payload)
      //           }
      //         }
      //       }
      //     }
      //   }

      if (fs.existsSync(join(filepath, `${jobId}_SequenceNumber.xml`))) {
        await deleteFileNew(join(filepath, `${jobId}_SequenceNumber.xml`));
      }
      resolve({ uuid: newData.uuid, path: newData.path, name: newData.name });
    } catch (e) {
      reject(e);
    }
  });
};

const upload = (url, reqData, additionalHeaders = {}) => {
  return new Promise((resolve, reject) => {
    axios({
      method: 'POST',
      url,
      data: reqData,
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      maxRedirects: 0,
      headers: {
        'Access-Control-Allow-Origin': true,
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...additionalHeaders,
      },
    })
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        const message = err.response?.data?.message
          ? err.response.data.message
          : err.response?.data
          ? err.response.data
          : err.message;
        reject({ status: false, message, additionalInfo: { url } });
      });
  });
};

export const getFilesStatus_checking = (req, res) => {
  // recent update added error handling wms_workflow_eventlog.activitystatus
  const reqData = req.body;
  logger.info(reqData, 'ReqData from getFilesStatus');
  const sqlData = `select distinct on( activityname,aliasstagename,woincomingfileid)
  * 
  from (	 
    select
     
    wms_mst_activity.activityname,wf.activityalias,
      wms_mst_stage.stagename||'('||wms_workflow_eventlog.stageiterationcount||')' as aliasStageName,
      wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
      stageiterationcount,wms_workflow_eventlog.activityiterationcount,case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
      'Hold','Pending','Created','Claimed') then wms_workflow_eventlog.activitystatus else 'Default'
      end as  activitystatus, wms_workflowactivitytrn_file_map.woincomingfileid,wms_workorder.itemcode,
      wms_workorder.workorderid, wms_workorder_incomingfiledetails.filename,wms_workflow_eventlog.wfeventid,wms_mst_service.serviceid, wms_mst_service.servicename 
   FROM wms_workflow_eventlog
     JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
     JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid
     JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid       
     JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid
     JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
     JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
     JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
   JOIN (SELECT ev.activityiterationcount ,ev.stageiterationcount as stgitercount,  wft1.woincomingfileid,wf1.activityid,wf1.stageid
     FROM public.wms_workflow_eventlog ev
         join wms_workflowdefinition  wf1 on wf1.wfdefid = ev.wfdefid
         JOIN wms_workflowactivitytrn_file_map wft1 ON ev.wfeventid = wft1.wfeventid
         JOIN wms_workorder_incomingfiledetails wdti1 ON wft1.woincomingfileid = wdti1.woincomingfileid
         WHERE ev.workorderid = $1) AS sti ON 
    sti.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid AND  sti.activityid=wf.activityid AND sti.stageid=wf.stageid
   AND wms_workflow_eventlog.activityiterationcount = sti.activityiterationcount
     WHERE  wms_workorder.workorderid=$1   
   order by wms_workorder_incomingfiledetails.filesequence  
    )as table3`;

  const sqlStageActivity = `select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
        left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
        left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
        left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
        where wms_workflow.wfid in 
        (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
        wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where workorderid=$1 and lock=false )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
         and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1`;
  // and wms_workflowdefinition.activitytype != 'External Task' order by wms_workflowdefinition.sequence) as table1`;
  // logger.info("sql data==>", sqlData);
  console.log(sqlData, 'sqlData');

  query(sqlData, [reqData.id])
    .then(response => {
      console.log(response, 'response1');
      console.log(sqlStageActivity, 'sqlStageActivity sql');

      query(sqlStageActivity, [reqData.id])
        .then(stageActivityRes => {
          console.log(stageActivityRes, 'stageActivityRes');

          res
            .status(200)
            .json({ data: response, stageActivity: stageActivityRes });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFilesStatus = (req, res) => {
  // recent update added error handling wms_workflow_eventlog.activitystatus
  const reqData = req.body;
  let sqlStageActivity = '';
  let sqlData = '';
  let customerid = 0;
  logger.info(reqData, 'ReqData from getFilesStatus');

  const sqlgetcust = `select customerid from wms_workorder where workorderid = $1`;
  query(sqlgetcust, [reqData.id]).then(response => {
    customerid = response.customerid;
  });

  if (customerid == 8) {
    sqlData = `with cte as (select wms_mst_activity.activityname,wf.activityalias,
        wms_mst_stage.stagename||'('||stageiterationcount||')' as aliasStageName,
        wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
        stageiterationcount,activityiterationcount,wms_workflow_eventlog.actualactivitycount,
        case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
        'Hold','Pending','Created','Claimed') then wms_workflow_eventlog.activitystatus else 'Default'end as  activitystatus, 
        wms_workflowactivitytrn_file_map.woincomingfileid,
        wms_workorder.itemcode,
        wms_workflow_eventlog.wfdefid,
        wms_workorder.workorderid, 
        wms_workorder_incomingfiledetails.filename,
        wms_workflow_eventlog.wfeventid,
        wms_mst_service.serviceid, 
        wms_mst_service.servicename,
        row_number() over(partition by 
        wms_workorder_incomingfiledetails.woincomingfileid,
        wms_mst_activity.activityid,
        wms_workflow_eventlog.stageiterationcount,
        wms_mst_stage.stageid,
        wf.wfdefid
        order by stageiterationcount desc,actualactivitycount desc) as rowcount
    FROM wms_workflow_eventlog  
    JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
    JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid 
    JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
    JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
    JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
    JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
    JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
    where  wms_workorder.workorderid in (select w.workorderid from public.wms_workorder_incoming a
    inner join public.wms_workorder_incomingfiledetails b on b.woincomingid=a.woincomingid 
    inner join wms_workorder_list w on LOWER(w.itemcode)=LOWER(b.filename)
    where a.woid=$1 and b.piinumber <> 'null'
    and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    union 
    SELECT workorderid  FROM wms_workorder_list where workorderid=$1)
    order by wms_workorder_incomingfiledetails.filesequence) 
    
    select * from cte where rowcount =1 and
    stagename in ('Issue Creation','Issue Revises','Elds','Revised Elds','Graphics')
    and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    
    union all
    
    select * from cte where rowcount =1 and
    stagename in ('Incoming Inspection','Pre Editing','Copy Editing','XML Conversion'
    ,'First Proof','Collation','Revises','First View','Graphics','AMO')
    and not exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
    `;

    sqlStageActivity = `;with cte as (
        select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
                left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
                left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
                left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
                where wms_workflow.wfid in 
                (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
                wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where workorderid in ((select w.workorderid from public.wms_workorder_incoming a
                  inner join public.wms_workorder_incomingfiledetails b on b.woincomingid=a.woincomingid 
                  inner join wms_workorder_list w on LOWER(w.itemcode)=LOWER(b.filename)
                  where a.woid=$1 and b.piinumber <> 'null'
                  union 
                  SELECT workorderid  FROM wms_workorder_list where workorderid=$1)) and lock=false )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
                 and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1
          )
          
          select * from cte where 
             stagename in ('Issue Creation','Issue Revises','Elds','Revised Elds','Graphics')
            and exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
            
            union all
            
            select * from cte where
             stagename in ('Incoming Inspection','Pre Editing','Copy Editing','XML Conversion'
        ,'First Proof','Collation','Revises','First View','Graphics','AMO')
            and not exists (select 1 from wms_workorder where coalesce(issuenumber,'')<>'' and customerid=8 and workorderid=$1)
            `;
    // and wms_workflowdefinition.activitytype != 'External Task' order by wms_workflowdefinition.sequence) as table1`;
    // logger.info("sql data==>", sqlData);
    console.log(sqlData, 'sqlData');
  } else {
    sqlData = `;with cte as (select wms_mst_activity.activityname,wf.activityalias,
        wms_mst_stage.stagename||'('||stageiterationcount||')' as aliasStageName,
        wms_mst_stage.stagename,wms_mst_stage.stageid,wms_mst_activity.activityid,
        stageiterationcount,activityiterationcount,wms_workflow_eventlog.actualactivitycount,
        case when wms_workflow_eventlog.activitystatus  in ('Completed','Work in progress','YTS','Reset','Failed','Rejected','Unassigned',
        'Hold','Pending','Created','Claimed') then wms_workflow_eventlog.activitystatus else 'Default'end as  activitystatus, 
        wms_workflowactivitytrn_file_map.woincomingfileid,
        wms_workorder.itemcode,
        wms_workflow_eventlog.wfdefid,
        wms_workorder.workorderid, 
        wms_workorder_incomingfiledetails.filename,
        wms_workflow_eventlog.wfeventid,
        wms_mst_service.serviceid, 
        wms_mst_service.servicename,
        row_number() over(partition by 
        wms_workorder_incomingfiledetails.woincomingfileid,
        wms_mst_activity.activityid,
        wms_workflow_eventlog.stageiterationcount,
        wms_mst_stage.stageid,
        wf.wfdefid
        order by stageiterationcount desc,actualactivitycount desc) as rowcount
  FROM wms_workflow_eventlog  
  JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
  JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid 
  JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
  JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
  JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
  JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
  JOIN wms_mst_service on wms_mst_service.serviceid = wms_workflow_eventlog.serviceid
  where  wms_workorder.workorderid=$1
  order by wms_workorder_incomingfiledetails.filesequence) select * from cte where rowcount =1`;

    sqlStageActivity = `select  stagename,activityName,iscompletiontriggeractivity, activityalias from (select * from wms_workflowdefinition 
  left join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
  left join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
  left join wms_workflow on wms_workflow.wfid=wms_workflowdefinition.wfid
  where wms_workflow.wfid in 
  (select  wfid from wms_workflow_eventlog join wms_workflowdefinition on 
  wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid where workorderid=$1 and lock=false )  and (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
   and lock=false and wms_workflowdefinition.enablefilestatusreport = true order by wms_workflowdefinition.sequence) as table1`;
    console.log(sqlData, 'sqlData');
  }

  query(sqlData, [reqData.id])
    .then(response => {
      query(sqlStageActivity, [reqData.id])
        .then(stageActivityRes => {
          res
            .status(200)
            .json({ data: response, stageActivity: stageActivityRes });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getProcessAdherence = (req, res) => {
  const { wfEventId } = req.body;
  const sql = `select checklist from wms_workflow_eventlog where wfeventid=${wfEventId}`;
  // let sql = `select checklist from wms_workflow_eventlog where wfeventid=2571`
  query(sql)
    .then(response => {
      res.status(200).json({ data: response, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getFileStatus = (req, res) => {
  const {
    stage,
    activity,
    customer,
    du,
    workOrderId,
    woincomingfileid,
    wfeventid,
    service: service1,
  } = req.body.file;
  logger.info(req.body.file, 'ReqData from getFileStatus');
  let sqlData = `select wo.itemcode,filename,wms_mst_stage.stagename||'('||stageiterationcount||')'  as stagename,  
  wms_mst_activity.activityname||'('||activityiterationcount||')' as activityname, 
  wms_workflowdefinition.activityalias||'('||activityiterationcount||')' as activityalias, case when activitytype = 'External Task' then '{"SYSTEM_NAME":"WMS Engine"}' else sysinfo
  end as systeminfo,COALESCE(users.userid||'('||users.username||')', 'System') as userid,
  eventlog.* from ( SELECT wms_workflow_eventlog.workorderid, wms_workflow_eventlog.wfdefid,
  stageiterationcount,activityiterationcount,wms_workflow_eventlog_details.actualactivitycount,serviceid,
  operationtype,wms_workflow_eventlog_details.timestamp,systeminfo as sysinfo,wfeventdetailid,
  wms_workflow_eventlog_details.userid as tempuserid
  FROM wms_workflow_eventlog_details
  JOIN wms_workflow_eventlog on wms_workflow_eventlog.wfeventid = wms_workflow_eventlog_details.wfeventid
  WHERE wms_workflow_eventlog_details.wfeventid=${wfeventid}  
  AND operationtype NOT IN ('YTS', 'Claimed')
    ORDER BY wfeventdetailid ASC) as eventlog
    JOIN wms_workorder as wo on wo.workorderid = eventlog.workorderid
    JOIN wms_workorder_incomingfiledetails ON  wms_workorder_incomingfiledetails.woincomingfileid =${woincomingfileid}
    JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = eventlog.wfdefid
    JOIN wms_mst_activity on wms_mst_activity.activityid = wms_workflowdefinition.activityid
    JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
    JOIN wms_mst_service on wms_mst_service.serviceid = eventlog.serviceid
    LEFT JOIN wms_user as users on users.userid = eventlog.tempuserid`;
  logger.info(sqlData, 'sqlll');
  query(sqlData, [])
    .then(async response => {
      const filesInfo = await getFileInfoDetails({
        stage,
        activity,
        customer,
        du,
        workOrderId,
        service: service1,
        woincomingfileid,
        wfEventId: wfeventid,
      });
      const tempFilesInfo = [];
      filesInfo.forEach(fIn => {
        if (fIn.incomingFileId === woincomingfileid) {
          tempFilesInfo.push(fIn);
        }
      });
      const placeholder = await getWorkflowPlaceHolders(wfeventid);
      sqlData = `select fileconfig from wms_workflowdefinition wfd join wms_workflow_eventlog wel on wfd.wfdefid=wel.wfdefid where wfeventid=${wfeventid}`;
      await query(sqlData, [])
        .then(async fileResponse => {
          // updated for fileconfig restructure
          const fileconfig = fileResponse.length
            ? ReStructureFileConfig(fileResponse[0].fileconfig)
            : {};
          const validationFileConfig =
            fileconfig && fileconfig.fileTypes ? fileconfig.fileTypes : {};
          const eventData = {};
          const mandatorySaveFile = {};
          const filesData = await fetchValidationDetails(
            tempFilesInfo,
            validationFileConfig,
            placeholder,
            eventData,
            mandatorySaveFile,
            workOrderId,
          );
          const dmsType = await getdmsType(workOrderId);
          const files = [];
          if (filesData.filesInfo && filesData.filesInfo.length) {
            filesData.filesInfo[0].files.forEach(fr => {
              // if (!fr.isReadOnly) {
              fr.dmstype = dmsType;
              files.push(fr);
              // }
            });
          }
          sqlData = `select checklist from wms_workflow_eventlog where wfeventid=${wfeventid}`;
          await query(sqlData, []).then(async checklist => {
            res.status(200).json({ data: response, files, checklist });
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// export const constGetStageAndActivityName = (req, res) => {
//     logger.info('reqbody', req);
//     let sqlData = `select distinct wms_mst_activity.activityname, wms_mst_stage.stagename from wms_workflow_eventlog
//     JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid
//     JOIN wms_workflowdefinition ON wms_workflow_eventlog.wfdefid = wms_workflowdefinition.wfdefid
//     JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
//     JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid
//     JOIN wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid
//     JOIN wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
//     where wms_workorder.itemcode='CUP0003'`;
//     query(sqlData, []).then((response) => {
//         logger.info('response bookfile details', [...new Set(response.map(x=>x.stagename))]);
//         res.status(200).json({ data: response })
//     }).catch((error) => {
//         res.status(400).send({ message: error });
//     });
// }
export const isDownloadAndUploadFile = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData for file ');
  logger.info(reqData.actfilemapid, 'reqData for file Download or upload');
  let sql = '';
  if (reqData.actfilemapid > 0) {
    sql = `UPDATE wms_workflowactivitytrn_file_map SET isdownloaded =$1,ischeckedout=$3  WHERE actfilemapid = $2 `;
    logger.info(sql, 'sql');
    query(sql, [
      reqData.isdownloaded,
      reqData.actfilemapid,
      reqData.ischeckedout,
    ])
      .then(() => {
        res.status(200).json({
          data: `Files has been  ${
            reqData.isdownloaded ? 'Downloaded' : 'Uploaded'
          } successfully`,
        });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'No Files to Downloaded/Uploaded' });
  }
};

export const isFileCheckout = (req, res) => {
  const reqData = req.body;
  const url = `${config.openKM.uri.ischeckout}/${reqData.repofileuuid}`;
  logger.info(reqData.repofileuuid, 'reqData.repofileuuid');
  logger.info(`${config.openKM.base_url}${url}`, 'url1');
  const headers = {};
  service
    .get(`${config.openKM.base_url}${url}`, {}, headers)
    .then(response => {
      logger.info(response, 'back end response');
      res.status(200).json({ data: response.data });
    })
    .catch(err => {
      res.status(400).send({ message: err });
    });
};

export const isFileExists = (req, res) => {
  const reqData = req.body;
  const url = `${config.openKM.uri.ischeckout}/${reqData.repofileuuid}`;
  logger.info(reqData.repofileuuid, 'reqData.repofileuuid');
  logger.info(`${config.openKM.base_url}${url}`, 'url1');
  const headers = {};
  service
    .get(`${config.openKM.base_url}${url}`, {}, headers)
    .then(response => {
      logger.info(response, 'back end response');
      res.status(200).json({ data: response.data });
    })
    .catch(err => {
      res.status(400).send({ message: err });
    });
};

export const newDocumentFileupload = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData for file ');
  logger.info(reqData.repofileuuid, 'reqData for file Download or upload');
  if (reqData.repofileuuid) {
    logger.info(reqData.wfeventid, 'inside query ');
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded,woincomingfileid)
        VALUES('${reqData.wfeventid}', '${reqData.repofileuuid}', '${reqData.repofilepath}', null, true, false,${reqData.woincomingfileid})`;
    logger.info(sql, 'sql');
    query(sql)
      .then(() => {
        res.status(200).json({ message: 'File uploaded successfully' });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'No Files to Uploaded' });
  }
};

export const newFileType = async (req, res) => {
  const {
    woid,
    serviceid,
    stageid,
    updatedby,
    filetypeid,
    filename,
    wfeventid,
    uuid,
    filepath,
    duedate,
    filesequence,
    isSubjob,
  } = req.body;
  logger.info(req.body, 'reqData for newFileType ');

  // check the iTracks call
  const { status } = await checkItracksExits(req, res);
  logger.info(status, 'status of iTracks');

  const checkCount = `select a.woincomingfileid,a.woincomingid,a.filename,a.filepath,a.fileuuid,a.imagecount,a.filetypeid,a.istriggered 
  from public.wms_workorder_incomingfiledetails a
  join wms_workorder_incoming b on b.woincomingid = a.woincomingid
  where b.woid =${woid}  and filename = '${filename}' and a.filetypeid !=1
  order by a.woincomingfileid desc`;
  const fileInfo = await query(checkCount);
  if (!fileInfo.length) {
    if (isSubjob && status) {
      // call iTracks API
      const jobArray = [req.body];
      logger.info(jobArray, 'jobArray req data');
      const subJobRes = await addSubJob(jobArray, req.body, false, true);
      const { status: status1, message } = subJobRes;
      logger.info(subJobRes, 'res for subjob creation');

      if (status1) {
        logger.info('iTracks call success');

        const sql = `INSERT INTO public.wms_workorder_incoming(
      woid, serviceid, stageid, receiptdatetime, duedate, updatedby, batchno, updatedon)
     VALUES ( ${woid}, ${serviceid}, ${stageid}, null, null, '${updatedby}', null, current_timestamp) returning *;`;
        query(sql)
          .then(response => {
            logger.info('response', response[0].woincomingid);
            const incomingFilesSql = `INSERT INTO public.wms_workorder_incomingfiledetails(
          woincomingid, filetypeid, filename, filepath, fileuuid, duedate, mspages, estimatedpages, imagecount, tablecount, equationcount, batchno, filesequence, isactive)
         VALUES ( ${
           response[0].woincomingid
         }, '${filetypeid}', '${filename}', '${filepath}',' ${uuid}', '${
              duedate || null
            }', null, null, null, null, null, null, ${filesequence}, null) returning *;`;
            logger.info('sql==>1', sql);
            logger.info('sql==>', incomingFilesSql);
            query(incomingFilesSql).then(IncomingResponse => {
              const txnIncmoingsql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
             wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded, woincomingfileid,ischeckedout)
            VALUES ( ${wfeventid}, '${uuid}', '${filepath}', null, true, false ,${IncomingResponse[0].woincomingfileid},false);`;
              query(txnIncmoingsql).then(async () => {
                // update subjobid in db
                const auditRes = await subJobAudit(message, [
                  IncomingResponse[0].woincomingfileid,
                ]);
                logger.info(auditRes, 'auditRes');

                // // await getStageinfo update
                // let camundaUpdate = await updtageStageinfo(woid,IncomingResponse[0].woincomingfileid)

                if (auditRes.status) {
                  res.status(200).json({
                    message: 'New File type Added successfully',
                    data: IncomingResponse[0].woincomingfileid,
                  });
                } else {
                  res.status(400).send({ message: auditRes.message });
                }
              });
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        logger.info('iTracks call error');
        res.status(400).send({ message });
      }
    } else {
      logger.info('without subjob creation');

      const sql = `INSERT INTO public.wms_workorder_incoming(
      woid, serviceid, stageid, receiptdatetime, duedate, updatedby, batchno, updatedon)
     VALUES ( ${woid}, ${serviceid}, ${stageid}, null, null, '${updatedby}', null, current_timestamp) returning *;`;
      query(sql)
        .then(response => {
          logger.info('response', response[0].woincomingid);
          const incomingFilesSql = `INSERT INTO public.wms_workorder_incomingfiledetails(
          woincomingid, filetypeid, filename, filepath, fileuuid, duedate, mspages, estimatedpages, imagecount, tablecount, equationcount, batchno, filesequence, isactive)
         VALUES ( ${
           response[0].woincomingid
         }, '${filetypeid}', '${filename}', '${filepath}',' ${uuid}', '${
            duedate || null
          }', null, null, null, null, null, null, ${filesequence}, null) returning *;`;
          logger.info('sql==>1', sql);
          logger.info('sql==>', incomingFilesSql);
          query(incomingFilesSql).then(async IncomingResponse => {
            const txnIncmoingsql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
             wfeventid, repofileuuid, repofilepath, workingfolderpath, isvisible, isdownloaded, woincomingfileid,ischeckedout)
            VALUES ( ${wfeventid}, '${uuid}', '${filepath}', null, true, false ,${IncomingResponse[0].woincomingfileid},false);`;
            // get stage info update
            // let camundaUpdate = await updtageStageinfo(woid,IncomingResponse[0].woincomingfileid)
            query(txnIncmoingsql).then(() => {
              res.status(200).json({
                message: 'New File type Added successfully',
                data: IncomingResponse[0].woincomingfileid,
              });
            });
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    }
  } else {
    res.status(400).send({ message: 'Filename already exist' });
  }
};

export const updtageStageinfo = async (woid, id) => {
  return new Promise(async (resolve, reject) => {
    try {
      let processInstanceId = '';
      let taskInstanceId = '';
      // .......GETTING PROCESS INSTANCEID.......//
      const sql1 = `select distinct eventdata->>'processInstanceId' as processinstanceid,taskinstanceid from wms_workflow_eventlog where workorderid = $1`;
      await query(sql1, [woid]).then(async response => {
        if (response && response.length) {
          processInstanceId = response[0].processinstanceid;
          taskInstanceId = response[0].taskinstanceid;
        }
      });

      // get stage info
      const getCamundaStageInfo = await _getStageInfoFromCamunda(woid);

      logger.info(getCamundaStageInfo, 'getCamundaStageInfo');
      let testobj = [];
      testobj = JSON.parse(getCamundaStageInfo.__stageInfo.data.value);

      const object = {
        id,
        isGraphic: false,
      };

      testobj.files.push(object);
      testobj.totalChapters = testobj.files.length;

      getCamundaStageInfo.__stageInfo.data.value = JSON.stringify(testobj);

      // update stage info
      const updateCamundaStageInfo = await _updateStageInfoToCamunda(
        JSON.parse(getCamundaStageInfo.__stageInfo.data.value),
        processInstanceId,
      );

      // update taskinstanceid
      const updateTaskInstanceInfo = await _updateActivityStageInfoToCamunda(
        JSON.parse(getCamundaStageInfo.__stageInfo.data.value),
        taskInstanceId,
      );

      logger.info(
        updateCamundaStageInfo,
        updateTaskInstanceInfo,
        'error update',
      );
      if (updateCamundaStageInfo) {
        resolve(true);
      } else {
        reject('Camunda update failed');
      }
    } catch (error) {
      reject(error);
      console.log(error, 'update stage info');
    }
  });
};

export const newFileTypeUpdate = (req, res) => {
  const { uuid, filepath, woincomingfileid } = req.body;
  console.log(req.body, 'reqData for newFileType  update');
  const incomingFilesSql = `UPDATE public.wms_workorder_incomingfiledetails SET filepath='${filepath}', fileuuid='${uuid}' WHERE woincomingfileid=${woincomingfileid} RETURNING woincomingfileid  `;
  console.log('sql==> incomingFilesSql update', incomingFilesSql);
  query(incomingFilesSql)
    .then(IncomingResponse => {
      const txnIncmoingsql = `UPDATE public.wms_workflowactivitytrn_file_map SET repofilepath='${filepath}', repofileuuid='${uuid}' WHERE woincomingfileid=${woincomingfileid}  `;
      console.log('sql txnIncmoingsql ==> update', txnIncmoingsql);
      query(txnIncmoingsql)
        .then(() => {
          res.status(200).json({
            message: 'New File type updated successfully',
            data: IncomingResponse[0].woincomingfileid,
          });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getViewHistory = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'dataforhisotry');
  let sql = '';
  let eventID = 0;
  let wfData = [];
  const result = [];
  let operationData = [];
  let fileData = [];
  sql = `SELECT  wms_workflow_eventlog.wfeventid,wms_workflow_eventlog_details.operationtype,wms_workflow_eventlog_details.timestamp, CONCAT(wms.stagename, '(', wms_workflow_eventlog.stageiterationcount, ')')
    as stagename, CONCAT(wma.activityname, '(', wms_workflow_eventlog.activityiterationcount, ')')
    as activityname, wms_workorder_incomingfiledetails.filename, pp_mst_filetype.filetype,wms_workorder_incomingfiledetails.filepath,wms_workflow_eventlog_details.userid,wms_user.username
     FROM wms_workflow_eventlog as wms_workflow_eventlog
     JOIN wms_workflow_eventlog_details as wms_workflow_eventlog_details  ON wms_workflow_eventlog_details.wfeventid = wms_workflow_eventlog.wfeventid
    left JOIN public.wms_user as wms_user ON wms_user.userid = wms_workflow_eventlog_details.userid
    JOIN wms_workflowdefinition as wms_workflowdefinition
        ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
    JOIN wms_mst_stage as wms
        ON wms.stageid = wms_workflowdefinition.stageid
    JOIN wms_mst_activity as wma
         ON wma.activityid = wms_workflowdefinition.activityid
    LEFT JOIN wms_workorder_incomingfiledetails as wms_workorder_incomingfiledetails
        ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
    LEFT JOIN pp_mst_filetype
        ON pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
   WHERE wms_workflow_eventlog.workorderid = ${reqData.wfOrderId} AND wms_workflow_eventlog.serviceid = ${reqData.serviceId}
   ORDER BY wfeventid ASC
   `;
  logger.info(sql, 'sqlforhistory');

  let history = {};
  query(sql)
    .then(response => {
      wfData = response;
      logger.info(response, 'responseforhistory');
      response.forEach(d => {
        if (d.wfeventid != eventID) {
          // logger.info(d.wfeventid,eventID)
          eventID = d.wfeventid;
          wfData.forEach(x => {
            if (x.wfeventid == eventID) {
              operationData.push({
                operation: x.operationtype,
                timestamp: x.timestamp,
                userid: x.userid,
                user: x.username,
              });
              // fileData.push({
              //     "filename": x.filename,
              //     "filepath": x.filepath,
              //     "filetype": x.filetype
              // })
            }
          });
          history = {
            wfeventid: d.wfeventid,
            stagename: d.stagename,
            activityname: d.activityname,
            starttime:
              operationData.filter(x => x.operation == 'Created').length > 0
                ? operationData.filter(x => x.operation == 'Created')[0]
                    .timestamp
                : '',
            endtime:
              operationData.filter(x => x.operation == 'Completed').length > 0
                ? operationData.filter(x => x.operation == 'Completed')[0]
                    .timestamp
                : '',
            operations: operationData.sort(function (a, b) {
              return a.timestamp - b.timestamp;
            }),
            files: fileData,
            filename: d.filename,
            filetype: d.filetype,
          };
          history.timetaken = calculateTime(history.operations);
          result.push(history);
          operationData = [];
          fileData = [];
        }
      });

      logger.info(result, 'historyforresult');
      res.status(200).json({ data: result });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
const calculateTime = operations => {
  let totaltime = 0;
  let wiptime = 0;
  let isWip = false;
  operations.forEach(val => {
    if (val.operation == 'Work in progress') {
      isWip = true;
      wiptime = val.timestamp;
    } else if (isWip) {
      isWip = false;
      totaltime += val.timestamp - wiptime;
    }
  });
  if (isWip) {
    totaltime += new Date().getTime() - wiptime;
  }
  const timemin = totaltime / (60 * 1000);
  logger.info(timemin, 'timemin');
  const hours = Math.floor(timemin / 60);
  const minutes = timemin % 60;
  logger.info(`${hours}:${minutes}`, 'hours+minutes');
  return `${hours}:${minutes.toFixed(0)}`;
};
export const getAuditAndFile = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'dataforhisotry');
  const sql = `SELECT  * from  wms_task_files
            WHERE  wms_task_files.wfeventid = ${reqData.wfeventID}
            ORDER BY wfeventid ASC`;
  logger.info(sql, 'sqlforfiless');
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateAuditHistory = async (req, res) => {
  const {
    files,
    woId,
    serviceId,
    stageId,
    activityId,
    activityIterationCount,
    stageIterationCount,
    updatedBy,
    wfeventId,
  } = req.body;
  console.log(req.body, 'bodddyyyyyupdateeeeee');
  let status = true;
  let fileReorderAuditId = '';
  const defaultSql = `SELECT * FROM public.wms_task_filereorder_audit where workorderid =${woId} ORDER BY filereorderauditid ASC`;
  await query(defaultSql)
    .then(async response => {
      console.log(response, 'responnnsnsns111');
      if (response.length) {
        fileReorderAuditId = response[0].filereorderauditid;
      } else {
        const sql = `INSERT INTO public.wms_task_filereorder_audit(wfeventid,workorderid, serviceid, stageid, activityid, stageiterationcount, activityiterationcount)
                  VALUES (${wfeventId || null}, ${woId}, ${serviceId}, ${
          stageId || null
        }, ${activityId || null}, ${stageIterationCount || null}, ${
          activityIterationCount || null
        }) RETURNING filereorderauditid`;
        console.log(sql, 'customermap11');
        await query(sql)
          .then(async fileReorderResponse => {
            fileReorderAuditId = fileReorderResponse[0].filereorderauditid;
            console.log(fileReorderResponse, 'responseiddd1111');
          })
          .catch(() => {
            status = false;
          });
      }
    })
    .catch(() => {
      status = false;
    });
  if (status == true && fileReorderAuditId) {
    const auditSql = `INSERT INTO public.wms_task_filereorder_audit_history(filereorderauditid, updatedby, updatedon,files) VALUES ($1, $2, $3,$4)`;
    console.log(auditSql, 'auditSq11111111111l');
    await query(auditSql, [fileReorderAuditId, updatedBy, new Date(), files])
      .then(async ResponseAuditSql => {
        console.log(ResponseAuditSql, 'ResponseAuditSql');
        res.status(200).json({ data: ResponseAuditSql });
      })
      .catch(() => {
        status = false;
      });
  } else {
    res.status(400).send({ message: 'Failed to get the filereorderauditid' });
  }
};

export const getEventIdForWo = async (req, res) => {
  const { WoId } = req.body;
  try {
    const sql = `select wfeventid from wms_workflow_eventlog where workorderid =${WoId} and (activitystatus != 'Completed' and activitystatus != 'Rejected' and activitystatus != 'Reset')`;
    logger.info(sql, 'sqlsql');
    query(sql)
      .then(response => {
        res.status(200).json({ data: response });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (e) {
    console.log(e, 'error occured while getting eventid');
  }
};

export const getLastInstanceActivity = (req, res) => {
  const { wfDefId, woId, fileTypeId } = req.body;
  let sql = `select count(*) from wms_workflow_eventlog as eventlog
  left join  wms_workorder_incomingfiledetails  as incomingdetails on incomingdetails.woincomingfileid = eventlog.woincomingfileid
 where eventlog.workorderid = ${woId} and eventlog.wfdefid = ${wfDefId} and incomingdetails.filetypeid = ${fileTypeId}`;
  console.log(sql, 'sql for latest acitivity');
  query(sql)
    .then(result => {
      console.log(result, 'res for latest actiivty');
      if (result[0].count > 0) {
        const Obj = {};
        Obj.type = 'indexpresent';
        Obj.count = result[0].count;
        res.status(200).json({ data: Obj });
      } else {
        sql = `select count(*) from wms_workflow_eventlog as eventlog
          where eventlog.workorderid = ${woId} and eventlog.wfdefid = ${wfDefId} and (eventlog.activitystatus = 'Completed' or eventlog.activitystatus = 'Rejected' or eventlog.activitystatus = 'Reset')`;
        logger.info('sql query for without index type', sql);
        query(sql, [])
          .then(data => {
            const Obj = {};
            Obj.type = 'indexnotpresent';
            Obj.count = data[0].count;
            logger.info('response for index type2', Obj);
            res.status(200).json({ data: Obj });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      }
    })
    .catch(error => {
      console.log(error, 'error for latest activity');
      res.status(400).send({ message: error });
    });
};

// user event history capture
export const captureUserEvent = async (req, res) => {
  try {
    await _captureUserEvent(req, req.body);
    res.status(200).json({ data: 'success' });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const _captureUserEvent = async (req, data) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sysInfo = req.headers.systemdetail
        ? JSON.parse(req.headers.systemdetail)
        : {};
      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...sysInfo,
      };
      logger.info(data, 'data - captureUserEvent');
      const { wfeventId, userId, userid } = data;
      const actionType = data.actionType.toUpperCase();
      let sql = `SELECT * from public.wms_workorder_activity_audit WHERE wfeventid = $1 and actiontype = $2`;
      logger.info(sql, 'select auditSq11111111111l');
      const existData = await query(sql, [wfeventId, actionType]);
      if (existData.length) {
        const { activityauditid } = existData[0];
        sql = `UPDATE public.wms_workorder_activity_audit SET updatedon = $1 WHERE activityauditid = $2`;
        logger.info(sql, 'update auditSq11111111111l');
        await query(sql, [new Date(), activityauditid]);
      } else {
        sql = `INSERT INTO public.wms_workorder_activity_audit(wfeventid, actiontype, createdon, updatedby, systeminfo)
        VALUES ($1, $2, $3, $4, $5)`;
        logger.info(sql, 'insert auditSq11111111111l');
        await query(sql, [
          wfeventId,
          actionType,
          new Date(),
          userId || userid,
          systemInfo,
        ]);
      }
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
};

export const updateTypeSetPages = async (req, res) => {
  try {
    const { woincomingfileid, typesetpage } = req.body;
    const sql = `UPDATE public.wms_workorder_incomingfiledetails SET uomvalue=${typesetpage}, typesetpage=${typesetpage}
    WHERE woincomingfileid=${woincomingfileid}`;
    await query(sql);
    res.status(200).json({ data: 'Successfully updated typeset page' });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};
export const getWOTypeSetPageList = async (req, res) => {
  try {
    const { workorderId } = req.body;
    const sql = `select filename, typesetpage, woincomingfileid from public.wms_workorder_incoming
    join public.wms_workorder_incomingfiledetails on  wms_workorder_incomingfiledetails.woincomingid=wms_workorder_incoming.woincomingid
    where woid=${workorderId}`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};
