// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { transaction } from '../../../../database/postgres.js';
import {
  checkItracksExits,
  canWorkActivity,
  openEntryExists,
  getSubjobIds,
  logisticEntryInsert,
  logisticEntryInsertJournal,
  _getWorksheetId,
} from '../../../iTracks/index.js';
import logger from '../../../utils/logs/index.js';
import { _captureUserEvent } from '../../taskDetails.js';
import {
  postProcess,
  preProcess,
  checkWipTask,
  checkWipTaskSameUser,
} from './index.js';

export const TaskViewPreProcess = async (req, res) => {
  try {
    const { userid, wfeventId } = req.body;
    let { systemdetail } = req.headers;
    // capture user event
    const payload = {
      userId: userid,
      wfeventId,
      actionType: 'Work in progress - resuming task',
    };
    preProcess(req, payload);
    // checking for wip task resuming the same user
    if (systemdetail) {
      systemdetail = JSON.parse(systemdetail);
      // if (systemdetail.SYSTEM_NAME != 'WEB') {
      await checkWipTaskSameUser(wfeventId, userid, systemdetail.SYSTEM_NAME);
      // }
    }
    res.status(200).send({ message: 'Success', success: true });
  } catch (e) {
    logger.info(e);
    res
      .status(400)
      .send({ message: e.message ? e.message : e, success: false });
  }
};
export const taskViewAction = async (req, res) => {
  try {
    const { userid, wfeventId, taskInstanceId, woType, workorderId } = req.body;
    // capture user event
    const payload = {
      userId: userid,
      wfeventId,
      actionType: 'Work in progress',
    };
    preProcess(req, payload);
    logger.info(workorderId);
    // // checking for wip task
    await checkWipTask(userid);

    // check iTracks API call
    const isItracksAPI = await checkItracksExits(req, res, true);
    console.log(isItracksAPI, 'isItracksAPI');
    const { status } = isItracksAPI;
    const checkWorkSheetIdExists = await _getWorksheetId(wfeventId);
    console.log(checkWorkSheetIdExists, 'checkWorkSheetIdExists');
    if (status && !checkWorkSheetIdExists) {
      const isCanWork = await canWorkActivity(req.body);
      const { status: stat, iStageId, iActivityId } = isCanWork;
      console.log(stat, 'status of isCanWork');
      if (stat) {
        const isEntryExists = await openEntryExists(req.body);
        const { status: st } = isEntryExists;
        console.log(st, 'status of exists');
        if (!st || st) {
          // Logistic Insert
          if (woType === 'Book') {
            const iSubjobIds = await getSubjobIds(req.body);
            if (iSubjobIds) {
              req.body.iStageId = iStageId;
              req.body.iActivityId = iActivityId;
              req.body.subjobArray = iSubjobIds;
              const entryRes = await logisticEntryInsert(req.body);
              const { status: sta } = entryRes;
              if (sta) {
                taskAction(userid, wfeventId, taskInstanceId, req)
                  .then(async response => {
                    res.send(response);
                    // capture user event
                    const paload = {
                      userId: userid,
                      wfeventId,
                      actionType: 'Work in progress',
                    };
                    postProcess(paload);
                  })
                  .catch(e => {
                    res.status(400).send(e);
                  });
              } else {
                res.status(400).send(entryRes);
              }
            } else {
              res.status(400).send({
                status: false,
                message: 'iTracks subjobid not found in iWMS',
              });
            }
          } else {
            console.log('inside journal logistic entry');

            req.body.iStageId = iStageId;
            req.body.iActivityId = iActivityId;
            const entryRes = await logisticEntryInsertJournal(req.body);
            const { status: staus } = entryRes;
            if (staus) {
              taskAction(userid, wfeventId, taskInstanceId, req)
                .then(async response => {
                  res.send(response);
                })
                .catch(e => {
                  res.status(400).send(e);
                });
            } else {
              res.status(400).send(entryRes);
            }
          }
        } else {
          res.status(400).send(isEntryExists);
        }
      } else {
        res.status(400).send(isCanWork);
      }
    } else {
      console.log('view task without iTracks');
      taskAction(userid, wfeventId, taskInstanceId, req)
        .then(async response => {
          res.send(response);
          // capture user event
          const paload = {
            userId: userid,
            wfeventId,
            actionType: 'Work in progress',
          };
          postProcess(paload);
        })
        .catch(e => {
          res.status(400).send(e);
          logger.info(e);
        });
    }
  } catch (e) {
    logger.info(e);
    res
      .status(400)
      .send({ message: e.message ? e.message : e, success: false });
  }
};

export const taskAction = async (userId, wfeventId, taskInstanceId, req) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { actualActivityCount } = req.body;
      await transaction(async client => {
        let sql = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE wfeventid = $3 AND taskinstanceid = $4 `;
        await client.query(sql, [
          userId,
          'Work in progress',
          wfeventId,
          taskInstanceId,
        ]);
        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6)`;
        await client.query(sql, [
          wfeventId,
          'Work in progress',
          new Date(),
          userId,
          systemInfo,
          actualActivityCount,
        ]);
        resolve('Work in Progress!');
      });

      // await startCronJob(wfeventId);
    } catch (e) {
      if (e?.message?.data?.message) {
        reject(e.message.data.message);
      } else {
        reject(e.message ? e.message : e);
      }
    }
  });
};

export const _viewPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _viewPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};
