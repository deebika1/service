import {
  claimAction,
  assignAction,
  updatePriority,
  calimPreProcess,
  _claimPostProcess,
  _claimPreProcess,
} from './claim.js';
import {
  TaskViewPreProcess,
  taskViewAction,
  _viewPreProcess,
  _viewPostProcess,
} from './view.js';
import { query } from '../../../../database/postgres.js';
import { ReStructureFileConfig } from '../../../utils/fileValidation/validate.js';

export const process = (req, res) => {
  const { type } = req.params;
  switch (type) {
    case 'Claim':
      claimAction(req, res);
      break;
    case 'TaskView':
      taskViewAction(req, res);
      break;
    case 'Assign':
      assignAction(req, res);
      break;
    case 'Priority':
      updatePriority(req, res);
      break;
    case 'calimPreProcess':
      calimPreProcess(req, res);
      break;
    case 'TaskViewPreProcess':
      TaskViewPreProcess(req, res);
      break;
    default:
      break;
  }
};

export const preProcess = (req, payload) => {
  const { actionType } = payload;
  switch (actionType) {
    case 'Claim':
      _claimPreProcess(req, payload);
      break;
    case 'View':
      _viewPreProcess(req, payload);
      break;
    default:
      break;
  }
};

export const postProcess = (req, payload) => {
  const { actionType } = payload;
  switch (actionType) {
    case 'Claim':
      _claimPostProcess(req, payload);
      break;
    case 'View':
      _viewPostProcess(req, payload);
      break;
    default:
      break;
  }
};
// check wip task exists
export const checkWipTask = async userId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select * from wms_tasklist where lower(userid) ='${userId.toLowerCase()}' and activitystatus='Work in progress'`;
      const result = await query(sql);
      // updated for fileconfig restructure
      for (const iterator of result) {
        if (iterator.fileconfig) {
          iterator.fileconfig = ReStructureFileConfig(iterator.fileconfig);
        }
      }
      if (result.length) {
        reject(
          `You are not allowed to claim this task since you already have a task in progress (Book Code : ${result[0].itemcode}, Activity : ${result[0].activityname})`,
        );
      } else {
        resolve(true);
      }
    } catch (e) {
      reject(e);
    }
  });
};

// checking for wip task resuming the same user
export const checkWipTaskSameUser = async (wfeventId, userId, SYSTEM_NAME) => {
  return new Promise(async (resolve, reject) => {
    let sql;
    try {
      sql = `select *, systeminfo::JSON->> 'SYSTEM_NAME' as systemname, systeminfo::JSON->> 'systemIP' as systemip  from wms_workflow_eventlog_details where wfeventid=${wfeventId} and operationtype='Work in progress'
      and lower(userid) ='${userId.toLowerCase()}' order by wfeventdetailid desc `;
      const result = await query(sql);
      if (
        result.length &&
        result[0].systemname &&
        result[0].systemname.toLowerCase() == SYSTEM_NAME.toLowerCase()
      ) {
        resolve(true);
      } else {
        let sysName = 'System';
        sysName = result[0].systemname || result[0].systemip || 'System';
        reject(
          `You are not allowed to resume this task since this task is already in wip in another system (${sysName})`,
        );
      }
      if (result.length) {
        resolve(true);
      } else {
        sql = `select *, systeminfo::JSON->> 'SYSTEM_NAME' as systemname, systeminfo::JSON->> 'systemIP' as systemip  from wms_workflow_eventlog_details where wfeventid=${wfeventId} and operationtype='Work in progress'
        and lower(userid) ='${userId.toLowerCase()}'  order by wfeventdetailid desc `;
        const resultOf = await query(sql);
        let sysName = 'System';
        if (resultOf.length) {
          sysName = resultOf[0].systemname || resultOf[0].systemip || 'System';
        }
        reject(
          `You are not allowed to resume this task since this task is already in wip in another system (${sysName})`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};
