// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { config } from '../../../../config/restApi.js';
import { Service } from '../../../../httpClient/index.js';
import { transaction, query } from '../../../../database/postgres.js';
import { emitAction, actions } from '../../../activityListener/index.js';
import {
  checkItracksExits,
  canWorkActivity,
  openEntryExists,
  getSubjobIds,
  logisticEntryInsert,
  logisticEntryInsertJournal,
} from '../../../iTracks/index.js';
import logger from '../../../utils/logs/index.js';
import { postProcess, preProcess, checkWipTask } from './index.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { preClaimValidation } from '../workflow/utils/validation.js';

const service = new Service();

export const calimPreProcess = async (req, res) => {
  const {
    userId,
    workorderId,
    wfeventId,
    woincomingFileId,
    // eslint-disable-next-line no-unused-vars
    taskType,
    // eslint-disable-next-line no-unused-vars
    fileName,
    activityIterationCount,
    stageIterationCount,
    wfDefId,
    // eslint-disable-next-line no-unused-vars
    wfId,
    preActivity,
  } = req.body;

  try {
    // capture user event
    const payload = {
      userId,
      wfeventId,
      actionType: 'Claim',
    };
    preProcess(req, payload);
    // checking for wip task
    await checkWipTask(userId);
    // checking for priority;
    const resultforpriority = await getFileSeqByPriority(
      workorderId,
      wfDefId,
      stageIterationCount,
      activityIterationCount,
      wfeventId,
    );
    console.log(resultforpriority, 'resultforpriority');
    if (resultforpriority.data) {
      // to be deleted
      // Checking for graphic validation
      // const resultforgrpahic = await getGraphicValidationList(
      //   workorderId,
      //   wfeventId,
      //   woincomingFileId,
      //   taskType,
      //   fileName,
      //   wfId,
      // );
      // console.log(resultforgrpahic, 'resultforgrpahic');

      // checking this activity have pre save validation
      let isGraphic = false;
      if (preActivity.length && woincomingFileId) {
        const sql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingfileid = ${woincomingFileId}`;
        const checkImageCount = await query(sql);
        if (checkImageCount.length > 0 && checkImageCount[0].imagecount > 0) {
          isGraphic = true;
        }
      } else if (preActivity.length && !woincomingFileId) {
        const sql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingid = (select woincomingid from wms_workorder_incoming where woid = ${workorderId}) and filetypeid != 1`;
        const checkImageCount = await query(sql);
        if (checkImageCount.length) {
          checkImageCount.forEach(item => {
            if (item.imagecount > 0) {
              isGraphic = true;
            }
          });
        }
      }
      logger.info(isGraphic, 'isGraphic');
      if (isGraphic) {
        const postSaveValidRes = await preClaimValidation(req.body);
        logger.info(postSaveValidRes, 'postSaveValidRes');
      }
      //
      res.status(200).send({ message: 'Pre validation success' });
    } else {
      res.status(400).send({
        message: resultforpriority
          ? `Please complete the before file (${resultforpriority.fileName})`
          : `Please complete the before file.`,
      });
    }
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const getFileSeqByPriority = async (
  workorderId,
  wfDefId,
  stageIterationCount,
  activityIterationCount,
  wfEventId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `select * from wms_workflowdefinition where wfdefid =${wfDefId} order by sequence`;
      const filePriority = await query(sql1, []);
      logger.info(filePriority, 'file priority');
      // updated for fileconfig restructure
      const fileconfig =
        filePriority.length > 0 ? filePriority[0].fileconfig : undefined;
      if (fileconfig && fileconfig.isSquence === true) {
        let sql = `SELECT filesequence FROM public.wms_workflow_eventlog eventlog join 
            wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=eventlog.woincomingfileid where wfeventid=${wfEventId}`;
        const fileSeq = await query(sql, []);
        if (fileSeq && fileSeq.length > 0) {
          sql = `SELECT * FROM public.wms_workflow_eventlog eventlog join wms_workorder_incomingfiledetails ifd on ifd.woincomingfileid=eventlog.woincomingfileid where
                workorderid=${workorderId} and wfdefid=${wfDefId} and stageiterationcount=${stageIterationCount} and activityiterationcount=${activityIterationCount} and  activitystatus not in ('Completed' ,'Rejected','Reset')  and filesequence < ${fileSeq[0].filesequence}  order by filesequence asc`;
          console.log(sql, 'sdfsdf');
          const fileSeqPriorityDetails = await query(sql, []);
          if (!fileSeqPriorityDetails.length) {
            resolve({ data: true });
          } else {
            resolve({
              data: false,
              fileName: fileSeqPriorityDetails[0].filename,
            });
          }
        } else {
          resolve({ data: true });
        }
      } else {
        resolve({ data: true });
      }
    } catch (e) {
      logger.info(e, 'file priority');
      reject(e);
    }
  });
};

export const getGraphicValidationList = async (
  workorderId,
  wfeventId,
  woincomingFileId,
  taskType,
  fileName,
  wfId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const overGraphicList = [];
      let condition = '';
      if (taskType == 'Multiple') {
        condition = `eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0 and incomingfile.woincomingfileid = ${woincomingFileId}`;
        // condition = `eventlog.wfeventid = ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.isgraphicrequired = true and incomingfile.woincomingfileid =${woincomingFileId} `
      } else {
        condition = `eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0`;
        // condition = `eventlog.wfeventid = ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.isgraphicrequired = true`
      }
      const sql = `select  incomingfile.woincomingfileid,incomingfile.filename,incomingfile.imagecount,eventlog.wfdefid,workflow.config,incomingfile.woincomingfileid from wms_workorder_incoming as incoming
                    join wms_workorder_incomingfiledetails as incomingfile on incomingfile.woincomingid =incoming.woincomingid
                    join  wms_workflow_eventlog as eventlog on eventlog.workorderid = incoming.woid
                    join wms_workflowdefinition as workflow on workflow.wfdefid = eventlog.wfdefid
                    ${condition ? `where ${condition}` : ''}`;

      const sql2 = `select  incomingfile.woincomingfileid,incomingfile.filename,incomingfile.imagecount,eventlog.wfdefid,workflow.config,incomingfile.woincomingfileid from wms_workorder_incoming as incoming
                    join wms_workorder_incomingfiledetails as incomingfile on incomingfile.woincomingid =incoming.woincomingid
                    join  wms_workflow_eventlog as eventlog on eventlog.workorderid = incoming.woid
                    join wms_workflowdefinition as workflow on workflow.wfdefid = eventlog.wfdefid 
                    where eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0`;
      console.log(sql);
      const reponse2 = await query(sql2);
      console.log(reponse2, 'reponse2');
      const filteredTrueValue = [];
      await query(sql)
        .then(async data => {
          if (data && data.length > 0) {
            const graphicConfiguration =
              data[0] &&
              data[0].config &&
              data[0].config.actions &&
              data[0].config.actions.general &&
              data[0].config.actions.general.graphic
                ? data[0].config.actions.general.graphic
                : {};
            const keysLength = Object.keys(graphicConfiguration);
            for (let i = 0; i < keysLength.length; i++) {
              if (
                graphicConfiguration[keysLength[i]] &&
                keysLength[i] != 'folderName'
              ) {
                const sqlQuery = `select wf.activityalias,wf.wfdefid,wf.activitytype from 
                             wms_workflowdefinition  as wf
                                   where  wf.wfid = ${wfId} and wf.stageid = 10 and LOWER (wf.activityalias) like '${keysLength[i]}'`;
                await query(sqlQuery)
                  .then(graphicsDetailsdata => {
                    if (graphicsDetailsdata && graphicsDetailsdata.length > 0) {
                      filteredTrueValue.push({
                        key: keysLength[i],
                        value: graphicConfiguration[keysLength[i]],
                        wfdefid: data[0].wfdefid,
                        filename: data[0].filename,
                        activityType: graphicsDetailsdata[0].activitytype,
                        graphicWfDefId: graphicsDetailsdata[0].wfdefid,
                      });
                    } else {
                      filteredTrueValue.push({
                        key: keysLength[i],
                        value: graphicConfiguration[keysLength[i]],
                        wfdefid: data[0].wfdefid,
                        filename: data[0].filename,
                        activityType: 'User Task',
                      });
                    }
                  })
                  .catch(innererror => {
                    logger.info(innererror, 'innererror');
                    resolve({ message: innererror });
                  });
              }
            }
            console.log(
              graphicConfiguration,
              'graphic configuration for selected activity',
            );
            console.log(
              filteredTrueValue,
              'filteredTrueValue configuration for selected activity',
            );
            if (filteredTrueValue && filteredTrueValue.length > 0) {
              let sqlQuery = '';
              for (let j = 0; j < filteredTrueValue.length; j++) {
                const name = filteredTrueValue[j].key;
                const failedName = `${filteredTrueValue[j].key}_f`;
                if (filteredTrueValue[j].activityType == 'External Task') {
                  let condition2 = '';
                  if (taskType == 'Multiple') {
                    condition2 = `eventlog.workorderid = ${workorderId} and wf.wfid = ${wfId} and wf.stageid = 10 and eventlog.woincomingfileid =${woincomingFileId} and  (LOWER (wf.activityalias) like '${name}' or LOWER (wf.activityalias) like '${failedName}') and (eventlog.activitystatus = 'Completed')`;
                  } else {
                    condition2 = `eventlog.workorderid = ${workorderId} and wf.wfid = ${wfId} and wf.stageid = 10  and (LOWER (wf.activityalias) like '${name}' or LOWER (wf.activityalias) like '${failedName}') and (eventlog.activitystatus = 'Completed')`;
                  }
                  if (
                    filteredTrueValue &&
                    filteredTrueValue.length > 0 &&
                    Object.keys(filteredTrueValue[j]).includes(
                      'graphicWfDefId',
                    ) &&
                    filteredTrueValue[j].graphicWfDefId == '502'
                  ) {
                    for (let p = 0; p < reponse2.length; p++) {
                      const Countsql = `select * from wms_workflow_eventlog where workorderid = $1  and wfdefid =$2  and woincomingfileid=$3`;
                      const count = await query(Countsql, [
                        workorderId,
                        filteredTrueValue[j].graphicWfDefId,
                        reponse2[p].woincomingfileid,
                      ]);
                      if (count.length == 0) {
                        overGraphicList.push({ name: 'duplicate', id: '000' });
                      }
                    }
                    sqlQuery = `select eventlog.wfeventid,wf.activityalias,wf.wfdefid, eventlog.activitystatus,eventlog.woincomingfileid from wms_workflow_eventlog  as eventlog
                                                join wms_workflowdefinition as wf on eventlog.wfdefid = wf.wfdefid
                                                ${
                                                  condition2
                                                    ? `where ${condition2}`
                                                    : ''
                                                }`;
                  } else {
                    sqlQuery = `select eventlog.wfeventid,wf.activityalias,wf.wfdefid, eventlog.activitystatus,eventlog.woincomingfileid from wms_workflow_eventlog  as eventlog
                                        join wms_workflowdefinition as wf on eventlog.wfdefid = wf.wfdefid
                                        ${
                                          condition2
                                            ? `where ${condition2}`
                                            : ''
                                        }`;
                  }
                } else {
                  let condition3 = '';
                  if (taskType == 'Multiple') {
                    condition3 = `eventlog.workorderid = ${workorderId} and wf.wfid = ${wfId} and wf.stageid = 10 and eventlog.woincomingfileid =${woincomingFileId} and  LOWER (wf.activityalias) like '${name}' and (eventlog.activitystatus = 'Completed')`;
                  } else {
                    condition3 = `eventlog.workorderid = ${workorderId} and wf.wfid = ${wfId} and wf.stageid = 10  and LOWER (wf.activityalias) like '${name}' and (eventlog.activitystatus = 'Completed')`;
                  }
                  if (
                    filteredTrueValue &&
                    filteredTrueValue.length > 0 &&
                    Object.keys(filteredTrueValue[j]).includes(
                      'graphicWfDefId',
                    ) &&
                    filteredTrueValue[j].graphicWfDefId == '502'
                  ) {
                    for (let p = 0; p < reponse2.length; p++) {
                      const Countsql = `select * from wms_workflow_eventlog where workorderid = $1  and wfdefid =$2  and woincomingfileid=$3`;
                      const count = await query(Countsql, [
                        workorderId,
                        filteredTrueValue[j].graphicWfDefId,
                        reponse2[p].woincomingfileid,
                      ]);
                      if (count.length == 0) {
                        overGraphicList.push({ name: 'duplicate', id: '000' });
                      }
                    }
                    sqlQuery = `select eventlog.wfeventid,wf.activityalias,wf.wfdefid, eventlog.activitystatus,eventlog.woincomingfileid from wms_workflow_eventlog  as eventlog
                                               join wms_workflowdefinition as wf on eventlog.wfdefid = wf.wfdefid
                                               ${
                                                 condition3
                                                   ? `where ${condition3}`
                                                   : ''
                                               }`;
                  } else {
                    sqlQuery = `select eventlog.wfeventid,wf.activityalias,wf.wfdefid, eventlog.activitystatus,eventlog.woincomingfileid from wms_workflow_eventlog  as eventlog
                                    join wms_workflowdefinition as wf on eventlog.wfdefid = wf.wfdefid
                                    ${condition3 ? `where ${condition3}` : ''}`;
                  }
                }
                await query(sqlQuery)
                  .then(innerdata => {
                    console.log(innerdata, 'intter');
                    if (innerdata && innerdata.length > 0) {
                      for (let c = 0; c < innerdata.length; c++) {
                        overGraphicList.push(innerdata[c]);
                      }
                    }
                  })
                  .catch(innererror => {
                    logger.info(innererror, 'innererror');
                    resolve({ message: innererror });
                  });
              }
              if (overGraphicList.length > 0 && taskType == 'Multiple') {
                resolve({
                  data: data ? data[0] : [],
                  message: 'Graphics is not required',
                });
              } else if (
                overGraphicList.length > 0 &&
                (data.length == overGraphicList.length ||
                  overGraphicList.length > data.length) &&
                taskType == 'Single'
              ) {
                resolve({
                  data: data ? data[0] : [],
                  message: 'Graphics is not required',
                });
              } else {
                resolve({
                  data: data ? data[0] : [],
                  message: 'Graphics is required',
                });
              }
            } else {
              resolve({
                data: data ? data[0] : [],
                message: 'Graphics is not required',
              });
            }
          } else {
            resolve({
              data: data ? data[0] : [],
              message: 'Graphics is not required',
            });
          }
        })
        .catch(error => {
          logger.info(error, 'errorerrorerror');
          resolve({ message: error });
        });
    } catch (e) {
      logger.info(e, 'graphic file validarion');
      reject(e);
    }
  });
};

export const claimAction = async (req, res) => {
  try {
    const { taskInstanceId, userid, wfeventid, woType } = req.body;
    const sql = `SELECT filename FROM wms_tasklist WHERE wfeventid IN('${wfeventid}') AND userid IS NOT NULL `;
    logger.info(sql, 'sqlll');
    query(sql)
      .then(async response => {
        if (response.length) {
          logger.info(response, 'response for exits');
          let taskName = '';
          if (response.length) {
            response.forEach((task, i) => {
              taskName +=
                response.length - 1 == i ? task.filename : `${task.filename}, `;
            });
          }
          res.status(409).send({ status: 409, message: taskName });
        } else {
          try {
            logger.info(response, 'response');
            // check iTracks API call
            const isItracksAPI = await checkItracksExits(req, res, true);
            console.log(isItracksAPI, 'isItracksAPI');
            const { status } = isItracksAPI;
            if (status) {
              const isCanWork = await canWorkActivity(req.body);
              const { status: stat, iStageId, iActivityId } = isCanWork;
              console.log(stat, 'status of isCanWork');
              if (stat) {
                const isEntryExists = await openEntryExists(req.body);
                const { status: stats } = isEntryExists;
                console.log(stats, 'status of exists');
                if (!stats || stats) {
                  if (woType === 'Book') {
                    const iSubjobIds = await getSubjobIds(req.body);
                    logger.info(iSubjobIds, 'iSubjobIds');

                    if (iSubjobIds) {
                      req.body.iStageId = iStageId;
                      req.body.iActivityId = iActivityId;
                      req.body.subjobArray = iSubjobIds;
                      const entryRes = await logisticEntryInsert(req.body);
                      const { status: st } = entryRes;
                      logger.info(entryRes, 'entryRes entryRes');
                      if (st) {
                        claimCamundaTask(taskInstanceId, userid, wfeventid, req)
                          .then(async resp => {
                            emitAction(actions.wfClaimed);
                            res.send(resp);
                            // capture user event
                            const payload = {
                              userId: userid,
                              wfeventId: wfeventid,
                              actionType: 'Claim',
                            };
                            postProcess(req, payload);
                          })
                          .catch(() => {
                            res
                              .status(400)
                              .send({ message: 'Task Claim Failed' });
                          });
                      } else {
                        res.status(400).send(entryRes);
                      }
                    } else {
                      res.status(400).send({
                        status: false,
                        message: 'iTracks subjobid not found in iWMS',
                      });
                    }
                  } else {
                    console.log('inside journal logistic entry');

                    req.body.iStageId = iStageId;
                    req.body.iActivityId = iActivityId;
                    const entryRes = await logisticEntryInsertJournal(req.body);
                    const { status: st } = entryRes;
                    if (st) {
                      claimCamundaTask(taskInstanceId, userid, wfeventid, req)
                        .then(async resp => {
                          emitAction(actions.wfClaimed);
                          res.send(resp);
                          // capture user event
                          const payload = {
                            userId: userid,
                            wfeventId: wfeventid,
                            actionType: 'Claim',
                          };
                          postProcess(req, payload);
                        })
                        .catch(() => {
                          res
                            .status(400)
                            .send({ message: 'Task Claim Failed' });
                        });
                    } else {
                      res.status(400).send(entryRes);
                    }
                  }
                } else {
                  res.status(400).send(isEntryExists);
                }
              } else {
                res.status(400).send(isCanWork);
              }
            } else {
              logger.info("claimed without iTracks'");

              claimCamundaTask(taskInstanceId, userid, wfeventid, req)
                .then(async resp => {
                  emitAction(actions.wfClaimed);
                  res.send(resp);
                  // capture user event
                  const payload = {
                    userId: userid,
                    wfeventId: wfeventid,
                    actionType: 'Claim',
                  };
                  postProcess(req, payload);
                })
                .catch(e => {
                  logger.info(e, "claim from camunda error'");
                  res.status(400).send({ message: 'Task Claim Failed' });
                });
            }
          } catch (e) {
            logger.info(e, "before final error'");
            res.status(400).send({ message: e.message ? e.message : e });
          }
        }
      })
      .catch(e => {
        logger.info(e.response, 'CLAIM final error');
        res.status(400).send(e);
      });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

const claimCamundaTask = (taskInstanceId, userid, wfeventid, req) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { actualActivityCount } = req.body;
      const url = config.camnunda.uri.claimTask;
      const data = { id: taskInstanceId, userId: userid };
      logger.info('claim task dta==>', data);
      await transaction(async client => {
        let sql = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2, priority=$3 WHERE wfeventid= $4 AND taskinstanceid = $5 RETURNING wfeventid, priority`;
        const { rows } = await client.query(sql, [
          userid,
          'YTS',
          2,
          wfeventid,
          taskInstanceId,
        ]);
        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6);`;
        await client.query(sql, [
          rows[0].wfeventid,
          'YTS',
          new Date(),
          userid,
          systemInfo,
          actualActivityCount,
        ]);

        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6);`;
        await client.query(sql, [
          rows[0].wfeventid,
          'Claimed',
          new Date(),
          userid,
          systemInfo,
          actualActivityCount,
        ]);
        await service.post(`${config.camnunda.base_url}${url}`, data);
        // claim by the user directly moves to view task page so updating the yts to work in progress immediately
        sql = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE taskinstanceid = $3 RETURNING wfeventid `;
        await client.query(sql, [userid, 'Work in progress', taskInstanceId]);
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6);`;
        await client.query(sql, [
          rows[0].wfeventid,
          'Work in progress',
          new Date(),
          userid,
          systemInfo,
          actualActivityCount,
        ]);

        const response = {
          data: { priority: rows[0].priority },
          message: 'Task has been claimed successfully',
        };
        resolve(response);
      });
    } catch (e) {
      console.log(e, 'eeeee1');
      if (e?.message?.data?.data) {
        // This is used to check camunda error msg and This is wrong. need to get proper error msg from camunda layer.
        reject(e.message.data.data);
      } else {
        reject(e);
      }
    }
  });
};

export const _claimPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _claimPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const assignAction = async (req, res) => {
  const reqData = req.body;
  let id = '';
  reqData.wfEventId.forEach((data, i) => {
    id += `'${data}'${reqData.wfEventId.length - 1 !== i ? ',' : ''}`;
  });
  if (reqData.role == '2') {
    try {
      const sql = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2, priority =$3 WHERE wfeventid IN(${id}) RETURNING wfeventid`;
      query(sql, [reqData.assignee, 'YTS', reqData.priority])
        .then(resForUpdate => {
          logger.info(resForUpdate, 'resForUpdate');
          let sqlQuery = '';
          if (resForUpdate.length > 0) {
            const systemInfo = {
              systemIP: requestIp.getClientIp(req),
              publicIP:
                req.headers['x-forwarded-for'] || req.connection.remoteAddress,
              ...JSON.parse(req.headers.systemdetail),
            };
            const valuesForAssigned = [];
            const valuesForYTS = [];
            resForUpdate.forEach(list => {
              valuesForAssigned.push(
                `(${list.wfeventid},'Assigned', current_timestamp, '${
                  reqData.assignee
                }', '${JSON.stringify(systemInfo)}')`,
              );
              valuesForYTS.push(
                `(${list.wfeventid},'YTS', current_timestamp, '${
                  reqData.assignee
                }', '${JSON.stringify(systemInfo)}')`,
              );
            });

            sqlQuery = `INSERT INTO public.wms_workflow_eventlog_details(
                                wfeventid, operationtype, timestamp, userid, systeminfo)
                                VALUES ${valuesForAssigned}`;
            query(sqlQuery)
              .then(() => {
                sqlQuery = `INSERT INTO public.wms_workflow_eventlog_details(
                                wfeventid, operationtype, timestamp, userid, systeminfo)
                                VALUES ${valuesForYTS}`;
                query(sqlQuery)
                  .then(() => {
                    res.status(200).json({
                      status: 200,
                      message: 'Task has been assigned successfully',
                    });
                  })
                  .catch(e => {
                    res.status(400).send({ status: 409, message: e });
                  });
              })
              .catch(e => {
                res.status(400).send({ status: 409, message: e });
              });
          }
        })
        .catch(e => {
          res.status(400).send({ status: 409, message: e });
        });
    } catch (e) {
      logger.info(e, 'errorerror');
      res.status(400).send({ status: 400, message: e.message ? e.message : e });
    }
  } else {
    res.status(400).send({ status: 400, message: 'Unauthorized user' });
  }
};

export const updatePriority = async (req, res) => {
  const reqData = req.body;
  if (reqData.role === 'Team Lead') {
    const sql = `UPDATE wms_workflow_eventlog SET priority =$1 WHERE wfeventid =$2 `;
    query(sql, [reqData.priority, reqData.wfEventId])
      .then(() => {
        res
          .status(200)
          .json({ message: 'Priority has been updated successfully' });
      })
      .catch(e => {
        res.status(400).send({ message: e });
      });
  } else {
    res.status(400).send({ message: 'Unauthorized user' });
  }
};
