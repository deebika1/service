// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { validateFiles } from './utils/validation.js';
import { config } from '../../../../config/restApi.js';
import { transaction, query } from '../../../../database/postgres.js';
import { Service } from '../../../../httpClient/index.js';
import { emitAction, actions } from '../../../activityListener/index.js';
import { getWorkflowConfig, createReportView } from '../../../common/index.js';

import {
  checkItracksExits,
  logisticEntryUpdate,
  getiTracksStageId,
  getiTracksActivityId,
  getSubjobIds,
  logisticEntryUpdateJournal,
} from '../../../iTracks/index.js';
import logger from '../../../utils/logs/index.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { postProcess, preProcess } from './index.js';

const service = new Service();
export const pendingPreProcess = async (req, res, action) => {
  const { userid, wfeventId } = req.body;
  // capture user event
  const payload = {
    userId: userid,
    wfeventId,
    actionType: 'Pending',
  };
  preProcess(req, payload);

  const response = { status: true, message: '' };
  await validateFiles(req, res, action)
    .then(() => {
      // res.send('validated pending action');
      response.status = true;
      response.message = 'Validated pending action';
    })
    .catch(e => {
      res.status(400).send(e);
    });
  res.status(200).send(response);
};

export const pendingProcess = async (req, res) => {
  // check iTracks API call
  // let isItracksAPI = await checkItracksExits(req, res, true);
  // console.log(isItracksAPI, 'isItracksAPI');
  // let { status } = isItracksAPI;
  // if (status) {
  //     let isEntryCancel = await logisticEntryDelete(req.body);
  //     let { status, Result } = isEntryCancel;
  //     console.log(isEntryCancel, 'isEntryCancel on Pending');
  //     if (status) {
  //         unClaimTask(req).then((response) => {
  //             emitAction(actions.wfUnClaimed);
  //             res.send(response);
  //         }).catch(e => {
  //             res.status(400).send(e);
  //             logger.info(e)
  //         });
  //     } else {
  //         res.status(400).send({ message: Result });
  //     }

  // } else {
  //     console.log('pending without iTracks API');
  //     unClaimTask(req).then((response) => {
  //         emitAction(actions.wfUnClaimed);
  //         res.send(response);
  //     }).catch(e => {
  //         res.status(400).send(e);
  //         logger.info(e)
  //     });
  // }

  const { userid, wfeventId, woType } = req.body;

  // check iTracks API call
  const isItracksAPI = await checkItracksExits(req, res, true);
  console.log(isItracksAPI, 'isItracksAPI');
  const { status, isProduction, isCustomer } = isItracksAPI;
  if (status) {
    const iStageId = await getiTracksStageId(req.body);
    const iActivityId = await getiTracksActivityId(req.body);
    if (woType === 'Book') {
      const iSubjobIds = await getSubjobIds(req.body);
      console.log(iSubjobIds, 'iSubjobIds');

      if (iStageId && iActivityId && iSubjobIds.length) {
        req.body.iStageId = iStageId;
        req.body.iActivityId = iActivityId;
        req.body.subjobArray = iSubjobIds;
        const isEntryUpdate = await logisticEntryUpdate(
          req.body,
          isProduction,
          isCustomer,
          1,
          'pending',
        );
        const { status: st, Result } = isEntryUpdate;
        console.log(isEntryUpdate, 'isEntryUpdate');
        if (st) {
          unClaimTask(req)
            .then(response => {
              emitAction(actions.wfUnClaimed);
              res.send(response);
              // capture user event
              const payload = {
                userId: userid,
                wfeventId,
                actionType: 'Pending',
              };
              postProcess(req, payload);
            })
            .catch(e => {
              res.status(400).send(e);
              logger.info(e);
            });
        } else {
          res.status(400).send({ message: Result });
        }
      } else {
        res.status(400).send({
          status: false,
          message: 'iTracks stageid / activityid / subjobid not fount in iWMS',
        });
      }
    } else if (iStageId && iActivityId) {
      req.body.iStageId = iStageId;
      req.body.iActivityId = iActivityId;
      const isEntryUpdate = await logisticEntryUpdateJournal(
        req.body,
        isProduction,
        isCustomer,
        1,
        'pending',
      );
      const { status: st, Result } = isEntryUpdate;
      console.log(isEntryUpdate, 'isEntryUpdate');
      if (st) {
        unClaimTask(req)
          .then(response => {
            emitAction(actions.wfUnClaimed);
            res.send(response);
            // capture user event
            const payload = {
              userId: userid,
              wfeventId,
              actionType: 'Pending',
            };
            postProcess(req, payload);
          })
          .catch(e => {
            res.status(400).send(e);
            logger.info(e);
          });
      } else {
        res.status(400).send({ message: Result });
      }
    } else {
      res.status(400).send({
        status: false,
        message: 'iTracks stageid / activityid / subjobid not fount in iWMS',
      });
    }
  } else {
    console.log('pending without iTracks API');
    unClaimTask(req)
      .then(response => {
        emitAction(actions.wfUnClaimed);
        res.send(response);
        // capture user event
        const payload = {
          userId: userid,
          wfeventId,
          actionType: 'Pending',
        };
        postProcess(req, payload);
      })
      .catch(e => {
        res.status(400).send(e);
        logger.info(e);
      });
  }
};

const unClaimTask = req => {
  const {
    du,
    wfeventId,
    userId,
    taskInstanceId,
    uomid,
    noOfPages,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
    stageId,
    wfId,
    activityCount,
    comments,
    actualActivityCount,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.camnunda.uri.unClaim;
      const data = { id: taskInstanceId, assignee: userId };

      await transaction(async client => {
        // entry for report
        let sql = `SELECT timestamp FROM wms_workflow_eventlog_details WHERE wfeventid =$1 AND userid=$2
                AND (operationtype =$3 OR operationtype =$4 OR operationtype =$5) ORDER BY wfeventdetailid DESC LIMIT 1`;
        const { rows } = await client.query(sql, [
          wfeventId,
          userId,
          'Work in progress',
          'Hold',
          'Pending',
        ]);
        logger.info(rows, 'timestamprowsrow11');
        if (rows.length > 0) {
          const payload = {
            duId: du,
            userId,
            wfeventId,
            timestamp: rows[0].timestamp,
            uomValue: noOfPages || 0,
          };
          logger.info(payload, 'req data for create view');
          await createReportView(client, payload);
        }
        // event log
        sql = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2, isfilesynced =$3, activitycount =$4 WHERE taskinstanceid = $5 RETURNING wfeventid `;
        await client.query(sql, [
          null,
          'Pending',
          false,
          parseInt(activityCount) + 1,
          taskInstanceId,
        ]);
        // event log details
        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid,uomid, uomvalue, usercomments, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9);`;
        await client.query(sql, [
          wfeventId,
          'Pending',
          new Date(),
          userId,
          uomid,
          noOfPages || 0,
          comments,
          systemInfo,
          actualActivityCount,
        ]);
        await service.post(`${config.camnunda.base_url}${url}`, data);
        // mail trigger
        const payload = {
          duId: du,
          entityId,
          workorderId,
          serviceId,
          wfdefid,
          stageName,
          iteration: iterationCount,
          stageDuedate,
          stageId,
          wfId,
        };
        const mailStatus = await getWorkflowConfig(payload, 'pending');
        logger.info(mailStatus, 'mail response');
        resolve('Task has been unclaimed successfully');
      });
    } catch (e) {
      logger.info(e.message, 'error for claim');
      logger.info(e.message.data.data, 'CLAIM');
      if (e.message.data.data) {
        // This is used to check camunda error msg and This is wrong. need to get proper error msg from camunda layer.
        logger.info(e.message.data.data, 'UNCLAIM');
        reject(e.message.data.data);
      } else {
        reject(e.message ? e.message : e);
      }
    }
  });
};

export const getUomHistory = (req, res) => {
  const { wfeventId } = req.body;
  const pendingSql = `SELECT * FROM public.wms_workflow_eventlog_details as eventlog  JOIN public.wms_user as username ON eventlog.userid=username.userid WHERE (eventlog.operationtype='Pending' or eventlog.operationtype='Hold') AND eventlog.wfeventid =${wfeventId} and eventlog.uomvalue is not null and eventlog.uomvalue is not null and eventlog.actualactivitycount = (SELECT MAX(actualactivitycount) FROM public.wms_workflow_eventlog_details where wfeventid =${wfeventId}) ORDER BY wfeventdetailid`;
  const holdAndPendingSql = `SELECT * FROM public.wms_workflow_eventlog_details as eventlog JOIN public.wms_user as username ON eventlog.userid=username.userid WHERE eventlog.operationtype in ('Pending','Hold') AND eventlog.wfeventid =${wfeventId} and eventlog.uomvalue is not null and eventlog.uomvalue is not null and eventlog.actualactivitycount = (SELECT MAX(actualactivitycount) FROM public.wms_workflow_eventlog_details where wfeventid =${wfeventId}) ORDER BY wfeventdetailid`;
  query(pendingSql)
    .then(pendingRes => {
      query(holdAndPendingSql)
        .then(pendingHoldRes => {
          res
            .status(200)
            .json({ data: pendingRes, pendingHoldData: pendingHoldRes });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const _pendingPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _pendingPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};
