import { Service } from '../../../../../httpClient/index.js';
import { config } from '../../../../../config/restApi.js';
import logger from '../../../../utils/logs/index.js';

const service = new Service();

export const completeTask = (payload, retryCount = 5) => {
  const url = config.camnunda.uri.completeTask;
  return new Promise(async (resolve, reject) => {
    try {
      if (retryCount > 0) {
        await service.post(`${config.camnunda.base_url}${url}`, payload);
        resolve();
      } else {
        reject('Server is currently busy. Please retry after some minute');
      }
    } catch (e) {
      const errMsg = e?.message?.data?.data;
      if (
        errMsg &&
        errMsg.includes('ENGINE-03005') &&
        errMsg.includes('concurrently')
      ) {
        retryCount--;
        logger.info(
          `Retrying the process in 5 sec (remaining retries - ${retryCount})`,
        );
        setTimeout(async () => {
          try {
            await completeTask(payload, retryCount);
            resolve();
          } catch (err) {
            reject(err);
          }
        }, 5000);
      } else {
        reject(errMsg);
      }
    }
  });
};
