// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
import { transaction } from '../../../../database/postgres.js';
import {
  validateFiles,
  validateToolsRunningStatus,
} from './utils/validation.js';
import { emitAction, actions } from '../../../activityListener/index.js';
import { getWorkflowConfig } from '../../../common/index.js';
import {
  checkItracksExits,
  logisticEntryDelete,
} from '../../../iTracks/index.js';
import logger from '../../../utils/logs/index.js';
import { Service } from '../../../../httpClient/index.js';
import { config } from '../../../../config/restApi.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { postProcess, preProcess } from './index.js';

const service = new Service();

export const cancelPreProcess = async (req, res, action) => {
  let response = { status: true, message: '' };
  const { userid, wfeventId, toolRunningStatus } = req.body;
  // capture user event
  const payload = {
    userId: userid,
    wfeventId,
    actionType: 'Cancel',
  };
  preProcess(req, payload);

  try {
    // checking for tools running status
    if (toolRunningStatus) {
      const result = await validateToolsRunningStatus(req);
      response = result;
    }

    await validateFiles(req, res, action)
      .then(() => {
        // res.send('validated save action points');
        response.status = true;
        response.message = 'Validated';
      })
      .catch(() => {
        res.status(400).send({ message: 'Invalid task plaese contact TL' });
      });
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const cancelProcess = async (req, res) => {
  const { userid, wfeventId } = req.body;
  // check iTracks API call
  const isItracksAPI = await checkItracksExits(req, res, true);
  console.log(isItracksAPI, 'isItracksAPI');
  const { status } = isItracksAPI;
  if (status) {
    const isEntryCancel = await logisticEntryDelete(req.body);
    const { status: stat, Result } = isEntryCancel;
    console.log(isEntryCancel, 'isEntryCancel');
    if (stat) {
      cancelTask(req)
        .then(response => {
          emitAction(actions.wfCancelled);
          res.send(response);
          // capture user event
          const payload = {
            userId: userid,
            wfeventId,
            actionType: 'Cancel',
          };
          postProcess(req, payload);
        })
        .catch(e => {
          res.status(400).send(e);
          logger.info(e);
        });
    } else {
      res.status(400).send({ message: Result });
    }
  } else {
    console.log('without entry cancel');
    cancelTask(req)
      .then(response => {
        emitAction(actions.wfCancelled);
        res.send(response);
        // capture user event
        const payload = {
          userId: userid,
          wfeventId,
          actionType: 'Cancel',
        };
        postProcess(req, payload);
      })
      .catch(e => {
        res.status(400).send(e);
        logger.info(e);
      });
  }
};

export const cancelTask = req => {
  const {
    du,
    wfeventId,
    userId,
    taskInstanceId,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
    stageId,
    wfId,
    activityCount,
    actualActivityCount,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.camnunda.uri.unClaim;
      const data = { id: taskInstanceId, assignee: userId };

      await transaction(async client => {
        // let sql = `SELECT * FROM public.wms_workflow_eventlog_details where wfeventid = ${wfeventId} and operationtype != 'Work in progress' and operationtype !='Claimed' and operationtype!='Assigned'  ORDER BY wfeventdetailid DESC limit 1`;
        // const eventResult = await client.query(sql)
        let sql;
        sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1, activitycount =$2, userid=$3 WHERE wfeventid = $4 `;
        await client.query(sql, [
          'Unassigned',
          parseInt(activityCount) + 1,
          null,
          wfeventId,
        ]);
        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6)`;
        await client.query(sql, [
          wfeventId,
          'Cancelled',
          new Date(),
          userId,
          systemInfo,
          actualActivityCount,
        ]);
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6)`;
        await client.query(sql, [
          wfeventId,
          'Unassigned',
          new Date(),
          userId,
          systemInfo,
          actualActivityCount,
        ]);

        await service.post(`${config.camnunda.base_url}${url}`, data);

        // mail trigger
        const payload = {
          duId: du,
          entityId,
          workorderId,
          serviceId,
          wfdefid,
          stageName,
          iteration: iterationCount,
          stageDuedate,
          stageId,
          wfId,
        };
        const mailStatus = await getWorkflowConfig(payload, 'cancel');
        logger.info(mailStatus, 'mail response');
        resolve('Task has been moved to previous state!');
      });
    } catch (e) {
      if (e?.message?.data?.message) {
        // This is used to checkThis is wrong. need to get proper error msg from camunda layer
        reject(e.message.data.message);
      } else {
        reject(e.message ? e.message : e);
      }
    }
  });
};

export const _cancelPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _cancelPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};
