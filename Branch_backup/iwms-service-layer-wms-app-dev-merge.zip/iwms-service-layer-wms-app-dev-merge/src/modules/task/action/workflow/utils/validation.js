import { query } from '../../../../../database/postgres.js';
import logger from '../../../../utils/logs/index.js';

export const validateFiles = (req, res, action) => {
  logger.info(action, 'actionaction');
  return new Promise((resolve, reject) => {
    const reqData = req.body;
    const sql = `SELECT 1 FROM wms_tasklist 
        WHERE userid = '${reqData.userid}' AND wfeventid = ${reqData.wfeventId}  AND baseduid = ${reqData.du} AND skillid IN(${reqData.skillid})`;
    logger.info(sql, 'validateUserTasksql12');
    query(sql)
      .then(response => {
        logger.info(response, 'response');
        if (response.length) {
          resolve('Validated');
        } else {
          reject('Invalid');
        }
      })
      .catch(() => {
        reject('Invalid');
      });
  });
};

export const validateToolsRunningStatus = req => {
  const { wfeventId } = req.body;
  return new Promise((resolve, reject) => {
    const sql = `select * from (select row_number() over(Partition by toolid order by apiid desc ) as rno,toolid,apiid,status from public.wms_tools_api 
        where wfeventid=${wfeventId}) results where rno =1 and status in ('InProgress')`;
    logger.info(sql, 'validateUserTasksql12');
    query(sql)
      .then(response => {
        if (response.length) {
          reject({
            status: false,
            message: 'Tools Running Status not yet Completed',
          });
        } else {
          // resolve({ status: true, message: 'Tools Running Status Completed' });
          const sqlQuery = `UPDATE public.wms_tools_api SET status = 'Failure', remarks = 'Latest Output has been generated for that tool'
                WHERE wfeventid = ${wfeventId} and status='InProgress'`;
          query(sqlQuery)
            .then(res => {
              if (res) {
                // resolve();
                resolve({
                  status: true,
                  message: 'Tools Running Status Completed',
                });
              }
            })
            .catch(error => {
              console.log(error);
            });
        }
      })
      .catch(error => {
        console.log(error);
      });
  });
};

export const validateOpenQuery = req => {
  const { workorderId } = req.body;
  return new Promise((resolve, reject) => {
    const sql = `select * from public.wms_workorder_query_list where  workorderid=${workorderId} and querystatus in ('Open','Re-opened')`;
    logger.info(sql, 'validateUserTasksql12');
    query(sql)
      .then(response => {
        if (response.length) {
          reject({
            status: false,
            message: 'Please resolve open queries to perform dispatch',
          });
        } else {
          resolve({ status: true, message: 'Queries not available' });
        }
      })
      .catch(error => {
        console.log(error);
      });
  });
};

export const validateUserTask = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData1111');
  const skills = [];
  reqData.skillid.forEach(item => {
    skills.push(parseInt(item));
  });
  const sql = `SELECT 1 FROM wms_tasklist 
    WHERE userid = $1 AND baseduid = $2 AND skillid IN(${skills})`;
  logger.info(sql, 'validateUserTasksql12');
  query(sql, [reqData.userid, reqData.du])
    .then(() => {
      res.status(200).send({ message: 'Success', success: true });
    })
    .catch(() => {
      res
        .status(400)
        .send({ message: 'Invalid task plaese contact TL', success: false });
    });
};

export const postSaveValidation = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, postActivity, wfId, woIncomingFileId } = req;
      const postActivityString = postActivity.join(',');
      let sql;
      sql = `select activitystatus from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid in (${postActivityString}) and woincomingfileid = ${woIncomingFileId} and activitystatus='Completed'`;
      logger.info(sql, 'post activity sql');
      const postActivityRes = await query(sql);
      if (postActivityRes.length) {
        resolve();
      } else {
        sql = `select activityalias from wms_workflowdefinition where wfid=${wfId} and wfdefid in (${postActivityString})`;
        const postActivityName = await query(sql);
        const postActivityNameString = postActivityName
          .map(item => item.activityalias)
          .join(',');
        reject(
          `Please complete the pre-activities ( ${postActivityNameString} ) to perform this action`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

export const preClaimValidation = req => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, preActivity, wfId, woIncomingFileId } = req;
      const preActivityString = preActivity.join(',');
      let sql;
      sql = `select activitystatus from wms_workflow_eventlog where workorderid=${workorderId} and wfdefid in (${preActivityString}) and woincomingfileid = ${woIncomingFileId} and activitystatus='Completed'`;
      logger.info(sql, 'post activity sql');
      const postActivityRes = await query(sql);
      if (postActivityRes.length) {
        resolve();
      } else {
        sql = `select activityalias from wms_workflowdefinition where wfid=${wfId} and wfdefid in (${preActivityString})`;
        const preActivityName = await query(sql);
        const preActivityNameString = preActivityName
          .map(item => item.activityalias)
          .join(',');
        reject(
          `Please complete the pre-activities ( ${preActivityNameString} ) to perform this action`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};
// validate ftp upload done or not
export const validateFtpUpload = (wfeventId, toolIds) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (toolIds != null && toolIds != undefined) {
        const isFtpUpload = toolIds.includes(346);
        if (isFtpUpload) {
          const sql = `select status from wms_tools_api where wfeventid=${wfeventId} and status='Success' and toolid=346 order by apiid desc`;
          const response = await query(sql);
          if (response.length > 0) {
            resolve(response);
          } else {
            reject('FTP upload not done, Please check the FTP upload status');
          }
        } else {
          resolve('FTP upload not required');
        }
      } else {
        reject(
          'Please take the new exe from iTools as part of the new build release.',
        );
      }
    } catch (e) {
      reject('FTP upload not done, Please check the FTP upload status');
    }
  });
};
