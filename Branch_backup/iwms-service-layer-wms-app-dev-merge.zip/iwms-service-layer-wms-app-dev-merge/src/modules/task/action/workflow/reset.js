import { response } from 'express';
import moment from 'moment';
import plimit from 'p-limit';
import { transaction, query } from '../../../../database/postgres.js';
import { config } from '../../../../config/restApi.js';
import { Service } from '../../../../httpClient/index.js';
import { getWorkflowConfig } from '../../../common/index.js';
import logger from '../../../utils/logs/index.js';
import { _getIncomingFileType } from '../../../utils/fileValidation/index.js';
import { ReStructureFileConfig } from '../../../utils/fileValidation/validate.js';
// import * as localHelper from '../../../utils/local/index.js';

const _plimit = plimit(1);
const service = new Service();

export const resetProcess = (req, res) => {
  resetTask(req)
    .then(resp => {
      res.send(resp);
    })
    .catch(e => {
      res.status(400).send(e);
      logger.info(e);
    });
};

export const resetTask = req => {
  const {
    userId,
    wfeventId,
    stageid,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `SELECT * FROM public.wms_workflow_eventlog where wfeventid=${wfeventId}`;
      const info = await query(sql);
      const {
        workorderid,
        serviceid,
        stageiterationcount,
        woincomingfileid,
        activityinstanceid,
      } = info[0];
      // previoustask activityid, ancestorid, processinstance id
      sql = `SELECT * FROM public.wms_previoustask where workorderid = $1 and serviceid = $2 and stageid = $3 and 
                    stageiterationcount = $4 and woincomingfileid = $5 and wfeventid < $6 ORDER BY wfeventid desc limit 1`;
      const previousTask = await query(sql, [
        workorderid,
        serviceid,
        stageid,
        stageiterationcount,
        woincomingfileid,
        wfeventId,
      ]);
      const {
        activityinstanceid: previousActivityIntanceId,
        parentinstanceid,
        processinstanceid,
        activitytype,
      } = previousTask[0];

      if (activitytype == 'User Task') {
        const previousActivityId = previousActivityIntanceId.substr(
          0,
          previousActivityIntanceId.lastIndexOf(':'),
        );
        const resetData = {
          skipCustomListeners: false,
          skipIoMappings: false,
          instructions: [
            {
              type: 'startBeforeActivity',
              ancestorActivityInstanceId: `${parentinstanceid}`,
              activityId: `${previousActivityId}`,
            },
            {
              type: 'cancel',
              activityInstanceId: `${activityinstanceid}`,
              cancelCurrentActiveActivityInstances: true,
            },
          ],
        };
        await transaction(async client => {
          let sqlQuery = `UPDATE wms_workflow_eventlog SET userid =$1, activitystatus =$2 WHERE wfeventid = $3`;
          await client.query(sqlQuery, [userId, 'Reset', wfeventId]);
          sqlQuery = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp) VALUES ($1, $2, $3);`;
          await client.query(sqlQuery, [wfeventId, 'Reset', new Date()]);
        });
        const url = config.camnunda.uri.reset;
        const resetResponse = await service.post(
          `${config.camnunda.base_url}${url}/${processinstanceid}`,
          resetData,
        );
        response.message = `Reset success for the task`;
        response.data = resetResponse.data ? resetResponse.data : resetResponse;

        // mail trigger
        const payload = {
          entityId,
          workorderId,
          serviceId,
          wfdefid,
          stageName,
          stageDuedate,
          iteration: iterationCount,
        };
        const mailStatus = await getWorkflowConfig(payload, 'reset');
        logger.info(mailStatus, 'mail response');
        resolve(response);
      } else {
        response.message = `Reset cannot be done at this task. Please contact your TL`;
        reject(response);
      }
    } catch (e) {
      response.message = `Task Reset Failed.`;
      response.data = e.message?.data.data ? e.message.data.data : e;
      logger.info(e);
      reject(response);
    }
  });
};

export const resetModification = async (req, res) => {
  const { filesArray } = req.body;
  /// /////
  try {
    logger.info(filesArray, 'filesArray');
    const incomingDetails = await _getIncomingFileType(
      filesArray[0].workorderId,
    );
    const taskFilesArray = await getTaskFilesArray(filesArray);
    logger.info(taskFilesArray, 'taskFilesArray afetr');
    const resp = [];

    for (let i = 0; i < taskFilesArray.length; i++) {
      resp.push(
        await resetCall(
          taskFilesArray,
          i,
          req.body,
          filesArray,
          incomingDetails,
        ),
      );
    }

    logger.info(resp, 'response111-response111');

    res.status(200).send({ data: resp });
  } catch (e) {
    res.status(400).send(e);
  }
};

export const getFormattedName = (
  unFormattedName,
  placeHolders,
  refOptions = {},
) => {
  const pattern = ';{{placeholder}};';
  const placeHolderkeys = Object.keys(placeHolders);
  let formattedName = unFormattedName;
  for (let i = 0; i < placeHolderkeys.length; i++) {
    const placeHolder = placeHolders[placeHolderkeys[i]]
      ? placeHolders[placeHolderkeys[i]]
      : `{{${placeHolderkeys[i]}}}`;
    if (typeof placeHolder !== 'string' && placeHolder.length > 0) {
      if (formattedName.includes(placeHolderkeys[i])) {
        refOptions.hasMultiple = true;
        refOptions.paths = [];
        placeHolder.forEach(ele => {
          refOptions.paths.push(
            formattedName.replace(
              new RegExp(
                pattern.replace(/{{placeholder}}/, placeHolderkeys[i]),
                'g',
              ),
              ele,
            ),
          );
        });
      }
    } else {
      formattedName = formattedName.replace(
        new RegExp(pattern.replace(/{{placeholder}}/, placeHolderkeys[i]), 'g'),
        placeHolder,
      );
    }
  }
  return formattedName;
};
// export const getFileDetails = async (
//   fileconfig,
//   incomingDetails,
//   placeHolders,
// ) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       console.log(fileconfig, 'fileconfig');
//       const keysLength = Object.keys(fileconfig.fileTypes);
//       const innerArray = [];
//       const innerArray1 = [];

//       for (var i = 0; i < keysLength.length > 0; i++) {
//         keyFile = keysLength[i];
//         const file = fileconfig.fileTypes[keysLength[i]];
//         if (
//           file &&
//           Object.keys(file).length > 0 &&
//           file.files &&
//           file.files.length > 0
//         ) {
//           const innerFile = file.files;
//           for (let j = 0; j < innerFile.length > 0; j++) {
//             if (
//               (innerFile[j].mandatoryCheck &&
//                 Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                 'isInputFile' in innerFile[j].mandatoryCheck) ||
//               ('isReadOnly' in innerFile[j] && innerFile[j].isReadOnly)
//             ) {
//               console.log(innerFile[j]);
//               const filteredFileNameAray = incomingDetails.filter(
//                 list => list.filetypeid == keysLength[i],
//               );
//               if (filteredFileNameAray.length > 0) {
//                 const fileTypeObj = {};
//                 if (innerFile[j].name.includes('PageRange')) {
//                   var FileTypeName = filteredFileNameAray[0].newfilename;
//                   fileTypeObj.PageRange = FileTypeName;
//                   innerFile[j].formattedName =
//                     innerFile[j].mandatoryCheck &&
//                     Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                     'isGraphicFolder' in innerFile[j].mandatoryCheck &&
//                     Object.keys(innerFile[j].mandatoryCheck.isGraphicFolder)
//                       .length > 0 &&
//                     innerFile[j].mandatoryCheck.isGraphicFolder.GraphicName
//                       ? getFormattedName(
//                           innerFile[j].mandatoryCheck.isGraphicFolder
//                             .GraphicName,
//                           fileTypeObj,
//                         )
//                       : innerFile[j].mandatoryCheck &&
//                         Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                         'isMainFolder' in innerFile[j].mandatoryCheck &&
//                         innerFile[j].mandatoryCheck.isMainFolder &&
//                         innerFile[j].mandatoryCheck.mainName
//                       ? getFormattedName(
//                           innerFile[j].mandatoryCheck.mainName,
//                           fileTypeObj,
//                         )
//                       : getFormattedName(innerFile[j].name, fileTypeObj);
//                 } else if (
//                   innerFile[j].name.includes('FileTypeName') &&
//                   !(
//                     innerFile[j].mandatoryCheck &&
//                     Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                     'isPattern' in innerFile[j].mandatoryCheck &&
//                     innerFile[j].mandatoryCheck.isPattern
//                   )
//                 ) {
//                   var FileTypeName = filteredFileNameAray[0].filename;
//                   fileTypeObj.FileTypeName = FileTypeName;
//                   innerFile[j].formattedName =
//                     innerFile[j].mandatoryCheck &&
//                     Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                     'isGraphicFolder' in innerFile[j].mandatoryCheck &&
//                     Object.keys(innerFile[j].mandatoryCheck.isGraphicFolder)
//                       .length > 0 &&
//                     innerFile[j].mandatoryCheck.isGraphicFolder.GraphicName
//                       ? getFormattedName(
//                           innerFile[j].mandatoryCheck.isGraphicFolder
//                             .GraphicName,
//                           fileTypeObj,
//                         )
//                       : innerFile[j].mandatoryCheck &&
//                         Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                         'isMainFolder' in innerFile[j].mandatoryCheck &&
//                         innerFile[j].mandatoryCheck.isMainFolder &&
//                         innerFile[j].mandatoryCheck.mainName
//                       ? getFormattedName(
//                           innerFile[j].mandatoryCheck.mainName,
//                           fileTypeObj,
//                         )
//                       : getFormattedName(innerFile[j].name, fileTypeObj);
//                 } else if (
//                   innerFile[j].name.includes('*') &&
//                   innerFile[j].mandatoryCheck &&
//                   Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                   'isPattern' in innerFile[j].mandatoryCheck &&
//                   innerFile[j].mandatoryCheck.isPattern
//                 ) {
//                   // let regExp = '[a-zA-Z0-9]+';
//                   const regExp = '[a-zA-Z0-9\\-\\_]+';
//                   let { name } = innerFile[j];
//                   if (name.includes('FileTypeName')) {
//                     var FileTypeName = filteredFileNameAray[0].filename;
//                     fileTypeObj.FileTypeName = FileTypeName;
//                     name = getFormattedName(name, fileTypeObj);
//                   }

//                   const splittedName = name.split('*');
//                   if (name.includes('*')) {
//                     let formattedFileName = name.replace('*', regExp);
//                     formattedFileName = formattedFileName.replace('/', '\\\\');
//                     const regex = new RegExp(formattedFileName, 'g');
//                     const lwfpath = this.clientUtility.pathDetails.client.path;
//                     if (isPathExist(lwfpath)) {
//                       const compath = await GetAllFiles(lwfpath);
//                       for (var i = 0; i < compath.length; i++) {
//                         const patternedName = regex.test(compath[i]);
//                         if (
//                           compath[i].includes(splittedName[0]) &&
//                           patternedName
//                         ) {
//                           innerFile[j].formattedName = basename(compath[i]);
//                         }
//                       }
//                     }
//                   }
//                 } else if (
//                   innerFile[j].mandatoryCheck &&
//                   Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                   'isMainFolder' in innerFile[j].mandatoryCheck &&
//                   innerFile[j].mandatoryCheck.isMainFolder &&
//                   innerFile[j].mandatoryCheck.mainName
//                 ) {
//                   innerFile[j].formattedName =
//                     innerFile[j].mandatoryCheck.mainName;
//                 } else if (
//                   innerFile[j].mandatoryCheck &&
//                   Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                   'isSubFolder' in innerFile[j].mandatoryCheck &&
//                   innerFile[j].mandatoryCheck.isSubFolder &&
//                   innerFile[j].mandatoryCheck.mainName
//                 ) {
//                   innerFile[j].formattedName =
//                     innerFile[j].mandatoryCheck.mainName;
//                 } else {
//                   var FileTypeName = getFormattedName(
//                     innerFile[j].name,
//                     placeHolders,
//                   );
//                   innerFile[j].formattedName = FileTypeName;
//                 }
//               }
//               if (
//                 (innerFile[j].mandatoryCheck &&
//                   Object.keys(innerFile[j].mandatoryCheck).length > 0 &&
//                   innerFile[j].mandatoryCheck.isInputFile) ||
//                 ('isReadOnly' in innerFile[j] && innerFile[j].isReadOnly)
//               ) {
//                 innerArray.push(innerFile[j]);
//                 innerArray1.push(innerFile[j].formattedName);
//               }
//             }
//           }
//         }
//       }

//       console.log(innerArray, 'innerArray');
//       const response = [...new Set(innerArray1)];
//       console.log(response, 'response');
//       resolve(response);
//     } catch (e) {
//       console.log(e, 'error in fetching file details');
//       reject(e);
//     }
//   });
// };

// const waitTime = time => {
//   return new Promise(resolve => {
//     setTimeout(() => {
//       resolve(true);
//     }, time);
//   });
// };

const resetCall = (taskFilesArray, i, data, targetDetails, incomingDetails) => {
  const { comments, userId } = data;

  const payload = {
    skipCustomListeners: false,
    skipIoMappings: false,
    instructions: [],
    annotation: comments,
  };
  return new Promise(async (resolve, reject) => {
    setTimeout(async () => {
      const resp = { data: '', message: '' };

      try {
        const {
          isselectedactivity,
          serviceid,
          stageid,
          workorderid,
          activityid,
          activityinstanceid: toActivityIntanceId,
          instancetype: cTaskType,
          wfeventid,
          stageiterationcount,
          wf_definitionid,
          eventdata,
          resettoactivityid,
          woincomingfileid,
          activitymodeltype,
          graphics,
          activityname,
          wfid,
        } = taskFilesArray[i];
        let { isParentInstanceIdCall } = taskFilesArray[i];
        let sqlForEventLog = ``;
        let sqlForEventLogDetails = ``;
        let sqlForEventLogFrom = ``;
        let sqlForEventHistory = ``;
        let variableForBatchToSingle = {};
        // let condition = '';
        // const filteredResponseDetails = [
        //   'BookDetails.xml',
        //   'BookDetails.txt',
        //   'Jobinfo.xml',
        //   'ImagePath.txt',
        //   'Imagepath.txt',
        // ];
        // filteredResponseDetails.forEach((list, i) => {
        //   condition += `${
        //     i == filteredResponseDetails.length - 1
        //       ? `repofilepath not like '%${list}%'`
        //       : `repofilepath  not like '%${list}%' AND `
        //   }`;
        // });

        // actions for graphic stage
        if (stageid == '10') {
          const variableUpdate = JSON.stringify({
            id: woincomingfileid,
            isGraphic: graphics,
          });
          console.log(variableUpdate, 'checkingwms');

          incomingDetails = `select woincomingfileid,* from wms_workorder_incoming as incoming
                join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
                where incoming.woid = ${workorderid} and filetypeid !=1 `;
          const incomingFileDetails = await query(incomingDetails);

          const files = [];
          if (taskFilesArray.length > 0) {
            taskFilesArray.forEach(ele => {
              files.push({
                id: ele.woincomingfileid,
                isGraphic: ele.isselectedactivity,
              });
            });
          }
          if (incomingFileDetails.length > 0) {
            incomingFileDetails.forEach(y => {
              if (files.filter(x => x.id == y.woincomingfileid).length == 0) {
                files.push({ id: y.woincomingfileid, isGraphic: false });
              }
            });
          }
          const stageName = `select LOWER(stagename) as stagename,stageiterationcount from wms_tasklist WHERE workorderid=${workorderid} AND serviceid=${serviceid} and (activitystatus = 'Unassigned' or activitystatus = 'YTS' or activitystatus = 'Work in progress') and stageid !=10`;
          const stageNameDetails = await query(stageName);
          const {
            stagename: stagenameForActive,
            stageiterationcount: stageiterationcountForActive,
          } = stageNameDetails.length ? stageNameDetails[0] : {};

          const stageInfo = {
            type: stagenameForActive,
            iteration: stageiterationcountForActive,
            files,
            totalChapters: files.length,
            enableListener: false,
          };

          variableForBatchToSingle = await validCamundaForms(
            activityname,
            isParentInstanceIdCall,
            stageInfo,
          );
          logger.info(variableForBatchToSingle, 'camunda variablle');
        }

        let setURL = '';
        let createInstructions = [];
        let wipActivity = [];

        // get wip activity details
        const singleCondition = `AND woincomingfileid = ${woincomingfileid}`;
        const sql = `SELECT instancetype, activityinstanceid, wfeventid, workorderid, serviceid,stageid,stageiterationcount, activityiterationcount, activityid ,wfdefid,parentinstanceid,woincomingfileid,activitymodeltype from wms_tasklist
                WHERE workorderid=${workorderid} AND serviceid=${serviceid} AND stageid=${stageid} 
                AND stageiterationcount=${stageiterationcount} ${
          cTaskType == 'Multiple' && activitymodeltype == 'S'
            ? singleCondition
            : ''
        }   AND activitystatus IN ('Unassigned','Work in progress','Reset')
                AND activityid != ${activityid} and isinstancerunning != false
                ORDER BY wfeventid DESC, activityiterationcount LIMIT 1`;
        logger.info(sql, 'sql for wip activity');
        wipActivity = await query(sql);
        logger.info(wipActivity, 'res for wip activity');
        if (wipActivity.length == 0) {
          const sql2 = `SELECT instancetype, activityinstanceid, wfeventid, workorderid, serviceid,stageid,stageiterationcount, activityiterationcount, activityid ,wfdefid,parentinstanceid,woincomingfileid,activitymodeltype,isinstancerunning from wms_tasklist
                    WHERE workorderid=${workorderid} AND serviceid=${serviceid} AND stageid=${stageid} 
                    AND stageiterationcount=${stageiterationcount} AND activitystatus IN ('Unassigned','Work in progress','Reset')
                    AND activityid != ${activityid} 
                    ORDER BY wfeventid DESC, activityiterationcount LIMIT 1`;
          logger.info(sql2, 'sql2 for wip activity');
          wipActivity = await query(sql2);
        }
        const {
          instancetype: wipTaskType,
          activityinstanceid: fromActivityIntanceId,
          parentinstanceid: fromParentInstanceId,
          wfeventid: fromWfeventId,
          activitymodeltype: fromActivityModelType,
          isinstancerunning,
        } = wipActivity.length ? wipActivity[0] : {};
        logger.info(cTaskType, 'cTaskType');

        if (isselectedactivity) {
          const url =
            config.camnundaNative.uri.externalTask.resetModification.replace(
              /{{id}}/,
              eventdata.processInstanceId,
            );
          setURL = `${config.camnundaNative.base_url}${url}`;
          // Batch - Single
          if (wipTaskType == 'Single' && cTaskType == 'Multiple') {
            if (stageid == '10') {
              if (isParentInstanceIdCall) {
                createInstructions = [
                  {
                    // "type": "startBeforeActivity",
                    type: 'startAfterActivity',
                    activityId: resettoactivityid,
                    variables: variableForBatchToSingle,
                  },
                ];
              }
              // if (isinstancerunning != false)
              if (isParentInstanceIdCall) {
                createInstructions.push({
                  type: 'cancel',
                  activityInstanceId: fromActivityIntanceId,
                  cancelCurrentActiveActivityInstances: true,
                });
              }
            } else {
              createInstructions = [
                {
                  type: 'startBeforeActivity',
                  activityId: toActivityIntanceId.split(':')[0],
                  variables: {
                    __file__: {
                      // value: variableUpdate,
                      type: 'Json',
                    },
                  },
                },
              ];
              if (isParentInstanceIdCall && isinstancerunning != false) {
                createInstructions.push({
                  type: 'cancel',
                  activityInstanceId: fromActivityIntanceId,
                  cancelCurrentActiveActivityInstances: true,
                });
              }
            }
            payload.instructions = createInstructions;
          }
          // Single - Batch
          else if (wipTaskType == 'Multiple' && cTaskType == 'Single') {
            createInstructions = [
              {
                type: 'startBeforeActivity',
                activityId: toActivityIntanceId.split(':')[0],
              },
              //  {
              //     "type": "cancel",
              //     "activityInstanceId": fromActivityIntanceId,
              //     "cancelCurrentActiveActivityInstances": true
              // }
            ];
            if (isinstancerunning != false) {
              createInstructions.push({
                type: 'cancel',
                activityInstanceId: fromActivityIntanceId,
                cancelCurrentActiveActivityInstances: true,
              });
            }
            payload.instructions = createInstructions;
          }
          // Single - single
          else if (wipTaskType == 'Multiple' && cTaskType == 'Multiple') {
            isParentInstanceIdCall = true;
            createInstructions = [
              {
                type: 'startBeforeActivity',
                ancestorActivityInstanceId: fromParentInstanceId,
                activityId: toActivityIntanceId.split(':')[0],
              },
              // {
              //     "type": "cancel",
              //     "activityInstanceId": fromActivityIntanceId,
              //     "cancelCurrentActiveActivityInstances": true
              // }
            ];
            if (isinstancerunning != false) {
              createInstructions.push({
                type: 'cancel',
                activityInstanceId: fromActivityIntanceId,
                cancelCurrentActiveActivityInstances: true,
              });
            }

            payload.instructions = createInstructions;
          }
          /// batch to batch |
          else {
            createInstructions = [
              {
                type: 'startBeforeActivity',
                activityId: toActivityIntanceId.split(':')[0],
              },
              {
                type: 'cancel',
                activityInstanceId: fromActivityIntanceId,
                cancelCurrentActiveActivityInstances: true,
              },
            ];
            payload.instructions = createInstructions;
          }
          sqlForEventLog = `UPDATE wms_workflow_eventlog SET userid='${userId}', activitystatus ='Reset' WHERE wfeventid IN (${fromWfeventId}, ${wfeventid})`;
          sqlForEventLogFrom = `UPDATE wms_workflow_eventlog SET  isinstancerunning = False WHERE wfeventid IN (${fromWfeventId})`;
          sqlForEventLogDetails = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid, usercomments, actualactivitycount)
                    (   select wfeventid ,'Reset' as operationtype,CURRENT_TIMESTAMP as timestamp,'${userId}' as userid, '${comments}' as usercomments, actualactivitycount from
                        wms_tasklist where workorderid=${workorderid} and wfeventid IN (${fromWfeventId}, ${wfeventid})
                    )`;
          sqlForEventHistory = `select distinct wfeventid from wms_workflowdefinition  JOIN wms_workflow_eventlog  as eventlog on wfeventid > ${wfeventid}  and stageid =${stageid} and wfid=${wfid} and workorderid=${workorderid}`;
        } else if (
          !(
            Object.keys(data).length > 0 &&
            targetDetails.length > 0 &&
            targetDetails[0].activityModelType.includes('P') &&
            fromActivityModelType.includes('P')
          )
        ) {
          setURL = `${config.camnundaNative.base_url}${config.camnundaNative.uri.parallelReset}`;
          payload.processDefinitionId = wf_definitionid;
          createInstructions = [
            {
              type: 'startAfterActivity',
              activityId: toActivityIntanceId.split(':')[0],
            },
          ];
          payload.processInstanceIds = [eventdata.processInstanceId];
          payload.instructions = createInstructions;
        }

        logger.info(sqlForEventLog, 'sqlForFromEventStatus');
        logger.info(sqlForEventLogDetails, 'sqlForFromEventDetailStatus');

        logger.info(setURL, 'setURLsetURLsetURLsetURL');
        logger.info(payload, 'playloadplayloadplayloadplayload111');
        logger.info('before', fromWfeventId, ':::::::', wfeventid);
        await query(sqlForEventLog);
        // await transaction(async (client) => {
        //     await client.query(sqlForEventLog);
        //     await client.query(sqlForEventLogFrom);
        //     await client.query(sqlForEventLogDetails);
        // });
        // to be handled
        // camunda call
        if (
          payload &&
          Object.keys(payload).length > 0 &&
          payload.instructions &&
          payload.instructions.length > 0
        ) {
          const resetResponse = await service.post(setURL, payload);
          logger.info(resetResponse);
          if (
            resetResponse.statusCode == 200 ||
            resetResponse.statusCode == 204
          ) {
            resp.data = resetResponse.data ? resetResponse.data : resetResponse;
            logger.info(resetResponse, 'resetResponseresetResponse');
            resp.message = `Reset success for the task`;
            // await query(sqlForEventLog);
            await query(sqlForEventLogFrom);
            await query(sqlForEventLogDetails);
            const eventResp = await query(sqlForEventHistory);
            if (eventResp && eventResp.length > 0) {
              // for (let m = 0; m < eventResp.length; m++) {
              //   await deleteFileTransactionHistory(eventResp[m]);
              // }
            }
          } else {
            reject(`Task Reset Failed.`);
          }
        }
        // delete the file transaction history after reset
        if (stageid != '10') {
          // await deleteFileTransactionHistory(wfeventid);
        }

        logger.info('After', fromWfeventId, ':::::::', wfeventid);

        if (isParentInstanceIdCall && sqlForEventLog) {
          // to be handled
          // if (false) {
          //   // have to cancel other parllel instance
          //   if (
          //     wipActivity &&
          //     wipActivity.length > 0 &&
          //     targetDetails &&
          //     targetDetails.length > 0 &&
          //     targetDetails[0].activityModelType == 'S'
          //   ) {
          //     var resetResponse = [];
          //     // gateway instance
          //     const result = await gateWayInstanceCall(eventdata);
          //     // parrlel activity instance outside
          //     const sql1 = `select * from wms_workflow_eventlog as eventlog
          //       join wms_workflowdefinition as wfdef on wfdef.wfdefid = eventlog.wfdefid
          //       where eventlog.workorderid = ${workorderid} and eventlog.activitystatus IN ('Unassigned','YTS','Work in progress') and wfdef.activitymodeltype != 'S' and eventlog.wfeventid != ${wipActivity[0].wfeventid}`;
          //     const parllelActivityDetails = await query(sql1);
          //     if (parllelActivityDetails && parllelActivityDetails.length > 0) {
          //       logger.info(
          //         parllelActivityDetails,
          //         'parllelActivityDetails for parllel gate way',
          //       );
          //       var resultCancel = await loopforparallelActivityCancel(
          //         parllelActivityDetails,
          //       );
          //       if (resultCancel) {
          //         response.data =
          //           resetResponse &&
          //           resetResponse.length > 0 &&
          //           resetResponse.data
          //             ? resetResponse.data
          //             : resetResponse;
          //       }
          //     } else {
          //       response.data =
          //         resetResponse &&
          //         resetResponse.length > 0 &&
          //         resetResponse.data
          //           ? resetResponse.data
          //           : resetResponse;
          //     }
          //   }
          //   // inside parallel gateway instance kill
          //   else if (
          //     wipActivity &&
          //     wipActivity.length > 0 &&
          //     wipActivity[0].instancetype == 'Multiple' &&
          //     targetDetails &&
          //     targetDetails.length > 0 &&
          //     targetDetails[0].activityModelType.includes('P')
          //   ) {
          //     const sql2 = `select * from wms_workflow_eventlog as eventlog
          //           join wms_workflowdefinition as wfdef on wfdef.wfdefid = eventlog.wfdefid
          //           where eventlog.workorderid = ${workorderid} and eventlog.activitystatus IN ('Unassigned','YTS','Work in progress') and eventlog.wfeventid != ${wipActivity[0].wfeventid} and eventlog.wfdefid = ${wipActivity[0].wfdefid}`;
          //     const singleinstanceActivityDetails = await query(sql2);
          //     logger.info(sql2, 'sql2 non parllel gate way');
          //     logger.info(
          //       singleinstanceActivityDetails,
          //       'singleinstanceActivityDetails for non parllel gate way',
          //     );
          //     if (
          //       singleinstanceActivityDetails &&
          //       singleinstanceActivityDetails.length > 0
          //     ) {
          //       var resultCancel = await loopforparallelActivityCancel(
          //         singleinstanceActivityDetails,
          //       );
          //       if (resultCancel) {
          //         response.data =
          //           resetResponse &&
          //           resetResponse.length > 0 &&
          //           resetResponse.data
          //             ? resetResponse.data
          //             : resetResponse;
          //       }
          //     } else {
          //       response.data =
          //         resetResponse &&
          //         resetResponse.length > 0 &&
          //         resetResponse.data
          //           ? resetResponse.data
          //           : resetResponse;
          //     }
          //   } else {
          //     response.data =
          //       resetResponse && resetResponse.length > 0 && resetResponse.data
          //         ? resetResponse.data
          //         : resetResponse;
          //   }
          // }
        }

        // to be deleted
        // getFileDetails(fileconfig,incomingDetails)
        resolve(resp);
      } catch (e) {
        logger.info(e, 'errrrrorrrr');
        resp.message = `Task Reset Failed`;
        resp.data = 'message' in e ? e.message.data : e;
        reject(resp);
      }
    }, 2000 * i);
  });
};

export const validCamundaForms = async (
  activityName,
  isParentInstanceIdCall,
  stageInfo,
) => {
  const variables = {};
  if (isParentInstanceIdCall) {
    variables.__isReset__ = getCamundaVariable('boolean', true);
    variables.__ActivityName__ = getCamundaVariable('string', activityName);
    variables.__stageInfo__ = {
      value: JSON.stringify(stageInfo),
      type: 'Json',
    };
  }
  console.log(variables, 'variables');
  return variables;
};

export const getCamundaVariable = (type, value) => {
  console.log(type, value, 'camunnddaa varale');
  switch (type) {
    case 'string':
    case 'enum':
      return { type: 'String', value };
    case 'long':
      return { type: 'Long', value: Number(value) };
    case 'boolean':
      return { type: 'Boolean', value };
    case 'date':
      return {
        type: 'Date',
        value: moment(value).format('YYYY-MM-DDTHH:mm:ss.SSSZZ'),
      };
    default:
      return {};
  }
};

export const gateWayInstanceCall = async eventdata => {
  return new Promise(async (resolve, reject) => {
    try {
      const gateWayArray = [];
      const activityInstanceDetails =
        config.camnundaNative.uri.activieInstance.replace(
          /{{id}}/,
          eventdata.processInstanceId,
        );
      const activityInstanceDetailsUrl = `${config.camnundaNative.base_url}${activityInstanceDetails}`;
      const activityInstanceDetailsResponse = await service.get(
        activityInstanceDetailsUrl,
      );
      logger.info(
        activityInstanceDetailsResponse,
        'activityInstanceDetailsResponse',
      );
      if (
        activityInstanceDetailsResponse &&
        Object.keys(activityInstanceDetailsResponse).length > 0 &&
        activityInstanceDetailsResponse.data &&
        'childActivityInstances' in activityInstanceDetailsResponse.data &&
        activityInstanceDetailsResponse.data.childActivityInstances.length > 0
      ) {
        const activityDetailsInstance =
          activityInstanceDetailsResponse.data.childActivityInstances;
        for (let k = 0; k < activityDetailsInstance.length; k++) {
          if (
            Object.keys(activityDetailsInstance[k]).length > 0 &&
            'childActivityInstances' in activityDetailsInstance[k] &&
            activityDetailsInstance[k].childActivityInstances.length > 0
          ) {
            const inneractivityDetailsInstance =
              activityDetailsInstance[k].childActivityInstances;
            for (let h = 0; h < inneractivityDetailsInstance.length; h++) {
              if (
                'activityType' in inneractivityDetailsInstance[h] &&
                inneractivityDetailsInstance[h].activityType ==
                  'parallelGateway'
              ) {
                gateWayArray.push(inneractivityDetailsInstance[h].id);
              }
            }
          }
        }
      }
      logger.info(gateWayArray, 'gateWayArray');
      if (gateWayArray && gateWayArray.length > 0) {
        await loopforparallelGateWayCancel(gateWayArray, eventdata);
      }
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
export const loopforparallelActivityCancel = async parllelActivityDetails => {
  return new Promise(async (resolve, reject) => {
    try {
      const awaits = [];
      logger.info(parllelActivityDetails, 'parllelActivityDetails');
      for (let j = 0; j < parllelActivityDetails.length; j++) {
        const { activityinstanceid: toActivityIntanceId, eventdata } =
          parllelActivityDetails[j];
        const payloadCancel = {
          skipCustomListeners: false,
          skipIoMappings: false,
          instructions: [],
          annotation: 'cancel',
        };
        const createInstructions1 = [
          {
            type: 'cancel',
            // "activityId": toActivityIntanceId.split(':')[0],
            activityInstanceId: `${toActivityIntanceId}`,
            cancelCurrentActiveActivityInstances: true,
          },
        ];
        payloadCancel.instructions = createInstructions1;
        const url1 =
          config.camnundaNative.uri.externalTask.resetModification.replace(
            /{{id}}/,
            eventdata.processInstanceId,
          );
        const setURL1 = `${config.camnundaNative.base_url}${url1}`;
        logger.info(payloadCancel, 'payloadCancel');
        logger.info(setURL1, 'setURL1');
        //    var resetResponse1= await service.post(setURL1, payloadCancel);
        //    logger.info(resetResponse1,"resetResponse1")
        //    if(resetResponse1 && resetResponse1.length>0)
        //    {updateEventlog(wfeventid, userId, comments)}
        // }

        awaits.push(
          _plimit(() =>
            service
              .post(setURL1, payloadCancel)
              .then(resetResponse1 => {
                console.log(resetResponse1, 'sfsdfsa');
                // need to be confirm
                // updateEventlog(wfeventid, userId, comments)
              })
              .catch(err => {
                console.log(err, 'err');
                throw err;
              }),
          ),
        );
      }
      await Promise.all(awaits);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

export const loopforparallelGateWayCancel = async (
  gateWayDetails,
  eventdata,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let j = 0; j < gateWayDetails.length; j++) {
        const payloadGateWayCancel = {
          skipCustomListeners: false,
          skipIoMappings: false,
          instructions: [],
          annotation: 'cancel',
        };
        const createInstructions1 = [
          {
            type: 'cancel',
            activityId: gateWayDetails[j].split(':')[0],
            cancelCurrentActiveActivityInstances: true,
          },
        ];
        payloadGateWayCancel.instructions = createInstructions1;
        const gateWayUrl1 =
          config.camnundaNative.uri.externalTask.resetModification.replace(
            /{{id}}/,
            eventdata.processInstanceId,
          );
        const setURL2 = `${config.camnundaNative.base_url}${gateWayUrl1}`;
        logger.info(payloadGateWayCancel, 'payloadGateWayCancel');
        logger.info(setURL2, 'setURL2');
        const resetResponse2 = await service.post(
          setURL2,
          payloadGateWayCancel,
        );
        console.log(resetResponse2, 'sfsdfsa');
        if (gateWayDetails.length - 1 == j) {
          resolve(true);
        }
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Update event log

export const updateEventlog = async (wfeventid, userId, comments) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `UPDATE public.wms_workflow_eventlog SET activitystatus = $1 WHERE wfeventid = $2 `;
      await query(sql, ['Reset', wfeventid])
        .then(async () => {
          const sql2 = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp,userid, usercomments) VALUES ($1, $2, $3,$4,$5)`;
          await query(sql2, [wfeventid, 'Reset', new Date(), userId, comments])
            .then(() => {})
            .catch(e => {
              reject(e);
            });
        })
        .catch(e => {
          reject(e);
        });
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
export const getTaskFilesArray = selectedFilesArray => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        serviceId,
        stageId,
        workorderId,
        activityModelType,
        stageIterationCount,
        activityModelTypeFlow,
        activityId,
        activityIterationCount,
        instanceType,
      } = selectedFilesArray[0];
      let getFilteredArray = [];
      let wfEventIdArray = [];
      // single without parllel
      if (instanceType == 'Multiple' && activityModelType == 'S') {
        wfEventIdArray = [];
        selectedFilesArray.forEach(list => {
          wfEventIdArray.push(list.wfeventId);
        });
        const wfEventIdArray1 = wfEventIdArray.join(',');
        const condition =
          wfEventIdArray && wfEventIdArray.length > 0
            ? `AND wfeventid in (${wfEventIdArray1})`
            : '';
        const sql = `SELECT *, true as isselectedactivity,case when imagecount > 0 then true else false end as graphics
                from wms_tasklist
                WHERE workorderid=${workorderId} AND serviceid=${serviceId} AND stageid=${stageId}
                AND stageiterationcount=${stageIterationCount}
                AND activityid=${activityId} ${condition || ''}`;
        logger.info(sql, 'sql for to activities');
        getFilteredArray = await query(sql);
        // updated for fileconfig restructure
        getFilteredArray.forEach((item, i) => {
          item.isParentInstanceIdCall = false;
          item.fileconfig = ReStructureFileConfig(item.fileconfig);
          if (getFilteredArray.length - 1 == i) {
            item.isParentInstanceIdCall = true;
          }
        });
        logger.info(
          getFilteredArray,
          'getFilteredArray single without paralle',
        );
      }
      // parllel
      else if (activityModelType != 'S') {
        wfEventIdArray = [];
        selectedFilesArray.forEach(list => {
          wfEventIdArray.push(list.wfeventId);
        });
        const wfEventIdArray1 = wfEventIdArray.join(',');
        const condition =
          wfEventIdArray && wfEventIdArray.length > 0
            ? `AND wfeventid in (${wfEventIdArray1})`
            : '';
        let sql = `SELECT *, true as isselectedactivity,case when imagecount > 0 then true else false end as graphics
                from wms_tasklist
                WHERE workorderid=${workorderId} AND serviceid=${serviceId} AND stageid=${stageId}
                AND stageiterationcount=${stageIterationCount} 
                AND activityid=${activityId} ${condition || ''}`;

        logger.info(sql, 'sql');
        const getSelectedActivity = await query(sql);
        // updated for fileconfig restructure
        getSelectedActivity.forEach((item, i) => {
          item.fileconfig = ReStructureFileConfig(item.fileconfig);
          item.isselectedactivity = true;
          item.isParentInstanceIdCall = false;
          if (getSelectedActivity.length - 1 == i) {
            item.isParentInstanceIdCall = true;
          }
        });

        logger.info(getSelectedActivity, 'getSelectedActivity parallel');

        sql = `SELECT DISTINCT ON (activityid, sequence) *, false as isselectedactivity,case when imagecount > 0 then true else false end as graphics
                from wms_tasklist
                WHERE workorderid=${workorderId} AND serviceid=${serviceId} AND stageid=${stageId}
                AND activitymodeltype IN ('${activityModelType}') AND activitymodeltypeflow NOT IN ('${activityModelTypeFlow}')
                ORDER BY sequence DESC LIMIT 1`;
        logger.info(sql, 'sql for getOtherActivitiy');
        const getOtherActivitiy = await query(sql);
        logger.info(getOtherActivitiy, 'getOtherActivitiy');
        // updated for fileconfig restructure
        for (const iterator of getOtherActivitiy) {
          iterator.fileconfig = ReStructureFileConfig(iterator.fileconfig);
        }
        getFilteredArray = [].concat(getSelectedActivity, getOtherActivitiy);

        logger.info(getFilteredArray, 'getFilteredArray');
      } else {
        const sql = `
                SELECT *, true as isselectedactivity,case when imagecount > 0 then true else false end as graphics
                from wms_tasklist
                WHERE workorderid=${workorderId} AND serviceid=${serviceId} AND stageid=${stageId}
                AND stageiterationcount=${stageIterationCount} AND activityiterationcount=${activityIterationCount} 
                AND activityid=${activityId}`;
        logger.info(sql, 'sql for to activities');
        getFilteredArray = await query(sql);
        // updated for fileconfig restructure
        getFilteredArray.forEach(item => {
          item.fileconfig = ReStructureFileConfig(item.fileconfig);
          item.isParentInstanceIdCall = true;
        });
        logger.info(getFilteredArray, 'getFilteredArray other else');
      }
      resolve(getFilteredArray.length ? getFilteredArray : []);
    } catch (e) {
      logger.info(e);
      reject(e);
    }
  });
};

// check for all activities are completed against a file
export const checkAllTaskCompletionReset = async (req, res) => {
  const { woIncomingFileId, woDetails } = req.body;
  try {
    let returnValue = true;
    if (woIncomingFileId) {
      const sql1 = `SELECT instancetype, activityinstanceid, wfeventid, workorderid, serviceid,stageid,stageiterationcount, activityiterationcount, activityid ,wfdefid,parentinstanceid,woincomingfileid,activitymodeltype,isinstancerunning from wms_tasklist
            WHERE workorderid=${woDetails.workorderid} AND serviceid=${woDetails.serviceid} AND stageid=${woDetails.stageid} 
            AND stageiterationcount=${woDetails.stageiterationcount} AND activitystatus IN ('Unassigned','Work in progress')
            AND activityid != ${woDetails.activityid} 
            ORDER BY wfeventid DESC, activityiterationcount LIMIT 1`;
      const response1 = await query(sql1);

      if (response1.length > 0 && response1.instancetype == 'Multiple') {
        const sql = `select activitystatus from public.wms_workflow_eventlog where woincomingfileid= ${woIncomingFileId} and activitystatus in ('Unassigned')`;
        const resp = await query(sql);
        returnValue = !!resp.length;
      }
    }
    logger.info(returnValue, 'returnValue');
    res.status(200).send(returnValue);
  } catch (e) {
    res.status(400).send(e);
  }
};

// detele the file transaction history after reset
export const deleteFileTransactionHistory = wfeventId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sqlGetfiles = `SELECT repofilepath FROM wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfeventId}`;
      const sqlDelete = `DELETE FROM wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfeventId}`;
      await query(sqlGetfiles);
      await query(sqlDelete);
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};

// export const moveFilesReset = (filePath) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const datetime = new Date();
//       const currDate = datetime.toISOString();
//       let destPath = path.join(filePath.split('article_4').shift(), currDate);
//       let filename = basename(filePath);
//           copyData = await localHelper._localcopyFile({
//             srcPath: filePath,
//             destBasePath: destPath,
//             filename,
//           });
//           tempArr.push(copyData);
//       resolve()
//     } catch (err) {
//       reject()
//     }
//   })
// }
