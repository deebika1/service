/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
import * as requestIp from 'request-ip';
// import moment from 'moment';
import { transaction, query } from '../../../../database/postgres.js';
import {
  validateFiles,
  validateToolsRunningStatus,
  validateOpenQuery,
  postSaveValidation,
  validateFtpUpload,
} from './utils/validation.js';
import { postProcess, preProcess } from './index.js';
import { emitAction, actions } from '../../../activityListener/index.js';
import {
  getRejectedVariables,
  getBWStageVariables,
} from '../../../utils/wfTrigger/variables.js';
import { completeTask } from './utils/completeTask.js';
import {
  getWorkflowConfig,
  pkgDepositTrigger,
  createReportView,
} from '../../../common/index.js';
import {
  checkItracksExits,
  logisticEntryUpdate,
  getiTracksStageId,
  getiTracksActivityId,
  getSubjobIds,
  logisticEntryUpdateJournal,
  taskDespatch,
  taskDespatchJournal,
  getiTracksDuId,
  getiTracksCustomerId,
} from '../../../iTracks/index.js';
import logger from '../../../utils/logs/index.js';
import { ActConfigDetails } from '../../../configuration/index.js';
import { getdmsType } from '../../../bpmn/listener/create.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { _triggerWOStageWf } from '../../../woi/stage.js';

export const savePreProcess = async (req, res, action) => {
  let response = { status: true, message: '' };
  const {
    toolRunningStatus,
    activityName,
    userId,
    wfeventId,
    postActivity,
    filesInfo,
    woIncomingFileId,
    workorderId,
    toolIds,
  } = req.body;
  // capture user event
  const payload = {
    userId,
    wfeventId,
    actionType: 'Save',
  };
  preProcess(req, payload);
  try {
    // checking this activity have post save validation
    let isGraphic = false;
    if (postActivity.length && woIncomingFileId) {
      const sql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingfileid = ${woIncomingFileId}`;
      const checkImageCount = await query(sql);
      if (checkImageCount.length > 0 && checkImageCount[0].imagecount > 0) {
        isGraphic = true;
      }
    } else if (postActivity.length && !woIncomingFileId) {
      const sql = `select filename,imagecount from wms_workorder_incomingfiledetails where woincomingid = (select woincomingid from wms_workorder_incoming where woid = ${workorderId}) and filetypeid != 1`;
      const checkImageCount = await query(sql);
      if (checkImageCount.length) {
        checkImageCount.forEach(item => {
          if (item.imagecount > 0) {
            isGraphic = true;
          }
        });
      }
    }
    logger.info(isGraphic, 'isGraphic');

    if (isGraphic) {
      const postSaveValidRes = await postSaveValidation(req.body);
      logger.info(postSaveValidRes, 'postSaveValidRes');
    }
    // checking for tools running status
    if (toolRunningStatus) {
      const result = await validateToolsRunningStatus(req);
      response = result;
    }
    // Checking open quaries
    if (activityName == 'Despatch') {
      const result = await validateOpenQuery(req, res);
      response = result;
    }

    await validateFiles(req, res, action);
    res.status(200).send(response);
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const _savePreProcess = async (req, payload) => {
  await _captureUserEvent(req, payload);
};
export const _savePostProcess = async (req, payload) => {
  await _captureUserEvent(req, payload);
};

export const saveProcess = async (req, res) => {
  const {
    userid,
    wfeventId,
    workorderId,
    woType,
    duId,
    // eslint-disable-next-line no-unused-vars
    customerId,
    wfId,
    activityId,
    stageId,
    filesInfo,
    camundaVariable,
    toolIds,
  } = req.body;
  try {
    req.body.actionType = 'Save';
    // FTP upload check
    await validateFtpUpload(wfeventId, toolIds);
    req.body.dmsType = await getdmsType(workorderId);
    const isItracksAPI = await checkItracksExits(req, res, true);
    console.log(isItracksAPI, 'isItracksAPI');
    req.body.isEngineReassign = camundaVariable?.__isEnableEngine__?.value;

    if (activityId === '22' && stageId === '5' && duId === '5') {
      const pkgFileInfo = filesInfo
        .pop()
        .files.filter(fname => fname.path.includes('.zip'));
      const wfdata = {
        body: {
          workflowID: wfId,
          stageID: stageId,
          activityID: activityId,
        },
      };
      const wfDefInfo = await ActConfigDetails(wfdata);
      const wfDefconfigInfo = wfDefInfo.data[0];
      console.log(wfDefconfigInfo, 'wfDefconfigInfo');
      //  if(activityId === '22' && stageId === '5' && duId === '5'){
      if (
        pkgFileInfo.length > 0 &&
        wfDefconfigInfo.config &&
        wfDefconfigInfo.config.isApiDespatch
      ) {
        const sendPkgtoApi = await pkgDepositTrigger(pkgFileInfo[0], req.body);
        console.log(sendPkgtoApi, 'sendPkgtoApi');
      }
    }
    // eslint-disable-next-line prefer-const
    let { status, isProduction, isCustomer } = isItracksAPI;
    if (status) {
      const iStageId = await getiTracksStageId(req.body);
      const iActivityId = await getiTracksActivityId(req.body);

      if (woType === 'Book') {
        const iSubjobIds = await getSubjobIds(req.body);
        console.log(iSubjobIds, 'iSubjobIds');

        if (iStageId && iActivityId && iSubjobIds.length) {
          req.body.iStageId = iStageId;
          req.body.iActivityId = iActivityId;
          req.body.subjobArray = iSubjobIds;
          const isEntryUpdate = await logisticEntryUpdate(
            req.body,
            isProduction,
            isCustomer,
            1,
            'save',
          );
          const { status: stat, Result } = isEntryUpdate;
          console.log(isEntryUpdate, 'isEntryUpdate');
          console.log(stat, 'status');
          console.log(Result, 'Result');
          // if (stat) {
          completeCamundaTask(req, res)
            .then(response => {
              emitAction(actions.wfSaved);
              res.status(200).send({ message: response });
              // capture user event
              const payload = {
                userId: userid,
                wfeventId,
                actionType: 'Save',
              };
              postProcess(req, payload);
            })
            .catch(e => {
              res.status(400).send({ message: e });
            });
          // } else {
          //   res.status(400).send({ message: Result });
          // }
        } else {
          res.status(400).send({
            status: false,
            message:
              'iTracks stageid / activityid / subjobid not fount in iWMS',
          });
        }
      } else {
        console.log('inside journal logistic update');

        if (iStageId && iActivityId) {
          req.body.iStageId = iStageId;
          req.body.iActivityId = iActivityId;
          const isEntryUpdate = await logisticEntryUpdateJournal(
            req.body,
            isProduction,
            isCustomer,
            1,
            'save',
          );
          const { status: stat, Result } = isEntryUpdate;
          console.log(isEntryUpdate, 'isEntryUpdate');
          if (stat) {
            completeCamundaTask(req, res)
              .then(response => {
                emitAction(actions.wfSaved);
                res.status(200).send({ message: response });
                // capture user event
                const payload = {
                  userId: userid,
                  wfeventId,
                  actionType: 'Save',
                };
                postProcess(req, payload);
              })
              .catch(e => {
                res.status(400).send({ message: e });
              });
          } else {
            res.status(400).send({ message: Result });
          }
        } else {
          res.status(400).send({
            status: false,
            message: 'iTracks stageid / activityid not fount in iWMS',
          });
        }
      }
    } else {
      if (req.body.isEngineReassign) {
        logger.info('iTracksDistapchCall not triggered - engine reassign');
      } else {
        const isTrigger = await iTracksDistapchCall(req, res);
        logger.info(isTrigger, 'iTracksDistapchCall');
      }
      completeCamundaTask(req, res)
        .then(response => {
          emitAction(actions.wfSaved);
          res.status(200).send({ message: response, iTracksSuccess: false });
          // capture user event
          const payload = {
            userId: userid,
            wfeventId,
            actionType: 'Save',
          };
          postProcess(req, payload);
        })
        .catch(e => {
          res.status(400).send({ message: e, iTracksSuccess: false });
        });
    }
  } catch (e) {
    logger.info(e, 'inside the main catch');
    res.status(400).send({ message: e });
  }
};

export const reassignTaskComplete = async (req, res) => {
  await completeCamundaTask(req, res)
    .then(() => {
      res.status(200).send(true);
    })
    .catch(e => {
      res.status(400).send(e.message ? e.message : e);
    });
};
const completeCamundaTask = (req, res) => {
  const {
    du,
    wfeventId,
    userId,
    taskInstanceId,
    uomId,
    noOfPages,
    isRejectHandlingTask,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
    stageId,
    wfId,
    activityAlias,
    checklist,
    camundaVariable,
    taskType,
    incomingFileId,
    isNewFileTrigger,
    actualActivityCount,
    actionType,
    isEngineReassign,
    customerId,
    activityId,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      // let isNewFileTrigger = (wfId == '18' && stageId == '1' && activityId == '1') ? true : false;
      let stage = {};
      const files = [];
      console.log(isNewFileTrigger, 'isNewFileTrigger');
      let oldArrayFiles = [];
      if (isNewFileTrigger) {
        stage = {
          type: stageName.toLowerCase().replace(/ /g, '_'),
          iteration: iterationCount,
        };
        const sql = `SELECT woincomingfileid,filename,pp_mst_filetype.filetype,allowsubfiletype FROM public.wms_workorder_incoming 
                JOIN public.wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
                JOIN public.pp_mst_filetype ON pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
                WHERE wms_workorder_incoming.woid = ${workorderId}`;
        const getFiles = await query(sql);
        getFiles.forEach(item => {
          if (item.allowsubfiletype) {
            files.push({
              id: item.woincomingfileid,
              name: item.filename,
              type: item.filetype,
            });
          }
        });
      }
      const sql1 = `SELECT * FROM public.wms_workflow_eventlog where workorderid = ${workorderId} and wfdefid=778`;
      oldArrayFiles = await query(sql1);

      camundaVariable.__isEnableForFirstIteration__ = {
        value: !(oldArrayFiles.length > 0),
        type: 'Boolean',
      };
      const payload = {
        taskId: `${taskInstanceId}`,
        variables: isRejectHandlingTask
          ? { ...camundaVariable, ...getRejectedVariables(false) }
          : isNewFileTrigger
          ? { ...camundaVariable, ...getBWStageVariables(stage, files) }
          : camundaVariable,
      };

      console.log(payload, 'payload payload');
      await transaction(async client => {
        const tempObj = {
          checklist: checklist.length ? checklist[0].instructions : [],
        };
        console.log(JSON.stringify(tempObj), 'dfdfd');
        let sql = `UPDATE wms_workflow_eventlog SET userid=coalesce($4, userid), activitystatus =$1,checklist=$3 WHERE wfeventid = $2 `;
        await client.query(sql, [
          'Completed',
          wfeventId,
          `${JSON.stringify(tempObj)}`,
          userId,
        ]);
        // entry for report
        sql = `SELECT timestamp FROM wms_workflow_eventlog_details WHERE wfeventid =$1 AND userid=$2
                AND (operationtype =$3 OR operationtype =$4 OR operationtype =$5) ORDER BY wfeventdetailid DESC LIMIT 1`;
        const { rows } = await client.query(sql, [
          wfeventId,
          userId,
          'Work in progress',
          'Hold',
          'Pending',
        ]);
        logger.info(rows, 'timestamprowsrow11');
        if (rows.length > 0) {
          const data = {
            duId: du,
            userId,
            wfeventId,
            timestamp: rows[0].timestamp,
            uomValue: noOfPages,
            activityAlias,
          };
          logger.info(data, 'req data for create view');
          await createReportView(client, data);
        }

        if (taskType === 'Multiple') {
          if (incomingFileId) {
            sql = `UPDATE wms_workorder_incomingfiledetails set uomvalue= ${noOfPages} WHERE woincomingfileid IN (${incomingFileId})`;
            console.log(sql, 'sql for uom update');
            await client.query(sql);
          }
        } else if (noOfPages) {
          sql = `UPDATE wms_workorder set uom= ${noOfPages} WHERE workorderid = ${workorderId}`;
          console.log(sql, 'sql for uom update on WO');
          await client.query(sql);
        }
        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid,uomid,uomvalue, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`;
        await client.query(sql, [
          wfeventId,
          'Completed',
          new Date(),
          userId,
          uomId,
          noOfPages,
          systemInfo,
          actualActivityCount,
        ]);
      });
      await completeTask(payload);
      const triggerRes = await triggerMailAndNextStage(
        req,
        res,
        actionType,
        isEngineReassign,
      );
      let msg = 'Task has been completed successfully';
      if (!triggerRes) {
        logger.info('Mail / next stage trigger failed', workorderId);
        msg =
          'Task has been completed successfully, but mail / next stage trigger failed, Please contact admin';
      }
      resolve(msg);
    } catch (e) {
      logger.info(e, 'error for save');
      if (e?.message?.data?.data) {
        // This is used to checkThis is wrong. need to get proper error msg from camunda layer
        reject(e.message.data.data);
      }
    }
  });
};

const triggerMailAndNextStage = async (
  req,
  res,
  actionType,
  isEngineReassign,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        du,
        workorderId,
        stageDuedate,
        entityId,
        serviceId,
        wfdefid,
        iterationCount,
        stageId,
        stageName,
        wfId,
        wfeventId,
        customerId,
        activityId,
      } = req.body;
      if (actionType == 'Save') {
        // mail trigger
        const data = {
          duId: du,
          entityId,
          workorderId,
          serviceId,
          wfdefid,
          stageName,
          iteration: iterationCount,
          stageDuedate,
          stageId,
          wfId,
          wfeventId,
        };
        const mailStatus = await getWorkflowConfig(data, 'save');
        logger.info(mailStatus, 'mail response');
        // call for next stage transfer check and trigger
        if (isEngineReassign) {
          logger.info(
            'next stage transfer not trigger - engine reassign',
            wfeventId,
          );
        } else {
          let nextStageTransfer = '';
          // to be handled from config - check for copyediting dispatch trigger for WKH specific
          if (customerId == '13' && stageId == '24' && activityId == '137') {
            const variables = await getCamundaVariableWithValue(workorderId);
            const checkCopyEditingDispatch =
              variables.__isCopyEditingDespatchNeeded__;
            if (!checkCopyEditingDispatch) {
              nextStageTransfer = await _nextStageTransferCheckTrigger(
                req,
                res,
              );
            }
          } else {
            nextStageTransfer = await _nextStageTransferCheckTrigger(req, res);
          }

          logger.info(
            nextStageTransfer,
            'Next stage triggered successfully -',
            wfeventId,
          );
        }
      }
      resolve(true);
    } catch (e) {
      resolve(false);
    }
  });
};

const getCamundaVariableWithValue = workerId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select eventdata->'variables' as variables from wms_workflow_eventlog where workorderid = ${workerId}
      order by wfeventid desc limit 1`;
      const result = await query(sql);
      resolve(result.length ? result[0].variables : {});
    } catch (e) {
      reject(e);
    }
  });
};

export const _nextStageTransferCheckTrigger = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        actionType,
        workorderId,
        serviceId,
        stageId,
        stageIterationCount,
        activityId,
        pmUserId,
      } = req.body;

      logger.info(
        req.body,
        `save.js _nextStageTransferCheckTrigger() - Next stage triggered - payload+ ${workorderId} -- ${stageId}}`,
      );

      const addeddate = new Date();

      logger.info(
        addeddate,
        `save.js _nextStageTransferCheckTrigger() -- newdate() -- suradha`,
      );

      addeddate.setHours(addeddate.getHours() + 5);
      addeddate.setMinutes(addeddate.getMinutes() + 30);

      logger.info(
        addeddate,
        `save.js _nextStageTransferCheckTrigger() -- addeddate -- suradha`,
      );
      const todaydatetime = convertDateFormat(addeddate);

      logger.info(
        todaydatetime,
        `save.js _nextStageTransferCheckTrigger()-- todyadatetime -- suradha`,
      );

      // get the task details
      let sql = `select wfid,duid,customerid,workorderid,itemcode,serviceid,servicename,wotype,stageid,stagename,stageiterationcount,activityid,wfeventid, 
      actualactivitycount, duedate, enableautostagetrnsf, activitystatus, instancetype, jobcardid, userid
      from wms_tasklist where workorderid=$1 and stageid=$2 and activityid=$3 and stageiterationcount=$4 order by actualactivitycount desc limit 1`;
      const taskInfo = await query(sql, [
        workorderId,
        stageId,
        activityId,
        stageIterationCount,
      ]);
      logger.info(taskInfo, 'taskInfo');
      const {
        enableautostagetrnsf,
        activitystatus,
        wfid: wfId,
        duid: duId,
        customerid: customerId,
        servicename: serviceName,
        stagename: stageName,
        wotype: woType,
        wfeventid: wfeventId,
        duedate,
        actualactivitycount: actualActivityCount,
        instancetype: taskType,
        jobcardid: jobCardId,
        userid: userId,
        itemcode: jobId,
      } = taskInfo.length ? taskInfo[0] : {};

      logger.info(enableautostagetrnsf, 'enableautostagetrnsf');
      logger.info(activitystatus, 'activitystatus');
      if (enableautostagetrnsf && activitystatus === 'Completed') {
        const iPayload = {
          stageId,
          wfId,
          stageIterationCount,
          activityId,
          actualActivityCount,
          customerId,
          duId,
          wfeventId,
          wfeventid: wfeventId,
          workorderId,
          taskType,
          jobCardId,
          userId: userId || pmUserId || 'System',
          userid: userId || pmUserId || 'System',
          jobId,
        };
        req.body = { ...req.body, ...iPayload };
        // itracks dispatch - trigger only from engine activity
        if (actionType === 'Save') {
          logger.info(
            'itracks dispatch not triggered - trigger only from engine activity',
          );
        } else {
          await iTracksDistapchCall(req, res);
        }
        // get the files info
        sql = `select * from wms_workorder_incomingfiledetails where woincomingid in (select woincomingid from wms_workorder_incoming where woid=$1)`;
        const getFilesInfo = await query(sql, [workorderId]);
        logger.info(getFilesInfo, 'getFilesInfo');
        const filesInfo = getFilesInfo.length ? getFilesInfo : [];

        // fetch workorder details
        sql = `select itemcode, wotype, wms_workorder_service.wfid, isiauthor, case when wms_workorder.celevelid  >1  then true else false end as iscopyeditingworkflow,otherfield from wms_workorder
        join wms_workorder_service on wms_workorder_service.workorderid = wms_workorder.workorderid
        join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
        where wms_workorder.workorderid=$1`;
        // to be deleted
        // changed for springer journal ce level value to take from workorder.

        // sql = `select itemcode, wotype, wms_workorder_service.wfid, isiauthor,
        // case when wms_workorder.customerid = 10 then
        // case when wms_workorder.celevelid  >1  then true else false  end
        // when wms_workorder.customerid != 10 then
        // case when pp_mst_journal.celevelid  >1  then true else false end
        // end as iscopyeditingworkflow
        // from wms_workorder
        //         join wms_workorder_service on wms_workorder_service.workorderid = wms_workorder.workorderid
        //         join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
        //         where wms_workorder.workorderid=$1`;
        const workOrderDetails = await query(sql, [workorderId]);
        const {
          wotype,
          itemcode,
          wfid,
          isiauthor,
          iscopyeditingworkflow,
          otherfield,
        } = workOrderDetails[0];
        const flowType = ['isgeneral'];
        if (isiauthor) {
          flowType.push('isiauthor');
        }
        if (iscopyeditingworkflow) {
          flowType.push('iscopyeditingworkflow');
        }
        if (
          otherfield &&
          Object.keys(otherfield).includes('papworkflow') &&
          otherfield.papworkflow
        ) {
          flowType.push('ispapworkflow');
        }
        const flows = flowType.join("','");
        // fetch next stage details
        sql = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
        join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
        join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
        and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
        where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
        and iterationcount=$3 and flowtype   in ('${flows}')
        group by nextstageid, stagename order by min(sequence)`;
        let nextStageDetails = await query(sql, [
          wfid,
          stageId,
          stageIterationCount,
        ]);
        if (!nextStageDetails.length) {
          sql = `select nextstageid, stagename as nextstagename from wms_workflow_stageconfig
          join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
          join wms_workflowdefinition on wms_workflowdefinition.wfid = wms_workflow_stageconfig.wfid
          and wms_workflowdefinition.stageid=wms_workflow_nextstage_map.nextstageid
          join wms_mst_stage on wms_mst_stage.stageid = wms_workflow_nextstage_map.nextstageid
          where wms_workflow_stageconfig.wfid=$1 and wms_workflow_stageconfig.stageid=$2
          and iterationcount=$3 and flowtype   in ('${flows}')
          group by nextstageid, stagename order by min(sequence)`;
          nextStageDetails = await query(sql, [
            wfid,
            stageId,
            stageIterationCount - 1,
          ]);
        }
        const { nextstageid, nextstagename } = nextStageDetails[0];
        // fetch the target stage iteration count
        sql = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;
        const targetStageInfo = await query(sql, [workorderId, nextstageid]);
        const { sequence, plannedstartdate, plannedenddate } =
          targetStageInfo[0];
        // fetch the TAT details for the stage
        // const duDates = `SELECT * FROM public.org_mst_du_duedates where customerid = $1 and duid = $2 and stageid = $3`;
        // const duDatesDetails = await query(duDates, [
        //   customerId,
        //   duId,
        //   nextstageid,
        // ]);
        // const { dueduration } = duDatesDetails[0];
        // fetch the workflow details
        const workFlow = `SELECT * FROM public.wms_workflow where wfid = $1`;
        const workFlowDetails = await query(workFlow, [wfId]);
        const { wfcategory } = workFlowDetails[0];

        // const currentDate = moment(new Date()).format('YYYY-MM-DD');
        // const targetDate = moment(new Date())
        //   .add(dueduration, 'days')
        //   .format('YYYY-MM-DD');

        // const currentDate = moment(plannedstartdate || new Date()).format(
        //   'YYYY-MM-DD HH:mm:ss',
        // );
        // const targetDate = moment(plannedenddate || new Date()).format(
        //   'YYYY-MM-DD HH:mm:ss',
        // );

        const currentDate = convertDateFormat(
          plannedstartdate || todaydatetime,
        );
        const targetDate = convertDateFormat(plannedenddate || todaydatetime);

        logger.info(currentDate, 'plannedstartdate - suradha1');
        logger.info(targetDate, 'plannedenddate - suradha1');

        const category = wfcategory;
        const nextStageIteration = targetStageInfo.filter(
          item => item.status === 'Completed',
        );

        const targetStage = {
          iteration: nextStageIteration.length + 1,
          id: nextstageid,
          name: nextstagename,
          plannedStart: currentDate,
          plannedEnd: targetDate,
          sequence,
          receiptdate: todaydatetime,
        };
        const currentStage = {
          iteration: stageIterationCount,
          id: stageId,
          name: stageName,
        };
        const selectedFiles = filesInfo.filter(item => item.typeid !== 1);
        const files = selectedFiles.map(item => {
          return { id: item.woincomingfileid };
        });
        req.body = {
          userId: 'System',
          wfId,
          duId,
          customerId,
          woId: workorderId,
          woType: woType || wotype,
          serviceId,
          serviceName,
          stageId: targetStage.id,
          jobcardId: null,
          jobId: itemcode,
          wfeventId,
          activityId,
          currentStage,
          targetStage,
          files,
          category,
          valuesOfArray: selectedFiles,
          duedate,
          type: 'next',
          entityId: '8',
        };
        req.body.isAutoStageTrigger = true;
        await _triggerWOStageWf(req, res);
        // stage sttatus update
        // sql = `UPDATE public.wms_workorder_stage SET status=$1, enddate=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
        sql = `UPDATE public.wms_workorder_stage SET status=$1, enddatetime=$2  where workorderid =$3 and serviceid = $4 and wfstageid = $5 and stageiterationcount = $6`;
        logger.info(
          'todaydatetime SaveJS Suradha',
          workorderId,
          '___',
          todaydatetime,
        );
        await query(sql, [
          'Completed',
          todaydatetime,
          workorderId,
          serviceId,
          stageId,
          stageIterationCount,
        ]);
        logger.info('Next stage triggered - after save', workorderId);
        resolve(true);
      } else {
        resolve(true);
      }
    } catch (e) {
      logger.info(e, 'error');
      reject(e);
    }
  });
};

export const iTracksDistapchCall = (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { woType, duId, customerId } = req.body;
    try {
      let isTrigger = true;
      let isProduction = false;
      let isCustomer = false;
      if (
        Object.keys(req.body).includes('ftpCustomerDespatchCall') &&
        req.body.ftpCustomerDespatchCall
      ) {
        isCustomer = req.body.ftpCustomerDespatchCall;
      } else {
        const isItracksAPI = await checkItracksExits(req, res, true);
        isProduction = isItracksAPI.isProduction
          ? isItracksAPI.isProduction
          : false;
        isCustomer = isItracksAPI.isCustomer ? isItracksAPI.isCustomer : false;
      }
      if (isProduction || isCustomer) {
        let iSubjobIds = [];
        const iStageId = await getiTracksStageId(req.body);
        const iActivityId = await getiTracksActivityId(req.body);
        if (woType === 'Book') {
          iSubjobIds = await getSubjobIds(req.body);
          console.log(iSubjobIds, 'iSubjobIds');
          req.body.iStageId = iStageId;
          req.body.iActivityId = iActivityId;
          req.body.subjobArray = iSubjobIds;
          if (isProduction && isCustomer) {
            const prodDespatch = await taskDespatch(req.body, 'production');
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              // customer dispatch
              const custDespatch = await taskDespatch(req.body, 'customer');
              const { status: isCust, Result: isCustRes } = custDespatch;
              if (isCust) {
                isTrigger = isCust;
                resolve(isTrigger);
              } else {
                reject(isCustRes);
              }
            } else {
              reject(Result);
            }
          } else if (isProduction) {
            const prodDespatch = await taskDespatch(req.body, 'production');
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              isTrigger = isProd;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else if (isCustomer) {
            const custDespatch = await taskDespatch(req.body, 'customer');
            const { status: isCust, Result } = custDespatch;
            if (isCust) {
              isTrigger = isCust;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else {
            logger.info('without itrcks entry update');
            isTrigger = true;
            resolve(isTrigger);
          }
        } else {
          req.body.iStageId = iStageId;
          req.body.isProduction = isProduction;
          req.body.isCustomer = isCustomer;
          const iDuId = await getiTracksDuId(duId);
          const iCustomerId = await getiTracksCustomerId(customerId);
          if (isProduction && isCustomer) {
            const prodDespatch = await taskDespatchJournal(
              { ...req.body, iDuId, iCustomerId },
              'production',
            );
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              // customer dispatch
              const custDespatch = await taskDespatchJournal(
                { ...req.body, iDuId, iCustomerId },
                'customer',
              );
              const { status: isCust, Result: isCustRes } = custDespatch;
              if (isCust) {
                isTrigger = isCust;
                resolve(isTrigger);
              } else {
                reject(isCustRes);
              }
            } else {
              reject(Result);
            }
          } else if (isProduction) {
            logger.info('production dispatch');
            const prodDespatch = await taskDespatchJournal(
              { ...req.body, iDuId, iCustomerId },
              'production',
            );
            const { status: isProd, Result } = prodDespatch;
            if (isProd) {
              isTrigger = isProd;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else if (isCustomer) {
            logger.info('customer dispatch');
            const custDespatch = await taskDespatchJournal(
              { ...req.body, iDuId, iCustomerId },
              'customer',
            );
            const { status: isCust, Result } = custDespatch;
            if (isCust) {
              isTrigger = isCust;
              resolve(isTrigger);
            } else {
              reject(Result);
            }
          } else {
            logger.info('without itrcks entry update');
            isTrigger = true;
            resolve(isTrigger);
          }
        }
      } else {
        logger.info('without itrcks entry update - main if');
        isTrigger = true;
        resolve(isTrigger);
      }
    } catch (e) {
      logger.info(e, 'error');
      reject(e);
    }
  });
};

export const iTracksDispatchEngineCall = async (req, res) => {
  try {
    const { itemcode, ftpCustomerDespatchCall } = req.body;
    const sql = `select  wo.workorderid,wo.wotype,wo.customerid, wo.itemcode, wfsub.wfeventid,wfsub.stageiterationcount, wfsub.activityiterationcount,wfsub.wfdefid,wfsub.userid,wfsub.actualactivitycount,wo.divisionid,wo.subdivisionid,wo.countryid,customer.custorgmapid,du.duid,wo.jobcardid
    ,wf.instancetype,wf.activityid,wf.stageid,wf.wfid,incoming.typesetpage from wms_workorder as wo 
    join(select * from wms_workflow_eventlog as eventlog where eventlog.activitystatus = 'Completed') as wfsub 
    on wfsub.workorderid = wo.workorderid
    join org_mst_customer_orgmap as customer on customer.customerid = wo.customerid and customer.divisionid = wo.divisionid and customer.subdivisionid = wo.subdivisionid and customer.countryid = wo.countryid
    join org_mst_customerorg_du_map as du on du.custorgmapid = customer.custorgmapid
    join wms_workflowdefinition as wf on wf.wfdefid = wfsub.wfdefid
    join(
    SELECT subjobid, filetypeid, filename, woincomingfileid, wms_workorder_incoming.woid,wms_workorder_incomingfiledetails.duedate, estimatedpages, mspages, uomvalue, typesetpage FROM public.wms_workorder_incoming
                JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
               ) as incoming on  incoming.woid=wfsub.workorderid
    where itemcode = '${itemcode}' order by wfsub.wfeventid desc limit 1`;
    const details = await query(sql);
    if (details.length > 0) {
      const {
        workorderid,
        wotype,
        customerid,
        wfeventid,
        stageiterationcount,
        userid,
        actualactivitycount,
        duid,
        jobcardid,
        instancetype,
        activityid,
        stageid,
        wfid,
        typesetpage,
      } = details[0];
      req.body.woType = wotype;
      req.body.duId = duid;
      req.body.customerId = customerid;
      req.body.stageId = stageid;
      req.body.wfId = wfid;
      req.body.stageIterationCount = stageiterationcount;
      req.body.activityId = activityid;
      req.body.actualActivityCount = actualactivitycount;
      req.body.wfeventId = wfeventid;
      req.body.wfeventid = wfeventid;
      req.body.workorderId = workorderid;
      req.body.taskType = instancetype;
      req.body.jobCardId = jobcardid;
      req.body.userId = userid;
      req.body.jobId = itemcode;
      req.body.quantity = typesetpage;
      req.body.userid = userid;
      req.body.ftpCustomerDespatchCall = ftpCustomerDespatchCall;
    }
    await iTracksDistapchCall(req, res);
    res.status(200).send({ message: 'itracks dispatch call' });
  } catch (e) {
    logger.info(e, 'error on iTracksDistapchEngineCall - final catch');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const nextStageTriggerAuto = async (req, res) => {
  try {
    const { workorderId } = req.body;
    const sql = `select userid from wms_workorder_contacts where workorderid=${workorderId} and contactrole='PM'`;
    const getUserId = await query(sql);
    req.body.pmUserId = getUserId.length ? getUserId[0].userid : null;
    await _nextStageTransferCheckTrigger(req, res);
    res
      .status(200)
      .send({ message: 'Next stage trigger successfully from engine' });
  } catch (e) {
    logger.info(e, 'error on next stage trigger from engine - final catch');
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export function convertDateFormat(inputDate) {
  // Parse the input date using a JavaScript Date object
  const parsedDate = new Date(inputDate);

  if (Number.isNaN(parsedDate)) {
    return 'Invalid Date'; // Handle invalid date input
  }

  // Format the date into 'YYYY-MM-DD HH:mm:ss' using the Date methods
  const year = parsedDate.getFullYear();
  const month = (parsedDate.getMonth() + 1).toString().padStart(2, '0');
  const day = parsedDate.getDate().toString().padStart(2, '0');
  const hours = parsedDate.getHours().toString().padStart(2, '0');
  const minutes = parsedDate.getMinutes().toString().padStart(2, '0');
  const seconds = parsedDate.getSeconds().toString().padStart(2, '0');

  // Create the formatted date string
  const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  return formattedDate;
}
