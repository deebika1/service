// eslint-disable-next-line import/no-unresolved
import * as requestIp from 'request-ip';
import { emitAction, actions } from '../../../activityListener/index.js';
import { query, transaction } from '../../../../database/postgres.js';
import {
  getRejectedVariables,
  getBWStageVariables,
} from '../../../utils/wfTrigger/variables.js';
import { completeTask } from './utils/completeTask.js';
import { getWorkflowConfig, createReportView } from '../../../common/index.js';

import logger from '../../../utils/logs/index.js';
import {
  checkItracksExits,
  logisticEntryUpdate,
  getiTracksStageId,
  getiTracksActivityId,
  getSubjobIds,
  logisticEntryUpdateJournal,
} from '../../../iTracks/index.js';
import { _captureUserEvent } from '../../taskDetails.js';
import { postProcess, preProcess } from './index.js';

// This function will get the defect category list
export const defectCategoryList = (req, res) => {
  const sql = `SELECT defectcategoryid as value, defectcategory as label FROM public.wms_mst_defectcategory`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const rejectProcess = async (req, res) => {
  // check iTracks API call
  const { woType, userid, wfeventId } = req.body;
  try {
    // capture user event
    const payload = {
      userId: userid,
      wfeventId,
      actionType: 'Reject',
    };
    preProcess(req, payload);
    // check iTracks API call
    const isItracksAPI = await checkItracksExits(req, res, true);
    console.log(isItracksAPI, 'isItracksAPI');
    const { status, isProduction, isCustomer } = isItracksAPI;
    if (status) {
      const iStageId = await getiTracksStageId(req.body);
      const iActivityId = await getiTracksActivityId(req.body);

      if (woType === 'Book') {
        const iSubjobIds = await getSubjobIds(req.body);
        console.log(iSubjobIds, 'iSubjobIds');

        if (iStageId && iActivityId && iSubjobIds.length) {
          req.body.iStageId = iStageId;
          req.body.iActivityId = iActivityId;
          req.body.subjobArray = iSubjobIds;
          const isEntryUpdate = await logisticEntryUpdate(
            req.body,
            isProduction,
            isCustomer,
            1,
            'reject',
          );
          const { status: stat, Result } = isEntryUpdate;
          console.log(isEntryUpdate, 'isEntryUpdate');
          if (stat) {
            rejectCamundaTask(req)
              .then(response => {
                emitAction(actions.wfRejected);
                res.send(response);
                postProcess(req, {
                  userId: userid,
                  wfeventId,
                  actionType: 'Reject',
                });
              })
              .catch(e => {
                res.status(400).send(e);
                logger.info(e);
              });
          } else {
            res.status(400).send({ message: Result });
          }
        } else {
          res.status(400).send({
            status: false,
            message:
              'iTracks stageid / activityid / subjobid not fount in iWMS',
          });
        }
      } else {
        console.log('inside journal logistic update');

        if (iStageId && iActivityId) {
          req.body.iStageId = iStageId;
          req.body.iActivityId = iActivityId;
          const isEntryUpdate = await logisticEntryUpdateJournal(
            req.body,
            isProduction,
            isCustomer,
            1,
            'reject',
          );
          const { status: stat, Result } = isEntryUpdate;
          console.log(isEntryUpdate, 'isEntryUpdate');
          if (stat) {
            rejectCamundaTask(req)
              .then(response => {
                emitAction(actions.wfRejected);
                res.send(response);
              })
              .catch(e => {
                res.status(400).send(e);
                logger.info(e);
              });
          } else {
            res.status(400).send({ message: Result });
          }
        } else {
          res.status(400).send({
            status: false,
            message: 'iTracks stageid / activityid not fount in iWMS',
          });
        }
      }
    } else {
      rejectCamundaTask(req)
        .then(response => {
          emitAction(actions.wfRejected);
          res.send(response);
        })
        .catch(e => {
          res.status(400).send(e);
          logger.info(e);
        });
    }
  } catch (e) {
    logger.info(e, 'inside the main catch');
    res.status(400).send({ message: e });
  }
};
// this function will insert the rejected data, complete camunda task, and update eventlogs
export const rejectCamundaTask = req => {
  const {
    du,
    wfeventId,
    taskInstanceId,
    userId,
    defectArray,
    workorderId,
    stageName,
    stageDuedate,
    entityId,
    serviceId,
    wfdefid,
    iterationCount,
    uomvalue,
    stageId,
    wfId,
    camundaVariable,
    rejectedFileInfo,
    isRejectUom,
    taskType,
    woType,
    rejectedActivityType,
    actualActivityCount,
    jobType,
  } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      console.log(
        du,
        wfeventId,
        taskInstanceId,
        userId,
        defectArray,
        workorderId,
        'bnbnn',
      );
      const val = [];
      rejectedFileInfo.forEach(mItem => {
        mItem.defectFormArray.forEach(sItem => {
          val.push(
            `(${mItem.wfEventId},${sItem.category},${sItem.count}, ${mItem.incomingFileId})`,
          );
        });
      });

      let stage = {};
      stage = {
        type: stageName.toLowerCase().replace(/ /g, '_'),
        iteration: iterationCount,
      };
      const rejectFiles = [];
      rejectedFileInfo.forEach(item => {
        rejectFiles.push({
          id: item.incomingFileId,
          name: item.fileName,
          type: item.type,
          isRejected: item.selected,
        });
      });

      // do not change the payload without discussing with team
      const payload = {
        taskId: `${taskInstanceId}`,
        variables:
          woType === 'Journal' && jobType === '2'
            ? {
                ...camundaVariable,
                ...getRejectedVariables(true),
                ...getBWStageVariables(stage, rejectFiles),
              }
            : woType === 'Journal'
            ? { ...camundaVariable, ...getRejectedVariables(true) }
            : !isRejectUom ||
              taskType === 'Multiple' ||
              rejectedActivityType === 'Batch'
            ? { ...camundaVariable, ...getRejectedVariables(true) }
            : {
                ...camundaVariable,
                ...getRejectedVariables(true),
                ...getBWStageVariables(stage, rejectFiles),
              },
      };

      console.log(payload);
      await transaction(async client => {
        let sql = `INSERT INTO public.wms_workflow_eventlog_defects(wfeventid, defectcategoryid, defectcount, woincomingfileid) VALUES ${val}`;
        await client.query(sql);
        sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1 WHERE wfeventid = $2 `;
        await client.query(sql, ['Rejected', wfeventId]);
        // entry for report
        sql = `SELECT timestamp FROM wms_workflow_eventlog_details WHERE wfeventid =$1 AND userid=$2
                AND (operationtype =$3 OR operationtype =$4 OR operationtype =$5) ORDER BY wfeventdetailid DESC LIMIT 1`;
        const { rows } = await client.query(sql, [
          wfeventId,
          userId,
          'Work in progress',
          'Hold',
          'Pending',
        ]);
        logger.info(rows, 'timestamprowsrow11');
        if (rows.length > 0) {
          const data = {
            duId: du,
            userId,
            wfeventId,
            timestamp: rows[0].timestamp,
            uomValue: uomvalue || 0,
          };
          logger.info(data, 'req data for create view');
          await createReportView(client, data);
        }

        const systemInfo = {
          systemIP: requestIp.getClientIp(req),
          publicIP:
            req.headers['x-forwarded-for'] || req.connection.remoteAddress,
          ...JSON.parse(req.headers.systemdetail),
        };
        sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid,uomvalue, systeminfo, actualactivitycount) VALUES ($1, $2, $3, $4, $5, $6, $7)`;
        await client.query(sql, [
          wfeventId,
          'Rejected',
          new Date(),
          userId,
          uomvalue,
          systemInfo,
          actualActivityCount,
        ]);
      });
      await completeTask(payload);
      const data = {
        duId: du,
        entityId,
        workorderId,
        serviceId,
        wfdefid,
        stageDuedate,
        stageName,
        iteration: iterationCount,
        stageId,
        wfId,
        wfeventId,
      };
      const mailStatus = await getWorkflowConfig(data, 'reject');
      logger.info(mailStatus, 'mail response');
      resolve('Task has been rejected successfully');
    } catch (e) {
      logger.info(e, 'reject');
      if (e?.message?.data?.message) {
        // This is used to checkThis is wrong. need to get proper error msg from camunda layer
        reject(e.message.data.message);
      } else {
        reject(e.message ? e.message : e);
      }
    }
  });
};

export const _rejectPostProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};

export const _rejectPreProcess = async (req, payload) => {
  // capture user event
  await _captureUserEvent(req, payload);
};
