import { query } from '../../../database/postgres.js';

export const getToolStatus = async (req, res) => {
  try {
    const { wfeventId } = req.body;
    const sql = `SELECT wms_tools_api.apiid,wms_tools_api.toolid, pp_mst_tool.toolname, wms_tools_api.status, wms_tools_api.remarks,
        wms_tools_api.starttime, wms_tools_api.endtime, pp_mst_tool_output.template,wms_workorder_additionalinfo.pitstopprofileid,wms_tools_api.profilepath
        FROM public.wms_tools_api
        join pp_mst_tool on  pp_mst_tool.toolid = wms_tools_api.toolid
        join pp_mst_tool_output on  pp_mst_tool_output.tooloutputid = pp_mst_tool.tooloutputid
        left join wms_workflow_eventlog as eventlog on eventlog.wfeventid = wms_tools_api.wfeventid
		LEFT JOIN wms_workorder_additionalinfo ON wms_workorder_additionalinfo.workorderid = eventlog.workorderid
        LEFT JOIN wms_mst_pitstopprofile ON wms_mst_pitstopprofile.pitstopprofileid = wms_workorder_additionalinfo.pitstopprofileid
        where wms_tools_api.wfeventid = $1 ORDER BY apiid desc`;
    const toolStatus = await query(sql, [wfeventId]);
    res.json(toolStatus);
  } catch (err) {
    const errMsg = err.message ? err.message : err;
    res.status(400).send(errMsg);
  }
};
