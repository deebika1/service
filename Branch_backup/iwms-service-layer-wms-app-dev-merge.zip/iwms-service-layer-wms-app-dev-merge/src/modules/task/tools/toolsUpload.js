import axios from 'axios';

// url: `${config.iAuthor.base_url()}${config.iAuthor.updateiAuthorMoved}`,
// added
export const getToolExeList = async (req, res) => {
  const input = {
    ids: 1,
  };
  axios({
    method: 'GET',
    url: `172.18.76.7/api/toolLog/getExeToolList`,
    data: JSON.stringify(input),
    headers: {
      'Access-Control-Allow-Origin': true,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  })
    .then(response => {
      console.log(response, 'response');
      res.status(200).json({ data: response.data });
    })
    .catch(err => {
      console.log(err, 'errr CallBackToiAuthor');
      res.status(400).send(err.message ? err.message : err);
    });
};

export const readFolderList = async (req, res) => {
  const { item } = req.body;
  axios({
    method: 'POST',
    url: `172.18.76.7/api/toolLog/getExeToolNewDtl`,
    data: item,
    headers: {
      'Access-Control-Allow-Origin': true,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  })
    .then(response => {
      console.log(response, 'response');
      res.status(200).json({ data: response.data });
    })
    .catch(err => {
      console.log(err, 'errr CallBackToiAuthor');
      res.status(400).send(err.message ? err.message : err);
    });
};

export const downloadFile = async (req, res) => {
  const { item } = req.body;
  axios({
    method: 'POST',
    url: `172.18.76.7/api/toolLog/downloadFile`,
    data: item,
    headers: {
      'Access-Control-Allow-Origin': true,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  })
    .then(response => {
      console.log(response, 'response');
      res.status(200).json({ data: response.data });
    })
    .catch(err => {
      console.log(err, 'errr CallBackToiAuthor');
      res.status(400).send(err.message ? err.message : err);
    });
};
