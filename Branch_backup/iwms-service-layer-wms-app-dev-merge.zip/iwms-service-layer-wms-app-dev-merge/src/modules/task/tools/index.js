/* eslint-disable no-throw-literal */
import { fileURLToPath } from 'url';
import { join, parse } from 'path';
import fs from 'fs';
import ExcelJS from 'exceljs';
import { query } from '../../../database/postgres.js';
import { getBasicToolsData } from '../../utils/tools/index.js';
import logger from '../../utils/logs/index.js';
import { _upload } from '../../utils/azure/index.js';
import { invokeFileUploadToFTP } from '../../filetransferkit/index.js';
import { makeDir, removeFolder } from '../../utils/custom/io.js';
import { mailTriggerForPM } from '../../woi/index.js';

const __filename = fileURLToPath(import.meta.url);
export const getToolsDetails = async (req, res) => {
  const { wfDefId, toolsId } = req.body;
  try {
    const toolsDetails = [];
    const toolsData = await getBasicToolsData(toolsId);
    const toolsConfig = await getToolsConfig(wfDefId);
    toolsData.sort(function (a, b) {
      return (
        toolsId.indexOf(parseInt(a.toolid)) -
        toolsId.indexOf(parseInt(b.toolid))
      );
    });
    for (let i = 0; i < toolsData.length; i++) {
      if (toolsData[i].toolstatus) {
        const id = parseInt(toolsData[i].toolid);
        const config =
          toolsConfig.tools && toolsConfig.tools[id]
            ? toolsConfig.tools[id]
            : {};
        const name = config.aliasName
          ? config.aliasName
          : toolsData[i].toolname;
        const type = parseInt(toolsData[i].tooltypeid);
        const syncFiles = !(config.isSync == false);
        const apiConfig = toolsData[i].apiconfig ? toolsData[i].apiconfig : {};
        const isAsync = !!toolsData[i].isasync;
        const tooloutputid = parseInt(toolsData[i].tooloutputid);
        toolsDetails.push({
          id,
          name,
          config,
          apiConfig,
          isAsync,
          syncFiles,
          type,
          tooloutputid,
        });
      }
    }
    res.status(200).json(toolsDetails);
  } catch (error) {
    logger.info(error, 'getToolsDetails');
    res.status(400).send({ message: error });
  }
};
export const onsaveGetToolsDetails = async (req, res) => {
  const { wfDefId, toolsId } = req.body;
  try {
    const toolsDetails = [];
    const toolsData = await getBasicToolsData(toolsId);
    const toolsConfig = await getToolsConfig(wfDefId);
    toolsData.sort(function (a, b) {
      return (
        toolsId.indexOf(parseInt(a.toolid)) -
        toolsId.indexOf(parseInt(b.toolid))
      );
    });
    for (let i = 0; i < toolsData.length; i++) {
      const id = parseInt(toolsData[i].toolid);
      const config =
        toolsConfig.tools && toolsConfig.tools[id] ? toolsConfig.tools[id] : {};
      const name = config.aliasName ? config.aliasName : toolsData[i].toolname;
      const type = parseInt(toolsData[i].tooltypeid);
      const syncFiles = !(config.isSync == false);
      const apiConfig = toolsData[i].apiconfig ? toolsData[i].apiconfig : {};
      const isAsync = !!toolsData[i].isasync;
      const tooloutputid = parseInt(toolsData[i].tooloutputid);
      const toolvalidation = toolsData[i].toolvalidation || '';
      toolsDetails.push({
        id,
        name,
        config,
        apiConfig,
        isAsync,
        syncFiles,
        type,
        tooloutputid,
        toolvalidation,
      });
    }
    res.status(200).json(toolsDetails);
  } catch (error) {
    logger.info(error, 'getToolsDetails');
    res.status(400).send({ message: error });
  }
};

const getToolsConfig = async wfDefId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT toolsconfig FROM public.wms_workflowdefinition where wfdefid = $1`;
      const data = await query(sql, [wfDefId]);
      const config = data[0].toolsconfig ? data[0].toolsconfig : {};
      resolve(config);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const updateFileTRNLog = (fileTrnData, wfeventId) => {
  return new Promise((resolve, reject) => {
    const values = [];
    fileTrnData.forEach(fileTrn => {
      const { path, uuid, fileId } = fileTrn;
      values.push(
        `(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`,
      );
    });
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES ${values};`;
    query(sql)
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const getToolsRunningStatus = async (req, res) => {
  const { wfeventId } = req.body;
  const sql = `select * from (select row_number() over(Partition by toolid order by apiid desc ) as rno,toolid,apiid,status from public.wms_tools_api 
        where wfeventid=${wfeventId}) results where rno =1 and status in ('InProgress')`;
  logger.info(sql, 'getToolsRunnningstatus');
  const response = await query(sql);
  if (response.length) {
    res.status(200).send({ message: false });
  } else {
    const sqlQuery = `UPDATE public.wms_tools_api SET status = 'Failure', remarks = 'Latest Output has been generated for that tool'
                WHERE wfeventid = ${wfeventId} and status='InProgress'`;
    await query(sqlQuery);
    res.status(200).send({ message: true });
  }
};

export const fetchguId = async (req, res) => {
  const { workorderId, stageId, stageIterationCount, customerId } = req.body;
  const iAuth = {};
  return new Promise(async (resolve, reject) => {
    try {
      if (customerId != '9') {
        const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid 
            join wms_workorder_stage as e on e.workorderid = a.workorderid
            join iauthor_transactions as d on d.workorderid = a.workorderid and e.triggeredstagefromid = d.stageid and d.stageiterationcount =  e.triggeredstageitrationfromid
            where a.workorderid = ${workorderId} and b.isiauthor=true  and 
            (e.wfstageid = ${stageId} or e.wfstageid =(select st.triggeredstagefromid from  wms_workorder_stage as st where st.workorderid=${workorderId} and st.wfstageid=${stageId} order by st.wostageid desc limit 1)) and
            e.stageiterationcount=${stageIterationCount} order by e.wostageid desc limit 1`;
        console.log(sql);
        const data = await query(sql);
        console.log(data);
        let errMsg = '';
        if (data.length <= 0) {
          errMsg =
            'This tool execution is not applicable for Revises iterations.';
          res.status(200).send({ guid: false, iAuth: {}, err: errMsg });
        }
        if (Object.keys(data[0].sequencedetails.length > 0)) {
          for (const [key, value] of Object.entries(
            data[0].sequencedetails.activities,
          )) {
            console.log(key);
            if (value.contactrole == 'SPM') {
              iAuth.roleid = value.RoleID;
              iAuth.activityid = value.ActivityID;
            }
          }
        }
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      } else if (customerId == '9') {
        const sql = `select d.guid, c.sequencedetails from wms_workorder as a join pp_mst_journal as b  on b.journalid = a.journalid join iauthor_workflow c on c.iauthworkflowid = b.iauthworkflowid 
        join wms_workorder_stage as e on e.workorderid = a.workorderid
        join iauthor_transactions as d on d.workorderid = a.workorderid
        where a.workorderid =${workorderId} and b.isiauthor=true  order by d.iauthourtrnsid desc  limit 1`;
        console.log(sql);
        const data = await query(sql);
        console.log(data[0].guid, iAuth, 'JI');
        res.status(200).send({ guid: data[0].guid, iAuth });
      }
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const checkGraphicEnabled = async (req, res) => {
  const { workorderId, wfeventId, woincomingFileId, taskType } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      let condition = '';
      let sql = '';
      if (taskType == 'Multiple') {
        condition = `eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0 and incomingfile.woincomingfileid = ${woincomingFileId}`;
        // condition = `eventlog.wfeventid = ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.isgraphicrequired = true and incomingfile.woincomingfileid =${woincomingFileId} `
        sql = `select  incomingfile.woincomingfileid,incomingfile.filename,incomingfile.imagecount,eventlog.wfdefid,workflow.config,incomingfile.woincomingfileid from wms_workorder_incoming as incoming
                join wms_workorder_incomingfiledetails as incomingfile on incomingfile.woincomingid =incoming.woincomingid
                join  wms_workflow_eventlog as eventlog on eventlog.workorderid = incoming.woid
                join wms_workflowdefinition as workflow on workflow.wfdefid = eventlog.wfdefid
                ${condition ? `where ${condition}` : ''}`;
      } else {
        condition = `eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0`;
        // condition = `eventlog.wfeventid = ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.isgraphicrequired = true`
        sql = `select  incomingfile.woincomingfileid from wms_workorder_incoming as incoming
                join wms_workorder_incomingfiledetails as incomingfile on incomingfile.woincomingid =incoming.woincomingid
                join  wms_workflow_eventlog as eventlog on eventlog.workorderid = incoming.woid
                join wms_workflowdefinition as workflow on workflow.wfdefid = eventlog.wfdefid 
                where eventlog.wfeventid =  ${wfeventId} and incoming.woid = ${workorderId} and incomingfile.imagecount is not null  and incomingfile.imagecount > 0`;
      }
      console.log(sql);
      const reponse2 = await query(sql);
      console.log(reponse2, 'reponse2');
      res.status(200).send(reponse2);
    } catch (e) {
      logger.info(e, 'graphic file validation');
      reject(e);
    }
  });
};

function appendUnderscoreBeforeFirstNumber(inputString) {
  const match = inputString.match(/\d/);
  if (match) {
    // Insert an underscore before the first numeric character
    const { index } = match;
    const modifiedString = `${inputString.slice(0, index)}_${inputString.slice(
      index,
    )}`;
    return modifiedString;
  }
  return inputString;
}
export const exportcollationreport = async (req, res) => {
  const {
    workorder,
    stage,
    excelfilename,
    stageid,
    customerid,
    duid,
    basePath,
    isEmail,
    attachFiles,
    wfeventId,
  } = req.body;

  let blobPath = '';

  try {
    // const sql = `select journalacronym as "mnemonic",doinumber as "doinumber",typesetpages as "number of pages",title,'' as"copy to copyed",'' as "copy to typesetter"
    //       ,firsrproofreceived as "first proof rec'd", collationenabled as "for correction",
    //       pmreviewcompleted1 as "revised proof",revisesreceived2 as "for correction v1",pmreviewcompleted2 as "revised proof1",revisesreceived3 as "for correction v2",pmreviewcompleted3 as "revised proof2"
    //       from getcollation_report('${workorder}','${stage}')`;
    const sql = `select journalacronym as "mnemonic",doi,typesetpages as "number of pages",title,'' as"copy to copyed",'' as "copy to typesetter",
    iauthorlinkcreated as "first proof rec'd", collationenabled as "for correction",
             pmreviewcompleted1 as "revised proof",revisesreceived2 as "for correction v1",pmreviewcompleted2 as "revised proof 1",revisesreceived3 as "for correction v2",pmreviewcompleted3 as "revised proof 2"
             from getcollation_report_new('${workorder}','${stage}')`;

    console.log(sql, 'getcollationreport');
    const report = await query(sql);
    let checkStatus = true;
    if (stageid != 1 && !isEmail) {
      const sql3 = `select * from wms_ftp_audit where stageid=1 and workorderid=${workorder}`;
      const count = await query(sql3);
      checkStatus = count.length > 0;
    }

    if (checkStatus) {
      const validationFtp = `select count(*) from wms_ftp_audit where wfeventid =${wfeventId} and status = 'Success'`;
      const validationCount = await query(validationFtp);
      if (
        validationCount &&
        validationCount.length > 0 &&
        validationCount[0].count <= 1
      ) {
        // to read the xlsx file from selected path
        let outputFilePath = join(__filename, '../../../../../');
        logger.info(outputFilePath, 'outputFilePath2');
        outputFilePath = join(outputFilePath, 'upload/cupJournals.xlsx');

        let tempFilePath = join(__filename, '../../../../../');
        logger.info(tempFilePath, 'tempFilePath2');

        const temp1 = `${tempFilePath}upload/temps`;
        await makeDir(temp1);
        const temp2 = `${tempFilePath}upload/temps/${workorder}`;
        await removeFolder(temp2);
        await makeDir(temp2);

        tempFilePath = join(
          tempFilePath,
          `upload/temps/${workorder}/cupJournals.xlsx`,
        );
        logger.info(
          outputFilePath,
          'outputFilePath',
          tempFilePath,
          'tempFilePath',
        );
        await copyXlsxFile(outputFilePath, tempFilePath);
        logger.info(tempFilePath, 'tempFilePath');

        const cells = [
          'A2',
          'B2',
          'C2',
          'D2',
          'E2',
          'F2',
          'G2',
          'H2',
          'I2',
          'J2',
          'K2',
          'L2',
          'M2',
        ];
        const cells1 = [
          'A1',
          'B1',
          'C1',
          'D1',
          'E1',
          'F1',
          'G1',
          'H1',
          'I1',
          'J1',
          'K1',
          'L1',
          'M1',
        ];

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(tempFilePath);
        const worksheet = workbook.getWorksheet('Sheet1'); // Replace 'Sheet1' with the actual sheet name
        for (let i = 0; i < cells.length; i++) {
          const cell = worksheet.getCell(cells[i]);
          const cell1 = worksheet.getCell(cells1[i]);
          // cell.value = Number.isNaN(report[0][cell1])
          //   ? report[0][cell1]
          //   : +report[0][cell1];
          cell.value =
            typeof report[0][cell1] === 'number'
              ? +report[0][cell1]
              : report[0][cell1];
        }
        const xlFilenameForUpload =
          appendUnderscoreBeforeFirstNumber(excelfilename);
        // Save the changes
        await workbook.xlsx.writeFile(tempFilePath);
        const fileDetails = {
          tempFilePath,
          name: xlFilenameForUpload,
        };

        logger.info(fileDetails, basePath, 'blob upload path');
        const uploadRes = await _upload(fileDetails, basePath);
        console.log('Kaniiiiii', uploadRes);
        blobPath = uploadRes.fullPath;
        logger.info('file upload to blob succesfully');
        // const sql2 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Success', current_timestamp,${wfeventId},'${uploadRes.fullPath}')`;
        // const reponse2 = await query(sql2);
        // console.log(reponse2, 'reponse2');
        const srcInfo = {
          path: `${tempFilePath}`,
        };
        const targetInfo = {
          filename: `${xlFilenameForUpload}`,
        };

        targetInfo.tempFileName = `${parse(targetInfo.filename).name}.io`;
        const ftpRes = await invokeFileUploadToFTP(
          'cup_ftp_fileUpload',
          srcInfo,
          targetInfo,
        );

        logger.info(ftpRes, 'ftpRes ftp response');
        if (ftpRes) {
          if (isEmail) {
            const fileArray = [];

            attachFiles.forEach(list => {
              fileArray.push(
                join(list.dest, list.srcName).split('\\').join('/'),
              );
            });
            logger.info(fileArray, req.body, 'fileArray');

            await mailTriggerForPM(req.body, fileArray);
          }
          const sql2 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,remarks,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Success', 'File Uploaded Successfully' ,current_timestamp,${wfeventId},'${blobPath}')`;
          const reponse2 = await query(sql2);
          console.log(reponse2, 'reponse2');
        }
        await removeFolder(temp2);
      }

      res.status(200).send(report);
    } else {
      res.status(400).send({
        message:
          'xlsx file not upload in ftp due to firstproof stage not uploaded xlsx',
      });
    }
  } catch (e) {
    const message = e.message ? e.message : e;
    const sql3 = `insert into wms_ftp_audit(customerid,duid,stageid,workorderid,status,remarks,createdon,wfeventid,filepath) values(${customerid},${duid},${stageid},${workorder},'Failed','${message}', current_timestamp,${wfeventId},'${blobPath}')`;
    await query(sql3);
    logger.info(e, 'ftp upload failed for collation activity');
    // res.status(400).send(e.message ? e.message : e);
    res.status(400).send(message);
  }
};

export const copyXlsxFile = async (outputFilePath, tempFilePath) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Read the content of the source file synchronously
      const data = await fs.readFileSync(outputFilePath);

      // Write the content to the destination file synchronously
      await fs.writeFileSync(tempFilePath, data);
      logger.info('File copied successfully!');
      resolve();
    } catch (err) {
      logger.info('Error copying file:', err);
      reject(err);
    }
  });
};
