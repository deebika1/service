import { Service } from '../../../httpClient/index.js';
import {
  _createAPIRequestId,
  _updateAPIRequestId,
  _buildApiConfig,
  _completeAPIRequestId,
  _updatePitstopProfile,
} from '../../utils/tools/api.js';
import { getFileTrnDetails } from '../../utils/tools/utils.js';
import { getFilesData, getFileTrnData } from '../../utils/tools/io.js';
import {
  formattedApiConfig,
  isNullorUndefined,
} from '../../utils/tools/index.js';
import { getFileInfoDetails } from '../fileDetails.js';
import { updateFileTRNLog } from './index.js';
import logger from '../../utils/logs/index.js';
import { startPolling } from './ack.js';
import { query } from '../../../database/postgres.js';
import { getdmsType } from '../../bpmn/listener/create.js';

const service = new Service();

export const invokeTools = async (req, res) => {
  const {
    workorderDetails,
    toolId,
    wfeventId,
    config,
    apiConfig,
    isAsync,
    placeHolders,
    userId,
    workorderId,
    jobId,
    stageName,
    activityName,
    toolsCustom,
    sId,
    customerId,
    customerName,
    woIncomingFileId,
    tooloutputid,
    iAuthor,
    newFileType,
    dmsType,
    isUICall,
    onSave,
    activityId,
    wfDefid,
    actualActivityCount,
    instanceType,
    pdfMerging,
    JournalAcronym,
  } = req.body;
  let apiId;
  let onsave;
  try {
    apiId = await _createAPIRequestId({
      wfeventId,
      toolsId: toolId,
      isForegroundService: true,
      userId,
    });
    const toolsPlaceHolder = config.placeHolder ? config.placeHolder : {};
    const combinedPlaceHolders = { ...placeHolders, ...toolsPlaceHolder };
    const updatedApiConfig = formattedApiConfig(
      apiConfig,
      combinedPlaceHolders,
    );
    const files = await getIOData(
      config,
      workorderDetails,
      wfeventId,
      placeHolders,
    );
    if (isUICall === true) {
      Object.keys(files.in).forEach(ele => {
        if (Array.isArray(files.in[ele])) {
          files.in[ele].forEach(el => {
            el.path = el.path.replace(
              el.actualPath,
              `${el.actualPath}tool/${toolId}/In/`,
            );
          });
        } else {
          files.in[ele].path = files.in[ele].path.replace(
            files.in[ele].actualPath,
            `${files.in[ele].actualPath}tool/${toolId}/In/`,
          );
        }
      });
      Object.keys(files.out).forEach(ele => {
        if (Array.isArray(files.out[ele])) {
          files.out[ele].forEach(el => {
            el.path = el.path.replace(
              el.actualPath,
              `${el.actualPath}tool/${toolId}/Out/`,
            );
          });
        } else {
          files.out[ele].path = files.out[ele].path.replace(
            files.out[ele].actualPath,
            `${files.out[ele].actualPath}tool/${toolId}/Out/`,
          );
        }
      });
    }
    const sql = `select ((a.toolsconfig ::jsonb ->> 'tools') ::jsonb ->> '${toolId}')::jsonb ->> 'params' as additionalinfo
        from wms_workflowdefinition a join public.wms_workflow_eventlog b on a.wfdefid=b.wfdefid 
        where a.activityid=${workorderDetails.activity.id} 
        and a.stageid=${workorderDetails.stage.id} and b.wfeventid=${wfeventId}`;
    let additionalInfo = await query(sql);
    if (additionalInfo.length > 0) {
      additionalInfo =
        additionalInfo[0].additionalinfo == null ||
        additionalInfo[0].additionalinfo == ''
          ? {}
          : JSON.parse(additionalInfo[0].additionalinfo);
    }
    const iwms = {
      additionalInfo,
      id: apiId,
      env: process.env.MODE_VAL,
      userId,
      woId: workorderId,
      wfEventId: wfeventId,
      woName: jobId,
      stage: stageName,
      stageId: workorderDetails.stage.id,
      activity: activityName,
      serviceId: workorderDetails.service.id,
      stageIteration: workorderDetails.activity.iteration,
      toolsCustom: toolsCustom || {},
      sId,
      custId: customerId,
      custName: customerName,
      tooloutputid,
      woIncomingFileId: woIncomingFileId || null,
      iAuthor: iAuthor || null,
      newFileType: newFileType || null,
      dmsType: dmsType || null,
      isUICall,
      onSave,
      activityId,
      wfDefid,
      actualActivityCount,
      instanceType,
      pdfMerging,
      JournalAcronym,
    };
    const inputParams = await _buildApiConfig(iwms, files, updatedApiConfig);
    console.log(inputParams, 'inputParams');
    await _updateAPIRequestId({ apiId, inputParams });
    try {
      const toolsResponse = await service.invokeService(inputParams);
      const { pitstopPath } = toolsResponse.data;
      await _updatePitstopProfile({ apiId, pitstopPath });
      // if (
      //   onSave == true &&
      //   Object.keys(toolsResponse.data).length > 0 &&
      //   Object.keys(toolsResponse.data.data).length > 0 &&
      //   toolsResponse.data.is_success == false &&
      //   toolsResponse.data.data.onSave == false
      // ) {
      //   res.status(200).json(toolsResponse);
      //   logger.info(toolsResponse, 'On save for service tool with Error');
      // } else {
      console.log(toolsResponse, 'toolsResponse');
      logger.info(toolsResponse, 'toolsResponse');
      if (!isAsync) {
        await processResponse(
          config,
          workorderDetails,
          wfeventId,
          placeHolders,
        );
        const remarks =
          !isNullorUndefined(toolsResponse.data.data) &&
          (Object.prototype.toString.call(toolsResponse.data.data) ==
            '[object String]' ||
            Object.prototype.toString.call(toolsResponse.data.data) ==
              '[object Boolean]')
            ? toolsResponse.data.data
            : !isNullorUndefined(toolsResponse.data.message) &&
              (Object.prototype.toString.call(toolsResponse.data.message) ==
                '[object String]' ||
                Object.prototype.toString.call(toolsResponse.data.message) ==
                  '[object Boolean]')
            ? toolsResponse.data.message
            : toolsResponse.data.data ||
              toolsResponse.data.message ||
              'Remarks missing';
        _completeAPIRequestId({
          apiId,
          onSave,
          status: 'Success',
          remarks: remarks.toString(),
          response: toolsResponse.data || {},
          sId,
          tooloutputid,
          isFileAvailable: true,
          actualActivityCount,
        });
      }
      if (isAsync && toolsCustom.validate) {
        console.log('START  POLLING');
        onsave = await startPolling(apiId, wfeventId, files, 200);
        console.log(onsave);
        if (onsave === false) throw new Error('On save validation failed');
      }
      // res.status(200).json(toolsResponse);
      if (onsave === true) {
        res
          .status(200)
          .json({ message: 'On Save Validation Completed', toolsResponse });
      } else {
        res.status(200).json(toolsResponse);
      }
      // }
    } catch (err) {
      const errorMsg =
        err?.message?.data?.data &&
        (Object.prototype.toString.call(err.message.data.data) ==
          '[object String]' ||
          Object.prototype.toString.call(err.message.data.data) ==
            '[object Boolean]')
          ? err.message.data.data
          : err?.message?.data?.message &&
            (Object.prototype.toString.call(err.message.data.message) ==
              '[object String]' ||
              Object.prototype.toString.call(err.message.data.message) ==
                '[object Boolean]')
          ? err.message.data.message
          : err?.message?.data?.data ||
            err?.message?.data?.message ||
            err.message ||
            err;
      logger.info(errorMsg, 'toolsResponse');
      _completeAPIRequestId({
        apiId,
        onSave,
        status: 'Failure',
        remarks: errorMsg.toString(),
        response: err?.message?.data || {},
        sId,
        tooloutputid,
        isFileAvailable: false,
        actualActivityCount,
      });
      res.status(400).send({ message: errorMsg });
    }
  } catch (err) {
    const errorMsg = err.message ? err.message : err;
    logger.info(errorMsg, 'invokeTool');
    if (apiId)
      _completeAPIRequestId({
        apiId,
        status: 'Failure',
        remarks: errorMsg.toString(),
        response: {},
        sId,
        tooloutputid,
        isFileAvailable: false,
        actualActivityCount,
      });
    res.status(400).send({ message: errorMsg });
  }
};

const getIOData = async (config, workorderDetails, wfeventId, placeHolders) => {
  const fileConfig = config.files ? config.files : {};
  const {
    stage,
    activity,
    service: ser,
    du,
    customer,
    workOrderId,
  } = workorderDetails;
  const fileDetails = await getFileInfoDetails({
    wfEventId: wfeventId,
    workOrderId,
    du,
    customer,
    service: ser,
    stage,
    activity,
    typesId: [],
  });
  const input = await getFilesData({
    workorderDetails,
    IOFiles:
      fileConfig?.filter(x => (x.fileFlowType || []).includes('IN')) || [],
    fileDetails,
    placeHolders,
  });
  const output = await getFilesData({
    workorderDetails,
    IOFiles:
      fileConfig?.filter(x => (x.fileFlowType || []).includes('OUT')) || [],
    fileDetails,
    placeHolders,
  });
  return {
    in: Object.keys(input).map(key => input?.[key]),
    out: Object.keys(output).map(key => output?.[key]),
  };
};

const processResponse = async (
  config,
  workorderDetails,
  wfeventId,
  placeHolders,
) => {
  const fileConfig = config.files ? config.files : {};
  const dmsType = await getdmsType(workorderDetails.workOrderId);
  const {
    stage,
    activity,
    service: ser,
    du,
    customer,
    workOrderId,
  } = workorderDetails;
  const fileDetails = await getFileInfoDetails({
    wfEventId: wfeventId,
    workOrderId,
    du,
    customer,
    service: ser,
    stage,
    activity,
    typesId: [],
  });
  const files = await getFilesData({
    workorderDetails,
    IOFiles: fileConfig.output,
    fileDetails,
    placeHolders,
    isInputProcessing: false,
  });
  const fileTrnDetails = await getFileTrnDetails(wfeventId);
  const fileTrnData = await getFileTrnData(files, fileTrnDetails, dmsType);
  if (fileTrnData.length) await updateFileTRNLog(fileTrnData, wfeventId);
};
