import { _getActivityDetails } from '../index.js';
import { getWorkflowPlaceHolders, getFileInfoDetails } from '../fileDetails.js';
import { getFileTrnData, getFilesData } from '../../utils/tools/io.js';
import { getFileTrnDetails } from '../../utils/tools/utils.js';
import { updateFileTRNLog } from './index.js';

import logger from '../../utils/logs/index.js';
import { query } from '../../../database/postgres.js';

export const acknowledge = async (wfeventId, toolsId, data, dmsType) => {
  const activityDetails = await _getActivityDetails(wfeventId);
  const {
    du,
    customer,
    stage,
    activity,
    workOrderId,
    service,
    fileId,
    toolsConfig,
  } = activityDetails;
  const config =
    toolsConfig.tools && toolsConfig.tools[toolsId]
      ? toolsConfig.tools[toolsId]
      : {};
  const fileConfig = config.files ? config.files : {};
  const placeHolders = await getWorkflowPlaceHolders(wfeventId);
  const workorderDetails = {
    stage,
    activity,
    service,
    du,
    customer,
    workOrderId,
    fileId,
  };
  const fileDetails = await getFileInfoDetails({
    wfEventId: wfeventId,
    workOrderId,
    du,
    customer,
    service,
    stage,
    activity,
    typesId: [],
  });
  const files = await getFilesData({
    dmsType,
    workorderDetails,
    IOFiles: fileConfig.output,
    fileDetails,
    placeHolders,
    isInputProcessing: false,
  });
  const fileTrnDetails = await getFileTrnDetails(wfeventId);
  const fileTrnData = await getFileTrnData(files, fileTrnDetails, dmsType);
  if (fileTrnData.length) await updateFileTRNLog(fileTrnData, wfeventId);
  logger.info(
    `Process Completed (wfeventId -${wfeventId}, toolId - ${toolsId})`,
  );
};

export const startPolling = (tokenId, wfeventId, enginePath, retryCount) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (retryCount > 0) {
        const entries = await fetchEntry(tokenId);
        console.log(entries, 'TOOLS');
        if (
          entries[0].status === 'Success' ||
          entries[0].status === 'Failure'
        ) {
          console.log(entries[0].response.data.onSave);
          resolve(entries[0].response.data.onSave);
        } else if (entries[0].status === 'InProgress') {
          --retryCount;
          console.log(
            `Retrying the process as the tool is running 'In Progress' (remaining retries - ${retryCount})`,
          );
          setTimeout(async () => {
            try {
              const data = await startPolling(
                tokenId,
                wfeventId,
                enginePath,
                retryCount,
              );
              resolve(data);
            } catch (e) {
              reject(e);
            }
          }, 7000);
        } else {
          --retryCount;
          console.log(
            `Retrying the process (remaining retries - ${retryCount})`,
          );
          setTimeout(async () => {
            try {
              const data = await startPolling(
                tokenId,
                wfeventId,
                enginePath,
                retryCount,
              );
              resolve(data);
            } catch (e) {
              reject(e);
            }
          }, 7000);
        }
      } else {
        console.log('Max Retry exhausted');
        reject('Max Retry exhausted');
      }
    } catch (e) {
      reject(e);
      console.log(e, 'startPolling');
    }
  });
};

const fetchEntry = async tokenId => {
  return new Promise(async (resolve, reject) => {
    const recordsArray = [];
    try {
      const sql = `SELECT * FROM public.wms_tools_api_list where apiid=$1`;
      console.log(sql, 'tools');
      const data = await query(sql, [tokenId]);
      console.log(sql, data, 'SL');
      data.forEach(list => {
        recordsArray.push({
          status: list.status,
          remarks: list.remarks,
          response: list.response,
        });
      });
      resolve(recordsArray);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
