import { query, transaction } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';

export const getAllTask = (req, res) => {
  console.log('uiinnnn');
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  if (reqData.userid == '') {
    res.status(400).send({ message: 'Userid should not be empty' });
  } else if (reqData.type == '') {
    res.status(400).send({ message: 'Type should not be empty' });
  } else if (reqData.pageNo == '') {
    res.status(400).send({ message: 'Page number should not be empty' });
  } else if (reqData.recordPerPage == '') {
    res.status(400).send({ message: 'Record per page should not be empty' });
  } else {
    let condition = '';
    if (
      reqData.type === 'all' ||
      reqData.type === 'myTask' ||
      reqData.type === 'despatch'
    ) {
      logger.info(reqData.filtervalues, reqData.type, 'searchobj');
      const { filtervalues } = reqData;
      const getNotInArray = filtervalues.filter(
        data => data.type === 'where' && data.operator !== 'IN',
      );
      const seen = {};
      const resultOfgroupBy = filtervalues.filter(entry => {
        if (entry.operator === 'IN') {
          let previous;
          if (Object.prototype.hasOwnProperty.call(seen, entry.name)) {
            previous = seen[entry.name];
            previous.value.push(entry.value);
            return false;
          }
          if (!Array.isArray(entry.value)) {
            entry.value = [entry.value];
          }
          seen[entry.name] = entry;
          return true;
        }
        return false;
      });
      logger.info(resultOfgroupBy, 'resultOfgroupBy');
      const mergedArray = [].concat(getNotInArray, resultOfgroupBy);
      mergedArray.forEach((item, i) => {
        if (item.type === 'where') {
          let statusValue = '';
          if (Array.isArray(item.value)) {
            item.value.forEach((status, vi) => {
              statusValue +=
                item.value.length - 1 !== vi ? `'${status}' ,` : `'${status}'`;
            });
          }
          condition +=
            mergedArray.length - 1 !== i
              ? Array.isArray(item.value)
                ? `${item.name} ${item.operator} (${statusValue})  AND `
                : item.value === ''
                ? `${item.name} ${item.operator} AND `
                : `${item.name} ${item.operator} ${
                    item.operator === 'IN'
                      ? `('${item.value}')`
                      : `'${item.value}'`
                  } AND `
              : Array.isArray(item.value)
              ? `${item.name} ${item.operator} (${statusValue})`
              : item.value === ''
              ? `${item.name} ${item.operator} `
              : `${item.name} ${item.operator} ${
                  item.operator === 'IN'
                    ? `('${item.value}')`
                    : `'${item.value}'`
                }  `;
        }
      });

      logger.info(condition, 'conditionconditioncondition111');
      console.log(condition, 'conditionconditioncondition111');
    } else if (reqData.type === 'filter') {
      const {
        filtervalues: { filtervalues, page, filterType, dateObjects },
      } = reqData;
      logger.info(reqData, 'ldjasjsdajfkdsjlksdk');
      if (page === 'allTask' || page === 'myTask') {
        const output = [];
        logger.info(filtervalues, 'filtervalues1');
        filtervalues.forEach(item => {
          if (item.type !== 'orderby') {
            const existing = output.filter(function (v) {
              return v.name == item.name;
            });
            logger.info(existing, 'existing');
            if (existing.length) {
              const existingIndex = output.indexOf(existing[0]);
              output[existingIndex].value = output[existingIndex].value.concat(
                item.value,
              );
            } else {
              if (typeof item.value === 'string')
                item.value = item.value ? [item.value] : [];
              output.push(item);
            }
          }
        });
        logger.info(output, 'output11');

        output.forEach(data => {
          data.setValue = '';
          data.value.forEach((data1, i) => {
            data.setValue += `'${data1}' ${
              data.value.length - 1 !== i ? ',' : ''
            }`;
          });
        });
        logger.info(output, 'output');

        output.forEach((item, i) => {
          logger.info(condition, 'coniidididi');
          logger.info(item.value.length, 'item.lengthq.value');
          if (item.name !== 'duedate') {
            condition +=
              output.length - 1 !== i
                ? item.setValue == ''
                  ? `${item.name} ${item.operator} AND `
                  : `${item.name} ${item.operator} (${item.setValue}) AND `
                : item.setValue == ''
                ? `${item.name} ${item.operator} `
                : `${item.name} ${item.operator} (${item.setValue}) `;
          }
        });
        logger.info('indate11');
        if (filterType === 'date') {
          logger.info('indate');
          condition += Object.keys(dateObjects).length ? 'AND' : '';
          condition += ` duedate BETWEEN '${dateObjects.startDate}' AND '${dateObjects.endDate}' `;
        }
        logger.info(condition, 'conditionconditioncondition11');
      }
    }
    if (reqData.roleid == '1' || reqData.roleid == '9') {
      condition += ` AND (userid='${reqData.userid}' OR activitystatus IN ('Unassigned', 'Pending') )`;
    }
    let skills = '';
    if (
      reqData.type != 'query' &&
      reqData.filtervalues.fiterValueType !== 'query'
    ) {
      reqData.skillid.forEach((skill, i) => {
        skills += `'${skill}' ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
      });
      const sqlFoTotal = `SELECT count(1) FROM public.wms_tasklist WHERE (baseduid IN (${
        reqData.duId
      }) OR assignedduid IN (${reqData.duId})) ${
        skills ? `AND skillid IN (${skills})` : ''
      } ${condition ? `${'AND '}${condition}` : ''}`;
      logger.info(sqlFoTotal, 'sql for count');

      query(sqlFoTotal)
        .then(async totalRecords => {
          logger.info(totalRecords.length, 'get response for count');
          if (totalRecords.length > 0) {
            const data = await getRecords(reqData, condition, skills, res);
            if (data.length > 0) {
              logger.info(data, 'new data');
              const total = totalRecords.length;
              res.status(200).json({ data, total });
            } else {
              res.status(200).json({ data: [], message: 'No data found' });
            }
          } else {
            res.status(200).json({ data: [] });
          }
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    } else {
      console.log(condition, 'conditinforquery');
      console.log(reqData, 'oosdkfsjdfkj');
      reqData.skillid.forEach((skill, i) => {
        skills += `${skill} ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
      });
      const sqlFoTotal = `SELECT * FROM public.wms_workorder_query_list where querystatus in ('Open','Re-open') and  duid in (${
        reqData.duId
      })  and (queryid in
            (select queryid from wms_query_assigned where skillid in (${skills})) or createdby='${
        reqData.userid
      }')  ${condition ? `${'AND '}${condition}` : ''}`;
      logger.info(sqlFoTotal, 'sql for count');
      console.log(sqlFoTotal, 'sql for count quereyyy');
      query(sqlFoTotal)
        .then(totalRecords => {
          logger.info(totalRecords.length, 'get response for count');
          console.log(totalRecords, 'recoof');
          if (totalRecords.length > 0) {
            getRecordForQuery(
              reqData,
              totalRecords.length,
              condition,
              skills,
              res,
            );
          } else {
            res.status(200).json({ data: [] });
          }
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    }
  }
};

export const getNewAllTask = (req, res) => {
  const { skillid, userid, roleid, duId } = req.body;

  const sql = `select * from wms_tasklist where duid='${duId}' and (userid = '${userid}' or userid is null) and roleid = ${roleid}
                and skillid in (${skillid})`;
  logger.info(sql, 'tasklist');

  query(sql)
    .then(data => {
      res.status(200).json({ data, issuccess: true });
    })
    .catch(error => {
      logger.info(error, 'errorerrorerror');
      res.status(400).send({ message: error });
    });
};

const getRecordForQuery = (reqData, total, condition, skills, res) => {
  const { pageNo, recordPerPage, duId } = reqData;
  const offset = (pageNo - 1) * recordPerPage;
  const numOfPages = Math.ceil(total / recordPerPage);
  const sql = `  SELECT * FROM public.wms_workorder_query_list where querystatus in ('Open','Re-open') and duid in (${duId})  and (queryid in
    (select queryid from wms_query_assigned where skillid in (${skills})) or createdby='${
    reqData.userid
  }')  ${
    condition ? `${'AND '}${condition}` : ''
  } LIMIT ${recordPerPage} OFFSET ${offset}`;
  console.log(sql);
  query(sql)
    .then(data => {
      res.status(200).json({ data, total, numOfPages });
    })
    .catch(error => {
      logger.info(error, 'errorerrorerror');
      res.status(400).send({ message: error });
    });
};

const getRecords = async (reqData, condition, skills) => {
  return new Promise(async resolve => {
    const { filtervalues } = reqData;
    const arrayValues =
      reqData.type === 'filter' ? filtervalues.filtervalues : filtervalues;
    let orderBy = '';
    arrayValues.forEach(item => {
      logger.info('item', item);
      if (item.type === 'orderby') {
        const splitOperator = item.operator.split(' ');
        logger.info(splitOperator, 'splitOperator');
        orderBy =
          splitOperator &&
          `${splitOperator[0]} ${splitOperator[1]} ${item.value.toString()} ${
            splitOperator[splitOperator.length - 1]
          }`;
      }
    });
    const values = [];
    const sql = `with cte as (SELECT DISTINCT ON (wms_workflow_eventlog.wfeventid) wms_workorder_service.baseduid,
    wms_workorder_service.assignedduid,
    wms_workorder_service.serviceid,
    wms_workorder_service.wfid,
    wms_workflow.config AS wfconfig,
    wms_workflow.wf_definitionid,
    wms_workorder.jobtype,
    wms_workorder.wotype,
    wms_mst_service.servicename,
    org_mst_deliveryunit.duname AS assignedduname,
    wms_workflow_eventlog.wfeventid,
    wms_workflow_eventlog.userid,
    wms_workflow_eventlog.skillid,
    wms_workflow_eventlog.wfdefid,
    wms_workflow_eventlog.activitystatus,
    wms_workflow_eventlog.createdon as createddate,
    wms_workflow_eventlog.activityinstanceid,
    wms_workflow_eventlog.taskinstanceid,
    wms_workflow_eventlog.stageiterationcount,
    wms_workflow_eventlog.activityiterationcount,
    wms_workflow_eventlog.priority,
    wms_workflow_eventlog.activitycount,
    wms_workflow_eventlog.eventdata,
    wms_workflow_eventlog.parentinstanceid,
    wms_workflow_eventlog.actualactivitycount,
    wms_mst_priority.priority AS priorityname,
    wms_workorder.workorderid,
    wms_workorder.customerid,
    org_mst_customer.customername,
    wms_workorder.itemcode,
    wms_workorder.title,
    wms_workorder.printisbn,
    wms_workorder.totalchaptercount,
    wms_workflowdefinition.activityalias,
    wms_workflowdefinition.stageid,
    wms_workflowdefinition.activityid,
    wms_workflowdefinition.instancetype,
    wms_workflowdefinition.formjson,
    wms_workflowdefinition.config,
    wms_workflowdefinition.fileconfig,
    wms_workflowdefinition.itracksconfig,
    wms_workflowdefinition.toolrunningstatus,
    wms_workflowdefinition.rejectedactivitytype,
    wms_workflowdefinition.activitymodeltype,
    wms_workflowdefinition.activitymodeltypeflow,
    wms_workflowdefinition.sequence,
    wms_user.username,
    wms_workorder_incomingfiledetails.filename,
    coalesce(wms_workorder_stage.revisedenddatetime, wms_workorder_stage.plannedenddate) AS duedate,
    pp_mst_filetype.filetype,
    wms_workorder_incomingfiledetails.mspages,
    wms_workorder_incomingfiledetails.estimatedpages,
    wms_workorder_incomingfiledetails.imagecount,
    wms_workorder_incomingfiledetails.tablecount,
    wms_workorder_incomingfiledetails.equationcount,
    wms_workorder_incomingfiledetails.newfiletype,
    wms_workorder_incomingfiledetails.filetypeid,
    wms_userrole.roleid,
    wms_workorder.doinumber,
    pp_mst_journal.journalacronym,
    pp_mst_journal.pdfmerging,
    wms_workflowdefinition.activitytype,
    dms_master.dmstype,
    wms_mst_stage.stagename,
    wms_mst_activity.activityname,
    wms_mst_screens.screenmappingpath AS screenpath,
    wms_mst_activity.isdespatchactivity,
    wms_mst_activity.iscompletiontriggeractivity,
    wms_mst_complexity.complexityid,
    wms_mst_complexity.complexity,
    wms_mst_jobnorms.jobnormsid,
    wms_mst_jobnorms.jobnormsname,
    wms_workorder.journalid,
    wms_workorder.divisionid,
    wms_workorder.subdivisionid,
    org_mst_deliveryunit.duid,
    wms_workorder.jobcardid,
    wms_workorder_incomingfiledetails.subjobid,
    wms_workorder_stage.typesetpages,
    wms_workflow_eventlog.worksheetid,
    wms_workorder_incomingfiledetails.woincomingfileid,
    wms_workorder.hardbackisbn,
    wms_workflowdefinition.resettoactivityid,
    wms_workflow_eventlog.isinstancerunning,
    wms_workorder.otherfield
   FROM wms_workorder_service
     JOIN wms_workflow_eventlog ON wms_workflow_eventlog.workorderid = wms_workorder_service.workorderid
     JOIN wms_workorder ON wms_workorder.workorderid = wms_workflow_eventlog.workorderid AND wms_workorder.isactive <> false
     LEFT JOIN wms_user ON wms_user.userid::text = wms_workflow_eventlog.userid::text
     JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
     JOIN wms_workorder_stage ON wms_workorder_stage.workorderid = wms_workflow_eventlog.workorderid AND wms_workorder_stage.serviceid = wms_workflow_eventlog.serviceid AND wms_workorder_stage.wfstageid = wms_workflowdefinition.stageid AND wms_workorder_stage.stageiterationcount = wms_workflow_eventlog.stageiterationcount
     JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = wms_workorder_service.assignedduid AND (org_mst_deliveryunit.duid = wms_user.duid OR wms_user.duid IS NULL)
     JOIN wms_mst_service ON wms_mst_service.serviceid = wms_workorder_service.serviceid
     JOIN wms_workflow ON wms_workflow.wfid = wms_workorder_service.wfid
     JOIN org_mst_customer ON org_mst_customer.customerid = wms_workorder.customerid
     LEFT JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workflowdefinition.stageid
     LEFT JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
     LEFT JOIN wms_mst_screens ON wms_mst_screens.screenid = wms_workflowdefinition.screenid
     LEFT JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingfileid = wms_workflow_eventlog.woincomingfileid
     LEFT JOIN wms_mst_priority ON wms_mst_priority.priorityid = wms_workflow_eventlog.priority
     LEFT JOIN pp_mst_filetype ON pp_mst_filetype.filetypeid::text = wms_workorder_incomingfiledetails.filetypeid::text
     LEFT JOIN wms_userrole ON wms_userrole.userid::text = wms_workflow_eventlog.userid::text
     LEFT JOIN pp_mst_journal ON pp_mst_journal.journalid = wms_workorder.journalid
     LEFT JOIN wms_mst_jobnorms ON wms_mst_jobnorms.jobnormsid = wms_workorder_service.jobnormsid
     LEFT JOIN wms_mst_complexity ON wms_mst_complexity.complexityid = wms_workorder_service.complexityid
     LEFT JOIN dms_master ON dms_master.dmsid = wms_workorder.dmsid WHERE (wms_workorder_service.baseduid IN (${
       reqData.duId
     }) OR wms_workorder_service.assignedduid IN (${reqData.duId}))  ${
      skills
        ? `AND wms_workflow_eventlog.skillid IN (${skills})) select * from cte`
        : ''
    }  ${condition ? `${'where '}${condition}` : ''} ${orderBy} `;

    logger.info(sql, 'sqlsqlsqlsql');
    const data = await query(sql, values);
    // updated for fileconfig restructure
    data.forEach(item => {
      item.fileconfig = ReStructureFileConfig(item.fileconfig);
    });
    resolve(data);
  });
};

export const assigneeList = (req, res) => {
  const reqData = req.body;
  const sql = `SELECT DISTINCT ON (wms_user.userid) wms_user.userid as value, CONCAT(wms_user.username, ' (', wms_user.userid, ')') as label FROM public.wms_user 
    JOIN wms_userskill ON wms_userskill.userid = wms_user.userid 
    JOIN wms_userrole ON wms_userrole.userid = wms_user.userid 
    WHERE duid=${reqData.duId} AND wms_userskill.skillid IN (${reqData.skillid}) AND wms_userrole.roleid = 3 AND wms_userrole.isactive = true AND wms_userskill.isactive = true `;
  logger.info(sql, 'sqlsql');

  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const saveView = async (req, res) => {
  const {
    userid,
    entityId,
    viewname,
    viewtype,
    filtervalues,
    columnfields,
    screenId,
  } = req.body;
  try {
    await transaction(async client => {
      let sql = `INSERT INTO public.wms_mst_view_config(
            userid, entityid, viewname, viewtype, filtervalues, columnfields, screenId)
            VALUES ($1, $2, $3, $4, $5, $6, $7) returning viewid`;
      const {
        rows: [data],
      } = await client.query(sql, [
        userid,
        entityId,
        viewname,
        viewtype,
        JSON.stringify(filtervalues),
        JSON.stringify(columnfields),
        screenId,
      ]);
      sql = `INSERT INTO public.wms_viewconfig_permissions(
                 viewid, roleid, skillid)
                VALUES ($1, $2, $3);`;
      await client.query(sql, [data.viewid, null, null]);
      res.status(200).json({ message: 'View has been saved successfully' });
    });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const deleteView = async (req, res) => {
  const { viewid } = req.body;
  try {
    await transaction(async client => {
      let sql = `DELETE FROM wms_viewconfig_permissions WHERE viewid = $1`;
      await client.query(sql, [viewid]);
      sql = `DELETE FROM wms_mst_view_config WHERE viewid = $1`;
      await client.query(sql, [viewid]);
      res.status(200).json({ message: 'View deleted successfully' });
    });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};

export const getFilteredList = (req, res) => {
  const reqData = req.body;
  let condition = '';
  if (
    reqData.type === 'all' ||
    reqData.type === 'myTask' ||
    reqData.type === 'despatch' ||
    reqData.type === 'workorder'
  ) {
    logger.info(reqData.filtervalues, reqData.type, 'searchobjforfilter');
    const { filtervalues } = reqData;

    const getNotInArray = filtervalues.filter(
      data => data.type === 'where' && data.operator !== 'IN',
    );
    const seen = {};
    const resultOfgroupBy = filtervalues.filter(entry => {
      if (entry.operator === 'IN') {
        let previous;
        if (Object.prototype.hasOwnProperty.call(seen, entry.name)) {
          previous = seen[entry.name];
          previous.value.push(entry.value);
          return false;
        }
        if (!Array.isArray(entry.value)) {
          entry.value = [entry.value];
        }
        seen[entry.name] = entry;
        return true;
      }
      return false;
    });
    logger.info(resultOfgroupBy, 'resultOfgroupBy');
    const mergedArray = [].concat(getNotInArray, resultOfgroupBy);
    mergedArray.forEach((item, i) => {
      if (item.type === 'where') {
        let statusValue = '';
        if (Array.isArray(item.value)) {
          item.value.forEach((status, vi) => {
            statusValue +=
              item.value.length - 1 !== vi ? `'${status}' ,` : `'${status}'`;
          });
        }
        condition +=
          mergedArray.length - 1 !== i
            ? Array.isArray(item.value)
              ? `${item.name} ${item.operator} (${statusValue})  AND `
              : item.value === ''
              ? `${item.name} ${item.operator} AND `
              : `${item.name} ${item.operator} ${
                  item.operator === 'IN'
                    ? `('${item.value}')`
                    : `'${item.value}'`
                } AND `
            : Array.isArray(item.value)
            ? `${item.name} ${item.operator} (${statusValue})`
            : item.value === ''
            ? `${item.name} ${item.operator} `
            : `${item.name} ${item.operator} ${
                item.operator === 'IN' ? `('${item.value}')` : `'${item.value}'`
              }  `;
      }
    });

    logger.info(condition, 'conditonforfiltered');
  }

  const condition1 = `LOWER(${
    reqData.columnName
  }) like '%${reqData.text.toLowerCase()}%'`;
  let skills = '';

  let sql = '';
  if (reqData.type !== 'query') {
    reqData.skillid.forEach((skill, i) => {
      skills += `'${skill}' ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
    });
    sql = `SELECT DISTINCT ${
      reqData.columnName
    } FROM public.wms_tasklist WHERE ${condition1} AND (baseduid IN (${
      reqData.duId
    }) OR assignedduid IN (${reqData.duId})) AND skillid IN (${skills})  ${
      condition ? `${'AND '}${condition}` : ''
    } ORDER BY ${reqData.columnName} ASC`;
    logger.info(sql, 'sqlforfilteredvalues');
  } else {
    reqData.skillid.forEach((skill, i) => {
      skills += `${skill} ${reqData.skillid.length - 1 !== i ? ',' : ''}`;
    });
    sql = `SELECT DISTINCT ${reqData.columnName} FROM public.wms_workorder_query_list where querystatus in ('Open','Re-open') and duid in (${reqData.duId}) and (queryid in
        (select queryid from wms_query_assigned where skillid in (${skills})) or createdby='${reqData.userid}') and ${condition1}`;
  }
  console.log(sql);
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const test1 = (req, res) => {
  const getData = req.body;
  let condition = '';
  getData.filterObj.forEach((item, i) => {
    condition +=
      getData.filterObj.length - 1 !== i
        ? `${item.name} = '${item.value}' AND `
        : `${item.name} = '${item.value}'`;
  });
  logger.info(condition, 'setCondition');

  const sql = `SELECT * FROM public.wms_tasklist WHERE ${condition}`;
  logger.info(sql, 'sql');

  query(sql)
    .then(data => {
      // updated for fileconfig restructure
      data.forEach(item => {
        item.fileconfig = ReStructureFileConfig(item.fileconfig);
      });
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getPriorityList = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `SELECT priorityid as value, priority as label FROM wms_mst_priority`;
  query(sql)
    .then(response => {
      logger.info('responsesss', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
