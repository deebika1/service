import { query } from '../../../database/postgres.js';
import { buildConfig } from '../../../httpClient/builder.js';
import logger from '../logs/index.js';
import { emitEvent } from '../../../socket/index.js';

export const createAPIRequestId = async (req, res) => {
  try {
    const {
      wfeventId,
      toolsId,
      isForegroundService,
      userId,
      actualActivityCount,
    } = req.body;
    const apiId = await _createAPIRequestId({
      wfeventId,
      toolsId,
      isForegroundService,
      userId,
      actualActivityCount,
    });
    res.status(200).json(apiId);
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _createAPIRequestId = ({
  wfeventId,
  toolsId,
  isForegroundService,
  userId,
  actualActivityCount,
}) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `INSERT INTO wms_tools_api(wfeventid, toolid, status, isforegroundservice, userid, actualactivitycount) VALUES ($1, $2, $3, $4, $5,$6) returning apiid`;
      const [{ apiid: apiId }] = await query(sql, [
        wfeventId,
        toolsId,
        'InProgress',
        isForegroundService,
        userId,
        actualActivityCount,
      ]);

      const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
      await query(sql1, [
        apiId,
        wfeventId,
        toolsId,
        'Created',
        new Date(),
        userId,
      ]);
      resolve(apiId);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const updateAPIRequestId = async (req, res) => {
  try {
    const { apiId, inputParams } = req.body;
    await _updateAPIRequestId({ apiId, inputParams });
    res.status(200).send(true);
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _updateAPIRequestId = ({ apiId, inputParams }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `UPDATE wms_tools_api SET inputparams = $1, status = $2, starttime =$3 WHERE apiid = $4 returning apiid, wfeventid,toolid,userid`;
      const [{ wfeventid: wfeventId, toolid: toolsId, userid: userId }] =
        await query(sql, [inputParams, 'InProgress', new Date(), apiId]);
      if (wfeventId && toolsId && userId) {
        const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
        await query(sql1, [
          apiId,
          wfeventId,
          toolsId,
          'InProgress',
          new Date(),
          userId,
        ]);
      }
      logger.info(apiId, 'updated tools output');

      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const _updatePitstopProfile = ({ apiId, pitstopPath }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `UPDATE wms_tools_api SET profilepath = $1 WHERE apiid = $2 returning toolid`;
      const [{ toolid: toolsId }] = await query(sql, [pitstopPath, apiId]);
      logger.info(apiId, 'updated tools output');
      console.log('toolid', toolsId);
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};
export const _updateIntermediateAPIRequestId = ({ apiId }) => {
  logger.info(apiId, 'apiId');
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `UPDATE wms_tools_api SET status = $1, remarks = $2 WHERE apiid = $3 returning apiid, wfeventid,toolid,userid`;
      const [{ wfeventid: wfeventId, toolid: toolsId, userid: userId }] =
        await query(sql, ['Failure', 'Due to Max Retry exhausted', apiId]);
      if (wfeventId && toolsId && userId) {
        const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
        await query(sql1, [
          apiId,
          wfeventId,
          toolsId,
          'Failure',
          new Date(),
          userId,
        ]);
      }
      logger.info(apiId, 'updated intermediate tools output');
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const completeAPIRequestId = async (req, res) => {
  try {
    const {
      apiId,
      status,
      remarks,
      response = {},
      sId,
      tooloutputid,
      isFileAvailable,
      actualActivityCount,
    } = req.body;
    const apiDetails = await _completeAPIRequestId({
      apiId,
      status,
      remarks,
      response,
      sId,
      tooloutputid,
      isFileAvailable,
      actualActivityCount,
    });
    res.status(200).send(apiDetails);
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _completeAPIRequestId = ({
  apiId,
  onSave,
  status,
  remarks,
  response = {},
  sId,
  tooloutputid = '',
  isFileAvailable = true,
  actualActivityCount,
}) => {
  logger.info(sId, `inside complete API Tool${tooloutputid}`);
  return new Promise(async (resolve, reject) => {
    try {
      let getToolsEntry = [];
      const sql = `UPDATE wms_tools_api SET status = $1, endtime = $2, remarks = $3, response = $4, isfileavailable=$6 WHERE apiid = $5 returning wfeventid, isforegroundservice, toolid,userid`;
      const [
        {
          wfeventid: wfeventId,
          isforegroundservice: isForegroundService,
          toolid: toolsId,
          userid: userId,
        },
      ] = await query(sql, [
        status,
        new Date(),
        remarks,
        response,
        apiId,
        isFileAvailable,
      ]);

      logger.info(apiId, 'apiId');
      logger.info(wfeventId, 'wfeventId');
      logger.info(toolsId, 'toolsId');
      logger.info(status, 'status');
      logger.info(userId, 'userId', actualActivityCount);
      if (wfeventId && toolsId && userId) {
        const sql1 = `INSERT INTO wms_tools_api_audit(apiid,wfeventid, toolid, status,timestamp,userid) VALUES ($1, $2, $3, $4, $5,$6)`;
        await query(sql1, [
          apiId,
          wfeventId,
          toolsId,
          status,
          new Date(),
          userId,
        ]);
      }
      logger.info(sId, 'complete API Tool query');
      // send signal for complete
      if (remarks !== 'On save validation failed' && onSave != true) {
        emitEvent(sId, 'okmStatus', {
          data: { toolid: toolsId, response, remarks },
          status,
          isToolCompleted: status === 'Success',
        });
      }
      // const sql2 = `SELECT * FROM  wms_tools_api  WHERE wfeventid = $1 `;
      const sql2 = `SELECT tool.apiid,tool.wfeventid,tool.toolid,tool.inputparams,tool.status,tool.starttime,tool.endtime,tool.isforegroundservice,tool.userid,tool.remarks,tool.response,eventlog.workorderid,eventlog.wfdefid,wfdef.activitytype,tool.isfileavailable FROM public.wms_tools_api as tool
            join wms_workflow_eventlog as eventlog on eventlog.wfeventid = tool.wfeventid
            join wms_workflowdefinition as wfdef on wfdef.wfdefid = eventlog.wfdefid
             WHERE tool.wfeventid = $1 and tool.actualactivitycount = $2`;
      getToolsEntry = await query(sql2, [wfeventId, actualActivityCount]);
      console.log(getToolsEntry, 'getToolsEntry');
      resolve({
        wfeventId,
        isForegroundService,
        toolsId,
        getToolsEntry,
      });
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const buildApiConfig = async (req, res) => {
  try {
    const { iwms, files, apiConfig, basePath } = req.body;
    const config = await _buildApiConfig(iwms, files, apiConfig, basePath);
    res.status(200).send(config);
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _buildApiConfig = (iwms, files, apiConfig, basePath = '') => {
  return new Promise(async (resolve, reject) => {
    try {
      apiConfig.input = apiConfig.input ? apiConfig.input : {};
      apiConfig.input.rawData = apiConfig.input.rawData
        ? apiConfig.input.rawData
        : {};
      apiConfig.input.rawData.files = files;
      apiConfig.input.rawData.iwms = iwms;
      apiConfig.url = basePath ? basePath + apiConfig.url : apiConfig.url;
      const config = buildConfig(apiConfig);
      resolve(config);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getToolsStatusForServiceTask = async (req, res) => {
  try {
    const { wfeventId, toolId } = req.body;
    logger.info(wfeventId, toolId, 'start pooling initiated');
    const response = await startPollingForServiceUserTask(wfeventId, toolId);
    res.status(200).send(response);
  } catch (e) {
    logger.info(e, 'start pooling failed 1 ');
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getToolsStatusForAsync = (wfeventId, toolId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT * FROM public.wms_tools_api where wfeventid=$1 and toolid =$2 order by apiid desc limit 1`;
      const toolStatus = await query(sql, [wfeventId, toolId]);
      logger.info(toolStatus, 'tool status for service to user task');
      resolve(toolStatus);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const startPollingForServiceUserTask = async (wfeventId, toolId) => {
  logger.info('Pooling Started');
  return new Promise(async (resolve, reject) => {
    try {
      const entries = await getToolsStatusForAsync(wfeventId, toolId);
      logger.info(entries, 'TOOLS service to user task');
      if (
        (entries && entries.length > 0 && entries[0].status === 'Success') ||
        (entries && entries.length > 0 && entries[0].status === 'Failure')
      ) {
        logger.info(entries, 'TOOLS service to user task 3 success or failure');
        resolve(entries);
      } else {
        resolve(entries);
      }
    } catch (e) {
      reject(e);
      logger.info(e, 'startPolling error');
    }
  });
};
