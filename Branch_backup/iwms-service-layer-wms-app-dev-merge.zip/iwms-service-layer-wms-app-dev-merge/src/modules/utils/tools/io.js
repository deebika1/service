import { basename, join } from 'path';
import micromatch from 'micromatch';
import { getFolderStructure } from '../wmsFolder/index.js';
import { getFormattedName } from '../fileValidation/utils.js';
import {
  _getUuid,
  _isFileExist,
  _deleteFile,
  folderRename,
  folderDelete,
  getFolderChildrenProperties,
  folderCreate,
  copyFolderExtendedCopy,
  ListAllChildDocument,
  _copyFile,
} from '../okm/index.js';
import * as azureHelper from '../azure/index.js';
import * as localHelper from '../local/index.js';
import { getdmsType } from '../../bpmn/listener/create.js';

export const azureFolderCopy = async payload => {
  return new Promise(async (resolve, reject) => {
    let { destinationPath, sourcePath } = payload;
    const { isMultiple, woincomingFileId } = payload;
    try {
      if (isMultiple == true) {
        destinationPath += woincomingFileId;
        sourcePath += woincomingFileId;
      }
      let awt = [];
      awt.push(azureHelper._listAllFiles(sourcePath));
      awt.push(azureHelper._listAllFiles(destinationPath));
      const output = await Promise.all(awt);
      const toCopyFile = output[0];
      const toSkipFile = output[1];
      awt = [];
      toCopyFile.forEach(x => {
        if (
          toSkipFile.filter(
            y =>
              y.path.replace(destinationPath, '') ==
              x.path.replace(sourcePath, ''),
          ).length == 0
        ) {
          awt.push(
            azureHelper._copyFile({
              srcPath: x.path,
              name: x.path.replace(sourcePath, ''),
              destBasePath: destinationPath,
            }),
          );
        }
      });
      await Promise.all(awt);
      awt = [];
      awt.push(azureHelper._listAllFiles(destinationPath));
      awt.push(azureHelper._listAllFiles(sourcePath));
      const out = await Promise.all(awt);
      const existInDestination = out[0];
      const toCopyFiles = out[1];
      existInDestination.forEach(x => {
        x.filePath = x.path.replace(destinationPath, '');
      });
      toCopyFiles.forEach(x => {
        x.filePath = x.path.replace(sourcePath, '');
      });
      existInDestination.forEach(file => {
        file.name = basename(file.path);
        const filterSource = toCopyFiles.filter(
          x => x.filePath == file.filePath,
        );
        file.oldPath = filterSource.length > 0 ? filterSource[0].path : '';
        file.olduuid = 'azure';
      });
      resolve(existInDestination);
    } catch (error) {
      reject(error);
    }
  });
};

export const localFolderCopy = async payload => {
  return new Promise(async (resolve, reject) => {
    let { destinationPath, sourcePath } = payload;
    const { isMultiple, woincomingFileId } = payload;
    try {
      if (isMultiple == true) {
        destinationPath += woincomingFileId;
        sourcePath += woincomingFileId;
      }
      let awt = [];
      awt.push(localHelper._locallistAllFiles(sourcePath));
      awt.push(localHelper._locallistAllFiles(destinationPath));
      const output = await Promise.all(awt);
      const toCopyFile = output[0];
      const toSkipFile = output[1];
      awt = [];
      toCopyFile.forEach(x => {
        if (
          toSkipFile.filter(
            y =>
              y.path.replace(destinationPath, '') ==
              x.path.replace(sourcePath, ''),
          ).length == 0
        ) {
          awt.push(
            localHelper._localcopyFile({
              srcPath: x.path,
              name: x.path.replace(sourcePath, ''),
              destBasePath: destinationPath,
            }),
          );
        }
      });
      await Promise.all(awt);
      awt = [];
      awt.push(localHelper._locallistAllFiles(destinationPath));
      awt.push(localHelper._locallistAllFiles(sourcePath));
      const out = await Promise.all(awt);
      const existInDestination = out[0];
      const toCopyFiles = out[1];
      existInDestination.forEach(x => {
        x.filePath = x.path.replace(destinationPath, '');
      });
      toCopyFiles.forEach(x => {
        x.filePath = x.path.replace(sourcePath, '');
      });
      existInDestination.forEach(file => {
        file.name = basename(file.path);
        const filterSource = toCopyFiles.filter(
          x => x.filePath == file.filePath,
        );
        file.oldPath = filterSource.length > 0 ? filterSource[0].path : '';
        file.olduuid = 'azure';
      });
      resolve(existInDestination);
    } catch (error) {
      reject(error);
    }
  });
};

export const okmFolderCopy = async payload => {
  return new Promise(async (resolve, reject) => {
    let { destinationPath } = payload;
    const { sourcePath, isMultiple, woincomingFileId } = payload;
    try {
      const _destinationPath = destinationPath;
      let destinationPathUUID;
      let sourcePathUUID;
      let _destinationPathUUIDTemp;
      if (isMultiple == true) {
        destinationPath += woincomingFileId;
      }
      let awaits = [];
      awaits.push(_getUuid(_destinationPath).catch(() => {}));
      awaits.push(
        _getUuid(destinationPath)
          .then(uuid => {
            destinationPathUUID = uuid;
          })
          .catch(() => {
            destinationPathUUID = undefined;
          }),
      );
      awaits.push(
        _getUuid(`${destinationPath}temp`)
          .then(uuid => {
            _destinationPathUUIDTemp = uuid;
          })
          .catch(() => {
            _destinationPathUUIDTemp = undefined;
          }),
      );
      awaits.push(
        _getUuid(sourcePath).then(uuid => {
          sourcePathUUID = uuid;
        }),
      );
      await Promise.all(awaits);
      let listTempFile = [];
      let listFile = [];
      if (destinationPathUUID != undefined) {
        if (_destinationPathUUIDTemp != undefined) {
          await folderDelete(_destinationPathUUIDTemp);
        }
        await folderRename(
          destinationPathUUID,
          basename(`${destinationPath}temp`),
        );
        listTempFile = await ListAllChildDocument(`${destinationPath}temp`);
      }
      destinationPathUUID = await folderCreate(_destinationPath);
      let childFolders = await getFolderChildrenProperties(sourcePathUUID);
      childFolders = Array.isArray(childFolders)
        ? childFolders
        : [childFolders];
      awaits = [];
      if (isMultiple == true) {
        childFolders = childFolders.filter(x =>
          x.path.endsWith(woincomingFileId),
        );
      }
      childFolders.forEach(child => {
        awaits.push(copyFolderExtendedCopy(child.uuid, destinationPathUUID));
      });
      await Promise.all(awaits);

      listFile = await ListAllChildDocument(destinationPath);
      const FileToDelete = [];
      listFile.forEach(ele => {
        if (
          listTempFile.filter(
            x =>
              x.path.replace(`${destinationPath}temp`, '') ==
              ele.path.replace(destinationPath, ''),
          ).length > 0
        ) {
          FileToDelete.push(ele);
        }
      });
      awaits = [];
      FileToDelete.forEach(ele => {
        awaits.push(_deleteFile(ele.uuid));
      });
      await Promise.all(awaits);
      awaits = [];
      listTempFile.forEach(ele => {
        awaits.push(
          replaceFiles(ele, destinationPath, `${destinationPath}temp`),
        );
      });
      await Promise.all(awaits);
      await _getUuid(`${destinationPath}temp`)
        .then(uuid => {
          _destinationPathUUIDTemp = uuid;
        })
        .catch(() => {
          _destinationPathUUIDTemp = undefined;
        });
      await folderDelete(_destinationPathUUIDTemp);
      awaits = [];
      // awaits.push(retreiveOKMFiles(destinationPath));
      awaits.push(ListAllChildDocument(destinationPath));

      if (isMultiple == true) {
        // awaits.push(retreiveOKMFiles(sourcePath + woincomingFileId));
        awaits.push(ListAllChildDocument(sourcePath + woincomingFileId));
      } else {
        // awaits.push(retreiveOKMFiles(sourcePath));
        awaits.push(ListAllChildDocument(sourcePath));
      }
      const FileDetails = await Promise.all(awaits);
      const files = FileDetails[0];
      const sourceFiles = FileDetails[1];
      sourceFiles.forEach(file => {
        file.name = basename(file.path);
      });
      files.forEach(file => {
        file.name = basename(file.path);
        const filterSource = sourceFiles.filter(x => x.name == file.name);
        file.oldPath = filterSource.length > 0 ? filterSource[0].path : '';
        file.olduuid = filterSource.length > 0 ? filterSource[0].uuid : '';
      });
      const replaceFiles = async (file, destpth, srcpth) => {
        let destinationUUID;
        const Pth = file.path.replace(srcpth, '');
        destpth = (destpth + Pth).replace(basename(file.path), '');
        await _getUuid(destpth)
          .then(uuid => {
            destinationUUID = uuid;
          })
          .catch(() => {
            destinationUUID = undefined;
          });
        if (destinationUUID == undefined) {
          destinationUUID = await folderCreate(destpth);
        }
        await _copyFile({
          src: file.uuid,
          dest: destinationUUID,
          name: basename(file.path),
          destBasePath: destpth,
        });
      };
      resolve(files);
    } catch (error) {
      reject(error);
    }
  });
};

export const getFilesData = async ({
  dmsType,
  workorderDetails,
  IOFiles,
  isInputProcessing = true,
  fileDetails,
  placeHolders,
}) => {
  IOFiles = IOFiles || {};
  if (dmsType == undefined) {
    dmsType = await getdmsType(workorderDetails.workOrderId);
  }
  const files = []; // isInputProcessing ? {} : [];
  const { stage, activity, service, du, customer, workOrderId, fileId } =
    workorderDetails;
  const ioKeys = Object.keys(IOFiles);
  for (let i = 0; i < ioKeys.length; i++) {
    const ioKey = ioKeys[i];
    const ioFile = IOFiles[ioKey];
    const { name, aliasKey } = ioFile;
    let { typeId, pitstopProfile } = ioFile;
    const { fileTypes } = ioFile;
    const fTypeName = ioFile.fileTypeName;
    typeId = fileTypes instanceof Array ? fileTypes : [fileTypes];
    const isArray = !!ioFile.isArray;
    pitstopProfile = !!pitstopProfile;
    const formattedFTypeName = fTypeName
      ? getFormattedName(fTypeName, placeHolders)
      : '';
    const formattedFTypeNameRegex = new RegExp(formattedFTypeName);
    const filteredfileDetails = fileDetails.filter(fd => {
      const formattedFTypeNameResult = fd.name.match(formattedFTypeNameRegex);
      const isTypeNameMatched = fTypeName
        ? formattedFTypeNameResult
          ? formattedFTypeNameResult[0] == fd.name
          : false
        : true;
      return (
        typeId.includes(parseInt(fd.typeId)) &&
        isTypeNameMatched &&
        (fileId && fd.allowSubFileType ? fd.incomingFileId == fileId : true)
      );
    });
    if (filteredfileDetails.length) {
      files[ioKey] = isArray || !isInputProcessing ? [] : {};
      for (let j = 0; j < filteredfileDetails.length; j++) {
        let actualPath = '';
        const {
          incomingFileId,
          newfiletype,
          singlepdfmerge,
          type,
          typeId: typeid,
          name: fileName,
          allowSubFileType,
          pageRange,
          pitstopProfilePath,
          files: IFiles,
        } = filteredfileDetails[j];
        let path = await getFolderStructure({
          type: allowSubFileType
            ? 'wo_activity_file_subtype'
            : 'wo_activity_filetype',
          fileType: {
            name: type,
            id: typeid,
            fileId: incomingFileId,
          },
          du,
          customer,
          stage,
          activity,
          service,
          workOrderId,
        });
        console.log(placeHolders);
        const springerZipFileName =
          IFiles.length > 0 ? IFiles[0].newfilename : '';
        placeHolders.zipFileName = springerZipFileName;
        placeHolders.articletype = (
          (placeHolders.ArticleTypeList || [])
            .filter(x => x.FileTypeName == fileName)
            .pop() || {}
        ).articletype;
        // let piivalue = await _getFileNameForPii(workOrderId, fileName);
        const piivalue = (
          (placeHolders.ArticleTypeList || [])
            .filter(x => x.FileTypeName == fileName)
            .pop() || {}
        ).piinumber;
        const formattedName = getFormattedName(name, {
          ...placeHolders,
          JnlTypeFileTypeName: fileName + placeHolders.JnlTypeFileName,
          FileTypeName: fileName,
          PageRange: pageRange,
          IssuePII: piivalue,
        });
        actualPath = path;
        if (path.substring(0, 2) === '//') {
          path = `/${join(path, formattedName).replace(/\\/g, '/')}`;
          path = path.substring(0, 3) === '///' ? path.slice(1) : path;
        } else {
          path = join(path, formattedName).replace(/\\/g, '/');
        }
        if (isInputProcessing) {
          const isFolder = path[path.length - 1] == '/';
          let srcFiles = isFolder
            ? [path]
            : micromatch(
                IFiles.map(f => f.path),
                path,
              );
          srcFiles = srcFiles.length ? srcFiles : [path];
          if (isArray) {
            files[ioKey] = [
              ...files[ioKey],
              ...srcFiles.map(srcFile => {
                const data = {
                  path: srcFile,
                  actualPath,
                  aliasKey,
                  fileId: incomingFileId,
                  fileName,
                  fileType: type,
                  newfiletype,
                  singlepdfmerge,
                };
                if (pitstopProfile)
                  data.pitstopProfile = pitstopProfilePath || '';
                return data;
              }),
            ];
          } else {
            const data = {
              actualPath,
              aliasKey,
              path: srcFiles[0],
              fileId: incomingFileId,
              fileName,
              fileType: type,
            };
            if (Object.keys(data).length && pitstopProfile)
              data.pitstopProfile = pitstopProfilePath || '';
            files[ioKey] = data;
            break;
          }
        } else {
          const isFolder = path[path.length - 1] == '/';
          if (isFolder) {
            // const retreivedFiles = await retreiveOKMFiles(path);

            let retreivedFiles = [];
            switch (dmsType) {
              case 'azure':
                retreivedFiles = await azureHelper._listAllFiles(path);
                break;
              case 'local':
                retreivedFiles = await localHelper._locallistAllFiles(path);
                break;
              default:
                retreivedFiles = await ListAllChildDocument(path);
                break;
            }

            for (let index = 0; index < retreivedFiles.length; index++) {
              const retreivedFile = retreivedFiles[index];
              const data = {
                actualPath,
                aliasKey,
                path: retreivedFile.path,
                uuid: retreivedFile.uuid,
                fileId: incomingFileId,
              };
              files[ioKey].push(data);
            }
          } else {
            let fileData = {};
            switch (dmsType) {
              case 'azure':
                fileData = { isExist: true, uuid: 'azure' };
                break;
              case 'local':
                fileData = { isExist: true, uuid: 'local' };
                break;
              default:
                fileData = await _isFileExist(path);
                break;
            }

            // to get the files from the folder which has * in the name
            const patternForFindStar = /(?:\*)/;
            if (patternForFindStar.test(name)) {
              path = path.substring(0, path.lastIndexOf('/'));
              let retreivedFiles = [];
              switch (dmsType) {
                case 'azure':
                  retreivedFiles = await azureHelper._listAllFiles(path);
                  break;
                case 'local':
                  retreivedFiles = await localHelper._locallistAllFiles(path);
                  break;
                default:
                  retreivedFiles = await ListAllChildDocument(path);
                  break;
              }

              for (let index = 0; index < retreivedFiles.length; index++) {
                const retreivedFile = retreivedFiles[index];
                // get the extension from the path
                const extension = basename(retreivedFile.path).split('.')[
                  basename(retreivedFile.path).split('.').length - 1
                ];
                if (extension === name.split('.')[name.split('.').length - 1]) {
                  const data = {
                    actualPath,
                    aliasKey,
                    path: retreivedFile.path,
                    uuid: retreivedFile.uuid,
                    fileId: incomingFileId,
                  };
                  files[ioKey].push(data);
                }
              }
            } else {
              const data = {
                path,
                actualPath,
                aliasKey,
                uuid: fileData.isExist ? fileData.uuid : undefined,
                fileId: incomingFileId,
              };
              files[ioKey].push(data);
            }
          }
        }
      }
    }
  }
  return files;
};

export const getFileTrnData = async (outputFiles, fileTrnDetails, dmsType) => {
  const files = [];
  const ioKeys = Object.keys(outputFiles);
  for (let i = 0; i < ioKeys.length; i++) {
    const ioKey = ioKeys[i];
    const ioFiles = outputFiles[ioKey];
    for (let j = 0; j < ioFiles.length; j++) {
      const { path, uuid, fileId } = ioFiles[j];
      let retreivedFiles = [];
      if (dmsType === 'openkm') {
        if (uuid && !fileTrnDetails.some(file => file.repofileuuid == uuid))
          files.push({ path, uuid, fileId });
      } else if (!fileTrnDetails.some(file => file.repofilepath == path)) {
        switch (dmsType) {
          case 'azure':
            retreivedFiles = await azureHelper._blobExist(path);
            break;
          case 'local':
            retreivedFiles = await localHelper._islocalFileExist(path);
            break;
          default:
            files.push({ path, uuid: 'azure', fileId });
            break;
        }
        if (
          Object.keys(retreivedFiles).includes('exist') &&
          retreivedFiles.exist
        ) {
          files.push({ path, uuid: dmsType, fileId });
        }
      }
    }
  }
  return files;
};
