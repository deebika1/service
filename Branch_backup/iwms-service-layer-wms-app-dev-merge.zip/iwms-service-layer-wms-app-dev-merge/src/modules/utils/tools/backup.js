import logger from '../logs/index.js';
import { query } from '../../../database/postgres.js';

export const updateBackupFile = async (req, res) => {
  try {
    logger.info(req.body, 'backup process.');
    const { wfeventid, filename, path, rowlimit } = req.body;
    const sql = `select public.insert_backupfiles(${wfeventid}, '${filename}', '${path}', ${rowlimit})`;
    await query(sql);
    res.status(200).send({ issuccess: true, message: 'Backup Successfull.' });
  } catch (e) {
    logger.info(e);
    res
      .status(400)
      .send({ issuccess: false, message: e.message ? e.message : e });
  }
};

export const getBackupFileDetails = async (req, res) => {
  try {
    logger.info(req.body, 'get backup file details.');
    const { wfeventid, filename } = req.body;
    let sql = `select * from public.wms_backup_files where wfeventid = ${wfeventid}`;
    if (filename) {
      sql = `${sql} and filename = '${filename}'`;
    }
    sql = `${sql} order by backupid desc`;
    const data = await query(sql);
    res
      .status(200)
      .send({ issuccess: true, data, message: 'Backup Successfull.' });
  } catch (e) {
    logger.info(e);
    res
      .status(400)
      .send({ issuccess: false, message: e.message ? e.message : e });
  }
};
