import path from 'path';
import axios from 'axios';
import { query } from '../../../database/postgres.js';
import { getWorkflowPlaceHolders } from '../../task/fileDetails.js';
import { getFormattedName } from '../fileValidation/utils.js';
import { okmFolderCopy } from './io.js';
import logger from '../logs/index.js';
import { config } from '../../../config/restApi.js';
import { getdmsType } from '../../bpmn/listener/create.js';
import * as azureHelper from '../azure/index.js';
import * as localHelper from '../local/index.js';

export const iNLPScoreGeneration = async (req, res) => {
  const { workOrderId, stage, service, eventId, graphicEventId } = req.body;
  try {
    const dmsType = await getdmsType(workOrderId);
    let sql = `select  COALESCE(d.typesetpages,0) as typesetpages, 
        a.otherfield ->>'articleno' as articleno, 
        doinumber as articlename,title as articletitle,
        b.isiauthor, b.iauthworkflowid,a.wotype, 
        b.journalacronym, b.journalname ,c.iauthcustomerid ,
        d.stageiterationcount 
            from wms_workorder a 
            join public.pp_mst_journal b on a.journalid=b.journalid 
            join public.wms_workorder_Stage d on d.workorderid=a.workorderid
            left join public.iauthor_mst_customer c on c.custorgmapid=b.custorgmapid 
                where a.workorderid=${workOrderId} and d.wfstageid=${stage.id}`;

    const mstJournal = await query(sql);
    if (mstJournal.length == 0) {
      throw new Error(`invalid workorderid : ${workOrderId}`);
    }
    sql = `Select incf.filename from public.wms_workorder_incoming as inc
        left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
        where woid=${workOrderId}`;
    let Filename = await query(sql);
    Filename = Filename[0].filename;
    let logFilePath = [];
    if (graphicEventId != null) {
      sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                    where wfeventid =${graphicEventId} and isactive=true and repofilepath like '%${Filename}_log.xml'`;
      logFilePath = await query(sql);
    }
    sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                where wfeventid =${eventId} and isactive=true and repofilepath like '%${Filename}.xml'`;
    const XMLFilePath = await query(sql);
    const data = {
      CustomerID: mstJournal[0].iauthcustomerid,
      JournalCode: mstJournal[0].journalacronym,
      isNewWMS: true,
      XMLFileName: `${Filename}.xml`,
      NLP_version: 'V2',
    };
    switch (dmsType) {
      case 'azure':
        let out = await azureHelper._download(XMLFilePath[0].repofilepath);
        data.XMLFile = out.data.path;
        if (logFilePath.length > 0) {
          out = await azureHelper._download(logFilePath[0].repofilepath);
          data.XMLLogFile = out.data.path;
          data.XMLLogFileName = `${Filename}_log.xml`;
        }
        break;
      case 'local':
        let out1 = await localHelper._localdownload(
          XMLFilePath[0].repofilepath,
        );
        data.XMLFile = out1.data.path;
        if (logFilePath.length > 0) {
          out1 = await localHelper._localdownload(logFilePath[0].repofilepath);
          data.XMLLogFile = out1.data.path;
          data.XMLLogFileName = `${Filename}_log.xml`;
        }
        break;
      default:
        data.XMLFile =
          config.openKM.base_out_url +
          config.openKM.uri.download +
          XMLFilePath[0].repofileuuid;
        if (logFilePath.length > 0) {
          data.XMLLogFile =
            config.openKM.base_out_url +
            config.openKM.uri.download +
            logFilePath[0].repofileuuid;
          data.XMLLogFileName = `${Filename}_log.xml`;
        }
        break;
    }
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.nlp
      }`,
      headers: {
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data,
    };
    axios(configAPI)
      .then(async function (response) {
        try {
          sql = `select * from insert_inlptran('${JSON.stringify({
            workorderid: (workOrderId || '').toString(),
            stageid: (stage.id || '').toString(),
            serviceid: (service.id || '').toString(),
            guid: (response.data.NLPGuid || '').toString(),
            stageiterationcount: (stage.stageiterationcount || 1).toString(),
            Score: (response.data.Score || '').toString(),
            TrackGrade: (response.data.TrackGrade || '').toString(),
          })}')`;
          await query(sql);
          res.status(200).send(response.data);
          logger.info(response.data, 'INLP');
        } catch (error) {
          logger.info(error, 'INLP');
          res.status(400).send({ is_success: false, message: error.message });
        }
      })
      .catch(function (error) {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (error) {
    logger.info(error);
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};

export const iAuthorLinkGeneration = async (req, res) => {
  const {
    workOrderId,
    stage,
    service,
    eventId,
    graphicEventId,
    skipFileValidation,
  } = req.body;
  try {
    const dmsType = await getdmsType(workOrderId);
    const SupplimentryFiles = [];
    let sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                    where wfeventid=${eventId}`;
    const eventDetails = await query(sql);
    let additionalFiles;
    if (graphicEventId != null) {
      sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map 
                    where wfeventid =${graphicEventId} and repofilepath not like '%.eps'`;
      additionalFiles = await query(sql);
      const supplementaryArray = [];
      additionalFiles.forEach(element => {
        element.FileName = path.basename(element.repofilepath);
        switch (dmsType) {
          case 'azure':
            supplementaryArray.push(
              azureHelper._download(element.repofilepath),
            );
            break;
          case 'local':
            supplementaryArray.push(
              localHelper._localdownload(element.repofilepath),
            );
            break;
          default:
            supplementaryArray.push({
              path:
                config.openKM.base_out_url +
                config.openKM.uri.download +
                element.repofileuuid,
            });
            break;
        }
      });
      const supplementary = await Promise.all(supplementaryArray);
      supplementary.forEach(ele => {
        SupplimentryFiles.push({
          flag: 'article_resource',
          url: ele.path ? ele.path : ele.data.path,
        });
      });
    }
    if (eventDetails.length == 0) {
      throw new Error(`File mapping missing for workorderid : ${eventId}`);
    }
    let iAuthorWorkFlowField = '';
    switch (stage.id) {
      case '13':
        iAuthorWorkFlowField = 'b.copyeditingworkflow';
        break;
      default:
        iAuthorWorkFlowField = 'b.iauthworkflowid';
        break;
    }
    sql = `select  COALESCE(d.typesetpages,0) as typesetpages, a.otherfield ->>'articleno' as articleno, doinumber as articlename,title as articletitle,b.isiauthor, 
                ${iAuthorWorkFlowField} as iauthworkflowid,a.wotype, b.journalacronym, b.journalname ,c.iauthcustomerid ,d.stageiterationcount 
                from wms_workorder a 
                join public.pp_mst_journal b on a.journalid=b.journalid 
                join public.wms_workorder_Stage d on d.workorderid=a.workorderid
                left join public.iauthor_mst_customer c on c.custorgmapid=b.custorgmapid 
                where a.workorderid=${workOrderId} and d.wfstageid=${stage.id}`;
    const mstJournal = await query(sql);
    sql = `Select incf.filename from public.wms_workorder_incoming as inc
        left join wms_workorder_incomingfiledetails as incf on inc.woincomingid = incf.woincomingid
        where woid=${workOrderId}`;
    const Filename = await query(sql);
    if (mstJournal.length == 0) {
      throw new Error(`invalid workorderid : ${workOrderId}`);
    }
    // to be deleted
    // if (mstJournal[0].typesetpages == 0) {
    //   throw new Error(`Typeset Pages not updated.`);
    // }
    const supplementaryArray = [];
    eventDetails.forEach(element => {
      element.FileName = path.basename(element.repofilepath);
      switch (dmsType) {
        case 'azure':
          supplementaryArray.push(azureHelper._download(element.repofilepath));
          break;
        case 'local':
          supplementaryArray.push(
            localHelper._localdownload(element.repofilepath),
          );
          break;
        default:
          supplementaryArray.push({
            path:
              config.openKM.base_out_url +
              config.openKM.uri.download +
              element.repofileuuid,
          });
          break;
      }
    });
    const supplementary = await Promise.all(supplementaryArray);
    supplementary.forEach(ele => {
      SupplimentryFiles.push({
        flag: 'article_resource',
        url: ele.path ? ele.path : ele.data.path,
      });
    });
    const inputXML = eventDetails.filter(
      x => x.FileName == `${Filename[0].filename}.xml`,
    );
    const logXML =
      additionalFiles && additionalFiles.length
        ? additionalFiles.filter(
            x => x.FileName == `${Filename[0].filename}_log.xml`,
          )
        : [];
    if (inputXML.length == 0) {
      throw new Error(`${`${Filename[0].filename}.xml`} file missing.`);
    }
    sql = `SELECT guid FROM inlp_transactions 
        WHERE workorderid = ${workOrderId}
        AND stageid = ${stage.id}
        AND serviceid = ${service.id}
        AND stageiterationcount = ${mstJournal[0].stageiterationcount} order by inlptrnsid limit 1`;
    let NLPGuid = await query(sql);
    if (NLPGuid.length > 0) {
      NLPGuid = NLPGuid[0].guid;
    } else {
      NLPGuid = undefined;
    }
    sql = `select contactname ,contactemail ,contactrole from public.wms_workorder_contacts 
                where workorderid=${workOrderId} order by wocontactid`;
    const workorderContacts = await query(sql);
    if (workorderContacts.length == 0) {
      throw new Error(`Workorder Contacts are missing.`);
    }
    const peDetails = workorderContacts.filter(
      x => x.contactrole == 'PED' || x.contactrole == 'CM',
    );
    const authorDetails = workorderContacts.filter(
      x => x.contactrole == 'AUTHOR',
    );
    const EditorDetails = workorderContacts.filter(
      x => x.contactrole == 'EC' || x.contactrole == 'E',
    );
    const spmDetails = workorderContacts.filter(x => x.contactrole == 'SPM');
    if (peDetails.length == 0) {
      throw new Error('Production Editor is not mapped.');
    }
    sql = `select * from public.iauthor_workflow 
                where iauthworkflowid=${mstJournal[0].iauthworkflowid}`;
    const iAuthorWorkFlow = await query(sql);
    if (iAuthorWorkFlow.length == 0) {
      throw new Error(
        `iAuthorWorkFlow is not mapped for this journal (${mstJournal[0].journalacronym})`,
      );
    } else if (
      mstJournal[0].typesetpages == 0 &&
      iAuthorWorkFlow[0].compoulsaryrole?.skipTypesetPageCount != 'true'
    ) {
      throw new Error(`Typeset Pages not updated.`);
    }
    const SequenceDetails = [];
    for (const activity of iAuthorWorkFlow[0].sequencedetails.activities) {
      if (activity.contactrole == 'DEFAULT') {
        SequenceDetails.push({
          ActivityID: activity.ActivityID,
          RoleID: activity.RoleID,
          userDetails: [
            {
              UserName: 'admin',
              Email: 'admin@integra.co.in',
            },
          ],
        });
      } else {
        const user = workorderContacts.filter(
          x => x.contactrole == activity.contactrole,
        );
        if (user.length == 0) {
          throw new Error(
            `Workorder Contacts are missing for ${activity.contactrole}`,
          );
        }
        SequenceDetails.push({
          ActivityID: activity.ActivityID,
          RoleID: activity.RoleID,
          userDetails: [
            {
              UserName: remove_linebreaksAndSpace(user[0].contactname),
              Email: remove_linebreaksAndSpace(user[0].contactemail),
            },
          ],
        });
      }
    }
    const articlemeta = {
      manuscriptid: Filename[0].filename,
      manuscripttitle: mstJournal[0].articletitle,
      DOI: Filename[0].filename,
      journaltitle: mstJournal[0].journalname,
      Articlenumber: mstJournal[0].articleno,
      Pageno: mstJournal[0].typesetpages,
    };

    if (authorDetails.length > 0) {
      articlemeta.Authoremail = remove_linebreaksAndSpace(
        authorDetails[0].contactemail,
      );
      articlemeta.Authorname = remove_linebreaksAndSpace(
        authorDetails[0].contactname,
      );
    }
    if (peDetails.length > 0) {
      articlemeta.Pemailid = remove_linebreaksAndSpace(
        peDetails[0].contactemail,
      );
      articlemeta.Pename = remove_linebreaksAndSpace(peDetails[0].contactname);
    }
    if (EditorDetails.length > 0) {
      if (EditorDetails.length > 1) {
        const additionalEditor = EditorDetails.splice(1, EditorDetails.length);
        articlemeta.AdditionalEditorMail = additionalEditor
          .map(x => remove_linebreaksAndSpace(x.contactemail))
          .join(';');
      }
      articlemeta.Editoremailid = remove_linebreaksAndSpace(
        EditorDetails[0].contactemail,
      );
      articlemeta.Editorname = remove_linebreaksAndSpace(
        EditorDetails[0].contactname,
      );
    }
    if (spmDetails.length > 0) {
      articlemeta.SPMemailid = remove_linebreaksAndSpace(
        spmDetails[0].contactemail,
      );
      articlemeta.SPMname = remove_linebreaksAndSpace(
        spmDetails[0].contactname,
      );
    }
    const iAuthorInputData = {
      isNewWMS: true,
      NLPGuid,
      supplementary: SupplimentryFiles,
      JobType: mstJournal[0].wotype,
      CustomerID: mstJournal[0].iauthcustomerid,
      isEDAjrnl: 0,
      ProofType: 'A',
      PEUser: {
        UserName: remove_linebreaksAndSpace(peDetails[0].contactname),
        Email: remove_linebreaksAndSpace(peDetails[0].contactemail),
      },
      JourFileToUpload: [],
      JournalDetails: {
        journalcode: mstJournal[0].journalacronym,
        journalname: mstJournal[0].journalname,
        journaltitle: mstJournal[0].journalname,
        journaltoc: [
          {
            ArticleGUID: null,
            title: mstJournal[0].articletitle,
            orderid: 1,
            type: null,
            code: Filename[0].filename,
            FileName: Filename[0].filename,
            IsOnshore: 0,
          },
        ],
      },
      workflowDetails: {
        isNeedActivitySkip:
          iAuthorWorkFlow[0].sequencedetails.isNeedActivitySkip,
        RevisionCount: mstJournal[0].stageiterationcount,
        WorkflowID: mstJournal[0].iauthworkflowid,
        SequenceDetails,
      },
      articlemeta,
      conversion_id: 1,
      skipFileValidation,
    };
    switch (dmsType) {
      case 'azure':
        const awt = [];
        awt.push(azureHelper._download(inputXML[0].repofilepath));
        awt.push(azureHelper._download(inputXML[0].repofilepath));
        const out = await Promise.all(awt);
        iAuthorInputData.JourFileToUpload.push({
          isArticle: true,
          url: out[0].data.path,
          Code: Filename[0].filename,
        });
        if (logXML.length > 0) {
          iAuthorInputData.JourFileToUpload.push({
            isArticle: false,
            url: out[1].data.path,
            Code: Filename[0].filename,
          });
        }
        break;
      case 'local':
        const awt1 = [];
        awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
        awt1.push(localHelper._localdownload(inputXML[0].repofilepath));
        const out1 = await Promise.all(awt1);
        iAuthorInputData.JourFileToUpload.push({
          isArticle: true,
          url: out1[0].data.path,
          Code: Filename[0].filename,
        });
        if (logXML.length > 0) {
          iAuthorInputData.JourFileToUpload.push({
            isArticle: false,
            url: out1[1].data.path,
            Code: Filename[0].filename,
          });
        }
        break;
      default:
        iAuthorInputData.JourFileToUpload.push({
          isArticle: true,
          url:
            config.openKM.base_out_url +
            config.openKM.uri.download +
            inputXML[0].repofileuuid,
          Code: Filename[0].filename,
        });
        if (logXML.length > 0) {
          iAuthorInputData.JourFileToUpload.push({
            isArticle: false,
            url:
              config.openKM.base_out_url +
              config.openKM.uri.download +
              logXML[0].repofileuuid,
            Code: Filename[0].filename,
          });
        }
        break;
    }
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.createjob
      }`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data: JSON.stringify(iAuthorInputData),
    };
    axios(configAPI)
      .then(async function (response) {
        try {
          sql = `select * from insert_iauthortran('${JSON.stringify({
            workorderid: (workOrderId || '').toString(),
            stageid: (stage.id || '').toString(),
            serviceid: (service.id || '').toString(),
            guid: (response.data.data.jobid || '').toString(),
            stageiterationcount: (stage.stageiterationcount || 1).toString(),
          })}')`;
          await query(sql);
          res.status(200).send(response.data);
          logger.info(response.data, 'IAUTH');
        } catch (error) {
          logger.info(error, 'IAUTH');
          res.status(400).send({ is_success: false, message: error.message });
        }
      })
      .catch(function (error) {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (error) {
    logger.info(error);
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};

function remove_linebreaksAndSpace(str) {
  return (str || '')
    .toString()
    .replace(/[\r\n]+/gm, '')
    .trim();
}

export const getCurrentiAuthorLink = async guid => {
  return new Promise((resolve, reject) => {
    try {
      const configAPI = {
        method: 'get',
        url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
          config.iAuthor.getCurrentiAuthorLink
        }?articleguid=${guid}`,
        headers: {
          'Content-Type': 'application/json',
          clientid: config.iAuthor.clientid,
          apikey: config.iAuthor.apikey,
        },
      };
      axios(configAPI)
        .then(async function (response) {
          resolve(response.data);
        })
        .catch(err => {
          if (err.response) reject(err.response.data);
          else reject({ is_success: false, message: err.message });
        });
    } catch (error) {
      logger.info(error);
      reject({
        is_success: false,
        message: error.message ? error.message : error,
      });
    }
  });
};

export const getiAuthorActivityLink = async (req, res) => {
  try {
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.getiAuthorLink
      }`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data: JSON.stringify({
        JobID: req.body.jobid,
        ActivityId: req.body.activityid,
        RoleID: req.body.roleid,
        isCompletedLink: req.body.isCompletedLink
          ? req.body.isCompletedLink
          : false,
        userDetails: {
          UserName: remove_linebreaksAndSpace(req.body.username),
          Email: remove_linebreaksAndSpace(req.body.email),
        },
      }),
    };
    axios(configAPI)
      .then(async function (response) {
        res.status(200).send(response.data);
      })
      .catch(err => {
        if (err.response) res.status(400).send(err.response.data);
        else res.status(400).send({ is_success: false, message: err.message });
      });
  } catch (error) {
    logger.info(error);
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};

export const FolderCopy = async (req, res) => {
  try {
    const result = await okmFolderCopy(req.body);
    res.status(200).send(result);
  } catch (e) {
    logger.info('FolderCopy Input : ', req.body);
    logger.info('FolderCopy', e.message);
    res.status(400).send('Folder copy Failed.');
  }
};

export const getiAuthorActivityFiles = async (req, res) => {
  try {
    const configAPI = {
      method: 'get',
      url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
        config.iAuthor.checkiAuthorStatus
      }?jobid=${req.body.jobid}&activityid=${req.body.activityid}`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
    };
    axios(configAPI)
      .then(async function (response) {
        try {
          if (response.data.is_success) {
            if (response.data.data.status_id == 4) {
              const configAPI2 = {
                method: 'post',
                url: `${config.iAuthor.base_url()}${config.iAuthor.journal}${
                  config.iAuthor.getiAuthorActivityFiles
                }`,
                headers: {
                  'Content-Type': 'application/json',
                  clientid: config.iAuthor.clientid,
                  apikey: config.iAuthor.apikey,
                },
                data: JSON.stringify(req.body),
              };
              axios(configAPI2)
                .then(async function (response1) {
                  response1.data.data.files = response1.data.data.files.filter(
                    x => !['Input', 'Resource'].includes(x.folderName),
                  );
                  const temp = [];
                  response1.data.data.files.forEach(ele => {
                    ele.paths.forEach(el => {
                      temp.push({ folder: ele.folderName, url: el });
                    });
                  });
                  if (
                    temp.filter(
                      x => x.folder == 'Output' && x.url.includes('.xml'),
                    ).length < 1
                  ) {
                    throw new Error('Output xml missing');
                  }
                  response1.data.data.files = temp;
                  res.status(200).send(response1.data);
                })
                .catch(err => {
                  if (err.response) {
                    res.status(400).send(err.response.data);
                  } else {
                    res
                      .status(400)
                      .send({ is_success: false, message: err.message });
                  }
                });
            } else {
              res.status(400).send({
                is_success: false,
                message: 'iAuthor link is not submitted.',
              });
            }
          } else {
            res
              .status(400)
              .send({ is_success: false, message: response.data.message });
          }
        } catch (error) {
          res.status(400).send({ is_success: false, message: error.message });
        }
      })
      .catch(function (error) {
        if (error.response) {
          res.status(400).send(error.response.data);
        } else {
          res.status(400).send({ is_success: false, message: error.message });
        }
      });
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getToolsData = async (req, res) => {
  const { toolsId, wfeventId, toolsPlaceHolder = {} } = req.body;
  try {
    const placeHolders = await getWorkflowPlaceHolders(wfeventId);
    const combinedPlaceHolders = { ...placeHolders, ...toolsPlaceHolder };
    const toolsData = await _getToolsData(toolsId, combinedPlaceHolders);
    res.status(200).json(toolsData);
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _getToolsData = async (toolsId, placeHolders) => {
  const commanUrl = await getCommanToolsUrl();
  logger.info(commanUrl, 'commanUrl for tools');
  const sql = `SELECT payload as apiconfig, isasync,tooltypeid,toolstatus FROM public.pp_mst_tool where toolid = $1 and toolstatus = $2`;
  const toolsData = await query(sql, [toolsId, true]);
  if (toolsData.length) {
    const sql2 = `SELECT * FROM public.pp_mst_tool_serverpath where servermode = '${process.env.MODE}'`;
    logger.info(sql2, 'sql for server url path');
    const serverUrlDetails = await query(sql2);
    toolsData[0].basePath = commanUrl
      ? commanUrl + serverUrlDetails[0].serverurl
      : serverUrlDetails[0].serverurl;
    const apiConfig = formattedApiConfig(toolsData[0].apiconfig, placeHolders);
    toolsData[0].apiconfig = apiConfig;
    return toolsData[0];
  }
  logger.info(toolsData, 'toolsData for get tools');
  return {};
};

export const formattedApiConfig = (apiConfig, placeHolders) => {
  apiConfig = apiConfig || {};
  if (!apiConfig.input) apiConfig.input = {};
  if (!apiConfig.input.rawData) apiConfig.input.rawData = {};
  const inputKeys = Object.keys(apiConfig.input.rawData);
  for (let i = 0; i < inputKeys.length; i++) {
    const inputField = apiConfig.input.rawData[inputKeys[i]];
    if (Object.prototype.toString.call(inputField) == '[object String]') {
      apiConfig.input.rawData[inputKeys[i]] = getFormattedName(inputField, {
        ...placeHolders,
      });
    }
  }
  return apiConfig;
};

export const getBasicToolsData = async toolsId => {
  return new Promise(async (resolve, reject) => {
    try {
      const commanUrl = await getCommanToolsUrl();
      console.log(commanUrl, 'commanUrl');
      toolsId = toolsId instanceof Array ? toolsId : [toolsId];
      const sql = `SELECT toolid, toolname, tooltypeid, toolstatus, tooldescription, payload as apiconfig, isasync,tooloutputid,toolvalidation FROM public.pp_mst_tool where toolid = Any($1)`;
      const data = await query(sql, [toolsId]);
      const sql2 = `SELECT * FROM public.pp_mst_tool_serverpath where servermode = '${process.env.MODE}'`;
      console.log(sql2, 'sql for server url path');
      const serverUrlDetails = await query(sql2);
      console.log(process.env.MODE_VAL, 'mode value', process.env.MODE);
      if (data && data.length > 0) {
        data.forEach(list => {
          let newUrl = '';
          if (
            Object.keys(list.apiconfig).length > 0 &&
            list.apiconfig.url &&
            list.tooltypeid == 1
          ) {
            // if(process.env.MODE == 'dev'){
            //      newUrl = list.apiconfig.url
            // }else{
            //     var remainingUrl = list.apiconfig.url.replace('https://tools.integra.co.in/wrapper-service-dev','')
            //     newUrl = 'https://tools.integra.co.in/wrapper-service' + remainingUrl
            // }
            newUrl = commanUrl
              ? commanUrl + serverUrlDetails[0].serverurl + list.apiconfig.url
              : serverUrlDetails[0].serverurl + list.apiconfig.url;
            list.apiconfig.url = newUrl;
          }
        });
      }

      resolve(data);
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getCommanToolsUrl = async () => {
  return new Promise(async (resolve, reject) => {
    try {
      const Comurl =
        process.env.MODE == 'dev' ||
        process.env.MODE == 'prod' ||
        process.env.MODE == 'test'
          ? 'https://ispswitch.integra.co.in/ipswitch?serverName=is-srv165&getIP=false'
          : 'https://ispswitch.integra.co.in/ipswitch?serverName=is-srv135&getIP=false';
      // url: "https://ispswitch.integra.co.in/ipswitch?serverName=is-srv135&getIP=false",
      axios({
        method: 'get',
        url: Comurl,
      }).then(response => {
        logger.info(response.data, 'response for tools comman url');
        const commanurl = `https://${response.data}`;
        resolve(commanurl);
      });
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const generateiAuthorHtml = async (req, res) => {
  const { conversion_type, conversion_method, DOMContent, configuration } =
    req.body;

  try {
    if (!conversion_type && !conversion_method) {
      throw new Error('Mandatory fields required');
    }
    const configAPI = {
      method: 'post',
      url: `${config.iAuthor.iauthorhtml}${config.iAuthor.generateiAuthorhtml}`,
      headers: {
        'Content-Type': 'application/json',
        clientid: config.iAuthor.clientid,
        apikey: config.iAuthor.apikey,
      },
      data: JSON.stringify({
        conversion_type,
        conversion_method,
        DOMContent,
        configuration,
      }),
    };
    axios(configAPI)
      .then(async function (response) {
        res.status(200).send(response.data);
      })
      .catch(err => {
        if (err.response) res.status(400).send(err.response.data);
        else res.status(400).send({ is_success: false, message: err.message });
      });
  } catch (error) {
    logger.info(error);
    res.status(400).send({
      is_success: false,
      message: error.message ? error.message : error,
    });
  }
};

export const saveiNetLink = async (req, res) => {
  const { iwms } = req.body;
  const { woId, serviceId, stageId, stageIteration } = iwms;
  const toolId = req.body.apiDetails.newToolId;
  const output = req.body.remarks;
  // const wfEventId = iwms.wfEventId ? iwms.wfEventId : '';

  const articleFileId = iwms.woIncomingFileId;
  const toolType = req.body.toolType ? req.body.toolType : '';
  let updatesql = '';
  const checksql = `SELECT COUNT(*) FROM wms_toolsoutput_details where workorderid =${woId} and serviceid= ${serviceId} and stageid= ${stageId} and stageiterationcount =${stageIteration} and toolid=${toolId} and tooltype = '${toolType}' and  (incomingfileid=${articleFileId} or incomingfileid is null)`;
  await query(checksql)
    .then(async getCount => {
      if (getCount[0].count > 0) {
        updatesql = `UPDATE wms_toolsoutput_details SET output ='${output}' WHERE workorderid = ${woId} and serviceid= ${serviceId} and stageid= ${stageId} and stageiterationcount =${stageIteration} and toolid=${toolId} and tooltype = '${toolType}' RETURNING output`;
        await query(updatesql)
          .then(async data => {
            res.status(200).json({
              data,
              status: true,
            });
          })
          .catch(error => {
            logger.info(error);
            res.status(400).send({
              data: error.message ? error.message : error,
              status: false,
              message: 'Save link for inetCompare failed.',
            });
          });
      } else {
        const sql = `Insert into wms_toolsoutput_details(workorderid,serviceid,stageid,stageiterationcount,toolid,output,incomingfileid,tooltype) values (${woId},${serviceId},${stageId},${stageIteration},${toolId},'${output}',${articleFileId},'${toolType}') RETURNING output`;
        await query(sql)
          .then(async data => {
            res.status(200).json({
              data,
              status: true,
            });
          })
          .catch(error => {
            logger.info(error);
            res.status(400).send({
              data: error.message ? error.message : error,
              status: false,
              message: 'Save link for inetCompare failed.',
            });
          });
      }
    })
    .catch(error => {
      res.status(400).send({
        data: error.message ? error.message : error,
        status: false,
        message: 'Save link for inetCompare failed.',
      });
    });
};
export const gettoolLink = async (req, res) => {
  const { woId, serviceId, stageId, stageIteration, toolId, iwms } = req.body;

  const toolType = req.body.toolType ? req.body.toolType : '';
  if (iwms.instanceType == 'Batch') {
    const fileID = `'{${iwms.woIncomingFileId}}'`;
    const sql = `select b.filename ,a.output, a. tooltype from  wms_toolsoutput_details a join wms_workorder_incomingfiledetails b
    on a.incomingfileid = b.woincomingfileid  where a.workorderid =${woId} and a.serviceid= ${serviceId} and a.stageid = ${stageId} and a.stageiterationcount=${stageIteration} and a.toolid=${toolId}
    and a.incomingfileid = any(${fileID})  order by a.toolsoutputid `;
    await query(sql)
      .then(async data => {
        res.status(200).json({
          data,
          status: true,
        });
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          status: false,
          message: 'iNet link was not updated',
        });
      });
  } else {
    const tmpwoIncomingFileId =
      iwms.woIncomingFileId == null ? 0 : iwms.woIncomingFileId;
    // const toolType = req.body.toolType ? req.body.toolType : '';
    const sql = `select output from  wms_toolsoutput_details where workorderid =${woId} and serviceid= ${serviceId} and stageid = ${stageId} and stageiterationcount=${stageIteration} and toolid=${toolId} and (tooltype='${toolType}' or tooltype is null) and (coalesce(incomingfileid,0) =${tmpwoIncomingFileId})order by toolsoutputid limit 1`;
    await query(sql)
      .then(async data => {
        res.status(200).json({
          data: data[0],
          status: true,
        });
      })
      .catch(() => {
        res.status(400).send({
          data: [],
          status: false,
          message: 'iNet link was not updated',
        });
      });
  }
};
export const isNullorUndefined = data => {
  return data == null || data == undefined || data.toString() == '';
};
