import { query } from '../../../database/postgres.js';
import { Service } from '../../../httpClient/index.js';

const service = new Service();

export const getFileDetails = async wfeventId => {
  const sql = `Select * from (SELECT 
        DISTINCT ON (wms_workflowactivitytrn_file_map.woincomingfileid)
        wms_workflowactivitytrn_file_map.woincomingfileid as fileid, 
        wms_workorder_incomingfiledetails.filename,
        wms_workorder_incomingfiledetails.newfilename,
        wms_workorder_incomingfiledetails.filesequence,
        wms_mst_pitstopprofile.pitstopprofile,
        pp_mst_filetype.filetypeid,
        pp_mst_filetype.filetype,
        pp_mst_filetype.allowsubfiletype
        FROM public.wms_workflowactivitytrn_file_map
        join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
        join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
        left join wms_mst_pitstopprofile on wms_mst_pitstopprofile.pitstopprofileid = wms_workorder_incomingfiledetails.pitstopprofile
        where wms_workflowactivitytrn_file_map.wfeventid = $1 ) WD order by WD.filesequence asc`;
  const fileDetails = await query(sql, [wfeventId]);
  return fileDetails;
};

export const getFileTrnDetails = async wfeventId => {
  const sql = `SELECT repofileuuid, repofilepath FROM public.wms_workflowactivitytrn_file_map
    where wfeventid = $1`;
  const fileDetails = await query(sql, [wfeventId]);
  return fileDetails;
};

export const getIntegraHostName = async () => {
  const url = 'https://ipswitch.azurewebsites.net/getip?type=host';
  const hostNameDetails = await service.get(url);
  return hostNameDetails.data;
};
