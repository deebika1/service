import { _completeAPIRequestId } from './api.js';
import { acknowledge as ackForegroundTask } from '../../task/tools/ack.js';
import { acknowledge as ackExternalTask } from '../../externalTask/tools/ack.js';
import { isNullorUndefined } from './index.js';
import logger from '../logs/index.js';
import { query } from '../../../database/postgres.js';

export const initialAcknowledge = async (req, res) => {
  try {
    logger.info(req.body, 'received initial acknowledgement from tools');
    const sql = `update public.wms_tools_api set isinitiated = true where apiid=${req.body.apiid}`;
    await query(sql);
    res
      .status(200)
      .send({ issuccess: true, message: 'Tools initial Acknowledged' });
  } catch (e) {
    logger.info(e);
    res
      .status(400)
      .send({ issuccess: false, message: e.message ? e.message : e });
  }
};
export const acknowledge = async (req, res) => {
  const { iwms, data, message, is_success, isBPCorrection, isFileAvailable } =
    req.body;
  logger.info(req.body, 'received acknowledgement from tools');
  try {
    const remarks =
      !isNullorUndefined(data) &&
      (Object.prototype.toString.call(data) == '[object String]' ||
        Object.prototype.toString.call(data) == '[object Boolean]')
        ? data
        : !isNullorUndefined(message) &&
          (Object.prototype.toString.call(message) == '[object String]' ||
            Object.prototype.toString.call(message) == '[object Boolean]')
        ? message
        : data || message || 'Remarks missing';
    const { wfeventId, isForegroundService, toolsId, getToolsEntry } =
      await _completeAPIRequestId({
        apiId: iwms.id,
        status: is_success ? 'Success' : 'Failure',
        remarks: remarks.toString(),
        response: req.body,
        sId: iwms.sId,
        tooloutputid: iwms.tooloutputid,
        isFileAvailable,
        actualActivityCount: iwms.actualActivityCount,
      });
    if (is_success) {
      if (isForegroundService) {
        await ackForegroundTask(wfeventId, toolsId, {}, iwms.dmsType);
      } else {
        await ackExternalTask(
          wfeventId,
          toolsId,
          {},
          is_success,
          getToolsEntry,
          remarks,
          iwms.dmsType,
          isBPCorrection,
        );
      }
    } else {
      await ackExternalTask(
        wfeventId,
        toolsId,
        {},
        is_success,
        getToolsEntry,
        remarks,
        iwms.dmsType,
        isBPCorrection,
      );
    }
    res.send(true);
  } catch (e) {
    logger.info(e, 'send acknowledgement return error');
    res.status(400).send(e.message ? e.message : e);
  }
};
