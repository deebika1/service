/* eslint-disable no-unused-vars */
import { createReadStream } from 'fs';
import path from 'path';
import FormData from 'form-data';
import axios from 'axios';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import logger from '../logs/index.js';

const service = new Service();

export const localproperties = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.delete;
      const result = await service.get(
        `${config._rest.base_url}${url}?docId=${pth}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};

export const localfileUpload = async (req, res) => {
  try {
    const { docPath } = req.body;
    const fileName = 'content';
    const result = await _uploadlocal(req.files[fileName], docPath);
    logger.info(result, 'azure file upload success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file upload err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _uploadlocal = (file, docPath) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (docPath != '') {
        const url = config.local_rest.uri.localupload;
        const formData = new FormData();
        formData.append('content', createReadStream(file.tempFilePath));
        formData.append('docPath', `${docPath}${file.name}`);
        const headers = {
          'Content-Type': 'multipart/form-data',
          ...formData.getHeaders(),
        };
        const result = await service.uploadPost(
          `${config.local_rest.base_url}${url}`,
          formData,
          headers,
        );
        const { data, status } = result;
        const response = {
          data: {
            ...data,
            okmPath: docPath,
            name: file.name,
            fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
          },
          status,
          fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
        };
        resolve(response);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const locallistCurrentDirectory = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.retreiveLocalRootList;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

export const localfileDelete = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _localdelete(pth);
    logger.info(result, 'azure file delete success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file delete err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _localdelete = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localdelete;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docId=${pth}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};

export const locallistAllFiles = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _locallistAllFiles(pth);
    logger.info(result, 'azure file delete success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file delete err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _locallistAllFiles = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.retreiveLocalFiles;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const localfileDownload = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _localdownload(pth);
    logger.info(result, 'azure file download success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file download err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _localdownload = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localdownload;
      // const result = await service.get(
      //   `${config.blob_rest.base_url}${url}?docPath=${pth}`,
      // );
      resolve({
        data: { path: `${config.local_rest.base_url}${url}?docPath=${pth}` },
      });
    } catch (err) {
      reject(err);
    }
  });
};

export const _islocalFileExist = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localisExists;
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${pth}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const _localcopyFile = (
  { srcPath, name, destBasePath, customerName = '' },
  isNewmsContainer = true,
) => {
  const url = isNewmsContainer
    ? config.local_rest.uri.localcopy
    : config.local_rest.uri.copyExternalBlobToLocal;
  const targetPath = destBasePath + name;
  // eslint-disable-next-line no-unused-vars
  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('docId', srcPath);
      formData.append('dstId', targetPath);
      formData.append('customerName', customerName);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.local_rest.base_url}${url}`,
        formData,
        headers,
      );
      logger.info(targetPath, 'azure file copy success');
      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      logger.info(err, 'azure file copy err');
      if (!isNewmsContainer) {
        reject('File copy failed');
      } else {
        resolve({ path: targetPath, uuid: 'azure' });
      }
    }
  });
};

export const localrenameBlob = ({ srcPath, name, destBasePath }) => {
  const url = config.local_rest.uri.localrename;
  const targetPath = destBasePath + name;
  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('docId', srcPath);
      formData.append('dstId', targetPath);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.local_rest.base_url}${url}`,
        formData,
        headers,
      );
      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};
