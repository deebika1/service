import { Service } from '../../../httpClient/index.js';
import logger from '../logs/index.js';

const service = new Service();

export const triggerStartEvent = (wfKey, variables) => {
  return new Promise(async (resolve, reject) => {
    logger.info(variables, 'camunda variable for springer trigger start event');
    const triggerData = { variables };
    try {
      const triggerResponse = await service.post(
        `${process.env.CAMUNDA_NATIVE_URL}process-definition/key/${wfKey}/start`,
        triggerData,
      );
      logger.info(
        triggerResponse,
        'camunda triggerResponse for springer trigger start event',
      );
      resolve(triggerResponse.data ? triggerResponse.data : triggerResponse);
    } catch (e) {
      logger.info(e, 'trigger start event for springer');
      reject(e.message?.data ? e.message.data : e);
    }
  });
};

export const triggerMsgEvent = (
  processInstanceId,
  messageName,
  variables = {},
) => {
  return new Promise(async (resolve, reject) => {
    const triggerData = {
      processInstanceId,
      messageName,
      processVariables: variables,
    };
    try {
      logger.info(triggerData, 'triggerData for springer');
      const triggerResponse = await service.post(
        `${process.env.CAMUNDA_NATIVE_URL}message`,
        triggerData,
      );
      resolve(triggerResponse.data ? triggerResponse.data : triggerResponse);
    } catch (e) {
      logger.info(e, 'springer');
      reject(e.message?.data ? e.message.data : e);
    }
  });
};
