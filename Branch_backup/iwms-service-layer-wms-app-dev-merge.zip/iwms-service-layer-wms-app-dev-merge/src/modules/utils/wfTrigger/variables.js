import { appConfig } from '../../../config/app.js';
import logger from '../logs/index.js';
// chapters
export const getCWVariables = async (
  workOrderId,
  serviceId,
  stage,
  file,
  // eslint-disable-next-line default-param-last
  camundaFormVariables = {},
  graphicVariables,
  isWordInput,
  isJournalInput,
  iscopyEditingLevel,
  isiAuthor,
  iseonly,
  isNLP,
  isDirectFP,
  flowtype,
  ceLevel,
  isreject,
  isPAP,
  isESM,
) => {
  const wfInfo = {
    workOrderId,
    serviceId,
  };
  const stageInfo = {
    type: stage.type,
    iteration: stage.iteration,
    file,
  };
  const mqInfo = getMQVariable();
  return {
    ...{
      __stageInfo__: {
        value: JSON.stringify(stageInfo),
        type: 'Json',
      },
      __wfInfo__: {
        value: JSON.stringify(wfInfo),
        type: 'Json',
      },
      __isReset__: {
        value: false,
        type: 'Boolean',
      },
    },
    ...mqInfo,
    ...camundaFormVariables,
    ...graphicVariables,
    ...isWordInput,
    ...isJournalInput,
    ...iscopyEditingLevel,
    ...isiAuthor,
    ...iseonly,
    ...isNLP,
    ...isDirectFP,
    ...flowtype,
    ...ceLevel,
    ...isreject,
    ...isPAP,
    ...isESM,
  };
};

export const getCWStageVariables = async (stage, file, iterationType) => {
  logger.info(iterationType, 'iterationType Deebika');
  const stageInfo = {
    type: stage.type,
    iteration: stage.iteration,
    file,
  };
  return {
    __stageInfo__: {
      value: JSON.stringify(stageInfo),
      type: 'Json',
    },
    __isGraphic__: {
      value: false,
      type: 'Boolean',
    },
    __isfirstiteration__: {
      value: iterationType != 'iterate', // added iteration camunda update
      type: 'Boolean',
    },
  };
};

// books
export const getBWVariables = (
  workOrderId,
  serviceId,
  stage,
  files,
  enableListener,
  // eslint-disable-next-line default-param-last
  camundaFormVariables = {},
  graphicVariables,
  isJournalInput,
  flowtype,
  isAltText,
) => {
  // export const getBWVariables = (workOrderId, serviceId, stage, files, enableListener, camundaFormVariables = {}) => {
  const wfInfo = {
    workOrderId,
    serviceId,
  };
  const stageInfo = {
    type: stage.type,
    iteration: stage.iteration,
    files: enableListener ? [] : files,
    totalChapters: enableListener ? -1 : files.length,
    enableListener,
  };
  const listenerInfo = enableListener
    ? getBWStageListenerVariables(files, -1)
    : {};
  const mqInfo = getMQVariable();
  return {
    ...{
      __stageInfo__: {
        value: JSON.stringify(stageInfo),
        type: 'Json',
      },
      __wfInfo__: {
        value: JSON.stringify(wfInfo),
        type: 'Json',
      },
      __isReset__: {
        value: false,
        type: 'Boolean',
      },
      // }, ...listenerInfo, ...mqInfo, ...camundaFormVariables
    },
    ...listenerInfo,
    ...mqInfo,
    ...camundaFormVariables,
    ...graphicVariables,
    ...isJournalInput,
    ...flowtype,
    ...isAltText,
  };
};

export const getBWStageVariables = (stage, files) => {
  const stageInfo = {
    type: stage.type,
    iteration: stage.iteration,
    files,
    totalChapters: files.length,
    enableListener: false,
  };
  return {
    ...{
      __stageInfo__: {
        value: JSON.stringify(stageInfo),
        type: 'Json',
      },
      __isGraphic__: {
        value: false,
        type: 'Boolean',
      },
    },
  };
};

export const getBWStageListenerVariables = (files, totalChapters) => {
  const listenerInfo = {
    files,
    totalChapters,
  };
  return {
    __stageListenerInfo__: {
      value: JSON.stringify(files ? listenerInfo : {}),
      type: 'Json',
    },
  };
};

// rejected
export const getRejectedVariables = isRejected => {
  return {
    __isRejected__: {
      value: isRejected,
      type: 'Boolean',
    },
  };
};

const getMQVariable = () => {
  switch (appConfig.MQ) {
    case 'rmq':
      return {
        __rmq__: {
          value: JSON.stringify({
            exchange: process.env.RMQ_CAMUNDA_TASK_EXCHANGE,
            routingKey: process.env.RMQ_CAMUNDA_TASK_RK,
          }),
          type: 'Json',
        },
      };
    case 'asb':
      return {
        __asb__: {
          value: JSON.stringify({
            queue: process.env.ASB_TASK_QUEUE,
          }),
          type: 'Json',
        },
      };
    default:
      return {};
  }
};
