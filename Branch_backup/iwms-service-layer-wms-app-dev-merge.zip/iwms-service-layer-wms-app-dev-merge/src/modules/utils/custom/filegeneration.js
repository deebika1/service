// import { apiConfig } from "../../config/api.mjs";
// import { createFileTypeFolderStructure } from "../bpmn-listener/utils/utils.mjs";
// import { post, upload } from "../http/index.mjs";
// import FormData from 'form-data';
// import { basename, resolve } from 'path';
// import { createReadStream } from "fs";
import querystring from 'querystring';
import { basename } from 'path';
import fs, { createReadStream } from 'fs';
import FormData from 'form-data';
import { createHash } from 'crypto';
import { writeSmallFile } from './io.js';
import { getFileSeq } from '../../bpmn/listener/create.js';
import { config } from '../../../config/restApi.js';
import { Service } from '../../../httpClient/index.js';
import logger from '../logs/index.js';

const service = new Service();
export const generateFileSeqDetails = payload => {
  const { workorderid, uuid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      await getFileSeq(workorderid).then(async data => {
        console.log('File Sequence Details', data);
        const ts = Date.now();
        const uniquefileName = `${random() + Math.floor(ts / 1000)}.xml`;
        await writeSmallFile(
          `uploads/${uniquefileName}`,
          getFileSeqTemplate(data.length ? data : null),
          `uploads/`,
        );
        await uploadExistingFile(`uploads/${uniquefileName}`, uuid);
        fs.unlink(`uploads/${uniquefileName}/`, function (err) {
          if (err) reject(err);
          logger.info('File deleted!');
        });
        // await removeFolder(`upload/${wfeventid}/${reportFileName}`)
        resolve();
      });
    } catch (error) {
      logger.info('error', error);
      reject(error);
    }
  });
};
const random = (length = 8) => {
  return Math.random().toString(16).substr(2, length);
};
export const getFileSeqTemplate = details => {
  console.log('details', details);
  let template = '<Book>';
  if (details) {
    details.forEach(detail => {
      const filename = detail.filename ? detail.filename : '';
      const filesequence = detail.filesequence ? detail.filesequence : '';
      const filetype = detail.filetype ? detail.filetype : '';
      const pitstopprofile = detail.pitstopprofile ? detail.pitstopprofile : '';
      template +=
        `${'<File><FileName>'}${filename}</FileName>` +
        `<SeqId>${filesequence}</SeqId>` +
        `<Type>${filetype}</Type>` +
        `<Pitstop>${pitstopprofile}</Pitstop>` +
        `</File>`;
    });
  }
  template += '</Book>';
  console.log('template', template);
  return template;
};
const uploadExistingFile = (src, uuid) => {
  return new Promise(async (resolve, reject) => {
    try {
      const fileName = basename(src);
      logger.info(`Upload started for ${fileName}`);
      await checkout(uuid);
      const formData = new FormData();
      formData.append('content', createReadStream(src));
      formData.append('docId', uuid);
      const header = {
        'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
      };
      await service.upload(
        `${config.openKM.base_url}${config.openKM.uri.checkin}`,
        formData,
        header,
      );
      logger.info(`Upload completed for ${fileName}`);
      resolve();
    } catch (e) {
      logger.info(e, 'uploadExistingFile error');
      if (e?.message?.data) {
        // for dms error message
        e.message = e.message.data.includes('FileNotFoundException')
          ? 'Uploading was interrupted. Please retry the current action'
          : e.message.data;
      }
      reject(e);
    }
  });
};
export const checkout = uuid => {
  return new Promise(async (resolve, reject) => {
    try {
      const headers = {
        Authorization: `Basic ${process.env.OKM_AUTH}`,
      };
      const url = config.okmNative.uri.checkout;
      const data = querystring.stringify({
        docId: uuid,
      });
      await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      resolve(true);
    } catch (err) {
      logger.info(err, 'checkout');
      reject({ message: err.message?.data ? err.message?.data : err });
    }
  });
};

export const getChecksum = path => {
  return new Promise(async (resolve, reject) => {
    try {
      const readStream = createReadStream(path);
      const hash = createHash('md5');
      hash.setEncoding('hex');
      readStream.on('close', () => {
        hash.end();
        resolve(hash.read());
      });
      readStream.on('error', e => {
        reject(e);
      });
      readStream.pipe(hash);
    } catch (e) {
      reject(e);
    }
  });
};
