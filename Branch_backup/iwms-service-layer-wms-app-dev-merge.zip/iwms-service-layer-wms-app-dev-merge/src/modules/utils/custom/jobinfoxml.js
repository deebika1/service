import { basename, extname } from 'path';
import { templates } from '../../JobInfoTemplate/template.js';
import { ProductionTemplates } from '../../JobInfoTemplate/productionTemplate.js';
import { JobInfoTemplates } from '../../JobInfoTemplate/jobInfoTemplate.js';
import { FileInfoTemplate } from '../../JobInfoTemplate/fileInfoTemplate.js';
import { query } from '../../../database/postgres.js';

const jobInfoXmlCreate = async (prodcutionList, jobInfoList, fileInfoList) => {
  return new Promise(async (resolve, reject) => {
    try {
      const prodOut = [];
      const jobInfoOut = [];
      const fileInfoOut = [];
      let finalTemplate = [];
      const {
        wmsid,
        bookid,
        countryid,
        jobname,
        woincomingfileid,
        filename,
        stageid,
        stagename,
        activityid,
        activityname,
        itrackstageid,
        jobcardid,
        templatename,
        folderid,
        templateid,
        workingpath,
        userid,
        category,
        volumeid,
      } = prodcutionList;
      prodOut.push(
        ProductionTemplates.li
          .replace(/{{wmsid}}/, wmsid)
          .replace(/{{bookid}}/, bookid)
          .replace(/{{countryid}}/, countryid)
          .replace(/{{jobname}}/, jobname)
          .replace(/{{woincomingfileid}}/, woincomingfileid)
          .replace(/{{filename}}/, filename)
          .replace(/{{stageid}}/, stageid)
          .replace(/{{stagename}}/, stagename)
          .replace(/{{activityid}}/, activityid)
          .replace(/{{activityname}}/, activityname)
          .replace(/{{itrackstageid}}/, itrackstageid)
          .replace(/{{volumeid}}/, volumeid)
          .replace(/{{jobcardid}}/, jobcardid || '{{jobcardid}}')
          .replace(/{{templatename}}/, templatename)
          .replace(/{{folderid}}/, folderid)
          .replace(/{{templateid}}/, templateid)
          .replace(/{{workingpath}}/, workingpath)
          .replace(/{{userid}}/, userid)
          .replace(/{{category}}/, category),
      );

      const productionXmlTemplate = ProductionTemplates.ul.replace(
        /{{li}}/,
        prodOut.join('\n'),
      );
      const productionTemplate = templates.ProductionInfo.replace(
        /{{ProductionTemplates}}/,
        productionXmlTemplate,
      );

      for (let j = 0; j < jobInfoList.length; j++) {
        const { fieldName, value } = jobInfoList[j];
        jobInfoOut.push(
          JobInfoTemplates.li
            .replace(/{{fieldName}}/, fieldName)
            .replace(/{{value}}/, value),
        );
      }
      const jobInfoTemplate = templates.JobInfo.replace(
        /{{JobInfoTemplate}}/,
        jobInfoOut.join('\n'),
      );

      for (let k = 0; k < fileInfoList.length; k++) {
        const { fileName, chapterType, chapterNumber, sequenceNumber } =
          fileInfoList[k];
        if (chapterType != 'Book') {
          fileInfoOut.push(
            FileInfoTemplate.li
              .replace(/{{fileName}}/, fileName)
              .replace(/{{chapterType}}/, chapterType)
              .replace(/{{chapterNumber}}/, chapterNumber)
              .replace(/{{sequenceNumber}}/, sequenceNumber),
          );
        }
      }
      const fileInfoTemplate = templates.FileInfo.replace(
        /{{FileInfotTemplate}}/,
        fileInfoOut.join('\n'),
      );
      finalTemplate =
        templates.xml + productionTemplate + jobInfoTemplate + fileInfoTemplate;
      resolve(finalTemplate);
    } catch (e) {
      reject(e);
      console.log(e, 'error in job info xml');
    }
  });
};
const getJobInfoFileDetails = async woId => {
  const jobInfoList = [];
  try {
    const sql = `select distinct on(incomingdetails.woincomingfileid) incomingdetails.woincomingfileid,incomingdetails.filename,
    incomingdetails.filetypeid,incomingdetails.filesequence,filetypes.filetype
    from wms_workorder_incoming as incoming
    left join wms_workorder_incomingfiledetails as incomingdetails on incomingdetails.woincomingid = incoming.woincomingid
    left join pp_mst_filetype as filetypes on filetypes.filetypeid = incomingdetails.filetypeid
    where incoming.woid = ${woId}`;
    const FileInfoDetails = await query(sql, []);
    FileInfoDetails.forEach(list => {
      jobInfoList.push({
        fileName: list.filename,
        chapterType: list.filetype,
        chapterNumber: list.filesequence,
        sequenceNumber: list.filesequence,
      });
    });
    console.log(jobInfoList, 'jobInfoList');
  } catch (e) {
    console.log(e);
  }
  return jobInfoList;
};
export const getJobInfoDetails = async (req, res) => {
  const { woId, wfEventId, sessionId, workingPath } = req.body;
  const fileInfoList = await getJobInfoFileDetails(woId);
  const prodcutionList = {};
  const jobInfoList = [
    { fieldName: 'Customer Name', value: '', iwmsFieldId: 'countrycode' },
    { fieldName: 'DTD', value: '', iwmsFieldId: 'dtdname' },
    { fieldName: 'ISBN', value: '', iwmsFieldId: 'isbn' },
    { fieldName: 'JobTitle', value: '', iwmsFieldId: 'title' },
    { fieldName: 'OutFilePath', value: '', iwmsFieldId: 'reportFileName' },
    { fieldName: 'Software', value: '', iwmsFieldId: 'appname' },
    { fieldName: 'Verso Format', value: '', iwmsFieldId: 'versoname' },
  ];
  try {
    const sql = `SELECT * from wms_jobinfoxml where wfeventid=${wfEventId}`;
    const jobInfoDetails = await query(sql, []);
    jobInfoDetails.map(async list => {
      const reportFileName = list.repofilepath
        ? basename(list.repofilepath)
        : '';
      const ext = reportFileName ? extname(reportFileName) : '';
      const prodFileName = reportFileName
        ? reportFileName.replace(ext, '')
        : ''.replace('.', '');
      prodcutionList.wmsid = list.customerid == '1' ? 25 : list.wfid;
      prodcutionList.bookid = list.itemcode;
      prodcutionList.countryid = list.countrycode;
      prodcutionList.jobname = list.itemcode;
      prodcutionList.woincomingfileid = list.woincomingfileid;
      prodcutionList.stageid = list.stageid;
      prodcutionList.stagename = list.stagename;
      prodcutionList.volumeid = list.wfid == '11' ? list.volumenumber : 0;
      prodcutionList.activityid = list.activityid;
      prodcutionList.activityname = list.activityname;
      prodcutionList.itrackstageid = list.itracksstageid;
      prodcutionList.userid = list.userid;
      prodcutionList.category = list.categoryalias;
      prodcutionList.templatename = list.wfid;
      prodcutionList.folderid = sessionId;
      prodcutionList.filename = prodFileName;
      prodcutionList.templateid = list.wfid;
      prodcutionList.workingpath = workingPath;
      prodcutionList.jobcardid = list.jobcardid;
      const isbn = list.customerid == '1' ? list.hardbackisbn : list.printisbn;
      if (list.countrycode)
        jobInfoList[
          jobInfoList.findIndex(ro => ro.iwmsFieldId == 'countrycode')
        ].value = list.countrycode;
      if (list.dtdname)
        jobInfoList[
          jobInfoList.findIndex(ro => ro.iwmsFieldId == 'dtdname')
        ].value = list.dtdname;
      if (isbn)
        jobInfoList[
          jobInfoList.findIndex(ro => ro.iwmsFieldId == 'isbn')
        ].value = isbn;
      if (list.title)
        jobInfoList[
          jobInfoList.findIndex(ro => ro.iwmsFieldId == 'title')
        ].value = list.title;
      if (list.repofilepath)
        jobInfoList[
          jobInfoList.findIndex(ro => ro.iwmsFieldId == 'reportFileName')
        ].value = reportFileName;
      if (list.appname)
        jobInfoList[
          jobInfoList.findIndex(ro => ro.iwmsFieldId == 'appname')
        ].value = list.appname;
      if (list.versoname)
        jobInfoList[
          jobInfoList.findIndex(ro => ro.iwmsFieldId == 'versoname')
        ].value = list.versoname;
    });
    console.log(prodcutionList, 'prodcutionList');
    console.log(jobInfoList, 'jobInfoList');
    let ul = {};
    if (
      Object.keys(prodcutionList).length &&
      jobInfoList.length &&
      fileInfoList.length
    ) {
      ul = await jobInfoXmlCreate(prodcutionList, jobInfoList, fileInfoList);
    }
    res.send({ data: ul });
  } catch (e) {
    res.status(400).send({ message: e.message ? e.message : e });
  }
};
