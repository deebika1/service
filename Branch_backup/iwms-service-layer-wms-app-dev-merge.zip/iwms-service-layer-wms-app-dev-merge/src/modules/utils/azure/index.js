import { createReadStream } from 'fs';
import path from 'path';
import FormData from 'form-data';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import logger from '../logs/index.js';
import { getsftpConfig } from '../../filetransferkit/index.js';
import { query } from '../../../database/postgres.js';
import { _localdownload } from '../local/index.js';

const service = new Service();

export const fileUpload = async (req, res) => {
  try {
    const { docPath } = req.body;
    const fileName = 'content';
    const newName =
      req.body && req.body.key && req.body.key == 'test'
        ? req.body.file
        : req.files[fileName];
    const result = await _upload(newName, docPath);
    logger.info(result, 'azure file upload success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file upload err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const listCurrentDirectory = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.retreiveBlobRootList;
      const encodedURL = encodeURI(pth);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};
export const _upload = (file, docPath) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (docPath != '') {
        const url = config.blob_rest.uri.upload;
        const formData = new FormData();
        const fPath = `${docPath}${file.name}`;
        const encodedURL = encodeURI(fPath);
        formData.append('content', createReadStream(file.tempFilePath));
        formData.append('docPath', encodedURL);
        const headers = {
          'Content-Type': 'multipart/form-data',
          ...formData.getHeaders(),
        };
        const result = await service.uploadPost(
          `${config.blob_rest.base_url}${url}`,
          formData,
          headers,
        );
        const { data, status } = result;
        const response = {
          data: {
            ...data,
            okmPath: docPath,
            name: file.name,
            fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
          },
          status,
          fullPath: path.join(docPath, file.name).replace(/\\/g, '/'),
        };
        resolve(response);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const fileDelete = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _delete(pth);
    logger.info(result, 'azure file delete success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file delete err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const listAllFiles = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _listAllFiles(pth);
    logger.info(result, 'azure file delete success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file delete err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _listAllFiles = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.retreiveBlobFiles;
      const encodedURL = encodeURI(pth);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const _blobExist = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.blobExist;
      const encodedURL = encodeURI(pth);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(Array.isArray(result) ? result : result.data);
    } catch (err) {
      reject(err);
    }
  });
};
export const _delete = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.delete;
      const encodedURL = encodeURI(pth);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docId=${encodedURL}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};

export const fileDownload = async (req, res) => {
  try {
    const { path: pth } = req.body;
    const result = await _download(pth);
    logger.info(result, 'azure file download success');
    res.status(200).send(result);
  } catch (err) {
    logger.info(err, 'azure file download err');
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const _download = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.download;
      const encodedURL = encodeURI(pth);
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docPath=${encodedURL}`,
      );
      resolve(result);
    } catch (err) {
      reject(err);
    }
  });
};
export const localFileGetDownload = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.local_rest.uri.localdownload;
      const docPath1 = pth.body.path;
      // let fileName = path.basename(docPath1)
      // const folderPat = path.join('uploads',fileName)
      // resolve(docPath1);
      const result = await service.get(
        `${config.local_rest.base_url}${url}?docPath=${docPath1}`,
      );
      // let writeStream = createWriteStream(folderPat);
      // result.data.pipe(writeStream);
      // writeStream.on('finish', () => {
      //     console.log('success')
      //     resolve();
      // })
      // writeStream.on('error', (error) => {
      //    reject(error);
      // })
      resolve(result);
    } catch (err) {
      reject(err);
    }
  });
};
export const _copyFile = (
  { srcPath, name, destBasePath, customerName },
  isNewmsContainer = true,
) => {
  const url = isNewmsContainer
    ? config.blob_rest.uri.copy
    : config.local_rest.uri.copyExternalBlobToBlob;
  const targetPath = destBasePath + name;
  const encodedSrcURL = encodeURI(srcPath);
  const encodedTargetURL = encodeURI(targetPath);

  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('docId', encodedSrcURL);
      formData.append('dstId', encodedTargetURL);
      formData.append('customerName', customerName);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.blob_rest.base_url}${url}`,
        formData,
        headers,
      );
      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};

export const renameBlob = ({ srcPath, name, destBasePath }) => {
  const url = config.blob_rest.uri.rename;
  const targetPath = destBasePath + name;
  const encodedSrcURL = encodeURI(srcPath);
  const encodedTargetURL = encodeURI(targetPath);
  return new Promise(async (resolve, reject) => {
    try {
      const formData = new FormData();
      formData.append('docId', encodedSrcURL);
      formData.append('dstId', encodedTargetURL);
      const headers = {
        ...formData.getHeaders(),
      };
      await service.post(
        `${config.blob_rest.base_url}${url}`,
        formData,
        headers,
      );
      resolve({ path: targetPath, uuid: 'azure' });
    } catch (err) {
      reject(err);
    }
  });
};

export const _downloadBlobFiles = async (req, res) => {
  try {
    const { dmsType } = req.body.data.iwms;
    let fileDetails = {};
    switch (dmsType) {
      case 'azure':
        fileDetails = await _download(req.body.data.source);
        break;
      case 'local':
        fileDetails = await _localdownload(req.body.data.source);
        break;
      default:
        break;
    }
    const configDetails = await getsftpConfig(
      req.body.data.iwms.custId,
      req.body.data.type,
      req.body.data.iwms.woId,
    );
    const statusCheck = await ftpUploadStatusCheck(req.body.data);
    res.status(200).send({ result: configDetails, fileDetails, statusCheck });
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};

export const ftpUploadStatusCheck = data => {
  return new Promise(async (resolve, reject) => {
    console.log(data);
    try {
      if (data.iwms.custId == 8) {
        const sql = `select count(*) from wms_tools_api_list where  workorderid =${data.iwms.woId} and stageid= ${data.iwms.stageId} and  toolid= 346 and status ='Success' `;
        const result = await query(sql);
        resolve(result[0].count == 0);
      } else {
        const sql = `select count(*) from wms_tools_api_list where  workorderid =${data.iwms.woId} and stageid= ${data.iwms.stageId} and activityid=${data.iwms.activityId} and  toolid= 346 and status ='Success' `;
        const result = await query(sql);
        resolve(result[0].count == 0);
      }
    } catch (err) {
      reject(err);
    }
  });
};

export const getToolListPath = async (req, res) => {
  try {
    const sql = `select tool.toolid as "ExeId",type.tooltype,tool.toolname as "ExeName",tool.tooldescription,tool.customerid,((tool.payload->>'dependentFiles')::json)->0->'src' as "Path"  
    ,toolsrights.read, 
    toolsrights.upload,toolsrights.delete from pp_mst_tool tool
    join pp_mst_tooltype type on type.tooltypeid = tool.tooltypeid
    join  wms_tools_accessrights as toolsrights on toolsrights.exeid= tool.toolid
    where tool.tooltypeid = 2 and tool.toolstatus = true and toolsrights.duid=${req.body.data} and toolsrights.userid ='${req.body.userId}'
    and toolsrights.useractive=true`;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (err) {
    res.status(400).send({ message: err.message ? err.message : err });
  }
};
