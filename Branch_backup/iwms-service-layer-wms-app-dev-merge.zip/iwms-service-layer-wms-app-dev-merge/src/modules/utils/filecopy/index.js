import { Service } from '../../../httpClient/index.js';
import { query } from '../../../database/postgres.js';
import logger from '../logs/index.js';
import { config } from '../../../config/restApi.js';

const service = new Service();
// file copy external blob to local
export const copyExternalBlobToLocal = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        srcPath,
        destBasePath,
        name,
        customerName,
        customerId,
        containerType,
      } = data;
      const { confvalue, type } = await getContainerInfo({
        customerId,
        containerType,
      });
      if (type == 'e2e') {
        const containerInfo = confvalue;
        const source = encodeURI(srcPath);
        const dest = encodeURI(destBasePath + name);
        const sourceCustomer = customerName;
        const payload = {
          source,
          dest,
          sourceCustomer,
          containerInfo,
        };
        const response = await service.post(
          config.local_rest.base_url +
            config.local_rest.uri.copyExternalBlobToLocal,
          payload,
        );
        resolve(response.data);
      } else {
        reject('Customer container info not found');
      }
    } catch (error) {
      logger.info('copyExternalBlobToLocal : ', error);
      reject(error);
    }
  });
};
// file copy external blob to blob
export const copyExternalBlobToBlob = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        srcPath,
        destBasePath,
        name,
        customerName,
        customerId,
        containerType,
      } = data;
      const { confvalue, type } = await getContainerInfo({
        customerId,
        containerType,
      });
      if (type == 'e2e') {
        const containerInfo = confvalue;
        const source = encodeURI(srcPath);
        const dest = encodeURI(destBasePath + name);
        const sourceCustomer = customerName;
        const payload = {
          source,
          dest,
          sourceCustomer,
          containerInfo,
        };
        const response = await service.post(
          config.blob_rest.base_url +
            config.blob_rest.uri.copyExternalBlobToBlob,
          payload,
        );
        resolve(response.data);
      } else {
        reject('Customer container info not found');
      }
    } catch (error) {
      logger.info('copyExternalBlobToBlob : ', error);
      reject(error);
    }
  });
};

// get container info based on customer
const getContainerInfo = data => {
  const { customerId, containerType } = data;
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select confvalue::json, type from wms_mst_configurationdetails where customerid = ${customerId} and isactive = true and type = '${containerType}'`;
      const result = await query(sql);
      if (result.length > 0) {
        resolve(result[0]);
      } else {
        reject('Customer container info not found');
      }
    } catch (error) {
      reject(error);
    }
  });
};

export const _localcopyFile = ({ srcPath, name, destBasePath }) => {
  return new Promise(async (resolve, reject) => {
    try {
      const payload = {
        docId: srcPath,
        dstId: destBasePath + name,
      };
      const response = await service.post(
        config.local_rest.base_url +
          config.local_rest.uri.localmultiplefileCopy,
        payload,
      );
      resolve(response.data);
    } catch (err) {
      logger.info(err, 'file copy err');
      reject('File copy failed');
    }
  });
};
