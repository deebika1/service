// import path from 'path';
import { wmsConfig, localwmsConfig } from '../../../config/wms.js';
import { query } from '../../../database/postgres.js';
import { getdmsType } from '../../bpmn/listener/create.js';

export const getFolderPath = async (req, res) => {
  try {
    console.log(res.send(await getFolderStructure(req.body)), 'test');
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getFolderStructure = async ({
  type,
  du,
  customer,
  journal,
  workOrderId,
  service,
  stage,
  activity,
  fileType,
  queryId,
  template,
}) => {
  let folderTemplate = '';
  let dmsType = '';
  if (workOrderId) dmsType = await getdmsType(workOrderId);
  if (type === 'template') {
    folderTemplate = template;
  } else {
    folderTemplate = await okmTemplateMap(dmsType, du, customer);
    folderTemplate = folderTemplate[type];
  }
  folderTemplate = folderTemplate || '';
  // return path.normalize(
  return folderTemplate
    .replace(/{DU_NAME}/, getFolderFullName(du))
    .replace(/{CUSTOMER_NAME}/, getFolderFullName(customer))
    .replace(/{JOURNAL_NAME}/, getFolderFullName(journal))
    .replace(/{WORK_ORDER_ID}/, workOrderId)
    .replace(/{SERVICE_NAME}/, getFolderFullName(service))
    .replace(/{STAGE_NAME}/, getFolderFullName(stage))
    .replace(
      /{STAGE_ITERATION}/,
      stage?.iteration ? stage.iteration : undefined,
    )
    .replace(/{ACTIVITY_NAME}/, getFolderFullName(activity))
    .replace(
      /{ACTIVITY_ITERATION}/,
      activity?.iteration ? activity.iteration : undefined,
    )
    .replace(/{FILE_TYPE}/, getFolderFullName(fileType))
    .replace(/{FILE_ID}/, fileType?.fileId ? fileType.fileId : undefined)
    .replace(/{QUERY_ID}/, queryId || undefined)
    .replace(/ /g, '_');
  // );
};

export const getFolderStructure_autowocreate = async req => {
  return new Promise(async resolve => {
    try {
      const {
        type,
        du,
        customer,
        journal,
        workOrderId,
        service,
        stage,
        activity,
        fileType,
        queryId,
        template,
      } = req.body;

      let folderTemplate = '';
      let dmsType = '';
      if (workOrderId) dmsType = await getdmsType(workOrderId);

      if (type === 'template') {
        folderTemplate = template;
      } else {
        folderTemplate = await okmTemplateMap(dmsType, du, customer);
        folderTemplate = folderTemplate[type];
      }
      // folderTemplate =
      // type === 'template' ? template : okmTemplateMap()[type];
      folderTemplate = folderTemplate || '';
      resolve(
        folderTemplate
          .replace(/{DU_NAME}/, getFolderFullName(du))
          .replace(/{CUSTOMER_NAME}/, getFolderFullName(customer))
          .replace(/{JOURNAL_NAME}/, getFolderFullName(journal))
          .replace(/{WORK_ORDER_ID}/, workOrderId)
          .replace(/{SERVICE_NAME}/, getFolderFullName(service))
          .replace(/{STAGE_NAME}/, getFolderFullName(stage))
          .replace(
            /{STAGE_ITERATION}/,
            stage?.iteration ? stage.iteration : undefined,
          )
          .replace(/{ACTIVITY_NAME}/, getFolderFullName(activity))
          .replace(
            /{ACTIVITY_ITERATION}/,
            activity?.iteration ? activity.iteration : undefined,
          )
          .replace(/{FILE_TYPE}/, getFolderFullName(fileType))
          .replace(/{FILE_ID}/, fileType?.fileId ? fileType.fileId : undefined)
          .replace(/{QUERY_ID}/, queryId || undefined)
          .replace(/ /g, '_'),
      );
    } catch (error) {
      console.log(error, 'localfilecopy');
    }
  });
};

const okmTemplateMap = async (dmsType, duid, customerid) => {
  return new Promise(async resolve => {
    let okm;
    switch (dmsType) {
      case 'local':
        const sql = `select * from wms_mst_customerconfigdetails where customerid =${customerid.id} and duid =${duid.id}`;
        const GetLocalbaseUrl = await query(sql);
        const localwmsConfig_1 = localwmsConfig(
          GetLocalbaseUrl[0].localserverpath,
        );
        okm = localwmsConfig_1.okm;
        break;
      default:
        okm = wmsConfig.okm;
        break;
    }

    // switch (dmsType) {
    //   case 'local':
    //     const sql = `select * from wms_mst_customerconfigdetails where customerid =${customerid} and duid =${duid}`;
    //     const GetLocalbaseUrl = await query(sql);
    //     const localwmsConfig_1 = localwmsConfig(
    //       GetLocalbaseUrl[0].localserverpath,
    //     );
    //     okm = localwmsConfig_1.okm;
    //     break;
    //   default:
    //     okm = wmsConfig.okm;
    //     break;
    // }
    const { du } = okm.base;
    const { customer } = du;
    const { wo } = customer;
    const { service } = wo;
    const { incoming, stage } = service;
    const { activity } = stage.iteration;

    resolve({
      // okm
      okm: `${okm.path}/`,
      okm_common: `${okm.common.path}/`,

      // base
      base: `${okm.base.path}/`,
      base_common: `${okm.base.common.path}/`,
      // service layer logs
      okm_logpath: `${okm.common.path}/servicelayer_logs/`,
      // du
      du: `${du.path}/`,
      du_common: `${du.common.path}/`,

      // customer
      customer: `${customer.path}/`,
      customer_common: `${customer.common.path}/`,

      // journal instruction
      journal_instructions: `${customer.journals.journal.path}/`,

      // wo
      wo: `${wo.path}/`,
      wo_common: `${wo.common.path}/`,
      wo_mail: `${wo.common.mail.path}/`,

      // wo service
      wo_service: `${service.path}/`,
      wo_service_common: `${service.common.path}/`,
      wo_service_mail: `${service.common.mail.path}/`,

      // wo stage
      wo_stage: `${stage.path}/`,
      wo_stage_common: `${stage.common.path}/`,
      wo_stage_graphic: `${stage.common.graphic.path}/`,
      wo_stage_instructions: `${stage.common.instructions.path}/`,
      wo_stage_query: `${stage.common.query.path}/`,
      wo_stage_iteration: `${stage.iteration.path}/`,
      wo_stage_iteration_common: `${stage.iteration.common.path}/`,
      wo_stage_iteration_mail: `${stage.iteration.common.mail.path}/`,

      // wo activity
      wo_activity: `${activity.path}/`,
      wo_activity_common: `${activity.common.path}/`,
      wo_activity_iteration: `${activity.iteration.path}/`,
      wo_activity_iteration_common: `${activity.iteration.common.path}/`,

      // wo file type
      wo_activity_filetype: `${activity.iteration.fileType.path}/`,
      wo_activity_file_subtype: `${activity.iteration.fileType.sub.path}/`,

      // wo incoming
      wo_incoming: `${incoming.path}/`,

      // wo incoming file type
      wo_incoming_filetype: `${incoming.fileType.path}/`,
      wo_incoming_file_subtype: `${incoming.fileType.sub.path}/`,

      // Proof central file
      wo_proofcentral: `${stage.iteration.common.proofCentral.path}/`,

      // iopp
      ioopp_ftp: `${stage.iteration.common.ioppPath.path}/`,
    });
  });
};

/// old
// const okmTemplateMap_old = () => {
//   const { okm } = wmsConfig;
//   const { du } = okm.base;
//   const { customer } = du;
//   const { wo } = customer;
//   const { service } = wo;
//   const { incoming, stage } = service;
//   const { activity } = stage.iteration;

//   return {
//     // okm
//     okm: `${okm.path}/`,
//     okm_common: `${okm.common.path}/`,

//     // base
//     base: `${okm.base.path}/`,
//     base_common: `${okm.base.common.path}/`,
//     // service layer logs
//     okm_logpath: `${okm.common.path}/servicelayer_logs/`,
//     // du
//     du: `${du.path}/`,
//     du_common: `${du.common.path}/`,

//     // customer
//     customer: `${customer.path}/`,
//     customer_common: `${customer.common.path}/`,

//     // journal instruction
//     journal_instructions: `${customer.journals.journal.path}/`,

//     // wo
//     wo: `${wo.path}/`,
//     wo_common: `${wo.common.path}/`,
//     wo_mail: `${wo.common.mail.path}/`,

//     // wo service
//     wo_service: `${service.path}/`,
//     wo_service_common: `${service.common.path}/`,
//     wo_service_mail: `${service.common.mail.path}/`,

//     // wo stage
//     wo_stage: `${stage.path}/`,
//     wo_stage_common: `${stage.common.path}/`,
//     wo_stage_graphic: `${stage.common.graphic.path}/`,
//     wo_stage_instructions: `${stage.common.instructions.path}/`,
//     wo_stage_query: `${stage.common.query.path}/`,
//     wo_stage_iteration: `${stage.iteration.path}/`,
//     wo_stage_iteration_common: `${stage.iteration.common.path}/`,
//     wo_stage_iteration_mail: `${stage.iteration.common.mail.path}/`,

//     // wo activity
//     wo_activity: `${activity.path}/`,
//     wo_activity_common: `${activity.common.path}/`,
//     wo_activity_iteration: `${activity.iteration.path}/`,
//     wo_activity_iteration_common: `${activity.iteration.common.path}/`,

//     // wo file type
//     wo_activity_filetype: `${activity.iteration.fileType.path}/`,
//     wo_activity_file_subtype: `${activity.iteration.fileType.sub.path}/`,

//     // wo incoming
//     wo_incoming: `${incoming.path}/`,

//     // wo incoming file type
//     wo_incoming_filetype: `${incoming.fileType.path}/`,
//     wo_incoming_file_subtype: `${incoming.fileType.sub.path}/`,

//     // Proof central file
//     wo_proofcentral: `${stage.iteration.common.proofCentral.path}/`,

//     // iopp
//     ioopp_ftp: `${stage.iteration.common.ioppPath.path}/`,
//   };
// };

const getFolderFullName = folderData => {
  if (folderData && folderData.name && (folderData.id == 0 || folderData.id)) {
    return `${folderData.name.toLowerCase()}_${folderData.id
      .toString()
      .toLowerCase()}`;
  }
  return undefined;
};

export const getTemplatePath = (req, res) => {
  res.send(getTemplatePathStructure(req.body));
};

export const getTemplatePathStructure = ({
  duID,
  customerId,
  softwareId,
  libraryId,
}) => {
  const {
    okm: {
      base: { composingswtemplates },
    },
  } = wmsConfig;
  return composingswtemplates.path
    .replace(/{DU_ID}/, duID)
    .replace(/{CUSTOMER_ID}/, customerId)
    .replace(/{SW_ID}/, softwareId)
    .replace(/{SW_ID}/, libraryId)
    .replace(/ /g, '_');
};

export const getTemplateSrcDetails = (req, res) => {
  const { woId } = req.body;
  const sql = `select * ,'update' as type from wms_workorder_swtemplate  as wotemplate
  join wms_mst_composingsw_templates as templates on templates.templateid = wotemplate.templateid
  where wotemplate.workorderid=${woId} and wotemplate.isactive=true and templates.isdelete = false`;
  query(sql)
    .then(data => {
      if (data && data.length == 0) {
        const sql1 = `select *, 'delete' as type from wms_workorder_swtemplate  as wotemplate
                join wms_mst_composingsw_templates as templates on templates.templateid = wotemplate.templateid
                where wotemplate.workorderid=${woId} and wotemplate.isactive=true`;
        query(sql1).then(data1 => {
          res
            .status(200)
            .json({ data: data && data.length > 0 ? data : data1 });
        });
      } else {
        res.status(200).json({ data });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
