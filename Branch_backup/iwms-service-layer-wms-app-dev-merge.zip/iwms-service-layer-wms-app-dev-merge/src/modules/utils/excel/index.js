import xl from 'excel4node';

export const exportToExcel = (wbData, wbField, name, sheetName, res) => {
  const wb = new xl.Workbook({
    dateFormat: 'm/d/yy',
  });
  const ws = wb.addWorksheet(sheetName);

  const HeaderStyle = wb.createStyle({
    font: {
      color: '#6675A2',
      size: 14,
    },
  });

  const wbFieldKeys = Object.keys(wbField);
  for (let i = 0; i < wbFieldKeys.length; i++) {
    const row = 1;
    const col = i + 1;
    ws.cell(row, col).string(wbFieldKeys[i]).style(HeaderStyle);
  }

  for (let i = 0; i < wbData.length; i++) {
    for (let j = 0; j < wbFieldKeys.length; j++) {
      const row = i + 2;
      const col = j + 1;
      const field = wbField[wbFieldKeys[j]];
      const fieldValue = wbData[i][field] ? wbData[i][field] : '';
      const filedDataType = getDataType(fieldValue);
      ws.cell(row, col)[filedDataType](
        filedDataType == 'string' ? fieldValue.toString() : fieldValue,
      );
    }
  }
  wb.write(`${name}.xlsx`, res);
};

const getDataType = data => {
  const type = Object.prototype.toString.call(data);
  switch (type) {
    case '[object Date]':
      return 'date';
    case '[object Number]':
      return 'number';
    case '[object Boolean]':
      return 'bool';
    default:
      return 'string';
  }
};
