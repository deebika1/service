import querystring from 'querystring';
import { createReadStream } from 'fs';
import path from 'path';
import FormData from 'form-data';
import { Service } from '../../../httpClient/index.js';
import { config } from '../../../config/restApi.js';
import logger from '../logs/index.js';
import * as azureHelper from '../azure/index.js';
import * as localHelper from '../local/index.js';

const service = new Service();

export const getDocumentProps = async (req, res) => {
  const { uuid } = req.body;
  try {
    const headers = {
      Authorization: `Basic ${process.env.OKM_AUTH}`,
    };
    const url = config.okmNative.uri.getDocumentProps;
    const data = querystring.stringify({
      docId: uuid,
    });
    const prop = await service.get(
      `${config.okmNative.base_url}${url}?${data}`,
      {},
      headers,
    );
    res.send(prop);
  } catch (err) {
    logger.info(err, 'getDocumentProps');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const __getDocumentProps = async uuid => {
  return new Promise(async (resolve, reject) => {
    try {
      const headers = {
        Authorization: `Basic ${process.env.OKM_AUTH}`,
      };
      const url = config.okmNative.uri.getDocumentProps;
      const data = querystring.stringify({
        docId: uuid,
      });
      const prop = await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      resolve(prop);
    } catch (err) {
      logger.info(err, 'getDocumentProps');
      reject(err);
    }
  });
};

export const getRestoreVersion = async (req, res) => {
  const { uuid } = req.body;
  try {
    const restoreVersionData = await __getDocumentProps(uuid);
    logger.info(restoreVersionData, 'restoreVersionData');

    const headers = {
      Authorization: `Basic ${process.env.OKM_AUTH}`,
    };
    const url = config.okmNative.uri.restoreVersion;
    const restoreVersionName =
      Object.keys(restoreVersionData.data).length > 0 &&
      restoreVersionData.data.actualVersion &&
      Object.keys(restoreVersionData.data.actualVersion).length > 0
        ? restoreVersionData.data.actualVersion.name
        : '1.0';
    let restoreVersionId;
    if (Number.isInteger(restoreVersionName)) {
      restoreVersionId = `${restoreVersionName}.0`;
    } else {
      // const restoreVersionIdDecimal = Math.floor(
      //   (restoreVersionName - Math.floor(restoreVersionName)) * 10,
      // );
      const value = restoreVersionName.toString().split('.');
      const decimalValue =
        value && value.length > 0 ? `.${value[1] - 1}` : '.0';
      restoreVersionId = value && value[0] ? value[0] + decimalValue : '1.0';
    }
    const data = querystring.stringify({
      docId: uuid,
      versionId: restoreVersionId,
    });
    const prop = await service.put(
      `${config.okmNative.base_url}${url}?${data}`,
      {},
      headers,
    );
    res.send(prop);
  } catch (err) {
    logger.info(err, 'getRestoreVersion');
    res.status(400).send({ message: err });
  }
};

export const checkout = async (req, res) => {
  const { uuid } = req.body;
  try {
    await checkoutOpenKMFile(uuid);
    res.send(true);
  } catch (err) {
    logger.info(err, 'checkout');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const deleteFile = async (req, res) => {
  const { uuid } = req.body;
  try {
    await _deleteFile(uuid);
    res.send(true);
  } catch (err) {
    logger.info(err, 'deleteFile');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const _deleteFile = uuid => {
  return new Promise(async (resolve, reject) => {
    try {
      const headers = {
        Authorization: `Basic ${process.env.OKM_AUTH}`,
      };
      const url = config.okmNative.uri.documentDelete;
      const data = querystring.stringify({
        docId: uuid,
      });
      await service.delete(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      resolve(true);
    } catch (err) {
      if (
        err.message &&
        err.message.data &&
        err.message.data.split(':')[0] == 'PathNotFoundException'
      ) {
        resolve(true);
      } else {
        reject(err);
      }
    }
  });
};

export const createFolder = async (req, res) => {
  const { folderName } = req.body;
  try {
    const uuid = await _createFolder(folderName);
    res.send(uuid);
  } catch (err) {
    logger.info(err, 'createFolder');
    res.status(400).send({ message: `create folder failed : ${folderName}` });
  }
};

export const createMissingFolders = async folderPath => {
  return new Promise(async (resolve, reject) => {
    try {
      const uuidData = await _getUuid(folderPath);
      resolve(uuidData);
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        try {
          const headers = {
            Authorization: `Basic ${process.env.OKM_AUTH}`,
          };
          const url = config.okmNative.uri.createFolder;
          const createResponse = await service.post(
            `${config.okmNative.base_url}${url}`,
            folderPath,
            headers,
          );
          resolve(createResponse.data.uuid);
        } catch (error) {
          reject(error);
        }
      } else {
        reject(err);
      }
    }
  });
};

export const folderCreate = async folderPath => {
  return new Promise(async (resolve, reject) => {
    try {
      const uuidData = await _getUuid(folderPath);
      resolve(uuidData);
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        try {
          const headers = {
            Authorization: `Basic ${process.env.OKM_AUTH}`,
          };
          const url = config.okmNative.uri.folderCreate;
          const data = querystring.stringify({
            fldPath: folderPath,
          });
          await service.put(
            `${config.okmNative.base_url}${url}?${data}`,
            folderPath,
            headers,
          );
          const uuidData = await _getUuid(folderPath);
          resolve(uuidData);
        } catch (error) {
          reject(error);
        }
      } else {
        reject(err);
      }
    }
  });
};

export const _createFolder = folderName => {
  return new Promise(async (resolve, reject) => {
    try {
      const uuidData = await _getUuid(folderName);
      logger.info(
        `skipped folder creation due to path already exists (${folderName})`,
      );
      resolve(uuidData);
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        try {
          const uuidData = await createSimpleFolder(folderName);
          resolve(uuidData);
        } catch (error) {
          reject(error);
        }
      } else {
        reject(err);
      }
    }
  });
};

const createSimpleFolder = folderName => {
  const folders = folderName.split('/');
  return new Promise(async (resolve, reject) => {
    try {
      let curPath = '';
      let uuid = '';
      for (let i = 0; i < folders.length; i++) {
        if (folders[i] && folders[i] !== 'okm:root') {
          curPath += `/${folders[i]}`;
          uuid = await makeDirectory(curPath);
        }
      }
      logger.info(`folder created ${curPath}`);
      resolve(uuid);
    } catch (err) {
      logger.info(err, 'createSimpleFolder');
      reject(err);
    }
  });
};

const makeDirectory = folderName => {
  folderName = `/okm:root${folderName}`;
  return new Promise(async (resolve, reject) => {
    try {
      const uuidData = await _getUuid(folderName);
      resolve(uuidData);
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        try {
          const headers = {
            Authorization: `Basic ${process.env.OKM_AUTH}`,
          };
          const url = config.okmNative.uri.createFolder;
          const createResponse = await service.post(
            `${config.okmNative.base_url}${url}`,
            folderName,
            headers,
          );
          resolve(createResponse.data.uuid);
        } catch (error) {
          logger.info(error, 'uuidData');
          reject(error);
        }
      } else {
        logger.info(err, 'ItemExistsException not found');
        reject(err);
      }
    }
  });
};

export const getUuid = async (req, res) => {
  const { path: pth } = req.body;
  try {
    const uuid = await _getUuid(pth);
    res.send(uuid);
  } catch (err) {
    logger.info(err, 'getUuid');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const _getUuid = pth => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.getUuid;
  const data = querystring.stringify({
    nodePath: pth,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const response = await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      resolve(response.data);
    } catch (err) {
      reject(err);
    }
  });
};

export const isFileExist = async (req, res) => {
  const { path: pth } = req.body;
  try {
    const fileExistDetails = await _isFileExist(pth);
    res.send(fileExistDetails);
  } catch (err) {
    logger.info(err, 'isFileExist');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const uploadFileCreateAndUpdate = async (req, res) => {
  const { docPath } = req.body;
  uploadFiletoOpenKM(req, docPath, 'content')
    .then(response => {
      logger.info(response, 'response for fileupload');
      res.status(200).json({
        data: response,
        fullPath: response.joinPath.replace(/\\/g, '/'),
      });
    })
    .catch(err => {
      logger.info(err, 'uploadFiletoOpenKM');
      res
        .status(400)
        .send({ message: err.message?.data ? err.message?.data : err });
    });
};

export const uploadFiletoOpenKM = async (req, okmPath, fileName) => {
  return new Promise(async (resolve, reject) => {
    let uuid = '';
    try {
      const isTargetDetails = await _isFileExist(
        `${okmPath}/${req.files[fileName].name}`,
      );
      if (isTargetDetails.isExist) {
        await _deleteFile(isTargetDetails.uuid);
      }
      await folderCreate(okmPath);
      const formData = new FormData();
      formData.append(
        'content',
        createReadStream(req.files[fileName].tempFilePath),
      );
      formData.append('docPath', `${okmPath}${req.files[fileName].name}`);
      const header = {
        Authorization: `Basic ${process.env.OKM_AUTH}`,
        'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
      };
      const response = await service.upload(
        `${config.okmNative.base_url}${config.okmNative.uri.createFile}`,
        formData,
        header,
      );
      console.log(response, 'resss');
      uuid = response.uuid;
      resolve({
        uuid,
        okmPath,
        path: okmPath,
        name: req.files[fileName].name,
        joinPath: path.join(
          okmPath,
          req.files[fileName].name.replace(/\\/g, '/'),
        ),
      });
    } catch (e) {
      logger.info(e, 'uploadFiletoOpenKM error');
      if (e?.message?.data) {
        e.message = e.message.data.includes('FileNotFoundException')
          ? 'Uploading was interrupted. Please retry the current action'
          : e.message.data;
      }
      reject(e);
    }
  });
};

export const _isFileExist = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const uuid = await _getUuid(pth);
      resolve({ isExist: true, uuid, path: pth });
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        resolve({ isExist: false });
      } else {
        reject(err);
      }
    }
  });
};

export const _isOkmNativeFileExist = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const headers = {
        Authorization: `Basic ${process.env.OKM_AUTH}`,
      };
      const url = config.okmNative.uri.getUuid;
      const data = querystring.stringify({
        nodePath: pth,
      });
      const response = await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      resolve({ isExist: true, uuid: response.data });
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        resolve({ isExist: false, uuid: undefined });
      } else {
        reject(err);
      }
    }
  });
};
export const copyFile = async (req, res) => {
  const { src, dest, name, destBasePath } = req.body;
  try {
    const data = await _copyFile({ src, dest, name, destBasePath });
    res.status(200).json(data);
  } catch (err) {
    logger.info(err, 'copyFile');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const _copyFile = ({ src, dest, name, destBasePath }) => {
  const targetPath = destBasePath + name;
  return new Promise(async (resolve, reject) => {
    try {
      const uuidData = await _getUuid(targetPath);
      resolve({ path: targetPath, uuid: uuidData });
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        try {
          const headers = {
            Authorization: `Basic ${process.env.OKM_AUTH}`,
          };
          const url = config.okmNative.uri.documentCopy;
          const data = querystring.stringify({
            docId: src,
            dstId: dest,
            name,
          });
          await service.put(
            `${config.okmNative.base_url}${url}?${data}`,
            {},
            headers,
          );
          const uuidData = await _getUuid(targetPath);
          resolve({ path: targetPath, uuid: uuidData });
        } catch (error) {
          reject(error);
        }
      } else {
        reject(err);
      }
    }
  });
};

export const retreiveFiles = async (req, res) => {
  const { path: pth, dmsType } = req.body;
  try {
    // when okm slow down file not fetching so another function used
    // const data = await retreiveOKMFiles(path);
    switch (dmsType) {
      case 'azure':
        res.status(200).json(await azureHelper._listAllFiles(pth));
        break;
      case 'local':
        res.status(200).json(await localHelper._locallistAllFiles(pth));
        break;
      default:
        res.status(200).json(await ListAllChildDocument(pth));
        break;
    }
  } catch (err) {
    logger.info(err, 'retreiveFiles');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const retreiveOKMFiles = pth => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.retreiveFiles;
  const data = querystring.stringify({
    path: pth,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const searchResponse = await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      let filesData = [];
      if (Object.keys(searchResponse.data).length) {
        filesData = Array.isArray(searchResponse.data.queryResult)
          ? searchResponse.data.queryResult
          : [searchResponse.data.queryResult];
      }
      const FileList = [];
      filesData.forEach(file => {
        if (file.node.locked == false) {
          FileList.push({ path: file.node.path, uuid: file.node.uuid });
        }
      });
      resolve(FileList);
    } catch (err) {
      if (err.message?.data && err.message.data.includes('Path Not Found')) {
        logger.info('Path Not Found :: ', err.message.data);
        resolve([]);
      } else {
        reject(err);
      }
    }
  });
};

export const okmChecksum = uuid => {
  return new Promise(async (resolve, reject) => {
    try {
      const headers = {
        Authorization: `Basic ${process.env.OKM_AUTH}`,
      };
      const url = config.okmNative.uri.getDocumentProps;
      const data = querystring.stringify({
        docId: uuid,
      });
      const docProp = await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      resolve(docProp.data.actualVersion.checksum);
    } catch (e) {
      reject(e);
    }
  });
};

export const checkoutOpenKMFile = uuid => {
  return new Promise(async (resolve, reject) => {
    try {
      const headers = {
        Authorization: `Basic ${process.env.OKM_AUTH}`,
      };
      const url = config.okmNative.uri.checkout;
      const data = querystring.stringify({
        docId: uuid,
      });
      await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
};
export const copyFolderExtendedCopy = (fldId, dstId) => {
  const reponseDelete = [];
  const copyFolder = [];
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.extendedCopy;
  const data = querystring.stringify({
    fldId,
    dstId,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const folderFileDetails = await service.put(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      logger.info(folderFileDetails, 'folderFileDetails');
      resolve(folderFileDetails);
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('ItemExistsException')
      ) {
        const dstIdPath = err.message.data
          .replace('ItemExistsException:', '')
          .trim();
        const dstId1 = await _getUuid(dstIdPath);
        logger.info(fldId, dstId1, 'extend folfer copy');
        reponseDelete.push(await folderDelete(dstId1));
        copyFolder.push(await copyFolderCopy(fldId, dstId));
        await Promise.all([...reponseDelete, ...copyFolder]).then(() => {
          resolve({ status: true });
        });
      } else {
        reject(err);
      }
    }
  });
};

export const getFolderChildrenProperties = fldId => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.folderChildren;
  const data = querystring.stringify({
    fldId,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const folderDetails = await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      logger.info(folderDetails, 'folderDetails');
      const result =
        folderDetails &&
        Object.keys(folderDetails).length > 0 &&
        folderDetails.data &&
        folderDetails.data.folder
          ? folderDetails.data.folder
          : folderDetails &&
            Object.keys(folderDetails).length > 0 &&
            folderDetails.folder
          ? folderDetails.folder
          : [];
      resolve(result);
    } catch (err) {
      if (err.message?.data && err.message.data.includes('Path Not Found')) {
        logger.info('Path Not Found :: ', err.message.data);
        resolve([]);
      } else {
        reject(err);
      }
    }
  });
};

export const getDocumentChildrenProperties = fldId => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.documentChildren;
  const data = querystring.stringify({
    fldId,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const documentFileDetails = await service.get(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      logger.info(documentFileDetails, 'documentFileDetails');
      const result =
        documentFileDetails &&
        Object.keys(documentFileDetails).length > 0 &&
        documentFileDetails.data &&
        documentFileDetails.data.document
          ? documentFileDetails.data.document
          : documentFileDetails &&
            Object.keys(documentFileDetails).length > 0 &&
            documentFileDetails.document
          ? documentFileDetails.document
          : [];
      resolve(result);
    } catch (err) {
      if (err.message?.data && err.message.data.includes('Path Not Found')) {
        logger.info('Path Not Found :: ', err.message.data);
        resolve([]);
      } else {
        reject(err);
      }
    }
  });
};

export const copyFolderCopy = async (fldId, dstId) => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.folderCopy;
  const data = querystring.stringify({
    fldId,
    dstId,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const copyFolderFileDetails = await service.put(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      logger.info(copyFolderFileDetails, 'copyFolderFileDetails');
      resolve(copyFolderFileDetails);
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('ItemExistsException')
      ) {
        resolve({ status: true });
      } else {
        reject(err);
      }
    }
  });
};

export const folderDelete = fldId => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.folderDelete;
  const data = querystring.stringify({
    fldId,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const deleteFolder = await service.delete(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      logger.info(deleteFolder, 'deltefolderfiles');
      resolve(deleteFolder);
    } catch (err) {
      if (
        err.message?.data &&
        err.message.data.includes('ItemExistsException')
      ) {
        resolve({ status: true });
      } else {
        reject(err);
      }
    }
  });
};

export const folderRename = (fldId, newName) => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.folderRename;
  const data = querystring.stringify({
    fldId,
    newName,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const RenameFolder = await service.put(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      logger.info(RenameFolder, 'renamefolder');
      resolve(RenameFolder);
    } catch (err) {
      reject(err);
    }
  });
};

export const lockDocument = docId => {
  const headers = {
    Authorization: `Basic ${process.env.OKM_AUTH}`,
  };
  const url = config.okmNative.uri.lock;
  const data = querystring.stringify({
    docId,
  });
  return new Promise(async (resolve, reject) => {
    try {
      const lockDetails = await service.put(
        `${config.okmNative.base_url}${url}?${data}`,
        {},
        headers,
      );
      logger.info(lockDetails, 'lockDetails');
      resolve(lockDetails);
    } catch (err) {
      logger.info(err, 'lockDetails error');
      reject(err);
    }
  });
};

export const ListAllChildDocument = async pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const uuid = await _getUuid(pth);
      resolve(await _ListAllChildDocument(uuid));
    } catch (err) {
      if (
        err.message &&
        err.message.data &&
        err.message.data.includes('PathNotFoundException')
      ) {
        resolve([]);
      } else {
        reject(err);
      }
    }
  });
};

export const _ListAllChildDocument = uuid => {
  return new Promise(async (resolve, reject) => {
    try {
      let FileList = await getDocumentChildrenProperties(uuid);
      let FolderList = await getFolderChildrenProperties(uuid);
      FileList = Array.isArray(FileList) ? FileList : [FileList];
      FolderList = Array.isArray(FolderList) ? FolderList : [FolderList];
      const awaits = [];
      FolderList.forEach(ele => awaits.push(_ListAllChildDocument(ele.uuid)));
      const files = await Promise.all(awaits);
      files.forEach(ele => FileList.push(...ele));
      resolve(FileList);
    } catch (err) {
      reject(err);
    }
  });
};

//* ********************************  OpenKM API's ********************************************//

// openkm performence testing API.
export const startOKMLoadTest = async (req, res) => {
  const { okmPath, count = 1 } = req.body;
  try {
    const okmPaths = [];
    for (let index = 0; index < +count; index++) {
      okmPaths.push(`${okmPath}/${index}`);
    }
    const resForCheckinCheckout = [];
    // this function is used to create and update file in openkm.
    okmPaths.forEach(element => {
      resForCheckinCheckout.push(
        fileCheckInCheckOut(req, element, 'content')
          .then(value => value)
          .catch(value => value),
      );
    });
    const out = await Promise.all(resForCheckinCheckout);
    res.send(out);
  } catch (error) {
    logger.info(error, 'error');
    res.send('failed');
  }
};

export const startOKMLoadTest_new = async (req, res) => {
  const { okmPath, count = 1 } = req.body;
  try {
    const okmPaths = [];
    for (let index = 0; index < +count; index++) {
      okmPaths.push(`${okmPath}/${index}`);
    }
    const resForCheckinCheckout = [];
    // this function is used to create and update file in openkm.
    okmPaths.forEach(element => {
      resForCheckinCheckout.push(
        fileCheckInCheckOut_new(req, element, 'content')
          .then(value => value)
          .catch(value => value),
      );
    });
    const out = await Promise.all(resForCheckinCheckout);
    res.send(out);
  } catch (error) {
    logger.info(error, 'error');
    res.send('failed');
  }
};

// file checkin & checkout
const fileCheckInCheckOut = async (req, okmPath, fileName) => {
  return new Promise(async (resolve, reject) => {
    let uuid = '';
    try {
      const isTargetDetails = await _isFileExist(
        `${okmPath}/${req.files[fileName].name}`,
      );
      if (isTargetDetails.isExist) {
        uuid = isTargetDetails.uuid;
        await checkoutOpenKMFile(uuid);
        const formData = new FormData();
        formData.append(
          'content',
          createReadStream(req.files[fileName].tempFilePath),
        );
        formData.append('docId', uuid);
        const header = {
          Authorization: `Basic ${process.env.OKM_AUTH}`,
          'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
        };
        await service.upload(
          `${config.okmNative.base_url}${config.openKM.uri.checkin}`,
          formData,
          header,
        );
      } else {
        const formData = new FormData();
        formData.append(
          'content',
          createReadStream(req.files[fileName].tempFilePath),
        );
        formData.append('docPath', `${okmPath}${req.files[fileName].name}`);
        const header = {
          Authorization: `Basic ${process.env.OKM_AUTH}`,
          'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
        };
        const response = await service.upload(
          `${config.okmNative.base_url}${config.okmNative.uri.createFile}`,
          formData,
          header,
        );
        console.log(response, 'resss');
        uuid = response.data.uuid;
        // fullPath = path.join(okmPath,req.files[fileName].name)
      }
      resolve({
        uuid,
        okmPath,
        name: req.files[fileName].name,
        joinPath: path.join(
          okmPath,
          req.files[fileName].name.replace(/\\/g, '/'),
        ),
      });
    } catch (e) {
      logger.info(e, 'uploadFiletoOpenKM error');
      if (e?.message?.data) {
        // for dms error message
        e.message = e.message.data.includes('FileNotFoundException')
          ? 'Uploading was interrupted. Please retry the current action'
          : e.message.data;
      }
      reject(e);
    }
  });
};

const fileCheckInCheckOut_new = async (req, okmPath, fileName) => {
  return new Promise(async (resolve, reject) => {
    let uuid = '';
    try {
      const isTargetDetails = await _isFileExist(
        `${okmPath}/${req.files[fileName].name}`,
      );
      if (isTargetDetails.isExist) {
        uuid = isTargetDetails.uuid;
        await checkoutOpenKMFile(uuid);
        const formData = new FormData();
        formData.append(
          'content',
          createReadStream(req.files[fileName].tempFilePath),
        );
        formData.append('docId', uuid);
        const header = {
          'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
          Authorization: `Basic ${process.env.OKM_AUTH}`,
        };
        await service.upload(
          `${config.okmNative.base_url}${config.okmNative.uri.checkin}`,
          formData,
          header,
        );
      } else {
        const formData = new FormData();
        formData.append(
          'content',
          createReadStream(req.files[fileName].tempFilePath),
        );
        formData.append('docPath', `${okmPath}/${req.files[fileName].name}`);
        const header = {
          'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
          Authorization: `Basic ${process.env.OKM_AUTH}`,
        };
        await folderCreate(okmPath);
        const response = await service.upload(
          `${config.okmNative.base_url}${config.okmNative.uri.createFile}`,
          formData,
          header,
        );
        console.log(response, 'resss');
        uuid = response.uuid;
        // fullPath = path.join(okmPath,req.files[fileName].name)
      }
      resolve({
        uuid,
        okmPath,
        name: req.files[fileName].name,
        joinPath: path.join(
          okmPath,
          req.files[fileName].name.replace(/\\/g, '/'),
        ),
      });
    } catch (e) {
      logger.info(e, 'uploadFiletoOpenKM error');
      if (e?.message?.data) {
        // for dms error message
        e.message = e.message.data.includes('FileNotFoundException')
          ? 'Uploading was interrupted. Please retry the current action'
          : e.message.data;
      }
      reject(e);
    }
  });
};
