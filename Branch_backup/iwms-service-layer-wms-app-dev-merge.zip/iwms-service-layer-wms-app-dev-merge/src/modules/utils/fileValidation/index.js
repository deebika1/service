import { extname } from 'path';
import * as validationModule from './validate.js';
import logger from '../logs/index.js';
import { query } from '../../../database/postgres.js';

export const getFileValidationStatus = (req, res) => {
  const {
    validationFileConfig,
    filesInfo,
    placeHolders,
    eventdata,
    action,
    workOrderId,
  } = req.body;
  try {
    res.send(
      validationModule.getFileValidationStatus(
        validationFileConfig,
        filesInfo,
        placeHolders,
        eventdata,
        action,
        workOrderId,
      ),
    );
  } catch (e) {
    logger.info(e, 'validateFiles');
    res.status(400).send(e.message ? e.message : e);
  }
};

export const isValidFile = (req, res) => {
  const { validationFiles, file, files, placeHolders, customer } = req.body;
  try {
    res.send(
      validationModule.isValidFile(
        validationFiles,
        file,
        files,
        placeHolders,
        customer,
      ),
    );
  } catch (e) {
    logger.info(e, 'isValidFile');
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getToolsFileDetail = (req, res) => {
  const { validationFile, file, files, placeHolders } = req.body;
  try {
    res.send(
      validationModule.getToolsFileDetail(
        validationFile,
        file,
        files,
        placeHolders,
      ),
    );
  } catch (e) {
    logger.info(e, 'isValidFile');
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getFilteredFiles = (req, res) => {
  const { filesInfo, filesData, placeHolders } = req.body;
  try {
    res.send(
      validationModule.getFilteredFiles(filesInfo, filesData, placeHolders),
    );
  } catch (e) {
    logger.info(e, 'getFilteredFiles');
    res.status(400).send(e.message ? e.message : e);
  }
};

export const _getIncomingFileType = async workOrderId => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select incomingfiledetails.filetypeid,incomingfiledetails.filename,incomingfiledetails.newfilename,incomingfiledetails.woincomingfileid,filetype.filetype from wms_workorder_incoming as incoming
join wms_workorder_incomingfiledetails as incomingfiledetails on incomingfiledetails.woincomingid = incoming.woincomingid
join pp_mst_filetype as filetype on filetype.filetypeid = incomingfiledetails.filetypeid
where incoming.woid = $1`;
      const FileDetails = await query(sql, [workOrderId]);
      console.log(FileDetails, 'FileDetails');
      resolve(FileDetails);
    } catch (e) {
      reject(e);
    }
  });
};

export const getIncomingFileType = async (req, res) => {
  const { workOrderId } = req.body;
  try {
    const incomingFileDetails = await _getIncomingFileType(workOrderId);
    res.send(incomingFileDetails);
  } catch (err) {
    logger.info(err, 'deleteFile');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const checkWipActivity = async (req, res) => {
  const { wfEventId } = req.body;
  try {
    const sql = `SELECT eventlog.wfeventid, eventlogdetails.operationtype, eventlog.actualactivitycount,eventlogdetails.actualactivitycount FROM public.wms_workflow_eventlog as eventlog
      join  wms_workflow_eventlog_details as eventlogdetails on eventlog.wfeventid = eventlogdetails.wfeventid and eventlog.actualactivitycount =eventlogdetails.actualactivitycount 
      where eventlog.wfeventid = $1 and eventlogdetails.operationtype = 'Work in progress'
      order by eventlogdetails.wfeventdetailid asc`;
    const FileDetails = await query(sql, [wfEventId]);
    logger.info(FileDetails, 'FileDetails');
    res.send(FileDetails);
  } catch (e) {
    logger.info(e, 'wip cancel details');
    res.status(400).send({ message: e.message?.data ? e.message?.data : e });
  }
};
// export const deleteTranscationEnterisForCancel = async (req, res) => {
//     const { wfEventId,repoFilePath } = req.body;
//     let sql1 = `select * from wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`
//     query(sql1).then((response1) => {
//         console.log(response1,"responsefordelte");
//         if(response1.length > 0){
//         let sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
//         WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`;
//         console.log(sql,"sql for transcation enteris")
//         query(sql).then((response) => {
//             console.log(response, "responseformemail")
//             res.status(200).json({ data: response });
//         }).catch((error) => {
//             res.status(400).send({ message: error });
//         }).catch((error) => {
//             res.status(400).send({ message: error });
//         });
//     }else{
//         res.status(200).json({ data: response1 });
//     }

// })
// }

export const deleteTranscationEnterisForCancel = async (req, res) => {
  const { wfEventId, repoFilePath, formattedSubLikeKey, ext } = req.body;
  let extensionFile = '';
  if (!formattedSubLikeKey) {
    const sql1 = `select * from wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`;
    query(sql1).then(response1 => {
      console.log(response1, 'responsefordelte');
      if (response1.length > 0) {
        const sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
            WHERE wfeventid = ${wfEventId} and repofilepath = '${repoFilePath}'`;
        console.log(sql, 'sql for transcation enteris');
        query(sql)
          .then(response => {
            console.log(response, 'responseformemail');
            res.status(200).json({ data: response });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: response1 });
      }
    });
  } else {
    const sql1 = `select * from wms_workflowactivitytrn_file_map WHERE wfeventid = ${wfEventId} and repofilepath like '%${repoFilePath}%'`;
    query(sql1).then(response1 => {
      console.log(response1, 'responsefordelte');
      if (response1.length > 0) {
        const extensionArray = [];
        for (let j = 0; j < response1.length; j++) {
          extensionFile = extname(response1[j].repofilepath);
          if (extensionFile != ext) {
            extensionArray.push(response1[j]);
          }
        }
        if (extensionArray.length > 0) {
          for (let k = 0; k < extensionArray.length; k++) {
            let lastIteration = false;
            if (k == extensionArray.length - 1) {
              lastIteration = true;
            }
            const sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
                            WHERE wfeventid = ${wfEventId} and actfilemapid = '${extensionArray[k].actfilemapid}'`;
            console.log(sql, `sql for transcation enteris${lastIteration}`);
            query(sql)
              .then(response => {
                if (lastIteration) {
                  res.status(200).json({ data: response });
                }
                console.log(response, 'responseformemail');
              })
              .catch(error => {
                res.status(400).send({ message: error });
              })
              .catch(error => {
                res.status(400).send({ message: error });
              });
          }
        } else {
          for (let i = 0; i < response1.length; i++) {
            let lastIteration1 = false;
            extensionFile = extname(response1[i].repofilepath);
            let sql = '';
            if (i == response1.length - 1) {
              lastIteration1 = true;
            }
            if (ext != '') {
              if (extensionFile != ext) {
                sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
                            WHERE wfeventid = ${wfEventId} and actfilemapid = '${response1[i].actfilemapid}'`;
                console.log(sql, 'sql for transcation enteris1');
              }
            } else {
              sql = `DELETE FROM public.wms_workflowactivitytrn_file_map
                            WHERE wfeventid = ${wfEventId} and actfilemapid = '${response1[i].actfilemapid}'`;
              console.log(sql, 'sql for transcation enteris2');
            }
            query(sql)
              .then(response => {
                if (lastIteration1) {
                  res.status(200).json({ data: response });
                }
                console.log(response, 'responseformemail');
              })
              .catch(error => {
                res.status(400).send({ message: error });
              })
              .catch(error => {
                res.status(400).send({ message: error });
              });
          }
        }
      } else {
        res.status(200).json({ data: response1 });
      }
    });
  }
};

export const getPreviousActivitiesForCancel = async (req, res) => {
  const { workOrderId, WfDefId } = req.body;
  try {
    const sql = `select * from wms_workflow_eventlog where workorderid = $1 and wfdefid =$2`;
    const FileDetails = await query(sql, [workOrderId, WfDefId]);
    if (FileDetails.length > 0) {
      res.send(true);
    } else {
      res.send(false);
    }
    console.log(FileDetails, 'FileDetails');
  } catch (e) {
    res.status(400).send(e.message ? e.message : e);
  }
};
