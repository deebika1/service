import { join } from 'path';
import moment from 'moment';
import { createReadStream } from 'fs';
import FormData from 'form-data';
import { config } from '../../../config/restApi.js';
import { Service } from '../../../httpClient/index.js';
import { getFolderStructure } from '../wmsFolder/index.js';

const service = new Service();

export const updateLogFileToDms = async (req, res) => {
  try {
    await _updateLogFileToDms();
    res.send({ isSuccess: true });
  } catch (err) {
    res.send({ isSuccess: false, message: err.message });
  }
};

const _updateLogFileToDms = async () => {
  try {
    const fileName = join(
      'logs',
      `iwms-${moment(new Date()).format('DD-MMM-YYYY').toString()}.txt`,
    );
    const fData = new FormData();
    const lStream = createReadStream(fileName);
    fData.append('content', lStream);
    const header = {
      Authorization: `Basic ${process.env.OKM_AUTH}`,
      'Content-Type': `multipart/form-data; boundary=${fData._boundary}`,
    };
    const logpath = await getFolderStructure({ type: 'okm_logpath' });
    fData.append('docPath', logpath);
    await service.upload(
      `${config.blob_rest.base_url}${config.blob_rest.uri.upload}`,
      fData,
      header,
    );
  } catch (err) {
    console.log(err, 'log file upload error');
  }
};

setInterval(function () {
  _updateLogFileToDms();
}, 60 * 60 * 1000); // 60 * 1000 milsec
