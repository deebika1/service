import log4js from 'log4js';
import { join } from 'path';
import moment from 'moment';

let log;
if (process.env.ENABLE_LOGGER && !log) {
  const fileName = join(
    'logs',
    `iwms-${moment(new Date()).format('DD-MMM-YYYY').toString()}.txt`,
  );
  log = log4js.configure({
    appenders: {
      iwms: { type: 'dateFile', filename: fileName, keepFileExt: true },
    },
    categories: { default: { appenders: ['iwms'], level: 'debug' } },
  });
  log = log4js.getLogger('iwms');
}
const logger = log
  ? {
      info: (...args) => {
        console.log(...args);
        log.info(...args);
      },
    }
  : {
      info: (...args) => {
        console.log(...args);
      },
    };

export default logger;
