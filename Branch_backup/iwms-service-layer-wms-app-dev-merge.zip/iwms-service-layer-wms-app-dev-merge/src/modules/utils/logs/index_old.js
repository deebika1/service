import log4js from 'log4js';
import { join } from 'path';

export const initializeLogger = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const fileName = join('logs', `iwms.log`);
      log4js.configure({
        appenders: {
          iwms: { type: 'dateFile', filename: fileName, keepFileExt: true },
        },
        categories: { default: { appenders: ['iwms'], level: 'debug' } },
      });
      const logger = log4js.getLogger('iwms');
      initialize(logger);
      logger.info('Logger Initialized');
      resolve();
    } catch (e) {
      const logger = log4js.getLogger('iwms');
      logger.info(e, 'initializeLogger error');
      reject(e);
    }
  });
};

const initialize = logger => {
  global.log = (...args) => {
    console.log(...args);
    logger.info(...args);
  };
  global.log.error = (...args) => {
    console.error(...args);
    logger.error(...args);
  };
  global.log.warn = (...args) => {
    console.warn(...args);
    logger.warn(...args);
  };
};
