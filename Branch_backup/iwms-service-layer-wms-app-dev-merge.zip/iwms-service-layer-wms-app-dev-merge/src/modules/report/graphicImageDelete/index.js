import { query } from '../../../database/postgres.js';

export const graphicImageDelete = (req, res) => {
  console.log(res);
  const sql = `   
    SELECT img.workorderid,wo.itemcode,wms_workorder_incomingfiledetails.filename,img.imagename,wf.activityalias,img.createdon as datetime,
    case when img.userid is null then 'WMS'
    else users.username ||' (' || img.userid  || ')' end as userid,
    img.operationtype,
    case when wf.activitytype = 'External Task' then 'WMS Engine'
    else systeminfo end as systeminfo 
    FROM public.wms_imageupload_actions_audit as img
    join wms_workflow_eventlog as ev on img.wfeventid=ev.wfeventid 
    join wms_workorder as wo on wo.workorderid = img.workorderid
	join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid=ev.woincomingfileid
    join wms_workflowdefinition as wf on ev.wfdefid=wf.wfdefid
    JOIN org_mst_customer as cu on cu.customerid  = wo.customerid
    join wms_mst_activity as act on act.activityid=wf.activityid
    join wms_workflow as wfl on wfl.wfid =wf.wfid and wfl.customerid=img.customerid
    left JOIN wms_user as users on users.userid = img.userid  
    where img.customerid=( SELECT DISTINCT (org_mst_customer.customerid) FROM org_mst_customerorg_du_map 
        JOIN org_mst_customer_orgmap ON org_mst_customer_orgmap.custorgmapid = org_mst_customerorg_du_map.custorgmapid
        JOIN org_mst_customer ON org_mst_customer.customerid = org_mst_customer_orgmap.customerid
        WHERE duid = ${req.body.duId} AND org_mst_customer.isactive = true) 
    and img.createdon :: Date between '${req.body.startdate}' ::Date and '${req.body.enddate}' ::Date  order by datetime desc`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
      console.log(res, data, 'Deleted image report');
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
