import { query } from '../../../database/postgres.js';

export const toolsWIPReport = (req, res) => {
  console.log(res);
  const sql = `   
    select wms_workflow_eventlog.workorderid,
    wms_workorder.itemcode,
    wms_workorder_incomingfiledetails.filename,
    wms_mst_stage.stagename,
    wms_workflowdefinition.activityalias,
    pp_mst_tool.toolname,
    wms_tools_api.status,
    wms_tools_api.starttime,
    wms_tools_api.endtime
    from public.wms_tools_api 
    join pp_mst_tool on pp_mst_tool.toolid=wms_tools_api.toolid
    join wms_workflow_eventlog on wms_workflow_eventlog.wfeventid=wms_tools_api.wfeventid
    join wms_workflowdefinition on wms_workflowdefinition.wfdefid=wms_workflow_eventlog.wfdefid
    join wms_mst_stage on wms_mst_stage.stageid=wms_workflowdefinition.stageid 
        join wms_workorder on wms_workorder.workorderid = wms_workflow_eventlog.workorderid
        join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid=wms_workflow_eventlog.woincomingfileid
        where coalesce (wms_tools_api.status,'')= case when '${req.body.status}' = 'null' then coalesce(wms_tools_api.status,'')  else 'InProgress' end
 
    and wms_tools_api.starttime :: Date between '${req.body.startdate}' ::Date and '${req.body.enddate}' ::Date  order by wms_tools_api.starttime desc`;

  // where wms_tools_api.status='InProgress'
  query(sql)
    .then(data => {
      res.status(200).json({ data });
      console.log(res, data, 'Tools WIP report');
    })
    .catch(error => {
      res.status(400).send({ message: error });
      console.log(sql);
    });
};
