import { query } from '../../../database/postgres.js';
import logger from '../../utils/logs/index.js';
// const path = require('path');

// Function to get wip  Report
export const getWIPReport = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'ReqData from getWIPReport');
  const sql = `select service.servicename as service,stage.stagename as stage,
    division.division,customer.customername as customer,
    workflow.wfname as workflow,wostage.status as stagestatus,software.softwarename as software,
    customermap.custorgmapid , contacts.contactname as PM,
    CASE
    WHEN wostage.plannedenddate isnull
    THEN 'Blank'
    when wostage.plannedenddate <= CURRENT_DATE + INTERVAL '${reqData.month} months' and wostage.plannedenddate>=CURRENT_DATE
    then TO_CHAR(wostage.plannedenddate :: DATE, 'Mon yy')
    when wostage.plannedenddate<CURRENT_DATE
    then TO_CHAR(CURRENT_DATE :: DATE, 'Mon yy')
    END as month,TO_CHAR(wostage.plannedenddate :: DATE, 'Mon yy')as actualdate
    from wms_workorder wo
    left join wms_workorder_service woservice on woservice.workorderid=wo.workorderid
    join wms_workorder_stage wostage on wostage.workorderid=wo.workorderid
    join wms_mst_service service on service.serviceid=wostage.serviceid
    join wms_mst_stage stage on stage.stageid=wostage.wfstageid
    join org_mst_division division on division.divisionid=wo.divisionid
    join org_mst_customer customer on customer.customerid=wo.customerid
    join org_mst_customer_orgmap as customermap on (customermap.customerid = wo.customerid and customermap.divisionid = wo.divisionid and customermap.subdivisionid = wo.subdivisionid and customermap.countryid = wo.countryid)
    join wms_workorder_contacts contacts on wo.workorderid=contacts.workorderid and contacts.contactrole='PM' and isprimary=true and contacttype='Integra'
    join wms_workflow workflow on workflow.wfid=woservice.wfid
    join pp_mst_composingsoftware software on software.softwareid=wo.composingsoftwareid
    join org_mst_customerorg_du_map du_map on du_map.custorgmapid = customermap.custorgmapid
    where wostage.status!='Completed' and wostage.stageiterationcount=(select stageiterationcount from wms_workorder_stage
    where wms_workorder_stage.workorderid=wo.workorderid  and
    wms_workorder_stage.wfstageid=wostage.wfstageid 
    order by stageiterationcount desc limit 1 )and du_map.duid =  ${reqData.duID} and (wostage.plannedenddate <= CURRENT_DATE + INTERVAL '${reqData.month} months' or wostage.plannedenddate isnull)
    order by wostage.plannedenddate , wfstageid`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// suradha (12-12-2022)
export const getWIPWorkorderReport1 = (req, res) => {
  const reqData = req.body;
  const jdata = JSON.stringify(reqData);
  logger.info(reqData, 'ReqData from getWIPWorkorderReport');
  const sql = `select * from public.getwip_workorderdata('${jdata}')`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getWIPChapterReport = (req, res) => {
  const reqData = req.body;
  const jdata = JSON.stringify(reqData);
  logger.info(reqData, 'ReqData from getWIPChapterReport');
  const sql = `select row_number()over(order by chapter) as "S.No", 
              chapter as "Chapter", service as "Service", stage as "Stage",mspages as "MS_Page", actstatus as "Status", 
              currentactivity as "Current_Activity", assignedto as "Assigned_To", 
              priority as "Priority"
            from public.getwip_workorderchapterdata('${jdata}')`;
  console.log(sql, 'chaptersql');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const exportWOReport = (req, res) => {
  const reqData = req.body;
  const jdata = JSON.stringify(reqData);
  logger.info(reqData, 'ReqData from exportWOReport');

  const sql = `select
  row_number()over(order by itemcode) as "S.No",
  itemcode as "Book Code", filename as "Chapter", division as "Division",stage as "Stage",
  workflow as "Workflow",receiveddate as "Received Date",duedate as "Due Date",
  proddespatchdate as "Prod.Despatch.Date",hoursleft as "Days Left",overdue as "Is Overdue" ,querystatus as "Query Status",
  querycount as "Query Count",querytext as "Query",pmname as "Project Manager",assigned as "Assigned To", inputtype as "Input Type",
   activities as "Current Activity",filepriority as "Priority",wipnotes as "Notes"
      from getwip_workorderdata_export('${jdata}')`;

  console.log(sql, 'exportsql');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWIPWorkorderReport = (req, res) => {
  const reqData = req.body;
  const jdata = reqData.params;
  let querySP = 'getwip_workorderdata_cupjournal';
  // JSON.parse(jdata).duID == '7'
  //   ? 'getwip_workorderdata_cupjournal'
  //   : 'getwip_workorderdata';

  if (JSON.parse(jdata).duID == '5') {
    querySP = 'getwip_workorderdata';
  }

  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
  }
  sql = `SELECT COUNT(*) FROM public.${querySP}('${jdata}') ${
    condition ? `WHERE${condition}` : condition
  }`;
  logger.info(sql, 'sqlsql');

  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);

        const sqlQuery = `select * from public.${querySP}('${jdata}') ${
          condition ? `WHERE${condition}` : condition
        }`; // LIMIT ${recordPerPage} OFFSET ${offset}
        //  const sql = `select * from (select * from public.getwip_workorderdata('${jdata}')  LIMIT ${recordPerPage} OFFSET ${offset}) as res
        //               ${condition ? ' WHERE' + condition : condition}`;
        console.log(sqlQuery, 'qryprint');
        query(sqlQuery)
          .then(data => {
            logger.info('color', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWIPReportTwo = (req, res) => {
  const reqData = req.body;
  // wostage.status as "Stage Status"
  logger.info(reqData, 'ReqData from getWIPReport');

  const jdata = JSON.stringify(reqData);
  const sql = `select service as "Service",stage as "Stage", division as "Division",customer as "Customer",
             workflow as "Workflow",software  as "Software" ,
             custorgmapid ,pm as "PM", dates as "Date", actualdate as "Actualdate",querystatus as "Query"
             from getwip_report('${jdata}')`;

  // let sql1 = `select service.servicename as "Service",stage.stagename as "Stage",
  // division.division as "Division",customer.customername as "Customer",
  // workflow.wfname as "Workflow",software.softwarename as "Software",
  // customermap.custorgmapid as "custorgmapid" , contacts.contactname as "PM",
  // CASE
  // WHEN wostage.plannedenddate isnull
  // THEN -- 'Blank'
  //     '3000-01-01'
  //   when wostage.plannedenddate <= '${reqData.enddate}' and wostage.plannedenddate >='${reqData.startdate}'
  //     then
  //       --TO_CHAR(wostage.plannedenddate :: DATE, 'dd/Mon')
  //        wostage.plannedenddate :: DATE
  //   when wostage.plannedenddate<'${reqData.startdate}'
  //     then -- TO_CHAR('${reqData.startdate}':: DATE, 'dd/Mon')
  //     '${reqData.startdate}':: DATE
  // END as "Date",
  //   TO_CHAR(wostage.plannedenddate :: DATE, 'dd/Mon') as "Actualdate"
  //   from wms_workorder wo
  //   left join wms_workorder_service woservice on woservice.workorderid=wo.workorderid
  //   join wms_workorder_stage wostage on wostage.workorderid=wo.workorderid and wostage.status ='In Process'
  //   join wms_mst_service service on service.serviceid=wostage.serviceid
  //   join wms_mst_stage stage on stage.stageid=wostage.wfstageid
  //   join org_mst_division division on division.divisionid=wo.divisionid
  //   join org_mst_customer customer on customer.customerid=wo.customerid
  //   join org_mst_customer_orgmap as customermap on (customermap.customerid = wo.customerid and customermap.divisionid = wo.divisionid and customermap.subdivisionid = wo.subdivisionid and customermap.countryid = wo.countryid)
  //   join wms_workorder_contacts contacts on wo.workorderid=contacts.workorderid and contacts.contactrole='PM' and isprimary=true and contacttype='Integra'
  //   join wms_workflow workflow on workflow.wfid=woservice.wfid
  //   join pp_mst_composingsoftware software on software.softwareid=wo.composingsoftwareid
  //   join org_mst_customerorg_du_map du_map on du_map.custorgmapid = customermap.custorgmapid
  //   where wostage.status!='Completed' and wostage.stageiterationcount=(select stageiterationcount from wms_workorder_stage
  //   where wms_workorder_stage.workorderid=wo.workorderid  and
  //   wms_workorder_stage.wfstageid=wostage.wfstageid
  //   order by stageiterationcount desc limit 1 ) and du_map.duid =  ${reqData.duID} and (wostage.plannedenddate <= '${reqData.enddate}' or wostage.plannedenddate isnull)
  //   order by wostage.plannedenddate , wfstageid`;

  console.log(sql, 'wiproportqry');

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Function to get wip detailed Report
export const getWIPDetailedReport = (req, res) => {
  const reqData = req.body;
  const type =
    req.body.type === 'default'
      ? ' or wostage.plannedenddate<CURRENT_DATE'
      : ' and 1=1';
  logger.info(reqData, 'ReqData from getWIPReport');
  let sql = `select  distinct activity,stage,* from(select wf.activityalias,wf.sequence,wms_workorder.workorderid as WOID, priority.priority,wms_workorder.itemcode,service.servicename as service,software.softwarename as software, 
    case
	when (select userid from wms_user where username=contacts.contactname) isnull
	then contacts.contactname
	else contacts.contactname||' (' ||  (select userid from wms_user where username=contacts.contactname)||')'
	end as PM,
    customer.customername as customer,wms_workorder.workorderid,wostage.plannedenddate as actualdate,wms_workorder_incomingfiledetails.woincomingfileid,wms_mst_activity.activityname as activity,
    workflow.wfname as workflow,wms_mst_stage.stagename as stage,
    wms_workflow_eventlog.stageiterationcount,wms_workflow_eventlog.actualactivitycount,wms_workflow_eventlog.activitystatus, wms_workflowactivitytrn_file_map.woincomingfileid,wms_workorder.itemcode,
     wms_workorder_incomingfiledetails.filename,wms_workflow_eventlog.wfeventid ,
     users.username ||' (' || wms_workflow_eventlog.userid  || ')' as userid,
	 CASE
    WHEN wostage.plannedenddate isnull
    THEN null
    when wostage.plannedenddate >= '${reqData.startdate}' and wostage.plannedenddate<='${reqData.enddate}'
    then wostage.plannedenddate
    when wostage.plannedenddate<CURRENT_DATE
    then CURRENT_DATE
    END as date
	 from wms_workflow_eventlog   
    JOIN wms_workorder on wms_workflow_eventlog.workorderid = wms_workorder.workorderid 
    JOIN wms_workflowdefinition  wf ON wms_workflow_eventlog.wfdefid = wf.wfdefid 
    JOIN wms_workflowactivitytrn_file_map  ON wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
    JOIN wms_workorder_incomingfiledetails ON wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid 
    JOIN wms_mst_activity on wms_mst_activity.activityid=wf.activityid
    JOIN wms_mst_stage on wms_mst_stage.stageid = wf.stageid
	JOIN wms_workorder_stage wostage on wostage.workorderid=wms_workorder.workorderid and wms_mst_stage.stageid=wostage.wfstageid
	JOIN org_mst_customer customer on customer.customerid=wms_workorder.customerid
	JOIN wms_workorder_contacts contacts on wms_workorder.workorderid=contacts.workorderid and contacts.contactrole='PM' and isprimary=true and contacttype='Integra'
  JOIN org_mst_customer_orgmap as customermap on (customermap.customerid = wms_workorder.customerid and customermap.divisionid = wms_workorder.divisionid and customermap.subdivisionid = wms_workorder.subdivisionid and customermap.countryid = wms_workorder.countryid)
  JOIN org_mst_customerorg_du_map du_map on du_map.custorgmapid = customermap.custorgmapid    
	JOIN pp_mst_composingsoftware software on software.softwareid=wms_workorder.composingsoftwareid
	left JOIN wms_workorder_service woservice on woservice.workorderid=wms_workorder.workorderid
	JOIN wms_workflow workflow on workflow.wfid=woservice.wfid
	JOIN wms_mst_service service on service.serviceid=wostage.serviceid
    left join wms_mst_priority priority on priority.priorityid=wms_workflow_eventlog.priority
    LEFT JOIN wms_user as users on users.userid = wms_workflow_eventlog.userid
	where actualactivitycount=(SELECT actualactivitycount FROM public.wms_workflow_eventlog ev
        JOIN wms_workflowdefinition  wf1 on wf1.wfdefid = ev.wfdefid
        JOIN wms_workflowactivitytrn_file_map wft1 ON ev.wfeventid = wft1.wfeventid
        JOIN wms_workorder_incomingfiledetails wdti1 ON wft1.woincomingfileid = wdti1.woincomingfileid
        JOIN wms_mst_stage on wms_mst_stage.stageid = wf1.stageid
        where  ev.stageiterationcount =wms_workflow_eventlog.stageiterationcount and wft1.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid and  wf1.activityid=wf.activityid
        order by ev.wfeventid desc limit 1) and (activitystatus!='Completed' and activitystatus!='Rejected' and activitystatus!='Reset') and du_map.duid = ${reqData.duID} and wostage.stageiterationcount=(select stageiterationcount from wms_workorder_stage
    where wms_workorder_stage.workorderid=wms_workorder.workorderid  and
    wms_workorder_stage.wfstageid=wostage.wfstageid 
    order by stageiterationcount desc limit 1 ) and (wostage.plannedenddate <= '${reqData.enddate}' and  wostage.plannedenddate >= '${reqData.startdate}' ${type} or wostage.plannedenddate isnull) 
    ) as table1  order by actualdate,sequence`;
  console.log('sql', sql);
  query(sql)
    .then(data => {
      sql = `select   stagename as stage,activityName as activity,sequence,activityalias from (select distinct stagename,activityName,sequence,wms_workflowdefinition.activityalias from wms_workflowdefinition 
        join wms_mst_activity on wms_mst_activity.activityid=wms_workflowdefinition.activityid 
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid 
      where  (iscompletiontriggeractivity!=true or iscompletiontriggeractivity is null)
      ) as table1 order by sequence`;
      query(sql).then(stageActivity => {
        res.status(200).json({ data, stageActivity });
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get productivity report
export const getProductivityReport = (req, res) => {
  const {
    duId,
    filterObj,
    type,
    selectedUser,
    dateRange: { startDate, endDate },
  } = req.body;
  let condition = '';
  logger.info(startDate, endDate, 'iskjdfk');
  logger.info(filterObj, 'vallll1111');
  let index = 0;
  for (const key in filterObj) {
    if (Object.prototype.hasOwnProperty.call(filterObj, key)) {
      let value = '';
      filterObj[key].forEach((data, i) => {
        value += filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
      });
      index += 1;
      condition += ` ${
        Object.keys(filterObj).length == index
          ? `${key} IN (${value})`
          : `${key} IN (${value}) AND`
      } `;
    }
  }
  let sql = '';
  if (type == 'groupByUser') {
    sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, sum(totaltime) as totalhours, skillname, skilllevel, COALESCE(sum(uomvalue), 0) as uomvalue
        FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
        duid = ${duId} ${condition ? `AND${condition}` : ''}
        GROUP BY duid, username,userid,skillname, skilllevel`;
  } else if (type == 'groupByDate') {
    sql = `SELECT duid,sum(totaltime) as totalhours, to_char(DATE(updatedon),'DD-Mon-YY') as date, COALESCE(sum(uomvalue), 0) as uomvalue
        FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
        duid = ${duId} AND userid = '${selectedUser}'
        GROUP BY duid, DATE(updatedon)`;
  } else if (type == 'groupByTask') {
    sql = `SELECT duid,concat(username, ' (', userid, ')') as employee, totaltime as totalhours, itemcode, servicename, 
    concat(stagename,' (',stageiterationcount,')') as stagename, COALESCE(uomvalue, 0) as uomvalue,
    filename,concat(activityalias,' (',activityiterationcount,')') as activityname, skillname, skilllevel
        FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND duid = ${duId} AND userid = '${selectedUser}' ${
      condition ? `AND${condition}` : ''
    }`;
  }

  logger.info(sql, 'sql for productivity report');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// will get dropdwon option for productivity report
export const getReportOptionLists = (req, res) => {
  const {
    duId,
    type,
    selectedUser,
    dateRange: { startDate, endDate },
    skill,
  } = req.body;
  let sql = '';
  if (type === 'employee') {
    sql = `SELECT DISTINCT ON (userid) userid as value, concat(username, ' (', userid ,')') as label
            FROM wms_task_report_view WHERE activityname != 'Despatch' `;
  } else if (type === 'jobId') {
    sql = `SELECT DISTINCT ON (itemcode) itemcode as value, itemcode as label FROM wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND skillname = '${skill}'
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  } else if (type === 'stage') {
    sql = `SELECT DISTINCT ON(stagename) stagename, stagename as label, stagename as value, duid, userid FROM public.wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' 
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  } else if (type === 'activity') {
    sql = `SELECT DISTINCT ON (activityalias) activityalias as value, activityalias as label FROM wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  } else if (type === 'skill') {
    sql = `SELECT DISTINCT ON (skillname) skillname, skillname as value, skillname as label FROM wms_task_report_view
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'chapter') {
    sql = `SELECT DISTINCT ON (filename) filename as value, filename as label FROM wms_task_report_view
        WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'
        AND duid = ${duId} AND userid = '${selectedUser}'`;
  }
  logger.info(sql, 'sql for options');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get quality report
export const getQualityReport = (req, res) => {
  const {
    duId,
    filterObj,
    type,
    selectedUser,
    dateRange: { startDate, endDate },
  } = req.body;
  let condition = '';
  logger.info(startDate, endDate, 'iskjdfk');
  logger.info(filterObj, 'vallll1111');
  let index = 0;
  for (const key in filterObj) {
    if (Object.prototype.hasOwnProperty.call(filterObj, key)) {
      let value = '';
      filterObj[key].forEach((data, i) => {
        value += filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
      });
      index += 1;
      condition += ` ${
        Object.keys(filterObj).length == index
          ? `${key} IN (${value})`
          : `${key} IN (${value}) AND`
      } `;
    }
  }
  let sql = '';
  if (type == 'groupByUser') {
    sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, sum(totaltime) as totalhours,
      skillname, skilllevel, COALESCE(sum(uomvalue), 0) as uomvalue, sum(defects.defectcount) as defectcount,
      COALESCE(case when sum(uomvalue)=0 then round(sum(defects.defectcount)/NULLIF(sum(uomvalue), 0))
      else round(sum(defects.defectcount)/sum(uomvalue))
      end, 0) as defectPerPage
      FROM public.wms_task_report_view
      JOIN wms_sum_of_defects as defects ON defects.wfeventid = wms_task_report_view.wfeventid
      WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
      duid = ${duId} ${condition ? `AND${condition}` : ''}
      GROUP BY duid, username,userid,skillname, skilllevel`;
  } else if (type == 'groupByDate') {
    sql = `SELECT to_char(DATE(updatedon),'DD-Mon-YY') as date, sum(totaltime) as totalhours, sum(uomvalue) as uomvalue,
      COALESCE(sum(defects.defectcount), 0) as defectcount,
      COALESCE(case when sum(uomvalue)=0 then round(sum(defects.defectcount)/NULLIF(sum(uomvalue), 0))
      else round(sum(defects.defectcount)/sum(uomvalue))
      end, 0) as defectPerPage
      FROM public.wms_task_report_view
      join wms_sum_of_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
      WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
      duid = ${duId} AND userid = '${selectedUser}'
      GROUP BY duid, DATE(updatedon)`;
  } else if (type == 'groupByTask') {
    sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, uomvalue,itemcode,
    concat(stagename,' (',stageiterationcount,')') as stagename,concat(activityalias,' (',activityiterationcount,')') as activityname,
    filename,defects.defectcount,
    COALESCE(case when sum(uomvalue)=0 then round(defects.defectcount/NULLIF(sum(uomvalue), 0))
    else round(defects.defectcount/sum(uomvalue))
    end, 0) as defectPerPage
    FROM public.wms_task_report_view
    join wms_sum_of_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
    duid = ${duId} AND userid = '${selectedUser}' ${
      condition ? `AND${condition}` : ''
    }
    GROUP BY duid, username,userid,itemcode,stagename,stageiterationcount,activityname,activityalias,activityiterationcount,filename,defects.defectcount,
    uomvalue`;
  }
  console.log(sql, 'sql for QAR');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
//   const {
//     duId,
//     filterObj,
//     type,
//     selectedUser,
//     dateRange: { startDate, endDate },
//   } = req.body;
//   let condition = "";
//   logger.info(filterObj, "vallll1111");
//   let index = 0;
//   for (const key in filterObj) {
//     let value = "";
//     filterObj[key].map((data, i) => {
//       value += filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
//     });
//     logger.info(value, "valuevaluevaluevalue");

//     index += 1;
//     condition += ` ${
//       Object.keys(filterObj).length == index
//         ? key + " IN" + `(${value})`
//         : key + " IN" + `(${value}) AND`
//     } `;
//   }

//   let sql = `SELECT duid,username,userid, concat(username, ' (', userid, ')') as employee, sum(totaltime) as totalhours, skillname, skilllevel, sum(uomvalue) as uomvalue,itemcode,
//   concat(stagename,' (',stageiterationcount,')') as stagename,concat(activityname,' (',activityiterationcount,')') as activityname,filename,defects.defectcount,
//   case when sum(uomvalue)=0 then round(defects.defectcount/1)
//   else round(defects.defectcount/sum(uomvalue))
//   end as defectPerPage
//   FROM public.wms_task_report_view
//   join wms_sum_of_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
//   WHERE activityname != 'Despatch' AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}' AND
//   duid = ${duId} ${condition ? "AND" + condition : ""}
//   GROUP BY duid, username,userid,skillname, skilllevel,itemcode,stagename,stageiterationcount,activityname,activityiterationcount,filename,defects.defectcount`;
//   console.log(sql, 'sql for QAR');
//   query(sql)
//     .then((data) => {
//       res.status(200).json({ data: data });
//     })
//     .catch((error) => {
//       res.status(400).send({ message: error });
//     });
// };

// will get dropdwon option for Quality report
export const getQualityReportOptionLists = (req, res) => {
  const {
    duId,
    type,
    dateRange: { startDate, endDate },
  } = req.body;
  let sql = '';
  if (type === 'employee') {
    sql = `SELECT DISTINCT ON (userid) userid as value, concat(username, ' (', userid ,')') as label
    FROM wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE wms_task_report_view.activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'skill') {
    sql = `SELECT DISTINCT ON (skillname) skillname, skillname as value, skillname as label FROM wms_task_report_view
    JOIN wms_workflow_eventlog_defects as defects ON defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'jobId') {
    sql = `SELECT DISTINCT ON (itemcode) itemcode as value, itemcode as label FROM wms_task_report_view
    join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'stage') {
    sql = `SELECT DISTINCT ON(stagename) stagename, stagename as label, stagename as value, duid, userid FROM public.wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'activity') {
    sql = `SELECT DISTINCT ON (activityalias) activityalias as value, activityalias as label FROM wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  } else if (type === 'chapter') {
    sql = `SELECT DISTINCT ON (filename) filename as value, filename as label FROM wms_task_report_view join wms_workflow_eventlog_defects as defects on defects.wfeventid = wms_task_report_view.wfeventid
    WHERE activityname != 'Despatch' AND duid = ${duId} AND DATE(updatedon) >= '${startDate}' AND DATE(updatedon) <= '${endDate}'`;
  }
  console.log(sql, 'sql for options');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will get quality report
export const getMonitoringReport = (req, res) => {
  const {
    duId,
    filterObj,
    type,
    dateRange: { startDate, endDate },
    stageid,
    stageiterationcount,
  } = req.body;
  console.log(filterObj, 'filterObj');

  let condition = ``;
  let index = 0;
  for (const key in filterObj) {
    if (Object.prototype.hasOwnProperty.call(filterObj, key)) {
      let value = '';
      if (Array.isArray(filterObj[key])) {
        filterObj[key].forEach((data, i) => {
          value +=
            filterObj[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
        });
      } else {
        value += filterObj[key];
      }
      index += 1;
      condition += ` ${
        Object.keys(filterObj).length == index
          ? `${key} IN (${value})`
          : `${key} IN (${value}) AND`
      } `;
    }
  }
  let sql = '';
  if (type === 'stage') {
    console.log(stageid, 'stageidstageid');
    let inValues = '';
    if (stageid.length) {
      stageid.forEach((data, i) => {
        inValues += stageid.length - 1 != i ? `${data},` : data;
      });
    }
    sql = `SELECT DISTINCT ON (stage) stage FROM wms_delivery_monitoring_report
      WHERE duid = ${duId} ${
      inValues ? `AND stageid IN (${inValues}) ` : ' '
    } ${
      filterObj.customerid ? `AND customerid IN (${filterObj.customerid})` : ''
    }  `;

    // sql = `SELECT wms_mst_stage.stagename as stage FROM wms_mst_stage
    // ORDER BY stageid ASC  `;
  } else if (type === 'groupByDate') {
    sql = `SELECT *, to_char("Date", 'dd Mon') AS "Date", wfname , contactname FROM wms_delivery_monitoring_report 
    WHERE status = 'Completed' AND DATE("Date") >= '${startDate}' AND DATE("Date") <= '${endDate}'
    AND duid = ${duId} ${
      condition ? `AND${condition}` : ''
    } ORDER BY wms_delivery_monitoring_report."Date" asc`;
  } else if (type === 'groupByTask') {
    sql = `SELECT *, to_char(date, 'dd Mon') AS date, (enddatetime::date - startdatetime::date) as totaltaken 
    FROM wms_delivery_monitoring_report 
    WHERE status = 'Completed' AND DATE(date) >= '${startDate}' AND DATE(date) <= '${endDate}'
    AND duid = ${duId} AND stageiterationcount = ${stageiterationcount}  ${
      condition ? `AND${condition}` : ''
    }`;
  }

  console.log(sql, 'sql for monitoring');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getMonitoringReportOptionList = (req, res) => {
  const { duId, type, filterObj } = req.body;
  const customerCon = filterObj;
  const serviceCon = filterObj;
  const stageCon = filterObj;
  const pmCon = filterObj;
  const workflowCon = filterObj;
  const softwareCon = filterObj;

  let sql = '';
  if (type === 'customer') {
    for (const key in customerCon) {
      if (key == 'customerid') {
        delete customerCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in customerCon) {
      if (Object.prototype.hasOwnProperty.call(customerCon, key)) {
        let value = '';
        if (Array.isArray(customerCon[key])) {
          customerCon[key].forEach((data, i) => {
            value +=
              customerCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += customerCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(customerCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (customerid) customerid as value, customername as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
    `;
    // else {
    //   sql = `SELECT customerid as value, customername as label  FROM org_mst_customer
    //     WHERE duid = ${duId} ORDER BY stageid ASC `;
    // }
  } else if (type === 'service') {
    for (const key in serviceCon) {
      if (key == 'customerid') {
        delete serviceCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in serviceCon) {
      if (Object.prototype.hasOwnProperty.call(serviceCon, key)) {
        let value = '';
        if (Array.isArray(serviceCon[key])) {
          serviceCon[key].forEach((data, i) => {
            value +=
              serviceCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += serviceCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(serviceCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (serviceid) serviceid as value, servicename as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
   `;
  } else if (type === 'stage') {
    for (const key in stageCon) {
      if (key == 'stageid') {
        delete stageCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in stageCon) {
      if (Object.prototype.hasOwnProperty.call(stageCon, key)) {
        let value = '';
        if (Array.isArray(stageCon[key])) {
          stageCon[key].forEach((data, i) => {
            value +=
              stageCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += stageCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(stageCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (stageid) stageid as value, stagename as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
   `;
  } else if (type === 'pm') {
    for (const key in pmCon) {
      if (key == 'userid') {
        delete pmCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in pmCon) {
      if (Object.prototype.hasOwnProperty.call(pmCon, key)) {
        let value = '';
        if (Array.isArray(pmCon[key])) {
          pmCon[key].forEach((data, i) => {
            value += pmCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += pmCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(pmCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (contactname) contactname as value, contactname as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId} AND contactname IS NOT NULL  ${
      condition ? `AND${condition}` : ''
    }
   `;
  } else if (type === 'workflow') {
    for (const key in workflowCon) {
      if (key == 'workflowid') {
        delete workflowCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in workflowCon) {
      if (Object.prototype.hasOwnProperty.call(workflowCon, key)) {
        let value = '';
        if (Array.isArray(workflowCon[key])) {
          workflowCon[key].forEach((data, i) => {
            value +=
              workflowCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += workflowCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(workflowCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    let inValues = '';
    if ('customerid' in filterObj && filterObj.customerid === '5') {
      inValues = `'Bookwise','Chapterwise'`;
    } else if ('customerid' in filterObj && filterObj.customerid === '6') {
      inValues = `'Articlewise','Issuewise'`;
    }
    sql = `SELECT DISTINCT ON (wfid) wfid as value, wfname as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    } ${inValues ? `AND wfcategory IN (${inValues})` : ''}
   `;
  } else if (type === 'software') {
    for (const key in softwareCon) {
      if (key == 'softwareid') {
        delete softwareCon[key];
      }
    }
    let condition = ``;
    let index = 0;
    for (const key in softwareCon) {
      if (Object.prototype.hasOwnProperty.call(softwareCon, key)) {
        let value = '';
        if (Array.isArray(softwareCon[key])) {
          softwareCon[key].forEach((data, i) => {
            value +=
              softwareCon[key].length - 1 !== i ? `'${data}' ,` : `'${data}'`;
          });
        } else {
          value += softwareCon[key];
        }
        index += 1;
        condition += ` ${
          Object.keys(softwareCon).length == index
            ? `${key} IN (${value})`
            : `${key} IN (${value}) AND`
        } `;
      }
    }
    sql = `SELECT DISTINCT ON (softwareid) softwareid as value, softwarename as label FROM wms_delivery_monitoring_report  
    WHERE status = 'Completed' AND duid = ${duId}  ${
      condition ? `AND${condition}` : ''
    }
   `;
  }
  console.log(sql, 'sql for options');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const insertWipStageNotes = (req, res) => {
  const bodyparam = JSON.stringify(req.body);

  const sql = `select * from  insert_wipstage_notes ('${bodyparam}')`;
  console.log(sql, 'sql for stagenotes');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).sen({ data: error.message() });
    });
};

export const ftpjobretrigger = (req, res) => {
  const { emailtranid, userid } = req.body;
  const sql = `UPDATE ftp_audit_wo_creation SET isactive = false,isretrigger = true,userid='${userid}',updatedon = now() WHERE auditid = ${emailtranid}`;
  console.log(sql, 'sql for ftpretriger');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).sen({ data: error.message() });
    });
};

export const getdownloadmanuscript = async (req, res) => {
  const reqData = req.body;
  const jdata = reqData.params;

  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  // let condition = '';
  // if (reqData.type === 'filter') {
  //   offset = 0;
  //   reqData.filter.forEach((item, i) => {
  //     condition +=
  //       reqData.filter.length - 1 !== i
  //         ? ` LOWER(${
  //             item.name
  //           }::text) LIKE '%${item.value.toLowerCase()}%' AND `
  //         : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
  //   });
  //   logger.info(condition, 'getdownloadmanuscript');
  // }
  sql = `SELECT COUNT(*) FROM public.getdownload_manuscript('${jdata}')`;
  logger.info(sql, 'sqlsql');

  await query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        // const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);

        const sqlQuery = `select * from public.getdownload_manuscript('${jdata}')`;

        console.log(sqlQuery, 'qryprint');
        query(sqlQuery)
          .then(data => {
            logger.info('color', data);
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getManuscriptStatus = (req, res) => {
  const reqData = req.body;

  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'getdownloadmanuscript');
  }
  sql = `SELECT COUNT(*) from springer.trn_jobdetails ${
    condition ? `WHERE${condition}` : condition
  } where duid = ${req.body.duid}`;
  logger.info(sql, 'sqlsql');

  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);

        const sqlQuery = `SELECT * from springer.trn_jobdetails ${
          condition ? `WHERE${condition}` : condition
        } where duid = ${
          req.body.duid
        } LIMIT ${recordPerPage} OFFSET ${offset}`;

        console.log(sqlQuery, 'qryprint');
        query(sqlQuery)
          .then(data => {
            logger.info('color', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getdownloadmanuscriptfile = (req, res) => {
  try {
    let sql = '';
    sql = `SELECT * FROM springer.trn_jobdetails a1 INNER JOIN  springer.trn_download_upload a2
    ON a1.jobcodeid = a2.jobcodeid INNER JOIN springer.mst_jobsheettype a3 ON 
    a2.currentjobsheettype = a3.jobsheettypeid INNER JOIN public.mst_jobstatus a4 ON a2.currentstatus = a4.statusid and a2.logstatus = a4.statusid where a1.jobcodeid = ${req.body.jobcodeid} ORDER BY a1.jobcodeid ASC `;
    logger.info(sql, 'sqll');
    query(sql)
      .then(data => {
        res.status(200).json({
          data,
        });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (e) {
    res.status(400).send({ message: e });
  }
};

export const activityTrackList = async (req, res) => {
  try {
    const reqData = req.body;
    // const { pageNo } = reqData;
    // const { recordPerPage } = reqData;
    // let offset = (pageNo - 1) * recordPerPage;
    let sql = '';
    let condition = '';
    if (reqData.type === 'filter') {
      //  offset = 0;
      reqData.filter.forEach((item, i) => {
        condition +=
          reqData.filter.length - 1 !== i
            ? ` LOWER(${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%' :: text AND `
            : ` LOWER(${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%' :: text`;
      });
      logger.info(condition, 'conditionconditioncondition111');
    }
    sql = `select count(*) from wms_workorder_activity_audit as wwaa
    join wms_workflow_eventlog on wms_workflow_eventlog.wfeventid = wwaa.wfeventid
    join wms_workorder on wms_workorder.workorderid= wms_workflow_eventlog.workorderid
    join wms_workflowdefinition  on wms_workflowdefinition.wfdefid=wms_workflow_eventlog.wfdefid
    join wms_mst_activity on wms_mst_activity.activityid= wms_workflowdefinition.activityid
    join wms_mst_stage on wms_mst_stage.stageid= wms_workflowdefinition.stageid  ${
      condition ? `WHERE${condition}` : condition
    }`;
    logger.info(sql, 'sqlsql');
    const getCount = await query(sql);
    logger.info(getCount, 'getCount');
    if (getCount[0].count > 0) {
      // const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
      const sqlQuery = `select itemcode,stagename,activityname,actiontype, age(updatedon, wwaa.createdon)::text as duration, concat(username, ' (', wms_user.userid, ')') as updatedby, 
      case when systeminfo::JSON->> 'systemIP' is null 
	  	then systeminfo::JSON->> 'SYSTEM_NAME' 
			else systeminfo::JSON->> 'systemIP' end as systemip 
      from wms_workorder_activity_audit as wwaa
          join wms_workflow_eventlog on wms_workflow_eventlog.wfeventid = wwaa.wfeventid
          join wms_workorder on wms_workorder.workorderid= wms_workflow_eventlog.workorderid
          join wms_workflowdefinition  on wms_workflowdefinition.wfdefid=wms_workflow_eventlog.wfdefid
          join wms_mst_activity on wms_mst_activity.activityid= wms_workflowdefinition.activityid
          join wms_mst_stage on wms_mst_stage.stageid= wms_workflowdefinition.stageid 
          join wms_user on wms_user.userid= wwaa.updatedby  ${
            condition ? `WHERE${condition}` : condition
          }
        ORDER BY activityauditid DESC `;
      console.log(sqlQuery, 'activity track sql');
      const data = await query(sqlQuery);
      res.status(200).json({
        data,
      });
    } else {
      res.status(200).json({ data: [], message: 'No data found' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getactivitystartend = (req, res) => {
  // select * from getactivity_startend('{"startdate":"2023-02-28 00:00:00","enddate":"2023-03-28 00:00:00","stagename":"Typescript","activity":"FQA","itemcode":"testing-template02"}');
  const reqData = req.body;
  const jdata = reqData.params;
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.getactivity_startend('${jdata}')`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `select * from public.getactivity_startend('${jdata}')`;

        console.log(sqlQuery, 'qryprint');
        query(sqlQuery)
          .then(data => {
            logger.info('color', data);
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageCreatedCount = (req, res) => {
  const { duID, startdate, enddate } = req.body;

  const sql = `select * from get_inflowreport_data(${duID}, '${startdate}', '${enddate}') `;
  console.log(sql, 'createdstage count');

  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getDespatchFailureReport = async (req, res) => {
  const { duID } = req.body;

  const sql = `select * from get_despatchfailure_report_data(${duID}) `;
  // const sql = `select * from get_despatchfailure_report_data_fpfw(${duID})`;
  console.log('despatchfailure', sql);
  query(sql)
    .then(data => {
      console.log('despatchfailure', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWipEngineActivityReport = async (req, res) => {
  // const { duID } = req.body;

  const sql = `SELECT * FROM public.getwip_engine_status_report()`;
  console.log('wipengineactivity', sql);
  query(sql)
    .then(data => {
      console.log('wipengineactivity', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getAuditReport = async (req, res) => {
  const { duId, startdate, enddate } = req.body;
  // dummy data entry into the table
  const sql = `select  * from public.wms_toolsupload_actions_audit where duid = (${duId})
  and createdon BETWEEN '${startdate}' and '${enddate}'`;

  console.log('auditreport', sql);
  query(sql)
    .then(data => {
      // data.forEach(list => {
      //   const fileName = list.filename;
      //   logger.info(basename(fileName), 'newwms');
      //   const parsedFileName = path.parse(fileName);
      //   list.filename = parsedFileName.base;
      //   logger.info(path.basename(fileName), 'newwms2');
      // });
      console.log('auditreport', data);
      // console.log(basename(list.filename),'test')
      logger.info(data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getToolsMasterAccessRightsReport = async (req, res) => {
  const { duId } = req.body;

  const sql = `select * from public.wms_toolsmasteraccessrights_report where duid = (${duId})`;
  console.log('ToolsMasterAccessRights', sql);
  query(sql)
    .then(data => {
      console.log('ToolsMasterAccessRights', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getToolsMasterAccessRights = async (req, res) => {
  const { duId, userid } = req.body;

  // const sql = `select * from public.wms_toolsmasteraccessrights_report where duid = (${duId})`;
  const sql = `select * from wms_tools_accessrights rights
  join wms_toolsmaster_serverpath toolsmaster ON toolsmaster.exeid = rights.exeid
  where toolsmaster.duid =${duId} and rights.userid = '${userid}'`;

  console.log('ToolsMasterAccessRights', sql);
  query(sql)
    .then(data => {
      console.log('ToolsMasterAccessRights', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getToolsListServerPath = async (req, res) => {
  // const sql = `select * from wms_toolsmaster_serverpath `;
  const sql = `select tool.toolid as exeid,type.tooltype,tool.toolname as exename,tool.tooldescription,tool.customerid,((tool.payload->>'dependentFiles')::json)->0->'src' as path  
  from pp_mst_tool tool
  join pp_mst_tooltype type on type.tooltypeid = tool.tooltypeid
  where tool.tooltypeid = 2 and tool.toolstatus = true`;
  console.log('Toolslist', sql);
  query(sql)
    .then(data => {
      console.log('Toolslist', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
//  getUsersByCustomer
export const getUsersByCustomer = async (req, res) => {
  const datas = req.body;
  console.log('datas', datas);
  const { toolname } = datas;
  console.log('toolname', toolname);

  const { customername } = req.body;
  const customerNameString = customername
    .map(name => `'${name.trim()}'`)
    .join(', ');
  console.log('customerNameString', customerNameString);
  const sql = `SELECT res1.username,res1.userid, acr.read as checked,acr.upload as isUpchecked,acr.delete as isDownchecked  FROM
  (
    select wuser.username,wuser.userid,wuser.useractive,wuser.duid,
    customer.customerid,customer.customername
    from  
    public.org_mst_customer customer 
    join org_mst_customer_orgmap custmap ON custmap.customerid = customer.customerid
    join org_mst_customerorg_du_map dumap ON dumap.custorgmapid = custmap.custorgmapid
    join org_mst_deliveryunit du ON du.duid =dumap.duid
    left join wms_user wuser ON wuser.duid = du.duid
    where customer.customername IN (${customerNameString}) 
    group by wuser.username,wuser.userid,wuser.useractive,wuser.duid,
    customer.customerid,customer.customername
  ) AS res1
  LEFT JOIN wms_tools_accessrights as acr on acr.userid = res1.userid and acr.customerid = res1.customerid and acr.toolname = ('${toolname}')
  group by res1.username,res1.userid, acr.read,acr.upload,acr.delete`;

  console.log('UsersList', sql);
  query(sql)
    .then(data => {
      data.forEach(list => {
        list.isUpchecked = list.isupchecked;
        list.isDownchecked = list.isdownchecked;
      });
      console.log('Userslist', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const postToolsMasterAccessRights = async (req, res) => {
  const requestData = req.body;

  console.log(req.body, 'postToolsMasterAccessRights');
  console.log(requestData, 'sssssssss');

  try {
    const { toolslist, toolsdescription, toolpath, checkedData, customername } =
      requestData;
    const insertData = checkedData.map(data => ({
      toolname: toolslist,
      tooldescription: toolsdescription,
      toolpath,
      customername: customername[0].custname,
      ...data,
    }));
    console.log('insertData', insertData);
    console.log('insertData', JSON.stringify(insertData));

    const p_data = JSON.stringify(insertData);
    console.log(p_data);
    const sql = `SELECT * FROM public.insert_or_update_tools_accessrights_1('${p_data}')`;
    query(sql)
      .then(data => {
        console.log('toolsaccess', data);
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (err) {
    console.log(err, 'postToolsMasterAccessRights error');
  }
};

export const addNewTool = async (req, res) => {
  try {
    const {
      exename,
      tooldescription,
      path,
      customername,
      tooltype,
      servername,
    } = req.body;

    console.log('req.body', req.body);
    const sql = `
      SELECT * from public.add_new_tool(
        $1, $2, $3, $4, $5, $6
      ) AS result;
    `;
    console.log('query', sql);
    const result = await query(sql, [
      exename,
      tooldescription,
      path,
      customername,
      tooltype,
      servername,
    ]);
    console.log('result', result);
    if (result && result[0].result == -1) {
      res.status(200).json({ message: 'Tool already exist' });
    } else {
      res.status(200).json({ success: 'Tool Added Successfully' });
    }
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const getCompletedWorkOrders = async (req, res) => {
  const jsonparam = JSON.stringify(req.body);
  console.log('jsonparam', jsonparam);

  try {
    const sql = `
      SELECT serialno, workorderid, itemcode, title, customername, division, subdivision, countryname,
      enddatetime, duid, customerid, divisionid, subdivisionid, wfid
      FROM public.getcompletedjobs('${jsonparam}')
    `;
    console.log('sql', sql);
    console.log('params', jsonparam);
    query(sql)
      .then(data => {
        console.log('completed work orders data', data);
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error.message });
      });
  } catch (err) {
    console.error(err);
  }
};

export const getFTPAuditReport = async (req, res) => {
  const { duID } = req.body;

  const sql = `select * from public.get_ftpreport_data(${duID})`;

  console.log('getFTPAuditReport', sql);
  query(sql)
    .then(data => {
      console.log('getFTPAuditReport', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFTPDownloadReportSpringer = async (req, res) => {
  // const { duID } = req.body;

  const sql = `select journalname  ,bookcode  ,downloadstarttime ,downloadendtime , filepath  , receiveddate ,packagename ,packagetype ,
  statusdescription  ,status , remarks ,duid ,zipfileid , processtype,stageid
  from springer.get_ftpdownloaduploadspringer()`;

  console.log('getFTPDownloadReportSpringer', sql);
  query(sql)
    .then(data => {
      console.log('getFTPDownloadReportSpringer', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getFilepathforSpringer = async (req, res) => {
  try {
    const { stageid } = req.body;
    const sqlqry = `SELECT s200ftppath, s300ftppath,s600ftppath,fileserverpath, * FROM springer.ice_integrasettings where isactive = 'Y'`;
    console.log('getFilepathforSpringer', sqlqry);
    const data = await query(sqlqry);
    const response =
      stageid === 200
        ? data[0].s200ftppath
        : stageid == 300
        ? data[0].s300ftppath
        : data[0].s600ftppath;
    res.status(200).send({ response, fileserverpath: data[0].fileserverpath });
  } catch (error) {
    res.status(400).send({ error });
  }
};

export const getDownloadUploadManuscriptReport = async (req, res) => {
  const { duID, stageid, start, end } = req.body;

  try {
    const sql = `select * from springer.get_downloadmanuscriptreport_data(${duID},'${stageid}', '${start}', '${end}') `;
    query(sql)
      .then(data => {
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } catch (error) {
    console.log('error', error);
  }
};

export const getJobsheetHistoryforSpringer = async (req, res) => {
  try {
    const { stageid, duID, bookcode } = req.body;
    const sqlqry = `select * from springer.get_jobsheet_history_data(${duID},'${stageid}', '${bookcode}')`;

    const data = await query(sqlqry);
    // console.log("data",data);
    res.status(200).json({ data });
  } catch (error) {
    res.status(400).send({ error });
  }
};
