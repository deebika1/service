// import remoteFileWatcher from 'remote-file-watcher'; // For SFTP
import xml2jsonConvertor from 'xml2js';
import { fileURLToPath } from 'url';
import { join, basename, extname } from 'path';
import fs from 'fs';
import {
  getFilefromSFTP,
  getsftpConfig,
  extractZip,
  getFilefromSFTPToDestPath,
  checkDirectorySync,
} from './index.js';
import logger from '../utils/logs/index.js';
import { query } from '../../database/postgres.js';
import { removeFolder } from '../utils/custom/io.js';
import { readWorkorderInfoprocess } from '../woi/woAutocreation.js';
import { _upload } from '../utils/azure/index.js';

const __filename = fileURLToPath(import.meta.url);
// const __dirname = dirname(__filename);

export const fetchXmlReaderFromSftpWatcher = async (req, res) => {
  try {
    const { currFileName, fPath } = req.body;
    const result = await _fetchXmlReaderFromSftpWatcher(currFileName, fPath);
    res
      .status(200)
      .json({ data: result, message: 'WorkOrder Created Successfulyy' });
  } catch (e) {
    logger.info(e);
    res.status(400).send(e);
  }
};

export const _fetchXmlReaderFromSftpWatcher = async (currFileName, fPath) => {
  return new Promise(async (resolve, reject) => {
    let details;
    try {
      let orginalZipPath = '';
      const ioppSftpConfig = await getsftpConfig('iopp_sftp_conf');
      const fileContent = await getFilefromSFTP(ioppSftpConfig, fPath);
      const xmlText = fileContent.toString('utf8');
      logger.info(xmlText, 'xmlText for ioop');
      let zipXmlContent = '';
      let ioppJsonData = '';
      let ioopXmlData = '';
      xml2jsonConvertor.parseString(xmlText, function (err, result) {
        ioppJsonData = result;
      });
      logger.info(ioppJsonData);
      // audit for xml content from ftp
      const trnId = await auditForXmlReader(ioppJsonData.xml);
      // extract zippath from the xml content
      const zipPath =
        ioppJsonData &&
        Object.keys(ioppJsonData).length > 0 &&
        ioppJsonData.xml &&
        Object.keys(ioppJsonData.xml).includes('resource') &&
        ioppJsonData.xml.resource
          ? ioppJsonData.xml.resource[0].replace(ioppSftpConfig.iopp_link, '')
          : '';
      const zipFileName =
        ioppJsonData &&
        Object.keys(ioppJsonData).length > 0 &&
        ioppJsonData.xml &&
        Object.keys(ioppJsonData.xml).includes('about') &&
        ioppJsonData.xml.about
          ? ioppJsonData.xml.about[0]
          : '';
      if (zipPath && zipFileName) {
        orginalZipPath = `${zipPath}/${zipFileName}`;
        const { zipcontent, dest1 } = await fetchZipReaderFromSftpWatcher(
          zipFileName,
          orginalZipPath,
          ioppSftpConfig,
        );
        xml2jsonConvertor.parseString(zipcontent, function (err, zipResult) {
          ioopXmlData = zipResult;
        });
        zipXmlContent = zipcontent.toString('utf8');

        details = await createAutoWoForIopp(
          zipXmlContent,
          ioopXmlData,
          ioppJsonData,
          trnId,
        );
        // xml content from zip folder
        const jobFileName = zipFileName.split('.zip')[0];
        const jobSheet = {
          tempFilePath: join(dest1, jobFileName, `${jobFileName}.XML`),
          name: 'jobsheet.xml',
        };
        // upload file to azure
        await fileUpload(dest1, zipFileName, details);
        await _upload(jobSheet, details.path);
        logger.info(ioopXmlData);
        // delete upload folder
        await removeFolder(dest1);
      } else {
        logger.info(
          `unable to read zip file for iopp customer ${orginalZipPath}`,
        );
      }
      resolve({ zipXmlContent, ioopXmlData });
    } catch (e) {
      logger.info(
        `unable to read xml file for iopp customer ${e} and error for article name ${details.name}`,
      );
      reject(e);
    }
  });
};

export const insert_uploadpath_uid = async req => {
  const { articlename, stagename, stageiterationcount, uploadpath, uid } = req;
  return new Promise(async resolve => {
    const sql = `select insert_uploadpathuid ('${articlename}','${stagename}',${stageiterationcount},'${uploadpath}','${uid}')`;
    console.log(sql, 'insert_uploadpathuid');
    query(sql)
      .then(async response => {
        if (response && response.length) {
          const respid = response[0].insert_uploadpathuid;
          resolve({ issuccess: true, id: respid, message: 'success' });
        } else {
          resolve({ issuccess: false, id: 0, message: 'failed' });
        }
      })
      .catch(error => {
        resolve({ issuccess: false, id: 0, message: error.message });
      });
  });
};

export const fileUpload = async (dest1, zipFileName, details) => {
  return new Promise(async (resolve, reject) => {
    const req = {};
    try {
      const localZipPath = join(dest1, zipFileName);
      const file = {
        name: basename(localZipPath),
        tempFilePath: localZipPath,
      };
      const OpenKMOutput = await _upload(file, details.path);
      req.uid = OpenKMOutput.data.uuid;
      req.uploadpath = OpenKMOutput.fullPath;
      req.articlename = details.name;
      req.stageiterationcount = details.payload.stageiterationcount;
      req.stagename = details.payload.stagename;
      await insert_uploadpath_uid(req);
      resolve();
    } catch (e) {
      reject(e);
      logger.info(`file upload issue  ${req.uploadpath}`);
    }
  });
};
export const auditForXmlReader = async ioppJsonData => {
  return new Promise((resolve, reject) => {
    const { from, type, about, resource } = ioppJsonData;
    const ioopvalues = [];
    const input = JSON.stringify(ioppJsonData);
    ioopvalues.push(
      `('${input}', '${from[0]}', '${type[0]}', '${''}', '${about[0]}','${
        resource[0]
      }')`,
    );
    const sql = `INSERT INTO public.ftp_audit_wo_creation(
             inputjson, duname, stagename, articlename, ftpfilename, ftpfilepath)
            VALUES ${ioopvalues} RETURNING auditid`;
    query(sql)
      .then(data => {
        console.log(data);
        resolve(data ? data[0].auditid : '');
        logger.info(`filemap updated for ${about[0]}`);
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const updateauditForXmlReader = async (trnId, articelName) => {
  return new Promise((resolve, reject) => {
    const sql = `UPDATE public.ftp_audit_wo_creation
        SET  articlename='${articelName}'
        WHERE auditid = ${trnId}`;
    query(sql)
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const fetchZipReaderFromSftpWatcher = async (
  currFileName,
  fPath,
  ioppSftpConfig,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const source = fPath;
      console.log(__filename, '__filename');
      let dest1 = join(__filename, '../../../../');
      dest1 += 'upload\\iopp';
      // const dest = 'D:\\WMSProjects\\WMS\\iwms-service-layer\\upload\\iopp';
      let destination = basename(fPath);
      const ext = extname(fPath);
      destination = join(dest1, destination);
      await checkDirectorySync(dest1);
      await getFilefromSFTPToDestPath(ioppSftpConfig, source, destination);
      await extractZip(destination);
      const baseFolder = basename(fPath).replace(ext, '');
      const zipFilePath = join(
        dest1,
        baseFolder,
        currFileName.replace('zip', 'XML'),
      );
      logger.info(zipFilePath, 'zipFilePathzipFilePath');
      const zipcontent = fs.readFileSync(zipFilePath);
      resolve({ zipcontent, dest1 });
    } catch (e) {
      logger.info(`unable to read zip file for iopp customer ${e}`);
      reject(e);
    }
  });
};

export const createAutoWoForIopp = async (
  zipXmlContent,
  ioopXmlData,
  ioppJsonData,
  trnId,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      let payload;
      let response = {};
      const stagename =
        ioppJsonData.xml &&
        ioppJsonData.xml.type &&
        ioppJsonData.xml.type.length > 0 &&
        ioppJsonData.xml.type[0] &&
        ioppJsonData.xml.type[0].includes('Pre Edit')
          ? 'Structure_PreEditing'
          : '';
      const articelName =
        ioopXmlData.article['article-meta'][0]['article-id'][0].$[
          'pub-id-type'
        ] == 'manuscript'
          ? ioopXmlData.article['article-meta'][0]['article-id'][0]._
          : '';
      const journal =
        ioopXmlData.article['journal-meta'][0]['journal-id'][0].$[
          'journal-id-type'
        ] == 'publisher-id'
          ? ioopXmlData.article['journal-meta'][0]['journal-id'][0]._
          : '';
      const tasktype = ioopXmlData.article.task[0].$['task-type'];
      console.log(ioopXmlData, 'ioopXmlData', ioppJsonData);
      if (journal && articelName && stagename) {
        payload = {
          InPath: '',
          customer: ioppJsonData.xml.from[0],
          fileType: 'xml',
          woType: 'Journal',
          jobType: 'Article',
          journal,
          tasktype,
          articlename: articelName,
          stagename,
          stageiterationcount: '1',
          remark: '',
          content: zipXmlContent,
          piivalue: '',
          ftpauditid: +trnId,
        };
        logger.info(JSON.stringify(payload), 'Iopp before Trigger');
        await updateauditForXmlReader(trnId, articelName);
        response = await readWorkorderInfoprocess(
          { body: payload },
          { res: {} },
        );
        console.log(response);
      } else {
        logger.info('work order creation failed');
        throw new Error('work order creation failed');
      }
      resolve({
        name: articelName,
        path: response.uploadpath,
        payload,
      });
    } catch (e) {
      reject(e);
      logger.info(`work order creation failed ${e}`);
    }
  });
};

// ----------------------------sftp watcher start here --------------------
// (async () => {
//   const ioppSftpWatcherConfig = await getsftpConfig('iopp_sftp_watcher_conf');
//   if (ioppSftpWatcherConfig != 'inactive') {
//     try {
//       // eslint-disable-next-line new-cap
//       const objRemoteFileWatcher = new remoteFileWatcher(
//         'iopp_watcher',
//         ioppSftpWatcherConfig,
//       );
//       objRemoteFileWatcher.on('uploading', function (objFile) {
//         logger.info('FILE UPLOADING:');
//         console.info(objFile);
//       });
//       objRemoteFileWatcher.on('uploaded', function (objFile) {
//         logger.info('FILE UPLOADED:');
//         logger.info(objFile);
//         const fPath = `${objFile.folder}/${objFile.fileName}`;
//         const currFileName = objFile.fileName;
//         fetchXmlReaderFromSftpWatcher(currFileName, fPath);
//       });
//       objRemoteFileWatcher.on('error', function (strServername, error) {
//         console.log(`ERROR: ${strServername}`);
//         logger.info(`unable to connect SFTP ${error}`);
//       });
//     } catch (e) {
//       logger.info(`unable to connect Iopp SFTP ${e}`);
//     }
//   }
// })();
// -------------------------------sftp watcher ends here-------------------------------------
