import fs, { createReadStream } from 'fs';
import moment from 'moment';
import remoteFileWatcher from 'remote-file-watcher'; // For SFTP
import FormData from 'form-data';
import xml2jsonConvertor from 'xml2js';
import { query } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';
import { config } from '../../config/restApi.js';
import {
  getNotificationConfig,
  getAuthAccessWorflow,
} from '../common/index.js';
import { emitAction } from '../activityListener/index.js';
import { Service } from '../../httpClient/index.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import { _getUuid } from '../utils/okm/index.js';
import * as azureHelper from '../utils/azure/index.js';
import {
  getFilefromSFTP,
  uploadFileToSFTP,
  writeOutPkgFile,
  getsftpConfig,
} from './index.js';
import { getdmsType } from '../bpmn/listener/create.js';

const service = new Service();

export const signalReceiverFromSftp = async (currFileName, fPath) => {
  try {
    let signalCategory = '';
    signalCategory =
      currFileName.indexOf('PC-validation') !== -1
        ? '201_packagevalidation'
        : currFileName.indexOf('-AU-2') !== -1
        ? '202_authorsubmission'
        : currFileName.indexOf('-PC-2') !== -1
        ? '203_collatorsubmission'
        : currFileName.indexOf('-SPM-Q-2') !== -1
        ? '204_spmquery'
        : currFileName.indexOf('-PC-Q-2') !== -1
        ? '205_collatorquery'
        : currFileName.indexOf('.zip') !== -1
        ? '206_out_package'
        : 'Unable to predict the signal category';
    // let signalExists = await checkIfSignalExists(currFileName);
    // let subSignalExists = await checkIfSubSignalExists(currFileName, signalCategory);
    const sftpConfig = await getsftpConfig('pc_sftp_conf');
    const fileContent = await getFilefromSFTP(sftpConfig, fPath);
    const xmlText = fileContent.toString('utf8');
    // console.log(fileContent, xmlText);
    xml2jsonConvertor.parseString(xmlText, function (err, result) {
      const pcRespInJson = result;
      console.log(pcRespInJson);
      // subSignalExists.count == '0' &&
      // signalExists.count == '0' &&
      if (signalCategory == '202_authorsubmission') {
        const articlefileId = currFileName.toString().split('-AU-2').shift();
        getOutPackagefromSFTP(
          fileContent,
          currFileName,
          articlefileId,
          signalCategory,
        );
        recordFileTransferDetails(
          pcRespInJson['proofcentral-out-information'],
          signalCategory,
          currFileName,
          articlefileId,
        );
      }
      if (signalCategory == '203_collatorsubmission') {
        const articlefileId = currFileName.toString().split('-PC-2').shift();
        getOutPackagefromSFTP(
          fileContent,
          currFileName,
          articlefileId,
          signalCategory,
        );
        recordFileTransferDetails(
          pcRespInJson['proofcentral-out-information'],
          signalCategory,
          currFileName,
          articlefileId,
        );
      }
      if (signalCategory == '201_packagevalidation') {
        const articlefileId = currFileName
          .toString()
          .split('-PC-validation')
          .shift();
        getOutPackagefromSFTP(
          fileContent,
          currFileName,
          articlefileId,
          signalCategory,
        );
        recordFileTransferDetails(
          pcRespInJson['proofcentral-import-information'],
          signalCategory,
          currFileName,
          articlefileId,
        );
      }
      if (signalCategory == '206_out_package') {
        if (currFileName.indexOf('-AU-2') !== -1) {
          const articlefileId = currFileName.toString().split('-AU-2').shift();
          getOutPackagefromSFTP(
            fileContent,
            currFileName,
            articlefileId,
            '206_out_package_AU',
          );
        } else if (currFileName.indexOf('-PC-2') !== -1) {
          const articlefileId = currFileName.toString().split('-PC-2').shift();
          getOutPackagefromSFTP(
            fileContent,
            currFileName,
            articlefileId,
            '206_out_package_PC',
          );
        }
      }
    });
  } catch (error) {
    logger.info(`Unable to receive the signal ${error}`);
  }
};

export const getOutPackagefromSFTP = async (
  fileContent,
  currFileName,
  articlefileId,
  signalCategory,
) => {
  try {
    console.log(currFileName, 'current_FileId');
    await writeOutPkgFile(`uploads/${currFileName}`, fileContent, `uploads`);
    const Wodetails = await getwoInfoForPkg(articlefileId);
    console.log(articlefileId, 'current_pkgFileId');
    const wfeid = Number(Wodetails.wfeventid) ? Number(Wodetails.wfeventid) : 0;
    const woinid = Number(Wodetails.woincomingfileid)
      ? Number(Wodetails.woincomingfileid)
      : 0;
    const woId = Number(Wodetails.workorderid)
      ? Number(Wodetails.workorderid)
      : 0;
    const dmsType = await getdmsType(woId);
    const stageIt = Number(Wodetails.stageiterationcount)
      ? Number(Wodetails.stageiterationcount)
      : 0;
    const activityIt = Number(Wodetails.activityiterationcount)
      ? Number(Wodetails.activityiterationcount)
      : 0;
    const pathSrcGen = {
      type: 'wo_proofcentral',
      du: {
        name: 'emerald_du',
        id: '5',
      },
      customer: {
        name: 'emerald_publishing',
        id: '6',
      },
      workOrderId: woId,
      service: {
        name: 'typesetting',
        id: '1',
      },
      stage: {
        name: 'First_Proof',
        id: '1',
        iteration: stageIt,
      },
      activity: {
        name: 'Cams package creation',
        id: '70',
        iteration: activityIt,
      },
      fileType: {
        name: 'article',
        id: '4',
        fileId: woinid,
      },
    };
    if (
      signalCategory == '203_collatorsubmission' ||
      signalCategory == '206_out_package_PC'
    ) {
      pathSrcGen.stage.name = 'ALP Package Creation';
      pathSrcGen.stage.id = '5';
      pathSrcGen.activity.name = 'Collation';
      pathSrcGen.activity.id = '29';
    }
    const folderpathRes = await getFolderStructure(pathSrcGen);
    let targetFilePath = '';
    if (
      signalCategory == '202_authorsubmission' ||
      signalCategory == '206_out_package_AU'
    ) {
      targetFilePath = `${folderpathRes}from_author`;
    } else if (
      signalCategory == '203_collatorsubmission' ||
      signalCategory == '206_out_package_PC'
    ) {
      targetFilePath = `${folderpathRes}from_collator`;
    } else {
      targetFilePath = folderpathRes;
    }
    logger.info(`Upload started for ${currFileName}`);
    const fData = new FormData();
    const pStream = createReadStream(`uploads/${currFileName}`);
    fData.append('content', pStream);
    fData.append('docPath', `${targetFilePath}/${currFileName}`);
    const header = {
      Authorization: `Basic ${process.env.OKM_AUTH}`,
      'Content-Type': `multipart/form-data; boundary=${fData._boundary}`,
    };
    console.log(targetFilePath);
    const getOutPkgPrms = new Promise(async (resolve, reject) => {
      try {
        // const response = await service.upload(`${config.openKM.base_url}${config.openKM.uri.upload}`, fData, header);
        const response = await service.upload(
          `${config.blob_rest.base_url}${config.blob_rest.uri.upload}`,
          fData,
          header,
        );
        console.log(response);
      } catch (err) {
        logger.info('Failure in file_upload', err);
      }
      try {
        fs.unlink(`uploads/${currFileName}`, function (err) {
          if (err) {
            logger.info('File deleted failed! Error:', err);
          } else {
            logger.info('File deleted!');
          }
        });
      } catch (err) {
        logger.info('Error', err);
      }
      try {
        const sFilePath = `${targetFilePath}/${currFileName}`;
        let pc_outUuid = '';
        switch (dmsType) {
          case 'azure':
            pc_outUuid = 'azure';
            break;

          default:
            pc_outUuid = await _getUuid(sFilePath);
            break;
        }
        const fvalues = [];
        fvalues.push(
          `(${wfeid}, '${pc_outUuid}', '${sFilePath}', ${true}, ${false}, ${woinid})`,
        );
        const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
                    wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
                    VALUES ${fvalues};`;
        query(sql)
          .then(() => {
            resolve();
            logger.info(`filemap updated for ${currFileName}`);
          })
          .catch(e => {
            reject(e);
          });
        logger.info(`Upload completed for ${currFileName}`);
        resolve();
      } catch (error) {
        logger.info('error', error);
        reject(error);
      }
    });
    return getOutPkgPrms.catch(message => {
      console.log(`getOutPkgPrms Failed: ${message}`);
    });
  } catch (err) {
    logger.info(`Unable to get the outpackage ${err}`);
    return false;
  }
};

const recordFileTransferDetails = async (
  pcRespInJson,
  signalCategory,
  currFileName,
  articlefileId,
) => {
  try {
    const objWodetails = await getwoInfoForPkg(articlefileId);
    const reswoid = objWodetails.workorderid ? objWodetails.workorderid : '';
    const reswfid = objWodetails.wfid ? objWodetails.wfid : '';
    const resduId = 5;
    // const entityId = 59;
    const artCode = objWodetails.itemcode ? objWodetails.itemcode : '';
    const tDoiNumber = objWodetails.doinumber ? objWodetails.doinumber : '';
    const rescusId = objWodetails.customerid
      ? Number(objWodetails.customerid)
      : '';
    const wfconfdata = {
      workorderid: Number(reswoid),
      wfid: reswfid,
      customerid: rescusId,
    };
    const processInstIdetails = await getprocessInstIdetails(reswoid);
    const processInstId = processInstIdetails.processinstanceid
      ? processInstIdetails.processinstanceid
      : '';
    if (signalCategory == '201_packagevalidation') {
      const datetime = new Date();
      const currDate = datetime.toISOString();
      const resSupplier = pcRespInJson.metadata[0].supplier
        ? pcRespInJson.metadata[0].supplier[0]
        : '';
      let resStatus = pcRespInJson.status ? pcRespInJson.status[0] : '';
      const resUrl = pcRespInJson.url ? pcRespInJson.url : '';
      if (resStatus != 'success') {
        resStatus = pcRespInJson.status ? pcRespInJson.status[0]._ : '';
      }
      const resErrDes = 'FAILED - Invalid Package';
      const resTimestamp = pcRespInJson.timestamp ? pcRespInJson.timestamp : '';
      const resJid = pcRespInJson['package-info'][0]['journal-id']
        ? pcRespInJson['package-info'][0]['journal-id'][0]
        : '';
      const resAid = pcRespInJson['package-info'][0]['article-id']
        ? pcRespInJson['package-info'][0]['article-id'][0]
        : '';
      const resPkgId = pcRespInJson['package-info'][0]['package-id']
        ? pcRespInJson['package-info'][0]['package-id'][0]
        : '';
      const respWoId = Number(reswoid);
      const sql = `INSERT INTO public.wms_mst_pkgvalidationsignal(
            customerid, pkgname, responsetype, signal_status, isactive, du_id, woid, entityid, signalcategory, error_description, created_date, articleid, packageid, journalid, time_stamp, pc_url, supplier)
            VALUES (6, '${currFileName}', 'xml',  '${resStatus}', true ,${resduId}, ${respWoId}, '59', '${signalCategory}',  '${resErrDes}','${currDate}','${resAid}','${resPkgId}','${resJid}','${resTimestamp}','${resUrl}','${resSupplier}')  RETURNING customerid`;
      console.log(sql, 'sql for pkg validation signal');
      query(sql)
        .then(data => {
          console.log(data, 'res for pkg validation insert');
          if (data.length) {
            console.log('Inserted Successfully.');
          }
        })
        .catch(error => {
          console.log(error);
        });

      console.log(objWodetails);
      if (resStatus != 'success') {
        const reqMailData = {
          duId: 5,
          entityId: 60,
          services: '1',
        };
        sendMail(reqMailData, wfconfdata, resErrDes, 'pkg_error');
        actOnPcSignal('Wait for PC Feedback', processInstId, true);
      } else {
        const reqMailData = {
          duId: 5,
          entityId: 59,
          services: '1',
        };
        sendMail(reqMailData, wfconfdata, resUrl, 'onlineproof');
        actOnPcSignal('Wait for PC Feedback', processInstId, false);
        TrackitTriggerFP(respWoId, tDoiNumber);
      }
    } else {
      console.log(pcRespInJson, signalCategory);
      const datetime = new Date();
      const currDate = datetime.toISOString();
      let resStatus = pcRespInJson.status ? pcRespInJson.status[0] : '';
      const receivedPayload = '';
      let resStatusCode = '1';
      if (resStatus != 'success') {
        resStatus = pcRespInJson.status ? pcRespInJson.status[0] : '';
        resStatusCode = '0';
      }
      const fileNameId = currFileName || '';
      const resJid = pcRespInJson.article[0].jid
        ? pcRespInJson.article[0].jid[0]
        : '';
      const resAid = pcRespInJson.article[0].aid
        ? pcRespInJson.article[0].aid[0]
        : '';
      const resUrl = pcRespInJson.url ? pcRespInJson.url[0] : '';
      const resTimestamp = pcRespInJson.timestamp
        ? pcRespInJson.timestamp[0]
        : '';
      console.log(resStatus, resTimestamp, resAid, resJid);
      if (
        signalCategory == '202_authorsubmission' ||
        signalCategory == '203_collatorsubmission'
      ) {
        const resSupplier = pcRespInJson.supplier[0].name
          ? pcRespInJson.supplier[0].name[0]
          : '';
        const resOutPkgName = pcRespInJson['out-package'][0]['zip-name']
          ? pcRespInJson['out-package'][0]['zip-name'][0]
          : '';
        const resOutPkgUrl = pcRespInJson['out-package'][0]['zip-url']
          ? pcRespInJson['out-package'][0]['zip-url'][0]
          : '';
        const resNextCorrector = pcRespInJson['next-proof-corrector']
          ? pcRespInJson['next-proof-corrector'][0]
          : '';
        const resSubmittedBy = pcRespInJson['submitted-by']
          ? pcRespInJson['submitted-by'][0]
          : '';
        const resCorrectionThrough = pcRespInJson['correction-through']
          ? pcRespInJson['correction-through'][0]
          : '';
        const resMd = pcRespInJson.MD5 ? pcRespInJson.MD5[0] : '';
        const resErrDes = '';
        const sql = `INSERT INTO public.wms_mst_pcvalidationftp_resp(
        customerid, filename, responsetype, signal_status, md5, isprocessed, created_date, signaldata, pc_timestamp, pc_supplier, pc_article_jid, pc_article_aid, pc_submitted_by, pc_correction_through, pc_next_proof_corrector, pc_url, pc_out_zipname, pc_out_zipurl, du_id, woid, entityid,statuscode,signalcategory,error_description, isactive, articlename)
        VALUES (6, '${fileNameId}', '.xml', '${resStatus}', '${resMd}', false , '${currDate}', '${JSON.stringify(
          receivedPayload,
        )}', '${resTimestamp}', '${resSupplier}', '${resJid}','${resAid}', '${resSubmittedBy}','${resCorrectionThrough}' ,'${resNextCorrector}', '${resUrl}','${resOutPkgName}', '${resOutPkgUrl}',5,'${reswoid}',59,'${resStatusCode}','${signalCategory}','${resErrDes}', true, '${artCode}')  RETURNING customerid`;
        console.log(sql, 'sql for wms_mst_pcvalidationftp_resp signal');
        query(sql)
          .then(data => {
            console.log(data, 'res for wms_mst_pcvalidationftp_resp insert');
            if (data.length) {
              console.log('Inserted Successfully.');
            }
          })
          .catch(error => {
            console.log(error);
          });
        if (
          signalCategory == '202_authorsubmission' &&
          resStatus == 'success'
        ) {
          const reqMailData = {
            duId: resduId,
            entityId: 60,
            services: '1',
          };
          // triggerNextStage(reqStageData)
          sendMail(reqMailData, wfconfdata, '', 'notify_collator');
          actOnPcSignal('Wait for PC Author Feedback', processInstId, true);
        }
      } else {
        const sql = `INSERT INTO public.wms_mst_pcvalidationftp_resp(
            customerid, filename, responsetype, signal_status, isprocessed, created_date, signaldata, pc_timestamp, pc_article_jid, pc_article_aid,  pc_url, du_id, woid, entityid,statuscode,signalcategory, isactive)
            VALUES (6, '${fileNameId}', '.xml', '${resStatus}',  false , '${currDate}', '${JSON.stringify(
          receivedPayload,
        )}', '${resTimestamp}', '${resJid}','${resAid}', '${resUrl}',5,'${reswoid}',59,'${resStatusCode}','${signalCategory}', true)  RETURNING customerid`;
        console.log(sql, 'sql for wms_mst_pcvalidationftp_resp signal');
        query(sql)
          .then(data => {
            console.log(data, 'res for wms_mst_pcvalidationftp_resp insert');
            if (data.length) {
              console.log('Inserted Successfully.');
            }
          })
          .catch(error => {
            console.log(error);
          });
      }
    }
  } catch (err) {
    logger.info(`unable record FTP transactions ${err}`);
  }
};

const getwoInfoForPkg = async pkgFileId => {
  const pkgFileName = `${pkgFileId}.zip`;
  const getwoInfoForPkgPrms = new Promise((resolve, reject) => {
    try {
      const sql = `SELECT  ftrans.woid, woevent.wfeventid,woinfo.wotype ,woinfo.doinumber, woinfo.workorderid, woinfo.wfid, woinfo.customerid, woinfo.itemcode, woevent.woincomingfileid, woevent.stageiterationcount, woevent.actualactivitycount as activityiterationcount FROM public.wms_workorder as woinfo 
            JOIN public.wms_workflow_eventlog as woevent  ON woinfo.workorderid = woevent.workorderid 
            JOIN public.wms_ft_transaction_table as ftrans ON ftrans.woid = woinfo.workorderid
            WHERE  ftrans.filename = '${pkgFileName}' ORDER BY woevent.wfeventid desc limit 1`;
      // let sql = `SELECT * FROM public.wms_workorder WHERE itemcode = '${pkgFileName}' `;
      query(sql)
        .then(res => {
          console.log(res, 'res for wo details');
          resolve(res.pop());
        })
        .catch(error => {
          console.log(error, 'error for wo details');
          reject(error);
        });
    } catch (err) {
      console.log(err);
    }
  });
  return getwoInfoForPkgPrms.catch(message => {
    console.log(`getwoInfoForPkg Failed: ${message}`);
  });
};
// const checkIfSignalExists = (pkgFileId) => {
//     let signalCountPrms = new Promise((resolve, reject) => {
//         try {
//             let sql = `SELECT  COUNT(*) FROM public.wms_mst_pkgvalidationsignal  where pkgName = '${pkgFileId}' `;
//             query(sql).then((res) => {
//                 console.log(res, 'res for signal count details');
//                 resolve(res.pop())
//             }).catch((error) => {
//                 console.log(error, 'error for signal count details');
//                 reject(error);
//             });
//         } catch (err) {
//             console.log(err)
//         }
//     });
//     signalCountPrms.catch((message) => {
//         console.log("signalCount Failed: " + message);
//     });

// }
// const checkIfSubSignalExists = (pkgFileId, signalCategory) => {
//     let subSignalCountPrms = new Promise((resolve, reject) => {
//         try {
//             let sql = `SELECT  COUNT(*) FROM public.wms_mst_pcvalidationftp_resp  where filename = '${pkgFileId}' and isprocessed = false and signalcategory='${signalCategory}'`;
//             query(sql).then((res) => {
//                 console.log(res, 'res for signal count details');
//                 resolve(res.pop())
//             }).catch((error) => {
//                 console.log(error, 'error for signal count details');
//                 reject(error);
//             });
//         } catch (err) {
//             console.log(err)
//         }
//     });
//     subSignalCountPrms.catch((message) => {
//         console.log("sub signalCount Failed: " + message);
//     });
// }
const getprocessInstIdetails = woID => {
  const prInstPrms = new Promise((resolve, reject) => {
    try {
      const sql = `SELECT processinstanceid, isbookcompleted FROM public.wms_workorder_service WHERE workorderid = '${woID}' `;
      query(sql)
        .then(res => {
          console.log(res, 'res for processinstance details');
          if (res.length > 0) {
            resolve(res.pop());
          } else {
            resolve({ data: 'no record found' });
          }
        })
        .catch(error => {
          console.log(error, 'error for processinstance details');
          reject(error);
        });
    } catch (err) {
      logger.info(`Error in getting proceess instance details ${err}`);
    }
  });
  return prInstPrms.catch(message => {
    console.log(`prInstPrms Failed: ${message}`);
  });
};
export const getRemainderDate = () => {
  const endDate = new Date();
  const holiday = [];
  const noOfDaysToAdd = 5;
  for (let i = 0; i < holiday.length; i++) {
    holiday[i] = new Date(holiday[i]);
  }
  logger.info('Holiday', holiday);
  let count = 0;
  while (count < noOfDaysToAdd) {
    endDate.setDate(endDate.getDate() + 1);
    if (
      endDate.getDay() !== 0 &&
      endDate.getDay() !== 6 &&
      !isHoliday(endDate, holiday)
    ) {
      count++;
    }
  }
  endDate.setMinutes(0);
  endDate.setHours(0);
  endDate.setSeconds(30);
  return endDate;
};
const compare = (dt1, dt2) => {
  let equal = false;
  if (
    dt1.getDate() === dt2.getDate() &&
    dt1.getMonth() === dt2.getMonth() &&
    dt1.getFullYear() === dt2.getFullYear()
  ) {
    equal = true;
  }
  return equal;
};

const isHoliday = (dt, arr) => {
  let bln = false;
  for (let i = 0; i < arr.length; i++) {
    if (compare(dt, arr[i])) {
      bln = true;
      break;
    }
  }
  return bln;
};
const actOnPcSignal = async (msgName, pInstId, isRejected) => {
  try {
    let triggerPayload;
    let remaindDate;
    let enableChaser;
    if (!isRejected) {
      enableChaser = true;
    } else {
      enableChaser = false;
    }
    if (msgName == 'Wait for PC Feedback') {
      remaindDate = getRemainderDate({
        noOfDaysToAdd: 5,
        holiday: 0,
      });
      triggerPayload = {
        messageName: msgName,
        processInstanceId: pInstId,
        processVariables: {
          __isRejected__: { value: isRejected, type: 'Boolean' },
          __isEnableChaser__: { value: enableChaser },
          __timer__: { value: remaindDate },
        },
      };
    } else {
      triggerPayload = {
        messageName: msgName,
        processInstanceId: pInstId,
        processVariables: {
          __isRejected__: { value: isRejected, type: 'Boolean' },
        },
      };
    }
    const activityUpdate = new Promise(async (resolve, reject) => {
      try {
        const triggerResponse = await service.post(
          `${process.env.CAMUNDA_NATIVE_URL}message`,
          triggerPayload,
        );
        resolve(triggerResponse.data ? triggerResponse.data : triggerResponse);
      } catch (e) {
        logger.info(e);
        reject(e.message?.data ? e.message.data : e);
      }
    });
    activityUpdate.catch(message => {
      console.log(`actOnPcSignal Failed: ${message}`);
    });
  } catch (err) {
    logger.info(`unable to act On the PcSignal ${err}`);
  }
};
const TrackitTriggerFP = async (respWoId, tDoiNumber) => {
  try {
    const username = process.env.TRACKIT_USERNAME;
    const password = process.env.TRACKIT_PASSWORD;
    const payloadFortrackitFP = {
      doi: tDoiNumber,
      stage: 'FIRST_PROOF_REVIEW',
      details: 'First proof sent to author',
      source: 'Emerald',
      runNumber: '1',
      result: 'Passed',
      username,
      password,
      workorderId: respWoId,
      serviceId: 1,
      stageId: 1,
      stageIterationCount: 1,
    };
    await getAuthAccessWorflow(payloadFortrackitFP);
  } catch (err) {
    logger.info(`Failure in TrackitTriggerFP ${err}`);
  }
};

export const sendMail = async (reqData, data, resUrl, mailAction) => {
  try {
    logger.info('reqMailData', reqData);
    const { entityId, services, duId } = reqData;
    const { workorderid, customerid } = data;
    const payload = {
      entityId,
      workorderId: workorderid,
      serviceId: services,
      customerId: customerid,
      duId,
      wfeventId: null,
    };
    const serviceId = services;
    let msgSubject = '';
    let msgToProduction = '';
    let subMsgToProduction = '';
    if (mailAction == 'notify_collator') {
      msgSubject = 'Author corrections submitted ';
      msgToProduction =
        'author corrections have been submitted via the proof central and firstproof is completed.';
      subMsgToProduction =
        'Please create the ALP package creation stage and finish the collation using the PC link.';
    } else if (mailAction == 'pkg_error') {
      msgSubject = 'PC package validation FAILED ';
      msgToProduction =
        'PC package validation FAILED for the subjected article and enabled in XML correction activity.';
      subMsgToProduction = `Please clear the error and send the updated package to proofcentral. Error: ${resUrl}`;
    } else if (mailAction == 'cv_errForSkipApproval') {
      msgSubject = 'Content validation Error in ALP Package Creation';
      msgToProduction =
        'Query raised to get approval to skip the content validation error. Before you contact client, please get approval from technology xml team.';
      subMsgToProduction = `Query Description: ${resUrl}`;
      mailAction = 'notify_production';
    }
    if (mailAction == 'notify_collator' || mailAction == 'pkg_error') {
      mailAction = 'notify_production';
    }
    logger.info('mailAction', mailAction);
    logger.info('payloadMail', payload);
    const resForConfig = await getNotificationConfig(payload, mailAction);
    logger.info('notifyConfig1', resForConfig);
    if (resForConfig.length > 0) {
      const {
        workorderid: woid,
        type,
        notificationconfig,
        customername,
        duname,
        itemcode,
        services: ser,
        totalchaptercount,
        printisbn,
        totalarticlecount,
        totalnonarticlecount,
        wotype,
        jobtype,
        title,
        journalname,
        doinumber,
        journalacronym,
      } = resForConfig[0];
      let isTrigger = false;
      if (
        notificationconfig.jobTypes.length &&
        notificationconfig.jobTypes.includes(jobtype)
      ) {
        isTrigger = true;
      } else if (notificationconfig.jobTypes.length == 0) {
        isTrigger = true;
      }
      console.log(isTrigger, 'isTrigger');
      if (type === 'mail' && isTrigger) {
        const pmI = resForConfig.findIndex(
          val => val.contactrole === 'PM' && val.isprimary,
        );
        const spmI = resForConfig.findIndex(
          val => val.contactrole === 'SPM' && !val.isprimary,
        );
        const authorI = resForConfig.findIndex(
          val => val.contactrole === 'AUTHOR' && val.contacttype === 'Customer',
        );
        const mailObj = {};
        if (pmI != -1) {
          mailObj.toPm = resForConfig[pmI].contactemail;
        }
        if (spmI != -1) {
          mailObj.toSpm = resForConfig[spmI].contactemail;
        }
        if (authorI != -1) {
          mailObj.toAuthor = resForConfig[authorI].contactemail;
        }
        const fromArray = [];
        const toMailArray = [];
        const ccMailArray = [];
        const bccMailArray = [];
        if (Array.isArray(notificationconfig.from)) {
          notificationconfig.from.forEach(item => {
            if (mailObj[item]) {
              fromArray.push(mailObj[item]);
            } else {
              fromArray.push(item);
            }
          });
        } else {
          fromArray.push(notificationconfig.from);
        }
        notificationconfig.to.forEach(item => {
          if (mailObj[item]) {
            toMailArray.push(mailObj[item]);
          } else {
            toMailArray.push(item);
          }
        });
        notificationconfig.cc.forEach(item => {
          if (mailObj[item]) {
            ccMailArray.push(mailObj[item]);
          } else {
            ccMailArray.push(item);
          }
        });
        notificationconfig.bcc.forEach(item => {
          if (mailObj[item]) {
            bccMailArray.push(mailObj[item]);
          } else {
            bccMailArray.push(item);
          }
        });
        console.log(fromArray, 'fromArray');
        const payld = {
          actionType: type,
          date: moment(new Date()).format('DD-MM-YYYY'),
          correctionEndDate: moment(getRemainderDate()).format('DD MMMM YYYY'),
          maxDate: 5,
          workorderId: woid,
          noOfChapter: totalchaptercount,
          noOfArticle: totalarticlecount,
          noOfNonArticle: totalnonarticlecount,
          printIsbn: printisbn,
          woType: wotype,
          jobType: jobtype,
          service: ser,
          doiNumber: doinumber,
          jobId: itemcode,
          jobName: title,
          journalAcronym: journalacronym,
          journalName: journalname,
          customerName: customername,
          duName: duname,
          pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
          spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
          spmMail: spmI != -1 ? resForConfig[spmI].contactemail : '',
          authorName: authorI != -1 ? resForConfig[authorI].contactname : '',
          ...notificationconfig,
          from: fromArray,
          toMail: toMailArray,
          pcLink: resUrl,
          cc: ccMailArray,
          bcc: bccMailArray,
          tlName: 'TL',
          serviceId,
          mailType: 'general',
          messageSubject: msgSubject || '',
          messageToProduction: msgToProduction || '',
          subMessage: subMsgToProduction || '',
        };
        emitAction(payld);
      }
    }
  } catch (err) {
    logger.info(`Unable to send email ${err}`);
  }
};
const recordUploadInfo = async reqInfo => {
  const recordUploadPrms = new Promise((resolve, reject) => {
    try {
      const fvalues = [];
      fvalues.push(
        `('Integra', ${reqInfo.cusId} , '${reqInfo.fName}', '${
          reqInfo.fileType
        }', 'proofcentral IN','${
          reqInfo.fPath
        }',${null},${null},${null},${true},${null},${true},'${
          reqInfo && reqInfo.activityname ? reqInfo.activityname : null
        }','${reqInfo && reqInfo.stagename ? reqInfo.stagename : null}','${
          reqInfo.currDate
        }',${reqInfo.woId},${
          reqInfo && reqInfo.issuccess != undefined ? reqInfo.issuccess : null
        })`,
      );
      const sql = `INSERT INTO public.wms_ft_transaction_table(
        requestraisedfrom, customerid, filename, packagetype, requesttype, actionrole, nextactionifsuccess, nextactioniffails, transactionstatus, iscompleted, ft_status, isactive, activityname, stagename, createddate, woid,issuccess)
       VALUES  ${fvalues}`;
      query(sql)
        .then(() => {
          resolve();
          logger.info(`pc file-uploaded for ${reqInfo.fName}`);
        })
        .catch(e => {
          reject(e);
        });
    } catch (e) {
      logger.info(`unable insert the uploaded info ${e}`);
    }
  });
  return recordUploadPrms.catch(message => {
    console.log(`recordUploadPrms Failed: ${message}`);
  });
};

export const pkgUploadOpenKmToSftp = async (req, res) => {
  const fpathSrc = req.body ? req.body.fPath : ' ';
  const reqInfo = {
    fPath: fpathSrc,
    fileType: req.body ? req.body.fileType : 'zip',
    woId: req.body ? Number(req.body.woId) : 0,
    cusId: req.body ? Number(req.body.cusId) : 0,
    currDate: new Date().toISOString(),
    fName: fpathSrc.toString().split('/').pop(),
    confValue:
      req.body && req.body.confValue ? req.body.confValue : 'pc_sftp_conf',
    uploadAction: !!(
      req.body.uploadAction && req.body.uploadAction == 'package_zip_upload'
    ),
    stagename: req.body && req.body.stageName ? req.body.stageName : '',
    activityname:
      req.body && req.body.activityName ? req.body.activityName : '',
  };

  try {
    const dmsType = await getdmsType(req.body.woId);
    let fileSrc = '';
    if (!reqInfo.uploadAction) {
      await recordUploadInfo(reqInfo);
    }
    switch (dmsType) {
      case 'azure':
        const out = await azureHelper._download(reqInfo.fPath);
        fileSrc = out.data.path;
        break;
      case 'local':
        const out1 = await azureHelper._localdownload(reqInfo.fPath);
        fileSrc = out1.data.path;
        break;
      default:
        const pc_infileuuid = await _getUuid(reqInfo.fPath);
        fileSrc =
          config.openKM.base_url + config.openKM.uri.viewFile + pc_infileuuid;
        break;
    }
    const sftpConfig = await getsftpConfig(reqInfo.confValue);
    const sftDest =
      sftpConfig && sftpConfig.folders ? sftpConfig.folders[0] : '/IN/';
    const checkCount = `select count(*) from wms_ft_transaction_table where woid =${reqInfo.woId} and activityname = '${reqInfo.activityname}'
      and stagename = '${reqInfo.stagename}' and issuccess =true`;
    const validationCount = await query(checkCount);
    let uploadResp = 'Upload Process started';
    if (
      (validationCount[0].count == 0 && reqInfo.uploadAction) ||
      !reqInfo.uploadAction
    ) {
      uploadResp = await uploadFileToSFTP(
        fileSrc,
        sftpConfig,
        sftDest,
        reqInfo.fName,
      );
    }
    if (uploadResp && validationCount[0].count == 0 && reqInfo.uploadAction) {
      reqInfo.issuccess = true;
      await recordUploadInfo(reqInfo);
    } else if (reqInfo.uploadAction) {
      uploadResp = 'Zip package already uploaded';
      logger.info('zip package already uploaded');
    }

    res.send({ isSuccess: true, data: uploadResp });
  } catch (err) {
    if (reqInfo.uploadAction) {
      reqInfo.issuccess = false;
      await recordUploadInfo(reqInfo);
    }
    res.send({ isSuccess: false, message: err.message });
    logger.info(`Unable call upload fn ${err}`);
  }
};
// -----------SFTP file watcher start----------- //
(async () => {
  try {
    const sftpWatcherConfig = await getsftpConfig('pc_sftp_watcher_conf');
    if (sftpWatcherConfig != 'inactive') {
      try {
        // eslint-disable-next-line new-cap
        const objRemoteFileWatcher = new remoteFileWatcher(
          'my_server_proofcentral',
          sftpWatcherConfig,
        );
        objRemoteFileWatcher.on('uploading', function (objFile) {
          console.log('FILE UPLOADING:');
          console.log(objFile);
        });
        objRemoteFileWatcher.on('uploaded', function (objFile) {
          console.log('FILE UPLOADED:');
          console.log(objFile);
          const fPath = `${objFile.folder}/${objFile.fileName}`;
          const currFileName = objFile.fileName;
          currFileName.replace('.filepart', '');
          signalReceiverFromSftp(currFileName, fPath);
        });
        objRemoteFileWatcher.on('error', function (strServername, error) {
          console.log(`ERROR: ${strServername}`);
          logger.info(`unable to connect SFTP ${error}`);
        });
      } catch (e) {
        logger.info(`unable to connect SFTP ${e}`);
      }
    }
  } catch (err) {
    logger.info(`connection closed err: ${err}`);
  }
})();
// -----------SFTP file watcher end----------- //
