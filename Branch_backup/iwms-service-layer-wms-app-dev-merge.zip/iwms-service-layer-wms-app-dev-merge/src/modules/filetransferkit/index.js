import Client from 'ssh2-sftp-client';
import request from 'request';
import fs, { promises, statSync, mkdirSync } from 'fs';
import path from 'path';
import JSZip from 'jszip';
// eslint-disable-next-line import/no-extraneous-dependencies
import * as _ftp from 'ftp';
import * as ftp from 'basic-ftp';
import logger from '../utils/logs/index.js';
import { query } from '../../database/postgres.js';

export const checkDirectorySync = directory => {
  try {
    statSync(directory);
  } catch (e) {
    mkdirSync(directory, { recursive: true });
  }
};

export const extractZip = filePath => {
  return new Promise(async (resolve, reject) => {
    try {
      const _path = path.dirname(filePath);
      fs.readFile(filePath, function (err, data) {
        if (!err) {
          // const zip = new JSZip();
          JSZip.loadAsync(data)
            .then(async function (zip) {
              for (let i = 0; i < Object.keys(zip.files).length; i++) {
                const filename = Object.keys(zip.files)[i];
                const dest = path.join(_path, filename);
                if (zip.files[filename].dir == true) {
                  checkDirectorySync(dest);
                } else {
                  checkDirectorySync(path.dirname(dest));
                  await zip
                    .file(filename)
                    .async('nodebuffer')
                    .then(function (content) {
                      fs.writeFileSync(dest, content);
                      if (filename.includes('.xhtml')) {
                        if (
                          content.toString().includes(global.failurePatternCV)
                        ) {
                          global.isContentValidationStatus = true;
                        } else if (
                          content.toString().includes(global.successPatternCV)
                        ) {
                          global.isContentValidationStatus = false;
                        }
                      }
                    })
                    .catch(error => {
                      reject(error);
                    });
                }
              }
              resolve(true);
            })
            .catch(e => {
              reject(e);
            });
        }
      });
    } catch (error) {
      reject(error);
    }
  });
};

export const getFilefromSFTPToDestPath = async (
  sftpConfig,
  remotePath,
  localPath,
) => {
  return new Promise(async (resolve, reject) => {
    const sftp = new Client();
    try {
      await sftp.connect(sftpConfig);
      await sftp.fastGet(remotePath, localPath);
      resolve(localPath);
    } catch (e) {
      logger.info(`unable to get file from SFTP ${e}`);
      reject(e);
    } finally {
      await sftp.end();
    }
  });
};

export const getFilefromSFTP = async (sftpConfig, fPath) => {
  const getPcFilePrms = new Promise(async (resolve, reject) => {
    try {
      if (sftpConfig != 'inactive') {
        const sftp = new Client();
        await sftp.connect(sftpConfig).then(() => {
          sftp
            .get(fPath)
            .then(fileContent => {
              resolve(fileContent);
            })
            .then(() => {
              sftp.end();
            })
            .catch(() =>
              reject({ uploaded: false, message: 'error in get file' }),
            );
        });
      } else {
        reject({ uploaded: false, message: 'sftpConfig is inactive.' });
      }
    } catch (e) {
      logger.info(`unable to get file from SFTP ${e}`);
      reject(e);
    }
  });
  return getPcFilePrms.catch(message => {
    console.log(`getPcFilePrms Failed: ${message}`);
  });
};

const uploadBlobToSFTP = async (fileUrl, ftpPath, sftpConfig) => {
  return new Promise(async (resolve, reject) => {
    const sftp = new Client();
    try {
      await sftp.connect(sftpConfig);
      const stream = request(fileUrl).pipe(sftp.createWriteStream(ftpPath));
      await new Promise((res, rej) => {
        stream.on('close', () => {
          res();
        });
        stream.on('error', () => {
          rej();
        });
      });
      resolve('File uploaded successfully!');
    } catch (error) {
      reject('Error occurred during file upload:', error);
    } finally {
      await sftp.end();
    }
  });
};

export const uploadFileToSFTP = async (
  fileSrc,
  sftpConfig,
  targetpath,
  fName,
) => {
  const pcUploadPrms = new Promise(async (resolve, reject) => {
    try {
      if (sftpConfig != 'inactive') {
        await uploadBlobToSFTP(fileSrc, `/${targetpath}/${fName}`, sftpConfig)
          .catch(() => {
            reject({ uploaded: false, msg: 'error in file upload' });
          })
          .finally(() => {
            resolve({
              uploaded: true,
              msg: 'file uploaded successfully',
            });
          });
      } else {
        reject({ uploaded: false, msg: 'inactive.' });
      }
    } catch (err) {
      logger.info(`error in sftp connect and upload ${err}`);
      reject({ uploaded: false, msg: `err in file upload${err}` });
    }
  });
  return pcUploadPrms.catch(message => {
    console.log(`pcUploadPrms: ${message}`);
  });
};

export const makeDir = async pth => {
  console.log(pth);
  if (!fs.existsSync(pth)) {
    return promises.mkdir(pth);
  }
  return true;
};
export const writeOutPkgFile = async (filepath, content, dirpath) => {
  const wrtOutPkgPrms = new Promise(async (resolve, reject) => {
    try {
      console.log(dirpath);
      const fileSize = Buffer.byteLength(content);
      const fileSizeInKB = fileSize / 35000;
      if (fileSizeInKB < 35000) {
        const fileContent = await promises.writeFile(filepath, content);
        resolve(fileContent);
      } else {
        reject(`File exceeds maximum limit (max - 35MB)`);
      }
    } catch (err) {
      reject(err);
    }
  });
  return wrtOutPkgPrms.catch(message => {
    console.log(`wrtOutPkgPrms Failed: ${message}`);
  });
};

export const getsftpConfig = async (confName, type = '', woId = '') => {
  const getFtpConfPrms = new Promise((resolve, reject) => {
    let sql = '';
    if (type) {
      sql = `SELECT  confvalue FROM public.wms_mst_configurationdetails  where customerid = ${confName} and type= '${type}' 
      and countryid= (select countryid from wms_workorder where workorderid=${woId}) and flowtype='OUT' and isactive=true `;
    } else {
      sql = `SELECT  confvalue FROM public.wms_mst_configurationdetails  where confname = '${confName}' and isactive=true`;
    }
    query(sql)
      .then(res => {
        if (res.length > 0) {
          const a = res.pop().confvalue;
          resolve(JSON.parse(a));
        } else {
          resolve('inactive');
        }
      })
      .catch(error => {
        console.log(error, 'error for ftp conf details');
        reject(error);
      });
  });
  return getFtpConfPrms.catch(message => {
    console.log(`getFtpConfPrms Failed: ${message}`);
  });
};

export const invokeFileUploadToFTP = async (configKey, srcInfo, targetInfo) => {
  const ftpConfig = await getsftpConfig(configKey);
  return new Promise(async (resolve, reject) => {
    // eslint-disable-next-line new-cap
    const client = new _ftp.default();
    client.passive = true;
    client.connect(ftpConfig.config);
    client.on('ready', () => {
      console.log('Connected to FTP server');
      client.list(ftpConfig.targetpathForExcel, (err, list) => {
        if (err) {
          client.end();
          reject('Ftp get list upload failed');
        } else {
          if (
            list.filter(
              x => x.name.toLowerCase() === targetInfo.filename.toLowerCase(),
            ).length > 0
          ) {
            client.delete(
              ftpConfig.targetpathForExcel + targetInfo.filename,
              deleteErr => {
                if (deleteErr) {
                  client.end();
                  reject('Already xl file delete failed');
                }
              },
            );
          }
          client.put(
            srcInfo.path,
            ftpConfig.targetpathForExcel + targetInfo.filename,
            err1 => {
              if (err1) {
                client.end();
                reject('Error uploading file:', err1);
              } else {
                client.size(
                  ftpConfig.targetpathForExcel + targetInfo.filename,
                  (error, size) => {
                    if (error) {
                      client.end();
                      reject('Error occurred, file does not exist');
                    } else if (size < 1) {
                      client.end();
                      reject('file is empty');
                    } else {
                      client.end();
                      resolve('File uploaded successfully');
                    }
                  },
                );
              }
            },
          );
        }
      });

      client.on('error', err => {
        reject('FTP connection error:', err);
      });
    });
  });
};

export const invokeFtpFileUpload = async (configKey, srcInfo, targetInfo) => {
  const ftpConfig = await getsftpConfig(configKey);
  return new Promise(async (resolve, reject) => {
    const client = new ftp.Client();
    client.ftp.verbose = true;
    try {
      await client.access(ftpConfig.config);
      const uploadRes = await client.uploadFrom(
        srcInfo.path,
        ftpConfig.targetpathForExcel + targetInfo.filename,
      );
      resolve(uploadRes);
    } catch (err) {
      console.log(err);
      reject(err);
    }
    client.close();
  });
};
