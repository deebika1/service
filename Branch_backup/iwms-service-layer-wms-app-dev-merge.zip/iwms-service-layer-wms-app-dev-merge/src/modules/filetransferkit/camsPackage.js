import { dirname, basename } from 'path';
import { query } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import { _upload } from '../utils/azure/index.js';
import { _uploadlocal } from '../utils/local/index.js';
import { uploadFiletoOpenKM } from '../utils/okm/index.js';

import { getdmsType } from '../bpmn/listener/create.js';

export const uploadCamsPackage = async (req, res) => {
  const { piid, issueFilename } = req.body;
  try {
    let sql1;
    if (issueFilename) {
      sql1 = `select v.otherfield ::jsonb->> 'pii' as piino,c1.woincomingfileid, f1.stageid,
       g1.stagename,h1.serviceid, h1.servicename ,v.customerid ,i1.customername,v.workorderid,
       e1.assignedduid as duid,l1.duname
       from wms_workorder as v
       join public.wms_workorder_incoming as b1 on b1.woid=v.workorderid
       join public.wms_workorder_incomingfiledetails as c1 on c1.woincomingid=b1.woincomingid
       --left join public.wms_workflow_details as d1 on d1.workorderid= v.workorderid
       join wms_workorder_service as e1 on e1.workorderid = v.workorderid
       join wms_workflowdefinition as f1 on f1.wfid = e1.wfid
       join wms_mst_stage as g1 on g1.stageid = f1.stageid
       join wms_mst_service as h1 on h1.serviceid = e1.serviceid
       join org_mst_customer as i1 on i1.customerid = v.customerid
       join org_mst_deliveryunit as l1 on l1.duid=e1.assignedduid
       where v.isactive=true and lower(v.itemcode) = lower('${issueFilename}')
       order by f1.sequence asc limit 1`;
    } else {
      sql1 = `select v.otherfield ::jsonb->> 'pii' as piino,c1.woincomingfileid, f1.stageid,
      g1.stagename,h1.serviceid, h1.servicename ,v.customerid ,i1.customername,v.workorderid,
      e1.assignedduid as duid,l1.duname
      from wms_workorder as v
      join public.wms_workorder_incoming as b1 on b1.woid=v.workorderid
      join public.wms_workorder_incomingfiledetails as c1 on c1.woincomingid=b1.woincomingid
      --left join public.wms_workflow_details as d1 on d1.workorderid= v.workorderid
      join wms_workorder_service as e1 on e1.workorderid = v.workorderid
      join wms_workflowdefinition as f1 on f1.wfid = e1.wfid
      join wms_mst_stage as g1 on g1.stageid = f1.stageid
      join wms_mst_service as h1 on h1.serviceid = e1.serviceid
      join org_mst_customer as i1 on i1.customerid = v.customerid
      join org_mst_deliveryunit as l1 on l1.duid=e1.assignedduid
      where v.isactive=true and v.otherfield ::jsonb->> 'pii' ='${piid}'
      order by f1.sequence asc limit 1`;
    }

    const result = await query(sql1, []);
    const sql2 = `;with cte as(
      SELECT a1.wfeventid,b.repofilepath,a1.activitystatus  FROM public.wms_workflow_eventlog as  a1
        left join public.wms_workflowactivitytrn_file_map as b on b.wfeventid = a1.wfeventid
        where workorderid = ${result[0].workorderid} and wfdefid=596 order by a1.wfeventid desc limit 1) 
      select wfeventid, repofilepath from cte where activitystatus not in ('Reset')`;
    const camsActivityCreated = await query(sql2, []);
    const dmsType = await getdmsType(result[0].workorderid);
    if (camsActivityCreated.length !== 0) {
      const dir = dirname(camsActivityCreated[0].repofilepath);
      const inId = basename(dir);
      const okmPath = `${dir}/${req.files.zip.name}`;
      let uploadCamsPackageActivity;
      switch (dmsType) {
        case 'azure':
          uploadCamsPackageActivity = await _upload(req.files.zip, okmPath);
          break;
        case 'local':
          uploadCamsPackageActivity = await _uploadlocal(
            req.files.zip,
            okmPath,
          );
          break;
        default:
          uploadCamsPackageActivity = await uploadFiletoOpenKM(
            req,
            okmPath,
            'zip',
          );
          break;
      }
      console.log(uploadCamsPackageActivity);
      const sql3 = `INSERT INTO public.wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES( ${camsActivityCreated[0].wfeventid}, '${uploadCamsPackageActivity.uuid}', '${uploadCamsPackageActivity.okmPath}', false, true, ${inId})`;
      console.log(sql3, 'sql for file path entry');
      await query(sql3);
    } else {
      const camsPath = await getCamsFolderPath(result[0]);
      switch (dmsType) {
        case 'azure':
          await _upload(req.files.zip, camsPath);
          break;
        case 'local':
          await _uploadlocal(req.files.zip, camsPath);
          break;
        default:
          await uploadFiletoOpenKM(req, camsPath, 'zip');
          break;
      }
    }
    res.status(200).send({
      issuccess: true,
      message: 'success',
    });
  } catch (e) {
    logger.info(e, 'error in cams package upload');
    res.status(400).send({
      issuccess: false,
      message: e.message ? e.message : e,
    });
  }
};

export const getCamsFolderPath = async result => {
  return new Promise(async (resolve, reject) => {
    try {
      const getCamsFolderPath1 = await getFolderStructure({
        type: 'wo_incoming_file_subtype',
        workOrderId: result.workorderid,
        du: {
          name: result.duname,
          id: result.duid,
        },
        customer: {
          name: result.customername,
          id: result.customerid,
        },
        stage: {
          name: result.stagename,
          id: result.stageid,
          iteration: 1,
        },
        service: {
          name: result.servicename,
          id: result.serviceid,
        },
        fileType: {
          name: 'article',
          id: '4',
          fileId: result.woincomingfileid,
        },
      });
      resolve(getCamsFolderPath1);
    } catch (e) {
      logger.info(e, 'error in cams package upload');
      reject({ message: e.message ? e.message : e });
    }
  });
};
