import pdfjsLib from 'pdfjs-dist/legacy/build/pdf.js';
import axios from 'axios';
// import PDFJSWorker from 'pdfjs-dist/legacy/build/pdf.worker.entry.js'
import getDocumentProperties from 'custom-office-document-properties';
import fs from 'fs';
import { join } from 'path';
import { config } from '../../config/restApi.js';
import { query } from '../../database/postgres.js';
import { Service } from '../../httpClient/index.js';
import logger from '../utils/logs/index.js';
import { getdmsType } from '../bpmn/listener/create.js';
import * as azureHelper from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';

const service = new Service();
export const getTotalPageNum = async (req, res) => {
  try {
    logger.info('inside get total page number', req.body);
    const {
      isTypeset,
      workorderId,
      stageId,
      iterationCount,
      path,
      woIncomingFileId,
    } = req.body;
    const dmsType = await getdmsType(workorderId);
    let file = {};
    switch (dmsType) {
      case 'azure':
        const out = await azureHelper._download(path);
        file = out.data.path;
        break;
      case 'local':
        const out1 = await localHelper._localdownload(path);
        file = out1.data.path;
        break;
      default:
        file =
          config.openKM.base_url + config.openKM.uri.viewFile + req.body.fileId;
        break;
    }
    logger.info(file, 'file name of reading');
    const { fileId } = req.body;
    const fileType = req.body.type;
    if (fileType.toLowerCase() === 'pdf') {
      console.log(file, 'fileelel');
      const loadingTask = pdfjsLib.getDocument(file);
      let count = 0;
      loadingTask.promise
        .then(async pdf => {
          logger.info('PDF loaded', pdf.numPages);
          count = pdf.numPages;
          if (count) {
            logger.info('inside typeset', count);
            // to be deleted
            // if (isTypeset)
            //   await addTypesetPage({
            //     workorderId,
            //     stageId,
            //     iterationCount,
            //     count,
            //     woIncomingFileId,
            //   });
            res.status(200).send({ count });
          } else {
            throw new Error('Page count not found');
          }
        })
        .catch(e => {
          logger.info(e);
          res.status(400).send({ ErrorMessage: e.message ? e.message : e });
        });
    } else if (fileType.toLowerCase() === 'word') {
      await getcount(file)
        .then(async data => {
          let pageCount = 0;
          pageCount = data && (data > 240 ? Math.ceil(data / 240) : 1);
          logger.info(pageCount, 'pageCount');
          if (pageCount) {
            logger.info('inside typeset');
            if (isTypeset)
              await addTypesetPage({
                workorderId,
                stageId,
                iterationCount,
                count: pageCount,
                woIncomingFileId,
              });
            res.status(200).send({ count: pageCount });
          } else {
            throw new Error('Word count not found');
          }
        })
        .catch(e => {
          logger.info(e);
          res.status(400).send({ ErrorMessage: e.message ? e.message : e });
        });
    } else if (fileType.toLowerCase() === 'xml') {
      await getFileSize(fileId, path, dmsType)
        .then(async fileSize => {
          logger.info(fileSize, 'data for file size');
          if (fileSize) {
            logger.info('inside typeset');
            // to be deleted
            // if (isTypeset)
            //   await addTypesetPage({
            //     workorderId,
            //     stageId,
            //     iterationCount,
            //     count: fileSize,
            //     woIncomingFileId,
            //   });
            res.status(200).send({ count: fileSize });
          } else {
            throw new Error('File size not found');
          }
        })
        .catch(e => {
          logger.info(e);
          res.status(400).send({ ErrorMessage: e.message ? e.message : e });
        });
    }
  } catch (error) {
    res.status(400).send({ ErrorMessage: error });
  }
};
export const updatePgNumFromPginfo = async (req, res) => {
  try {
    logger.info('inside get total page number', req.body);
    const { workorderId, stageId, iterationCount, count, woIncomingFileId } =
      req.body;
    console.log('inside typeset');
    await addTypesetPage({
      workorderId,
      stageId,
      iterationCount,
      count,
      woIncomingFileId,
    });
    res.status(200).send({ count, issuccess: true });
  } catch (e) {
    logger.info(e);
    res.status(400).send({ ErrorMessage: e, issuccess: false });
  }
};

export const getcount = path => {
  console.log(path, 'dataforgetcount');
  return new Promise((resolve, reject) => {
    const ts = Date.now();
    const incomingFile = path;
    const uniquefileName = `${random() + Math.floor(ts / 1000)}.docx`;
    const tempFileUploadPath = 'tempFolder/';
    const filePath = `tempFolder/${uniquefileName}`;
    if (!fs.existsSync(tempFileUploadPath)) {
      fs.mkdirSync(tempFileUploadPath);
    }
    downloadFile(incomingFile, filePath).then(async data => {
      logger.info(data);
      if (data) {
        getDocumentProperties.fromFilePath(filePath, function (err, value) {
          if (err) reject(err);
          logger.info('word details', value);
          fs.unlink(filePath, function (error) {
            if (error) reject(error);
            logger.info('File deleted!');
            resolve(value ? value.words : value);
          });
        });
      }
    });
  });
};

export const getFileSize = async (uuid, file, dmsType) => {
  console.log(uuid, 'uuidforfile');
  return new Promise(async (resolve, reject) => {
    try {
      let result = 0;
      let fileObj;
      switch (dmsType) {
        case 'azure':
          fileObj = await service.get(
            `${config.blob_rest.base_url}${config.blob_rest.uri.getProperties}?docId=${file}`,
            {},
            {},
          );
          result = fileObj.data.contentLength;
          break;
        case 'local':
          fileObj = await service.get(
            `${config.local_rest.base_url}${config.local_rest.uri.getlocalProperties}?docId=${file}`,
            {},
            {},
          );
          result = fileObj.data.contentLength;
          break;
        default:
          const headers = {
            Authorization: `Basic ${process.env.OKM_AUTH}`,
          };
          fileObj = await service.get(
            `${
              config.openKM.base_url + config.openKM.uri.getFileDetails
            }?fileId=${uuid}`,
            {},
            headers,
          );
          console.log(fileObj.data.actualVersion.size, 'fileSize');
          result = fileObj.data.actualVersion.size
            ? parseInt(fileObj.data.actualVersion.size)
            : 0;
          break;
      }
      const fileInKb = result / 1000;
      const fileInPage = fileInKb > 6.92 ? Math.ceil(fileInKb / 6.92) : 1;
      console.log(fileInKb, fileInPage, 'sizeparammerteres');
      resolve(fileInPage);
    } catch (error) {
      console.log(error, 'error for file size');
      reject(error);
    }
  });
};
const random = (length = 8) => {
  return Math.random().toString(16).substr(2, length);
};
export async function downloadFile(fileUrl, outputLocationPath) {
  const writer = fs.createWriteStream(outputLocationPath);
  return axios({
    method: 'get',
    url: fileUrl,
    responseType: 'stream',
  }).then(response => {
    return new Promise((resolve, reject) => {
      response.data.pipe(writer);
      let error = null;
      writer.on('error', err => {
        error = err;
        writer.close();
        reject(err);
      });
      writer.on('close', () => {
        if (!error) {
          resolve(true);
        }
      });
    });
  });
}

// this function will add the typeset page of corresponding stage
const addTypesetPage = payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderId, stageId, iterationCount, count, woIncomingFileId } =
        payload;
      let sql = `UPDATE public.wms_workorder_stage SET typesetpages=${count}
            WHERE workorderid=${workorderId} AND wfstageid = ${stageId} AND stageiterationcount = ${iterationCount} `;
      logger.info(sql, 'sql for typeset page on stage wise');
      await query(sql);
      sql = `UPDATE public.wms_workorder_incomingfiledetails SET typesetpage=${count}
            WHERE woincomingfileid=${woIncomingFileId}`;
      logger.info(sql, 'sql for typeset page on chapter wise');
      await query(sql);
      resolve(true);
    } catch (e) {
      logger.info(e);
      reject(e);
    }
  });
};

export const readFileInfo = async (req, res) => {
  try {
    const sql = `select distinct on (filename,wms_workorder.workorderid) wms_workorder.workorderid,itemcode,filename,repofilepath,wms_workflowactivitytrn_file_map.woincomingfileid from public.wms_workorder
        join wms_workorder_incoming on wms_workorder_incoming.woid = wms_workorder.workorderid
        join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
        join wms_workflowactivitytrn_file_map on wms_workflowactivitytrn_file_map.woincomingfileid = wms_workorder_incomingfiledetails.woincomingfileid
        join wms_workflow_eventlog on wms_workflow_eventlog.wfeventid = wms_workflowactivitytrn_file_map.wfeventid
        where wotype ='Book' and wfdefid=237 and wms_workorder.isactive=true and repofilepath like '%.pag'  order by filename, wms_workorder.workorderid asc limit 1
        `;
    console.log(sql, 'sql for typeset page on stage');
    const files = await query(sql);
    const fileContainer = [];
    for (let i = 0; i < files.length; i++) {
      fs.readdirSync(files[i].repofilepath).forEach(async File => {
        let TotalPagNum;
        if (File.includes('.pag')) {
          const fileContent = fs.readFileSync(
            join(files[i].repofilepath, File),
            { encoding: 'utf8' },
          );
          const regex = /(?<=<total>).*?(?=<\/total>)/gm;
          let m;
          // eslint-disable-next-line no-cond-assign
          while ((m = regex.exec(fileContent)) !== null) {
            // This is necessary to avoid infinite loops with zero-width matches
            if (m.index === regex.lastIndex) {
              regex.lastIndex++;
            } // The result can be accessed through the `m`-variable.
            m.forEach((match, groupIndex) => {
              console.log(`Found match, group ${groupIndex}: ${match}`);
              TotalPagNum = match;
            });
          }
        }

        fileContainer.push({ job: files[i].itemcode, total: TotalPagNum });
      });
    }
    res.status(200).send(fileContainer);
  } catch (error) {
    res.status(400).send(error);
  }
};
