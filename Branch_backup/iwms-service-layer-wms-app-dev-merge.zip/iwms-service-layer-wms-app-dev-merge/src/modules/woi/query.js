import { query } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';
import { sendMail } from '../filetransferkit/proofcentral.js';

export const getQueryBuilderOptions = (req, res) => {
  const getData = req.body;
  let sql = '';

  /*
    SELECT stagelist.stagename||'('||stagelist.stageiterationcount||')' as stagename,stagelist.wostageid,stagelist.status,stagelist.wfstageid,stagelist.serviceid,stagelist.servicename, wms_workorder_service.wfid, wms_workflow.wfname, wms_workflow.wfcategory FROM public.wms_wo_stagelist stagelist
        join wms_workorder_service on wms_workorder_service.serviceid = stagelist.serviceid and 
	  wms_workorder_service.workorderid = stagelist.workorderid
        join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
        WHERE stagelist.workorderid=${woId} order by stagelist.wfstageid
        */
  if (getData.type === 'service') {
    sql = `SELECT DISTINCT ON (stagelist.serviceid) stagelist.serviceid as value,stagelist.servicename as label FROM public.wms_wo_stagelist stagelist
        join wms_workorder_service on wms_workorder_service.serviceid = stagelist.serviceid and 
	  wms_workorder_service.workorderid = stagelist.workorderid
        WHERE stagelist.workorderid=${getData.woId}`;
  } else if (getData.type === 'stage') {
    sql = `SELECT DISTINCT ON (stagelist.wfstageid) (concat(stagelist.stagename, ' (', stagelist.stageiterationcount, ')')) as label,stagelist.wfstageid as value,stagelist.stageiterationcount FROM public.wms_wo_stagelist stagelist
        join wms_workorder_service on wms_workorder_service.serviceid = stagelist.serviceid and 
	  wms_workorder_service.workorderid = stagelist.workorderid
        join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
        WHERE stagelist.workorderid=${getData.woId}`;
    // sql = `SELECT DISTINCT ON( stage.stageid) stage.stageid as value, (concat(stage.stagename, ' (', eventlog.stageiterationcount, ')')) as label FROM public.wms_workflow_eventlog as eventlog
    // join wms_workflowdefinition as wfdef on wfdef.wfdefid = eventlog.wfdefid
    // join wms_mst_stage as stage on stage.stageid = wfdef.stageid
    // where eventlog.workorderid = ${getData.woId}`
  } else if (getData.type === 'classification') {
    sql = `select queryclassificationid as value, classificationname as label from wms_mst_query_classification`;
  } else if (getData.type === 'assignTo') {
    sql = `SELECT  skillid as value, skillname as label FROM public.wms_mst_skill`;
  } else if (getData.type === 'status') {
    sql = `SELECT  status as label, querystatusid as value FROM public.wms_mst_query_status`;
  }
  console.log(sql, 'sqlforToolOption');
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getQueryListforDespatch = async (req, res) => {
  const reqData = req.body;
  try {
    let sql = '';
    sql = `SELECT * FROM wms_workorder_query_list as list
        WHERE list.workorderid = ${reqData.woId} `;
    const response = await query(sql);
    res.status(200).send({ data: response, status: true });
  } catch (e) {
    console.log(e);
    res.status(400).send({ message: e, data: [], status: false });
  }
};

export const getLastActivityForQueryCheck = async (req, res) => {
  const reqData = req.body;
  try {
    let sql = '';
    sql = `SELECT * FROM wms_workflowdefinition as workflow
        WHERE workflow.wfid = ${reqData.wfId}  and workflow.stageid = ${reqData.stageId} order by sequence`;
    const response = await query(sql);
    let completiontrigger = false;

    const fileterddata = response.filter(list => list.activityid == 21);
    completiontrigger = fileterddata.length > 0;
    let lastActivity = '';
    if (completiontrigger) {
      lastActivity = response[response.length - 2].wfdefid;
    } else {
      lastActivity = response[response.length - 1].wfdefid;
    }
    res.status(200).send({ data: lastActivity, status: true });
  } catch (e) {
    console.log(e);
    res.status(400).send({ message: e, data: [], status: false });
  }
};

export const queryInsertion = (req, res) => {
  const getData = req.body;
  const list = getData.queryList;
  console.log(getData, 'getdataaaa');
  let sql = '';
  const val = [];
  const val1 = [];
  if (getData.type == 'Workorder') {
    val.push(
      `(${list.du},${list.woId},${list.service},${list.stage},${
        list.stageItertaion
      },${list.activityId ? list.activityId : 'null'},${
        list.activityIteration ? list.activityIteration : 'null'
      },${list.fileName ? `'${list.fileName} '` : 'null'},${
        list.classification
      },1,'${list.createdBy}',current_timestamp,null,'${list.subject}',${
        list.wfeventid ? list.wfeventid : 'null'
      })`,
    );
  }
  console.log(val, 'vallllalauee');
  sql = `INSERT INTO public.wms_query( duid, workorderid, serviceid, stageid, stageiterationcount, activityid, activityiterationcount, filename, classificationid, querystatusid, createdby, createdon, updatedon, subject,wfeventid)
    VALUES ${val} RETURNING queryid;`;
  console.log(sql, 'insertforquery');
  query(sql)
    .then(data => {
      const dataobj = {};
      dataobj.queryid = data[0].queryid;
      dataobj.message = 'Query Inserted Successfully';
      val1.push(
        `(${data[0].queryid},'${list.description}',1,'${list.createdBy}',current_timestamp)`,
      );
      console.log(val1, 'val11');
      const insertHistory = `INSERT INTO public.wms_query_history(queryid, description, querystatusid, createdby, createdon)
            VALUES ${val1} RETURNING queryhistoryid;`;
      console.log(insertHistory, 'insertHistoryinsertHistory');
      query(insertHistory)
        .then(async response => {
          dataobj.queryhistoryid = response[0].queryhistoryid;
          const val2 = [];
          list.assignTo.forEach(assig => {
            val2.push(`(${data[0].queryid},${assig})`);
          });
          sql = `INSERT INTO public.wms_query_assigned(queryid, skillid)
            VALUES ${val2}`;
          await query(sql)
            .then(() => {
              res.status(200).json({ data: dataobj, status: true });
            })
            .catch(error => {
              res.status(400).send({ message: error, status: false, data: [] });
            });
          if (
            list.classification == '4' &&
            list.du == '5' &&
            list.activityId == '30'
          ) {
            const reqMailData = {
              duId: Number(list.du),
              entityId: 60,
              services: `${list.service}`,
            };
            const wfconfdata = {
              workorderid: Number(list.woId),
              wfid: list.wfeventid,
              customerid: 6,
            };
            sendMail(
              reqMailData,
              wfconfdata,
              `${list.description}`,
              'cv_errForSkipApproval',
            );
          }
          // list.assignTo.map((data1) => {
          //     let insertskill = `INSERT INTO public.wms_query_assigned(queryid, skillid)
          //         VALUES (${data[0].queryid},${data1})`
          //     console.log(insertskill, "insertskill")
          //     query(insertskill).then((response1) => {
          //     })
          //     res.status(200).json({ data: dataobj, status: true });
          // }).catch((error) => {
          //     res.status(400).send({ message: error, status: false, data: [] });
          // });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const queryFile = (req, res) => {
  const { queryhistoryid, path, repofileuuid } = req.body;
  const sql = `INSERT INTO public.wms_query_files(
        queryhistoryid, filepath, fileuuid)
       VALUES ( ${queryhistoryid}, '${path}', '${repofileuuid}')`;
  console.log(sql, 'insertingfile');
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ data: 'Query Inserted Successfully', status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getQueryList = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
    sql = `SELECT COUNT(*) FROM wms_workorder_query_list as list
        WHERE list.workorderid = ${reqData.woId} ${
      condition ? `AND${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM wms_workorder_query_list as list
        WHERE list.workorderid = ${reqData.woId} ${
      condition ? `AND${condition}` : condition
    }`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sql1 = `SELECT * FROM wms_workorder_query_list as list
             WHERE list.workorderid = ${reqData.woId} ${
          condition ? `AND${condition}` : condition
        } LIMIT ${recordPerPage} OFFSET ${offset}`;
        console.log(sql1, 'sqlforquerryy');
        query(sql1)
          .then(data => {
            logger.info('activity', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ status: false, data: [] });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getQueryHistory = async (req, res) => {
  console.log('Req data for get query history');
  const reqData = req.body;
  let sql = `select status.status,concat(users.username, ' (', wms_query.createdby, ')') AS raisedby,wms_query.* from wms_query join wms_mst_query_status status on status.querystatusid=wms_query.querystatusid LEFT
    JOIN wms_user users ON users.userid::text = wms_query.createdby::text where queryid=${reqData.queryId}`;
  const finalData = {};
  await query(sql)
    .then(async queryData => {
      finalData.queryData = queryData;
      if (queryData.length) {
        sql = `select status.status,wms_query_history.*,concat(users.username, ' (', wms_query_history.createdby, ')') AS raisedby from wms_query_history join wms_mst_query_status status on status.querystatusid=wms_query_history.querystatusid
            left JOIN wms_user users ON users.userid::text = wms_query_history.createdby::text where queryid=${reqData.queryId}  order by wms_query_history.createdon asc`;
        await query(sql)
          .then(async historyData => {
            historyData.map(async (hd, index) => {
              sql = `select * from wms_query_files where queryhistoryid=${hd.queryhistoryid}`;
              console.log('yuvaraj', sql);
              await query(sql).then(fileData => {
                hd.file = fileData;
              });
              if (historyData.length - 1 === index) {
                finalData.historyData = historyData;
                sql = `select skill.skillname as label,skill.skillid as value,assigned.* from wms_query_assigned assigned join wms_mst_skill skill on skill.skillid=assigned.skillid where queryid=${reqData.queryId}`;
                await query(sql).then(async assignedData => {
                  finalData.assignedData = assignedData;
                  res.status(200).send({ data: finalData, status: true });
                });
              }
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, data: [], status: false });
          });
      } else {
        res.status(200).send({ data: finalData, status: true });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, data: [], status: false });
    });
};
export const postReply = async (req, res) => {
  const {
    replyDesc,
    createdBy,
    status,
    assigned,
    uploadedFileDetails,
    queryId,
  } = req.body;
  let sql = `update wms_query set querystatusid=${status},updatedon=current_timestamp where queryid=${queryId}`;
  try {
    console.log(sql);
    await query(sql);
    const val = [];
    val.push(
      `(${queryId},'${replyDesc}',${status},'${createdBy}',current_timestamp)`,
    );
    sql = `INSERT INTO public.wms_query_history(queryid, description, querystatusid, createdby, createdon)
        VALUES ${val} RETURNING queryhistoryid;`;
    console.log(sql);
    const historyData = await query(sql);
    console.log(historyData);
    if (uploadedFileDetails.length) {
      const val1 = [];
      uploadedFileDetails.forEach(uf => {
        val1.push(
          `( ${historyData[0].queryhistoryid}, '${uf.path}', '${uf.uuid}')`,
        );
      });
      sql = `INSERT INTO public.wms_query_files(queryhistoryid, filepath, fileuuid) VALUES ${val1}`;
      console.log(sql);
      await query(sql);
    }
    if (assigned.length) {
      sql = `delete from wms_query_assigned where queryid=${queryId}`;
      await query(sql);
      const val2 = [];
      assigned.forEach(assig => {
        val2.push(`(${queryId},${assig.value})`);
      });
      sql = `INSERT INTO public.wms_query_assigned(queryid, skillid)
            VALUES ${val2}`;
      await query(sql);
    }
    res
      .status(200)
      .send({ data: 'Reply has been posted sucessfully', status: true });
  } catch (error) {
    console.log(error);
    res.status(400).send({ message: error, data: [], status: false });
  }
};
