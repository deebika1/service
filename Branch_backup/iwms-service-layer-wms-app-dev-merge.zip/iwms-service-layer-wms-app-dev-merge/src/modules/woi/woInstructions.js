import { query } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';
import { triggerMsgEvent } from '../utils/wfTrigger/trigger.js';

export const woInstructions = async (req, res) => {
  const { wostageid, userId, date, type, text } = req.body;
  try {
    if (type === 'insert') {
      const sql = `INSERT INTO wms_workorder_stage_instructions(wostageid, insttext,addedon,addedby) VALUES ($1,$2,$3,$4) RETURNING wostageinstid;`;
      const resForEntry = await query(sql, [wostageid, text, date, userId]);
      res
        .status(200)
        .json({ data: resForEntry, message: `Data Updated Sucessfully` });
    } else if (type === 'update') {
      const sql = `UPDATE public.wms_workorder_stage_instructions SET wostageid=$1, insttext=$2, addedon=$3,addedby=$4
                where wostageid =${wostageid} RETURNING wostageinstid`;
      const resForEntry = await query(sql, [wostageid, text, date, userId]);
      res
        .status(200)
        .json({ data: resForEntry, message: `Data Updated Sucessfully` });
    }
  } catch (e) {
    logger.info(e);
  }
};

export const woInstructionsFiles = async (req, res) => {
  const { wostageinstid, filepath, fileuuid, userId, date, type } = req.body;
  try {
    if (type === 'insert') {
      const sql =
        'INSERT INTO wms_workorder_stage_instructionfiles(instfilepath,instfileuuid,addedon,addedby,wostageinstid) VALUES ($1,$2,$3,$4,$5) RETURNING wostageinstid;';
      await query(sql, [filepath, fileuuid, date, userId, wostageinstid]);
      res.status(200).json({ message: `Data Updated Sucessfully` });
    }
  } catch (e) {
    logger.info(e);
  }
};

export const getWOI = async (req, res) => {
  logger.info(req.body, 'REQ1');
  try {
    const reqData = req.body;
    const { woId } = reqData;
    let sql = '';
    const { type } = reqData;
    let condition = '';
    if (type === 'filter') {
      reqData.filter.forEach((item, i) => {
        condition +=
          reqData.filter.length - 1 !== i
            ? ` LOWER(${
                item.name
              }::text) LIKE '%${item.value.toLowerCase()}%' AND `
            : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
      });
      sql = ` 
            Select count(*) from wms_workorder_instructions
            where workorderid=${woId}   ${
        condition ? `AND${condition}` : condition
      }) as wostageIns`;
    } else {
      sql = `Select count(*) from wms_workorder_instructions   where workorderid=${woId}   ${
        condition ? `AND${condition}` : condition
      }) as wostageIns `;
    }

    sql = `Select addedbyname, wostageinstid, wostageid, addedon, insttext, addedby, workorderid, stageiterationcount, stagename||'('||stageiterationcount||')' as stagename, servicename, serviceid from wms_workorder_instructions
	    where workorderid=${woId}  ${condition ? `AND${condition}` : condition}`;
    const WOIData = await query(sql);
    res.status(200).json({ data: WOIData });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const edittWOI = async (req, res) => {
  let sql = '';
  try {
    const { id, woId, serviceid, stageid, despatch, vi } = req.body;
    sql = `select * from public.wms_workorder_stage_instructions as inst 
        left join wms_workorder_stage_instructionfiles as files 
        on files.wostageinstid=inst.wostageinstid join wms_wo_stagelist stage on 
        stage.wostageid= inst.wostageid `;
    if (!despatch) {
      sql += ` where inst.wostageinstid=${id}`;
    } else if (vi) {
      sql += `where stage.workorderid=${woId} and stage.wfstageid=${stageid} and
            stage.serviceid=${serviceid}`;
    } else {
      sql += `where stage.workorderid=${woId} and stage.wostageid=${stageid} and
                stage.serviceid=${serviceid}`;
    }
    sql += ' order by files.wostageinstfilesid';
    logger.info('sql', sql);
    const WOIeditData = await query(sql);
    logger.info('WOIeditData', WOIeditData);
    res.status(200).json({ data: WOIeditData });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};
export const deleteWOI = async (req, res) => {
  try {
    const { wostageinstfilesid } = req.body;
    const sql = `Delete FROM public.wms_workorder_stage_instructionFiles where wostageinstfilesid=${wostageinstfilesid}`;
    const WOIDeleteData = await query(sql);
    res.status(200).json({ data: WOIDeleteData });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};
export const getStageList = async (req, res) => {
  try {
    const { woId } = req.body;
    const sql = `SELECT stagelist.stagename||'('||stagelist.stageiterationcount||')' as stagename, stagelist.stagename as stage, stagelist.wostageid,stagelist.status,stagelist.wfstageid,stagelist.serviceid,stagelist.servicename, wms_workorder_service.wfid, wms_workflow.wfname, wms_workflow.wfcategory FROM public.wms_wo_stagelist stagelist
        join wms_workorder_service on wms_workorder_service.serviceid = stagelist.serviceid and 
	  wms_workorder_service.workorderid = stagelist.workorderid
        join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
        WHERE stagelist.workorderid=${woId} order by stagelist.wfstageid`;
    const WOIStageList = await query(sql);
    res.status(200).json({ data: WOIStageList });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const triggerMessage = async (req, res) => {
  try {
    const { itemCode, messageName, processVariables } = req.body;
    const sql = `Select distinct eventdata->>'processInstanceId' as processinstanceid from wms_workorder wo
    inner join wms_workflow_eventlog el on el.workorderid = wo.workorderid  
    where itemcode='${itemCode}'`;
    console.log(sql);
    const data = await query(sql);
    const processInstanceId = data[0].processinstanceid;
    const result = await triggerMsgEvent(
      processInstanceId,
      messageName,
      processVariables,
    );
    res.send({ status: true, ...result });
  } catch (error) {
    res.send({ status: false, ...error });
    console.log(error);
  }
};
