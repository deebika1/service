import { query } from '../../database/postgres.js';

export const insert_acs_mst_notificationdetails = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select xmlnotificationid
                        from public.ACS_Mst_NotificationDetails where packageack ='${jsonobj.packageack}' `;
    const out = await query(sql);
    if (out.length == 0) {
      const sqlInsert = `INSERT INTO public.ACS_Mst_NotificationDetails(
                packageack, zipname, statusid,islock,requestid,transcode,mscno,remarks,status)
               VALUES ( '${jsonobj.packageack}', '${jsonobj.zipname}', '${jsonobj.statusid}','${jsonobj.islock}','${jsonobj.requestid}','${jsonobj.transcode}','${jsonobj.mscno}','${jsonobj.remarks}','${jsonobj.status}')`;

      await query(sqlInsert).then(() => {
        res
          .status(200)
          .json({ data: 'Query Inserted Successfully', status: 'Success' });
      });
    } else {
      res
        .status(200)
        .json({ data: 'file already available', status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getDownloadList_ACS = async (req, res) => {
  try {
    const jsonobj = req.body;

    const acsPathMap = {
      acs_convert_downloader: 1,
      acs_graphics_downloader: 11,
      acs_techedit_downloader: 21,
      convert_notification: 2,
      graphics_notification: 12,
      techedit_notification: 22,
      Conversion: 3,
      Graphics: 13,
      'Copy Editing': 23,
    };

    const acsStatusId = acsPathMap[jsonobj.acsPath];
    const sql = `select xmlnotificationid,packageack,zipname,statusid,requestid,mscno,transcode from public.acs_mst_notificationdetails
    where statusid ='${acsStatusId}' order by xmlnotificationid asc;`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const updateACSmetainfo = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `update public.acs_mst_notificationdetails set statusid ='${jsonobj.statusid}',transcode='${jsonobj.transcode}', remarks = '${jsonobj.remarks}'where packageack='${jsonobj.packageack}' and islock = 'N'`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
export const updateACSFailuremetainfo = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `update public.acs_mst_notificationdetails set remarks = '${jsonobj.remarks}'where packageack='${jsonobj.packageack}' and islock = 'N'`;

    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const insert_ack_notificationdetails = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select packagename from public.trn_acknotificationdetails where packagename ='${jsonobj.PackageName}'`;
    const out = await query(sql);
    if (out.length == 0) {
      const sqlInsert = `INSERT INTO public.trn_acknotificationdetails(
            transcode, transdesc, timestamp,requestid,ackcode,manuscriptnumber,statusid,islock,
              createddate,uploadedtime,notesfromvendor,packagename,journalname,tocgraphic,prioritycode,turnaroundminutes)
            VALUES ( '${jsonobj.Transcode}', '${jsonobj.Transdesc}', '${jsonobj.TimeStamp}','${jsonobj.RequestId}',
                '${jsonobj.ACKcode}','${jsonobj.ManuscriptNumber}','${jsonobj.StatusId}','${jsonobj.isLock}',
                '${jsonobj.CreatedDate}','${jsonobj.UploadedTime}','${jsonobj.NotesFromVendor}',
                '${jsonobj.PackageName}','${jsonobj.JournalName}',
                '${jsonobj.tocGraphic}','${jsonobj.priorityCode}','${jsonobj.turnaroundMinutes}')`;

      await query(sqlInsert).then(() => {
        res
          .status(200)
          .json({ data: 'Query Inserted Successfully', status: 'Success' });
      });
    } else {
      res
        .status(200)
        .json({ data: 'file already available', status: 'Success' });
    }
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getGraphicsList_ACS = async (req, res) => {
  try {
    const jsonobj = req.body;
    const sql = `select xmlnotificationid,packageack,zipname,statusid,requestid,mscno,transcode from public.acs_mst_notificationdetails
    where mscno ='${jsonobj.mscno}' and transcode = 140`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
