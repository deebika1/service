/* eslint-disable no-unused-vars */
import { readFile } from 'fs';
import xmlParser from 'fast-xml-parser';
import moment from 'moment';
import xml2jsonConvertor from 'xml2js';
import { query } from '../../database/postgres.js';
import { woxmlConfig, woKeyConfig } from '../bpmn/parser/core/config.js';
import {
  WorkOrderCreation,
  mailTriggerForAutoWOCreate,
  mailTriggerForWatcherIdle,
} from './index.js';
import { triggerWOStageWf_logic, settriggerNextStagewf } from './stage.js';
import {
  getFolderStructure_autowocreate,
  getFolderStructure,
} from '../utils/wmsFolder/index.js';
import { _upload } from '../utils/azure/index.js';
import { uploadFiletoOpenKM } from '../utils/okm/index.js';
import { emitAction } from '../activityListener/index.js';
import logger from '../utils/logs/index.js';
import { getJournalDetail } from '../common/index.js';
import { fileTxnUpdate } from '../task/index.js';

export const readWorkorderInfo = async (req, res) => {
  logger.info(`===========wocreation triggered===============`);
  const { stagename, articlename } = req.body;
  const ndate = Date.now();
  const date_ob = new Date(ndate);
  const date = date_ob.getDate();
  const month = date_ob.getMonth() + 1;
  const year = date_ob.getFullYear();
  const hours = date_ob.getHours();
  const minutes = date_ob.getMinutes();
  const seconds = date_ob.getSeconds();

  // prints date & time in YYYY-MM-DD format
  const tdate = `${year}-${month}-${date} ${hours}:${minutes}:${seconds}`;

  logger.info(
    `articlename = ${articlename} , stagename = ${stagename}, datetime = ${tdate}`,
  );

  let output = {
    issuccess: false,
    message: 'wo creation started',
    workorderid: 0,
    uploadpath: '',
  };
  try {
    const resp = await readWorkorderInfoprocess(req, res);
    if (resp) {
      output = resp;
    } else {
      output.message = 'wo creation failed';
    }
  } catch (error) {
    output.message = error.message;
  } finally {
    res.json(output);
    res.end('Response sent message');
  }
};

export const woInstructions = async instruction => {
  return new Promise(async (resolve, reject) => {
    try {
      const { wostageid, userId, date, text } = instruction;
      const sql = `INSERT INTO wms_workorder_stage_instructions(wostageid, insttext,addedon,addedby) VALUES ($1,$2,$3,$4) RETURNING wostageinstid;`;
      const resForEntry = await query(sql, [wostageid, text, date, userId]);
      resolve(resForEntry, 'woInstructions success');
    } catch (e) {
      logger.info(e, 'woInstructions');
      reject(e);
    }
  });
};

export const getWKjournals = async (req, res) => {
  // const { piivalue } = req;
  return new Promise(async resolve => {
    const sql = `select mp.ftpaliasname,jo.journalacronym  from pp_mst_journal jo  
    inner join org_mst_customer_orgmap om on om.custorgmapid=jo.custorgmapid 
    inner join pp_mst_journal_alias_ftp mp on lower(mp.journalacronym)=lower(jo.journalacronym)
    where customerid=13
     `;
    await query(sql)
      .then(response => {
        if (response.length) {
          res.status(200).send({ issuccess: true, data: response });
        } else {
          res.status(200).send({ issuccess: false, data: response });
        }
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

export const getWKjournalsByFTPName = async (req, res) => {
  const { ftpname } = req.body;
  return new Promise(async resolve => {
    const sql = `select mp.ftpaliasname,jo.journalacronym  from pp_mst_journal jo  
    inner join org_mst_customer_orgmap om on om.custorgmapid=jo.custorgmapid 
    inner join pp_mst_journal_alias_ftp mp on lower(mp.journalacronym)=lower(jo.journalacronym)
    where customerid=13 and lower(mp.ftpaliasname) = lower('${ftpname}');`;
    await query(sql)
      .then(response => {
        if (response.length) {
          res.status(200).send({ issuccess: true, data: response });
        } else {
          res.status(200).send({ issuccess: false, data: response });
        }
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

export const UpdateManuscriptzipname = async (req, res) => {
  const { itemcode, manuscriptzipname } = req.body;
  return new Promise(async resolve => {
    const sql = `UPDATE wms_workorder
    SET otherfield = jsonb_set(otherfield::jsonb, '{manuscriptzipname}', '"${manuscriptzipname}"', true)
    WHERE itemcode = '${itemcode}';`;
    await query(sql)
      .then(response => {
        res.status(200).send({ issuccess: true, data: response });
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

export const getStageIterationCount = async (req, res) => {
  const { wfstageid, itemcode } = req.body;

  return new Promise(async resolve => {
    const sql = `select ww.workorderid, wws.wostageid, wws.wfstageid  ,wws.stageiterationcount ,wws.status
    from wms_workorder ww  
    join wms_workorder_stage wws on ww.workorderid = wws.workorderid 
    where wfstageid = $1 and ww.itemcode  = $2 order by wws.wostageid desc limit 1`;
    await query(sql, [wfstageid, itemcode])
      .then(response => {
        if (response.length) {
          res.status(200).send({ issuccess: true, data: response });
        } else {
          res.status(200).send({ issuccess: false, data: response });
        }
      })
      .catch(error => {
        res.status(400).send({ issuccess: false, message: error });
      });
  });
};

export const readWorkorderInfoprocess = async (req, res) => {
  let logid = 0;
  let output = '';
  let cparam = '';
  let ismailsend = true;
  let dmstype = 'azure';
  let isuploadfile = true;
  let err_message = '';

  console.log(ismailsend);
  return new Promise(async resolve => {
    let woDetails1;
    let eventDetails;
    const {
      customer,
      fileType,
      woType,
      stagename,
      articlename,
      stageiterationcount,
      journal,
      tranid,
      remark,
      piivalue,
      jobType,
      otherInput,
    } = req.body;

    const initiallogmesage =
      remark == undefined || remark == ''
        ? 'Wo creation process started and incomplete'
        : `failed in reading file: ${remark}`;
    let wfconfdata = {
      issuccess: false,
      message: initiallogmesage,
      articlename,
      journal,
      customer,
      stageName: stagename,
      iteration: stageiterationcount,
    };

    if (remark != '') {
      output = {
        issuccess: false,
        message: initiallogmesage,
        workorderid: 0,
        uploadpath: '',
      };
    }

    let actiontype = 'wocreation_error';

    try {
      const objreqbody = req.body;
      objreqbody.tranid = tranid;
      objreqbody.logmessage = initiallogmesage;

      const logresp = await workorderlog(objreqbody, 'Insert');
      logid = logresp.logid;

      if (customer == 'CUP') {
        dmstype = 'azure';
        isuploadfile = true;
      } else {
        dmstype = 'local';
        isuploadfile = false;
      }

      if (
        fileType.toLowerCase() == 'xml' &&
        (remark == '' || remark == undefined)
      ) {
        const checkjournaldetail = await getJournalDetail({
          journalshortname: journal,
          customershortname: customer,
        });

        // const wodetails = await getWorkOrderDetail_Itemcode(articlename);
        // if (wodetails.length > 0) {
        //   dmstype = wodetails[0].dmstype;
        //   console.log(dmstype, 'dmstype');
        // }
        const retwoexist = await checWoandStageStatus({
          body: {
            articlename,
            stagename,
            stageiterationcount,
          },
        });

        let alljobcompleted = true;

        if (
          customer.toLowerCase() == 'springer' &&
          woType == 'Journal' &&
          jobType == 'Issue'
        ) {
          const jsoninput = JSON.parse(otherInput);
          const getstatus = await checkworkorderstatus(jsoninput.doilist);
          if (getstatus && getstatus.issuccess) {
            alljobcompleted = true;
          } else {
            alljobcompleted = false;
          }
        }

        let valid = true;
        if (
          checkjournaldetail.error != undefined &&
          stagename != 'First View'
        ) {
          valid = false;
          err_message = 'Email and other details not present for journal';
        } else if (alljobcompleted == false) {
          valid = false;
          err_message = 'Stage 600 chapters not fully completed';
        } else {
          valid = true;
        }

        if (valid) {
          if (
            stageiterationcount == 1 &&
            stagename != 'First View' &&
            retwoexist.issuccess == true &&
            retwoexist.iswoexist == false
          ) {
            if (req.body.content.toLowerCase() != '') {
              logger.info('Req for initial hit');
              const wo_response = await getWorkorderxmlData(req, res, logid);
              if (wo_response) {
                if (wo_response.status == true) {
                  cparam = {
                    logmessage: wo_response.message,
                    issuccess: true,
                    workorderid: +wo_response.woId,
                    autologid: logid,
                    uploadpath: wo_response.uploadpath,
                    isstagetrigger: false,
                  };
                  output = {
                    issuccess: true,
                    message: wo_response.message,
                    workorderid: +wo_response.woId,
                    uploadpath: wo_response.uploadpath,
                  };
                } else {
                  cparam = {
                    logmessage: wo_response.message,
                    issuccess: false,
                    workorderid: 0,
                    autologid: logid,
                    uploadpath: '',
                    isstagetrigger: false,
                  };
                  output = {
                    issuccess: false,
                    message: wo_response.message,
                    workorderid: 0,
                    uploadpath: '',
                  };
                }
              } else {
                cparam = {
                  logmessage: 'failed',
                  issuccess: false,
                  workorderid: 0,
                  autologid: logid,
                  uploadpath: '',
                  isstagetrigger: false,
                };
                output = {
                  issuccess: false,
                  message: 'failed',
                  workorderid: 0,
                  uploadpath: '',
                };
              }
            } else {
              cparam = {
                logmessage: 'content is empty',
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              output = {
                issuccess: false,
                message: 'content is empty',
                workorderid: 0,
                uploadpath: '',
              };
            }

            wfconfdata = {
              issuccess: output.issuccess,
              message: output.message,
              articlename,
              journal,
              customer,
              stageName: stagename,
              iteration: stageiterationcount,
            };
            actiontype =
              output.issuccess == true
                ? 'wocreation_success'
                : 'wocreation_error';
          } //* *****Stage trigger Process Start********//
          else if (
            (retwoexist.issuccess == true &&
              retwoexist.iswoexist == true &&
              (retwoexist.isstageexist == false ||
                retwoexist.isstagecomplete == true)) ||
            stagename == 'First View'
          ) {
            if (customer.toLowerCase() == 'springer') {
              dmstype = 'local';
              isuploadfile = false;
            } else if (customer.toLowerCase() == 'wkh') {
              dmstype = 'local';
              isuploadfile = false;
            } else {
              dmstype = 'azure';
              isuploadfile = true;
            }

            const reqobj = {
              stagename,
              articlename,
              woType,
              stageiterationcount,
              journal,
            };
            console.log(reqobj);

            actiontype = 'stagecreation_error';
            if (stagename != 'First View') {
              woDetails1 = await getworkorderdetail_bystage(
                articlename,
                stagename,
              );

              eventDetails = await getWfEventDetailsForWo(
                articlename,
                stagename,
                +stageiterationcount,
              );
            }

            console.log(eventDetails);
            if (stagename == 'First View') {
              // ismailsend = false;
              const getjob = await getArticleDetailByPii({ piivalue });
              if (getjob.issuccess) {
                reqobj.articlename = getjob.data[0].itemcode;
                reqobj.journal = getjob.data[0].journalacronym;
                // articlename = getjob.data[0].itemcode;
                // journal = reqobj.journal;
              }
            }

            const trigstat = await getwostagetrigger({ body: reqobj }, res);

            // const trigstat = {
            //   message: 'success',
            //   issuccess: true,
            //   uploadpath: 'fileuploadpath',
            // }

            if (trigstat.issuccess == true) {
              actiontype = 'stagecreation_success';

              if (stagename == 'First View') {
                ismailsend = false;
              }
              cparam = {
                logmessage: 'success',
                issuccess: true,
                workorderid: 0,
                autologid: logid,
                uploadpath: trigstat.uploadpath,
                isstagetrigger: true,
              };
              output = {
                issuccess: true,
                message: 'success',
                uploadpath: trigstat.uploadpath,
              };
            } else {
              cparam = {
                logmessage: trigstat.message,
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: true,
              };
              output = {
                issuccess: false,
                message: trigstat.message,
                uploadpath: '',
              };
            }

            wfconfdata = {
              issuccess: output.issuccess,
              message: output.message,
              articlename: reqobj.articlename,
              journal: reqobj.journal,
              customer,
              stageName: stagename,
              iteration: stageiterationcount,
            };
          } else if (
            retwoexist.issuccess == true &&
            retwoexist.iswoexist == true &&
            retwoexist.isstageexist == true
          ) {
            ismailsend = false;
            if (retwoexist.isstagecomplete == false) {
              cparam = {
                logmessage: 'Current stage is In progres cannot trigger stage',
                issuccess: false,
                workorderid: -1,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              output = {
                issuccess: false,
                message: 'Current stage is In progres cannot trigger stage',
                uploadpath: '',
              };
            } else {
              const respayload = await payloadStagetriggerFileupload({
                body: {
                  stagename,
                  articlename,
                  woType,
                  stageiterationcount,
                },
              });
              if (respayload.issuccess) {
                const fileuploadpath = await getFolderStructure_autowocreate({
                  body: JSON.parse(respayload.uploadpathpayload),
                });

                if (fileuploadpath) {
                  cparam = {
                    logmessage: 'success',
                    issuccess: true,
                    workorderid: -1,
                    autologid: logid,
                    uploadpath: fileuploadpath,
                    isstagetrigger: false,
                  };
                  output = {
                    issuccess: false,
                    message: 'success',
                    uploadpath: fileuploadpath,
                  };
                } else {
                  const msg =
                    'File upload path is not available while stage trigger';
                  cparam = {
                    logmessage: msg,
                    issuccess: false,
                    workorderid: -1,
                    autologid: logid,
                    uploadpath: '',
                    isstagetrigger: false,
                  };
                  output = { issuccess: false, message: msg, uploadpath: '' };
                }
              } else {
                const msg = 'Failed on getting payload for stage trigger';
                cparam = {
                  logmessage: msg,
                  issuccess: false,
                  workorderid: -1,
                  autologid: logid,
                  uploadpath: '',
                  isstagetrigger: false,
                };
                output = { issuccess: false, message: msg, uploadpath: '' };
              }
            }
          } else {
            output = {
              issuccess: false,
              message: 'process failed-- no condition matched',
              uploadpath: '',
            };
          }
        } else {
          cparam = {
            logmessage: err_message,
            issuccess: false,
            workorderid: 0,
            autologid: logid,
            uploadpath: '',
            isstagetrigger: false,
          };
          wfconfdata = {
            issuccess: false,
            message: err_message,
            articlename,
            journal,
            customer,
            stageName: stagename,
            iteration: stageiterationcount,
          };
          output = {
            issuccess: false,
            message: err_message,
            workorderid: 0,
            uploadpath: '',
          };
        }

        ///
        if (output.issuccess) {
          if (
            stagename == 'Revises' &&
            customer == 'CUP' &&
            woType == 'Journal'
          ) {
            if (woDetails1) {
              let fileuploadpath = '';

              const filepathpayload = {
                type: 'wo_activity_file_subtype',
                du: { name: woDetails1[0].duname, id: woDetails1[0].duid },
                customer: {
                  name: woDetails1[0].customername,
                  id: woDetails1[0].customerid,
                },
                workOrderId: woDetails1[0].workorderid,
                service: {
                  name: woDetails1[0].servicename,
                  id: woDetails1[0].serviceid,
                },
                stage: {
                  name: stagename,
                  id: woDetails1[0].stageid,
                  iteration:
                    +stageiterationcount > 1
                      ? +stageiterationcount - 1
                      : +stageiterationcount,
                },
                activity: {
                  name: 'completion trigger',
                  id: 21,
                  iteration: 1,
                },
                fileType: {
                  name: 'article',
                  id: '4',
                  fileId: woDetails1[0].woincomingfileid,
                },
              };

              fileuploadpath = await getFolderStructure_autowocreate({
                body: filepathpayload,
              });

              // fileuploadpath = getFolderStructure({
              //   type: 'wo_activity_file_subtype',
              //   du: { name: woDetails1[0].duname, id: woDetails1[0].duid },
              //   customer: {
              //     name: woDetails1[0].customername,
              //     id: woDetails1[0].customerid,
              //   },
              //   workOrderId: woDetails1[0].workorderid,
              //   service: {
              //     name: woDetails1[0].servicename,
              //     id: woDetails1[0].serviceid,
              //   },
              //   stage: {
              //     name: stagename,
              //     id: woDetails1[0].stageid,
              //     iteration:
              //       +stageiterationcount > 1
              //         ? +stageiterationcount - 1
              //         : +stageiterationcount,
              //   },
              //   activity: {
              //     name: 'completion trigger',
              //     id: 21,
              //     iteration: 1,
              //   },
              //   fileType: {
              //     name: 'article',
              //     id: '4',
              //     fileId: woDetails1[0].woincomingfileid,
              //   },
              // });

              fileuploadpath = fileuploadpath.replace(
                'completion_trigger_',
                'completion_trigger__',
              );
              output.uploadpath = fileuploadpath;
              cparam.uploadpath = fileuploadpath;
            }
          }
        }

        ///

        // else if (req.body.fileType.toLowerCase() == 'excel') {
        //   const wo_response = await getWorkorderExcelData(req, res);
        //   console.log(wo_response);
        // }

        //* *****uploading process start********//
        if (
          isuploadfile == true &&
          output.issuccess == true &&
          stagename != 'First View'
        ) {
          if (
            output.uploadpath != '' &&
            req.files &&
            (req.files.zip || req.files.xml)
          ) {
            let OpenKMOutput;

            switch (dmstype) {
              case 'azure':
                if (customer == 'CUP') {
                  if (woType == 'Journal' && jobType == 'Issue') {
                    OpenKMOutput = await _upload(
                      req.files.zip,
                      `${output.uploadpath}ZIP/`,
                    );
                    if (output.uploadpath != '' && req.files && req.files.xml) {
                      await _upload(req.files.xml, `${output.uploadpath}XML/`);
                    }
                  } else {
                    OpenKMOutput = await _upload(
                      req.files.zip,
                      output.uploadpath,
                    );
                    if (output.uploadpath != '' && req.files && req.files.xml) {
                      await _upload(req.files.xml, output.uploadpath);
                    }
                  }
                } else {
                  OpenKMOutput = await _upload(
                    req.files.zip,
                    output.uploadpath,
                  );
                  if (output.uploadpath != '' && req.files && req.files.xml) {
                    await _upload(req.files.xml, output.uploadpath);
                  }
                }
                break;
              default:
                OpenKMOutput = await uploadFiletoOpenKM(
                  req,
                  output.uploadpath,
                  'zip',
                );
                break;
            }
            //  let oOpenKMOutput = dmstype == 'openkm' ? await uploadFiletoOpenKM(req, output.uploadpath, "zip") :
            //     await _upload(req.files["zip"], output.uploadpath);

            req.body.uid = OpenKMOutput.data.uuid;
            req.body.uploadpath = OpenKMOutput.fullPath;

            if (stagename == 'Revises' && woType == 'Journal') {
              if (eventDetails && eventDetails.length > 0) {
                await fileTxnUpdate(
                  eventDetails[0].wfeventid,
                  OpenKMOutput.uuid,
                  OpenKMOutput.fullPath,
                  eventDetails[0].woincomingfileid,
                );
              }
            }
            const ures = await insert_uploadpath_uid(req);
            if (ures && ures.issuccess == false) {
              cparam = {
                logmessage: 'Failed to insert on table source file details',
                issuccess: false,
                workorderid: 0,
                autologid: logid,
                uploadpath: '',
                isstagetrigger: false,
              };
              wfconfdata = {
                issuccess: false,
                message: 'Failed to insert on table source file details',
                articlename,
                journal,
                customer,
                stageName: stagename,
                iteration: stageiterationcount,
              };
            }
          } else {
            cparam = {
              logmessage: 'File upload failed',
              issuccess: false,
              workorderid: 0,
              autologid: logid,
              uploadpath: '',
              isstagetrigger: false,
            };
            wfconfdata = {
              issuccess: false,
              message: 'File upload failed',
              articlename,
              journal,
              customer,
              stageName: stagename,
              iteration: stageiterationcount,
            };
          }
        }

        if (output.issuccess == true && isuploadfile == false) {
          req.body.uid = 'local';
          req.body.uploadpath = output.uploadpath;
          await insert_uploadpath_uid(req);
        }
      }
      //* *****uploading process end********//
    } catch (e) {
      cparam = {
        logmessage: e.message,
        issuccess: false,
        workorderid: 0,
        autologid: logid,
        uploadpath: '',
        isstagetrigger: false,
      };
      wfconfdata = {
        issuccess: false,
        message: 'Wo creation failed',
        articlename,
        journal,
        customer,
        stageName: stagename,
        iteration: stageiterationcount,
      };

      output = { issuccess: false, message: e.message, uploadpath: '' };
    } finally {
      logger.info(
        articlename,
        'dblogwrite: ---before log write in db (no await)---',
      );
      workorderlog(cparam, 'Update').catch(err => {
        logger.info(err, ' [logwrite error:]');
      });

      if (customer == 'CUP' || customer == 'WKH') {
        if (woType == 'Journal' && jobType !== 'Issue') {
          if (ismailsend) {
            logger.info(articlename, 'mail_log: ---inside mail condition---');
            mailTriggerForAutoWOCreate(wfconfdata, actiontype);
          }
        }
      }
      logger.info(articlename, 'mail_log: ---after mail trigger (no await)---');
      logger.info(output, '[response output:]');
      // res.json(output);
      resolve(output);
    }
  });
};

export const TestSendEmail = async (req, res) => {
  const data = req.body;
  emitAction(data);

  res.send('success');
  /*
    data = {
        actionType: "mail",
        jobTypes: [
          "1",
        ],
        from: "iwmssupport@integra.co.in",
        to: [
          "toSpm",
        ],
        cc: [
        ],
        bcc: [
          "gnanamani.murugan@integra.co.in",
          "alaguraj.sannasi@integra.co.in",
        ],
        subject: "Auto workorder created succesfully for <%= data.jobId %>",
        template: "<html><style>.header{color: #ff7904;}.auto-text{color: #70757a;text-align: center;margin-top: 10px;}.footer{margin-top: 10px;}</style><body><div><div class='body'><p>Dear Team,</p><div> <p>We confirm a safe receipt of shared files for new article <%= data.jobId %></p> <br></br><div><span>Regards,</span></br><span>Integra Production team, Journals</span></br></div></div></div></div></body></html>",
        jobId: "PAX_test100",
        subMessage: "Message : success",
        toMail: [
          "suradha.gunaseelan@integra-india.com",
        ],
      };
*/

  /* let { workorderid, message, issuccess, articlename, journal, customer } = data;
    let actiontype = issuccess == true ? "wocreation_success" : "wocreation_error";
    let wfconfdata = { workorderid: workorderid, issuccess: issuccess, message: message, articlename: articlename, journal: journal, customer: customer }
    return new Promise(async (resolve, reject) => {
        logger.info('before mail trigger')
        let resmail = await mailTriggerForAutoWOCreate(wfconfdata, actiontype);
        if (resmail && resmail.isssuccess == true) {
            resolve("Email sent successfully");
        } else {
            resolve("Failed in sending email");
        }

    }).catch((error) => {
        resolve("Failed in sending email");
    }); */
};

const getArticleDetailByPii = async req => {
  const { piivalue } = req;
  return new Promise(async resolve => {
    const sql = `select 
                  wo.workorderid, wo.itemcode, wo.title, wo.customerid, wo.divisionid, 
                  wo.subdivisionid, wo.countryid,  wo.status, wo.journalid, wo.wotype, 
                  wo.doinumber, jo.journalacronym
                 from wms_workorder as wo
                 left join public.pp_mst_journal as jo on jo.journalid = wo.journalid and jo.isactive = 1
                 where wo.isactive = true and wo.otherfield->>'pii' = '${piivalue}'`;
    // console.log(sql, 'logsql');
    query(sql)
      .then(response => {
        if (response.length) {
          resolve({ issuccess: true, data: response });
        } else {
          resolve({ issuccess: false, data: response });
        }
      })
      .catch(() => {
        resolve({ issuccess: false, data: {} });
      });
  });
};

export const checWoandStageStatus = async req => {
  const { articlename, stagename, stageiterationcount } = req.body;

  return new Promise(async resolve => {
    const sql = `SELECT * from checkworkorderstage_exist('${articlename}','${stagename}',${stageiterationcount})`;
    console.log(sql, 'logsql');
    logger.info(sql, 'checexistingjob');
    query(sql)
      .then(response => {
        if (response.length) {
          // let triggerstage = false;
          // if( (response[0].isstagetriggered && response[0].isstagecomplete) || response[0].isstagetriggered == false ) {
          //     triggerstage =   true;
          // }

          logger.info(response[0], 'response_checexistingjob');

          resolve({
            issuccess: true,
            iswoexist: response[0].isworkorderexist,
            isstageexist: response[0].isstagetriggered,
            isstagecomplete: response[0].isstagecomplete,
          });
        } else {
          resolve({
            issuccess: false,
            iswoexist: false,
            isstageexist: false,
            isstagecomplete: false,
          });
        }
      })
      .catch(() => {
        resolve({
          issuccess: false,
          iswoexist: false,
          isstageexist: false,
          isstagecomplete: false,
        });
      });
  });
};

const getwostagetrigger = async (req, res) => {
  const { stagename, articlename, stageiterationcount } = req.body;
  // let iparam = JSON.stringify(req);
  return new Promise(async resolve => {
    const respayload = await payloadStagetriggerFileupload(req);

    if (
      (respayload.issuccess == true &&
        stagename == 'AMO' &&
        respayload.amostagepayload != '') ||
      (stagename != 'AMO' && respayload.nextstagepayload != '')
    ) {
      // const stagetrigpayload = respayload.stagetriggerpayload
      //   ? JSON.parse(respayload.stagetriggerpayload)
      //   : '{}';
      const filtepathpayload = respayload.uploadpathpayload
        ? JSON.parse(respayload.uploadpathpayload)
        : '{}';
      const amostagepayload = respayload.amostagepayload
        ? JSON.parse(respayload.amostagepayload)
        : '{}';
      const nextstagepayload = respayload.nextstagepayload
        ? JSON.parse(respayload.nextstagepayload)
        : '{}';

      let checkresp;

      //   const server = http.createServer(async(request, response) => {
      // magic happens here!

      if (stagename == 'AMO') {
        checkresp = await settriggerNextStagewf({ body: amostagepayload }, res);
      } else {
        //  checkresp = await updateWoStage_autoCall({ body: JSON.parse(stagetrigpayload) }, res);
        checkresp = await triggerWOStageWf_logic(
          { body: nextstagepayload },
          res,
        );
      }
      //  });
      if (checkresp && checkresp.issuccess) {
        await updatestagetatdate({
          articlename,
          stagename,
          stageiterationcount,
        });

        const fileuploadpath = await getFolderStructure_autowocreate({
          body: filtepathpayload,
        });

        // if (checkresp && checkresp.issuccess) {
        resolve({
          message: 'success',
          issuccess: true,
          uploadpath: fileuploadpath,
        });
      } else {
        resolve({
          message: `Stage trigger failed -(${checkresp.message})`,
          issuccess: false,
          uploadpath: '',
        });
      }
    } else {
      resolve({
        message: 'Failed on getting payload for stage trigger',
        issuccess: false,
        uploadpath: '',
      });
    }
  });
};

const updatestagetatdate = async req => {
  const { articlename, stagename, stageiterationcount } = req;
  return new Promise(async resolve => {
    const sql = `SELECT * from update_stage_tatdate('${articlename}','${stagename}', ${stageiterationcount})`;
    query(sql)
      .then(() => {
        resolve('success');
      })
      .catch(() => {
        resolve('failed');
      });
  });
};

export const payloadStagetriggerFileupload = async req => {
  const { stagename, articlename, woType, stageiterationcount } = req.body;
  return new Promise(async resolve => {
    const sql = `SELECT * from getarticlestagetrigger('${stagename}','${articlename}','${woType}','${stageiterationcount}')`;
    logger.info(sql, 'getarticlestagetrigger logsql');
    query(sql)
      .then(async response => {
        if (response) {
          logger.info(response, 'fileupload response');
          const { fileuploadpayload } = response[0];
          const stagetriggerpayload = response[0].stagepayload;
          const amostagepayload = response[0].amopayload;
          const { nextstagepayload } = response[0];
          resolve({
            issuccess: true,
            uploadpathpayload: fileuploadpayload,
            stagetriggerpayload,
            amostagepayload,
            nextstagepayload,
          });
        }
      })
      .catch(() => {
        resolve({
          issuccess: false,
          uploadpathpayload: '',
          stagetriggerpayload: '',
          amostagepayload: '',
          nextstagepayload: '',
        });
      });
  });
};

export const insert_uploadpath_uid = async req => {
  const { articlename, stagename, stageiterationcount, uploadpath, uid } =
    req.body;
  return new Promise(async resolve => {
    const sql = `select insert_uploadpathuid ('${articlename}','${stagename}',${stageiterationcount},'${uploadpath}','${uid}')`;
    logger.info(sql, 'insert_uploadpathuid');
    query(sql)
      .then(async response => {
        if (response && response.length) {
          const respid = response[0].insert_uploadpathuid;
          resolve({ issuccess: true, id: respid, message: 'success' });
        } else {
          resolve({ issuccess: false, id: 0, message: 'failed' });
        }
      })
      .catch(error => {
        resolve({ issuccess: false, id: 0, message: error.message });
      });
  });
};
export const insertUploadPathUid = async (req, res) => {
  try {
    const respobj = await insert_uploadpath_uid(req);
    if (respobj && respobj.issuccess == true) {
      res.status(200).send({ issuccess: true, message: respobj.message });
    } else {
      res.status(400).send({ issuccess: false, message: respobj.message });
    }
  } catch (error) {
    res.status(400).send({ issuccess: false, message: error.message });
  }
};

export const workorderlog = async (req, flag) => {
  const iparam = JSON.parse(JSON.stringify(req));
  iparam.content = '';
  return new Promise(async resolve => {
    const sql = `SELECT * from workorder_autolog('${JSON.stringify(
      iparam,
    )}','${flag}')`;

    query(sql)
      .then(response => {
        if (response) {
          const lid = response[0].logresult;
          resolve({ logid: lid });
        } else {
          resolve({ logid: 0 });
        }
      })
      .catch(() => {
        resolve({ logid: 0 });
      });
  });
};

export const getWorkorderxmlData = async (req, res, logid) => {
  const {
    InPath,
    customer,
    woType,
    jobType,
    stagename,
    articlename,
    journal,
    tasktype,
    springerinput,
    // manuscriptzipname,
    otherInput,
  } = req.body;
  const { content } = req.body;
  let currentkey = '';
  return new Promise(async resolve => {
    try {
      if (customer == 'CUP') {
        if (woType == 'Journal') {
          if (jobType == 'Issue') {
            currentkey = woKeyConfig.cup_bookxmlkeys;
          } else {
            currentkey = woKeyConfig.cup_journalxmlkeys;
          }
        } else {
          // book
          currentkey = woKeyConfig.cup_bookxmlkeys;
        }
      } else if (customer == 'Emerald') {
        if (woType == 'Journal')
          currentkey = woKeyConfig.emerald_journalxmlkeys;
        if (woType == 'Book') currentkey = woKeyConfig.emerald_bookxmlkeys;
      } else if (customer == 'IOPP') {
        if (woType == 'Journal') currentkey = woKeyConfig.iopp_journalxmlkeys;
      } else if (customer.toLowerCase() == 'springer') {
        if (jobType == 'Issue') {
          currentkey = woKeyConfig.springer_issuexmlkeys;
        } else {
          currentkey = woKeyConfig.springer_journalxmlkeys;
        }
        // currentkey = woKeyConfig.springer_journalxmlkeys;
      } else if (customer == 'WKH') {
        currentkey = woKeyConfig.WKH_journalxmlkeys;
      } else if (customer == 'ACS') {
        currentkey = woKeyConfig.ACS_journalxmlkeys;
      }
      // logger.info("content check 1-suradha", content);
      const xmlobjdata = content
        ? await readXMLDatafromContent(content, woxmlConfig)
        : await readXMLData(InPath, woxmlConfig);
      // logger.info("content check 2-suradha", xmlobjdata);

      const setPayloads = {};
      let errormsg = '';
      if (xmlobjdata) {
        const keyobj = JSON.parse(currentkey);

        for (const [key, value] of Object.entries(keyobj[0])) {
          if (key.includes('XML')) {
            if (value.includes(',')) {
              let xval = readKeyvalue(value, Object.values(xmlobjdata)[0]);

              if (xval === undefined) {
                xval = '';
                errormsg =
                  errormsg.length > 0
                    ? `${errormsg}, ${key.replace(/^xml(?:DBID)?/i, '')}`
                    : `${key.replace(/^xml(?:DBID)/i, '')}`;
              }
              xval =
                typeof xval === 'string' || typeof xval === 'number'
                  ? xval
                  : '';
              if (key.includes('XMLDBID'))
                setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
                  value: xval,
                  keyconfig: key,
                });
              else setPayloads[key.replace('XML', '')] = xval;
            } else {
              let dval = Object.values(xmlobjdata)[0][value];
              if (dval === undefined) {
                if (
                  customer == 'CUP' &&
                  woType == 'Journal' &&
                  key === 'XMLarticleno'
                ) {
                  dval = '';
                } else {
                  errormsg =
                    errormsg.length > 0
                      ? `${errormsg}, ${key.replace(/^xml(?:DBID)?/i, '')}`
                      : `${key.replace(/^xml(?:DBID)?/i, '')}`;
                  dval = '';
                }
              }
              const fval = typeof dval === 'object' ? dval[0] : dval;

              if (key.includes('XMLDBID'))
                setPayloads[key.replace('XMLDBID', '')] = await getIdFromName({
                  value: fval,
                  keyconfig: key,
                });
              else setPayloads[key.replace('XML', '')] = fval;
            }
          } else {
            setPayloads[key] = value;
          }
        }
      }
      logger.info('The following element missing (check) = ', errormsg);
      if (errormsg.length > 0) {
        resolve({
          message: `The following element is "${errormsg}" missing in metadata`,
          status: false,
          uploadpath: '',
        });
        return;
      }
      let users = [];
      // (customer == 'CUP' || customer == 'IOPP') &&
      if (woType == 'Journal') {
        const customerName = customer == 'CUP' ? 'CUP Journals' : customer;
        const DBjournaldet = await getCustomerJournalDetail({
          customer: customerName,
          journalAcronym: journal,
        });

        if (DBjournaldet.length > 0) {
          for (const [key, value] of Object.entries(DBjournaldet[0])) {
            if (
              key == 'customer' ||
              key == 'country' ||
              key == 'colours' ||
              key == 'journalId'
            ) {
              setPayloads[key] = +value;
            } else {
              setPayloads[key] =
                typeof setPayloads[key] === 'number' ? +value : value;
            }
          }
          if (customer == 'CUP' || customer == 'WKH') {
            if (woType == 'Journal' && jobType !== 'Issue') {
              // eslint-disable-next-line no-const-assign
              users = await constructAuthorDetails(setPayloads);
              if (users.issuccess == true) {
                setPayloads.externalUsers = users.data;
              }
            }
          }
          if (customer.toLowerCase() == 'springer') {
            if (woType == 'Journal' && jobType !== 'Issue') {
              const lstusers = [];
              // eslint-disable-next-line no-const-assign
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };

              const spaudet = JSON.parse(
                JSON.parse(springerinput).articleauthor,
              );
              pushobj.email = spaudet.email;
              pushobj.name = spaudet.name;
              lstusers.push(pushobj);

              setPayloads.externalUsers = lstusers;
              setPayloads.isESM = JSON.parse(springerinput).isESM;
              setPayloads.flowtype = JSON.parse(springerinput).flowtype;
              setPayloads.CELevel = JSON.parse(springerinput).copyEditingValue;
            } else if (woType == 'Journal' && jobType === 'Issue') {
              const lstusers = [];
              // eslint-disable-next-line no-const-assign
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };

              pushobj.email = 'test@integra.co.in';
              pushobj.name = 'Springer Issue';
              lstusers.push(pushobj);

              setPayloads.externalUsers = lstusers;
              setPayloads.jobTitle = `${articlename}-Issue`;

              setPayloads.frontmatterPrintPDF =
                JSON.parse(otherInput).frontmatterPrintPDF;
              setPayloads.backmatterPrintPDF =
                JSON.parse(otherInput).backmatterPrintPDF;
              setPayloads.coverPrintPDF = JSON.parse(otherInput).coverPrintPDF;
              setPayloads.advertisementPrintPDF =
                JSON.parse(otherInput).advertisementPrintPDF;
            }
          }

          if (customer.toLowerCase() == 'acs') {
            if (woType == 'Journal' && jobType !== 'Issue') {
              const lstusers = [];
              // eslint-disable-next-line no-const-assign
              const pushobj = {
                email: '',
                name: 'rname',
                role: 7,
                roleAcronym: 'AUTHOR',
              };
              pushobj.email = 'abc@gmail.com';
              pushobj.name = 'acs customer';
              lstusers.push(pushobj);
              setPayloads.journalAcronym = journal;
              setPayloads.externalUsers = lstusers;
            }
          }

          if (customer.toLowerCase() == 'wkh') {
            setPayloads.manuscriptzipname =
              JSON.parse(otherInput).manuscriptzipname;
            setPayloads.CELevel =
              JSON.parse(otherInput).iscopyediting == true ? 2 : 1;
          }
          // users = await constructAuthorDetails(setPayloads);
          // if (users.issuccess == true) {
          //   setPayloads.externalUsers = users.data;
          // }
        } else {
          resolve({
            message: 'journal detail not present',
            status: false,
            uploadpath: '',
          });
          return;
        }
      }

      switch (jobType) {
        case 'Article':
          setPayloads.jobType = 1;
          break;
        case 'Non Article':
          setPayloads.jobType = 3;
          break;
        case 'Issue':
          setPayloads.jobType = 2;
          break;
        default:
      }

      setPayloads.trigerstagename = stagename;
      setPayloads.isauto = true;
      setPayloads.jobId = articlename;
      setPayloads.journalAcronym = journal;
      setPayloads.tasktype = tasktype;

      if (customer == 'CUP' || customer == 'WKH') {
        if (woType == 'Journal' && jobType !== 'Issue') {
          if (setPayloads.externalUsers == '') {
            resolve({
              message: 'author detail not present in xml',
              status: false,
              uploadpath: '',
            });
            return;
          }
          // add instruction in wms_workorder_stage
          const instructions = {
            wostageid: null,
            text: setPayloads.Instruction ? setPayloads.Instruction : '',
            date: moment(new Date()).format('YYYY-MM-DD'),
            userId: 'IS4615',
          };
          if (setPayloads.Instruction && setPayloads.Instruction.length > 0) {
            const wostageinstid = await woInstructions(instructions);
            setPayloads.wostageinstid =
              wostageinstid && wostageinstid.length > 0
                ? wostageinstid[0].wostageinstid
                : '';
          }
        }
      }
      const param = { payload: setPayloads, autologid: logid };

      await workorderlog(param, 'UpdatePayload');
      logger.info(setPayloads, 'before wo creation service');

      // to get no.of.articles from xml

      if (customer == 'CUP' && woType == 'Journal' && jobType == 'Issue') {
        xml2jsonConvertor.parseString(content, async (err, xmlResult) => {
          if (err) {
            console.error('Error parsing Xml:', err);
          }
          const filenamecount =
            xmlResult &&
            xmlResult['issue-order'] &&
            xmlResult['issue-order']['issue-running-order'][0] &&
            xmlResult['issue-order']['issue-running-order'][0].filename
              ? xmlResult['issue-order']['issue-running-order'][0].filename
                  .length
              : '';
          // console.log('Number of <filename> tags:', filenamecount);
          setPayloads.noOfArticles = filenamecount;
          // console.log(setPayloads);
          setPayloads.jobTitle = setPayloads.jobId;
          // checking articles completed in firstview or not
          setPayloads.backPii =
            xmlResult &&
            xmlResult['issue-order'] &&
            xmlResult['issue-order']['issue-running-order'][0] &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover
              .length > 0 &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover[0]
              .$ &&
            xmlResult['issue-order']['issue-running-order'][0].back_cover[0].$
              .PII
              ? xmlResult['issue-order']['issue-running-order'][0].back_cover[0]
                  .$.PII
              : '';
          setPayloads.frontPii =
            xmlResult &&
            xmlResult['issue-order'] &&
            xmlResult['issue-order']['issue-running-order'][0] &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover
              .length > 0 &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover[0]
              .$ &&
            xmlResult['issue-order']['issue-running-order'][0].front_cover[0].$
              .PII
              ? xmlResult['issue-order']['issue-running-order'][0]
                  .front_cover[0].$.PII
              : '';
          const xmlFileNames = Object.values(
            xmlResult['issue-order']['issue-running-order'][0].filename,
          );

          const fileNames = xmlFileNames.map(item => item._);
          // console.log(fileNames);
          const result = await isWoCompleted(fileNames);
          // console.log(result);

          if (result.issuccess == false) {
            resolve({
              message:
                'Failed on workorder creation, given Articles are not completed in iWms',
              status: false,
              uploadpath: '',
            });
          }
        });
      }

      const woresp = await WorkOrderCreation({ body: setPayloads }, res, true);
      resolve(woresp);
    } catch (e) {
      console.log(e, 'ee');
      resolve({
        message: 'Failed on workorder creation',
        status: false,
        uploadpath: '',
      });
    }
  });
};

const constructAuthorDetails = async data => {
  const users = [];
  const rolelist = await getAllRole();

  return new Promise(resolve => {
    if (rolelist.data && rolelist.data.length > 0) {
      const { GivenName, Prefix, SurName, Email } = data;
      let rname = '';
      try {
        if (Prefix) {
          rname = `${Prefix} replace`;
        }
        if (GivenName) {
          rname =
            rname == ''
              ? GivenName
              : `${rname.replace('replace', GivenName)} replace`;
        }
        if (SurName) {
          rname = rname == '' ? SurName : rname.replace('replace', SurName);
        }
        rname = rname.replace('replace', '');
        const roledet = rolelist.data
          .filter(x => x.roleacronym == 'AUTHOR')
          .map(item => item.roleid);
        const pushobj = {
          email: Email,
          name: rname,
          role: roledet[0],
          roleAcronym: 'AUTHOR',
        };
        users.push(pushobj);
        if (users && users.length > 0) {
          resolve({ issuccess: true, data: users });
        } else {
          resolve({ issuccess: false, data: users });
        }
      } catch (e) {
        resolve({ issuccess: false, data: {} });
      }
    } else {
      resolve({ issuccess: false, data: {} });
    }
  });
};

// const generateExternaluser = async data => {
//   const users = [];
//   const rolelist = await getAllRole();
//   if (rolelist.data && rolelist.data.length > 0) {
//     return new Promise(resolve => {
//       const extuser = data;
//       const extdata = extuser
//         .filter(f => f['__WOAttr__contrib-type'] == 'author')
//         .map(md => {
//           const contype = md['__WOAttr__contrib-type'];
//           const corresp = md.__WOAttr__corr;
//           let remail = '';
//           let rname = '';
//           // const roleid = 0;
//           if (contype == 'author' && (corresp == 'yes' || corresp == 1)) {
//             remail = md.email.__WOText__;

//             if (remail == undefined) {
//               const maildtl = md.email.filter(
//                 x => x.__WOAttr__primary == 'True',
//               );
//               if (maildtl.length > 0) {
//                 remail = maildtl[0].__WOText__;
//               }
//             }

//             if (md.name.prefix) {
//               rname = `${md.name.prefix}replace`;
//             }
//             if (md.name['given-name']) {
//               rname =
//                 rname == ''
//                   ? md.name['given-name']
//                   : `${rname.replace(
//                       'replace',
//                       md.name['given-name'],
//                     )} replace`;
//             }
//             if (md.name.surname) {
//               rname =
//                 rname == ''
//                   ? md.name.surname
//                   : rname.replace('replace', md.name.surname);
//             }
//             rname = rname.replace('replace', '');

//             const roledet = rolelist.data
//               .filter(x => x.roleacronym == 'AUTHOR')
//               .map(item => item.roleid);
//             const pushobj = {
//               email: remail,
//               name: rname,
//               role: roledet[0],
//               roleAcronym: 'AUTHOR',
//             };
//             const eindex = users.findIndex(
//               object => object.roleAcronym == 'AUTHOR',
//             );
//             if (eindex === -1) {
//               users.push(pushobj);
//             }
//             console.log(users);
//           }
//         });

//       if (extdata && extdata.length > 0) {
//         resolve({ issuccess: true, data: users });
//       } else {
//         resolve({ issuccess: false, data: users });
//       }
//     });
//   }
// };

// export const getWorkorderExcelData = async (req) => {
//   const resData = req.body;
//   const { InPath, customer } = req.body;
//   // let currentkey = woKeyConfig.cupexcelkeys;
//   const keyobj = JSON.parse(currentkey);
//   const filepath =
//     'C:/Users/is9825/Desktop/New folder/file_example_XLSX_10.xlsx';

//   let currentkey = '';
//   switch (customer) {
//     case 'CUP':
//       currentkey = woKeyConfig.cup_excelkeys;
//       break;
//     case 'EMERALD':
//       currentkey = woKeyConfig.emerald_excelkeys;
//   }

//   const result = excelToJson({
//     sourceFile: InPath,
//   });
//   const excelrst = [];
//   if (result.Sheet1.length > 0) {
//     const FirstRow = result.Sheet1.shift();
//     const Headers = Object.values(FirstRow);
//     result.Sheet1.forEach(element => {
//       const values = Object.values(element);
//       const obj = {};
//       Headers.forEach((val, index) => {
//         obj[val] = values[index];
//       });
//       excelrst.push(obj);
//     });
//   }
//   console.log(excelrst);
//   let val_journalid = '';
//   let val_journaltitle = '';
//   let val_issn = '';

//   excelrst.forEach(val => {
//     // let dval = Object.values(val);
//     const xval = val;
//     val_journalid = val[keyobj.Journalid];
//     val_journaltitle = val[keyobj.Journaltitle];
//     val_issn = val[keyobj.issn];
//     console.log(dval);
//   });
// };

const readKeyvalue = (keytext, xmlobject) => {
  try {
    logger.info(keytext, 'keytext');
    logger.info(xmlobject, 'xmlobject');

    logger.info(typeof keytext, 'typeof keytext');
    logger.info(process.version, 'node version');

    const keyereplace = keytext.replace(/","/g, '"_"');
    logger.info(keyereplace, 'keyereplace1');

    // const keyereplaceold = keytext.replaceAll('","', '"_"');
    // logger.info(keyereplaceold,'keyereplace');

    const splitkey = keyereplace.split(',');
    let currxmlobj = xmlobject;
    let indexplus = 0;
    let nextkeyindex = 0;
    logger.info(splitkey, 'splitkey');

    for (let index = 0; index < splitkey.length; index++) {
      // splitkey[indexplus] = splitkey[indexplus].replaceAll("\"_\"", "\",\"");
      if (index > 0) {
        // indexplus = index + 1;
        indexplus = nextkeyindex + 1;
      }

      let currentkey = '';
      let currentattribute = '';
      let nextkey = '';
      let nextattribute = '';

      let attrstartindex = -1;
      let attrlastindex = -1;
      if (indexplus < splitkey.length) {
        if (splitkey[indexplus] && splitkey[indexplus].indexOf('{') == -1) {
          currentkey = splitkey[indexplus];
        } else {
          attrstartindex = splitkey[indexplus].indexOf('{');
          attrlastindex = splitkey[indexplus].indexOf('}') + 1;

          currentkey = splitkey[indexplus].substring(0, attrstartindex);
          currentattribute = splitkey[indexplus].substring(
            attrstartindex,
            attrlastindex,
          );
        }

        if (indexplus + 1 < splitkey.length) {
          nextkeyindex = indexplus + 1;

          //  splitkey[indexplus+1] = splitkey[indexplus+1].replaceAll("\"_\"", "\",\"");
          if (splitkey[indexplus + 1].indexOf('{') == -1) {
            nextkey = splitkey[indexplus + 1];
          } else {
            attrstartindex = splitkey[indexplus + 1].indexOf('{');
            attrlastindex = splitkey[indexplus + 1].indexOf('}') + 1;

            nextkey = splitkey[indexplus + 1].substring(0, attrstartindex);

            nextattribute = splitkey[indexplus + 1].substring(
              attrstartindex,
              attrlastindex,
            );
          }
        }
        const retrivedobject = reccall(
          currentkey,
          currxmlobj,
          currentattribute,
        );
        // const retrivedobject_old = currxmlobj[currentkey];
        console.log(retrivedobject);
        logger.info(retrivedobject, 'retrivedobject');

        if (retrivedobject && nextkey != '') {
          logger.info(retrivedobject, 'retrivedobject if');

          if (Object.keys(retrivedobject).length > 0) {
            const retcontent = reccall(nextkey, retrivedobject, nextattribute);
            if (nextkey === splitkey[splitkey.length - 1]) {
              console.log(retcontent, 'rettttt');
              //  const returnresult = typeof retcontent === 'string' ? retcontent :
              //       typeof retcontent === 'object' ? retcontent.length ? retcontent[0]['__WOText__'] : '':'';
              return retcontent;
            }
            currxmlobj = retcontent;
          }
        } else {
          logger.info(retrivedobject, 'retrivedobject else');

          if (
            typeof retrivedobject == 'object' &&
            Object.keys(retrivedobject).includes('__WOText__')
          ) {
            const resultobj1 = Object.keys(retrivedobject).includes(
              '__WOText__',
            )
              ? retrivedobject.__WOText__
              : retrivedobject;
            return resultobj1;
          }
          if (
            Array.isArray(retrivedobject) &&
            retrivedobject.length &&
            Object.keys(retrivedobject[0]).includes('__WOText__')
          ) {
            const resultobj2 = retrivedobject[0].__WOText__;

            return resultobj2;
          }
          return retrivedobject;
        }
      } else {
        console.log(currxmlobj);
        currxmlobj =
          currxmlobj.length > 0 &&
          Object.keys(currxmlobj[0]).includes('__WOText__')
            ? currxmlobj[0].__WOText__
            : currxmlobj;
        return currxmlobj;
      }
    }
  } catch (error) {
    logger.info(error, 'xml read error');
    return undefined;
  }
  return {};
};

const reccall = function (key, xmlobj, attributeType) {
  // attributeType = attributeType.replaceAll('"_"', '","');
  attributeType = attributeType.replace(/"_"/g, '","');

  let result = '';
  if (attributeType == '') {
    if (xmlobj.length == undefined) {
      result =
        xmlobj.length > 0
          ? xmlobj[0][key]
          : Object.keys(xmlobj).includes(key)
          ? xmlobj[key]
          : xmlobj;
    }
    if (xmlobj.length > 0) {
      if (
        xmlobj[0][key].length != undefined &&
        xmlobj[0][key].length > 1 &&
        Array.isArray(xmlobj[0][key])
      ) {
        // eslint-disable-next-line prefer-destructuring
        result = xmlobj[0][key][0];
      } else {
        result = xmlobj[0][key].__WOText__
          ? xmlobj[0][key].__WOText__
          : xmlobj[0][key];
        //  result = xmlobj[0][key];
      }
    }
  } else if (Object.keys(attributeType).length > 0) {
    const toFilter = JSON.parse(attributeType);
    const keys = Object.keys(toFilter);
    let objectof = {};

    objectof = Array.isArray(xmlobj)
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key]) && xmlobj.length > 0
      ? xmlobj[0][key]
      : Array.isArray(xmlobj[key])
      ? xmlobj[key]
      : [xmlobj[key]];

    if (Array.isArray(objectof)) {
      result = objectof.filter(x => {
        if (typeof x === 'object') {
          const matchs = keys
            .map(y => x[`__WOAttr__${y}`] == toFilter[y])
            .filter(z => z == true);
          return matchs.length == keys.length;
        }
        return '';
      });
      // console.log(result);
    } else if (typeof objectof === 'object') {
      let checkloop = true;
      keys.forEach(element => {
        if (objectof[`__WOAttr__${element}`] == toFilter[element]) {
          console.log(objectof[`__WOAttr__${element}`]);
        } else {
          console.log('failed');
          checkloop = false;
        }
      });

      if (checkloop == true && objectof.__WOText__) {
        result = objectof.__WOText__;
      } else {
        result = '';
      }
    }
  }
  console.log(result);
  return result;
};

export const readXMLData = (wofilename, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      readFile(wofilename, { encoding: 'utf-8' }, (err, xmlData) => {
        if (err) {
          this.emit('error', err);
          return;
        }

        const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
        xmlobjdata = xmlObj;
        resolve(xmlobjdata);
      });
    } catch (error) {
      reject(error);
    }
  });
};
const readXMLDatafromContent = (xmlData, wxmlconfig) => {
  return new Promise((resolve, reject) => {
    let xmlobjdata = [];
    try {
      const xmlObj = xmlParser.parse(xmlData, wxmlconfig);
      xmlobjdata = xmlObj;
      resolve(xmlobjdata);
    } catch (error) {
      reject(error);
    }
  });
};

const getAllRole = () => {
  return new Promise(resolve => {
    const sql = `select roleid,rolename,roledescription,roleacronym from public.wms_role where isactive = true`;
    query(sql)
      .then(response => {
        resolve({ issuccess: true, data: response });
      })
      .catch(() => {
        resolve({ issuccess: false, data: {} });
      });
  });
};

const getCustomerJournalDetail = data => {
  const { customer, journalAcronym } = data;
  return new Promise((resolve, reject) => {
    const sql = `select a.colorid as colours ,a.softwareid as softwares ,a.languageid as languages ,a.celevelid as  "CELevel",a.printissn as "printISSN" , 
         b.divisionid as division ,b.subdivisionid as "subDivision",b.countryid as country ,b.customerid as  customer,d.duid as "duId",
         a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
         a.journalid as "journalId"
         from pp_mst_journal a  
         JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
         JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
         JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid
         JOIN org_mst_customer e on e.customerid=b.customerid 
         where a.isactive = 1 AND b.isactive = 1
         AND (LOWER(e.customername) = LOWER('${customer}')
         or  LOWER(e.customershortname) = LOWER('${customer}')
         )
        AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;

    console.log(sql, 'sql for getJournalDetail');
    query(sql)
      .then(response => {
        resolve(response);
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};

export const getIdFromName = data => {
  const { value, keyconfig } = data;
  const tblkeys = JSON.parse(woKeyConfig.tableKeyConfig);
  const splitval = tblkeys[0][keyconfig].split(',');
  const tableName = splitval[0];
  const columnName = splitval[1];
  const primaryId = splitval[2];

  return new Promise((resolve, reject) => {
    let sql = ``;
    // SELECT customerid as value, customername as label FROM public.org_mst_customer
    sql = `SELECT ${primaryId} as colval FROM ${tableName} WHERE ${columnName} = '${value}' AND isactive = true`;

    query(sql)
      .then(response => {
        const id = response.length ? response[0].colval : '';
        resolve(id);
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};

export const getAutoemailLogdetails = (req, res) => {
  const sql = 'select * from get_autoemail_log()';
  let resobject = [];
  query(sql)
    .then(response => {
      if (
        response != undefined &&
        response.length > 0 &&
        response[0].j.length != undefined
      ) {
        resobject = response[0].j;
      }
      res.send(resobject);
    })
    .catch(() => {
      res.sen({});
    });
};
/*
const getWorkOrderDetail_Itemcode = async itemcode => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select wo.workorderid,wo.dmsid,dms.dmstype  from wms_workorder as wo
            left join dms_master as dms on dms.dmsid = wo.dmsid and dms.isactive = true
            where wo.isactive = true and itemcode = $1`;
      const articledetails = await query(sql, [itemcode]);
      resolve(articledetails);
    } catch (e) {
      reject(e);
    }
  });
}; */

export const getWfEventDetailsForWo = async (
  itemcode,
  stage,
  stageiterationcount,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select  wo.workorderid,ev.wfeventid,ev.woincomingfileid,stg.stagename,act.activityname 
      from  wms_workorder as wo
      join wms_workflow_eventlog as ev on ev.workorderid = wo.workorderid and ev.stageiterationcount = case when ${stageiterationcount}>1 then ${stageiterationcount}-1 else 1 end 
      join wms_workflowdefinition as wfd on wfd.wfdefid = ev.wfdefid 
      join wms_mst_stage as stg on stg.stageid = wfd.stageid
      join wms_mst_activity as act on act.activityid = wfd.activityid
    where wo.itemcode = $1 and stg.stagename = $2 and trim(act.activityname) = 'Completion Trigger'`;
      const eventdetails = await query(sql, [itemcode, stage]);
      resolve(eventdetails);
    } catch (e) {
      logger.info(e, 'event details for wo');
      reject(e);
    }
  });
};
export const getworkorderdetail_bystage = async (itemcode, stage) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `SELECT distinct wo.workorderid,wo.itemcode, st.stageid, st.stagename, srv.serviceid,srv.servicename,du.duid,du.duname,
      cust.customerid ,cust.customername,winf.woincomingfileid 
      FROM public.wms_workorder AS wo
      JOIN public.wms_workorder_stage AS wos ON wo.workorderid = wos.workorderid
      JOIN public.wms_mst_stage AS st ON st.stageid = wos.wfstageid AND st.isactive = true
      JOIN public.org_mst_customer AS cust ON cust.customerid = wo.customerid AND cust.isactive= true
      JOIN public.wms_mst_service AS srv ON srv.serviceid = wos.serviceid AND srv.isactive = true
      JOIN public.org_mst_customer_orgmap AS orgmap on orgmap.customerid = wo.customerid 
      and orgmap.divisionid = wo.divisionid and orgmap.subdivisionid = wo.subdivisionid and 
      orgmap.countryid = wo.countryid and orgmap.isactive = 1
      join public.org_mst_customerorg_du_map custdu on custdu.custorgmapid = orgmap.custorgmapid
      join public.org_mst_deliveryunit as du on du.duid = custdu.duid and du.isactive = true
      join public.wms_workorder_incoming wi on wi.woid = wo.workorderid
      join public.wms_workorder_incomingfiledetails winf on winf.woincomingid = wi.woincomingid
      WHERE wo.itemcode = $1 AND st.stagename = $2`;
      const articledetails = await query(sql, [itemcode, stage]);
      resolve(articledetails);
    } catch (e) {
      reject(e);
    }
  });
};

const isWoCompleted = filenames => {
  return new Promise(async (resolve, reject) => {
    try {
      // const placeholders = Array(filenames.length).fill('filenames').join(',');
      // const sql = `SELECT count(wo.workorderid) FROM public.wms_workorder wo JOIN public.wms_workorder_stage wos ON wo.workorderid = wos.workorderid WHERE wo.itemcode = '${fname}' AND wos.wfstageid = 12 AND wos.status = 'Completed'`;
      const sql = `SELECT count(wo.workorderid) FROM public.wms_workorder wo JOIN public.wms_workorder_stage wos ON wo.workorderid = wos.workorderid WHERE wo.itemcode IN ('${filenames.join(
        "','",
      )}') AND wos.wfstageid = 12 AND wos.status = 'Completed'`;

      const res = await query(sql);

      if (filenames.length == Number(res[0].count)) {
        resolve({ issuccess: true, data: res });
      } else {
        resolve({ issuccess: false, data: res });
      }
    } catch (e) {
      logger.info(e, 'err in WO creation');
      reject(e);
    }
  });
};

const checkworkorderstatus = async doinumber => {
  // let doiarray = JSON.parse(doinumber)
  const doiarray = doinumber;
  // console.log(doiarray);
  return new Promise(async resolve => {
    const tsql = `update public.wms_workorder set status = 'Completed'
    WHERE doinumber IN ('${doiarray.join("','")}')`;

    await query(tsql);

    const sql = `SELECT 
     COUNT(wo.doinumber) AS alljobstatus
     FROM public.wms_workorder wo    
     WHERE  wo.status = 'Completed' AND wo.doinumber IN ('${doiarray.join(
       "','",
     )}')`;

    const res = await query(sql);
    if (res != undefined && res.length > 0) {
      if (doinumber.length == Number(res[0].alljobstatus)) {
        resolve({ issuccess: true, data: res });
      } else {
        resolve({ issuccess: false, data: res });
      }
    } else {
      resolve({ issuccess: false, data: [] });
    }
  });
};

export const checkFtpWatcherIdleNotification = async (req, res) => {
  let outputmessage = '';
  try {
    const sql = `select duname,to_char(createdon, 'yyyy-mm-dd hh24:mi:ss') as createdon, difference, case when difference > 6 then true else false end as latehours from 
            (select duname,  max(createdon) as createdon,
            ((extract(epoch from  now() - max(createdon) ) / 60)/60)::numeric(10,2)  as difference
            from public.ftp_audit_wo_creation group by duname
            ) as res`;

    const resdata = await query(sql);

    if (resdata && resdata.length) {
      for (let index = 0; index < resdata.length; index++) {
        const islatehour = resdata[index].latehours;
        if (islatehour) {
          const objparam = {
            customershortname: resdata[index].duname,
            lastcreatedon: resdata[index].createdon,
            hoursdifference: resdata[index].difference,
          };
          const mres = await mailTriggerForWatcherIdle(objparam);
          console.log(mres);
        }
      }
    }
    outputmessage = 'completed';
  } catch (er) {
    console.log(er);
    outputmessage = er.message;
  } finally {
    res.status(200).send({ outputmessate: outputmessage });
  }
};
