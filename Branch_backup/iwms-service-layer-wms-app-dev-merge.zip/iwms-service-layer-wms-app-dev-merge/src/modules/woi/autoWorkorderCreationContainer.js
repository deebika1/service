/* eslint-disable no-unused-vars */
import { transaction, query } from '../../database/postgres.js';
import { _upload } from '../utils/azure/index.js';
import { emitAction } from '../activityListener/index.js';
import { getNotificationConfig } from '../common/index.js';
import { kliSchema } from './schema.js';
import { validator } from '../../helper/validator.js';
import { createJob, checkItracksExits } from '../iTracks/index.js';
import { _autoIncomingCreationFromAPI } from './incoming.js';
import { workorderlog } from './woAutocreation.js';
import logger from '../utils/logs/index.js';
import { Service } from '../../httpClient/index.js';
import { config } from '../../config/restApi.js';

const service = new Service();

const jobTypeObj = {
  1: 'Article',
  2: 'Issue',
  3: 'Non Article',
};
let mailContainer = {
  action: '',
  from: '',
  to: '',
  customerName: '',
  customerId: '',
  stageName: '',
  iteration: '',
  subject: '',
  template: '',
  text: '',
};
let logId = 0;
// E to E Integration for WK-KLI
// Work order creation from API trigger based on payload
export const workorderCreationFromE2EAPI = async (req, res) => {
  try {
    await _workorderCreationFromE2EAPI(req.body);
    res
      .status(200)
      .send({ status: true, message: 'Workorder created successfully' });
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};

export const _workorderCreationFromE2EAPI = async data => {
  return new Promise(async (resolve, reject) => {
    const { issueDetails, articleDetails, generalDetails } = data;
    let payload = {
      ...generalDetails,
    };
    try {
      const logRes = await woCreateLog(data, 'Insert');
      logId = logRes.autologid;
      logger.info(data, 'workorderCreationFromE2EAPI');
      // for loop for multiple article details
      for (let i = 0; i < articleDetails.length; i++) {
        let item = articleDetails[i];
        // get extention with dot from file name
        const ext = item.extention.lastIndexOf('.')
          ? item.extention.substr(item.extention.lastIndexOf('.'))
          : item.extention;
        item.extention = ext;
        item = { ...item, ...generalDetails };
        item.issueDetails = issueDetails;
        // construct payload for workorder creation
        payload = await constructPayloadForWorkorderCreation(item);
      }
      const promises = [];
      // Make multiple API calls in a loop
      articleDetails.forEach(async item => {
        promises.push(makeApiCallInLoop(payload));
      });
      // Use Promise.all() to wait for all promises to resolve
      Promise.all(promises)
        .then(results => {
          logger.info(results, 'results');
          resolve({
            message: 'Workorder created successfully',
            status: true,
          });
        })
        .catch(e => {
          reject({
            message: e.message ? e.message : e,
            status: false,
          });
        });
    } catch (e) {
      if (mailContainer.action === 'common_failure') {
        // get customer details from customer name
        const sql = `SELECT customerid FROM org_mst_customer WHERE LOWER(customername) = LOWER('${payload.customer}')`;
        const response = await query(sql);
        const customerId = response.length ? response[0].customerid : 0;
        mailContainer.customerId = customerId;
        mailContainer.subject = `Work order creation failed for due to journal details not found for the customer ${payload.customer}`;
        mailContainer.message = `Journal details not found for the customer ${payload.customer}`;
      }
      if (mailContainer.customerId) {
        await sendMail(mailContainer);
      }
      reject({
        message: e.message ? e.message : e,
        status: false,
      });
    }
  });
};

// workorder create log
const woCreateLog = (data, action) => {
  return new Promise(async (resolve, reject) => {
    try {
      let sql = ``;
      if (action == 'Insert') {
        sql = `INSERT INTO log_autowocreate(apiinput) VALUES ('${JSON.stringify(
          data,
        )}') RETURNING autologid`;
      } else {
        const {
          customerName,
          fileType,
          woType,
          workorderId,
          logMessage,
          isSuccess,
          isStagetrigger,
          articleName,
          stageName,
        } = data;
        sql = `UPDATE public.log_autowocreate
        SET customer='${customerName}', filetype='${fileType}', wotype='${woType}', jobtype='${fileType}', payload='${JSON.stringify(
          data,
        )}', workorderid=${
          workorderId || null
        }, logmessage='${logMessage}', issuccess=${isSuccess}, isstagetrigger=${
          isStagetrigger || false
        }, trigerarticle='${articleName}', trigerstage='${stageName || null}'
        WHERE autologid=${logId} RETURNING autologid`;
      }
      const response = await query(sql);
      resolve(response[0]);
    } catch (e) {
      reject(e);
    }
  });
};

// construct payload for workorder creation
const constructPayloadForWorkorderCreation = async item => {
  return new Promise(async (resolve, reject) => {
    const { customerName } = item;
    try {
      // get journal information from customer and journal acronym
      const journalDetail = await getCustomerJournalDetail(item);
      if (journalDetail) {
        // change string to integer from journalDetails array
        journalDetail.customer = parseInt(journalDetail.customer);
        journalDetail.division = parseInt(journalDetail.division);
        journalDetail.subDivision = parseInt(journalDetail.subDivision);
        journalDetail.country = parseInt(journalDetail.country);
        journalDetail.duId = parseInt(journalDetail.duId);
        journalDetail.colours = parseInt(journalDetail.colours);
        journalDetail.softwares = parseInt(journalDetail.softwares);
        journalDetail.languages = parseInt(journalDetail.languages);
        journalDetail.CELevel = parseInt(journalDetail.CELevel);
        journalDetail.journalId = parseInt(journalDetail.journalId);
        journalDetail.custOrgMapId = parseInt(journalDetail.custOrgMapId);
        journalDetail.services = journalDetail.serviceId;
        journalDetail.custPrimaryContact = journalDetail.primaryContact;
        journalDetail.custSecondaryContact = journalDetail.secondaryContact;
        journalDetail.kamName = journalDetail.KAMContact;
        journalDetail.clientManager = journalDetail.CMContact;
        // create payload for workorder creation
        const payload = {
          ...item,
          ...journalDetail,
          customerId: journalDetail.customer,
          userId: item.createdBy,
          doiNumber: item.articleName,
          jobId: item.articleName,
          jobTitle: item.articleTitle,
          externalUsers: [
            {
              name: item.authorName,
              role: '7',
              email: item.authorMailId,
              roleAcronym: 'AUTHOR',
            },
          ],
          noOfChapters: 1,
          piiNumber: '',
          // journalAcronym: journalDetail.journalId,
          // emailOrderDate: item.receivedDate,
          // orderEmailPath: '',
          // orderEmailPathUuid: '',
          // inputFileTypes: 4,
          // edition: '1',
          // category: 1,
          // noOfChapters: 1,
          // indexType: 1,
          // noOfArticles: null,
          // noOfNonArticles: null,
          pageWidth: 1,
          pageWidthUnit: 'in',
          pageHeight: 11,
          pageHeightUnit: 'in',
          msPages: item.msPages,
        };
        resolve(payload);
      } else {
        mailContainer.action = 'common_failure';
        mailContainer.subject = `Work order creation failed for due to journal details not found for the customer ${customerName}`;
        mailContainer.message = `Journal details not found for the customer ${customerName}`;
        throw new Error(
          `Journal details not found for the customer ${customerName}`,
        );
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Make API call in loop with promise all using axios for workorder creation
const makeApiCallInLoop = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // check iTracks exists for customer
      const iPayload = {
        customerId: payload.customer,
        duId: payload.duId,
        userId: payload.createdBy,
      };
      const { status } = await checkItracksExits({ body: iPayload }, {});
      if (status) {
        // fields validation with specific error messages for workorder creation
        if (!payload) {
          throw new Error('Payload is required');
        }
        const validate = validator(payload, kliSchema);
        if (!validate.status) {
          throw new Error(validate.message);
        }
        // check title already exists
        const woExists = await checkWOExists(payload);
        // create job card in iTracks
        const { status: jobStatus } = await createJob(payload);
        if (jobStatus) {
          const result = await autoWorkorderCreation(payload);
          const { data, message } = result;
          // const data = {
          //   workorderid: '2317',
          //   serviceid: '1',
          //   issuemstid: '2',
          // };
          // auto incoming creation
          const incomingPayload = await constructIncomingPayload(payload, data);
          logger.info('before auto incoming creation');
          const resOfIncoming = await _autoIncomingCreationFromAPI(
            incomingPayload,
          );
          // Mail trigger for success
          mailContainer = {
            action: 'auto_create_success',
            articlename: payload.articleName,
            to: [],
            customerId: payload.customer,
            workorderId: data.workorderid,
            serviceId: data.serviceid,
            duId: payload.duId,
            message,
            subject: `Work order created successfully for the title - ${payload.articleName}`,
          };
          // payload for workorder log
          payload.logMessage = message;
          payload.isSuccess = true;
          payload.workorderId = data.workorderid;
          payload.stageName = resOfIncoming.data.stageName;
          payload.stageId = resOfIncoming.data.stageId;
          payload.iteration = resOfIncoming.data.iteration;
          payload.isStagetrigger = true;
          await woCreateLog(payload, 'Update');
          await sendMail(mailContainer);
          resolve({ status: true, message });
        } else {
          throw new Error('Job creation failed in iTracks');
        }
      } else {
        mailContainer.action = 'common_failure';
        mailContainer.subject = `Work order creation failed for due to iTracks not found for the customer ${payload.customerName}`;
        mailContainer.message = `iTracks not found for the customer ${payload.customerName}`;
        mailContainer.customerId = payload.customer;
        throw new Error('iTracks not found for customer');
      }
    } catch (e) {
      // Mail trigger for error
      mailContainer = {
        action: 'auto_create_failure',
        articlename: payload.articleName,
        to: [],
        customerId: payload.customer,
        duId: payload.duId,
        serviceId: payload.services,
        subject: `Work order creation failed for the title - ${payload.articleName}`,
        message: e.message ? e.message : e,
      };
      // payload for workorder log
      payload.logMessage = e.message ? e.message : e;
      payload.isSuccess = false;
      await woCreateLog(payload, 'Update');
      await sendMail(mailContainer);
      reject(e);
    }
  });
};

export const checkWOExists = data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobId, doiNumber } = data;
      const job = jobId ? jobId.trim() : '';
      const doi = doiNumber ? doiNumber.trim() : '';
      let condition = `WHERE itemcode='${job}'`;
      if (doi) {
        condition = `WHERE itemcode='${job}'  OR doinumber='${doi}'`;
      }
      logger.info(condition, 'where condition');
      const sql = `SELECT itemcode FROM public.wms_workorder ${condition} `;
      console.log(sql, 'sql for wo exists');
      const result = await query(sql);
      if (result.length) {
        reject({
          status: false,
          message: `Workorder already exists for the title - ${jobId}`,
        });
      } else {
        resolve({ status: true, message: 'Workorder not exists' });
      }
    } catch (e) {
      reject(e);
    }
  });
};

// Mail trigger
const sendMail = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        action,
        articlename,
        to,
        customerId,
        workorderId,
        serviceId,
        duId,
        message,
      } = data;
      let payload = {
        entityId: 2,
        actionType: action,
        duId,
        customerId,
        workorderId,
        serviceId,
      };
      const resForConfig = await getNotificationConfig(payload, action);
      const { type, notificationconfig } = resForConfig[0];
      const toMailArray = notificationconfig.to.concat(to);
      payload = {
        actionType: type,
        ...notificationconfig,
        jobId: articlename,
        subMessage: message,
        toMail: toMailArray,
      };
      emitAction(payload);
      resolve({ status: true, message: 'Mail sent successfully' });
    } catch (e) {
      console.log(e, 'ee');
      reject({ status: false, message: 'Mail sent failed' });
    }
  });
};

// get journal details from customer and journal acronym
const getCustomerJournalDetail = data => {
  const { customerName, journalAcronym } = data;
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `select a.colorid::bigint as colours ,a.softwareid::bigint  as softwares ,a.languageid::bigint as languages ,a.celevelid::bigint as  "CELevel",a.printissn as "printISSN" ,
        b.divisionid::bigint as division ,b.subdivisionid::bigint as "subDivision",b.countryid::bigint as country ,b.customerid::bigint as  customer,d.duid as "duId",
        a.pmid as "projectManager", a.supplierpmid as "supplierProjectManager", c.serviceid as "serviceId" , b.custorgmapid as "custOrgMapId",
        a.journalid as "journalId",
        (select  JSON_AGG(JSON_BUILD_OBJECT('custorgconmapid',custorgconmapid,'contacttype',contacttype,'contactroleid',contactroleid, 'isprimary', isprimary)) from (select * from org_mst_customerorg_contact where custorgmapid=292 ) as contacts) as contacts
        from pp_mst_journal a
              JOIN org_mst_customer_orgmap b on a.custorgmapid = b.custorgmapid
              JOIN org_mst_customerorg_service_map c on c.custorgmapid = a.custorgmapid
              JOIN org_mst_customerorg_du_map d on d.custorgmapid =  a.custorgmapid
              JOIN org_mst_customer e on e.customerid=b.customerid
              where a.isactive = 1 AND b.isactive = 1
              AND (LOWER(e.customername) = LOWER('${customerName}')
              or  LOWER(e.customershortname) = LOWER('${customerName}')
              )
              AND LOWER(a.journalacronym) = LOWER('${journalAcronym}')`;

      console.log(sql, 'sql for getJournalDetail');
      const response = await query(sql);
      if (response.length) {
        const journalInfo = response[0];
        journalInfo.contacts.forEach(list => {
          if (list.isprimary && list.contacttype === 'Customer') {
            journalInfo.primaryContact = list.custorgconmapid;
          } else if (!list.isprimary && list.contacttype === 'Customer') {
            journalInfo.secondaryContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'KAM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.KAMContact = list.custorgconmapid;
          } else if (
            list.contactroleid === 'CM' &&
            list.contacttype === 'Integra'
          ) {
            journalInfo.CMContact = list.custorgconmapid;
          }
        });
        resolve(journalInfo);
      } else {
        reject({
          message: `Journal details not found for the customer ${customerName} `,
        });
      }
    } catch (e) {
      reject(e);
    }
  });
};
// auto workorder, service, stage creation with transaction
const autoWorkorderCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      // transaction for workorder, service, stage creation
      let responseOfWoCreation = { status: false, message: '' };
      await transaction(async client => {
        responseOfWoCreation = await workorderCreation(payload, client);
      });
      resolve(responseOfWoCreation);
    } catch (e) {
      logger.info(e, 'ee');
      reject(e);
    }
  });
};
// Workorder creation with transaction
const workorderCreation = async (data, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { articleName, piiNumber, emailOrderDate } = data;
      const otherFileds = articleName
        ? `{"articleno": "${articleName}", "pii": "${piiNumber}" }`
        : null;
      const orderDate = emailOrderDate
        ? `'${emailOrderDate}'`
        : 'current_timestamp';

      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          if (data[key] === undefined) {
            data[key] = null;
          }
        }
      }
      // check creation type for workorder
      const resultObj = { status: true, message: '' };
      if (data.containerType == 'e2e') {
        // check issue name in issue master table
        const sql = `SELECT issuemstid FROM pp_mst_issue_master WHERE issuename = '${data.issueDetails.issueName}'`;
        const issueResult = await query(sql);
        if (issueResult.length) {
          resultObj.status = true;
          data.issueDetails.issueId = issueResult[0].issuemstid;
        } else {
          resultObj.status = false;
          resultObj.message = 'Issue name not found';
        }
      }

      if (resultObj.status) {
        // insert query for workorder creation in wms_workorder table
        let sql = `INSERT INTO public.wms_workorder(
        itemcode, title,projectbrief,printisbn, eisbn, issn, edition,customerid, 
        divisionid, subdivisionid, countryid, colorid, composingsoftwareid, inputfiletypeid, 
        languageid, celevelid, indextypeid,category, status, trimsizewidth, trimsizewidthuom,
        trimsizeheight, trimsizeheightuom, orderemailpath, orderemailpathuuid, totalchaptercount, 
        ordermaildate, journalid, jobtype, doinumber, wotype, totalarticlecount, totalnonarticlecount, issuenumber, volumenumber, jobcardid, iworkflow, paperbackisbn, hardbackisbn, ocisbn, otherfield,logoid,dmsid, issuemstid, isonlineissue, ismscompleted, createdbyemail, createdby )
        VALUES ('${data.jobId}', '${data.jobTitle}','${
          data.projectBrief ? data.projectBrief : null
        }','${data.printISBN ? data.printISBN : null}',
        '${data.eISBN ? data.eISBN : null}', '${
          data.ISSN ? data.ISSN : null
        }', '${data.edition}',
            ${data.customer}, ${data.division}, ${data.subDivision},${
          data.country
        }, 
            ${data.colours}, ${data.softwares}, ${
          data.inputFileTypes ? data.inputFileTypes : 4
        },
            ${data.languages}, ${data.CELevel}, ${
          data.indexType ? data.indexType : null
        },
            ${data.category ? data.category : null}, 'In Process',${
          data.pageWidth ? data.pageWidth : null
        },'${data.pageWidthUnit}',
            ${data.pageHeight ? data.pageHeight : null},'${
          data.pageHeightUnit
        }','${data.orderEmailPath}','${data.orderEmailPathUuid}', 
            ${data.noOfChapters}, ${orderDate}, ${data.journalId}, ${
          data.jobType ? data.jobType : null
        }, '${data.doiNumber}',
            '${data.woType}', ${
          // eslint-disable-next-line radix
          !Number.isNaN(parseInt(data.noOfArticles)) ? data.noOfArticles : null
        },${
          // eslint-disable-next-line radix
          !Number.isNaN(parseInt(data.noOfNonArticles))
            ? data.noOfNonArticles
            : null
        }, '${data.issueNumber}', '${data.volumeNumber}', ${
          data.jobCardId ? data.jobCardId : null
        }, '${data.iWorkflow}', '${
          data.WoPaperBackISBN ? data.WoPaperBackISBN : null
        }','${data.WoHardBackISBN ? data.WoHardBackISBN : null}','${
          data.WoOcISBN ? data.WoOcISBN : null
        }',  
            '${otherFileds}',${data.logoid ? data.logoid : null},${
          data.dmsid ? data.dmsid : null
        }, ${data.issueDetails.issueId || null}, ${
          data.issueDetails.isOnlineIssue || false
        } ,${data.issueDetails.msComplete || false}, '${
          data.issueDetails.movedBy
        }', '${
          data.userId
        }' ) RETURNING workorderid, wfid, customerid, issuemstid`;
        const response = await query(sql);
        const { workorderid, issuemstid } = response[0];
        // insert query for workorder contact details in wms_workorder_contact table
        // get contact detsils from org_mst_customerorg_contact_map table
        const getContactValues = `SELECT ${workorderid},custorgconmapid, contactname,contactemail,contactphone1,contactphone2,contactroleid,contacttype,isprimary 
          FROM org_mst_customerorg_contact WHERE custorgconmapid IN (${
            data.custPrimaryContact
          },${data.custSecondaryContact},
              ${data.kamName},${data.clientManager} ${
          data.subDivision !== 9 ? `,'${data.projectManager}'` : ''
        }) `;
        logger.info(getContactValues, 'getContactValues');
        sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactid, contactname, contactemail, contactphone1, contactphone2, contactrole, contacttype, isprimary)
          ${getContactValues} 
          RETURNING workorderid`;
        logger.info(sql, 'sql wo contact');
        await client.query(sql);
        // insert query for pm entry to wms_workorder_contact table
        if (data.subDivision == 9) {
          const journalMappedPm = await workorderJournalMappedPmEntry(
            {
              projectManager: data.projectManager,
              supplierProjectManager: data.supplierProjectManager,
              workorderid,
            },
            client,
          );
          logger.info(journalMappedPm, 'journalMappedPm');
        }
        let externalUserRes = [];
        if (
          data.externalUsers &&
          Object.keys(data.externalUsers).length &&
          data.externalUsers !== '{}'
        ) {
          externalUserRes = await workorderExternalUserEntry(
            { externalUsers: data.externalUsers, workorderid },
            client,
          );
          logger.info(externalUserRes, 'externalUserRes');
        }
        const serviceResponse = await workorderServiceEntry(
          {
            duId: data.duId,
            services: data.services,
            custOrgMapId: data.custOrgMapId,
            workorderid,
            wfId: data.wfId,
          },
          client,
        );
        const { serviceid } = serviceResponse.data;
        await workorderStageEntry(
          {
            workorderid,
            wfId: data.wfId,
            serviceId: serviceid,
            userId: data.userId,
            plannedStartDate: data.plannedStartDate,
            plannedEndDate: data.articleDueDate,
            receivedDate: data.articleRecDate,
          },
          client,
        );
        // TAT calculation for stages
        await tatCalculationForStages(
          {
            workorderid,
            customerId: data.customer,
            journalId: data.journalId,
          },
          client,
        );
        // issue payload insert into wms_issue_payload table
        if (data.issueDetails.issueId) {
          await issuePayloadEntry(data.issueDetails, client);
        }
        resolve({
          data: { workorderid, serviceid, issuemstid },
          message: `workorder created successfully (${workorderid})`,
        });
      } else {
        reject({ message: resultObj.message });
      }
    } catch (e) {
      reject(e);
    }
  });
};

// journal mapped pm entry insert into wms_workorder_contact table
const workorderJournalMappedPmEntry = (payload, client) => {
  const { projectManager, supplierProjectManager, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      let sql = `
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${projectManager}' AND wms_userrole.roleid = 1
      UNION ALL
      SELECT ${workorderid}, wms_user.username as contactname, wms_user.useremail as contactemail, wms_user.userphone as contactphone1,
      wms_user.userid, wms_userrole.roleid, wms_role.roleacronym FROM wms_user
      JOIN wms_userrole ON wms_userrole.userid =  wms_user.userid
      JOIN wms_role ON wms_role.roleid =  wms_userrole.roleid
      WHERE wms_user.userid = '${supplierProjectManager}' AND wms_userrole.roleid = 9
      `;
      logger.info(sql, 'sql for get pm && spm users');
      const { rows } = await client.query(sql);
      let userArray = rows;
      if (projectManager == supplierProjectManager) {
        userArray = [].concat(rows, rows);
      }
      logger.info(userArray, 'userArray');
      const val = [];
      userArray.forEach((list, i) => {
        val.push(`(${workorderid},'${list.contactname}','${
          list.contactemail
        }','${list.contactphone1}',
    '${list.roleacronym}', 'Integra' , ${i == 0}, '${list.userid}',${
          list.roleid
        })`);
      });
      sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, 
    contactphone1, contactrole, contacttype, isprimary, userid, roleid)
    VALUES ${val} RETURNING workorderid`;
      logger.info(sql, 'sql for journal pm mapped');
      await client.query(sql);
      resolve({
        message: `Journal mapped pm added successfully (${workorderid})`,
      });
    } catch (e) {
      reject({ message: `Journal mapped pm added failed (${workorderid})` });
    }
  });
};
// external user entry insert into wms_workorder_contact table
const workorderExternalUserEntry = (payload, client) => {
  const { externalUsers, workorderid } = payload;
  return new Promise(async (resolve, reject) => {
    try {
      const val = [];
      externalUsers.forEach(list => {
        val.push(`(${workorderid},'${list.name}','${list.email}',${
          list.phone1 ? `'${list.phone1}'` : null
        },
              '${list.roleAcronym}', 'Customer' , false, ${list.role})`);
      });
      logger.info(val, 'values for external customer');
      const sql = `INSERT INTO public.wms_workorder_contacts(workorderid, contactname, contactemail, contactphone1, contactrole, contacttype, isprimary, roleid)
              VALUES ${val} RETURNING contactrole,contactname,contactemail `;
      logger.info(sql, 'sql for external customer');
      await client.query(sql);
      resolve({ message: `External user added successfully (${workorderid})` });
    } catch (e) {
      reject({ message: `External user added failed (${workorderid})` });
    }
  });
};
// workorder service entry insert into wms_workorder_service table
const workorderServiceEntry = (payload, client) => {
  const { duId, services, custOrgMapId, workorderid, wfId } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const getDataQuery = `SELECT org_mst_customerorg_service_map.serviceid,org_mst_deliveryunit.duid, org_mst_deliveryunit.duid as assignedduid, org_mst_deliveryunit.duid as internalbilling,true, ${workorderid}, ${wfId}, 'YTS' as status
      FROM org_mst_customerorg_service_map
      JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customerorg_service_map.custorgmapid
      JOIN org_mst_deliveryunit ON org_mst_deliveryunit.duid = org_mst_customerorg_du_map.duid
      WHERE  org_mst_customerorg_service_map.serviceid IN (${services}) AND org_mst_customerorg_service_map.custorgmapid = ${custOrgMapId}
      AND org_mst_deliveryunit.duid = ${duId}`;
      const sql = `INSERT INTO public.wms_workorder_service(serviceid, baseduid, assignedduid,internalbilling,iscustomerbillable ,workorderid, wfid, status)
      ${getDataQuery} RETURNING woserviceid, workorderid, serviceid`;
      logger.info(sql, 'sqlForServiceEntry');
      const { rows } = await client.query(sql);
      resove({
        message: `Service added successfully (${workorderid})`,
        data: { ...rows[0] },
      });
    } catch (e) {
      reject({ message: `Service added failed (${workorderid})` });
    }
  });
};
// workorder stage entry insert into wms_workorder_stage table
const workorderStageEntry = (payload, client) => {
  const {
    workorderid,
    wfId,
    serviceId,
    userId,
    plannedStartDate,
    plannedEndDate,
    receivedDate,
  } = payload;
  return new Promise(async (resove, reject) => {
    try {
      const sqlQuery = `with cte as (SELECT DISTINCT ON(stageid) stageid, sequence
      FROM wms_workflowdefinition
      WHERE wfid IN (${wfId}) AND lock = false ) select * from cte order by sequence`;
      logger.info(sqlQuery, 'sql for update');
      const { rows } = await client.query(sqlQuery);
      if (rows.length) {
        const values = [];
        rows.forEach((stage, i) => {
          if (i === 0) {
            values.push(
              `(${serviceId},${stage.stageid},'${userId}',${workorderid}, 'YTS', 1, ${stage.sequence}, current_timestamp, current_timestamp,'${plannedEndDate}', '${receivedDate}', '${receivedDate}')`,
            );
          } else {
            values.push(
              `(${serviceId},${stage.stageid},'${userId}',${workorderid}, 'YTS', 1, ${stage.sequence}, current_timestamp, null, null, null, null)`,
            );
          }
        });
        const sql = `INSERT INTO public.wms_workorder_stage(serviceid, wfstageid, updatedby, workorderid, status, stageiterationcount, sequence, updatedon, plannedstartdate, plannedenddate, ordermaildate, ordermaildatetime)
        VALUES ${values} RETURNING workorderid`;
        logger.info(sql, 'sqlForCreateWOS');
        await client.query(sql);
        resove({ message: `Stage added successfully (${workorderid})` });
      } else {
        reject({ message: `No stages found the workorder (${workorderid})` });
      }
    } catch (e) {
      reject({ message: `Stage added failed (${workorderid})` });
    }
  });
};
// TAT calculation update for stages in wms_workorder_stage table
const tatCalculationForStages = (payload, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { workorderid, customerId, journalId } = payload;
      const sql = `UPDATE wms_workorder_stage AS st SET plannedstartdate = cte.p_startdate ,plannedenddate = cte.p_duedate 
			FROM get_wo_autocreation_tat(${workorderid}::bigint,${customerId}:: bigint,${journalId}::bigint,1::integer) AS cte
			WHERE cte.p_wostageid = st.wostageid;`;
      logger.info(sql, 'sql for tat update');
      await client.query(sql);
      resolve({ message: 'Stage TAT updated successfully' });
    } catch (e) {
      reject({ message: 'Stage TAT updated failed' });
    }
  });
};
// issue payload entry insert into wms_issue_payload table
const issuePayloadEntry = (issueDetails, client) => {
  return new Promise(async (resolve, reject) => {
    try {
      // check issue payload already exists for the workorder id
      let issuePayloadSql = `SELECT issuemstid FROM public.wms_issue_payload WHERE issuemstid = ${issueDetails.issueId}`;
      const { rows } = await client.query(issuePayloadSql);
      if (rows.length === 0) {
        issuePayloadSql = `INSERT INTO public.wms_issue_payload(issuemstid, payload)
         VALUES (${issueDetails.issueId}, '${JSON.stringify(
          issueDetails,
        )}') RETURNING issuemstid`;
        await client.query(issuePayloadSql);
        resolve({ message: 'Issue payload added successfully' });
      } else {
        // update issue payload for the workorder id
        issuePayloadSql = `UPDATE public.wms_issue_payload SET payload = '${JSON.stringify(
          issueDetails,
        )}' WHERE issuemstid = ${issueDetails.issueId} RETURNING issuemstid`;
        await client.query(issuePayloadSql);
        resolve({ message: 'Issue payload updated successfully' });
      }
    } catch (e) {
      reject({ message: 'Issue payload added failed' });
    }
  });
};

// create auto issue workorder creation
export const constructPayloadForIssueWorkorderCreation = async payload => {
  return new Promise(async (resolve, reject) => {
    try {
      const { issueName, generalDetails } = payload;
      const payloadObj = {
        generalDetails,
      };
      // get issue details from issue master table
      let sql = `SELECT payload, wms_issue_payload.issuemstid FROM pp_mst_issue_master
      JOIN wms_issue_payload ON wms_issue_payload.issuemstid = pp_mst_issue_master.issuemstid
      WHERE LOWER(issuename) = LOWER('${issueName}')`;
      const response = await query(sql);
      if (response.length) {
        // get workorder count for the issue
        sql = `SELECT workorderid FROM public.wms_workorder WHERE issuemstid = ${response[0].issuemstid}`;
        const resultOfWOCount = await query(sql);
        const data = response[0].payload;
        payloadObj.issueDetails = response[0].payload;
        payloadObj.articleDetails = [
          {
            journalAcronym: data.journalAcronym,
            customerName: data.customerName,
            fileType: 'Issue',
            isHalfPage: false,
            articleName: data.issueName,
            articleTitle: data.issueTitle,
            issueNumber: data.issueNo,
            volumeNumber: data.volumeNo,
            msPages: data.msPages,
            articleRecDate: data.receivedDate,
            articleDueDate: data.dueDate,
            createdBy: data.createdBy,
            movedBy: data.movedBy,
            extention: '',
            noOfArticles: resultOfWOCount.length,
            noOfNonArticles: 0,
            articleCategory: '',
            authorName: data.authorName,
            authorMailId: data.authorMailId,
          },
        ];
        resolve(payloadObj);
      } else {
        throw new Error(`Issue details not found for the issue ${issueName}`);
      }
    } catch (e) {
      reject(e);
    }
  });
};
export const autoIssueWorkorderCreation = async (req, res) => {
  try {
    const payload = await constructPayloadForIssueWorkorderCreation(req.body);
    await _workorderCreationFromE2EAPI(payload);
    res.status(200).send({
      message: 'Issue Workorder created successfully',
      status: true,
    });
  } catch (e) {
    res.status(400).send({ status: false, message: e.message ? e.message : e });
  }
};
// create incoming payload for auto incoming creation
export const constructIncomingPayload = async (payload, data) => {
  return new Promise(async (resolve, reject) => {
    try {
      const { jobType, articleDueDate } = payload;
      const { workorderid, issuemstid } = data;
      const file = [
        {
          filetypeid: '',
          filetype: '',
          jobType: payload.jobType,
          filename: payload.articleName,
          extention: payload.extention,
          filepath: payload.sourcePath ? payload.sourcePath : null,
          fileuuid: '',
          duedate: payload.articleDueDate,
          mspages: payload.msPages,
          imagecount: 1,
          estimatedpages: 0,
          tablecount: 0,
          equationcount: 0,
          boxcount: 0,
          wordcount: 0,
          referencecount: 0,
          filesequence: payload.atrilceOrderId,
          ishalfpage: payload.isHalfPage,
        },
      ];
      if (jobType == '2') {
        const sql = `SELECT wif.filetypeid, filetype, 'Article', filename, filepath, fileuuid, duedate, mspages, imagecount, estimatedpages, tablecount, equationcount, boxcount, wordcount, referencecount, filesequence, ishalfpage FROM wms_workorder_incomingfiledetails as wif
        JOIN pp_mst_filetype as pf ON pf.filetypeid = wif.filetypeid
        WHERE woincomingid in (select woincomingid from public.wms_workorder_incoming where
          woid in (select workorderid from wms_workorder where issuemstid = ${issuemstid}))`;
        const filesArray = await query(sql);
        const fileSequences = await getFileSequenceForIssue(
          payload.articleName,
        );
        fileSequences.forEach(list => {
          filesArray.forEach(item => {
            if (list.articleName == item.filename) {
              item.filesequence = list.fileSequence;
            }
          });
        });
        filesArray.forEach(list => {
          file.push({
            filetypeid: list.filetypeid,
            filetype: list.filetype,
            jobType: list.jobtype,
            filename: list.filename,
            filepath: list.filepath,
            fileuuid: list.fileuuid,
            duedate: articleDueDate,
            mspages: list.mspages,
            imagecount: list.imagecount,
            estimatedpages: list.estimatedpages,
            tablecount: list.tablecount,
            equationcount: list.equationcount,
            boxcount: list.boxcount,
            wordcount: list.wordcount,
            referencecount: list.referencecount,
            filesequence: list.filesequence,
            ishalfpage: list.ishalfpage,
          });
        });
      }
      const incomingPayload = {
        workorderId: workorderid,
        containerType: payload.containerType,
        files: file,
        jobType: payload.jobType,
        fileType: payload.fileType,
      };
      resolve(incomingPayload);
    } catch (e) {
      reject(e);
    }
  });
};
// get article file sequence for issue
const getFileSequenceForIssue = issueName => {
  return new Promise(async (resolve, reject) => {
    try {
      // const response = [
      //   {
      //     articleName: 'EUCL_26',
      //     fileSequence: 4,
      //   },
      //   {
      //     articleName: 'EUCL_27',
      //     fileSequence: 3,
      //   },
      //   {
      //     articleName: 'EUCL_28',
      //     fileSequence: 1,
      //   },
      //   {
      //     articleName: 'EUCL_29',
      //     fileSequence: 2,
      //   },
      // ];
      // resolve(response);

      const url = config.e2e.base_url + config.e2e.uri.getIssueSequence;
      const payload = {
        issueName,
      };
      const result = await service.iPost(url, payload);
      const { status, message, data } = result;
      if (status) {
        resolve(data);
      } else {
        reject({ message });
      }
    } catch (e) {
      reject(e);
    }
  });
};
