import { basename, dirname } from 'path';
import moment from 'moment';
import axios from 'axios';
import { query, transaction } from '../../database/postgres.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import {
  triggerStageWorkflow,
  triggerBatchCompletion,
} from '../utils/wfTrigger/index.js';
import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import {
  getNotificationConfig,
  getAuthAccessWorflow,
} from '../common/index.js';
import {
  addSubJob,
  checkItracksExits,
  addSatge,
  relatedStageInfo,
} from '../iTracks/index.js';
import logger from '../utils/logs/index.js';
import { multipleInstance } from '../master/index.js';
import { renameBlob } from '../utils/azure/index.js';

const service = new Service();
const categories = {
  chapter: 'Chapterwise',
  book: 'Bookwise',
  article: 'Articlewise',
  issue: 'Issuewise',
};

export const queryWOStageChapters = async (
  category,
  incomingFileTypes,
  stageId,
  serviceId,
  stageIteration,
  woId,
) => {
  incomingFileTypes =
    category === 'Issuewise'
      ? incomingFileTypes.includes(10)
        ? (incomingFileTypes.splice(incomingFileTypes.indexOf(10), 1),
          incomingFileTypes)
        : incomingFileTypes
      : incomingFileTypes;
  let sql = `SELECT wms_workorder_incoming.woid, wms_workorder_incomingfiledetails.woincomingfileid as fileid, wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.filetypeid, pp_mst_filetype.filetype, pp_mst_filetype.allowsubfiletype,
    wms_workorder_incomingfiledetails.mspages, wms_workorder_incomingfiledetails.estimatedpages
    FROM public.wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid where wms_workorder_incoming.woid = $1 and wms_workorder_incomingfiledetails.filetypeid = any($2) ORDER BY fileid`;
  const incomingsData = await query(sql, [woId, incomingFileTypes]);
  sql = `SELECT * FROM public.wms_stage_chapter_details
    where workorderid = $1 and serviceid = $2 and stageid = $3 and stageiterationcount= $4 order by wfeventid asc`;
  const filesData = await query(sql, [
    woId,
    serviceId,
    stageId,
    stageIteration,
  ]);
  return getStageDetails(category, incomingsData, filesData);
};

//
export const queryWOStageFiles = async (
  category,
  incomingFileTypes,
  serviceId,
  woId,
) => {
  let sql = `SELECT wms_workorder_incoming.woid, wms_workorder_incomingfiledetails.woincomingfileid as fileid, wms_workorder_incomingfiledetails.filename, wms_workorder_incomingfiledetails.filetypeid, pp_mst_filetype.filetype, pp_mst_filetype.allowsubfiletype
    FROM public.wms_workorder_incoming
    join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
    join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid where wms_workorder_incoming.woid = $1 and wms_workorder_incomingfiledetails.filetypeid = any($2) ORDER BY fileid`;
  const incomingsData = await query(sql, [woId, incomingFileTypes]);
  sql = `SELECT * FROM public.wms_stage_chapter_details
    where workorderid = $1 and serviceid = $2 order by wfeventid asc`;
  const filesData = await query(sql, [woId, serviceId]);
  return getStageDetails(category, incomingsData, filesData);
};

const getStageDetails = (category, incomingsData, filesData) => {
  let stageDetails = [];
  switch (category) {
    case categories.chapter:
    case categories.article:
      stageDetails = getChapterData(incomingsData, filesData);
      break;
    case categories.book:
    case categories.issue:
      stageDetails = getBookData(incomingsData, filesData);
      break;
    default:
  }
  return stageDetails;
};

const getChapterData = (incomingsData, filesData) => {
  const files = [];
  for (let i = 0; i < incomingsData.length; i++) {
    const incomingData = incomingsData[i];
    const events = filesData.filter(
      fd => fd.woincomingfileid == incomingData.fileid,
    );
    const event = events[events.length - 1];
    console.log(event, 'eventevent');
    if (event) {
      const isCompletedChapter = !!event.iscompletiontriggeractivity;
      const isCTCreated = !!(
        event.iscompletiontriggeractivity &&
        event.activitystatus === 'Unassigned'
      );
      files.push({
        fileId: event.woincomingfileid,
        name: event.filename,
        type: event.filetype,
        wfeventId: event.wfeventid,
        isCompletedChapter,
        isCTCreated,
        stagename: `${event.stagename} (${event.stageiterationcount})`,
      });
    }
  }
  return { files };
};

const getBookData = (incomingsData, filesData) => {
  console.log(incomingsData, 'incomingsData');
  console.log(filesData, 'filesData');
  let isCTCreated = false;
  let isCompletedStage = false;
  let CTData = {};
  const files = [];
  for (let i = 0; i < incomingsData.length; i++) {
    const incomingData = incomingsData[i];
    files.push({
      id: incomingData.fileid,
      name: incomingData.filename,
      type: incomingData.filetype,
      filetypeid: incomingData.filetypeid,
      mspages: incomingData.mspages,
      estimatedpages: incomingData.estimatedpages,
    });
  }
  for (let j = 0; j < filesData.length; j++) {
    const event = filesData[j];
    if (!isCTCreated) {
      isCTCreated = !!(
        event.iscompletiontriggeractivity &&
        event.activitystatus === 'Unassigned'
      );
      CTData = {
        fileId: event.woincomingfileid,
        name: event.filename,
        type: event.filetype,
        wfeventId: event.wfeventid,
      };
    }
    if (!isCompletedStage) {
      isCompletedStage = !!event.iscompletiontriggeractivity;
    }
  }
  return { isCTCreated, isCompletedStage, CTData, files };
};

export const getWOStageLists = async (req, res) => {
  try {
    const { woId, pageNo, recordPerPage } = req.body;
    const offset = (pageNo - 1) * recordPerPage;
    let sql = `SELECT COUNT(*) FROM public.wms_wo_stagelist
        join wms_workorder_service on wms_workorder_service.serviceid = wms_wo_stagelist.serviceid and wms_workorder_service.workorderid = wms_wo_stagelist.workorderid
        join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
        WHERE wms_wo_stagelist.workorderid=$1 and wfstageid !=10 `;
    console.log('sql', sql);
    const [{ count }] = await query(sql, [woId]);
    console.log('count', count);
    sql = `SELECT *, 
      date_part('day'::text, CURRENT_TIMESTAMP::timestamp without time zone - coalesce(revisedenddatetime::timestamp without time zone, plannedenddate::timestamp without time zone)) AS overdue  
      from (SELECT wms_wo_stagelist.*, wms_workorder_service.wfid, wms_workflow.wfname, wms_workflow.wfcategory, wms_workflow.config as wfconfig FROM public.wms_wo_stagelist
        join wms_workorder_service on wms_workorder_service.serviceid = wms_wo_stagelist.serviceid and wms_workorder_service.workorderid = wms_wo_stagelist.workorderid
        join wms_workflow on wms_workflow.wfid = wms_workorder_service.wfid
        WHERE wms_wo_stagelist.workorderid=$1 and wfstageid !=10  ORDER BY wostageid ASC) as sageList ORDER BY sequence ASC, stageiterationcount ASC LIMIT $2 OFFSET $3`;
    const stageData = await query(sql, [woId, recordPerPage, offset]);
    logger.info(sql, 'sqqlfororo');
    res.status(200).json({ data: stageData, total: count });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const triggerMultipleInstance = async (req, res) => {
  const {
    selectedFiles,
    customerid,
    duId,
    woId,
    serviceId,
    wfStageId,
    stageIterationCount,
  } = req.body;

  try {
    const processInstanceId = await getProcessInstance(woId);
    for (let i = 0; i < selectedFiles.length; i++) {
      const payload = {
        skipCustomListeners: false,
        skipIoMappings: false,
        instructions: [
          {
            type: 'startBeforeActivity',
            activityId: 'Activity_1n8xrjo',
            variables: {
              __file__: {
                value: `{\"id\": \"${selectedFiles[i].id}\",\"name\": \"${selectedFiles[i].name}\",\"filetypeid\": \"2\",\"mspages\": null,\"estimatedpages\": null,\"isChecked\": "${selectedFiles[i].isChecked}"}`,
                type: 'Json',
                local: true,
              },
            },
          },
        ],
        annotation: 'Modified to resolve an error.',
      };
      console.log(payload);
      await service.post(
        `${process.env.CAMUNDA_NATIVE_URL}process-instance/${processInstanceId}/modification`,
        payload,
      );

      const payloads = {
        duId,
        woId,
        customerId: customerid,
        serviceId,
        currentStage: {
          id: wfStageId,
          iteration: stageIterationCount,
        },
        files: selectedFiles,
      };

      console.log(payloads, 'payloadssss');
      /// don't do enable without confirmation
      await multipleInstance(payloads);
    }
    res.status(200).json({ message: 'File Added successfully' });
  } catch (e) {
    logger.info(e);
    res.status(400).send({ message: 'File Added failed' });
  }
};

export const triggerWOStageWf = async (req, res) => {
  try {
    const retresult = await triggerWOStageWf_logic(req, res);
    if (retresult.issuccess == true) {
      res.status(200).json({ message: retresult.message });
    } else {
      res.status(400).send({ message: retresult.message });
    }
  } catch (e) {
    res.status(400).send({ message: 'Next stage initiated/iterated failed' });
  }
};

export const _triggerWOStageWf = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    try {
      const retresult = await triggerWOStageWf_logic(req, res);
      if (retresult.issuccess == true) {
        resolve(retresult);
      } else {
        reject(retresult);
      }
    } catch (e) {
      reject(e);
    }
  });
};
// start
export const triggerWOStageWf_logic = async (req, res) => {
  const {
    duId,
    woId,
    customerId,
    wfId,
    wfeventId,
    serviceId,
    userId,
    targetStage,
    category,
    files,
    entityId,
    serviceName,
    woType,
    currentStage,
    type,
    isbnUpdateConfirmation,
    isbnLabel,
    newISBN,
    oldISBN,
    jobType,
    isAutoStageTrigger,
  } = req.body;

  logger.info(req.body, 'triggerWOStageWf_logic woid-', woId);
  return new Promise(async resolve => {
    try {
      // check the iTracks call
      const isItracksAPI = await checkItracksExits(req, res);
      logger.info(isItracksAPI, 'isItracksAPI exist on stage');
      const { status } = isItracksAPI;
      let iTracksObj = { status: true, message: '' };

      const { isgraphicsData, graphicsData } =
        await checkGraphicCompletionTrigger(wfId, woId);
      logger.info(isgraphicsData, graphicsData, 'graphicCompletionDetails');

      let setrevisedduedate = false;

      if (type == 'complete' && !isgraphicsData) {
        // res.status(400).send({ message: "Please Complete the Graphic Stage" });
        resolve({
          message: 'Please Complete the Graphic Stage',
          issuccess: false,
        });
      } else {
        // get revised end date
        const addeddate = new Date();
        addeddate.setHours(addeddate.getHours() + 5);
        addeddate.setMinutes(addeddate.getMinutes() + 30);

        logger.info(
          addeddate,
          'added 530 hours-stage.js--triggerWOStageWf_logic--suradha2',
        );

        const tomorrowdate = new Date(addeddate);
        tomorrowdate.setDate(addeddate.getDate() + 1);
        tomorrowdate.setHours(0, 0, 0, 0);
        // targetStage.name == 'Collation'
        logger.info(
          tomorrowdate,
          'tommorrow date stage.js--triggerWOStageWf_logic--suradha2',
        );

        const currentdate = convertDateFormat(addeddate);
        logger.info(
          currentdate,
          'currentdate date stage.js--triggerWOStageWf_logic--suradha2',
        );

        let datebegin = currentdate;

        if (woType === 'Journal' && type != 'complete') {
          if (
            targetStage.name == 'Collation' ||
            targetStage.name == 'First View' ||
            targetStage.name == 'Revised First View' ||
            (targetStage.name == 'Revises' &&
              targetStage.iteration > 1 &&
              customerId === '8') ||
            targetStage.name == 'Stage200 Revises' ||
            targetStage.name == 'Stage 300'
          ) {
            setrevisedduedate = true;
          }
        }

        if (setrevisedduedate == true) {
          if (customerId === '8') {
            datebegin = convertDateFormat(tomorrowdate);
          }

          // let currentdate =  new Date().toLocaleDateString();

          const psql = `SELECT  
           (SELECT add_hours_exclude_weekends_and_holidays 
           FROM add_hours_exclude_weekends_and_holidays($3::timestamp(0), duc.articleduedays ::integer))::timestamp(0) as revisedenddate
           FROM wms_workorder as wo
           JOIN public.org_mst_journal_dueconfig as duc on duc.journalid = wo.journalid
           WHERE wo.workorderid = $1 and duc.stageid = $2 and duc.stageiterationcount = $4 and duc.isactive = true`;
          console.log(psql);
          await query(psql, [
            woId,
            targetStage.id,
            datebegin,
            targetStage.iteration,
          ]).then(async dataresult => {
            if (dataresult && dataresult.length) {
              console.log(dataresult);
              const newreviseddate = convertDateFormat(
                dataresult[0].revisedenddate,
              );
              targetStage.revisedenddate = newreviseddate;

              if (customerId === '8') {
                if (
                  targetStage.name == 'First View' ||
                  targetStage.name == 'Revised First View' ||
                  (targetStage.name == 'Revises' && targetStage.iteration > 1)
                ) {
                  targetStage.plannedStart = datebegin;
                  targetStage.plannedEnd = newreviseddate;
                }
              } else {
                targetStage.plannedStart = datebegin;
                targetStage.plannedEnd = newreviseddate;
              }
            } else {
              targetStage.revisedenddate = datebegin;
            }
          });
        } else {
          targetStage.revisedenddate = datebegin;
        }

        if (isbnUpdateConfirmation && newISBN && oldISBN && isbnLabel) {
          await updateIsbn(woId, isbnLabel, newISBN, oldISBN, woType);
          // get file details
          const sql = `SELECT woincomingfileid, filename FROM public.wms_workorder_incomingfiledetails
                where woincomingfileid IN (${files
                  .map(file => file.id)
                  .join(',')})`;
          const newFiles = await query(sql);
          // need to replace name value from newfiles array in files array
          newFiles.forEach(file => {
            files.forEach(file1 => {
              if (file.woincomingfileid == file1.id) {
                file1.name = file.filename;
              }
            });
          });
        }

        if (status && type != 'complete') {
          // iTracks API call
          req.body.stageId = targetStage.id;
          req.body.stageIterationCount = targetStage.iteration;

          if (woType === 'Book') {
            const subJobRes = await addSubJob(files, req.body, true, false);
            iTracksObj = subJobRes;
          } else {
            // Journal
            // if coming from customer we start from next day date variable "datebegin"
            if (setrevisedduedate == true) {
              req.body.plannedstartdate = datebegin;
              req.body.plannedenddate = targetStage.revisedenddate;
              req.body.ordermaildate = targetStage.receiptdate;
            } else {
              req.body.plannedstartdate = targetStage.plannedStart;
              req.body.plannedenddate = targetStage.plannedEnd;
              req.body.ordermaildate = targetStage.receiptdate;
            }
            let stageResponse;
            if (woId > 1976 && targetStage.iteration == 1) {
              const relatedstagedet = await relatedStageInfo(
                wfId,
                customerId,
                targetStage.id,
                woId,
              );
              const relatedstageObj = relatedstagedet.data.length
                ? relatedstagedet.data
                : [];
              if (relatedstageObj.length) {
                for (
                  let rindex = 0;
                  rindex < relatedstageObj.length;
                  rindex++
                ) {
                  if (targetStage.id != relatedstageObj[rindex].stageid) {
                    req.body.stageId = relatedstageObj[rindex].stageid;
                    req.body.isrelatedstage = true;
                  } else {
                    req.body.isrelatedstage = false;
                  }
                  stageResponse = await addSatge(req.body);
                  if (
                    stageResponse.status == undefined ||
                    stageResponse.status == false
                  ) {
                    break;
                  }
                }
              } else {
                stageResponse = { status: true, message: '' };
              }
            } else {
              stageResponse = await addSatge(req.body);
            }
            // const stageResponse = await addSatge(req.body);
            iTracksObj = stageResponse;
          }
          req.body.stageId = targetStage.id;
        }
        logger.info(iTracksObj, 'iTracksObj on stage');
        logger.info(isAutoStageTrigger, 'isAutoStageTrigger');
        if (iTracksObj.status) {
          let wfDefId = '';
          try {
            let sql = ``;
            // camunda call
            if (
              !isAutoStageTrigger ||
              isAutoStageTrigger == undefined ||
              isAutoStageTrigger == null
            ) {
              const url = config.camnunda.uri.completeTask;
              // await transaction(async (client) => {
              sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1 WHERE wfeventid = $2 returning taskinstanceid, wfdefid`;
              const resOfWWE = await query(sql, ['Completed', wfeventId]);
              const { taskinstanceid: taskInstanceId, wfdefid: wfdefId } =
                resOfWWE[0];
              const variables1 = {};
              variables1.__isfirstiteration__ = {
                value: !(targetStage.iteration > 1), // added iteration camunda update
                type: 'Boolean',
              };
              logger.info('inside : ', variables1);
              const data = {
                taskId: taskInstanceId,
                variables: variables1,
              };
              wfDefId = wfdefId;
              sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid) VALUES ($1, $2, $3, $4)`;
              await query(sql, [wfeventId, 'Completed', currentdate, userId]);
              await service.post(`${config.camnunda.base_url}${url}`, data);
              // end camunda call
            }

            if (targetStage.name) {
              logger.info('in 1');
              sql = `SELECT wostageid, startdatetime FROM public.wms_workorder_stage where workorderid = $1 and serviceid = $2 and wfstageid = $3 and stageiterationcount = $4`;
              const targetWoStageData = await query(sql, [
                woId,
                serviceId,
                targetStage.id,
                targetStage.iteration,
              ]);
              logger.info(
                targetWoStageData,
                'targetWoStageDatatargetWoStageData',
              );
              if (targetWoStageData.length) {
                const {
                  startdatetime,
                  wostageid,
                  ordermaildate,
                  plannedstartdate,
                  plannedenddate,
                } = targetWoStageData[0];

                console.log(startdatetime);
                console.log(ordermaildate);
                // sql = `UPDATE public.wms_workorder_stage SET status=$1, startdate=$2, enddate=$3, plannedstartdate= $4, plannedenddate = $5, ordermaildate = $6,updatedon = current_timestamp, triggeredstagefromid=$7, triggeredstageitrationfromid=$8  where wostageid =$9`;
                if (targetStage.name == 'Collation') {
                  await updateRevisesduedate(woId, targetStage.revisedenddate);
                }
                if (setrevisedduedate == true) {
                  sql = `UPDATE public.wms_workorder_stage 
                  SET status=$1, startdatetime=$2, 
                  enddatetime=$3, plannedstartdate= $4, 
                  plannedenddate = $5, ordermaildatetime = $6,updatedon = current_timestamp, 
                  triggeredstagefromid=$7, triggeredstageitrationfromid=$8, revisedenddatetime='${targetStage.revisedenddate}'                          
                  where wostageid =$9`;
                } else {
                  sql = `UPDATE public.wms_workorder_stage 
                  SET status=$1, startdatetime=$2, 
                  enddatetime=$3, plannedstartdate= $4, 
                  plannedenddate = $5, ordermaildatetime = $6,updatedon = current_timestamp, 
                  triggeredstagefromid=$7, triggeredstageitrationfromid=$8                         
                  where wostageid =$9`;
                }
                //  targetStage.revisedenddate || new Date(),
                await query(sql, [
                  'In Process',
                  currentdate,
                  null,
                  plannedstartdate || targetStage.plannedStart,
                  plannedenddate || targetStage.plannedEnd,
                  currentdate,
                  currentStage.id,
                  currentStage.iteration,
                  wostageid,
                ]);
                await updateStageHistory({
                  id: wostageid,
                  plannedstartdate:
                    plannedstartdate || targetStage.plannedStart,
                  plannedenddate: plannedenddate || targetStage.plannedEnd,
                  userid: userId,
                });
              } else {
                sql = `INSERT INTO wms_workorder_stage(serviceid, wfstageid,updatedby, workorderid, 
                  status, stageiterationcount, startdatetime, plannedstartdate, plannedenddate,
                   ordermaildatetime,updatedon,triggeredstagefromid, 
                   triggeredstageitrationfromid, sequence,revisedenddatetime) VALUES 
                   ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,current_timestamp,$11,$12,$13,$14)
                    returning wostageid`;

                await query(sql, [
                  serviceId,
                  targetStage.id,
                  userId,
                  woId,
                  'In Process',
                  targetStage.iteration,
                  currentdate,
                  targetStage.plannedStart,
                  targetStage.plannedEnd,
                  currentdate,
                  currentStage.id,
                  currentStage.iteration,
                  targetStage.sequence,
                  targetStage.revisedenddate,
                ]).then(async val => {
                  await updateStageHistory({
                    id: val[0].wostageid,
                    plannedstartdate: targetStage.plannedStart,
                    plannedenddate: targetStage.plannedEnd,
                    userid: userId,
                  });
                });
              }
            }
            // });
            sql = `SELECT processinstanceid, isbookcompleted FROM public.wms_workorder_service where serviceid = $1 and workorderid = $2`;
            const [
              {
                processinstanceid: processInstanceId,
                isbookcompleted: isBookCompleted,
              },
            ] = await query(sql, [serviceId, woId]);
            if (targetStage.name) {
              const stage = {
                type: targetStage.name.toLowerCase().replace(/ /g, '_'),
                iteration: targetStage.iteration,
              };
              await triggerStageWorkflow(
                category,
                stage,
                files,
                processInstanceId,
                type,
              );
              // Trigger mail
              const payload = {
                duId,
                entityId,
                workorderId: woId,
                serviceId,
              };
              const resForConfig = await getNotificationConfig(
                payload,
                'iterate/next',
              );
              let data;
              if (resForConfig.length > 0) {
                const {
                  workorderid,
                  type: type1,
                  notificationconfig,
                  customername,
                  duname,
                  itemcode,
                  services,
                  totalchaptercount,
                  printisbn,
                  totalarticlecount,
                  totalnonarticlecount,
                  wotype,
                  jobtype,
                  title,
                  journalname,
                  doinumber,
                  journalacronym,
                } = resForConfig[0];
                let isTrigger = false;
                if (
                  notificationconfig.jobTypes.length &&
                  notificationconfig.jobTypes.includes(jobtype)
                ) {
                  isTrigger = true;
                } else if (notificationconfig.jobTypes.length == 0) {
                  isTrigger = true;
                }
                logger.info(isTrigger, 'isTrigger next stage');
                if (type1 === 'mail' && isTrigger) {
                  const pmI = resForConfig.findIndex(
                    val => val.contactrole === 'PM' && val.isprimary,
                  );
                  const spmI = resForConfig.findIndex(
                    val => val.contactrole === 'SPM' && !val.isprimary,
                  );
                  const authorI = resForConfig.findIndex(
                    val =>
                      val.contactrole === 'AUTHOR' &&
                      val.contacttype === 'Customer',
                  );
                  const mailObj = {};
                  if (pmI != -1) {
                    mailObj.toPm = resForConfig[pmI].contactemail;
                  }
                  if (spmI != -1) {
                    mailObj.toSpm = resForConfig[spmI].contactemail;
                  }
                  if (authorI != -1) {
                    mailObj.toAuthor = resForConfig[authorI].contactemail;
                  }
                  const fromArray = [];
                  const toMailArray = [];
                  const ccMailArray = [];
                  const bccMailArray = [];

                  if (Array.isArray(notificationconfig.from)) {
                    notificationconfig.from.forEach(item => {
                      if (mailObj[item]) {
                        fromArray.push(mailObj[item]);
                      } else {
                        fromArray.push(item);
                      }
                    });
                  } else {
                    fromArray.push(notificationconfig.from);
                  }
                  notificationconfig.to.forEach(item => {
                    if (mailObj[item]) {
                      toMailArray.push(mailObj[item]);
                    } else {
                      toMailArray.push(item);
                    }
                  });
                  notificationconfig.cc.forEach(item => {
                    if (mailObj[item]) {
                      ccMailArray.push(mailObj[item]);
                    } else {
                      ccMailArray.push(item);
                    }
                  });
                  notificationconfig.bcc.forEach(item => {
                    if (mailObj[item]) {
                      bccMailArray.push(mailObj[item]);
                    } else {
                      bccMailArray.push(item);
                    }
                  });

                  console.log(toMailArray, 'toMailArray');
                  console.log(ccMailArray, 'ccMailArray');
                  console.log(bccMailArray, 'bccMailArray');
                  data = {
                    actionType: type1,
                    date: moment(currentdate || new Date()).format(
                      'DD-MM-YYYY',
                    ),
                    workorderId: workorderid,
                    noOfChapter: totalchaptercount,
                    noOfArticle: totalarticlecount,
                    noOfNonArticle: totalnonarticlecount,
                    printIsbn: printisbn,
                    woType: wotype,
                    jobType: jobtype,
                    service: services,
                    doiNumber: doinumber,
                    jobId: itemcode,
                    jobName: title,
                    journalAcronym: journalacronym,
                    journalName: journalname,
                    customerName: customername,
                    duName: duname,
                    pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
                    spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
                    spmMail: spmI != -1 ? resForConfig[spmI].contactemail : '',
                    authorName:
                      authorI != -1 ? resForConfig[authorI].contactname : '',
                    ...notificationconfig,
                    from: fromArray,
                    toMail: toMailArray,
                    cc: ccMailArray,
                    bcc: bccMailArray,
                    tlName: 'TL',
                    serviceName,
                    stageName: targetStage.name,
                    iteration: targetStage.iteration,
                    plannedStartDate: targetStage.plannedStart,
                    plannedEndDate: targetStage.plannedEnd,
                    serviceId,
                    stageId: targetStage.id,
                    stageIterationCount: targetStage.iteration,
                    wfDefId,
                    mailType: 'general',
                  };
                  logger.info(data, 'req for next stage notif');
                  //  emitAction(data);
                }
                logger.info(data, 'req for next stage notif');
                // emitAction(data);
              }
              // Trigger Trackit API
              if (
                customerId == '6' &&
                woType == 'Journal' &&
                (jobType == '3' || jobType == '1')
              ) {
                await trackitAPITrigger(
                  data.doiNumber,
                  woId,
                  serviceId,
                  targetStage.id,
                  targetStage.iteration,
                );
              }
            }
            await updateServiceStatus(
              woId,
              serviceId,
              processInstanceId,
              isBookCompleted,
              graphicsData,
              type,
            );
            if (
              (req.body.currentStage.iteration && req.body.woType == 'Book') ||
              (req.body.woType == 'Journal' && req.body.category == 'Issuewise')
            ) {
              await multipleInstance(req.body);
            }

            // res.status(200).json({ message: 'Next stage initiated/iterated successfully' });
            resolve({
              message: 'Next stage initiated/iterated successfully',
              issuccess: true,
            });
          } catch (error) {
            logger.info(error, 'error for trigger next stage');
            // res.status(400).send({ message: 'Next stage initiated/iterated failed' });
            resolve({
              message: 'Next stage initiated/iterated failed',
              issuccess: false,
            });
          }
        } else {
          // res.status(400).send({ message: iTracksObj.message });
          resolve({ message: iTracksObj.message, issuccess: false });
        }
      }
    } catch (e) {
      logger.info(e, 'final catch');
      // rollback the isbn update
      // if (isbnUpdateConfirmation) {
      //     await updateIsbn(woId, isbnLabel, oldISBN, newISBN);
      // }
      // res.status(400).send({ message: 'Next stage initiated/iterated failed' });
      resolve({
        message: 'Next stage initiated/iterated failed',
        issuccess: false,
      });
    }
  });
};
// end

export const graphicFilenameUpdateNewISBN = async (woId, newISBN, oldISBN) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `select fmap.actfilemapid,fmap.wfeventid ,fmap.repofilepath ,* from wms_workflow_eventlog as ed
       join wms_workflowactivitytrn_file_map as fmap on ed.wfeventid =fmap.wfeventid 
      where workorderid=${woId} and wfdefid in (501,502,503,504,505)`;
      const isgraphicsDetails = await query(sql1);
      for (let i = 0; i < isgraphicsDetails.length; i++) {
        const list = isgraphicsDetails[i];
        if (list.repofilepath.includes(oldISBN)) {
          const newname = list.repofilepath.replace(oldISBN, newISBN);
          await renameBlob({
            srcPath: list.repofilepath,
            name: basename(newname),
            destBasePath: `${dirname(newname)}/`,
          });
          // await removeFolder(list.repofilepath);
          const sql2 = `UPDATE wms_workflowactivitytrn_file_map
          SET repofilepath = '${newname}'
          WHERE actfilemapid  =  ${list.actfilemapid}`;
          await query(sql2);
        }
      }
      resolve(true);
    } catch (e) {
      logger.info(e, 'check completion trigger');
      reject(e);
    }
  });
};
export const triggerNextStagewf = async (req, res) => {
  const trresp = await settriggerNextStagewf(req, res);

  if (trresp) {
    if (trresp.issuccess == true) {
      res.status(200).json({ message: trresp.message });
    } else {
      res.status(400).send({ message: trresp.message });
    }
  }
};

export const settriggerNextStagewf = async (req, res) => {
  return new Promise(async resolve => {
    const {
      duId,
      woId,
      customerId,
      serviceId,
      targetStage,
      category,
      files,
      entityId,
      serviceName,
      woType,
      jobType,
      type,
    } = req.body;
    // check the iTracks call
    const isItracksAPI = await checkItracksExits(req, res);
    logger.info(isItracksAPI, 'isItracksAPI exist on stage');
    const { status } = isItracksAPI;
    let iTracksObj = { status: true, message: '' };

    // resolve({issuccess:false, message: "test" });

    // let {isgraphicsData,graphicsData} = await checkGraphicCompletionTrigger(graphicCompletionTriggerWfDefid, woId)
    // logger.info(isgraphicsData, graphicsData,"graphicCompletionDetails")

    if (type == 'complete') {
      resolve({
        issuccess: false,
        message: 'Please Complete the Graphic Stage',
      });
      // res.status(400).send({ message: "Please Complete the Graphic Stage" });
    } else {
      if (status && type != 'complete') {
        // iTracks API call
        req.body.stageId = targetStage.id;
        req.body.stageIterationCount = targetStage.iteration;

        if (woType === 'Book') {
          const subJobRes = await addSubJob(files, req.body, false, false);
          iTracksObj = subJobRes;
        } else {
          // Journal
          req.body.plannedstartdate = targetStage.plannedStart;
          req.body.plannedenddate = targetStage.plannedEnd;
          req.body.ordermaildate = targetStage.receiptdate;

          const stageResponse = await addSatge(req.body);
          iTracksObj = stageResponse;
        }
      }
      logger.info(iTracksObj, 'iTracksObj on stage');

      if (iTracksObj.status) {
        const wfDefId = '';
        try {
          // let url = config.camnunda.uri.completeTask;
          // await transaction(async (client) => {
          //     let sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1 WHERE wfeventid = $2 returning taskinstanceid, wfdefid`;
          //     const { rows: [{ taskinstanceid: taskInstanceId, wfdefid: wfdefId }] } = await client.query(sql, ['Completed', wfeventId]);
          //     let data = {
          //         taskId: taskInstanceId
          //     };
          //     wfDefId = wfdefId;
          //     sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp, userid) VALUES ($1, $2, $3, $4)`;
          //     await client.query(sql, [wfeventId, 'Completed', new Date(), userId]);
          //     await service.post(`${config.camnunda.base_url}${url}`, data);
          //     if (targetStage.name) {
          //         logger.info('in 1');
          //         sql = `SELECT wostageid, startdate FROM public.wms_workorder_stage where workorderid = $1 and serviceid = $2 and wfstageid = $3 and stageiterationcount = $4`;
          //         let { rows: targetWoStageData } = await client.query(sql, [woId, serviceId, targetStage.id, targetStage.iteration]);
          //         logger.info(targetWoStageData, "targetWoStageDatatargetWoStageData")
          //         if (targetWoStageData.length) {

          //             const { startdate, wostageid, ordermaildate, plannedstartdate, plannedenddate } = targetWoStageData[0];
          //             sql = `UPDATE public.wms_workorder_stage SET status=$1, startdate=$2, enddate=$3, plannedstartdate= $4, plannedenddate = $5, ordermaildate = $6,updatedon = current_timestamp, triggeredstagefromid=$7, triggeredstageitrationfromid=$8  where wostageid =$9`;
          //             await client.query(sql, ['In Process', startdate ? startdate : new Date(), null, plannedstartdate ? plannedstartdate : targetStage.plannedStart, plannedenddate ? plannedenddate : targetStage.plannedEnd, ordermaildate ? ordermaildate : new Date(), currentStage.id, currentStage.iteration, wostageid]);
          //             setTimeout(async () => {
          //                 await updateStageHistory({
          //                     id: wostageid,
          //                     plannedstartdate: plannedstartdate ? plannedstartdate : targetStage.plannedStart,
          //                     plannedenddate: plannedenddate ? plannedenddate : targetStage.plannedEnd,
          //                     userid: userId
          //                 });
          //             }, 1000)
          //         } else {
          //             sql = `INSERT INTO wms_workorder_stage(serviceid, wfstageid,updatedby, workorderid, status, stageiterationcount, startdate, plannedstartdate, plannedenddate, ordermaildate,updatedon,triggeredstagefromid, triggeredstageitrationfromid, sequence) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,current_timestamp,$11,$12,$13) returning wostageid`;
          //             await client.query(sql, [serviceId, targetStage.id, userId, woId, 'In Process', targetStage.iteration, new Date(), targetStage.plannedStart, targetStage.plannedEnd, new Date(), currentStage.id, currentStage.iteration, targetStage.sequence]).then((data => {
          //                 setTimeout(async () => {
          //                     await updateStageHistory({
          //                         id: data.rows[0].wostageid,
          //                         plannedstartdate: targetStage.plannedStart,
          //                         plannedenddate: targetStage.plannedEnd,
          //                         userid: userId
          //                     });
          //                 }, 1000)
          //             }))
          //         }
          //     }
          // });
          const sql = `SELECT processinstanceid, isbookcompleted FROM public.wms_workorder_service where serviceid = $1 and workorderid = $2`;
          const [{ processinstanceid: processInstanceId }] = await query(sql, [
            serviceId,
            woId,
          ]);
          if (targetStage.name) {
            const stage = {
              type: targetStage.name.toLowerCase().replace(/ /g, '_'),
              iteration: targetStage.iteration,
            };
            await triggerStageWorkflow(
              category,
              stage,
              files,
              processInstanceId,
              type,
            );
            // Trigger mail
            const payload = {
              duId,
              entityId,
              workorderId: woId,
              serviceId,
            };
            const resForConfig = await getNotificationConfig(
              payload,
              'iterate/next',
            );
            let data;
            if (resForConfig.length > 0) {
              const {
                workorderid,
                type: type1,
                notificationconfig,
                customername,
                duname,
                itemcode,
                services,
                totalchaptercount,
                printisbn,
                totalarticlecount,
                totalnonarticlecount,
                wotype,
                jobtype,
                title,
                journalname,
                doinumber,
                journalacronym,
              } = resForConfig[0];
              let isTrigger = false;
              if (
                notificationconfig.jobTypes.length &&
                notificationconfig.jobTypes.includes(jobtype)
              ) {
                isTrigger = true;
              } else if (notificationconfig.jobTypes.length == 0) {
                isTrigger = true;
              }
              console.log(isTrigger, 'isTrigger next stage');
              if (type1 === 'mail' && isTrigger) {
                const pmI = resForConfig.findIndex(
                  val => val.contactrole === 'PM' && val.isprimary,
                );
                const spmI = resForConfig.findIndex(
                  val => val.contactrole === 'SPM' && !val.isprimary,
                );
                const authorI = resForConfig.findIndex(
                  val =>
                    val.contactrole === 'AUTHOR' &&
                    val.contacttype === 'Customer',
                );
                const mailObj = {};
                if (pmI != -1) {
                  mailObj.toPm = resForConfig[pmI].contactemail;
                }
                if (spmI != -1) {
                  mailObj.toSpm = resForConfig[spmI].contactemail;
                }
                if (authorI != -1) {
                  mailObj.toAuthor = resForConfig[authorI].contactemail;
                }
                const fromArray = [];
                const toMailArray = [];
                const ccMailArray = [];
                const bccMailArray = [];

                if (Array.isArray(notificationconfig.from)) {
                  notificationconfig.from.forEach(item => {
                    if (mailObj[item]) {
                      fromArray.push(mailObj[item]);
                    } else {
                      fromArray.push(item);
                    }
                  });
                } else {
                  fromArray.push(notificationconfig.from);
                }
                notificationconfig.to.forEach(item => {
                  if (mailObj[item]) {
                    toMailArray.push(mailObj[item]);
                  } else {
                    toMailArray.push(item);
                  }
                });
                notificationconfig.cc.forEach(item => {
                  if (mailObj[item]) {
                    ccMailArray.push(mailObj[item]);
                  } else {
                    ccMailArray.push(item);
                  }
                });
                notificationconfig.bcc.forEach(item => {
                  if (mailObj[item]) {
                    bccMailArray.push(mailObj[item]);
                  } else {
                    bccMailArray.push(item);
                  }
                });

                console.log(toMailArray, 'toMailArray');
                console.log(ccMailArray, 'ccMailArray');
                console.log(bccMailArray, 'bccMailArray');
                data = {
                  actionType: type1,
                  date: moment(new Date()).format('DD-MM-YYYY'),
                  workorderId: workorderid,
                  noOfChapter: totalchaptercount,
                  noOfArticle: totalarticlecount,
                  noOfNonArticle: totalnonarticlecount,
                  printIsbn: printisbn,
                  woType: wotype,
                  jobType: jobtype,
                  service: services,
                  doiNumber: doinumber,
                  jobId: itemcode,
                  jobName: title,
                  journalAcronym: journalacronym,
                  journalName: journalname,
                  customerName: customername,
                  duName: duname,
                  pmName: pmI != -1 ? resForConfig[pmI].contactname : '',
                  spmName: spmI != -1 ? resForConfig[spmI].contactname : '',
                  spmMail: spmI != -1 ? resForConfig[spmI].contactemail : '',
                  authorName:
                    authorI != -1 ? resForConfig[authorI].contactname : '',
                  ...notificationconfig,
                  from: fromArray,
                  toMail: toMailArray,
                  cc: ccMailArray,
                  bcc: bccMailArray,
                  tlName: 'TL',
                  serviceName,
                  stageName: targetStage.name,
                  iteration: targetStage.iteration,
                  plannedStartDate: targetStage.plannedStart,
                  plannedEndDate: targetStage.plannedEnd,
                  serviceId,
                  stageId: targetStage.id,
                  stageIterationCount: targetStage.iteration,
                  wfDefId,
                  mailType: 'general',
                };
                logger.info(data, 'req for next stage notif');
                //  emitAction(data);
              }
              logger.info(data, 'req for next stage notif');
              // emitAction(data);
            }
            // Trigger Trackit API
            if (
              (customerId == '6' && woType == 'Journal' && jobType == '3') ||
              jobType == '1'
            ) {
              await trackitAPITrigger(
                data.doiNumber,
                woId,
                serviceId,
                targetStage.id,
                targetStage.iteration,
              );
            }
          }
          // let payload = {
          //     duId : req.body.duId,
          //     woId : req.body.woId,
          //     customerId : customerId,
          //     serviceId : serviceId,
          //     stageId : req.body.currentStage.id,
          //     stageiterationcount : req.body.currentStage.iteration,
          //     files : req.body.files
          // }
          //  await updateServiceStatus(woId, serviceId, processInstanceId, isBookCompleted, graphicsData, type);
          // if (req.body.currentStage.iteration) {
          //     await multipleInstance(req.body);
          // }
          resolve({
            issuccess: true,
            message: 'Next stage initiated/iterated successfully',
          });
          // res.status(200).json({ message: 'Next stage initiated/iterated successfully' });
        } catch (error) {
          logger.info(error);
          resolve({
            issuccess: false,
            message: 'Next stage initiated/iterated failed',
          });
          // res.status(400).send({ message: 'Next stage initiated/iterated failed' });
        }
      } else {
        resolve({ issuccess: false, message: iTracksObj.message });
        // res.status(400).send({ message: iTracksObj.message });
      }
    }
  });
};

export const triggerNextStagewfguid = async (req, res) => {
  try {
    let sql = `SELECT * FROM public.iauthor_transactions where guid = $1`;
    const woDetails = await query(sql, [req.body.article_guid]);
    const {
      customerid,
      duid,
      serviceid,
      stageid,
      stageiterationcount,
      workorderid,
    } = woDetails[0];
    // fetch workorder details
    sql = `select itemcode, wotype, wms_workorder_service.wfid, isiauthor, copyeditingworkflow from wms_workorder 
    join wms_workorder_service on wms_workorder_service.workorderid = wms_workorder.workorderid
    join pp_mst_journal on pp_mst_journal.journalid = wms_workorder.journalid
    where wms_workorder.workorderid=$1`;
    const workOrderDetails = await query(sql, [workorderid]);
    const { wotype, itemcode, wfid, isiauthor, copyeditingworkflow } =
      workOrderDetails[0];
    const flowType = ['isgeneral'];
    if (isiauthor) {
      flowType.push('isiauthor');
    }
    if (copyeditingworkflow) {
      flowType.push('iscopyeditingworkflow');
    }
    const flows = flowType.join("','");
    // fetch next stage details
    sql = `select stageid as nextstageid, stagename as nextstagename from wms_mst_stage
      where stageid = any (select nextstageid from wms_workflow_stageconfig
      join wms_workflow_nextstage_map on wms_workflow_nextstage_map.wfstageconfigid = wms_workflow_stageconfig.wfstageconfigid
      where wfid=$1 and stageid=$2 and iterationcount=$3 and flowtype in ('${flows}'))`;
    const nextStageDetails = await query(sql, [
      wfid,
      stageid,
      stageiterationcount,
    ]);
    const { nextstageid, nextstagename } = nextStageDetails[0];
    // fetch the target stage iteration count
    sql = `SELECT * FROM wms_workorder_stage where workorderid=$1 and wfstageid = $2 order by stageiterationcount desc limit 1`;
    const targetStageInfo = await query(sql, [workorderid, nextstageid]);
    const { sequence, plannedstartdate, plannedenddate } = targetStageInfo[0];
    // fetch the TAT details for the stage
    // commented by suradha - reasen (planned start date enddate should pick from workorder stage.
    // we calculate date during wo auto creation)
    // const duDates = `SELECT * FROM public.org_mst_du_duedates where customerid = $1 and duid = $2 and stageid = $3`;
    // const duDatesDetails = await query(duDates, [
    //   customerid,
    //   duid,
    //   nextstageid,
    // ]);
    // const { dueduration } = duDatesDetails[0];
    // fetch the workflow details
    const workFlow = `SELECT * FROM public.wms_workflow where wfid = $1`;
    const workFlowDetails = await query(workFlow, [wfid]);
    const { wfcategory } = workFlowDetails[0];
    // fetch the service details
    const serviceNameDetail = `SELECT * FROM public.wms_mst_service where serviceid = $1`;
    const serviceNameDetails = await query(serviceNameDetail, [serviceid]);
    // fetch the stage details
    const stageInfo = `SELECT * FROM public.wms_mst_stage where stageid = $1`;
    const stageInfoDetails = await query(stageInfo, [stageid]);
    // fetch the event id
    sql = `select wfeventid, activityid, sequence from wms_workflowdefinition a
            join wms_workflow_eventlog b on a.wfdefid = b.wfdefid   
             where workorderid = $1 and stageid =$2 and wfid = $3 and activityalias = 'Completion Trigger'`;
    const EventIDDetails = await query(sql, [workorderid, stageid, wfid]);
    const { activityid, wfeventid } = EventIDDetails[0];
    // const currentDate = moment(new Date()).format('YYYY-MM-DD');
    // const targetDate = moment(new Date())
    //   .add(dueduration, 'days')
    //   .format('YYYY-MM-DD');
    const addeddate = new Date();
    addeddate.setHours(addeddate.getHours() + 5);
    addeddate.setMinutes(addeddate.getMinutes() + 30);
    const newdate = convertDateFormat(addeddate);

    logger.info(newdate, 'newdate-check stage.js');

    const psd = plannedstartdate || addeddate;
    const ped = plannedenddate || addeddate;

    const currentDate = convertDateFormat(psd);
    const targetDate = convertDateFormat(ped);
    // const currentDate = moment(plannedstartdate || new Date()).format(
    //   'YYYY-MM-DD HH:mm:ss',
    // );
    // const targetDate = moment(plannedenddate || new Date()).format(
    //   'YYYY-MM-DD HH:mm:ss',
    // );

    const getFileDetailsSql = `SELECT woincomingfileid,filename,filetypeid,mspages,estimatedpages, imagecount,equationcount, tablecount , wwif.duedate FROM public.wms_workorder_incoming 
        JOIN wms_workorder_incomingfiledetails AS wwif ON wwif.woincomingid = wms_workorder_incoming.woincomingid
        WHERE woid=$1`;
    const getFileDetails = await query(getFileDetailsSql, [workorderid]);
    const { duedate } = getFileDetails[0];
    // check the iTracks call
    const customerId = customerid;
    const serviceId = serviceid;
    const woId = workorderid;
    const type = 'next';
    const serviceName = serviceNameDetails[0].servicename;
    const wfId = wfid;
    const category = wfcategory;
    const nextStageIteration = targetStageInfo.filter(
      item => item.status === 'Completed',
    );
    const targetStage = {
      iteration: nextStageIteration.length + 1,
      id: nextstageid,
      name: nextstagename,
      plannedStart: currentDate,
      plannedEnd: targetDate,
      sequence,
      receiptdate: newdate,
    };
    const currentStage = {
      iteration: stageiterationcount,
      id: stageid,
      name: stageInfoDetails[0].stagename,
    };
    const selectedFiles = getFileDetails.filter(item => item.filetypeid !== 1);
    const files = selectedFiles.map(item => {
      return { id: item.woincomingfileid };
    });
    req.body = {
      woId,
      type,
      wfeventId: wfeventid,
      userId: 'System',
      currentStage,
      targetStage,
      files,
      category,
      serviceId,
      serviceName,
      entityId: '8',
      wfId,
      customerId,
      jobcardId: null,
      woType: wotype,
      jobId: itemcode,
      duId: duid,
      activityId: activityid,
      stageId: targetStage.id,
      valuesOfArray: getFileDetails,
      duedate,
    };
    await _triggerWOStageWf(req, res);
    await CallBackToiAuthor(req.body.id);
    res
      .status(200)
      .send({ message: 'Next stage triggered - after iAuthor update' });
  } catch (e) {
    logger.info(e, 'error');
    res.status(400).send({ message: e.message });
  }
};

export const checkGraphicCompletionTrigger = async (wfId, woId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql1 = `select * from wms_workflowdefinition where stageid in (10) and wfid = $1 and activityid = 21 order by sequence`;
      const graphicCompletionTriggerDetails = await query(sql1, [wfId]);
      const graphicCompletionTriggerWfDefid =
        graphicCompletionTriggerDetails &&
        graphicCompletionTriggerDetails.length
          ? graphicCompletionTriggerDetails[0].wfdefid
          : '';
      let sql = `select * from wms_workorder_stage where workorderid =$1
            and wfstageid in (10)`;
      const isgraphicsDetails = await query(sql, [woId]);
      let graphicsData = [];
      if (
        isgraphicsDetails.lenght > 0 &&
        graphicCompletionTriggerDetails &&
        graphicCompletionTriggerDetails.length > 0
      ) {
        sql = `select * from wms_workflow_eventlog where workorderid = $1 and wfdefid = $2`;
        graphicsData = await query(sql, [
          woId,
          graphicCompletionTriggerWfDefid,
        ]);
        resolve({
          isgraphicsData: graphicsData.length > 0,
          graphicsData,
        });
      } else {
        resolve({ isgraphicsData: true, graphicsData });
      }
    } catch (e) {
      logger.info(e, 'check completion trigger');
      reject(e);
    }
  });
};

const trackitAPITrigger = async (
  doiNumber,
  woId,
  serviceId,
  targetStageid,
  targetStageiteration,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const username = process.env.TRACKIT_USERNAME;
      const password = process.env.TRACKIT_PASSWORD;
      const payloadFortrackit = {
        doi: doiNumber,
        stage: 'CREATE_FINAL_PROOF',
        details: 'Author proof returned',
        // "details": "The article proof has been completed by the author",
        source: 'Emerald',
        // "source": "TYPESETTER_INTEGRA",
        runNumber: '1',
        result: 'Passed',
        username,
        password,

        workorderId: woId,
        serviceId,
        stageId: targetStageid,
        stageIterationCount: targetStageiteration,
      };

      logger.info(payloadFortrackit, 'payloadFortrackit');
      const resForTrackitApi = await getAuthAccessWorflow(payloadFortrackit);
      logger.info(resForTrackitApi, 'resForTrackitApi');
      resolve();
    } catch (e) {
      logger.info(e, 'Trackit API Call Error');
      reject(e);
    }
  });
};

export const updateServiceStatus = async (
  woId,
  serviceId,
  processInstanceId,
  isBookCompleted,
  graphicCompletionDetails,
  type,
) => {
  let sql = `SELECT count(*) FROM public.wms_workorder_stage where workorderid = $1 and serviceid = $2 and status = $3`;
  return new Promise(async (resolve, reject) => {
    try {
      if (isBookCompleted) {
        const [{ count }] = await query(sql, [woId, serviceId, 'In Process']);
        if (count == 0) {
          sql = `UPDATE public.wms_workorder_service SET status=$1 where workorderid = $2 and serviceid = $3`;
          await query(sql, ['Completed', woId, serviceId]);
          await triggerBatchCompletion(processInstanceId);
          if (type == 'complete' && graphicCompletionDetails.length > 0) {
            logger.info(graphicCompletionDetails, 'graphicCompletionDetails');
            const url = config.camnunda.uri.completeTask;
            const data = {
              taskId: graphicCompletionDetails[0].taskinstanceid,
            };
            await service.post(`${config.camnunda.base_url}${url}`, data);
          }
          logger.info(`Service is completed for woid ${woId}`);
          await updateWOStatus(woId);
        }
      }
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const updateWOStatus = async woId => {
  let sql = `SELECT count(*) FROM public.wms_workorder_service where workorderid = $1 and status != $2`;
  return new Promise(async (resolve, reject) => {
    try {
      const [{ count }] = await query(sql, [woId, 'Completed']);
      if (count == 0) {
        sql = `UPDATE public.wms_workorder SET status=$1, completeddate=$2 where workorderid=$3`;
        await query(sql, ['Completed', new Date(), woId]);
        logger.info(`Workorder is completed for woid ${woId}`);
      }
      resolve();
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

export const getPreviousChapterPath = async (req, res) => {
  try {
    const path = await getFolderStructure({ type: 'okm_common' });
    res.status(200).json({ path });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error });
  }
};

export const updateWoStage = async (req, res) => {
  // check the iTracks call
  // let { status } = await checkItracksExits(req, res);
  // console.log(status, 'status of itracks exist');

  // if (status) {
  //     let { id } = req.body
  //     let isItracksStageTrigger = await checkITrackStageTrigger(id);
  //     console.log(isItracksStageTrigger, 'isItracksStageTrigger');

  //     if (isItracksStageTrigger) {
  //         console.log('alredy exists');
  //         stageUpdateAction(req, res, false);
  //     } else {
  //         console.log(req, 'req fro add stage');
  //         let response = await addSatge(req.body);
  //         console.log(response, 'ress123');

  //         if (response.status) {
  //             stageUpdateAction(req, res, true);
  //         } else {
  //             res.status(400).send(response);
  //         }
  //     }

  // } else {
  //     console.log('without itracks stage');
  //     stageUpdateAction(req, res, false);
  // }

  stageUpdateAction(req, res, false);
};

// ----------------using for autojob creation with promise---------------------//
export const updateWoStage_autoCall = async (req, res) => {
  // check the iTracks call
  return new Promise(async resolve => {
    const stupdate = await stageUpdateAction_autoCall(req, res, false);
    if (stupdate.issuccess) {
      resolve({ message: 'success', issuccess: true });
    } else {
      resolve({ message: 'failed', issuccess: false });
    }

    // TO BE DELETED
    // let { status } = await checkItracksExits(req, res);
    // console.log(status, 'status of itracks exist');

    // if (status) {
    //     let { id } = req.body
    //     let isItracksStageTrigger = await checkITrackStageTrigger(id);
    //     console.log(isItracksStageTrigger, 'isItracksStageTrigger');

    //     if (isItracksStageTrigger) {
    //         console.log('alredy exists');
    //         let stupdate = await stageUpdateAction_autoCall(req, '', false);

    //         if (stupdate.issuccess) {
    //             resolve({ message: "success", issuccess: true });
    //         } else {
    //             resolve({ message: "failed", issuccess: false });
    //         }

    //     } else {
    //         console.log(req, 'req fro add stage');
    //         let response = await addSatge(req.body);
    //         console.log(response, 'ress123');

    //         if (response.status) {
    //             let stupdate = await stageUpdateAction_autoCall(req, res, true);

    //             if (stupdate.issuccess) {
    //                 resolve({ message: "success", issuccess: true });
    //             } else {
    //                 resolve({ message: "failed", issuccess: false });
    //             }

    //         } else {
    //             resolve({ message: "failed", issuccess: false });
    //         }
    //     }

    // } else {
    //     console.log('without itracks stage');
    //     let stupdate = await stageUpdateAction_autoCall(req, res, false);
    //     if (stupdate.issuccess) {
    //         resolve({ message: "success", issuccess: true });
    //     } else {
    //         resolve({ message: "failed", issuccess: false });
    //     }
    // }
  });
};
/*
const checkITrackStageTrigger = id => {
  return new Promise(async resolve => {
    const sql = `SELECT * FROM public.wms_workorder_stage WHERE wostageid=${id} AND istagecreated=true`;
    logger.info(sql, 'sql for istage entry');
    query(sql)
      .then(data => {
        resolve(!!data.length);
      })
      .catch(() => {
        resolve(false);
      });
  });
};
*/
const stageUpdateAction = (req, res) => {
  // let iStageColumn = iStageEntry ? `, istagecreated=true` : ``
  const getData = req.body;
  const sql = `UPDATE wms_workorder_stage
                            SET plannedstartdate='${getData.plannedstartdate}', plannedenddate='${getData.plannedenddate}', ordermaildatetime='${getData.ordermaildate}',
                            emailpath='${getData.emailpath}',emailpathuuid='${getData.emailpathuuid}',updatedon = current_timestamp, ismilestone= ${getData.ismilestone}  WHERE wostageid = ${getData.id}`;
  logger.info(sql, 'sqlforupdatedd');
  query(sql)
    .then(async data => {
      const historyUpdate = await updateStageHistory(getData);
      logger.info(historyUpdate, 'historyUpdate');
      if (historyUpdate) {
        res
          .status(200)
          .json({ data, message: 'Stage details updated successfully' });
      } else {
        res.status(400).send({ message: 'History update failed' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

const stageUpdateAction_autoCall = req => {
  return new Promise(async resolve => {
    // let iStageColumn = iStageEntry ? `, istagecreated=true` : ``
    const getData = req.body;
    const sql = `UPDATE wms_workorder_stage
                            SET plannedstartdate='${getData.plannedstartdate}', plannedenddate='${getData.plannedenddate}', ordermaildatetime='${getData.ordermaildate}',
                            emailpath='${getData.emailpath}',emailpathuuid='${getData.emailpathuuid}',updatedon = current_timestamp, ismilestone= ${getData.ismilestone} WHERE wostageid = ${getData.id}`;
    logger.info(sql, 'sqlforupdatedd');
    query(sql)
      .then(async data => {
        const historyUpdate = await updateStageHistory(getData);
        logger.info(historyUpdate, 'historyUpdate');
        if (historyUpdate) {
          resolve({
            data,
            message: 'Stage details updated successfully',
            issuccess: true,
          });
        } else {
          resolve({ message: 'History update failed', issuccess: false });
        }
      })
      .catch(error => {
        resolve({ message: error, issuccess: false });
      });
  });
};

const updateStageHistory = getData => {
  logger.info(getData, 'daaaattt');
  return new Promise(async resolve => {
    const sql = `INSERT INTO public.wms_workorder_stage_audit(
            wostageid, plannedstartdate, plannedenddate, updatedby, updatedon)
            VALUES ($1, $2, $3,  $4, $5)`;
    query(sql, [
      getData.id,
      getData.plannedstartdate,
      getData.plannedenddate,
      getData.userid,
      new Date(),
    ])
      .then(() => {
        logger.info(sql, 'sqlforupdateee');
        resolve(true);
      })
      .catch(() => {
        resolve(false);
      });
  });
};

export const getStageHistory = async (req, res) => {
  if (req.body.type == 'stage') {
    // const { pageNo } = req.body;
    // const { recordPerPage } = req.body;
    // query(sql).then((count) => {

    const sql = `SELECT  distinct on
            (wms_workorder_stage_audit.wostageid) wms_workorder_stage_audit.wostageid,wms_wo_stagelist.stagename||'('||stageiterationcount||')' as stagename,
                    wms_wo_stagelist.plannedstartdate as plannedstartdate,
                    wms_wo_stagelist.plannedenddate as plannedenddate,
                    wms_wo_stagelist.updatedon as updatedon,
                    wms_wo_stagelist.servicename,wms_user.username||' ('||wms_user.userid||')' as username
                    from wms_workorder_stage_audit
                       join wms_wo_stagelist on wms_workorder_stage_audit.wostageid = wms_wo_stagelist.wostageid
                      join wms_user on wms_user.userid = wms_wo_stagelist.updatedby
                        WHERE wms_wo_stagelist.workorderid=${req.body.woId} ORDER BY wms_workorder_stage_audit.wostageid ASC`;
    logger.info(sql, 'sqlforhsitory');
    query(sql)
      .then(data => {
        res.status(200).json({ data });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
    // }).catch((error) => {
    //     res.status(400).send({ message: error });
    // })
  } else {
    let sql = '';
    sql = `select count(*)
        from wms_workorder_stage_audit
        where wostageid=${req.body.stageid}`;
    query(sql)
      .then(count => {
        sql = `select wostageid,plannedstartdate,
            plannedenddate,
            updatedon ,updatedby,wms_user.username||' ('||wms_user.userid||')' as username
            from wms_workorder_stage_audit
            join wms_user on wms_user.userid = wms_workorder_stage_audit.updatedby
            where wostageid=${
              req.body.stageid
            } order by wostageauditid desc limit ${
          count[0].count - 1
        } offset 1`;
        logger.info(sql, 'sqlfroexpanndaa');
        query(sql)
          .then(data => {
            res.status(200).json({ data });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  }
};

export const checkMultiInstance = async (req, res) => {
  const { woId, serviceId, stageId, stageiterationcount } = req.body;
  let sql = `SELECT * FROM public.wms_workflow_stagetrn_file WHERE workorderid = ${woId} and serviceid = ${serviceId} and stageid = ${stageId} and stageiterationcount = ${stageiterationcount}`;
  logger.info(sql, 'sqlforhsitory');
  const stagetrn = await query(sql);
  if (stagetrn.length == 0) {
    res.status(200).json({ data: { history: stagetrn } });
  } else {
    try {
      const stageIterationCount = `SELECT stageiterationcount FROM wms_workorder_stage where wfstageid = 2 and workorderid = ${woId} and status='In Process'`;
      const data = await query(stageIterationCount);
      sql = `SELECT workorderid, status, wfstageid,triggeredstagefromid, triggeredstageitrationfromid FROM wms_workorder_stage where workorderid = ${woId} and status='In Process'`;
      const finalData = await query(sql);
      if (data.length == 0) {
        res
          .status(200)
          .json({ data: { history: stagetrn, previousStage: finalData } });
      } else {
        try {
          sql = `SELECT distinct wfeventid,wms_workflow_eventlog.wfdefid,workorderid,stageid,stageiterationcount, activitystatus, activityid 
        FROM public.wms_workflow_eventlog   
        JOIN public.wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
        where workorderid= ${woId} and stageid = 2 and stageiterationcount = ${data[0].stageiterationcount}
        and activitystatus in ('Completed','Rejected','Reset') and activityid=16`;
          logger.info(sql, 'validation');
          const validData = await query(sql);
          sql = `SELECT distinct wfeventid,wms_workflow_eventlog.wfdefid,workorderid,stageid,stageiterationcount, activitystatus, activityid 
            FROM public.wms_workflow_eventlog   
            JOIN public.wms_workflowdefinition ON wms_workflowdefinition.wfdefid = wms_workflow_eventlog.wfdefid
            where workorderid= ${woId} and stageid = 2 and stageiterationcount = ${data[0].stageiterationcount}
             and activityid=16`;
          const responseData = await query(sql);
          sql = `SELECT workorderid, status, wfstageid,triggeredstagefromid, triggeredstageitrationfromid FROM wms_workorder_stage where workorderid = ${woId} and status='In Process'`;
          const finalData1 = await query(sql);
          res.status(200).json({
            data: {
              history: stagetrn,
              isValidButton:
                responseData.length != 0
                  ? validData.length == responseData.length
                  : false,
              previousStage: finalData1,
            },
          });
        } catch (error) {
          res.status(400).send({ message: error });
        }
      }
    } catch (error) {
      res.status(400).send({ message: error });
    }
  }
};

const updateIsbn = (woId, isbnLabel, newISBN, oldISBN, woType) => {
  // let { woId, isbnLabel, newISBN, oldISBN } = req.body;
  return new Promise(async (resolve, reject) => {
    try {
      await transaction(async client => {
        let sql = `update wms_workorder set ${isbnLabel} = ${newISBN} where workorderid = ${woId} returning workorderid`;
        logger.info(sql, 'sql for isbn update wo');
        const {
          rows: [{ workorderid }],
        } = await client.query(sql);
        logger.info(workorderid, 'workorderid');

        const sql1 = `update wms_workorder_additionalinfo set hardbackisbn = ${newISBN} where workorderid = ${woId}`;
        logger.info(sql1, 'sql for isbn update woadd');
        await client.query(sql1);

        sql = `select woincomingfileid, filename from public.wms_workorder_incoming
                join public.wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
                where woid=${workorderid}`;
        logger.info(sql, 'sql for get filenames');
        const getFileList = await client.query(sql);
        logger.info(getFileList, 'getFileList');
        getFileList.rows.forEach(async item => {
          const newFileName = item.filename.replace(oldISBN, newISBN);
          sql = `update wms_workorder_incomingfiledetails set filename = '${newFileName}' where woincomingfileid = ${item.woincomingfileid}`;
          logger.info(sql, 'sql for filename update');
          await client.query(sql);
        });
      });
      // added for graphics image filename shipping
      if (woType == 'Book') {
        await graphicFilenameUpdateNewISBN(woId, newISBN, oldISBN);
      }
      logger.info('filename update completed');
      resolve('ISBN updated successfully');
    } catch (e) {
      reject(e);
    }
  });
};

export const addFileButtonValidation = async (req, res) => {
  const { woId } = req.body;
  const sql = `SELECT table1.workorderid, table1.status, table1.wfstageid, table1.triggeredstagefromid, table1.triggeredstageitrationfromid FROM wms_workorder_stage as table1 JOIN (SELECT * FROM wms_workorder_stage where status='In Process') as table2 ON table1.wfstageid = table2.triggeredstagefromid where table1.workorderid=${woId} and table1.status='In Process'`;
  logger.info(sql, 'sqlforhsitory');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getEventlog = async (req, res) => {
  const { woId, stageiterationcount } = req.body;
  const sql = `SELECT * FROM public.wms_workflow_eventlog where wfdefid in (267, 272) and workorderid=${woId} and stageiterationcount =${stageiterationcount}`;
  console.log(sql);
  logger.info(sql, 'sqlforhsitory');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getProcessInstance = woId => {
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM public.wms_workorder_service WHERE workorderid=${woId}`;
    query(sql)
      .then(res => {
        if (res.length) {
          resolve(res[0].processinstanceid);
        }
      })
      .catch(error => {
        reject(error);
      });
  });
};

// export const getProcessInstance = async (woId) => {
//     debugger
//     const sql = `SELECT * FROM public.wms_workorder_service WHERE workorderid=${woId}`
//     logger.info(sql, "sqlforhsitory")
//     query(sql).then((data) => {
//         res.status(200).json({ data: data[0].processinstanceid });
//     }).catch((error) => {
//         res.status(400).send({ message: error });
//     })
// }

export const getWOStageChapters = async (req, res) => {
  try {
    const { category, wfConfig, stageId, serviceId, stageIteration, woId } =
      req.body;
    const incomingFileTypes =
      wfConfig && wfConfig.incoming && wfConfig.incoming.fileTypes
        ? wfConfig.incoming.fileTypes
        : [];
    const filesData = await queryWOStageChapters(
      category,
      incomingFileTypes,
      stageId,
      serviceId,
      stageIteration,
      woId,
    );
    res.status(200).json({ filesData });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};
export const getWOStageFiles = async (req, res) => {
  try {
    const { category, wfConfig, serviceId, woId } = req.body;
    const incomingFileTypes =
      wfConfig && wfConfig.incoming && wfConfig.incoming.fileTypes
        ? wfConfig.incoming.fileTypes
        : [];
    const filesData = await queryWOStageFiles(
      category,
      incomingFileTypes,
      serviceId,
      woId,
    );
    res.status(200).json({ filesData });
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const getStageCompletionStatus = (category, stageDetails) => {
  let isCompleted = false;
  switch (category) {
    case categories.chapter:
    case categories.article:
      isCompleted = stageDetails.files.length
        ? stageDetails.files.every(data => data.isCompletedChapter)
        : false;
      break;
    case categories.book:
    case categories.issue:
      isCompleted = !!stageDetails.isCompletedStage;
      break;
    default:
  }
  return isCompleted;
};

export const getWfTargetStageList = async (req, res) => {
  const { stageId, wfId, workorderId } = req.body;

  let sql = `SELECT nextstages, isiteration, enableisbnupdate FROM public.wms_workflow
    JOIN wms_workflow_stageconfig ON wms_workflow_stageconfig.wfid = wms_workflow.wfid
    WHERE wms_workflow_stageconfig.stageid=${stageId} AND wms_workflow_stageconfig.wfid=${wfId}`;
  console.log(sql, 'sql for target stage IDS');
  query(sql)
    .then(data => {
      sql = `select * from
      (SELECT row_number() over(partition by wfstageid order by stageiterationcount desc) as rno, * FROM public.wms_workorder_stage
                JOIN wms_mst_stage ON wms_mst_stage.stageid = wms_workorder_stage.wfstageid
                WHERE wfstageid IN (select nextstageid from public.wms_workflow_nextstage_map where wfstageconfigid in (select wfstageconfigid from public.wms_workflow_stageconfig where wfid=${wfId} and stageid=${stageId}
)) AND wms_workorder_stage.workorderid = ${workorderId} order by wostageid desc
          ) as res where res.rno = 1`;

      console.log(sql, 'sql for target stage');
      query(sql)
        .then(result => {
          console.log(result, 'resultresult');
          if (result.length) {
            res.status(200).json({
              data: result,
              isIteration: data.length && data[0].isiteration,
              isbnUpdate: !!(data.length && data[0].enableisbnupdate),
            });
          } else {
            res.status(200).json({
              data: [],
              isIteration: data.length && data[0].isiteration,
              isbnUpdate: !!(data.length && data[0].enableisbnupdate),
            });
          }
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
const CallBackToiAuthor = id => {
  return new Promise((resolve, reject) => {
    const input = {
      ids: [id],
    };
    axios({
      method: 'POST',
      url: `${config.iAuthor.base_url()}${config.iAuthor.updateiAuthorMoved}`,
      data: JSON.stringify(input),
      headers: {
        'Content-Type': 'application/json',
        clientid: 'WMS',
        apikey: '84B9A8C7-FDEA-47DC-B1CF-845FD79C4E05',
      },
    })
      .then(() => {
        resolve({ status: true, data: input });
      })
      .catch(err => {
        console.log(err, 'errr CallBackToiAuthor');
        reject({
          status: false,
          message: err.response ? err.response : err.message,
        });
      });
  });
};

export const targeStageInfo = async (req, res) => {
  const { stageId } = req.body;
  try {
    const sql = `select * from public.wms_mst_stage WHERE stageid=${stageId}`;
    logger.info(sql, 'targeStageInfo');
    query(sql).then(data => {
      res.status(200).send(data);
    });
  } catch (e) {
    res.status(400).send({ message: 'targeStageInfo failed' });
  }
};

export const updateRevisesduedate = async (woId, startdate) => {
  return new Promise(async resolve => {
    try {
      const stdate = new Date(startdate);
      stdate.setSeconds(stdate.getSeconds() + 1);
      const newstartdate = convertDateFormat(stdate);

      const psql = `SELECT  
             (SELECT add_hours_exclude_weekends_and_holidays 
             FROM add_hours_exclude_weekends_and_holidays($3::timestamp(0), duc.articleduedays ::integer))::timestamp(0) as revisedenddate
             FROM wms_workorder as wo
             JOIN public.org_mst_journal_dueconfig as duc on duc.journalid = wo.journalid
             WHERE wo.workorderid = $1 and duc.stageid = $2 and duc.stageiterationcount = $4 and duc.isactive = true`;
      console.log(psql);
      const revisesdate = await query(psql, [woId, 2, newstartdate, 1]);

      const csql = `select res.stagename,res.stageid,res.nextstageid,res.minseq from 
      (select 
        st.stagename
        ,wf.stageid
        ,lead(wf.stageid,1) over(order by min(sequence)) as nextstageid
        ,min(sequence)  as minseq
      from wms_workflowdefinition as wf
      join wms_mst_stage as st on st.stageid = wf.stageid
      where wfid = (select wfid from wms_workorder_service where workorderid = $1) 
      group by wf.stageid,st.stagename
      order by  minseq) as res where res.stageid = 21`;

      const nextstage = await query(csql, [woId]);
      if (revisesdate && revisesdate.length && nextstage && nextstage.length) {
        const { nextstageid } = nextstage[0];
        const coverteddate = convertDateFormat(revisesdate[0].revisedenddate);

        const wsqry = `update wms_workorder_stage set revisedenddatetime = $2 
          where workorderid = $1 and wfstageid = $3 and stageiterationcount = 1`;
        await query(wsqry, [woId, coverteddate, nextstageid]);
      }
      resolve('success');
    } catch (err) {
      console.log(err);
    }
  });
};

function convertDateFormat(inputDate) {
  // Parse the input date using a JavaScript Date object
  const parsedDate = new Date(inputDate);

  if (Number.isNaN(parsedDate)) {
    return 'Invalid Date'; // Handle invalid date input
  }

  // Format the date into 'YYYY-MM-DD HH:mm:ss' using the Date methods
  const year = parsedDate.getFullYear();
  const month = (parsedDate.getMonth() + 1).toString().padStart(2, '0');
  const day = parsedDate.getDate().toString().padStart(2, '0');
  const hours = parsedDate.getHours().toString().padStart(2, '0');
  const minutes = parsedDate.getMinutes().toString().padStart(2, '0');
  const seconds = parsedDate.getSeconds().toString().padStart(2, '0');

  // Create the formatted date string
  const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  return formattedDate;
}
