import { basename, extname, join } from 'path';
import { query, transaction } from '../../database/postgres.js';
import {
  triggerWorkflow,
  triggerBookCompleted,
} from '../utils/wfTrigger/index.js';
import { updateServiceStatus } from './stage.js';
import { exportToExcel } from '../utils/excel/index.js';
import { getdmsType } from '../bpmn/listener/create.js';
import { _copyFile, _createFolder } from '../utils/okm/index.js';
import {
  addSubJob,
  checkItracksExits,
  mergeIssue,
  addSatge,
  relatedStageInfo,
} from '../iTracks/index.js';
import { appConfig } from '../../config/app.js';

import logger from '../utils/logs/index.js';
import * as azureHelper from '../utils/azure/index.js';
import * as localHelper from '../utils/local/index.js';
import * as fileCopyHelper from '../utils/filecopy/index.js';
import { getFormattedName } from '../utils/fileValidation/utils.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import { getCamundaVariable } from '../task/action/workflow/reset.js';

const jobTypeObj = {
  1: 'Article',
  2: 'Issue',
  3: 'Non Article',
};
export const getimcomingDetails = async (req, res) => {
  try {
    const { start, end, baseduid } = req.body;
    const sql = `select distinct icf.isactive,wo.isactive,wo.workorderid, wo.itemcode, wo.title, 
    wo.totalchaptercount,wo.doinumber,wo.wotype,TO_CHAR(wo.createdon,'DD-MM-YYYY') as createdon,
    ic.woincomingid, icf.filename,icf.filepath,icf.fileuuid,wo.createdon as actualcreatedon,
    icf.mspages,icf.estimatedpages,icf.imagecount,icf.tablecount,
    icf.equationcount,icf.filesequence,icf.boxcount,icf.typesetpage,icf.wordcount,icf.referencecount
    from wms_workorder_incomingfiledetails as icf join
    wms_workorder_incoming as ic on ic.woincomingid=icf.woincomingid join
    wms_workorder as wo on wo.workorderid=ic.woid join
    wms_workorder_service as ws on ws.workorderid=wo.workorderid
    where wo.isactive !=false and (icf.isactive isnull or 
    icf.isactive = true) and ws.baseduid=${baseduid} and (wo.createdon between '${start}' and '${end}') 
    order by wo.createdon desc`;
    const out = await query(sql);
    res.status(200).json(out);
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error });
  }
};

export const insertWOSourceFileDetails = (req, res) => {
  const {
    duId,
    customerId,
    woId,
    serviceId,
    stageId,
    stageIterationCount,
    uploadPath,
  } = req.body;
  const sql = `INSERT INTO public.wms_workorder_sourcefile_details(
     duid, customerid, workorderid, serviceid, stageid, stageiterationcount, uploadpath, uuid, createdon)
    VALUES ( ${duId}, ${customerId}, ${woId}, ${serviceId}, ${stageId}, ${stageIterationCount}, ${uploadPath}, 'azure', current_timestamp)  RETURNING wosourcefileid`;
  logger.info(sql, 'sql form source download');
  query(sql)
    .then(response => {
      res
        .status(200)
        .send({ message: 'Inserted Successfully', data: response });
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ data: error });
    });
};

export const autoIncomingForIssue = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    const sql2 = `select * from pp_mst_filetype where (category = 'Article' or category = 'Issue')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });
    await saveArticleToMapping(response.data, woDetails[0], files);
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }
    const trigerstatus = await triggerCamundaWorkflow(woDetails[0], files);
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');
    res.send({ status: trigerstatus });
  } catch (e) {
    res.status(400).send({ status: false, data: e, message: e });
  }
};

export const autoIncomingForSpringerIssue = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);

    let doiList = files.filter(list => list.articledoi != '');
    doiList = doiList.map(list => list.articledoi);

    console.log(doiList, 'doiListdoiList');

    const sql3 = `SELECT * FROM public.wms_workorder WHERE doinumber  IN ('${doiList.join(
      "','",
    )}')`;

    const articleNameDetails = await query(sql3);
    files.map(list => {
      const filetedFileType = articleNameDetails.filter(
        sublist => sublist.doinumber == list.articledoi,
      );
      list.filename =
        filetedFileType.length > 0 && list.filetype == 'Article'
          ? `${filetedFileType[0].itemcode}`
          : list.filename;
      return list;
    });

    const sql2 = `select * from pp_mst_filetype where (category = 'Article' or category = 'Issue')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });
    await saveArticleToMappingForSpringerIssue(
      response.data,
      woDetails[0],
      files,
    );
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }
    const trigerstatus = await triggerCamundaWorkflow(woDetails[0], files);
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');
    res.send({ status: trigerstatus });
  } catch (e) {
    res.status(400).send({ status: false, data: e, message: e });
  }
};

export const autoIncomingForSpringer = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype
             , wo.celevelid 
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);
    logger.info('springer api 1', woDetails);
    const sql2 = `select * from pp_mst_filetype where (category = 'Article')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });
    logger.info('springer api _saveChapter', response);
    await saveArticleToMappingForSpringer(response.data, woDetails[0], files);
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }
    logger.info('springer api triggerCamundaWorkflow', woDetails[0]);
    const camundastatus = await triggerCamundaWorkflow(woDetails[0], files);
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');
    logger.info('springer api success');
    res.send({ status: camundastatus });
  } catch (e) {
    logger.info('springer api catch', e);
    res.status(400).send({ status: false, data: e, message: e });
  }
};

export const autoIncomingForWKHJournals = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid,case when org.countryid = 4 then 'true' else 'false' end as isuscustomer
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            join org_mst_customer_orgmap org on org.custorgmapid = jo.custorgmapid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);
    logger.info('springer api 1', woDetails);
    const sql2 = `select * from pp_mst_filetype where (category = 'Article')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });
    logger.info('springer api _saveChapter', response);
    await saveArticleToMappingForWKHJournals(
      response.data,
      woDetails[0],
      files,
    );
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }
    logger.info('wkh api triggerCamundaWorkflow', woDetails[0]);
    await triggerCamundaWorkflow(woDetails[0], files);
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');
    logger.info('wkh api success');
    res.send({ status: true });
  } catch (e) {
    logger.info('springer api catch', e);
    res.status(400).json({ status: false, data: e, message: e });
  }
};

export const autoIncomingForACSJournals = async (req, res) => {
  try {
    const { workorderId, files } = req.body;
    const sql = `select  wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,wostage.ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid and updatedon is not null
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId}`;
    const woDetails = await query(sql);
    logger.info('springer api 1', woDetails);
    const sql2 = `select * from pp_mst_filetype where (category = 'Article')`;
    const fileTypeDetails = await query(sql2);
    const workflow = {
      name: woDetails[0].wfname,
      id: woDetails[0].wfname_bpmnid,
      category: woDetails[0].wfcategory,
      enableListener: woDetails[0].wfconfig
        ? !!woDetails[0].wfconfig.enableListener
        : false,
      incoming: {
        fileTypes:
          woDetails[0].wfconfig &&
          woDetails[0].wfconfig.incoming &&
          woDetails[0].wfconfig.incoming.fileTypes
            ? woDetails[0].wfconfig.incoming.fileTypes
            : [],
      },
    };
    const service = {
      id: woDetails[0].serviceid,
      name: woDetails[0].servicename,
    };
    woDetails[0].workflow = workflow;
    woDetails[0].service = service;

    files.map(list => {
      const filetedFileType = fileTypeDetails.filter(
        sublist => sublist.filetype == list.filetype,
      );
      list.filetypeid =
        filetedFileType.length > 0 ? filetedFileType[0].filetypeid : '';
      return list;
    });
    const payload = {
      woid: workorderId,
      service: { id: woDetails[0].serviceid, name: woDetails[0].servicename },
      stageid: woDetails[0].wfstageid,
      receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
      duedate: new Date(woDetails[0].plannedenddate).toISOString(),
      updatedby: woDetails[0].updatedby,
      batchno: 0,
      valuesOfArray: files,
      totalArticleCount: '',
      totalNonArticleCount: '',
      totalCount: 0,
      totalChapterCount: null,
      fileNameISBN: '',
    };
    const response = await _saveChapter({ body: payload }, { res: {} });
    logger.info('acs api _saveChapter', response);
    await saveArticleToMappingForWKHJournals(
      response.data,
      woDetails[0],
      files,
    );
    for (let k = 0; k < files.length; k++) {
      const list = files[k];
      const filteredId = response.data.filter(
        sublist => sublist.filename == list.filename,
      );
      list.woincomingfileid = list.woincomingfileid
        ? list.woincomingfileid
        : filteredId.length > 0
        ? filteredId[0].woincomingfileid
        : '';
    }
    logger.info('acs api triggerCamundaWorkflow', woDetails[0]);
    await triggerCamundaWorkflow(woDetails[0], files);
    console.log(response, 'response for save chapter');
    console.log(workorderId, files, 'dfd');
    logger.info('acs api success');
    res.send({ status: true });
  } catch (e) {
    logger.info('acs api catch', e);
    res.status(400).send({ status: false, data: e, message: e });
  }
};

export const triggerCamundaWorkflow = async (woDetails, files) => {
  return new Promise(async resolve => {
    try {
      let coverValue = files.filter(list => list.filetypeid == '5');
      let advertValue = files.filter(list => list.filetypeid == '6');
      let runOnValue = files.filter(list => list.filetypeid == '16');
      coverValue = coverValue.length > 0;
      advertValue = advertValue.length > 0;
      runOnValue = runOnValue.length > 0;

      const filteredFiles = files.filter(list => list.filetypeid == '4');
      const articelIssue = filteredFiles.length > 0;
      const isWordInput = {};
      const isJournalInput = {};
      const iscopyEditingLevel = {};
      const isiAuthor = {};
      const iseonly = {};
      const isNLP = {};
      const isDirectFP = {};
      const flowtype = {};
      const ceLevel = {};
      const isreject = {};
      const camundaFormVariables = {};
      const graphicVariables = {};
      const isPAP = {};
      const isESM = {};
      const word =
        filteredFiles.length > 0 && filteredFiles[0].filepath == ''
          ? true
          : !!(
              woDetails.customerid != '8' &&
              filteredFiles &&
              filteredFiles.length > 0 &&
              (extname(filteredFiles[0].filepath) == '.docx' ||
                extname(filteredFiles[0].filepath) == '.doc')
            );
      camundaFormVariables.__isJournal__ = getCamundaVariable(
        'boolean',
        'true',
      );
      let grpahicValue = files.filter(list => list.imagecount > 0);
      grpahicValue = grpahicValue.length > 0;
      graphicVariables.__isGraphic__ = getCamundaVariable(
        'boolean',
        grpahicValue,
      );
      camundaFormVariables.__isWord__ = getCamundaVariable('boolean', word);
      if (woDetails.celevelid) {
        camundaFormVariables.__CELevel__ = getCamundaVariable(
          'string',
          woDetails.celevelid,
        );
      } else {
        camundaFormVariables.__CELevel__ = getCamundaVariable('string', false);
      }
      camundaFormVariables.__isESM__ = getCamundaVariable('boolean', false);
      camundaFormVariables.__isRejected__ = getCamundaVariable(
        'boolean',
        false,
      );
      camundaFormVariables.__isReset__ = getCamundaVariable('boolean', 'false');
      let tmpiscopyedit = false;
      if (woDetails.celevelid == '0' || woDetails.celevelid == '1') {
        tmpiscopyedit = false;
      } else {
        tmpiscopyedit = true;
      }
      camundaFormVariables.__iscopyEditing__ = getCamundaVariable(
        'boolean',
        tmpiscopyedit,
      );

      if (
        woDetails.wotype == 'Journal' &&
        (['8'].includes(woDetails.customerid.toString()) ||
          ['13', '10'].includes(woDetails.customerid.toString()))
      ) {
        // customerid 1 is not required after the live migration._DU_Segregation_
        camundaFormVariables.__isArticlewiseIssue__ = getCamundaVariable(
          'boolean',
          articelIssue,
        );
        camundaFormVariables.__isEnableForFirstIteration__ = getCamundaVariable(
          'boolean',
          true,
        );
        // variable for WKH specific
        console.log(files[0], ' files[0]');
        if (woDetails.customerid == '13') {
          camundaFormVariables.__isWord__ = getCamundaVariable(
            'boolean',
            files[0].isword,
          );
          camundaFormVariables.__isUSCustomer__ = getCamundaVariable(
            'boolean',
            woDetails.isuscustomer,
          );
          camundaFormVariables.__iscopyEditing__ = getCamundaVariable(
            'boolean',
            files[0].iscopy,
          );
          camundaFormVariables.__isCopyEditingDespatchNeeded__ =
            getCamundaVariable('boolean', files[0].isCopyEditingDespatchNeeded);
        } else if (
          woDetails.customerid == '8' ||
          woDetails.customerid == '10'
        ) {
          // need to be confirmed with team and deleted unwanted variables
          camundaFormVariables.__isAuthor__ = getCamundaVariable(
            'boolean',
            false,
          );
          camundaFormVariables.__iseonly__ = getCamundaVariable(
            'boolean',
            woDetails.journaltype,
          );
          camundaFormVariables.__isDirectFP__ = getCamundaVariable(
            'boolean',
            false,
          );
          camundaFormVariables.__isNLP__ = getCamundaVariable('boolean', false);
          camundaFormVariables.__isRejected__ = getCamundaVariable(
            'boolean',
            false,
          );
          camundaFormVariables.__isPAP__ = getCamundaVariable('boolean', false);

          camundaFormVariables.__isCover__ = getCamundaVariable(
            'boolean',
            coverValue,
          );
          camundaFormVariables.__isAdvert__ = getCamundaVariable(
            'boolean',
            advertValue,
          );
          camundaFormVariables.__isRunOn__ = getCamundaVariable(
            'boolean',
            runOnValue,
          );
          camundaFormVariables.__isXMLCorr__ = getCamundaVariable(
            'boolean',
            'false',
          );
          camundaFormVariables.__isTextCorr__ = getCamundaVariable(
            'boolean',
            'false',
          );
        }
      } else if (woDetails.customerid == '70') {
        camundaFormVariables.__isprePub__ = getCamundaVariable(
          'boolean',
          woDetails.isonlineissue,
        );
      }

      files = files.filter(list => list.filetypeid != 10);
      const data = {
        woid: woDetails.workorderid,
        workFlow: woDetails.workflow,
        woStageId: woDetails.wostageid,
        service: woDetails.service,
        stagename: woDetails.stagename,
        valuesOfArray: files,
        chapters: {
          received: files.length,
          total:
            woDetails.wotype !== 'Journal'
              ? woDetails.totalchaptercount
              : files.length,
        },
        receiptdate: new Date(woDetails.ordermaildate).toISOString(),
        jobcardId: woDetails.jobcardid,
        userid: 'System',
        wotype: woDetails.wotype,
        customerId: woDetails.customerid,
        duId: woDetails.assignedduid,
        stageId: woDetails.wfstageid,
        wfId: woDetails.wfid,
        camundaFormVariables: camundaFormVariables || {},
        graphicVariables,
        isWordInput,
        isJournalInput,
        iscopyEditingLevel,
        iseonly,
        isiAuthor,
        isNLP,
        isDirectFP,
        ceLevel,
        flowtype,
        isreject,
        isPAP,
        isESM,
        duedate: new Date(woDetails.plannedenddate).toISOString(),
        updatedby: 'System',
        fileNameISBN: `${woDetails.itemcode}_Issue`,
        doiNumber: woDetails.doinumber ? woDetails.doinumber : '',
        jobId: woDetails.itemcode,
        jobType: jobTypeObj[woDetails.jobtype],
      };
      logger.info(data, 'camunda data for spriner');
      const camundaResponse = await _saveBookCompleted(
        { body: data },
        { res: {} },
      );
      console.log(camundaResponse);
      if (camundaResponse.status == false) {
        resolve(false);
      } else {
        resolve(true);
      }
    } catch (error) {
      resolve(false);
    }
  });
};
export const saveArticleToMapping = async (resData, woDetails, files) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename,
        );
        const fileType = {
          fileTypeName: filteredFiles[0].filetype,
          fileTypeId: filteredFiles[0].filetypeid,
          fileId: res.woincomingfileid,
        };
        const paths = await getFolderPathForFileType(woDetails, fileType);
        console.log(paths, 'path for issue article file');
        const sql = `select wo.workorderid,woservice.serviceid from wms_workorder  as wo
        join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
        where itemcode = '${res.filename}' `;
        const srcFileDetails = await query(sql);
        if (srcFileDetails && srcFileDetails.length > 0) {
          const data = {
            desFolderPath: paths,
            workorderId: srcFileDetails[0].workorderid,
            serviceId: srcFileDetails[0].serviceid,
            customerId: woDetails.customerid,
          };

          const copyFileDetail = await _copyArticleToIssue(
            { body: data },
            { res: {} },
          );
          console.log('copy file details', copyFileDetail);
          res.fileuuid = copyFileDetail.uuid ? copyFileDetail.uuid : '';
          res.filepath = copyFileDetail.path ? copyFileDetail.path : '';
          const resArray = [];
          resArray.push(res);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }

      // copy non article type to issue zip file copy//

      const nonArticleTypes = files.filter(
        list =>
          list.filetype == 'Cover' ||
          list.filetype == 'TOC' ||
          list.filetype == 'Advert',
      );
      const nonarticlesql = `select woincomingfileid,filetypes.filetype,filename,* from wms_workorder_incoming as incoming
      join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
      join pp_mst_filetype as filetypes on filetypes.filetypeid = indetails.filetypeid
      where incoming.woid = ${woDetails.workorderid} and filetypes.filetypeid in (6,5,17)`;
      const incomingDetails = await query(nonarticlesql);
      for (let j = 0; j < incomingDetails.length; j++) {
        const fileType = {
          fileTypeName: incomingDetails[j].filetype,
          fileTypeId: incomingDetails[j].filetypeid,
          fileId: incomingDetails[j].woincomingfileid,
        };
        const findIndex = files.findIndex(
          list => list.filetype == incomingDetails[j].filetype,
        );
        if (findIndex != -1) {
          files[findIndex].woincomingfileid =
            incomingDetails[j].woincomingfileid;
        }
        const paths = await getFolderPathForFileType(woDetails, fileType);
        const data = {
          desFolderPath: paths,
          srcFilePath:
            nonArticleTypes.length > 0 ? nonArticleTypes[0].filepath : '',
          workorderId: woDetails.workorderid,
        };
        if (nonArticleTypes.length > 0) {
          const copyFileDetail1 = await _copyNonArticleToIssue(
            { body: data },
            { res: {} },
          );
          console.log('copy file details', copyFileDetail1);
          const res = incomingDetails[j];
          res.duedate = new Date(incomingDetails[j].duedate).toISOString();
          res.fileuuid = copyFileDetail1.uuid ? copyFileDetail1.uuid : '';
          res.filepath = copyFileDetail1.path ? copyFileDetail1.path : '';
          const resArray = [];
          resArray.push(res);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const saveArticleToMappingForSpringerIssue = async (
  resData,
  woDetails,
  files,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename && list.filetypeid == '4',
        );
        if (filteredFiles && filteredFiles.length > 0) {
          const fileType = {
            fileTypeName: filteredFiles[0].filetype,
            fileTypeId: filteredFiles[0].filetypeid,
            fileId: res.woincomingfileid,
          };
          const paths = await getFolderPathForFileType(woDetails, fileType);
          console.log(paths, 'path for issue article file');
          const sql = `select wo.workorderid,woservice.serviceid from wms_workorder  as wo
        join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
        where itemcode = '${res.filename}' `;
          const srcFileDetails = await query(sql);
          if (srcFileDetails && srcFileDetails.length > 0) {
            const data = {
              desFolderPath: paths,
              workorderId: srcFileDetails[0].workorderid,
              serviceId: srcFileDetails[0].serviceid,
              customerId: woDetails.customerid,
            };

            const copyFileDetail = await _copyArticleToIssue(
              { body: data },
              { res: {} },
            );
            console.log('copy file details springer issue', copyFileDetail);
            const resArray = [];
            if (copyFileDetail && copyFileDetail.length > 0) {
              res.fileuuid = copyFileDetail[0].uuid
                ? copyFileDetail[0].uuid
                : '';
              res.filepath = copyFileDetail[0].path
                ? copyFileDetail[0].path
                : '';
              resArray.push(res);
            } else {
              res.fileuuid =
                copyFileDetail && copyFileDetail.uuid
                  ? copyFileDetail.uuid
                  : '';
              res.filepath =
                copyFileDetail && copyFileDetail.path
                  ? copyFileDetail.path
                  : '';
              resArray.push(res);
            }

            const data1 = {
              valuesOfArray: resArray,
              action: 'update',
              woid: woDetails.workorderid,
            };
            await _updateChapter({ body: data1 }, { res: {} });
          }
        }
      }
      // copy non article type to issue zip file copy//

      const nonArticleTypes = files.filter(
        list =>
          list.filetype == 'Cover' ||
          list.filetype == 'Frontmatter' ||
          list.filetype == 'Advert' ||
          list.filetype == 'TOC' ||
          list.filetype == 'Backmatter',
      );
      const nonarticlesql = `select woincomingfileid,filetypes.filetype,filename,* from wms_workorder_incoming as incoming
      join wms_workorder_incomingfiledetails as indetails on indetails.woincomingid = incoming.woincomingid
      join pp_mst_filetype as filetypes on filetypes.filetypeid = indetails.filetypeid
      where incoming.woid = ${woDetails.workorderid} and filetypes.filetypeid in (6,5,18,19)`;
      const incomingDetails = await query(nonarticlesql);
      for (let j = 0; j < incomingDetails.length; j++) {
        const fileType = {
          fileTypeName: incomingDetails[j].filetype,
          fileTypeId: incomingDetails[j].filetypeid,
          fileId: incomingDetails[j].woincomingfileid,
        };
        const findIndex = files.findIndex(
          list => list.filetype == incomingDetails[j].filetype,
        );
        if (findIndex != -1) {
          files[findIndex].woincomingfileid =
            incomingDetails[j].woincomingfileid;
        }
        const paths = await getFolderPathForFileType(woDetails, fileType);
        const data = {
          desFolderPath: paths,
          srcFilePath:
            nonArticleTypes.length > 0 ? nonArticleTypes[0].filepath : '',
          workorderId: woDetails.workorderid,
        };
        if (nonArticleTypes.length > 0) {
          const copyFileDetail1 = await _copyNonArticleToIssue(
            { body: data },
            { res: {} },
          );
          console.log('copy file details', copyFileDetail1);
          const res = incomingDetails[j];
          res.duedate = new Date(incomingDetails[j].duedate).toISOString();
          res.fileuuid = copyFileDetail1.uuid ? copyFileDetail1.uuid : '';
          res.filepath = copyFileDetail1.path ? copyFileDetail1.path : '';
          const resArray = [];
          resArray.push(res);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const saveArticleToMappingForSpringer = async (
  resData,
  woDetails,
  files,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename,
        );
        const fileType = {
          fileTypeName: filteredFiles[0].filetype,
          fileTypeId: filteredFiles[0].filetypeid,
          fileId: res.woincomingfileid,
        };
        const paths = await getFolderPathForFileType(woDetails, fileType);
        console.log(paths, 'path for issue article file');

        // let copyData = {};
        // const dmsType = await getdmsType(woDetails.workorderid);
        // const name = basename(files[0].filepath);
        // switch (dmsType) {
        //   case 'azure':
        //     copyData = await azureHelper._copyFile({
        //       srcPath: files[0].filepath,
        //       destBasePath: path,
        //       name,
        //     });
        //     break;
        //   default:
        //     const destUuid = await _createFolder(path);
        //     copyData = await _copyFile({
        //       src: 'openkm',
        //       dest: destUuid,
        //       destBasePath: path,
        //       name,
        //     });
        // }
        // tempArr.push(copyData);
        // console.log('copied file', copyData);
        //   console.log('copy file details', copyData);
        res.fileuuid = 'azure';
        res.filepath = paths || '';
        const resArray = [];
        resArray.push(res);
        const data1 = {
          valuesOfArray: resArray,
          action: 'update',
          woid: woDetails.workorderid,
        };
        await _updateChapter({ body: data1 }, { res: {} });
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const saveArticleToMappingForWKHJournals = async (
  resData,
  woDetails,
  files,
) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < resData.length; i++) {
        const res = resData[i];
        res.duedate = new Date(res.duedate).toISOString();
        const filteredFiles = files.filter(
          list => list.filename == res.filename,
        );
        const fileType = {
          fileTypeName: filteredFiles[0].filetype,
          fileTypeId: filteredFiles[0].filetypeid,
          fileId: res.woincomingfileid,
        };
        let paths = await getFolderPathForFileType(woDetails, fileType);
        paths = join(paths, '');

        console.log(paths, 'path for issue article file');

        let copyData = {};
        const dmsType = await getdmsType(woDetails.workorderid);
        const name = basename(files[0].filepath);
        const tempArr = [];
        switch (dmsType) {
          case 'azure':
            copyData = await azureHelper._copyFile({
              srcPath: files[0].filepath,
              destBasePath: paths,
              name,
            });
            break;
          case 'local':
            copyData = await localHelper._localcopyFile({
              srcPath: files[0].filepath,
              destBasePath: paths,
              name,
            });
            break;
          default:
            const destUuid = await _createFolder(paths);
            copyData = await _copyFile({
              src: 'openkm',
              dest: destUuid,
              destBasePath: paths,
              name,
            });
        }
        tempArr.push(copyData);
        console.log('copied file', copyData);
        console.log('copy file details', copyData);
        res.fileuuid = 'azure';
        res.filepath = tempArr[0].path || '';
        const resArray = [];
        resArray.push(res);
        const data1 = {
          valuesOfArray: resArray,
          action: 'update',
          woid: woDetails.workorderid,
        };
        await _updateChapter({ body: data1 }, { res: {} });
      }

      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

export const getFolderPathForFileType = (item, fileType) => {
  return new Promise(async (resolve, reject) => {
    const {
      customername,
      customerid,
      assignedduid,
      duname,
      workorderid,
      servicename,
      serviceid,
    } = item;
    const du = { id: assignedduid, name: duname };
    const service = { id: serviceid, name: servicename };
    const folderPathData = {
      // eslint-disable-next-line no-constant-condition
      type: true ? 'wo_incoming_file_subtype' : 'wo_incoming_filetype',
      du,
      customer: {
        name: customername,
        id: customerid,
      },
      workOrderId: workorderid,
      service,
      fileType: {
        name: fileType.fileTypeName,
        id: fileType.fileTypeId,
        fileId: fileType.fileId,
      },
    };
    try {
      const paths = await getFolderStructure(folderPathData);
      resolve(paths);
    } catch (e) {
      reject(e);
    }
  });
};

export const _saveChapter = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const {
      woid,
      service,
      stageid,
      receiptdate,
      duedate,
      updatedby,
      batchno,
      valuesOfArray,
      totalNonArticleCount,
      totalArticleCount,
    } = req.body;
    console.log(req.body);
    try {
      await transaction(async client => {
        let continueFlow = true;
        if (totalNonArticleCount && totalArticleCount) {
          let tempArticleCount = 0;
          let tempNonArticleCount = 0;
          valuesOfArray.forEach(vr => {
            if (vr.filetypeid === '4') {
              tempArticleCount += 1;
            }
            if (vr.filetypeid === '9') {
              tempNonArticleCount += 1;
            }
          });
          const sql = `SELECT filetypeid,count(*) FROM wms_workorder_incomingfiledetails incoming left join wms_workorder_incoming incomingfiles
          on incomingfiles.woincomingid=incoming.woincomingid where incomingfiles.woid=${woid} group by filetypeid`;
          const { rows: dataCount } = await client.query(sql);
          if (dataCount && dataCount.length > 0) {
            dataCount.forEach(dc => {
              if (dc.filetypeid === '4' && tempArticleCount > 0) {
                if (+dc.count + tempArticleCount > +totalArticleCount)
                  continueFlow = false;
              } else if (dc.filetypeid === '9' && tempNonArticleCount > 0) {
                if (+dc.count + tempNonArticleCount > +totalNonArticleCount)
                  continueFlow = false;
              }
            });
          }
        }
        if (continueFlow) {
          let sql = `INSERT INTO public.wms_workorder_incoming(woid, serviceid, stageid, receiptdate, duedate, updatedby, batchno,updatedon)
                   VALUES (${woid}, ${service.id}, ${stageid}, '${receiptdate}', '${duedate}', 
                     '${updatedby}', ${batchno},current_timestamp) RETURNING woincomingid`;
          const { rows: resForEntry } = await client.query(sql);
          const val = [];
          valuesOfArray.forEach(list => {
            const piinumber = list.pii ? list.pii : null;
            const articletype = list.articletype ? list.articletype : null;
            val.push(
              `(${resForEntry[0].woincomingid},'${list.filename}','${
                list.filepath
              }','${list.fileuuid}','${list.duedate}',${list.mspages},${
                list.estimatedpages
              },${list.imagecount},${list.tablecount},${list.equationcount},${
                list.boxcount ? list.boxcount : null
              },${list.filetypeid},false,${
                list.filesequence ? list.filesequence : null
              },${list.wordcount ? list.wordcount : null},${
                list.referencecount ? list.referencecount : null
              },'${piinumber || null}','${articletype || null}', ${
                list.ishalfpage ? list.ishalfpage : false
              }
              )`,
            );
          });
          sql = `INSERT INTO public.wms_workorder_incomingfiledetails(
                          woincomingid, filename, filepath, fileuuid, duedate, mspages, estimatedpages, imagecount, tablecount, equationcount,boxcount,filetypeid,istriggered,filesequence,wordcount,referencecount,piinumber,articletype, ishalfpage)
                          VALUES ${val} RETURNING * `;
          const { rows: resForChapter } = await client.query(sql);
          const folderPath = [];
          console.log(res, 'resres');
          resolve({
            data: resForChapter,
            path: folderPath,
            isFirstIncoming: true,
            message: 'Chapter has been added successfully',
          });
        } else {
          resolve({ message: 'Total Article or Non Article exceed.' });
        }
      });
    } catch (error) {
      logger.info('springer _saveChapter', error);
      // res.status(400).send({ message: error });
      reject(error);
    }
  });
};

export const saveChapter = async (req, res) => {
  try {
    const result = await _saveChapter(req, res);
    res.send({ status: true, ...result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const updateChapter = async (req, res) => {
  try {
    const result = await _updateChapter(req, res);
    res.send({ status: true, ...result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const _updateChapter = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { valuesOfArray, action, woid } = req.body;
    logger.info('updateChapter', req.body);
    try {
      let fileExists = [];
      if (action !== 'add' && valuesOfArray.length === 1) {
        const condition = `AND filename IN ('${
          valuesOfArray[0].filename
        }') AND  woincomingfileid != ${valuesOfArray[0].woincomingfileid}
        ${
          valuesOfArray[0].filepath
            ? `AND filepath = '${valuesOfArray[0].filepath}'`
            : ''
        }`;
        const sqlForFileExists = `SELECT filename FROM wms_workorder_incoming
            JOIN wms_workorder_incomingfiledetails ON wms_workorder_incomingfiledetails.woincomingid = wms_workorder_incoming.woincomingid
             ${condition}
            WHERE  wms_workorder_incoming.woid = ${woid} `;
        fileExists = await query(sqlForFileExists);
      }
      // have to changes from  > to <
      if (fileExists.length < 1) {
        const files = [];
        for (let i = 0; i < valuesOfArray.length; i++) {
          const {
            woincomingid,
            filetypeid,
            filename,
            mspages,
            estimatedpages,
            imagecount,
            tablecount,
            equationcount,
            woincomingfileid,
            filepath,
            fileuuid,
            duedate,
            boxcount,
            wordcount,
            referencecount,
          } = valuesOfArray[i];

          const sql = `UPDATE wms_workorder_incomingfiledetails
            SET woincomingid=${woincomingid}, filetypeid='${filetypeid}', filename='${filename}', filepath='${filepath}', 
            fileuuid='${fileuuid}', duedate='${duedate}', mspages=${mspages}, estimatedpages=${estimatedpages}, imagecount=${imagecount},
            tablecount=${tablecount}, equationcount=${equationcount},boxcount=${boxcount},wordcount=${wordcount}, referencecount=${referencecount} 
            WHERE woincomingfileid = ${woincomingfileid}`;
          files.push({ id: woincomingfileid });
          await query(sql);
          const sql1 = `UPDATE public.wms_workorder_incoming SET updatedon = current_timestamp
        WHERE woincomingid = ${woincomingid} `;
          await query(sql1);
        }
        console.log(res);
        // res
        //   .status(200)
        //   .json({ message: 'Chapter has been updated successfully' });
        resolve({ message: 'Chapter has been updated successfully' });
      } else {
        let existFiles = '';
        fileExists.forEach((file, i) => {
          existFiles += `'${file.filename}' ${
            fileExists.length - 1 !== i ? ',' : ''
          }`;
        });
        // res
        //   .status(409)
        //   .json({ message: `Chapter name already exists: ${existFiles}` });
        resolve({ message: `Chapter name already exists: ${existFiles}` });
      }
    } catch (error) {
      logger.info(error);
      reject({ message: error.message ? error.message : error });
      // res.status(400).send({ message: error.message ? error.message : error });
    }
  });
};
export const _saveBookCompleted = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const {
      woid,
      service,
      stagename,
      workFlow,
      woStageId,
      chapters,
      valuesOfArray,
      wotype,
      camundaFormVariables,
      jobType,
      graphicVariables,
      isWordInput,
      isJournalInput,
      iscopyEditingLevel,
      isiAuthor,
      iseonly,
      isNLP,
      isDirectFP,
      flowtype,
      ceLevel,
      isreject,
      isAltText,
      isPAP,
      isESM,
      customerId,
      stageId,
      wfId,
    } = req.body;
    const stage = {
      type: stagename.toLowerCase().replace(/ /g, '_'),
      iteration: 1,
    };

    logger.info(req.body, 'payload - incoming.js suradha');
    try {
      const files = [];
      const unTriggeredArray = [];
      let iscopyediting = false;
      const wosql = `SELECT 
                    workorderid,itemcode, createdon :: timestamp(0) as jobcreatedon,celevelid, 
                    CASE WHEN customerid = 10 THEN 
                    CASE WHEN celevelid> 2 THEN true ELSE false END
                    ELSE 
                    CASE WHEN celevelid> 1 THEN true ELSE false END
                    END AS iscopyediting
                  FROM wms_workorder 
                  WHERE workorderid = $1`;
      const workorderdata = await query(wosql, [woid]);

      if (workorderdata.length) {
        iscopyediting = workorderdata.length
          ? workorderdata[0].iscopyediting
          : false;
      }

      let sql = `SELECT processinstanceid FROM public.wms_workorder_service where serviceid = $1 and workorderid = $2`;
      let [{ processinstanceid: processInstanceId }] = await query(sql, [
        service.id,
        woid,
      ]);
      const fileids = [];
      valuesOfArray.forEach(ele => {
        fileids.push(ele.woincomingfileid);
      });
      sql = `select istriggered, wms_workorder_incomingfiledetails.filetypeid,imagecount,woincomingfileid,filename,filetypes.filetype,mspages,estimatedpages from wms_workorder_incomingfiledetails
      join pp_mst_filetype as filetypes on filetypes.filetypeid = wms_workorder_incomingfiledetails.filetypeid
       where woincomingfileid in (${fileids.join(',')})`;
      const data = await query(sql, []);
      data.forEach(ele => {
        if (
          !ele.istriggered &&
          workFlow.incoming.fileTypes.includes(parseInt(ele.filetypeid))
        ) {
          if (jobType === 'Issue' && wotype == 'Journal') {
            files.push({
              id: ele.woincomingfileid,
              isGraphic: parseInt(ele.imagecount) > 0,
              type: ele.filetype,
              filetypeid: ele.filetypeid,
              name: ele.filename,
              isChecked: false,
              mspages: ele.mspages,
              estimatedpages: ele.estimatedpages,
            });
          } else {
            files.push({
              id: ele.woincomingfileid,
              isGraphic: parseInt(ele.imagecount) > 0,
            });
          }

          unTriggeredArray.push(
            ...valuesOfArray.filter(
              x => x.woincomingfileid == ele.woincomingfileid,
            ),
          );
        }
      });
      // check the iTracks call
      let iTracksObj = { status: true, message: '' };
      const isItracksAPI = await checkItracksExits(req, res);
      console.log(isItracksAPI, 'isItracksAPI');
      const { status } = isItracksAPI;
      if (wotype === 'Book') {
        await addNewFileType(req, 1);
        if (status && unTriggeredArray.length) {
          console.log(appConfig.isItracksAPI, 'start the subjob call');

          sql = `SELECT * FROM public.wms_workorder_incoming as wwi
        JOIN public.wms_workorder_incomingfiledetails as wwif ON wwif.woincomingid = wwi.woincomingid
        where wwi.woid = $1`;
          const getIncomingFiles = await query(sql, [woid]);
          console.log(getIncomingFiles, 'getIncomingFiles');

          // call iTracks API
          req.body.stageIterationCount = 1;
          const subJobRes = await addSubJob(
            getIncomingFiles,
            req.body,
            true,
            false,
          );
          iTracksObj = subJobRes;
        }
      } else if (jobType === 'Issue') {
        // call merge issue
        if (status) {
          const mergeIssueRes = await mergeIssue(unTriggeredArray, req.body);
          iTracksObj = mergeIssueRes;
        }
        // add issue type
        await addNewFileType(req, 10);
        if (status) {
          iTracksObj = await addSatge(req.body);
        }
      } else {
        let addStageRes;

        // console.log(relatedstagedet);
        // add stage for journal
        if (status) {
          if (woid > 1976 && customerId == '13') {
            let relatedstageObj = [];
            const relatedstagedet = await relatedStageInfo(
              wfId,
              customerId,
              stageId,
              woid,
            );

            if (relatedstagedet.issuccess) {
              relatedstageObj = relatedstagedet.data;
            }
            // const objreqbody = req.body;
            for (let rindex = 0; rindex < relatedstageObj.length; rindex++) {
              if (
                relatedstageObj[rindex].stageid == 24 &&
                iscopyediting == false
              ) {
                console.log('test');
              } else {
                if (stageId != relatedstageObj[rindex].stageid) {
                  req.body.stageId = relatedstageObj[rindex].stageid;
                  req.body.isrelatedstage = true;
                } else {
                  req.body.isrelatedstage = false;
                }
                addStageRes = await addSatge(req.body);
                if (
                  addStageRes.status == undefined ||
                  addStageRes.status == false
                ) {
                  break;
                }
              }
            }
          } else {
            addStageRes = await addSatge(req.body);
          }
          iTracksObj = addStageRes;
        }
        req.body.stageId = stageId;
        // if (status) {
        //   addStageRes = await addSatge(req.body);
        //   iTracksObj = addStageRes;
        // }
      }

      // iTracksObj.status = false;
      console.log(iTracksObj, 'iTracksObj');
      if (iTracksObj.status) {
        const addeddate = new Date();

        logger.info(
          addeddate,
          ' new date incoming savebookcompleted - suradha1',
        );

        addeddate.setHours(addeddate.getHours() + 5);
        addeddate.setMinutes(addeddate.getMinutes() + 30);

        logger.info(
          addeddate,
          'added date incoming savebookcompleted - suradha1',
        );

        const currentdate = convertDateFormat(addeddate);

        logger.info(
          currentdate,
          'current date incoming savebookcompleted - suradha1',
        );

        console.log(iTracksObj.status, 'iTracksObj.status');
        if (!processInstanceId) {
          // let m_reviseddate = currentdate;
          // if (wotype === 'Journal') {
          //   const psql = `SELECT
          //   (SELECT  add_hours_exclude_weekends_and_holidays
          //   FROM add_hours_exclude_weekends_and_holidays($3::timestamp, duc.articleduedays ::integer))::timestamp(0) as revisedenddate
          //   ,wst.wfstageid
          //   FROM wms_workorder as wo
          //   JOIN wms_workorder_stage AS wst on wst.workorderid = wo.workorderid and wst.wostageid = $2
          //   JOIN public.org_mst_journal_dueconfig as duc on duc.journalid = wo.journalid and duc.stageid = wst.wfstageid
          //   WHERE wo.workorderid = $1   and duc.stageiterationcount = 1 and duc.isactive = true;`;

          //   await query(psql, [woid, woStageId, currentdate]).then(
          //     async dataresult => {
          //       if (dataresult && dataresult.length) {
          //         // console.log(dataresult);
          //         const newreviseddate = convertDateFormat(
          //           dataresult[0].revisedenddate,
          //         );
          //         m_reviseddate = newreviseddate;
          //       } else {
          //         m_reviseddate = currentdate;
          //       }
          //     },
          //   );
          // }

          sql = `UPDATE public.wms_workorder_stage SET status=$1, startdatetime= $2  where wostageid =$3`;
          await query(sql, [
            'In Process',
            // new Date(),
            currentdate,
            woStageId,
          ]);
          processInstanceId = await triggerWorkflow(
            workFlow.category,
            workFlow.id,
            woid,
            service.id,
            stage,
            files,
            workFlow.enableListener,
            undefined,
            camundaFormVariables,
            graphicVariables,
            isWordInput,
            isJournalInput,
            iscopyEditingLevel,
            isiAuthor,
            iseonly,
            isNLP,
            isDirectFP,
            flowtype,
            ceLevel,
            isreject,
            isAltText,
            isPAP,
            isESM,
          );
          // processInstanceId = await triggerWorkflow(workFlow.category, workFlow.id, woid, service.id, stage, files, workFlow.enableListener, undefined, camundaFormVariables);
          sql = `UPDATE public.wms_workorder_service SET processinstanceid=$1, status=$2 where serviceid = $3 and workorderid = $4`;
          await query(sql, [processInstanceId, 'In Process', service.id, woid]);
        } else {
          await triggerWorkflow(
            workFlow.category,
            workFlow.id,
            woid,
            service.id,
            stage,
            files,
            workFlow.enableListener,
            processInstanceId,
          );
        }
        for (let i = 0; i < files.length; i++) {
          sql = `UPDATE public.wms_workorder_incomingfiledetails SET istriggered=true where woincomingfileid=${files[i].id}`;
          await query(sql, []);
        }
        if (chapters.total == chapters.received)
          await bookComplete(
            woid,
            service.id,
            workFlow.category,
            chapters.total,
            stage.type,
            workFlow.enableListener,
            processInstanceId,
          );

        resolve({ message: 'WF Triggered successfully', status: true });
      } else {
        console.log('inside err');
        resolve({ message: iTracksObj.message, status: false });
      }
    } catch (e) {
      logger.info(e);
      reject({ message: e.message ? e.message : e, status: false });
    }
  });
};

export const _getFormattedName = async (req, res) => {
  try {
    const { unFormattedName, placeHolders } = req.body;
    const result = await getFormattedName(unFormattedName, placeHolders);
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};
export const saveBookCompleted = async (req, res) => {
  try {
    const result = await _saveBookCompleted(req, res);
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, data: e });
  }
};

export const bookComplete = async (
  woid,
  serviceId,
  category,
  totalChapters,
  stageType,
  enableListener,
  processInstanceId,
) => {
  const stage = {
    type: stageType,
  };
  await triggerBookCompleted(
    category,
    processInstanceId,
    stage,
    totalChapters,
    enableListener,
  );
  const sql = `UPDATE wms_workorder_service SET isbookcompleted= true WHERE workorderid=$1 AND serviceid=$2`;
  await query(sql, [woid, serviceId]);
  await updateServiceStatus(woid, serviceId, processInstanceId, true);
};

const addNewFileType = async (req, fileTypeId) => {
  const {
    woid,
    service,
    stageId,
    receiptdate,
    duedate,
    updatedby,
    fileNameISBN,
    valuesOfArray,
  } = req.body;
  const filteredFiles = valuesOfArray.filter(item => item.filetypeid != 1);

  const sql = `SELECT count(*) FROM public.wms_workorder_incoming as wwi
  JOIN public.wms_workorder_incomingfiledetails as wwif ON wwif.woincomingid = wwi.woincomingid
  where wwi.woid = $1 and filetypeid=$2`;
  return new Promise(async (resolve, reject) => {
    try {
      const [{ count }] = await query(sql, [woid, fileTypeId]);
      if (count == 0) {
        await transaction(async client => {
          let sqlQuery = `INSERT INTO public.wms_workorder_incoming(woid, serviceid, stageid, receiptdatetime, duedate, updatedby,updatedon)
                    VALUES (${woid}, ${service.id}, ${stageId}, '${receiptdate}', '${duedate}', '${updatedby}',current_timestamp) RETURNING woincomingid`;
          const { rows: resForEntry } = await client.query(sqlQuery);
          sqlQuery = `INSERT INTO public.wms_workorder_incomingfiledetails(
                                    woincomingid, filename, duedate, filetypeid, istriggered, filesequence)
                                    VALUES (${
                                      resForEntry[0].woincomingid
                                    }, '${fileNameISBN}', '${duedate}', ${fileTypeId}, false, ${
            filteredFiles.length + 1
          } ) RETURNING * `;
          await client.query(sqlQuery);
        });
      }
      logger.info('New File Type has been added successfully');

      resolve('New File Type has been added successfully');
    } catch (e) {
      reject(e.message ? e.message : e);
    }
  });
};

// const deleteChapterEntry = woid => {
//   return new Promise((resolve, reject) => {
//     const sql = `SELECT * FROM wms_workorder_incoming WHERE woid = ${woid}`;
//     logger.info(sql, 'sql for delete');
//     query(sql)
//       .then(data => {
//         let woincomingid = '';
//         data.map((item, i) => {
//           woincomingid +=
//             data.length - 1 !== i ? `${item.woincomingid},` : item.woincomingid;
//         });
//         logger.info(woincomingid, 'woincomingid');
//         const sql = `DELETE FROM wms_workorder_incomingfiledetails
//             WHERE woincomingid IN (${woincomingid})`;
//         logger.info(sql, 'sql for delete');
//         query(sql)
//           .then(data => {
//             const sql = `DELETE FROM wms_workorder_incoming WHERE woid = ${woid}`;
//             logger.info(sql, 'sql for delete in');
//             query(sql)
//               .then(data => {
//                 const sql = resolve(true);
//               })
//               .catch(error => {
//                 reject(false);
//               });
//           })
//           .catch(error => {
//             reject(false);
//           });
//       })
//       .catch(error => {
//         reject(false);
//       });
//   });
// };

export const deleteChapter = (req, res) => {
  const reqData = req.body;
  let sql = `DELETE FROM wms_workorder_incomingfiledetails
    WHERE woincomingfileid = ${reqData.id} returning *`;
  logger.info(sql, 'sql for delete');
  query(sql)
    .then(data => {
      if (reqData.sequence) {
        sql = `update wms_workorder_incomingfiledetails set filesequence=filesequence-1 where woincomingid = ${data[0].woincomingid} and filesequence>${reqData.sequence}`;
        console.log('Reordering the file sequence', sql);
        query(sql).then(() => {
          res.status(200).json({ message: 'Record deleted successfully' });
        });
      } else {
        res.status(200).json({ message: 'Record deleted successfully' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getIncomingData = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'inn coming');
  let sql = '';
  if (reqData.type === 'files') {
    sql = `SELECT woif.woincomingfileid,woif.filetypeid, woif.filename, woif.fileuuid, woif.filepath,
        woif.duedate, woif.mspages,woif.wordcount,woif.referencecount, woif.estimatedpages,woif.imagecount,woif.tablecount,
        woif.equationcount,woif.boxcount, woif.woincomingid,woif.istriggered,woif.filesequence FROM wms_workorder_incoming as wo
        JOIN  wms_workorder_incomingfiledetails as woif ON wo.woincomingid = woif.woincomingid
        WHERE wo.woid = ${reqData.workorderId} ORDER BY woincomingfileid`;
  } else if (reqData.type === 'incoming slot') {
    sql = `SELECT * FROM public.wms_workorder_incomingfiledetails as incomingdetails
    left join pp_mst_filetype as filetype on filetype.filetypeid = incomingdetails.filetypeid 
        WHERE woincomingid = ${reqData.woincomingid} ORDER BY woincomingfileid ASC`;
  } else {
    sql = `SELECT  woi.woincomingid,st.stagename,sv.servicename, woi.receiptdatetime, woi.updatedon, woi.duedate, woi.batchno, users.username||' ('|| woi.updatedby||')' as updatedby, (SELECT COUNT (*) FROM wms_workorder_incomingfiledetails 
        JOIN wms_workorder_incoming on wms_workorder_incoming.woincomingid = wms_workorder_incomingfiledetails.woincomingid 
        WHERE wms_workorder_incomingfiledetails.woincomingid = woi.woincomingid) AS noofchapters FROM wms_workorder_incoming as woi
                JOIN  wms_mst_stage as st ON woi.stageid = st.stageid
                JOIN  wms_mst_service as sv ON woi.serviceid = sv.serviceid
                JOIN wms_user as users ON woi.updatedby = users.userid
        WHERE woi.woid = ${reqData.workorderId} ORDER BY woincomingid`;
  }

  logger.info(sql, 'sql');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const exportIncomingData = async (req, res) => {
  try {
    const { id } = req.params;
    const sql = `SELECT infile.filename,ft.filetype,infile.duedate,infile.mspages,infile.estimatedpages,infile.imagecount,infile.tablecount,infile.equationcount	 FROM public.wms_workorder_incomingfiledetails as infile join pp_mst_filetype as ft on ft.filetypeid=infile.filetypeid
        WHERE woincomingid = $1 ORDER BY woincomingfileid ASC`;
    // let sql = `SELECT * FROM public.wms_workorder_incomingfiledetails
    // WHERE woincomingid = $1 ORDER BY woincomingfileid ASC`;
    const wbData = await query(sql, [id]);
    const wbField = {
      'File Name': 'filename',
      'File Type': 'filetype',
      'Chapter / Article': 'filename',
      'MS Pages': 'mspages',
      'Est. Pages': 'estimatedpages',
      'Image Count': 'imagecount',
      Tables: 'tablecount',
      Equations: 'equationcount',
    };
    exportToExcel(
      wbData,
      wbField,
      `incoming-report ${new Date()}`,
      'incoming-report',
      res,
    );
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error.message ? error.message : error });
  }
};

export const remainingChaptersCount = (req, res) => {
  const { workorderId } = req.body;
  const sql = `
    Select count(*), (SELECT totalchaptercount from wms_workorder where workorderid = ${workorderId}) as noofchapters 
    from wms_workorder_incomingfiledetails
      JOIN wms_workorder_incoming on wms_workorder_incoming.woincomingid = wms_workorder_incomingfiledetails.woincomingid
        WHERE wms_workorder_incoming.woid = ${workorderId} AND wms_workorder_incomingfiledetails.filetypeid = 2`;
  query(sql)
    .then(data => {
      logger.info(data, 'sdfjsd');
      const chapterCount =
        data.length > 0 ? data[0].noofchapters - data[0].count : 0;
      res.status(200).json({ data: chapterCount });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// for options in dropdown
export const getTemplateListOptions = (req, res) => {
  const { customerId, softwareId, duId } = req.body;
  const sql = `
  select distinct on (templatename) templateid as value,templatename as label from public.wms_mst_composingsw_templates 
  where duId=${duId} and composingswid=${softwareId} and customerid=${customerId} and isactive = true and isdelete = false
  order by templatename, templateid desc`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// for db entry
export const updateTemplateList = async (req, res) => {
  try {
    await transaction(async client => {
      const { woId, templateId, userId } = req.body;
      let sql = `Update public.wms_workorder_swtemplate SET isactive='false' where workorderid=${woId} RETURNING *;`;
      await client.query(sql, []);
      sql = `INSERT INTO public.wms_workorder_swtemplate(workorderid,templateid,updatedby,updatedon,isactive) VALUES ($1,$2,$3,current_timestamp,true) RETURNING * ;`;
      await client.query(sql, [woId, templateId, userId]);
      res.status(200).json({ message: 'Template Updated' });
    });
  } catch (e) {
    logger.info(e);
    res.status(400).json({ data: 'error', message: e });
  }
};

export const getSelectedTemplate = async (req, res) => {
  const { workorderId } = req.body;
  const sql = `SELECT * FROM public.wms_workorder_swtemplate as wotemplate
        join wms_mst_composingsw_templates as templates on templates.templateid = wotemplate.templateid
        where wotemplate.workorderid = ${workorderId} and wotemplate.isactive = true
        ORDER BY wotemplid ASC `;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// preload the template field
export const templateList = async (req, res) => {
  const { woId } = req.body;
  const sql = `SELECT * FROM public.wms_workorder_swtemplate where workorderid=${woId} and isactive=true`;
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getArticleIssueList = (req, res) => {
  const reqData = req.body;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
  }
  logger.info(sql, 'sqlsql');
  sql = `SELECT * FROM public.wms_unassigned_list ${
    condition ? `WHERE${condition}` : condition
  }`;
  query(sql)
    .then(data => {
      logger.info('activity', data);
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const saveAssignedArticle = (req, res) => {
  console.log('inside insert assigned article', req.body);
  const { workorderId, listOfArray } = req.body;
  for (let i = 0; i < listOfArray.length; i++) {
    const sql = `INSERT INTO public.wms_issue_workorder(
      issueworkorderid, articleworkorderid, woincomingfileid)
       VALUES (${workorderId}, ${listOfArray[i].workorderid}, ${listOfArray[i].woincomingfileid})`;
    query(sql)
      .then(data => {
        logger.info('Save Article', data);
      })
      .catch(error => {
        logger.info(error);
      });
  }
  res.status(200).send({ message: 'Article Assigned Successfully' });
};
export const getAssignedArticleList = (req, res) => {
  const { workorderId } = req.body;
  const sql = `SELECT idetails.filetypeid,filetype.filetype, wo.doinumber,wo.title AS jobname,idetails.filepath,idetails.filename,idetails.fileuuid,
issuewo.assignedissuewoid, issuewo.issueworkorderid,issuewo.articleworkorderid,issuewo.woincomingfileid,wo.workorderid,idetails.mspages,idetails.estimatedpages,idetails.imagecount,idetails.tablecount,idetails.equationcount,idetails.boxcount
  FROM wms_workorder wo
   JOIN wms_workorder_incoming incoming ON incoming.woid = wo.workorderid
    JOIN wms_workorder_incomingfiledetails idetails ON idetails.woincomingid = incoming.woincomingid
    JOIN pp_mst_filetype filetype on filetype.filetypeid=idetails.filetypeid
    LEFT JOIN wms_issue_workorder issuewo ON issuewo.articleworkorderid = wo.workorderid
 WHERE (wo.jobtype::text = '1'::text or wo.jobtype::text = '3'::text) AND issuewo.issueworkorderid=${workorderId}
 ORDER BY wo.workorderid;`;
  query(sql)
    .then(data => {
      res.status(200).send({ data });
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ message: 'Error in Fetching Assigned Article' });
    });
};
export const deleteAssignedArticle = (req, res) => {
  const { incomingfileid } = req.body;
  logger.info('delete Assigned Article', req.body);
  const sql = `DELETE FROM public.wms_issue_workorder WHERE woincomingfileid=${incomingfileid};`;
  query(sql)
    .then(() => {
      res.status(200).send({ message: 'Delete Successfull' });
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ message: 'Error in Delete Assigned Article' });
    });
};

export const _copyArticleToIssue = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, serviceId, desFolderPath } = req.body;
    try {
      const dmsType = await getdmsType(workorderId);
      const fileDetails = await getDespatchFiles(workorderId, serviceId);
      const tempArr = [];
      const isReject = [];
      let resOfOutput = [];
      if (fileDetails && fileDetails.length > 0) {
        for (let j = 0; j < fileDetails.length; j++) {
          const fileDetail = fileDetails[j];
          const name = basename(fileDetail.path);
          let copyData = {};
          switch (dmsType) {
            case 'azure':
              copyData = await azureHelper._copyFile({
                srcPath: fileDetail.path,
                destBasePath: desFolderPath,
                name,
              });
              break;
            case 'local':
              copyData = await fileCopyHelper._localcopyFile({
                srcPath: fileDetail.path,
                destBasePath: desFolderPath,
                name,
              });
              break;
            default:
              const destUuid = await _createFolder(desFolderPath);
              copyData = await _copyFile({
                src: fileDetail.uuid,
                dest: destUuid,
                destBasePath: desFolderPath,
                name,
              });
          }
          tempArr.push(copyData);
          if (dmsType == 'local' && !copyData.exist) {
            reject(`src file are not available ${fileDetail.path}`);
          }
          console.log('copied file', copyData);
        }
        if (
          Object.keys(req.body).includes('customerId') &&
          req.body.customerId == 10
        ) {
          resOfOutput = tempArr;
          resolve(resOfOutput);
        } else {
          const resOfOutput2 = tempArr.filter(item =>
            item.path.includes('.pdf'),
          );
          const [firstItem] = resOfOutput2;
          resOfOutput = firstItem;
          resolve(resOfOutput);
        }
      } else {
        isReject.push(workorderId);
      }
      if (isReject.length == 0) {
        resolve(resOfOutput);
      } else {
        reject(`src file are not available for this ${workorderId}`);
      }
      console.log(res, 'resres');

      // res.status(200).send({ data: resOfOutput[0] });
    } catch (error) {
      const mesg = error.message ? error.message : error;
      reject(mesg);
      // res.status(400).send({ message: error.message ? error.message : error });
    }
  });
};

export const _copyNonArticleToIssue = async (req, res) => {
  return new Promise(async (resolve, reject) => {
    const { desFolderPath, srcFilePath } = req.body;
    try {
      const tempArr = [];
      const srcPath = srcFilePath;
      const srcName = basename(srcFilePath);
      let dmsType = 'azrure';
      if (
        Object.keys(req.body).includes('workorderId') &&
        req.body.workorderId
      ) {
        dmsType = await getdmsType(req.body.workorderId);
      }
      let copyData = {};
      switch (dmsType) {
        case 'azure':
          copyData = await azureHelper._copyFile({
            srcPath,
            destBasePath: desFolderPath,
            name: srcName,
          });
          break;
        case 'local':
          copyData = await fileCopyHelper._localcopyFile({
            srcPath,
            destBasePath: desFolderPath,
            name: srcName,
          });
          break;
        default:
          const destUuid = await _createFolder(desFolderPath);
          copyData = await _copyFile({
            srcPath,
            dest: destUuid,
            destBasePath: desFolderPath,
            name: srcName,
          });
      }

      tempArr.push(copyData);
      console.log('copied file', copyData);
      const resOfOutput = tempArr.filter(item => item.path.includes('.zip'));
      resolve(resOfOutput[0]);
      console.log(res, 'resres');
    } catch (error) {
      const mesg = error.message ? error.message : error;
      reject(mesg);
    }
  });
};

export const copyArticleToIssue = async (req, res) => {
  try {
    const result = await _copyArticleToIssue(req, res);
    res.send({ status: true, data: result });
  } catch (e) {
    res.send({ status: false, message: e });
  }
};

const getDespatchFiles = async (woID, serviceId) => {
  return new Promise(async (resolve, reject) => {
    const sql = `SELECT wms_workflowactivitytrn_file_map.repofilepath as path, 
  wms_workflowactivitytrn_file_map.repofileuuid as uuid,
  wms_workflowactivitytrn_file_map.woincomingfileid as fileid,
  wms_workorder_incomingfiledetails.filetypeid,
  wms_workorder_incomingfiledetails.filename,
pp_mst_filetype.filetype
  FROM public.wms_workflowactivitytrn_file_map 
  left join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
left join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
  where wfeventid = (SELECT eventlog.wfeventid FROM public.wms_workflow_eventlog as eventlog
 JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = eventlog.wfdefid
   JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
  where workorderid = $1 and serviceid = $2 and  wms_mst_activity.iscompletiontriggeractivity = $3
  ORDER BY wfeventid desc limit 1)`;
    try {
      const queryResult = await query(sql, [woID, serviceId, true]);
      resolve(queryResult);
    } catch (error) {
      reject(error);
    }
  });
};

export const getArticleStatus = async (req, res) => {
  const { workorderId } = req.body;
  const sql = ` select count(1) from wms_issue_workorder where articleworkorderid=$1`;
  try {
    const queryResult = await query(sql, [workorderId]);
    logger.info('query result', queryResult);
    res.status(200).send({ data: queryResult });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getEnableListener = (req, res) => {
  const { workorderId } = req.body;
  logger.info('enable listend', req.body);
  const sql = `SELECT * FROM public.wms_workorder_service as service
  left join wms_workflow as workflow on workflow.wfid = service.wfid
  where service.workorderid = ${workorderId}`;
  query(sql)
    .then(response => {
      res.status(200).send({ data: response });
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ data: error });
    });
};

export const updateCamundaDetails = async (req, res) => {
  const { camundaVariableObj, woId } = req.body;
  console.log(req.body, 'camundaalal');
  const sql = `UPDATE public.wms_workorder SET camundaform= $1 WHERE workorderid=$2`;
  console.log(sql, 'sqlfoororuoddd');
  await query(sql, [camundaVariableObj, woId])
    .then(() => {
      res.status(200).json({ message: 'camunda details updated successfully' });
    })
    .catch(error => {
      res
        .status(400)
        .send({ data: error.message ? error.message : error, status: false });
    });
};

export const getWOSourceFileDetails = (req, res) => {
  const { duId, woId, serviceId, stageId, stageIterationCount } = req.body;
  const sql = `SELECT *, uploadpath as path FROM public.wms_workorder_sourcefile_details
  where duid=${duId} and workorderid = ${woId} and serviceid=${serviceId} and stageId=${stageId} and stageiterationcount=${stageIterationCount}`;
  logger.info(sql, 'sql form source download');
  query(sql)
    .then(response => {
      res.status(200).send({ data: response.length > 0 ? response[0] : '' });
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ data: error });
    });
};

function convertDateFormat(inputDate) {
  // Parse the input date using a JavaScript Date object
  const parsedDate = new Date(inputDate);

  if (Number.isNaN(parsedDate)) {
    return 'Invalid Date'; // Handle invalid date input
  }

  // Format the date into 'YYYY-MM-DD HH:mm:ss' using the Date methods
  const year = parsedDate.getFullYear();
  const month = (parsedDate.getMonth() + 1).toString().padStart(2, '0');
  const day = parsedDate.getDate().toString().padStart(2, '0');
  const hours = parsedDate.getHours().toString().padStart(2, '0');
  const minutes = parsedDate.getMinutes().toString().padStart(2, '0');
  const seconds = parsedDate.getSeconds().toString().padStart(2, '0');

  // Create the formatted date string
  const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  return formattedDate;
}

// Auto incoming creation from API trigger based customer
export const _autoIncomingCreationFromAPI = async data => {
  return new Promise(async (resolve, reject) => {
    const { workorderId, files, containerType, jobType, fileType } = data;
    try {
      let sql = `select wo.workorderid,woservice.serviceid,service.servicename,wostage.wfstageid,updatedby,plannedenddate,coalesce(wostage.ordermaildatetime,now()::timestamp(0) + interval '330 minute')::timestamp(0) as ordermaildate,wo.customerid,cust.customername,woservice.assignedduid,du.duname,wo.otherfield,jo.isnlp,woservice.wfid,wo.wotype,wo.journalid,
      case when jo.journaltype = 'online' then true else false end as journaltype,
            wf.wfname, wf.wfcategory, wf.wfname_bpmnid, wf.config as wfconfig,wostage.wostageid,stage.stagename,wo.totalchaptercount,wo.jobcardid,wo.itemcode,wo.title,wo.jobtype,jo.runon,jo.cover,jo.advert,jo.runontype,jo.celevelid, wo.isonlineissue
            from wms_workorder as wo
            join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
            JOIN wms_mst_service  as service On service.serviceid = woservice.serviceid
            JOIN wms_workorder_stage as wostage on wostage.workorderid = wo.workorderid 
            JOIN org_mst_customer as cust ON cust.customerid = wo.customerid
            JOIN org_mst_deliveryunit as du ON du.duid = woservice.assignedduid
            LEFT JOIN pp_mst_journal as jo on wo.journalid = jo.journalid
            JOIN  wms_workflow as wf ON wf.wfid = woservice.wfid
            JOIN wms_mst_stage as stage on wostage.wfstageid = stage.stageid
            where wo.workorderid = ${workorderId} order by wostageid limit 1`;
      // and updatedon is not null
      const woDetails = await query(sql);
      if (woDetails.length) {
        // files.forEach(async fi => {
        //   sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        //   const fileTypeRes = await query(sql);
        //   fi.filetypeid = fileTypeRes[0].filetypeid;
        //   fi.filetype = fileTypeRes[0].filetype;
        // });
        sql = `select * from pp_mst_filetype where filetype = '${fileType}'`;
        const fileTypeRes = await query(sql);
        files[0].filetypeid = fileTypeRes[0].filetypeid;
        files[0].filetype = fileTypeRes[0].filetype;

        const workflow = {
          name: woDetails[0].wfname,
          id: woDetails[0].wfname_bpmnid,
          category: woDetails[0].wfcategory,
          enableListener: woDetails[0].wfconfig
            ? !!woDetails[0].wfconfig.enableListener
            : false,
          incoming: {
            fileTypes:
              woDetails[0].wfconfig &&
              woDetails[0].wfconfig.incoming &&
              woDetails[0].wfconfig.incoming.fileTypes
                ? woDetails[0].wfconfig.incoming.fileTypes
                : [],
          },
        };
        const service = {
          id: woDetails[0].serviceid,
          name: woDetails[0].servicename,
        };
        woDetails[0].workflow = workflow;
        woDetails[0].service = service;
        const payload = {
          woid: workorderId,
          service: {
            id: woDetails[0].serviceid,
            name: woDetails[0].servicename,
          },
          stageid: woDetails[0].wfstageid,
          receiptdate: new Date(woDetails[0].ordermaildate).toISOString(),
          duedate: new Date(woDetails[0].plannedenddate).toISOString(),
          updatedby: woDetails[0].updatedby,
          batchno: 0,
          valuesOfArray: files,
          totalArticleCount: 1,
          totalNonArticleCount: 0,
          totalCount: 0,
          totalChapterCount: null,
          fileNameISBN: '',
        };
        const response = await _saveChapter({ body: payload }, { res: {} });
        logger.info('before auto incoming file copy');
        const fileCopyPayload = {
          resData: response.data,
          woDetails: woDetails[0],
          files,
          containerType,
          jobTypeName: jobTypeObj[jobType],
        };
        await fileCopyForAutoIncoming(fileCopyPayload);
        logger.info('after auto incoming file copy');
        for (let k = 0; k < files.length; k++) {
          const filteredObj = response.data.find(
            sublist => sublist.filename == files[k].filename,
          );
          files[k].woincomingfileid = files[k].woincomingfileid
            ? files[k].woincomingfileid
            : filteredObj.woincomingfileid;
        }
        logger.info('wkh api triggerCamundaWorkflow', woDetails[0]);
        await triggerCamundaWorkflow(woDetails[0], files);
        resolve({
          message: `Auto incoming success for ${workorderId}`,
          data: {
            stageId: woDetails[0].wfstageid,
            stageName: woDetails[0].stagename,
            iteration: 1,
          },
          status: true,
        });
      } else {
        reject({
          message: `Auto incoming failed due to wokflow details not found for ${workorderId}`,
        });
      }
    } catch (e) {
      logger.info('Auto incoming failed for', e);
      reject({
        message: e.message
          ? e.message
          : `Auto incoming failed for ${workorderId}`,
        status: false,
      });
    }
  });
};

export const fileCopyForAutoIncoming = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { resData, woDetails, files, containerType, jobTypeName } = data;
      for (let i = 0; i < resData.length; i++) {
        if (resData[i].filetypeid != 10) {
          resData[i].duedate = new Date(resData[i].duedate).toISOString();
          const filteredObj = files.find(
            list => list.filename == resData[i].filename,
          );
          const fileType = {
            fileTypeName: filteredObj.filetype,
            fileTypeId: filteredObj.filetypeid,
            fileId: resData[i].woincomingfileid,
          };
          logger.info('get folder structure for file type', fileType);
          const path = await getFolderPathForFileType(woDetails, fileType);
          let fileResponse = {};
          if (jobTypeName == 'Article') {
            // file copy for article
            fileResponse = await fileCopyForArticle({
              containerType,
              woDetails,
              files,
              path,
              fileName: filteredObj.filename + filteredObj.extention,
              woIncomingFileId: resData[i].woincomingfileid,
            });
          } else {
            // copy file for issue
            fileResponse = await fileCopyForIssue({
              containerType,
              woDetails,
              files,
              path,
              fileName: filteredObj.filename,
              woIncomingFileId: resData[i].woincomingfileid,
            });
          }
          resData[i].fileuuid = fileResponse.uuid;
          resData[i].filepath = fileResponse.path;
          const resArray = [];
          resArray.push(resData[i]);
          const data1 = {
            valuesOfArray: resArray,
            action: 'update',
            woid: woDetails.workorderid,
          };
          await _updateChapter({ body: data1 }, { res: {} });
        }
      }
      resolve();
    } catch (e) {
      logger.info('fileCopyForAutoIncoming local-blob', e);
      reject(e);
    }
  });
};

// file copy for article
export const fileCopyForArticle = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { containerType, woDetails, files, path, fileName } = data;
      let copyData = {};
      const dmsType = await getdmsType(woDetails.workorderid);
      switch (dmsType) {
        case 'azure':
          copyData = await fileCopyHelper.copyExternalBlobToBlob({
            srcPath: files[0].filepath,
            destBasePath: path,
            name: fileName,
            customerName: woDetails.customername,
            customerId: woDetails.customerid,
            containerType,
          });

          break;
        case 'local':
          copyData = await fileCopyHelper.copyExternalBlobToLocal({
            srcPath: files[0].filepath,
            destBasePath: path,
            name: fileName,
            customerName: woDetails.customername,
            customerId: woDetails.customerid,
            containerType,
          });
          break;
        default:
          const destUuid = await _createFolder(path);
          copyData = await _copyFile({
            src: 'openkm',
            dest: destUuid,
            destBasePath: path,
            name: fileName,
          });
      }
      resolve(copyData);
    } catch (e) {
      reject(e);
    }
  });
};
// file copy for issue
export const fileCopyForIssue = async data => {
  return new Promise(async (resolve, reject) => {
    try {
      const { woDetails, path, fileName, woIncomingFileId } = data;
      const sql = `select wo.workorderid,woservice.serviceid from wms_workorder  as wo
        join wms_workorder_service as woservice on woservice.workorderid = wo.workorderid
        where itemcode = '${fileName}' `;
      const srcFileDetails = await query(sql);
      if (srcFileDetails && srcFileDetails.length > 0) {
        const dmsType = await getdmsType(woDetails.workorderid);
        const fileDetails = await getDespatchFilesForIssue(
          srcFileDetails[0].workorderid,
          srcFileDetails[0].serviceid,
        );
        const tempArr = [];
        let resOfOutput = {};
        if (fileDetails && fileDetails.length > 0) {
          for (let j = 0; j < fileDetails.length; j++) {
            const fileDetail = fileDetails[j];
            const name = basename(fileDetail.path);
            let copyData = {};
            switch (dmsType) {
              case 'azure':
                copyData = await azureHelper._copyFile({
                  srcPath: fileDetail.path,
                  destBasePath: path,
                  name,
                });
                tempArr.push(copyData);
                break;
              case 'local':
                copyData = await fileCopyHelper._localcopyFile({
                  srcPath: fileDetail.path,
                  destBasePath: path,
                  name,
                });
                tempArr.push(copyData);
                break;
              default:
                const destUuid = await _createFolder(path);
                copyData = await _copyFile({
                  src: fileDetail.uuid,
                  dest: destUuid,
                  destBasePath: path,
                  name,
                });
                tempArr.push(copyData);
            }
          }
          resOfOutput = tempArr.find(item => item.path.includes('.3d'));
          if (Object.keys(resOfOutput).length > 0) {
            await workorderMappingToIssue({
              sourceWorkorderId: srcFileDetails[0].workorderid,
              issueWorkorderId: woDetails.workorderid,
              woIncomingFileId,
            });
            resolve(resOfOutput);
          } else {
            reject({ message: 'Article file was not found', status: false });
          }
        } else {
          reject({
            status: false,
            message: `src file are not available for this ${woDetails.workorderid}`,
          });
        }
      }
    } catch (error) {
      const mesg = error.message ? error.message : error;
      reject({ status: false, message: mesg });
    }
  });
};

// get dispatch files for issue
const getDespatchFilesForIssue = async (woID, serviceId) => {
  return new Promise(async (resolve, reject) => {
    const sql = `SELECT wms_workflowactivitytrn_file_map.repofilepath as path, 
  wms_workflowactivitytrn_file_map.repofileuuid as uuid,
  wms_workflowactivitytrn_file_map.woincomingfileid as fileid,
  wms_workorder_incomingfiledetails.filetypeid,
  wms_workorder_incomingfiledetails.filename,
pp_mst_filetype.filetype
  FROM public.wms_workflowactivitytrn_file_map 
  left join wms_workorder_incomingfiledetails on wms_workorder_incomingfiledetails.woincomingfileid = wms_workflowactivitytrn_file_map.woincomingfileid
left join pp_mst_filetype on pp_mst_filetype.filetypeid = wms_workorder_incomingfiledetails.filetypeid
  where wfeventid = (SELECT eventlog.wfeventid FROM public.wms_workflow_eventlog as eventlog
 JOIN wms_workflowdefinition ON wms_workflowdefinition.wfdefid = eventlog.wfdefid
   JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
  where workorderid = $1 and serviceid = $2 and eventlog.wfdefid=1118
  ORDER BY wfeventid desc limit 1)`;
    // and  wms_mst_activity.iscompletiontriggeractivity = $3 true
    try {
      const queryResult = await query(sql, [woID, serviceId]);
      resolve(queryResult);
    } catch (error) {
      reject(error);
    }
  });
};
// workorder mapping to issue
const workorderMappingToIssue = async data => {
  return new Promise(async (resolve, reject) => {
    const { sourceWorkorderId, issueWorkorderId, woIncomingFileId } = data;
    const sql = `INSERT INTO public.wms_issue_workorder(issueworkorderid, articleworkorderid, woincomingfileid)
       VALUES (${issueWorkorderId}, ${sourceWorkorderId}, ${woIncomingFileId})`;
    try {
      await query(sql);
      resolve();
    } catch (error) {
      reject(error);
    }
  });
};
