import { config } from '../../config/restApi.js';
import { Service } from '../../httpClient/index.js';
import { query } from '../../database/postgres.js';
import { getPlaceHolderFields } from '../task/fileDetails.js';
import logger from '../utils/logs/index.js';
import { _isFileExist } from '../utils/okm/index.js';
import { sendToTaskQueue } from '../../mq/index.js';
import { getFolderStructure } from '../utils/wmsFolder/index.js';
import * as azureHelper from '../utils/azure/index.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';
// Activity Module
// to get the details for master activity
const service = new Service();
export const convertdifferentFileConfig = async (inputJson, wfdefid) => {
  console.log('inn', inputJson, wfdefid);
  return new Promise(async (resolve, reject) => {
    try {
      const outputFormat = {
        files: [],
      };

      for (const fileTypeId in inputJson.fileTypes) {
        if (
          Object.prototype.hasOwnProperty.call(inputJson.fileTypes, fileTypeId)
        ) {
          const fileType = inputJson.fileTypes[fileTypeId];

          // Process files within each file type
          fileType.files.forEach(file => {
            const outputFile = {
              name: file.name,
              fileFlowType: ['IN'],
              fileTypes: [parseInt(fileTypeId)],
              mandatoryCheck: {
                save: file.mandatoryCheck
                  ? file.mandatoryCheck.save === true
                  : false,
                pending: file.mandatoryCheck
                  ? file.mandatoryCheck.pending === true
                  : false,
                cancel: file.mandatoryCheck
                  ? file.mandatoryCheck.cancel === true
                  : false,
                hold: file.mandatoryCheck
                  ? file.mandatoryCheck.hold === true
                  : false,
                reject: file.mandatoryCheck
                  ? file.mandatoryCheck.reject === true
                  : false,
              },
              isUOM: !!file.isUOM,
              softwareOpen: !!file.softwareOpen,
              overwrite: !!file.overwrite,
              backup: {
                enable: false,
                limit: '',
                duration: '',
              },
              custom: [],
            };

            // Check if mandatoryCheck is specified
            if (file.mandatoryCheck && file.mandatoryCheck.save) {
              outputFile.backup.enable = true;
              outputFile.backup.limit = 5;
              outputFile.backup.duration = 60000;
              outputFile.fileFlowType.push('OUT');
            }

            // Check if custom properties are specified
            if (file.custom) {
              outputFile.custom.push(Object.keys(file.custom)[0]);
            }

            // Add the processed file to the output format
            outputFormat.files.push(outputFile);
          });
        }
      }

      const keyToFind = 'name';

      const groupedByValue = outputFormat.files.reduce((result, obj) => {
        const value = obj[keyToFind];

        // Create an array for the value if it doesn't exist
        if (!result[value]) {
          result[value] = [];
        }

        // Push the object to the array
        result[value].push(obj);

        return result;
      }, {});
      console.log(groupedByValue, 'groupedByValue');
      const originalData = [];
      Object.entries(groupedByValue).forEach(([fileName, fileInfoArray]) => {
        console.log(`File Name: ${fileName}`);
        // Iterate over the array of objects for each file name
        fileInfoArray.forEach(fileInfo => {
          const check =
            originalData.length > 0 &&
            originalData.filter(list => list.name == fileInfo.name);
          if (check && check.length > 0) {
            const index = originalData.findIndex(
              item => item.name === check[0].name,
            );
            originalData[index].fileTypes.push(fileInfo.fileTypes[0]);
          } else {
            originalData.push(fileInfo);
          }
          console.log(' Object:', fileInfo);
        });
      });
      const newFiles = { files: originalData };
      const newFileConfig = JSON.stringify(newFiles);
      console.log(newFileConfig, 'newFileConfig');
      const sql = `update wms_workflowdefinition set fileconfig='${newFileConfig}' where wfdefid =${wfdefid}`;
      console.log(sql, 'sql');
      await query(sql);
      resolve();
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

// This part check for different filetypes like Book

export const convertdifferentFileConfigAll = async (req, res) => {
  console.log(req, res);
  const { stageid, wfid, _wfdefid } = req.body;
  console.log(stageid, wfid, 'tesss');
  try {
    let sql = ``;
    if (_wfdefid) {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and activityid !=21 and wfdefid =${_wfdefid} and fileconfig IS NOT NULL
      order by sequence `;
    } else {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and  activityid !=21 and stageid =${stageid} and fileconfig IS NOT NULL 
      order by sequence `;
    }

    console.log(sql, 'sql');
    const fileInfo = await query(sql);
    for (let i = 0; i < fileInfo.length; i++) {
      const inputPayload = fileInfo[i].fileconfig_old;
      const { wfdefid } = fileInfo[i];
      await convertdifferentFileConfig(inputPayload, wfdefid);
    }
    res
      .status(200)
      .json({ message: 'Fileconfig has been updated successfully' });
  } catch (error) {
    res.status(400).json({ message: 'Fileconfig update failed' });
    console.log(error);
  }
};

// end different filetypes

// This part only for fileconfig start
export const _convertNewFileConfig = async (inputPayload, wfdefid) => {
  console.log('inn', inputPayload, wfdefid);
  return new Promise(async (resolve, reject) => {
    try {
      // if (inputPayload.fileTypes && inputPayload.fileTypes.length > 0) {
      const type = JSON.parse(Object.keys(inputPayload.fileTypes)[0]);
      const files1 = inputPayload.fileTypes[type].files.map(file => {
        const convertedFile = {
          name: file.name,
          fileFlowType: ['IN'],
          fileTypes: [type],
          mandatoryCheck: {
            save: file.mandatoryCheck
              ? file.mandatoryCheck.save === true
              : false,
            pending: file.mandatoryCheck
              ? file.mandatoryCheck.pending === true
              : false,
            cancel: file.mandatoryCheck
              ? file.mandatoryCheck.cancel === true
              : false,
            hold: file.mandatoryCheck
              ? file.mandatoryCheck.hold === true
              : false,
            reject: file.mandatoryCheck
              ? file.mandatoryCheck.reject === true
              : false,
          },
          isUOM: !!file.isUOM,
          softwareOpen: !!file.softwareOpen,
          overwrite: !!file.overwrite,
          backup: {
            enable: false,
            limit: '',
            duration: '',
          },
          custom: [],
        };

        if (file.mandatoryCheck && file.mandatoryCheck.save) {
          convertedFile.backup.enable = true;
          convertedFile.backup.limit = 5;
          convertedFile.backup.duration = 60000;
          convertedFile.fileFlowType.push('OUT');
        }

        if (file.custom) {
          convertedFile.custom.push(Object.keys(file.custom)[0]);
        }

        return convertedFile;
      });
      const newFiles = { files: files1 };
      console.log(newFiles, 'newFiles');

      const newFileConfig = JSON.stringify(newFiles);
      console.log(newFileConfig, 'newFileConfig');
      const sql = `update wms_workflowdefinition set fileconfig='${newFileConfig}' where wfdefid =${wfdefid}`;
      console.log(sql, 'sql');
      await query(sql);
      // }
      resolve();
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

export const convertNewFileConfig = async (req, res) => {
  console.log(req, res);
  const { stageid, wfid, _wfdefid } = req.body;
  console.log(stageid, wfid, 'tesss');
  try {
    let sql = ``;
    if (_wfdefid) {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and activityid !=21 and wfdefid =${_wfdefid} and fileconfig IS NOT NULL
      order by sequence `;
    } else {
      sql = `select  fileconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and  activityid !=21 and stageid =${stageid} and fileconfig IS NOT NULL 
      order by sequence `;
    }

    console.log(sql, 'sql');
    const fileInfo = await query(sql);
    for (let i = 0; i < fileInfo.length; i++) {
      const inputPayload = fileInfo[i].fileconfig_old;
      const { wfdefid } = fileInfo[i];
      await _convertNewFileConfig(inputPayload, wfdefid);
    }
    res
      .status(200)
      .json({ message: 'Fileconfig has been updated successfully' });
  } catch (error) {
    res.status(400).json({ message: 'Fileconfig update failed' });
    console.log(error);
  }
};

// This part only for config start
export const converNewConfig = async (req, res) => {
  console.log(req, res);
  const { stageid, wfid, _wfdefid } = req.body;
  console.log(stageid, wfid, 'tesss');
  try {
    let sql = ``;
    if (_wfdefid) {
      sql = `select  config_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and  activityid !=21 and wfdefid =${_wfdefid} and config IS NOT NULL order by sequence `;
    } else {
      sql = `select  config_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and  activityid !=21 and config IS NOT NULL
      order by sequence `;
    }

    console.log(sql, 'sql');
    const confInfo = await query(sql);
    const response = [];
    for (let i = 0; i < confInfo.length; i++) {
      const inputPayload = confInfo[i].config_old;
      const { wfdefid } = confInfo[i];
      const res1 = await _convertNewConfig(inputPayload, wfdefid);
      response.push(res1);
    }
    res
      .status(200)
      .json({ message: `Config has been updated successfully ${response}` });
  } catch (error) {
    res.status(400).json({ message: 'Config update failed' });
    console.log(error);
  }
};

export const _convertNewConfig = async (originalData, wfdefid) => {
  console.log('inn', originalData, wfdefid);
  return new Promise(async (resolve, reject) => {
    try {
      if (originalData.actions && originalData.actions.workflow) {
        const convertedData = {
          displayName: originalData.displayName,
          os: originalData.os,
          isTypesetPage: originalData.isTypesetPage,
          fileType: 'Batch',
          actions: {
            workflow: {
              save: originalData.actions.workflow.save,
              reject: originalData.actions.workflow.reject,
              hold: originalData.actions.workflow.hold,
              cancel: originalData.actions.workflow.cancel,
              pending: originalData.actions.workflow.pending,
            },
          },
          softwareId: originalData.softwareId,
          toolsId: originalData.toolsId,
          type: originalData.type,
          postActivity: originalData.postActivity,
          preActivity: [],
          onSaveToolsId: [],
          newFileTypes: [],
          newFileTypesExt: [],
          graphicFileFormat: [],
          fileCombination: [],
          allowedFileExtension: [],
          skipFileExtension: [],
        };
        console.log(convertedData, 'convertedData');

        const newConfig = JSON.stringify(convertedData);
        console.log(newConfig, 'newFileConfig');
        const sql = `update wms_workflowdefinition set config='${newConfig}' where wfdefid =${wfdefid}`;
        console.log(sql, 'sql');
        await query(sql);
        resolve();
      } else {
        resolve(`${wfdefid} config is different`);
      }
    } catch (error) {
      console.log(error, 'error');
      reject(error);
    }
  });
};

// config end

// This part only for toolconfig start

export const convertNewToolConfig = async (req, res) => {
  console.log(req, res);

  const { stageid, wfid, _wfdefid } = req.body;
  try {
    let sql = '';
    if (_wfdefid) {
      sql = `select  toolsconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and  activityid !=21 and stageid =${stageid} and wfdefid =${_wfdefid}
      and toolsconfig IS NOT NULL order by sequence `;
    } else {
      sql = `select  toolsconfig_old,wfdefid from  wms_workflowdefinition where wfid=${wfid} and stageid =${stageid} and  activityid !=21
      and toolsconfig IS NOT NULL order by sequence `;
    }

    console.log(sql, 'sql');
    const toolsInfo = await query(sql);
    for (let i = 0; i < toolsInfo.length; i++) {
      const inputPayload = toolsInfo[i].toolsconfig_old;
      const { wfdefid } = toolsInfo[i];
      await _convertNewToolConfig(inputPayload, wfdefid);
    }

    res
      .status(200)
      .json({ message: 'Toolconfig has been updated successfully' });
  } catch (error) {
    console.log(error);
    res.status(400).json({ message: 'Toolconfig update failed' });
  }
};
export const _convertNewToolConfig = async (originalData, wfdefid) => {
  console.log(originalData, 'originalData');

  return new Promise(async (resolve, reject) => {
    try {
      const convertedData = {
        tools: {},
      };
      console.log(convertedData, 'convertedData');

      for (const toolId of Object.keys(originalData.tools)) {
        console.log(toolId);

        const originalTool = originalData.tools[toolId];
        const convertedTool = {
          isToolClick: !!originalTool.isToolClick,
          params:
            originalTool && originalTool.params ? originalTool.params : '',
          files: [],
        };

        console.log(convertedTool, 'convertedTool');

        Object.keys(originalTool.files.input).forEach(inputFileName => {
          const inputFile = originalTool.files.input[inputFileName];
          const params1 =
            inputFile &&
            'params' in inputFile &&
            inputFile.params &&
            inputFile.params.length
              ? inputFile.params
              : '';
          convertedTool.params =
            convertedTool &&
            'params' in convertedTool &&
            convertedTool.params &&
            convertedTool.params.length
              ? convertedTool.params
              : '';

          const fileName =
            inputFile.src && inputFile.src.name
              ? inputFile.src.name
              : inputFile.name;
          const aliasName = fileName.includes('_')
            ? fileName.match(/_([^\.]+)/)[1]
            : '';
          const inputFileType =
            inputFile.src && inputFile.src.typeId
              ? inputFile.src.typeId
              : inputFile.typeId;
          // convertedTool.params.push(
          convertedTool.params =
            convertedTool &&
            'params' in convertedTool &&
            convertedTool.params &&
            convertedTool.params.length
              ? convertedTool.params
              : params1;
          // );
          // console.log(check, 'check');
          convertedTool.files.push({
            // params: params1,
            name: fileName,
            fileTypes: Array.isArray(inputFileType)
              ? inputFileType
              : [inputFileType],
            fileFlowType: ['IN'],
            aliasKey: aliasName,
          });
        });
        Object.entries(originalTool.files.output).forEach(
          ([fileName, fileInfoArray]) => {
            console.log(`File Name: ${fileName}`);
            // Iterate over the array of objects for each file name
            // fileInfoArray.forEach(fileInfo => {
            const check =
              convertedTool.files.length > 0 &&
              convertedTool.files.filter(
                list => list.name == fileInfoArray.name,
              );
            if (check && check.length > 0) {
              const index = convertedTool.files.findIndex(
                item => item.name === check[0].name,
              );
              convertedTool.files[index].fileFlowType.push('OUT');
              convertedTool.files[index].fileopen = true;
            } else {
              // originalData.push(fileInfo);
              console.log(fileInfoArray, 'fileInfoArray');
              const aliasName = fileInfoArray.name.includes('_')
                ? fileInfoArray.name.match(/_([^\.]+)/)[1]
                : '';
              const parameter =
                fileInfoArray && fileInfoArray.params
                  ? fileInfoArray.params
                  : [];

              convertedTool.params =
                convertedTool &&
                'params' in convertedTool &&
                convertedTool.params &&
                convertedTool.params.length
                  ? convertedTool.params
                  : '';

              convertedTool.params =
                convertedTool &&
                'params' in convertedTool &&
                convertedTool.params.length
                  ? convertedTool.params
                  : parameter;
              // console.log(parameter1, 'parameter1');
              // convertedTool.params.pushparameter;
              convertedTool.files.push({
                name: fileInfoArray.name,
                fileTypes: Array.isArray(fileInfoArray.typeId)
                  ? fileInfoArray.typeId
                  : [fileInfoArray.typeId],
                fileFlowType: ['OUT'],
                aliasKey: aliasName,
                fileopen: fileInfoArray.fileopen || false,
              });
            }
            // });
          },
        );

        // Object.keys(originalTool.files.output).forEach(outputFileName => {
        //   const outputFile = originalTool.files.output[outputFileName];
        //   const outputFileType = outputFile.typeId;
        //   const aliasName = outputFile.name.includes('_')
        //     ? outputFile.name.match(/_([^\.]+)/)[1]
        //     : '';
        //   convertedTool.files.push({
        //     name: outputFile.name,
        //     fileTypes: Array.isArray(outputFileType)
        //       ? outputFileType
        //       : [outputFileType],
        //     fileFlowType: ['OUT'],
        //     aliasKey: aliasName,
        //     fileopen: outputFile.fileopen || false,
        //   });
        // });

        convertedData.tools[toolId] = convertedTool;
      }
      console.log(convertedData, 'convertedData');
      const fileData = JSON.stringify(convertedData);
      console.log(fileData, 'fileData');
      const sql = `update wms_workflowdefinition set toolsconfig='${fileData}' where wfdefid =${wfdefid}`;
      console.log(sql, 'sql');
      await query(sql);
      resolve();
    } catch (error) {
      console.log(error);
      reject(error);
    }
  });
};

// This part only for toolconfig end

// convertNewToolConfig({
//   tools: {
//     284: {
//       isToolClick: true,
//       isFileOpen: true,
//       files: {
//         input: {
//           xml: {
//             name: ';FileTypeName;.xml',
//             typeId: 4,
//           },
//           figure: {
//             name: 'Figure.txt',
//             typeId: 4,
//             isSync: false,
//           },
//           bookDetails: {
//             name: 'BookDetails.xml',
//             typeId: 4,
//             isSync: false,
//           },
//           xml_export: {
//             name: 'xml_export_;articleno;_*.xml',
//             typeId: 4,
//             isSync: false,
//           },
//           po_Pdf: {
//             name: ';FileTypeName;_po_*.pdf',
//             typeId: 4,
//             isSync: false,
//           },
//         },
//         output: {
//           pdf: {
//             name: ';FileTypeName;.pdf',
//             typeId: [4],
//             fileopen: true,
//           },
//           aux: {
//             name: ';FileTypeName;.aux',
//             typeId: [4],
//           },
//           tex: {
//             name: ';FileTypeName;.tex',
//             typeId: [4],
//           },
//           xml: {
//             name: ';FileTypeName;.xml',
//             typeId: [4],
//             cancelFile: true,
//           },
//           reportLog: {
//             name: 'Report.log',
//             typeId: [4],
//           },
//         },
//       },
//     },
//     264: {
//       isToolClick: true,
//       params: [],
//       files: {
//         input: [
//           {
//             params: [';__FILE__;'],
//             src: {
//               name: ';FileTypeName;.xml',
//               typeId: [4],
//             },
//             dest: '',
//           },
//         ],
//         output: [],
//         outputFileValidation: [
//           {
//             name: ';FileTypeName;_err.htm',
//             type: 'Single',
//             typeId: [
//               {
//                 id: 4,
//                 isRequired: true,
//               },
//             ],
//           },
//         ],
//       },
//     },
//   },
// });

export const getActivityMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_mst_activity order by 1 desc`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.wms_mst_activity order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in activity master
export const createActivity = (req, res) => {
  const reqData = req.body;
  const status = reqData.status == '1';

  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.wms_mst_activity(activityname, isactive) 
        VALUES ('${reqData.activityName}',${status})`;
  } else {
    sql = `UPDATE public.wms_mst_activity
        SET activityname='${reqData.activityName}', isactive=${status}
        WHERE activityid =${reqData.id}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Activity  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from activity master
export const deleteActivity = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `DELETE FROM public.wms_mst_activity WHERE activityid =${reqData.activityId}`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Activity has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Stage module
// get the details for stage master

export const getStageMasterList = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
    sql = `SELECT COUNT(*) FROM public.wms_mst_stage ${
      condition ? `WHERE${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM public.wms_mst_stage ${
      condition ? `WHERE${condition}` : condition
    }`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `SELECT * FROM public.wms_mst_stage ${
          condition ? `WHERE${condition}` : condition
        }`;
        query(sqlQuery)
          .then(data => {
            logger.info('stage', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in activity master
export const createStage = (req, res) => {
  const reqData = req.body;
  const status = reqData.status == '1';
  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.wms_mst_stage(stagename, isactive) 
        VALUES ('${reqData.stageName}',${status})`;
  } else {
    sql = `UPDATE public.wms_mst_stage
        SET stagename='${reqData.stageName}', isactive=${status}
        WHERE stageid =${reqData.id}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Stage  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from stage master
export const deleteStage = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `DELETE FROM public.wms_mst_stage WHERE stageid =${reqData.stageId}`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({ message: 'Stage has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// SubDivision Module
// get the details for  Subdivision master
export const getSubDivisionMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.org_mst_subdivision`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.org_mst_subdivision order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('subdivision', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in division master
export const createSubDivision = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.org_mst_subdivision(subdivision) 
        VALUES ('${reqData.SubDivisionName}')`;
  } else {
    sql = `UPDATE public.org_mst_subdivision
        SET subdivision='${reqData.SubDivisionName}'
        WHERE subdivisionid =${reqData.id}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Division  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to delete a row from SubDivision master
export const deleteSubDivision = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `DELETE FROM public.org_mst_subdivision WHERE subdivisionid =${reqData.subDivisionId}`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'SubDivison has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// divison module
// get the details for  division master
export const getDivisionMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.org_mst_division `;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.org_mst_division order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('divsion', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in division master
export const createDivision = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.org_mst_division(division) 
        VALUES ('${reqData.divisionName}')`;
  } else {
    sql = `UPDATE public.org_mst_division
        SET division='${reqData.divisionName}'
        WHERE divisionid =${reqData.id}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Division  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to delete a row from Division master
export const deleteDivision = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `DELETE FROM public.org_mst_division WHERE divisionid =${reqData.divisionId}`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Divison has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Location Module
// to get the details for master Location
export const getLocationMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.geo_mst_country`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.geo_mst_country order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('location', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in location master
export const createLocation = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.geo_mst_country(countryname) 
        VALUES ('${reqData.locationName}')`;
  } else {
    sql = `UPDATE public.geo_mst_country
        SET countryname='${reqData.locationName}'
        WHERE countryid =${reqData.id}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Location  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from location master
export const deleteLocation = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `DELETE FROM public.geo_mst_country WHERE countryid =${reqData.locationId}`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Location has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Color Module
// to get the details for master color
export const getColorMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.pp_mst_color`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.pp_mst_color order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('color', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to insert a new row in color master
export const createColor = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO public.pp_mst_color(color) 
        VALUES ('${reqData.colorName}')`;
  } else {
    sql = `UPDATE public.pp_mst_color
        SET color='${reqData.colorName}'
        WHERE colorid =${reqData.id}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Color  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// to delete a row from color master
export const deleteColor = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `DELETE FROM public.pp_mst_color WHERE colorid =${reqData.colorId}`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({ message: 'Color has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Software Module
// to get the details for master Software
export const getSoftwareMasterList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.pp_mst_composingsoftware`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM public.pp_mst_composingsoftware order by 1 desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('software', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in software master
export const createSoftware = (req, res) => {
  const reqData = req.body;
  const status = reqData.status == '1';

  logger.info(reqData, 'reqData');
  let sql = '';
  if (reqData.id === '') {
    sql = `INSERT INTO  public.pp_mst_composingsoftware(softwarename, isactive) 
        VALUES ('${reqData.softwareName}',${status})`;
  } else {
    sql = `UPDATE  public.pp_mst_composingsoftware
        SET softwarename='${reqData.softwareName}', isactive=${status}
        WHERE softwareid =${reqData.id}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res.status(200).json({
        message: `Software  has been ${
          reqData.id ? 'updated' : 'added'
        } successfully`,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to delete a row from software master
export const deleteSoftware = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  const sql = `DELETE FROM  public.pp_mst_composingsoftware WHERE softwareid =${reqData.softwareId}`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(() => {
      res
        .status(200)
        .json({ message: 'Software has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const userList = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_user as users
        LEFT JOIN  geo_mst_country as country ON users.countryid = country.countryid
        LEFT JOIN  org_mst_deliveryunit as du ON users.duid = du.duid`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT users.userid, users.username, users.userpassword, users.useractive, users.useremail, users.duid, du.duname, users.designation, users.countryid, country.countryname, users.useraddress, users.userphone, users.usertype
            FROM public.wms_user as users
             LEFT JOIN  geo_mst_country as country ON users.countryid = country.countryid
             LEFT JOIN  org_mst_deliveryunit as du ON users.duid = du.duid
           order by useractive desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('user list', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const OptionList = (req, res) => {
  const reqData = req.body;
  let sql = '';
  logger.info(reqData, 'reqdata');
  if (reqData.type == 'country') {
    sql = `SELECT countryid as value , countryname as label FROM public.geo_mst_country ORDER BY countryid ASC `;
  } else if (reqData.type == 'du') {
    sql = `SELECT duid as value , duname as label FROM public.org_mst_deliveryunit ORDER BY duid ASC `;
  } else if (reqData.type == 'role') {
    sql = `SELECT roleid as value , rolename as label FROM public.wms_role ORDER BY roleid ASC `;
  } else if (reqData.type == 'skill') {
    sql = `SELECT skillid as value , skillname as label FROM public.wms_mst_skill ORDER BY skillid ASC `;
  } else if (reqData.type == 'skilllevel') {
    sql = `SELECT skilllevelid as value , skilllevel as label FROM public.wms_mst_skilllevel ORDER BY skilllevelid ASC `;
  } else if (reqData.type == 'certlevel') {
    sql = `SELECT certlevelid as value , certlevel as label FROM public.wms_mst_certificationlevel ORDER BY certlevelid ASC `;
  } else if (reqData.type == 'software') {
    sql = `SELECT softwareid as value , softwarename as label FROM public.pp_mst_composingsoftware ORDER BY softwareid ASC `;
  }
  query(sql)
    .then(response => {
      logger.info(response, 'user data..');
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const userRoleList = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'userbody');
  let sql = '';
  let condition;
  if (reqData.type == 'role') {
    if (reqData.userid == null) {
      sql = `select  null as userroleid, null as userid, null as roleid, null as effectivedate, null as isactive, null as isdefault from wms_userrole limit 1`;
    } else {
      condition = `wms_userrole.userid='${reqData.userid}'`;
      // sql = `SELECT wms_userrole.userid, wms_userrole.userroleid ,wms_userrole.effectivedate,wms_userrole.roleid, wms_userrole.isdefault,wms_role.rolename,wms_role.isactive FROM public.wms_userrole left join wms_role on wms_userrole.roleid=wms_role.roleid WHERE ${condition}`;
      // sql = `SELECT * FROM public.wms_userrole WHERE ${condition}`
      sql = `SELECT distinct on (roleid) userroleid, userid, roleid, effectivedate, isactive, isdefault FROM public.wms_userrole WHERE ${condition}`;
    }
  } else if (reqData.type == 'skill') {
    if (reqData.userid == null) {
      sql = `SELECT null as userid, null as username, null as userpassword, null as useractive, null as useremail, null as duid, null as designation, null as countryid, null as useraddress, null as userphone, null as usertype, null as issuperuser, null as mappedduid FROM public.wms_user limit 1`;
    } else {
      condition = `wms_userskill.userid='${reqData.userid}'`;
      // sql = `SELECT * FROM public.wms_userskill WHERE ${condition}`
      sql = `SELECT distinct on (skillid) userskillid,userid, skillid,isactive, effectivefrom, skillelvelid, composingswid, certlevelid
        FROM public.wms_userskill  WHERE ${condition}`;
    }
  } else if (reqData.type == 'user') {
    if (reqData.userid == null) {
      sql = `SELECT null as userid, null as username, null as userpassword, null as useractive, null as useremail, null as duid, null as designation, null as countryid, null as useraddress, null as userphone, null as usertype, null as issuperuser, null as mappedduid FROM public.wms_user limit 1`;
    } else {
      condition = `wms_user.userid='${reqData.userid}'`;
      sql = `SELECT * FROM public.wms_user WHERE ${condition}`;
    }
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(response => {
      logger.info(response, 'user role data..');
      if (reqData.type == 'skill') {
        const skillData = response;
        if (response.length > 0 && reqData.userid != null) {
          const skillId = response.map(data => data.skillid);
          sql = `SELECT * FROM public.wms_tasklist WHERE wms_tasklist.userid = '${reqData.userid}' AND wms_tasklist.skillid  IN (${skillId})`;
          logger.info(sql, 'sqlsql');
          query(sql)
            .then(resp => {
              // updated for fileconfig restructure
              resp.forEach(item => {
                item.fileconfig = ReStructureFileConfig(item.fileconfig);
              });
              res.status(200).json({
                data: {
                  skill: skillData,
                  taskList: resp,
                },
              });
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        } else
          res.status(200).json({
            data: {
              skill: skillData,
              taskList: [],
            },
          });
      } else res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to insert a new row in user list master
export const createUser = (req, res) => {
  const reqData = req.body.data.info;

  /** ***********Create Object then convert to json and pass to dbfunction as json parameter*************** */

  const roleobjarray = req.body.data.role.map(item => {
    const conObj = {};
    conObj.userroleid = item.userroleid;
    conObj.userid = item.userid;
    conObj.roleid = item.roleid;
    conObj.effectivedate = item.effectivedate;
    conObj.isactive = item.isactive;
    conObj.isdefault = item.isdefault;

    return conObj;
  });

  const skillobjarray = req.body.data.skill.map(item => {
    const skillObj = {};
    skillObj.userskillid = item.userskillid;
    skillObj.userid = item.userid;
    skillObj.skillid = item.skillid;
    skillObj.isactive = item.isactive;
    skillObj.effectivefrom = item.effectivefrom;
    skillObj.skillelvelid = item.skillelvelid;
    skillObj.composingswid = item.composingswid;
    skillObj.certlevelid = item.certlevelid;
    return skillObj;
  });

  const jroles = JSON.stringify(roleobjarray);
  const jskill = JSON.stringify(skillobjarray);

  logger.info(reqData, 'reqData create user role');

  const checkUser = `select * from public.wms_user where userid = '${reqData.userid}'`;
  let checkUserLen;
  logger.info(checkUser, 'checkUser');
  query(checkUser).then(async response => {
    console.log(response);
    checkUserLen = response.length;

    let sql = '';
    if (!checkUserLen) {
      sql = `INSERT INTO public.wms_user(duid,useractive,useraddress,useremail,userphone,userid,username,designation) 
        VALUES (${reqData.duid},${reqData.useractive},'${reqData.useraddress}','${reqData.useremail}',${reqData.userphone},'${reqData.userid}','${reqData.username}','${reqData.designation}')`;
    } else {
      sql = `UPDATE public.wms_user
        SET duid='${reqData.duid}' , useractive=${reqData.useractive} , useraddress='${reqData.useraddress}' , useremail='${reqData.useremail}' , userphone='${reqData.userphone}'
        WHERE userid ='${reqData.userid}'`;
    }

    logger.info(sql, 'wms_user');
    query(sql)
      .then(async () => {
        // await createRole(jroles)
        // await createSkill(jskill)
        /** **********User and Skill will create in db function call in loop manner *************** */
        const usql = `select * from userroleskillmap('${jroles}','${jskill}')`;
        console.log(usql, 'roleandskillqry');
        query(usql).then(resp => {
          console.log(resp);
          if (resp) {
            if (resp.length > 0) {
              if (resp[0].id == 'done') {
                res
                  .status(200)
                  .json({ message: 'User information added successfully' });
              } else {
                res.status(400).json({ message: 'User information not added' });
              }
            }
          }
        });

        /** ***************************************************************
         *   old coding - not in use...
         *   same process moved to db function         
         * ***************************************************************
        if (req.body.data.role.length > 0) req.body.data.role.map(data => {
            const reqData = data;
            userrolemap
            logger.info(reqData, 'reqData create user role');
            
            if (reqData.userroleid === "") {
                sql = `INSERT INTO public.wms_userrole(userid, roleid, effectivedate, isactive , isdefault) 
                VALUES ('${reqData.userid}', '${reqData.roleid}', '${reqData.effectivedate}', ${reqData.isactive}, ${reqData.isdefault})`;
            } else {
                sql = `UPDATE public.wms_userrole
                SET isactive=${reqData.isactive} , roleid='${reqData.roleid}'
                WHERE userroleid ='${reqData.userroleid}'`;
            }
            logger.info(sql, 'sqlsql');
            query(sql).then((response) => {
                // res.status(200).json({ message: `User Role has been ${reqData.userroleid ? 'updated' : 'added'} successfully` });

                if (req.body.data.skill.length > 0) req.body.data.skill.map(data => {
                    const reqData = data;
                    logger.info(reqData, 'reqData create user skill');
                    let sql = '';
                    if (reqData.userskillid === "") {
                        sql = `INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid) 
                        VALUES ('${reqData.userid}','${reqData.skillid}',${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid})`;
                    }
                    else {
                        sql = `UPDATE public.wms_userskill
                        SET skillid='${reqData.skillid}', isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
                        WHERE userskillid ='${reqData.userskillid}'`;
                    }
                    logger.info(sql, 'sqlsql');
                    query(sql).then((response) => {
                        res.status(200).json({ message: `User information has been ${reqData.userskillid ? 'updated' : 'added'} successfully` });
                    }).catch((error) => {
                        res.status(400).send({ message: error });
                    });
                })
                else res.status(200).json({ message: `User information has been ${reqData.userroleid ? 'updated' : 'added'} successfully` });


            }).catch((error) => {
                res.status(400).send({ message: error });
            });
        })

        else {
            if (req.body.data.skill.length > 0) req.body.data.skill.map(data => {
                const reqData = data;
                logger.info(reqData, 'reqData create user skill');
                let sql = '';
                if (reqData.userskillid === "") {
                    sql = ` if not exists (select * from wms_userskill where userid = '${reqData.userid}' and skillid = '${reqData.skillid}' and isactive = ${reqData.isactive}) then
                    INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid) 
                    VALUES ('${reqData.userid}','${reqData.skillid}',${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid})
                    end if;
                    `;
                }
                else {
                    sql = `UPDATE public.wms_userskill
                    SET skillid='${reqData.skillid}', isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
                    WHERE userskillid ='${reqData.userskillid}'`;
                }
                logger.info(sql, 'sqlsql');
                query(sql).then((response) => {
                    res.status(200).json({ message: `User information has been ${reqData.userskillid ? 'updated' : 'added'} successfully` });
                }).catch((error) => {
                    res.status(400).send({ message: error });
                });
            })
            else res.status(200).json({ message: `User information has been ${reqData.userroleid ? 'updated' : 'added'} successfully` });
        } */
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  });
};

export const createRole = async (req, res) => {
  try {
    const awaits = [];
    if (req.body.type === 'role') {
      req.body.data.forEach(data => {
        const reqData = data;
        logger.info(reqData, 'reqData create user role');
        let sql = '';
        if (reqData.userroleid === '') {
          sql = `INSERT INTO public.wms_userrole(userid, roleid, effectivedate, isactive , isdefault) 
                VALUES ('${req.body.userid}', '${reqData.roleid}', '${reqData.effectivedate}', ${reqData.isactive}, ${reqData.isdefault}) RETURNING userroleid`;
        } else {
          sql = `UPDATE public.wms_userrole
                SET isactive=${reqData.isactive} , roleid='${reqData.roleid}'
                WHERE userroleid ='${reqData.userroleid}' RETURNING userroleid`;
        }
        awaits.push(query(sql));
      });
    }
    await Promise.all(awaits);
    res
      .status(200)
      .json({ message: `User Role has been updated successfully`, data: {} });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};

export const createSkill = async (req, res) => {
  logger.info(req.body, 'skill');
  try {
    const awaits = [];
    req.body.data.forEach(data => {
      const reqData = data;
      logger.info(reqData, 'reqData create user skill');
      console.log(reqData.userskillid, 'reqData.userskillid');
      let sql;
      if (reqData.userskillid == '') {
        sql = `INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid) 
                VALUES ('${req.body.userList.userid}',${reqData.skillid},${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid})`;
      } else {
        sql = `UPDATE public.wms_userskill
                SET skillid=${reqData.skillid}, isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
                WHERE userskillid =${reqData.userskillid}`;
      }
      console.log(sql, 'ifblock');
      awaits.push(query(sql));
    });
    await Promise.all(awaits);
    res
      .status(200)
      .json({ message: `User Skill has been updated successfully`, data: {} });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
};
// export const createSkill = (req, res) => {
//     logger.info(req.body, 'skill')
//     req.body.data.map(data => {
//         const reqData = data;
//         logger.info(reqData, 'reqData create user skill');
//         let sql = '';
//         if (reqData.userskillid === "") {
//             sql = `INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid)
//                 VALUES ('${req.body.userList.userid}','${reqData.skillid}',${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid}) RETURNING userskillid`;
//         }
//         else {
//             sql = `UPDATE public.wms_userskill
//                 SET skillid='${reqData.skillid}', isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
//                 WHERE userskillid ='${reqData.userskillid}' RETURNING userskillid`;
//         }
//         logger.info(sql, 'sqlsql');
//         query(sql).then((response) => {
//             res.status(200).json({ message: `User Skill has been ${reqData.userskillid ? 'updated' : 'added'} successfully`, data: response });
//         }).catch((error) => {
//             res.status(400).send({ message: error });
//         });
//     })
// }
// export const createSkill = async (req, res) => {
//     logger.info(req.body, 'skill')
//     try {
//         let awaits = [];
//         req.body.data.map(data => {
//             const reqData = data;
//             logger.info(reqData, 'reqData create user skill');
//             console.log(reqData.userskillid, 'reqData.userskillid');
//                 let sql = `
//                 DO $$ begin
//                     if((select count(1) from public.wms_userskill where  userid = '${req.body.userList.userid}' and skillid = ${reqData.skillid}) > 0 ) then
//                         UPDATE public.wms_userskill
//                         SET skillid=${reqData.skillid}, isactive=${reqData.isactive}, skillelvelid=${reqData.skillelvelid}, composingswid=${reqData.composingswid}, certlevelid=${reqData.certlevelid}
//                         WHERE userskillid =${reqData.userskillid};
//                     else
//                         INSERT INTO public.wms_userskill(userid,skillid,isactive,effectivefrom,skillelvelid,composingswid,certlevelid)
//                         VALUES ('${req.body.userList.userid}',${reqData.skillid},${reqData.isactive},'${reqData.effectivefrom}',${reqData.skillelvelid},${reqData.composingswid},${reqData.certlevelid}) ;
//                     end if;
//                 end $$;
//                 `;
//                 console.log(sql,'ifblock');
//                 awaits.push(query(sql));
//         });
//         await Promise.all(awaits)
//         res.status(200).json({ message: `User Skill has been updated successfully` , data: {}});
//     } catch (error) {
//         res.status(400).send({ message: error.message });
//     }
// }

export const deleteSkill = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqDataforDelete');
  let sql = '';
  if (reqData.type == 'skill') {
    sql = `DELETE FROM  public.wms_userskill WHERE userskillid =${reqData.userSkillId}`;
  } else if (reqData.type == 'role') {
    sql = `DELETE FROM  public.wms_userrole WHERE userroleid =${reqData.userRoleId}`;
  }
  logger.info(sql, 'deleteeeeeee');
  query(sql)
    .then(() => {
      res.status(200).json({ message: 'Skill has been deleted successfully' });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getLibraryTempList = (req, res) => {
  let sql = '';
  sql = `select count(distinct (templatename)) 
        FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
        join public.org_mst_deliveryunit as du on du.duid =t.duid
        join public.org_mst_customer as cus on cus.customerid =t.customerid  
        join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
        where isdelete=false`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = ` select * from 
    (SELECT distinct on (t.templatename) du.duname,cus.customername, tt.libraryname, sw.softwarename, sw.softwareid,t.templatename,t.templateid,
     t.composingswid,t.duid,t.customerid,t.uploadedby,t.uploadeddate,t.templateuuid,t.templatefilepath,t.isdelete,t.templatetypeid,t.filename,concat(us.username , ' (', us.userid, ')') as username,case when t.isactive = TRUE then 1 else 0 end as isactive
    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
          join public.org_mst_deliveryunit as du on du.duid =t.duid
          join public.org_mst_customer as cus on cus.customerid =t.customerid   
         join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid  
          join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
           where isdelete=false) as tempp order by tempp.uploadeddate desc`;
        query(sqlQuery)
          .then(data => {
            logger.info('user list', data);
            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getSeparateTempList = (req, res) => {
  const reqData = req.body;
  let sql = '';
  sql = `SELECT COUNT(*) FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
        join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
       where t.templatename='${reqData.templatename}' and isdelete=false`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT 
            *,concat(us.username , ' (', us.userid, ')') as username,case when t.isactive = TRUE then 1 else 0 end as isactive
             FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
                join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
               where t.templatename='${reqData.templatename}' and isdelete=false order by t.isactive desc ,t.uploadeddate desc`;

        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);

            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// templete repository
export const getTemplateList = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  // let condition = '';
  // if (reqData.type === 'filter') {
  //   offset = 0;
  //   reqData.filter.forEach((item, i) => {
  //     condition +=
  //       reqData.filter.length - 1 !== i
  //         ? ` LOWER(${
  //             item.name
  //           }::text) LIKE '%${item.value.toLowerCase()}%' AND `
  //         : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
  //   });
  //   logger.info(condition, 'conditionconditioncondition111');
  //   sql = `SELECT COUNT(*) FROM wms_mst_composingsw_templates ${
  //     condition ? `WHERE${condition}` : condition
  //   }`;
  // } else {
  sql = `SELECT COUNT(*) FROM wms_mst_composingsw_templates`;
  logger.info(sql, 'sqlsql');
  let newcondition = '';
  // const tempcondition = '';
  if (reqData.newdata == 'true') {
    newcondition = ' where res.rno = 1  ';
  } else {
    newcondition = ` where res.templatename = '${reqData.templatename}' `;
  }
  //   else {
  //    condition = 'sdfdfdf and'
  //     condition = `and t.templatename = ${reqData.templatename}`
  // }

  let newCount = '';
  newCount = `select count(0) as totalcount from (
        select row_number() Over(partition by t.templatename order by t.templateid desc) as rno,
        *
        from wms_mst_composingsw_templates t
        join public.wms_user as us on us.userid=t.uploadedby
        join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid
        join public.org_mst_deliveryunit as du on du.duid =t.duid
        join public.org_mst_customer as cus on cus.customerid =t.customerid
        join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid
        where isdelete=false
        ) res where res.rno = 1`;

  query(newCount)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].totalcount > 0) {
        // const numOfPages = Math.ceil(
        //   getCount[0].totalcount / reqData.recordPerPage,
        // );
        // const sql1 = `SELECT

        //     *,concat(us.username , ' (', us.userid, ')') as username,case when t.isactive = TRUE then 1 else 0 end as isactive
        //     FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
        //     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid
        //     where isdelete=false ${
        //       condition ? `and${condition}` : condition
        //     } order by t.isactive desc ,t.uploadeddate desc LIMIT ${recordPerPage} OFFSET ${offset}`;

        const sqlQuery = `select * from( 
                SELECT
                row_number() Over(partition by t.templatename order by t.templateid desc) as rno,
                *,
                concat(us.username , ' (', us.userid, ')') as username,
                case when t.isactive = TRUE then 1 else 0 end as isactive
                FROM public.wms_mst_composingsw_templates as t 
                join public.wms_user as us on us.userid=t.uploadedby 
                join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid 
                join public.org_mst_deliveryunit as du on du.duid =t.duid
                join public.org_mst_customer as cus on cus.customerid =t.customerid
                join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid 
                where isdelete=false  order by t.isactive desc ,t.uploadeddate desc 
                ) res ${newcondition} order by res.templateid desc`;

        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);

            res.status(200).json({
              data,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to be deleted
export const getDULists = (req, res) => {
  const result = {
    DUlist: [],
    SWlist: [],
    LBlist: [],
    CustomerList: [],
    templateDetails: [],
  };
  const { pageNo } = req.body;
  const { recordPerPage } = req.body;
  let offset = (pageNo - 1) * recordPerPage;
  let countRow = '';
  let condition = '';
  if (req.body.type === 'filter') {
    offset = 0;
    req.body.filter.forEach((item, i) => {
      condition +=
        req.body.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
    countRow = `SELECT count(*)
        FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
         join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid where isdelete=false  ${
           condition ? `and${condition}` : condition
         }`;
  } else {
    countRow = `SELECT count(*)
    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid where isdelete=false `;
  }
  query(`SELECT duid as value, duname as label FROM org_mst_deliveryunit`)
    .then(data => {
      result.DUlist = data;
      query(
        `SELECT softwareid as value, softwarename as label FROM pp_mst_composingsoftware where isactive=true`,
      )
        .then(val => {
          result.SWlist = val;
          query(
            `SELECT templatetypeid as value, libraryname as label FROM public.wms_mst_template_type where isactive=true`,
          )
            .then(out => {
              result.LBlist = out;
              query(
                `SELECT customerid as value, customername as label FROM public.org_mst_customer`,
              )
                .then(rest => {
                  rest.CustomerList = rest;
                  query(countRow)
                    .then(count => {
                      query(`SELECT t.templateid,t.templatename,sw.softwarename,tt.libraryname,concat(us.username , ' (', us.userid, ')') as username,t.uploadeddate,t.templateuuid,t.templatefilepath,case when t.isactive = TRUE then 1 else 0 end as isactive
                    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby
                     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid where isdelete=false ${
                       condition ? `and${condition}` : condition
                     } order by t.isactive desc ,t.uploadeddate desc LIMIT ${recordPerPage} OFFSET ${offset}`)
                        .then(value => {
                          rest.templateDetails = value;
                          rest
                            .status(200)
                            .json({ data: rest, total: count[0].count });
                        })
                        .catch(error => {
                          rest.status(400).send({ message: error });
                        });
                    })
                    .catch(error => {
                      rest.status(400).send({ message: error });
                    });
                })
                .catch(error => {
                  res.status(400).send({ message: error });
                });
            })
            .catch(error => {
              res.status(400).send({ message: error });
            });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// for Template details
export const addTemplateDetails = (req, res) => {
  const templateDetails = req.body;

  const sqlFortemplate = `INSERT INTO public.wms_mst_composingsw_templates(templatename, composingswid, duid, customerid, uploadedby, uploadeddate,isactive, templateuuid,templatefilepath,isdelete,templatetypeid,filename)
            VALUES('${templateDetails.templatename}', ${templateDetails.composingswid}, ${templateDetails.duid}, ${templateDetails.customerid},'${templateDetails.rolename}',CURRENT_DATE,true,'${templateDetails.templateuuid}','${templateDetails.templatefilepath}',false, ${templateDetails.templatetypeid},'${templateDetails.templatename}') returning templateid;`;
  console.log(sqlFortemplate, 'queries');
  query(sqlFortemplate)
    .then(resForCreate => {
      query(`INSERT INTO public.wms_mst_composingsw_templates_auditlog(templateid,changelog)
        VALUES(${resForCreate[0].templateid}, '${JSON.stringify(
        templateDetails.log,
      )}')`)
        .then(() => {
          res.status(200).json({ data: resForCreate });
        })
        .catch(error => {
          logger.info(error);
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ message: error });
    });
};
// to update the template
export const updateTemplateStatus = (req, res) => {
  const updatetemplateDetails = req.body;
  query(
    `update public.wms_mst_composingsw_templates set isactive=${
      updatetemplateDetails.isactive != 0
    } where templateid=${updatetemplateDetails.id}`,
  )
    .then(() => {
      res.status(200).json({ data: updatetemplateDetails });
      query(`INSERT INTO public.wms_mst_composingsw_templates_auditlog(templateid,changelog)
        VALUES(${updatetemplateDetails.id}, '${JSON.stringify(
        updatetemplateDetails.log,
      )}')`)
        .then(resp => {
          resp.status(200).json({ data: resp });
        })
        .catch(error => {
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ message: error });
    });
};
// to delete the template
// export const deleteTemplate1 = (req, res) => {
//     let { templateuuid, templateid, templatename } = req.body;
//     const headers = {};
//     const url = config.openKM.uri.delete;
//     service.delete(`${config.openKM.base_url}${url}/${templateuuid}`, {}, headers).then(async (response) => {
//         // query(`INSERT INTO public.wms_mst_composingsw_templates_auditlog(templateid,changelog)
//         // VALUES(${deletetemplateDetails.id}, '${JSON.stringify(deletetemplateDetails.log)}')`).then((data) => {
//         query(`update public.wms_mst_composingsw_templates set isdelete=true where templateid=${templateid}`).then((data) => {
//             res.status(200).json({ data: data });
//         }).catch((error) => {
//             logger.info(error)
//             res.status(400).send({ message: error });
//         });
//         // }).catch((error) => {
//         //     logger.info(error)
//         //     res.status(400).send({ message: error });
//         // })
//     }).catch((error) => {
//         logger.info(error)
//         res.status(400).send({ message: error });
//     })

// }

// to delete the template
const _delete = pth => {
  return new Promise(async (resolve, reject) => {
    try {
      const url = config.blob_rest.uri.delete;
      const result = await service.get(
        `${config.blob_rest.base_url}${url}?docId=${pth}`,
      );
      resolve({ data: 'file deleted successfully', status: result.status });
    } catch (err) {
      reject(err);
    }
  });
};
export const deleteTemplate = (req, res) => {
  const { templatename } = req.body;

  const sqlFortemplate = `select templateid,templateuuid,templatename,templatefilepath from wms_mst_composingsw_templates WHERE templatename='${templatename}'`;
  console.log(sqlFortemplate, 'sqlFortemplate');

  query(sqlFortemplate)
    .then(resForCreate => {
      if (resForCreate) {
        const resobj = resForCreate;
        resobj.forEach(element => {
          const fullPath = element.templatefilepath + element.templatename;
          _delete(fullPath)
            .then(async () => {
              query(
                `update public.wms_mst_composingsw_templates set isdelete=true where templateid=${element.templateid}`,
              )
                .then(data => {
                  res.status(200).json({ data });
                })
                .catch(error => {
                  logger.info(error);
                  res.status(400).send({ message: error });
                });
            })
            .catch(error => {
              logger.info(error);
              res.status(400).send({ message: error });
            });
        });
      }
    })
    .catch(error => {
      logger.info(error);
      res.status(400).send({ message: error });
    });
};

export const getWorkorderWithNameLike = async (req, res) => {
  try {
    const out =
      await query(`select distinct a.workorderid, a.itemcode from wms_workorder a join 
    wms_workorder_service b on a.workorderid=b.workorderid where b.baseduid=${req.body.duid}
    and itemcode ILIKE '%${req.body.name}%'
    order by a.workorderid`);
    res.status(200).json(out);
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error });
  }
};

export const getAccessRightsBlobFiles = async (req, res) => {
  try {
    const sql = `select isupload,duid ,* from wms_blobfiles_accessrights where userid='${req.body.userid}' and duid=${req.body.duid}`;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (error) {
    logger.info('error', error);
    res.status(400).send({ message: error });
  }
};

export const getJournalOptionList = async (req, res) => {
  try {
    const sql = `SELECT
    journalid as value, journalacronym as label 
   FROM org_mst_customerorg_du_map as custmermap
   JOIN pp_mst_journal as journal ON journal.custorgmapid = custmermap.custorgmapid
   where custmermap.duid =${req.body.duid}`;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (error) {
    logger.info('error', error);
    res.status(400).send({ message: error });
  }
};

export const getJournalBaseWOList = async (req, res) => {
  try {
    const sql = `select workorderid as value, itemcode as label  from  wms_workorder as workorder join 
    pp_mst_journal as journal on workorder.journalid = journal.journalid
     where workorder.journalid = ${req.body.journalid}`;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (error) {
    logger.info('error', error);
    res.status(400).send({ message: error });
  }
};

export const getWoChapters = async (req, res) => {
  try {
    const sql = `select woincomingfileid as value, filename as label
    from public.wms_workorder_incomingfiledetails a
    join wms_workorder_incoming b on b.woincomingid = a.woincomingid
    where b.woid =   ${req.body.workorderid} and a.filetypeid !=1
    order by a.woincomingfileid desc
   `;
    const result = await query(sql);
    res.status(200).send({ data: result });
  } catch (error) {
    logger.info('error', error);
    res.status(400).send({ message: error });
  }
};

export const deleteFilePathTrn = async (req, res) => {
  try {
    const { value } = req.body;
    for (let i = 0; i < value.length; i++) {
      const repofilepath = `/okm:root/prodrepository/${value[i].path}/${value[i].name}`;
      const sql = `DELETE FROM wms_workflowactivitytrn_file_map WHERE repofilepath ='${repofilepath}'`;
      await query(sql);
    }
    res.status(200).send({ data: 'Deleted successfully!' });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({ message: error });
  }
};

// tools Upload Actions
export const blobFilesActionsAudit = async (req, res) => {
  console.log(req.body, 'neww', res);
  try {
    const { files, actionType, props, systemInfo, userid } = req.body;
    console.log(props, 'props');
    const val = [];
    files.forEach(list => {
      val.push(
        `('${
          list.name ? list.name : list.data.name
        }', '${userid}', '${systemInfo}', '${
          list.path ? list.path : list.data.path
        }', '${actionType}', ${props.profile.duId} )`,
      );
    });

    const sql2 = `INSERT INTO wms_blobfiles_actions_audit(filename,userid,systeminfo,actionpath,actiontype
      ,duid) values ${val}`;
    logger.info(sql2, val, 'data');
    await query(sql2);
    res.status(200).json({
      status: true,
      data: 'audit table inserted successfully',
    });
  } catch (error) {
    console.log(error, 'error');
    res.status(400).send({ message: error, status: false });
  }
};

export const getBlobFileDetailsForPath = async (req, res) => {
  try {
    let pth =
      req.body && req.body.path
        ? req.body.path.toLowerCase().replace(/ /g, '_')
        : undefined;

    if (pth == undefined) {
      const type =
        req.body.woincomingfileid != 0 && req.body.woincomingfileid != undefined
          ? 'wo_activity_file_subtype'
          : 'wo_activity_iteration';
      const input = {
        type,
        du: { name: req.body.assignedduname, id: req.body.duid },
        customer: { name: req.body.customername, id: req.body.customerid },
        workOrderId: req.body.workorderid,
        service: { name: req.body.servicename, id: req.body.serviceid },
        stage: {
          name: req.body.stagename,
          id: req.body.stageid,
          iteration: req.body.stageiterationcount,
        },
        activity: {
          name: req.body.activityname,
          id: req.body.activityid,
          iteration: req.body.activityiterationcount,
        },
        fileType: {
          name: req.body.filetype,
          id: req.body.filetypeid,
          fileId: req.body.woincomingfileid,
        },
      };
      pth = await getFolderStructure(input);
    }
    let originalPath = pth;
    if (!req.body.fileExplore || req.body.fileExplore == undefined) {
      originalPath = pth.substring(0, pth.length - 1);
    } else {
      originalPath = req.body.setpath;
    }
    const out = await azureHelper.listCurrentDirectory(originalPath);
    res.status(200).json(out);
  } catch (error) {
    logger.info(error);
    res.status(400).send({ message: error });
  }
};

export const getFileDetailsforWorkorder = async (req, res) => {
  try {
    let condition;
    if (req.body.type == 'book') {
      condition = `workorderid=${req.body.workorderid} and (woincomingfileid =${req.body.woincomingfileid} or woincomingfileid is null)`;
    } else {
      condition = `workorderid=${req.body.workorderid}`;
    }

    const sql = `;with cte as (select 
      row_number() over(partition by itemcode,stagename,stageiterationcount,activityalias,filename order by stageiterationcount,activityiterationcount desc ) as rno,
      filetype,filetypeid,newfiletype,duid,assignedduname,customerid,customername,
      COALESCE(woincomingfileid,0) as woincomingfileid,workorderid,wfeventid, 
      filename, itemcode, servicename,stageid,stagename,
      serviceid, activityalias, activityname, activityid, stageiterationcount, 
      activityiterationcount 
      from wms_tasklist 
      where ${condition} ) select 
      filetype,filetypeid,newfiletype,duid,assignedduname,customerid,customername,
      COALESCE(woincomingfileid,0) as woincomingfileid,workorderid,wfeventid, 
      filename,COALESCE(filename,activityiterationcount::varchar) as name, itemcode, servicename,stageid,stagename,
      serviceid,servicename,activityalias, activityname, activityid, stageiterationcount, 
      activityiterationcount 
      from cte where rno=1
      order by stageid`;
    const sqlResult = await query(sql);
    const StageName = [
      ...new Set(
        sqlResult.flatMap(d => `${d.stagename}(${d.stageiterationcount})`),
      ),
    ];
    const out = { StageName: [] };
    const getstagepath = stg => {
      return `${stg.assignedduname}_${stg.duid}/${stg.customername}_${stg.customerid}/${req.body.workorderid}/${stg.servicename}_${stg.serviceid}/${stg.stagename}_${stg.stageid}/${stg.stageiterationcount}`;
    };
    const getactivitypath = aty => {
      const stagepath = getstagepath(aty);
      return `${stagepath}/${aty.activityname}_${aty.activityid}/${aty.activityiterationcount}`;
    };
    const uniqueFileDtls = Array.from([
      ...new Set(
        sqlResult
          .map(d => ({
            woincomingfileid: d.woincomingfileid,
            filename: d.filename,
            newfiletype: d.newfiletype,
            filetypeid: d.filetypeid,
            filetype: d.filetype,
            name: d.name || d.activityiterationcount,
          }))
          .map(JSON.stringify),
      ),
    ])
      .map(JSON.parse)
      .filter(x => x.woincomingfileid != 0);
    StageName.forEach(stg => {
      out.StageName.push({
        path: getstagepath(
          sqlResult.filter(
            x => `${x.stagename}(${x.stageiterationcount})` == stg,
          )[0],
        ),
        name: stg,
        isFolder: true,
        id: sqlResult.filter(
          x => `${x.stagename}(${x.stageiterationcount})` == stg,
        )[0].stageid,
        stagename: stg,
        stageid: sqlResult.filter(
          x => `${x.stagename}(${x.stageiterationcount})` == stg,
        )[0].stageid,
        children: Array.from([
          ...new Set(
            sqlResult
              .filter(x => `${x.stagename}(${x.stageiterationcount})` == stg)
              .map(d => ({
                path: getactivitypath(d),
                name: d.activityalias,
                id: d.activityid,
                activityname: d.activityname,
                activityid: d.activityid,
                isFolder: true,
                children: sqlResult
                  .filter(
                    x =>
                      x.activityid == d.activityid &&
                      `${x.stagename}(${x.stageiterationcount})` == stg,
                  )
                  .map(x => {
                    x.children = [];
                    x.isFolder = true;
                    return x;
                  }),
              }))
              .map(JSON.stringify),
          ),
        ]).map(JSON.parse),
      });
    });
    // out.StageName.forEach(async list => {
    //   // const fstat = await fsPromises.stat(list.path);
    //   if (list.name.includes('.')) {
    //     list.isFolder = false;
    //   } else {
    //     list.isFolder = true;
    //   }
    // });

    // out.StageName.forEach(async list => {
    //   if (list.children) {
    //     list.children.forEach(async list1 => {
    //       try {
    //         if (list1.name.includes('.')) {
    //           list1.isFolder = false;
    //         } else {
    //           list1.isFolder = true;
    //         }
    //       } catch (error) {
    //         console.error(`Error: ${error}`);
    //       }
    //     });
    //   }
    // });

    res.status(200).json({ StageInfo: out.StageName, uniqueFileDtls });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getMasterOptionLists = (req, res) => {
  const getData = req.body;
  let sql = ``;
  console.log(getData, 'dataformaster');
  if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value ,org_mst_customer.customername as label , org_mst_customer.customershortname as custname
        FROM public.org_mst_customer`;
  }
  // else if (getData.type === 'customershortname') {
  //     sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value , org_mst_customer.customershortname as label
  //     FROM public.org_mst_customer where customerid=${getData.customerId}`;
  // }
  else if (getData.type === 'division') {
    sql = `SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label
         FROM public.org_mst_division`;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label 
        FROM  org_mst_subdivision`;
  } else if (getData.type === 'country') {
    sql = `SELECT DISTINCT ON (geo_mst_country.countryid)geo_mst_country.countryid as value, geo_mst_country.countryname as label 
        FROM geo_mst_country`;
  } else if (getData.type === 'projectmanager') {
    sql = `select users.userid as value, concat(users.username , ' (', users.userid, ')')as label from wms_user as users
        join wms_userrole as roles on roles.userid = users.userid where roles.roleid =1 and users.duid = ${getData.duId} and useractive = true and isactive = true`;
  } else if (getData.type === 'supplierprojectmanager') {
    sql = `select users.userid as value, concat(users.username , ' (', users.userid, ')')as label from wms_user as users
        join wms_userrole as roles on roles.userid = users.userid where roles.roleid = 9 and users.duid = ${getData.duId} and useractive = true and isactive = true`;
  } else if (getData.type === 'softwares') {
    sql = `SELECT softwareid as value, softwarename as label FROM public.pp_mst_composingsoftware WHERE isactive = true`;
    // sql =`select trndrop.id as value, trndrop.value as label from wms_mst_dropdown as drops
    // join wms_Trn_dropdown as trndrop on trndrop.dropid = drops.dropid
    //  where drops.fieldname like '%${getData.type}%' and duid=${getData.duId}`
  } else if (getData.type === 'colours') {
    sql = `SELECT colorid as value, color as label FROM public.pp_mst_color`;
  } else if (getData.type === 'languages') {
    sql = `SELECT languageid as value, languagename as label FROM public.wms_mst_language`;
  } else if (getData.type === 'celevel') {
    sql = `SELECT celevelid as value, celevel as label FROM public.pp_mst_copyeditinglevel`;
  } else if (getData.type === 'indexType') {
    sql = `SELECT indextypeid as value, indextype as label FROM public.pp_mst_indextype`;
  } else if (getData.type === 'templatefile') {
    sql = `SELECT templateid as value,templatename as label FROM public.wms_mst_composingsw_templates where duId= ${getData.duId} and composingswid=${getData.composingSwId} and isactive = true and isdelete = false`;
  } else if (getData.type === 'iauthorworkflow') {
    sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
        where duid=${getData.duId} and isactive = true and stageid=1 ORDER BY iauthormstworkflowid ASC`;
  } else if (getData.type === 'copyeditingworkflow') {
    sql = `SELECT * , iauthworkflowid as value, iauthworkflow as label FROM public.iauthor_workflow
        where isactive = true and duid=${getData.duId}  and stageid=13 ORDER BY iauthormstworkflowid  ASC`;
  } else if (getData.type === 'textcolumn') {
    sql = `SELECT textcolumnid as value, textcolumn as label FROM public.wms_mst_textcolumn ORDER BY textcolumnid ASC  `;
  } else if (getData.type === 'printprofile') {
    sql = `SELECT printprofileid as value, printprofile as label FROM public.wms_mst_printprofile where duid=${getData.duId} ORDER BY printprofileid ASC  `;
  } else if (getData.type === 'onlineprofile') {
    sql = `SELECT onlineprofileid as value, onlineprofile as label FROM public.wms_mst_onlineprofile where duid=${getData.duId} ORDER BY onlineprofileid ASC  `;
  } else if (getData.type === 'referenceprofile') {
    sql = `SELECT referenceprofileid as value, referenceprofile as label FROM public.wms_mst_referenceprofile where duid=${getData.duId} and isactive = true ORDER BY referenceprofileid ASC  `;
  } else if (getData.type === 'pdfprofile') {
    sql = `SELECT pdfa2bprofileid as value, pdfa2bprofile as label FROM public.wms_mst_pdfa2bprofile where duid=${getData.duId} and isactive = true ORDER BY pdfa2bprofileid ASC  `;
  } else if (getData.type === 'category') {
    sql = `SELECT onlineprofileid as value, onlineprofile as label FROM public.wms_mst_onlineprofile ORDER BY onlineprofileid ASC `;
  } else if (getData.type === 'coverprofile') {
    sql = `SELECT coverprofileid as value, coverprofile as label FROM public.wms_mst_coverprofile where duid=${getData.duId} and isactive = true ORDER BY coverprofileid ASC  `;
  }
  console.log(sql, 'sqlforjornlalal');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// export const createJournalMaster = (req) => {
//     const {customerId,divisionId,subDivisionId, countryId, journalStatus,ceLevel,JournalAcronym,colour,custShortName,software,
//         journalName,language, onlineIssn,printIssn,projectManager,supplierProjectManager,tat,templateFile,pageHeight,pageWidth} = req.body;
//     return new Promise(async (resolve, reject) => {
//         try {
//             await transaction(async (client) => {
//                 let sql = `INSERT INTO public.org_mst_customer_orgmap(customerid, divisionid, subdivisionid, countryid, isactive) VALUES (${customerId}, ${divisionId}, ${subDivisionId}, ${countryId}, ${journalStatus}) RETURNING custorgmapid`;
//                 console.log(sql,"sqllll11")
//                 const eventResult = await client.query(sql)
//                 console.log(sql,"sqllll")
//                 console.log(eventResult,"eventResult")
//                 sql = `INSERT INTO public.pp_mst_journal(
//                     custorgmapid, journalname, journalacronym, colorid, turnaroundtime, softwareid, languageid, celevelid, templateid, printissn, trimesizewidth, trimesizewidthuom, trimesizeheight, trimesizeheightuom, pmid, supplierpmid, onlineissn)
//                    VALUES (${eventResult.rows[0].custorgmapid}, '${journalName}', '${JournalAcronym}', ${colour}, ${tat}, ${software}, ${language}, ${ceLevel}, ${templateFile}, '${printIssn}', ${pageWidth}, '0', ${pageHeight}, '0', '${projectManager}', '${supplierProjectManager}',' ${onlineIssn}') RETURNING journalid`;
//                   console.log(sql,"sqlforsecnd")
//                    await client.query(sql);
//                 resolve('Journal Created Successfully');
//             });
//         } catch (e) {
//             if (e?.message?.data?.message) { //This is used to checkThis is wrong. need to get proper error msg from camunda layer
//                 reject(e.message.data.message);
//             } else {
//                 reject(e.message ? e.message : e);
//             }
//         }
//     });
// }

export const createJournalMaster = async (req, res) => {
  const {
    customerId,
    divisionId,
    subDivisionId,
    countryId,
    journalStatus,
    ceLevel,
    JournalAcronym,
    colour,
    software,
    journalName,
    language,
    onlineIssn,
    printIssn,
    projectManager,
    supplierProjectManager,
    articleTat,
    issueTat,
    issueCount,
    budgetedCount,
    proofingType,
    accessArticle,
    templateFile,
    pageHeight,
    pageWidth,
    productionList,
    duId,
    pageHeightUnit,
    pageWidthUnit,
    nonArticle,
    isIAuthorRequired,
    iAuthorWorkflow,
    ce,
    amo,
    textColumn,
    onlineProfile,
    printProfile,
    tatList,
    templateFormat,
    isNLPRequired,
    isFirstproofRequired,
    copyEditingWorkflow,
    category,
    journalType,
    referenceProfile,
    pdfProfile,
    runon,
    runontype,
    cover,
    advert,
    blankpagelogic,
    coverProfile,
  } = req.body;
  const runontypeJSON = JSON.stringify(runontype);
  console.log('runontypeJSON', runontypeJSON);
  console.log(req.body, 'boddyyyyyyyyyy');
  const isAccessArticle = accessArticle == true ? 1 : 0;
  let custId;
  let status = true;
  const defaultSql = `select custorgmapid from public.org_mst_customer_orgmap where customerid = ${customerId}  and  divisionid = ${divisionId} and  subdivisionid = ${subDivisionId}  and countryid = ${countryId}`;
  await query(defaultSql)
    .then(async response => {
      console.log(response, 'responnnsnsns');
      custId = response;
      if (response.length) {
        custId = response[0].custorgmapid;
      } else {
        const sql = `INSERT INTO public.org_mst_customer_orgmap(customerid, divisionid, subdivisionid, countryid) VALUES (${customerId}, ${divisionId}, ${subDivisionId}, ${countryId}) RETURNING custorgmapid`;
        console.log(sql, 'customermap');
        await query(sql).then(async resp => {
          custId = resp[0].custorgmapid;
          const createDu = `INSERT INTO public.org_mst_customerorg_du_map(custorgmapid, duid)
               VALUES ( ${custId}, ${duId}) RETURNING custorgmapid`;
          console.log(createDu, 'createduuu');
          await query(createDu)
            .then(async responsedu => {
              console.log(responsedu, 'duduud');
            })
            .catch(() => {
              status = false;
            })
            .catch(() => {
              status = false;
            });
        });
      }
    })
    .catch(() => {
      status = false;
    });
  if (status == true) {
    const createJournal = `INSERT INTO public.pp_mst_journal(
            custorgmapid, journalname, journalacronym, colorid, softwareid, languageid, celevelid, templateid, printissn, trimesizewidth, trimesizewidthuom, trimesizeheight, trimesizeheightuom, pmid, supplierpmid, onlineissn,articletat, issuetat, totalissuecount, budgetedcount, isopenaccessarticle,isactive,proofingtype,isiauthor,iauthworkflowid,textcolumnid,ceid,amoid,printprofileid,onlineprofileid,templateformat,isnlp,isfirstproof,category,copyeditingworkflow,journaltype,referenceprofileid,pdfa2bprofileid,runon,runontype,cover,advert,blankpagelogic,coverprofileid)
           VALUES (${custId}, '${journalName}', '${JournalAcronym}', ${
      colour || null
    }, ${software || null}, ${language || null}, ${ceLevel || null}, ${
      templateFile || null
    }, '${printIssn || ''}', ${pageWidth || null}, '${
      pageWidthUnit || null
    }', ${pageHeight || null}, '${pageHeightUnit || null}', '${
      projectManager || null
    }', '${supplierProjectManager || null}','${onlineIssn || null}', ${
      articleTat || null
    }, ${issueTat || null}, ${issueCount || null}, ${budgetedCount || null}, ${
      isAccessArticle.toString().length > 0 ? isAccessArticle : null
    },${journalStatus.toString().length > 0 ? journalStatus : null}, '${
      proofingType || null
    }',${isIAuthorRequired.toString().length > 0 ? isIAuthorRequired : null},${
      iAuthorWorkflow && isIAuthorRequired == true ? iAuthorWorkflow : null
    },
           ${textColumn || null},${ce || null},${amo || null},${
      printProfile || null
    },${onlineProfile || null},
           '${templateFormat || null}',${isNLPRequired || null},${
      isFirstproofRequired || null
    },${category || null},${copyEditingWorkflow || null},'${
      journalType || null
    }',${referenceProfile || null},${pdfProfile || null},
    ${runon !== null ? runon : false},'${
      runontype && runon == true ? runontypeJSON : null
    }',${cover !== null ? cover : false},${advert !== null ? advert : false},${
      blankpagelogic || null
    },${coverProfile || null}) RETURNING journalid`;
    console.log(createJournal, 'createJournal');
    await query(createJournal)
      .then(async data => {
        console.log(data, 'resultforcreatejournal');
        nonArticle.map(async nonarticleid => {
          const createNonArticle = `INSERT INTO public.pp_mst_journal_nonart_types(
                    journalid, filetypeid)
                   VALUES ( ${data[0].journalid}, ${nonarticleid})`;
          await query(createNonArticle).then(async datanonartical => {
            console.log(datanonartical, 'datanonartical');
          });
        });
        let isPrimary;
        const val = [];
        productionList.forEach(list => {
          isPrimary = list.editiorPrimary ? 1 : 0;
          val.push(
            `(${data[0].journalid}, '${list.editiorName}', '${list.editiorEmail}', null, '${list.editiorPhone}', null, '${list.prodStatus}', ${isPrimary})`,
          );
        });

        // add tat info save
        if (tatList) {
          tatList.forEach(list => {
            list.customerid = customerId;
            list.journalid = data[0].journalid;
            list.isactive = list.isactive != false;
          });

          const jsonparam = JSON.stringify(tatList);
          console.log(jsonparam, tatList, 'tatlisttttttt');
          const createTatInfo = `select * from insertjournalduedays('${jsonparam}')`;
          await query(createTatInfo);
        }

        const createJournalConatacts = `INSERT INTO public.pp_mst_journal_contacts(
                        journalid, name, email, address, phone1, phone2, designation, isprimary)
                       VALUES ${val} RETURNING journalconid`;
        console.log(createJournalConatacts, 'createJournalConatacts');
        await query(createJournalConatacts).then(async datacontacts => {
          console.log(datacontacts, 'datacontacts');
          res.status(200).json({
            journalid: data[0].journalid,
          });
        });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      })
      .catch(error => {
        res.status(400).send({ message: error });
      });
  } else {
    res.status(400).send({ message: 'Failed to get the custorgmapid' });
  }
};

export const journalFile = async (req, res) => {
  const { journalid, path, repofileuuid } = req.body;
  const sql = `INSERT INTO public.pp_mst_journal_instructions(journalid, repofilepath, repofileuuid)
       VALUES ( ${journalid}, '${path}', '${repofileuuid}')`;
  console.log(sql, 'insertingfile');
  await query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// to get the details for master activity
export const getJournalList = (req, res) => {
  const reqData = req.body;
  let sql = '';
  sql = `SELECT COUNT(*) FROM wms_detail_journal WHERE duid = ${reqData.duId} `;

  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM wms_detail_journal WHERE duid = ${reqData.duId}  ORDER BY status DESC`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateJournalMaster = async (req, res) => {
  const { custList, prodList, tatList } = req.body;
  console.log(req.body, 'bodyforupdate');
  // let updateCustomer = `UPDATE public.org_mst_customer_orgmap
  // SET  isactive=${custList.status}
  // WHERE custorgmapid=${custList.custorgmapid}`;
  // console.log(updateCustomer, "updateCustomer")
  // await query(updateCustomer).then(async (response) => {
  const runontypeJSON = JSON.stringify(req.body.custList.runontype);
  console.log('runontypeJSON', runontypeJSON);
  const updateJournal = `UPDATE public.pp_mst_journal
	SET  colorid=${custList.colours ? custList.colours : null}, softwareid=${
    custList.softwares ? custList.softwares : null
  }, languageid=${custList.languages ? custList.languages : null}, celevelid=${
    custList.celevel ? custList.celevel : null
  }, templateid=${
    custList.templatefile ? custList.templatefile : null
  }, printissn='${
    custList.printissn ? custList.printissn : ''
  }', trimesizewidth=${
    custList.pagewidth ? custList.pagewidth : null
  }, trimesizewidthuom='${
    custList.pagewidthunit ? custList.pagewidthunit : null
  }', trimesizeheight=${
    custList.pageheight ? custList.pageheight : null
  }, trimesizeheightuom='${
    custList.pageheightunit ? custList.pageheightunit : null
  }',
     pmid='${
       custList.projectmanager ? custList.projectmanager : null
     }', supplierpmid='${
    custList.supplierprojectmanager ? custList.supplierprojectmanager : null
  }', 
     onlineissn='${
       custList.onlineissn ? custList.onlineissn : null
     }',articletat=${
    custList.articletat ? custList.articletat : null
  }, issuetat=${custList.issuetat ? custList.issuetat : null}, 
     totalissuecount=${
       custList.totalissue ? custList.totalissue : null
     }, budgetedcount=${
    custList.budgeted ? custList.budgeted : null
  }, isopenaccessarticle=${
    custList.openarticle && custList.openarticle.toString().length > 0
      ? custList.openarticle
      : null
  }, isactive =${
    custList.status.toString().length > 0 ? custList.status : null
  }, proofingtype ='${custList.proofingtype ? custList.proofingtype : null}',
      isiauthor = ${
        custList.isiauthor && custList.isiauthor.toString().length > 0
          ? custList.isiauthor
          : null
      },iauthworkflowid =${
    custList.iauthorworkflow && custList.isiauthor == true
      ? custList.iauthorworkflow
      : null
  },
runon = ${custList.runon && custList.runon ? custList.runon : false},
runontype = '${
    custList.runontype && custList.runontype ? runontypeJSON : null
  }',
  cover = ${custList.cover && custList.cover ? custList.cover : false},
  advert = ${custList.advert && custList.advert ? custList.advert : false},
  blankpagelogic = ${
    custList.blankpagelogic && custList.blankpagelogic
      ? custList.blankpagelogic
      : null
  },
textcolumnid = ${custList.textcolumn ? custList.textcolumn : null},ceid =${
    custList.ce ? custList.ce : null
  },amoid =${custList.amo ? custList.amo : null},printprofileid =${
    custList.printprofile ? custList.printprofile : null
  },
      onlineprofileid =${
        custList.onlineprofile ? custList.onlineprofile : null
      } ,templateformat='${
    custList.templateformat ? custList.templateformat : null
  }',isnlp = ${
    custList.isnlp && custList.isnlp.toString().length > 0
      ? custList.isnlp
      : null
  },
      isfirstproof = ${
        custList.isfirstproof && custList.isfirstproof.toString().length > 0
          ? custList.isfirstproof
          : null
      },category=${
    custList.category ? custList.category : null
  },copyeditingworkflow= ${
    custList.copyeditingworkflow ? custList.copyeditingworkflow : null
  }, journaltype = '${custList.journaltype ? custList.journaltype : null}',
  referenceprofileid =${
    custList.referenceprofile ? custList.referenceprofile : null
  },
  pdfa2bprofileid =${custList.pdfprofile ? custList.pdfprofile : null},
  coverprofileid =${custList.coverprofile ? custList.coverprofile : null}
	WHERE journalid=${custList.journalid}`;
  console.log(updateJournal, 'sqlforfirst');
  await query(updateJournal)
    .then(async response => {
      console.log(response, 'respsosofn');
      const deleteNonArticle = `DELETE FROM public.pp_mst_journal_nonart_types
       where journalid=${custList.journalid}`;
      console.log(deleteNonArticle, 'deleteNonArticle');
      await query(deleteNonArticle)
        .then(async deletenonartical => {
          console.log(deletenonartical, 'deletenonarticaldeletenonartical');
          custList.nonArticle.map(async nonarticleid => {
            const createNonArticle = `INSERT INTO public.pp_mst_journal_nonart_types(
                journalid, filetypeid)
               VALUES ( ${custList.journalid}, ${nonarticleid})`;
            console.log(createNonArticle, 'createNonArticle');
            await query(createNonArticle).then(async () => {});
          });
          const deleteProd = `DELETE FROM public.pp_mst_journal_contacts WHERE journalid=${custList.journalid};`;
          await query(deleteProd).then(async () => {
            let isPrimary;
            const val = [];
            const tempProdList = [];
            prodList.forEach(list => {
              if (list != null) {
                tempProdList.push(list);
              }
            });
            console.log(tempProdList, 'tempProdList');
            tempProdList.forEach(list => {
              console.log(list, 'listforprod', list.editiorPrimary);
              isPrimary = list.editiorPrimary == true ? 1 : 0;
              val.push(
                `(${custList.journalid}, '${list.editiorName}', '${list.editiorEmail}', null, '${list.editiorPhone}', null, '${list.prodStatus}', ${isPrimary})`,
              );
            });
            const updateProd = `INSERT INTO public.pp_mst_journal_contacts(
                                journalid, name, email, address, phone1, phone2, designation, isprimary)
                               VALUES ${val} RETURNING journalconid`;
            console.log(updateProd, 'updateProdupdateProd');
            await query(updateProd).then(async responsedu => {
              console.log(responsedu, 'resoponsefordu');
            });
            // added tat delete info also
            if (tatList) {
              tatList.forEach(list => {
                list.customerid = custList.customer;
                list.journalid = custList.journalid;
                list.isactive = list.isactive != false;
              });
              const jsonparam = JSON.stringify(tatList);
              const createTatInfo = `select * from insertjournalduedays('${jsonparam}')`;
              await query(createTatInfo);
            }
          });
          res.status(200).json({
            data: 'Updated Successfully',
          });
        })
        .catch(error => {
          console.log(error, 'er1');
          res.status(400).send({ message: error });
        });
    })
    .catch(error => {
      console.log(error, 'er2');
      res.status(400).send({ message: error });
    })

    .catch(error => {
      console.log(error, 'er3');
      res.status(400).send({ message: error });
    })
    .catch(error => {
      console.log(error, 'er4');
      res.status(400).send({ message: error });
    });
};

export const nonArticleList = (req, res) => {
  const { journalId } = req.body;
  const sql = `select nonart.filetypeid as value ,filetype.filetype as label from pp_mst_journal_nonart_types as nonart 
    join pp_mst_journal as journal on journal.journalid = nonart.journalid 
    join pp_mst_filetype as filetype on filetype.filetypeid = nonart.filetypeid
    where nonart.journalid = ${journalId}`;
  console.log(sql, 'nonarctiiilll');
  query(sql)
    .then(response => {
      console.log(response, 'ikkdsfkss');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getjournalduedays = (req, res) => {
  const { journalId, customerId } = req.body;
  const sql = `select * from getjournalduedays(${customerId},${journalId})`;
  console.log(sql, req.body, 'due');
  query(sql)
    .then(response => {
      console.log(response, 'ikkdsfkss');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJournalInstruction = (req, res) => {
  const { journalId, type, journalinstructionid } = req.body;
  let sql = '';
  if (type == 'list') {
    sql = ` SELECT 
    journalinstruction.journalinstructionid,journalinstruction.repofilepath,journalinstruction.repofileuuid
   FROM  pp_mst_journal journal 
   JOIN pp_mst_journal_instructions journalinstruction ON journalinstruction.journalid = journal.journalid
    where journal.journalid = ${journalId}`;
    console.log(sql, 'insertingfile');
  } else if (type == 'delete') {
    sql = `DELETE FROM public.pp_mst_journal_instructions WHERE journalinstructionid =${journalinstructionid}`;
  }
  console.log(sql, 'deletingfileeee');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getJournalContact = (req, res) => {
  const { journalId } = req.body;
  const sql = ` SELECT  journalcontact.journalconid,journalcontact.name,journalcontact.email,journalcontact.phone1, journalcontact.designation,journalcontact.isprimary
   FROM  pp_mst_journal as journal 
   JOIN pp_mst_journal_contacts as journalcontact ON journalcontact.journalid = journal.journalid
    where journal.journalid = ${journalId} order by journalcontact.journalconid asc`;
  console.log(sql, 'gettingcontact');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
export const getJournalAcroymn = (req, res) => {
  const { customerId, divsionId, subDivisionId, countryId, journalAcroymn } =
    req.body;
  const sql = `SELECT journal.journalacronym FROM public.org_mst_customer_orgmap  as custorg
    left join pp_mst_journal as journal on journal.custorgmapid = custorg.custorgmapid
    where custorg.customerid =${customerId || ''}  and custorg.divisionid =${
    divsionId || null
  } and custorg.subdivisionid =${
    subDivisionId || null
  } and custorg.countryid = ${
    countryId || null
  } and journal.journalacronym = '${journalAcroymn}'
    ORDER BY journal.journalid ASC `;
  console.log(sql, 'journalacronym');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeee');
      res.status(200).json({
        data: response.length,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Master tool and software start
// Get Master Option List or tool

export const getToolsCommonOptions = (req, res) => {
  const sql = `SELECT org_mst_deliveryunit.duid as value, org_mst_deliveryunit.duname as label FROM org_mst_deliveryunit order by value`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getDeliverUnitList = (req, res) => {
  const sql = `select duid as value, duname as label from  public.org_mst_deliveryunit where isactive=true order by value`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getcustomerconfigdetails = (req, res) => {
  const { customerId } = req.body;
  const sql = `SELECT a.duid, a.duname, b.id,b.cloudserverpath,b.localserverpath,b.isspcopylocal,b.cloudfilereceivedpath,b.localfilereceivedpath,b.isrpcopylocal,b.servertoolpath,b.localtoolspath,b.cloudgraphicfilepath,b.localgraphicfilepath,b.isgpcopylocal,b.localworkingfolder,b.islock,b.createdon,b.duid as existingduid FROM org_mst_deliveryunit a left join wms_mst_customerconfigdetails b on a.duid=b.duid where a.duid=${customerId}`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getToolMasterOptions = (req, res) => {
  const getData = req.body;
  let sql = '';
  if (getData.type === 'toolmode') {
    sql = `	select toolmodeid as value,toolmode as label from pp_mst_toolmode`;
  } else if (getData.type === 'tooltype') {
    sql = `	select tooltypeid as value,tooltype as label from pp_mst_tooltype`;
  } else if (getData.type === 'toolsoutput') {
    sql = `SELECT tooloutputid as value,name as label  FROM public.pp_mst_tool_output ORDER BY tooloutputid ASC `;
  }
  console.log(sql, 'sqlforToolOption');
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const createnewTool = (req, res) => {
  const getData = req.body;

  console.log(getData, 'getData');
  console.log(getData.exevalue, 'exevalue');
  const checkSql = `select count(1) from pp_mst_tool where customerid=${getData.customername} and toolname='${getData.name}'`;
  query(checkSql)
    .then(checkData => {
      console.log('chckdata', checkData);
      if (!+checkData[0].count > 0) {
        const sql = `INSERT INTO public.pp_mst_tool(
            toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid)
           VALUES ('${getData.name}','${getData.description}', ${
          getData.tooltype
        }, ${getData.toolmode}, ${getData.status}, true,'${JSON.stringify(
          getData.payload,
        )}',${getData.toolsexecutiontype != '0'},${getData.toolsoutput},${
          getData.customername
        }) returning toolid;`;
        console.log(sql, 'sqlforTool');
        query(sql)
          .then(data => {
            // insertin customer
            res.status(200).json({
              data,
              message: 'tool inserted successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(400).send({
          data: 'Tool is already registered for selected customer',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const multipleInstance = payload => {
  return new Promise((resolve, reject) => {
    try {
      const { duId, woId, customerId, serviceId, currentStage, files } =
        payload;
      console.log(payload, 'payload');

      const val = [];
      const selectedFiles =
        customerId == 1 ? files.filter(list => list.isChecked) : files;
      selectedFiles.forEach(list => {
        val.push(`(${duId},'${woId}','${customerId}','${serviceId}',
                '${currentStage.id}', '${currentStage.iteration}',${list.id})`);
      });
      if (val != '' && val != undefined) {
        console.log(val, 'values for users');
        const sql = `INSERT INTO public.wms_workflow_stagetrn_file(duid, workorderid,customerid, serviceid, stageid, stageiterationcount, woincomingfileid)
             VALUES ${val} RETURNING stagetrnfileid`;
        logger.info(sql, 'sql for stage trans files');
        query(sql)
          .then(data => {
            logger.info(data, 'res for stage trans files');
            if (data.length) {
              resolve(true);
            }
          })
          .catch(error => {
            reject(error);
          });
      } else {
        resolve(true);
      }
    } catch (e) {
      console.log(e, 'mutlitple instance errro');
      reject(e);
    }
  });
};

export const deletemultipleInstanceTwo = (req, res) => {
  const getData = req.body;
  console.log(getData, 'getData');
  const checkSql = `DELETE FROM public.wms_workflow_stagetrn_file WHERE workorderid =${getData.workorderid} and customerid =${getData.customerid} and  serviceid =${getData.serviceid} and stageid =${getData.stageid} and stageiterationcount =${getData.stageiterationcount}`;
  console.log(checkSql, 'something');
  query(checkSql)
    .then(data => {
      console.log(data, 'FFFFFFFFFF');
      res.status(200).json({ data, message: 'Deleted', status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const createToolMaster = async (req, res) => {
  const {
    customername,
    name,
    description,
    tooltype,
    toolmode,
    status,
    payload,
    toolsexecutiontype,
    toolsoutput,
  } = req.body;

  const checkSql = `select count(1) from pp_mst_tool where customerid=${customername} and toolname='${name}'`;

  query(checkSql)
    .then(checkData => {
      const dataCount = +checkData[0].count;

      if (!dataCount > 0) {
        const sql = `INSERT INTO public.pp_mst_tool(
          toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid)
         VALUES ('${name}','${description}', ${tooltype}, ${toolmode}, ${status}, true,'${JSON.stringify(
          payload,
        )}',${
          toolsexecutiontype != '0'
        },${toolsoutput},${customername}) returning toolid;`;

        console.log(sql, 'sqlforTool');

        query(sql)
          .then(data => {
            // insertin customer
            res.status(200).json({
              data,
              message: 'tool inserted successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(400).send({
          data: 'Tool is already registered for selected customer',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

// export const createToolMaster = async (req, res) => {
//   if (req.body.tooltype == 2) {
//     createnewTool(req, res);
//   } else {
//     try {
//       const getData = JSON.parse(JSON.stringify(req.body));

//       const newCustomer =
//         getData.customername == 2
//           ? 'WKI'
//           : getData.customername == 3
//           ? 'Hodder'
//           : getData.customername == 4
//           ? 'SDU'
//           : getData.customername == 7
//           ? 'T&FPublisher'
//           : getData.customername == 1
//           ? 'CUP'
//           : getData.customername == 5
//           ? 'HodderEducation'
//           : getData.customername == 6
//           ? 'EmeraldPublishing'
//           : '';

//       const turl = 'http://172.18.5.46:8000/api/common/addUpdateTool';
//       const reqData = {
//         toolName: getData.name,
//         toolType: getData.toolsexecutiontype == '0' ? 'sync' : 'async',
//         processType: 'object',
//         customer: newCustomer,

//         toolId: 0,
//         isLock: 'n',
//       };

//       const options = {
//         method: 'POST',
//         httpAgent: new http.Agent({ keepAlive: true }),
//         headers: {
//           'Access-Control-Allow-Origin': true,
//           'Content-Type': 'application/json',
//           Accept: 'application/json',
//         },
//         data: reqData,
//         url: turl,
//       };
//       callAddTool(options, getData).then(result => {
//         if (result) {
//           res.status(200).send(result);
//         }
//         // console.log("res",res)
//       });
//     } catch (err) {
//       console.log(err, 'createtool');
//     }
//   }
// };

// const callAddTool = async (options, getData) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       console.log('reinn');

//       axios(options).then(async response => {
//         console.log('reas', response);
//         const datanew = response.data;

//         if (datanew.is_success) {
//           const output = await createToolMaster1(getData, datanew);
//           resolve(output);
//           // console.log("res",output)
//         }
//       });
//     } catch (err) {
//       console.log('callAddTool', err);
//       reject({
//         status: false,
//         message: err.response ? err.response : err.message,
//       });
//     }
//   });
// };

// export const createToolMaster1 = async (getData, datanew, res) => {
//   return new Promise(async resolve => {
//     const toolrefid = String(datanew.data);
//     const customer = String(getData.customername);

//     const checkSql = `select count(1) from pp_mst_tool where customerid=${customer} and toolname='${getData.name}'`;
//     query(checkSql)
//       .then(checkData => {
//         console.log('chckdata', checkData);
//         if (!+checkData[0].count > 0) {
//           const sql = `INSERT INTO public.pp_mst_tool(
//             toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid,toolrefid)
//            VALUES ('${getData.name}','${getData.description}', ${
//             getData.tooltype
//           }, ${getData.toolmode}, ${getData.status}, true,'${JSON.stringify(
//             getData.payload,
//           )}',${getData.toolsexecutiontype != '0'},${
//             getData.toolsoutput
//           },${customer},${toolrefid}) returning toolid;`;
//           console.log(sql, 'sqlforTool');
//           query(sql)
//             .then(data => {
//               // insertin customer
//               resolve({
//                 data,
//                 message: 'tool inserted successfully',
//                 status: true,
//               });
//             })
//             .catch(error => {
//               res.status(400).send({ message: error, status: false, data: [] });
//             });
//         } else {
//           resolve({
//             data: 'Tool is already registered for selected customer',
//             status: false,
//           });
//         }
//       })
//       .catch(error => {
//         return { message: error, status: false, data: [] };
//       });
//   });
// };

export const createComposingSoftwareMaster = (req, res) => {
  const getData = req.body;
  console.log(getData, 'getData');
  const checkSql = `select count(1) from wms_mst_software where customerid=${getData.customername} and appname='${getData.name}'`;
  query(checkSql)
    .then(checkData => {
      console.log('chckdata', checkData);
      if (!+checkData[0].count > 0) {
        const sql = `INSERT INTO public.wms_mst_software(
                appname, apptype, appurlpath, appdescription, isactive, version, owner, displayname, appicon, customerid)
           VALUES ('${getData.name}','${getData.fileParameter}','${getData.softwareParameter}','${getData.description}','${getData.status}', null,null, '${getData.displayname}', '${getData.appicon}',${getData.customername}) returning appid;`;
        console.log(sql, 'sqlforSoft');
        query(sql)
          .then(data => {
            // insertin customer
            res.status(200).json({
              data,
              message: 'Software inserted successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(400).send({
          data: 'Software is already registered for selected customer',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const getToolMaster = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      console.log(reqData.filter, 'filterrrrrrrr');
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');

    console.log(condition, 'connnnnnnnnnnnnnnnnn');
  }
  sql = `select count(1) from pp_mst_tool where 1=1 ${
    condition ? `AND${condition}` : condition
  } `;
  console.log(sql, 'getToolMaster');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        // sql = `select * from wms_tools_software_table where 1=1 ${
        //   condition ? `AND${condition}` : condition
        // } ORDER BY toolid DESC`;
        sql = `select a.toolid, a.toolname,a.tooldescription,a.toolstatus,a.istoolverified,a.payload,a.toolmodeid,a.tooloutputid
          ,a.isasync,a.toolrefid,a.isword,e.duname,b.toolmode,c.tooltype,d.name,a.tooltypeid,a.customerid from pp_mst_tool a
          join pp_mst_toolmode b on b.toolmodeid=a.toolmodeid
          join pp_mst_tooltype c on c.tooltypeid=a.tooltypeid
          join pp_mst_tool_output d on d.tooloutputid=a.tooloutputid
          left join org_mst_deliveryunit e on a.customerid=e.duid order by a.toolname`;
        query(sql)
          .then(getToolData => {
            res.status(200).json({
              data: {
                data: getToolData,
              },
              Success: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, Success: false, data: [] });
          });
      } else {
        res.status(200).json({
          data: { data: [] },
          message: 'No data found',
          Success: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, Success: false, data: [] });
    });
};
export const getSoftwareMaster = (req, res) => {
  const reqData = req.body;
  // const { pageNo } = reqData;
  // const { recordPerPage } = reqData;
  // let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    // offset = 0;
    reqData.filter.forEach((item, i) => {
      console.log(reqData.filter, 'filterrrrrrrr');
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${
              item.name === 'type' ? 'type' : item.name
            }::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');

    console.log(condition, 'connnnnnnnnnnnnnnnnn');
  }

  // sql = `select * from wms_tools_software_table where 1=1 ${
  //   condition ? `AND${condition}` : condition
  // } ORDER BY toolid DESC`;
  sql = `select a.appid,a.appname,a.apptype,a.appurlpath,a.appdescription,a.isactive,a.version
          ,a.owner,a.displayname,a.appicon,a.customerid,a.softrefid,a.softtypeid,e.duname from wms_mst_software a
          left join org_mst_deliveryunit e on a.customerid=e.duid order by a.appname`;
  query(sql)
    .then(getToolData => {
      if (getToolData.length > 0) {
        res.status(200).json({
          data: {
            data: getToolData,
          },
          Success: true,
        });
      } else {
        res.status(200).json({
          data: { data: [] },
          message: 'No data found',
          Success: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, Success: false, data: [] });
    });
};
export const deletenewTool = (req, res) => {
  const getData = req.body;

  console.log(getData, 'getDataaaaaaa');

  let sql = `DELETE FROM pp_mst_tool WHERE toolid=${getData.toolId};`;
  if (getData.tooltype != 'tool') {
    sql = `DELETE FROM wms_mst_software WHERE appid=${getData.toolId};`;
  }
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Tool deleted sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const deleteToolMaster = (req, res) => {
  deletenewTool(req, res);
};

// export const createDeleteMaster1 = (req, res) => {
//     let getData = req.body

//     console.log(getData, 'getDataaaaaaa')

//     let sql = `DELETE FROM pp_mst_tool WHERE toolid=${getData.toolId};`
//     query(sql).then((data) => {
//         res.status(200).json({ data: data, message: "Tool deleted sucessfully", status: true });
//     }).catch((error) => {
//         res.status(400).send({ message: error, status: false, );data: [] }
//      });
//     }

export const createDeleteMaster1 = getData => {
  return new Promise(async resolve => {
    const sql = `DELETE FROM pp_mst_tool WHERE toolid=${getData.toolId};`;
    query(sql)
      .then(data => {
        resolve({
          data,
          message: 'Tool deleted sucessfully',
          status: true,
        });
      })
      .catch(error => {
        resolve({ message: error, status: false, data: [] });
      });
  }).catch(err => {
    console.log(err, 'errr');
  });
};

// export const createToolMaster1 = async (getData, datanew, res) => {
//     return new Promise(async (resolve, reject) => {

//         let toolrefid = String(datanew.data);
//         let customer = String(getData.customername);

//         let checkSql = `select count(1) from pp_mst_tool where customerid=${customer} and toolname='${getData.name}'`
//         query(checkSql).then((checkData) => {
//             console.log("chckdata", checkData)
//             if (! +checkData[0].count > 0) {
//                 let sql = `INSERT INTO public.pp_mst_tool(
//             toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, tooloutputid,customerid,toolrefid)
//            VALUES ('${getData.name}','${getData.description}', ${getData.tooltype}, ${getData.toolmode}, ${getData.status}, true,'${JSON.stringify(getData.payload)}',${getData.toolsexecutiontype == '0' ? false : true},${getData.toolsoutput},${customer},${toolrefid}) returning toolid;`
//                 console.log(sql, "sqlforTool")
//                 query(sql).then((data) => {
//                     //insertin customer
//                     resolve({ data: data, message: "tool inserted successfully", status: true }
//                     )
//                 }).catch((error) => {
//                     res.status(400).send({ message: error, status: false, data: [] });
//                 });
//             } else {
//                 resolve({ data: "Tool is already registered for selected customer", status: false })
//             }
//         }).catch((error) => {
//             return { message: error, status: false, data: [] };
//         });
//     })
// }

export const deleteSoftwareMaster = (req, res) => {
  const getData = req.body;

  console.log(getData, 'Dataaaaaaa software');

  const sql = `DELETE FROM wms_mst_software WHERE appid=${getData.appId};`;
  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Software deleted sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const stageActivityDetails = (req, res) => {
  const reqData = req.body;
  console.log('reqqq', reqData);

  let sql = '';
  logger.info(reqData, 'reqdata');
  sql = `select a.activityname,b.stagename,c.config from wms_workflowdefinition c join wms_mst_activity a ON a.activityid=c.activityid
    join wms_mst_stage b ON  b.stageid= c.stageid and C.wfid =${parseInt(
      reqData.wfid,
    )}`;

  query(sql, [])
    .then(response => {
      // logger.info("dataforsoftware",response)
      const toolsDetails = [];
      for (let i = 0; i < response.length; i++) {
        const toolsIdArr =
          response[i].config &&
          response[i].config.toolsId &&
          response[i].config.toolsId instanceof Array
            ? response[i].config.toolsId
            : [];
        console.log('toolsIdArr', toolsIdArr);
        if (
          toolsIdArr.length > 0 &&
          toolsIdArr.includes(parseInt(reqData.toolsId))
        ) {
          toolsDetails.push({
            activity: response[i].activityname,
            stage: response[i].stagename,
          });
        }
      }
      console.log('toolsDetails', toolsDetails);
      res.status(200).json({ data: toolsDetails });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const wipActivityDetails = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
  }

  sql = `select count(0) from getwipenginestatus(${parseInt(
    reqData.wfid,
  )},${parseInt(reqData.activitystatus)}) ${
    condition ? `WHERE${condition}` : condition
  }`;

  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `select * from getwipenginestatus(${parseInt(
          reqData.wfid,
        )},${parseInt(reqData.activitystatus)}) ${
          condition ? `WHERE${condition}` : condition
        } LIMIT ${recordPerPage} OFFSET ${offset}`;

        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const retriggerActivity = async (req, res) => {
  let fileid = '';
  const {
    workorderid,
    wfdefid,
    woincomingfileid,
    stageiterationcount,
    activityiterationcount,
    // wfeventid,
  } = req.body;
  try {
    // let fileid = woincomingfileid == null? 0 : woincomingfileid;
    const sql1 = `Select instancetype from wms_workflowdefinition where wfdefid=${wfdefid}`;
    const instancetype = await query(sql1);
    if (instancetype[0].instancetype == 'Single') {
      fileid = 0;
    } else {
      const sql2 = `Select filetypeid from public.wms_workorder_incomingfiledetails where woincomingfileid in (${woincomingfileid})`;
      const chapter = await query(sql2);
      fileid = chapter[0].filetypeid == 1 ? 0 : woincomingfileid;
    }
    const sql = ` Select * from retriggeractivity ( $1 ,$2 , $3 ,$4,$5)`;
    const eventdata = await query(sql, [
      workorderid,
      wfdefid,
      fileid,
      stageiterationcount,
      activityiterationcount,
    ]);
    if (
      eventdata &&
      eventdata.length > 0 &&
      eventdata[0].retriggeractivity != null
    ) {
      logger.info(eventdata[0].retriggeractivity, 'Event data deleted');
      await sendToTaskQueue(eventdata[0].retriggeractivity);
    }
    res.status(200).send('Data triggered sucessfully');
  } catch (e) {
    logger.info(e, 'Error in Retriggering the activity');
    res.status(400).send(e.message ? e.message : e);
  }
};

export const workorderlock = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
    sql = `SELECT COUNT(*) FROM wms_workorder ${
      condition ? `WHERE${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM wms_workorder ${
      condition ? `WHERE${condition}` : condition
    }`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `SELECT * FROM wms_workorder ${
          condition ? `WHERE${condition}` : condition
        }  ORDER BY 1 DESC LIMIT ${recordPerPage} OFFSET ${offset}`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const softstageActivityDetails = (req, res) => {
  const reqData = req.body;
  console.log('reqqq', reqData);

  let sql = '';
  logger.info(reqData, 'reqdata');
  sql = `select a.activityname,b.stagename,c.config from wms_workflowdefinition c join wms_mst_activity a ON a.activityid=c.activityid
    join wms_mst_stage b ON  b.stageid= c.stageid and C.wfid =${parseInt(
      reqData.wfid,
    )}`;

  query(sql, [])
    .then(response => {
      // logger.info("dataforsoftware",response) softwareId
      const softwareDetails = [];
      for (let i = 0; i < response.length; i++) {
        const softwareIdArr =
          response[i].config &&
          response[i].config.softwareId &&
          response[i].config.softwareId instanceof Array
            ? response[i].config.softwareId
            : [];
        console.log('softwareIdArr', softwareIdArr);
        if (
          softwareIdArr.length > 0 &&
          softwareIdArr.includes(parseInt(reqData.softId))
        ) {
          softwareDetails.push({
            activity: response[i].activityname,
            stage: response[i].stagename,
          });
        }
      }
      console.log('toolsDetails', softwareDetails);
      res.status(200).json({ data: softwareDetails });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWfidOptions = (req, res) => {
  const sql = `select wfid as id,wfname as text from wms_workflow`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getToolidOptions = (req, res) => {
  const sql = `select toolid as id,toolname as text from pp_mst_tool where toolstatus=true`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getSoftwareidOptions = (req, res) => {
  const sql = `select appid as id,appname as text from wms_mst_software where isactive=true`;
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getToolById = (req, res) => {
  const { toolId } = req.body;
  console.log(toolId, 'tooliddd');
  const sql = `select toolname, tooldescription, tooltypeid, toolmodeid, toolstatus, istoolverified,payload, isasync, 
    tooloutputid,customerid from pp_mst_tool where toolid =${toolId}`;
  console.log(sql, 'journalacronym');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeee');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getSoftwareById = (req, res) => {
  const { appId } = req.body;
  console.log(appId, 'appp');
  const sql = `select apptype,appurlpath,appicon,displayname,isactive from wms_mst_software where appid=${appId}`;
  console.log(sql, 'softtttt');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeeesoft');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getLocalToolsPath = (req, res) => {
  const { duId } = req.body;
  const sql = `select * from public.wms_mst_customerconfigdetails where duid=${duId}`;

  query(sql)
    .then(response => {
      res.status(200).json({
        data: response[0],
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updatenewTool = (req, res) => {
  const getData = req.body;

  console.log(getData, 'getDataaaaaaaup');

  const sql = `UPDATE pp_mst_tool SET   
    toolname='${getData.name}', tooldescription='${
    getData.description
  }', toolmodeid='${getData.toolmode}', toolstatus=${
    getData.status
  }, tooltypeid = ${getData.tooltype},
    payload='${JSON.stringify(
      getData.payload,
    )}',istoolverified=${true}, isasync =${
    getData.toolsexecutiontype != '0'
  }, tooloutputid =${getData.toolsoutput}
    WHERE toolid=${getData.toolId};`;

  console.log(sql, 'sqltool');

  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Tool updated sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const updateToolById = async (req, res) => {
  const {
    name,
    description,
    toolmode,
    status,
    tooltype,
    payload,
    toolsexecutiontype,
    toolsoutput,
    toolId,
  } = req.body;

  const sql = `UPDATE pp_mst_tool SET   
    toolname='${name}', tooldescription='${description}', toolmodeid='${toolmode}', toolstatus=${status}, tooltypeid = ${tooltype},
    payload='${JSON.stringify(payload)}',istoolverified=${true}, isasync =${
    toolsexecutiontype != '0'
  }, tooloutputid =${toolsoutput}
    WHERE toolid=${toolId};`;

  console.log(sql, 'sqltool');

  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Tool updated sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

// export const updateToolById = async (req, res) => {
//   if (req.body.tooltype == 2) {
//     updatenewTool(req, res);
//   } else {
//     try {
//       const getData = JSON.parse(JSON.stringify(req.body));
//       let sql = ``;
//       if (getData.tooltype.toString() == '3') {
//         sql = `UPDATE pp_mst_tool SET tooldescription='${
//           getData.description
//         }', toolmodeid='${getData.toolmode}', toolstatus=${
//           getData.status
//         }, tooltypeid = ${
//           getData.tooltype
//         },istoolverified=${true}, tooloutputid =${getData.toolsoutput}
//             WHERE toolid=${getData.toolId};`;
//       } else {
//         sql = `UPDATE pp_mst_tool SET tooldescription='${
//           getData.description
//         }', toolmodeid='${getData.toolmode}', toolstatus=${
//           getData.status
//         }, tooltypeid = ${getData.tooltype},
//             payload='${JSON.stringify(
//               getData.payload,
//             )}',istoolverified=${true}, isasync =${
//           getData.toolsexecutiontype != '0'
//         }, tooloutputid =${getData.toolsoutput}
//             WHERE toolid=${getData.toolId};`;
//       }

//       query(sql)
//         .then(data => {
//           res.status(200).json({
//             data,
//             message: 'Tool updated sucessfully',
//             status: true,
//           });
//         })
//         .catch(error => {
//           res.status(400).send({
//             message: error,
//             status: false,
//             data: [],
//           });
//         });
//     } catch (err) {
//       console.log(err);
//     }
//   }
// };

// const callUpdateTool = async (options, getData) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       axios(options).then(async response => {
//         console.log(response);
//         const datanew = response.data;
//         if (datanew.is_success) {
//           const output = await updateToolById1(getData);
//           resolve(output);
//         }
//       });
//     } catch (err) {
//       console.log(err);
//       reject({
//         status: false,
//         message: err.response ? err.response : err.message,
//       });
//     }
//   });
// };

export const updateToolById1 = (getData, res) => {
  return new Promise(async resolve => {
    const sql = `UPDATE pp_mst_tool SET   
        toolname='${getData.name}', tooldescription='${
      getData.description
    }', toolmodeid='${getData.toolmode}', toolstatus=${
      getData.status
    }, tooltypeid = ${getData.tooltype},
        payload='${JSON.stringify(
          getData.payload,
        )}',istoolverified=${true}, isasync =${
      getData.toolsexecutiontype != '0'
    }, tooloutputid =${getData.toolsoutput}
        WHERE toolid=${getData.toolId};`;

    console.log(sql, 'sqltool');

    query(sql)
      .then(data => {
        resolve({
          data,
          message: 'Tool updated sucessfully',
          status: true,
        });
      })
      .catch(error => {
        res.status(400).send({ message: error, status: false, data: [] });
      });
  });
};

export const updateSoftwareById = (req, res) => {
  const {
    name,
    fileParameter,
    softwareParameter,
    description,
    displayname,
    appicon,
    customername,
    appId,
  } = req.body;

  const sql = `UPDATE wms_mst_software SET   
    appname='${name}', apptype='${fileParameter}', appurlpath='${softwareParameter}',appdescription='${description}',displayname = '${displayname}',
    appicon ='${appicon}', customerid =${customername}
    WHERE appid=${appId};`;

  console.log(sql, 'sqltool');

  query(sql)
    .then(data => {
      res.status(200).json({
        data,
        message: 'Software updated sucessfully',
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

// export const updateSoftwareById = (req, res) => {
//   const getData = req.body;

//   console.log(getData, 'getDataaaaaaasoft');

//   const sql = `UPDATE wms_mst_software SET
//     appname='${getData.name}', apptype='${getData.fileParameter}', appurlpath='${getData.softwareParameter}',appdescription='${getData.description}',displayname = '${getData.displayname}',
//     appicon ='${getData.appicon}', customerid =${getData.customername}
//     WHERE appid=${getData.appId};`;

//   console.log(sql, 'sqltool');

//   query(sql)
//     .then(data => {
//       res.status(200).json({
//         data,
//         message: 'Software updated sucessfully',
//         status: true,
//       });
//     })
//     .catch(error => {
//       res.status(400).send({ message: error, status: false, data: [] });
//     });
// };

export const getToolstPlaceholderField = (req, res) => {
  const fields = getPlaceHolderFields();
  res.send(fields);
};

// Master tool and software end
// end

// Configuration ftp start

export const getFtpList = (req, res) => {
  const reqData = req.body;
  const { pageNo } = reqData;
  const { recordPerPage } = reqData;
  let offset = (pageNo - 1) * recordPerPage;
  let sql = '';
  let condition = '';
  if (reqData.type === 'filter') {
    offset = 0;
    reqData.filter.forEach((item, i) => {
      condition +=
        reqData.filter.length - 1 !== i
          ? ` LOWER(${
              item.name
            }::text) LIKE '%${item.value.toLowerCase()}%' AND `
          : ` LOWER(${item.name}::text) LIKE '%${item.value.toLowerCase()}%'`;
    });
    logger.info(condition, 'conditionconditioncondition111');
    sql = `SELECT COUNT(*) FROM wms_ft_transaction_table ${
      condition ? `WHERE${condition}` : condition
    }`;
  } else {
    sql = `SELECT COUNT(*) FROM wms_ft_transaction_table ${
      condition ? `WHERE${condition}` : condition
    }`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const numOfPages = Math.ceil(getCount[0].count / reqData.recordPerPage);
        const sqlQuery = `SELECT * FROM wms_ft_transaction_table ${
          condition ? `WHERE${condition}` : condition
        }  ORDER BY trid DESC LIMIT ${recordPerPage} OFFSET ${offset}`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);
            res.status(200).json({
              data,
              total: getCount[0].count,
              numOfPages,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      } else {
        res.status(200).json({ data: [], message: 'No data found' });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// Configuration ftp end

// Library Report Start
export const getTemplateById = (req, res) => {
  const { id } = req.body;

  const sql = `SELECT cus.customername,cus.customerid,tem.templatetypeid,tem.isactive,tem.libraryname,du.duname,du.duid,t.templateid,t.templatename,sw.softwarename,sw.softwareid,tt.libraryname,concat(us.username , ' (', us.userid, ')') as username,t.uploadeddate,t.templateuuid,t.templatefilepath,case when t.isactive = TRUE then 1 else 0 end as isactive	
    FROM public.wms_mst_composingsw_templates as t join public.wms_user as us on us.userid=t.uploadedby	
     join public.pp_mst_composingsoftware as sw on sw.softwareid=t.composingswid join public.wms_mst_template_type as tt on tt.templatetypeid=t.templatetypeid	
	 join public.org_mst_deliveryunit as du on du.duid = t.duid 	
	 join public.wms_mst_template_type as tem on tem.templatetypeid = t.templatetypeid	
	 join public.org_mst_customer as cus on cus.customerid =t.composingswid where templateid=${id}`;
  console.log(sql, 'journalacronym');
  query(sql)
    .then(response => {
      console.log(response, 'responseeeee');
      res.status(200).json({
        data: response,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const addTempDetails = (req, res) => {
  const { path, uuid, datas, type } = req.body;
  const status = datas.status == '1';

  if (type == 'add') {
    const sql = `INSERT INTO public.wms_mst_composingsw_templates(templatename, composingswid, duid, customerid, uploadedby, uploadeddate,isactive, templateuuid,templatefilepath,isdelete,templatetypeid,filename)
            VALUES('${datas.templatename}', ${datas.softwareId}, ${datas.duID}, ${datas.customerId},'${datas.profile}',CURRENT_DATE,'${status}',
            '${uuid}','${path}',false, ${datas.libraryId},'${datas.uploadingFileName}') returning templateid;`;
    console.log(sql, 'newwww');
    query(sql)
      .then(data => {
        res.status(200).json({
          data,
          message: 'Template Uploaded Successfully',
          status: true,
        });
      })
      .catch(error => {
        console.log(error, 'eeeee');
        res.status(400).send({ message: error, status: false, data: [] });
      });
  } else {
    const sql1 = `UPDATE public.wms_mst_composingsw_templates SET  isactive='${status}'
         WHERE templateid='${datas.templateid}'`;
    query(sql1)
      .then(data => {
        const sql2 = `INSERT INTO public.wms_mst_composingsw_templates(templatename, composingswid, duid, customerid, uploadedby, uploadeddate,isactive, templateuuid,templatefilepath,isdelete,templatetypeid,filename)
            VALUES('${datas.templatename}', ${datas.softwareId}, ${datas.duID}, ${datas.customerId},'${datas.profile}',CURRENT_DATE,'${status}',
            '${uuid}','${path}',false, ${datas.libraryId},'${datas.uploadingFileName}') returning templateid;`;

        query(sql2)
          .then(response => {
            console.log(response, 'responseeeee');
            res.status(200).json({
              data,
              message: 'Template Updated Successfully',
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error });
          });
      })
      .catch(error => {
        console.log(error, 'eeeee');
        res.status(400).send({ message: error, status: false, data: [] });
      });
  }
};

export const getFileInfo = async (req, res) => {
  const { path } = req.body;
  try {
    const fileExistDetails = await _isFileExist(path);

    res.send(fileExistDetails);
  } catch (err) {
    logger.info(err, 'isFileExist');
    res
      .status(400)
      .send({ message: err.message?.data ? err.message?.data : err });
  }
};

export const getTemplateCommonOptions = (req, res) => {
  const getData = req.body;
  let sql = '';
  if (getData.type === 'du') {
    sql = `	select duid as value,duname as label from org_mst_deliveryunit`;
  } else if (getData.type === 'customername') {
    sql = `	select customerid as value,customername as label from org_mst_customer`;
  } else if (getData.type === 'library') {
    sql = `select templatetypeid as value,libraryname as label from wms_mst_template_type `;
  } else if (getData.type === 'software') {
    sql = `select softwareid as value,softwarename as label from pp_mst_composingsoftware `;
  }
  console.log(sql, 'sqlforToolOption');
  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
// Library Report End

export const checkJobNormCombination = (req, res) => {
  const {
    customer,
    division,
    du,
    service: ser,
    subdivision,
    workflow,
    softwares,
    inputfiletype,
  } = req.body;
  const sql = `select count(1) from public.wms_mst_jobnorms where divisionid=${division} 
    and subdivisionid=${subdivision} and duid=${du} and customerid=${customer} and serviceid=${ser} and wfid=${workflow} and softwareid=${softwares} and filetypeid=${inputfiletype}`;
  console.log('sql', sql);
  query(sql)
    .then(normCount => {
      console.log('normCount', normCount);
      if (+normCount[0].count === 0) {
        res.status(200).json({
          data: 'Combination is not present',
          status: true,
        });
      } else {
        res.status(200).json({
          data: 'Job Norms is already mapped for this combination',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const createNormMaster = (req, res) => {
  const {
    category,
    customer,
    division,
    du,
    inputfiletype,
    normname,
    service: ser,
    softwares,
    subdivision,
    workflow,
    createdBy,
    getData,
    stageiterationpercent,
    activityiterationpercent,
    duration,
    effectiveDate,
  } = req.body;
  let sql = `select count(1) from public.wms_mst_jobnorms where divisionid=${division} and subdivisionid=${subdivision} 
    and duid=${du} and customerid=${customer} and serviceid=${ser} and wfid=${workflow}  and softwareid=${softwares} and filetypeid=${inputfiletype}`;
  query(sql)
    .then(normCount => {
      if (+normCount[0].count === 0) {
        sql = `INSERT INTO public.wms_mst_jobnorms(
         jobnormsname, divisionid, subdivisionid, customerid, duid, softwareid, categoryid, 
        filetypeid, serviceid, wfid,
        createdby, createdon, updatedby, updatedon,stageiterationpercent,activityiterationpercent,duration,effectivedate)
        VALUES ('${normname}', ${division},  ${subdivision},  ${customer}, ${du}, ${softwares}, ${category},
         ${inputfiletype}, ${ser}, ${workflow}, '${createdBy}', current_timestamp, '${createdBy}', current_timestamp,${
          stageiterationpercent || null
        },${
          activityiterationpercent || null
        },'${duration}','${effectiveDate}') RETURNING *;`;
        console.log(sql, 'Inserting Norm Master');
        query(sql)
          .then(response => {
            const val = [];
            getData.forEach(data => {
              val.push(
                `(${response[0].jobnormsid},${data.service},${data.stage},${
                  data.activity
                },${data.complexity},${data.quantity ? data.quantity : null},${
                  data.unit ? data.unit : null
                },${data.skill},${data.skillvalue ? data.skillvalue : null})`,
              );
            });
            sql = `	INSERT INTO public.wms_mst_jobnorms_details_map(
            jobnormsid, serviceid,
           stageid, activityid, complexityid, quantity, uomid, skilllevelid, skillquantity)
           VALUES ${val}`;
            console.log(sql, 'Inserting Norm Detail');
            query(sql)
              .then(resp => {
                res.status(200).json({
                  data: resp,
                  status: true,
                });
              })
              .catch(error => {
                res
                  .status(400)
                  .send({ message: error, status: false, data: [] });
              });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      } else {
        res.status(200).json({
          data: 'Job Norms is already mapped for this combination',
          status: false,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getNormMaster = (req, res) => {
  let sql = '';
  sql = `select count(1) from (select division.division as division,
        subdivision.subdivision as subdivision,
        du.duname as du,
        cust.customername as customer,
        software.softwarename as software,
        category.category as category,
        workflow.wfname as workflow,
        filetype.filetypename as inputfiletype,
        jobnorms.* from wms_mst_jobnorms jobnorms 
        join org_mst_division  division on division.divisionid = jobnorms.divisionid
        join org_mst_subdivision subdivision on subdivision.subdivisionid=jobnorms.subdivisionid
        join org_mst_deliveryunit du on du.duid=jobnorms.duid
        join org_mst_customer cust on cust.customerid=jobnorms.customerid
        join pp_mst_composingsoftware software on software.softwareid=jobnorms.softwareid
        join pp_mst_wocategory  category on category.categoryid=jobnorms.categoryid
        join wms_workflow workflow on workflow.wfid=jobnorms.wfid
        join pp_mst_inputfiletype filetype on filetype.filetypeid=jobnorms.filetypeid
        )as table1 where 1=1`;
  console.log(sql, 'getNormMaster');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        sql = `select * from (select division.division as division,
                subdivision.subdivision as subdivision,
                du.duname as du,
                cust.customername as customer,
                software.softwarename as software,
                category.category as category,
                workflow.wfname as workflow,
                filetype.filetypename as inputfiletype,
                jobnorms.* from wms_mst_jobnorms jobnorms 
                join org_mst_division  division on division.divisionid = jobnorms.divisionid
                join org_mst_subdivision subdivision on subdivision.subdivisionid=jobnorms.subdivisionid
                join org_mst_deliveryunit du on du.duid=jobnorms.duid
                join org_mst_customer cust on cust.customerid=jobnorms.customerid
                join pp_mst_composingsoftware software on software.softwareid=jobnorms.softwareid
                join pp_mst_wocategory  category on category.categoryid=jobnorms.categoryid
                join wms_workflow workflow on workflow.wfid=jobnorms.wfid
                join pp_mst_inputfiletype filetype on filetype.filetypeid=jobnorms.filetypeid
                ) as table1 where 1=1  ORDER BY jobnormsid DESC`;
        query(sql)
          .then(getNormData => {
            res.status(200).json({
              data: {
                data: getNormData,
              },
              Success: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, Success: false, data: [] });
          });
      } else {
        res.status(200).json({
          data: { data: [] },
          message: 'No data found',
          Success: true,
        });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, Success: false, data: [] });
    });
};
export const updateNorms = (req, res) => {
  const {
    category,
    customer,
    division,
    du,
    inputfiletype,
    normname,
    service: ser,
    softwares,
    subdivision,
    workflow,
    createdBy,
    getData,
    normId,
    stageiterationpercent,
    activityiterationpercent,
    duration,
    effectiveDate,
  } = req.body;
  let sql = `UPDATE public.wms_mst_jobnorms
	SET  jobnormsname='${normname}', divisionid=${division}, subdivisionid=${subdivision}, customerid=${customer}, 
	duid=${du}, softwareid=${softwares}, categoryid=${category}, filetypeid=${inputfiletype}, serviceid=${ser}, wfid=${workflow},
	 updatedby='${createdBy}',stageiterationpercent=${stageiterationpercent},activityiterationpercent=${activityiterationpercent},duration='${duration}',effectivedate='${effectiveDate}', updatedon=current_timestamp
	WHERE jobnormsid=${normId};`;
  query(sql)
    .then(() => {
      sql = `DELETE FROM public.wms_mst_jobnorms_details_map WHERE jobnormsid=${normId}`;
      query(sql)
        .then(() => {
          const val = [];
          getData.forEach(data => {
            val.push(
              `(${normId},${data.service},${data.stage},${data.activity},${
                data.complexity
              },${data.quantity ? data.quantity : null},${
                data.unit ? data.unit : null
              },${data.skill},${data.skillvalue ? data.skillvalue : null})`,
            );
          });
          sql = `INSERT INTO public.wms_mst_jobnorms_details_map(
        jobnormsid, serviceid,
       stageid, activityid, complexityid, quantity, uomid, skilllevelid, skillquantity)
       VALUES ${val}`;
          console.log(sql, 'Inserting Norm Detail');
          query(sql)
            .then(response => {
              res.status(200).json({ data: response, status: true });
            })
            .catch(error => {
              res.status(400).send({ message: error, status: false, data: [] });
            });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const getNormById = async (req, res) => {
  const reqData = req.body;
  let sql = `select division.division as division,subdivision.subdivision as subdivision,du.duname as du,cust.customername as customer,software.softwarename as software,
    category.category as category,workflow.wfname as workflow,filetype.filetypename as inputfilename,jobnorms.* from wms_mst_jobnorms jobnorms join org_mst_division  division on division.divisionid = jobnorms.divisionid join org_mst_subdivision subdivision on subdivision.subdivisionid=jobnorms.subdivisionid
    join org_mst_deliveryunit du on du.duid=jobnorms.duid join org_mst_customer cust on cust.customerid=jobnorms.customerid join pp_mst_composingsoftware software on software.softwareid=jobnorms.softwareid join pp_mst_wocategory  category on category.categoryid=jobnorms.categoryid
    join wms_workflow workflow on workflow.wfid=jobnorms.wfid join pp_mst_inputfiletype filetype on 
    filetype.filetypeid=jobnorms.filetypeid where jobnorms.jobnormsid=${reqData.normsId}`;
  console.log(sql, 'get Norm From ID');
  await query(sql)
    .then(async response => {
      sql = `select distinct on(complexity.complexityid,details.skilllevelid) complexity.complexityid,details.skilllevelid,complexity.complexity,skill.skilllevel
        from wms_mst_jobnorms_details_map details 
        join wms_mst_complexity complexity on details.complexityid=complexity.complexityid
        join wms_mst_skilllevel skill on skill.skilllevelid=details.skilllevelid
        where jobnormsid=${reqData.normsId}`;
      await query(sql).then(async complexSkill => {
        console.log(complexSkill);
        let complex = complexSkill.map(compSk => {
          return {
            label: compSk.complexity,
            value: compSk.complexityid,
          };
        });
        complex = Array.from(new Set(complex.map(JSON.stringify))).map(
          JSON.parse,
        );
        let skill = complexSkill.map(compSk => {
          return {
            label: compSk.skilllevel,
            value: compSk.skilllevelid,
          };
        });
        skill = Array.from(new Set(skill.map(JSON.stringify))).map(JSON.parse);
        sql = `	select * from wms_mst_jobnorms_details_map where jobnormsid=${reqData.normsId} order by jobnormsdetailid`;
        await query(sql)
          .then(async detail => {
            res.status(200).json({
              data: {
                normsData: response[0],
                complexity: complex,
                skill,
                detailData: detail,
              },
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};
export const deleteNormMaster = async (req, res) => {
  const reqData = req.body;
  let sql = `DELETE FROM public.wms_mst_jobnorms_details_map WHERE jobnormsid=${reqData.normsId}`;
  await query(sql)
    .then(async () => {
      sql = `DELETE FROM public.wms_mst_jobnorms WHERE jobnormsid=${reqData.normsId}`;
      await query(sql)
        .then(async response => {
          res.status(200).send({ status: true, data: response });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const getNotificationsOptionList = (req, res) => {
  const getData = req.body;
  let sql = ``;
  if (getData.type === 'du') {
    sql = `SELECT duid as value, duname as label from org_mst_deliveryunit`;
  } else if (getData.type === 'division') {
    sql = `
            SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value, org_mst_division.division as label FROM org_mst_customer_orgmap  
            JOIN org_mst_division ON org_mst_customer_orgmap.divisionid = org_mst_division.divisionid
			JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE duid = ${getData.duId} `;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap  
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} AND duid = ${getData.duId}`;
  } else if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label,org_mst_customer_orgmap.custorgmapid FROM org_mst_customer_orgmap  
            JOIN org_mst_customer ON org_mst_customer_orgmap.customerid = org_mst_customer.customerid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} AND duid = ${getData.duId} AND org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId}`;
  } else if (getData.type === 'service') {
    sql = `SELECT  DISTINCT ON (service.serviceid)  service.serviceid as value, service.servicename as label FROM public.org_mst_customer_orgmap as custmap
                JOIN public.org_mst_customerorg_service_map as custservice ON custservice.custorgmapid = custmap.custorgmapid
                JOIN public.wms_mst_service as service ON service.serviceid = custservice.serviceid
                JOIN org_mst_customerorg_du_map as dumap ON dumap.custorgmapid = custmap.custorgmapid 
                WHERE  custmap.customerid=${getData.customerId} AND custmap.divisionid=${getData.divisionId} 
                AND custmap.subdivisionid=${getData.subDivisionId} AND dumap.duid = ${getData.duId}  `;
  } else if (getData.type === 'workflow') {
    sql = `SELECT DISTINCT ON(workflow.wfid) workflow.wfid as value, workflow.wfname as label, def.wfid
            FROM public.wms_workflow as workflow
            left join wms_workflowdefinition as def on def.wfid = workflow.wfid
            WHERE workflow.isactive = true AND  workflow.customerid = ${getData.customerId}
            ORDER BY workflow.wfid ASC`;
  } else if (getData.type === 'journal') {
    sql = `SELECT DISTINCT ON(journal.journalid) journal.journalid as value, journal.journalacronym as label FROM pp_mst_journal as journal
    WHERE journal.custorgmapid = ${getData.customerOrgId}
    ORDER BY journal.journalid ASC`;
  }
  console.log(sql, 'sql for optionsj');
  query(sql)
    .then(data => {
      res.status(200).json({ data });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getChecklistOptionList = (req, res) => {
  const getData = req.body;
  let sql = ``;
  if (getData.type === 'du') {
    sql = `SELECT DISTINCT ON (org_mst_deliveryunit.duid) org_mst_deliveryunit.duid as value, 
		org_mst_deliveryunit.duname as label FROM org_mst_customer_orgmap 
			JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
			 JOIN org_mst_deliveryunit ON org_mst_customerorg_du_map.duid = org_mst_deliveryunit.duid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId} and
            org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId}  
            and  org_mst_deliveryunit.isactive=true order by org_mst_deliveryunit.duid`;
  } else if (getData.type === 'division') {
    sql = `
        SELECT DISTINCT ON (org_mst_division.divisionid) org_mst_division.divisionid as value,org_mst_division.division as label
        from org_mst_division
        WHERE org_mst_division.isactive=true order by org_mst_division.divisionid`;
  } else if (getData.type === 'subdivision') {
    sql = `SELECT DISTINCT ON (org_mst_subdivision.subdivisionid) org_mst_subdivision.subdivisionid as value, org_mst_subdivision.subdivision as label FROM org_mst_customer_orgmap  
            JOIN org_mst_subdivision ON org_mst_customer_orgmap.subdivisionid = org_mst_subdivision.subdivisionid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId}  and org_mst_subdivision.isactive=true`;
  } else if (getData.type === 'customer') {
    sql = `SELECT DISTINCT ON (org_mst_customer.customerid) org_mst_customer.customerid as value, org_mst_customer.customername as label,org_mst_customer_orgmap.custorgmapid as custorgid FROM org_mst_customer_orgmap  
            JOIN org_mst_customer ON org_mst_customer_orgmap.customerid = org_mst_customer.customerid
            JOIN org_mst_customerorg_du_map ON org_mst_customerorg_du_map.custorgmapid = org_mst_customer_orgmap.custorgmapid
            WHERE org_mst_customer_orgmap.divisionid = ${getData.divisionId}  AND 
            org_mst_customer_orgmap.subdivisionid = ${getData.subDivisionId} and org_mst_customerorg_du_map.duid=${getData.duId}  and org_mst_customer.isactive=true`;
  } else if (getData.type === 'workflow') {
    sql = `SELECT workflow.wfid as value, workflow.wfname as label
        FROM public.wms_workflow as workflow
        WHERE workflow.isactive = true AND  workflow.customerid =${getData.customerId}
        ORDER BY workflow.wfid ASC`;
  } else if (getData.type === 'checklisttype') {
    sql = `SELECT checklisttypeid as value, checklisttype as lable FROM public.wms_mst_checklisttype
        where isactive = 1 ORDER BY checklisttypeid ASC  `;
  } else if (
    getData.type === 'genericskill' ||
    getData.type == 'customerskill'
  ) {
    sql = `SELECT skillid as value , skillname as label FROM public.wms_mst_skill
        ORDER BY skillid ASC `;
  } else if (getData.type === 'stage') {
    sql = `SELECT DISTINCT ON(stage.stageid) stage.stageid as value, stage.stagename as label FROM public.wms_workflowdefinition as def
        left join wms_mst_stage as stage on stage.stageid = def.stageid
        where def.wfid = ${getData.workflowId}
        ORDER BY stage.stageid ASC  `;
  }

  query(sql)
    .then(data => {
      res.status(200).json({ data, status: true });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const createCheckListMaster = async (req, res) => {
  const {
    checkListName,
    checkListType,
    workflowId,
    skillId,
    status,
    instructionList,
    divisionId,
    subDivisionId,
    customerId,
    duId,
    ischecklist,
  } = req.body;
  console.log(req.body, 'boddyyyyyyyyyy');
  const sql = `INSERT INTO public.wms_mst_checklist(
        checklistname, checklisttypeid, divisionid, subdivisionid, customerid, duid, wfid, skillid, isactive,ischecklist)
                 VALUES ('${checkListName}',${checkListType || null}, ${
    divisionId || null
  }, ${subDivisionId || null}, ${customerId || null} ,${duId || null}, ${
    workflowId || null
  }, ${skillId || null}, ${status},${ischecklist}) RETURNING checklistid`;
  console.log(sql, 'customermap');
  await query(sql)
    .then(async response => {
      const val = [];
      instructionList.forEach(list => {
        val.push(
          `(${response[0].checklistid}, '${list.instructions}', ${
            list.mandatory
          },${list.stage ? list.stage : null}, ${list.status})`,
        );
      });
      const insertInstruction = `INSERT INTO public.wms_mst_checklistinstruction(
                checklistid, checklistinstruction, mandatory, stageid, isactive)
                       VALUES ${val} RETURNING checklistinstructionid`;
      console.log(insertInstruction, 'insertInstruction');
      await query(insertInstruction).then(async dataInstruction => {
        console.log(dataInstruction, 'dataInstruction');
        const valAnswer = [];
        instructionList.forEach((data, i) => {
          data.answers.forEach(list => {
            valAnswer.push(
              `(${dataInstruction[i].checklistinstructionid}, '${list.answer}')`,
            );
          });
        });

        const insertAnswer = `INSERT INTO public.wms_mst_checklistinstruction_answer(
                checklistinstructionid, answer)
                VALUES ${valAnswer}`;
        console.log(insertAnswer, 'insertAnswer');
        await query(insertAnswer).then(async dataAnswer => {
          console.log(dataAnswer, 'dataAnswer');
          res.status(200).json({
            data: dataAnswer,
            status: true,
          });
        });
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const getCheckListMaster = (req, res) => {
  let sql = '';
  sql = `SELECT COUNT(*) FROM wms_master_checklist`;
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(getCount => {
      logger.info(getCount, 'getCount');
      if (getCount[0].count > 0) {
        const sqlQuery = `SELECT * FROM wms_master_checklist ORDER BY status DESC`;
        console.log(sqlQuery, 'sqlforquerryy');
        query(sqlQuery)
          .then(data => {
            logger.info('activity', data);
            res.status(200).json({
              data,
              status: true,
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false });
          });
      } else {
        res
          .status(200)
          .json({ data: [], message: 'No data found', status: true });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const getPrePopulateInstruction = (req, res) => {
  const { checkListId, checkListTypeId } = req.body;
  const sql = `SELECT instruction.checklistinstructionid,instruction.checklistid,instruction.checklistinstruction,instruction.mandatory,instruction.stageid,instruction.isactive FROM wms_mst_checklist as checklist
    left join wms_mst_checklistinstruction as instruction on instruction.checklistid = checklist.checklistid
    where instruction.checklistid = ${checkListId} and checklist.checklisttypeid = ${
    checkListTypeId || null
  }
    ORDER BY checklistinstructionid ASC `;
  console.log(sql, 'gettinginstruction');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

// Email Reader start

export const getEmailReader = (req, res) => {
  const sql = `select * from wms_mst_emailreader where isactive=true`;

  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

// File sequence filename details
export const getFilenameDetails = (req, res) => {
  const { woid } = req.body;

  const sql = `select ft.filetype,ifd.filename,ifd.filesequence,ifd.woincomingfileid from wms_workorder_incoming incoming 
    join wms_workorder_incomingfiledetails ifd on incoming.woincomingid=ifd.woincomingid
     join pp_mst_filetype ft on ft.filetypeid=ifd.filetypeid
    where incoming.woid=${woid} and ft.filetypeid NOT IN (1, 15) order by ifd.filesequence`;

  query(sql)
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const insertupdateEmailReader = (req, res) => {
  const reqData = JSON.stringify(req.body);
  const sql = `select * from  insert_emailreadertran('${reqData}')`;

  console.log(sql, 'insertingfile');
  query(sql)
    .then(response => {
      res
        .status(200)
        .json({ issuccess: true, data: response[0].insert_emailreadertran });
    })
    .catch(error => {
      res.status(400).json({ issuccess: false, message: error });
    });
};

// Email Reader end

export const getPrePopulateInstructionAnswers = (req, res) => {
  const { checkListId } = req.body;
  const sql = `SELECT answers.answer,answers.checklistinstructionanswerid, instruction.checklistinstructionid FROM public.wms_mst_checklistinstruction_answer as answers
    left join wms_mst_checklistinstruction as instruction on instruction.checklistinstructionid = answers.checklistinstructionid
    where checklistid = ${checkListId}
    ORDER BY checklistinstructionanswerid ASC  `;
  console.log(sql, 'gettinginstruction');
  query(sql)
    .then(response => {
      res.status(200).json({
        data: response,
        status: true,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};

export const updateCheckListMaster = async (req, res) => {
  const { checkResultArray, instructionList } = req.body;
  console.log(req.body, 'request body');
  let sql = '';
  const checklisttypeid =
    checkResultArray.checklisttype == 'customerspecific' ? 2 : 1;
  sql = `UPDATE public.wms_mst_checklist SET checklistname='${
    checkResultArray.checklistname
  }', checklisttypeid=${checklisttypeid || null}, divisionid=${
    checkResultArray.division ? checkResultArray.division : null
  },subdivisionid=${
    checkResultArray.subdivision ? checkResultArray.subdivision : null
  },customerid=${
    checkResultArray.customer ? checkResultArray.customer : null
  },duid=${checkResultArray.du ? checkResultArray.du : null}, wfid=${
    checkResultArray.wfid ? checkResultArray.wfid : null
  },skillid=${
    checkResultArray.genericskill
      ? checkResultArray.genericskill
      : checkResultArray.customerskill
  }, isactive=${checkResultArray.status}
               WHERE checklistid= ${checkResultArray.checklistid}`;
  console.log(sql, 'checklist updation');
  await query(sql)
    .then(async () => {
      sql = `delete from wms_mst_checklistinstruction_answer where checklistinstructionid in 
        (select checklistinstructionid from wms_mst_checklistinstruction where checklistid= ${checkResultArray.checklistid})`;
      await query(sql)
        .then(async () => {
          sql = `delete from wms_mst_checklistinstruction where checklistid= ${checkResultArray.checklistid}`;
          await query(sql)
            .then(async () => {
              const val = [];
              instructionList.forEach(list => {
                val.push(
                  `(${checkResultArray.checklistid}, '${list.instructions}', ${
                    list.mandatory
                  },${list.stage ? list.stage : null}, ${list.status})`,
                );
              });
              sql = `INSERT INTO public.wms_mst_checklistinstruction(checklistid, checklistinstruction, mandatory, stageid, isactive)
                                           VALUES ${val} RETURNING checklistinstructionid`;
              console.log(sql, 'insertInstruction');
              await query(sql)
                .then(async insertInsertion => {
                  const valAnswer = [];
                  instructionList.forEach((data, i) => {
                    data.answers.forEach(list => {
                      valAnswer.push(
                        `(${insertInsertion[i].checklistinstructionid}, '${list.answer}')`,
                      );
                    });
                  });
                  sql = `INSERT INTO public.wms_mst_checklistinstruction_answer(checklistinstructionid, answer)
                                            VALUES ${valAnswer}`;
                  console.log(sql, 'insertAnswer');
                  await query(sql)
                    .then(async insertInsertionAnswer => {
                      res
                        .status(200)
                        .json({ data: insertInsertionAnswer, status: true });
                    })
                    .catch(error => {
                      res
                        .status(400)
                        .send({ message: error, status: false, data: [] });
                    });
                })
                .catch(error => {
                  res
                    .status(400)
                    .send({ message: error, status: false, data: [] });
                });
            })
            .catch(error => {
              res.status(400).send({ message: error, status: false, data: [] });
            });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false, data: [] });
    });
};

export const deleteCheckListMaster = (req, res) => {
  const getData = req.body;

  const selectsql = `select checklistinstructionid FROM public.wms_mst_checklistinstruction WHERE checklistid=${getData.checkListId}`;
  console.log(selectsql, 'sql');
  query(selectsql).then(data => {
    console.log(data, 'data');
    // const val = [];
    if (data.length > 0) {
      data.forEach(list => {
        const deleteAns = `DELETE FROM public.wms_mst_checklistinstruction_answer WHERE checklistinstructionid=${list.checklistinstructionid}`;
        console.log(deleteAns, 'deleteAns');
        query(deleteAns)
          .then(() => {
            const deleteInst = `DELETE FROM public.wms_mst_checklistinstruction WHERE checklistid=${getData.checkListId}`;
            console.log(deleteInst, 'deleteInst');
            query(deleteInst).then(() => {
              const deleteChecklist = `DELETE FROM public.wms_mst_checklist WHERE checklistid=${getData.checkListId}`;
              console.log(deleteChecklist, 'deleteChecklist');
              query(deleteChecklist).then(() => {});
              res.status(200).json({
                data,
                message: 'Checklist deleted sucessfully',
                status: true,
              });
            });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          })
          .catch(error => {
            res.status(400).send({ message: error, status: false, data: [] });
          });
      });
    } else {
      const deleteChecklist = `DELETE FROM public.wms_mst_checklist WHERE checklistid=${getData.checkListId}`;
      console.log(deleteChecklist, 'deleteChecklist');
      query(deleteChecklist)
        .then(() => {
          res.status(200).json({
            data,
            message: 'Checklist deleted sucessfully',
            status: true,
          });
        })
        .catch(error => {
          res.status(400).send({ message: error, status: false, data: [] });
        });
    }
  });
};

export const checkSkillAvaliablity = async (req, res) => {
  const {
    type,
    skillId,
    divisionId,
    subDivisionId,
    duId,
    customerId,
    workflowId,
    typeId,
    checklistName,
  } = req.body;
  let sql = '';
  if (type == 'generic') {
    sql = `SELECT count(1) FROM public.wms_mst_checklist as checklist
        where checklist.skillid =${skillId} and checklist.checklisttypeid = ${typeId} `;
  } else if (type == 'customerspecific') {
    sql = `SELECT count(1) FROM public.wms_mst_checklist  as checklist
        where checklist.customerid = ${customerId} and checklist.divisionid = ${divisionId} and checklist.subdivisionid =${subDivisionId} and checklist.duid= ${duId} and checklist.skillid = ${skillId} and checklist.checklisttypeid = ${typeId} and checklist.wfid= ${workflowId}`;
  } else if (type == 'genericInstruction') {
    sql = `SELECT instruction.checklistinstructionid,instruction.checklistinstruction,instruction.mandatory,instruction.stageid,
        instruction.isactive,checklist.checklisttypeid FROM public.wms_mst_checklist as checklist
        left join wms_mst_checklistinstruction as instruction on instruction.checklistid = checklist.checklistid
        where checklist.checklisttypeid = ${typeId} and checklist.skillid = ${skillId}
        ORDER BY instruction.checklistinstructionid ASC `;
  } else if (type == 'checklistname') {
    sql = `SELECT count(*) FROM public.wms_mst_checklist as checklist where checklist.checklistname ='${checklistName}'`;
  }

  console.log(sql, 'gettinginstruction');
  await query(sql)
    .then(response => {
      const result = [];
      let tempAns = [];
      let temp = {};
      console.log(response, 'instruction response');
      if (type == 'genericInstruction') {
        if (type == 'genericInstruction') {
          let insertans = '';
          if (response && response.length) {
            response.map(async (list, index) => {
              console.log(list, index, 'listttt');
              insertans = `SELECT * FROM public.wms_mst_checklistinstruction_answer where checklistinstructionid = ${list.checklistinstructionid}
                                    ORDER BY checklistinstructionanswerid ASC `;
              await query(insertans).then(responseAns => {
                console.log(responseAns, 'responseAnsresponseAns');
                if (responseAns.length > 1) {
                  console.log(responseAns, 'answer');
                  responseAns.forEach(ans => {
                    tempAns.push({
                      answer: ans.answer,
                      checklistinstructionid: ans.checklistinstructionid,
                    });
                  });
                } else {
                  tempAns.push({
                    answer: responseAns[0].answer,
                    checklistinstructionid:
                      responseAns[0].checklistinstructionid,
                  });
                }
              });
              temp.answers = tempAns;
              temp.instructions = list.checklistinstruction;
              temp.checklistinstructionid = list.checklistinstructionid;
              temp.mandatory = list.mandatory;
              temp.status = list.isactive;
              temp.stageid = list.stageid;
              temp.checklisttypeid = list.checklisttypeid;
              result.push(temp);
              tempAns = [];
              temp = {};
              console.log(result, 'result for lk');
              if (index == response.length - 1) {
                res.status(200).json({
                  data: result,
                  status: true,
                });
              }
            });
          } else {
            res.status(200).json({
              data: [],
              status: true,
            });
          }
        } else {
          res.status(200).json({ data: [], status: true });
        }
      } else if (type == 'checklistname') {
        res.status(200).json({ data: response[0].count, status: true });
      } else {
        res.status(200).json({ data: response, status: true });
      }
    })
    .catch(error => {
      res.status(400).send({ message: error, status: false });
    });
};
