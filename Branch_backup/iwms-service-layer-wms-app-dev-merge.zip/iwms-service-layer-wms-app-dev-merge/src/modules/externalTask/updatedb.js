import { query } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';

export const updateFileTRNLog = (fileTrnData, wfeventId, client) => {
  logger.info(fileTrnData, 'inside fileTrnData trns update', wfeventId);
  return new Promise((resolve, reject) => {
    const values = [];
    fileTrnData.forEach(fileTrn => {
      const { path, uuid, fileId } = fileTrn;
      values.push(
        `(${wfeventId}, '${uuid}', '${path}', ${true}, ${false}, ${fileId})`,
      );
    });
    const sql = `INSERT INTO public.wms_workflowactivitytrn_file_map(
            wfeventid, repofileuuid, repofilepath, isvisible, isdownloaded, woincomingfileid)
            VALUES ${values};`;
    if (client) {
      client
        .query(sql)
        .then(() => {
          resolve();
        })
        .catch(e => {
          reject(e);
        });
    } else {
      query(sql)
        .then(() => resolve())
        .catch(e => reject(e));
    }
  });
};

export const updateEventLog = (
  wfeventId,
  log,
  client,
  activityStatusForExternalTask,
) => {
  return new Promise((resolve, reject) => {
    const sql = `UPDATE wms_workflow_eventlog SET activitystatus =$1, externaltasklog = $2 WHERE wfeventid = $3`;
    client
      .query(sql, [activityStatusForExternalTask, log, wfeventId])
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};

export const updateEventLogDetails = (
  wfeventId,
  client,
  activityStatusForExternalTask,
  Remarks,
) => {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO wms_workflow_eventlog_details( wfeventid, operationtype, timestamp,usercomments) VALUES ($1, $2, $3,$4)`;
    client
      .query(sql, [
        wfeventId,
        activityStatusForExternalTask,
        new Date(),
        Remarks,
      ])
      .then(() => {
        resolve();
      })
      .catch(e => {
        reject(e);
      });
  });
};
