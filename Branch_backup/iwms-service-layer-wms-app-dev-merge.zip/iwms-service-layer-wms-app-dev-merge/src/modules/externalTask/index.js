import { getNotificationConfig } from '../common/index.js';
import { query, transaction } from '../../database/postgres.js';
import {
  updateEventLog,
  updateEventLogDetails,
  updateFileTRNLog,
} from './updatedb.js';
import logger from '../utils/logs/index.js';

export const updateDb = async (req, res) => {
  const { wfeventId, log, fileTrnData = [], activityStatus, Type } = req.body;
  try {
    const sql = `select wf.wfdefid,wf.activityalias,wf.activitytype from wms_workflow_eventlog  as eventlog

        join wms_workflowdefinition  as wf on eventlog.wfdefid = wf.wfdefid

        where eventlog.wfeventid = $1`;
    const resultArray = await query(sql, [wfeventId]);
    const result = resultArray.length ? resultArray[0] : {};
    logger.info(result, 'responsedfsdf');

    const activityStatusForExternalTask =
      Type == 'externalTaskStatus'
        ? activityStatus
        : Object.keys(result).length > 0 &&
          result.activitytype == 'External Task'
        ? activityStatus
          ? 'Completed'
          : 'Failed'
        : 'Completed';

    logger.info(activityStatusForExternalTask, 'activityStatusForExternalTask');

    await _updateDb(wfeventId, log, fileTrnData, activityStatusForExternalTask);
    logger.info(res, 'res for activity external task');

    res.status(200).json({ status: 'Success' });
  } catch (e) {
    logger.info(e);

    res.status(400).send(e.message ? e.message : e);
  }
};

export const _updateDb = async (
  wfeventId,
  log,
  fileTrnData,
  activityStatusForExternalTask,
) => {
  await transaction(async client => {
    await updateEventLog(wfeventId, log, client, activityStatusForExternalTask);
    logger.info(fileTrnData, 'fileTrnData before trns update', wfeventId);
    if (fileTrnData.length)
      await updateFileTRNLog(fileTrnData, wfeventId, client);
    await updateEventLogDetails(
      wfeventId,
      client,
      activityStatusForExternalTask,
      log,
    );
  });
};

export const _updateDBForMultipleTool = async (
  wfeventId,
  log,
  fileTrnData,
  activityStatusForExternalTask,
  remarks,
) => {
  await transaction(async client => {
    await updateEventLog(wfeventId, log, client, activityStatusForExternalTask);
    // if (fileTrnData.length) await updateFileTRNLog(fileTrnData, wfeventId, client);
    await updateEventLogDetails(
      wfeventId,
      client,
      activityStatusForExternalTask,
      remarks,
    );
  });
};

export const updateExternalTaskData = async (req, res) => {
  const { wfeventId, taskInstanceId, payload } = req.body;
  try {
    const sql = `UPDATE wms_workflow_eventlog SET taskinstanceid =$1, externaltaskdata = $2 WHERE wfeventid = $3`;
    await query(sql, [taskInstanceId, payload, wfeventId]);
    res.status(200).json({ status: 'Success' });
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getExternalTaskConfig = async (req, res) => {
  const { wfdefid, workorderId, serviceId, duId, wfeventId } = req.body;
  await transaction(async () => {
    const sql = `SELECT * , (select pc_url from public.wms_mst_pkgvalidationsignal where woid =$1   limit 1 ) as pc_url
        FROM public.wms_workflowdefinition where wfdefid =$2`;
    query(sql, [workorderId, wfdefid])
      .then(async data => {
        const resData = await getNotificationConfig(
          { workorderId, serviceId, duId, wfeventId },
          'save',
        );
        res
          .status(200)
          .json({ data, notificationConfig: resData, status: 'Success' });
      })
      .catch(e => {
        res.status(400).send(e.message ? e.message : e);
      });
  });
};

export const getEventFileDeatils = async (req, res) => {
  const { wfeventId } = req.body;
  await transaction(async () => {
    const sql = `SELECT * FROM public.wms_workflowactivitytrn_file_map where wfeventid=$1`;
    query(sql, [wfeventId])
      .then(async data => {
        res.status(200).json({ data, status: 'Success' });
      })
      .catch(e => {
        res.status(400).send(e.message ? e.message : e);
      });
  });
};
export const updateEventDetails = async (req, res) => {
  const {
    wfeventId,
    serviceId,
    stageIterationCount,
    incomingFileId,
    stageId,
    workorderId,
  } = req.body;
  await transaction(async () => {
    let sql = `SELECT * FROM public.wms_previoustask where workorderid = $4 and serviceid = $5 and stageid = $6 and
        stageiterationcount = $1 and woincomingfileid = $2 and wfeventid < $3 ORDER BY wfeventid desc limit 1`;
    query(sql, [
      stageIterationCount,
      incomingFileId,
      wfeventId,
      workorderId,
      serviceId,
      stageId,
    ])
      .then(async response => {
        logger.info('response for previous workflow', response);
        sql = ` UPDATE public.wms_workflow_eventlog SET  activitystatus='Completed' WHERE wfeventid=$1`;
        query(sql, [response[0].wfeventid])
          .then(async () => {
            sql = `INSERT INTO public.wms_workflow_eventlog_details(wfeventid, operationtype, "timestamp")
                       VALUES ($1, 'Completed', current_timestamp);`;
            query(sql, [response[0].wfeventid])
              .then(async () => {
                res.status(200).json({
                  messgae: 'Task Completed Successfully',
                  status: 'Success',
                });
              })
              .catch(e => {
                res.status(400).send(e.message ? e.message : e);
              });
          })
          .catch(e => {
            res.status(400).send(e.message ? e.message : e);
          });
      })
      .catch(e => {
        res.status(400).send(e.message ? e.message : e);
      });
  });
};
