import {
  getWorkflowPlaceHolders,
  getFileInfoDetails,
} from '../../task/fileDetails.js';
import { getFileTrnData, getFilesData } from '../../utils/tools/io.js';
import { getFileTrnDetails } from '../../utils/tools/utils.js';

import logger from '../../utils/logs/index.js';

export const getIOFilesData = async (req, res) => {
  const {
    stage,
    activity,
    service,
    du,
    customer,
    fileId,
    toolsConfig,
    workOrderId,
    wfeventId,
  } = req.body;
  try {
    const fileConfig = {};
    fileConfig.input = toolsConfig.files
      ? toolsConfig.files.filter(x => (x.fileFlowType || []).includes('IN'))
      : [];
    fileConfig.output = toolsConfig.files
      ? toolsConfig.files.filter(x => (x.fileFlowType || []).includes('OUT'))
      : [];
    const placeHolders = await getWorkflowPlaceHolders(wfeventId);
    const workorderDetails = {
      stage,
      activity,
      service,
      du,
      customer,
      workOrderId,
      fileId,
    };
    const fileDetails = await getFileInfoDetails({
      wfEventId: wfeventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId: [],
    });
    res.status(200).json({
      in: await getFilesData({
        workorderDetails,
        IOFiles: fileConfig.input,
        fileDetails,
        placeHolders,
      }),
      out: await getFilesData({
        workorderDetails,
        IOFiles: fileConfig.output,
        fileDetails,
        placeHolders,
      }),
    });
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};

export const getIOFilesTrnData = async (req, res) => {
  const {
    stage,
    activity,
    service,
    du,
    customer,
    fileId,
    toolsConfig,
    workOrderId,
    wfeventId,
  } = req.body;
  try {
    const fileConfig = toolsConfig.files ? toolsConfig.files : {};
    const placeHolders = await getWorkflowPlaceHolders(wfeventId);
    const workorderDetails = {
      stage,
      activity,
      service,
      du,
      customer,
      workOrderId,
      fileId,
    };
    const fileDetails = await getFileInfoDetails({
      wfEventId: wfeventId,
      workOrderId,
      du,
      customer,
      service,
      stage,
      activity,
      typesId: [],
    });
    const files = await getFilesData({
      workorderDetails,
      IOFiles: fileConfig.output,
      fileDetails,
      placeHolders,
      isInputProcessing: false,
    });
    const fileTrnDetails = await getFileTrnDetails(wfeventId);
    const fileTrnData = await getFileTrnData(files, fileTrnDetails);
    res.status(200).json(fileTrnData);
  } catch (e) {
    logger.info(e);
    res.status(400).send(e.message ? e.message : e);
  }
};
