import { query } from '../../../database/postgres.js';
import { completeExternalTaskQueue } from '../task.js';
import { _updateDBForMultipleTool } from '../index.js';
import { _getActivityDetails } from '../../task/index.js';
import {
  getWorkflowPlaceHolders,
  getFileInfoDetails,
} from '../../task/fileDetails.js';
import { getFileTrnData, getFilesData } from '../../utils/tools/io.js';
import { getFileTrnDetails } from '../../utils/tools/utils.js';

import logger from '../../utils/logs/index.js';
import { updateFileTRNLog } from '../updatedb.js';
import {
  _getStageInfoFromCamunda,
  _updateStageInfoToCamunda,
  // _updateActivityStageInfoToCamunda,
} from '../../bpmn/listener/create.js';

export const acknowledge = async (
  wfeventId,
  toolsId,
  data,
  is_success,
  getToolsEntry,
  remarks,
  dmsType,
  isBPCorrection,
) => {
  let filteredArray2 = [];
  let filteredArray3 = [];
  const sql = `select wfeventid, taskinstanceid from public.wms_workflow_eventlog where wfeventid = $1`;
  const eventDataResponse = await query(sql, [wfeventId]);
  const { taskinstanceid } = eventDataResponse[0];
  const activityDetails = await _getActivityDetails(wfeventId);
  const {
    du,
    customer,
    stage,
    activity,
    workOrderId,
    service,
    fileId,
    toolsConfig,
    activityConfig,
  } = activityDetails;
  const config =
    toolsConfig.tools && toolsConfig.tools[toolsId]
      ? toolsConfig.tools[toolsId]
      : {};
  const fileConfig = config.files ? config.files : {};
  const placeHolders = await getWorkflowPlaceHolders(wfeventId);
  const workorderDetails = {
    stage,
    activity,
    service,
    du,
    customer,
    workOrderId,
    fileId,
  };
  const fileDetails = await getFileInfoDetails({
    wfEventId: wfeventId,
    workOrderId,
    du,
    customer,
    service,
    stage,
    activity,
    typesId: [],
  });
  const files = await getFilesData({
    dmsType,
    workorderDetails,
    IOFiles: fileConfig.filter(x => x.fileFlowType.includes('OUT')),
    fileDetails,
    placeHolders,
    isInputProcessing: false,
  });
  const fileTrnDetails = await getFileTrnDetails(wfeventId);
  const fileTrnData = await getFileTrnData(files, fileTrnDetails, dmsType);
  if (fileTrnData.length) await updateFileTRNLog(fileTrnData, wfeventId);
  // await _updateDb(wfeventId, null, fileTrnData);
  let isSuccess;
  let filteredArray1 = [];
  if (Array.isArray(activityDetails.toolsId)) {
    const filteredArray = getToolsEntry.filter(
      list => list.status == 'Success',
    );
    filteredArray1 = getToolsEntry.filter(
      list => list.status == 'Success' || list.status == 'Failure',
    );
    // filteredArray2 = getToolsEntry.filter(
    //   list =>
    //     list.status == 'Success' &&
    //     (list.isfileavailable == false || list.isfileavailable == true),
    // );
    filteredArray2 = getToolsEntry.filter(
      list =>
        (list.status == 'Success' || list.status == 'Failure') &&
        list.isfileavailable == true,
    );
    filteredArray3 = getToolsEntry.filter(
      list => list.isfileavailable == false,
    );

    if (
      filteredArray &&
      filteredArray.length > 0 &&
      filteredArray.length == activityDetails.toolsId.length
    ) {
      isSuccess = true;
    } else if (
      filteredArray2 &&
      filteredArray2.length > 0 &&
      filteredArray2.length == activityDetails.toolsId.length
    ) {
      // } else if (filteredArray2.length > 0) {
      isSuccess = true;
    } else {
      isSuccess = false;
    }
  } else {
    isSuccess = is_success;
  }
  logger.info(isSuccess, 'isSuccess variable');
  const activityStatusForExternalTask = isSuccess ? 'Completed' : 'Failed';
  const externalTask = getServiceToUserTaskVariables(isSuccess);
  const camundaPayload = {
    workerId: 'System',
  };
  logger.info(externalTask, 'externalTaskexternalTask');

  const externalvariable = {};
  externalvariable.__isSuccess__ = externalTask.__isSuccess__;
  logger.info(externalvariable, 'variable external');

  // if (
  //   activityConfig &&
  //   Object.keys(activityConfig).includes('skipActivity') &&
  //   activityConfig.skipActivity.enable &&
  //   activityConfig.skipActivity.toolId == toolsId
  // )
  if (
    activityConfig &&
    Object.keys(activityConfig).includes('skipActivity') &&
    activityConfig.skipActivity.enable
  ) {
    const getStageInfo = await _getStageInfoFromCamunda(workOrderId);
    const stageInfo = JSON.parse(getStageInfo.__stageInfo.data.value);
    const fileObj = stageInfo.files;
    if (fileObj && fileObj.length > 0) {
      fileObj.forEach(cal => {
        if (cal.id == fileId) {
          cal.isBPCorrection = isBPCorrection || false;
        }
      });
      console.log(fileObj);
      stageInfo.files = fileObj;
    }
    // let sql = `SELECT taskinstanceid FROM public.wms_workflow_eventlog where wfeventid=$1`;
    // const taskInstanceId = await query(sql, [wfeventId]);
    await _updateStageInfoToCamunda(stageInfo, getStageInfo.processInstanceId);
    // if(taskInstanceId && taskInstanceId.length >0){
    //     await _updateActivityStageInfoToCamunda(fileObj, taskInstanceId[0].taskinstanceid)
    // }
    // _updateActivityStageInfoToCamunda;
    const payload = {
      type: 'Json',
      value: JSON.stringify(stageInfo),
      valueInfo: {},
    };
    externalvariable.__stageInfo__ = payload;
    if (isBPCorrection != undefined) {
      externalvariable.__isEngineSuccess__ = {
        type: 'Boolean',
        value: isBPCorrection,
      };
    }
  }
  camundaPayload.variables = externalvariable;

  logger.info(camundaPayload, 'camundaPayload variable');
  if (Array.isArray(activityDetails.toolsId) && filteredArray3.length == 0) {
    logger.info(activityDetails.toolsId, 'activityDetails toolsId');
    if (
      filteredArray1.length == activityDetails.toolsId.length ||
      filteredArray1.length >= activityDetails.toolsId.length
    ) {
      logger.info(wfeventId, 'variable');
      if (
        getToolsEntry &&
        getToolsEntry.length > 0 &&
        getToolsEntry[0].activitytype == 'External Task'
      ) {
        await _updateDBForMultipleTool(
          wfeventId,
          null,
          fileTrnData,
          activityStatusForExternalTask,
          remarks,
        );
      }
      logger.info('camunda payload updated');
      await completeExternalTaskQueue(taskinstanceid, camundaPayload);
      logger.info('external task completed');
      logger.info(`completed external task ${wfeventId}`);
    }
  } else if (
    filteredArray3.length > 0 &&
    getToolsEntry[0].activitytype == 'External Task'
  ) {
    await _updateDBForMultipleTool(
      wfeventId,
      null,
      fileTrnData,
      activityStatusForExternalTask,
      remarks,
    );
    await completeExternalTaskQueue(taskinstanceid, camundaPayload);
  } else {
    if (
      getToolsEntry &&
      getToolsEntry.length > 0 &&
      getToolsEntry[0].activitytype == 'External Task'
    ) {
      await _updateDBForMultipleTool(
        wfeventId,
        null,
        fileTrnData,
        activityStatusForExternalTask,
        remarks,
      );
    }
    await completeExternalTaskQueue(taskinstanceid, camundaPayload);
    logger.info(`completed external task ${wfeventId}`);
  }
};

export const getServiceToUserTaskVariables = isSuccess => {
  return {
    __isSuccess__: {
      type: 'Boolean',
      value: isSuccess,
    },
  };
};
