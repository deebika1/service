export const JobInfoTemplates = {
  ul: `{{li}}`,
  li: `<JobInfo>
    <FieldName>{{fieldName}}</FieldName>
    <Value>{{value}}</Value>
    </JobInfo>
    `,
};
