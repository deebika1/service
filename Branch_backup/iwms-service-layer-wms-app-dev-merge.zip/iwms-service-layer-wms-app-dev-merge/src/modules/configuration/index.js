import * as requestIp from 'request-ip';
import { transaction, query } from '../../database/postgres.js';
import logger from '../utils/logs/index.js';
import { getsftpConfig } from '../filetransferkit/index.js';
import { _upload } from '../utils/azure/index.js';
import { ReStructureFileConfig } from '../utils/fileValidation/validate.js';

export const getftpConfig = async (req, res) => {
  try {
    const { key } = req.query;
    const out = await getsftpConfig(key);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getauditForXmlReader = async (req, res) => {
  try {
    const sql = `select * from public.ftp_audit_wo_creation 
                  where isactive = true 
                  and duname = '${req.query.duname}'
                  and createdon::date BETWEEN current_date - interval '2 day' AND current_date`;
    const out = await query(sql);
    res.status(200).send(out);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const auditForXmlReader = async (req, res) => {
  try {
    let { auditid } = req.body;
    const {
      inputjson,
      remark,
      issuccess,
      duname,
      stagename,
      articlename,
      ftpfilename,
      journalname,
      ftpfilepath,
      stageiterationcount,
      tempPath,
      statusid,
    } = req.body;
    let uploadpath = '';
    if (req.files && req.files.zip) {
      const out = await _upload(req.files.zip, tempPath);
      uploadpath = out.fullPath;
    }
    let sql = '';
    if (auditid === undefined) {
      sql = `INSERT INTO public.ftp_audit_wo_creation(
      inputjson, duname, stagename, articlename, ftpfilename, ftpfilepath, remark, issuccess,uploadpath,journalcode, stageiterationcount, statusid)
     VALUES ('${inputjson}','${duname}','${stagename}','${articlename}','${ftpfilename}','${ftpfilepath}','${remark}',${issuccess},'${uploadpath}','${journalname}',${stageiterationcount},${statusid}) RETURNING auditid`;
    } else {
      sql = `update public.ftp_audit_wo_creation set remark = '${remark}', issuccess = ${issuccess}, statusid = ${statusid} where auditid = ${auditid} RETURNING auditid`;
    }
    auditid = await query(sql);
    res.status(200).send(auditid[0].auditid);
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// to get the details for activity configuration
export const ActivityConfigDetails = (req, res) => {
  const reqData = req.body;
  logger.info(reqData, 'reqData');
  console.log(reqData, 'stagereqData');
  let sql = '';
  if (reqData.type == 'stage') {
    sql = `SELECT   DISTINCT stage.stageid as value , stage.stagename as label  FROM wms_workflowdefinition as workflow 
        left JOIN public.wms_mst_stage as stage ON workflow.stageid=stage.stageid
          where wfid=${reqData.workflowID}`;
  } else if (reqData.type == 'all') {
    logger.info('allllllllllll');
    sql = `SELECT * FROM wms_workflowdefinition as  workflow
        left JOIN public.wms_mst_skill as skill ON workflow.skillid=skill.skillid 
        where wfid=${reqData.workflowID} AND stageid=${reqData.stageID} AND activityid=${reqData.activityID} `;
  } else if (reqData.type == 'stageForActivity') {
    sql = `SELECT  DISTINCT activity.activityid as value , activity.activityname as label  FROM wms_workflowdefinition as workflow
        left JOIN public.wms_mst_activity as activity ON workflow.activityid=activity.activityid
        where wfid=${reqData.workflowID} AND stageid=${reqData.stageID}`;
  }
  logger.info(sql, 'sqlsql');
  query(sql)
    .then(response => {
      // updated for fileconfig restructure
      response.forEach(item => {
        item.fileconfig = ReStructureFileConfig(item.fileconfig);
      });
      logger.info('responsesss', response);
      console.log('resforstage', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateForActConfig = (req, res) => {
  const reqData = req.body;
  global.log(reqData, 'reqDataforUpdate');
  console.log(reqData, 'reqDataforUpdate');
  const updatedData = JSON.stringify(reqData.update);
  const toolconficData = JSON.stringify(reqData.toolsConfig);
  // const toolData= JSON.stringify(reqData.toolsconfig.toolsConficUpdate)
  // console.log("toolData",toolData)
  global.log(toolconficData, 'toolconficData');
  console.log(toolconficData, 'toolconficData');
  const sql = `UPDATE public.wms_workflowdefinition
	SET   config =$1,toolsconfig =$2
	WHERE wfid =${reqData.workflowID} and stageid =${reqData.stageID} and activityid=${reqData.activityID}`;
  query(sql, [updatedData, toolconficData])
    .then(response => {
      res.status(200).json({
        data: response,
        message: `Data Updated Sucessfully for this workflowId ${reqData.workflowID} for stageid ${reqData.stageID} and activityid ${reqData.activityID} `,
      });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// software config module start
export const softwareDetails = (req, res) => {
  const sql = `SELECT appname as label, appid as value, * FROM public.wms_mst_software WHERE isactive=true ORDER BY appid ASC`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const softwareIOList = async (req, res) => {
  try {
    const { wfId, stageId, activityId } = req.body;
    const sql = `select softwareconfig from public.wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

// adding tools I/O details
export const softwareIOAdd = async (req, res) => {
  try {
    await transaction(async client => {
      const {
        wfId,
        stageId,
        activityId,
        formData,
        type,
        form,
        softwareId,
        userId,
      } = req.body;
      let sql = '';
      const softwareconfigVal = formData
        ? `'${JSON.stringify(formData)}'`
        : null;

      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...JSON.parse(req.headers.systemdetail),
      };
      // insert autit log
      sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
        wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
        ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('toolsconfig', toolsconfig) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}
      )::JSON as sourcedata, '${userId}' as updatedby, current_timestamp, '${type}', '${JSON.stringify(
        systemInfo,
      )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
      await client.query(sql);
      // get the config from wms_workflowdefinition table
      sql = `SELECT config FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
      const { rows } = await client.query(sql);
      const { config } = rows[0];
      // update the config
      const updatedConfig = { ...config, softwareId };
      if (Object.keys(updatedConfig).length) {
        // replace the single quote with double quote
        if (
          'actions' in config &&
          'workflow' in config.actions &&
          Object.keys(config.actions.workflow).length
        ) {
          Object.keys(updatedConfig.actions.workflow).forEach(keyName => {
            if (
              'emailConfig' in
                updatedConfig.actions.workflow[keyName].capture &&
              updatedConfig.actions.workflow[keyName].capture.emailConfig
                .template
            ) {
              updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template = updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template.replace(/'/g, "''");
            }
          });
        }
      }

      sql = `UPDATE public.wms_workflowdefinition
        SET config='${JSON.stringify(updatedConfig)}', 
        softwareconfig=${softwareconfigVal}
        WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
      await client.query(sql);
      let msg = '';
      if (type === 'Add') {
        msg = `Workflow activity ${form} config added sucessfully`;
      } else if (type === 'Update') {
        msg = `Workflow activity ${form} config updated sucessfully`;
      } else if (type === 'Delete') {
        msg = `Workflow activity ${form} config deleted sucessfully`;
      }
      res.status(200).json({
        message: msg,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const ActConfigDetails = async req => {
  return new Promise((resolve, reject) => {
    const reqData = req.body;

    console.log(reqData, 'reqDatafortool');
    const sql = `select * from wms_workflowdefinition
        WHERE wfid =${reqData.workflowID} and stageid =${reqData.stageID} and activityid=${reqData.activityID}`;
    query(sql)
      .then(response => {
        // updated for fileconfig restructure
        response.forEach(item => {
          item.fileconfig = ReStructureFileConfig(item.fileconfig);
        });
        resolve({ data: response });
      })
      .catch(error => {
        reject({ message: error });
      });
  });
};
// tools config module start
export const ToolsConfigDetails = (req, res) => {
  ActConfigDetails.then(response => {
    res.status(200).json({ data: response });
  }).catch(error => {
    res.status(400).send({ message: error });
  });
};

export const toolDetails = (req, res) => {
  const sql = `SELECT toolname as label, toolid as value FROM public.pp_mst_tool WHERE toolstatus=true ORDER BY toolid ASC`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
// get the tool I/O details
export const toolIOList = async (req, res) => {
  try {
    const { wfId, stageId, activityId } = req.body;
    const sql = `select toolsconfig, wfdefid from public.wms_workflowdefinition where wfid=${wfId} 
    and stageid=${stageId} and activityid=${activityId}`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};
// get the tool params suggestions
export const toolParamsSuggestions = (req, res) => {
  const sql = `SELECT toolparamsugges as label, toolparamsugges as value, description FROM public.pp_mst_tool_param_suggestions WHERE isactive=true ORDER BY toolparamsuggesid ASC`;
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// adding tools I/O details
export const toolsIOAdd = async (req, res) => {
  try {
    await transaction(async client => {
      const {
        wfId,
        stageId,
        activityId,
        formData,
        type,
        form,
        toolsId,
        userId,
        onSaveToolsId,
      } = req.body;
      let sql = '';
      const toolsconfigVal = formData ? `'${JSON.stringify(formData)}'` : null;
      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...JSON.parse(req.headers.systemdetail),
      };
      // insert autit log
      sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
        wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
        ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('toolsconfig', toolsconfig) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}
      )::JSON as sourcedata, '${userId}' as updatedby, current_timestamp, '${type}', '${JSON.stringify(
        systemInfo,
      )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
      await client.query(sql);
      // get the config from wms_workflowdefinition table
      sql = `SELECT config FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
      const { rows } = await client.query(sql);
      const { config } = rows[0];
      // update the config
      const updatedConfig = {
        ...config,
        toolsId: [...toolsId],
        onSaveToolsId: [...onSaveToolsId],
      };
      // if (toolType === 'activity') {
      //   updatedConfig = { ...config, toolsId: [...toolsId] };
      // } else if (toolType === 'onSave') {
      //   updatedConfig = {
      //     ...config,
      //     onSaveToolsId: [...onSaveToolsId],
      //   };
      // } else if (toolType === 'both') {
      //   updatedConfig = {
      //     ...config,
      //     toolsId: [...toolsId],
      //     onSaveToolsId: [...onSaveToolsId],
      //   };
      // }
      if (Object.keys(updatedConfig).length) {
        // replace the single quote with double quote
        if (
          'actions' in config &&
          'workflow' in config.actions &&
          Object.keys(config.actions.workflow).length
        ) {
          Object.keys(updatedConfig.actions.workflow).forEach(keyName => {
            if (
              'emailConfig' in
                updatedConfig.actions.workflow[keyName].capture &&
              updatedConfig.actions.workflow[keyName].capture.emailConfig
                .template
            ) {
              updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template = updatedConfig.actions.workflow[
                keyName
              ].capture.emailConfig.template.replace(/'/g, "''");
            }
          });
        }

        const configVal = `'${JSON.stringify(updatedConfig)}'`;

        sql = `UPDATE public.wms_workflowdefinition
        SET config=${configVal}, 
        toolsconfig=${toolsconfigVal}
        WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
        await client.query(sql);
      }

      let msg = '';
      if (type === 'Add') {
        msg = `Workflow activity ${form} config added sucessfully`;
      } else if (type === 'Update') {
        msg = `Workflow activity ${form} config updated sucessfully`;
      } else if (type === 'Delete') {
        msg = `Workflow activity ${form} config deleted sucessfully`;
      }
      res.status(200).json({
        message: msg,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const OptionList = async (req, res) => {
  const { type, wfId, stageId, activityId } = req.body;
  let sql = '';
  if (type === 'allStages') {
    sql = `SELECT stageid as value, stagename as label from wms_mst_stage
        ORDER BY stageid ASC `;
  } else if (type === 'wfStageFilter') {
    sql = `SELECT stageid as value, stagename as label from wms_mst_stage where stageid in (select stageid from public.wms_workflowdefinition where wfid=${wfId})
        ORDER BY stageid ASC `;
  } else if (type === 'activity') {
    sql = `SELECT activityid as value , activityname as label FROM wms_mst_activity
         WHERE activityid NOT IN (select activityid from public.wms_workflowdefinition where wfid=${wfId}) ORDER BY activityid ASC`;
  } else if (type === 'wfActivityFilter') {
    sql = `SELECT activityid as value , activityname as label FROM wms_mst_activity
         WHERE activityid NOT IN (select activityid from public.wms_workflowdefinition where wfid=${wfId}) ORDER BY activityid ASC`;
  } else if (type === 'skill') {
    sql = `SELECT skillid as value , skillname as label FROM public.wms_mst_skill ORDER BY skillid ASC `;
  } else if (type === 'wfFiletypeFilter') {
    // need to update
    sql = `SELECT fileconfig FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}`;
    const filetypeDtl = await query(sql);
    let fileTypes = [];
    for (const fileConfig of filetypeDtl) {
      fileConfig.files.forEach(x => {
        fileTypes = [...new Set([...fileTypes, ...(x.fileTypes || [])])];
      });
    }
    sql = `SELECT filetype as label, filetypeid as value  FROM public.pp_mst_filetype where filetypeid NOT IN (
                    ${fileTypes.join(',')}
                )
                ORDER BY filetypeid ASC`;
  } else if (type === 'wfFiletype') {
    //   sql = `SELECT filetype as label, filetypeid as value  FROM public.pp_mst_filetype where filetypeid NOT IN (
    //     SELECT json_object_keys(fileconfig::json -> 'fileTypes')::bigint
    //     as filtetypeid FROM wms_workflowdefinition WHERE wfid=${wfId} AND stageid=${stageId} AND activityid=${activityId}
    // )
    // ORDER BY filetypeid ASC`;

    sql = `SELECT filetype as label, filetypeid as value  FROM public.pp_mst_filetype`;
  } else if (type === 'flowType') {
    sql = `SELECT flowtype as value , flowtype as label FROM public.pp_mst_flowtype where isactive=true`;
  } else if (type === 'wfFileExtention') {
    sql = `SELECT fileextention as value , fileextention as label FROM pp_mst_fileextention WHERE isactive=true`;
    // sql = `with cte as (
    //   SELECT DISTINCT ON (label)
    //           CASE
    //               WHEN position('.' IN reverse(source)) > 0
    //               THEN reverse(substring(reverse(source) FROM 1 FOR position('.' IN reverse(source))-1 ))
    //               ELSE ''
    //           END AS label,
    //         CASE
    //               WHEN position('.' IN reverse(source)) > 0
    //               THEN reverse(substring(reverse(source) FROM 1 FOR position('.' IN reverse(source))-1 ))
    //               ELSE ''
    //           END AS value
    //       FROM wms_filemovementconfig) select label, value from cte where value !=''`;
  } else if (type === 'getCustomTagList') {
    sql = `SELECT custom as value, custom as label, description FROM public.pp_mst_custom_tags`;
  }

  logger.info(sql, 'sql for options');
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWFStageDetails = (req, res) => {
  const { type, stageId, wfId } = req.body;
  let sql = '';
  if (type === 'wfStages') {
    sql = `select t1.*, (
      select JSON_AGG(t2.*) from wms_workflow_nextstage_map as t2 where t2.wfstageconfigid= t1.wfstageconfigid) as nextstageconfig 
      from wms_workflow_stageconfig as t1 where wfid=${wfId} and stageid=${stageId}`;
  } else if (type === 'allWFStages') {
    sql = `select  STRING_TO_ARRAY('', '') as activity,
      min(wms_workflowdefinition.sequence) seq ,st.stageid, st.stagename
      from wms_workflowdefinition 
      join wms_mst_stage as st on st.stageid = wms_workflowdefinition.stageid
      where wfid=${wfId} group by st.stageid, st.stagename order by seq asc`;
  }

  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getWFActivityDetails = (req, res) => {
  const { type, wfId, stageId, activityId } = req.body;
  let sql = '';
  if (type === 'allWFActivity') {
    sql = `SELECT concat(activityalias, ' -> ', stagename) as label, wfdefid as value FROM wms_workflowdefinition
        join wms_mst_stage on wms_mst_stage.stageid = wms_workflowdefinition.stageid
        WHERE wfid=${wfId} ORDER BY sequence ASC`;
  } else if (type === 'WFStageActivity') {
    sql = `SELECT * FROM wms_workflowdefinition 
        JOIN wms_mst_activity ON wms_mst_activity.activityid = wms_workflowdefinition.activityid
        WHERE wfid=${wfId} AND stageid=${stageId} ORDER BY sequence ASC`;
  } else if (type === 'wfActivity') {
    sql = ` SELECT * FROM wms_workflowdefinition  WHERE wfid=${wfId} AND stageid=${stageId} and activityid=${activityId} `;
    // sql = ` SELECT * FROM wms_workflowdefinition as ws
    //     LEFT JOIN wms_mst_activity as act on act.activityid = ws.activityid
    //     JOIN (SELECT wfid, json_build_object('value',act.activityid,'label',act.activityname) as skillid
    //     FROM wms_workflowdefinition as ws
    //     LEFT JOIN wms_mst_activity as act on act.activityid = ws.activityid
    //     WHERE wfid=${wfId} AND ws.stageid=${stageId} and ws.activityid=${activityId}
    //     group by ws.wfid, act.activityid) AS sub ON sub.wfid = ws.wfid
    //     WHERE ws.wfid=${wfId} AND ws.stageid=${stageId} and ws.activityid=${activityId}`;
  }
  logger.info(sql, 'sqllll');
  query(sql)
    .then(response => {
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

// this function will add / update wf stage details
export const saveWFStage = async (req, res) => {
  try {
    const { type, wfId, stageId, stageForm, userId } = req.body;
    logger.info(type, 'req.body');
    await transaction(async client => {
      let sql = `INSERT INTO public.wms_workflow_stageconfig_audit(wfid, stageid, iterationcount, stageconfig, nextstageconfig, updatedby, updatedon)
      select wfid, stageid, iterationcount,
        (select JSON_AGG(t3.*) from wms_workflow_stageconfig as t3 where t3.wfstageconfigid= t1.wfstageconfigid) as stageconfig
        , (select JSON_AGG(t2.*) from wms_workflow_nextstage_map as t2 where t2.wfstageconfigid= t1.wfstageconfigid) as nextstageconfig,
          '${userId}' as updatedby, now() as updatedon
            from wms_workflow_stageconfig as t1 where wfid=${wfId} and stageid=${stageId} `;
      await client.query(sql);
      sql = `DELETE FROM public.wms_workflow_nextstage_map WHERE wfstageconfigid IN (SELECT wfstageconfigid FROM public.wms_workflow_stageconfig WHERE wfid=${wfId} AND stageid=${stageId})`;
      await client.query(sql);
      sql = `DELETE FROM public.wms_workflow_stageconfig WHERE wfid=${wfId} AND stageid=${stageId} RETURNING wfstageconfigid;`;
      await client.query(sql);
      for (let i = 0; i < stageForm.length; i++) {
        const wfConfigId = await insertWfStageConfig(
          client,
          wfId,
          stageId,
          stageForm[i],
        );
        if (stageForm[i].nextStageConfig.length) {
          for (let j = 0; j < stageForm[i].nextStageConfig.length; j++) {
            await insertWfNextStageConfig(
              client,
              wfConfigId,
              stageForm[i].nextStageConfig[j],
            );
          }
        }
      }
    });

    logger.info('sql for update');
    res.status(200).json({
      message: `Wokflow stage configuration ${
        type === 'add' ? 'added' : 'updated'
      } sucessfully`,
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

const insertWfStageConfig = async (client, wfId, stageId, item) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `INSERT INTO public.wms_workflow_stageconfig(wfid, stageid, isiteration, iterationcount, enableisbnupdate, aliasname)
      VALUES (${wfId}, ${stageId}, ${item.isIteration}, ${item.iterationCount}, ${item.enableISBN}, '${item.stageAliasName}') RETURNING wfstageconfigid;`;
      const { rows } = await client.query(sql);
      const { wfstageconfigid } = rows[0];
      resolve(wfstageconfigid);
    } catch (error) {
      reject(error);
    }
  });
};

const insertWfNextStageConfig = async (client, wfstageconfigid, item) => {
  return new Promise(async (resolve, reject) => {
    try {
      const sql = `INSERT INTO public.wms_workflow_nextstage_map(wfstageconfigid, nextstageid, submittype, flowtype)
      VALUES (${wfstageconfigid}, ${item.nextStages}, 3, '${item.flowType}') RETURNING nextstagemapid;`;
      const { rows } = await client.query(sql);
      const { nextstagemapid } = rows[0];
      resolve(nextstagemapid);
    } catch (error) {
      reject(error);
    }
  });
};

export const saveWFActivity = async (req, res) => {
  try {
    const {
      form,
      type,
      action,
      formData,
      wfId,
      stageId,
      activityId,
      wfdefId,
      userId,
    } = req.body;
    logger.info(wfId, stageId, activityId);
    await transaction(async client => {
      let sql = '';
      const systemInfo = {
        systemIP: requestIp.getClientIp(req),
        publicIP:
          req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        ...JSON.parse(req.headers.systemdetail),
      };
      logger.info(systemInfo, 'systemInfo');
      if (form === 'general') {
        sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
          wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
          ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('wfid', wfid, 'stageid', stageid,'activityid', activityid, 'sequence',sequence, 'activitytype',activitytype, 'instancetype',instancetype, 'skillid',skillid, 'config',config, 'activityalias',activityalias, 'itracksconfig',itracksconfig,
        'lock',lock, 'toolrunningstatus',toolrunningstatus, 'enablefilestatusreport',enablefilestatusreport, 'enableautostagetrnsf' ,enableautostagetrnsf) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId})::JSON as sourcedata
        , '${userId}' as updatedby, current_timestamp, '${action}',
        '${JSON.stringify(
          systemInfo,
        )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
        await client.query(sql);
        const {
          wfdefid,
          wfid,
          stageid,
          activityid,
          activitytype,
          instancetype,
          skillid,
          config,
          activityalias,
          itracksconfig,
          enablefilestatusreport,
          enableautostagetrnsf,
          isactive,
        } = formData;

        // extract the values from the array of objects
        if (config.preActivity.length) {
          config.preActivity = config.preActivity.map(item => item.value);
        }
        if (config.postActivity.length) {
          config.postActivity = config.postActivity.map(item => item.value);
        }
        if (config.newFileTypes.length) {
          config.newFileTypes = config.newFileTypes.map(item => item.value);
        }
        if (config.newFileTypesExt.length) {
          config.newFileTypesExt = config.newFileTypesExt.map(
            item => item.value,
          );
        }
        if (config.graphicFileFormat.length) {
          config.graphicFileFormat = config.graphicFileFormat.map(
            item => item.value,
          );
        }
        if (config.fileCombination.length) {
          config.fileCombination = config.fileCombination.map(
            item => item.value,
          );
        }
        if (config.allowedFileExtension.length) {
          config.allowedFileExtension = config.allowedFileExtension.map(
            item => item.value,
          );
        }
        if (config.skipFileExtension.length) {
          config.skipFileExtension = config.skipFileExtension.map(
            item => item.value,
          );
        }
        // replace the single quote with double quote
        if (
          'actions' in config &&
          'workflow' in config.actions &&
          Object.keys(config.actions.workflow).length
        ) {
          Object.keys(config.actions.workflow).forEach(keyName => {
            if (
              'emailConfig' in config.actions.workflow[keyName].capture &&
              config.actions.workflow[keyName].capture.emailConfig.template
            ) {
              config.actions.workflow[keyName].capture.emailConfig.template =
                config.actions.workflow[
                  keyName
                ].capture.emailConfig.template.replace(/'/g, "''");
            }
          });
        }

        const configVal = config ? `'${JSON.stringify(config)}'` : null;
        const itracksconfigVal = itracksconfig
          ? `'${JSON.stringify(itracksconfig)}'`
          : null;
        // eslint-disable-next-line no-unneeded-ternary
        const lock = isactive === 'true' || isactive === true ? false : true;
        sql = `
          UPDATE public.wms_workflowdefinition
          SET wfid=${wfid}, stageid=${stageid}, activityid=${activityid}, activitytype='${activitytype}', instancetype='${instancetype}',
          skillid=${skillid}, config=${configVal}, activityalias='${activityalias}', 
          lock=${lock},
          itracksconfig=${itracksconfigVal}, enablefilestatusreport=${enablefilestatusreport}, enableautostagetrnsf=${enableautostagetrnsf}
          WHERE wfdefid=${wfdefid}`;
      } else if (form === 'file') {
        sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
          wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
          ( select wfid, stageid,activityid, '${form}' as formtype, (select json_build_object('fileconfig', fileconfig) from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId}
        )::JSON as sourcedata, '${userId}' as updatedby, current_timestamp, '${action}', '${JSON.stringify(
          systemInfo,
        )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
        await client.query(sql);
        const fileconfigVal = formData ? `'${JSON.stringify(formData)}'` : null;
        sql = ` UPDATE public.wms_workflowdefinition SET fileconfig=${fileconfigVal} WHERE wfId=${wfId} AND wfdefid=${wfdefId}`;
      } else if (form === 'filetransfer') {
        const {
          flowFrom,
          file,
          fromActivity,
          copyWithNewName,
          copyFromCommonPath,
          fromFileType,
          toFileType,
          isIncomingSrc,
          isTemplateSrc,
          filePriority,
          toActivity,
          fmconfigid,
        } = formData;
        const flowFromAct =
          flowFrom && flowFrom.length ? flowFrom.join(',') : '';

        if (type === 'Update') {
          sql = `UPDATE public.wms_filemovementconfig
          SET flowfrom='{${flowFromAct}}', flowto=${toActivity}, filesrcactivity=${fromActivity}, source='${file}', destination='${copyWithNewName}', commonfolderpath='${copyFromCommonPath}', srcfiletypeid=${fromFileType}, destfiletypeid=${toFileType}, 
          isincomingsrc=${isIncomingSrc}, istemplatesrc=${isTemplateSrc}
          WHERE fmconfigid=${fmconfigid}`;
        } else {
          sql = `INSERT INTO public.wms_filemovementconfig(
            flowfrom, flowto, filesrcactivity, source, destination, commonfolderpath, srcfiletypeid, destfiletypeid, isincomingsrc, istemplatesrc, filepriority)
          VALUES ('{${flowFromAct}}', ${toActivity}, 
          ${fromActivity || null}, 
          '${file}', '${copyWithNewName}', '${copyFromCommonPath}',
          ${fromFileType || null},
          ${toFileType || null},
          ${isIncomingSrc},${isTemplateSrc},${filePriority});`;
        }
        await client.query(sql);

        const sqlINF = `SELECT MAX(array_length(flowfrom, 1)) AS max_length, flowfrom
        FROM wms_filemovementconfig
        WHERE flowto = ${toActivity}
        GROUP BY flowfrom ORDER BY max_length DESC LIMIT 1`;

        const {
          rows: [{ flowfrom: fFrom }],
        } = await client.query(sqlINF);
        logger.info(fFrom, 'resOfIncomingFlows');
        const inFlow = fFrom ? fFrom.join(',') : '';
        sql = `UPDATE public.wms_workflowdefinition
        SET incomingflows='{${inFlow}}' WHERE wfdefid=${toActivity} `;
      }
      logger.info(sql, 'sql for update');
      await client.query(sql);
      let msg = '';
      if (form === 'general') {
        msg = 'Workflow activity general info updated sucessfully';
      } else if (form === 'file') {
        if (type === 'Add') {
          msg = 'Workflow activity file I/O config added sucessfully';
        } else if (type === 'Update') {
          msg = 'Workflow activity file I/O config updated sucessfully';
        } else if (type === 'Delete') {
          msg = 'Workflow activity file I/O config deleted sucessfully';
        }
      } else if (form === 'filetransfer') {
        if (type === 'Update') {
          msg = 'Workflow activity file transfer config updated sucessfully';
        } else {
          msg = 'Workflow activity file transfer config added sucessfully';
        }
      }
      res.status(200).json({
        message: msg,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const saveWFActivityOld = async (req, res) => {
  const {
    type,
    wfdefid,
    wfid,
    stageid,
    activityid,
    activitytype,
    instancetype,
    formjson,
    skillid,
    config,
    fileconfig,
    activityalias,
    incomingflows,
    toolsconfig,
    itracksconfig,
    softwareconfig,
    toolrunningstatus,
    rejectedactivitytype,
    activitymodeltype,
    activitymodeltypeflow,
    enablefilestatusreport,
    resettoactivityid,
  } = req.body;

  const formjsonVal = formjson ? `'${JSON.stringify(formjson)}'` : null;
  const configVal = config ? `'${JSON.stringify(config)}'` : null;
  const fileconfigVal = fileconfig ? `'${JSON.stringify(fileconfig)}'` : null;
  const incomingflowsVal = incomingflows
    ? `'${JSON.stringify(incomingflows)}'`
    : null;
  const toolsconfigVal = toolsconfig
    ? `'${JSON.stringify(toolsconfig)}'`
    : null;
  const itracksconfigVal = itracksconfig
    ? `'${JSON.stringify(itracksconfig)}'`
    : null;
  const softwareconfigVal = softwareconfig
    ? `'${JSON.stringify(softwareconfig)}'`
    : null;
  const skillidVal = skillid ? skillid.value : null;

  try {
    await transaction(async client => {
      let sql = '';
      if (type === 'add') {
        sql = `SELECT sequence FROM wms_workflowdefinition WHERE wfid =${wfid} AND stageid=${stageid} `;
        const { rows } = await client.query(sql);
        logger.info(rows, 'seqseqseq');
        const seq = rows.length + 1;
        sql = `INSERT INTO public.wms_workflowdefinition(
                        wfid, stageid, activityid, sequence, activitytype, instancetype, formjson, skillid, config, fileconfig, activityalias, incomingflows, toolsconfig, itracksconfig, softwareconfig, lock, toolrunningstatus, rejectedactivitytype, activitymodeltype, activitymodeltypeflow, enablefilestatusreport, resettoactivityid)
                VALUES (${wfid}, ${stageid}, ${activityid}, ${seq}, '${activitytype}', '${instancetype}', 
                ${formjsonVal}, ${skillidVal}, ${configVal},${fileconfigVal}, '${activityalias}',
                ${incomingflowsVal}, ${toolsconfigVal}, ${itracksconfigVal}, ${softwareconfigVal}, false, 
                ${toolrunningstatus}, '${rejectedactivitytype}', '${activitymodeltype}', '${activitymodeltypeflow}', ${enablefilestatusreport}, '${resettoactivityid}')`;
      } else {
        sql = `
                UPDATE public.wms_workflowdefinition
                SET wfid=${wfid}, stageid=${stageid}, activityid=${activityid}, activitytype='${activitytype}', instancetype='${instancetype}',
                formjson=${formjsonVal}, skillid=${skillidVal}, config=${configVal}, fileconfig=${fileconfigVal}, activityalias='${activityalias}', 
                incomingflows=${incomingflowsVal}, toolsconfig=${toolsconfigVal}, itracksconfig=${itracksconfigVal},
                softwareconfig=${softwareconfigVal}, toolrunningstatus=${toolrunningstatus}, rejectedactivitytype='${rejectedactivitytype}',
                activitymodeltype='${activitymodeltype}', activitymodeltypeflow='${activitymodeltypeflow}', enablefilestatusreport=${enablefilestatusreport},
                resettoactivityid='${resettoactivityid}'
                WHERE wfdefid=${wfdefid}`;
      }
      logger.info(sql, 'sql for update');
      await client.query(sql);
      res.status(200).json({
        message: `Workflow activity ${
          type === 'add' ? 'added' : 'updated'
        } sucessfully`,
      });
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getFilenameSuggestions = async (req, res) => {
  try {
    const { value, type } = req.body;
    let condition = ``;
    if (type === 'Search' && value) {
      condition = `WHERE source LIKE '${value}%'`;
    } else {
      condition = `WHERE source !=''`;
    }
    const sql = `SELECT distinct on (source) source as label, source as value FROM wms_filemovementconfig ${
      condition || ''
    } `;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getExistingFiles = async (req, res) => {
  try {
    const { wfId, stageId, activityId } = req.body;
    const sql = `select (fileconfig ->> 'files')::json as existingfiles, wfdefid from public.wms_workflowdefinition where wfid=${wfId} 
    and stageid=${stageId} and activityid=${activityId}`;
    const response = await query(sql);
    res
      .status(200)
      .json({ data: response.length ? response[0].existingfiles : [] });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getFileTransferList = async (req, res) => {
  try {
    const { wfdefId } = req.body;
    const sql = `SELECT * FROM public.wms_filemovementconfig WHERE flowto=${wfdefId}`;
    //   const sql = `select
    //   (SELECT coalesce(string_agg(activityalias, ', '), 'NA')  AS flowfromname
    //   FROM wms_workflowdefinition WHERE wfdefid in ( SELECT unnest(flowfrom::bigint[]) as id
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT  activityalias AS flowtoname
    //   FROM wms_workflowdefinition WHERE wfdefid in ( SELECT flowto
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT  activityalias AS fromactivityname
    //   FROM wms_workflowdefinition WHERE wfdefid in ( SELECT filesrcactivity
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT string_agg(filetype, ', ') AS fromfiletypename from public.pp_mst_filetype WHERE filetypeid in (SELECT srcfiletypeid
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    //   (SELECT string_agg(filetype, ', ') AS tofiletypename from public.pp_mst_filetype WHERE filetypeid in (SELECT destfiletypeid
    //       FROM public.wms_filemovementconfig WHERE flowto = ${wfdefId})),
    // *
    // from public.wms_filemovementconfig where flowto in (${wfdefId})`;
    const response = await query(sql);
    res.status(200).json({ data: response });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getWfFilename = async (req, res) => {
  // eslint-disable-next-line no-unused-vars
  const { type, wfId, stageId } = req.body;
  let sql = '';

  sql = `with cte as (
      SELECT (fileconfig->> 'files')::JSON as files FROM wms_workflowdefinition where stageid=${stageId}
    ) 
    select files from cte where files is not null
    `;

  logger.info(sql, 'sql for options');
  query(sql)
    .then(response => {
      const wfFileName = [];
      if (response.length) {
        response[0].files.forEach(item => {
          wfFileName.push({ label: item.name, value: item.name });
        });
      }
      res.status(200).json({ data: wfFileName });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const deleteFileTransferList = async (req, res) => {
  try {
    const { userId, id, action, form, wfId, stageId, activityId } = req.body;
    const systemInfo = {
      systemIP: requestIp.getClientIp(req),
      publicIP: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
      ...JSON.parse(req.headers.systemdetail),
    };

    let sql = `INSERT INTO public.wms_workflow_activityconfig_audit(
      wfid, stageid, activityid, formtype, sourcedata, updatedby, updatedon, action, systeminfo)
  ( select wfid, stageid,activityid, '${form}' as formtype,
   (select json_build_object('fmconfigid', fmconfigid, 'flowfrom', flowfrom, 'flowto', flowto, 'filesrcactivity', filesrcactivity, 'source', source, 'destination', destination, 'commonfolderpath', commonfolderpath, 'srcfiletypeid', srcfiletypeid, 'destfiletypeid', destfiletypeid, 'isincomingsrc', isincomingsrc, 'istemplatesrc',istemplatesrc, 'filepriority', filepriority) from wms_filemovementconfig where fmconfigid = ${id}
    )::JSON as sourcedata, 
   '${userId}' as updatedby, current_timestamp, '${action}', '${JSON.stringify(
      systemInfo,
    )}' from wms_workflowdefinition where wfid=${wfId} and stageid=${stageId} and activityid=${activityId} )`;
    await query(sql);
    sql = `DELETE FROM public.wms_filemovementconfig WHERE fmconfigid=${id}`;
    const response = await query(sql);
    res.status(200).json({
      data: response,
      message: 'File movement configuration deleted successfully',
    });
  } catch (error) {
    res.status(400).send({ message: error });
  }
};

export const getUserMapDU = (req, res) => {
  const { userid } = req.body;
  const sql = `SELECT * FROM public.org_mst_deliveryunit WHERE duid = ANY (SELECT unnest(mappedduid) FROM wms_user where userid = '${userid}' )`;
  console.log('sqlllll', sql);
  query(sql)
    .then(response => {
      logger.info('getUserMultiDU', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const updateUserMapDU = (req, res) => {
  const { selectDUid, userid } = req.body;
  const sql = `UPDATE wms_user SET mappedduid = ARRAY[${selectDUid}]::integer[] WHERE userid = '${userid}'`;
  console.log('sqlllll', sql);
  query(sql)
    .then(response => {
      logger.info('updateUserMapDU', response);
      res
        .status(200)
        .json({ message: 'Successfully updated the Mapping DU for the user' });
    })
    .catch(error => {
      res.status(400).send({
        message: `Failed to mapped the DU for the user. => ${error}`,
      });
    });
};

export const getAllMasterStages = (req, res) => {
  const { wfid } = req.body;
  const sql = `select * from wms_mst_stage where stageid in (select distinct(stageid) 
  from public.wms_workflowdefinition where wfid=${wfid})`;

  query(sql)
    .then(response => {
      logger.info('get All Masters Stages', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageOrder = (req, res) => {
  const { wfid } = req.body;
  const sql = `SELECT DISTINCT ON (stageid) stageorder.stageid, stage.stagename, sequence, islock
    FROM public.ms_mst_workflowstageorder as stageorder JOIN wms_mst_stage as stage on 
    stageorder.stageid = stage.stageid WHERE stageorder.wfid = ${wfid}`;

  query(sql)
    .then(response => {
      logger.info('get Stages Orders By wfid', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const saveStageOrder = (req, res) => {
  const stageOrders = req.body;
  const { wfid } = req.query;

  const values = [];

  stageOrders.forEach((item, index) => {
    values.push(`('${wfid}', '${item.stageid}', '${index}', '${false}')`);
  });

  const sql = `INSERT INTO ms_mst_workflowstageorder (wfid, stageid, sequence, islock) VALUES ${values}`;

  query(sql, [])
    .then(response => {
      logger.info('Save stages');
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getAllMasterActivities = (req, res) => {
  const { stageid } = req.body;
  const sql = `select * from wms_mst_activity where activityid in(select distinct(activityid) 
  from public.wms_workflowdefinition where stageid=${stageid})`;

  query(sql)
    .then(response => {
      logger.info('All master activity', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const getStageSpecificActivities = (req, res) => {
  const { wfid, stageid } = req.body;
  const sql = `SELECT DISTINCT ON (activityid) activityorder.activityid, activity.activityname, 
    sequence, islock FROM public.ms_mst_workflowactivityorder as activityorder JOIN
    wms_mst_activity as activity on activityorder.activityid = activity.activityid WHERE 
    activityorder.wfid = ${wfid} and activityorder.stageid = ${stageid}`;

  query(sql)
    .then(response => {
      logger.info('get activity order by wfid and stageid', response);
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};

export const saveActivityOrder = (req, res) => {
  const activityOrder = req.body;
  const { wfid, stageid } = req.query;

  const values = [];

  activityOrder.forEach((item, index) => {
    values.push(
      `('${wfid}', '${stageid}', '${item.activityid}', '${index}', '${false}')`,
    );
  });

  const sql = `INSERT INTO ms_mst_workflowactivityorder (wfid, stageid, activityid, sequence, islock) VALUES ${values}`;

  query(sql, [])
    .then(response => {
      logger.info('Save activities');
      res.status(200).json({ data: response });
    })
    .catch(error => {
      res.status(400).send({ message: error });
    });
};
