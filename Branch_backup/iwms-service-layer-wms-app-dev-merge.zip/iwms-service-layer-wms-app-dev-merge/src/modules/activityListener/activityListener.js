import { EventEmitter } from 'events';
import { sendToNotificationQueue } from '../../mq/index.js';
import logger from '../utils/logs/index.js';

const ACTION = 'action';

class ActivityListener extends EventEmitter {
  emitAction(payload) {
    this.emit(ACTION, payload);
  }
}

const activityListener = new ActivityListener();

activityListener.on(ACTION, async payload => {
  try {
    await sendToNotificationQueue(payload);
  } catch (e) {
    logger.info(e);
  }
});

export const emitAction = activityListener.emitAction.bind(activityListener);
