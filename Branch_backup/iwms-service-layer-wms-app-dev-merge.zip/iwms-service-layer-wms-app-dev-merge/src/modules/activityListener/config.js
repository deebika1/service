export const actions = {
  wfCreated: 'WF_CREATED',
  wfClaimed: 'WF_CLAIMED',
  wfUnClaimed: 'WF_UNCLAIMED',
  wfWip: 'WF_WIP',
  wfSaved: 'WF_SAVED',
  wfHold: 'WF_HOLD',
  wfPended: 'WF_PENDED',
  wfRejected: 'WF_REJECTED',
  wfCancelled: 'WF_CANCELLED',

  wfResetted: 'WF_RESETTED',

  woCreated: 'WO_CREATED',
  woUpdated: 'WO_UPDATED',
};
