/* eslint-disable class-methods-use-this */
import axios from 'axios';
import { config } from '../config/restApi.js';
import logger from '../modules/utils/logs/index.js';

export class Service {
  // eslint-disable-next-line no-useless-constructor, no-empty-function
  constructor() {}

  post(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'POST',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({
            status: true,
            data: response.data,
            statusCode: response.status,
          });
        })
        .catch(err => {
          console.log(err, 'errr post method');
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  uploadPost(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'POST',
        url,
        data: reqData,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
          'Access-Control-Allow-Origin': true,
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          console.log(err, 'errr post method');
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  put(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'PUT',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  get(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'GET',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  delete(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'DELETE',
        url,
        data: reqData,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          reject({
            status: false,
            message: err.response ? err.response : err.message,
          });
        });
    });
  }

  invokeService(conf) {
    return new Promise((resolve, reject) => {
      axios(conf)
        .then(response => {
          logger.info(`${response}Tool Invoked`);
          resolve({ status: true, data: response.data });
        })
        .catch(err => {
          logger.info(`${err}Tool Invoked Error`);
          reject({
            status: false,
            message:
              err.response && err.response.data && err.response.data.message
                ? err.response.data.message
                : err.response.statusText
                ? err.response.statusText
                : err.message,
          });
        });
    });
  }

  upload(url, reqData, additionalHeaders = {}) {
    return new Promise((resolve, reject) => {
      axios({
        method: 'POST',
        url,
        data: reqData,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        maxRedirects: 0,
        headers: {
          'Access-Control-Allow-Origin': true,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...additionalHeaders,
        },
      })
        .then(response => {
          resolve(response.data);
        })
        .catch(err => {
          const message = err.response?.data?.message
            ? err.response.data.message
            : err.response?.data
            ? err.response.data
            : err.message;
          reject({ status: false, message, additionalInfo: { url } });
        });
    });
  }

  // iTracks post
  iPost(url, reqData, additionalHeaders = {}) {
    return new Promise(async (resolve, reject) => {
      try {
        const gerUrl = await axios.get(config.iTracks.switch_url);
        console.log(gerUrl.data, 'gerUrl');
        console.log(
          `https://${gerUrl.data}/${config.iTracks.service_url}`,
          'constructed url',
        );

        axios({
          method: 'POST',
          url: `https://${gerUrl.data}/${config.iTracks.service_url}`,
          data: reqData,
          headers: {
            'Access-Control-Allow-Origin': true,
            'Content-Type': 'application/json',
            Accept: 'application/json',
            ...additionalHeaders,
          },
        })
          .then(response => {
            resolve({ status: true, data: response.data });
          })
          .catch(err => {
            console.log(err, 'errr');
            reject({
              status: false,
              message: err.response ? err.response : err.message,
            });
          });
      } catch (e) {
        reject({ status: false, message: e });
      }
    });
  }
}
