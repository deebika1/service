import jsv from 'json-validator';
import logger from '../modules/utils/logs/index.js';

export const validator = (reqData, userSchema) => {
  let response = {};
  jsv.validate(reqData, userSchema, (err, messages, test, test1) => {
    if (err) {
      throw err;
    }
    logger.info(test1, 'messagesmessages');
    if (Object.keys(messages).length) {
      response = { status: false, message: test1[0] };
    } else {
      response = { status: true, message: [] };
    }
  });

  return response;
};
